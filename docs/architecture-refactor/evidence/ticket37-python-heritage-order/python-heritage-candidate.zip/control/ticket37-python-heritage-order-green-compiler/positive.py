from nekojs._java.java.nio.channels.spi import AbstractInterruptibleChannel
from nekojs._java.java.nio.channels import Channel, InterruptibleChannel
from nekojs._java.java.lang import AutoCloseable
def valid(value: AbstractInterruptibleChannel) -> tuple[Channel, InterruptibleChannel, AutoCloseable, bool]:
    value.close()
    return value, value, value, value.open
