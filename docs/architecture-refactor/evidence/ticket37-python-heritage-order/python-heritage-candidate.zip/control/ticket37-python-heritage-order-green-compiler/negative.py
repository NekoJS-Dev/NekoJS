from nekojs._java.java.nio.channels.spi import AbstractInterruptibleChannel
def invalid(value: AbstractInterruptibleChannel) -> int:
    return value.notAnExposedMember()
