/// <reference path="../../../@registry-builders/index.d.ts" />

interface DynamicRegistryEvent {
    item(id: string, build?: (build: DynamicItemBuilder) => void): boolean;
    mobEffect(id: string, build?: (build: DynamicMobEffectBuilder) => void): boolean;
    soundEvent(id: string, build?: (build: DynamicSoundEventBuilder) => void): boolean;
}

declare module "@side-only/startup/events" {
}

export {};

declare global {
    namespace DynamicRegistryEvents {
        function dynamicRegistry(handler: ((event: DynamicRegistryEvent) => void)): void;
    }

}
