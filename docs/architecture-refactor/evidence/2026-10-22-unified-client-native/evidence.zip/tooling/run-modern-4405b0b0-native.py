import json
import subprocess
import sys
from pathlib import Path

p = Path.cwd()
raw = p / 'build/priority-closeout'
for short in ['261', '262']:
    with (raw / (short + '-4405b0b0-native-run.log')).open('xb') as output:
        code = subprocess.run([sys.executable, str(raw / ('run-posteffects-' + short + '-4405b0b0.py'))],
            stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW).returncode
    result = json.loads((raw / ('posteffects-' + short + '-installed-4405b0b0-v1/run-result.json')).read_text())
    assert code == 0 and result['mechanicalVerdict'] == 'PASS', (short, code, result)
    print('LATEST_INSTALLED_NATIVE_MECHANICAL_PASS', short, flush=True)
