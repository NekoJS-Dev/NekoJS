import hashlib
import json
import zipfile
from pathlib import Path

p = Path.cwd()
raw = p / 'build/priority-closeout'
out = p / 'docs/architecture-refactor/evidence/2026-10-22-unified-client-native'
assert not (out / 'evidence.zip').exists()
out.mkdir(exist_ok=True)
entries = {}
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    def add(f, name):
        assert name not in entries
        data = f.read_bytes()
        entries[name] = dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
        z.writestr(name, data)
    for short in ['261', '262']:
        trial = raw / ('posteffects-' + short + '-installed-4405b0b0-v1')
        assert json.loads((trial / 'pixel-review.json').read_text())['verdict'] == 'PASS'
        for f in sorted(trial.iterdir()):
            if f.is_file() and f.suffix in {'.json', '.jsonl', '.log', '.png', '.gradle'}:
                add(f, short + '/' + f.name)
        for f in sorted((trial / 'src').rglob('*')):
            if f.is_file():
                add(f, short + '/src/' + f.relative_to(trial / 'src').as_posix())
        for side in ['client', 'server']:
            for name in ['stdout.log', 'stderr.log', 'installed-source.json', 'owned-process.json', 'thread-startup-observation.txt']:
                f = trial / side / name
                if f.exists():
                    add(f, short + '/' + side + '/' + name)
            for f in sorted((trial / side / 'nekojs').rglob('*')):
                if f.is_file() and f.suffix in {'.js', '.toml'} and 'data' not in f.relative_to(trial / side / 'nekojs').parts:
                    add(f, short + '/' + side + '/nekojs/' + f.relative_to(trial / side / 'nekojs').as_posix())
        for name in ['run-posteffects-' + short + '-4405b0b0.py', 'review-' + short + '-4405b0b0.py',
                     short + '-4405b0b0-native-run.log']:
            add(raw / name, 'tooling/' + name)
    for name in ['prepare-modern-4405b0b0-native.py', 'run-modern-4405b0b0-native.py',
                 '4405b0b0-runtime-class-reuse.json', 'seal-latest-modern-native.py']:
        add(raw / name, 'tooling/' + name)
references = {name: hashlib.sha256((p / 'docs/architecture-refactor/evidence' / name / 'evidence.zip').read_bytes()).hexdigest()
    for name in ['2026-10-22-posteffects-legacy-installed', '2026-10-22-dynamic-tcp']}
(out / 'manifest.json').write_text(json.dumps(dict(entries=entries,
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    sourceRevision='4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349', references=references), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size)))
