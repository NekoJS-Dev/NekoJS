import hashlib
import json
import shutil
from pathlib import Path

p = Path.cwd()
raw = p / 'build/priority-closeout'
candidate = p / 'build/closeout-4405b0b0-installed'
manifest = json.loads((candidate / 'preparation-manifest.json').read_text())
for short, node, source_name, runner_name, port, prior_port in [
    ('261', '26.1.2', 'posteffects-261-installed-d91ca974-v2', 'run-posteffects-261-installed-v2.py', 29591, 28691),
    ('262', '26.2.0', 'posteffects-262-installed-d91ca974-v1', 'run-posteffects-262-installed.py', 29691, 29191)]:
    source = raw / source_name
    root = raw / ('posteffects-' + short + '-installed-4405b0b0-v1')
    assert not root.exists()
    root.mkdir()
    for file in ['settings.gradle', 'build.gradle']:
        (root / file).write_text((source / file).read_text().replace(source.name, root.name)
            .replace(str(prior_port), str(port)))
    shutil.copytree(source / 'src', root / 'src')
    for side in ['client', 'server']:
        for folder in ['config', 'startup_scripts', side + '_scripts']:
            shutil.copytree(source / side / 'nekojs' / folder, root / side / 'nekojs' / folder,
                ignore=shutil.ignore_patterns('*.rejected*'))
        shutil.copytree(candidate / node / 'mods', root / side / 'mods')
    (root / 'client/nekojs/data').mkdir()
    (root / 'client/nekojs/data/step.txt').write_text('idle')
    shutil.copyfile(source / 'client/options.txt', root / 'client/options.txt')
    shutil.copyfile(source / 'server/eula.txt', root / 'server/eula.txt')
    (root / 'server/server.properties').write_text((source / 'server/server.properties').read_text()
        .replace(str(prior_port), str(port)).replace(str(prior_port + 1), str(port + 1)))
    (root / 'server/libraries').symlink_to((source / 'server/libraries').resolve(), target_is_directory=True)
    node_row = next(row for row in manifest['nodes'] if row['node'] == node)
    (root / 'artifact-manifest.json').write_text(json.dumps(dict(sourceRevision=manifest['sourceRevision'],
        nodeClassBindings=node_row['classBindings'], artifacts=[dict(name=f.name,
            sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in (root / 'client/mods').glob('*.jar')]), indent=2) + '\n')
    runner = (raw / runner_name).read_text().replace(source.name, root.name)
    (raw / ('run-posteffects-' + short + '-4405b0b0.py')).write_text(runner)
    (root / 'preparation.json').write_text(json.dumps(dict(sourceRevision=manifest['sourceRevision'],
        freshWorld=True, node=node, priorSuccessfulFixture=source.name,
        reason='Replay the same installed-client acceptance on the latest unified candidate.'), indent=2) + '\n')
    print(root)
