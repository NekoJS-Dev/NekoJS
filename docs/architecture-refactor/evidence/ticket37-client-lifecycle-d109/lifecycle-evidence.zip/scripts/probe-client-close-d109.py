import json
import sys
import time
from pathlib import Path

root = Path.cwd().resolve() / 'build/ticket37-client-lifecycle-d109'
letter = sys.argv[1]
assert letter in ('A', 'B')
client = root / ('client' + letter)
assert not (client / 'close-probe.json').exists()
signal = client / 'nekojs/data/visual-step.txt'
pending = signal.with_suffix('.pending')
pending.write_text('close\n', encoding='ascii')
started = time.monotonic()
pending.replace(signal)
deadline = started + 10
while time.monotonic() < deadline and not (client / 'exit.json').exists():
    time.sleep(0.1)
text = (client / 'stdout.log').read_text(encoding='utf-8', errors='replace')
stop_seen = 'LIFECYCLE-OWNED-STOP requested=true' in text
direct = json.loads((client / 'exit.json').read_text()) if (client / 'exit.json').exists() else None
result = dict(client=letter, stopRequestedOnTickOwner=stop_seen, directExit=direct,
              observedSeconds=round(time.monotonic() - started, 3), thresholdSeconds=10,
              result='PASS' if stop_seen and direct is not None and direct['exitCode'] == 0 else 'FAIL')
(client / 'close-probe.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
sys.exit(0 if result['result'] == 'PASS' else 1)
