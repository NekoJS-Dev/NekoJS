import json
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
repair = project / 'build/ticket37-config-sync-repair'
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision == 'd10912ebbf24d9d5df75a908dc7a5529da09979a'
for name in ('prepare-client93-visual-resumed', 'run-client93-resumed', 'api-client93-resumed', 'rcon-client93-resumed', 'step-client93-visual-resumed', 'setup-client93-scene-resumed'):
    text = (repair / (name + '.py')).read_text(encoding='utf-8')
    text = text.replace('ticket37-client93-resumed', 'ticket37-client-lifecycle-d109')
    for helper in ('api-client93-resumed', 'rcon-client93-resumed'):
        text = text.replace(helper + '.py', helper + '-d109.py')
    if name == 'prepare-client93-visual-resumed':
        text = text.replace('93f4b259ffafb6466918582fcfa950c2c2480d77', revision)
        text = text.replace("installed / 'mods' / entry['artifact']", "project / 'versions/26.2.0/build/libs' / entry['artifact']")
        text = text.replace("assert sha(artifact) == entry['sha256']", "entry['sha256'] = sha(artifact)\nassert entry['sha256'] == 'fde6c16ba1b6fbca43dfc87aff4bf9709c1925bcb2d72c307f2e73346922f092'")
        text = text.replace("for jar in (artifact, graal, bridge):", "for jar in ((artifact, graal, bridge) if letter == 'A' else (artifact, graal)):")
    with (repair / (name + '-d109.py')).open('x', encoding='utf-8') as output:
        output.write(text)
print('CURRENT_LIFECYCLE_HELPERS_PREPARED')
