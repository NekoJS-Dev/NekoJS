import sys
from pathlib import Path

letter, step = sys.argv[1:]
assert letter in ('A', 'B') and step in ('clear', 'vanilla')
signal = Path.cwd().resolve() / 'build/ticket37-client-lifecycle-d109' / ('client' + letter) / 'nekojs/data/visual-step.txt'
pending = signal.with_suffix('.pending')
pending.write_text(step + '\n', encoding='ascii')
pending.replace(signal)
print('OWNED_SIGNAL_WRITTEN', letter, step)
