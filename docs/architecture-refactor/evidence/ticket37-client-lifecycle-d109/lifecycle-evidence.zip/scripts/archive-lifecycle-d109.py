import hashlib
import json
import shutil
import socket
import subprocess
import zipfile
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/ticket37-client-lifecycle-d109'
destination = project / 'docs/architecture-refactor/evidence/ticket37-client-lifecycle-d109'
destination.mkdir(exist_ok=True)
assert not (destination / 'lifecycle-evidence.zip').exists()
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert source == 'd10912ebbf24d9d5df75a908dc7a5529da09979a'
sha = lambda data: hashlib.sha256(data).hexdigest()
preparation = json.loads((root / 'preparation.json').read_text())
artifact_hash = 'fde6c16ba1b6fbca43dfc87aff4bf9709c1925bcb2d72c307f2e73346922f092'
assert preparation['productionRevision'] == source and preparation['artifactSha256'] == artifact_hash
for port in (25981, 25982, 9876, 9875, 9874):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
properties = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines() if '=' in line)
secret = properties['rcon.password'].encode()
class_bindings = {}
for node in ('server', 'clientA', 'clientB'):
    jar_path = root / node / 'mods' / preparation['artifact']
    assert sha(jar_path.read_bytes()) == artifact_hash
    with zipfile.ZipFile(jar_path) as jar:
        for name in jar.namelist():
            if not name.startswith('com/tkisor/nekojs/') or not name.endswith('.class'):
                continue
            paths = [project / 'versions/26.2.0/build/classes/java/main' / name,
                     project / 'common/build/classes/java/main' / name]
            compiled = next((path for path in paths if path.is_file()), None)
            if compiled is not None:
                actual = sha(jar.read(name))
                assert actual == sha(compiled.read_bytes()), (node, name)
                if node == 'server':
                    class_bindings[name] = actual
assert len(class_bindings) > 100
assert (root / 'clientA/mods/minecraft-mcp-26.2-neoforge.jar').exists()
assert not (root / 'clientB/mods/minecraft-mcp-26.2-neoforge.jar').exists()
exits = {node: json.loads((root / node / 'exit.json').read_text())['exitCode'] for node in ('server', 'clientA', 'clientB')}
assert exits == dict(server=0, clientA=4294967295, clientB=0)
probes = {letter: json.loads((root / ('client' + letter) / 'close-probe.json').read_text()) for letter in ('A', 'B')}
assert probes['A']['result'] == 'FAIL' and probes['A']['stopRequestedOnTickOwner'] and probes['A']['directExit'] is None
assert probes['B']['result'] == 'PASS' and probes['B']['directExit']['exitCode'] == 0
minimal = {mode: json.loads((root / ('bridge-' + mode) / 'result.json').read_text()) for mode in ('original', 'dispose-executor', 'no-request')}
assert minimal['original']['result'] == 'FAIL' and minimal['original']['forcedCleanup']
assert minimal['original']['statusRequestVerified'] and minimal['original']['bridgeStopReturned']
assert all(minimal[mode]['result'] == 'PASS' and not minimal[mode]['forcedCleanup'] for mode in ('dispose-executor', 'no-request'))
assert not minimal['no-request']['statusRequestVerified']
assert 'executorShutdown=false' in (root / 'bridge-original/stdout.log').read_text()
assert 'executorTerminated=true' in (root / 'bridge-dispose-executor/stdout.log').read_text()
assert not list(root.glob('client*/hs_err_pid*.log'))
screenshots = {letter: sorted((root / ('client' + letter) / 'screenshots').glob('*.png')) for letter in ('A', 'B')}
assert all(len(paths) == 4 for paths in screenshots.values())
assert len({sha(path.read_bytes()) for paths in screenshots.values() for path in paths}) == 8
def readings(letter, marker):
    text = (root / ('client' + letter) / 'stdout.log').read_text(encoding='utf-8', errors='replace')
    return [json.loads(line.split(marker + ' ', 1)[1]) for line in text.splitlines() if marker + ' ' in line]
hud = {letter: readings(letter, 'CLIENT93-FIRST-HUD') for letter in ('A', 'B')}
assert all([row['generation'] for row in values] == [1, 2] and values[-1]['declared'] and values[-1]['active'] for values in hud.values())
steps = {letter: readings(letter, 'CLIENT93-VISUAL-STEP') for letter in ('A', 'B')}
assert all(any(row['step'] == 'clear' and row['generation'] == 2 and not row['active'] for row in values) for values in steps.values())
bytecode = (root / 'bridge-http-bytecode.txt').read_text(encoding='utf-8')
pool_lines = [line for line in bytecode.splitlines() if 'newFixedThreadPool' in line or 'setExecutor' in line]
stop_body = bytecode.split('  public void stop();', 1)[1].split('\n  private ', 1)[0]
(root / 'bridge-executor-excerpt.txt').write_text('\n'.join(pool_lines) + '\n  public void stop();' + stop_body, encoding='utf-8')
summary = dict(sourceRevision=source, artifactSha256=artifact_hash, compiledClassBindings=class_bindings,
    loader='NeoForge26.2.0.75', java='JDK25.0.2', bridgeSha256=preparation['bridgeSha256'],
    nativeBeforeAndAfterReloadPixels='PASS', nativeScreenshots={letter: [path.name for path in paths] for letter, paths in screenshots.items()},
    firstHud=hud, steps=steps, firstPixelFrame='NOT_VERIFIED', crossNode='NOT_RUN',
    directExits=exits, closeProbes=probes, minimalActualBridgeProbes=minimal,
    shutdownCause='Installed bridge HTTP executor is not shut down; isolated actual class proves non-daemon request workers keep JVM alive',
    bridgeProductFixed=False, bridgeJarChanged=False, bridgeDisposalControlOnly=True,
    nativeGlfwCrash='NOT_REPRODUCED in these two sequential sessions; historical cause remains NOT_ESTABLISHED',
    currentFullIDE='NOT_RERUN', currentFormalPerformance='NOT_RUN', productionSourceChangedThisTurn=False,
    ownedPortsFree=True, overall='NOT_COMPLETE', humanAcceptance='NOT_RECORDED')
(destination / 'runtime-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
files = {}
def add(path, name):
    data = path.read_bytes()
    assert secret not in data, 'Credential found in selected artifact: ' + name
    assert name not in files
    files[name] = data
for name in ('preparation.json', 'PLAN.md', 'LIFECYCLE-PLAN.md', 'api-actions.jsonl', 'rcon.jsonl', 'visual-captures.jsonl',
             'BridgeExitProbe.java', 'BridgeExitProbe-first.java', 'probe-bridge-exit-first.py', 'bridge-executor-excerpt.txt'):
    path = root / name
    if path.exists():
        add(path, 'runtime/' + name)
for node in ('server', 'clientA', 'clientB'):
    directory = root / node
    for name in ('stdout.log', 'stderr.log', 'owned-process.json', 'exit.json', 'close-probe.json', 'options.txt', 'forced-cleanup.json', 'shutdown-thread-dump.txt', 'bridge-binding.json'):
        path = directory / name
        if path.exists():
            add(path, 'runtime/' + node + '/' + name)
    for path in (directory / 'logs').glob('*.log'):
        add(path, 'runtime/' + node + '/logs/' + path.name)
    for folder in ('config', 'startup_scripts', 'server_scripts', 'client_scripts'):
        for path in (directory / 'nekojs' / folder).rglob('*'):
            if path.is_file() and path.suffix in ('.js', '.toml'):
                add(path, 'runtime/' + node + '/' + path.relative_to(directory).as_posix())
    for path in (directory / 'screenshots').glob('*.png'):
        add(path, 'runtime/' + node + '/screenshots/' + path.name)
for path in (root / 'captures').glob('*.png'):
    add(path, 'runtime/captures/' + path.name)
for mode in minimal:
    for path in (root / ('bridge-' + mode)).iterdir():
        if path.is_file():
            add(path, 'runtime/bridge-' + mode + '/' + path.name)
repair = project / 'build/ticket37-config-sync-repair'
for pattern in ('*d109.py',):
    for path in repair.glob(pattern):
        add(path, 'scripts/' + path.name)
add(repair / 'prepare-lifecycle-close-probe.py', 'scripts/prepare-lifecycle-close-probe.py')
add(destination / 'runtime-summary.json', 'runtime-summary.json')
archive = destination / 'lifecycle-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(files.items()):
        output.writestr(name, data)
entries = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(files.items())}
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    assert all(sha(output.read(name)) == row['sha256'] for name, row in entries.items())
manifest = dict(sourceRevision=source, entries=entries, archive=dict(file=archive.name, entries=len(entries), bytes=archive.stat().st_size, sha256=sha(archive.read_bytes())),
    actualCredentialScan='PASS', readback='PASS', exclusions=['server.properties/credentials', 'world', 'launcher/accounts/argfiles', 'binaries/libraries/assets', 'unrelated desktop images'])
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for letter, paths in screenshots.items():
    for index, path in enumerate(paths):
        shutil.copyfile(path, destination / (letter.lower() + '-' + ['clear', 'blur', 'reload-blur', 'reload-clear'][index] + '.png'))
print(json.dumps(dict(archive=manifest['archive'], classEntries=len(class_bindings), pixels='PASS', bridgeProductFixed=False, overall='NOT_COMPLETE')))
