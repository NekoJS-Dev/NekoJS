import json
import socket
import subprocess
import sys
import time
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/ticket37-client-lifecycle-d109'
mode = sys.argv[1]
assert mode in ('original', 'dispose-executor', 'no-request')
directory = root / ('bridge-' + mode)
directory.mkdir()
with socket.socket() as guard:
    guard.bind(('127.0.0.1', 9874))
java = Path('C:/Program Files/Java/jdk-25.0.2/bin/java.exe')
classpath = str(root) + ';' + str(root / 'clientA/mods/minecraft-mcp-26.2-neoforge.jar')
started = time.monotonic()
with (directory / 'stdout.log').open('xb') as out, (directory / 'stderr.log').open('xb') as err:
    process = subprocess.Popen([str(java), '-cp', classpath, 'BridgeExitProbe', mode], cwd=root,
        stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
    (directory / 'owned-process.json').write_text(json.dumps(dict(pid=process.pid, executable=str(java), directory=str(root), mode=mode)))
    forced = False
    try:
        code = process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        forced = True
        process.kill()
        code = process.wait()
text = (directory / 'stdout.log').read_text(encoding='utf-8')
result = dict(mode=mode, statusRequestVerified='OWNED_STATUS_REQUEST_PASS' in text,
    bridgeStopReturned='BRIDGE_STOP_RETURNED' in text, forcedCleanup=forced,
    exitCode=code, elapsedSeconds=round(time.monotonic()-started, 3),
    result='PASS' if not forced and code == 0 and ('executorTerminated=true' in text or mode == 'no-request') else 'FAIL')
(directory / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
sys.exit(0 if result['result'] == 'PASS' else 1)
