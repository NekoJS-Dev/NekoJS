import com.sun.net.httpserver.HttpServer;
import java.lang.reflect.Field;
import java.net.URI;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import xyz.langyo.minecraft.mcp.common.McpHttpServer;

public final class BridgeExitProbe {
    public static void main(String[] args) throws Exception {
        boolean dispose = args[0].equals("dispose-executor");
        McpHttpServer bridge = new McpHttpServer(null, 9874);
        bridge.start();
        Field field = McpHttpServer.class.getDeclaredField("server");
        field.setAccessible(true);
        HttpServer server = (HttpServer) field.get(bridge);
        ExecutorService executor = (ExecutorService) server.getExecutor();
        if (!args[0].equals("no-request")) {
          try (var body = URI.create("http://127.0.0.1:9874/api/status").toURL().openStream()) {
            String response = new String(body.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            if (!response.contains("\"pid\":" + ProcessHandle.current().pid())) {
                throw new AssertionError("Owned bridge PID mismatch");
            }
            System.out.println("OWNED_STATUS_REQUEST_PASS");
          }
        }
        bridge.stop();
        if (dispose) {
            executor.shutdown();
            if (!executor.awaitTermination(2, TimeUnit.SECONDS)) {
                throw new AssertionError("Owned bridge executor did not terminate");
            }
        }
        System.out.println("BRIDGE_STOP_RETURNED executorShutdown=" + executor.isShutdown()
                + " executorTerminated=" + executor.isTerminated());
    }
}
