# Current source owned client lifecycle probe

Source d10912eb, NeoForge26.2.0.75/JDK25.0.2, exact official JAR
fde6c16ba1b6fbca43dfc87aff4bf9709c1925bcb2d72c307f2e73346922f092.
Fresh server/world and A/B profiles with identical owned script/config/mod
bytes except A includes the pinned Minecraft HTTP bridge and B excludes it.
Start A first. Observe actual world, clear/blur, game-native F2 and F3+T,
then request Minecraft.stop through the tick owner in the existing fixture.
Assert shutdown completes in ten seconds; retain a failed direct observation,
owned JVM thread dump and checked cleanup if it remains alive. Then run B
with the same game-close path, no bridge, and compare direct exit.
This is a diagnosis control, not all-node acceptance or a native-crash fix.
GLFW window-activation crashes require their own reproducible input loop.
Never automate user games, change security or hide failed observations.
The inherited PLAN.md is the old fixture template, not this control plan.
