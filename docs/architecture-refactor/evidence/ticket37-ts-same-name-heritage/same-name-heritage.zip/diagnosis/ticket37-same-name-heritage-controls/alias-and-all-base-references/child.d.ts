import { $PersistentData as $BasePersistentData } from "java:com/tkisor/nekojs/probe/testfixture/samebase";

declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export class $PersistentData extends $BasePersistentData<string> {
        constructor(value: string);
        acceptBase(value: $BasePersistentData<string>): string;
    }

}
