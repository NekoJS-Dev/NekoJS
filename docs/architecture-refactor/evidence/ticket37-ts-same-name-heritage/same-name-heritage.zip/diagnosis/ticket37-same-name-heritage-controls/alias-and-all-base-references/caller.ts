import { $PersistentData as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData as Child } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
const child = new Child("child");
const base: Base<string> = child;
const inherited: string = child.baseValue();
const accepted: string = child.acceptBase(new Base<string>("base"));
export {base, inherited, accepted};
