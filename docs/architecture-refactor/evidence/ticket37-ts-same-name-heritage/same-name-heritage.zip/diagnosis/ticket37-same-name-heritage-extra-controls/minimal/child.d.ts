import { $PersistentData } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export class $PersistentData extends $PersistentData<string> {}
}
