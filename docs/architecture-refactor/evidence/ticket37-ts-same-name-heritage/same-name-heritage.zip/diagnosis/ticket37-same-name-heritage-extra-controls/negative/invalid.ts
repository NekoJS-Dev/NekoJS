import { $PersistentData as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData as Child } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
new Child(1);
new Child("ok").acceptBase(new Base<number>(1));
const wrong: number = new Child("ok").baseValue();
export {wrong};
