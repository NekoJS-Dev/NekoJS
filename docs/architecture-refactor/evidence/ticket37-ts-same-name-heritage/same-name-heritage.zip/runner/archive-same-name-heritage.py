import hashlib
import io
import json
import re
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root=Path.cwd().resolve()
runner=root/'build/ticket37-config-sync-repair'
trial=root/'build/ticket37-constructor-member-installed'
out=root/'docs/architecture-refactor/evidence/ticket37-ts-same-name-heritage'
assert not out.exists()
out.mkdir()
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert revision.startswith('6fdf3c73')
baseline='a2f7f9facf71fb4b82bd29e0a9ad848f6faad35e'
assert not subprocess.check_output(['git','diff',baseline,revision,'--','common/src/main','src/main','versions'],text=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
files={}
for folder in ['ticket37-same-name-heritage-red','ticket37-same-name-heritage-controls',
    'ticket37-same-name-heritage-extra-controls','ticket37-same-name-heritage-focused',
    'ticket37-same-name-heritage-matrix','ticket37-same-name-heritage-platform-gates']:
    for path in sorted((root/'build'/folder).rglob('*')):
        if path.is_file(): files['diagnosis/'+folder+'/'+path.relative_to(root/'build'/folder).as_posix()]=path.read_bytes()
for name in ['check-same-name-heritage.py','control-same-name-heritage.py','extend-same-name-heritage-controls.py',
    'same-name-heritage-reflection.txt','same-name-heritage-matrix.txt','same-name-heritage-npm.txt',
    'same-name-heritage-platform.txt','archive-same-name-heritage.py']:
    files['runner/'+name]=(runner/name).read_bytes()
test_paths=['common/src/test/java/com/tkisor/nekojs/probe/TypeScriptSameNameHeritageTest.java',
    'common/src/test/java/com/tkisor/nekojs/probe/testfixture/samebase/PersistentData.java',
    'common/src/test/java/com/tkisor/nekojs/probe/testfixture/samechild/PersistentData.java']
for path in test_paths+['common/src/main/java/com/tkisor/nekojs/probe/backend/typescript/IndexFileGenerator.java',
    'common/src/main/java/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.java',
    'src/main/java/com/tkisor/nekojs/wrapper/item/PersistentDataJS.java']:
    files['source/'+path]=subprocess.check_output(['git','show',revision+':'+path])
files['source/test.patch']=subprocess.check_output(['git','diff',baseline,revision,'--'] )
preparation=json.loads((trial/'preparation-manifest.json').read_text())
files['installed/preparation-manifest.json']=(trial/'preparation-manifest.json').read_bytes()
files['installed/prior-repair-manifest.json']=(root/'docs/architecture-refactor/evidence/ticket37-ts-constructor-member-repair/manifest.json').read_bytes()
secrets=[]
nodes=[]
for row in preparation['nodes']:
    node=row['node']
    profile=trial/node
    for line in (profile/'server.properties').read_text().splitlines():
        if line.startswith('rcon.password='): secrets.append(line.partition('=')[2].encode())
    jars=list((profile/'mods').glob('nekojs-*.jar'))
    assert len(jars)==1 and sha(jars[0].read_bytes())==row['sha256']
    with ZipFile(jars[0]) as jar:
        renderer_sha=sha(jar.read('com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.class'))
        assert renderer_sha=='d4f2ae48dadd54cc6570d50741a8b969285928c9eecb1d914bcc252d96c628eb'
    for package in ['item','pdata']:
        path=profile/'.neko_probe/typescript/@package/com/tkisor/nekojs/wrapper'/package/'index.d.ts'
        files[f'installed/{node}/{package}.d.ts']=path.read_bytes()
    for side in ['server','startup']:
        report=(trial/'ide'/f'{node}-{side}-tsc.txt').read_bytes()
        files[f'installed/{node}/{side}-tsc.txt']=report
        files[f'installed/{node}/{side}-tsconfig.json']=(trial/'ide'/f'{node}-{side}-tsconfig.json').read_bytes()
        assert sum(b'TS2506' in line and b"'$PersistentDataJS'" in line for line in report.splitlines())==1
    item=files[f'installed/{node}/item.d.ts']
    assert b'export class $PersistentDataJS extends $PersistentDataJS {' in item
    assert b'import { $PersistentDataJS } from "java:com/tkisor/nekojs/wrapper/pdata";' in item
    nodes.append(dict(node=node,installedJarSha256=row['sha256'],rendererClassSha256=renderer_sha,
        existingSelfHeritageErrorsPerProject=1))
matrix=json.loads((root/'build/ticket37-same-name-heritage-matrix/summary.json').read_text())
assert matrix['total']==dict(xml=803,tests=4749,skipped=271,failures=0,errors=0)
assert b'BUILD SUCCESSFUL in 1m 42s' in files['runner/same-name-heritage-matrix.txt']
files['direct-exits.json']=json.dumps(dict(reflection=0,matrix=0,matrixToolSession=50948,
    npm=0,postBuildPlatformGates=0,redCollector=0,redCompiler=[2,2],controlCollector=0,
    controlsCompiler=[2,2,0],minimalCompiler=2,negativeModelCompiler=2,
    observation='Direct tool completion observed before snapshot and packaging'),indent=2).encode()
files['review.json']=json.dumps(dict(standards=dict(hard=0,heuristic=0),spec=dict(findings=0),
    mode='Independent read-only review of diagnostic tests; not production repair acceptance'),indent=2).encode()
def scan(data,suffix):
    if suffix=='.zip':
        with ZipFile(io.BytesIO(data)) as archive:
            for name in archive.namelist(): scan(archive.read(name),Path(name).suffix)
        return
    assert not any(secret and secret in data for secret in secrets),'Credential value in evidence'
    assert not re.search(rb'(?m)^rcon\.password=',data),'Credential line in evidence'
entries=[]
archive_path=out/'same-name-heritage.zip'
with ZipFile(archive_path,'x',ZIP_DEFLATED) as archive:
    for name,data in sorted(files.items()):
        scan(data,Path(name).suffix)
        archive.writestr(name,data)
        entries.append(dict(path=name,bytes=len(data),sha256=sha(data)))
summary=dict(sourceRevision=revision,baselineRevision=baseline,productionRevision='7b724a50f51367ad43f5903b1e7240e8e69bad10',
    productionChanges=False,productionRepair='NOT IMPLEMENTED',fullIde='FAIL; existing reports retained',
    nodes=nodes,matrix=matrix,archive=dict(file=archive_path.name,bytes=archive_path.stat().st_size,
    entries=len(entries),sha256=sha(archive_path.read_bytes())),entries=entries,
    exclusions=['properties/RCON credentials','worlds','JARs','raw JFR','active packaging console','unrelated data'])
(out/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in summary.items() if key!='entries'}))
