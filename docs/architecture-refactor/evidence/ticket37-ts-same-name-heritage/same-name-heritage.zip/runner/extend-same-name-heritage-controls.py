import json
import subprocess
from pathlib import Path

root=Path.cwd().resolve()
out=root/'build/ticket37-same-name-heritage-extra-controls'
assert not out.exists()
out.mkdir()
red=root/'build/ticket37-same-name-heritage-red'
model=root/'build/ticket37-same-name-heritage-controls/alias-and-all-base-references'
config=json.loads((red/'tsconfig.json').read_text())
minimal=out/'minimal'
minimal.mkdir()
(minimal/'base.d.ts').write_bytes((red/'base.d.ts').read_bytes())
(minimal/'child.d.ts').write_bytes(b'import { $PersistentData } from "java:com/tkisor/nekojs/probe/testfixture/samebase";\n'
    b'declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {\n'
    b'    export class $PersistentData extends $PersistentData<string> {}\n}\n')
config['files']=['base.d.ts','child.d.ts']
(minimal/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
result=subprocess.run(['node',str(root/'node_modules/typescript/bin/tsc'),'-p',str(minimal/'tsconfig.json'),
    '--pretty','false'],capture_output=True)
assert not result.stderr
(minimal/'tsc.txt').write_bytes(result.stdout)
assert result.returncode==2 and result.stdout.count(b': error TS')==1 and b'TS2506' in result.stdout
negative=out/'negative'
negative.mkdir()
for file in ['base.d.ts','child.d.ts']:
    (negative/file).write_bytes((model/file).read_bytes())
(negative/'invalid.ts').write_bytes(b'import { $PersistentData as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";\n'
    b'import { $PersistentData as Child } from "java:com/tkisor/nekojs/probe/testfixture/samechild";\n'
    b'new Child(1);\nnew Child("ok").acceptBase(new Base<number>(1));\n'
    b'const wrong: number = new Child("ok").baseValue();\nexport {wrong};\n')
config['files']=['base.d.ts','child.d.ts','invalid.ts']
(negative/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
invalid=subprocess.run(['node',str(root/'node_modules/typescript/bin/tsc'),'-p',str(negative/'tsconfig.json'),
    '--pretty','false'],capture_output=True)
assert not invalid.stderr
(negative/'tsc.txt').write_bytes(invalid.stdout)
assert invalid.returncode==2 and invalid.stdout.count(b': error TS')==3
summary=dict(minimal=dict(exitCode=result.returncode,diagnostics=result.stdout.decode().splitlines()),
    modelNegative=dict(exitCode=invalid.returncode,diagnostics=invalid.stdout.decode().splitlines()),
    productionRepair='NOT IMPLEMENTED')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
