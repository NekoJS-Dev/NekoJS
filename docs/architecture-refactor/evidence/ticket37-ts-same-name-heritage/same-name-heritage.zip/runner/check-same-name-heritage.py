import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
out = root/'build/ticket37-same-name-heritage-red'
assert not out.exists()
out.mkdir()
for name in ['base.d.ts', 'child.d.ts']:
    (out/name).write_bytes((root/'common/build/probe-ts-same-name-heritage'/name).read_bytes())
base = 'java:com/tkisor/nekojs/probe/testfixture/samebase'
child = 'java:com/tkisor/nekojs/probe/testfixture/samechild'
(out/'caller.ts').write_text(f'import {{ $PersistentData as Base }} from "{base}";\n'
    f'import {{ $PersistentData as Child }} from "{child}";\n'
    'const child = new Child("child");\nconst base: Base<string> = child;\n'
    'const inherited: string = child.baseValue();\n'
    'const accepted: string = child.acceptBase(new Base<string>("base"));\n'
    'export {base, inherited, accepted};\n', encoding='utf-8')
config = dict(compilerOptions=dict(strict=True,skipLibCheck=False,noEmit=True,types=[],target='ES2020',
    module='ESNext',moduleResolution='bundler',baseUrl='.',paths={base:['base.d.ts'],child:['child.d.ts']}),
    files=['base.d.ts','child.d.ts','caller.ts'])
(out/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
rows=[]
for index in range(2):
    result = subprocess.run(['node',str(root/'node_modules/typescript/bin/tsc'),'-p',str(out/'tsconfig.json'),
        '--pretty','false'],capture_output=True)
    (out/f'run-{index+1}.txt').write_bytes(result.stdout)
    assert not result.stderr
    rows.append(dict(exitCode=result.returncode,diagnostics=result.stdout.decode().splitlines()))
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows))
assert all(row['exitCode']==2 and any('TS2506' in line for line in row['diagnostics']) for row in rows)
assert rows[0]==rows[1]
