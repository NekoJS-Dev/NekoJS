import json
import subprocess
from pathlib import Path

root=Path.cwd().resolve()
red=root/'build/ticket37-same-name-heritage-red'
out=root/'build/ticket37-same-name-heritage-controls'
assert not out.exists()
out.mkdir()
original=(red/'child.d.ts').read_text()
cases={
    'heritage-without-generic': original.replace('extends $PersistentData<string>', 'extends $PersistentData'),
    'import-alias-only': original.replace('import { $PersistentData }', 'import { $PersistentData as $BasePersistentData }'),
    'alias-and-all-base-references': original.replace('import { $PersistentData }', 'import { $PersistentData as $BasePersistentData }')
        .replace('extends $PersistentData<string>', 'extends $BasePersistentData<string>')
        .replace('acceptBase(value: $PersistentData<string>)', 'acceptBase(value: $BasePersistentData<string>)'),
}
rows=[]
for name, candidate in cases.items():
    target=out/name
    target.mkdir()
    for file in ['base.d.ts','caller.ts','tsconfig.json']:
        (target/file).write_bytes((red/file).read_bytes())
    (target/'child.d.ts').write_bytes(candidate.encode())
    result=subprocess.run(['node',str(root/'node_modules/typescript/bin/tsc'),'-p',str(target/'tsconfig.json'),
        '--pretty','false'],capture_output=True)
    assert not result.stderr
    (target/'tsc.txt').write_bytes(result.stdout)
    rows.append(dict(control=name,exitCode=result.returncode,diagnostics=result.stdout.decode().splitlines()))
assert rows[0]['exitCode']==2 and any('TS2506' in line for line in rows[0]['diagnostics'])
assert rows[1]['exitCode']==2 and any('TS2506' in line for line in rows[1]['diagnostics'])
assert rows[2]['exitCode']==0
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows))
