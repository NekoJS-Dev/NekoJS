import { $TypeScriptConstructorMemberTest$StaticMember as Static, $TypeScriptConstructorMemberTest$InstanceMember as Instance, $TypeScriptConstructorMemberTest$BeanMember as Bean, $TypeScriptConstructorMemberTest$FieldMember as Field, $TypeScriptConstructorMemberTest$InterfaceMember as Interface, $TypeScriptConstructorMemberTest$InterfaceField as Constant, $TypeScriptConstructorMemberTest$EnumMember as Enum } from './index';
Static.constructor('bad');
new Instance().constructor(1);
new Bean().constructor = 'bad';
new Field().constructor = false;
Constant.constructor = 8;
const wrong: string = Enum.constructor;
export {wrong};
