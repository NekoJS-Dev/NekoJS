    export class $TypeScriptConstructorMemberTest$StaticMember {
        constructor();
        static ["constructor"](value: number): string;
        static ["constructor"](value: 3): string;
        other(): string;
    }
    export class $TypeScriptConstructorMemberTest$InstanceMember {
        constructor();
        ["constructor"](): string;
    }
    export class $TypeScriptConstructorMemberTest$BeanMember {
        constructor();
        get ["constructor"](): boolean;
        isConstructor(): boolean;
        set ["constructor"](value: boolean);
        setConstructor(value: boolean): void;
    }
    export class $TypeScriptConstructorMemberTest$FieldMember {
        constructor();
        ["constructor"]: number;
    }
    export interface $TypeScriptConstructorMemberTest$InterfaceMember {
    }
    export const $TypeScriptConstructorMemberTest$InterfaceMember: {
        ["constructor"](value: number): string;
    };
    export interface $TypeScriptConstructorMemberTest$InterfaceField {
    }
    export const $TypeScriptConstructorMemberTest$InterfaceField: {
        readonly ["constructor"]: number;
    };
    export class $TypeScriptConstructorMemberTest$EnumMember {
        static OTHER: $TypeScriptConstructorMemberTest$EnumMember;
        static ["constructor"]: $TypeScriptConstructorMemberTest$EnumMember;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TypeScriptConstructorMemberTest$EnumMember[];
        static valueOf(name: string): $TypeScriptConstructorMemberTest$EnumMember;
    }
