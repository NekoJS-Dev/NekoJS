interface Before {
    x: number;
    x(): number;
}
