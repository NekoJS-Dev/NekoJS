interface Fixture {
    readonly x: number;
    "x()"(): number;
    readonly m00: number;
    "m00(int)"(value: number): string;
    "m00(double)"(value: number): string;
    renamed(value: number): string;
    "original(int)"(value: number): string;
}
interface Matrix {
    m00: number;
    "m00()"(): number;
    "m00(double)"(value: number): Matrix;
}
declare const target: Fixture;
declare const matrix: Matrix;
const field: number = target.x;
const result: number = target["x()"]();
const extracted = target["x()"];
const called: number = extracted();
const integerResult: string = target["m00(int)"](2);
const doubleResult: string = target["m00(double)"](2.5);
const renamedResult: string = target.renamed(2);
const rawSelectorResult: string = target["original(int)"](2);
const current: number = matrix["m00()"]();
const updated: Matrix = matrix["m00(double)"](3);
// @ts-expect-error A field value is not callable after extraction.
const broken = field();
// @ts-expect-error This proposed spelling migration requires the explicit selector.
target.x();
// @ts-expect-error The selected Java setter accepts a number.
matrix["m00(double)"]("bad");
// @ts-expect-error Installed GraalMC selectors use the Java name, not @Remap.
target["renamed(int)"](2);
// @ts-expect-error Hidden methods have no selector declaration.
target["hidden()"]();
