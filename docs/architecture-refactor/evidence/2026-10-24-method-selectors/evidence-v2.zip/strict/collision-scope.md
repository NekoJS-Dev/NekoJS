| Java declaration class | Member | Nodes |
|---|---|---|
| `net.minecraft.server.level.ServerLevel` | `noSave` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `net.minecraft.server.level.ServerPlayer` | `gameMode` | 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `net.minecraft.world.entity.animal.chicken.Chicken` | `isChickenJockey` | 26.1.2, 26.1.2-fabric |
| `net.minecraft.world.entity.animal.Chicken` | `isChickenJockey` | 1.21.1 |
| `net.minecraft.world.item.crafting.ShapedRecipe` | `showNotification` | 1.21.1 |
| `net.minecraft.world.item.crafting.SingleItemRecipe` | `result` | 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `net.minecraft.world.level.biome.BiomeGenerationSettings` | `features` | 26.1.2-fabric, 26.2.0-fabric |
| `net.minecraft.world.level.biome.BiomeSpecialEffects` | `dryFoliageColorOverride` | 26.1.2-fabric, 26.2.0-fabric |
| `net.minecraft.world.level.biome.BiomeSpecialEffects` | `foliageColorOverride` | 26.1.2-fabric, 26.2.0-fabric |
| `net.minecraft.world.level.biome.BiomeSpecialEffects` | `grassColorModifier` | 26.1.2-fabric, 26.2.0-fabric |
| `net.minecraft.world.level.biome.BiomeSpecialEffects` | `grassColorOverride` | 26.1.2-fabric, 26.2.0-fabric |
| `net.minecraft.world.level.biome.BiomeSpecialEffects` | `waterColor` | 26.1.2-fabric, 26.2.0-fabric |
| `net.minecraft.world.level.Explosion` | `radius` | 1.21.1 |
| `net.minecraft.world.level.Level` | `isClientSide` | 1.21.1 |
| `net.minecraft.world.level.saveddata.maps.MapItemSavedData` | `locked` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `net.minecraft.world.phys.Vec3` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `net.minecraft.world.phys.Vec3` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `net.minecraft.world.phys.Vec3` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix2d` | `m00` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix2d` | `m01` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix2d` | `m10` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix2d` | `m11` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix2f` | `m00` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix2f` | `m01` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix2f` | `m10` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix2f` | `m11` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m00` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m01` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m02` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m10` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m11` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m12` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m20` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m21` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3d` | `m22` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m00` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m01` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m02` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m10` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m11` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m12` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m20` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m21` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3f` | `m22` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2d` | `m00` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2d` | `m01` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2d` | `m10` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2d` | `m11` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2d` | `m20` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2d` | `m21` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2f` | `m00` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2f` | `m01` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2f` | `m10` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2f` | `m11` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2f` | `m20` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Matrix3x2f` | `m21` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Quaterniond` | `w` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Quaterniond` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Quaterniond` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Quaterniond` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Quaternionf` | `w` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Quaternionf` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Quaternionf` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Quaternionf` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector2L` | `x` | 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector2L` | `y` | 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector2d` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector2d` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector2f` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector2f` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector2i` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector2i` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3L` | `x` | 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3L` | `y` | 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3L` | `z` | 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3d` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3d` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3d` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3f` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3f` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3f` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3i` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3i` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector3i` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4d` | `w` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4d` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4d` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4d` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4f` | `w` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4f` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4f` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4f` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4i` | `w` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4i` | `x` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4i` | `y` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
| `org.joml.Vector4i` | `z` | 1.21.1, 26.1.2, 26.1.2-fabric, 26.2.0, 26.2.0-fabric |
