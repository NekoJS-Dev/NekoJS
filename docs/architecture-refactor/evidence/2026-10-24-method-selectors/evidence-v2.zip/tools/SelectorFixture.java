package nekojs.acceptance.selector;

import com.tkisor.nekojs.api.annotation.HideFromJS;
import com.tkisor.nekojs.api.annotation.Remap;
import net.neoforged.fml.common.Mod;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;

/** Provides isolated observable values for an installed-server interoperability experiment. */
@Mod("owned_selector_probe")
public final class SelectorFixture {
    public static final class Nested {}
    public final double x = 3;
    public final double m00 = 9;
    public double x() { return 4; }
    public String m00(int value) { return "int:" + value; }
    public String m00(double value) { return "double:" + value; }
    public int ints(int[] values) { return values.length; }
    public int strings(String[] values) { return values.length; }
    public String nested(Nested value) { return "nested"; }
    public int erased(List<String> values) { return values.size(); }
    public String varargs(String... values) { return String.join("/", values); }
    @HideFromJS public String hidden() { return "hidden"; }
    @Remap("renamed") public String original(int value) { return "renamed:" + value; }

    public static String loadedBinding() throws Exception {
        StringBuilder value = new StringBuilder();
        for (String name : List.of("com.tkisor.nekojs.core.NekoSharedHostAccess",
                "com.tkisor.nekojs.core.NekoJSMemberRemapper", "graal.graalvm.polyglot.Context")) {
            Class<?> type = Class.forName(name);
            var source = type.getProtectionDomain().getCodeSource().getLocation();
            try (var stream = type.getResourceAsStream("/" + name.replace('.', '/') + ".class")) {
                value.append(name).append('|').append(source).append('|')
                        .append(HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(stream.readAllBytes())))
                        .append('\n');
            }
        }
        return value.toString();
    }
}
