const Fixture = Java.type('nekojs.acceptance.selector.SelectorFixture');
const Nested = Java.type('nekojs.acceptance.selector.SelectorFixture$Nested');
const target = new Fixture();
const nested = new Nested();
const vector = new (Java.type('net.minecraft.world.phys.Vec3'))(7, 8, 9);
const matrix = new (Java.type('org.joml.Matrix2d'))();
const list = new (Java.type('java.util.ArrayList'))();
list.add('a');
list.add('b');
const rows = [];
function observe(label, call) {
    try { rows.push({ label, success: true, value: call() }); }
    catch (error) { rows.push({ label, success: false, message: String(error) }); }
}
observe('field', () => target.x);
observe('direct', () => target.x());
observe('selector', () => target['x()']());
observe('extracted', () => { const f = target['x()']; return f(); });
observe('int', () => target['m00(int)'](2));
observe('double', () => target['m00(double)'](2));
observe('intNarrowing', () => target['m00(int)'](2.5));
observe('primitiveArray', () => target['ints(int[])']([1, 2]));
observe('referenceArray', () => target['strings(java.lang.String[])'](['a', 'b']));
observe('binaryNested', () => target['nested(nekojs.acceptance.selector.SelectorFixture$Nested)'](nested));
observe('canonicalNested', () => target['nested(nekojs.acceptance.selector.SelectorFixture.Nested)'](nested));
observe('erased', () => target['erased(java.util.List)'](list));
observe('genericSpelling', () => target['erased(java.util.List<java.lang.String>)'](list));
observe('varargsArraySpelling', () => target['varargs(java.lang.String[])']('a', 'b'));
observe('varargsEllipsisSpelling', () => target['varargs(java.lang.String...)']('a', 'b'));
observe('hiddenDirect', () => target.hidden());
observe('hiddenSelector', () => target['hidden()']());
observe('renamedDirect', () => target.renamed(2));
observe('renamedSelector', () => target['renamed(int)'](2));
observe('originalDirect', () => target.original(2));
observe('originalSelector', () => target['original(int)'](2));
observe('vectorField', () => vector.x);
observe('vectorSelector', () => vector['x()']());
observe('matrixFieldBefore', () => matrix.m00);
observe('matrixGetter', () => matrix['m00()']());
observe('matrixSetter', () => matrix['m00(double)'](3) === matrix);
observe('matrixFieldAfter', () => matrix.m00);
observe('matrixExtracted', () => { const f = matrix['m00()']; return f(); });
console.info('OWNED-SELECTOR-BINDING ' + JSON.stringify(String(Fixture.loadedBinding())));
console.info('OWNED-SELECTOR-OBSERVATIONS ' + JSON.stringify(rows));
