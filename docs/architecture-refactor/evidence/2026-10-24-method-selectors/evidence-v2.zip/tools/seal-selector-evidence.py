"""Seal bounded interop observations without properties, launch arguments, worlds, or credentials."""
import hashlib
import io
import json
from pathlib import Path
import zipfile

ROOT = Path.cwd().resolve()
TOOLS = ROOT / 'build/priority-closeout'
OUT = ROOT / 'docs/architecture-refactor/evidence/2026-10-24-method-selectors'
OUT.mkdir(exist_ok=True)
assert not (OUT / 'evidence-v2.zip').exists()
files = {}
def add(name, path):
    files[name] = path.read_bytes()
for filename in ['MethodSelectorProbe.java', 'run-method-selector-probe.py', 'SelectorFixture.java',
                 'installed-selector-probe.js', 'run-installed-selector-probe.py',
                 'prepare-selector-evidence.py', 'seal-selector-evidence.py']:
    add('tools/' + filename, TOOLS / filename)
for prefix, directory, names in [
    ('standalone', 'method-selector-261-v1', ['binding.json', 'result.json', 'compile.log', 'compile-stderr.log', 'run.log', 'run-stderr.log']),
    ('installed', 'installed-selector-261-v2', ['result.json', 'owned-process.json', 'stdout.log', 'stderr.log', 'compile.log', 'mods/owned-selector-probe.jar']),
    ('strict', 'method-selector-evidence-v2', ['collision-inventory.json', 'collision-scope.md', 'before.ts', 'after.ts', 'before-tsconfig.json', 'after-tsconfig.json', 'before-tsc.log', 'after-tsc.log', 'strict-result.json']),
    ('initial-preparation-failure', 'method-selector-evidence-v1', ['before-tsc.log', 'after-tsc.log']),
]:
    for name in names:
        add(prefix + '/' + name, TOOLS / directory / name)
add('initial-stop-record/evidence.zip', OUT / 'evidence.zip')
add('initial-stop-record/verification.json', OUT / 'verification.json')
source = ROOT / 'build/closeout-owner-stamp-installed/26.1.2'
candidate = next((source / 'mods').glob('nekojs-*.jar'))
graal = next((source / 'mods').glob('graal-*.jar'))
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == '7b0dd1544837cf86ba35ccc4817da40cde54ff7c07544fc3b25fd5437027e8ae'
binding = {'sourceRevision': '6e43b82789a7dbf7b9659dc1c21fefecac662649',
    'candidateSha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
    'installedGraalSha256': hashlib.sha256(graal.read_bytes()).hexdigest(),
    'candidateArchive': '../2026-10-24-owner-stamp-performance/evidence.zip',
    'installedSources': {name: hashlib.sha256((TOOLS / name).read_bytes()).hexdigest()
        for name in ['SelectorFixture.java', 'installed-selector-probe.js', 'run-installed-selector-probe.py']},
    'claim': 'Bounded compatibility observations only; no production declaration migration or full strict-gate pass',
    'maintainerAcceptance': False}
with zipfile.ZipFile(candidate) as jar:
    binding['candidateClassCount'] = len([n for n in jar.namelist() if n.startswith('com/tkisor/nekojs/') and n.endswith('.class')])
    binding['loadedProductionClasses'] = {name: hashlib.sha256(jar.read(name)).hexdigest() for name in [
        'com/tkisor/nekojs/core/NekoSharedHostAccess.class', 'com/tkisor/nekojs/core/NekoJSMemberRemapper.class']}
files['binding.json'] = (json.dumps(binding, indent=2) + '\n').encode()
secrets = set()
for path in (ROOT / 'build/closeout-owner-stamp-installed').glob('*/server.properties'):
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.startswith(('rcon.password=', 'management-server-secret=')):
            value = line.split('=', 1)[1]
            if value:
                secrets.add(value)
patterns = {value.encode(encoding) for value in secrets for encoding in ['utf-8', 'utf-16-le', 'utf-16-be']}
payload_count = 0
def scan(data):
    global payload_count
    payload_count += 1
    assert not any(pattern in data for pattern in patterns), 'Private credential retained; stop before sealing'
    if data.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(data)) as jar:
            for name in jar.namelist():
                if not name.endswith('/'):
                    scan(jar.read(name))
for data in files.values():
    scan(data)
files['privacy-audit.json'] = (json.dumps(dict(payloadsChecked=payload_count, secretCount=len(secrets),
    patternCount=len(patterns), retainedMatches=0, redactedFiles=0,
    limitation='Private-pattern scan performed locally; public digest verification cannot repeat it without private inputs'), indent=2) + '\n').encode()
files['entries.json'] = (json.dumps({name: hashlib.sha256(data).hexdigest() for name, data in files.items()}, indent=2) + '\n').encode()
archive = OUT / 'evidence-v2.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as jar:
    for name, data in sorted(files.items()):
        jar.writestr(name, data)
(OUT / 'seal-result-v3.json').write_text(json.dumps(dict(archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    entries=len(files), bytes=archive.stat().st_size, privacyPayloads=payload_count, retainedMatches=0,
    redactedFiles=0), indent=2) + '\n', encoding='utf-8')
print((OUT / 'seal-result-v3.json').read_text(encoding='utf-8'))
