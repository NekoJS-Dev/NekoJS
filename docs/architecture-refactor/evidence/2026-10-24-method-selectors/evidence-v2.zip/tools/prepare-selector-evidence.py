"""Capture current collision declarations and compile a minimal explicit-selector consumer."""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd().resolve()
OUT = ROOT / 'build/priority-closeout/method-selector-evidence-v2'
OUT.mkdir(exist_ok=False)
BASE = ROOT / 'build/closeout-owner-stamp-installed'
entities = {}
diagnostic_count = 0
bound = {}
for log in sorted((BASE / 'ide').glob('*-server-tsc.txt')):
    node = log.name.removesuffix('-server-tsc.txt')
    bound[str(log.relative_to(ROOT))] = hashlib.sha256(log.read_bytes()).hexdigest()
    for raw in log.read_text(encoding='utf-8-sig').splitlines():
        match = re.match(r"(.+)\((\d+),(\d+)\): error TS2300: Duplicate identifier '([^']+)'\.", raw)
        if not match:
            continue
        filename, line, column, member = match.groups()
        source = ROOT / filename
        content = source.read_bytes()
        lines = content.decode('utf-8').splitlines()
        line = int(line)
        owners = [found.group(1) for candidate in lines[:line]
                  if (found := re.match(r'\s*export (?:abstract )?(?:class|interface|enum) ([\w$]+)', candidate))]
        assert owners and not lines[line - 1].lstrip().startswith('import ')
        owner = owners[-1]
        relative = source.relative_to(BASE / node).as_posix()
        key = (node, relative, owner, member)
        row = entities.setdefault(key, dict(node=node, file=relative, owner=owner, member=member, declarations=[]))
        row['declarations'].append(dict(line=line, column=int(column), text=lines[line - 1].strip()))
        bound[str(source.relative_to(ROOT))] = hashlib.sha256(content).hexdigest()
        diagnostic_count += 1
rows = sorted(entities.values(), key=lambda row: (row['node'], row['file'], row['owner'], row['member']))
members = collections.defaultdict(set)
for row in rows:
    members[(row['file'], row['owner'], row['member'])].add(row['node'])
    escaped = re.escape(row['member'])
    assert any(re.match(r'(?:readonly )?' + escaped + r'\s*[?:]', d['text']) for d in row['declarations'])
    assert any(re.match(escaped + r'\s*[<(]', d['text']) for d in row['declarations'])
assert diagnostic_count == 1002 and len(rows) == 436 and len(members) == 96
inventory = dict(sourceRevision='6e43b82789a7dbf7b9659dc1c21fefecac662649', diagnosticLocations=diagnostic_count,
                 nodeEntities=dict(collections.Counter(row['node'] for row in rows)), uniqueFieldMethodMembers=len(members),
                 entities=rows, sourceHashes=bound)
(OUT / 'collision-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n', encoding='utf-8')
table = '| Java declaration class | Member | Nodes |\n|---|---|---|\n'
for (file, owner, member), nodes in sorted(members.items()):
    package = file.split('/@package/', 1)[1].removesuffix('/index.d.ts').replace('/', '.')
    table += f'| `{package}.{owner.removeprefix("$")}` | `{member}` | {", ".join(sorted(nodes))} |\n'
(OUT / 'collision-scope.md').write_text(table, encoding='utf-8')
before = '''interface Before {
    x: number;
    x(): number;
}
'''
after = '''interface Fixture {
    readonly x: number;
    "x()"(): number;
    readonly m00: number;
    "m00(int)"(value: number): string;
    "m00(double)"(value: number): string;
    renamed(value: number): string;
    "original(int)"(value: number): string;
}
interface Matrix {
    m00: number;
    "m00()"(): number;
    "m00(double)"(value: number): Matrix;
}
declare const target: Fixture;
declare const matrix: Matrix;
const field: number = target.x;
const result: number = target["x()"]();
const extracted = target["x()"];
const called: number = extracted();
const integerResult: string = target["m00(int)"](2);
const doubleResult: string = target["m00(double)"](2.5);
const renamedResult: string = target.renamed(2);
const rawSelectorResult: string = target["original(int)"](2);
const current: number = matrix["m00()"]();
const updated: Matrix = matrix["m00(double)"](3);
// @ts-expect-error A field value is not callable after extraction.
const broken = field();
// @ts-expect-error This proposed spelling migration requires the explicit selector.
target.x();
// @ts-expect-error The selected Java setter accepts a number.
matrix["m00(double)"]("bad");
// @ts-expect-error Installed GraalMC selectors use the Java name, not @Remap.
target["renamed(int)"](2);
// @ts-expect-error Hidden methods have no selector declaration.
target["hidden()"]();
'''
codes = {}
for name, text in [('before', before), ('after', after)]:
    (OUT / f'{name}.ts').write_text(text, encoding='utf-8')
    (OUT / f'{name}-tsconfig.json').write_text(json.dumps(dict(compilerOptions=dict(strict=True, noEmit=True,
        skipLibCheck=False, types=[], target='ES2022'), files=[f'{name}.ts']), indent=2) + '\n', encoding='utf-8')
    with (OUT / f'{name}-tsc.log').open('wb') as log:
        run = subprocess.run(['node', 'node_modules/typescript/bin/tsc', '--pretty', 'false', '-p', str(OUT / f'{name}-tsconfig.json')],
                             stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    codes[name] = run.returncode
assert codes == {'before': 2, 'after': 0}, codes
assert (OUT / 'before-tsc.log').read_text(encoding='utf-8').count('error TS2300') == 2
(OUT / 'strict-result.json').write_text(json.dumps(dict(exitCodes=codes, scope='Hand-authored prototype consumer, not production backend or full default output',
    compilerSha256=hashlib.sha256((ROOT / 'node_modules/typescript/lib/typescript.js').read_bytes()).hexdigest()), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(diagnosticLocations=diagnostic_count, nodeMembers=len(rows), uniqueMembers=len(members), strictPrototype=codes)))
