"""Run one fresh installed NeoForge server without modifying the candidate artifact."""
import hashlib
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import shutil
import socket
import subprocess
import time
import zipfile

ROOT = Path.cwd().resolve()
TOOLS = ROOT / 'build/priority-closeout'
OUT = TOOLS / 'installed-selector-261-v2'
assert not OUT.exists()
OUT.mkdir()
source = ROOT / 'build/closeout-owner-stamp-installed/26.1.2'
artifact = next((source / 'mods').glob('nekojs-*.jar'))
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == '7b0dd1544837cf86ba35ccc4817da40cde54ff7c07544fc3b25fd5437027e8ae'
ports = (33491, 33492)
for port in ports:
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', port))
shutil.copyfile(source / 'eula.txt', OUT / 'eula.txt')
properties = (source / 'server.properties').read_text(encoding='utf-8')
properties = '\n'.join('server-port=33491' if line.startswith('server-port=') else
    'rcon.port=33492' if line.startswith('rcon.port=') else
    'level-name=owned-selector-proof' if line.startswith('level-name=') else
    'server-ip=127.0.0.1' if line.startswith('server-ip=') else line for line in properties.splitlines()) + '\n'
(OUT / 'server.properties').write_text(properties, encoding='utf-8')
password = dict(line.split('=', 1) for line in properties.splitlines() if '=' in line)['rcon.password']
shutil.copytree(source / 'nekojs/config', OUT / 'nekojs/config')
(OUT / 'nekojs/server_scripts').mkdir()
shutil.copyfile(TOOLS / 'installed-selector-probe.js', OUT / 'nekojs/server_scripts/selector.js')
shutil.copytree(source / 'mods', OUT / 'mods')
(OUT / 'libraries').symlink_to((source / 'libraries').resolve(), target_is_directory=True)
classes = OUT / 'helper-classes'
classes.mkdir()
cp = ';'.join([str(p) for p in (source / 'libraries').rglob('*.jar')] + [str(artifact)])
flags = subprocess.CREATE_NO_WINDOW
with (OUT / 'compile.log').open('wb') as log:
    code = subprocess.run([shutil.which('javac'), '-proc:none', '-cp', cp, '-d', str(classes), str(TOOLS / 'SelectorFixture.java')], stdout=log, stderr=subprocess.STDOUT, creationflags=flags).returncode
assert code == 0, 'Owned helper compilation failed; inspect compile.log'
metadata = '''modLoader="javafml"
loaderVersion="[1,)"
license="MIT"
[[mods]]
modId="owned_selector_probe"
version="1.0"
displayName="Owned Method Selector Probe"
'''
with zipfile.ZipFile(OUT / 'mods/owned-selector-probe.jar', 'w', zipfile.ZIP_DEFLATED) as jar:
    jar.writestr('META-INF/neoforge.mods.toml', metadata)
    for file in classes.rglob('*.class'):
        jar.write(file, file.relative_to(classes).as_posix())
spec = importlib.util.spec_from_file_location('owned_rcon_selector', ROOT / 'bench/perf/rcon.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
def command(text):
    with socket.create_connection(('127.0.0.1', ports[1]), timeout=15) as connection:
        connection.settimeout(30)
        rcon.send_packet(connection, 1, 3, password)
        assert rcon.recv_packet(connection)[0] != -1
        rcon.send_packet(connection, 2, 2, text)
        return rcon.recv_packet(connection)[2]
java = 'C:/Program Files/Java/jdk-25.0.2/bin/java.exe'
args = [java, '-Xms512M', '-Xmx2G', '@libraries/net/neoforged/neoforge/26.1.2.71/win_args.txt', 'nogui']
with (OUT / 'stdout.log').open('xb') as stdout, (OUT / 'stderr.log').open('xb') as stderr:
    process = subprocess.Popen(args, cwd=OUT, stdout=stdout, stderr=stderr, creationflags=flags)
(OUT / 'owned-process.json').write_text(json.dumps({'pid': process.pid, 'scope': 'Fresh installed 26.1.2 NeoForge .71 dedicated server; no client or other node claim'}, indent=2) + '\n', encoding='utf-8')
result = {'verdict': 'NOTGREEN', 'pid': process.pid, 'artifactSha256': hashlib.sha256(artifact.read_bytes()).hexdigest()}
try:
    deadline = time.monotonic() + 300
    while True:
        log = (OUT / 'stdout.log').read_text(encoding='utf-8', errors='replace')
        assert process.poll() is None, 'Owned server exited before readiness'
        if 'Done (' in log or 'Done(' in log:
            break
        assert time.monotonic() < deadline, 'Owned readiness timed out'
        time.sleep(1)
    lines = log.splitlines()
    def marker(name):
        matches = [line.split(name, 1)[1].strip() for line in lines if name in line]
        assert len(matches) == 1, f'Expected one {name} observation'
        return json.loads(matches[0])
    rows = marker('OWNED-SELECTOR-OBSERVATIONS ')
    result.update(observations=rows, loadedBinding=marker('OWNED-SELECTOR-BINDING '), verdict='RECORDED')
finally:
    stop = dict(attempted=False, responseReceived=False)
    result['stop'] = stop
    try:
        if process.poll() is None:
            stop['attempted'] = True
            stop['requestedUtc'] = datetime.now(timezone.utc).isoformat()
            stop['response'] = command('stop')
            stop['responseReceived'] = True
            stop['returnedUtc'] = datetime.now(timezone.utc).isoformat()
    finally:
        try:
            result['exitCode'] = process.wait(timeout=90)
            stopped_log = (OUT / 'stdout.log').read_text(encoding='utf-8', errors='replace')
            stop['shutdownMarkersObserved'] = 'Stopping server' in stopped_log and 'Closing FML Loader' in stopped_log
            result['normalRconStop'] = stop['attempted'] and stop['responseReceived'] and stop['shutdownMarkersObserved'] and result['exitCode'] == 0
        finally:
            (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
assert result['exitCode'] == 0
print(json.dumps(result, indent=2), flush=True)
