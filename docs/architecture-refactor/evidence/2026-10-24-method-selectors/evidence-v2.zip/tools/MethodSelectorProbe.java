import com.tkisor.nekojs.core.NekoSharedHostAccess;
import com.tkisor.nekojs.core.NekoJSMemberRemapper;
import com.tkisor.nekojs.api.annotation.HideFromJS;
import com.tkisor.nekojs.api.annotation.Remap;
import graal.mod.api.MemberRemapper;
import graal.graalvm.polyglot.Context;
import graal.graalvm.polyglot.PolyglotException;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix2d;
import com.google.gson.GsonBuilder;
import java.nio.file.*;
import java.util.*;

/** Observes public host interop with untransformed classes; no launcher or installed-game claim. */
public final class MethodSelectorProbe {
    public static final class Nested {}
    public static final class Fixture {
        public final double x = 3;
        public final double m00 = 9;
        public double x() { return 4; }
        public String m00(int value) { return "int:" + value; }
        public String m00(double value) { return "double:" + value; }
        public int ints(int[] values) { return values.length; }
        public int strings(String[] values) { return values.length; }
        public String nested(Nested value) { return "nested"; }
        public int erased(List<String> values) { return values.size(); }
        public String varargs(String... values) { return String.join("/", values); }
        @HideFromJS public String hidden() { return "hidden"; }
        @Remap("renamed") public String original(int value) { return "renamed:" + value; }
    }

    public static void main(String[] args) throws Exception {
        MemberRemapper.CHAIN.addRemapper(new NekoJSMemberRemapper());
        var result = new LinkedHashMap<String, Object>();
        result.put("scope", "Untransformed Fabric 26.1.2 classes, production HostAccess and member remapper; no launcher or applied Mixins");
        result.put("sources", Map.of("vec3", source(Vec3.class), "matrix", source(Matrix2d.class),
                "hostAccess", source(NekoSharedHostAccess.class), "context", source(Context.class)));
        var lookups = new ArrayList<String>();
        var rows = new ArrayList<Map<String, Object>>();
        try (Context context = Context.newBuilder("js").allowExperimentalOptions(true)
                .allowHostAccess(new NekoSharedHostAccess(List.of()).get())
                .allowHostClassLookup(name -> { lookups.add(name); return false; })
                .allowCreateProcess(false)
                .option("js.nashorn-compat", "true").option("js.foreign-object-prototype", "true")
                .option("js.ecmascript-version", "latest").option("js.strict", "true")
                .option("js.v8-compat", "true").build()) {
            result.put("engineVersion", context.getEngine().getVersion());
            var bindings = context.getBindings("js");
            bindings.putMember("target", new Fixture());
            bindings.putMember("nested", new Nested());
            bindings.putMember("list", List.of("a", "b"));
            bindings.putMember("ints", new int[]{1, 2, 3});
            bindings.putMember("strings", new String[]{"a", "b"});
            bindings.putMember("vector", new Vec3(7, 8, 9));
            bindings.putMember("matrix", new Matrix2d());
            for (String expression : List.of(
                    "typeof target.x", "target.x", "target.x()", "target['x()']()",
                    "(() => { const f = target['x()']; return f(); })()",
                    "target.m00", "target['m00(int)'](2)", "target['m00(double)'](2)",
                    "target['m00(int)'](2.5)", "target['m00(double)'](2.5)",
                    "target['ints(int[])'](ints)", "target['ints(int[])']([1,2])",
                    "target['strings(java.lang.String[])'](strings)",
                    "target['strings(java.lang.String[])'](['a'])",
                    "target['nested(MethodSelectorProbe$Nested)'](nested)",
                    "target['nested(MethodSelectorProbe.Nested)'](nested)",
                    "target['erased(java.util.List)'](list)",
                    "target['erased(java.util.List<java.lang.String>)'](list)",
                    "target['varargs(java.lang.String[])'](strings)",
                    "target['varargs(java.lang.String[])']('a','b')",
                    "target['varargs(java.lang.String...)']('a','b')",
                    "target.hidden()", "target['hidden()']()",
                    "target.renamed(2)", "target['renamed(int)'](2)",
                    "target.original(2)", "target['original(int)'](2)",
                    "vector.x", "vector.x()", "vector['x()']()",
                    "matrix.m00", "matrix['m00()']()", "matrix['m00(double)'](3) === matrix",
                    "matrix.m00", "(() => { const f = matrix['m00()']; return f(); })()",
                    "Java.type('java.lang.String')")) {
                var row = new LinkedHashMap<String, Object>();
                row.put("expression", expression);
                try {
                    var value = context.eval("js", expression);
                    row.put("success", true);
                    row.put("value", value.isNumber() ? value.asDouble() : value.toString());
                } catch (PolyglotException e) {
                    row.put("success", false);
                    row.put("guestException", e.isGuestException());
                    row.put("message", e.getMessage());
                }
                rows.add(row);
            }
        }
        result.put("deniedClassLookups", lookups);
        result.put("observations", rows);
        Files.writeString(Path.of(args[0]), new GsonBuilder().setPrettyPrinting().create().toJson(result));
        System.out.println("METHOD_SELECTOR_OBSERVATIONS_RECORDED");
    }

    private static String source(Class<?> type) {
        return type.getProtectionDomain().getCodeSource().getLocation().toString();
    }
}
