"""Run a standalone compatibility observation without changing production files."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'build/priority-closeout/method-selector-261-v1'
OUT.mkdir(exist_ok=False)
SOURCE = ROOT / 'build/priority-closeout/MethodSelectorProbe.java'
old = json.loads((ROOT / 'build/priority-closeout/bean-read-invocation-261/binding.json').read_text(encoding='utf-8'))
graal = next(Path(p) for p in old['files'] if 'graal-1504336-8762963.jar' in p)
base = (ROOT / 'build/priority-closeout/root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip().split(';')
fabric = (ROOT / 'build/priority-closeout/fabric-client-5fec3f89-261-v1/compile-classpath.txt').read_text(encoding='utf-8').strip().split(';')
paths = [str(OUT), str(graal)]
for raw in base + fabric:
    path = Path(raw)
    if 'graal-1504336' in raw or raw in paths:
        continue
    if path.exists():
        paths.append(raw)
cp = ';'.join(paths)
flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
commands = [
    ('compile', [shutil.which('javac'), '-cp', cp, '-d', str(OUT), str(SOURCE)]),
    ('run', [shutil.which('java'), '--enable-native-access=ALL-UNNAMED', '-Dpolyglot.engine.WarnInterpreterOnly=false', '-cp', cp, 'MethodSelectorProbe', str(OUT / 'result.json')]),
]
codes = {}
for name, command in commands:
    with (OUT / f'{name}.log').open('w', encoding='utf-8') as stdout, (OUT / f'{name}-stderr.log').open('w', encoding='utf-8') as stderr:
        run = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, creationflags=flags)
    codes[name] = run.returncode
    print(f'{name}: exit {run.returncode}', flush=True)
    if run.returncode:
        break
bound = [SOURCE, graal, Path(shutil.which('java')), Path(shutil.which('javac')),
         ROOT / 'common/src/main/java/com/tkisor/nekojs/core/NekoSharedHostAccess.java',
         ROOT / 'common/src/main/java/com/tkisor/nekojs/core/NekoJSMemberRemapper.java',
         ROOT / 'common/build/classes/java/main/com/tkisor/nekojs/core/NekoSharedHostAccess.class',
         ROOT / 'common/build/classes/java/main/com/tkisor/nekojs/core/NekoJSMemberRemapper.class']
bound += [Path(p) for p in paths if Path(p).is_file() and ('minecraft-merged-' in p or 'joml-' in p)]
binding = {'exitCodes': codes, 'files': {str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in bound}}
(OUT / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n', encoding='utf-8')
if codes.get('run') != 0:
    raise SystemExit(1)
result = json.loads((OUT / 'result.json').read_text(encoding='utf-8'))
print(json.dumps(result, ensure_ascii=False, indent=2))
