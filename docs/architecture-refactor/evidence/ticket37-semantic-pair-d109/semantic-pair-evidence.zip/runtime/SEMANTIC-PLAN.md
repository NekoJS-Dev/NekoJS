# Concurrent semantic game acceptance

Exact current d109 official JAR, no bridge, no cross-process Sky activation.
Fresh owned server/world, synthetic clients A/B, ports25985/25986.
Read real joins and configuration catch-ups. Set a deterministic contrast
wall through owned RCON. Request native Minecraft Screenshot.grab(mc,false)
on each client tick owner after ten ticks, without a guest async consumer.
Capture clear/blur before and after resource reload. Force one invalid local
CLIENT candidate, retain prior generation, remove only that owned fixture,
reload and verify recovery. Then real two-client server dynamic reload,
actual ACK/activation reports, readback and normal owner-thread/RCON exits.
No first-pixel, all-node, pack-download or human conclusion inferred.
Keep all failures; no world, credentials, binary artifacts or raw hs_err in Git.
Inherited PLAN is a template, not this run's plan.
