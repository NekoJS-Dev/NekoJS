const visualFs = require('node:fs');
const Minecraft = Java.type('net.minecraft.client.Minecraft');
const Screenshot = Java.type('net.minecraft.client.Screenshot');
const ClientCompat = Java.type('com.tkisor.nekojs.platform.compat.McClientCompat');
const signal = 'D:/mcmodDemo/NekoJS-mult/build/ticket37-semantic-pair-d109/clientA/nekojs/data/visual-step.txt';
let previous = '';
let pendingCapture = null;
let captureTicks = 0;
let firstHud = false;
ClientEvents.postEffects(event => {
    event.register('minecraft:invert', { blurRadius: 16, blurRounds: 1 });
    event.register('ticket37_client93:inline_blur', { blurRadius: 16, blurRounds: 1 });
});
ClientEvents.hud(() => {
    if (firstHud) return;
    firstHud = true;
    console.info('SEMANTIC-FIRST-HUD ' + JSON.stringify({ generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('ticket37_client93:inline_blur') }));
});
ClientEvents.tickPost(() => {
    const minecraft = Minecraft.getInstance();
    if (minecraft.player === null || !visualFs.existsSync(signal)) return;
    const step = String(visualFs.readFileSync(signal, 'utf8')).trim();
    if (step !== previous) {
        previous = step;
        if (step === 'close') {
            console.info('LIFECYCLE-OWNED-STOP requested=true');
            minecraft.stop();
            return;
        }
        if (step === 'reload') {
            visualFs.writeFileSync(signal, 'idle\n');
            console.info('SEMANTIC-RESOURCE-RELOAD requested=true');
            minecraft.reloadResourcePacks();
            return;
        }
        if (step.startsWith('clear-') || step.startsWith('vanilla-')) {
            minecraft.options.pauseOnLostFocus = false;
            ClientCompat.get().showScreen(null);
            const accepted = step.startsWith('vanilla-') ? PostEffects.set('minecraft:invert') : PostEffects.clear();
            console.info('SEMANTIC-VISUAL-STEP ' + JSON.stringify({ step, accepted, generation: PostEffects.activeGeneration(), current: PostEffects.current(), active: PostEffects.isActive() }));
            pendingCapture = step;
            captureTicks = 0;
        }
    }
    if (pendingCapture !== null && ++captureTicks === 10) {
        console.info('SEMANTIC-NATIVE-CAPTURE ' + JSON.stringify({ step: pendingCapture, generation: PostEffects.activeGeneration(), current: PostEffects.current(), active: PostEffects.isActive() }));
        Screenshot.grab(minecraft, false);
        pendingCapture = null;
    }
});
