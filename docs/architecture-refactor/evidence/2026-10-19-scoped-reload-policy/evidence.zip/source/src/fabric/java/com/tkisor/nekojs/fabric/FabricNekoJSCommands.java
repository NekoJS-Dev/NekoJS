package com.tkisor.nekojs.fabric;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.mojang.brigadier.tree.CommandNode;
import com.tkisor.nekojs.NekoJS;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.api.catalog.NekoScriptCatalog;
import com.tkisor.nekojs.api.plugin.NekoRuntimeAccess;
import com.tkisor.nekojs.command.AddressArgument;
import com.tkisor.nekojs.core.ScriptLocator;
import com.tkisor.nekojs.core.fs.NekoJSPaths;
import com.tkisor.nekojs.core.lifecycle.NekoRuntimeRoot;
import com.tkisor.nekojs.core.lifecycle.RuntimeCommandResultFormatter;
import com.tkisor.nekojs.platform.Platform;
import com.tkisor.nekojs.platform.ReloadExecution;
import com.tkisor.nekojs.probe.ProbeBackend;
import com.tkisor.nekojs.probe.ProbeBackendRegistry;
import com.tkisor.nekojs.probe.ProbeBackendSelector;
import com.tkisor.nekojs.probe.ProbeCoordinator;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * fabric 侧的 {@code /nekojs} 指令树（挂载等价 NeoForge 的 {@code RegisterCommandsEvent}）。
 *
 * <p>共享树的 {@code NekoJSCommands} 还是整文件 neoforge 守卫（它的依赖面——错误面板网络包、
 * 工作区编辑器、Modification 重放、ClientReloadExecutor——大多未移植 fabric，见
 * {@code docs/fabric-port-status} 的缺口清单），在那些面落地前由本文件提供 fabric 当前能力
 * 子集。子命令与 NeoForge 版同名同语义；差异：
 * <ul>
 *   <li>{@code error} / {@code view_all_errors} 降级为文本输出（错误 UI 与网络面板未移植）</li>
 *   <li>{@code editor} 不注册（工作区编辑器 GUI 面未移植）</li>
 *   <li>SERVER reload 做配方热重载（RecipeManagerMixin 孪生）+ Modification 重放
 *       （ItemModificationEventJS/BlockModificationEventJS 已去守卫复用）；
 *       村民交易重放仍未移植（对应机制无 fabric 落点）</li>
 *   <li>CLIENT reload is queued on the client thread, with results returned to the server source</li>
 * </ul>
 * 依赖面齐后应与共享树版合并回单副本。
 */
public final class FabricNekoJSCommands {

    private FabricNekoJSCommands() {}

    public static void registerCallback(Supplier<NekoRuntimeRoot> rootProvider) {
        // Resolve the loader-owned root when a command executes, not during mod initialization.
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                register(dispatcher, rootProvider));
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher, Supplier<NekoRuntimeRoot> rootProvider) {
        dispatcher.register(
                Commands.literal("nekojs")
                        .requires(source -> Commands.LEVEL_GAMEMASTERS.check(source.permissions()))
                        .executes(context -> sendRootUsage(context.getSource(), dispatcher))

                        .then(reloadCommand(rootProvider))
                        .then(testCommand(rootProvider))
                        .then(errorCommand(rootProvider))
                        .then(viewAllErrorsCommand(rootProvider))
                        .then(packsCommand(rootProvider))
                        .then(registryCommand())
                        .then(handCommand())
                        .then(inventoryCommand())
                        .then(trustCommand())
                        .then(probeCommand())
        );
    }

    // ------------------------------------------------------------------
    //  reload / test
    // ------------------------------------------------------------------

    private static LiteralArgumentBuilder<CommandSourceStack> reloadCommand(Supplier<NekoRuntimeRoot> rootProvider) {
        LiteralArgumentBuilder<CommandSourceStack> reload = Commands.literal("reload")
                .executes(context -> reloadType(context.getSource(), ScriptType.SERVER, rootProvider.get()));
        for (ScriptType type : ScriptType.all()) {
            addReloadType(reload, type, rootProvider);
        }
        return reload;
    }

    private static void addReloadType(LiteralArgumentBuilder<CommandSourceStack> reload, ScriptType type, Supplier<NekoRuntimeRoot> rootProvider) {
        reload.then(Commands.literal(type.name)
                .executes(context -> reloadType(context.getSource(), type, rootProvider.get()))
                .then(Commands.argument("file", StringArgumentType.greedyString())
                        .suggests((context, builder) -> suggestReloadFiles(type, builder))
                        .executes(context -> reloadFile(context.getSource(), type, StringArgumentType.getString(context, "file"), rootProvider.get()))));
    }

    private static CompletableFuture<Suggestions> suggestReloadFiles(ScriptType type, SuggestionsBuilder builder) {
        String prefix = "nekojs reload " + type.name + " ";
        String input = builder.getInput();
        int commandStart = input.startsWith("/") ? 1 : 0;
        int fileStart = input.startsWith(prefix, commandStart) ? commandStart + prefix.length() : builder.getStart();
        String fileInput = input.substring(Math.min(fileStart, input.length())).replace('\\', '/');
        SuggestionsBuilder pathBuilder = builder.createOffset(fileStart);
        for (String suggestion : ScriptLocator.suggestScriptFiles(type, fileInput)) {
            pathBuilder.suggest(suggestion);
        }
        return pathBuilder.buildFuture();
    }

    @SuppressWarnings("try")
    private static int reloadType(CommandSourceStack source, ScriptType type, NekoRuntimeRoot root) {
        if (!canReloadHere(source, type)) {
            return 0;
        }
        if (root == null) {
            source.sendFailure(Component.literal("NekoJS runtime is not available."));
            return 0;
        }
        if (type == ScriptType.TEST) {
            return runTests(source, root);
        }
        if (type == ScriptType.CLIENT && Platform.isClient()) {
            return scheduleClientReload(source, type, root, null);
        }
        try (ReloadExecution ignored = ReloadExecution.begin(type == ScriptType.SERVER)) {
            NekoRuntimeRoot.ReloadResult result = root.reload(type);
            if (type == ScriptType.SERVER) {
                try {
                    applyRecipeScripts(source);
                } catch (Exception postReloadFailure) {
                    return reportPostReloadFailure(source, root, result,
                            "recipe processing", postReloadFailure);
                }
            }
            return reportReloadResult(source, root, result);
        } catch (com.tkisor.nekojs.core.lifecycle.NekoReloadException e) {
            NekoJS.LOGGER.error("Reloading {} scripts failed", type.name, e);
            source.sendFailure(Component.literal(RuntimeCommandResultFormatter.reloadFailure(
                    e.report(), root.isActiveFailed(type))));
            return 0;
        } catch (Exception e) {
            NekoJS.LOGGER.error("Reloading {} scripts failed fatally", type.name, e);
            source.sendFailure(Component.literal("Reloading NekoJS " + type.name + " scripts failed fatally."));
            return 0;
        }
    }

    private static int runTests(CommandSourceStack source, NekoRuntimeRoot root) {
        if (!canReloadHere(source, ScriptType.TEST)) {
            return 0;
        }
        if (root == null) {
            source.sendFailure(Component.literal("NekoJS runtime is not available."));
            return 0;
        }
        try {
            NekoRuntimeRoot.TestRunResult result = root.runTests();
            if (!result.isConfigured() || !result.isCompleted()) {
                source.sendFailure(Component.literal(RuntimeCommandResultFormatter.testResult(result)));
                return 0;
            }
            sendReloadResult(source, root, RuntimeCommandResultFormatter.testResult(result));
            return 1;
        } catch (com.tkisor.nekojs.core.lifecycle.NekoReloadException e) {
            NekoJS.LOGGER.error("Running test scripts failed", e);
            source.sendFailure(Component.literal(RuntimeCommandResultFormatter.reloadFailure(
                    e.report(), root.isActiveFailed(ScriptType.TEST))));
            return 0;
        } catch (Exception e) {
            NekoJS.LOGGER.error("Running test scripts failed fatally", e);
            source.sendFailure(Component.literal("Running NekoJS test scripts failed fatally."));
            return 0;
        }
    }

    private static int scheduleClientReload(CommandSourceStack source, ScriptType type,
                                            NekoRuntimeRoot root, String filePath) {
        source.sendSystemMessage(Component.literal(filePath == null
                ? "NekoJS CLIENT reload scheduled on the client thread."
                : "NekoJS CLIENT script " + filePath + " reload scheduled on the client thread."));
        FabricClientReloadExecutor.execute(() -> {
            try {
                NekoRuntimeRoot.ReloadResult result = filePath == null
                        ? root.reload(type)
                        : root.reloadFile(type, java.nio.file.Path.of(filePath));
                source.getServer().execute(() -> reportReloadResult(source, root, result));
            } catch (com.tkisor.nekojs.core.lifecycle.NekoReloadException e) {
                NekoJS.LOGGER.error("Reloading {} scripts failed", type.name, e);
                source.getServer().execute(() -> source.sendFailure(Component.literal(
                        RuntimeCommandResultFormatter.reloadFailure(e.report(), root.isActiveFailed(type)))));
            } catch (Exception e) {
                NekoJS.LOGGER.error("Reloading {} scripts failed fatally", type.name, e);
                source.getServer().execute(() -> source.sendFailure(Component.literal(
                        "Reloading NekoJS " + type.name + " scripts failed fatally.")));
            }
        });
        return 1;
    }

    private static int reportPostReloadFailure(CommandSourceStack source, NekoRuntimeRoot root,
                                               NekoRuntimeRoot.ReloadResult result,
                                               String stage, Exception failure) {
        reportReloadResult(source, root, result);
        source.sendFailure(Component.literal(
                RuntimeCommandResultFormatter.postReloadFailure(result, stage, failure)));
        return 0;
    }

    private static int reportReloadResult(CommandSourceStack source, NekoRuntimeRoot root,
                                          NekoRuntimeRoot.ReloadResult result) {
        String message = RuntimeCommandResultFormatter.reloadResult(
                result, root.isActiveFailed(result.type()));
        if (!result.success()) {
            source.sendFailure(Component.literal(message));
            return 0;
        }
        sendReloadResult(source, root, message);
        return 1;
    }

    /**
     * SERVER 脚本 reload 后重新应用配方脚本（与 NeoForge 版 {@code NekoJSCommands#applyRecipeScripts}
     * 同语义）：RecipeManagerMixin 孪生的 {@code nekojs$applyScripts()} 从永久缓存重建工作集并
     * 重跑配方脚本；其内部会向全体 gamemaster 广播 ✔/⚠。
     */
    private static void applyRecipeScripts(CommandSourceStack source) {
        net.minecraft.server.MinecraftServer server = source.getServer();
        if (server == null) return;
        if (server.getRecipeManager() instanceof com.tkisor.nekojs.api.recipe.IRecipeManagerExtension ext) {
            ext.nekojs$applyScripts();
        }
    }

    @SuppressWarnings("try")
    private static int reloadFile(CommandSourceStack source, ScriptType type, String filePath,
                                  NekoRuntimeRoot root) {
        if (!canReloadHere(source, type)) {
            return 0;
        }
        if (root == null) {
            source.sendFailure(Component.literal("NekoJS runtime is not available."));
            return 0;
        }
        if (type == ScriptType.CLIENT && Platform.isClient()) {
            return scheduleClientReload(source, type, root, filePath);
        }
        source.sendSystemMessage(Component.literal("Reloading NekoJS " + type.name + " script " + filePath + "..."));
        try (ReloadExecution ignored = ReloadExecution.begin(type == ScriptType.SERVER)) {
            return reportReloadResult(source, root, root.reloadFile(type, java.nio.file.Path.of(filePath)));
        } catch (Exception e) {
            NekoJS.LOGGER.error("Reloading {} script file {} failed fatally", type.name, filePath, e);
            source.sendFailure(Component.literal("Reloading NekoJS " + type.name + " script file failed fatally."));
            return 0;
        }
    }

    private static boolean canReloadHere(CommandSourceStack source, ScriptType type) {
        if (source.getServer() == null) {
            source.sendFailure(Component.literal("NekoJS lifecycle commands require a server command source."));
            return false;
        }
        if (type == ScriptType.STARTUP) {
            source.sendFailure(Component.literal(
                    "STARTUP scripts cannot be reloaded from a runtime command; restart the game/loader."));
            return false;
        }
        if (type == ScriptType.CLIENT && !Platform.isClient()) {
            source.sendFailure(Component.literal("Client script reload is only available in an integrated client runtime."));
            return false;
        }
        return true;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> testCommand(Supplier<NekoRuntimeRoot> rootProvider) {
        return Commands.literal("test")
                .executes(context -> runTests(context.getSource(), rootProvider.get()));
    }

    // ------------------------------------------------------------------
    //  error / view_all_errors（文本降级：错误 UI 与网络面板未移植）
    // ------------------------------------------------------------------

    private static LiteralArgumentBuilder<CommandSourceStack> errorCommand(Supplier<NekoRuntimeRoot> rootProvider) {
        return Commands.literal("error")
                .executes(context -> {
                    CommandSourceStack source = context.getSource();
                    NekoRuntimeRoot root = rootProvider.get();
                    if (root == null) {
                        source.sendFailure(Component.literal("NekoJS runtime is not available."));
                        return 0;
                    }
                    int count = root.errors().count();
                    if (count > 0) {
                        source.sendFailure(Component.literal(count + " script error(s); use /nekojs view_all_errors to list."));
                    } else {
                        source.sendSuccess(() -> Component.translatable("nekojs.command.error.healthy"), false);
                    }
                    return 1;
                });
    }

    private static LiteralArgumentBuilder<CommandSourceStack> viewAllErrorsCommand(Supplier<NekoRuntimeRoot> rootProvider) {
        return Commands.literal("view_all_errors")
                .executes(context -> {
                    CommandSourceStack source = context.getSource();
                    NekoRuntimeRoot root = rootProvider.get();
                    if (root == null) {
                        source.sendFailure(Component.literal("NekoJS runtime is not available."));
                        return 0;
                    }
                    var errors = root.errors().errors();
                    if (errors.isEmpty()) {
                        source.sendSuccess(() -> Component.translatable("nekojs.command.error.none"), false);
                        return 1;
                    }
                    for (var err : errors) {
                        source.sendSystemMessage(Component.literal("[" + err.getErrorId() + "] "
                                + err.getDisplayPath() + ":" + err.getLineNumber() + " - "
                                + err.getErrorMessage() + " (x" + err.getOccurrenceCount() + ")"));
                    }
                    return 1;
                });
    }

    private static void sendReloadResult(CommandSourceStack source, NekoRuntimeRoot root, String successMessage) {
        NekoRuntimeRoot.ErrorSnapshot errors = root.errors();
        int count = errors.count();
        if (count > 0) {
            MutableComponent message = Component.literal(successMessage + " (" + count + " error(s) remain)")
                    .withStyle(style -> style
                            .withHoverEvent(new HoverEvent.ShowText(Component.translatable("nekojs.error.tracker.hover_hint")))
                            .withClickEvent(new ClickEvent.RunCommand("/nekojs view_all_errors")));
            source.sendSuccess(() -> message, false);
        } else {
            source.sendSuccess(() -> Component.literal(successMessage + " - no errors."), false);
        }
    }

    // ------------------------------------------------------------------
    //  trust / packs
    // ------------------------------------------------------------------

    private static LiteralArgumentBuilder<CommandSourceStack> trustCommand() {
        return Commands.literal("trust")
                .then(Commands.argument("address", AddressArgument.address())
                        .executes(context -> trustServer(context.getSource(), AddressArgument.getAddress(context, "address"))));
    }

    /** Bare /nekojs: list the registered subtree instead of brigadier's "Unknown or incomplete command". */
    private static int sendRootUsage(CommandSourceStack source, CommandDispatcher<CommandSourceStack> dispatcher) {
        String subtree = dispatcher.getRoot().getChild("nekojs").getChildren().stream()
                .map(CommandNode::getName)
                .collect(Collectors.joining("|"));
        source.sendSuccess(() -> Component.translatable("nekojs.command.usage", Component.literal(subtree)), false);
        return 1;
    }

    private static int trustServer(CommandSourceStack source, String address) {
        if (!Platform.isClient()) {
            source.sendFailure(Component.literal("Run /nekojs trust on a client process (e.g. in a singleplayer world)."));
            return 0;
        }
        var store = com.tkisor.nekojs.core.pack.sync.PackSyncTrustStore.get();
        store.trustServer(address);
        source.sendSuccess(() -> Component.literal(
                "Trusted " + address + " (bucket " + com.tkisor.nekojs.core.pack.sync.PackSyncTrustStore.bucketFor(address)
                        + "). Reconnect to receive its script packs."), false);
        return 1;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> packsCommand(Supplier<NekoRuntimeRoot> rootProvider) {
        var packs = Commands.literal("packs")
                .executes(context -> {
                    listPacks(context.getSource());
                    return 1;
                })
                .then(Commands.literal("enable")
                        .then(Commands.argument("id", StringArgumentType.greedyString())
                                .executes(context -> togglePack(context.getSource(), StringArgumentType.getString(context, "id"), true))))
                .then(Commands.literal("disable")
                        .then(Commands.argument("id", StringArgumentType.greedyString())
                                .executes(context -> togglePack(context.getSource(), StringArgumentType.getString(context, "id"), false))));
        var status = Commands.literal("status");
        var plan = Commands.literal("plan");
        for (ScriptType type : ScriptType.all()) {
            status.then(Commands.literal(type.name)
                    .executes(context -> showPackExecution(context.getSource(), rootProvider.get(), type, false)));
            plan.then(Commands.literal(type.name)
                    .executes(context -> showPackExecution(context.getSource(), rootProvider.get(), type, true)));
        }
        var reload = Commands.literal("reload");
        var create = Commands.literal("create");
        for (ScriptType type : ScriptType.all()) {
            create.then(Commands.literal(type.name).then(Commands.argument("id", StringArgumentType.greedyString())
                    .executes(context -> reportPackTool(context.getSource(), rootProvider.get(), "create",
                            StringArgumentType.getString(context, "id"), type, null, null))));
            if (type == ScriptType.STARTUP) continue;
            reload.then(Commands.literal(type.name).then(Commands.argument("id", StringArgumentType.greedyString())
                    .executes(context -> reloadPackCommand(context.getSource(), rootProvider.get(), type, StringArgumentType.getString(context, "id")))));
        }
        packs.then(reload).then(create);
        for (String action : java.util.List.of("validate", "archive")) {
            packs.then(Commands.literal(action).then(Commands.argument("id", StringArgumentType.greedyString())
                    .executes(context -> reportPackTool(context.getSource(), rootProvider.get(), action,
                            StringArgumentType.getString(context, "id"), null, null, null))));
        }
        var jar = Commands.literal("jar");
        for (String loader : java.util.List.of("neoforge", "fabric")) {
            var target = Commands.literal(loader);
            for (String minecraft : loader.equals("neoforge") ? java.util.List.of("1.21.1", "26.1.2", "26.2") : java.util.List.of("26.1.2", "26.2")) {
                target.then(Commands.literal(minecraft).then(Commands.argument("id", StringArgumentType.greedyString())
                        .executes(context -> reportPackTool(context.getSource(), rootProvider.get(), "jar",
                                StringArgumentType.getString(context, "id"), null, loader, minecraft))));
            }
            jar.then(target);
        }
        packs.then(jar);
        return packs.then(status).then(plan);
    }

    private static int reportPackTool(CommandSourceStack source, NekoRuntimeRoot root, String action,
                                      String selector, ScriptType type, String loader, String minecraft) {
        if (root == null) { source.sendFailure(Component.translatable("nekojs.command.packs.tool_failed", action, selector, "runtime unavailable")); return 0; }
        var result = root.packTool(action, selector, type, loader, minecraft);
        if (!result.success()) {
            source.sendFailure(Component.translatable("nekojs.command.packs.tool_failed", action, selector, result.detail())); return 0;
        }
        source.sendSystemMessage(Component.translatable("nekojs.command.packs.tool_success", action, result.selector(),
                result.output() == null ? result.detail() : result.output().toString()));
        return 1;
    }

    private static int reloadPackCommand(CommandSourceStack source, NekoRuntimeRoot root, ScriptType type, String selector) {
        if (!canReloadHere(source, type) || root == null || !root.hasScriptType(type)) return 0;
        if (type == ScriptType.CLIENT) {
            FabricClientReloadExecutor.execute(() -> {
                var result = root.reloadPack(type, selector);
                source.getServer().execute(() -> reportPackReload(source, result));
            });
            return 1;
        }
        var result = root.reloadPack(type, selector);
        int outcome = reportPackReload(source, result);
        if (result.success() && type == ScriptType.SERVER) {
            try { applyRecipeScripts(source); }
            catch (Exception failure) { source.sendFailure(Component.translatable("nekojs.command.packs.post_reload_failed", failure.getMessage())); return 0; }
        }
        return outcome;
    }

    private static int reportPackReload(CommandSourceStack source, com.tkisor.nekojs.core.pack.PackActivationCoordinator.Result result) {
        if (!result.success()) { source.sendFailure(Component.translatable("nekojs.command.packs.reload_failed", result.failure())); return 0; }
        source.sendSystemMessage(Component.translatable("nekojs.command.packs.reload_success", result.type().name, result.affected().size()));
        result.affected().forEach((selector, reason) -> source.sendSystemMessage(Component.translatable("nekojs.command.packs.affected", selector, reason)));
        result.waiting().forEach((selector, reason) -> source.sendSystemMessage(Component.translatable("nekojs.command.packs.blocked", selector, reason)));
        result.cleanupFailures().forEach(failure -> source.sendFailure(Component.translatable("nekojs.command.packs.cleanup_failed", failure)));
        return 1;
    }

    private static int showPackExecution(CommandSourceStack source, NekoRuntimeRoot root, ScriptType type, boolean plan) {
        if (root == null || !root.hasScriptType(type)) {
            source.sendFailure(Component.translatable("nekojs.command.packs.type_unavailable", type.name));
            return 0;
        }
        if (!plan) {
            for (var activation : root.packActivations(type)) source.sendSystemMessage(Component.translatable(
                    "nekojs.command.packs.activation", activation.selector(), activation.activation(), activation.version(),
                    Component.translatable("nekojs.command.packs.activation_" + activation.status().toLowerCase(java.util.Locale.ROOT)), activation.reason() == null ? "" : activation.reason()));
        }
        java.util.List<com.tkisor.nekojs.core.pack.PackScriptView> entries;
        if (plan) {
            var view = root.packExecutionPlan(type);
            entries = view.entries();
            source.sendSystemMessage(Component.translatable("nekojs.command.packs.plan_header", type.name, entries.size()));
            view.blockedPacks().forEach((selector, reason) -> source.sendSystemMessage(
                    Component.translatable("nekojs.command.packs.blocked", selector, reason)));
            if (!view.orderWarning().isEmpty()) {
                source.sendSystemMessage(Component.translatable("nekojs.command.packs.order_warning", view.orderWarning()));
            }
        } else {
            var view = root.packRuntimeView(type);
            entries = view.entries();
            source.sendSystemMessage(Component.translatable("nekojs.command.packs.status_header", type.name,
                    view.generation(), entries.size(), Component.translatable(view.activeFailed()
                            ? "nekojs.command.packs.isolated" : "nekojs.command.packs.not_isolated")));
        }
        for (var entry : entries) {
            String outcomeKey = switch (entry.status()) {
                case READY -> "nekojs.command.packs.ready";
                case EXECUTED -> "nekojs.command.packs.executed";
                case SKIPPED -> "nekojs.command.packs.skipped";
                case FAILED -> "nekojs.command.packs.failed";
            };
            var reason = switch (entry.reason()) {
                case "disabled" -> Component.translatable("nekojs.command.packs.reason_disabled");
                case "mod_unavailable" -> Component.translatable("nekojs.command.packs.reason_mod");
                default -> Component.literal(entry.reason());
            };
            source.sendSystemMessage(Component.translatable("nekojs.command.packs.execution_entry", entry.scriptId(),
                    entry.selector(), entry.version(), Component.translatable(outcomeKey), reason, entry.source().toString()));
        }
        return 1;
    }

    private static void listPacks(CommandSourceStack source) {
        var registry = com.tkisor.nekojs.core.pack.ScriptPackRegistry.get();
        registry.refreshLocalPacks();
        var all = registry.allPacks();
        if (all.isEmpty()) {
            source.sendSystemMessage(Component.translatable("nekojs.command.packs.empty"));
            return;
        }
        source.sendSystemMessage(Component.translatable("nekojs.command.packs.header", all.size()));
        for (var pack : all) {
            var intent = Component.translatable(pack.scope() == com.tkisor.nekojs.core.pack.ScriptPackScope.SERVER_CACHE
                    ? "nekojs.command.packs.remote"
                    : pack.enabled() ? "nekojs.command.packs.enabled" : "nekojs.command.packs.disabled");
            source.sendSystemMessage(Component.translatable("nekojs.command.packs.entry",
                    pack.selector(), pack.version(), pack.name(), intent, pack.root().toString()));
        }
    }

    private static int togglePack(CommandSourceStack source, String id, boolean enabled) {
        var registry = com.tkisor.nekojs.core.pack.ScriptPackRegistry.get();
        var result = registry.setEnabled(id, enabled);
        if (!result.succeeded()) {
            String key = switch (result.status()) {
                case NOT_FOUND -> "nekojs.command.packs.not_found";
                case AMBIGUOUS -> "nekojs.command.packs.ambiguous";
                case READ_ONLY -> "nekojs.command.packs.read_only";
                case SAVE_FAILED -> "nekojs.command.packs.save_failed";
                case SAVED -> "nekojs.command.packs.saved";
            };
            source.sendFailure(Component.translatable(key, result.selector(), String.join(", ", result.matches())));
            return 0;
        }
        source.sendSystemMessage(Component.translatable("nekojs.command.packs.saved", result.selector(),
                Component.translatable(enabled ? "nekojs.command.packs.enabled" : "nekojs.command.packs.disabled")));
        return 1;
    }

    // ------------------------------------------------------------------
    //  registry / hand / inventory
    // ------------------------------------------------------------------

    /** /nekojs registry：动态注册健康快照。fabric 上动态注册面未移植，快照恒为空。 */
    private static LiteralArgumentBuilder<CommandSourceStack> registryCommand() {
        return Commands.literal("registry")
                .executes(context -> {
                    for (var s : com.tkisor.nekojs.dynamic.DynamicRegistryDebug.snapshot()) {
                        context.getSource().sendSystemMessage(Component.literal(s.summary()));
                    }
                    return 1;
                })
                .then(Commands.literal("stale")
                        .executes(context -> {
                            boolean any = false;
                            for (var s : com.tkisor.nekojs.dynamic.DynamicRegistryDebug.snapshot()) {
                                for (String id : s.prettyStaleIds()) {
                                    context.getSource().sendSystemMessage(Component.literal(id));
                                    any = true;
                                }
                            }
                            if (!any) {
                                context.getSource().sendSystemMessage(Component.literal("No stale dynamic registry entries."));
                            }
                            return 1;
                        }));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> handCommand() {
        return Commands.literal("hand")
                .executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    showHand(context.getSource(), player.getMainHandItem());
                    return 1;
                });
    }

    private static void showHand(CommandSourceStack source, ItemStack stack) {
        if (stack.isEmpty()) {
            source.sendSystemMessage(Component.literal("Empty hand"));
            return;
        }
        String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        MutableComponent line = Component.literal(id)
                .withStyle(style -> style
                        .withClickEvent(new ClickEvent.CopyToClipboard(id))
                        .withHoverEvent(new HoverEvent.ShowText(Component.literal("Click to copy"))))
                .append(Component.literal(" x" + stack.getCount()));
        source.sendSystemMessage(line);
        if (stack.isDamageableItem()) {
            source.sendSystemMessage(Component.literal("  damage: " + stack.getDamageValue() + "/" + stack.getMaxDamage()));
        }
        source.sendSystemMessage(Component.literal("  components: " + compactComponents(stack)));
    }

    private static String compactComponents(ItemStack stack) {
        String text = stack.getComponentsPatch().toString().replace('\n', ' ');
        return text.length() > 300 ? text.substring(0, 300) + "..." : text;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> inventoryCommand() {
        return Commands.literal("inventory")
                .executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    listInventory(context.getSource(), player.getInventory());
                    return 1;
                });
    }

    private static void listInventory(CommandSourceStack source, Inventory inventory) {
        int used = 0;
        for (int slot = 0; slot < Inventory.INVENTORY_SIZE; slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (stack.isEmpty()) {
                continue;
            }
            source.sendSystemMessage(Component.literal("slot " + slot + ": "
                    + BuiltInRegistries.ITEM.getKey(stack.getItem()).toString() + " x" + stack.getCount()));
            used++;
        }
        if (used == 0) {
            source.sendSystemMessage(Component.literal("Inventory is empty."));
        }
    }

    // ------------------------------------------------------------------
    //  probe
    // ------------------------------------------------------------------

    private static LiteralArgumentBuilder<CommandSourceStack> probeCommand() {
        LiteralArgumentBuilder<CommandSourceStack> probe = Commands.literal("probe")
                .executes(context -> runProbe(context.getSource(), ProbeBackendSelector.defaultTypescript()));
        probe.then(Commands.literal("all")
                .executes(context -> runProbe(context.getSource(), ProbeBackendSelector.all())));
        probe.then(Commands.literal("list")
                .executes(context -> listProbeBackends(context.getSource())));
        probe.then(Commands.literal("reload")
                .executes(context -> reloadProbeConfig(context.getSource())));
        probe.then(Commands.literal("reset_config")
                .executes(context -> {
                    CommandSourceStack source = context.getSource();
                    int backends = ProbeCoordinator.resetEditorConfigs();
                    source.sendSystemMessage(Component.literal(
                            "Editor configs reset (" + backends + " backend(s)); regenerating probe..."));
                    return runProbe(source, ProbeBackendSelector.defaultTypescript());
                }));
        probe.then(Commands.literal("enable")
                .executes(context -> enableProbe(context.getSource())));
        probe.then(Commands.literal("disable")
                .executes(context -> disableProbe(context.getSource())));
        probe.then(Commands.argument("language", StringArgumentType.word())
                .suggests((context, builder) -> suggestProbeLanguages(builder))
                .executes(context -> runProbe(context.getSource(),
                        ProbeBackendSelector.forLanguage(StringArgumentType.getString(context, "language"))))
                .then(Commands.argument("name", StringArgumentType.word())
                        .suggests((context, builder) -> suggestProbeBackendNames(
                                StringArgumentType.getString(context, "language"), builder))
                        .executes(context -> runProbe(context.getSource(),
                                ProbeBackendSelector.named(
                                        StringArgumentType.getString(context, "language"),
                                        StringArgumentType.getString(context, "name"))))));
        return probe;
    }

    private static int runProbe(CommandSourceStack source, List<ProbeBackend> backends) {
        if (backends.isEmpty()) {
            source.sendFailure(Component.literal("No probe backend selected."));
            return 0;
        }
        String names = backends.stream()
                .map(b -> b.languageId() + ":" + b.name())
                .collect(Collectors.joining(", "));
        source.sendSystemMessage(Component.literal("Generating probe (" + names + ")..."));
        boolean allOk = true;
        try {
            var snapshot = NekoScriptCatalog.snapshot(NekoRuntimeAccess.get());
            List<ProbeBackend.GenerateResult> results = ProbeCoordinator.run(snapshot, backends);

            int totalFiles = 0;
            long maxMs = 0;
            for (ProbeBackend.GenerateResult r : results) {
                if (r.success()) {
                    totalFiles += r.filesGenerated();
                    maxMs = Math.max(maxMs, r.durationMs());
                    for (String w : r.warnings()) {
                        source.sendSystemMessage(Component.literal("  warning: " + w));
                    }
                } else {
                    allOk = false;
                    source.sendFailure(Component.literal("  backend failed: " + r.message()));
                }
            }
            if (allOk) {
                final int tf = totalFiles;
                final long ms = maxMs;
                source.sendSuccess(() -> Component.literal(
                        "Probe generated: " + tf + " files in " + ms + "ms"), false);
                String dirs = results.stream()
                        .map(ProbeBackend.GenerateResult::outputDir)
                        .filter(java.util.Objects::nonNull)
                        .map(d -> {
                            try {
                                return NekoJSPaths.get().gameDir().relativize(d).toString();
                            } catch (IllegalArgumentException e) {
                                return d.toString();
                            }
                        })
                        .distinct()
                        .collect(Collectors.joining(", "));
                if (!dirs.isEmpty()) {
                    source.sendSystemMessage(Component.literal("  Output: " + dirs));
                }
            }
        } catch (Exception e) {
            NekoJS.LOGGER.error("Probe generation failed", e);
            source.sendFailure(Component.literal("Probe generation failed: " + e.getMessage()));
            return 0;
        }
        return allOk ? 1 : 0;
    }

    private static int listProbeBackends(CommandSourceStack source) {
        var entries = ProbeBackendRegistry.get().registrars();
        if (entries.isEmpty()) {
            source.sendSystemMessage(Component.literal("No probe backends registered."));
        } else {
            source.sendSystemMessage(Component.literal("Registered probe backends:"));
            for (String e : entries) {
                source.sendSystemMessage(Component.literal("  - " + e));
            }
        }
        return 1;
    }

    private static int reloadProbeConfig(CommandSourceStack source) {
        ProbeCoordinator.reloadConfig();
        source.sendSuccess(() -> Component.literal("Probe config (probe.toml) reloaded."), false);
        return 1;
    }

    private static int enableProbe(CommandSourceStack source) {
        ProbeCoordinator.setEnabled(true);
        source.sendSuccess(() -> Component.literal("Probe enabled."), false);
        return 1;
    }

    private static int disableProbe(CommandSourceStack source) {
        ProbeCoordinator.setEnabled(false);
        source.sendSuccess(() -> Component.literal("Probe disabled."), false);
        return 1;
    }

    private static CompletableFuture<Suggestions> suggestProbeLanguages(SuggestionsBuilder builder) {
        for (String lang : ProbeBackendSelector.languageSuggestions()) {
            builder.suggest(lang);
        }
        return builder.buildFuture();
    }

    private static CompletableFuture<Suggestions> suggestProbeBackendNames(String languageId, SuggestionsBuilder builder) {
        if (languageId != null && !languageId.isBlank()) {
            for (ProbeBackend b : ProbeBackendSelector.nameSuggestions(languageId)) {
                builder.suggest(b.name());
            }
        }
        return builder.buildFuture();
    }
}
