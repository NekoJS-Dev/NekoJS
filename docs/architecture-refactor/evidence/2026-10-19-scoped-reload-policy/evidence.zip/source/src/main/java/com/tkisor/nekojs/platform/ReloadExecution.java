package com.tkisor.nekojs.platform;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.win32.StdCallLibrary;
import com.tkisor.nekojs.NekoJS;
import com.tkisor.nekojs.api.annotation.HideFromJS;

import java.util.concurrent.atomic.AtomicBoolean;

/** Requests prompt execution for a synchronous server reload and restores its thread policy. */
@HideFromJS
public final class ReloadExecution implements AutoCloseable {
    private static final AtomicBoolean UNAVAILABLE_REPORTED = new AtomicBoolean();
    private static final ReloadExecution UNCHANGED = new ReloadExecution(null, null);
    private final Policy policy;
    private final State original;
    private final Thread owner = Thread.currentThread();
    private boolean closed;

    private ReloadExecution(Policy policy, State original) {
        this.policy = policy;
        this.original = original;
    }

    /** The caller keeps this scope on the reload owner thread, including post-commit work. */
    public static ReloadExecution begin(boolean serverReload) {
        if (!serverReload || !com.sun.jna.Platform.isWindows()) {
            return UNCHANGED;
        }
        try {
            return begin(WindowsPolicy.INSTANCE);
        } catch (RuntimeException | LinkageError failure) {
            reportUnavailable(failure);
            return UNCHANGED;
        }
    }

    static ReloadExecution begin(Policy policy) {
        State original;
        try {
            original = policy.read();
        } catch (RuntimeException | LinkageError failure) {
            reportUnavailable(failure);
            return UNCHANGED;
        }
        ReloadExecution scope = new ReloadExecution(policy, original);
        try {
            policy.write(new State(original.version(), original.control() | 1, original.state() & ~1));
            return scope;
        } catch (RuntimeException | LinkageError failure) {
            // A failed setter may have changed state; attempt restoration before falling back.
            scope.close();
            reportUnavailable(failure);
            return UNCHANGED;
        }
    }

    private static void reportUnavailable(Throwable failure) {
        if (UNAVAILABLE_REPORTED.compareAndSet(false, true)) {
            NekoJS.LOGGER.warn("[NEKO-1019] Reload thread execution hint unavailable; reload continues", failure);
        }
    }

    @Override
    public void close() {
        if (policy == null || closed) return;
        if (Thread.currentThread() != owner) {
            throw new IllegalStateException("[NEKO-1020] Reload thread policy must be restored by its owner");
        }
        closed = true;
        try {
            // Nested scopes restore their own snapshot, including an outer scope's hint.
            policy.write(original);
        } catch (RuntimeException | LinkageError failure) {
            NekoJS.LOGGER.error("[NEKO-1020] Reload thread policy restoration failed; original policy may remain unapplied", failure);
        }
    }

    record State(int version, int control, int state) {}

    interface Policy {
        State read();
        void write(State state);
    }

    private static final class WindowsPolicy implements Policy {
        private static final WindowsPolicy INSTANCE = new WindowsPolicy();
        private final Kernel api = Native.load("kernel32", Kernel.class);

        @Override
        public State read() {
            try (Memory buffer = new Memory(12)) {
                buffer.clear();
                buffer.setInt(0, 1);
                if (api.GetThreadInformation(api.GetCurrentThread(), 3, buffer, 12) == 0) {
                    throw new IllegalStateException("[NEKO-1019] GetThreadInformation failed; error=" + Native.getLastError());
                }
                return new State(buffer.getInt(0), buffer.getInt(4), buffer.getInt(8));
            }
        }

        @Override
        public void write(State state) {
            try (Memory buffer = new Memory(12)) {
                buffer.setInt(0, state.version());
                buffer.setInt(4, state.control());
                buffer.setInt(8, state.state());
                if (api.SetThreadInformation(api.GetCurrentThread(), 3, buffer, 12) == 0) {
                    throw new IllegalStateException("[NEKO-1019] SetThreadInformation failed; error=" + Native.getLastError());
                }
            }
        }
    }

    interface Kernel extends StdCallLibrary {
        Pointer GetCurrentThread();
        int GetThreadInformation(Pointer thread, int informationClass, Pointer state, int size);
        int SetThreadInformation(Pointer thread, int informationClass, Pointer state, int size);
    }
}
