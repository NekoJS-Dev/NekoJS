package com.tkisor.nekojs.platform;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

@SuppressWarnings("try")
class ReloadExecutionTest {
    private static final ReloadExecution.State ORIGINAL = new ReloadExecution.State(1, 4, 4);
    private static final ReloadExecution.State HIGH = new ReloadExecution.State(1, 5, 4);

    @Test
    void restoresAllOriginalFieldsAfterSuccess() {
        FakePolicy policy = new FakePolicy();
        try (var scope = ReloadExecution.begin(policy)) {
            assertEquals(HIGH, policy.current);
        }
        assertEquals(ORIGINAL, policy.current);
        assertEquals(List.of(HIGH, ORIGINAL), policy.writes);
    }

    @Test
    void preservesBodyFailureAndRestoresOriginalPolicy() {
        FakePolicy policy = new FakePolicy();
        RuntimeException expected = new IllegalStateException("body failure");
        RuntimeException actual = assertThrows(RuntimeException.class, () -> {
            try (var scope = ReloadExecution.begin(policy)) {
                throw expected;
            }
        });
        assertSame(expected, actual);
        assertEquals(ORIGINAL, policy.current);
    }

    @Test
    void nestedScopesRetainTheOuterHintUntilItsOwnExit() {
        FakePolicy policy = new FakePolicy();
        try (var outer = ReloadExecution.begin(policy)) {
            try (var inner = ReloadExecution.begin(policy)) {
                assertEquals(HIGH, policy.current);
            }
            assertEquals(HIGH, policy.current);
        }
        assertEquals(ORIGINAL, policy.current);
        assertEquals(List.of(HIGH, HIGH, HIGH, ORIGINAL), policy.writes);
    }

    @Test
    void queryFailureDoesNotPreventTheBodyOrAttemptAnUnknownRestore() {
        FakePolicy policy = new FakePolicy();
        policy.readFailure = true;
        boolean ran = false;
        try (var scope = ReloadExecution.begin(policy)) {
            ran = true;
        }
        assertTrue(ran);
        assertTrue(policy.writes.isEmpty());
    }

    @Test
    void setterFailureRestoresEvenWhenTheFailedCallChangedState() {
        FakePolicy policy = new FakePolicy();
        policy.failWrite = 1;
        try (var scope = ReloadExecution.begin(policy)) {
            assertEquals(ORIGINAL, policy.current);
        }
        assertEquals(List.of(HIGH, ORIGINAL), policy.writes);
    }

    @Test
    void restorationFailureDoesNotReplaceTheBodyFailure() {
        FakePolicy policy = new FakePolicy();
        policy.failWrite = 2;
        RuntimeException expected = new IllegalStateException("body failure");
        assertSame(expected, assertThrows(RuntimeException.class, () -> {
            try (var scope = ReloadExecution.begin(policy)) {
                throw expected;
            }
        }));
        assertEquals(2, policy.writes.size());
    }

    @Test
    void closingTwiceDoesNotOverwriteSubsequentPolicy() {
        FakePolicy policy = new FakePolicy();
        var scope = ReloadExecution.begin(policy);
        scope.close();
        policy.current = new ReloadExecution.State(1, 2, 2);
        scope.close();
        assertEquals(new ReloadExecution.State(1, 2, 2), policy.current);
        assertEquals(2, policy.writes.size());
    }

    @Test
    void rejectsForeignThreadCloseAndStillAllowsOwnerRestoration() throws InterruptedException {
        FakePolicy policy = new FakePolicy();
        var scope = ReloadExecution.begin(policy);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Thread other = new Thread(() -> {
            try { scope.close(); } catch (Throwable caught) { failure.set(caught); }
        });
        other.start();
        other.join();
        assertInstanceOf(IllegalStateException.class, failure.get());
        assertEquals(HIGH, policy.current);
        scope.close();
        assertEquals(ORIGINAL, policy.current);
    }

    @Test
    void actualWindowsThreadPolicyChangesOnlyInsideTheScope() {
        assumeTrue(com.sun.jna.Platform.isWindows(), "Windows API observation");
        ReloadExecution.Kernel kernel = Native.load("kernel32", ReloadExecution.Kernel.class);
        var before = readNative(kernel);
        try (var scope = ReloadExecution.begin(true)) {
            assertEquals(new ReloadExecution.State(before.version(), before.control() | 1, before.state() & ~1), readNative(kernel));
            try (var nested = ReloadExecution.begin(true)) {
                assertEquals(before.control() | 1, readNative(kernel).control());
            }
            assertEquals(before.control() | 1, readNative(kernel).control());
        }
        assertEquals(before, readNative(kernel));
    }

    private static ReloadExecution.State readNative(ReloadExecution.Kernel kernel) {
        try (Memory buffer = new Memory(12)) {
            buffer.clear();
            buffer.setInt(0, 1);
            assertNotEquals(0, kernel.GetThreadInformation(kernel.GetCurrentThread(), 3, buffer, 12));
            return new ReloadExecution.State(buffer.getInt(0), buffer.getInt(4), buffer.getInt(8));
        }
    }

    private static final class FakePolicy implements ReloadExecution.Policy {
        private ReloadExecution.State current = ORIGINAL;
        private final List<ReloadExecution.State> writes = new ArrayList<>();
        private boolean readFailure;
        private int failWrite;

        @Override public ReloadExecution.State read() {
            if (readFailure) throw new IllegalStateException("query failure");
            return current;
        }

        @Override public void write(ReloadExecution.State state) {
            writes.add(state);
            current = state;
            if (writes.size() == failWrite) throw new IllegalStateException("write failure");
        }
    }
}
