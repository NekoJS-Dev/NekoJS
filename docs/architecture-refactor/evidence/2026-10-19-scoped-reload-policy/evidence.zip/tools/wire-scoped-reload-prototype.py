"""Wire only the synchronous command scopes in the owned performance checkout."""
from pathlib import Path

root = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
for name in ['src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java',
             'versions/1.21.1/src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java',
             'src/fabric/java/com/tkisor/nekojs/fabric/FabricNekoJSCommands.java']:
    file = root / name
    source = file.read_text(encoding='utf-8')
    assert 'import com.tkisor.nekojs.platform.ReloadExecution;' not in source
    source = source.replace('import com.tkisor.nekojs.platform.Platform;',
                            'import com.tkisor.nekojs.platform.Platform;\nimport com.tkisor.nekojs.platform.ReloadExecution;', 1)
    for method in ['reloadType', 'reloadFile']:
        start = source.index('    private static int ' + method + '(')
        position = source.index('        try {', start)
        assert source.index('root.reload' + ('File' if method == 'reloadFile' else '') + '(type', start) > position
        source = source[:position] + source[position:].replace('        try {',
                    '        try (ReloadExecution ignored = ReloadExecution.begin(type == ScriptType.SERVER)) {', 1)
        source = source[:start] + '    @SuppressWarnings("try")\n' + source[start:]
    file.write_text(source, encoding='utf-8')
    print(name)
