"""Preserve the full matrix before a diagnostic wording refinement."""
import hashlib
import json
import shutil
from pathlib import Path
from xml.etree import ElementTree as ET

tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
out = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/scoped-policy-prototype/full-build')
assert not out.exists()
out.mkdir()
totals = {}
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    totals[node] = dict(tests=0, failures=0, errors=0, skipped=0)
    for file in (tree / 'versions' / node / 'build/test-results').rglob('TEST-*.xml'):
        root = ET.parse(file).getroot()
        for key in totals[node]:
            totals[node][key] += int(root.attrib.get(key, 0))
        target = out / 'results' / node / file.relative_to(tree / 'versions' / node / 'build/test-results')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(file, target)
    assert totals[node]['tests'] > 0 and totals[node]['failures'] == totals[node]['errors'] == 0
    native = ET.parse(tree / 'versions' / node / 'build/test-results/test/TEST-com.tkisor.nekojs.platform.ReloadExecutionTest.xml').getroot()
    assert int(native.attrib['tests']) == 9 and int(native.attrib['skipped']) == 0
sources = ['src/main/java/com/tkisor/nekojs/platform/ReloadExecution.java',
           'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java',
           'versions/1.21.1/src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java',
           'src/fabric/java/com/tkisor/nekojs/fabric/FabricNekoJSCommands.java']
bound = {}
for name in sources:
    target = out / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(tree / name, target)
    bound[name] = hashlib.sha256(target.read_bytes()).hexdigest()
(out / 'binding.json').write_text(json.dumps(dict(sourceHashes=bound, nodeTotals=totals), indent=2) + '\n')
print(json.dumps(totals))
