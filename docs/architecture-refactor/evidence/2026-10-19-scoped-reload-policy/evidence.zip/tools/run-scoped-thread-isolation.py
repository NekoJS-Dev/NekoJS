"""Run the post-cohort thread-isolation observation against the frozen artifact."""
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout')
prep = json.loads((root / 'scoped-thread-8ca66bf4-formal/preparation.json').read_text())
artifact = Path(prep['artifact'])
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == prep['artifactSha256']
out = root / 'scoped-policy-prototype/thread-isolation'
assert not out.exists()
out.mkdir()
classes = out / 'classes'
classes.mkdir()
source = root / 'ObserveScopedThreadIsolation.java'
dependencies = (root / 'client-world-acceptance/adapter-classpath.txt').read_text().strip()
classpath = str(artifact) + ';' + dependencies
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
steps = []
for name, command in [
    ('compile', [str(java / 'javac.exe'), '-encoding', 'UTF-8', '-cp', classpath, '-d', str(classes), str(source)]),
    ('run', [str(java / 'java.exe'), '-cp', str(classes) + ';' + classpath,
             'com.tkisor.nekojs.platform.ObserveScopedThreadIsolation', str(out / 'observation.json')]),
]:
    with (out / (name + '.log')).open('xb') as stdout, (out / (name + '-stderr.log')).open('xb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    steps.append(dict(name=name, exitCode=result.returncode))
    assert result.returncode == 0, name
binding = dict(artifactSha256=prep['artifactSha256'], sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),
               dependencyClasspathSha256=hashlib.sha256(dependencies.encode()).hexdigest(), steps=steps,
               executedAfterFormalCohort=True, processPolicyChanged=False,
               jnaLibraries={Path(p).name: hashlib.sha256(Path(p).read_bytes()).hexdigest()
                             for p in dependencies.split(';') if Path(p).name.startswith('jna-')})
(out / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
print((out / 'observation.json').read_text())
