package com.tkisor.nekojs.platform;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Observes existing and newly created threads without changing their policies. */
public final class ObserveScopedThreadIsolation {
    private static final ReloadExecution.Kernel KERNEL = Native.load("kernel32", ReloadExecution.Kernel.class);

    private static int[] read() {
        try (Memory buffer = new Memory(12)) {
            buffer.clear();
            buffer.setInt(0, 1);
            if (KERNEL.GetThreadInformation(KERNEL.GetCurrentThread(), 3, buffer, 12) == 0) {
                throw new IllegalStateException("[NEKO-1019] Thread isolation probe query failed");
            }
            return new int[]{buffer.getInt(0), buffer.getInt(4), buffer.getInt(8)};
        }
    }

    private static int[] freshThread() throws InterruptedException {
        AtomicReference<int[]> result = new AtomicReference<>();
        Thread worker = new Thread(() -> result.set(read()), "scoped-policy-new-thread-observer");
        worker.setDaemon(true);
        worker.start();
        worker.join(5000);
        if (worker.isAlive() || result.get() == null) throw new AssertionError("New thread observation incomplete");
        return result.get();
    }

    @SuppressWarnings("try")
    public static void main(String[] args) throws Exception {
        int[] ownerBefore = read();
        int[] newBefore = freshThread();
        CountDownLatch ready = new CountDownLatch(1);
        CountDownLatch observe = new CountDownLatch(1);
        CountDownLatch completed = new CountDownLatch(1);
        AtomicReference<int[]> existingBefore = new AtomicReference<>();
        AtomicReference<int[]> existingDuring = new AtomicReference<>();
        Thread existing = new Thread(() -> {
            try {
                existingBefore.set(read());
                ready.countDown();
                if (!observe.await(5, TimeUnit.SECONDS)) throw new AssertionError("Observer request missing");
                existingDuring.set(read());
            } catch (InterruptedException failure) {
                Thread.currentThread().interrupt();
            } finally {
                completed.countDown();
            }
        }, "scoped-policy-existing-thread-observer");
        existing.setDaemon(true);
        existing.start();
        if (!ready.await(5, TimeUnit.SECONDS)) throw new AssertionError("Existing thread not ready");
        int[] ownerDuring;
        int[] newDuring;
        try (var scope = ReloadExecution.begin(true)) {
            ownerDuring = read();
            observe.countDown();
            if (!completed.await(5, TimeUnit.SECONDS)) throw new AssertionError("Existing thread observation incomplete");
            newDuring = freshThread();
        } finally {
            observe.countDown();
            existing.join(5000);
        }
        int[] ownerAfter = read();
        int[] high = new int[]{ownerBefore[0], ownerBefore[1] | 1, ownerBefore[2] & ~1};
        if (!Arrays.equals(high, ownerDuring) || !Arrays.equals(ownerBefore, ownerAfter)) {
            throw new AssertionError("Owner scope was not applied or precisely restored");
        }
        if (existingBefore.get() == null || existingDuring.get() == null
                || !Arrays.equals(existingBefore.get(), existingDuring.get()) || !Arrays.equals(newBefore, newDuring)) {
            throw new AssertionError("Another thread's explicit policy changed");
        }
        String output = "{\"passed\":true,\"jdk\":\"" + System.getProperty("java.version")
                + "\",\"jna\":\"" + Native.VERSION + "\",\"ownerBefore\":" + Arrays.toString(ownerBefore)
                + ",\"ownerDuring\":" + Arrays.toString(ownerDuring) + ",\"ownerAfter\":" + Arrays.toString(ownerAfter)
                + ",\"existingBefore\":" + Arrays.toString(existingBefore.get())
                + ",\"existingDuring\":" + Arrays.toString(existingDuring.get())
                + ",\"newBefore\":" + Arrays.toString(newBefore) + ",\"newDuring\":" + Arrays.toString(newDuring) + "}\n";
        Files.writeString(Path.of(args[0]), output);
        System.out.println("SCOPED_THREAD_ISOLATION_PASS");
    }
}
