"""Freeze the rejected scope prototype, all formal samples and validation failures."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project / 'build/priority-closeout'
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
cohort = tools / 'scoped-thread-8ca66bf4-formal'
prep = json.loads((cohort / 'preparation.json').read_text())
target = project / 'docs/architecture-refactor/evidence/2026-10-19-scoped-reload-policy'
target.mkdir(parents=True, exist_ok=True)
packed = target / 'evidence.zip'
assert not packed.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == prep['revision']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
classes = {}
for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    base = tree / relative
    for file in base.rglob('*.class'):
        key = file.relative_to(base).as_posix()
        assert key not in classes
        classes[key] = hashlib.sha256(file.read_bytes()).hexdigest()
assert classes == prep['classBindings']
artifact = Path(prep['artifact'])
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == prep['artifactSha256']
secrets = []
for file in [tree / 'versions/26.1.2/run/server.properties', tools / 'client-world-acceptance/server/server.properties']:
    secrets.extend(line.split('=', 1)[1] for line in file.read_text().splitlines() if line.startswith('rcon.password='))
assert len(secrets) == 2 and all(secrets)
entries, redactions = {}, {}

def add_bytes(data, name, binary=False):
    assert name not in entries
    assert not any(secret in name for secret in secrets)
    if not binary:
        encoding = 'utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
        try:
            text = data.decode(encoding)
        except UnicodeDecodeError:
            encoding = 'gb18030'
            text = data.decode(encoding)
        if any(secret in text for secret in secrets):
            redactions[name] = dict(originalSha256=hashlib.sha256(data).hexdigest(),
                                    occurrences=sum(text.count(secret) for secret in secrets))
            for secret in secrets:
                text = text.replace(secret, '<REDACTED-RCON-CREDENTIAL>')
            data = text.encode(encoding)
    for secret in secrets:
        assert all(secret.encode(encoding) not in data for encoding in ['utf-8', 'utf-16-le', 'utf-16-be'])
    entries[name] = data

def add(file, name, binary=False):
    add_bytes(file.read_bytes(), name, binary)

for file in cohort.iterdir():
    if file.is_file(): add(file, 'formal/metadata/' + file.name)
for group in json.loads((cohort / 'groups.json').read_text()):
    folder = Path(group['outputDirectories'][0])
    for file in folder.rglob('*'):
        if file.is_file() and file.suffix in {'.json', '.jsonl', '.log', '.txt', '.csv'}:
            add(file, 'formal/' + group['group'] + '/' + file.relative_to(folder).as_posix())
for file in (tools / 'scoped-policy-prototype').rglob('*'):
    if file.is_file() and file.suffix in {'.json', '.xml', '.java', '.log'}:
        add(file, 'validation/' + file.relative_to(tools / 'scoped-policy-prototype').as_posix())
for file in tools.glob('scoped-policy-*.log'):
    add(file, 'validation/logs/' + file.name)
for file in tools.glob('scoped-policy-ci-*.json'):
    add(file, 'validation/gates/' + file.name)
for name in ['scoped-thread-formal-controller.log', 'scoped-thread-formal-controller-stderr.log']:
    add(tools / name, 'validation/logs/' + name)
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    base = tree / 'versions' / node / 'build'
    for name in ['TEST-com.tkisor.nekojs.platform.ReloadExecutionTest.xml',
                 'TEST-com.tkisor.nekojs.command.RuntimeCommandLifecycleSourceTraceTest.xml']:
        add(base / 'test-results/test' / name, 'validation/final-tests/' + node + '/' + name)
    for file in (base / 'nekojs-gates').glob('*.json'):
        add(file, 'validation/node-gates/' + node + '/' + file.name)
add(tree / 'common/build/test-results/test/TEST-com.tkisor.nekojs.core.api.ManagedDeclarationCoverageGateTest.xml',
    'validation/common-declaration.xml')
add(tree / 'common/build/nekojs-gates/declaration-parity.json', 'validation/declaration-parity.json')
add(artifact, 'binaries/prototype-neoforge.jar', True)
for name in ['bench/perf/sample.ps1', 'bench/perf/rcon.py', *prep['fixtureHashes']]:
    add(tree / name, 'harness/' + name)
sources = subprocess.check_output(['git', 'diff', '--name-only', '3c94d8c8', prep['revision']], cwd=tree, text=True).splitlines()
for name in sources:
    add(tree / name, 'source/' + name)
add_bytes(subprocess.check_output(['git', 'diff', '3c94d8c8', prep['revision']], cwd=tree), 'source/change.patch')
for name in ['formal-performance.py', 'judge-performance.py', 'freeze-scoped-policy-full-build.py',
             'wire-scoped-reload-prototype.py', 'ObserveScopedThreadIsolation.java',
             'run-scoped-thread-isolation.py', 'seal-scoped-policy-evidence.py']:
    add(tools / name, 'tools/' + name)
add_bytes((json.dumps(dict(classBindings=classes, trackedSourcesClean=True,
                          prototypeOnly=True, promotedToStonecutter=False), indent=2) + '\n').encode(), 'post-run-bindings.json')
add_bytes((json.dumps(redactions, indent=2) + '\n').encode(), 'redactions.json')
with zipfile.ZipFile(packed, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()): archive.writestr(name, data)
manifest = dict(prototypeCommit=prep['revision'], baseCommit='3c94d8c8', prototypeRejected=True,
                promotedToStonecutter=False, samplerChanged=False, externalQosController=False,
                archiveBytes=packed.stat().st_size, archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
                entries={name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())})
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k != 'entries'}))
print('entries=' + str(len(entries)))
