import { $Function as $NekoImport$Function, $Function_ as $NekoImport$Function_ } from "java:it/unimi/dsi/fastutil";
import { $Byte2ByteFunction, $Byte2ByteFunction_, $Byte2CharFunction, $Byte2CharFunction_, $Byte2DoubleFunction, $Byte2DoubleFunction_, $Byte2FloatFunction, $Byte2FloatFunction_, $Byte2IntFunction, $Byte2IntFunction_, $Byte2LongFunction, $Byte2LongFunction_, $Byte2ObjectFunction, $Byte2ObjectFunction_, $Byte2ReferenceFunction, $Byte2ReferenceFunction_, $Byte2ShortFunction, $Byte2ShortFunction_ } from "java:it/unimi/dsi/fastutil/bytes";
import { $Char2ByteFunction, $Char2ByteFunction_, $Char2CharFunction, $Char2CharFunction_, $Char2DoubleFunction, $Char2DoubleFunction_, $Char2FloatFunction, $Char2FloatFunction_, $Char2IntFunction, $Char2IntFunction_, $Char2LongFunction, $Char2LongFunction_, $Char2ObjectFunction, $Char2ObjectFunction_, $Char2ReferenceFunction, $Char2ReferenceFunction_, $Char2ShortFunction, $Char2ShortFunction_ } from "java:it/unimi/dsi/fastutil/chars";
import { $Double2ByteFunction, $Double2ByteFunction_, $Double2CharFunction, $Double2CharFunction_, $Double2DoubleFunction, $Double2DoubleFunction_, $Double2FloatFunction, $Double2FloatFunction_, $Double2IntFunction, $Double2IntFunction_, $Double2LongFunction, $Double2LongFunction_, $Double2ObjectFunction, $Double2ObjectFunction_, $Double2ReferenceFunction, $Double2ReferenceFunction_, $Double2ShortFunction, $Double2ShortFunction_ } from "java:it/unimi/dsi/fastutil/doubles";
import { $Float2ByteFunction, $Float2ByteFunction_, $Float2CharFunction, $Float2CharFunction_, $Float2DoubleFunction, $Float2DoubleFunction_, $Float2FloatFunction, $Float2FloatFunction_, $Float2IntFunction, $Float2IntFunction_, $Float2LongFunction, $Float2LongFunction_, $Float2ObjectFunction, $Float2ObjectFunction_, $Float2ReferenceFunction, $Float2ReferenceFunction_, $Float2ShortFunction, $Float2ShortFunction_ } from "java:it/unimi/dsi/fastutil/floats";
import { $Int2ByteFunction, $Int2ByteFunction_, $Int2CharFunction, $Int2CharFunction_, $Int2DoubleFunction, $Int2DoubleFunction_, $Int2FloatFunction, $Int2FloatFunction_, $Int2IntFunction, $Int2IntFunction_, $Int2LongFunction, $Int2LongFunction_, $Int2ObjectFunction, $Int2ObjectFunction_, $Int2ReferenceFunction, $Int2ReferenceFunction_, $Int2ShortFunction, $Int2ShortFunction_ } from "java:it/unimi/dsi/fastutil/ints";
import { $Object2ByteFunction, $Object2ByteFunction_, $Object2CharFunction, $Object2CharFunction_, $Object2DoubleFunction, $Object2DoubleFunction_, $Object2FloatFunction, $Object2FloatFunction_, $Object2IntFunction, $Object2IntFunction_, $Object2LongFunction, $Object2LongFunction_, $Object2ObjectFunction, $Object2ObjectFunction_, $Object2ReferenceFunction, $Object2ReferenceFunction_, $Object2ShortFunction, $Object2ShortFunction_, $ObjectCollection, $ObjectSet, $Reference2ByteFunction, $Reference2ByteFunction_, $Reference2CharFunction, $Reference2CharFunction_, $Reference2DoubleFunction, $Reference2DoubleFunction_, $Reference2FloatFunction, $Reference2FloatFunction_, $Reference2IntFunction, $Reference2IntFunction_, $Reference2LongFunction, $Reference2LongFunction_, $Reference2ObjectFunction, $Reference2ObjectFunction_, $Reference2ReferenceFunction, $Reference2ReferenceFunction_, $Reference2ShortFunction, $Reference2ShortFunction_ } from "java:it/unimi/dsi/fastutil/objects";
import { $Short2ByteFunction, $Short2ByteFunction_, $Short2CharFunction, $Short2CharFunction_, $Short2DoubleFunction, $Short2DoubleFunction_, $Short2FloatFunction, $Short2FloatFunction_, $Short2IntFunction, $Short2IntFunction_, $Short2LongFunction, $Short2LongFunction_, $Short2ObjectFunction, $Short2ObjectFunction_, $Short2ReferenceFunction, $Short2ReferenceFunction_, $Short2ShortFunction, $Short2ShortFunction_ } from "java:it/unimi/dsi/fastutil/shorts";
import { $Comparable, $Comparable_, $Iterable } from "java:java/lang";
import { $Collection, $Comparator, $Comparator_, $Map, $Map$Entry, $PrimitiveIterator$OfLong, $Set, $Spliterator$OfLong } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function as $NekoImport$Function1, $Function_ as $NekoImport$Function_1, $IntFunction, $IntFunction_, $LongConsumer as $NekoImport$LongConsumer, $LongConsumer_ as $NekoImport$LongConsumer_, $LongFunction, $LongFunction_, $LongPredicate as $NekoImport$LongPredicate, $LongPredicate_ as $NekoImport$LongPredicate_, $LongToDoubleFunction, $LongToDoubleFunction_, $LongToIntFunction, $LongToIntFunction_, $LongUnaryOperator, $LongUnaryOperator_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $LongStream, $Stream } from "java:java/util/stream";

declare module "java:it/unimi/dsi/fastutil/longs" {
    export interface $Long2ObjectFunction<out V> extends $NekoImport$Function<number, V>, $LongFunction<V> {
        andThenByte(arg0: $Object2ByteFunction_<V, object, number>): $Long2ByteFunction;
        andThenChar(arg0: $Object2CharFunction_<V, object, string>): $Long2CharFunction;
        andThenDouble(arg0: $Object2DoubleFunction_<V, object, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Object2FloatFunction_<V, object, number>): $Long2FloatFunction;
        andThenInt(arg0: $Object2IntFunction_<V, object, number>): $Long2IntFunction;
        andThenLong(arg0: $Object2LongFunction_<V, object, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, object, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, object, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Object2ShortFunction_<V, object, number>): $Long2ShortFunction;
        apply(arg0: number): V;
        apply(arg0: number): V;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2ObjectFunction<V>;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, V>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        getOrDefault(arg0: number, arg1: V): V;
        get(arg0: object): V;
        get(arg0: number): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: object): V;
        remove(arg0: number): V;
    }

    export interface $Long2ByteFunction extends $NekoImport$Function<number, number>, $LongToIntFunction {
        andThenByte(arg0: $Byte2ByteFunction_<number, number>): $Long2ByteFunction;
        andThenChar(arg0: $Byte2CharFunction_<number, string>): $Long2CharFunction;
        andThenDouble(arg0: $Byte2DoubleFunction_<number, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Byte2FloatFunction_<number, number>): $Long2FloatFunction;
        andThenInt(arg0: $Byte2IntFunction_<number, number>): $Long2IntFunction;
        andThenLong(arg0: $Byte2LongFunction_<number, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Byte2ObjectFunction_<T, number, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Byte2ReferenceFunction_<T, number, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Byte2ShortFunction_<number, number>): $Long2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2ByteFunction;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2ByteFunction;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2ByteFunction;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2ByteFunction;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2ByteFunction;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2ByteFunction;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2ByteFunction<T>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2ByteFunction<T>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2ByteFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Long2CharFunction extends $NekoImport$Function<number, string>, $LongToIntFunction {
        andThenByte(arg0: $Char2ByteFunction_<string, number>): $Long2ByteFunction;
        andThenChar(arg0: $Char2CharFunction_<string, string>): $Long2CharFunction;
        andThenDouble(arg0: $Char2DoubleFunction_<string, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Char2FloatFunction_<string, number>): $Long2FloatFunction;
        andThenInt(arg0: $Char2IntFunction_<string, number>): $Long2IntFunction;
        andThenLong(arg0: $Char2LongFunction_<string, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Char2ObjectFunction_<T, string, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Char2ReferenceFunction_<T, string, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Char2ShortFunction_<string, number>): $Long2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<string, T, string, T>): $NekoImport$Function1<number, T>;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2CharFunction;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2CharFunction;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2CharFunction;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2CharFunction;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2CharFunction;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2CharFunction;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2CharFunction<T>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2CharFunction<T>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2CharFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, string>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: string): void;
        defaultReturnValue(): string;
        getOrDefault(arg0: object, arg1: string): string;
        getOrDefault(arg0: number, arg1: string): string;
        get(arg0: object): string;
        get(arg0: number): string;
        put(arg0: number, arg1: string): string;
        put(arg0: number, arg1: string): string;
        remove(arg0: object): string;
        remove(arg0: number): string;
    }

    export interface $Long2DoubleFunction extends $NekoImport$Function<number, number>, $LongToDoubleFunction {
        andThenByte(arg0: $Double2ByteFunction_<number, number>): $Long2ByteFunction;
        andThenChar(arg0: $Double2CharFunction_<number, string>): $Long2CharFunction;
        andThenDouble(arg0: $Double2DoubleFunction_<number, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Double2FloatFunction_<number, number>): $Long2FloatFunction;
        andThenInt(arg0: $Double2IntFunction_<number, number>): $Long2IntFunction;
        andThenLong(arg0: $Double2LongFunction_<number, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Double2ObjectFunction_<T, number, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Double2ReferenceFunction_<T, number, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Double2ShortFunction_<number, number>): $Long2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsDouble(arg0: number): number;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2DoubleFunction;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2DoubleFunction;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2DoubleFunction;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2DoubleFunction;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2DoubleFunction;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2DoubleFunction;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2DoubleFunction<T>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2DoubleFunction<T>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2DoubleFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Long2FloatFunction extends $NekoImport$Function<number, number>, $LongToDoubleFunction {
        andThenByte(arg0: $Float2ByteFunction_<number, number>): $Long2ByteFunction;
        andThenChar(arg0: $Float2CharFunction_<number, string>): $Long2CharFunction;
        andThenDouble(arg0: $Float2DoubleFunction_<number, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Float2FloatFunction_<number, number>): $Long2FloatFunction;
        andThenInt(arg0: $Float2IntFunction_<number, number>): $Long2IntFunction;
        andThenLong(arg0: $Float2LongFunction_<number, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Float2ObjectFunction_<T, number, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Float2ReferenceFunction_<T, number, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Float2ShortFunction_<number, number>): $Long2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsDouble(arg0: number): number;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2FloatFunction;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2FloatFunction;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2FloatFunction;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2FloatFunction;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2FloatFunction;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2FloatFunction;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2FloatFunction<T>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2FloatFunction<T>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2FloatFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Long2IntFunction extends $NekoImport$Function<number, number>, $LongToIntFunction {
        andThenByte(arg0: $Int2ByteFunction_<number, number>): $Long2ByteFunction;
        andThenChar(arg0: $Int2CharFunction_<number, string>): $Long2CharFunction;
        andThenDouble(arg0: $Int2DoubleFunction_<number, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Int2FloatFunction_<number, number>): $Long2FloatFunction;
        andThenInt(arg0: $Int2IntFunction_<number, number>): $Long2IntFunction;
        andThenLong(arg0: $Int2LongFunction_<number, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Int2ObjectFunction_<T, number, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Int2ReferenceFunction_<T, number, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Int2ShortFunction_<number, number>): $Long2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2IntFunction;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2IntFunction;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2IntFunction;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2IntFunction;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2IntFunction;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2IntFunction;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2IntFunction<T>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2IntFunction<T>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2IntFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Long2LongFunction extends $NekoImport$Function<number, number>, $LongUnaryOperator {
        andThenByte(arg0: $Long2ByteFunction_<number, number>): $Long2ByteFunction;
        andThenChar(arg0: $Long2CharFunction_<number, string>): $Long2CharFunction;
        andThenDouble(arg0: $Long2DoubleFunction_<number, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Long2FloatFunction_<number, number>): $Long2FloatFunction;
        andThenInt(arg0: $Long2IntFunction_<number, number>): $Long2IntFunction;
        andThenLong(arg0: $Long2LongFunction_<number, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Long2ObjectFunction_<T, number, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Long2ReferenceFunction_<T, number, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Long2ShortFunction_<number, number>): $Long2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $LongUnaryOperator_<number, number>): $LongUnaryOperator;
        applyAsLong(arg0: number): number;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2LongFunction;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2LongFunction;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2LongFunction;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2LongFunction;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2LongFunction;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2LongFunction;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2LongFunction<T>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2LongFunction<T>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2LongFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        compose(arg0: $LongUnaryOperator_<number, number>): $LongUnaryOperator;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }
    export const $Long2LongFunction: {
        identity(): $Long2LongFunction;
    };

    export interface $Long2ReferenceFunction<out V> extends $NekoImport$Function<number, V>, $LongFunction<V> {
        andThenByte(arg0: $Reference2ByteFunction_<V, object, number>): $Long2ByteFunction;
        andThenChar(arg0: $Reference2CharFunction_<V, object, string>): $Long2CharFunction;
        andThenDouble(arg0: $Reference2DoubleFunction_<V, object, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Reference2FloatFunction_<V, object, number>): $Long2FloatFunction;
        andThenInt(arg0: $Reference2IntFunction_<V, object, number>): $Long2IntFunction;
        andThenLong(arg0: $Reference2LongFunction_<V, object, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Reference2ObjectFunction_<V, T, object, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Reference2ReferenceFunction_<V, T, object, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Reference2ShortFunction_<V, object, number>): $Long2ShortFunction;
        apply(arg0: number): V;
        apply(arg0: number): V;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2ReferenceFunction<V>;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2ReferenceFunction<V>;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2ReferenceFunction<V>;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2ReferenceFunction<V>;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2ReferenceFunction<V>;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2ReferenceFunction<V>;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2ReferenceFunction<T, V>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2ReferenceFunction<T, V>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2ReferenceFunction<V>;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, V>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        getOrDefault(arg0: number, arg1: V): V;
        get(arg0: object): V;
        get(arg0: number): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: object): V;
        remove(arg0: number): V;
    }

    export interface $Long2ShortFunction extends $NekoImport$Function<number, number>, $LongToIntFunction {
        andThenByte(arg0: $Short2ByteFunction_<number, number>): $Long2ByteFunction;
        andThenChar(arg0: $Short2CharFunction_<number, string>): $Long2CharFunction;
        andThenDouble(arg0: $Short2DoubleFunction_<number, number>): $Long2DoubleFunction;
        andThenFloat(arg0: $Short2FloatFunction_<number, number>): $Long2FloatFunction;
        andThenInt(arg0: $Short2IntFunction_<number, number>): $Long2IntFunction;
        andThenLong(arg0: $Short2LongFunction_<number, number>): $Long2LongFunction;
        andThenObject<T>(arg0: $Short2ObjectFunction_<T, number, T>): $Long2ObjectFunction<T>;
        andThenReference<T>(arg0: $Short2ReferenceFunction_<T, number, T>): $Long2ReferenceFunction<T>;
        andThenShort(arg0: $Short2ShortFunction_<number, number>): $Long2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2LongFunction_<number, number>): $Byte2ShortFunction;
        composeChar(arg0: $Char2LongFunction_<string, number>): $Char2ShortFunction;
        composeDouble(arg0: $Double2LongFunction_<number, number>): $Double2ShortFunction;
        composeFloat(arg0: $Float2LongFunction_<number, number>): $Float2ShortFunction;
        composeInt(arg0: $Int2LongFunction_<number, number>): $Int2ShortFunction;
        composeLong(arg0: $Long2LongFunction_<number, number>): $Long2ShortFunction;
        composeObject<T>(arg0: $Object2LongFunction_<T, object, number>): $Object2ShortFunction<T>;
        composeReference<T>(arg0: $Reference2LongFunction_<T, object, number>): $Reference2ShortFunction<T>;
        composeShort(arg0: $Short2LongFunction_<number, number>): $Short2ShortFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $LongConsumer extends $Consumer<number>, $NekoImport$LongConsumer {
        accept(arg0: number): void;
        accept(arg0: number): void;
        andThen(arg0: $LongConsumer_<number>): $LongConsumer;
        andThen(arg0: $Consumer_<number, number>): $Consumer<number>;
        andThen(arg0: $NekoImport$LongConsumer_<number>): $LongConsumer;
    }

    export interface $LongSet extends $LongCollection, $Set<number> {
        addAll(arg0: $LongCollection): boolean;
        addAll(arg0: number[]): boolean;
        add(arg0: number): boolean;
        add(arg0: number): boolean;
        clear(): void;
        containsAll(arg0: $LongCollection): boolean;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        contains(arg0: number): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $LongConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$LongConsumer_<number>): void;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $LongIterator;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $LongCollection): boolean;
        removeAll(arg0: any[]): boolean;
        removeIf(arg0: $LongPredicate_<number, boolean>): boolean;
        removeIf(arg0: $NekoImport$LongPredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        remove(arg0: object): boolean;
        remove(arg0: number): boolean;
        rem(arg0: number): boolean;
        retainAll(arg0: $LongCollection): boolean;
        retainAll(arg0: any[]): boolean;
        size(): number;
        spliterator(): $LongSpliterator;
        stream(): $Stream<number>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(arg0: number[]): number[];
        toArray(): object[];
    }
    export const $LongSet: {
        of(arg0?: number[]): $LongSet;
        of(arg0: number, arg1: number, arg2: number): $LongSet;
        of(arg0: number, arg1: number): $LongSet;
        of(arg0: number): $LongSet;
        of(): $LongSet;
    };

    export interface $LongCollection extends $Collection<number>, $LongIterable {
        addAll(arg0: $LongCollection): boolean;
        addAll(arg0: number[]): boolean;
        add(arg0: number): boolean;
        add(arg0: number): boolean;
        containsAll(arg0: $LongCollection): boolean;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        contains(arg0: number): boolean;
        forEach(arg0: $LongConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$LongConsumer_<number>): void;
        iterator(): $LongIterator;
        longIterator(): $LongIterator;
        longParallelStream(): $LongStream;
        longSpliterator(): $LongSpliterator;
        longStream(): $LongStream;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $LongCollection): boolean;
        removeAll(arg0: any[]): boolean;
        removeIf(arg0: $LongPredicate_<number, boolean>): boolean;
        removeIf(arg0: $NekoImport$LongPredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        remove(arg0: object): boolean;
        rem(arg0: number): boolean;
        retainAll(arg0: $LongCollection): boolean;
        retainAll(arg0: any[]): boolean;
        spliterator(): $LongSpliterator;
        stream(): $Stream<number>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(arg0: number[]): number[];
        toArray(): object[];
        toLongArray(arg0: number[]): number[];
        toLongArray(): number[];
    }

    export interface $LongIterator extends $PrimitiveIterator$OfLong {
        forEachRemaining(arg0: $LongConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$LongConsumer_<number>): void;
        nextLong(): number;
        next(): number;
        skip(arg0: number): number;
    }

    export interface $LongPredicate extends $Predicate<number>, $NekoImport$LongPredicate {
        and(arg0: $LongPredicate_<number, boolean>): $LongPredicate;
        and(arg0: $NekoImport$LongPredicate_<number, boolean>): $LongPredicate;
        and(arg0: $Predicate_<number, number, boolean>): $Predicate<number>;
        negate(): $LongPredicate;
        or(arg0: $LongPredicate_<number, boolean>): $LongPredicate;
        or(arg0: $NekoImport$LongPredicate_<number, boolean>): $LongPredicate;
        or(arg0: $Predicate_<number, number, boolean>): $Predicate<number>;
        test(arg0: number): boolean;
        test(arg0: number): boolean;
    }

    export interface $LongSpliterator extends $Spliterator$OfLong {
        forEachRemaining(arg0: $LongConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$LongConsumer_<number>): void;
        getComparator(): $LongComparator;
        skip(arg0: number): number;
        tryAdvance(arg0: $LongConsumer_<number>): boolean;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $NekoImport$LongConsumer_<number>): boolean;
        trySplit(): $LongSpliterator;
    }

    export interface $LongIterable extends $Iterable<number> {
        forEach(arg0: $LongConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$LongConsumer_<number>): void;
        iterator(): $LongIterator;
        longIterator(): $LongIterator;
        longSpliterator(): $LongSpliterator;
        spliterator(): $LongSpliterator;
    }

    export interface $LongComparator extends $Comparator<number> {
        compare(arg0: number, arg1: number): number;
        compare(arg0: number, arg1: number): number;
        reversed(): $LongComparator;
        thenComparing(arg0: $LongComparator_<number, number, number>): $LongComparator;
        thenComparing(arg0: $Comparator_<number, number, number, number>): $Comparator<number>;
        thenComparing<U>(arg0: $NekoImport$Function_1<number, U, number, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<number>;
        thenComparing<U extends $Comparable<any>>(arg0: $NekoImport$Function_1<number, U, number, U>): $Comparator<number>;
    }

    export interface $Long2ObjectMap<V> extends $Long2ObjectFunction<V>, $Map<number, V> {
        clear(): void;
        computeIfAbsentPartial(arg0: number, arg1: $Long2ObjectFunction_<V, number, V>): V;
        computeIfAbsent(arg0: number, arg1: $NekoImport$Function_1<number, V, number, V>): V;
        computeIfAbsent(arg0: number, arg1: $Long2ObjectFunction_<V, number, V>): V;
        computeIfAbsent(arg0: number, arg1: $LongFunction_<V, number, V>): V;
        computeIfPresent(arg0: number, arg1: $BiFunction_<number, V, V, number, V, V>): V;
        computeIfPresent(arg0: number, arg1: $BiFunction_<number, V, V, number, V, V>): V;
        compute(arg0: number, arg1: $BiFunction_<number, V, V, number, V, V>): V;
        compute(arg0: number, arg1: $BiFunction_<number, V, V, number, V, V>): V;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        entrySet(): $ObjectSet<$Map$Entry<number, V>>;
        forEach(arg0: $BiConsumer_<number, V, number, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        getOrDefault(arg0: number, arg1: V): V;
        get(arg0: object): V;
        get(arg0: number): V;
        keySet(): $LongSet;
        long2ObjectEntrySet(): $ObjectSet<$Long2ObjectMap$Entry<V>>;
        merge(arg0: number, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        merge(arg0: number, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putIfAbsent(arg0: number, arg1: V): V;
        putIfAbsent(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        remove(arg0: number, arg1: object): boolean;
        remove(arg0: number): V;
        replace(arg0: number, arg1: V, arg2: V): boolean;
        replace(arg0: number, arg1: V): V;
        replace(arg0: number, arg1: V, arg2: V): boolean;
        replace(arg0: number, arg1: V): V;
        size(): number;
        values(): $ObjectCollection<V>;
    }

    export interface $Long2ObjectMap$Entry<V> extends $Map$Entry<number, V> {
        getKey(): number;
        getLongKey(): number;
    }

    export type $Long2ObjectFunction_<Host0 = any, CallbackArg0 = number, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2ObjectFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Long2ByteFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2ByteFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Long2CharFunction_<CallbackArg0 = number, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2CharFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Long2DoubleFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2DoubleFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Long2FloatFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2FloatFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Long2IntFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2IntFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Long2LongFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2LongFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Long2ReferenceFunction_<Host0 = any, CallbackArg0 = number, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2ReferenceFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Long2ShortFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Long2ShortFunction & { readonly [Symbol.hasInstance]?: never });
    export type $LongConsumer_<CallbackArg0 = number> = ((arg0: CallbackArg0) => void) | ($LongConsumer & { readonly [Symbol.hasInstance]?: never });
    export type $LongPredicate_<CallbackArg0 = number, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($LongPredicate & { readonly [Symbol.hasInstance]?: never });
    export type $LongIterable_<CallbackResult = $LongIterator> = (() => CallbackResult) | ($LongIterable & { readonly [Symbol.hasInstance]?: never });
    export type $LongComparator_<CallbackArg0 = number, CallbackArg1 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($LongComparator & { readonly [Symbol.hasInstance]?: never });
}
