import { $Excluder } from "java:com/google/gson/internal";
import { $TypeToken } from "java:com/google/gson/reflect";
import { $JsonReader, $JsonWriter } from "java:com/google/gson/stream";
import { $Reader, $Writer } from "java:java/io";
import { $Appendable, $Class, $Enum, $Iterable } from "java:java/lang";
import { $Annotation, $Annotation_ } from "java:java/lang/annotation";
import { $Field, $Type } from "java:java/lang/reflect";
import { $Collection, $Iterator, $List, $Map, $Map$Entry, $Set, $Spliterator } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";

export * as internal from "java:com/google/gson/internal";
export * as reflect from "java:com/google/gson/reflect";
export * as stream from "java:com/google/gson/stream";

declare module "java:com/google/gson" {
    export class $JsonArray extends $JsonElement implements $Iterable<$JsonElement> {
        constructor();
        constructor(arg0: number);
        get asBigDecimal(): number;
        getAsBigDecimal(): number;
        get asBigInteger(): number;
        getAsBigInteger(): number;
        get asBoolean(): boolean;
        getAsBoolean(): boolean;
        get asByte(): number;
        getAsByte(): number;
        get asCharacter(): string;
        getAsCharacter(): string;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get asString(): string;
        getAsString(): string;
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(arg0: $JsonArray): void;
        add(arg0: $JsonElement): void;
        add(arg0: boolean): void;
        add(arg0: string): void;
        add(arg0: number): void;
        add(arg0: string): void;
        asList(): $List<$JsonElement>;
        contains(arg0: $JsonElement): boolean;
        deepCopy(): $JsonArray;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<$JsonElement, $JsonElement>): void;
        get(arg0: number): $JsonElement;
        hashCode(): number;
        iterator(): $Iterator<$JsonElement>;
        remove(arg0: $JsonElement): boolean;
        remove(arg0: number): $JsonElement;
        set(arg0: number, arg1: $JsonElement): $JsonElement;
        size(): number;
        spliterator(): $Spliterator<$JsonElement>;
    }

    export class $JsonObject extends $JsonElement {
        constructor();
        get asJsonArray(): $JsonArray;
        getAsJsonArray(): $JsonArray;
        get asJsonObject(): $JsonObject;
        getAsJsonObject(): $JsonObject;
        get asJsonPrimitive(): $JsonPrimitive;
        getAsJsonPrimitive(): $JsonPrimitive;
        get empty(): boolean;
        isEmpty(): boolean;
        addProperty(arg0: string, arg1: boolean): void;
        addProperty(arg0: string, arg1: string): void;
        addProperty(arg0: string, arg1: number): void;
        addProperty(arg0: string, arg1: string): void;
        add(arg0: string, arg1: $JsonElement): void;
        asMap(): $Map<string, $JsonElement>;
        deepCopy(): $JsonObject;
        entrySet(): $Set<$Map$Entry<string, $JsonElement>>;
        equals(arg0: object): boolean;
        getAsJsonArray(arg0: string): $JsonArray;
        getAsJsonObject(arg0: string): $JsonObject;
        getAsJsonPrimitive(arg0: string): $JsonPrimitive;
        get(arg0: string): $JsonElement;
        hashCode(): number;
        has(arg0: string): boolean;
        keySet(): $Set<string>;
        remove(arg0: string): $JsonElement;
        size(): number;
    }

    export class $JsonElement {
        constructor();
        get asBigDecimal(): number;
        getAsBigDecimal(): number;
        get asBigInteger(): number;
        getAsBigInteger(): number;
        get asBoolean(): boolean;
        getAsBoolean(): boolean;
        get asByte(): number;
        getAsByte(): number;
        get asCharacter(): string;
        getAsCharacter(): string;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asJsonArray(): $JsonArray;
        getAsJsonArray(): $JsonArray;
        get asJsonNull(): $JsonNull;
        getAsJsonNull(): $JsonNull;
        get asJsonObject(): $JsonObject;
        getAsJsonObject(): $JsonObject;
        get asJsonPrimitive(): $JsonPrimitive;
        getAsJsonPrimitive(): $JsonPrimitive;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get asString(): string;
        getAsString(): string;
        get jsonArray(): boolean;
        isJsonArray(): boolean;
        get jsonNull(): boolean;
        isJsonNull(): boolean;
        get jsonObject(): boolean;
        isJsonObject(): boolean;
        get jsonPrimitive(): boolean;
        isJsonPrimitive(): boolean;
        deepCopy(): $JsonElement;
        toString(): string;
    }

    export class $JsonNull extends $JsonElement {
        constructor();
        static INSTANCE: $JsonNull;
        deepCopy(): $JsonNull;
        equals(arg0: object): boolean;
        hashCode(): number;
    }

    export class $JsonPrimitive extends $JsonElement {
        constructor(arg0: boolean);
        constructor(arg0: string);
        constructor(arg0: number);
        constructor(arg0: string);
        get asBigDecimal(): number;
        getAsBigDecimal(): number;
        get asBigInteger(): number;
        getAsBigInteger(): number;
        get asBoolean(): boolean;
        getAsBoolean(): boolean;
        get asByte(): number;
        getAsByte(): number;
        get asCharacter(): string;
        getAsCharacter(): string;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get asString(): string;
        getAsString(): string;
        get boolean(): boolean;
        isBoolean(): boolean;
        get number(): boolean;
        isNumber(): boolean;
        get string(): boolean;
        isString(): boolean;
        deepCopy(): $JsonPrimitive;
        equals(arg0: object): boolean;
        hashCode(): number;
    }

    export class $Gson {
        constructor();
        excluder(): $Excluder;
        fieldNamingStrategy(): $FieldNamingStrategy;
        fromJson<T>(arg0: $JsonElement, arg1: $TypeToken<T>): T;
        fromJson<T>(arg0: $JsonElement, arg1: $Class<T>): T;
        fromJson<T>(arg0: $JsonElement, arg1: $Type): T;
        fromJson<T>(arg0: $JsonReader, arg1: $TypeToken<T>): T;
        fromJson<T>(arg0: $JsonReader, arg1: $Type): T;
        fromJson<T>(arg0: $Reader, arg1: $TypeToken<T>): T;
        fromJson<T>(arg0: $Reader, arg1: $Class<T>): T;
        fromJson<T>(arg0: $Reader, arg1: $Type): T;
        fromJson<T>(arg0: string, arg1: $TypeToken<T>): T;
        fromJson<T>(arg0: string, arg1: $Class<T>): T;
        fromJson<T>(arg0: string, arg1: $Type): T;
        getAdapter<T>(arg0: $TypeToken<T>): $TypeAdapter<T>;
        getAdapter<T>(arg0: $Class<T>): $TypeAdapter<T>;
        getDelegateAdapter<T>(arg0: $TypeAdapterFactory_<$Gson, $TypeToken<any>, $TypeAdapter<any>>, arg1: $TypeToken<T>): $TypeAdapter<T>;
        htmlSafe(): boolean;
        newBuilder(): $GsonBuilder;
        newJsonReader(arg0: $Reader): $JsonReader;
        newJsonWriter(arg0: $Writer): $JsonWriter;
        serializeNulls(): boolean;
        toJsonTree(arg0: object, arg1: $Type): $JsonElement;
        toJsonTree(arg0: object): $JsonElement;
        toJson(arg0: $JsonElement, arg1: $JsonWriter): void;
        toJson(arg0: $JsonElement, arg1: $Appendable): void;
        toJson(arg0: $JsonElement): string;
        toJson(arg0: object, arg1: $Appendable): void;
        toJson(arg0: object, arg1: $Type, arg2: $JsonWriter): void;
        toJson(arg0: object, arg1: $Type, arg2: $Appendable): void;
        toJson(arg0: object, arg1: $Type): string;
        toJson(arg0: object): string;
        toString(): string;
    }

    export interface $FieldNamingStrategy {
        translateName(arg0: $Field): string;
    }

    export class $GsonBuilder {
        constructor();
        addDeserializationExclusionStrategy(arg0: $ExclusionStrategy): $GsonBuilder;
        addReflectionAccessFilter(arg0: $ReflectionAccessFilter_<$Class<any>, $ReflectionAccessFilter$FilterResult_>): $GsonBuilder;
        addSerializationExclusionStrategy(arg0: $ExclusionStrategy): $GsonBuilder;
        create(): $Gson;
        disableHtmlEscaping(): $GsonBuilder;
        disableInnerClassSerialization(): $GsonBuilder;
        disableJdkUnsafe(): $GsonBuilder;
        enableComplexMapKeySerialization(): $GsonBuilder;
        excludeFieldsWithModifiers(arg0?: number[]): $GsonBuilder;
        excludeFieldsWithoutExposeAnnotation(): $GsonBuilder;
        generateNonExecutableJson(): $GsonBuilder;
        registerTypeAdapterFactory(arg0: $TypeAdapterFactory_<$Gson, $TypeToken<any>, $TypeAdapter<any>>): $GsonBuilder;
        registerTypeAdapter(arg0: $Type, arg1: object): $GsonBuilder;
        registerTypeHierarchyAdapter(arg0: $Class<any>, arg1: object): $GsonBuilder;
        serializeNulls(): $GsonBuilder;
        serializeSpecialFloatingPointValues(): $GsonBuilder;
        setDateFormat(arg0: number, arg1: number): $GsonBuilder;
        setDateFormat(arg0: number): $GsonBuilder;
        setDateFormat(arg0: string): $GsonBuilder;
        setExclusionStrategies(arg0?: $ExclusionStrategy[]): $GsonBuilder;
        setFieldNamingPolicy(arg0: $FieldNamingPolicy_): $GsonBuilder;
        setFieldNamingStrategy(arg0: $FieldNamingStrategy_<$Field, string>): $GsonBuilder;
        setLenient(): $GsonBuilder;
        setLongSerializationPolicy(arg0: $LongSerializationPolicy_): $GsonBuilder;
        setNumberToNumberStrategy(arg0: $ToNumberStrategy_<$JsonReader, number>): $GsonBuilder;
        setObjectToNumberStrategy(arg0: $ToNumberStrategy_<$JsonReader, number>): $GsonBuilder;
        setPrettyPrinting(): $GsonBuilder;
        setVersion(arg0: number): $GsonBuilder;
    }

    export class $TypeAdapter<T> {
        constructor();
        fromJsonTree(arg0: $JsonElement): T;
        fromJson(arg0: $Reader): T;
        fromJson(arg0: string): T;
        nullSafe(): $TypeAdapter<T>;
        read(arg0: $JsonReader): T;
        toJsonTree(arg0: T): $JsonElement;
        toJson(arg0: T): string;
        toJson(arg0: $Writer, arg1: T): void;
        write(arg0: $JsonWriter, arg1: T): void;
    }

    export interface $TypeAdapterFactory {
        create<T>(arg0: $Gson, arg1: $TypeToken<T>): $TypeAdapter<T>;
    }

    export interface $ExclusionStrategy {
        shouldSkipClass(arg0: $Class<any>): boolean;
        shouldSkipField(arg0: $FieldAttributes): boolean;
    }

    export class $FieldNamingPolicy {
        static IDENTITY: $FieldNamingPolicy;
        static LOWER_CASE_WITH_DASHES: $FieldNamingPolicy;
        static LOWER_CASE_WITH_DOTS: $FieldNamingPolicy;
        static LOWER_CASE_WITH_UNDERSCORES: $FieldNamingPolicy;
        static UPPER_CAMEL_CASE: $FieldNamingPolicy;
        static UPPER_CAMEL_CASE_WITH_SPACES: $FieldNamingPolicy;
        static UPPER_CASE_WITH_UNDERSCORES: $FieldNamingPolicy;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $FieldNamingPolicy[];
        static valueOf(name: string): $FieldNamingPolicy;
    }
    export interface $FieldNamingPolicy extends $Enum<$FieldNamingPolicy> {}

    export class $LongSerializationPolicy {
        static DEFAULT: $LongSerializationPolicy;
        static STRING: $LongSerializationPolicy;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LongSerializationPolicy[];
        static valueOf(name: string): $LongSerializationPolicy;
    }
    export interface $LongSerializationPolicy extends $Enum<$LongSerializationPolicy> {}

    export interface $ReflectionAccessFilter {
        check(arg0: $Class<any>): $ReflectionAccessFilter$FilterResult;
    }
    export const $ReflectionAccessFilter: {
        readonly BLOCK_ALL_ANDROID: $ReflectionAccessFilter;
        readonly BLOCK_ALL_JAVA: $ReflectionAccessFilter;
        readonly BLOCK_ALL_PLATFORM: $ReflectionAccessFilter;
        readonly BLOCK_INACCESSIBLE_JAVA: $ReflectionAccessFilter;
    };

    export interface $ToNumberStrategy {
        readNumber(arg0: $JsonReader): number;
    }

    export class $FieldAttributes {
        constructor(arg0: $Field);
        get annotations(): $Collection<$Annotation>;
        getAnnotations(): $Collection<$Annotation>;
        get declaredClass(): $Class<any>;
        getDeclaredClass(): $Class<any>;
        get declaredType(): $Type;
        getDeclaredType(): $Type;
        get declaringClass(): $Class<any>;
        getDeclaringClass(): $Class<any>;
        get name(): string;
        getName(): string;
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        hasModifier(arg0: number): boolean;
        toString(): string;
    }

    export class $ReflectionAccessFilter$FilterResult {
        static ALLOW: $ReflectionAccessFilter$FilterResult;
        static BLOCK_ALL: $ReflectionAccessFilter$FilterResult;
        static BLOCK_INACCESSIBLE: $ReflectionAccessFilter$FilterResult;
        static INDECISIVE: $ReflectionAccessFilter$FilterResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ReflectionAccessFilter$FilterResult[];
        static valueOf(name: string): $ReflectionAccessFilter$FilterResult;
    }
    export interface $ReflectionAccessFilter$FilterResult extends $Enum<$ReflectionAccessFilter$FilterResult> {}

    export type $JsonObject_ = $JsonObject | { [key: string]: any };
    export type $FieldNamingStrategy_<CallbackArg0 = $Field, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($FieldNamingStrategy & { readonly [Symbol.hasInstance]?: never });
    export type $TypeAdapterFactory_<CallbackArg0 = $Gson, CallbackArg1 = $TypeToken<any>, CallbackResult = $TypeAdapter<any>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($TypeAdapterFactory & { readonly [Symbol.hasInstance]?: never });
    export type $FieldNamingPolicy_ = $FieldNamingPolicy | "IDENTITY" | "LOWER_CASE_WITH_DASHES" | "LOWER_CASE_WITH_DOTS" | "LOWER_CASE_WITH_UNDERSCORES" | "UPPER_CAMEL_CASE" | "UPPER_CAMEL_CASE_WITH_SPACES" | "UPPER_CASE_WITH_UNDERSCORES";
    export type $LongSerializationPolicy_ = $LongSerializationPolicy | "DEFAULT" | "STRING";
    export type $ReflectionAccessFilter_<CallbackArg0 = $Class<any>, CallbackResult = $ReflectionAccessFilter$FilterResult_> = ((arg0: CallbackArg0) => CallbackResult) | ($ReflectionAccessFilter & { readonly [Symbol.hasInstance]?: never });
    export type $ToNumberStrategy_<CallbackArg0 = $JsonReader, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($ToNumberStrategy & { readonly [Symbol.hasInstance]?: never });
    export type $ReflectionAccessFilter$FilterResult_ = $ReflectionAccessFilter$FilterResult | "ALLOW" | "BLOCK_ALL" | "BLOCK_INACCESSIBLE" | "INDECISIVE";
}
