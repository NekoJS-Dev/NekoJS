import { $ProtocolFamily, $ProtocolFamily_ } from "java:java/net";
import { $Channel, $DatagramChannel, $InterruptibleChannel, $Pipe, $SelectableChannel, $SelectionKey, $Selector, $ServerSocketChannel, $SocketChannel } from "java:java/nio/channels";

declare module "java:java/nio/channels/spi" {
    export class $AbstractInterruptibleChannel implements $Channel, $InterruptibleChannel {
        get open(): boolean;
        isOpen(): boolean;
        close(): void;
    }

    export class $SelectorProvider {
        static provider(): $SelectorProvider;
        inheritedChannel(): $Channel;
        openDatagramChannel(arg0: $ProtocolFamily_<string>): $DatagramChannel;
        openDatagramChannel(): $DatagramChannel;
        openPipe(): $Pipe;
        openSelector(): $AbstractSelector;
        openServerSocketChannel(arg0: $ProtocolFamily_<string>): $ServerSocketChannel;
        openServerSocketChannel(): $ServerSocketChannel;
        openSocketChannel(arg0: $ProtocolFamily_<string>): $SocketChannel;
        openSocketChannel(): $SocketChannel;
    }

    export class $AbstractSelector extends $Selector {
        get open(): boolean;
        isOpen(): boolean;
        close(): void;
        provider(): $SelectorProvider;
    }

    export class $AbstractSelectableChannel extends $SelectableChannel {
        get blocking(): boolean;
        isBlocking(): boolean;
        get registered(): boolean;
        isRegistered(): boolean;
        blockingLock(): object;
        configureBlocking(arg0: boolean): $SelectableChannel;
        keyFor(arg0: $Selector): $SelectionKey;
        provider(): $SelectorProvider;
        register(arg0: $Selector, arg1: number, arg2: object): $SelectionKey;
        register(arg0: $Selector, arg1: number): $SelectionKey;
    }

}
