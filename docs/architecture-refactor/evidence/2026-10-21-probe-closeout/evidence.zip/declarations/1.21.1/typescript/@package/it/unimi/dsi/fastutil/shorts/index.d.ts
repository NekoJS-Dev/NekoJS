import { $Function as $NekoImport$Function, $Function_ as $NekoImport$Function_ } from "java:it/unimi/dsi/fastutil";
import { $Byte2ByteFunction, $Byte2ByteFunction_, $Byte2CharFunction, $Byte2CharFunction_, $Byte2DoubleFunction, $Byte2DoubleFunction_, $Byte2FloatFunction, $Byte2FloatFunction_, $Byte2IntFunction, $Byte2IntFunction_, $Byte2LongFunction, $Byte2LongFunction_, $Byte2ObjectFunction, $Byte2ObjectFunction_, $Byte2ReferenceFunction, $Byte2ReferenceFunction_, $Byte2ShortFunction, $Byte2ShortFunction_ } from "java:it/unimi/dsi/fastutil/bytes";
import { $Char2ByteFunction, $Char2ByteFunction_, $Char2CharFunction, $Char2CharFunction_, $Char2DoubleFunction, $Char2DoubleFunction_, $Char2FloatFunction, $Char2FloatFunction_, $Char2IntFunction, $Char2IntFunction_, $Char2LongFunction, $Char2LongFunction_, $Char2ObjectFunction, $Char2ObjectFunction_, $Char2ReferenceFunction, $Char2ReferenceFunction_, $Char2ShortFunction, $Char2ShortFunction_ } from "java:it/unimi/dsi/fastutil/chars";
import { $Double2ByteFunction, $Double2ByteFunction_, $Double2CharFunction, $Double2CharFunction_, $Double2DoubleFunction, $Double2DoubleFunction_, $Double2FloatFunction, $Double2FloatFunction_, $Double2IntFunction, $Double2IntFunction_, $Double2LongFunction, $Double2LongFunction_, $Double2ObjectFunction, $Double2ObjectFunction_, $Double2ReferenceFunction, $Double2ReferenceFunction_, $Double2ShortFunction, $Double2ShortFunction_ } from "java:it/unimi/dsi/fastutil/doubles";
import { $Float2ByteFunction, $Float2ByteFunction_, $Float2CharFunction, $Float2CharFunction_, $Float2DoubleFunction, $Float2DoubleFunction_, $Float2FloatFunction, $Float2FloatFunction_, $Float2IntFunction, $Float2IntFunction_, $Float2LongFunction, $Float2LongFunction_, $Float2ObjectFunction, $Float2ObjectFunction_, $Float2ReferenceFunction, $Float2ReferenceFunction_, $Float2ShortFunction, $Float2ShortFunction_ } from "java:it/unimi/dsi/fastutil/floats";
import { $Int2ByteFunction, $Int2ByteFunction_, $Int2CharFunction, $Int2CharFunction_, $Int2DoubleFunction, $Int2DoubleFunction_, $Int2FloatFunction, $Int2FloatFunction_, $Int2IntFunction, $Int2IntFunction_, $Int2LongFunction, $Int2LongFunction_, $Int2ObjectFunction, $Int2ObjectFunction_, $Int2ReferenceFunction, $Int2ReferenceFunction_, $Int2ShortFunction, $Int2ShortFunction_, $IntIterator, $IntSpliterator } from "java:it/unimi/dsi/fastutil/ints";
import { $Long2ByteFunction, $Long2ByteFunction_, $Long2CharFunction, $Long2CharFunction_, $Long2DoubleFunction, $Long2DoubleFunction_, $Long2FloatFunction, $Long2FloatFunction_, $Long2IntFunction, $Long2IntFunction_, $Long2LongFunction, $Long2LongFunction_, $Long2ObjectFunction, $Long2ObjectFunction_, $Long2ReferenceFunction, $Long2ReferenceFunction_, $Long2ShortFunction, $Long2ShortFunction_ } from "java:it/unimi/dsi/fastutil/longs";
import { $Object2ByteFunction, $Object2ByteFunction_, $Object2CharFunction, $Object2CharFunction_, $Object2DoubleFunction, $Object2DoubleFunction_, $Object2FloatFunction, $Object2FloatFunction_, $Object2IntFunction, $Object2IntFunction_, $Object2LongFunction, $Object2LongFunction_, $Object2ObjectFunction, $Object2ObjectFunction_, $Object2ReferenceFunction, $Object2ReferenceFunction_, $Object2ShortFunction, $Object2ShortFunction_, $ObjectBidirectionalIterator, $Reference2ByteFunction, $Reference2ByteFunction_, $Reference2CharFunction, $Reference2CharFunction_, $Reference2DoubleFunction, $Reference2DoubleFunction_, $Reference2FloatFunction, $Reference2FloatFunction_, $Reference2IntFunction, $Reference2IntFunction_, $Reference2LongFunction, $Reference2LongFunction_, $Reference2ObjectFunction, $Reference2ObjectFunction_, $Reference2ReferenceFunction, $Reference2ReferenceFunction_, $Reference2ShortFunction, $Reference2ShortFunction_ } from "java:it/unimi/dsi/fastutil/objects";
import { $Comparable, $Comparable_, $Iterable } from "java:java/lang";
import { $Collection, $Comparator, $Comparator_, $List, $ListIterator, $PrimitiveIterator, $Spliterator$OfPrimitive } from "java:java/util";
import { $Consumer, $Consumer_, $Function as $NekoImport$Function1, $Function_ as $NekoImport$Function_1, $IntConsumer, $IntConsumer_, $IntFunction, $IntFunction_, $IntPredicate, $IntPredicate_, $IntToDoubleFunction, $IntToDoubleFunction_, $IntToLongFunction, $IntToLongFunction_, $IntUnaryOperator, $IntUnaryOperator_, $Predicate, $Predicate_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $IntStream, $Stream } from "java:java/util/stream";

declare module "java:it/unimi/dsi/fastutil/shorts" {
    export interface $Short2ObjectFunction<out V> extends $NekoImport$Function<number, V>, $IntFunction<V> {
        andThenByte(arg0: $Object2ByteFunction_<V, object, number>): $Short2ByteFunction;
        andThenChar(arg0: $Object2CharFunction_<V, object, string>): $Short2CharFunction;
        andThenDouble(arg0: $Object2DoubleFunction_<V, object, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Object2FloatFunction_<V, object, number>): $Short2FloatFunction;
        andThenInt(arg0: $Object2IntFunction_<V, object, number>): $Short2IntFunction;
        andThenLong(arg0: $Object2LongFunction_<V, object, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, object, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, object, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Object2ShortFunction_<V, object, number>): $Short2ShortFunction;
        apply(arg0: number): V;
        apply(arg0: number): V;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2ObjectFunction<V>;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, V>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        getOrDefault(arg0: number, arg1: V): V;
        get(arg0: object): V;
        get(arg0: number): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: object): V;
        remove(arg0: number): V;
    }

    export interface $Short2ByteFunction extends $NekoImport$Function<number, number>, $IntUnaryOperator {
        andThenByte(arg0: $Byte2ByteFunction_<number, number>): $Short2ByteFunction;
        andThenChar(arg0: $Byte2CharFunction_<number, string>): $Short2CharFunction;
        andThenDouble(arg0: $Byte2DoubleFunction_<number, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Byte2FloatFunction_<number, number>): $Short2FloatFunction;
        andThenInt(arg0: $Byte2IntFunction_<number, number>): $Short2IntFunction;
        andThenLong(arg0: $Byte2LongFunction_<number, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Byte2ObjectFunction_<T, number, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Byte2ReferenceFunction_<T, number, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Byte2ShortFunction_<number, number>): $Short2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2ByteFunction;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2ByteFunction;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2ByteFunction;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2ByteFunction;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2ByteFunction;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2ByteFunction;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2ByteFunction<T>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2ByteFunction<T>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2ByteFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        compose(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Short2CharFunction extends $NekoImport$Function<number, string>, $IntUnaryOperator {
        andThenByte(arg0: $Char2ByteFunction_<string, number>): $Short2ByteFunction;
        andThenChar(arg0: $Char2CharFunction_<string, string>): $Short2CharFunction;
        andThenDouble(arg0: $Char2DoubleFunction_<string, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Char2FloatFunction_<string, number>): $Short2FloatFunction;
        andThenInt(arg0: $Char2IntFunction_<string, number>): $Short2IntFunction;
        andThenLong(arg0: $Char2LongFunction_<string, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Char2ObjectFunction_<T, string, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Char2ReferenceFunction_<T, string, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Char2ShortFunction_<string, number>): $Short2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<string, T, string, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2CharFunction;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2CharFunction;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2CharFunction;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2CharFunction;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2CharFunction;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2CharFunction;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2CharFunction<T>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2CharFunction<T>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2CharFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, string>;
        compose(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: string): void;
        defaultReturnValue(): string;
        getOrDefault(arg0: object, arg1: string): string;
        getOrDefault(arg0: number, arg1: string): string;
        get(arg0: object): string;
        get(arg0: number): string;
        put(arg0: number, arg1: string): string;
        put(arg0: number, arg1: string): string;
        remove(arg0: object): string;
        remove(arg0: number): string;
    }

    export interface $Short2DoubleFunction extends $NekoImport$Function<number, number>, $IntToDoubleFunction {
        andThenByte(arg0: $Double2ByteFunction_<number, number>): $Short2ByteFunction;
        andThenChar(arg0: $Double2CharFunction_<number, string>): $Short2CharFunction;
        andThenDouble(arg0: $Double2DoubleFunction_<number, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Double2FloatFunction_<number, number>): $Short2FloatFunction;
        andThenInt(arg0: $Double2IntFunction_<number, number>): $Short2IntFunction;
        andThenLong(arg0: $Double2LongFunction_<number, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Double2ObjectFunction_<T, number, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Double2ReferenceFunction_<T, number, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Double2ShortFunction_<number, number>): $Short2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsDouble(arg0: number): number;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2DoubleFunction;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2DoubleFunction;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2DoubleFunction;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2DoubleFunction;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2DoubleFunction;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2DoubleFunction;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2DoubleFunction<T>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2DoubleFunction<T>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2DoubleFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Short2FloatFunction extends $NekoImport$Function<number, number>, $IntToDoubleFunction {
        andThenByte(arg0: $Float2ByteFunction_<number, number>): $Short2ByteFunction;
        andThenChar(arg0: $Float2CharFunction_<number, string>): $Short2CharFunction;
        andThenDouble(arg0: $Float2DoubleFunction_<number, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Float2FloatFunction_<number, number>): $Short2FloatFunction;
        andThenInt(arg0: $Float2IntFunction_<number, number>): $Short2IntFunction;
        andThenLong(arg0: $Float2LongFunction_<number, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Float2ObjectFunction_<T, number, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Float2ReferenceFunction_<T, number, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Float2ShortFunction_<number, number>): $Short2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsDouble(arg0: number): number;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2FloatFunction;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2FloatFunction;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2FloatFunction;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2FloatFunction;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2FloatFunction;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2FloatFunction;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2FloatFunction<T>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2FloatFunction<T>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2FloatFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Short2IntFunction extends $NekoImport$Function<number, number>, $IntUnaryOperator {
        andThenByte(arg0: $Int2ByteFunction_<number, number>): $Short2ByteFunction;
        andThenChar(arg0: $Int2CharFunction_<number, string>): $Short2CharFunction;
        andThenDouble(arg0: $Int2DoubleFunction_<number, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Int2FloatFunction_<number, number>): $Short2FloatFunction;
        andThenInt(arg0: $Int2IntFunction_<number, number>): $Short2IntFunction;
        andThenLong(arg0: $Int2LongFunction_<number, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Int2ObjectFunction_<T, number, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Int2ReferenceFunction_<T, number, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Int2ShortFunction_<number, number>): $Short2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2IntFunction;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2IntFunction;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2IntFunction;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2IntFunction;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2IntFunction;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2IntFunction;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2IntFunction<T>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2IntFunction<T>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2IntFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        compose(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Short2LongFunction extends $NekoImport$Function<number, number>, $IntToLongFunction {
        andThenByte(arg0: $Long2ByteFunction_<number, number>): $Short2ByteFunction;
        andThenChar(arg0: $Long2CharFunction_<number, string>): $Short2CharFunction;
        andThenDouble(arg0: $Long2DoubleFunction_<number, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Long2FloatFunction_<number, number>): $Short2FloatFunction;
        andThenInt(arg0: $Long2IntFunction_<number, number>): $Short2IntFunction;
        andThenLong(arg0: $Long2LongFunction_<number, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Long2ObjectFunction_<T, number, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Long2ReferenceFunction_<T, number, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Long2ShortFunction_<number, number>): $Short2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsLong(arg0: number): number;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2LongFunction;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2LongFunction;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2LongFunction;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2LongFunction;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2LongFunction;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2LongFunction;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2LongFunction<T>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2LongFunction<T>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2LongFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }

    export interface $Short2ReferenceFunction<out V> extends $NekoImport$Function<number, V>, $IntFunction<V> {
        andThenByte(arg0: $Reference2ByteFunction_<V, object, number>): $Short2ByteFunction;
        andThenChar(arg0: $Reference2CharFunction_<V, object, string>): $Short2CharFunction;
        andThenDouble(arg0: $Reference2DoubleFunction_<V, object, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Reference2FloatFunction_<V, object, number>): $Short2FloatFunction;
        andThenInt(arg0: $Reference2IntFunction_<V, object, number>): $Short2IntFunction;
        andThenLong(arg0: $Reference2LongFunction_<V, object, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Reference2ObjectFunction_<V, T, object, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Reference2ReferenceFunction_<V, T, object, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Reference2ShortFunction_<V, object, number>): $Short2ShortFunction;
        apply(arg0: number): V;
        apply(arg0: number): V;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2ReferenceFunction<V>;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2ReferenceFunction<V>;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2ReferenceFunction<V>;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2ReferenceFunction<V>;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2ReferenceFunction<V>;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2ReferenceFunction<V>;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2ReferenceFunction<T, V>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2ReferenceFunction<T, V>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2ReferenceFunction<V>;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, V>;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        getOrDefault(arg0: number, arg1: V): V;
        get(arg0: object): V;
        get(arg0: number): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: object): V;
        remove(arg0: number): V;
    }

    export interface $Short2ShortFunction extends $NekoImport$Function<number, number>, $IntUnaryOperator {
        andThenByte(arg0: $Short2ByteFunction_<number, number>): $Short2ByteFunction;
        andThenChar(arg0: $Short2CharFunction_<number, string>): $Short2CharFunction;
        andThenDouble(arg0: $Short2DoubleFunction_<number, number>): $Short2DoubleFunction;
        andThenFloat(arg0: $Short2FloatFunction_<number, number>): $Short2FloatFunction;
        andThenInt(arg0: $Short2IntFunction_<number, number>): $Short2IntFunction;
        andThenLong(arg0: $Short2LongFunction_<number, number>): $Short2LongFunction;
        andThenObject<T>(arg0: $Short2ObjectFunction_<T, number, T>): $Short2ObjectFunction<T>;
        andThenReference<T>(arg0: $Short2ReferenceFunction_<T, number, T>): $Short2ReferenceFunction<T>;
        andThenShort(arg0: $Short2ShortFunction_<number, number>): $Short2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2ShortFunction_<number, number>): $Byte2ShortFunction;
        composeChar(arg0: $Char2ShortFunction_<string, number>): $Char2ShortFunction;
        composeDouble(arg0: $Double2ShortFunction_<number, number>): $Double2ShortFunction;
        composeFloat(arg0: $Float2ShortFunction_<number, number>): $Float2ShortFunction;
        composeInt(arg0: $Int2ShortFunction_<number, number>): $Int2ShortFunction;
        composeLong(arg0: $Long2ShortFunction_<number, number>): $Long2ShortFunction;
        composeObject<T>(arg0: $Object2ShortFunction_<T, object, number>): $Object2ShortFunction<T>;
        composeReference<T>(arg0: $Reference2ShortFunction_<T, object, number>): $Reference2ShortFunction<T>;
        composeShort(arg0: $Short2ShortFunction_<number, number>): $Short2ShortFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        compose(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        containsKey(arg0: object): boolean;
        containsKey(arg0: number): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        get(arg0: object): number;
        get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: object): number;
        remove(arg0: number): number;
    }
    export const $Short2ShortFunction: {
        identity(): $Short2ShortFunction;
    };

    export interface $ShortList extends $List<number>, $Comparable<$List<number>>, $ShortCollection {
        addAll(arg0: number, arg1: $ShortCollection): boolean;
        addAll(arg0: number, arg1: $ShortList): boolean;
        addAll(arg0: number, arg1: number[]): boolean;
        addAll(arg0: $ShortCollection): boolean;
        addAll(arg0: $ShortList): boolean;
        addAll(arg0: number[]): boolean;
        addElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        addElements(arg0: number, arg1: number[]): void;
        add(arg0: number, arg1: number): void;
        add(arg0: number, arg1: number): void;
        add(arg0: number): boolean;
        add(arg0: number): boolean;
        clear(): void;
        containsAll(arg0: $ShortCollection): boolean;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        contains(arg0: number): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $ShortConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $IntConsumer_<number>): void;
        getElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        getShort(arg0: number): number;
        get(arg0: number): number;
        hashCode(): number;
        indexOf(arg0: object): number;
        indexOf(arg0: number): number;
        isEmpty(): boolean;
        iterator(): $ShortListIterator;
        lastIndexOf(arg0: object): number;
        lastIndexOf(arg0: number): number;
        listIterator(arg0: number): $ShortListIterator;
        listIterator(): $ShortListIterator;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $ShortCollection): boolean;
        removeAll(arg0: any[]): boolean;
        removeElements(arg0: number, arg1: number): void;
        removeIf(arg0: $ShortPredicate_<number, boolean>): boolean;
        removeIf(arg0: $IntPredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        removeShort(arg0: number): number;
        remove(arg0: number): number;
        remove(arg0: object): boolean;
        replaceAll(arg0: $ShortUnaryOperator_<number, number>): void;
        replaceAll(arg0: $IntUnaryOperator_<number, number>): void;
        replaceAll(arg0: $UnaryOperator_<number, number, number>): void;
        retainAll(arg0: $ShortCollection): boolean;
        retainAll(arg0: any[]): boolean;
        setElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        setElements(arg0: number, arg1: number[]): void;
        setElements(arg0: number[]): void;
        set(arg0: number, arg1: number): number;
        set(arg0: number, arg1: number): number;
        size(arg0: number): void;
        size(): number;
        sort(arg0: $ShortComparator_<number, number, number>): void;
        sort(arg0: $Comparator_<number, number, number, number>): void;
        spliterator(): $ShortSpliterator;
        stream(): $Stream<number>;
        subList(arg0: number, arg1: number): $ShortList;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(arg0: number[]): number[];
        toArray(): object[];
        unstableSort(arg0: $ShortComparator_<number, number, number>): void;
        unstableSort(arg0: $Comparator_<number, number, number, number>): void;
    }
    export const $ShortList: {
        of(arg0?: number[]): $ShortList;
        of(arg0: number, arg1: number, arg2: number): $ShortList;
        of(arg0: number, arg1: number): $ShortList;
        of(arg0: number): $ShortList;
        of(): $ShortList;
    };

    export interface $ShortCollection extends $Collection<number>, $ShortIterable {
        addAll(arg0: $ShortCollection): boolean;
        addAll(arg0: number[]): boolean;
        add(arg0: number): boolean;
        add(arg0: number): boolean;
        containsAll(arg0: $ShortCollection): boolean;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        contains(arg0: number): boolean;
        forEach(arg0: $ShortConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $IntConsumer_<number>): void;
        intIterator(): $IntIterator;
        intParallelStream(): $IntStream;
        intSpliterator(): $IntSpliterator;
        intStream(): $IntStream;
        iterator(): $ShortIterator;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $ShortCollection): boolean;
        removeAll(arg0: any[]): boolean;
        removeIf(arg0: $ShortPredicate_<number, boolean>): boolean;
        removeIf(arg0: $IntPredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        remove(arg0: object): boolean;
        rem(arg0: number): boolean;
        retainAll(arg0: $ShortCollection): boolean;
        retainAll(arg0: any[]): boolean;
        spliterator(): $ShortSpliterator;
        stream(): $Stream<number>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(arg0: number[]): number[];
        toArray(): object[];
        toShortArray(arg0: number[]): number[];
        toShortArray(): number[];
    }

    export interface $ShortComparator extends $Comparator<number> {
        compare(arg0: number, arg1: number): number;
        compare(arg0: number, arg1: number): number;
        reversed(): $ShortComparator;
        thenComparing(arg0: $ShortComparator_<number, number, number>): $ShortComparator;
        thenComparing(arg0: $Comparator_<number, number, number, number>): $Comparator<number>;
        thenComparing<U>(arg0: $NekoImport$Function_1<number, U, number, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<number>;
        thenComparing<U extends $Comparable<any>>(arg0: $NekoImport$Function_1<number, U, number, U>): $Comparator<number>;
    }

    export interface $ShortConsumer extends $Consumer<number>, $IntConsumer {
        accept(arg0: number): void;
        accept(arg0: number): void;
        accept(arg0: number): void;
        andThen(arg0: $ShortConsumer_<number>): $ShortConsumer;
        andThen(arg0: $Consumer_<number, number>): $Consumer<number>;
        andThen(arg0: $IntConsumer_<number>): $ShortConsumer;
    }

    export interface $ShortListIterator extends $ShortBidirectionalIterator, $ListIterator<number> {
        add(arg0: number): void;
        add(arg0: number): void;
        forEachRemaining(arg0: $ShortConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        hasNext(): boolean;
        hasPrevious(): boolean;
        next(): number;
        previous(): number;
        remove(): void;
        set(arg0: number): void;
        set(arg0: number): void;
    }

    export interface $ShortPredicate extends $Predicate<number>, $IntPredicate {
        and(arg0: $ShortPredicate_<number, boolean>): $ShortPredicate;
        and(arg0: $IntPredicate_<number, boolean>): $ShortPredicate;
        and(arg0: $Predicate_<number, number, boolean>): $Predicate<number>;
        negate(): $ShortPredicate;
        or(arg0: $ShortPredicate_<number, boolean>): $ShortPredicate;
        or(arg0: $IntPredicate_<number, boolean>): $ShortPredicate;
        or(arg0: $Predicate_<number, number, boolean>): $Predicate<number>;
        test(arg0: number): boolean;
        test(arg0: number): boolean;
        test(arg0: number): boolean;
    }

    export interface $ShortSpliterator extends $Spliterator$OfPrimitive<number, $ShortConsumer, $ShortSpliterator> {
        forEachRemaining(arg0: $ShortConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        getComparator(): $ShortComparator;
        skip(arg0: number): number;
        tryAdvance(arg0: $ShortConsumer_<number>): boolean;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        trySplit(): $ShortSpliterator;
    }

    export interface $ShortUnaryOperator extends $UnaryOperator<number>, $IntUnaryOperator {
        andThen<V>(arg0: $NekoImport$Function_1<number, V, number, V>): $NekoImport$Function1<number, V>;
        andThen(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
        applyAsInt(arg0: number): number;
        apply(arg0: number): number;
        apply(arg0: number): number;
        compose<V>(arg0: $NekoImport$Function_1<V, number, V, number>): $NekoImport$Function1<V, number>;
        compose(arg0: $IntUnaryOperator_<number, number>): $IntUnaryOperator;
    }
    export const $ShortUnaryOperator: {
        identity(): $ShortUnaryOperator;
        negation(): $ShortUnaryOperator;
    };

    export interface $ShortIterable extends $Iterable<number> {
        forEach(arg0: $ShortConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $IntConsumer_<number>): void;
        intIterator(): $IntIterator;
        intSpliterator(): $IntSpliterator;
        iterator(): $ShortIterator;
        spliterator(): $ShortSpliterator;
    }

    export interface $ShortIterator extends $PrimitiveIterator<number, $ShortConsumer> {
        forEachRemaining(arg0: $ShortConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        nextShort(): number;
        next(): number;
        skip(arg0: number): number;
    }

    export interface $ShortBidirectionalIterator extends $ShortIterator, $ObjectBidirectionalIterator<number> {
        back(arg0: number): number;
        forEachRemaining(arg0: $ShortConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        hasNext(): boolean;
        next(): number;
        previousShort(): number;
        previous(): number;
        remove(): void;
        skip(arg0: number): number;
    }

    export type $Short2ObjectFunction_<Host0 = any, CallbackArg0 = number, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2ObjectFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Short2ByteFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2ByteFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Short2CharFunction_<CallbackArg0 = number, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2CharFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Short2DoubleFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2DoubleFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Short2FloatFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2FloatFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Short2IntFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2IntFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Short2LongFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2LongFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Short2ReferenceFunction_<Host0 = any, CallbackArg0 = number, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2ReferenceFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Short2ShortFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Short2ShortFunction & { readonly [Symbol.hasInstance]?: never });
    export type $ShortComparator_<CallbackArg0 = number, CallbackArg1 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($ShortComparator & { readonly [Symbol.hasInstance]?: never });
    export type $ShortConsumer_<CallbackArg0 = number> = ((arg0: CallbackArg0) => void) | ($ShortConsumer & { readonly [Symbol.hasInstance]?: never });
    export type $ShortPredicate_<CallbackArg0 = number, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($ShortPredicate & { readonly [Symbol.hasInstance]?: never });
    export type $ShortUnaryOperator_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($ShortUnaryOperator & { readonly [Symbol.hasInstance]?: never });
    export type $ShortIterable_<CallbackResult = $ShortIterator> = (() => CallbackResult) | ($ShortIterable & { readonly [Symbol.hasInstance]?: never });
}
