import { $InputStream, $OutputStream, $PrintStream, $PrintWriter, $Reader, $Serializable, $Writer } from "java:java/io";
import { $Class, $ClassLoader, $Cloneable, $Comparable, $Comparable_, $Enum, $Iterable, $Module, $Runnable, $Runnable_, $Throwable } from "java:java/lang";
import { $ByteBuffer, $LongBuffer } from "java:java/nio";
import { $Charset } from "java:java/nio/charset";
import { $Instant, $ZoneId } from "java:java/time";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $Consumer, $Consumer_, $DoubleConsumer, $DoubleConsumer_, $DoubleSupplier, $DoubleSupplier_, $Function, $Function_, $IntConsumer, $IntConsumer_, $IntFunction, $IntFunction_, $IntSupplier, $IntSupplier_, $LongConsumer, $LongConsumer_, $LongSupplier, $LongSupplier_, $Predicate, $Predicate_, $Supplier, $Supplier_, $ToDoubleFunction, $ToDoubleFunction_, $ToIntFunction, $ToIntFunction_, $ToLongFunction, $ToLongFunction_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $RandomGenerator, $RandomGenerator_ } from "java:java/util/random";
import { $DoubleStream, $IntStream, $LongStream, $Stream } from "java:java/util/stream";

export * as concurrent from "java:java/util/concurrent";
export * as function from "java:java/util/function";
export * as stream from "java:java/util/stream";
export * as zip from "java:java/util/zip";
export * as logging from "java:java/util/logging";
export * as random from "java:java/util/random";

declare module "java:java/util" {
    export class $AbstractCollection<E> implements $Collection<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(arg0: E[]): boolean;
        add(arg0: E): boolean;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(arg0: any[]): boolean;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        remove(arg0: object): boolean;
        retainAll(arg0: any[]): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
        toString(): string;
    }

    export class $AbstractList<E> extends $AbstractCollection<E> implements $List<E> {
        get first(): E;
        getFirst(): E;
        get last(): E;
        getLast(): E;
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(arg0: number, arg1: E[]): boolean;
        addAll(arg0: E[]): boolean;
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        add(arg0: E): boolean;
        add(arg0: number, arg1: E): void;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        get(arg0: number): E;
        hashCode(): number;
        indexOf(arg0: object): number;
        iterator(): $Iterator<E>;
        lastIndexOf(arg0: object): number;
        listIterator(arg0: number): $ListIterator<E>;
        listIterator(): $ListIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(arg0: any[]): boolean;
        removeFirst(): E;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        removeLast(): E;
        remove(arg0: number): E;
        remove(arg0: object): boolean;
        replaceAll(arg0: $UnaryOperator_<E, E, E>): void;
        retainAll(arg0: any[]): boolean;
        reversed(): $List<E>;
        set(arg0: number, arg1: E): E;
        size(): number;
        sort(arg0: $Comparator_<E, E, E, number>): void;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        subList(arg0: number, arg1: number): $List<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export class $AbstractMap<K, V> implements $Map<K, V> {
        get empty(): boolean;
        isEmpty(): boolean;
        clear(): void;
        computeIfAbsent(arg0: K, arg1: $Function_<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: object): boolean;
        containsValue(arg0: object): boolean;
        entrySet(): $Set<$Map$Entry<K, V>>;
        equals(arg0: object): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        hashCode(): number;
        keySet(): $Set<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): void;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        replaceAll(arg0: $BiFunction_<K, V, V, K, V, V>): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        toString(): string;
        values(): $Collection<V>;
    }

    export class $AbstractSet<E> extends $AbstractCollection<E> implements $Set<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(arg0: E[]): boolean;
        add(arg0: E): boolean;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(arg0: any[]): boolean;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        remove(arg0: object): boolean;
        retainAll(arg0: any[]): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export class $ArrayList<E> extends $AbstractList<E> implements $List<E>, $RandomAccess, $Cloneable, $Serializable {
        constructor();
        constructor(arg0: number);
        constructor(arg0: E[]);
        get first(): E;
        getFirst(): E;
        get last(): E;
        getLast(): E;
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(arg0: number, arg1: E[]): boolean;
        addAll(arg0: E[]): boolean;
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        add(arg0: E): boolean;
        add(arg0: number, arg1: E): void;
        clear(): void;
        clone(): object;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        ensureCapacity(arg0: number): void;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        get(arg0: number): E;
        hashCode(): number;
        indexOf(arg0: object): number;
        iterator(): $Iterator<E>;
        lastIndexOf(arg0: object): number;
        listIterator(arg0: number): $ListIterator<E>;
        listIterator(): $ListIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(arg0: any[]): boolean;
        removeFirst(): E;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        removeLast(): E;
        remove(arg0: number): E;
        remove(arg0: object): boolean;
        replaceAll(arg0: $UnaryOperator_<E, E, E>): void;
        retainAll(arg0: any[]): boolean;
        reversed(): $List<E>;
        set(arg0: number, arg1: E): E;
        size(): number;
        sort(arg0: $Comparator_<E, E, E, number>): void;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        subList(arg0: number, arg1: number): $List<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
        trimToSize(): void;
    }

    export class $BitSet implements $Cloneable, $Serializable {
        constructor();
        constructor(arg0: number);
        get empty(): boolean;
        isEmpty(): boolean;
        static valueOf(arg0: number[]): $BitSet;
        static valueOf(arg0: $ByteBuffer): $BitSet;
        static valueOf(arg0: $LongBuffer): $BitSet;
        static valueOf(arg0: number[]): $BitSet;
        andNot(arg0: $BitSet): void;
        and(arg0: $BitSet): void;
        cardinality(): number;
        clear(arg0: number, arg1: number): void;
        clear(arg0: number): void;
        clear(): void;
        clone(): object;
        equals(arg0: object): boolean;
        flip(arg0: number, arg1: number): void;
        flip(arg0: number): void;
        get(arg0: number, arg1: number): $BitSet;
        get(arg0: number): boolean;
        hashCode(): number;
        intersects(arg0: $BitSet): boolean;
        length(): number;
        nextClearBit(arg0: number): number;
        nextSetBit(arg0: number): number;
        or(arg0: $BitSet): void;
        previousClearBit(arg0: number): number;
        previousSetBit(arg0: number): number;
        set(arg0: number, arg1: boolean): void;
        set(arg0: number, arg1: number, arg2: boolean): void;
        set(arg0: number, arg1: number): void;
        set(arg0: number): void;
        size(): number;
        stream(): $IntStream;
        toByteArray(): number[];
        toLongArray(): number[];
        toString(): string;
        xor(arg0: $BitSet): void;
    }

    export interface $Collection<E> extends $Iterable<E> {
        addAll(arg0: E[]): boolean;
        add(arg0: E): boolean;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(arg0: any[]): boolean;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        remove(arg0: object): boolean;
        retainAll(arg0: any[]): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export interface $Comparator<T> {
        compare(arg0: T, arg1: T): number;
        equals(arg0: object): boolean;
        reversed(): $Comparator<T>;
        thenComparingDouble(arg0: $ToDoubleFunction_<T, T, number>): $Comparator<T>;
        thenComparingInt(arg0: $ToIntFunction_<T, T, number>): $Comparator<T>;
        thenComparingLong(arg0: $ToLongFunction_<T, T, number>): $Comparator<T>;
        thenComparing(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        thenComparing<U>(arg0: $Function_<T, U, T, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<T>;
        thenComparing<U extends $Comparable<any>>(arg0: $Function_<T, U, T, U>): $Comparator<T>;
    }
    export const $Comparator: {
        comparingDouble<T>(arg0: $ToDoubleFunction_<T, T, number>): $Comparator<T>;
        comparingInt<T>(arg0: $ToIntFunction_<T, T, number>): $Comparator<T>;
        comparingLong<T>(arg0: $ToLongFunction_<T, T, number>): $Comparator<T>;
        comparing<T, U>(arg0: $Function_<T, U, T, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<T>;
        comparing<T, U extends $Comparable<any>>(arg0: $Function_<T, U, T, U>): $Comparator<T>;
        naturalOrder<T extends $Comparable<any>>(): $Comparator<T>;
        nullsFirst<T>(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        nullsLast<T>(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        reverseOrder<T extends $Comparable<any>>(): $Comparator<T>;
    };

    export class $Currency implements $Serializable {
        get currencyCode(): string;
        getCurrencyCode(): string;
        get defaultFractionDigits(): number;
        getDefaultFractionDigits(): number;
        get displayName(): string;
        getDisplayName(): string;
        get numericCodeAsString(): string;
        getNumericCodeAsString(): string;
        get numericCode(): number;
        getNumericCode(): number;
        get symbol(): string;
        getSymbol(): string;
        static getAvailableCurrencies(): $Set<$Currency>;
        static getInstance(arg0: string): $Currency;
        static getInstance(arg0: $Locale): $Currency;
        getDisplayName(arg0: $Locale): string;
        getSymbol(arg0: $Locale): string;
        toString(): string;
    }

    export class $Date implements $Serializable, $Cloneable, $Comparable<$Date> {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number);
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number);
        constructor(arg0: string);
        constructor(arg0: number);
        get date(): number;
        getDate(): number;
        set date(value: number);
        get day(): number;
        getDay(): number;
        get hours(): number;
        getHours(): number;
        set hours(value: number);
        get minutes(): number;
        getMinutes(): number;
        set minutes(value: number);
        get month(): number;
        getMonth(): number;
        set month(value: number);
        get seconds(): number;
        getSeconds(): number;
        set seconds(value: number);
        get timezoneOffset(): number;
        getTimezoneOffset(): number;
        get time(): number;
        getTime(): number;
        set time(value: number);
        get year(): number;
        getYear(): number;
        set year(value: number);
        static UTC(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): number;
        static from(arg0: $Instant): $Date;
        static parse(arg0: string): number;
        after(arg0: $Date): boolean;
        before(arg0: $Date): boolean;
        clone(): object;
        compareTo(arg0: $Date): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        setDate(arg0: number): void;
        setHours(arg0: number): void;
        setMinutes(arg0: number): void;
        setMonth(arg0: number): void;
        setSeconds(arg0: number): void;
        setTime(arg0: number): void;
        setYear(arg0: number): void;
        toGMTString(): string;
        toInstant(): $Instant;
        toLocaleString(): string;
        toString(): string;
    }

    export class $DoubleSummaryStatistics implements $DoubleConsumer {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        get average(): number;
        getAverage(): number;
        get count(): number;
        getCount(): number;
        get max(): number;
        getMax(): number;
        get min(): number;
        getMin(): number;
        get sum(): number;
        getSum(): number;
        accept(arg0: number): void;
        andThen(arg0: $DoubleConsumer_<number>): $DoubleConsumer;
        combine(arg0: $DoubleSummaryStatistics): void;
        toString(): string;
    }

    export class $EnumSet<E extends $Enum<E>> extends $AbstractSet<E> implements $Cloneable, $Serializable {
        static allOf<E extends $Enum<E>>(arg0: $Class<E>): $EnumSet<E>;
        static complementOf<E extends $Enum<E>>(arg0: $EnumSet<E>): $EnumSet<E>;
        static copyOf<E extends $Enum<E>>(arg0: E[]): $EnumSet<E>;
        static copyOf<E extends $Enum<E>>(arg0: $EnumSet<E>): $EnumSet<E>;
        static noneOf<E extends $Enum<E>>(arg0: $Class<E>): $EnumSet<E>;
        static of<E extends $Enum<E>>(arg0: E, arg1?: E[]): $EnumSet<E>;
        static of<E extends $Enum<E>>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): $EnumSet<E>;
        static of<E extends $Enum<E>>(arg0: E, arg1: E, arg2: E, arg3: E): $EnumSet<E>;
        static of<E extends $Enum<E>>(arg0: E, arg1: E, arg2: E): $EnumSet<E>;
        static of<E extends $Enum<E>>(arg0: E, arg1: E): $EnumSet<E>;
        static of<E extends $Enum<E>>(arg0: E): $EnumSet<E>;
        static range<E extends $Enum<E>>(arg0: E, arg1: E): $EnumSet<E>;
        clone(): $EnumSet<E>;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        parallelStream(): $Stream<E>;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export interface $Enumeration<E> {
        asIterator(): $Iterator<E>;
        hasMoreElements(): boolean;
        nextElement(): E;
    }

    export class $HashMap<K, V> extends $AbstractMap<K, V> implements $Map<K, V>, $Cloneable, $Serializable {
        constructor();
        constructor(arg0: number);
        constructor(arg0: number, arg1: number);
        constructor(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)));
        get empty(): boolean;
        isEmpty(): boolean;
        static newHashMap<K, V>(arg0: number): $HashMap<K, V>;
        clear(): void;
        clone(): object;
        computeIfAbsent(arg0: K, arg1: $Function_<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: object): boolean;
        containsValue(arg0: object): boolean;
        entrySet(): $Set<$Map$Entry<K, V>>;
        equals(arg0: object): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        hashCode(): number;
        keySet(): $Set<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): void;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        replaceAll(arg0: $BiFunction_<K, V, V, K, V, V>): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        values(): $Collection<V>;
    }

    export class $IntSummaryStatistics implements $IntConsumer {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        get average(): number;
        getAverage(): number;
        get count(): number;
        getCount(): number;
        get max(): number;
        getMax(): number;
        get min(): number;
        getMin(): number;
        get sum(): number;
        getSum(): number;
        accept(arg0: number): void;
        andThen(arg0: $IntConsumer_<number>): $IntConsumer;
        combine(arg0: $IntSummaryStatistics): void;
        toString(): string;
    }

    export interface $Iterator<E> {
        forEachRemaining(arg0: $Consumer_<E, E>): void;
        hasNext(): boolean;
        next(): E;
        remove(): void;
    }

    export interface $List<E> extends $SequencedCollection<E> {
        addAll(arg0: number, arg1: E[]): boolean;
        addAll(arg0: E[]): boolean;
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        add(arg0: E): boolean;
        add(arg0: number, arg1: E): void;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        getFirst(): E;
        getLast(): E;
        get(arg0: number): E;
        hashCode(): number;
        indexOf(arg0: object): number;
        isEmpty(): boolean;
        iterator(): $Iterator<E>;
        lastIndexOf(arg0: object): number;
        listIterator(arg0: number): $ListIterator<E>;
        listIterator(): $ListIterator<E>;
        removeAll(arg0: any[]): boolean;
        removeFirst(): E;
        removeLast(): E;
        remove(arg0: number): E;
        remove(arg0: object): boolean;
        replaceAll(arg0: $UnaryOperator_<E, E, E>): void;
        retainAll(arg0: any[]): boolean;
        reversed(): $List<E>;
        set(arg0: number, arg1: E): E;
        size(): number;
        sort(arg0: $Comparator_<E, E, E, number>): void;
        spliterator(): $Spliterator<E>;
        subList(arg0: number, arg1: number): $List<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }
    export const $List: {
        copyOf<E>(arg0: E[]): $List<E>;
        of<E>(arg0?: E[]): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E, arg9: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E): $List<E>;
        of<E>(arg0: E, arg1: E): $List<E>;
        of<E>(arg0: E): $List<E>;
        of<E>(): $List<E>;
    };

    export interface $ListIterator<E> extends $Iterator<E> {
        add(arg0: E): void;
        hasNext(): boolean;
        hasPrevious(): boolean;
        nextIndex(): number;
        next(): E;
        previousIndex(): number;
        previous(): E;
        remove(): void;
        set(arg0: E): void;
    }

    export class $Locale implements $Cloneable, $Serializable {
        constructor(arg0: string);
        constructor(arg0: string, arg1: string);
        constructor(arg0: string, arg1: string, arg2: string);
        static CANADA: $Locale;
        static CANADA_FRENCH: $Locale;
        static CHINA: $Locale;
        static CHINESE: $Locale;
        static ENGLISH: $Locale;
        static FRANCE: $Locale;
        static FRENCH: $Locale;
        static GERMAN: $Locale;
        static GERMANY: $Locale;
        static ITALIAN: $Locale;
        static ITALY: $Locale;
        static JAPAN: $Locale;
        static JAPANESE: $Locale;
        static KOREA: $Locale;
        static KOREAN: $Locale;
        static PRC: $Locale;
        static PRIVATE_USE_EXTENSION: string;
        static ROOT: $Locale;
        static SIMPLIFIED_CHINESE: $Locale;
        static TAIWAN: $Locale;
        static TRADITIONAL_CHINESE: $Locale;
        static UK: $Locale;
        static UNICODE_LOCALE_EXTENSION: string;
        static US: $Locale;
        get country(): string;
        getCountry(): string;
        get displayCountry(): string;
        getDisplayCountry(): string;
        get displayLanguage(): string;
        getDisplayLanguage(): string;
        get displayName(): string;
        getDisplayName(): string;
        get displayScript(): string;
        getDisplayScript(): string;
        get displayVariant(): string;
        getDisplayVariant(): string;
        get extensionKeys(): $Set<string>;
        getExtensionKeys(): $Set<string>;
        get iSO3Country(): string;
        getISO3Country(): string;
        get iSO3Language(): string;
        getISO3Language(): string;
        get language(): string;
        getLanguage(): string;
        get script(): string;
        getScript(): string;
        get unicodeLocaleAttributes(): $Set<string>;
        getUnicodeLocaleAttributes(): $Set<string>;
        get unicodeLocaleKeys(): $Set<string>;
        getUnicodeLocaleKeys(): $Set<string>;
        get variant(): string;
        getVariant(): string;
        static availableLocales(): $Stream<$Locale>;
        static caseFoldLanguageTag(arg0: string): string;
        static filterTags(arg0: $Locale$LanguageRange[], arg1: string[], arg2: $Locale$FilteringMode_): $List<string>;
        static filterTags(arg0: $Locale$LanguageRange[], arg1: string[]): $List<string>;
        static filter(arg0: $Locale$LanguageRange[], arg1: $Locale[], arg2: $Locale$FilteringMode_): $List<$Locale>;
        static filter(arg0: $Locale$LanguageRange[], arg1: $Locale[]): $List<$Locale>;
        static forLanguageTag(arg0: string): $Locale;
        static getAvailableLocales(): $Locale[];
        static getDefault(arg0: $Locale$Category_): $Locale;
        static getDefault(): $Locale;
        static getISOCountries(arg0: $Locale$IsoCountryCode_): $Set<string>;
        static getISOCountries(): string[];
        static getISOLanguages(): string[];
        static lookupTag(arg0: $Locale$LanguageRange[], arg1: string[]): string;
        static lookup(arg0: $Locale$LanguageRange[], arg1: $Locale[]): $Locale;
        static of(arg0: string, arg1: string, arg2: string): $Locale;
        static of(arg0: string, arg1: string): $Locale;
        static of(arg0: string): $Locale;
        static setDefault(arg0: $Locale$Category_, arg1: $Locale): void;
        static setDefault(arg0: $Locale): void;
        clone(): object;
        equals(arg0: object): boolean;
        getDisplayCountry(arg0: $Locale): string;
        getDisplayLanguage(arg0: $Locale): string;
        getDisplayName(arg0: $Locale): string;
        getDisplayScript(arg0: $Locale): string;
        getDisplayVariant(arg0: $Locale): string;
        getExtension(arg0: string): string;
        getUnicodeLocaleType(arg0: string): string;
        hasExtensions(): boolean;
        hashCode(): number;
        stripExtensions(): $Locale;
        toLanguageTag(): string;
        toString(): string;
    }

    export class $Locale$Category {
        static DISPLAY: $Locale$Category;
        static FORMAT: $Locale$Category;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Locale$Category[];
        static valueOf(name: string): $Locale$Category;
    }
    export interface $Locale$Category extends $Enum<$Locale$Category> {}

    export class $Locale$FilteringMode {
        static AUTOSELECT_FILTERING: $Locale$FilteringMode;
        static EXTENDED_FILTERING: $Locale$FilteringMode;
        static IGNORE_EXTENDED_RANGES: $Locale$FilteringMode;
        static MAP_EXTENDED_RANGES: $Locale$FilteringMode;
        static REJECT_EXTENDED_RANGES: $Locale$FilteringMode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Locale$FilteringMode[];
        static valueOf(name: string): $Locale$FilteringMode;
    }
    export interface $Locale$FilteringMode extends $Enum<$Locale$FilteringMode> {}

    export class $Locale$IsoCountryCode {
        static PART1_ALPHA2: $Locale$IsoCountryCode;
        static PART1_ALPHA3: $Locale$IsoCountryCode;
        static PART3: $Locale$IsoCountryCode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Locale$IsoCountryCode[];
        static valueOf(name: string): $Locale$IsoCountryCode;
    }
    export interface $Locale$IsoCountryCode extends $Enum<$Locale$IsoCountryCode> {}

    export class $Locale$LanguageRange {
        constructor(arg0: string);
        constructor(arg0: string, arg1: number);
        static MAX_WEIGHT: number;
        static MIN_WEIGHT: number;
        get range(): string;
        getRange(): string;
        get weight(): number;
        getWeight(): number;
        static mapEquivalents(arg0: $Locale$LanguageRange[], arg1: ($Map<string, string[]> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, string[]>> : never))): $List<$Locale$LanguageRange>;
        static parse(arg0: string, arg1: ($Map<string, string[]> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, string[]>> : never))): $List<$Locale$LanguageRange>;
        static parse(arg0: string): $List<$Locale$LanguageRange>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $LongSummaryStatistics implements $LongConsumer, $IntConsumer {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        get average(): number;
        getAverage(): number;
        get count(): number;
        getCount(): number;
        get max(): number;
        getMax(): number;
        get min(): number;
        getMin(): number;
        get sum(): number;
        getSum(): number;
        accept(arg0: number): void;
        accept(arg0: number): void;
        andThen(arg0: $IntConsumer_<number>): $IntConsumer;
        andThen(arg0: $LongConsumer_<number>): $LongConsumer;
        combine(arg0: $LongSummaryStatistics): void;
        toString(): string;
    }

    export interface $Map<K, V> {
        clear(): void;
        computeIfAbsent(arg0: K, arg1: $Function_<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: object): boolean;
        containsValue(arg0: object): boolean;
        entrySet(): $Set<$Map$Entry<K, V>>;
        equals(arg0: object): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        hashCode(): number;
        isEmpty(): boolean;
        keySet(): $Set<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): void;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        replaceAll(arg0: $BiFunction_<K, V, V, K, V, V>): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        values(): $Collection<V>;
    }
    export const $Map: {
        copyOf<K, V>(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): $Map<K, V>;
        entry<K, V>(arg0: K, arg1: V): $Map$Entry<K, V>;
        ofEntries<K, V>(arg0?: $Map$Entry<K, V>[]): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V): $Map<K, V>;
        of<K, V>(): $Map<K, V>;
    };

    export interface $Map$Entry<K, V> {
        equals(arg0: object): boolean;
        getKey(): K;
        getValue(): V;
        hashCode(): number;
        setValue(arg0: V): V;
    }
    export const $Map$Entry: {
        comparingByKey<K, V>(arg0: $Comparator_<K, K, K, number>): $Comparator<$Map$Entry<K, V>>;
        comparingByKey<K extends $Comparable<any>, V>(): $Comparator<$Map$Entry<K, V>>;
        comparingByValue<K, V>(arg0: $Comparator_<V, V, V, number>): $Comparator<$Map$Entry<K, V>>;
        comparingByValue<K, V extends $Comparable<any>>(): $Comparator<$Map$Entry<K, V>>;
        copyOf<K, V>(arg0: $Map$Entry<K, V>): $Map$Entry<K, V>;
    };

    export class $Optional<T> {
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        static empty<T>(): $Optional<T>;
        static ofNullable<T>(arg0: T): $Optional<T>;
        static of<T>(arg0: T): $Optional<T>;
        equals(arg0: object): boolean;
        filter(arg0: $Predicate_<T, T, boolean>): $Optional<T>;
        flatMap<U>(arg0: $Function_<T, $Optional<U>, T, $Optional<U>>): $Optional<U>;
        get(): T;
        hashCode(): number;
        ifPresentOrElse(arg0: $Consumer_<T, T>, arg1: $Runnable_): void;
        ifPresent(arg0: $Consumer_<T, T>): void;
        map<U>(arg0: $Function_<T, U, T, U>): $Optional<U>;
        orElseGet(arg0: $Supplier_<T, T>): T;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): T;
        orElseThrow(): T;
        orElse(arg0: T): T;
        or(arg0: $Supplier_<$Optional<T>, $Optional<T>>): $Optional<T>;
        stream(): $Stream<T>;
        toString(): string;
    }

    export class $OptionalDouble {
        get asDouble(): number;
        getAsDouble(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        static empty(): $OptionalDouble;
        static of(arg0: number): $OptionalDouble;
        equals(arg0: object): boolean;
        hashCode(): number;
        ifPresentOrElse(arg0: $DoubleConsumer_<number>, arg1: $Runnable_): void;
        ifPresent(arg0: $DoubleConsumer_<number>): void;
        orElseGet(arg0: $DoubleSupplier_<number>): number;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): number;
        orElseThrow(): number;
        orElse(arg0: number): number;
        stream(): $DoubleStream;
        toString(): string;
    }

    export class $OptionalInt {
        get asInt(): number;
        getAsInt(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        static empty(): $OptionalInt;
        static of(arg0: number): $OptionalInt;
        equals(arg0: object): boolean;
        hashCode(): number;
        ifPresentOrElse(arg0: $IntConsumer_<number>, arg1: $Runnable_): void;
        ifPresent(arg0: $IntConsumer_<number>): void;
        orElseGet(arg0: $IntSupplier_<number>): number;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): number;
        orElseThrow(): number;
        orElse(arg0: number): number;
        stream(): $IntStream;
        toString(): string;
    }

    export class $OptionalLong {
        get asLong(): number;
        getAsLong(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        static empty(): $OptionalLong;
        static of(arg0: number): $OptionalLong;
        equals(arg0: object): boolean;
        hashCode(): number;
        ifPresentOrElse(arg0: $LongConsumer_<number>, arg1: $Runnable_): void;
        ifPresent(arg0: $LongConsumer_<number>): void;
        orElseGet(arg0: $LongSupplier_<number>): number;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): number;
        orElseThrow(): number;
        orElse(arg0: number): number;
        stream(): $LongStream;
        toString(): string;
    }

    export interface $PrimitiveIterator<T, T_CONS> extends $Iterator<T> {
        forEachRemaining(arg0: T_CONS): void;
        forEachRemaining(arg0: $Consumer_<T, T>): void;
    }

    export interface $PrimitiveIterator$OfDouble extends $PrimitiveIterator<number, $DoubleConsumer> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $DoubleConsumer_<number>): void;
        nextDouble(): number;
        next(): number;
    }

    export interface $PrimitiveIterator$OfInt extends $PrimitiveIterator<number, $IntConsumer> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        nextInt(): number;
        next(): number;
    }

    export interface $PrimitiveIterator$OfLong extends $PrimitiveIterator<number, $LongConsumer> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $LongConsumer_<number>): void;
        nextLong(): number;
        next(): number;
    }

    export interface $RandomAccess {
    }

    export interface $SequencedCollection<E> extends $Collection<E> {
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        getFirst(): E;
        getLast(): E;
        removeFirst(): E;
        removeLast(): E;
        reversed(): $SequencedCollection<E>;
    }

    export interface $SequencedMap<K, V> extends $Map<K, V> {
        firstEntry(): $Map$Entry<K, V>;
        lastEntry(): $Map$Entry<K, V>;
        pollFirstEntry(): $Map$Entry<K, V>;
        pollLastEntry(): $Map$Entry<K, V>;
        putFirst(arg0: K, arg1: V): V;
        putLast(arg0: K, arg1: V): V;
        reversed(): $SequencedMap<K, V>;
        sequencedEntrySet(): $SequencedSet<$Map$Entry<K, V>>;
        sequencedKeySet(): $SequencedSet<K>;
        sequencedValues(): $SequencedCollection<V>;
    }

    export interface $SequencedSet<E> extends $SequencedCollection<E>, $Set<E> {
        addAll(arg0: E[]): boolean;
        add(arg0: E): boolean;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(arg0: any[]): boolean;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        remove(arg0: object): boolean;
        retainAll(arg0: any[]): boolean;
        reversed(): $SequencedSet<E>;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export interface $Set<E> extends $Collection<E> {
        addAll(arg0: E[]): boolean;
        add(arg0: E): boolean;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $Iterator<E>;
        removeAll(arg0: any[]): boolean;
        remove(arg0: object): boolean;
        retainAll(arg0: any[]): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }
    export const $Set: {
        copyOf<E>(arg0: E[]): $Set<E>;
        of<E>(arg0?: E[]): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E, arg9: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E): $Set<E>;
        of<E>(arg0: E, arg1: E): $Set<E>;
        of<E>(arg0: E): $Set<E>;
        of<E>(): $Set<E>;
    };

    export interface $SortedMap<K, V> extends $SequencedMap<K, V> {
        comparator(): $Comparator<any>;
        entrySet(): $Set<$Map$Entry<K, V>>;
        firstKey(): K;
        headMap(arg0: K): $SortedMap<K, V>;
        keySet(): $Set<K>;
        lastKey(): K;
        putFirst(arg0: K, arg1: V): V;
        putLast(arg0: K, arg1: V): V;
        reversed(): $SortedMap<K, V>;
        subMap(arg0: K, arg1: K): $SortedMap<K, V>;
        tailMap(arg0: K): $SortedMap<K, V>;
        values(): $Collection<V>;
    }

    export interface $Spliterator<T> {
        characteristics(): number;
        estimateSize(): number;
        forEachRemaining(arg0: $Consumer_<T, T>): void;
        getComparator(): $Comparator<any>;
        getExactSizeIfKnown(): number;
        hasCharacteristics(arg0: number): boolean;
        tryAdvance(arg0: $Consumer_<T, T>): boolean;
        trySplit(): $Spliterator<T>;
    }
    export const $Spliterator: {
        readonly CONCURRENT: number;
        readonly DISTINCT: number;
        readonly IMMUTABLE: number;
        readonly NONNULL: number;
        readonly ORDERED: number;
        readonly SIZED: number;
        readonly SORTED: number;
        readonly SUBSIZED: number;
    };

    export interface $Spliterator$OfDouble extends $Spliterator$OfPrimitive<number, $DoubleConsumer, $Spliterator$OfDouble> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $DoubleConsumer_<number>): void;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $DoubleConsumer_<number>): boolean;
        trySplit(): $Spliterator$OfDouble;
    }

    export interface $Spliterator$OfInt extends $Spliterator$OfPrimitive<number, $IntConsumer, $Spliterator$OfInt> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $IntConsumer_<number>): boolean;
        trySplit(): $Spliterator$OfInt;
    }

    export interface $Spliterator$OfLong extends $Spliterator$OfPrimitive<number, $LongConsumer, $Spliterator$OfLong> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $LongConsumer_<number>): void;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $LongConsumer_<number>): boolean;
        trySplit(): $Spliterator$OfLong;
    }

    export interface $Spliterator$OfPrimitive<T, T_CONS, T_SPLITR extends $Spliterator$OfPrimitive<T, T_CONS, T_SPLITR>> extends $Spliterator<T> {
        forEachRemaining(arg0: T_CONS): void;
        forEachRemaining(arg0: $Consumer_<T, T>): void;
        tryAdvance(arg0: T_CONS): boolean;
        tryAdvance(arg0: $Consumer_<T, T>): boolean;
        trySplit(): T_SPLITR;
    }

    export class $UUID implements $Serializable, $Comparable<$UUID> {
        constructor(arg0: number, arg1: number);
        get leastSignificantBits(): number;
        getLeastSignificantBits(): number;
        get mostSignificantBits(): number;
        getMostSignificantBits(): number;
        static fromString(arg0: string): $UUID;
        static nameUUIDFromBytes(arg0: number[]): $UUID;
        static randomUUID(): $UUID;
        clockSequence(): number;
        compareTo(arg0: $UUID): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        node(): number;
        timestamp(): number;
        toString(): string;
        variant(): number;
        version(): number;
    }

    export class $Properties extends $Hashtable<object, object> {
        constructor();
        constructor(arg0: number);
        constructor(arg0: $Properties);
        get empty(): boolean;
        isEmpty(): boolean;
        clear(): void;
        clone(): object;
        computeIfAbsent(arg0: object, arg1: $Function_<object, any, object, any>): object;
        computeIfPresent(arg0: object, arg1: $BiFunction_<object, object, any, object, object, any>): object;
        compute(arg0: object, arg1: $BiFunction_<object, object, any, object, object, any>): object;
        containsKey(arg0: object): boolean;
        containsValue(arg0: object): boolean;
        contains(arg0: object): boolean;
        elements(): $Enumeration<object>;
        entrySet(): $Set<$Map$Entry<object, object>>;
        equals(arg0: object): boolean;
        forEach(arg0: $BiConsumer_<object, object, object, object>): void;
        getOrDefault(arg0: object, arg1: object): object;
        getProperty(arg0: string, arg1: string): string;
        getProperty(arg0: string): string;
        get(arg0: object): object;
        hashCode(): number;
        keySet(): $Set<object>;
        keys(): $Enumeration<object>;
        list(arg0: $PrintStream): void;
        list(arg0: $PrintWriter): void;
        loadFromXML(arg0: $InputStream): void;
        load(arg0: $InputStream): void;
        load(arg0: $Reader): void;
        merge(arg0: object, arg1: object, arg2: $BiFunction_<object, object, any, object, object, any>): object;
        propertyNames(): $Enumeration<any>;
        putAll(arg0: ($Map<any, any> | ([any] extends [PropertyKey] ? Partial<Record<Extract<any, PropertyKey>, any>> : never))): void;
        putIfAbsent(arg0: object, arg1: object): object;
        put(arg0: object, arg1: object): object;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): object;
        replaceAll(arg0: $BiFunction_<object, object, any, object, object, any>): void;
        replace(arg0: object, arg1: object, arg2: object): boolean;
        replace(arg0: object, arg1: object): object;
        save(arg0: $OutputStream, arg1: string): void;
        setProperty(arg0: string, arg1: string): object;
        size(): number;
        storeToXML(arg0: $OutputStream, arg1: string, arg2: string): void;
        storeToXML(arg0: $OutputStream, arg1: string, arg2: $Charset): void;
        storeToXML(arg0: $OutputStream, arg1: string): void;
        store(arg0: $OutputStream, arg1: string): void;
        store(arg0: $Writer, arg1: string): void;
        stringPropertyNames(): $Set<string>;
        toString(): string;
        values(): $Collection<object>;
    }

    export class $Random implements $RandomGenerator, $Serializable {
        constructor();
        constructor(arg0: number);
        get deprecated(): boolean;
        isDeprecated(): boolean;
        static from(arg0: $RandomGenerator_<number>): $Random;
        doubles(arg0: number, arg1: number): $DoubleStream;
        doubles(arg0: number, arg1: number, arg2: number): $DoubleStream;
        doubles(arg0: number): $DoubleStream;
        doubles(): $DoubleStream;
        ints(arg0: number, arg1: number): $IntStream;
        ints(arg0: number, arg1: number, arg2: number): $IntStream;
        ints(arg0: number): $IntStream;
        ints(): $IntStream;
        longs(arg0: number, arg1: number, arg2: number): $LongStream;
        longs(arg0: number, arg1: number): $LongStream;
        longs(arg0: number): $LongStream;
        longs(): $LongStream;
        nextBoolean(): boolean;
        nextBytes(arg0: number[]): void;
        nextDouble(arg0: number, arg1: number): number;
        nextDouble(arg0: number): number;
        nextDouble(): number;
        nextExponential(): number;
        nextFloat(arg0: number, arg1: number): number;
        nextFloat(arg0: number): number;
        nextFloat(): number;
        nextGaussian(arg0: number, arg1: number): number;
        nextGaussian(): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(arg0: number, arg1: number): number;
        nextLong(arg0: number): number;
        nextLong(): number;
        setSeed(arg0: number): void;
    }

    export class $Calendar implements $Serializable, $Cloneable, $Comparable<$Calendar> {
        static ALL_STYLES: number;
        static AM: number;
        static AM_PM: number;
        static APRIL: number;
        static AUGUST: number;
        static DATE: number;
        static DAY_OF_MONTH: number;
        static DAY_OF_WEEK: number;
        static DAY_OF_WEEK_IN_MONTH: number;
        static DAY_OF_YEAR: number;
        static DECEMBER: number;
        static DST_OFFSET: number;
        static ERA: number;
        static FEBRUARY: number;
        static FIELD_COUNT: number;
        static FRIDAY: number;
        static HOUR: number;
        static HOUR_OF_DAY: number;
        static JANUARY: number;
        static JULY: number;
        static JUNE: number;
        static LONG: number;
        static LONG_FORMAT: number;
        static LONG_STANDALONE: number;
        static MARCH: number;
        static MAY: number;
        static MILLISECOND: number;
        static MINUTE: number;
        static MONDAY: number;
        static MONTH: number;
        static NARROW_FORMAT: number;
        static NARROW_STANDALONE: number;
        static NOVEMBER: number;
        static OCTOBER: number;
        static PM: number;
        static SATURDAY: number;
        static SECOND: number;
        static SEPTEMBER: number;
        static SHORT: number;
        static SHORT_FORMAT: number;
        static SHORT_STANDALONE: number;
        static SUNDAY: number;
        static THURSDAY: number;
        static TUESDAY: number;
        static UNDECIMBER: number;
        static WEDNESDAY: number;
        static WEEK_OF_MONTH: number;
        static WEEK_OF_YEAR: number;
        static YEAR: number;
        static ZONE_OFFSET: number;
        get calendarType(): string;
        getCalendarType(): string;
        get firstDayOfWeek(): number;
        getFirstDayOfWeek(): number;
        set firstDayOfWeek(value: number);
        get minimalDaysInFirstWeek(): number;
        getMinimalDaysInFirstWeek(): number;
        set minimalDaysInFirstWeek(value: number);
        get timeInMillis(): number;
        getTimeInMillis(): number;
        set timeInMillis(value: number);
        get timeZone(): $TimeZone;
        getTimeZone(): $TimeZone;
        set timeZone(value: $TimeZone);
        get time(): $Date;
        getTime(): $Date;
        set time(value: $Date);
        get weekYear(): number;
        getWeekYear(): number;
        get weeksInWeekYear(): number;
        getWeeksInWeekYear(): number;
        get lenient(): boolean;
        isLenient(): boolean;
        set lenient(value: boolean);
        get weekDateSupported(): boolean;
        isWeekDateSupported(): boolean;
        static getAvailableCalendarTypes(): $Set<string>;
        static getAvailableLocales(): $Locale[];
        static getInstance(arg0: $Locale): $Calendar;
        static getInstance(arg0: $TimeZone, arg1: $Locale): $Calendar;
        static getInstance(arg0: $TimeZone): $Calendar;
        static getInstance(): $Calendar;
        add(arg0: number, arg1: number): void;
        after(arg0: object): boolean;
        before(arg0: object): boolean;
        clear(arg0: number): void;
        clear(): void;
        clone(): object;
        compareTo(arg0: $Calendar): number;
        equals(arg0: object): boolean;
        getActualMaximum(arg0: number): number;
        getActualMinimum(arg0: number): number;
        getDisplayNames(arg0: number, arg1: number, arg2: $Locale): $Map<string, number>;
        getDisplayName(arg0: number, arg1: number, arg2: $Locale): string;
        getGreatestMinimum(arg0: number): number;
        getLeastMaximum(arg0: number): number;
        getMaximum(arg0: number): number;
        getMinimum(arg0: number): number;
        get(arg0: number): number;
        hashCode(): number;
        isSet(arg0: number): boolean;
        roll(arg0: number, arg1: boolean): void;
        roll(arg0: number, arg1: number): void;
        setFirstDayOfWeek(arg0: number): void;
        setLenient(arg0: boolean): void;
        setMinimalDaysInFirstWeek(arg0: number): void;
        setTimeInMillis(arg0: number): void;
        setTimeZone(arg0: $TimeZone): void;
        setTime(arg0: $Date): void;
        setWeekDate(arg0: number, arg1: number, arg2: number): void;
        set(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): void;
        set(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): void;
        set(arg0: number, arg1: number, arg2: number): void;
        set(arg0: number, arg1: number): void;
        toInstant(): $Instant;
        toString(): string;
    }

    export class $TimeZone implements $Serializable, $Cloneable {
        constructor();
        static LONG: number;
        static SHORT: number;
        get dSTSavings(): number;
        getDSTSavings(): number;
        get displayName(): string;
        getDisplayName(): string;
        get iD(): string;
        getID(): string;
        set iD(value: string);
        get rawOffset(): number;
        getRawOffset(): number;
        set rawOffset(value: number);
        static getAvailableIDs(arg0: number): string[];
        static getAvailableIDs(): string[];
        static getDefault(): $TimeZone;
        static getTimeZone(arg0: string): $TimeZone;
        static getTimeZone(arg0: $ZoneId): $TimeZone;
        static setDefault(arg0: $TimeZone): void;
        clone(): object;
        getDisplayName(arg0: boolean, arg1: number, arg2: $Locale): string;
        getDisplayName(arg0: boolean, arg1: number): string;
        getDisplayName(arg0: $Locale): string;
        getOffset(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): number;
        getOffset(arg0: number): number;
        hasSameRules(arg0: $TimeZone): boolean;
        inDaylightTime(arg0: $Date): boolean;
        observesDaylightTime(): boolean;
        setID(arg0: string): void;
        setRawOffset(arg0: number): void;
        toZoneId(): $ZoneId;
        useDaylightTime(): boolean;
    }

    export class $Hashtable<K, V> extends $Dictionary<K, V> implements $Map<K, V>, $Cloneable, $Serializable {
        constructor();
        constructor(arg0: number);
        constructor(arg0: number, arg1: number);
        constructor(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)));
        get empty(): boolean;
        isEmpty(): boolean;
        clear(): void;
        clone(): object;
        computeIfAbsent(arg0: K, arg1: $Function_<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: object): boolean;
        containsValue(arg0: object): boolean;
        contains(arg0: object): boolean;
        elements(): $Enumeration<V>;
        entrySet(): $Set<$Map$Entry<K, V>>;
        equals(arg0: object): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        hashCode(): number;
        keySet(): $Set<K>;
        keys(): $Enumeration<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): void;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        replaceAll(arg0: $BiFunction_<K, V, V, K, V, V>): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        toString(): string;
        values(): $Collection<V>;
    }

    export class $Dictionary<K, V> {
        constructor();
        get empty(): boolean;
        isEmpty(): boolean;
        elements(): $Enumeration<V>;
        get(arg0: object): V;
        keys(): $Enumeration<K>;
        put(arg0: K, arg1: V): V;
        remove(arg0: object): V;
        size(): number;
    }

    export class $ResourceBundle {
        constructor();
        get baseBundleName(): string;
        getBaseBundleName(): string;
        get keys(): $Enumeration<string>;
        getKeys(): $Enumeration<string>;
        get locale(): $Locale;
        getLocale(): $Locale;
        static clearCache(arg0: $ClassLoader): void;
        static clearCache(): void;
        static getBundle(arg0: string, arg1: $Module): $ResourceBundle;
        static getBundle(arg0: string, arg1: $Locale, arg2: $ClassLoader, arg3: $ResourceBundle$Control): $ResourceBundle;
        static getBundle(arg0: string, arg1: $Locale, arg2: $ClassLoader): $ResourceBundle;
        static getBundle(arg0: string, arg1: $Locale, arg2: $Module): $ResourceBundle;
        static getBundle(arg0: string, arg1: $Locale, arg2: $ResourceBundle$Control): $ResourceBundle;
        static getBundle(arg0: string, arg1: $Locale): $ResourceBundle;
        static getBundle(arg0: string, arg1: $ResourceBundle$Control): $ResourceBundle;
        static getBundle(arg0: string): $ResourceBundle;
        containsKey(arg0: string): boolean;
        getObject(arg0: string): object;
        getStringArray(arg0: string): string[];
        getString(arg0: string): string;
        keySet(): $Set<string>;
    }

    export class $ResourceBundle$Control {
        static FORMAT_CLASS: $List<string>;
        static FORMAT_DEFAULT: $List<string>;
        static FORMAT_PROPERTIES: $List<string>;
        static TTL_DONT_CACHE: number;
        static TTL_NO_EXPIRATION_CONTROL: number;
        static getControl(arg0: string[]): $ResourceBundle$Control;
        static getNoFallbackControl(arg0: string[]): $ResourceBundle$Control;
        getCandidateLocales(arg0: string, arg1: $Locale): $List<$Locale>;
        getFallbackLocale(arg0: string, arg1: $Locale): $Locale;
        getFormats(arg0: string): $List<string>;
        getTimeToLive(arg0: string, arg1: $Locale): number;
        needsReload(arg0: string, arg1: $Locale, arg2: string, arg3: $ClassLoader, arg4: $ResourceBundle, arg5: number): boolean;
        newBundle(arg0: string, arg1: $Locale, arg2: string, arg3: $ClassLoader, arg4: boolean): $ResourceBundle;
        toBundleName(arg0: string, arg1: $Locale): string;
        toResourceName(arg0: string, arg1: string): string;
    }

    export interface $Queue<E> extends $Collection<E> {
        add(arg0: E): boolean;
        element(): E;
        offer(arg0: E): boolean;
        peek(): E;
        poll(): E;
        remove(arg0: object): boolean;
        remove(): E;
    }

    export interface $EventListener {
    }

    export type $ArrayList_<E> = E[];
    export type $Collection_<E> = E[];
    export type $Comparator_<Host0 = any, CallbackArg0 = Host0, CallbackArg1 = Host0, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($Comparator<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $HashMap_<K, V> = { [key: string]: V };
    export type $Iterator_<E> = E[];
    export type $List_<E> = E[];
    export type $Locale$Category_ = $Locale$Category | "DISPLAY" | "FORMAT";
    export type $Locale$FilteringMode_ = $Locale$FilteringMode | "AUTOSELECT_FILTERING" | "EXTENDED_FILTERING" | "IGNORE_EXTENDED_RANGES" | "MAP_EXTENDED_RANGES" | "REJECT_EXTENDED_RANGES";
    export type $Locale$IsoCountryCode_ = $Locale$IsoCountryCode | "PART1_ALPHA2" | "PART1_ALPHA3" | "PART3";
    export type $Map_<K, V> = { [key: string]: V };
    export type $Optional_<T> = T | null;
    export type $SequencedCollection_<E> = E[];
    export type $SequencedMap_<K, V> = { [key: string]: V };
    export type $SequencedSet_<E> = E[];
    export type $Set_<E> = E[];
    export type $SortedMap_<K, V> = { [key: string]: V };
    export type $Spliterator_<T> = T[];
}
