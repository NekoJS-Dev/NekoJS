const fs = require('fs'), cp = require('child_process'), ts = require('../../node_modules/typescript');
const paths = cp.execFileSync('git', ['diff', '--name-only', '77aa54b0', '--', 'common/src/test/resources/nekojs/probe/legacy-tree'], {encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
if(paths.length !== 7) throw new Error('Expected exactly seven regenerated golden files');
function members(nodes, source) {
  return nodes.map(n => n.getText(source).replace(/^(?:static|readonly)\s+/, '').replaceAll('\r\n','\n')).sort();
}
function surface(text, file) {
  const source = ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
  const result = {interfaces:{},other:[],values:{}};
  function visit(statements) {
    for(const node of statements) {
      if(ts.isModuleDeclaration(node) && node.body && ts.isModuleBlock(node.body)) { visit(node.body.statements); continue; }
      if(ts.isInterfaceDeclaration(node)) {
        result.interfaces[node.name.text] = {header: node.getText(source).split('{')[0].trim(), members:members([...node.members],source)};
      } else if(ts.isVariableStatement(node) && node.declarationList.declarations.length===1 && ts.isTypeLiteralNode(node.declarationList.declarations[0].type)) {
        const declaration=node.declarationList.declarations[0];
        result.values[declaration.name.getText(source)] = members([...declaration.type.members],source);
      } else result.other.push(node.getText(source).replaceAll('\r\n','\n'));
    }
  }
  visit(source.statements);
  return result;
}
const rows=[];
for(const file of paths) {
  const before=surface(cp.execFileSync('git',['show','77aa54b0:'+file],{encoding:'utf8'}),file);
  const after=surface(fs.readFileSync(file,'utf8'),file);
  if(JSON.stringify(before.other)!==JSON.stringify(after.other)) throw new Error('Non-interface declarations changed: '+file);
  let moved=0;
  for(const [name,definition] of Object.entries(before.interfaces)) {
    const actual=after.interfaces[name];
    if(!actual || definition.header!==actual.header) throw new Error('Interface heritage/generics changed: '+name);
    const combined=[...actual.members,...(after.values[name] || [])].sort();
    if(JSON.stringify(definition.members)!==JSON.stringify(combined)) throw new Error('Member names/signatures changed: '+name);
    moved+=(after.values[name] || []).length;
  }
  if(Object.keys(before.interfaces).length!==Object.keys(after.interfaces).length) throw new Error('Interface set changed');
  for(const name of Object.keys(after.values)) if(!(name in after.interfaces)) throw new Error('Unexpected value declaration '+name);
  rows.push({file,movedMembers:moved,memberNamesSignaturesPreserved:true,otherDeclarationsPreserved:true});
}
const output={typescriptVersion:ts.version,sourceBase:'77aa54b00b3d22aa7fade97eef5ee635a2dabbf9',files:rows,allPassed:true};
fs.writeFileSync('build/ticket37-config-sync-repair/interface-static-golden-audit.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output));
