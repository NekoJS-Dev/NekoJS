const fs=require('fs'),path=require('path'),crypto=require('crypto'),ts=require('../../node_modules/typescript');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const results=[];
for(const node of ['1.21.1','26.1.2','26.2.0']) {
  function extract(profile) {
    const file=path.join('build',profile,node,'.neko_probe/typescript/@package/com/mojang/serialization/index.d.ts');
    const source=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
    const declarations={};
    function visit(statements) {for(const item of statements) {
      if(ts.isModuleDeclaration(item)&&item.body&&ts.isModuleBlock(item.body))visit(item.body.statements);
      else if((ts.isInterfaceDeclaration(item)||ts.isClassDeclaration(item))&&item.name)declarations[item.name.text]=item;
    }}
    visit(source.statements);
    return {source,declarations};
  }
  const before=extract('ticket37-892-sam-installed'),after=extract('ticket37-interface-static-installed');
  const beforeClass=before.declarations.$MapCodec.getText(before.source).replaceAll('\r\n','\n');
  const afterClass=after.declarations.$MapCodec.getText(after.source).replaceAll('\r\n','\n');
  if(beforeClass!==afterClass)throw new Error('MapCodec class changed');
  const classNames=new Set([...before.declarations.$MapCodec.members].map(m=>m.name?.getText(before.source)).filter(Boolean));
  const missing={};
  for(const name of ['$MapDecoder','$MapEncoder']) {
    const oldMembers=[...before.declarations[name].members].map(m=>m.getText(before.source));
    const newMembers=[...after.declarations[name].members].map(m=>m.getText(after.source));
    if(newMembers.some(m=>!oldMembers.includes(m)))throw new Error('Existing interface instance method changed');
    missing[name]=[...after.declarations[name].members].map(m=>m.name?.getText(after.source)).filter(n=>n&&!classNames.has(n));
  }
  results.push({node,mapCodecClassByteIdentical:true,classSha256:sha(beforeClass),survivingInterfaceInstanceMembersByteIdentical:true,missingClassMembersBeforeAndAfter:missing,interpretation:'Observed: the unchanged class omits inherited interface methods and the surviving interface signatures are byte-identical. Inference: corrected static separation reveals this structural gap. A modifier-only control did not reproduce the expected two Codec diagnostics, so invalid static poisoning alone is not established.'});
}
fs.writeFileSync('build/ticket37-config-sync-repair/interface-static-codec-diagnosis.json',JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results));
