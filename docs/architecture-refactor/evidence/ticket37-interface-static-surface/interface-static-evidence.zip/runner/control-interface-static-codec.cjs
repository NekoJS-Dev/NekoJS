const fs=require('fs'),path=require('path'),ts=require('../../node_modules/typescript');
const results=[];
for(const node of ['1.21.1','26.1.2','26.2.0']) {
  const configPath=path.resolve('build/ticket37-892-sam-installed/ide/'+node+'-server-tsconfig.json');
  const config=ts.readConfigFile(configPath,ts.sys.readFile);
  const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,path.dirname(configPath));
  const target=path.resolve('build/ticket37-892-sam-installed',node,'.neko_probe/typescript/@package/com/mojang/serialization/index.d.ts');
  const original=fs.readFileSync(target,'utf8');
  const source=ts.createSourceFile(target,original,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
  const removals=[];
  function visit(n) {
    if(ts.isInterfaceDeclaration(n))for(const member of n.members)for(const modifier of member.modifiers || []) {
      if(modifier.kind===ts.SyntaxKind.StaticKeyword)removals.push({start:modifier.getStart(source),end:modifier.end});
    }
    ts.forEachChild(n,visit);
  }
  visit(source);
  let control=original;
  for(const range of removals.sort((a,b)=>b.start-a.start))control=control.slice(0,range.start)+control.slice(range.end);
  const host=ts.createCompilerHost(parsed.options),readFile=host.readFile.bind(host);
  host.readFile=file=>path.resolve(file)===target ? control : readFile(file);
  const program=ts.createProgram(parsed.fileNames,parsed.options,host);
  const diagnostics=ts.getPreEmitDiagnostics(program).filter(d=>d.code===2430&&d.file?.fileName&&path.resolve(d.file.fileName)===target&&ts.flattenDiagnosticMessageText(d.messageText,'\n').startsWith("Interface '$Codec<A>'"));
  if(diagnostics.length!==2)throw new Error('Expected both Codec errors in the in-memory old-source control');
  if(fs.readFileSync(target,'utf8')!==original)throw new Error('Captured output changed');
  results.push({node,originalGeneratedFilesModified:false,control:'Only illegal static modifier tokens in the old serialization interface declarations removed in the compiler host; class bodies and instance factories remain old bytes',removedModifierCount:removals.length,codecDiagnostics:diagnostics.map(d=>({code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')})),verdict:'Old unchanged class/instance-signature defect is red without invalid static poisoning; current static-surface patch did not create those missing members'});
}
fs.writeFileSync('build/ticket37-config-sync-repair/interface-static-codec-control.json',JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results));
