import collections
import concurrent.futures
import json
import os
import re
import subprocess
from pathlib import Path

project=Path.cwd().resolve()
trial=project/'build/ticket37-interface-static-installed'
output=trial/'ide'
output.mkdir()
pyright='C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js'

def check(node):
    server=trial/node
    files=sorted((server/'.neko_probe/python').rglob('*.pyi'))
    assert files
    config=dict(extends=str(server/'pyrightconfig.json'), include=[os.path.relpath(p, output).replace('\\','/') for p in files], exclude=[])
    config_path=output/(node+'-pyrightconfig.json')
    config_path.write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
    result_path=output/(node+'-pyright.json')
    with result_path.open('xb') as out:
        result=subprocess.run(['node',pyright,'--project',str(config_path),'--outputjson'],stdout=out,stderr=subprocess.PIPE)
    (output/(node+'-pyright-stderr.txt')).write_bytes(result.stderr)
    assert not result.stderr
    pyright_exit=result.returncode
    document=json.loads(result_path.read_text(encoding='utf-8-sig'))
    assert document['summary']['filesAnalyzed']==len(files)
    ts_results=[]
    for side in ['server','startup']:
        config=dict(extends=str(server/'nekojs'/(side+'_scripts/jsconfig.json')),compilerOptions=dict(skipLibCheck=False,noEmit=True))
        config_path=output/(node+'-'+side+'-tsconfig.json')
        config_path.write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
        result_path=output/(node+'-'+side+'-tsc.txt')
        with result_path.open('xb') as out:
            result=subprocess.run(['node',str(project/'node_modules/typescript/bin/tsc'),'--project',str(config_path),'--pretty','false'],stdout=out,stderr=subprocess.PIPE)
        assert not result.stderr
        codes=collections.Counter(re.findall(r'error (TS\d+):',result_path.read_text(encoding='utf-8-sig')))
        ts_results.append(dict(side=side,exitCode=result.returncode,diagnosticCount=sum(codes.values()),codes=dict(codes),defaultEditorIncludes=True,skipLibCheck=False))
    old_path=project/'build/ticket37-config-sync-repair'/('ts-member-ide-'+node+'-pyright.json')
    old=json.loads(old_path.read_text(encoding='utf-8-sig'))
    def normalized(d):
        return(d['file'].replace('\\','/').partition('/python/')[2],d.get('rule','none'),d['message'])
    old_keys=collections.Counter(normalized(d) for d in old['generalDiagnostics'])
    new_keys=collections.Counter(normalized(d) for d in document['generalDiagnostics'])
    answer=dict(node=node,pyright=dict(version=document['version'],exitCode=pyright_exit,summary=document['summary'],stubCount=len(files),rules=dict(collections.Counter(d.get('rule','none') for d in document['generalDiagnostics'])),previousCb5ErrorCount=old['summary']['errorCount'],removed=sum((old_keys-new_keys).values()),added=sum((new_keys-old_keys).values())),typescript=ts_results)
    print(json.dumps(answer),flush=True)
    return answer

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    results=list(executor.map(check,['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']))
(output/'summary.json').write_text(json.dumps(dict(sourceRevision='77aa54b00b3d22aa7fade97eef5ee635a2dabbf9',nodes=results),indent=2)+'\n',encoding='utf-8')
