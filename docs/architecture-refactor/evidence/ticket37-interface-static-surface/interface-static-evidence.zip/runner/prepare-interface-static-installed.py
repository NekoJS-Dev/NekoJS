import hashlib
import json
import shutil
import socket
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
revision = '77aa54b00b3d22aa7fade97eef5ee635a2dabbf9'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == revision
patch=subprocess.check_output(['git', 'diff', revision, '--', 'common/src/main/java/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.java'])
assert patch
patch_sha=hashlib.sha256(patch).hexdigest()
target = project / 'build/ticket37-interface-static-installed'
assert target.parent == project / 'build' and not target.exists()
source_root = project / 'build/ticket37-ts-member-candidate'
nodes = [('1.21.1', 25921), ('26.1.2', 25931), ('26.2.0', 25961), ('26.1.2-fabric', 25941), ('26.2.0-fabric', 25951)]
for node, port in nodes:
    for checked_port in [port, port + 1]:
        with socket.socket() as guard:
            guard.bind(('127.0.0.1', checked_port))
rows = []
for node, port in nodes:
    source = source_root / node
    directory = target / node
    (directory / 'mods').mkdir(parents=True)
    for name in ['eula.txt', 'server.properties']:
        shutil.copyfile(source / name, directory / name)
    for folder in ['config', 'startup_scripts', 'server_scripts']:
        shutil.copytree(source / 'nekojs' / folder, directory / 'nekojs' / folder)
    for jar in (source / 'mods').glob('*.jar'):
        if not jar.name.startswith('nekojs-'):
            shutil.copyfile(jar, directory / 'mods' / jar.name)
    artifacts = list((project / 'versions' / node / 'build/libs').glob('*-server.jar')) if node == '1.21.1' else [p for p in (project / 'versions' / node / 'build/libs').glob('*.jar') if not p.name.endswith(('-dev.jar', '-sources.jar'))]
    assert len(artifacts) == 1, [p.name for p in artifacts]
    jar = artifacts[0]
    shutil.copyfile(jar, directory / 'mods' / jar.name)
    (directory / 'libraries').symlink_to((source / 'libraries').resolve(), target_is_directory=True)
    if node.endswith('-fabric'):
        (directory / 'versions').symlink_to((source / 'versions').resolve(), target_is_directory=True)
        shutil.copyfile(source / 'fabric-server-launch.jar', directory / 'fabric-server-launch.jar')
    fixtures = {p.relative_to(directory).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['config', 'startup_scripts', 'server_scripts'] for p in (directory / 'nekojs' / folder).rglob('*') if p.is_file()}
    rows.append(dict(node=node, artifact=jar.name, sha256=hashlib.sha256(jar.read_bytes()).hexdigest(), serverPort=port, rconPort=port+1, fixtureHashes=fixtures))
(target / 'preparation-manifest.json').write_text(json.dumps(dict(sourceRevision=revision, productionPatchSha256=patch_sha, freshWorld=True, fixtureSource='ticket37-ts-member-candidate', nodes=rows), indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(sourceRevision=revision, artifacts=[{k:v for k,v in r.items() if k != 'fixtureHashes'} for r in rows])))
