    export interface $TypeScriptInterfaceStaticSurfaceTest$ValueApi<T> {
        label(): string;
        length(value: number): number;
        static length(value: 3): 3;
        of<R>(value: R): $TypeScriptInterfaceStaticSurfaceTest$ValueApi<R>;
        value(): T;
        static LEVEL: number;
    }
    export interface $TypeScriptInterfaceStaticSurfaceTest$ChildApi extends $TypeScriptInterfaceStaticSurfaceTest$ValueApi<string> {
    }
