import { $TypeScriptInterfaceStaticSurfaceTest$ValueApi as Api,
    $TypeScriptInterfaceStaticSurfaceTest$ChildApi as Child } from '../../common/build/probe-ts-interface-static/index';
const factoryValue: string = Api.of('x').value();
const defaultLabel: string = Api.of('x').label();
const level: number = Api.LEVEL;
const length: number = Api.length(4);
const specializedLength: 3 = Api.length(3);
declare const instance: Api<string>;
declare const child: Child;
const childValue: string = child.value();
// @ts-expect-error A static factory is not an instance member.
instance.of('x');
// @ts-expect-error A static constant is not an instance member.
instance.LEVEL;
// @ts-expect-error Interface static methods are not inherited instance members.
child.of('x');
// @ts-expect-error The factory retains inference from its actual argument.
const wrongValue: number = Api.of('x').value();
// @ts-expect-error The actual Java parameter contract is numeric.
Api.length('x');
// @ts-expect-error Java interface constants cannot be assigned.
Api.LEVEL = 4;
