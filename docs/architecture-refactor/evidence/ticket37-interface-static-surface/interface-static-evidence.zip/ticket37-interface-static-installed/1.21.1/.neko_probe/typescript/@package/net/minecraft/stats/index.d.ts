import { $DataFixer } from "java:com/mojang/datafixers";
import { $Iterable } from "java:java/lang";
import { $DecimalFormat } from "java:java/text";
import { $Collection, $Iterator } from "java:java/util";
import { $Registry } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $RecipeBookMenu, $RecipeBookType, $RecipeBookType_ } from "java:net/minecraft/world/inventory";
import { $RecipeHolder, $RecipeManager } from "java:net/minecraft/world/item/crafting";
import { $ObjectiveCriteria } from "java:net/minecraft/world/scores/criteria";

declare module "java:net/minecraft/stats" {
    export class $RecipeBook {
        constructor();
        get bookSettings(): $RecipeBookSettings;
        getBookSettings(): $RecipeBookSettings;
        set bookSettings(value: $RecipeBookSettings);
        addHighlight(arg0: $RecipeHolder<any>): void;
        add(arg0: $RecipeHolder<any>): void;
        contains(arg0: $ResourceLocation_): boolean;
        contains(arg0: $RecipeHolder<any>): boolean;
        copyOverData(arg0: $RecipeBook): void;
        isFiltering(arg0: $RecipeBookMenu<any, any>): boolean;
        isFiltering(arg0: $RecipeBookType_): boolean;
        isOpen(arg0: $RecipeBookType_): boolean;
        removeHighlight(arg0: $RecipeHolder<any>): void;
        remove(arg0: $RecipeHolder<any>): void;
        setBookSetting(arg0: $RecipeBookType_, arg1: boolean, arg2: boolean): void;
        setFiltering(arg0: $RecipeBookType_, arg1: boolean): void;
        setOpen(arg0: $RecipeBookType_, arg1: boolean): void;
        willHighlight(arg0: $RecipeHolder<any>): boolean;
    }

    export class $RecipeBookSettings {
        constructor();
        static read(arg0: $CompoundTag_): $RecipeBookSettings;
        static read(arg0: $FriendlyByteBuf): $RecipeBookSettings;
        copy(): $RecipeBookSettings;
        equals(arg0: object): boolean;
        hashCode(): number;
        isFiltering(arg0: $RecipeBookType_): boolean;
        isOpen(arg0: $RecipeBookType_): boolean;
        replaceFrom(arg0: $RecipeBookSettings): void;
        setFiltering(arg0: $RecipeBookType_, arg1: boolean): void;
        setOpen(arg0: $RecipeBookType_, arg1: boolean): void;
        write(arg0: $CompoundTag_): void;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $ServerRecipeBook extends $RecipeBook {
        constructor();
        static RECIPE_BOOK_TAG: string;
        addRecipes(arg0: $RecipeHolder<any>[], arg1: $ServerPlayer): number;
        fromNbt(arg0: $CompoundTag_, arg1: $RecipeManager): void;
        removeRecipes(arg0: $RecipeHolder<any>[], arg1: $ServerPlayer): number;
        sendInitialRecipeBook(arg0: $ServerPlayer): void;
        toNbt(): $CompoundTag;
    }

    export class $ServerStatsCounter extends $StatsCounter {
        constructor(arg0: $MinecraftServer, arg1: string);
        markAllDirty(): void;
        parseLocal(arg0: $DataFixer, arg1: string): void;
        save(): void;
        sendStats(arg0: $ServerPlayer): void;
        setValue(arg0: $Player, arg1: $Stat<any>, arg2: number): void;
    }

    export class $Stat<T> extends $ObjectiveCriteria {
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Stat<any>>;
        get type(): $StatType<T>;
        getType(): $StatType<T>;
        get value(): T;
        getValue(): T;
        static buildName<T>(arg0: $StatType<T>, arg1: T): string;
        equals(arg0: object): boolean;
        format(arg0: number): string;
        hashCode(): number;
        toString(): string;
    }

    export interface $StatFormatter {
        format(arg0: number): string;
    }
    export const $StatFormatter: {
        readonly DECIMAL_FORMAT: $DecimalFormat;
        readonly DEFAULT: $StatFormatter;
        readonly DISTANCE: $StatFormatter;
        readonly DIVIDE_BY_TEN: $StatFormatter;
        readonly TIME: $StatFormatter;
    };

    export class $StatType<T> implements $Iterable<$Stat<T>> {
        constructor(arg0: $Registry<T>, arg1: $Component_);
        get displayName(): $Component;
        getDisplayName(): $Component;
        get registry(): $Registry<T>;
        getRegistry(): $Registry<T>;
        contains(arg0: T): boolean;
        get(arg0: T, arg1: $StatFormatter_<number, string>): $Stat<T>;
        get(arg0: T): $Stat<T>;
        iterator(): $Iterator<$Stat<T>>;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, $Stat<T>>;
    }

    export class $StatsCounter {
        constructor();
        getValue(arg0: $Stat<any>): number;
        getValue<T>(arg0: $StatType<T>, arg1: T): number;
        increment(arg0: $Player, arg1: $Stat<any>, arg2: number): void;
        setValue(arg0: $Player, arg1: $Stat<any>, arg2: number): void;
    }

    export type $StatFormatter_<CallbackArg0 = number, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | $StatFormatter;
}
