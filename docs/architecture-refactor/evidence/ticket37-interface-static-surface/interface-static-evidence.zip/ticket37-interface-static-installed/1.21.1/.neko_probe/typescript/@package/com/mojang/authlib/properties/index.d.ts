import { $ForwardingMultimap } from "java:com/google/common/collect";
import { $Record } from "java:java/lang";
import { $PublicKey } from "java:java/security";

declare module "java:com/mojang/authlib/properties" {
    export class $Property extends $Record {
        constructor(arg0: string, arg1: string);
        constructor(name: string, value: string, signature: string);
        equals(arg0: object): boolean;
        hasSignature(): boolean;
        hashCode(): number;
        isSignatureValid(arg0: $PublicKey): boolean;
        name(): string;
        signature(): string;
        toString(): string;
        value(): string;
    }

    export class $PropertyMap extends $ForwardingMultimap<string, $Property> {
        constructor();
    }

}
