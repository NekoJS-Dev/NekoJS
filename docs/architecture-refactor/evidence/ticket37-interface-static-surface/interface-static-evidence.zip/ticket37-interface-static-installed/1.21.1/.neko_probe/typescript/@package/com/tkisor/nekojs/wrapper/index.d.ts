import { $JsonElement } from "java:com/google/gson";
import { $Value } from "java:graal/graalvm/polyglot";
import { $ProxyObject } from "java:graal/graalvm/polyglot/proxy";
import { $List, $Map } from "java:java/util";

export * as clientdata from "java:com/tkisor/nekojs/wrapper/clientdata";
export * as entity from "java:com/tkisor/nekojs/wrapper/entity";
export * as event from "java:com/tkisor/nekojs/wrapper/event";
export * as fluid from "java:com/tkisor/nekojs/wrapper/fluid";
export * as item from "java:com/tkisor/nekojs/wrapper/item";
export * as network from "java:com/tkisor/nekojs/wrapper/network";
export * as pdata from "java:com/tkisor/nekojs/wrapper/pdata";
export * as registry from "java:com/tkisor/nekojs/wrapper/registry";

declare module "java:com/tkisor/nekojs/wrapper" {
    /** Event object for generateData/generateAssets; writes files into NekoJS's disk pack directory. */
    export class $DataGeneratorJS {
        constructor(root: string);
        constructor(root: string, stage: string);
        /** Per-file size cap for generated files, in bytes (16 MiB). */
        static MAX_GENERATED_FILE_BYTES: number;
        /** Cumulative size cap per generator instance, in bytes (64 MiB). */
        static MAX_GENERATED_TOTAL_BYTES: number;
        /**
         * Returns the generation stage this event belongs to.
         * @returns stage name such as 'after_mods', or empty string when unspecified
         */
        get stage(): string;
        getStage(): string;
        /**
         * Writes plain text to a file; alias of text(path, content).
         * @param path relative path inside the pack root; must not escape it
         * @param content text content to write; must not be null
         */
        add(path: string, content: string): void;
        /**
         * Reads back a previously generated JSON file.
         * @param path relative path inside the pack root
         * @returns parsed JSON, or null when the file is missing, unreadable, or invalid
         */
        getJson(path: string): $JsonElement;
        /**
         * Writes a JSON file; the value may be a JS object (auto-serialized) or a JSON string.
         * @param path relative path inside the pack root; must not escape it
         * @param value JS object, JS array, or JSON string
         */
        json(path: string, value: object): void;
        /**
         * Writes plain text to a file.
         * @param path relative path inside the pack root; must not escape it
         * @param content text content to write; must not be null
         */
        text(path: string, content: string): void;
    }

    /** Common fluid amounts in millibuckets for recipe scripts. */
    export class $FluidAmounts {
        /** Alias of BUCKET. */
        static B: number;
        /** One bottle (250mB). */
        static BOTTLE: number;
        /** One bucket, in millibuckets (1000mB). */
        static BUCKET: number;
        /** Fluid for one ingot (90mB). */
        static INGOT: number;
        /** Alias of MILLIBUCKET. */
        static MB: number;
        /** Fluid for one metal block (810mB). */
        static METAL_BLOCK: number;
        /** One millibucket (1mB). */
        static MILLIBUCKET: number;
        /** Fluid for one nugget (10mB). */
        static NUGGET: number;
    }

    /** Implemented by JS wrappers that can expose their wrapped native object. */
    export interface $NekoWrapper<T> {
        /**
         * Unwraps the JS wrapper and returns the underlying native object.
         * @returns the wrapped native object, never null
         */
        unwrap(): T;
    }

    export class $RecipeRegistryProxy implements $ProxyObject {
        constructor(event: $RecipeEventJS);
        get memberKeys(): object;
        getMemberKeys(): object;
        describeType(namespace: string, type: string): $Map<string, object>;
        getMember(namespace: string): object;
        hasMember(key: string): boolean;
        hasNamespace(namespace: string): boolean;
        hasType(namespace: string, type: string): boolean;
        namespaces(): $List<string>;
        putMember(key: string, value: $Value): void;
        types(namespace: string): $List<string>;
    }

    export type $NekoWrapper_<Host0 = any, CallbackResult = Host0> = (() => CallbackResult) | $NekoWrapper<Host0>;
}
