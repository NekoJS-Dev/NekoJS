import { $GameProfile } from "java:com/mojang/authlib";
import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $ClientboundPacketListener, $ConnectionProtocol, $ConnectionProtocol_, $FriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ClientPongPacketListener } from "java:net/minecraft/network/protocol/ping";

declare module "java:net/minecraft/network/protocol/status" {
    export interface $ClientStatusPacketListener extends $ClientPongPacketListener, $ClientboundPacketListener {
        handleStatusResponse(arg0: $ClientboundStatusResponsePacket): void;
        protocol(): $ConnectionProtocol;
    }

    export class $ClientboundStatusResponsePacket extends $Record implements $Packet<$ClientStatusPacketListener> {
        constructor(arg0: $ServerStatus);
        constructor(status: $ServerStatus, cachedStatus: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundStatusResponsePacket>;
        cachedStatus(): string;
        equals(arg0: object): boolean;
        handle(arg0: $ClientStatusPacketListener): void;
        hashCode(): number;
        status(): $ServerStatus;
        toString(): string;
        type(): $PacketType<$ClientboundStatusResponsePacket>;
    }

    export class $ServerStatus extends $Record {
        constructor(arg0: $Component_, arg1: $Optional<$ServerStatus$Players>, arg2: $Optional<$ServerStatus$Version>, arg3: $Optional<$ServerStatus$Favicon>, arg4: boolean);
        constructor(description: $Component_, players: $Optional<$ServerStatus$Players>, version: $Optional<$ServerStatus$Version>, favicon: $Optional<$ServerStatus$Favicon>, enforcesSecureChat: boolean, isModded: boolean);
        static CODEC: $Codec<$ServerStatus>;
        get modded(): boolean;
        isModded(): boolean;
        description(): $Component;
        enforcesSecureChat(): boolean;
        equals(arg0: object): boolean;
        favicon(): $Optional<$ServerStatus$Favicon>;
        hashCode(): number;
        players(): $Optional<$ServerStatus$Players>;
        toString(): string;
        version(): $Optional<$ServerStatus$Version>;
    }

    export class $ServerStatus$Favicon extends $Record {
        constructor(iconBytes: number[]);
        static CODEC: $Codec<$ServerStatus$Favicon>;
        equals(arg0: object): boolean;
        hashCode(): number;
        iconBytes(): number[];
        toString(): string;
    }

    export class $ServerStatus$Players extends $Record {
        constructor(max: number, online: number, sample: $GameProfile[]);
        static CODEC: $Codec<$ServerStatus$Players>;
        equals(arg0: object): boolean;
        hashCode(): number;
        max(): number;
        online(): number;
        sample(): $List<$GameProfile>;
        toString(): string;
    }

    export class $ServerStatus$Version extends $Record {
        constructor(name: string, protocol: number);
        static CODEC: $Codec<$ServerStatus$Version>;
        static current(): $ServerStatus$Version;
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): string;
        protocol(): number;
        toString(): string;
    }

}
