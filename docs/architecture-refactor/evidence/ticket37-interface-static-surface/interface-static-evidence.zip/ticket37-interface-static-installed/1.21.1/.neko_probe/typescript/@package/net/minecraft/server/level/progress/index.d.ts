import { $ChunkPos } from "java:net/minecraft/world/level";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";

declare module "java:net/minecraft/server/level/progress" {
    export interface $ChunkProgressListener {
        onStatusChange(arg0: $ChunkPos, arg1: $ChunkStatus_): void;
        start(): void;
        stop(): void;
        updateSpawnPos(arg0: $ChunkPos): void;
    }
    export const $ChunkProgressListener: {
        calculateDiameter(arg0: number): number;
    };

    export interface $ChunkProgressListenerFactory {
        create(arg0: number): $ChunkProgressListener;
    }

    export type $ChunkProgressListenerFactory_<CallbackArg0 = number, CallbackResult = $ChunkProgressListener> = ((arg0: CallbackArg0) => CallbackResult) | $ChunkProgressListenerFactory;
}
