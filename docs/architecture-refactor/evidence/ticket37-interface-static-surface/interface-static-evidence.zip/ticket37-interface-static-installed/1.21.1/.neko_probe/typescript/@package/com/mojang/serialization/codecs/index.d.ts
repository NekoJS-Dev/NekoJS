import { $App, $Applicative, $Applicative$Mu, $K1 } from "java:com/mojang/datafixers/kinds";
import { $Function3, $Function3_, $Function4, $Function4_, $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult, $DynamicOps, $Lifecycle, $MapCodec, $MapDecoder, $MapEncoder, $MapLike, $RecordBuilder } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Map } from "java:java/util";
import { $BiFunction, $BiFunction_, $Function, $Function_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";

declare module "java:com/mojang/serialization/codecs" {
    export interface $BaseMapCodec<K, V> {
        decode<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>): $DataResult<$Map<K, V>>;
        elementCodec(): $Codec<V>;
        encode<T>(arg0: { [key: K]: V }, arg1: $DynamicOps<T>, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
        keyCodec(): $Codec<K>;
    }

    export interface $PrimitiveCodec<A> extends $Codec<A> {
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<A, T>>;
        encode<T>(arg0: A, arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
        read<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<A>;
        write<T>(arg0: $DynamicOps<T>, arg1: A): T;
    }

    export class $RecordCodecBuilder<O, F> implements $App<$RecordCodecBuilder$Mu<O>, F> {
        static build<O>(arg0: $App<$RecordCodecBuilder$Mu<O>, O>): $MapCodec<O>;
        static create<O>(arg0: $Function_<$RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>, $RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>>): $Codec<O>;
        static deprecated<O, F>(arg0: F, arg1: number): $RecordCodecBuilder<O, F>;
        static instance<O>(): $RecordCodecBuilder$Instance<O>;
        static mapCodec<O>(arg0: $Function_<$RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>, $RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>>): $MapCodec<O>;
        static of<O, F>(arg0: $Function_<O, F, O, F>, arg1: $MapCodec<F>): $RecordCodecBuilder<O, F>;
        static of<O, F>(arg0: $Function_<O, F, O, F>, arg1: string, arg2: $Codec<F>): $RecordCodecBuilder<O, F>;
        static point<O, F>(arg0: F, arg1: $Lifecycle): $RecordCodecBuilder<O, F>;
        static point<O, F>(arg0: F): $RecordCodecBuilder<O, F>;
        static stable<O, F>(arg0: F): $RecordCodecBuilder<O, F>;
        static unbox<O, F>(arg0: $App<$RecordCodecBuilder$Mu<O>, F>): $RecordCodecBuilder<O, F>;
        dependent<E>(arg0: $Function_<O, E, O, E>, arg1: $MapEncoder<E>, arg2: $Function_<F, $MapDecoder<E>, F, $MapDecoder<E>>): $RecordCodecBuilder<O, E>;
    }

    export class $RecordCodecBuilder$Instance<O> implements $Applicative<$RecordCodecBuilder$Mu<O>, $RecordCodecBuilder$Instance$Mu<O>> {
        constructor();
        ap2<A, B, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $BiFunction_<A, B, R, A, B, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, A>, arg2: $App<$RecordCodecBuilder$Mu<O>, B>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap3<T1, T2, T3, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function3_<T1, T2, T3, R, T1, T2, T3, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap4<T1, T2, T3, T4, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function4_<T1, T2, T3, T4, R, T1, T2, T3, T4, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>): $App<$RecordCodecBuilder$Mu<O>, R>;
        deprecated<A>(arg0: A, arg1: number): $App<$RecordCodecBuilder$Mu<O>, A>;
        lift1<A, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function_<A, R, A, R>>): $Function<$App<$RecordCodecBuilder$Mu<O>, A>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        map<T, R>(arg0: $Function_<T, R, T, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T>): $App<$RecordCodecBuilder$Mu<O>, R>;
        point<A>(arg0: A, arg1: $Lifecycle): $App<$RecordCodecBuilder$Mu<O>, A>;
        point<A>(arg0: A): $App<$RecordCodecBuilder$Mu<O>, A>;
        stable<A>(arg0: A): $App<$RecordCodecBuilder$Mu<O>, A>;
    }

    export class $RecordCodecBuilder$Instance$Mu<O> implements $Applicative$Mu {
    }

    export class $RecordCodecBuilder$Mu<O> implements $K1 {
        constructor();
    }

    export class $SimpleMapCodec<K, V> extends $MapCodec<$Map<K, V>> implements $BaseMapCodec<K, V> {
        constructor(arg0: $Codec<K>, arg1: $Codec<V>, arg2: $Keyable_<$DynamicOps<any>, $Stream<any>>);
        decode<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>): $DataResult<$Map<K, V>>;
        elementCodec(): $Codec<V>;
        encode<T>(arg0: { [key: K]: V }, arg1: $DynamicOps<T>, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        keyCodec(): $Codec<K>;
        keys<T>(arg0: $DynamicOps<T>): $Stream<T>;
        toString(): string;
    }

    export class $UnboundedMapCodec<K, V> extends $Record implements $BaseMapCodec<K, V>, $Codec<$Map<K, V>> {
        constructor(keyCodec: $Codec<K>, elementCodec: $Codec<V>);
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<$Map<K, V>, T>>;
        elementCodec(): $Codec<V>;
        encode<T>(arg0: { [key: K]: V }, arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        keyCodec(): $Codec<K>;
        toString(): string;
    }

}
