import { $Gson, $JsonElement } from "java:com/google/gson";
import { $BufferedReader, $InputStream } from "java:java/io";
import { $AutoCloseable, $AutoCloseable_ } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Collection, $List, $Map, $Optional, $Set } from "java:java/util";
import { $CompletableFuture, $Executor, $Executor_ } from "java:java/util/concurrent";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $ZipEntry, $ZipFile } from "java:java/util/zip";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $PackResources } from "java:net/minecraft/server/packs";
import { $MetadataSectionSerializer } from "java:net/minecraft/server/packs/metadata";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $ProfilerFiller } from "java:net/minecraft/util/profiling";
import { $ContextAwareReloadListener } from "java:net/neoforged/neoforge/resource";

declare module "java:net/minecraft/server/packs/resources" {
    export interface $CloseableResourceManager extends $ResourceManager, $AutoCloseable {
        close(): void;
    }

    export interface $IoSupplier<T> {
        get(): T;
    }
    export const $IoSupplier: {
        create(arg0: string): $IoSupplier<$InputStream>;
        create(arg0: $ZipFile, arg1: $ZipEntry): $IoSupplier<$InputStream>;
    };

    export interface $PreparableReloadListener {
        getName(): string;
        reload(arg0: $PreparableReloadListener$PreparationBarrier_<any, $CompletableFuture<any>>, arg1: $ResourceManager, arg2: $ProfilerFiller, arg3: $ProfilerFiller, arg4: $Executor_<$Runnable>, arg5: $Executor_<$Runnable>): $CompletableFuture<void>;
    }

    export interface $PreparableReloadListener$PreparationBarrier {
        wait<T>(arg0: T): $CompletableFuture<T>;
    }

    export class $Resource {
        constructor(arg0: $PackResources, arg1: $IoSupplier_<$InputStream, $InputStream>);
        constructor(arg0: $PackResources, arg1: $IoSupplier_<$InputStream, $InputStream>, arg2: $IoSupplier_<$ResourceMetadata, $ResourceMetadata_<$MetadataSectionSerializer<any>, $Optional<any>>>);
        knownPackInfo(): $Optional<$KnownPack>;
        metadata(): $ResourceMetadata;
        openAsReader(): $BufferedReader;
        open(): $InputStream;
        sourcePackId(): string;
        source(): $PackResources;
    }

    export interface $ResourceManager extends $ResourceProvider {
        getNamespaces(): $Set<string>;
        getResourceStack(arg0: $ResourceLocation_): $List<$Resource>;
        listPacks(): $Stream<$PackResources>;
        listResourceStacks(arg0: string, arg1: $Predicate_<$ResourceLocation, $ResourceLocation, boolean>): $Map<$ResourceLocation, $List<$Resource>>;
        listResources(arg0: string, arg1: $Predicate_<$ResourceLocation, $ResourceLocation, boolean>): $Map<$ResourceLocation, $Resource>;
    }

    export interface $ResourceMetadata {
        copySections(arg0: $MetadataSectionSerializer<any>[]): $ResourceMetadata;
        getSection<T>(arg0: $MetadataSectionSerializer<T>): $Optional<T>;
    }
    export const $ResourceMetadata: {
        fromJsonStream(arg0: $InputStream): $ResourceMetadata;
        readonly EMPTY: $ResourceMetadata;
        readonly EMPTY_SUPPLIER: $IoSupplier<$ResourceMetadata>;
    };

    export interface $ResourceProvider {
        getResourceOrThrow(arg0: $ResourceLocation_): $Resource;
        getResource(arg0: $ResourceLocation_): $Optional<$Resource>;
        openAsReader(arg0: $ResourceLocation_): $BufferedReader;
        open(arg0: $ResourceLocation_): $InputStream;
    }
    export const $ResourceProvider: {
        fromMap(arg0: { [key: $ResourceLocation_]: $Resource }): $ResourceProvider;
        readonly EMPTY: $ResourceProvider;
    };

    export class $SimpleJsonResourceReloadListener extends $SimplePreparableReloadListener<$Map<$ResourceLocation, $JsonElement>> {
        constructor(arg0: $Gson, arg1: string);
        static scanDirectory(arg0: $ResourceManager, arg1: string, arg2: $Gson, arg3: { [key: $ResourceLocation_]: $JsonElement }): void;
    }

    export class $SimplePreparableReloadListener<T> extends $ContextAwareReloadListener implements $PreparableReloadListener {
        constructor();
        reload(arg0: $PreparableReloadListener$PreparationBarrier_<any, $CompletableFuture<any>>, arg1: $ResourceManager, arg2: $ProfilerFiller, arg3: $ProfilerFiller, arg4: $Executor_<$Runnable>, arg5: $Executor_<$Runnable>): $CompletableFuture<void>;
    }

    export type $IoSupplier_<Host0 = any, CallbackResult = Host0> = (() => CallbackResult) | $IoSupplier<Host0>;
    export type $PreparableReloadListener_<CallbackArg0 = $PreparableReloadListener$PreparationBarrier, CallbackArg1 = $ResourceManager, CallbackArg2 = $ProfilerFiller, CallbackArg3 = $ProfilerFiller, CallbackArg4 = $Executor, CallbackArg5 = $Executor, CallbackResult = $CompletableFuture<void>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4, arg5: CallbackArg5) => CallbackResult) | $PreparableReloadListener;
    export type $PreparableReloadListener$PreparationBarrier_<CallbackArg0 = any, CallbackResult = $CompletableFuture<any>> = ((arg0: CallbackArg0) => CallbackResult) | $PreparableReloadListener$PreparationBarrier;
    export type $ResourceMetadata_<CallbackArg0 = $MetadataSectionSerializer<any>, CallbackResult = $Optional<any>> = ((arg0: CallbackArg0) => CallbackResult) | $ResourceMetadata;
    export type $ResourceProvider_<CallbackArg0 = $ResourceLocation, CallbackResult = $Optional<$Resource>> = ((arg0: CallbackArg0) => CallbackResult) | $ResourceProvider;
}
