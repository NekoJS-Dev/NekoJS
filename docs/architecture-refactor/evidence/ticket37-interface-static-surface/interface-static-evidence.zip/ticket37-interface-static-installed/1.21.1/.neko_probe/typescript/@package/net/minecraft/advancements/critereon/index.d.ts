import { $StringReader } from "java:com/mojang/brigadier";
import { $DynamicCommandExceptionType, $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Function, $Function_, $Supplier, $Supplier_ } from "java:java/util/function";

declare module "java:net/minecraft/advancements/critereon" {
    export interface $MinMaxBounds<T extends number> {
        isAny(): boolean;
        max(): $Optional<T>;
        min(): $Optional<T>;
        unwrapPoint(): $Optional<T>;
    }
    export const $MinMaxBounds: {
        createCodec<T, R>(arg0: $Codec<T>, arg1: $MinMaxBounds$BoundsFactory_<T, R, $Optional<T>, $Optional<T>, R>): $Codec<R>;
        fromReader<T, R>(arg0: $StringReader, arg1: $MinMaxBounds$BoundsFromReaderFactory_<T, R, $StringReader, $Optional<T>, $Optional<T>, R>, arg2: $Function_<string, T, string, T>, arg3: $Supplier_<$DynamicCommandExceptionType, $DynamicCommandExceptionType>, arg4: $Function_<T, T, T, T>): R;
        readonly ERROR_EMPTY: $SimpleCommandExceptionType;
        readonly ERROR_SWAPPED: $SimpleCommandExceptionType;
    };

    export interface $MinMaxBounds$BoundsFactory<T extends number, R extends $MinMaxBounds<T>> {
        create(arg0: $Optional<T>, arg1: $Optional<T>): R;
    }

    export interface $MinMaxBounds$BoundsFromReaderFactory<T extends number, R extends $MinMaxBounds<T>> {
        create(arg0: $StringReader, arg1: $Optional<T>, arg2: $Optional<T>): R;
    }

    export class $MinMaxBounds$Doubles extends $Record implements $MinMaxBounds<number> {
        constructor(arg0: $Optional<number>, arg1: $Optional<number>, arg2: $Optional<number>, arg3: $Optional<number>);
        static ANY: $MinMaxBounds$Doubles;
        static CODEC: $Codec<$MinMaxBounds$Doubles>;
        static atLeast(arg0: number): $MinMaxBounds$Doubles;
        static atMost(arg0: number): $MinMaxBounds$Doubles;
        static between(arg0: number, arg1: number): $MinMaxBounds$Doubles;
        static exactly(arg0: number): $MinMaxBounds$Doubles;
        static fromReader(arg0: $StringReader, arg1: $Function_<number, number, number, number>): $MinMaxBounds$Doubles;
        static fromReader(arg0: $StringReader): $MinMaxBounds$Doubles;
        equals(arg0: object): boolean;
        hashCode(): number;
        matchesSqr(arg0: number): boolean;
        matches(arg0: number): boolean;
        maxSq(): $Optional<number>;
        max(): $Optional<number>;
        minSq(): $Optional<number>;
        min(): $Optional<number>;
        toString(): string;
    }

    export type $MinMaxBounds$BoundsFactory_<Host0 = any, Host1 = any, CallbackArg0 = $Optional<Host0>, CallbackArg1 = $Optional<Host0>, CallbackResult = Host1> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | $MinMaxBounds$BoundsFactory<Host0, Host1>;
    export type $MinMaxBounds$BoundsFromReaderFactory_<Host0 = any, Host1 = any, CallbackArg0 = $StringReader, CallbackArg1 = $Optional<Host0>, CallbackArg2 = $Optional<Host0>, CallbackResult = Host1> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | $MinMaxBounds$BoundsFromReaderFactory<Host0, Host1>;
}
