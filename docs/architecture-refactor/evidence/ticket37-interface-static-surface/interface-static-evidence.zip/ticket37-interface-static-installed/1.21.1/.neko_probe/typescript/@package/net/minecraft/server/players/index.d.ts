import { $GameProfile } from "java:com/mojang/authlib";
import { $File } from "java:java/io";
import { $SocketAddress } from "java:java/net";
import { $SimpleDateFormat } from "java:java/text";
import { $Collection, $Date, $List, $Optional, $UUID } from "java:java/util";
import { $CompletableFuture, $Executor, $Executor_ } from "java:java/util/concurrent";
import { $Function, $Function_ } from "java:java/util/function";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Connection } from "java:net/minecraft/network";
import { $ChatType$Bound, $Component, $Component_, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer, $PlayerAdvancements } from "java:net/minecraft/server";
import { $ClientInformation, $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $CommonListenerCookie, $ServerGamePacketListenerImpl } from "java:net/minecraft/server/network";
import { $ServerStatsCounter } from "java:net/minecraft/stats";
import { $Entity$RemovalReason, $Entity$RemovalReason_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Level } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/server/players" {
    export class $BanListEntry<T> extends $StoredUserEntry<T> {
        constructor(arg0: T, arg1: $Date, arg2: string, arg3: $Date, arg4: string);
        static DATE_FORMAT: $SimpleDateFormat;
        static EXPIRES_NEVER: string;
        get created(): $Date;
        getCreated(): $Date;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get expires(): $Date;
        getExpires(): $Date;
        get reason(): string;
        getReason(): string;
        get source(): string;
        getSource(): string;
    }

    export class $GameProfileCache {
        constructor(arg0: $GameProfileRepository_<string[], $ProfileLookupCallback>, arg1: string);
        static setUsesAuthentication(arg0: boolean): void;
        add(arg0: $GameProfile): void;
        clearExecutor(): void;
        getAsync(arg0: string): $CompletableFuture<$Optional<$GameProfile>>;
        get(arg0: string): $Optional<$GameProfile>;
        get(arg0: string): $Optional<$GameProfile>;
        load(): $List<$GameProfileCache$GameProfileInfo>;
        save(): void;
    }

    export class $GameProfileCache$GameProfileInfo {
        get expirationDate(): $Date;
        getExpirationDate(): $Date;
        get lastAccess(): number;
        getLastAccess(): number;
        set lastAccess(value: number);
        get profile(): $GameProfile;
        getProfile(): $GameProfile;
    }

    export class $IpBanList extends $StoredUserList<string, $IpBanListEntry> {
        constructor(arg0: string);
        get(arg0: $SocketAddress): $IpBanListEntry;
        isBanned(arg0: string): boolean;
        isBanned(arg0: $SocketAddress): boolean;
    }

    export class $IpBanListEntry extends $BanListEntry<string> {
        constructor(arg0: $JsonObject);
        constructor(arg0: string);
        constructor(arg0: string, arg1: $Date, arg2: string, arg3: $Date, arg4: string);
        get displayName(): $Component;
        getDisplayName(): $Component;
    }

    export class $PlayerList {
        constructor(arg0: $MinecraftServer, arg1: $LayeredRegistryAccess<$RegistryLayer_>, arg2: $PlayerDataStorage, arg3: number);
        static CHAT_FILTERED_FULL: $Component;
        static DUPLICATE_LOGIN_DISCONNECT_MESSAGE: $Component;
        static IPBANLIST_FILE: $File;
        static OPLIST_FILE: $File;
        static USERBANLIST_FILE: $File;
        static WHITELIST_FILE: $File;
        get bans(): $UserBanList;
        getBans(): $UserBanList;
        get ipBans(): $IpBanList;
        getIpBans(): $IpBanList;
        get maxPlayers(): number;
        getMaxPlayers(): number;
        get opNames(): string[];
        getOpNames(): string[];
        get ops(): $ServerOpList;
        getOps(): $ServerOpList;
        get playerCount(): number;
        getPlayerCount(): number;
        get playerNamesArray(): string[];
        getPlayerNamesArray(): string[];
        get players(): $List<$ServerPlayer>;
        getPlayers(): $List<$ServerPlayer>;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get simulationDistance(): number;
        getSimulationDistance(): number;
        set simulationDistance(value: number);
        get singleplayerData(): $CompoundTag;
        getSingleplayerData(): $CompoundTag;
        get viewDistance(): number;
        getViewDistance(): number;
        set viewDistance(value: number);
        get whiteListNames(): string[];
        getWhiteListNames(): string[];
        get whiteList(): $UserWhiteList;
        getWhiteList(): $UserWhiteList;
        get allowCommandsForAllPlayers(): boolean;
        isAllowCommandsForAllPlayers(): boolean;
        set allowCommandsForAllPlayers(value: boolean);
        get usingWhitelist(): boolean;
        isUsingWhitelist(): boolean;
        addWorldborderListener(arg0: $ServerLevel): void;
        broadcastAll(arg0: $Packet<any>, arg1: $ResourceKey<$Level>): void;
        broadcastAll(arg0: $Packet<any>): void;
        broadcastChatMessage(arg0: $PlayerChatMessage, arg1: $CommandSourceStack, arg2: $ChatType$Bound): void;
        broadcastChatMessage(arg0: $PlayerChatMessage, arg1: $ServerPlayer, arg2: $ChatType$Bound): void;
        broadcastSystemMessage(arg0: $Component_, arg1: boolean): void;
        broadcastSystemMessage(arg0: $Component_, arg1: $Function_<$ServerPlayer, $Component, $ServerPlayer, $Component_>, arg2: boolean): void;
        broadcastSystemToAllExceptTeam(arg0: $Player, arg1: $Component_): void;
        broadcastSystemToTeam(arg0: $Player, arg1: $Component_): void;
        broadcast(arg0: $Player, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $ResourceKey<$Level>, arg6: $Packet<any>): void;
        canBypassPlayerLimit(arg0: $GameProfile): boolean;
        canPlayerLogin(arg0: $SocketAddress, arg1: $GameProfile): $Component;
        deop(arg0: $GameProfile): void;
        disconnectAllPlayersWithProfile(arg0: $GameProfile): boolean;
        getPlayerAdvancements(arg0: $ServerPlayer): $PlayerAdvancements;
        getPlayerByName(arg0: string): $ServerPlayer;
        getPlayerForLogin(arg0: $GameProfile, arg1: $ClientInformation): $ServerPlayer;
        getPlayerStats(arg0: $Player): $ServerStatsCounter;
        getPlayersWithAddress(arg0: string): $List<$ServerPlayer>;
        getPlayer(arg0: string): $ServerPlayer;
        isOp(arg0: $GameProfile): boolean;
        isWhiteListed(arg0: $GameProfile): boolean;
        load(arg0: $ServerPlayer): $Optional<$CompoundTag>;
        op(arg0: $GameProfile): void;
        placeNewPlayer(arg0: $Connection, arg1: $ServerPlayer, arg2: $CommonListenerCookie): void;
        reloadResources(): void;
        reloadWhiteList(): void;
        removeAll(): void;
        remove(arg0: $ServerPlayer): void;
        respawn(arg0: $ServerPlayer, arg1: boolean, arg2: $Entity$RemovalReason_): $ServerPlayer;
        saveAll(): void;
        sendActiveEffects(arg0: $LivingEntity, arg1: $ServerGamePacketListenerImpl): void;
        sendActivePlayerEffects(arg0: $ServerPlayer): void;
        sendAllPlayerInfo(arg0: $ServerPlayer): void;
        sendLevelInfo(arg0: $ServerPlayer, arg1: $ServerLevel): void;
        sendPlayerPermissionLevel(arg0: $ServerPlayer): void;
        tick(): void;
    }

    export class $ServerOpList extends $StoredUserList<$GameProfile, $ServerOpListEntry> {
        constructor(arg0: string);
        get userList(): string[];
        getUserList(): string[];
        canBypassPlayerLimit(arg0: $GameProfile): boolean;
    }

    export class $ServerOpListEntry extends $StoredUserEntry<$GameProfile> {
        constructor(arg0: $JsonObject);
        constructor(arg0: $GameProfile, arg1: number, arg2: boolean);
        get bypassesPlayerLimit(): boolean;
        getBypassesPlayerLimit(): boolean;
        get level(): number;
        getLevel(): number;
    }

    export class $StoredUserEntry<T> {
        constructor(arg0: T);
    }

    export class $StoredUserList<K, V extends $StoredUserEntry<K>> {
        constructor(arg0: string);
        get entries(): $Collection<V>;
        getEntries(): $Collection<V>;
        get file(): $File;
        getFile(): $File;
        get userList(): string[];
        getUserList(): string[];
        get empty(): boolean;
        isEmpty(): boolean;
        add(arg0: V): void;
        get(arg0: K): V;
        load(): void;
        remove(arg0: K): void;
        remove(arg0: $StoredUserEntry<K>): void;
        save(): void;
    }

    export class $UserBanList extends $StoredUserList<$GameProfile, $UserBanListEntry> {
        constructor(arg0: string);
        get userList(): string[];
        getUserList(): string[];
        isBanned(arg0: $GameProfile): boolean;
    }

    export class $UserBanListEntry extends $BanListEntry<$GameProfile> {
        constructor(arg0: $JsonObject);
        constructor(arg0: $GameProfile);
        constructor(arg0: $GameProfile, arg1: $Date, arg2: string, arg3: $Date, arg4: string);
        get displayName(): $Component;
        getDisplayName(): $Component;
    }

    export class $UserWhiteList extends $StoredUserList<$GameProfile, $UserWhiteListEntry> {
        constructor(arg0: string);
        get userList(): string[];
        getUserList(): string[];
        isWhiteListed(arg0: $GameProfile): boolean;
    }

    export class $UserWhiteListEntry extends $StoredUserEntry<$GameProfile> {
        constructor(arg0: $JsonObject);
        constructor(arg0: $GameProfile);
    }

}
