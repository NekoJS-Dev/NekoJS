import { $FamilyOptic, $FamilyOptic_, $RewriteResult, $TypeRewriteRule, $TypeRewriteRule_, $Typed, $TypedOptic, $View } from "java:com/mojang/datafixers";
import { $PointFreeRule, $PointFreeRule_ } from "java:com/mojang/datafixers/functions";
import { $Type, $Type$FieldNotFoundException, $Type$TypeMatcher, $Type$TypeMatcher_ } from "java:com/mojang/datafixers/types";
import { $RecursiveTypeFamily, $TypeFamily, $TypeFamily_ } from "java:com/mojang/datafixers/types/families";
import { $Either, $Pair } from "java:com/mojang/datafixers/util";
import { $DynamicOps } from "java:com/mojang/serialization";
import { $Map, $Optional } from "java:java/util";
import { $IntFunction, $IntFunction_ } from "java:java/util/function";

declare module "java:com/mojang/datafixers/types/templates" {
    export class $RecursivePoint$RecursivePointType<A> extends $Type<A> {
        constructor(arg0: $RecursiveTypeFamily, arg1: number, arg2: $Supplier_<$Type<A>, $Type<A>>);
        all(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: boolean, arg2: boolean): $RewriteResult<A, any>;
        buildTemplate(): $TypeTemplate;
        equals(arg0: object, arg1: boolean, arg2: boolean): boolean;
        everywhere(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>, arg2: boolean, arg3: boolean): $Optional<$RewriteResult<A, any>>;
        family(): $RecursiveTypeFamily;
        findCheckedType(arg0: number): $Optional<$Type<any>>;
        findChoiceType(arg0: string, arg1: number): $Optional<$TaggedChoice$TaggedChoiceType<any>>;
        findFieldTypeOpt(arg0: string): $Optional<$Type<any>>;
        findTypeInChildren<FT, FR>(arg0: $Type<FT>, arg1: $Type<FR>, arg2: $Type$TypeMatcher_<FT, FR, $Type<any>, $Either<$TypedOptic<any, any, FT, FR>, $Type$FieldNotFoundException>>, arg3: boolean): $Either<$TypedOptic<A, any, FT, FR>, $Type$FieldNotFoundException>;
        hashCode(): number;
        index(): number;
        in(): $View<A, A>;
        one(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>): $Optional<$RewriteResult<A, any>>;
        out(): $View<A, A>;
        point(arg0: $DynamicOps<any>): $Optional<A>;
        toString(): string;
        unfold(): $Type<A>;
        updateMu(arg0: $RecursiveTypeFamily): $Type<any>;
    }

    export class $TaggedChoice$TaggedChoiceType<K> extends $Type<$Pair<K, any>> {
        constructor(arg0: string, arg1: $Type<K>, arg2: $Object2ObjectMap<K, $Type<any>>);
        get keyType(): $Type<K>;
        getKeyType(): $Type<K>;
        get name(): string;
        getName(): string;
        static elementResult<K, FT, FR>(arg0: K, arg1: $TaggedChoice$TaggedChoiceType<K>, arg2: $RewriteResult<FT, FR>): $RewriteResult<$Pair<K, any>, $Pair<K, any>>;
        all(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: boolean, arg2: boolean): $RewriteResult<$Pair<K, any>, any>;
        buildTemplate(): $TypeTemplate;
        equals(arg0: object, arg1: boolean, arg2: boolean): boolean;
        findCheckedType(arg0: number): $Optional<$Type<any>>;
        findChoiceType(arg0: string, arg1: number): $Optional<$TaggedChoice$TaggedChoiceType<any>>;
        findFieldTypeOpt(arg0: string): $Optional<$Type<any>>;
        findTypeInChildren<FT, FR>(arg0: $Type<FT>, arg1: $Type<FR>, arg2: $Type$TypeMatcher_<FT, FR, $Type<any>, $Either<$TypedOptic<any, any, FT, FR>, $Type$FieldNotFoundException>>, arg3: boolean): $Either<$TypedOptic<$Pair<K, any>, any, FT, FR>, $Type$FieldNotFoundException>;
        hasType(arg0: K): boolean;
        hashCode(): number;
        one(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>): $Optional<$RewriteResult<$Pair<K, any>, any>>;
        point(arg0: $DynamicOps<any>, arg1: K, arg2: object): $Optional<$Typed<$Pair<K, any>>>;
        point(arg0: $DynamicOps<any>): $Optional<$Pair<K, any>>;
        toString(): string;
        types(): $Map<K, $Type<any>>;
        updateMu(arg0: $RecursiveTypeFamily): $Type<any>;
    }

    export interface $TypeTemplate {
        applyO<A, B>(arg0: $FamilyOptic_<A, B, number, $TypedOptic<any, any, A, B>>, arg1: $Type<A>, arg2: $Type<B>): $FamilyOptic<A, B>;
        apply(arg0: $TypeFamily_<number, $Type<any>>): $TypeFamily;
        findFieldOrType<A, B>(arg0: number, arg1: string, arg2: $Type<A>, arg3: $Type<B>): $Either<$TypeTemplate, $Type$FieldNotFoundException>;
        hmap(arg0: $TypeFamily_<number, $Type<any>>, arg1: $IntFunction_<$RewriteResult<any, any>, number, $RewriteResult<any, any>>): $IntFunction<$RewriteResult<any, any>>;
        size(): number;
        toSimpleType(): $Type<any>;
    }

}
