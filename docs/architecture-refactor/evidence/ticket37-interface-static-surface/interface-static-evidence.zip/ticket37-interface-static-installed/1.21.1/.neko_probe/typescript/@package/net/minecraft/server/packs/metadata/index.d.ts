import { $JsonObject } from "java:com/google/gson";
import { $Codec } from "java:com/mojang/serialization";

export * as pack from "java:net/minecraft/server/packs/metadata/pack";

declare module "java:net/minecraft/server/packs/metadata" {
    export interface $MetadataSectionSerializer<T> {
        fromJson(arg0: $JsonObject): T;
        getMetadataSectionName(): string;
    }

    export interface $MetadataSectionType<T> extends $MetadataSectionSerializer<T> {
        toJson(arg0: T): $JsonObject;
    }
    export const $MetadataSectionType: {
        fromCodec<T>(arg0: string, arg1: $Codec<T>): $MetadataSectionType<T>;
    };

}
