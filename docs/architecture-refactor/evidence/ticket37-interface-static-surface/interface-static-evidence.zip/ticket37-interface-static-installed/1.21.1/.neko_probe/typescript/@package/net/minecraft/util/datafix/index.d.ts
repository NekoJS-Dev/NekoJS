import { $DSL$TypeReference, $DSL$TypeReference_, $DataFixer } from "java:com/mojang/datafixers";
import { $Codec, $Dynamic } from "java:com/mojang/serialization";
import { $Set } from "java:java/util";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";

declare module "java:net/minecraft/util/datafix" {
    export class $DataFixTypes {
        static ADVANCEMENTS: $DataFixTypes;
        static CHUNK: $DataFixTypes;
        static ENTITY_CHUNK: $DataFixTypes;
        static HOTBAR: $DataFixTypes;
        static LEVEL: $DataFixTypes;
        static OPTIONS: $DataFixTypes;
        static PLAYER: $DataFixTypes;
        static POI_CHUNK: $DataFixTypes;
        static SAVED_DATA_COMMAND_STORAGE: $DataFixTypes;
        static SAVED_DATA_FORCED_CHUNKS: $DataFixTypes;
        static SAVED_DATA_MAP_DATA: $DataFixTypes;
        static SAVED_DATA_MAP_INDEX: $DataFixTypes;
        static SAVED_DATA_RAIDS: $DataFixTypes;
        static SAVED_DATA_RANDOM_SEQUENCES: $DataFixTypes;
        static SAVED_DATA_SCOREBOARD: $DataFixTypes;
        static SAVED_DATA_STRUCTURE_FEATURE_INDICES: $DataFixTypes;
        static STATS: $DataFixTypes;
        static STRUCTURE: $DataFixTypes;
        static WORLD_GEN_SETTINGS: $DataFixTypes;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DataFixTypes[];
        static valueOf(name: string): $DataFixTypes;
    }

    export type $DataFixTypes_ = $DataFixTypes | "ADVANCEMENTS" | "CHUNK" | "ENTITY_CHUNK" | "HOTBAR" | "LEVEL" | "OPTIONS" | "PLAYER" | "POI_CHUNK" | "SAVED_DATA_COMMAND_STORAGE" | "SAVED_DATA_FORCED_CHUNKS" | "SAVED_DATA_MAP_DATA" | "SAVED_DATA_MAP_INDEX" | "SAVED_DATA_RAIDS" | "SAVED_DATA_RANDOM_SEQUENCES" | "SAVED_DATA_SCOREBOARD" | "SAVED_DATA_STRUCTURE_FEATURE_INDICES" | "STATS" | "STRUCTURE" | "WORLD_GEN_SETTINGS";
}
