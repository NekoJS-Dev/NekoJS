import { $App, $Applicative, $Applicative$Mu, $K1 } from "java:com/mojang/datafixers/kinds";
import { $Either, $Function3, $Function3_, $Pair, $Unit, $Unit_ } from "java:com/mojang/datafixers/util";
import { $PrimitiveCodec, $RecordCodecBuilder, $SimpleMapCodec, $UnboundedMapCodec } from "java:com/mojang/serialization/codecs";
import { $Iterable, $Record } from "java:java/lang";
import { $ByteBuffer } from "java:java/nio";
import { $List, $Map, $Optional } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function, $Function_, $Supplier, $Supplier_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $IntStream, $LongStream, $Stream } from "java:java/util/stream";

export * as codecs from "java:com/mojang/serialization/codecs";

declare module "java:com/mojang/serialization" {
    export interface $Codec<A> extends $Encoder<A>, $Decoder<A> {
        comapFlatMap<S>(arg0: $Function_<A, $DataResult<S>, A, $DataResult<S>>, arg1: $Function_<S, A, S, A>): $Codec<S>;
        deprecated(arg0: number): $Codec<A>;
        dispatchMap<E>(arg0: string, arg1: $Function_<E, A, E, A>, arg2: $Function_<A, $MapCodec<E>, A, $MapCodec<E>>): $MapCodec<E>;
        dispatchMap<E>(arg0: $Function_<E, A, E, A>, arg1: $Function_<A, $MapCodec<E>, A, $MapCodec<E>>): $MapCodec<E>;
        dispatchStable<E>(arg0: $Function_<E, A, E, A>, arg1: $Function_<A, $MapCodec<E>, A, $MapCodec<E>>): $Codec<E>;
        dispatch<E>(arg0: string, arg1: $Function_<E, A, E, A>, arg2: $Function_<A, $MapCodec<E>, A, $MapCodec<E>>): $Codec<E>;
        dispatch<E>(arg0: $Function_<E, A, E, A>, arg1: $Function_<A, $MapCodec<E>, A, $MapCodec<E>>): $Codec<E>;
        fieldOf(arg0: string): $MapCodec<A>;
        flatComapMap<S>(arg0: $Function_<A, S, A, S>, arg1: $Function_<S, $DataResult<A>, S, $DataResult<A>>): $Codec<S>;
        flatXmap<S>(arg0: $Function_<A, $DataResult<S>, A, $DataResult<S>>, arg1: $Function_<S, $DataResult<A>, S, $DataResult<A>>): $Codec<S>;
        lenientOptionalFieldOf(arg0: string, arg1: A, arg2: $Lifecycle): $MapCodec<A>;
        lenientOptionalFieldOf(arg0: string, arg1: A): $MapCodec<A>;
        lenientOptionalFieldOf(arg0: string, arg1: $Lifecycle, arg2: A, arg3: $Lifecycle): $MapCodec<A>;
        lenientOptionalFieldOf(arg0: string): $MapCodec<$Optional<A>>;
        listOf(arg0: number, arg1: number): $Codec<$List<A>>;
        listOf(): $Codec<$List<A>>;
        mapResult(arg0: $Codec$ResultFunction<A>): $Codec<A>;
        optionalFieldOf(arg0: string, arg1: A, arg2: $Lifecycle): $MapCodec<A>;
        optionalFieldOf(arg0: string, arg1: A): $MapCodec<A>;
        optionalFieldOf(arg0: string, arg1: $Lifecycle, arg2: A, arg3: $Lifecycle): $MapCodec<A>;
        optionalFieldOf(arg0: string): $MapCodec<$Optional<A>>;
        orElseGet(arg0: $Consumer_<string, string>, arg1: $Supplier_<A, A>): $Codec<A>;
        orElseGet(arg0: $Supplier_<A, A>): $Codec<A>;
        orElseGet(arg0: $UnaryOperator_<string, string, string>, arg1: $Supplier_<A, A>): $Codec<A>;
        orElse(arg0: A): $Codec<A>;
        orElse(arg0: $Consumer_<string, string>, arg1: A): $Codec<A>;
        orElse(arg0: $UnaryOperator_<string, string, string>, arg1: A): $Codec<A>;
        partialDispatch<E>(arg0: string, arg1: $Function_<E, $DataResult<A>, E, $DataResult<A>>, arg2: $Function_<A, $DataResult<$MapCodec<E>>, A, $DataResult<$MapCodec<E>>>): $Codec<E>;
        promotePartial(arg0: $Consumer_<string, string>): $Codec<A>;
        sizeLimitedListOf(arg0: number): $Codec<$List<A>>;
        stable(): $Codec<A>;
        validate(arg0: $Function_<A, $DataResult<A>, A, $DataResult<A>>): $Codec<A>;
        withLifecycle(arg0: $Lifecycle): $Codec<A>;
        xmap<S>(arg0: $Function_<A, S, A, S>, arg1: $Function_<S, A, S, A>): $Codec<S>;
    }
    export const $Codec: {
        checkRange<N>(arg0: N, arg1: N): $Function<N, $DataResult<N>>;
        compoundList<K, V>(arg0: $Codec<K>, arg1: $Codec<V>): $Codec<$List<$Pair<K, V>>>;
        dispatchedMap<K, V>(arg0: $Codec<K>, arg1: $Function_<K, $Codec<V>, K, $Codec<V>>): $Codec<$Map<K, V>>;
        doubleRange(arg0: number, arg1: number): $Codec<number>;
        either<F, S>(arg0: $Codec<F>, arg1: $Codec<S>): $Codec<$Either<F, S>>;
        floatRange(arg0: number, arg1: number): $Codec<number>;
        intRange(arg0: number, arg1: number): $Codec<number>;
        lazyInitialized<A>(arg0: $Supplier_<$Codec<A>, $Codec<A>>): $Codec<A>;
        list<E>(arg0: $Codec<E>, arg1: number, arg2: number): $Codec<$List<E>>;
        list<E>(arg0: $Codec<E>): $Codec<$List<E>>;
        mapEither<F, S>(arg0: $MapCodec<F>, arg1: $MapCodec<S>): $MapCodec<$Either<F, S>>;
        mapPair<F, S>(arg0: $MapCodec<F>, arg1: $MapCodec<S>): $MapCodec<$Pair<F, S>>;
        of<A>(arg0: $Encoder_<A, A, $DynamicOps<any>, any, $DataResult<any>>, arg1: $Decoder_<A, $DynamicOps<any>, any, $DataResult<$Pair<A, any>>>, arg2: string): $Codec<A>;
        of<A>(arg0: $Encoder_<A, A, $DynamicOps<any>, any, $DataResult<any>>, arg1: $Decoder_<A, $DynamicOps<any>, any, $DataResult<$Pair<A, any>>>): $Codec<A>;
        of<A>(arg0: $MapEncoder<A>, arg1: $MapDecoder<A>, arg2: $Supplier_<string, string>): $MapCodec<A>;
        of<A>(arg0: $MapEncoder<A>, arg1: $MapDecoder<A>): $MapCodec<A>;
        optionalField<F>(arg0: string, arg1: $Codec<F>, arg2: boolean): $MapCodec<$Optional<F>>;
        pair<F, S>(arg0: $Codec<F>, arg1: $Codec<S>): $Codec<$Pair<F, S>>;
        recursive<A>(arg0: string, arg1: $Function_<$Codec<A>, $Codec<A>, $Codec<A>, $Codec<A>>): $Codec<A>;
        simpleMap<K, V>(arg0: $Codec<K>, arg1: $Codec<V>, arg2: $Keyable_<$DynamicOps<any>, $Stream<any>>): $SimpleMapCodec<K, V>;
        sizeLimitedString(arg0: number): $Codec<string>;
        stringResolver<E>(arg0: $Function_<E, string, E, string>, arg1: $Function_<string, E, string, E>): $Codec<E>;
        string(arg0: number, arg1: number): $Codec<string>;
        unboundedMap<K, V>(arg0: $Codec<K>, arg1: $Codec<V>): $UnboundedMapCodec<K, V>;
        unit<A>(arg0: A): $Codec<A>;
        unit<A>(arg0: $Supplier_<A, A>): $Codec<A>;
        withAlternative<T>(arg0: $Codec<T>, arg1: $Codec<T>): $Codec<T>;
        withAlternative<T, U>(arg0: $Codec<T>, arg1: $Codec<U>, arg2: $Function_<U, T, U, T>): $Codec<T>;
        xor<F, S>(arg0: $Codec<F>, arg1: $Codec<S>): $Codec<$Either<F, S>>;
        readonly BOOL: $PrimitiveCodec<boolean>;
        readonly BYTE: $PrimitiveCodec<number>;
        readonly BYTE_BUFFER: $PrimitiveCodec<$ByteBuffer>;
        readonly DOUBLE: $PrimitiveCodec<number>;
        readonly EMPTY: $MapCodec<$Unit>;
        readonly FLOAT: $PrimitiveCodec<number>;
        readonly INT: $PrimitiveCodec<number>;
        readonly INT_STREAM: $PrimitiveCodec<$IntStream>;
        readonly LONG: $PrimitiveCodec<number>;
        readonly LONG_STREAM: $PrimitiveCodec<$LongStream>;
        readonly PASSTHROUGH: $Codec<$Dynamic<any>>;
        readonly SHORT: $PrimitiveCodec<number>;
        readonly STRING: $PrimitiveCodec<string>;
    };

    export interface $Codec$ResultFunction<A> {
        apply<T>(arg0: $DynamicOps<T>, arg1: T, arg2: $DataResult<$Pair<A, T>>): $DataResult<$Pair<A, T>>;
        coApply<T>(arg0: $DynamicOps<T>, arg1: A, arg2: $DataResult<T>): $DataResult<T>;
    }

    export interface $Compressable extends $Keyable {
        compressor<T>(arg0: $DynamicOps<T>): $KeyCompressor<T>;
    }

    export class $CompressorHolder implements $Compressable {
        constructor();
        compressor<T>(arg0: $DynamicOps<T>): $KeyCompressor<T>;
    }

    export interface $DataResult<R> extends $App<$DataResult$Mu, R> {
        addLifecycle(arg0: $Lifecycle): $DataResult<R>;
        apply2stable<R2, S>(arg0: $BiFunction_<R, R2, S, R, R2, S>, arg1: $DataResult<R2>): $DataResult<S>;
        apply2<R2, S>(arg0: $BiFunction_<R, R2, S, R, R2, S>, arg1: $DataResult<R2>): $DataResult<S>;
        apply3<R2, R3, S>(arg0: $Function3_<R, R2, R3, S, R, R2, R3, S>, arg1: $DataResult<R2>, arg2: $DataResult<R3>): $DataResult<S>;
        ap<R2>(arg0: $DataResult<$Function_<R, R2, R, R2>>): $DataResult<R2>;
        error(): $Optional<$DataResult$Error<R>>;
        flatMap<R2>(arg0: $Function_<R, $DataResult<R2>, R, $DataResult<R2>>): $DataResult<R2>;
        getOrThrow<E>(arg0: $Function_<string, E, string, E>): R;
        getOrThrow(): R;
        getPartialOrThrow<E>(arg0: $Function_<string, E, string, E>): R;
        getPartialOrThrow(): R;
        hasResultOrPartial(): boolean;
        ifError(arg0: $Consumer_<$DataResult$Error<R>, $DataResult$Error<R>>): $DataResult<R>;
        ifSuccess(arg0: $Consumer_<R, R>): $DataResult<R>;
        isError(): boolean;
        isSuccess(): boolean;
        lifecycle(): $Lifecycle;
        mapError(arg0: $UnaryOperator_<string, string, string>): $DataResult<R>;
        mapOrElse<T>(arg0: $Function_<R, T, R, T>, arg1: $Function_<$DataResult$Error<R>, T, $DataResult$Error<R>, T>): T;
        map<T>(arg0: $Function_<R, T, R, T>): $DataResult<T>;
        promotePartial(arg0: $Consumer_<string, string>): $DataResult<R>;
        resultOrPartial(arg0: $Consumer_<string, string>): $Optional<R>;
        resultOrPartial(): $Optional<R>;
        result(): $Optional<R>;
        setLifecycle(arg0: $Lifecycle): $DataResult<R>;
        setPartial(arg0: R): $DataResult<R>;
        setPartial(arg0: $Supplier_<R, R>): $DataResult<R>;
    }
    export const $DataResult: {
        appendMessages(arg0: string, arg1: string): string;
        error<R>(arg0: $Supplier_<string, string>, arg1: R, arg2: $Lifecycle): $DataResult<R>;
        error<R>(arg0: $Supplier_<string, string>, arg1: R): $DataResult<R>;
        error<R>(arg0: $Supplier_<string, string>, arg1: $Lifecycle): $DataResult<R>;
        error<R>(arg0: $Supplier_<string, string>): $DataResult<R>;
        instance(): $DataResult$Instance;
        partialGet<K, V>(arg0: $Function_<K, V, K, V>, arg1: $Supplier_<string, string>): $Function<K, $DataResult<V>>;
        success<R>(arg0: R, arg1: $Lifecycle): $DataResult<R>;
        success<R>(arg0: R): $DataResult<R>;
        unbox<R>(arg0: $App<$DataResult$Mu, R>): $DataResult<R>;
    };

    export class $DataResult$Error<R> extends $Record implements $DataResult<R> {
        constructor(messageSupplier: $Supplier_<string, string>, partialValue: $Optional<R>, lifecycle: $Lifecycle);
        get success(): boolean;
        isSuccess(): boolean;
        ap<R2>(arg0: $DataResult<$Function_<R, R2, R, R2>>): $DataResult$Error<R2>;
        equals(arg0: object): boolean;
        error(): $Optional<$DataResult$Error<R>>;
        flatMap<R2>(arg0: $Function_<R, $DataResult<R2>, R, $DataResult<R2>>): $DataResult$Error<R2>;
        getOrThrow<E>(arg0: $Function_<string, E, string, E>): R;
        getPartialOrThrow<E>(arg0: $Function_<string, E, string, E>): R;
        hasResultOrPartial(): boolean;
        hashCode(): number;
        ifError(arg0: $Consumer_<$DataResult$Error<R>, $DataResult$Error<R>>): $DataResult<R>;
        ifSuccess(arg0: $Consumer_<R, R>): $DataResult<R>;
        lifecycle(): $Lifecycle;
        mapError(arg0: $UnaryOperator_<string, string, string>): $DataResult$Error<R>;
        mapOrElse<T>(arg0: $Function_<R, T, R, T>, arg1: $Function_<$DataResult$Error<R>, T, $DataResult$Error<R>, T>): T;
        map<T>(arg0: $Function_<R, T, R, T>): $DataResult$Error<T>;
        messageSupplier(): $Supplier<string>;
        message(): string;
        partialValue(): $Optional<R>;
        promotePartial(arg0: $Consumer_<string, string>): $DataResult<R>;
        resultOrPartial(arg0: $Consumer_<string, string>): $Optional<R>;
        resultOrPartial(): $Optional<R>;
        result(): $Optional<R>;
        toString(): string;
    }

    export class $DataResult$Instance {
        static INSTANCE: $DataResult$Instance;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DataResult$Instance[];
        static valueOf(name: string): $DataResult$Instance;
    }

    export class $DataResult$Instance$Mu implements $Applicative$Mu {
        constructor();
    }

    export class $DataResult$Mu implements $K1 {
        constructor();
    }

    export interface $Decoder<A> {
        boxed(): $Decoder$Boxed<A>;
        decode<T>(arg0: $Dynamic<T>): $DataResult<$Pair<A, T>>;
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<A, T>>;
        fieldOf(arg0: string): $MapDecoder<A>;
        flatMap<B>(arg0: $Function_<A, $DataResult<B>, A, $DataResult<B>>): $Decoder<B>;
        map<B>(arg0: $Function_<A, B, A, B>): $Decoder<B>;
        parse<T>(arg0: $Dynamic<T>): $DataResult<A>;
        parse<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<A>;
        promotePartial(arg0: $Consumer_<string, string>): $Decoder<A>;
        simple(): $Decoder$Simple<A>;
        terminal(): $Decoder$Terminal<A>;
        withLifecycle(arg0: $Lifecycle): $Decoder<A>;
    }
    export const $Decoder: {
        error<A>(arg0: string): $Decoder<A>;
        ofBoxed<A>(arg0: $Decoder$Boxed_<A, $Dynamic<any>, $DataResult<$Pair<A, any>>>): $Decoder<A>;
        ofSimple<A>(arg0: $Decoder$Simple_<A, $Dynamic<any>, $DataResult<A>>): $Decoder<A>;
        ofTerminal<A>(arg0: $Decoder$Terminal_<A, $DynamicOps<any>, any, $DataResult<A>>): $Decoder<A>;
        unit<A>(arg0: A): $MapDecoder<A>;
        unit<A>(arg0: $Supplier_<A, A>): $MapDecoder<A>;
    };

    export interface $Decoder$Boxed<A> {
        decoder(): $Decoder<A>;
        decode<T>(arg0: $Dynamic<T>): $DataResult<$Pair<A, T>>;
    }

    export interface $Decoder$Simple<A> {
        decoder(): $Decoder<A>;
        decode<T>(arg0: $Dynamic<T>): $DataResult<A>;
    }

    export interface $Decoder$Terminal<A> {
        decoder(): $Decoder<A>;
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<A>;
    }

    export class $Dynamic<T> extends $DynamicLike<T> {
        constructor(arg0: $DynamicOps<T>);
        constructor(arg0: $DynamicOps<T>, arg1: T);
        get mapValues(): $DataResult<$Map<$Dynamic<T>, $Dynamic<T>>>;
        getMapValues(): $DataResult<$Map<$Dynamic<T>, $Dynamic<T>>>;
        get value(): T;
        getValue(): T;
        static convert<S, T>(arg0: $DynamicOps<S>, arg1: $DynamicOps<T>, arg2: S): T;
        static copyAndFixField<T>(arg0: $Dynamic<T>, arg1: string, arg2: $Dynamic<any>, arg3: string, arg4: $UnaryOperator_<$Dynamic<T>, $Dynamic<T>, $Dynamic<T>>): $Dynamic<any>;
        static copyField(arg0: $Dynamic<any>, arg1: string, arg2: $Dynamic<any>, arg3: string): $Dynamic<any>;
        asBoolean(): $DataResult<boolean>;
        asByteBufferOpt(): $DataResult<$ByteBuffer>;
        asIntStreamOpt(): $DataResult<$IntStream>;
        asLongStreamOpt(): $DataResult<$LongStream>;
        asMapOpt(): $DataResult<$Stream<$Pair<$Dynamic<T>, $Dynamic<T>>>>;
        asNumber(): $DataResult<number>;
        asStreamOpt(): $DataResult<$Stream<$Dynamic<T>>>;
        asString(): $DataResult<string>;
        castTyped<U>(arg0: $DynamicOps<U>): $Dynamic<U>;
        cast<U>(arg0: $DynamicOps<U>): U;
        convert<R>(arg0: $DynamicOps<R>): $Dynamic<R>;
        decode<A>(arg0: $Decoder_<A, $DynamicOps<any>, any, $DataResult<$Pair<A, any>>>): $DataResult<$Pair<A, T>>;
        equals(arg0: object): boolean;
        getElementGeneric(arg0: T): $DataResult<T>;
        getElement(arg0: string): $DataResult<T>;
        getGeneric(arg0: T): $DataResult<T>;
        get(arg0: string): $OptionalDynamic<T>;
        hashCode(): number;
        into<V>(arg0: $Function_<$Dynamic<T>, V, $Dynamic<T>, V>): V;
        map(arg0: $Function_<T, T, T, T>): $Dynamic<T>;
        merge(arg0: $Dynamic<any>, arg1: $Dynamic<any>): $OptionalDynamic<T>;
        merge(arg0: $Dynamic<any>): $OptionalDynamic<T>;
        remove(arg0: string): $Dynamic<T>;
        renameAndFixField(arg0: string, arg1: string, arg2: $UnaryOperator_<$Dynamic<any>, $Dynamic<any>, $Dynamic<any>>): $Dynamic<T>;
        renameField(arg0: string, arg1: string): $Dynamic<T>;
        replaceField(arg0: string, arg1: string, arg2: $Optional<$Dynamic<any>>): $Dynamic<T>;
        setFieldIfPresent(arg0: string, arg1: $Optional<$Dynamic<any>>): $Dynamic<T>;
        set(arg0: string, arg1: $Dynamic<any>): $Dynamic<T>;
        toString(): string;
        updateGeneric(arg0: T, arg1: $Function_<T, T, T, T>): $Dynamic<T>;
        updateMapValues(arg0: $Function_<$Pair<$Dynamic<any>, $Dynamic<any>>, $Pair<$Dynamic<any>, $Dynamic<any>>, $Pair<$Dynamic<any>, $Dynamic<any>>, $Pair<$Dynamic<any>, $Dynamic<any>>>): $Dynamic<T>;
        update(arg0: string, arg1: $Function_<$Dynamic<any>, $Dynamic<any>, $Dynamic<any>, $Dynamic<any>>): $Dynamic<T>;
    }

    export class $DynamicLike<T> {
        constructor(arg0: $DynamicOps<T>);
        get ops(): $DynamicOps<T>;
        getOps(): $DynamicOps<T>;
        asBoolean(arg0: boolean): boolean;
        asBoolean(): $DataResult<boolean>;
        asByteBufferOpt(): $DataResult<$ByteBuffer>;
        asByteBuffer(): $ByteBuffer;
        asByte(arg0: number): number;
        asDouble(arg0: number): number;
        asFloat(arg0: number): number;
        asIntStreamOpt(): $DataResult<$IntStream>;
        asIntStream(): $IntStream;
        asInt(arg0: number): number;
        asListOpt<U>(arg0: $Function_<$Dynamic<T>, U, $Dynamic<T>, U>): $DataResult<$List<U>>;
        asList<U>(arg0: $Function_<$Dynamic<T>, U, $Dynamic<T>, U>): $List<U>;
        asLongStreamOpt(): $DataResult<$LongStream>;
        asLongStream(): $LongStream;
        asLong(arg0: number): number;
        asMapOpt<K, V>(arg0: $Function_<$Dynamic<T>, K, $Dynamic<T>, K>, arg1: $Function_<$Dynamic<T>, V, $Dynamic<T>, V>): $DataResult<$Map<K, V>>;
        asMapOpt(): $DataResult<$Stream<$Pair<$Dynamic<T>, $Dynamic<T>>>>;
        asMap<K, V>(arg0: $Function_<$Dynamic<T>, K, $Dynamic<T>, K>, arg1: $Function_<$Dynamic<T>, V, $Dynamic<T>, V>): $Map<K, V>;
        asNumber(arg0: number): number;
        asNumber(): $DataResult<number>;
        asShort(arg0: number): number;
        asStreamOpt(): $DataResult<$Stream<$Dynamic<T>>>;
        asStream(): $Stream<$Dynamic<T>>;
        asString(arg0: string): string;
        asString(): $DataResult<string>;
        createBoolean(arg0: boolean): $Dynamic<T>;
        createByteList(arg0: $ByteBuffer): $Dynamic<any>;
        createByte(arg0: number): $Dynamic<T>;
        createDouble(arg0: number): $Dynamic<T>;
        createFloat(arg0: number): $Dynamic<T>;
        createIntList(arg0: $IntStream): $Dynamic<any>;
        createInt(arg0: number): $Dynamic<T>;
        createList(arg0: $Stream<$Dynamic<any>>): $Dynamic<T>;
        createLongList(arg0: $LongStream): $Dynamic<any>;
        createLong(arg0: number): $Dynamic<T>;
        createMap(arg0: { [key: $Dynamic<any>]: $Dynamic<any> }): $Dynamic<T>;
        createNumeric(arg0: number): $Dynamic<T>;
        createShort(arg0: number): $Dynamic<T>;
        createString(arg0: string): $Dynamic<T>;
        decode<A>(arg0: $Decoder_<A, $DynamicOps<any>, any, $DataResult<$Pair<A, any>>>): $DataResult<$Pair<A, T>>;
        emptyList(): $Dynamic<T>;
        emptyMap(): $Dynamic<T>;
        getElementGeneric(arg0: T, arg1: T): T;
        getElementGeneric(arg0: T): $DataResult<T>;
        getElement(arg0: string, arg1: T): T;
        getElement(arg0: string): $DataResult<T>;
        getGeneric(arg0: T): $DataResult<T>;
        get(arg0: string): $OptionalDynamic<T>;
        readList<E>(arg0: $Decoder_<E, $DynamicOps<any>, any, $DataResult<$Pair<E, any>>>): $DataResult<$List<E>>;
        readList<E>(arg0: $Function_<$Dynamic<any>, $DataResult<E>, $Dynamic<any>, $DataResult<E>>): $DataResult<$List<E>>;
        readMap<R>(arg0: $DataResult<R>, arg1: $Function3_<R, $Dynamic<T>, $Dynamic<T>, $DataResult<R>, R, $Dynamic<T>, $Dynamic<T>, $DataResult<R>>): $DataResult<R>;
        readMap<K, V>(arg0: $Decoder_<K, $DynamicOps<any>, any, $DataResult<$Pair<K, any>>>, arg1: $Decoder_<V, $DynamicOps<any>, any, $DataResult<$Pair<V, any>>>): $DataResult<$List<$Pair<K, V>>>;
        readMap<K, V>(arg0: $Decoder_<K, $DynamicOps<any>, any, $DataResult<$Pair<K, any>>>, arg1: $Function_<K, $Decoder<V>, K, $Decoder_<V, $DynamicOps<any>, any, $DataResult<$Pair<V, any>>>>): $DataResult<$List<$Pair<K, V>>>;
        read<A>(arg0: $Decoder_<A, $DynamicOps<any>, any, $DataResult<$Pair<A, any>>>): $DataResult<A>;
    }

    export interface $DynamicOps<T> {
        compressMaps(): boolean;
        convertList<U>(arg0: $DynamicOps<U>, arg1: T): U;
        convertMap<U>(arg0: $DynamicOps<U>, arg1: T): U;
        convertTo<U>(arg0: $DynamicOps<U>, arg1: T): U;
        createBoolean(arg0: boolean): T;
        createByteList(arg0: $ByteBuffer): T;
        createByte(arg0: number): T;
        createDouble(arg0: number): T;
        createFloat(arg0: number): T;
        createIntList(arg0: $IntStream): T;
        createInt(arg0: number): T;
        createList(arg0: $Stream<T>): T;
        createLongList(arg0: $LongStream): T;
        createLong(arg0: number): T;
        createMap(arg0: { [key: T]: T }): T;
        createMap(arg0: $Stream<$Pair<T, T>>): T;
        createNumeric(arg0: number): T;
        createShort(arg0: number): T;
        createString(arg0: string): T;
        emptyList(): T;
        emptyMap(): T;
        empty(): T;
        getBooleanValue(arg0: T): $DataResult<boolean>;
        getByteBuffer(arg0: T): $DataResult<$ByteBuffer>;
        getGeneric(arg0: T, arg1: T): $DataResult<T>;
        getIntStream(arg0: T): $DataResult<$IntStream>;
        getList(arg0: T): $DataResult<$Consumer<$Consumer<T>>>;
        getLongStream(arg0: T): $DataResult<$LongStream>;
        getMapEntries(arg0: T): $DataResult<$Consumer<$BiConsumer<T, T>>>;
        getMapValues(arg0: T): $DataResult<$Stream<$Pair<T, T>>>;
        getMap(arg0: T): $DataResult<$MapLike<T>>;
        getNumberValue(arg0: T, arg1: number): number;
        getNumberValue(arg0: T): $DataResult<number>;
        getStream(arg0: T): $DataResult<$Stream<T>>;
        getStringValue(arg0: T): $DataResult<string>;
        get(arg0: T, arg1: string): $DataResult<T>;
        listBuilder(): $ListBuilder<T>;
        mapBuilder(): $RecordBuilder<T>;
        mergeToList(arg0: T, arg1: T): $DataResult<T>;
        mergeToList(arg0: T, arg1: T[]): $DataResult<T>;
        mergeToMap(arg0: T, arg1: T, arg2: T): $DataResult<T>;
        mergeToMap(arg0: T, arg1: $MapLike<T>): $DataResult<T>;
        mergeToMap(arg0: T, arg1: { [key: T]: T }): $DataResult<T>;
        mergeToPrimitive(arg0: T, arg1: T): $DataResult<T>;
        remove(arg0: T, arg1: string): T;
        set(arg0: T, arg1: string, arg2: T): T;
        updateGeneric(arg0: T, arg1: T, arg2: $Function_<T, T, T, T>): T;
        update(arg0: T, arg1: string, arg2: $Function_<T, T, T, T>): T;
        withDecoder<E>(arg0: $Decoder_<E, $DynamicOps<any>, any, $DataResult<$Pair<E, any>>>): $Function<T, $DataResult<$Pair<E, T>>>;
        withEncoder<E>(arg0: $Encoder_<E, E, $DynamicOps<any>, any, $DataResult<any>>): $Function<E, $DataResult<T>>;
        withParser<E>(arg0: $Decoder_<E, $DynamicOps<any>, any, $DataResult<$Pair<E, any>>>): $Function<T, $DataResult<E>>;
    }

    export interface $Encoder<A> {
        comap<B>(arg0: $Function_<B, A, B, A>): $Encoder<B>;
        encodeStart<T>(arg0: $DynamicOps<T>, arg1: A): $DataResult<T>;
        encode<T>(arg0: A, arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
        fieldOf(arg0: string): $MapEncoder<A>;
        flatComap<B>(arg0: $Function_<B, $DataResult<A>, B, $DataResult<A>>): $Encoder<B>;
        withLifecycle(arg0: $Lifecycle): $Encoder<A>;
    }
    export const $Encoder: {
        empty<A>(): $MapEncoder<A>;
        error<A>(arg0: string): $Encoder<A>;
    };

    export class $KeyCompressor<T> {
        constructor(arg0: $DynamicOps<T>, arg1: $Stream<T>);
        compress(arg0: T): number;
        compress(arg0: string): number;
        decompress(arg0: number): T;
        size(): number;
    }

    export interface $Keyable {
        keys<T>(arg0: $DynamicOps<T>): $Stream<T>;
    }
    export const $Keyable: {
        forStrings(arg0: $Supplier_<$Stream<string>, $Stream<string>>): $Keyable;
    };

    export class $Lifecycle {
        static deprecated(arg0: number): $Lifecycle;
        static experimental(): $Lifecycle;
        static stable(): $Lifecycle;
        add(arg0: $Lifecycle): $Lifecycle;
    }

    export interface $ListBuilder<T> {
        addAll<E>(arg0: $Iterable<E>, arg1: $Encoder_<E, E, $DynamicOps<any>, any, $DataResult<any>>): $ListBuilder<T>;
        add<E>(arg0: E, arg1: $Encoder_<E, E, $DynamicOps<any>, any, $DataResult<any>>): $ListBuilder<T>;
        add(arg0: T): $ListBuilder<T>;
        add(arg0: $DataResult<T>): $ListBuilder<T>;
        build(arg0: T): $DataResult<T>;
        build(arg0: $DataResult<T>): $DataResult<T>;
        mapError(arg0: $UnaryOperator_<string, string, string>): $ListBuilder<T>;
        ops(): $DynamicOps<T>;
        withErrorsFrom(arg0: $DataResult<any>): $ListBuilder<T>;
    }

    export class $MapCodec<A> extends $CompressorHolder implements $MapDecoder<A>, $MapEncoder<A> {
        constructor();
        static assumeMapUnsafe<A>(arg0: $Codec<A>): $MapCodec<A>;
        static of<A>(arg0: $MapEncoder<A>, arg1: $MapDecoder<A>, arg2: $Supplier_<string, string>): $MapCodec<A>;
        static of<A>(arg0: $MapEncoder<A>, arg1: $MapDecoder<A>): $MapCodec<A>;
        static recursive<A>(arg0: string, arg1: $Function_<$Codec<A>, $MapCodec<A>, $Codec<A>, $MapCodec<A>>): $MapCodec<A>;
        static unit<A>(arg0: A): $MapCodec<A>;
        static unit<A>(arg0: $Supplier_<A, A>): $MapCodec<A>;
        codec(): $Codec<A>;
        dependent<E>(arg0: $MapCodec<E>, arg1: $Function_<A, $Pair<E, $MapCodec<E>>, A, $Pair<E, $MapCodec<E>>>, arg2: $BiFunction_<A, E, A, A, E, A>): $MapCodec<A>;
        deprecated(arg0: number): $MapCodec<A>;
        fieldOf(arg0: string): $MapCodec<A>;
        flatXmap<S>(arg0: $Function_<A, $DataResult<S>, A, $DataResult<S>>, arg1: $Function_<S, $DataResult<A>, S, $DataResult<A>>): $MapCodec<S>;
        forGetter<O>(arg0: $Function_<O, A, O, A>): $RecordCodecBuilder<O, A>;
        keys<T>(arg0: $DynamicOps<T>): $Stream<T>;
        mapResult(arg0: $MapCodec$ResultFunction<A>): $MapCodec<A>;
        orElseGet(arg0: $Consumer_<string, string>, arg1: $Supplier_<A, A>): $MapCodec<A>;
        orElseGet(arg0: $Supplier_<A, A>): $MapCodec<A>;
        orElseGet(arg0: $UnaryOperator_<string, string, string>, arg1: $Supplier_<A, A>): $MapCodec<A>;
        orElse(arg0: A): $MapCodec<A>;
        orElse(arg0: $Consumer_<string, string>, arg1: A): $MapCodec<A>;
        orElse(arg0: $UnaryOperator_<string, string, string>, arg1: A): $MapCodec<A>;
        stable(): $MapCodec<A>;
        validate(arg0: $Function_<A, $DataResult<A>, A, $DataResult<A>>): $MapCodec<A>;
        withLifecycle(arg0: $Lifecycle): $MapCodec<A>;
        xmap<S>(arg0: $Function_<A, S, A, S>, arg1: $Function_<S, A, S, A>): $MapCodec<S>;
    }

    export interface $MapCodec$ResultFunction<A> {
        apply<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>, arg2: $DataResult<A>): $DataResult<A>;
        coApply<T>(arg0: $DynamicOps<T>, arg1: A, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
    }

    export interface $MapDecoder<A> extends $Keyable {
        ap<E>(arg0: $MapDecoder<$Function_<A, E, A, E>>): $MapDecoder<E>;
        compressedDecode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<A>;
        compressor<T>(arg0: $DynamicOps<T>): $KeyCompressor<T>;
        decoder(): $Decoder<A>;
        decode<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>): $DataResult<A>;
        flatMap<B>(arg0: $Function_<A, $DataResult<B>, A, $DataResult<B>>): $MapDecoder<B>;
        map<B>(arg0: $Function_<A, B, A, B>): $MapDecoder<B>;
        withLifecycle(arg0: $Lifecycle): $MapDecoder<A>;
    }

    export interface $MapEncoder<A> extends $Keyable {
        comap<B>(arg0: $Function_<B, A, B, A>): $MapEncoder<B>;
        compressedBuilder<T>(arg0: $DynamicOps<T>): $RecordBuilder<T>;
        compressor<T>(arg0: $DynamicOps<T>): $KeyCompressor<T>;
        encoder(): $Encoder<A>;
        encode<T>(arg0: A, arg1: $DynamicOps<T>, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
        flatComap<B>(arg0: $Function_<B, $DataResult<A>, B, $DataResult<A>>): $MapEncoder<B>;
        withLifecycle(arg0: $Lifecycle): $MapEncoder<A>;
    }
    export const $MapEncoder: {
        makeCompressedBuilder<T>(arg0: $DynamicOps<T>, arg1: $KeyCompressor<T>): $RecordBuilder<T>;
    };

    export interface $MapLike<T> {
        entries(): $Stream<$Pair<T, T>>;
        get(arg0: T): T;
        get(arg0: string): T;
    }
    export const $MapLike: {
        forMap<T>(arg0: { [key: T]: T }, arg1: $DynamicOps<T>): $MapLike<T>;
    };

    export class $OptionalDynamic<T> extends $DynamicLike<T> {
        constructor(arg0: $DynamicOps<T>, arg1: $DataResult<$Dynamic<T>>);
        asBoolean(): $DataResult<boolean>;
        asByteBufferOpt(): $DataResult<$ByteBuffer>;
        asIntStreamOpt(): $DataResult<$IntStream>;
        asLongStreamOpt(): $DataResult<$LongStream>;
        asMapOpt(): $DataResult<$Stream<$Pair<$Dynamic<T>, $Dynamic<T>>>>;
        asNumber(): $DataResult<number>;
        asStreamOpt(): $DataResult<$Stream<$Dynamic<T>>>;
        asString(): $DataResult<string>;
        decode<A>(arg0: $Decoder_<A, $DynamicOps<any>, any, $DataResult<$Pair<A, any>>>): $DataResult<$Pair<A, T>>;
        flatMap<U>(arg0: $Function_<$Dynamic<T>, $DataResult<U>, $Dynamic<T>, $DataResult<U>>): $DataResult<U>;
        getElementGeneric(arg0: T): $DataResult<T>;
        getElement(arg0: string): $DataResult<T>;
        getGeneric(arg0: T): $DataResult<T>;
        get(arg0: string): $OptionalDynamic<T>;
        get(): $DataResult<$Dynamic<T>>;
        into<V>(arg0: $Function_<$Dynamic<T>, V, $Dynamic<T>, V>): $DataResult<V>;
        map<U>(arg0: $Function_<$Dynamic<T>, U, $Dynamic<T>, U>): $DataResult<U>;
        orElseEmptyList(): $Dynamic<T>;
        orElseEmptyMap(): $Dynamic<T>;
        result(): $Optional<$Dynamic<T>>;
    }

    export interface $RecordBuilder<T> {
        add(arg0: T, arg1: T): $RecordBuilder<T>;
        add(arg0: T, arg1: $DataResult<T>): $RecordBuilder<T>;
        add(arg0: $DataResult<T>, arg1: $DataResult<T>): $RecordBuilder<T>;
        add<E>(arg0: string, arg1: E, arg2: $Encoder_<E, E, $DynamicOps<any>, any, $DataResult<any>>): $RecordBuilder<T>;
        add(arg0: string, arg1: T): $RecordBuilder<T>;
        add(arg0: string, arg1: $DataResult<T>): $RecordBuilder<T>;
        build(arg0: T): $DataResult<T>;
        build(arg0: $DataResult<T>): $DataResult<T>;
        mapError(arg0: $UnaryOperator_<string, string, string>): $RecordBuilder<T>;
        ops(): $DynamicOps<T>;
        setLifecycle(arg0: $Lifecycle): $RecordBuilder<T>;
        withErrorsFrom(arg0: $DataResult<any>): $RecordBuilder<T>;
    }

    export type $DataResult$Instance_ = $DataResult$Instance | "INSTANCE";
    export type $Decoder_<Host0 = any, CallbackArg0 = $DynamicOps<any>, CallbackArg1 = any, CallbackResult = $DataResult<$Pair<Host0, any>>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | $Decoder<Host0>;
    export type $Decoder$Boxed_<Host0 = any, CallbackArg0 = $Dynamic<any>, CallbackResult = $DataResult<$Pair<Host0, any>>> = ((arg0: CallbackArg0) => CallbackResult) | $Decoder$Boxed<Host0>;
    export type $Decoder$Simple_<Host0 = any, CallbackArg0 = $Dynamic<any>, CallbackResult = $DataResult<Host0>> = ((arg0: CallbackArg0) => CallbackResult) | $Decoder$Simple<Host0>;
    export type $Decoder$Terminal_<Host0 = any, CallbackArg0 = $DynamicOps<any>, CallbackArg1 = any, CallbackResult = $DataResult<Host0>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | $Decoder$Terminal<Host0>;
    export type $Encoder_<Host0 = any, CallbackArg0 = Host0, CallbackArg1 = $DynamicOps<any>, CallbackArg2 = any, CallbackResult = $DataResult<any>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | $Encoder<Host0>;
    export type $Keyable_<CallbackArg0 = $DynamicOps<any>, CallbackResult = $Stream<any>> = ((arg0: CallbackArg0) => CallbackResult) | $Keyable;
}
