    export interface $TypeScriptInterfaceStaticSurfaceTest$ValueApi<T> {
        label(): string;
        value(): T;
    }
    export const $TypeScriptInterfaceStaticSurfaceTest$ValueApi: {
        length(value: number): number;
        length(value: 3): 3;
        of<R>(value: R): $TypeScriptInterfaceStaticSurfaceTest$ValueApi<R>;
        readonly LEVEL: number;
    };
    export interface $TypeScriptInterfaceStaticSurfaceTest$ChildApi extends $TypeScriptInterfaceStaticSurfaceTest$ValueApi<string> {
    }
