import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd() / 'build/ticket37-signed-workspace-client'
helper = Path('build/ticket37-config-sync-repair/rcon-signed-workspace-client.py')
assert not (root / 'download-verdict.json').exists()

def wait(test, seconds, label):
    deadline = time.monotonic() + seconds
    while not test():
        assert time.monotonic() < deadline, label
        time.sleep(.005)

def command(value):
    result = subprocess.run([sys.executable, str(helper), value], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)

def snapshots():
    text = (root / 'server/logs/latest.log').read_text(encoding='utf-8')
    return [json.loads(line.split('LIVE-WINDOW ', 1)[1]) for line in text.splitlines() if 'LIVE-WINDOW ' in line]

wait(lambda: (root / 'D-bundle-held.json').exists(), 55, 'D partial bundle not held')
held = json.loads((root / 'D-bundle-held.json').read_text())
assert 0 < held['prefixBytes'] < held['bytes']
client = root / 'clientD'
client_log = lambda: (client / 'stdout.log').read_text(encoding='utf-8', errors='replace')
assert 'PACK-DOWNLOAD-PROOF executed=true' not in client_log()
assert not list((client / 'nekojs/server_packs').rglob('manifest.json'))
baseline = snapshots()[-1]['activatedGeneration']
assert baseline == 2
reload = command('nekojs reload server')
wait(lambda: snapshots()[-1]['status'] == 'AWAITING_ACK' and any(row['generation'] == baseline + 1 and row['outcome'] == 'ack' for row in snapshots()[-1]['outcomes']), 3, 'No actual pending reload with C ack')
pending = snapshots()[-1]
generation = baseline + 1
assert pending['activatedGeneration'] == baseline
assert not any(row['generation'] == generation and row['phase'] == 'COMMIT' for row in pending['phases'])
assert len({row['participant'] for row in pending['outcomes'] if row['generation'] == generation and row['outcome'] == 'ack'}) == 1
assert 'NekoWindow7dD joined the game' not in (root / 'server/stdout.log').read_text(encoding='utf-8', errors='replace')
(root / 'release-D-bundle').write_bytes(b'')
wait(lambda: 'NekoWindow7dD joined the game' in (root / 'server/stdout.log').read_text(encoding='utf-8', errors='replace'), 12, 'D did not finish signed download and log in')
wait(lambda: 'PACK-DOWNLOAD-PROOF executed=true' in client_log() and 'Activated 1 remote script pack(s)' in client_log(), 3, 'Actual signed remote pack not activated')
wait(lambda: snapshots()[-1]['status'] == 'COMMITTED' and snapshots()[-1]['activatedGeneration'] == generation and len({row['participant'] for row in snapshots()[-1]['outcomes'] if row['generation'] == generation and row['outcome'] == 'activation-report'}) == 2, 4, 'D/C did not complete actual post-download commit')
catchup = snapshots()[-1]
for outcome in ('ack', 'activation-report'):
    assert len({row['participant'] for row in catchup['outcomes'] if row['generation'] == generation and row['outcome'] == outcome}) == 2
give = command('give NekoWindow7dD ticket37_live:window_item')
assert 'Gave' in give['response'], give
cached = list((client / 'nekojs/server_packs').rglob('manifest.json'))
assert len(cached) == 1
server_pack = root / 'server/nekojs/packs/owned-download'
assert cached[0].read_bytes() == (server_pack / 'manifest.json').read_bytes()
cached_script = cached[0].parent / 'client_scripts/download-proof.js'
assert cached_script.read_bytes() == (server_pack / 'client_scripts/download-proof.js').read_bytes()
trust = json.loads((client / 'nekojs/config/trusted-servers.json').read_text())
key = trust['trustedKeys']['owned-download-window-7d']
assert key['publicKey'] == json.loads(cached[0].read_text())['signature']['publicKey']
summary = dict(result='PASS', sourceBase='99e48fa30755ce226581b101cd59d4e9ffc48b17', sourcePatchSha256='d0afd044e05fe8cfdfd1c635e728f04dc2f64c0d97e79e867adb3850b8c07baf', partialBundle=held,
    notExecutedOrCachedBeforeRelease=True, baselineGeneration=baseline, awaitingAckWhilePartial=pending,
    signedRemotePackExecuted=True, signatureKeyPinned=True, cachedManifestSha256=hashlib.sha256(cached[0].read_bytes()).hexdigest(),
    cachedScriptSha256=hashlib.sha256(cached_script.read_bytes()).hexdigest(), latestGenerationCatchup=catchup, give=give,
    fakeReplies=False, changedWireBytes=False, allowUnsigned=False)
(root / 'download-verdict.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(result='PASS', generation=generation, signedRemotePackExecuted=True, configurationCatchup=True)))
