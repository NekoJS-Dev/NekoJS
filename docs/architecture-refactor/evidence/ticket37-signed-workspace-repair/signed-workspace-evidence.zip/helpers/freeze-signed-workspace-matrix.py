import json
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

project=Path.cwd().resolve()
root=project/'build/ticket37-signed-workspace-repair'
target=root/'matrix-xml'
assert not target.exists()
directories=[project/'common/build/test-results/test',project/'common-api-processor/build/test-results/test']
directories += [project/'versions'/node/'build/test-results/test' for node in ('1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric')]
stats=dict(tests=0,failures=0,errors=0,skipped=0,xml=0)
for directory in directories:
    assert directory.is_dir(),directory
    for path in sorted(directory.glob('TEST-*.xml')):
        destination=target/path.relative_to(project)
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,destination)
        tree=ET.parse(path).getroot()
        for key in ('tests','failures','errors','skipped'): stats[key]+=int(tree.attrib.get(key,0))
        stats['xml']+=1
assert stats['failures']==0 and stats['errors']==0
(root/'matrix-summary.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats))
