import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
source = project / 'build/ticket37-signed-workspace-repair'
installed = project / 'build/ticket37-signed-workspace-installed'
nodes = ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']
assert not installed.exists()

def run(name, command):
    with (source / (name + '.txt')).open('xb') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    (source / (name + '-exit.json')).write_text(json.dumps(dict(exitCode=result.returncode)))
    assert result.returncode == 0, name + ' failed; original output retained'

deadline = time.monotonic() + 180
while not (source / 'matrix-final-exit.json').exists():
    assert time.monotonic() < deadline, 'Final matrix did not finish'
    time.sleep(.1)
assert json.loads((source / 'matrix-final-exit.json').read_text(encoding='utf-8-sig'))['exitCode'] == 0
assert subprocess.check_output(['git', 'diff', '--', 'common/src/main/java/com/tkisor/nekojs/script/WorkspaceGenerator.java']) == (source / 'production-source.patch').read_bytes()
run('freeze-matrix', [sys.executable, str(helpers / 'freeze-signed-workspace-matrix.py')])
run('platform-gates', [sys.executable, 'tools/nekojs-ci-gates.py', 'all', '--out', str(source / 'platform-gates.json')])
run('prepare-installed', [sys.executable, str(helpers / 'prepare-signed-workspace-profiles.py')])
libraries = project / 'build/ticket37-config-sync-installed-attempt1/launcherA/.minecraft/libraries'
jars = list(libraries.glob('com/google/code/gson/gson/*/*.jar')) + list(libraries.glob('org/slf4j/slf4j-api/*/*.jar'))
classpath = ';'.join(str(path.resolve()) for path in [project / 'common/build/classes/java/main'] + jars)
classes = source / 'signer-classes'
classes.mkdir()
run('signer-compile', ['C:/Program Files/Java/jdk-25.0.2/bin/javac.exe', '-cp', classpath, '-d', str(classes), str(helpers / 'OwnedSignedWorkspaceFixture.java')])
classpath = str(classes) + ';' + classpath
signer = ['C:/Program Files/Java/jdk-25.0.2/bin/java.exe', '-cp', classpath, 'com.tkisor.nekojs.core.pack.sync.OwnedSignedWorkspaceFixture']
signed = {}
for node in nodes:
    pack = installed / node / 'nekojs/packs/owned-signed-workspace'
    run(node + '-sign-before-boot', signer + ['sign', str(pack)])
    signed[node] = json.loads((source / (node + '-sign-before-boot.txt')).read_text())
print('SIGNED_WORKSPACE_FIVE_NODE_PREPARED', flush=True)
with (installed / 'runner.txt').open('xb') as output:
    runner = subprocess.Popen([sys.executable, str(helpers / 'run-other-nodes.py'), str(installed), '--skip-install'], stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
run('installed-proof', [sys.executable, str(helpers / 'prove-other-nodes.py'), str(installed), *nodes])
runner_code = runner.wait(timeout=120)
(installed / 'runner-exit.json').write_text(json.dumps(dict(exitCode=runner_code)))
assert runner_code == 0
verdicts = json.loads((installed / 'runtime-summary.json').read_text())
assert all(row['verdict'] == 'PASS' for row in verdicts), verdicts
bindings = {}
for node in nodes:
    assert json.loads((installed / node / 'server-exit.json').read_text())['exitCode'] == 0
    pack = installed / node / 'nekojs/packs/owned-signed-workspace'
    run(node + '-sign-after-boot', signer + ['check', str(pack)])
    checked = json.loads((source / (node + '-sign-after-boot.txt')).read_text())
    assert checked['hash'] == signed[node]['hash'] and checked['signatureValid']
    bindings[node] = dict(before=signed[node], after=checked)
(source / 'signed-content-verdict.json').write_text(json.dumps(dict(result='PASS', nodes=bindings, signaturesRegeneratedAfterBoot=False), indent=2))
print('SIGNED_WORKSPACE_FIVE_NODE_RUNTIME_PASS', flush=True)
run('installed-ide', [sys.executable, str(helpers / 'check-signed-workspace-ide.py')])
print('SIGNED_WORKSPACE_IDE_REPORT_COMPLETE_NOT_TYPECHECK_PASS', flush=True)
