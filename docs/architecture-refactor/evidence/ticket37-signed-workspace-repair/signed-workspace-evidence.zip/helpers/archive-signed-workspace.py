import hashlib
import json
import socket
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

project = Path.cwd().resolve()
source = project / 'build/ticket37-signed-workspace-repair'
installed = project / 'build/ticket37-signed-workspace-installed'
client = project / 'build/ticket37-signed-workspace-client'
destination = project / 'docs/architecture-refactor/evidence/ticket37-signed-workspace-repair'
assert {path.name for path in destination.iterdir()} == {'verify.py'}
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {}
secrets = []

def add(path, name):
    assert name not in entries
    entries[name] = path.read_bytes()

def signed_hash(directory):
    manifest = (directory / 'manifest.json').read_bytes()
    value = hashlib.sha256(manifest + b'\0')
    files = sorted(path for folder in ('startup_scripts', 'server_scripts', 'client_scripts', 'test_scripts', 'assets', 'data') for path in (directory / folder).rglob('*') if path.is_file() and 'node_modules' not in str(path))
    for path in files:
        value.update(path.relative_to(directory).as_posix().encode() + b'\0' + path.read_bytes() + b'\0')
    return value.hexdigest(), files

assert json.loads((source / 'accept-installed-exit.json').read_text(encoding='utf-8-sig'))['exitCode'] == 0
assert json.loads((client / 'orchestrator-exit.json').read_text())['exitCode'] == 0
for path in source.iterdir():
    if path.is_file():
        add(path, 'checks/' + path.name)
for path in (source / 'matrix-xml').rglob('*.xml'):
    add(path, 'checks/matrix-xml/' + path.relative_to(source / 'matrix-xml').as_posix())
for path in installed.iterdir():
    if path.is_file():
        add(path, 'installed/' + path.name)
for path in (installed / 'ide').iterdir():
    if path.is_file():
        add(path, 'installed/ide/' + path.name)
prepared = json.loads((installed / 'preparation-manifest.json').read_text())
bindings = {}
exits = {}
ports = []
for row in prepared['nodes']:
    node = row['node']
    directory = installed / node
    artifact = directory / 'mods' / row['artifact']
    assert sha(artifact.read_bytes()) == row['sha256']
    node_bindings = {}
    with ZipFile(artifact) as jar:
        for name in jar.namelist():
            if not name.startswith('com/tkisor/nekojs/') or not name.endswith('.class'):
                continue
            candidates = [project / 'common/build/classes/java/main' / name, project / 'versions' / node / 'build/classes/java/main' / name]
            compiled = next((path for path in candidates if path.is_file()), None)
            if compiled is not None:
                digest = sha(jar.read(name))
                assert digest == sha(compiled.read_bytes())
                node_bindings[name] = digest
    bindings[node] = dict(artifact=row['artifact'], sha256=row['sha256'], classes=node_bindings)
    exits[node] = json.loads((directory / 'server-exit.json').read_text())['exitCode']
    assert exits[node] == 0
    ports += [row['serverPort'], row['rconPort']]
    props = dict(line.split('=', 1) for line in (directory / 'server.properties').read_text().splitlines() if '=' in line)
    secrets.append(props['rcon.password'].encode())
    for name in ('server-stdout.log', 'server-stderr.log', 'server-exit.json', 'owned-process.json', 'command-proof.txt', 'runtime-verdict.json', 'pyrightconfig.json', 'logs/latest.log'):
        path = directory / name
        if path.exists():
            add(path, 'installed/' + node + '/' + name)
    for folder in ('startup_scripts', 'server_scripts', 'packs'):
        for path in (directory / 'nekojs' / folder).rglob('*'):
            if path.is_file():
                add(path, 'installed/' + node + '/' + path.relative_to(directory).as_posix())
    for path in (directory / '.neko_probe').rglob('*'):
        if path.is_file() and path.suffix in ('.ts', '.pyi', '.json'):
            add(path, 'installed/' + node + '/' + path.relative_to(directory).as_posix())
client_exits = {}
for path in client.iterdir():
    if path.is_file() and path.suffix in ('.txt', '.json', '.jsonl', '.md', '.js'):
        add(path, 'client-window/' + path.name)
props = dict(line.split('=', 1) for line in (client / 'server/server.properties').read_text().splitlines() if '=' in line)
secrets.append(props['rcon.password'].encode())
client_prepared = json.loads((client / 'preparation.json').read_text())
assert client_prepared['artifactSha256'] == bindings['26.2.0']['sha256']
assert client_prepared['classBindings'] == bindings['26.2.0']['classes']
for node in ('server', 'clientC', 'clientD', 'clientE'):
    directory = client / node
    assert sha((directory / 'mods' / client_prepared['artifact']).read_bytes()) == client_prepared['artifactSha256']
    if (directory / 'owned-process.json').exists():
        client_exits[node] = json.loads((directory / 'exit.json').read_text())['exitCode']
        assert client_exits[node] == 0
        for name in ('stdout.log', 'stderr.log', 'exit.json', 'owned-process.json', 'options.txt', 'logs/latest.log', 'nekojs/config/trusted-servers.json'):
            path = directory / name
            if path.exists():
                add(path, 'client-window/' + node + '/' + name)
    for folder in ('startup_scripts', 'server_scripts', 'client_scripts', 'packs', 'server_packs'):
        for path in (directory / 'nekojs' / folder).rglob('*'):
            if path.is_file():
                add(path, 'client-window/' + node + '/' + path.relative_to(directory).as_posix())
before = json.loads((client / 'signed-pack-preparation.json').read_text())['hash']
hashes = {}
for node in ('server', 'clientC', 'clientD'):
    parent = client / node / 'nekojs' / ('packs' if node == 'server' else 'server_packs')
    packs = [path.parent for path in parent.rglob('manifest.json')]
    assert len(packs) == 1
    digest, files = signed_hash(packs[0])
    assert digest == before and len(files) == 1 and not (packs[0] / 'client_scripts/jsconfig.json').exists()
    hashes[node] = digest
ports += [25995, 25996, 25997, 25998]
for port in ports:
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
for path in (project / 'build/ticket37-config-sync-repair').iterdir():
    if path.is_file() and ('signed-workspace' in path.name or path.name in ('OwnedSignedWorkspaceFixture.java', 'OwnedSignedDownloadPackNormalizedTrust.java', 'run-other-nodes.py', 'prove-other-nodes.py')):
        add(path, 'helpers/' + path.name)
for path in [project / 'common/src/main/java/com/tkisor/nekojs/script/WorkspaceGenerator.java', project / 'common/src/test/java/com/tkisor/nekojs/core/plugin/WorkspaceGeneratorModifyConfigHookTest.java']:
    add(path, 'source/' + path.relative_to(project).as_posix())
for name, data in entries.items():
    assert not any(secret in data for secret in secrets), name
archive = destination / 'signed-workspace-evidence.zip'
with ZipFile(archive, 'x', compression=ZIP_DEFLATED) as output:
    for name, data in sorted(entries.items()):
        output.writestr(name, data)
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()), entries=[dict(name=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(entries.items())], exclusions=['credentials/server.properties', 'worlds', 'private signing keys', 'binary artifacts and launcher args', 'raw JFR/hs_err', 'unrelated user files'])
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
summary = dict(sourceBase=prepared['sourceRevision'], productionPatchSha256=prepared['productionPatchSha256'], artifacts=bindings,
    matrix=json.loads((source / 'matrix-summary.json').read_text()), runtime=json.loads((installed / 'runtime-summary.json').read_text()),
    signedContent=json.loads((source / 'signed-content-verdict.json').read_text()), ide=json.loads((installed / 'ide/summary.json').read_text()),
    diagnosticComparison=json.loads((source / 'diagnostic-comparison.json').read_text()), directExits=exits,
    clientExits=client_exits, clientDownload=json.loads((client / 'download-verdict.json').read_text()), clientPackHashes=hashes,
    unsignedRejectionRetained=True, signaturesRegeneratedAfterBoot=False, noBridge=True, noNativeActivationOrInput=True,
    newSourcePerformance='NOT_RUN', previous7dFormalReload='FAIL', firstPixel='NOT_VERIFIED', humanAcceptance='NOT_RECORDED', overall='NOT_COMPLETE')
(destination / 'runtime-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(result='ARCHIVED', entries=len(entries), bytes=manifest['bytes'], sha256=manifest['sha256'], tests=summary['matrix']['tests'])))
