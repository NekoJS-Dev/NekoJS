package com.tkisor.nekojs.core.pack.sync;

import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPairGenerator;
import java.security.Signature;
import java.util.Base64;

/** Signs before startup, then checks the same file set without regenerating the signature. */
public final class OwnedSignedWorkspaceFixture {
    public static void main(String[] args) throws Exception {
        Path pack = Path.of(args[1]).toAbsolutePath().normalize();
        if (args[0].equals("sign")) {
            if (Files.exists(pack)) throw new IllegalStateException("Preserve existing signed fixture");
            Files.createDirectories(pack.resolve("client_scripts"));
            Files.writeString(pack.resolve("client_scripts/proof.js"),
                    "console.info('SIGNED-WORKSPACE-PROOF executed=true');\n");
            JsonObject manifest = new JsonObject();
            manifest.addProperty("id", "owned-signed-workspace");
            manifest.addProperty("version", "1.0.0");
            manifest.addProperty("clientSync", true);
            var keys = KeyPairGenerator.getInstance("Ed25519").generateKeyPair();
            var signer = Signature.getInstance("Ed25519");
            signer.initSign(keys.getPrivate());
            signer.update(PackSignaturePayload.build("packs:owned-signed-workspace", "GLOBAL",
                    manifest.toString(), PackHasher.readContentFiles(pack)));
            JsonObject signature = new JsonObject();
            signature.addProperty("algorithm", "Ed25519");
            signature.addProperty("keyId", "owned-signed-workspace");
            signature.addProperty("publicKey", Base64.getEncoder().encodeToString(keys.getPublic().getEncoded()));
            signature.addProperty("signature", Base64.getEncoder().encodeToString(signer.sign()));
            manifest.add("signature", signature);
            Files.writeString(pack.resolve("manifest.json"), manifest.toString());
        } else if (!args[0].equals("check")) {
            throw new IllegalArgumentException("Expected sign or check");
        }
        String manifest = Files.readString(pack.resolve("manifest.json"));
        var files = PackHasher.readContentFiles(pack);
        var result = PackSignatureVerifier.verify("packs:owned-signed-workspace", "GLOBAL", manifest,
                files, false, new PackSyncTrustStore(pack.getParent().resolve("unused-owned-trust.json")));
        if (!result.valid() || files.size() != 1 || Files.exists(pack.resolve("client_scripts/jsconfig.json"))) {
            throw new IllegalStateException("Owned signed fixture content changed");
        }
        JsonObject report = new JsonObject();
        report.addProperty("mode", args[0]);
        report.addProperty("signatureValid", result.valid());
        report.addProperty("hash", PackHasher.hashPackDir(pack));
        report.addProperty("files", files.size());
        report.addProperty("allowUnsigned", false);
        report.addProperty("privateKeyPersisted", false);
        System.out.println(report);
    }
}
