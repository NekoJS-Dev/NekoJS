package com.tkisor.nekojs.probe.backend.typescript;

import com.tkisor.nekojs.probe.ProbeConfigLoader;
import com.tkisor.nekojs.api.catalog.EventCatalogEntry;
import com.tkisor.nekojs.api.catalog.RegistryBuilderSurfaceEntry;
import com.tkisor.nekojs.api.catalog.RegistryBuilderSurfaceEntry.EventPayload;
import com.tkisor.nekojs.probe.EventPayloadDeclarations;
import com.tkisor.nekojs.probe.ir.TypeReflector;
import com.tkisor.nekojs.probe.ir.TypeScriptClassRenderer;
import com.tkisor.nekojs.probe.types.TypeAliasRegistry;
import com.tkisor.nekojs.api.ScriptType;

import java.lang.reflect.TypeVariable;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 事件声明生成器：从 EventCatalogEntry 生成 TypeScript 事件声明。
 *
 * <p>格式参考 ProbeJS：
 * <pre>
 * import { $RecipeEventJS } from "java:com/example";
 * import { $ResourceLocation_ } from "java:net/minecraft/resources";
 *
 * declare module "@side-only/server/events" {
 * }
 *
 * export {};
 *
 * declare global {
 *     export namespace ServerEvents {
 *         function recipes(handler: ((event: $RecipeEventJS) => void)): void;
 *         function recipes(extra: string, handler: ((event: $RecipeEventJS) => void)): void;
 *     }
 * }
 * </pre>
 */
public final class EventDeclarationGenerator {
    private final TypeAliasRegistry aliasRegistry;
    private final AdapterAliasGenerator adapterAliasGenerator;

    public EventDeclarationGenerator(TypeAliasRegistry aliasRegistry, AdapterAliasGenerator adapterAliasGenerator) {
        this.aliasRegistry = aliasRegistry;
        this.adapterAliasGenerator = adapterAliasGenerator;
    }

    /**
     * 为指定 ScriptType 生成事件声明。
     */
    public String generate(List<EventCatalogEntry> events, ScriptType scriptType) {
        return generate(events, scriptType, List.of());
    }

    public String generate(List<EventCatalogEntry> events, ScriptType scriptType,
                           List<RegistryBuilderSurfaceEntry> builders) {
        Map<Class<?>, EventPayload> payloads = EventPayloadDeclarations.resolve(events, builders);
        StringBuilder sb = new StringBuilder();
        if (!payloads.isEmpty()) {
            sb.append("/// <reference path=\"../../../@event-builders/index.d.ts\" />\n\n");
        }

        // 收集所有需要 import 的类型
        Set<String> imports = new LinkedHashSet<>();
        for (EventCatalogEntry event : events) {
            if (event.eventType() != null && !payloads.containsKey(event.eventType())) {
                collectImports(event.eventType(), imports);
            }
            if (event.dispatchKeyType() != null) {
                collectImports(event.dispatchKeyType(), imports);
            }
        }

        // 生成 import 语句
        if (!imports.isEmpty()) {
            Map<String, List<String>> importsByPackage = new TreeMap<>();
            for (String fqn : imports) {
                String pkg = fqn.substring(0, fqn.lastIndexOf('.'));
                String simple = fqn.substring(fqn.lastIndexOf('.') + 1);
                List<String> names = importsByPackage.computeIfAbsent(pkg, k -> new ArrayList<>());
                names.add("$" + simple);
                // dispatch key 参数放宽后可能引用 $Foo_，需一并导入
                String aliasName = adapterAliasGenerator.aliasNameOf(fqn);
                if (aliasName != null) {
                    names.add(aliasName);
                }
            }

            for (var entry : importsByPackage.entrySet()) {
                String importPath = "java:" + entry.getKey().replace('.', '/');
                // 包内符号名按字典序排序：反射方法/接口顺序无规范保证，沿用首插序会导致
                // 产物跨 JVM 运行抖动（事件类型图深递归时尤甚）
                List<String> names = new ArrayList<>(new LinkedHashSet<>(entry.getValue()));
                Collections.sort(names);
                sb.append("import { ").append(String.join(", ", names));
                sb.append(" } from \"").append(importPath).append("\";\n");
            }
            sb.append("\n");
        }

        for (EventPayload payload : payloads.values()) {
            sb.append("interface ").append(payload.name()).append(" {\n");
            for (RegistryBuilderSurfaceEntry.Member member : payload.members()) {
                switch (member.kind()) {
                    case WRITABLE_PROPERTY -> sb.append("    ").append(member.name()).append(": ")
                            .append(member.tsType()).append(";\n");
                    case READ_ONLY_PROPERTY -> sb.append("    readonly ").append(member.name()).append(": ")
                            .append(member.tsType()).append(";\n");
                    case METHOD -> sb.append("    ").append(member.tsType()).append(";\n");
                }
            }
            sb.append("}\n\n");
        }

        // 空的 module 声明（保持结构一致）
        sb.append("declare module \"@side-only/").append(scriptType.name).append("/events\" {\n");
        sb.append("}\n\n");

        // export {} + declare global
        sb.append("export {};\n\n");
        sb.append("declare global {\n");

        // 按 group 分组
        Map<String, List<EventCatalogEntry>> byGroup = events.stream()
                .collect(Collectors.groupingBy(EventCatalogEntry::group, LinkedHashMap::new, Collectors.toList()));

        for (var groupEntry : byGroup.entrySet()) {
            String group = groupEntry.getKey();
            List<EventCatalogEntry> groupEvents = groupEntry.getValue();

            sb.append("    namespace ").append(group).append(" {\n");

            for (EventCatalogEntry event : groupEvents) {
                sb.append(generateEventMethod(event, payloads.get(event.eventType())));
            }

            sb.append("    }\n\n");
        }

        sb.append("}\n");
        return sb.toString();
    }

    /**
     * 获取类的 TypeScript 标识符名（内部类使用 Parent$Child 格式）。
     */
    private static String getTsClassName(Class<?> cls) {
        if (cls.getEnclosingClass() != null && !cls.isAnonymousClass()) {
            return getTsClassName(cls.getEnclosingClass()) + "$" + cls.getSimpleName();
        }
        return cls.getSimpleName();
    }

    private String generateEventMethod(EventCatalogEntry event, EventPayload payload) {
        StringBuilder sb = new StringBuilder();

        // ScriptEvents 声明的自定义事件：载荷任意、且脚本可自己触发
        if (event.scriptDefined()) {
            sb.append("        namespace ").append(event.name()).append(" {\n");
            sb.append("            function post(payload?: any): void;\n");
            sb.append("        }\n");
            sb.append("        function ").append(event.name());
            sb.append("(handler: ((payload: any) => void)): void;\n");
            return sb.toString();
        }

        // 事件类类型
        String eventType = "any";
        if (payload != null) {
            eventType = payload.name();
        } else if (event.eventType() != null) {
            eventType = "$" + getTsClassName(event.eventType());
            // 处理泛型
            TypeVariable<?>[] typeParams = event.eventType().getTypeParameters();
            if (typeParams.length > 0) {
                eventType += "<";
                List<String> args = new ArrayList<>();
                for (int i = 0; i < typeParams.length; i++) {
                    args.add("any");
                }
                eventType += String.join(", ", args);
                eventType += ">";
            }
        }

        // 无 dispatch key 的版本
        sb.append("        function ").append(event.name());
        sb.append("(handler: ((event: ").append(eventType).append(") => void)): void;\n");

        // 有 dispatch key 的版本
        if (event.dispatchable() && event.dispatchKeyType() != null) {
            String keyType = TypeScriptClassRenderer.renderTypeRef(
                    TypeReflector.toRef(event.dispatchKeyType()), aliasRegistry, true);
            sb.append("        function ").append(event.name());
            sb.append("(extra: ").append(keyType);
            sb.append(", handler: ((event: ").append(eventType).append(") => void)): void;\n");
        }

        return sb.toString();
    }

    private void collectImports(Class<?> cls, Set<String> imports) {
        if (cls == null || cls.isPrimitive() || cls == Object.class) return;

        // 数组类：递归收集组件类型
        if (cls.isArray()) {
            collectImports(cls.getComponentType(), imports);
            return;
        }

        String name = cls.getName();
        if (!isRelevantClass(name)) return;

        // Event signatures reference only the event and dispatch-key symbols. Their member
        // dependencies belong to package declarations and the shared bounded scan.
        imports.add(name);
    }

    private boolean isRelevantClass(String name) {
        return ProbeConfigLoader.isRelevantClassDefault(name);
    }
}
