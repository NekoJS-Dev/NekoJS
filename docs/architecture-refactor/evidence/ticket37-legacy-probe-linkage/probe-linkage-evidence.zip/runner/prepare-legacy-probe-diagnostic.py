import hashlib
import json
import shutil
import socket
import sys
from pathlib import Path

project = Path.cwd()
source = project / 'build/ticket37-legacy-server-icu-installed/1.21.1'
root = (project / (sys.argv[1] if len(sys.argv) > 1 else 'build/ticket37-legacy-probe-diagnostic')).resolve()
assert root.parent == (project / 'build').resolve()
assert not root.exists()
for port in [25921, 25922]:
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
node = root / '1.21.1'
(node / 'mods').mkdir(parents=True)
for name in ['server.properties', 'eula.txt']:
    shutil.copyfile(source / name, node / name)
for jar in (source / 'mods').glob('*.jar'):
    if not jar.name.startswith('nekojs-'):
        shutil.copyfile(jar, node / 'mods' / jar.name)
jar = project / ('build/ticket37-legacy-probe-diagnostic2/1.21.1/mods/nekojs-neoforge-1.21.1-1.1.0-preview3-server.jar' if '--reuse-diagnostic' in sys.argv else 'versions/1.21.1/build/libs/nekojs-neoforge-1.21.1-1.1.0-preview3-server.jar')
shutil.copyfile(jar, node / 'mods' / jar.name)
(node / 'libraries').symlink_to((source / 'libraries').resolve(), target_is_directory=True)
custom = '--original-fixtures' in sys.argv
if custom:
    for folder in ['config', 'startup_scripts', 'server_scripts']:
        shutil.copytree(source / 'nekojs' / folder, node / 'nekojs' / folder)
manifest = dict(purpose='Temporary failed-class/depth instrumentation', sourceWip=True, artifactSha256=hashlib.sha256(jar.read_bytes()).hexdigest(), customStartupScripts=custom)
(root / 'preparation-manifest.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest))
