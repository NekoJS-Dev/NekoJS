import importlib.util
import json
import socket
import time
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else 'build/ticket37-legacy-probe-diagnostic') / '1.21.1'
spec = importlib.util.spec_from_file_location('owned_rcon', Path('bench/perf/rcon.py').resolve())
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
properties = dict(line.split('=', 1) for line in (root / 'server.properties').read_text().splitlines() if '=' in line)
commands = []
def command(text):
    with socket.create_connection(('127.0.0.1', int(properties['rcon.port'])), timeout=15) as connection:
        connection.settimeout(60)
        rcon.send_packet(connection, 1, 3, properties['rcon.password'])
        auth = rcon.recv_packet(connection)
        assert auth is not None and auth[0] != -1
        rcon.send_packet(connection, 10, 2, text)
        response = rcon.recv_packet(connection)
        assert response is not None
        commands.append(dict(command=text, response=response[2]))
        print(text, response[2], flush=True)
        return response[2]
ready = False
try:
    deadline = time.monotonic() + 300
    while time.monotonic() < deadline:
        log = (root / 'server-stdout.log').read_text(encoding='utf-8', errors='replace')
        if 'Done (' in log:
            ready = True
            break
        assert not (root / 'server-exit.json').exists(), 'Server exited before readiness'
        time.sleep(1)
    assert ready
    for language in ['typescript', 'python']:
        response = command('nekojs probe ' + language)
    assert all('[DEBUG-probe-legacy]' in record['response'] for record in commands), commands
finally:
    if ready:
        command('stop')
    (root / 'diagnostic-command-proof.json').write_text(json.dumps(commands, indent=2))
