import hashlib
import json
import subprocess
from pathlib import Path

root = Path.cwd()
files = subprocess.check_output(['git', '-c', 'core.safecrlf=false', 'diff', '--name-only', '--', '*.d.ts'], text=True).splitlines()
assert len(files) == 20, files
results = []
for name in files:
    before = subprocess.check_output(['git', 'show', '87e9b863:' + name]).decode().replace('\r\n', '\n')
    after = (root / name).read_text().replace('\r\n', '\n')
    without_imports = lambda text: '\n'.join(line for line in text.splitlines() if not line.startswith('import '))
    assert without_imports(before) == without_imports(after), name
    before_imports = [line for line in before.splitlines() if line.startswith('import ')]
    after_imports = [line for line in after.splitlines() if line.startswith('import ')]
    results.append(dict(path=name, beforeSha256=hashlib.sha256(before.encode()).hexdigest(), afterSha256=hashlib.sha256(after.encode()).hexdigest(), oldImportLines=len(before_imports), newImportLines=len(after_imports), nonImportBodyIdentical=True))
path = root / 'build/ticket37-config-sync-repair/legacy-probe-golden-audit.json'
path.write_text(json.dumps(dict(baseline='87e9b863', files=results, signaturesAndNonImportContentUnchanged=True, humanAcceptance='PENDING; no maintainer conclusion invented'), indent=2) + '\n')
patch = subprocess.check_output(['git', '-c', 'core.safecrlf=false', 'diff', '87e9b863', '--', 'common/src/test/resources/nekojs/probe', 'src/test/resources/golden/events-declared'])
(path.parent / 'legacy-probe-golden-diff.patch').write_bytes(patch)
print(json.dumps(dict(files=len(results), nonImportBodyIdentical=True, importLinesBefore=sum(r['oldImportLines'] for r in results), importLinesAfter=sum(r['newImportLines'] for r in results))))
