import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
repair = root / 'build/ticket37-config-sync-repair'
destination = root / 'docs/architecture-refactor/evidence/ticket37-legacy-probe-linkage'
assert not (destination / 'manifest.json').exists(), 'Preserve completed evidence'
sha = lambda data: hashlib.sha256(data).hexdigest()
roots = [root / 'build' / name for name in ['ticket37-legacy-probe-diagnostic', 'ticket37-legacy-probe-diagnostic2', 'ticket37-legacy-probe-diagnostic3', 'ticket37-legacy-probe-candidate1', 'ticket37-legacy-probe-candidate2']]
secrets = []
files = []
for trial in roots:
    server = trial / '1.21.1'
    for line in (server / 'server.properties').read_text().splitlines():
        if line.startswith('rcon.password='):
            secrets.append(line.partition('=')[2].encode())
    for path in trial.glob('*'):
        if path.is_file() and path.suffix in ['.json', '.patch']:
            files.append((path, trial.name + '/' + path.name))
    for path in server.glob('*'):
        if path.is_file() and path.suffix in ['.json', '.log', '.txt'] and path.name not in ['banned-ips.json', 'banned-players.json', 'ops.json', 'whitelist.json', 'usercache.json', 'eula.txt']:
            files.append((path, path.relative_to(root / 'build').as_posix()))
    for directory in ['logs', 'nekojs', '.neko_probe', 'crash-reports']:
        for path in (server / directory).rglob('*'):
            if path.is_file() and path.suffix in ['.json', '.log', '.txt', '.gz', '.js', '.mjs', '.ts', '.pyi', '.md', '.toml', '.typed']:
                files.append((path, path.relative_to(root / 'build').as_posix()))

for path in repair.glob('legacy-probe-*'):
    if path.is_file() and path.suffix in ['.txt', '.json', '.xml', '.patch', '.zip']:
        files.append((path, 'runner/' + path.name))
for pattern in ['*legacy-probe*.py', '*legacy-probe*.txt', 'audit-probe-event-goldens.py', 'snapshot-probe-final-tests.py', 'archive-probe-linkage.py', 'run-other-nodes.py']:
    for path in repair.glob(pattern):
        files.append((path, 'runner/' + path.name))
changed = subprocess.check_output(['git', '-c', 'core.safecrlf=false', 'diff', '--name-only', '87e9b863'], text=True).splitlines()
source_names = [name for name in changed if name.startswith(('common/', 'src/test/resources/golden/events-declared/', 'wiki/error-reference_'))]
source_names += ['common/src/test/java/com/tkisor/nekojs/probe/' + name for name in ['ProbeUnavailableTypeTest.java', 'ProbeLinkageFixture.java']]
for name in source_names:
    files.append((root / name, 'source/' + name))
source_patch = subprocess.check_output(['git', '-c', 'core.safecrlf=false', 'diff', '87e9b863', '--', 'common/src/main/java/com/tkisor/nekojs/probe', 'common/src/test/resources/nekojs/probe', 'src/test/resources/golden/events-declared', 'wiki/error-reference_cn.md', 'wiki/error-reference_us.md'])
(destination / 'source-and-golden-diff.patch').write_bytes(source_patch)

def checked(path):
    data = path.read_bytes()
    scan = gzip.decompress(data) if path.suffix == '.gz' else data
    assert not any(secret and secret in scan for secret in secrets), path
    assert not re.search(rb'(?m)^rcon\.password=', scan), path
    return data

entries = []
seen = set()
archive_path = destination / 'probe-linkage-evidence.zip'
with ZipFile(archive_path, 'w', ZIP_DEFLATED) as archive:
    for path, name in sorted(files, key=lambda pair: pair[1]):
        if name in seen:
            continue
        seen.add(name)
        data = checked(path)
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in entries:
        assert sha(archive.read(record['path'])) == record['sha256']
for name in ['legacy-probe-final-test-summary.json', 'legacy-probe-ide-summary.json', 'legacy-probe-golden-audit.json', 'legacy-probe-final-matrix.txt']:
    (destination / name).write_bytes(checked(repair / name))
runtime = json.loads((roots[-1] / '1.21.1/runtime-verdict.json').read_text())
artifact = roots[-1] / '1.21.1/mods/nekojs-neoforge-1.21.1-1.1.0-preview3-server.jar'
assert sha(artifact.read_bytes()) == '1bd35c6a79e243bf4094633e6fb194fd35d4aa0a8f7d84e5b4a8abcef5b84ba9'
assert artifact.read_bytes() == (root / 'versions/1.21.1/build/libs' / artifact.name).read_bytes()
assert runtime['checks']['typescriptGenerated'] and runtime['checks']['pythonGenerated']
warnings = runtime['probeWarnings']
types = sorted(set(re.findall(r'(?:incomplete|failed) for ([^;]+);', '\n'.join(warnings))))
manifest = dict(sourceBase='87e9b863', sourceWip=True, productionPatchSha256='9b70e7439799f09ebf2c7fc2f551cd4e39da4118e62b861b27444e6c9715ea6f', artifactSha256=sha(artifact.read_bytes()), runtime=runtime, warnedTypes=types, testSummary=json.loads((repair / 'legacy-probe-final-test-summary.json').read_text()), ideSummary=json.loads((repair / 'legacy-probe-ide-summary.json').read_text()), goldenMaintainerConclusion='PENDING', archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes())), entries=entries, exclusions=['server.properties/RCON credentials', 'worlds', 'account/launcher data', 'game binaries/libraries', 'raw JFR'])
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(destination / '.gitattributes').write_bytes(b'*.txt -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\n*.patch -text\n')
print(json.dumps(dict(entries=len(entries), warnedTypes=types, warningCount=len(warnings), archiveSha256=manifest['archive']['sha256'])))
