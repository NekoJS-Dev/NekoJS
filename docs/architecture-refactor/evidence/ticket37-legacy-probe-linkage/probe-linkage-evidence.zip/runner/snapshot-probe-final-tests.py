import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
out = root / 'build/ticket37-config-sync-repair'
counts = []
with ZipFile(out / 'legacy-probe-final-ordinary-xml.zip', 'x', ZIP_DEFLATED) as archive:
    for project in ['common', 'common-api-processor'] + ['versions/' + n for n in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']]:
        row = dict(project=project, xml=0, tests=0, skipped=0, failures=0, errors=0)
        for path in sorted((root / project / 'build/test-results/test').glob('TEST-*.xml')):
            suite = ET.parse(path).getroot()
            row['xml'] += 1
            for key in ['tests', 'skipped', 'failures', 'errors']:
                row[key] += int(suite.get(key, 0))
            archive.writestr(path.relative_to(root).as_posix(), path.read_bytes())
        counts.append(row)
total = {key: sum(row[key] for row in counts) for key in ['xml', 'tests', 'skipped', 'failures', 'errors']}
assert total == dict(xml=790, tests=4592, skipped=271, failures=0, errors=0), total
artifacts = []
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    for path in sorted((root / 'versions' / node / 'build/libs').glob('*.jar')):
        if path.name.endswith(('-sources.jar', '-dev.jar')):
            continue
        artifacts.append(dict(node=node, file=path.name, bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
document = dict(sourceBase='87e9b863', sourceWip=True, productionPatchSha256='9b70e7439799f09ebf2c7fc2f551cd4e39da4118e62b861b27444e6c9715ea6f', projects=counts, total=total, artifacts=artifacts, note='Ordinary test report snapshot; up-to-date outputs are included. Platform gates are separate. Baseline maintainer conclusion remains pending.')
(out / 'legacy-probe-final-test-summary.json').write_text(json.dumps(document, indent=2) + '\n')
print(json.dumps(total))
