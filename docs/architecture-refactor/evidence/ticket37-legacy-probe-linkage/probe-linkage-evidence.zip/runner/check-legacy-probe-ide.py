import collections
import json
import re
import subprocess
import os
from pathlib import Path

root = Path.cwd()
repair = root / 'build/ticket37-config-sync-repair'
server = root / 'build/ticket37-legacy-probe-candidate2/1.21.1'
files = sorted((server / '.neko_probe/python').rglob('*.pyi'))
assert len(files) == 317
config = dict(extends=str(server / 'pyrightconfig.json'), include=[os.path.relpath(path, repair).replace('\\', '/') for path in files], exclude=[])
config_path = repair / 'legacy-probe-explicit-stub-pyrightconfig.json'
config_path.write_text(json.dumps(config, indent=2) + '\n')
with (repair / 'legacy-probe-actual-explicit-pyright.json').open('xb') as output:
    result = subprocess.run(['node', 'C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js', '--project', str(config_path), '--outputjson'], stdout=output, stderr=subprocess.PIPE)
(repair / 'legacy-probe-explicit-pyright-stderr.txt').write_bytes(result.stderr)
assert not result.stderr, 'See legacy-probe-explicit-pyright-stderr.txt'
document = json.loads((repair / 'legacy-probe-actual-explicit-pyright.json').read_text())
assert document['summary']['filesAnalyzed'] == len(files), document['summary']
ts = []
for side in ['server', 'startup']:
    text = (repair / f'legacy-probe-actual-{side}-strict-tsc.txt').read_text(encoding='utf-8-sig')
    codes = collections.Counter(re.findall(r'error (TS\d+):', text))
    assert codes
    ts.append(dict(side=side, diagnostics=sum(codes.values()), codes=dict(sorted(codes.items())), exitCode=2, defaultIncludesPreserved=True, skipLibCheck=False))
summary = dict(typescript=ts, pyright=dict(version=document['version'], summary=document['summary'], exitCode=result.returncode, explicitInputStubCount=len(files), defaultDirectoryAttemptAnalyzed=0, note='The initial directory invocation analyzed zero files; it is not a PASS. Explicit enumeration checks every generated stub without editing generated outputs.'))
(repair / 'legacy-probe-ide-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
