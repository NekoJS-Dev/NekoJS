import hashlib
import json
import shutil
import socket
import sys
from pathlib import Path

root = Path.cwd()
target = (root / (sys.argv[1] if len(sys.argv) > 1 else 'build/ticket37-probe-other-candidates')).resolve()
assert target.parent == (root / 'build').resolve()
assert not target.exists()
summary = []
for node, port in [('26.1.2', 25931), ('26.2.0', 25961), ('26.1.2-fabric', 25941), ('26.2.0-fabric', 25951)]:
    if sys.argv[2:] and node not in sys.argv[2:]:
        continue
    for checked_port in [port, port + 1]:
        with socket.socket() as guard:
            guard.bind(('127.0.0.1', checked_port))
    base_node = '26.1.2' if node == '26.2.0' else node
    source = root / 'build/ticket37-ec7-installed-nodes-attempt2' / base_node
    directory = target / node
    (directory / 'mods').mkdir(parents=True)
    shutil.copyfile(source / 'eula.txt', directory / 'eula.txt')
    properties = source.joinpath('server.properties').read_text().splitlines()
    replacements = {'server-port': str(port), 'rcon.port': str(port + 1)}
    properties = [line.partition('=')[0] + '=' + replacements[line.partition('=')[0]] if line.partition('=')[0] in replacements else line for line in properties]
    (directory / 'server.properties').write_text('\n'.join(properties) + '\n')
    for folder in ['config', 'startup_scripts', 'server_scripts']:
        shutil.copytree(source / 'nekojs' / folder, directory / 'nekojs' / folder)
    for jar in (source / 'mods').glob('*.jar'):
        if not jar.name.startswith('nekojs-'):
            shutil.copyfile(jar, directory / 'mods' / jar.name)
    libraries = root / 'build/ticket37-config-sync-installed-attempt1/server/libraries' if node == '26.2.0' else source / 'libraries'
    (directory / 'libraries').symlink_to(libraries.resolve(), target_is_directory=True)
    if node.endswith('-fabric'):
        (directory / 'versions').symlink_to((source / 'versions').resolve(), target_is_directory=True)
        shutil.copyfile(source / 'fabric-server-launch.jar', directory / 'fabric-server-launch.jar')
    artifacts = [path for path in (root / 'versions' / node / 'build/libs').glob('*.jar') if not path.name.endswith(('-dev.jar', '-sources.jar'))]
    assert len(artifacts) == 1
    jar = artifacts[0]
    shutil.copyfile(jar, directory / 'mods' / jar.name)
    summary.append(dict(node=node, artifact=jar.name, sha256=hashlib.sha256(jar.read_bytes()).hexdigest(), sourceWip=True, productionPatchSha256='9b70e7439799f09ebf2c7fc2f551cd4e39da4118e62b861b27444e6c9715ea6f', serverPort=port, rconPort=port+1))
(target / 'preparation-manifest.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
