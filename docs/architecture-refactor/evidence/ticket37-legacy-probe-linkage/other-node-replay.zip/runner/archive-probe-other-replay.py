import gzip
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
destination = root / 'docs/architecture-refactor/evidence/ticket37-legacy-probe-linkage'
archive_path = destination / 'other-node-replay.zip'
assert not archive_path.exists(), 'Preserve completed evidence'
sha = lambda data: hashlib.sha256(data).hexdigest()
trials = [root / 'build' / name for name in ['ticket37-probe-other-candidates', 'ticket37-probe-other-candidates-repeat']]
files = {}
secrets = []
results = []
artifacts = []
for trial in trials:
    preparations = json.loads((trial / 'preparation-manifest.json').read_text())
    summary = json.loads((trial / 'runtime-summary.json').read_text())
    results.append(dict(trial=trial.name, results=summary))
    files[trial.name + '/preparation-manifest.json'] = trial / 'preparation-manifest.json'
    files[trial.name + '/runtime-summary.json'] = trial / 'runtime-summary.json'
    for preparation in preparations:
        server = trial / preparation['node']
        exit_record = json.loads((server / 'server-exit.json').read_text())
        assert exit_record['exitCode'] == 0, exit_record
        for line in (server / 'server.properties').read_text().splitlines():
            if line.startswith('rcon.password='):
                secrets.append(line.partition('=')[2].encode())
        artifact = server / 'mods' / preparation['artifact']
        actual_sha = sha(artifact.read_bytes())
        assert actual_sha == preparation['sha256']
        assert artifact.read_bytes() == (root / 'versions' / preparation['node'] / 'build/libs' / artifact.name).read_bytes()
        artifacts.append(dict(trial=trial.name, node=preparation['node'], artifact=artifact.name, sha256=actual_sha, serverExit=exit_record))
        for path in server.iterdir():
            if path.is_file() and (path.name.startswith(('owned-', 'server-', 'runtime-')) or path.name in ['pyrightconfig.json']):
                files[path.relative_to(root / 'build').as_posix()] = path
        for folder in ['logs', 'nekojs', '.neko_probe', 'crash-reports']:
            for path in (server / folder).rglob('*'):
                if path.is_file() and path.suffix in ['.json', '.log', '.txt', '.gz', '.js', '.mjs', '.ts', '.pyi', '.md', '.toml', '.typed']:
                    files[path.relative_to(root / 'build').as_posix()] = path
repair = root / 'build/ticket37-config-sync-repair'
for pattern in ['*probe-other-candidates*.txt', 'prepare-probe-other-candidates.py', 'configure-other-node-proofs.py', 'prove-legacy-probe-candidate.py', 'run-other-nodes.py', 'archive-probe-other-replay.py']:
    for path in repair.glob(pattern):
        files['runner/' + path.name] = path
records = []
with ZipFile(archive_path, 'w', ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        scan = gzip.decompress(data) if path.suffix == '.gz' else data
        assert not any(secret and secret in scan for secret in secrets), path
        assert not re.search(rb'(?m)^rcon\.password=', scan), path
        archive.writestr(name, data)
        records.append(dict(path=name, bytes=len(data), sha256=sha(data)))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in records:
        assert sha(archive.read(record['path'])) == record['sha256']
manifest = dict(sourceBase='87e9b863', sourceWipAtBuild=True, productionPatchSha256='9b70e7439799f09ebf2c7fc2f551cd4e39da4118e62b861b27444e6c9715ea6f', artifacts=artifacts, trials=results, archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes()), entries=len(records)), entries=records, exclusions=['server.properties/RCON credentials', 'worlds', 'account/launcher data', 'game binaries/libraries', 'raw JFR'])
(destination / 'other-node-replay-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(archive=manifest['archive'], results=[dict(trial=t['trial'], nodes=[dict(node=r['node'], verdict=r['verdict'], checks=r['checks']) for r in t['results']]) for t in results])))
