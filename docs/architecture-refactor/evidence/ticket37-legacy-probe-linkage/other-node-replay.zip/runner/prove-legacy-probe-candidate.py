import ast
import concurrent.futures
import importlib.util
import json
import socket
import time
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else 'build/ticket37-ec7-installed-nodes').resolve()
spec = importlib.util.spec_from_file_location('owned_rcon', Path('bench/perf/rcon.py').resolve())
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)

def prove(node):
    server = root / node
    properties = dict(line.split('=', 1) for line in (server / 'server.properties').read_text().splitlines() if '=' in line)
    port = int(properties['rcon.port'])
    password = properties['rcon.password']
    results = dict(node=node, commands=[], checks={}, errors=[])
    log_path = server / 'command-proof.txt'
    with log_path.open('x', encoding='utf-8') as output:
        def command(text):
            with socket.create_connection(('127.0.0.1', port), timeout=15) as connection:
                connection.settimeout(60)
                rcon.send_packet(connection, 1, 3, password)
                auth = rcon.recv_packet(connection)
                assert auth is not None and auth[0] != -1, 'Owned RCON authentication failed'
                rcon.send_packet(connection, 10, 2, text)
                if text.startswith('nekojs probe '):
                    # The long warning response spans multiple vanilla RCON packets.
                    # A later read-only command marks the end without relying on a timeout.
                    first = rcon.recv_packet(connection)
                    assert first is not None and first[0] == 10, 'Owned RCON first response missing'
                    # Wait for the first response before sending the marker: some vanilla
                    # versions reject two requests coalesced into the same socket read.
                    rcon.send_packet(connection, 11, 2, 'list')
                    parts = [first[2]]
                    while True:
                        response = rcon.recv_packet(connection)
                        assert response is not None, 'Owned RCON response missing'
                        if response[0] == 11:
                            break
                        assert response[0] == 10, response[0]
                        parts.append(response[2])
                    body = ''.join(parts)
                else:
                    response = rcon.recv_packet(connection)
                    assert response is not None, 'Owned RCON response missing'
                    body = response[2]
                output.write('COMMAND=' + text + '\nRESPONSE=' + body + '\n')
                output.flush()
                results['commands'].append(dict(command=text, response=body))
                return body

        ready = False
        try:
            deadline = time.monotonic() + 600
            while time.monotonic() < deadline:
                log = (server / 'server-stdout.log').read_text(encoding='utf-8', errors='replace') if (server / 'server-stdout.log').exists() else ''
                if 'Done (' in log or 'Done(' in log:
                    ready = True
                    break
                if (server / 'server-exit.json').exists():
                    raise RuntimeError('Owned server exited before readiness')
                time.sleep(1)
            assert ready, 'Owned server readiness deadline exceeded'
            print('READY', node, flush=True)
            checks = results['checks']
            for name, marker in [
                ('startupCallbacks', 'EC7-INSTALLED-STARTUP-CALLBACKS-PASS'),
                ('registrations', 'EC7-INSTALLED-REGISTRATIONS-PASS'),
                ('nestedFingerprint', 'EC7-INSTALLED-NESTED-FINGERPRINT-PASS'),
            ]:
                checks[name] = marker in log
            if not node.endswith('-fabric'):
                checks['fluidTypeIdentity'] = 'EC7-INSTALLED-FLUIDTYPE-IDENTITY-PASS' in log
            command('nekojs registry')
            ts_response = command('nekojs probe typescript')
            py_response = command('nekojs probe python')
            checks['typescriptGenerated'] = 'Probe generated:' in ts_response
            checks['pythonGenerated'] = 'Probe generated:' in py_response
            results['probeWarnings'] = [line for response in [ts_response, py_response]
                                        for line in response.splitlines() if 'NEKO-4029' in line]
            command('forceload add 0 0')
            time.sleep(2)
            command('fill -1 79 -1 1 79 1 minecraft:stone')
            checks['blockPlacement'] = 'changed' in command('setblock 2 80 0 installed_ec7:stone').lower()
            if not node.endswith('-fabric'):
                checks['fluidPlacement'] = 'changed' in command('setblock 3 80 0 installed_ec7:spring').lower()
            if node in ['26.1.2', '26.2.0']:
                command('summon minecraft:pig 0.5 80 0.5 {Tags:["ec7_installed_proof"],NoAI:1b,PersistenceRequired:1b}')
                for attempt in range(20):
                    entity = command('data get entity @e[type=minecraft:pig,tag=ec7_installed_proof,limit=1]')
                    if 'entity data:' in entity:
                        break
                    time.sleep(0.25)
                else:
                    raise RuntimeError('Summoned living entity did not become queryable')
                before = command('effect give @e[type=minecraft:pig,tag=ec7_installed_proof,limit=1] installed_ec7:proof_effect 60 0 true')
                checks['effectBeforeReload'] = 'Applied effect' in before and 'installed_ec7:proof_effect' in command('data get entity @e[type=minecraft:pig,tag=ec7_installed_proof,limit=1]')
            response = command('nekojs reload server')
            checks['reloadCommitted'] = 'phase=COMMIT - no errors' in response
            time.sleep(2)
            if node in ['26.1.2', '26.2.0']:
                command('effect clear @e[type=minecraft:pig,tag=ec7_installed_proof,limit=1] installed_ec7:proof_effect')
                after = command('effect give @e[type=minecraft:pig,tag=ec7_installed_proof,limit=1] installed_ec7:proof_effect 60 1 true')
                checks['effectAfterReload'] = 'Applied effect' in after and 'installed_ec7:proof_effect' in command('data get entity @e[type=minecraft:pig,tag=ec7_installed_proof,limit=1]')
            stubs = sorted((server / '.neko_probe/python').rglob('*.pyi'))
            checks['pythonStubCount'] = len(stubs)
            failures = []
            for path in stubs:
                try:
                    ast.parse(path.read_text(encoding='utf-8'), filename=str(path.relative_to(server)))
                except SyntaxError as error:
                    failures.append(dict(file=str(path.relative_to(server)), line=error.lineno, message=error.msg))
            checks['pythonAst'] = bool(stubs) and not failures
            results['pythonAstFailures'] = failures
        except Exception as error:
            results['errors'].append(str(error))
        finally:
            if ready:
                try:
                    command('stop')
                    results['shutdown'] = 'RCON stop requested; process exit verified separately'
                except Exception as error:
                    results['errors'].append('RCON shutdown: ' + str(error))
            results['verdict'] = 'PASS' if not results['errors'] and results['checks'] and all(results['checks'].values()) else 'NOT GREEN'
            if results['verdict'] == 'PASS' and results.get('probeWarnings'):
                results['verdict'] = 'PARTIAL: available output generated; reflection omissions remain explicit'
            (server / 'runtime-verdict.json').write_bytes((json.dumps(results, indent=2) + '\n').encode())
            print('PROOF_RESULT', node, results['verdict'], json.dumps(results['checks']), json.dumps(results['errors']), flush=True)
    return results

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    results = list(executor.map(prove, sys.argv[2:] or ['1.21.1', '26.1.2', '26.1.2-fabric', '26.2.0-fabric']))
(root / 'runtime-summary.json').write_bytes((json.dumps(results, indent=2) + '\n').encode())
