import { $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $ClientboundAddEntityPacket } from "java:net/minecraft/network/protocol/game";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_, $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $Entity, $Entity$RemovalReason, $Entity$RemovalReason_, $EntityDimensions, $EntityReference, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $EquipmentSlot, $EquipmentSlot_, $InterpolationHandler, $ItemSteerable, $LightningBolt, $LivingEntity, $LivingEntity$Fallsounds, $Mob, $MoverType, $MoverType_, $NeutralMob, $PathfinderMob, $Pose, $Pose_, $SpawnGroupData, $TraceableEntity } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $AbstractGolem } from "java:net/minecraft/world/entity/animal/golem";
import { $HoglinBase } from "java:net/minecraft/world/entity/monster/hoglin";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Raider } from "java:net/minecraft/world/entity/raid";
import { $DyeColor, $DyeColor_, $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $FluidState } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $VoxelShape } from "java:net/minecraft/world/phys/shapes";

export * as breeze from "java:net/minecraft/world/entity/monster/breeze";
export * as creaking from "java:net/minecraft/world/entity/monster/creaking";
export * as hoglin from "java:net/minecraft/world/entity/monster/hoglin";
export * as illager from "java:net/minecraft/world/entity/monster/illager";
export * as piglin from "java:net/minecraft/world/entity/monster/piglin";
export * as skeleton from "java:net/minecraft/world/entity/monster/skeleton";
export * as spider from "java:net/minecraft/world/entity/monster/spider";
export * as warden from "java:net/minecraft/world/entity/monster/warden";
export * as zombie from "java:net/minecraft/world/entity/monster/zombie";

declare module "java:net/minecraft/world/entity/monster" {
    export class $Blaze extends $Monster {
        constructor(blaze: $EntityType<$Blaze>, level: $Level);
        get lightLevelDependentMagicValue(): number;
        getLightLevelDependentMagicValue(): number;
        get onFire(): boolean;
        isOnFire(): boolean;
        get sensitiveToWater(): boolean;
        isSensitiveToWater(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
    }

    export class $Creeper extends $Monster {
        constructor(type: $EntityType<$Creeper>, level: $Level);
        get maxFallDistance(): number;
        getMaxFallDistance(): number;
        get swellDir(): number;
        getSwellDir(): number;
        set swellDir(value: number);
        get ignited(): boolean;
        isIgnited(): boolean;
        get powered(): boolean;
        isPowered(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        causeFallDamage(fallDistance: number, damageModifier: number, damageSource: $DamageSource): boolean;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        getSwelling(a: number): number;
        ignite(): void;
        killedEntity(level: $ServerLevel, entity: $LivingEntity, source: $DamageSource): boolean;
        thunderHit(level: $ServerLevel, lightningBolt: $LightningBolt): void;
        tick(): void;
    }

    export interface $CrossbowAttackMob extends $RangedAttackMob {
        getTarget(): $LivingEntity;
        onCrossbowAttackPerformed(): void;
        performCrossbowAttack(body: $LivingEntity, crossbowPower: number): void;
        setChargingCrossbow(isCharging: boolean): void;
    }

    export class $ElderGuardian extends $Guardian {
        constructor(type: $EntityType<$ElderGuardian>, level: $Level);
        static ELDER_SIZE_SCALE: number;
        get attackDuration(): number;
        getAttackDuration(): number;
        static createAttributes(): $AttributeSupplier$Builder;
    }

    export class $EnderMan extends $Monster implements $NeutralMob {
        constructor(type: $EntityType<$EnderMan>, level: $Level);
        get carriedBlock(): $BlockState;
        getCarriedBlock(): $BlockState;
        set carriedBlock(value: $BlockState_);
        get persistentAngerEndTime(): number;
        getPersistentAngerEndTime(): number;
        set persistentAngerEndTime(value: number);
        get persistentAngerTarget(): $EntityReference<$LivingEntity>;
        getPersistentAngerTarget(): $EntityReference<$LivingEntity>;
        set persistentAngerTarget(value: $EntityReference<$LivingEntity>);
        get creepy(): boolean;
        isCreepy(): boolean;
        get sensitiveToWater(): boolean;
        isSensitiveToWater(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        hasBeenStaredAt(): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playStareSound(): void;
        requiresCustomPersistence(): boolean;
        setBeingStaredAt(): void;
        startPersistentAngerTimer(): void;
    }

    export class $Endermite extends $Monster {
        constructor(type: $EntityType<$Endermite>, level: $Level);
        static checkEndermiteSpawnRules(type: $EntityType<$Endermite>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        tick(): void;
    }

    export interface $Enemy {
        static XP_REWARD_BOSS: number;
        static XP_REWARD_HUGE: number;
        static XP_REWARD_LARGE: number;
        static XP_REWARD_MEDIUM: number;
        static XP_REWARD_NONE: number;
        static XP_REWARD_SMALL: number;
    }

    export class $Ghast extends $Mob implements $Enemy {
        constructor(type: $EntityType<$Ghast>, level: $Level);
        get explosionPower(): number;
        getExplosionPower(): number;
        get maxSpawnClusterSize(): number;
        getMaxSpawnClusterSize(): number;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get charging(): boolean;
        isCharging(): boolean;
        set charging(value: boolean);
        static checkGhastSpawnRules(type: $EntityType<$Ghast>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        static faceMovementDirection(ghast: $Mob): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        isInvulnerableTo(level: $ServerLevel, source: $DamageSource): boolean;
        leashElasticDistance(): number;
        leashSnapDistance(): number;
        onClimbable(): boolean;
        supportQuadLeashAsHolder(): boolean;
        travel(input: $Vec3_): void;
    }

    export class $Giant extends $Monster {
        constructor(type: $EntityType<$Giant>, level: $Level);
        static createAttributes(): $AttributeSupplier$Builder;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
    }

    export class $Guardian extends $Monster {
        constructor(type: $EntityType<$Guardian>, level: $Level);
        get activeAttackTarget(): $LivingEntity;
        getActiveAttackTarget(): $LivingEntity;
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get attackDuration(): number;
        getAttackDuration(): number;
        get clientSideAttackTime(): number;
        getClientSideAttackTime(): number;
        get maxHeadXRot(): number;
        getMaxHeadXRot(): number;
        get moving(): boolean;
        isMoving(): boolean;
        static checkGuardianSpawnRules(type: $EntityType<$Guardian>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        checkSpawnObstruction(level: $LevelReader): boolean;
        getAttackAnimationScale(a: number): number;
        getSpikesAnimation(a: number): number;
        getTailAnimation(a: number): number;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        hasActiveAttackTarget(): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
    }

    export class $MagmaCube extends $Slime {
        constructor(type: $EntityType<$MagmaCube>, level: $Level);
        get lightLevelDependentMagicValue(): number;
        getLightLevelDependentMagicValue(): number;
        get onFire(): boolean;
        isOnFire(): boolean;
        static checkMagmaCubeSpawnRules(type: $EntityType<$MagmaCube>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        jumpFromGround(): void;
        setSize(size: number, updateHealth: boolean): void;
    }

    export class $Monster extends $PathfinderMob implements $Enemy {
        get fallSounds(): $LivingEntity$Fallsounds;
        getFallSounds(): $LivingEntity$Fallsounds;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        static checkAnyLightMonsterSpawnRules(type: $EntityType<$Monster>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static checkMonsterSpawnRules(type: $EntityType<$Mob>, level: $ServerLevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static checkSurfaceMonstersSpawnRules(type: $EntityType<$Mob>, level: $ServerLevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createMonsterAttributes(): $AttributeSupplier$Builder;
        static isDarkEnoughToSpawn(level: $ServerLevelAccessor, pos: $BlockPos_, random: $RandomSource): boolean;
        aiStep(): void;
        getProjectile(heldWeapon: $ItemStack_): $ItemStack;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        isPreventingPlayerRest(level: $ServerLevel, player: $Player): boolean;
        shouldDropExperience(): boolean;
    }

    export class $PatrollingMonster extends $Monster {
        get patrolTarget(): $BlockPos;
        getPatrolTarget(): $BlockPos;
        set patrolTarget(value: $BlockPos_);
        get patrolLeader(): boolean;
        isPatrolLeader(): boolean;
        set patrolLeader(value: boolean);
        static checkPatrollingMonsterSpawnRules(type: $EntityType<$PatrollingMonster>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        canBeLeader(): boolean;
        canJoinPatrol(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        findPatrolTarget(): void;
        hasPatrolTarget(): boolean;
        removeWhenFarAway(distSqr: number): boolean;
    }

    export class $Phantom extends $Mob implements $Enemy {
        constructor(type: $EntityType<$Phantom>, level: $Level);
        static FLAP_DEGREES_PER_TICK: number;
        static TICKS_PER_FLAP: number;
        get phantomSize(): number;
        getPhantomSize(): number;
        set phantomSize(value: number);
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get uniqueFlapTickOffset(): number;
        getUniqueFlapTickOffset(): number;
        get flapping(): boolean;
        isFlapping(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        onClimbable(): boolean;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        shouldRenderAtSqrDistance(distance: number): boolean;
        tick(): void;
        travel(input: $Vec3_): void;
    }

    export interface $RangedAttackMob {
        performRangedAttack(target: $LivingEntity, power: number): void;
    }

    export class $Ravager extends $Raider {
        constructor(type: $EntityType<$Ravager>, level: $Level);
        static ATTACK_DURATION: number;
        static STUN_DURATION: number;
        get attackTick(): number;
        getAttackTick(): number;
        get celebrateSound(): $SoundEvent;
        getCelebrateSound(): $SoundEvent;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get roarTick(): number;
        getRoarTick(): number;
        get stunnedTick(): number;
        getStunnedTick(): number;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        applyRaidBuffs(level: $ServerLevel, wave: number, isCaptain: boolean): void;
        canBeLeader(): boolean;
        checkSpawnObstruction(level: $LevelReader): boolean;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        handleEntityEvent(id: number): void;
        hasLineOfSight(target: $Entity): boolean;
    }

    export class $Shulker extends $AbstractGolem implements $Enemy {
        constructor(type: $EntityType<$Shulker>, level: $Level);
        get attachFace(): $Direction;
        getAttachFace(): $Direction;
        get color(): $DyeColor;
        getColor(): $DyeColor;
        get deltaMovement(): $Vec3;
        getDeltaMovement(): $Vec3;
        set deltaMovement(value: $Vec3_);
        get interpolation(): $InterpolationHandler;
        getInterpolation(): $InterpolationHandler;
        get maxHeadXRot(): number;
        getMaxHeadXRot(): number;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get variant(): $Optional<$DyeColor>;
        getVariant(): $Optional<$DyeColor>;
        static createAttributes(): $AttributeSupplier$Builder;
        static getProgressAabb(size: number, direction: $Direction_, progressTo: number, position: $Vec3_): $AABB;
        static getProgressDeltaAabb(size: number, direction: $Direction_, progressFrom: number, progressTo: number, position: $Vec3_): $AABB;
        canBeCollidedWith(other: $Entity): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getClientPeekAmount(a: number): number;
        getRenderPosition(a: number): $Vec3;
        get<T>(type: $DataComponentType<T>): T;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        move(moverType: $MoverType_, delta: $Vec3_): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playAmbientSound(): void;
        push(entity: $Entity): void;
        recreateFromPacket(packet: $ClientboundAddEntityPacket): void;
        setPos(x: number, y: number, z: number): void;
        startRiding(entity: $Entity, force: boolean, sendEventAndTriggers: boolean): boolean;
        stopRiding(): void;
        tick(): void;
    }

    export class $Silverfish extends $Monster {
        constructor(type: $EntityType<$Silverfish>, level: $Level);
        static checkSilverfishSpawnRules(type: $EntityType<$Silverfish>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        tick(): void;
    }

    export class $Slime extends $Mob implements $Enemy {
        constructor(type: $EntityType<$Slime>, level: $Level);
        static MAX_NATURAL_SIZE: number;
        static MAX_SIZE: number;
        static MIN_SIZE: number;
        oSquish: number;
        squish: number;
        targetSquish: number;
        get maxHeadXRot(): number;
        getMaxHeadXRot(): number;
        get size(): number;
        getSize(): number;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get type(): $EntityType<$Slime>;
        getType(): $EntityType<$Slime>;
        get tiny(): boolean;
        isTiny(): boolean;
        static checkSlimeSpawnRules(type: $EntityType<$Slime>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        jumpFromGround(): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playerTouch(player: $Player): void;
        push(entity: $Entity): void;
        refreshDimensions(): void;
        remove(reason: $Entity$RemovalReason_): void;
        setSize(size: number, updateHealth: boolean): void;
        tick(): void;
    }

    export class $Strider extends $Animal implements $ItemSteerable {
        constructor(strider: $EntityType<$Strider>, level: $Level);
        get controllingPassenger(): $LivingEntity;
        getControllingPassenger(): $LivingEntity;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get liquidCollisionShape(): $VoxelShape;
        getLiquidCollisionShape(): $VoxelShape;
        get onFire(): boolean;
        isOnFire(): boolean;
        get sensitiveToWater(): boolean;
        isSensitiveToWater(): boolean;
        get suffocating(): boolean;
        isSuffocating(): boolean;
        set suffocating(value: boolean);
        static checkStriderSpawnRules(ignoredType: $EntityType<$Strider>, level: $LevelAccessor, ignoredSpawnType: $EntitySpawnReason_, pos: $BlockPos_, ignoredRandom: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        boost(): boolean;
        canStandOnFluid(fluid: $FluidState): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        checkSpawnObstruction(level: $LevelReader): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Strider;
        getDismountLocationForPassenger(passenger: $LivingEntity): $Vec3;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        tick(): void;
    }

    export class $Vex extends $Monster implements $TraceableEntity {
        constructor(type: $EntityType<$Vex>, level: $Level);
        static FLAP_DEGREES_PER_TICK: number;
        static TICKS_PER_FLAP: number;
        get boundOrigin(): $BlockPos;
        getBoundOrigin(): $BlockPos;
        set boundOrigin(value: $BlockPos_);
        get lightLevelDependentMagicValue(): number;
        getLightLevelDependentMagicValue(): number;
        get owner(): $Mob;
        getOwner(): $Mob;
        set owner(value: $Mob);
        get charging(): boolean;
        isCharging(): boolean;
        get flapping(): boolean;
        isFlapping(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        restoreFrom(oldEntity: $Entity): void;
        tick(): void;
    }

    export class $Witch extends $Raider implements $RangedAttackMob {
        constructor(type: $EntityType<$Witch>, level: $Level);
        get celebrateSound(): $SoundEvent;
        getCelebrateSound(): $SoundEvent;
        get drinkingPotion(): boolean;
        isDrinkingPotion(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        applyRaidBuffs(level: $ServerLevel, wave: number, isCaptain: boolean): void;
        canBeLeader(): boolean;
        handleEntityEvent(id: number): void;
        performRangedAttack(target: $LivingEntity, power: number): void;
    }

    export class $Zoglin extends $Monster implements $HoglinBase {
        constructor(type: $EntityType<$Zoglin>, level: $Level);
        get attackAnimationRemainingTicks(): number;
        getAttackAnimationRemainingTicks(): number;
        get brain(): $Brain<$Zoglin>;
        getBrain(): $Brain<$Zoglin>;
        get target(): $LivingEntity;
        getTarget(): $LivingEntity;
        get adult(): boolean;
        isAdult(): boolean;
        get baby(): boolean;
        isBaby(): boolean;
        set baby(value: boolean);
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canBeLeashed(): boolean;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        handleEntityEvent(id: number): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
    }

}
