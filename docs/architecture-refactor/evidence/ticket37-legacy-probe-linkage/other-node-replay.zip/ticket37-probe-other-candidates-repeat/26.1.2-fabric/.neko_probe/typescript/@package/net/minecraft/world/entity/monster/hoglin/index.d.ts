import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $Entity, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Enemy } from "java:net/minecraft/world/entity/monster";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/monster/hoglin" {
    export class $Hoglin extends $Animal implements $Enemy, $HoglinBase {
        constructor(type: $EntityType<$Hoglin>, level: $Level);
        static CONVERSION_TIME: number;
        get attackAnimationRemainingTicks(): number;
        getAttackAnimationRemainingTicks(): number;
        get brain(): $Brain<$Hoglin>;
        getBrain(): $Brain<$Hoglin>;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get target(): $LivingEntity;
        getTarget(): $LivingEntity;
        get adult(): boolean;
        isAdult(): boolean;
        get converting(): boolean;
        isConverting(): boolean;
        static checkHoglinSpawnRules(type: $EntityType<$Hoglin>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canBeHunted(): boolean;
        canBeLeashed(): boolean;
        canFallInLove(): boolean;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        handleEntityEvent(id: number): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        removeWhenFarAway(distSqr: number): boolean;
        shouldDropExperience(): boolean;
    }

    export interface $HoglinBase {
        getAttackAnimationRemainingTicks(): number;
        hurtAndThrowTarget(level: $ServerLevel, body: $LivingEntity, target: $LivingEntity): boolean;
        throwTarget(body: $LivingEntity, target: $LivingEntity): void;
        static ATTACK_ANIMATION_DURATION: number;
        static PROBABILITY_OF_SPAWNING_AS_BABY: number;
    }

}
