import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AnimationState, $Entity, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Monster } from "java:net/minecraft/world/entity/monster";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $LevelReader } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/monster/creaking" {
    export class $Creaking extends $Monster {
        constructor(type: $EntityType<$Creaking>, level: $Level);
        static ATTACK_INTERVAL: number;
        static CREAKING_GRAY: number;
        static CREAKING_ORANGE: number;
        static INVULNERABILITY_ANIMATION_DURATION: number;
        static SPEED_MULTIPLIER_WHEN_IDLING: number;
        static TWITCH_DEATH_DURATION: number;
        attackAnimationState: $AnimationState;
        deathAnimationState: $AnimationState;
        invulnerabilityAnimationState: $AnimationState;
        get brain(): $Brain<$Creaking>;
        getBrain(): $Brain<$Creaking>;
        get homePos(): $BlockPos;
        getHomePos(): $BlockPos;
        set homePos(value: $BlockPos_);
        get target(): $LivingEntity;
        getTarget(): $LivingEntity;
        get active(): boolean;
        isActive(): boolean;
        get heartBound(): boolean;
        isHeartBound(): boolean;
        get pushable(): boolean;
        isPushable(): boolean;
        get tearingDown(): boolean;
        isTearingDown(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        activate(player: $Player): void;
        aiStep(): void;
        blameSourceForDamage(source: $DamageSource): $Player;
        canMove(): boolean;
        canUsePortal(ignorePassenger: boolean): boolean;
        checkCanMove(): boolean;
        checkEyeBlink(): void;
        creakingDeathEffects(source: $DamageSource): void;
        deactivate(): void;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        fireImmune(): boolean;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        handleEntityEvent(id: number): void;
        hasGlowingEyes(): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        knockback(power: number, xd: number, zd: number): void;
        playAttackSound(): void;
        playerIsStuckInYou(): boolean;
        push(xa: number, ya: number, za: number): void;
        setTearingDown(): void;
        tearDown(): void;
        tick(): void;
    }

}
