import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $DifficultyInstance, $SimpleContainer } from "java:net/minecraft/world";
import { $EntitySpawnReason, $EntitySpawnReason_, $LivingEntity, $SlotAccess, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $CrossbowAttackMob, $RangedAttackMob } from "java:net/minecraft/world/entity/monster";
import { $InventoryCarrier } from "java:net/minecraft/world/entity/npc";
import { $Raider } from "java:net/minecraft/world/entity/raid";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/monster/illager" {
    export class $AbstractIllager extends $Raider {
        get armPose(): $AbstractIllager$IllagerArmPose;
        getArmPose(): $AbstractIllager$IllagerArmPose;
        canAttack(target: $LivingEntity): boolean;
    }

    export class $AbstractIllager$IllagerArmPose {
        static ATTACKING: $AbstractIllager$IllagerArmPose;
        static BOW_AND_ARROW: $AbstractIllager$IllagerArmPose;
        static CELEBRATING: $AbstractIllager$IllagerArmPose;
        static CROSSBOW_CHARGE: $AbstractIllager$IllagerArmPose;
        static CROSSBOW_HOLD: $AbstractIllager$IllagerArmPose;
        static CROSSED: $AbstractIllager$IllagerArmPose;
        static NEUTRAL: $AbstractIllager$IllagerArmPose;
        static SPELLCASTING: $AbstractIllager$IllagerArmPose;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AbstractIllager$IllagerArmPose[];
        static valueOf(name: string): $AbstractIllager$IllagerArmPose;
    }

    export class $Evoker extends $SpellcasterIllager {
        constructor(type: $EntityType<$Evoker>, level: $Level);
        get celebrateSound(): $SoundEvent;
        getCelebrateSound(): $SoundEvent;
        static createAttributes(): $AttributeSupplier$Builder;
        applyRaidBuffs(level: $ServerLevel, wave: number, isCaptain: boolean): void;
    }

    export class $Illusioner extends $SpellcasterIllager implements $RangedAttackMob {
        constructor(type: $EntityType<$Illusioner>, level: $Level);
        static ILLUSION_SPREAD: number;
        get armPose(): $AbstractIllager$IllagerArmPose;
        getArmPose(): $AbstractIllager$IllagerArmPose;
        get celebrateSound(): $SoundEvent;
        getCelebrateSound(): $SoundEvent;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        applyRaidBuffs(level: $ServerLevel, wave: number, isCaptain: boolean): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getIllusionOffsets(a: number): $Vec3[];
        performRangedAttack(target: $LivingEntity, power: number): void;
    }

    export class $Pillager extends $AbstractIllager implements $CrossbowAttackMob, $InventoryCarrier {
        constructor(type: $EntityType<$Pillager>, level: $Level);
        get armPose(): $AbstractIllager$IllagerArmPose;
        getArmPose(): $AbstractIllager$IllagerArmPose;
        get celebrateSound(): $SoundEvent;
        getCelebrateSound(): $SoundEvent;
        get inventory(): $SimpleContainer;
        getInventory(): $SimpleContainer;
        get maxSpawnClusterSize(): number;
        getMaxSpawnClusterSize(): number;
        get preferredWeaponType(): $TagKey<$Item>;
        getPreferredWeaponType(): $TagKey<$Item>;
        get chargingCrossbow(): boolean;
        isChargingCrossbow(): boolean;
        set chargingCrossbow(value: boolean);
        static createAttributes(): $AttributeSupplier$Builder;
        applyRaidBuffs(level: $ServerLevel, wave: number, isCaptain: boolean): void;
        canUseNonMeleeWeapon(item: $ItemStack_): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getSlot(slot: number): $SlotAccess;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        onCrossbowAttackPerformed(): void;
        performRangedAttack(target: $LivingEntity, power: number): void;
    }

    export class $SpellcasterIllager extends $AbstractIllager {
        get armPose(): $AbstractIllager$IllagerArmPose;
        getArmPose(): $AbstractIllager$IllagerArmPose;
        get castingSpell(): boolean;
        isCastingSpell(): boolean;
        tick(): void;
    }

    export class $SpellcasterIllager$IllagerSpell {
        static BLINDNESS: $SpellcasterIllager$IllagerSpell;
        static DISAPPEAR: $SpellcasterIllager$IllagerSpell;
        static FANGS: $SpellcasterIllager$IllagerSpell;
        static NONE: $SpellcasterIllager$IllagerSpell;
        static SUMMON_VEX: $SpellcasterIllager$IllagerSpell;
        static WOLOLO: $SpellcasterIllager$IllagerSpell;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SpellcasterIllager$IllagerSpell[];
        static valueOf(name: string): $SpellcasterIllager$IllagerSpell;
    }

    export class $Vindicator extends $AbstractIllager {
        constructor(type: $EntityType<$Vindicator>, level: $Level);
        get armPose(): $AbstractIllager$IllagerArmPose;
        getArmPose(): $AbstractIllager$IllagerArmPose;
        get celebrateSound(): $SoundEvent;
        getCelebrateSound(): $SoundEvent;
        static createAttributes(): $AttributeSupplier$Builder;
        applyRaidBuffs(level: $ServerLevel, wave: number, isCaptain: boolean): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
    }

    export type $AbstractIllager$IllagerArmPose_ = $AbstractIllager$IllagerArmPose | "ATTACKING" | "BOW_AND_ARROW" | "CELEBRATING" | "CROSSBOW_CHARGE" | "CROSSBOW_HOLD" | "CROSSED" | "NEUTRAL" | "SPELLCASTING";
    export type $SpellcasterIllager$IllagerSpell_ = $SpellcasterIllager$IllagerSpell | "BLINDNESS" | "DISAPPEAR" | "FANGS" | "NONE" | "SUMMON_VEX" | "WOLOLO";
}
