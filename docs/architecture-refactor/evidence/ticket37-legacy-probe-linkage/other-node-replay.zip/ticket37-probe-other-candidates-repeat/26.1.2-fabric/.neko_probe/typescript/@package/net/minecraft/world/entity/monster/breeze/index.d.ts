import { $Optional } from "java:java/util";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $DebugValueSource$Registration } from "java:net/minecraft/util/debug";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AnimationState, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Monster } from "java:net/minecraft/world/entity/monster";
import { $Projectile, $ProjectileDeflection } from "java:net/minecraft/world/entity/projectile";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/monster/breeze" {
    export class $Breeze extends $Monster {
        constructor(type: $EntityType<$Monster>, level: $Level);
        idle: $AnimationState;
        inhale: $AnimationState;
        longJump: $AnimationState;
        shoot: $AnimationState;
        slide: $AnimationState;
        slideBack: $AnimationState;
        get brain(): $Brain<$Breeze>;
        getBrain(): $Brain<$Breeze>;
        get firingYPosition(): number;
        getFiringYPosition(): number;
        get fluidJumpThreshold(): number;
        getFluidJumpThreshold(): number;
        get headRotSpeed(): number;
        getHeadRotSpeed(): number;
        get hurtBy(): $Optional<$LivingEntity>;
        getHurtBy(): $Optional<$LivingEntity>;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get target(): $LivingEntity;
        getTarget(): $LivingEntity;
        static createAttributes(): $AttributeSupplier$Builder;
        canAttack(target: $LivingEntity): boolean;
        causeFallDamage(fallDistance: number, damageModifier: number, damageSource: $DamageSource): boolean;
        deflection(projectile: $Projectile): $ProjectileDeflection;
        emitGroundParticles(amount: number): void;
        emitJumpTrailParticles(): void;
        isInvulnerableTo(level: $ServerLevel, source: $DamageSource): boolean;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playAmbientSound(): void;
        playWhirlSound(): void;
        registerDebugValues(level: $ServerLevel, registration: $DebugValueSource$Registration): void;
        resetJumpTrail(): $Breeze;
        tick(): void;
        withinInnerCircleRange(target: $Vec3_): boolean;
    }

}
