import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult, $SimpleContainer } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity, $Pose, $Pose_, $SlotAccess, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $Brain, $Brain$Provider } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $CrossbowAttackMob, $Monster } from "java:net/minecraft/world/entity/monster";
import { $InventoryCarrier } from "java:net/minecraft/world/entity/npc";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/monster/piglin" {
    export class $AbstractPiglin extends $Monster {
        constructor(type: $EntityType<$AbstractPiglin>, level: $Level);
        static CONVERSION_TIME: number;
        get armPose(): $PiglinArmPose;
        getArmPose(): $PiglinArmPose;
        get target(): $LivingEntity;
        getTarget(): $LivingEntity;
        get adult(): boolean;
        isAdult(): boolean;
        get converting(): boolean;
        isConverting(): boolean;
        playAmbientSound(): void;
    }

    export class $Piglin extends $AbstractPiglin implements $CrossbowAttackMob, $InventoryCarrier {
        constructor(type: $EntityType<$AbstractPiglin>, level: $Level);
        get armPose(): $PiglinArmPose;
        getArmPose(): $PiglinArmPose;
        get brain(): $Brain<$Piglin>;
        getBrain(): $Brain<$Piglin>;
        get inventory(): $SimpleContainer;
        getInventory(): $SimpleContainer;
        get preferredWeaponType(): $TagKey<$Item>;
        getPreferredWeaponType(): $TagKey<$Item>;
        get baby(): boolean;
        isBaby(): boolean;
        set baby(value: boolean);
        get dancing(): boolean;
        isDancing(): boolean;
        set dancing(value: boolean);
        static checkPiglinSpawnRules(type: $EntityType<$Piglin>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canUseNonMeleeWeapon(item: $ItemStack_): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getSlot(slot: number): $SlotAccess;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        onCrossbowAttackPerformed(): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        performRangedAttack(target: $LivingEntity, power: number): void;
        removeWhenFarAway(distSqr: number): boolean;
        startRiding(entityToRide: $Entity, force: boolean, sendEventAndTriggers: boolean): boolean;
        wantsToPickUp(level: $ServerLevel, itemStack: $ItemStack_): boolean;
    }

    export class $PiglinArmPose {
        static ADMIRING_ITEM: $PiglinArmPose;
        static ATTACKING_WITH_MELEE_WEAPON: $PiglinArmPose;
        static CROSSBOW_CHARGE: $PiglinArmPose;
        static CROSSBOW_HOLD: $PiglinArmPose;
        static DANCING: $PiglinArmPose;
        static DEFAULT: $PiglinArmPose;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PiglinArmPose[];
        static valueOf(name: string): $PiglinArmPose;
    }

    export class $PiglinBrute extends $AbstractPiglin {
        constructor(type: $EntityType<$PiglinBrute>, level: $Level);
        static BRAIN_PROVIDER: $Brain$Provider<$PiglinBrute>;
        get armPose(): $PiglinArmPose;
        getArmPose(): $PiglinArmPose;
        get brain(): $Brain<$PiglinBrute>;
        getBrain(): $Brain<$PiglinBrute>;
        static createAttributes(): $AttributeSupplier$Builder;
        canHunt(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        wantsToPickUp(level: $ServerLevel, itemStack: $ItemStack_): boolean;
    }

    export type $PiglinArmPose_ = $PiglinArmPose | "ADMIRING_ITEM" | "ATTACKING_WITH_MELEE_WEAPON" | "CROSSBOW_CHARGE" | "CROSSBOW_HOLD" | "DANCING" | "DEFAULT";
}
