import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $DataFixTypes, $DataFixTypes_ } from "java:net/minecraft/util/datafix";

export * as maps from "java:net/minecraft/world/level/saveddata/maps";

declare module "java:net/minecraft/world/level/saveddata" {
    export class $SavedData {
        constructor();
        get dirty(): boolean;
        isDirty(): boolean;
        set dirty(value: boolean);
        setDirty(arg0: boolean): void;
        setDirty(): void;
    }

    export class $SavedDataType<T extends $SavedData> extends $Record {
        constructor(arg0: $Identifier_, arg1: $Supplier_<T, T>, arg2: $Codec<T>);
        constructor(arg0: $Identifier_, arg1: $Supplier_<T, T>, arg2: $Codec<T>, arg3: $DataFixTypes_);
        constructor(arg0: $Identifier_, arg1: $SavedDataType$Factory_<T, $ServerLevel, T>, arg2: $SavedDataType$Factory_<$Codec<T>, $ServerLevel, $Codec<T>>);
        constructor(id: $Identifier_, factory: $SavedDataType$Factory_<T, $ServerLevel, T>, codecFactory: $SavedDataType$Factory_<$Codec<T>, $ServerLevel, $Codec<T>>, dataFixType: $DataFixTypes_);
        codecFactory(): $SavedDataType$Factory<$Codec<T>>;
        codec(): $Codec<T>;
        constructor(): $Supplier<T>;
        dataFixType(): $DataFixTypes;
        equals(arg0: object): boolean;
        factory(): $SavedDataType$Factory<T>;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
    }

    export interface $SavedDataType$Factory<T> {
        create(arg0: $ServerLevel): T;
    }

    export class $WeatherData extends $SavedData {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number, arg3: boolean, arg4: boolean);
        static CODEC: $Codec<$WeatherData>;
        static TYPE: $SavedDataType<$WeatherData>;
        get clearWeatherTime(): number;
        getClearWeatherTime(): number;
        set clearWeatherTime(value: number);
        get rainTime(): number;
        getRainTime(): number;
        set rainTime(value: number);
        get thunderTime(): number;
        getThunderTime(): number;
        set thunderTime(value: number);
        get raining(): boolean;
        isRaining(): boolean;
        set raining(value: boolean);
        get thundering(): boolean;
        isThundering(): boolean;
        set thundering(value: boolean);
        setClearWeatherTime(arg0: number): void;
        setRainTime(arg0: number): void;
        setRaining(arg0: boolean): void;
        setThunderTime(arg0: number): void;
        setThundering(arg0: boolean): void;
    }

    export type $SavedDataType$Factory_<Host0 = any, CallbackArg0 = $ServerLevel, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($SavedDataType$Factory<Host0> & { readonly [Symbol.hasInstance]?: never });
}
