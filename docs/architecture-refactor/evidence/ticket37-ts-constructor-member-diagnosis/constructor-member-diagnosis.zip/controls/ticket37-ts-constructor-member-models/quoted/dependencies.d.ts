declare module 'java:java/lang' { export class $Record {} }
declare module 'java:java/util' { export interface $List<T> {} }
