import { $ApiSignature, $ApiTypeRef } from 'java:com/tkisor/nekojs/api/surface';
const type = $ApiTypeRef.voidType();
const direct: $ApiSignature = new $ApiSignature([], type, true);
const made: $ApiSignature = $ApiSignature.constructor([], type);
const bean: boolean = direct.constructor;
export {direct, made, bean};
