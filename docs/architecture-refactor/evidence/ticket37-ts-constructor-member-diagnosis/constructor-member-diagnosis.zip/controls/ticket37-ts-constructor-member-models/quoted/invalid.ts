import { $ApiSignature, $ApiTypeRef } from 'java:com/tkisor/nekojs/api/surface';
const type = $ApiTypeRef.voidType();
const direct = new $ApiSignature([], type, true);
const wrongBean: string = direct.constructor;
const wrongFactory: number = $ApiSignature.constructor([], type);
$ApiSignature.constructor(1, type);
export {wrongBean,wrongFactory};
