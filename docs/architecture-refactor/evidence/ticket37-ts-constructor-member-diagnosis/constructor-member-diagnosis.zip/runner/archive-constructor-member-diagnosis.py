import hashlib
import json
import subprocess
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd().resolve()
runner = root/'build/ticket37-config-sync-repair'
out = root/'docs/architecture-refactor/evidence/ticket37-ts-constructor-member-diagnosis'
assert not out.exists()
out.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
for folder in ['ticket37-ts-constructor-member-red','ticket37-ts-constructor-member-models','ticket37-ts-constructor-member-resolved-red','ticket37-ts-constructor-member-resolved-models']:
    for path in (root/'build'/folder).rglob('*'):
        if path.is_file(): files['controls/'+folder+'/'+path.relative_to(root/'build'/folder).as_posix()] = path
for path in runner.iterdir():
    if path.is_file() and 'constructor-member' in path.name and path.name != 'constructor-member-archive.txt': files['runner/'+path.name] = path
trial = root/'build/ticket37-node-util-predicate-installed'
files['actual/whole-26.1.2-server-tsc.txt'] = trial/'ide/26.1.2-server-tsc.txt'
files['actual/surface.d.ts'] = trial/'26.1.2/.neko_probe/typescript/@package/com/tkisor/nekojs/api/surface/index.d.ts'
files['actual/saveddata.d.ts'] = trial/'26.1.2/.neko_probe/typescript/@package/net/minecraft/world/level/saveddata/index.d.ts'
for name in ['common/src/main/java/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.java','common/src/main/java/com/tkisor/nekojs/api/surface/ApiSignature.java']:
    files['source/'+name] = root/name
secrets = []
for node in ['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']:
    secrets += [line.partition('=')[2].encode() for line in (trial/node/'server.properties').read_text().splitlines() if line.startswith('rcon.password=')]
red = json.loads((root/'build/ticket37-ts-constructor-member-resolved-red/summary.json').read_text())
models = json.loads((root/'build/ticket37-ts-constructor-member-resolved-models/summary.json').read_text())
assert red['exitCode'] == 2 and len(red['diagnostics']) == 3
assert models['models'][0]['checks'][0]['exitCode'] == 2
assert models['models'][1]['checks'][0]['exitCode'] == 0
assert models['models'][1]['checks'][1]['exitCode'] == 2 and len(models['models'][1]['checks'][1]['diagnostics']) == 3
entries = []
archive_path = out/'constructor-member-diagnosis.zip'
with ZipFile(archive_path,'x',ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):
        data = path.read_bytes()
        assert not any(secret and secret in data for secret in secrets)
        archive.writestr(name,data)
        entries.append(dict(path=name,bytes=len(data),sha256=sha(data)))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(entries)
    for row in entries: assert sha(archive.read(row['path'])) == row['sha256']
manifest = dict(sourceRevision='60139fffffa6e54b2248797c2a32d4fd75025a54', evidenceBase=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    generatedSurfaceSha256=sha(files['actual/surface.d.ts'].read_bytes()), red=red, models=models,
    archive=dict(file=archive_path.name,entries=len(entries),bytes=archive_path.stat().st_size,sha256=sha(archive_path.read_bytes())),entries=entries,
    productionChange='NONE', generatedSourceModified=False, initialHarnessFailures='Original missing-module diagnostic and incorrect quoted-getter expectation retained',
    limitations=['Only two external dependency leaf declarations isolated', 'Computed names only tested on candidate copies', 'Runtime host access and real generator regression NOT RUN', 'Whole default IDE FAIL', 'NOT A COMPLETED REPAIR'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archive=manifest['archive'],productionChange='NONE',computedCandidate='caller0/three negative rejects',overall='NOT COMPLETE')))
