import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
red = root/'build/ticket37-ts-constructor-member-resolved-red'
out = root/'build/ticket37-ts-constructor-member-resolved-models'
assert not out.exists()
out.mkdir()
original = (red/'surface.d.ts').read_text(encoding='utf-8')
assert original.count('get constructor(): boolean;') == 1 and original.count('static constructor(parameters:') == 1
rows = []
for model in ['quoted','computed']:
    target = out/model
    target.mkdir()
    name = '"constructor"' if model == 'quoted' else '["constructor"]'
    candidate = original.replace('get constructor(): boolean;', 'get '+name+'(): boolean;').replace('static constructor(parameters:', 'static '+name+'(parameters:')
    assert candidate.count('constructor(parameters: $ApiParameter[], returnType: $ApiTypeRef, isConstructor: boolean);') == 1
    (target/'surface.d.ts').write_text(candidate,encoding='utf-8')
    for filename in ['dependencies.d.ts','caller.ts','tsconfig.json']:
        (target/filename).write_bytes((red/filename).read_bytes())
    (target/'invalid.ts').write_text("import { $ApiSignature, $ApiTypeRef } from 'java:com/tkisor/nekojs/api/surface';\nconst type = $ApiTypeRef.voidType();\nconst direct = new $ApiSignature([], type, true);\nconst wrongBean: string = direct.constructor;\nconst wrongFactory: number = $ApiSignature.constructor([], type);\n$ApiSignature.constructor(1, type);\nexport {wrongBean,wrongFactory};\n",encoding='utf-8')
    records = []
    for mode in ['caller','invalid']:
        config = json.loads((target/'tsconfig.json').read_text())
        config['files'][-1] = mode+'.ts'
        config_path = target/(mode+'-tsconfig.json')
        config_path.write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
        result = subprocess.run(['node',str(root/'node_modules/typescript/bin/tsc'),'--project',str(config_path),'--pretty','false'],capture_output=True)
        assert not result.stderr
        (target/(mode+'-tsc.txt')).write_bytes(result.stdout)
        lines = result.stdout.decode().splitlines()
        records.append(dict(caller=mode,exitCode=result.returncode,diagnostics=lines))
    rows.append(dict(model=model,checks=records,actualConstructorSignatureRetained=True))
    if model == 'quoted':
        assert records[0]['exitCode'] == 2 and len(records[0]['diagnostics']) == 2 and all('TS2792' not in line for line in records[0]['diagnostics'])
    else:
        assert records[0]['exitCode'] == 0
        assert records[1]['exitCode'] == 2 and len(records[1]['diagnostics']) == 3
document = dict(models=rows, canonicalGeneratedFileUnchanged=True,
    limitations=['Separate candidate copies only, not production generation', 'No Java host runtime/property access proof', 'No regression or installed new-JAR proof', 'Not a completed repair'])
(out/'summary.json').write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8')
print(json.dumps(document))

