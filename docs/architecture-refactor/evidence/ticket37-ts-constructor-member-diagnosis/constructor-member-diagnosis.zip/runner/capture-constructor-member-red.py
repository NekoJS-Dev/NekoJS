import hashlib
import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
out = root/'build/ticket37-ts-constructor-member-red'
assert not out.exists()
out.mkdir()
original = root/'build/ticket37-node-util-predicate-installed/26.1.2/.neko_probe/typescript/@package/com/tkisor/nekojs/api/surface/index.d.ts'
data = original.read_bytes()
(out/'surface.d.ts').write_bytes(data)
(out/'dependencies.d.ts').write_text("declare module 'java:java/lang' { export class $Record {} }\ndeclare module 'java:java/util' { export interface $List<T> {} }\n", encoding='utf-8')
(out/'caller.ts').write_text("import { $ApiSignature, $ApiTypeRef } from 'java:com/tkisor/nekojs/api/surface';\nconst type = $ApiTypeRef.voidType();\nconst direct: $ApiSignature = new $ApiSignature([], type, true);\nconst made: $ApiSignature = $ApiSignature.constructor([], type);\nconst bean: boolean = direct.constructor;\nexport {direct, made, bean};\n",encoding='utf-8')
config = dict(compilerOptions=dict(strict=True,skipLibCheck=False,noEmit=True,types=[],target='ES2020'),files=['dependencies.d.ts','surface.d.ts','caller.ts'])
(out/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
result = subprocess.run(['node',str(root/'node_modules/typescript/bin/tsc'),'--project',str(out/'tsconfig.json'),'--pretty','false'],capture_output=True)
assert not result.stderr
(out/'tsc.txt').write_bytes(result.stdout)
lines = result.stdout.decode().splitlines()
assert result.returncode == 2 and all(any(code in line for line in lines) for code in ['TS1341','TS1089','TS1093'])
summary = dict(sourceRevision='60139fffffa6e54b2248797c2a32d4fd75025a54', frozenGeneratedFileSha256=hashlib.sha256(data).hexdigest(),
    fullGeneratedFileUnchanged=True, exitCode=result.returncode, diagnostics=lines,
    limitations=['Only two external dependency leaf declarations replaced by explicit isolation fixtures', 'No runtime or production renderer change', 'Whole default-includes strict report separately retained'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
