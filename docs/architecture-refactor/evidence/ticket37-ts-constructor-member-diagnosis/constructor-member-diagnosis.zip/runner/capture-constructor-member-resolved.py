import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
previous = root/'build/ticket37-ts-constructor-member-red'
out = root/'build/ticket37-ts-constructor-member-resolved-red'
assert not out.exists()
out.mkdir()
for name in ['surface.d.ts','dependencies.d.ts','caller.ts']:
    (out/name).write_bytes((previous/name).read_bytes())
config = json.loads((previous/'tsconfig.json').read_text())
config['compilerOptions'].update(module='ESNext',moduleResolution='bundler',paths={'java:com/tkisor/nekojs/api/surface':['./surface.d.ts']})
(out/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
result = subprocess.run(['node',str(root/'node_modules/typescript/bin/tsc'),'--project',str(out/'tsconfig.json'),'--pretty','false'],capture_output=True)
assert not result.stderr
(out/'tsc.txt').write_bytes(result.stdout)
lines = result.stdout.decode().splitlines()
assert result.returncode == 2
assert not any('TS2792' in line or '/caller.ts' in line for line in lines)
assert len(lines) == 3 and all(any(code in line for line in lines) for code in ['TS1341','TS1089','TS1093'])
document = dict(exitCode=result.returncode,diagnostics=lines,wholeGeneratedBytesEqual=(out/'surface.d.ts').read_bytes()==(previous/'surface.d.ts').read_bytes(),
    correction='Only isolated caller module mapping corrected; original failed caller and model assertion retained',
    limitations=['Two external leaf dependency fixtures', 'No production or runtime change'])
(out/'summary.json').write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8')
print(json.dumps(document))
