import json
import statistics
from pathlib import Path

root = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/historical-reference-3400')
groups = json.loads((root/'groups.json').read_text())
assert [row['group'] for row in groups] == ['startup', 'reload-1', 'reload-2']
result = dict(diagnosticOnly=True, currentSourceFormalVerdictUnchanged='FAIL', groups={})
for group in groups:
    assert group['exitCode'] == 0 and len(group['outputs']) == 1
    directory = Path(group['outputs'][0])
    rows = [json.loads(line) for line in (directory/'samples.jsonl').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    assert all(row['rev'] == '3400e97e' and row['node'] == '26.1.2' for row in rows)
    assert all(not row['forced_kill'] and not row.get('killed') and not row.get('timeout') and row['stop_channel'] == 'rcon' for row in rows)
    formal = [row for row in rows if row['kind'] == 'formal']
    assert len(formal) == 5
    if group['group'] == 'startup':
        assert len(rows) == 7 and [row['kind'] for row in rows] == ['warmup']*2+['formal']*5
        assert all(row['wall_done_ms'] is not None and row['done_s'] is not None for row in rows)
        values = [row['wall_done_ms'] for row in formal]
        result['groups']['startup'] = dict(valuesMs=values, meanMs=statistics.mean(values),
            historicalThresholdMs=41173, withinHistoricalThreshold=statistics.mean(values) <= 41173)
    else:
        assert len(rows) == 5
        assert all(row['marker_ms'] is not None and row['rcon_rtt_ms'] is not None for row in rows)
        assert all('PERF02-SERVER tick-bench load' in row['marker_line'] and '- no errors.' in row['rcon_response'] for row in rows)
        values = [row['marker_ms'] for row in formal]
        result['groups'][group['group']] = dict(valuesMs=values, meanMs=statistics.mean(values),
            rconValuesMs=[row['rcon_rtt_ms'] for row in formal],
            rconMeanMs=statistics.mean(row['rcon_rtt_ms'] for row in formal),
            historicalThresholdMs=285.3, withinHistoricalThreshold=statistics.mean(values) <= 285.3)
(root/'summary.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
