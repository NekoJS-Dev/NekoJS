import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
control = tools/'historical-reference-3400'
preparation = json.loads((control/'preparation.json').read_text())
inner = Path(preparation['project'])
root = Path(preparation['worktree'])
assert subprocess.run(['git', 'diff', '--quiet'], cwd=root).returncode == 0
target = project/'docs/architecture-refactor/evidence/2026-10-17-reload-performance/historical-reference-3400'
properties = dict(line.split('=', 1) for line in Path(
    'C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run/server.properties'
).read_text().splitlines() if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password'].encode()
files, redactions = {}, {}


def add(file, name, binary=False):
    data = file.read_bytes()
    assert name not in files
    if secret in data:
        assert not binary, 'Omit binary evidence containing credential bytes; never byte-edit it'
        redactions[name] = dict(originalSha256=hashlib.sha256(data).hexdigest(), occurrences=data.count(secret))
        data = data.replace(secret, b'<REDACTED-RCON-CREDENTIAL>')
    files[name] = data


for file in control.iterdir():
    if file.is_file(): add(file, 'control/'+file.name)
for row in json.loads((control/'groups.json').read_text()):
    directory = Path(row['outputs'][0])
    for file in directory.rglob('*'):
        if file.is_file(): add(file, row['group']+'/'+file.relative_to(directory).as_posix())
for relative in preparation['addedUntrackedHarness']:
    add(inner/relative, 'fixed-harness/'+relative.removeprefix('bench/perf/'))
for module, directory in [('common', inner/'common/build/libs'), ('26.1.2', inner/'versions/26.1.2/build/libs')]:
    jars = [file for file in directory.glob('*.jar') if not file.name.endswith(('-sources.jar', '-javadoc.jar'))]
    assert len(jars) == 1, module
    add(jars[0], 'binaries/'+module+'.jar', binary=True)
for name in ['prepare-historical-reference.py', 'run-historical-reference.py', 'analyze-historical-reference.py', 'seal-historical-reference.py']:
    add(tools/name, 'tooling/'+name)
files['redactions.json'] = (json.dumps(redactions, indent=2)+'\n').encode()
packed = target/'evidence.zip'
assert not packed.exists()
with zipfile.ZipFile(packed, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()): archive.writestr(name, data)
manifest = dict(diagnosticOnly=True, revision=preparation['revision'],
    archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
    entries={name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(entries=len(files), zipBytes=packed.stat().st_size, archiveSha256=manifest['archiveSha256'])))
