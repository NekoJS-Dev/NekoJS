import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
root = Path(sys.argv[1]).resolve(strict=True)
assert root == Path('C:/Users/11515/.codex/worktrees/historical-perf-3400/NekoJS-mult')
for path in [root, *root.parents]:
    assert not path.is_symlink() and not path.is_junction()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert revision.startswith('3400e97e')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
inner = root/'NekoJS-mult'
assert (inner/'gradlew.bat').is_file() and (inner/'versions/26.1.2/gradle.properties').is_file()
output = tools/'historical-reference-3400'
output.mkdir(exist_ok=False)
destination = inner/'bench/perf'
assert not destination.exists()
files = [path for path in (project/'bench/perf/fixtures').rglob('*') if path.is_file()]
files.extend([project/'bench/perf/sample.ps1', project/'bench/perf/rcon.py'])
bindings = {}
for source in files:
    relative = source.relative_to(project).as_posix()
    reference = subprocess.check_output(['git', 'rev-parse', 'c8604eb4b:'+relative], cwd=project, text=True).strip()
    actual = subprocess.check_output(['git', 'hash-object', str(source)], cwd=project, text=True).strip()
    assert reference == actual, relative
    target = inner/relative
    assert target.resolve().is_relative_to(inner.resolve())
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    bindings[relative] = hashlib.sha256(target.read_bytes()).hexdigest()
assert bindings['bench/perf/sample.ps1'] == '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
assert subprocess.run(['git', 'diff', '--quiet'], cwd=root).returncode == 0
for port in [25871, 25872]:
    with socket.socket() as listener: listener.bind(('127.0.0.1', port))
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME']+'/bin;'+environment['PATH']
environment['GRADLE_USER_HOME'] = 'D:/mcmodDemo/NekoJS/.gradle-<REDACTED-RCON-CREDENTIAL>'
preparation = dict(revision=revision, worktree=str(root), project=str(inner),
    fixedHarnessRevision='c8604eb4b', addedUntrackedHarness=bindings,
    historicalBinaryUnavailable=True, historicalWorldUnavailable=True,
    scope='Rebuild old behavior in the current environment; not the historical binary or world')
(output/'preparation.json').write_text(json.dumps(preparation, indent=2)+'\n')
with (output/'build-stdout.log').open('wb') as stdout, (output/'build-stderr.log').open('wb') as stderr:
    process = subprocess.Popen(['cmd.exe', '/d', '/c', 'gradlew.bat', '--offline', ':26.1.2:jar', '--console=plain',
                                '--no-configuration-cache'], cwd=inner, env=environment, stdout=stdout, stderr=stderr)
    (output/'build-owner.json').write_text(json.dumps(dict(pid=process.pid, project=str(inner), operation='historical-reference-jar'))+'\n')
    code = process.wait()
(output/'build-result.json').write_text(json.dumps(dict(exitCode=code))+'\n')
assert subprocess.run(['git', 'diff', '--quiet'], cwd=root).returncode == 0
for relative, expected in bindings.items(): assert hashlib.sha256((inner/relative).read_bytes()).hexdigest() == expected
print(json.dumps(dict(revision=revision, historicalReferenceBuildExitCode=code, noProductionSourceEdits=True)))
sys.exit(code)
