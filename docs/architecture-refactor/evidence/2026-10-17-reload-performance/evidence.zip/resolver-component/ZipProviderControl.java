import com.tkisor.nekojs.core.module.NekoModuleResolver;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class ZipProviderControl {
    public static void main(String[] args) throws Exception {
        Path archive = Path.of(args[0]);
        if (Files.exists(archive)) throw new AssertionError("Fresh control archive required");
        try (var fileSystem = FileSystems.newFileSystem(archive, Map.of("create", "true"))) {
            Path game = fileSystem.getPath("/game");
            Path root = game.resolve("nekojs");
            Files.writeString(Files.createDirectories(root.resolve("server_scripts")).resolve("entry.json"), "{}");
            var oldResolver = new DiagnosticBaselineResolver(game, root, root.resolve("node_modules"), null);
            var newResolver = new NekoModuleResolver(game, root, root.resolve("node_modules"), null);
            Throwable oldFailure = null, newFailure = null;
            try { oldResolver.resolveEntry("./server_scripts/entry.json"); } catch (Exception failure) { oldFailure = failure; }
            try { newResolver.resolveEntry("./server_scripts/entry.json"); } catch (Exception failure) { newFailure = failure; }
            if (oldFailure == null || newFailure == null || oldFailure.getClass() != newFailure.getClass()) {
                throw new AssertionError("Control failures differ");
            }
            System.out.println("{\"baselineFailure\":\"" + oldFailure.getClass().getName()
                    + "\",\"candidateFailure\":\"" + newFailure.getClass().getName()
                    + "\",\"sameFailure\":true,\"zipProviderSupported\":false}");
        }
    }
}
