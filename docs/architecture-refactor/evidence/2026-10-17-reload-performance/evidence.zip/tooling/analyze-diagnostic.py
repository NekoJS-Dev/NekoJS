import json
import re
import statistics
from pathlib import Path

tools = Path(__file__).resolve().parent
root = tools / 'diagnostic-f41db5d9'
assert json.loads((tools / 'diagnostic-exit.json').read_text())['exitCode'] == 0
reloads = json.loads((root / 'reloads.json').read_text(encoding='utf-8-sig'))
assert len(reloads) == 20 and all('phase=COMMIT - no errors.' in row['response'] for row in reloads)
stderr = (root / 'profile-stderr.log').read_text(encoding='utf-8-sig')
metrics = []
for line in stderr.splitlines():
    if '[DEBUG-CLOSEOUT-17]' in line:
        metrics.append({name: dict(ms=int(nanos)/1e6, calls=int(calls))
            for name, nanos, calls in re.findall(r'(\w+)=(\d+)/(\d+);', line)})
assert len(metrics) == 20
summary = dict(diagnosticOnly=True, inclusiveTimingsNotAdditive=True, commands=len(reloads),
    rconMeanMs=statistics.mean(row['rconMs'] for row in reloads),
    metrics={name: dict(meanMs=statistics.mean(row[name]['ms'] for row in metrics),
              meanCalls=statistics.mean(row[name]['calls'] for row in metrics)) for name in metrics[0]})
command = re.findall(r'command type=server rootNs=(\d+) recipeNs=(\d+)', stderr)
assert len(command) == 20
summary['rootMeanMs'] = statistics.mean(int(root)/1e6 for root, _ in command)
summary['recipeMeanMs'] = statistics.mean(int(recipe)/1e6 for _, recipe in command)
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
(root / 'windows.tsv').write_text(''.join(row['startedUtc'] + '\t' + row['endedUtc'] + '\n' for row in reloads), encoding='utf-8')
print(json.dumps(summary, indent=2))
