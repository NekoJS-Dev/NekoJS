$ErrorActionPreference = 'Stop'
$env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
$ownedRoot = 'C:\Users\11515\.codex\worktrees\domain-perf-0965\NekoJS-mult'
$revision = 'f41db5d9819df7f501069163d2cbb7a0397b7d6e'
$logRoot = 'D:\mcmodDemo\NekoJS-mult\build\priority-closeout'
if (@(& git -C $ownedRoot status --porcelain).Count -ne 0) { throw 'Owned checkout is not clean' }
foreach ($relative in @('', 'versions', 'versions\26.1.2', 'versions\26.1.2\run')) {
    $target = if ($relative) { Join-Path $ownedRoot $relative } else { $ownedRoot }
    $item = Get-Item -LiteralPath $target -Force
    while ($null -ne $item) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse point on run path: $target" }
        $item = $item.Parent
    }
}
$runRoot = [IO.Path]::GetFullPath((Join-Path $ownedRoot 'versions\26.1.2\run'))
foreach ($relative in @('nekojs', '.neko_probe', 'world')) {
    $target = [IO.Path]::GetFullPath((Join-Path $runRoot $relative))
    if (-not $target.StartsWith($runRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target outside owned run directory' }
    if (Test-Path -LiteralPath $target) {
        $items = @((Get-Item -LiteralPath $target -Force)) + @(Get-ChildItem -LiteralPath $target -Recurse -Force)
        if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Reparse point under owned target' }
    }
}
if (@(Get-CimInstance Win32_Process -Filter "Name='java.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($ownedRoot) }).Count) { throw 'Owned game is still running' }
if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 25871,25872).Count) { throw 'Formal ports occupied' }
& git -C $ownedRoot switch --detach $revision
if ($LASTEXITCODE -ne 0 -or (& git -C $ownedRoot rev-parse HEAD).Trim() -ne $revision) { throw 'Failed to select exact source' }
if ((Get-FileHash -LiteralPath (Join-Path $ownedRoot 'bench\perf\sample.ps1')).Hash -ne '1F9C5D14A1A586DA4B3F1CA8E71B2407CE089EE8BEE185418963E1B5745DF0B4') { throw 'Sampler changed' }
$env:JAVA_HOME = 'C:\Program Files\Java\jdk-25.0.2'
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
$env:GRADLE_USER_HOME = 'D:\mcmodDemo\NekoJS\.gradle-<REDACTED-RCON-CREDENTIAL>'
$process = Start-Process -FilePath cmd.exe -ArgumentList '/c gradlew.bat --offline :26.1.2:build --console=plain' -WorkingDirectory $ownedRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logRoot 'baseline-build-2.log') -RedirectStandardError (Join-Path $logRoot 'baseline-build-2-stderr.log') -PassThru
$handle = $process.Handle
$process.WaitForExit()
if ($process.ExitCode -ne 0) { throw "Baseline build failed: $($process.ExitCode)" }
Write-Output 'BASELINE_BUILD_COMPLETE'
