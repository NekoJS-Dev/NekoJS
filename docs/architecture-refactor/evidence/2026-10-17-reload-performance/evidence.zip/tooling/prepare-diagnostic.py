import hashlib
import json
import re
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project / 'build/priority-closeout'
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
revision = 'f41db5d9819df7f501069163d2cbb7a0397b7d6e'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
assert json.loads((tools / 'baseline-f41db5d9-formal/groups.json').read_text())[-1]['group'] == 'startup'
originals = tools / 'diagnostic-originals'
assert not originals.exists()
originals.mkdir()
paths = [
    'common/src/main/java/com/tkisor/nekojs/core/lifecycle/ReloadProgressTracker.java',
    'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java',
    'common/src/main/java/com/tkisor/nekojs/core/module/NekoModuleResolver.java',
    'common/src/main/java/com/tkisor/nekojs/core/module/NekoModulePipelineCache.java',
    'common/src/main/java/com/tkisor/nekojs/core/module/NekoScriptModuleLoaderHost.java',
    'common/src/main/java/com/tkisor/nekojs/script/ScriptExecutor.java',
    'common/src/main/java/com/tkisor/nekojs/core/module/NekoCanonicalPath.java',
    'common/src/main/java/com/tkisor/nekojs/core/fs/NekoJSPaths.java',
]
manifest = {}
for index, relative in enumerate(paths):
    path = worktree / relative
    data = path.read_bytes()
    (originals / f'{index}.java').write_bytes(data)
    manifest[relative] = dict(backup=f'{index}.java', sha256=hashlib.sha256(data).hexdigest())
subprocess.run(['git', 'apply', str(project / 'build/domain-closeout-tooling/phase-current.patch')],
               cwd=worktree, check=True)

probe = 'com.tkisor.nekojs.core.lifecycle.ReloadPerfProbe'

def instrument(relative, signature, metric):
    path = worktree / relative
    source = path.read_text(encoding='utf-8')
    assert source.count(signature) == 1, signature
    start = source.index('{', source.index(signature)) + 1
    # All selected methods have a four-space closing brace at the start of a line.
    end = re.search(r'^    }', source[start:], flags=re.MULTILINE)
    assert end, signature
    finish = start + end.start()
    body = source[start:finish]
    replacement = ('\n        long diagnosticStarted = System.nanoTime();\n        try {' + body +
                   '\n        } finally {\n            ' + probe + '.record("' + metric +
                   '", diagnosticStarted);\n        }\n')
    path.write_text(source[:start] + replacement + source[finish:], encoding='utf-8', newline='\n')

resolver = paths[2]
instrument(resolver, 'public NekoResolvedModule resolveEntry(String entryPath)', 'resolveEntry')
instrument(resolver, 'public NekoResolvedModule resolveForRequire(String parentPath, String specifier,', 'resolveRequire')
instrument(resolver, 'private Path verifyModulePath(Path path, Path containmentRoot)', 'verifyModulePath')
instrument(resolver, 'private Path verifyInsideGameDir(Path path)', 'verifyInsideGame')
instrument(resolver, 'private static Path canonicalSplicedForm(Path path)', 'canonicalSplice')
instrument(paths[3], 'public NekoPreparedModule prepare(Path path)', 'prepareTotal')
instrument(paths[3], 'private SourceSnapshot readSource(Path path)', 'readSource')
instrument(paths[3], 'private void publishSourceMap(Path path, NekoPreparedModule prepared)', 'publishSourceMap')
instrument(paths[4], 'private void executeScriptModule(NekoResolvedModule resolved, ModuleState module, NekoPreparedModule prepared)', 'guestModuleExecute')
instrument(paths[5], 'private void validateGlobalBindings(Context context, ScriptContainer script,', 'entryValidator')
instrument(paths[5], 'public void executeEntry(Context ctx, ScriptContainer script, NekoNodeRuntime nodeRuntime,', 'entryExecute')
instrument(paths[6], 'static Path pathOf(Path path)', 'canonicalModulePath')
instrument(paths[7], 'private Path verifyInsideRoot(Path path, Path rt)', 'verifyFilesystemRoot')
instrument(paths[7], 'private static Path canonicalSplicedForm(Path path)', 'filesystemCanonicalSplice')

command = worktree / paths[1]
source = command.read_text(encoding='utf-8')
source = source.replace('            long diagnosticRootStarted = System.nanoTime();',
                       '            ' + probe + '.begin();\n            long diagnosticRootStarted = System.nanoTime();')
source = source.replace('            long diagnosticRootDone = System.nanoTime();',
                       '            long diagnosticRootDone = System.nanoTime();\n            ' + probe + '.finish();')
command.write_text(source, encoding='utf-8', newline='\n')

helper_relative = 'common/src/main/java/com/tkisor/nekojs/core/lifecycle/ReloadPerfProbe.java'
helper = worktree / helper_relative
assert not helper.exists()
helper.write_text('''package com.tkisor.nekojs.core.lifecycle;

import java.util.LinkedHashMap;
import java.util.Map;

/** Temporary diagnostic counters; inclusive timings must not be added together. */
public final class ReloadPerfProbe {
    private static final ThreadLocal<Map<String, long[]>> METRICS = new ThreadLocal<>();
    private ReloadPerfProbe() {}
    public static void begin() { METRICS.set(new LinkedHashMap<>()); }
    public static void record(String name, long started) {
        long elapsed = System.nanoTime() - started;
        Map<String, long[]> metrics = METRICS.get();
        if (metrics == null) return;
        long[] metric = metrics.computeIfAbsent(name, ignored -> new long[2]);
        metric[0] += elapsed;
        metric[1]++;
    }
    public static void finish() {
        Map<String, long[]> metrics = METRICS.get();
        METRICS.remove();
        StringBuilder text = new StringBuilder("[DEBUG-CLOSEOUT-17] inclusiveNs/count ");
        metrics.forEach((name, metric) -> text.append(name).append('=').append(metric[0])
                .append('/').append(metric[1]).append(';'));
        System.err.println(text);
    }
}
''', encoding='utf-8')
for relative, row in manifest.items():
    row['diagnosticSha256'] = hashlib.sha256((worktree / relative).read_bytes()).hexdigest()
(tools / 'diagnostic-manifest.json').write_text(json.dumps(dict(revision=revision, files=manifest,
    helper=helper_relative, helperSha256=hashlib.sha256(helper.read_bytes()).hexdigest()), indent=2) + '\n', encoding='utf-8')
with (tools / 'diagnostic.patch').open('wb') as output:
    subprocess.run(['git', 'diff', '--', *paths], cwd=worktree, check=True, stdout=output)

controller = (project / 'build/domain-closeout-tooling/phase-current.ps1').read_text(encoding='utf-8')
controller = controller.replace('0965e29b90fecb80f62a97e7f0dd110a82b8653a', revision)
controller = controller.replace('D:\\mcmodDemo\\NekoJS-mult\\build\\domain-performance-phases-0965', str(tools / 'diagnostic-f41db5d9'))
old_guard = "if ((($changedFiles | Sort-Object) -join '|') -ne 'common/src/main/java/com/tkisor/nekojs/core/lifecycle/ReloadProgressTracker.java|src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java') { throw 'Unexpected diagnostic diff' }"
assert old_guard in controller
controller = controller.replace(old_guard, 'if ($changedFiles.Count -ne 8) { throw "Unexpected diagnostic diff" }')
(tools / 'diagnostic.ps1').write_text(controller, encoding='utf-8')
print('DIAGNOSTIC_SOURCE_PREPARED', flush=True)
