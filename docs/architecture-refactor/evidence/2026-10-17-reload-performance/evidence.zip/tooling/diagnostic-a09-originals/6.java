package com.tkisor.nekojs.core.module;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.Path;
import java.util.Objects;

/** Shared canonical identity for module cache keys and trust boundaries. */
final class NekoCanonicalPath {
    private NekoCanonicalPath() {}

    static String of(Path path) {
        Objects.requireNonNull(path, "path");
        Path canonical = pathOf(path);
        String normalized = canonical.toString().replace('\\', '/');
        return isCaseInsensitive(canonical) ? normalized.toLowerCase(java.util.Locale.ROOT) : normalized;
    }

    /** Preserve the injected provider when a canonical path is used as a map key. */
    static Path pathOf(Path path) {
        Objects.requireNonNull(path, "path");
        Path canonical = path.normalize().toAbsolutePath();
        try {
            canonical = canonical.toRealPath();
        } catch (IOException ignored) {
            // A missing source still needs a deterministic lexical identity.
        }
        return canonical;
    }

    static boolean isWithin(String subject, String root) {
        if (subject == null || root == null) {
            return false;
        }
        String prefix = root.endsWith("/") ? root : root + "/";
        return subject.equals(root) || subject.startsWith(prefix);
    }

    /** The filesystem owns case semantics; the common layer does not inspect host properties. */
    static boolean isCaseInsensitive(Path path) {
        FileSystem fileSystem = path.getFileSystem();
        return fileSystem.getPath("A").equals(fileSystem.getPath("a"));
    }
}
