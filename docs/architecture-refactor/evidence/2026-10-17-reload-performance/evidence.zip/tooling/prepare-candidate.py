import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
project = Path('D:/mcmodDemo/NekoJS-mult')
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project, text=True).strip()
assert revision == 'a09e5bc29cfef094467446c46d05a18ae4a1c346'
source = (tools / 'prepare-performance.ps1').read_text(encoding='utf-8')
source = source.replace('f41db5d9819df7f501069163d2cbb7a0397b7d6e', revision)
source = source.replace('baseline-build-2', 'candidate-build')
target = tools / 'prepare-candidate.ps1'
assert not target.exists()
target.write_text(source, encoding='utf-8')
subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(target)],
    cwd=project, check=True)
