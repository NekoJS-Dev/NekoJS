from pathlib import Path
import json
import statistics

tools = Path(__file__).resolve().parent
source = (tools / 'analyze-diagnostic.py').read_text(encoding='utf-8')
source = source.replace('diagnostic-f41db5d9', 'diagnostic-a09e5bc2-retry')
source = source.replace('diagnostic-exit.json', 'diagnostic-a09-retry-exit.json')
exec(compile(source, str(tools / 'analyze-diagnostic-a09.py'), 'exec'))
for label, start, end in [('first5', 0, 5), ('last15', 5, 20)]:
    part = dict(rconMeanMs=statistics.mean(r['rconMs'] for r in reloads[start:end]),
        rootMeanMs=statistics.mean(int(r)/1e6 for r, _ in command[start:end]),
        recipeMeanMs=statistics.mean(int(r)/1e6 for _, r in command[start:end]),
        metrics={name: statistics.mean(row[name]['ms'] for row in metrics[start:end]) for name in metrics[0]})
    summary[label] = part
summary['perCommand'] = [dict(index=i+1, metrics=metric, rootMs=int(timing[0])/1e6,
    recipeMs=int(timing[1])/1e6, rconMs=reloads[i]['rconMs']) for i, (metric, timing) in enumerate(zip(metrics, command))]
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({label: summary[label] for label in ['first5', 'last15']}, indent=2))
