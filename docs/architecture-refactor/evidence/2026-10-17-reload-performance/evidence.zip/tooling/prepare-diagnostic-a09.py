from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
script = (root / 'prepare-diagnostic.py').read_text(encoding='utf-8')
script = script.replace('f41db5d9819df7f501069163d2cbb7a0397b7d6e', 'a09e5bc29cfef094467446c46d05a18ae4a1c346')
script = script.replace('baseline-f41db5d9-formal', 'candidate-a09e5bc2-formal')
script = script.replace('diagnostic-f41db5d9', 'diagnostic-a09e5bc2')
for stem in ('diagnostic-originals', 'diagnostic-manifest.json', 'diagnostic.patch', 'diagnostic.ps1'):
    script = script.replace(stem, stem.replace('diagnostic', 'diagnostic-a09-v2'))
script = script.replace("    'common/src/main/java/com/tkisor/nekojs/core/fs/NekoJSPaths.java',",
    "    'common/src/main/java/com/tkisor/nekojs/core/fs/NekoJSPaths.java',\n"
    "    'common/src/main/java/com/tkisor/nekojs/core/node/NekoNodeModuleInstaller.java',\n"
    "    'common/src/main/java/com/tkisor/nekojs/script/ScriptEnvironmentFactory.java',\n"
    "    'common/src/main/java/com/tkisor/nekojs/core/module/NekoRuntimeTrustContext.java',")
script = script.replace('private Path verifyModulePath(Path path, Path containmentRoot)', 'private Path verifyModulePath(Path path, ResolutionRoots roots)')
script = script.replace('private Path verifyInsideGameDir(Path path)', 'private Path verifyInsideGameDir(Path path, Path rootForm)')
script = script.replace('command = worktree / paths[1]', '''instrument(paths[8], 'private static void loadManifest(Context context, NekoModulePipelineCache preparationCache)', 'manifestTotal')
instrument(paths[8], 'private static String readResource(String path)', 'builtinReadResource')
instrument(paths[9], 'public Environment createContext(ScriptType scriptType, NekoModulePipelineCache moduleSession)', 'contextCreate')
instrument(paths[9], 'public void installEnvironmentBindings(Context context, ScriptType scriptType, GenerationGlobals globals,', 'bindingsInstall')
instrument(paths[10], 'public NekoTrustApprovedSource approvalFor(Path file)', 'trustApproval')
command = worktree / paths[1]''')
script = script.replace('$changedFiles.Count -ne 8', '$changedFiles.Count -ne 11')
exec(compile(script, str(root / 'prepare-diagnostic-a09.py'), 'exec'))

controller = (root / 'run-diagnostic.py').read_text(encoding='utf-8')
controller = controller.replace("'diagnostic.ps1'", "'diagnostic-a09-v2.ps1'")
controller = controller.replace('diagnostic-controller', 'diagnostic-a09-controller').replace('diagnostic-exit', 'diagnostic-a09-exit')
(root / 'run-diagnostic-a09.py').write_text(controller, encoding='utf-8')
restore = (root / 'restore-diagnostic.py').read_text(encoding='utf-8')
restore = restore.replace('diagnostic-manifest', 'diagnostic-a09-v2-manifest').replace('diagnostic-originals', 'diagnostic-a09-v2-originals')
(root / 'restore-diagnostic-a09.py').write_text(restore, encoding='utf-8')
