import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
manifest = json.loads((tools / 'diagnostic-manifest.json').read_text(encoding='utf-8'))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == manifest['revision']
for relative, row in manifest['files'].items():
    path = worktree / relative
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['diagnosticSha256'], path
    original = (tools / 'diagnostic-originals' / row['backup']).read_bytes()
    assert hashlib.sha256(original).hexdigest() == row['sha256']
    path.write_bytes(original)
helper = worktree / manifest['helper']
assert helper.resolve().is_relative_to(worktree.resolve())
assert hashlib.sha256(helper.read_bytes()).hexdigest() == manifest['helperSha256']
helper.unlink()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
print('DIAGNOSTIC_SOURCE_RESTORED_CLEAN')
