from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'diagnostic-a09-v2.ps1').read_text(encoding='utf-8')
source = source.replace("'diagnostic-a09e5bc2'", "'diagnostic-a09e5bc2-retry'")
source = source.replace('build\\priority-closeout\\diagnostic-a09e5bc2', 'build\\priority-closeout\\diagnostic-a09e5bc2-retry')
needle = 'Write-EnvSnapshot\nDeploy-Fixtures -Bench:$false'
assert needle in source
source = source.replace(needle, '''function Invoke-Rcon {
    param([string]$Command, [int]$TimeoutMs = 180000)
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = 'python.exe'
    $startInfo.Arguments = '"' + (Join-Path $sampleDirectory 'rcon.py') + '" ' + $RconPort + ' "' + $RconPass + '" ' + ($TimeoutMs / 1000) + ' "' + $Command + '"'
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $client = [System.Diagnostics.Process]::Start($startInfo)
    $output = $client.StandardOutput.ReadToEnd()
    $errorOutput = $client.StandardError.ReadToEnd()
    $client.WaitForExit()
    if ($client.ExitCode -ne 0) { throw "Diagnostic RCON failed: $errorOutput" }
    return $output.Trim()
}
Write-EnvSnapshot
Deploy-Fixtures -Bench:$false''')
(root / 'diagnostic-a09-retry.ps1').write_text(source, encoding='utf-8')
runner = (root / 'run-diagnostic-a09.py').read_text(encoding='utf-8')
runner = runner.replace('diagnostic-a09-v2.ps1', 'diagnostic-a09-retry.ps1')
runner = runner.replace('diagnostic-a09-controller', 'diagnostic-a09-retry-controller').replace('diagnostic-a09-exit', 'diagnostic-a09-retry-exit')
(root / 'run-diagnostic-a09-retry.py').write_text(runner, encoding='utf-8')
