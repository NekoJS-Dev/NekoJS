import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project / 'build/priority-closeout'
destination = tools / 'final-validation'
assert not destination.exists()
destination.mkdir()
modules = ['common', 'common-api-processor', 'versions/1.21.1', 'versions/26.1.2',
           'versions/26.2.0', 'versions/26.1.2-fabric', 'versions/26.2.0-fabric']
statistics = []
for module in modules:
    directory = project / module / 'build/test-results/test'
    rows = list(directory.glob('TEST-*.xml'))
    assert rows, module
    sums = {name: 0 for name in ['tests', 'failures', 'errors', 'skipped']}
    for path in rows:
        suite = ET.parse(path).getroot()
        for name in sums:
            sums[name] += int(suite.get(name, '0'))
        target = destination / 'test-results' / module / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    assert sums['failures'] == 0 and sums['errors'] == 0, (module, sums)
    statistics.append(dict(module=module, suites=len(rows), **sums))
gametest = (tools / 'resolver-gametest.log').read_text(encoding='utf-8-sig')
assert 'All 1 required tests passed' in gametest and 'BUILD SUCCESSFUL' in gametest
assert 'BUILD SUCCESSFUL' in (tools / 'resolver-final-check.log').read_text(encoding='utf-8-sig')
failed_matrix = (tools / 'resolver-matrix.log').read_text(encoding='utf-8-sig')
assert failed_matrix.count(':build\n') >= 5
assert 'preservesArchiveProviderPathsAndBareModuleContainment() FAILED' in failed_matrix
ci = json.loads((tools / 'resolver-final-ci-gates.json').read_text(encoding='utf-8-sig'))
relative_sources = ['common/src/main/java/com/tkisor/nekojs/core/module/NekoModuleResolver.java',
                    'common/src/test/java/com/tkisor/nekojs/core/module/NekoModuleResolverTest.java']
summary = dict(modules=statistics, total={name: sum(row[name] for row in statistics)
    for name in ['tests', 'failures', 'errors', 'skipped']},
    sourceHashes={relative: hashlib.sha256((project / relative).read_bytes()).hexdigest()
                  for relative in relative_sources},
    commonCheckPassed=True, fiveNodeBuildsPassed=True, originalMatrixCommonFailed=True,
    failedProbeRetained=True, gameTestPassed=True,
    commands=[r'.\gradlew.bat --offline :common:check :common-api-processor:test guardLint :1.21.1:build :26.1.2:build :26.2.0:build :26.1.2-fabric:build :26.2.0-fabric:build --console=plain',
        r'.\gradlew.bat --offline :common:check :common-api-processor:test guardLint --console=plain',
        r'.\gradlew.bat --offline :26.1.2:runGameTestServer --console=plain',
        'python tools/nekojs-ci-gates.py all --out build/priority-closeout/resolver-final-ci-gates.json'])
(destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary['total']), flush=True)
