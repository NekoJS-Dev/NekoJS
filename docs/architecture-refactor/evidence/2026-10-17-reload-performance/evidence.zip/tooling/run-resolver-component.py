import hashlib
import json
import os
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
root = project / 'build/priority-closeout/resolver-component'
assert not root.exists()
root.mkdir()
revision = 'f41db5d9819df7f501069163d2cbb7a0397b7d6e'
relative = 'common/src/main/java/com/tkisor/nekojs/core/module/NekoModuleResolver.java'
baseline = subprocess.check_output(['git', 'show', f'{revision}:{relative}'], cwd=project).decode('utf-8')
(root / 'baseline-source.java.txt').write_text(baseline, encoding='utf-8')
adapted = baseline.replace('package com.tkisor.nekojs.core.module;',
    'import com.tkisor.nekojs.core.module.NekoResolvedModule;\nimport com.tkisor.nekojs.core.module.NekoModuleKind;')
adapted = adapted.replace('NekoModuleResolver', 'DiagnosticBaselineResolver')
(root / 'DiagnosticBaselineResolver.java').write_text(adapted, encoding='utf-8')
benchmark = (project / 'build/domain-resolver-component/ResolverProductionBenchmark.java').read_bytes()
(root / 'ResolverProductionBenchmark.java').write_bytes(benchmark)
classpath = (project / 'build/domain-closeout-tooling/preflight-classpath.txt').read_text(encoding='utf-8-sig').strip()
classpath = ';'.join([str(project / 'common/build/classes/java/main'),
    str(project / 'common/build/resources/main'), *[part for part in classpath.split(';') if part.endswith('.jar')]])
(root / 'classpath.txt').write_text(classpath, encoding='utf-8')
java_root = Path('C:/Program Files/Java/jdk-25.0.2/bin')
classes = root / 'classes'
classes.mkdir()
with (root / 'compile.log').open('xb') as output:
    subprocess.run([str(java_root / 'javac.exe'), '-encoding', 'UTF-8', '-cp', classpath, '-d', str(classes),
        str(root / 'DiagnosticBaselineResolver.java'), str(root / 'ResolverProductionBenchmark.java')],
        cwd=project, stdout=output, stderr=subprocess.STDOUT, check=True)
binding = dict(baselineRevision=revision, baselineSourceSha256=hashlib.sha256(baseline.encode()).hexdigest(),
    currentSourceSha256=hashlib.sha256((project / relative).read_bytes()).hexdigest(),
    currentClassSha256=hashlib.sha256((project / 'common/build/classes/java/main/com/tkisor/nekojs/core/module/NekoModuleResolver.class').read_bytes()).hexdigest(),
    baselineClassSha256=hashlib.sha256((classes / 'DiagnosticBaselineResolver.class').read_bytes()).hexdigest(),
    diagnosticOnly=True)
(root / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n', encoding='utf-8')
with (root / 'result.json').open('xb') as out, (root / 'runtime-stderr.log').open('xb') as err:
    subprocess.run([str(java_root / 'java.exe'), '-cp', str(classes) + ';' + classpath,
        'ResolverProductionBenchmark', str(root / 'trial')], cwd=project, stdout=out, stderr=err, check=True)
result = json.loads((root / 'result.json').read_text(encoding='utf-8'))
old_mean = sum(row['baselineNs'] for row in result['pairs']) / 10 / 30 / 1e6
new_mean = sum(row['candidateNs'] for row in result['pairs']) / 10 / 30 / 1e6
summary = dict(diagnosticOnly=True, baselineMsPerSixPaths=old_mean, candidateMsPerSixPaths=new_mean,
    savedMsPerSixPaths=old_mean-new_mean, symlinkChecked=result['symlinkChecked'],
    identityCases=result['identityCases'], rejectionCases=result['rejectionCases'])
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary), flush=True)
