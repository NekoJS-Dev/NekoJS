import ast
import hashlib
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
source = ast.parse((root / 'prepare-diagnostic.py').read_text(encoding='utf-8'))
paths = next(ast.literal_eval(node.value) for node in source.body
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'paths' for t in node.targets))
paths += ['common/src/main/java/com/tkisor/nekojs/core/node/NekoNodeModuleInstaller.java',
    'common/src/main/java/com/tkisor/nekojs/script/ScriptEnvironmentFactory.java',
    'common/src/main/java/com/tkisor/nekojs/core/module/NekoRuntimeTrustContext.java']
for index, relative in enumerate(paths):
    original = (root / 'diagnostic-a09-originals' / f'{index}.java').read_bytes()
    expected = subprocess.check_output(['git', 'show', 'HEAD:' + relative], cwd=tree)
    assert original.replace(b'\r\n', b'\n') == expected.replace(b'\r\n', b'\n'), relative
    (tree / relative).write_bytes(original)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
print('PARTIAL_DIAGNOSTIC_SOURCE_RESTORED_CLEAN')
