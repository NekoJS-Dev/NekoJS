package com.tkisor.nekojs.core.module;
import java.nio.file.*;
import java.util.*;
public class TrustBenchmark {
    static long run(NekoTrustContext trust, List<Path> paths, int rounds) {
        long started = System.nanoTime();
        for (int r = 0; r < rounds; r++) for (Path path : paths) {
            NekoTrustApprovedSource approved = trust.approvalFor(path);
            if (!approved.covers(path)) throw new AssertionError(path);
        }
        return System.nanoTime() - started;
    }
    public static void main(String[] args) throws Exception {
        List<Path> paths = new ArrayList<>();
        try (var files = Files.walk(Path.of(args[0]))) {
            files.filter(Files::isRegularFile).sorted().forEach(paths::add);
        }
        if (paths.size() != 6) throw new AssertionError(paths.size());
        var old = BaselineRuntimeTrustContext.local();
        var current = NekoRuntimeTrustContext.local();
        for (Path path : paths) {
            if (!old.approvalFor(path).equals(current.approvalFor(path))) throw new AssertionError(path);
        }
        run(old, paths, 50); run(current, paths, 50);
        System.out.print("{\"pairs\":[");
        for (int p = 0; p < 10; p++) {
            long a, b;
            if (p % 2 == 0) { a = run(old, paths, 20); b = run(current, paths, 20); }
            else { b = run(current, paths, 20); a = run(old, paths, 20); }
            if (p > 0) System.out.print(",");
            System.out.print("{\"baselineNs\":"+a+",\"candidateNs\":"+b+"}");
        }
        System.out.println("]}");
    }
}
