package com.tkisor.nekojs.core.module;
import com.tkisor.nekojs.core.ScriptFilePolicy;
import com.tkisor.nekojs.core.compiler.ScriptCompilerRegistry;
import com.tkisor.nekojs.core.fs.NekoJSPaths;
import java.nio.file.*;
import java.util.*;
public class PathLocationBenchmark {
    record Arm(NekoJSPaths paths, NekoModuleResolver resolver, NekoRuntimeTrustContext trust, List<Path> files) {}
    static Arm arm(Path game) throws Exception {
        NekoJSPaths paths = NekoJSPaths.fromGameDir(game);
        List<Path> files;
        try (var stream = Files.walk(paths.serverScripts())) {
            files = stream.filter(Files::isRegularFile).filter(p -> p.toString().endsWith(".js")).sorted().toList();
        }
        if (files.size() != 6) throw new AssertionError(files.size());
        var resolver = new NekoModuleResolver(paths.gameDir(), paths.root(), paths.nodeModules(),
            new ScriptFilePolicy(ScriptCompilerRegistry.createRuntimeRegistry()));
        return new Arm(paths, resolver, NekoRuntimeTrustContext.local(), files);
    }
    static long run(Arm arm, int rounds, String phase) throws Exception {
        long start = System.nanoTime();
        for (int r = 0; r < rounds; r++) for (Path path : arm.files()) {
            switch (phase) {
                case "resolve" -> {
                    var resolved = arm.resolver().resolveEntry(path.toString());
                    if (!resolved.path().equals(path.toRealPath())) throw new AssertionError(path);
                }
                case "trust" -> {
                    var approved = arm.trust().approvalFor(path);
                    if (!approved.covers(path)) throw new AssertionError(path);
                }
                case "filesystem" -> arm.paths().verifyInsideGameDir(path);
                default -> throw new AssertionError(phase);
            }
        }
        return System.nanoTime() - start;
    }
    public static void main(String[] args) throws Exception {
        var c = arm(Path.of(args[0])); var d = arm(Path.of(args[1]));
        System.out.print("{\"phases\":{");
        boolean first = true;
        for (String phase : List.of("resolve", "trust", "filesystem")) {
            run(c, 50, phase); run(d, 50, phase);
            if (!first) System.out.print(","); first = false;
            System.out.print("\""+phase+"\":[");
            for (int p = 0; p < 10; p++) {
                long a,b;
                if (p % 2 == 0) { a=run(c,20,phase); b=run(d,20,phase); }
                else { b=run(d,20,phase); a=run(c,20,phase); }
                if (p > 0) System.out.print(",");
                System.out.print("{\"cNs\":"+a+",\"dNs\":"+b+"}");
            }
            System.out.print("]");
        }
        System.out.println("}}");
    }
}
