from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
revision = subprocess.check_output(['git', 'rev-parse', '6e5bb8f0'], text=True).strip()
source = (root / 'prepare-candidate.ps1').read_text(encoding='utf-8')
source = source.replace('a09e5bc29cfef094467446c46d05a18ae4a1c346', revision)
source = source.replace('candidate-build', 'trust-performance-build')
target = root / 'trust-prepare-performance.ps1'
assert not target.exists()
target.write_text(source, encoding='utf-8')
process = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(target)])
raise SystemExit(process.returncode)
