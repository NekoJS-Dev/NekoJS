from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'trust-component.py').read_text(encoding='utf-8')
source = source.replace("'build/priority-closeout/trust-component'", "'build/priority-closeout/trust-component-v2'")
source = source.replace('files.filter(Files::isRegularFile).sorted()',
    'files.filter(Files::isRegularFile).filter(path -> path.toString().endsWith(".js")).sorted()')
exec(compile(source, str(root / 'trust-component-v2.py'), 'exec'))
