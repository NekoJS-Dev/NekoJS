import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project / 'build/priority-closeout'
destination = tools / 'trust-validation'
assert not destination.exists()
destination.mkdir()
modules = ['common', 'common-api-processor', 'versions/1.21.1', 'versions/26.1.2',
           'versions/26.2.0', 'versions/26.1.2-fabric', 'versions/26.2.0-fabric']
statistics = []
for module in modules:
    rows = list((project / module / 'build/test-results/test').glob('TEST-*.xml'))
    assert rows, module
    sums = dict(tests=0, failures=0, errors=0, skipped=0)
    for path in rows:
        suite = ET.parse(path).getroot()
        for name in sums:
            sums[name] += int(suite.get(name, '0'))
        target = destination / 'test-results' / module / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    assert sums['failures'] == sums['errors'] == 0
    statistics.append(dict(module=module, suites=len(rows), **sums))
for label in ['matrix', 'gametest', 'green']:
    log = (tools / ('trust-subject-' + label + '.log')).read_text(encoding='utf-8-sig')
    assert 'BUILD SUCCESSFUL' in log
    if label == 'gametest':
        assert 'All 1 required tests passed' in log
red = ET.parse(tools / 'trust-subject-red.xml').getroot()
assert int(red.get('failures')) == 1 and int(red.get('tests')) == 2
source_paths = ['common/src/main/java/com/tkisor/nekojs/core/module/NekoRuntimeTrustContext.java',
    'common/src/test/java/com/tkisor/nekojs/core/module/NekoRuntimeTrustContextTest.java']
summary = dict(modules=statistics, total={name: sum(row[name] for row in statistics)
    for name in ['tests', 'failures', 'errors', 'skipped']},
    sourceHashes={relative: hashlib.sha256((project / relative).read_bytes()).hexdigest() for relative in source_paths})
assert summary['total'] == dict(tests=4959, failures=0, errors=0, skipped=271)
(destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary['total']))
