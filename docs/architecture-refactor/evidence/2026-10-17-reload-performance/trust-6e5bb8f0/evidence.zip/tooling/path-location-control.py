import hashlib
import json
import shutil
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
root = project / 'build/priority-closeout/path-location-control'
assert not root.exists()
root.mkdir()
game_c = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run')
game_d = root / 'game'
fixtures = project / 'bench/perf/fixtures/nekojs/server_scripts'
paths = sorted(p.relative_to(fixtures).as_posix() for p in fixtures.rglob('*.js'))
assert len(paths) == 6
hashes = {}
for relative in paths:
    source = game_c / 'nekojs/server_scripts' / relative
    expected = fixtures / relative
    assert source.read_bytes() == expected.read_bytes()
    target = game_d / 'nekojs/server_scripts' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    hashes[relative] = hashlib.sha256(source.read_bytes()).hexdigest()

source = '''package com.tkisor.nekojs.core.module;
import com.tkisor.nekojs.core.ScriptFilePolicy;
import com.tkisor.nekojs.core.compiler.ScriptCompilerRegistry;
import com.tkisor.nekojs.core.fs.NekoJSPaths;
import java.nio.file.*;
import java.util.*;
public class PathLocationBenchmark {
    record Arm(NekoJSPaths paths, NekoModuleResolver resolver, NekoRuntimeTrustContext trust, List<Path> files) {}
    static Arm arm(Path game) throws Exception {
        NekoJSPaths paths = NekoJSPaths.fromGameDir(game);
        List<Path> files;
        try (var stream = Files.walk(paths.serverScripts())) {
            files = stream.filter(Files::isRegularFile).filter(p -> p.toString().endsWith(".js")).sorted().toList();
        }
        if (files.size() != 6) throw new AssertionError(files.size());
        var resolver = new NekoModuleResolver(paths.gameDir(), paths.root(), paths.nodeModules(),
            new ScriptFilePolicy(ScriptCompilerRegistry.createRuntimeRegistry()));
        return new Arm(paths, resolver, NekoRuntimeTrustContext.local(), files);
    }
    static long run(Arm arm, int rounds, String phase) throws Exception {
        long start = System.nanoTime();
        for (int r = 0; r < rounds; r++) for (Path path : arm.files()) {
            switch (phase) {
                case "resolve" -> {
                    var resolved = arm.resolver().resolveEntry(path.toString());
                    if (!resolved.path().equals(path.toRealPath())) throw new AssertionError(path);
                }
                case "trust" -> {
                    var approved = arm.trust().approvalFor(path);
                    if (!approved.covers(path)) throw new AssertionError(path);
                }
                case "filesystem" -> arm.paths().verifyInsideGameDir(path);
                default -> throw new AssertionError(phase);
            }
        }
        return System.nanoTime() - start;
    }
    public static void main(String[] args) throws Exception {
        var c = arm(Path.of(args[0])); var d = arm(Path.of(args[1]));
        System.out.print("{\\"phases\\":{");
        boolean first = true;
        for (String phase : List.of("resolve", "trust", "filesystem")) {
            run(c, 50, phase); run(d, 50, phase);
            if (!first) System.out.print(","); first = false;
            System.out.print("\\""+phase+"\\":[");
            for (int p = 0; p < 10; p++) {
                long a,b;
                if (p % 2 == 0) { a=run(c,20,phase); b=run(d,20,phase); }
                else { b=run(d,20,phase); a=run(c,20,phase); }
                if (p > 0) System.out.print(",");
                System.out.print("{\\"cNs\\":"+a+",\\"dNs\\":"+b+"}");
            }
            System.out.print("]");
        }
        System.out.println("}}");
    }
}
'''
(root / 'PathLocationBenchmark.java').write_text(source, encoding='utf-8')
classpath = (project / 'build/priority-closeout/resolver-component/classpath.txt').read_text().strip()
classes = root / 'classes'
classes.mkdir()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
with (root / 'compile.log').open('xb') as log:
    result = subprocess.run([str(java / 'javac.exe'), '-encoding', 'UTF-8', '-cp', classpath, '-d', str(classes),
        str(root / 'PathLocationBenchmark.java')], cwd=project, stdout=log, stderr=subprocess.STDOUT)
    assert result.returncode == 0, 'See compile.log'
with (root / 'result.json').open('xb') as out, (root / 'runtime-stderr.log').open('xb') as err:
    result = subprocess.run([str(java / 'java.exe'), '-cp', str(classes)+';'+classpath,
        'com.tkisor/nekojs/core/module/PathLocationBenchmark'.replace('/', '.'), str(game_c), str(game_d)],
        cwd=project, stdout=out, stderr=err)
    assert result.returncode == 0, 'See runtime-stderr.log'
observed = json.loads((root / 'result.json').read_text())
summary = dict(diagnosticOnly=True, exactSameClasses=True, fixtureHashes=hashes, cRoot=str(game_c), dRoot=str(game_d),
    rounds=20, warmups=50, pairs=10,
    metrics={phase: dict(cMsPerSix=sum(r['cNs'] for r in rows)/10/20/1e6,
                        dMsPerSix=sum(r['dNs'] for r in rows)/10/20/1e6) for phase, rows in observed['phases'].items()})
(root / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(summary['metrics']), flush=True)
