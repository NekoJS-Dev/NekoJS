import json
import statistics
from pathlib import Path

tools = Path(__file__).resolve().parent
source = (tools / 'analyze-diagnostic.py').read_text(encoding='utf-8')
source = source.replace('diagnostic-f41db5d9', 'diagnostic-6e5bb8f0')
source = source.replace('diagnostic-exit.json', 'diagnostic-current-exit.json')
source = source.replace(r"r'(\w+)=(\d+)/(\d+);'", r"r'([^=;\s]+)=(\d+)/(\d+);'")
source = source.replace('print(json.dumps(summary, indent=2))', '')
exec(compile(source, str(tools / 'analyze-diagnostic-current-generated.py'), 'exec'))
for label, start, end in [('first5', 0, 5), ('last15', 5, 20)]:
    summary[label] = dict(rconMeanMs=statistics.mean(r['rconMs'] for r in reloads[start:end]),
        rootMeanMs=statistics.mean(int(r)/1e6 for r, _ in command[start:end]),
        recipeMeanMs=statistics.mean(int(r)/1e6 for _, r in command[start:end]))
assert summary['metrics']['canonicalModulePath']['meanCalls'] == 24
assert len([name for name in summary['metrics'] if name.startswith('builtinEval/')]) == 17
summary['perCommand'] = [dict(index=i+1, metrics=metric, rootMs=int(timing[0])/1e6,
    recipeMs=int(timing[1])/1e6, rconMs=reloads[i]['rconMs']) for i, (metric, timing) in enumerate(zip(metrics, command))]
(root / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps({key: summary[key] for key in ['commands', 'rootMeanMs', 'recipeMeanMs', 'rconMeanMs', 'first5', 'last15']}))
print(json.dumps(summary['metrics']))
