from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
source = (root / 'trust-prepare-performance.ps1').read_text(encoding='utf-8')
source = source.replace('trust-performance-build', 'diagnostic-current-restored-build')
source = source.replace('BASELINE_BUILD_COMPLETE', 'DIAGNOSTIC_RESTORED_BUILD_COMPLETE')
script = root / 'diagnostic-current-restored-build.ps1'
assert not script.exists()
script.write_text(source, encoding='utf-8')
result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(script)],
                        cwd='D:/mcmodDemo/NekoJS-mult', capture_output=True, text=True)
(root / 'diagnostic-current-restored-controller.log').write_text(result.stdout, encoding='utf-8')
(root / 'diagnostic-current-restored-controller-stderr.log').write_text(result.stderr, encoding='utf-8')
print('RESTORED_BUILD_EXIT='+str(result.returncode), flush=True)
raise SystemExit(result.returncode)
