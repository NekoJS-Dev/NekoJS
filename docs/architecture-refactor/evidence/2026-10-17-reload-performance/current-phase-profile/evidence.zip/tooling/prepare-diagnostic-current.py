import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
revision = '6e5bb8f00c3747b828056589853cb0471477b18a'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
subprocess.run(['git', 'apply', '--check', 'D:/mcmodDemo/NekoJS-mult/build/domain-closeout-tooling/phase-current.patch'], cwd=worktree, check=True)
source = (root / 'prepare-diagnostic.py').read_text(encoding='utf-8')
source = source.replace('f41db5d9819df7f501069163d2cbb7a0397b7d6e', revision)
source = source.replace('baseline-f41db5d9-formal', 'candidate-6e5bb8f0-formal')
source = source.replace('diagnostic-f41db5d9', 'diagnostic-6e5bb8f0')
for name in ['diagnostic-originals', 'diagnostic-manifest.json', 'diagnostic.patch', 'diagnostic.ps1']:
    source = source.replace(name, name.replace('diagnostic', 'diagnostic-current'))
source = source.replace("    'common/src/main/java/com/tkisor/nekojs/core/fs/NekoJSPaths.java',", """    'common/src/main/java/com/tkisor/nekojs/core/fs/NekoJSPaths.java',
    'common/src/main/java/com/tkisor/nekojs/core/node/NekoNodeModuleInstaller.java',
    'common/src/main/java/com/tkisor/nekojs/script/ScriptEnvironmentFactory.java',
    'common/src/main/java/com/tkisor/nekojs/core/module/NekoRuntimeTrustContext.java',""")
source = source.replace('private Path verifyModulePath(Path path, Path containmentRoot)', 'private Path verifyModulePath(Path path, ResolutionRoots roots)')
source = source.replace('private Path verifyInsideGameDir(Path path)', 'private Path verifyInsideGameDir(Path path, Path rootForm)')
source = source.replace('command = worktree / paths[1]', '''instrument(paths[8], 'private static void loadManifest(Context context, NekoModulePipelineCache preparationCache)', 'manifestTotal')
instrument(paths[8], 'private static String readResource(String path)', 'builtinReadResource')
instrument(paths[9], 'public Environment createContext(ScriptType scriptType, NekoModulePipelineCache moduleSession)', 'contextCreate')
instrument(paths[9], 'public void installEnvironmentBindings(Context context, ScriptType scriptType, GenerationGlobals globals,', 'bindingsInstall')
instrument(paths[9], 'private void bindManagedGlobals(Value bindings, ScriptType scriptType,', 'managedGlobals')
instrument(paths[10], 'public NekoTrustApprovedSource approvalFor(Path file)', 'trustApproval')
node = worktree / paths[8]
nodeSource = node.read_text(encoding='utf-8')
assert nodeSource.count('            context.eval(prepared);') == 1
nodeSource = nodeSource.replace('            context.eval(prepared);',
    '            long resourceStarted = System.nanoTime();\\n'
    '            try { context.eval(prepared); } finally {\\n'
    '                ' + probe + '.record("builtinEval/" + entry, resourceStarted);\\n'
    '            }')
node.write_text(nodeSource, encoding='utf-8', newline='\\n')
command = worktree / paths[1]''')
source = source.replace('$changedFiles.Count -ne 8', '$changedFiles.Count -ne 11')
exec(compile(source, str(root / 'prepare-diagnostic-current-generated.py'), 'exec'))

controller = (root / 'diagnostic-a09-retry.ps1').read_text(encoding='utf-8')
controller = controller.replace('a09e5bc29cfef094467446c46d05a18ae4a1c346', revision)
controller = controller.replace('diagnostic-a09e5bc2-retry', 'diagnostic-6e5bb8f0')
(root / 'diagnostic-current.ps1').write_text(controller, encoding='utf-8')
runner = (root / 'run-diagnostic-a09-retry.py').read_text(encoding='utf-8')
runner = runner.replace('diagnostic-a09-retry', 'diagnostic-current')
(root / 'run-diagnostic-current.py').write_text(runner, encoding='utf-8')
restore = (root / 'restore-diagnostic.py').read_text(encoding='utf-8')
restore = restore.replace('diagnostic-manifest', 'diagnostic-current-manifest').replace('diagnostic-originals', 'diagnostic-current-originals')
(root / 'restore-diagnostic-current.py').write_text(restore, encoding='utf-8')
print('CURRENT_DIAGNOSTIC_PREPARED')
