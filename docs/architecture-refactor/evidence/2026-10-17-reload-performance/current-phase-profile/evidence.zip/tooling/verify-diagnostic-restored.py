import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
manifest = json.loads((tools / 'diagnostic-current-manifest.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == manifest['revision']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
for name, row in manifest['files'].items():
    assert hashlib.sha256((worktree / name).read_bytes()).hexdigest() == row['sha256'], name
assert not (worktree / manifest['helper']).exists()
count = 0
for root in [worktree / 'common/build/classes/java/main', worktree / 'versions/26.1.2/build/classes/java/main']:
    for path in root.rglob('*.class'):
        data = path.read_bytes()
        assert not any(tag in data for tag in [b'DEBUG-CLOSEOUT-16', b'DEBUG-CLOSEOUT-17', b'ReloadPerfProbe']), path
        count += 1
assert count > 1500
result = dict(sourceRestoredAndClean=True, helperSourceAbsent=True, recompiledClassesWithoutDiagnosticTags=count,
              revision=manifest['revision'])
(tools / 'diagnostic-6e5bb8f0/restoration.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))
