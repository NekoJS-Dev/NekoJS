
import jdk.jfr.consumer.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import com.google.gson.*;

public class ExistingCpuJfrAnalysis {
    static Map<String,Long> sorted(Map<String,Long> values) {
        Map<String,Long> result = new LinkedHashMap<>();
        values.entrySet().stream().sorted(Map.Entry.<String,Long>comparingByValue().reversed()).limit(35)
            .forEach(entry -> result.put(entry.getKey(), entry.getValue()));
        return result;
    }
    public static void main(String[] args) throws Exception {
        var windows = Files.readAllLines(Path.of(args[1])).stream().map(line -> {
            var parts = line.split("\t"); return new Instant[]{Instant.parse(parts[0]),Instant.parse(parts[1])};
        }).toList();
        Map<String,Long> leaves = new HashMap<>(), jsLeaves = new HashMap<>(), compileMethods = new HashMap<>(), events = new HashMap<>();
        long samples = 0, compileNanos = 0;
        try (var file = new RecordingFile(Path.of(args[0]))) {
            while (file.hasMoreEvents()) {
                var event = file.readEvent();
                if (windows.stream().noneMatch(w -> !event.getStartTime().isBefore(w[0]) && !event.getStartTime().isAfter(w[1]))) continue;
                String name = event.getEventType().getName();
                events.merge(name,1L,Long::sum);
                if (name.equals("jdk.Compilation")) {
                    var method = event.getValue("method");
                    if (method instanceof RecordedMethod m) {
                        compileMethods.merge(m.getType().getName()+"."+m.getName(),event.getDuration().toNanos(),Long::sum);
                        compileNanos += event.getDuration().toNanos();
                    }
                }
                if (!name.equals("jdk.ExecutionSample") && !name.equals("jdk.NativeMethodSample")) continue;
                var thread = event.getThread("sampledThread");
                if (thread == null || !thread.getJavaName().equals("Server thread") || event.getStackTrace() == null) continue;
                var frames = event.getStackTrace().getFrames();
                boolean root = frames.stream().anyMatch(f -> f.getMethod().getType().getName().endsWith("ScriptManager") && f.getMethod().getName().contains("reload"));
                if (!root || frames.isEmpty()) continue;
                samples++;
                var leaf = frames.getFirst().getMethod();
                String label = leaf.getType().getName()+"."+leaf.getName();
                leaves.merge(label,1L,Long::sum);
                if (frames.stream().anyMatch(f -> f.getMethod().getType().getName().endsWith("NekoScriptModuleLoaderHost") && f.getMethod().getName().equals("executeScriptModule")))
                    jsLeaves.merge(label,1L,Long::sum);
            }
        }
        var result = new LinkedHashMap<String,Object>();
        result.put("diagnosticOnly",true); result.put("sampleCountsNotMilliseconds",true);
        result.put("serverRootSamples",samples); result.put("rootLeafCounts",sorted(leaves));
        result.put("scriptExecutionLeafCounts",sorted(jsLeaves)); result.put("recordedCompileNanos",compileNanos);
        result.put("recordedCompileMethodsNanos",sorted(compileMethods)); result.put("eventCounts",sorted(events));
        Files.writeString(Path.of(args[2]),new GsonBuilder().setPrettyPrinting().create().toJson(result));
    }
}
