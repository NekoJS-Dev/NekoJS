import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.api.event.EventGroup;
import com.tkisor.nekojs.api.plugin.IPluginRuntime;
import com.tkisor.nekojs.core.*;
import com.tkisor.nekojs.core.compiler.ScriptCompilerRegistry;
import com.tkisor.nekojs.core.config.SandboxConfig;
import com.tkisor.nekojs.core.error.DefaultErrorTracker;
import com.tkisor.nekojs.core.fs.*;
import com.tkisor.nekojs.core.lifecycle.NekoRuntimeRoot;
import com.tkisor.nekojs.core.pack.ScriptPackRegistry;
import com.tkisor.nekojs.script.prop.*;
import com.tkisor.nekojs.testfixture.*;
import graal.graalvm.polyglot.*;
import com.google.gson.Gson;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import jdk.jfr.*;

public class PreflightDuplicationControl {
    static Map<String, EventGroup> groups() {
        Map<String, EventGroup> groups = new LinkedHashMap<>();
        for (var entry : Map.of("ServerEvents", List.of("started", "tagsUpdated", "tickPre", "stopped"),
                "PlayerEvents", List.of("loggedIn"), "LevelEvents", List.of("loaded"),
                "Perf02Bench", List.of("adapterRun")).entrySet()) {
            EventGroup group = EventGroup.of(entry.getKey());
            for (String name : entry.getValue()) group.server(name, Object.class);
            groups.put(entry.getKey(), group);
        }
        return groups;
    }
    public static void main(String[] arguments) throws Exception {
        Path project = Path.of(arguments[0]);
        Path output = Path.of(arguments[1]);
        Path game = output.resolve("game");
        TestPlatformInit.ensureInitialized(game);
        var paths = NekoJSPaths.fromGameDir(game);
        Field instance = NekoJSPaths.class.getDeclaredField("INSTANCE");
        instance.setAccessible(true); instance.set(null, paths);
        Path fixtures = project.resolve("bench/perf/fixtures/nekojs/server_scripts");
        Map<String, String> hashes = new TreeMap<>();
        try (var stream = Files.walk(fixtures)) {
            for (Path file : stream.filter(Files::isRegularFile).toList()) {
                Path target = paths.root().resolve("server_scripts").resolve(fixtures.relativize(file));
                Files.createDirectories(target.getParent()); Files.copy(file, target);
                if (!Arrays.equals(Files.readAllBytes(file), Files.readAllBytes(target))) throw new AssertionError(file);
            }
        }
        if (Files.exists(paths.root().resolve("perf-out/RUN_BENCH"))) throw new AssertionError("Unexpected benchmark mode");
        ScriptPackRegistry.get().deactivateWorldPacks(); ScriptPackRegistry.get().refreshGlobalPacks();
        Map<String, EventGroup> groups = groups();
        IPluginRuntime plugins = (IPluginRuntime) Proxy.newProxyInstance(IPluginRuntime.class.getClassLoader(), new Class<?>[]{IPluginRuntime.class},
                (proxy, method, args) -> {
                    if (method.getName().equals("eventGroups")) return groups;
                    if (method.getReturnType() == Map.class) return Map.of();
                    if (method.getReturnType() == List.class) return List.of();
                    return null;
                });
        var config = SandboxConfig.defaultConfig();
        var compilers = ScriptCompilerRegistry.createRuntimeRegistry();
        var tracker = new DefaultErrorTracker(paths, config);
        List<Map<String, Object>> samples = new ArrayList<>();
        try (Engine engine = Engine.newBuilder().option("engine.WarnInterpreterOnly", "false").build();
                Recording recording = new Recording(Configuration.getConfiguration("profile"))) {
            recording.enable("jdk.ExecutionSample").withPeriod(java.time.Duration.ofMillis(1));
            recording.start();
            var core = new NekoCoreContext(engine, config, new ClassFilter(config), tracker);
            var cache = NekoModuleTestFixtures.newCache(paths, compilers, config);
            var sandbox = new NekoSandboxFactory(core, paths, compilers, plugins, cache);
            var properties = new ScriptPropertyRegistry.Impl();
            properties.register(ScriptProperty.AFTER); properties.register(ScriptProperty.MODLOADED);
            properties.register(ScriptProperty.DISABLE); properties.register(ScriptProperty.PRIORITY); properties.freeze();
            var bridge = new DefaultScriptEventBridge(null); bridge.setPluginRuntime(plugins);
            try (var root = new NekoRuntimeRoot(core, plugins, bridge, properties, sandbox, cache)) {
                var manager = root.createScriptManager(ScriptType.SERVER);
                manager.discoverScripts();
                
                Context previous = null;
                for (int index = 0; index < 1; index++) {
                    String epochStart = java.time.Instant.now().toString(); long start = System.nanoTime();
                    var result = root.reload(ScriptType.SERVER);
                    long nanos = System.nanoTime() - start;
                    if (!result.success() || !result.phase().name().equals("COMMIT") || root.errors().count() != 0)
                        throw new AssertionError(result + " errors=" + root.errors());
                    Context current = manager.activeContextForPackOwner();
                    if (current == null || current == previous) throw new AssertionError("Context not replaced");
                    if (previous != null) {
                        boolean closed = false;
                        try { previous.eval("js", "1"); } catch (IllegalStateException expected) { closed = true; }
                        if (!closed) throw new AssertionError("Old Context remains usable");
                    }
                    if (cache.preparedEntryCount() != 6) throw new AssertionError("Expected six prepared entries: " + cache.preparedEntryCount());
                    previous = current;
                    samples.add(Map.of("index", index, "epochStart", epochStart, "epochEnd", java.time.Instant.now().toString(), "nanos", nanos, "generation", result.generation(), "contextReplaced", true,
                            "oldContextClosed", index > 0, "preparedEntries", cache.preparedEntryCount()));
                }

                var activeView = cache.activeBindingSchemaView(ScriptType.SERVER);
                if (activeView.schemas().isEmpty() || activeView.globals().isEmpty()) throw new AssertionError("Schema missing");
                Map<Path, String> sources = new LinkedHashMap<>();
                try (var files = Files.walk(paths.root().resolve("server_scripts"))) {
                    for (Path file : files.filter(Files::isRegularFile).filter(f -> f.toString().endsWith(".js")).sorted().toList()) {
                        sources.put(file, Files.readString(file));
                    }
                }
                List<Map<String, Object>> contrast = new ArrayList<>();
                List<String> expectedDiagnostics = new ArrayList<>();
                for (var entry : sources.entrySet()) {
                    var view = new com.tkisor.nekojs.api.event.ScriptBindingSchema.View(activeView.schemas(), activeView.globals(),
                        d -> expectedDiagnostics.add(d.callbackKind()+":"+d.throwable().getMessage()));
                    com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator.validate(entry.getKey(), entry.getValue(), view);
                }
                for (int pair = 0; pair < 10; pair++) {
                    for (String arm : pair % 2 == 0 ? List.of("baseline", "capture-replay") : List.of("capture-replay", "baseline")) {
                        long start = System.nanoTime();
                        List<String> actual = new ArrayList<>();
                        int reports = 0;
                        for (int round = 0; round < 20; round++) {
                            actual.clear();
                            for (var entry : sources.entrySet()) {
                                var events = new ArrayList<com.tkisor.nekojs.api.event.ScriptBindingSchema.Diagnostic>();
                                var view = new com.tkisor.nekojs.api.event.ScriptBindingSchema.View(activeView.schemas(), activeView.globals(),
                                    d -> { events.add(d); actual.add(d.callbackKind()+":"+d.throwable().getMessage()); });
                                com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator.validate(entry.getKey(), entry.getValue(), view);
                                if (arm.equals("baseline")) {
                                    com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator.validate(entry.getKey(), entry.getValue(), view);
                                } else {
                                    for (var d : List.copyOf(events)) view.report(d.type(), d.callbackKind(), d.throwable());
                                }
                            }
                            if (actual.size() != expectedDiagnostics.size()*2) throw new AssertionError("Diagnostic count changed");
                            reports += actual.size();
                        }
                        contrast.add(Map.of("pair", pair, "arm", arm, "rounds", 20, "nanos", System.nanoTime()-start, "reports", reports));
                    }
                }
                Files.writeString(output.resolve("contrast.json"), new Gson().toJson(contrast));
                Files.writeString(output.resolve("diagnostics.json"), new Gson().toJson(expectedDiagnostics));
            }
            recording.stop(); recording.dump(output.resolve("root-profile.jfr"));
        }
        Files.writeString(output.resolve("samples.json"), new Gson().toJson(samples));
    }
}
