"""Read Windows process execution policy. This script has no mutation API."""
import ctypes
from ctypes import wintypes
import json
import os
import subprocess
from pathlib import Path

kernel = ctypes.WinDLL('kernel32', use_last_error=True)


class State(ctypes.Structure):
    _fields_ = [('Version', wintypes.ULONG), ('ControlMask', wintypes.ULONG), ('StateMask', wintypes.ULONG)]


kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.GetProcessInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
kernel.GetProcessInformation.restype = wintypes.BOOL
kernel.GetPriorityClass.argtypes = [wintypes.HANDLE]
kernel.GetPriorityClass.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.CloseHandle.restype = wintypes.BOOL
targets = json.loads(subprocess.check_output(['powershell.exe', '-NoProfile', '-Command',
    '@(Get-Process java -ErrorAction SilentlyContinue | Select-Object Id,ProcessName) | ConvertTo-Json -Compress'], text=True))
if not isinstance(targets, list): targets = [targets]
targets += [dict(Id=os.getpid(), ProcessName='query-python'), dict(Id=os.getppid(), ProcessName='query-parent')]
rows = []
for target in targets:
    handle = kernel.OpenProcess(0x1000, False, target['Id'])
    if not handle:
        rows.append(dict(target, error=ctypes.get_last_error()))
        continue
    try:
        state = State(1, 0, 0)
        success = bool(kernel.GetProcessInformation(handle, 4, ctypes.byref(state), ctypes.sizeof(state)))
        row = dict(target, success=success, priorityClass=kernel.GetPriorityClass(handle))
        if success:
            row.update(controlMask=state.ControlMask, stateMask=state.StateMask,
                       explicitEcoQos=bool(state.ControlMask & state.StateMask & 1))
        else: row['error'] = ctypes.get_last_error()
        rows.append(row)
    finally: kernel.CloseHandle(handle)
result = dict(readOnly=True, processPolicyChanged=False, processes=rows)
Path(__file__).with_name('process-qos-snapshot.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))
