import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
binding = json.loads((tools/'cpu-source-binding.json').read_text())
target = worktree/binding['path']
assert hashlib.sha256(target.read_bytes()).hexdigest() == binding['instrumentedSha256']
original = (tools/'cpu-original-command.java').read_bytes()
assert hashlib.sha256(original).hexdigest() == binding['originalSha256']
target.write_bytes(original)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
state = dict(sourceRestored=True, cleanCheckout=True, originalSha256=binding['originalSha256'],
             restoredBuildPending=True, instrumentedClassMustNotBeUsedAsFormalSource=True)
(tools/'diagnostic-cpu-6e5bb8f0/restoration.json').write_text(json.dumps(state, indent=2)+'\n', encoding='utf-8')
build = (tools/'visibility-restored-build.ps1').read_text(encoding='utf-8').replace('visibility-restored-build', 'cpu-restored-build')
(tools/'cpu-restored-build.ps1').write_text(build, encoding='utf-8')
print('CPU_SOURCE_RESTORED')
