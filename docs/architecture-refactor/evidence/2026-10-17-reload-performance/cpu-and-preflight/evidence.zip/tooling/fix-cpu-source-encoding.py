import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
binding = json.loads((tools/'cpu-source-binding.json').read_text())
source = worktree/binding['path']
failed = tools/'cpu-encoding-failure'
assert not failed.exists()
failed.mkdir()
bad = source.read_bytes()
(failed/'instrumented-source-cp936.java').write_bytes(bad)
reports = worktree/'versions/26.1.2/build/test-results/test'
shutil.copytree(reports, failed/'test-results')
failures = []
for file in reports.glob('TEST-*.xml'):
    suite = ET.parse(file).getroot()
    for case in suite.findall('testcase'):
        for failure in case.findall('failure'):
            failures.append(dict(className=case.attrib['classname'], name=case.attrib['name'], message=failure.attrib.get('message', '')))
fixed = bad.decode('cp936').encode('utf-8')
assert b'[DEBUG-CPU-18]' in fixed
source.write_bytes(fixed)
binding['firstInstrumentedSha256'] = binding['instrumentedSha256']
binding['instrumentedSha256'] = hashlib.sha256(fixed).hexdigest()
(tools/'cpu-source-binding.json').write_text(json.dumps(binding, indent=2)+'\n', encoding='utf-8')
(failed/'summary.json').write_text(json.dumps(dict(cause='Diagnostic writer used cp936 instead of explicit UTF-8',
    failures=failures, failedSha256=hashlib.sha256(bad).hexdigest(), fixedSha256=binding['instrumentedSha256']), indent=2)+'\n', encoding='utf-8')
build = (tools/'cpu-instrumented-build.ps1').read_text(encoding='utf-8')
build = build.replace('cpu-instrumented-build', 'cpu-utf8-build')
(tools/'cpu-utf8-build.ps1').write_text(build, encoding='utf-8')
print(json.dumps(dict(failedTests=len(failures), classes=sorted({row['className'] for row in failures}), fixedEncoding='UTF-8')))
