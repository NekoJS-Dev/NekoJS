import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
relative = 'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java'
path = worktree/relative
original = path.read_bytes()
backup = tools/'cpu-original-command.java'
assert not backup.exists()
backup.write_bytes(original)
source = original.decode()
before = '            reloadResult = root.reload(type);'
assert source.count(before) == 1
source = source.replace(before, '''            ReloadCpuStamp cpuStart = ReloadCpuStamp.capture();
            reloadResult = root.reload(type);
            cpuStart.report("root");''')
before = '                    recipeBroadcast = applyRecipeScripts(source);'
assert source.count(before) == 1
source = source.replace(before, '''                    ReloadCpuStamp cpuStartRecipe = ReloadCpuStamp.capture();
                    recipeBroadcast = applyRecipeScripts(source);
                    cpuStartRecipe.report("recipe");''')
before = '    private static boolean applyRecipeScripts(CommandSourceStack source) {'
assert source.count(before) == 1
source = source.replace(before, '''    private record ReloadCpuStamp(long wall, long threadCpu, long processCpu, long gcMillis, long jitMillis) {
        static ReloadCpuStamp capture() {
            long thread = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            long process = ((com.sun.management.OperatingSystemMXBean) java.lang.management.ManagementFactory.getOperatingSystemMXBean()).getProcessCpuTime();
            long gc = java.lang.management.ManagementFactory.getGarbageCollectorMXBeans().stream().mapToLong(java.lang.management.GarbageCollectorMXBean::getCollectionTime).sum();
            long jit = java.lang.management.ManagementFactory.getCompilationMXBean().getTotalCompilationTime();
            return new ReloadCpuStamp(System.nanoTime(), thread, process, gc, jit);
        }
        void report(String stage) {
            ReloadCpuStamp end = capture();
            System.err.println("[DEBUG-CPU-18] stage=" + stage + " wallNs=" + (end.wall-wall)
                + " threadCpuNs=" + (end.threadCpu-threadCpu) + " processCpuNs=" + (end.processCpu-processCpu)
                + " gcMs=" + (end.gcMillis-gcMillis) + " jitMs=" + (end.jitMillis-jitMillis));
        }
    }

'''+before)
path.write_text(source, encoding='utf-8', newline='\n')
(tools/'cpu-source-binding.json').write_text(json.dumps(dict(revision='6e5bb8f00c3747b828056589853cb0471477b18a', path=relative,
    originalSha256=hashlib.sha256(original).hexdigest(), instrumentedSha256=hashlib.sha256(path.read_bytes()).hexdigest()), indent=2)+'\n')
(tools/'cpu.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', relative], cwd=worktree))

controller = (tools/'real-rcon-invocation-control.ps1').read_text().split("New-Item -ItemType Directory -Path $OutDir | Out-Null")[0]
controller = controller.replace('real-rcon-invocation-control-6e5bb8f0', 'diagnostic-cpu-6e5bb8f0')
controller = controller.replace("if (@(& git -C $ProjectDir status --porcelain).Count -ne 0)", "if (@(& git -C $ProjectDir diff --name-only).Count -ne 1)")
controller += r'''
New-Item -ItemType Directory -Path $OutDir | Out-Null
Write-EnvSnapshot
Deploy-Fixtures -Bench:$false
$session = Invoke-ServerSession -Tag 'cpu' -OnDone {
    param($proc, $outLog, $sw)
    $offset = (Get-Item -LiteralPath $outLog).Length
    $rows = @()
    try {
        for ($index = 1; $index -le 10; $index++) {
            Start-Sleep -Seconds 3
            [void](Read-LogTailUtf8 $outLog ([ref]$offset))
            $timer = [Diagnostics.Stopwatch]::StartNew()
            $response = Invoke-Rcon -Command 'nekojs reload'
            $rconMs = $timer.Elapsed.TotalMilliseconds
            if ($response -notmatch 'phase=COMMIT - no errors\.') { throw 'Reload diagnostic did not commit' }
            $markerMs = $null
            $deadline = [DateTime]::UtcNow.AddSeconds(10)
            while ([DateTime]::UtcNow -lt $deadline) {
                $chunk = Read-LogTailUtf8 $outLog ([ref]$offset)
                if ($chunk.Contains($script:ReloadMarker)) { $markerMs = $timer.Elapsed.TotalMilliseconds; break }
                Start-Sleep -Milliseconds 100
            }
            if ($null -eq $markerMs) { throw 'Reload diagnostic marker missing' }
            $rows += @{index=$index;rconMs=$rconMs;markerMs=$markerMs;response=$response}
            $rows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $OutDir 'observations.json') -Encoding UTF8
        }
    } finally { $stop = Stop-Server $proc }
    @{stopSent=$true;stopChannel=$stop.channel;killed=$stop.killed}
}
$session | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $OutDir 'session.json') -Encoding UTF8
if ($session.forcedKill -or $session.extra.killed -or $session.extra.stopChannel -ne 'rcon') { throw 'Diagnostic shutdown was not normal' }
Write-Output 'CPU_DIAGNOSTIC_COMPLETE'
'''
# This is a raw PowerShell string; the match needs a single literal-dot escape.
controller = controller.replace(r'no errors\\.', r'no errors\.')
(tools/'cpu-diagnostic.ps1').write_text(controller, encoding='utf-8')
build = (tools/'visibility-restored-build.ps1').read_text()
build = build.replace("if (@(& git -C $ownedRoot status --porcelain).Count -ne 0) { throw 'Owned checkout is not clean' }", "if (@(& git -C $ownedRoot diff --name-only).Count -ne 1) { throw 'Unexpected diagnostic diff' }")
build = build.replace('& git -C $ownedRoot switch --detach $revision', '# Diagnostic source remains on the frozen revision.')
build = build.replace('visibility-restored-build', 'cpu-instrumented-build').replace('DIAGNOSTIC_RESTORED_BUILD_COMPLETE', 'CPU_INSTRUMENTED_BUILD_COMPLETE')
(tools/'cpu-instrumented-build.ps1').write_text(build, encoding='utf-8')
runner = (tools/'run-visibility.py').read_text().replace("'visibility.ps1'", "'cpu-diagnostic.ps1'").replace('visibility-controller', 'cpu-controller').replace('visibility-exit', 'cpu-exit')
(tools/'run-cpu-diagnostic.py').write_text(runner, encoding='utf-8')
print('CPU_DIAGNOSTIC_PREPARED')
