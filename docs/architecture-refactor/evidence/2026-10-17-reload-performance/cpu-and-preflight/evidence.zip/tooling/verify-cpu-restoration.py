import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
baseline = json.loads((tools/'candidate-6e5bb8f0-formal/preparation.json').read_text())
classes = {}
for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    root = worktree/relative
    for file in root.rglob('*.class'):
        key = file.relative_to(root).as_posix()
        assert key not in classes
        data = file.read_bytes()
        assert b'DEBUG-CPU-18' not in data
        classes[key] = hashlib.sha256(data).hexdigest()
assert classes == baseline['classBindings']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
state = dict(sourceRestored=True, cleanCheckout=True, restoredBuildPending=False, restoredBuild='PASS',
             compiledClasses=len(classes), classesMatchOriginalFormal=True, classBindings=classes,
             diagnosticMarkerAbsent=True, formalVerdictUnchanged='FAIL')
(tools/'diagnostic-cpu-6e5bb8f0/restoration.json').write_text(json.dumps(state, indent=2)+'\n', encoding='utf-8')
print(json.dumps({key:value for key,value in state.items() if key != 'classBindings'}))
