import hashlib
import json
import shutil
from pathlib import Path

tools = Path(__file__).resolve().parent
target = tools/'diagnostic-cpu-6e5bb8f0'
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
classes = {}
for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    root = worktree/relative
    for file in root.rglob('*.class'):
        key = file.relative_to(root).as_posix()
        assert key not in classes
        classes[key] = hashlib.sha256(file.read_bytes()).hexdigest()
baseline = json.loads((tools/'candidate-6e5bb8f0-formal/preparation.json').read_text())['classBindings']
changes = sorted(key for key in classes.keys() | baseline.keys() if classes.get(key) != baseline.get(key))
assert all(key.startswith('com/tkisor/nekojs/command/NekoJSCommands') for key in changes), changes
(target/'instrumented-classes.json').write_text(json.dumps(dict(classes=classes, changedFromFormal=changes), indent=2)+'\n', encoding='utf-8')
shutil.copytree(worktree/'versions/26.1.2/build/test-results', target/'instrumented-test-results')
binding = json.loads((tools/'cpu-source-binding.json').read_text())
source = worktree/binding['path']
assert hashlib.sha256(source.read_bytes()).hexdigest() == binding['instrumentedSha256']
(target/'instrumented-command.java').write_bytes(source.read_bytes())
print(json.dumps(dict(mainClasses=len(classes), changedFromFormal=changes)))
