import json
import os
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
base = project/'build/priority-closeout/root-reload-diagnostic-v3'
target = project/'build/priority-closeout/preflight-duplication-control'
assert not target.exists()
target.mkdir()
source = (base/'RootReloadDiagnostic.java').read_text()
source = source.replace('public class RootReloadDiagnostic', 'public class PreflightDuplicationControl')
source = source.replace('index < 30', 'index < 1')
needle = '            }\n            recording.stop();'
assert needle in source
source = source.replace(needle, r'''
                var activeView = cache.activeBindingSchemaView(ScriptType.SERVER);
                if (activeView.schemas().isEmpty() || activeView.globals().isEmpty()) throw new AssertionError("Schema missing");
                Map<Path, String> sources = new LinkedHashMap<>();
                try (var files = Files.walk(paths.root().resolve("server_scripts"))) {
                    for (Path file : files.filter(Files::isRegularFile).filter(f -> f.toString().endsWith(".js")).sorted().toList()) {
                        sources.put(file, Files.readString(file));
                    }
                }
                List<Map<String, Object>> contrast = new ArrayList<>();
                List<String> expectedDiagnostics = new ArrayList<>();
                for (var entry : sources.entrySet()) {
                    var view = new com.tkisor.nekojs.api.event.ScriptBindingSchema.View(activeView.schemas(), activeView.globals(),
                        d -> expectedDiagnostics.add(d.callbackKind()+":"+d.throwable().getMessage()));
                    com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator.validate(entry.getKey(), entry.getValue(), view);
                }
                for (int pair = 0; pair < 10; pair++) {
                    for (String arm : pair % 2 == 0 ? List.of("baseline", "capture-replay") : List.of("capture-replay", "baseline")) {
                        long start = System.nanoTime();
                        List<String> actual = new ArrayList<>();
                        int reports = 0;
                        for (int round = 0; round < 20; round++) {
                            actual.clear();
                            for (var entry : sources.entrySet()) {
                                var events = new ArrayList<com.tkisor.nekojs.api.event.ScriptBindingSchema.Diagnostic>();
                                var view = new com.tkisor.nekojs.api.event.ScriptBindingSchema.View(activeView.schemas(), activeView.globals(),
                                    d -> { events.add(d); actual.add(d.callbackKind()+":"+d.throwable().getMessage()); });
                                com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator.validate(entry.getKey(), entry.getValue(), view);
                                if (arm.equals("baseline")) {
                                    com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator.validate(entry.getKey(), entry.getValue(), view);
                                } else {
                                    for (var d : List.copyOf(events)) view.report(d.type(), d.callbackKind(), d.throwable());
                                }
                            }
                            if (actual.size() != expectedDiagnostics.size()*2) throw new AssertionError("Diagnostic count changed");
                            reports += actual.size();
                        }
                        contrast.add(Map.of("pair", pair, "arm", arm, "rounds", 20, "nanos", System.nanoTime()-start, "reports", reports));
                    }
                }
                Files.writeString(output.resolve("contrast.json"), new Gson().toJson(contrast));
                Files.writeString(output.resolve("diagnostics.json"), new Gson().toJson(expectedDiagnostics));
            }
            recording.stop();''')
(target/'PreflightDuplicationControl.java').write_text(source)
classpath = (base/'runtime-classpath.txt').read_text().strip()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
classes = target/'classes'
classes.mkdir()
for label, command in [('compile', [str(java/'javac.exe'), '-cp', classpath, '-d', str(classes), str(target/'PreflightDuplicationControl.java')]),
                       ('run', [str(java/'java.exe'), '-cp', str(classes)+';'+classpath, 'PreflightDuplicationControl', str(project), str(target)])]:
    with (target/(label+'.log')).open('xb') as stdout, (target/(label+'-stderr.log')).open('xb') as stderr:
        result = subprocess.run(command, cwd=project, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, label
rows = json.loads((target/'contrast.json').read_text())
means = {arm: sum(row['nanos']/row['rounds']/1e6 for row in rows if row['arm'] == arm)/10 for arm in ['baseline', 'capture-replay']}
summary = dict(diagnosticOnly=True, upperBoundNotProductionChange=True, sources=6, pairs=10,
               meanMsPerSix=means, savingMs=means['baseline']-means['capture-replay'],
               diagnosticsPerSix=len(json.loads((target/'diagnostics.json').read_text())))
(target/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary))
