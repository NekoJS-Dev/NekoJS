import hashlib
import json
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
target = project/'docs/architecture-refactor/evidence/2026-10-17-reload-performance/cpu-and-preflight'
target.mkdir(exist_ok=True)
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
properties = dict(line.split('=', 1) for line in (worktree/'versions/26.1.2/run/server.properties').read_text().splitlines()
                  if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password'].encode()
files, redactions = {}, {}


def add(file, name):
    assert name not in files
    data = file.read_bytes()
    if secret in data:
        redactions[name] = dict(originalSha256=hashlib.sha256(data).hexdigest(), occurrences=data.count(secret))
        data = data.replace(secret, b'<REDACTED-RCON-CREDENTIAL>')
    files[name] = data


for relative,label in [('diagnostic-cpu-6e5bb8f0','cpu'), ('cpu-encoding-failure','encoding-failure')]:
    root = tools/relative
    for file in root.rglob('*'):
        if file.is_file() and (file.suffix in {'.json','.java','.xml','.log','.txt'}):
            add(file, label+'/'+file.relative_to(root).as_posix())
for relative,label in [('preflight-duplication-control','preflight'), ('existing-cpu-jfr-analysis','prior-jfr')]:
    root = tools/relative
    for file in root.iterdir():
        if file.is_file() and file.suffix in {'.json','.java','.log'}: add(file, label+'/'+file.name)
for name in ['prepare-cpu-diagnostic.py', 'fix-cpu-source-encoding.py', 'cpu-instrumented-build.ps1', 'cpu-utf8-build.ps1',
             'cpu-restored-build.ps1', 'cpu-diagnostic.ps1', 'run-cpu-diagnostic.py', 'analyze-cpu-diagnostic.py',
             'freeze-cpu-inputs.py', 'restore-cpu-diagnostic.py', 'verify-cpu-restoration.py', 'preflight-duplication-control.py',
             'analyze-existing-cpu-jfr.py', 'query-process-qos.py', 'process-qos-snapshot.json', 'cpu-source-binding.json',
             'cpu-original-command.java', 'cpu.patch', 'cpu-controller.log', 'cpu-controller-stderr.log', 'cpu-exit.json',
             'cpu-instrumented-build.log', 'cpu-instrumented-build-stderr.log', 'cpu-utf8-build.log', 'cpu-utf8-build-stderr.log',
             'cpu-restored-build.log', 'cpu-restored-build-stderr.log', 'seal-cpu-diagnostic.py']:
    add(tools/name, 'tooling/'+name)
add(tools/'candidate-6e5bb8f0-formal/preparation.json', 'formal-preparation.json')
for name in ['windows.tsv','windowed-profile.txt']:
    add(tools/'diagnostic-6e5bb8f0'/name, 'prior-jfr/'+name)
raw = tools/'diagnostic-6e5bb8f0/reload.jfr'
files['prior-jfr/input-binding.json'] = (json.dumps(dict(originalBinaryArchived=False,
    originalBinarySha256=hashlib.sha256(raw.read_bytes()).hexdigest(),
    reason='Preserve the original locally; never redact binary recordings by byte replacement'), indent=2)+'\n').encode()
restoration = json.loads((tools/'diagnostic-cpu-6e5bb8f0/restoration.json').read_text())
assert restoration['classesMatchOriginalFormal'] and not restoration['restoredBuildPending']
files['redactions.json'] = (json.dumps(redactions, indent=2)+'\n').encode()
packed = target/'evidence.zip'
assert not packed.exists()
with zipfile.ZipFile(packed, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()): archive.writestr(name, data)
manifest = dict(diagnosticOnly=True, archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
    entries={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(entries=len(files), zipBytes=packed.stat().st_size, archiveSha256=manifest['archiveSha256'])))
