import json
import re
import statistics
from pathlib import Path

tools = Path(__file__).resolve().parent
root = tools/'diagnostic-cpu-6e5bb8f0'
rows = json.loads((root/'observations.json').read_text(encoding='utf-8-sig'))
assert [row['index'] for row in rows] == list(range(1, 11))
trace = (root/'cpu-stderr.log').read_text(encoding='utf-8', errors='replace')
pattern = r'\[DEBUG-CPU-18\] stage=(root|recipe) wallNs=(\d+) threadCpuNs=(\d+) processCpuNs=(\d+) gcMs=(\d+) jitMs=(\d+)'
events = [dict(stage=match[0], **{key:int(value) for key,value in zip(['wallNs','threadCpuNs','processCpuNs','gcMs','jitMs'], match[1:])})
          for match in re.findall(pattern, trace)]
assert [row['stage'] for row in events] == ['root', 'recipe']*10
for index, row in enumerate(rows):
    assert 'phase=COMMIT - no errors.' in row['response']
    row['stages'] = events[2*index:2*index+2]
    row['outsideStagesMs'] = row['rconMs'] - sum(stage['wallNs']/1e6 for stage in row['stages'])
summary = dict(diagnosticOnly=True, formalVerdictUnchanged='FAIL', samples=len(rows), stages={})
for name in ['root', 'recipe']:
    selected = [row for row in events if row['stage'] == name]
    summary['stages'][name] = {key.replace('Ns','Ms'):statistics.mean(row[key]/(1e6 if key.endswith('Ns') else 1) for row in selected)
                             for key in ['wallNs','threadCpuNs','processCpuNs','gcMs','jitMs']}
summary['meanRconMs'] = statistics.mean(row['rconMs'] for row in rows)
summary['meanMarkerMs'] = statistics.mean(row['markerMs'] for row in rows)
summary['meanOutsideStagesMs'] = statistics.mean(row['outsideStagesMs'] for row in rows)
(root/'joined.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf-8')
(root/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(summary))
