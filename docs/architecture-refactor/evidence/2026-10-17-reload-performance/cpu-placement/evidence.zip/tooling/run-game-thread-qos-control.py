import json
import hashlib
import os
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
preparation = json.loads((tools/'candidate-6e5bb8f0-formal/preparation.json').read_text())


def classes():
    result = {}
    for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
        directory = worktree/relative
        for file in directory.rglob('*.class'):
            key = file.relative_to(directory).as_posix()
            assert key not in result
            result[key] = hashlib.sha256(file.read_bytes()).hexdigest()
    return result


assert classes() == preparation['classBindings']
assert hashlib.sha256((worktree/'bench/perf/sample.ps1').read_bytes()).hexdigest() == preparation['samplerSha256']
bindings = dict(diagnosticOnly=True, revision=preparation['revision'], classBindings=classes(),
    classesMatchOriginalFormal=True, plannedPairs=20, alternatingArms=['original', 'high-qos'], intervalSeconds=3,
    firstSamplesRetained=True, formalVerdictUnchanged='FAIL')
(tools/'game-thread-qos-control-bindings.json').write_text(json.dumps(bindings, indent=2)+'\n')
properties = dict(line.split('=', 1) for line in Path(
    'C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run/server.properties'
).read_text().splitlines() if line and not line.startswith('#') and '=' in line)
environment = dict(os.environ, NEKO_PERF_RCON_PASS=properties['rcon.password'])
with (tools/'game-thread-qos-control-controller.log').open('xb') as stdout, (tools/'game-thread-qos-control-controller-stderr.log').open('xb') as stderr:
    result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                             str(tools/'game-thread-qos-control.ps1')], cwd=project, env=environment,
                            stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
(tools/'game-thread-qos-control-exit.json').write_text(json.dumps(dict(exitCode=result.returncode))+'\n')
print(json.dumps(dict(diagnosticOnly=True, exitCode=result.returncode)))
assert result.returncode == 0
assert classes() == preparation['classBindings']
