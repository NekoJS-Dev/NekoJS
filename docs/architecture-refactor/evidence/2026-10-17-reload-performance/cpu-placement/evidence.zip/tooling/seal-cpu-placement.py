"""Freeze text evidence and immutable input bindings; never redact a binary recording."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
target=project/'docs/architecture-refactor/evidence/2026-10-17-reload-performance/cpu-placement'
worktree=Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
secret=dict(line.split('=',1) for line in (worktree/'versions/26.1.2/run/server.properties').read_text().splitlines() if line and not line.startswith('#') and '=' in line)['rcon.password'].encode()
assert secret
files={};redactions={}
def add(path,name):
    assert name not in files
    data=path.read_bytes()
    if secret in data:
        assert path.suffix in {'.txt','.log','.json','.java','.py','.ps1','.js'}, 'No binary redaction'
        redactions[name]=dict(originalSha256=hashlib.sha256(data).hexdigest(),occurrences=data.count(secret))
        data=data.replace(secret,b'<REDACTED-RCON-CREDENTIAL>')
    files[name]=data

labels=['root-cpu-split','path-cpu-attribution','root-native-attribution','root-cpu-placement','root-thread-qos-control','game-thread-qos-control-6e5bb8f0']
for label in labels:
    root=tools/label
    for file in root.rglob('*'):
        if not file.is_file() or 'game' in file.relative_to(root).parts or 'classes' in file.relative_to(root).parts:continue
        if file.suffix in {'.json','.java','.txt','.log'}:add(file,label+'/'+file.relative_to(root).as_posix())
for name in ['root-cpu-split.py','path-cpu-attribution.py','root-native-attribution.py','root-cpu-placement.py','root-thread-qos-control.py',
             'game-thread-qos.py','prepare-game-thread-qos.py','game-thread-qos-control.ps1','run-game-thread-qos-control.py','analyze-game-thread-qos-control.py',
             'game-thread-qos-control-bindings.json','game-thread-qos-control-exit.json','game-thread-qos-control-controller.log',
             'game-thread-qos-control-controller-stderr.log','seal-cpu-placement.py']:
    add(tools/name,'tooling/'+name)
add(tools/'root-reload-diagnostic-v3/runtime-classpath.txt','tooling/runtime-classpath.txt')
formal=json.loads((tools/'candidate-6e5bb8f0-formal/preparation.json').read_text(encoding='utf-8'))
classes={p.relative_to(project/'common/build/classes/java/main').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (project/'common/build/classes/java/main').rglob('*.class')}
assert len(classes)==1152 and all(formal['classBindings'].get(k)==v for k,v in classes.items())
bindings=dict(diagnosticOnly=True,commonClassBindings=classes,commonMatchesFormal=True,gameClassCount=1625,
    productionRevision=formal['revision'],samplerSha256=formal['samplerSha256'],fixtureHashes=formal['fixtureHashes'],formalVerdictUnchanged='FAIL')
files['input-bindings.json']=(json.dumps(bindings,indent=2)+'\n').encode()
for relative,sha in formal['fixtureHashes'].items():
    path=worktree/relative
    assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
    add(path,'fixtures/'+relative.removeprefix('bench/perf/fixtures/'))
for relative in ['common/src/main/java/com/tkisor/nekojs/core/module/NekoCanonicalPath.java','common/src/main/java/com/tkisor/nekojs/core/fs/NekoJSPaths.java']:
    add(project/relative,'current-sources/'+Path(relative).name)
files['owned-worktree-status.json']=(json.dumps(dict(clean=not subprocess.check_output(['git','-C',str(worktree),'status','--porcelain']).strip()))+'\n').encode()
assert json.loads(files['owned-worktree-status.json'])['clean']
files['redactions.json']=(json.dumps(redactions,indent=2)+'\n').encode()
archive=target/'evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for name,data in sorted(files.items()):out.writestr(name,data)
manifest=dict(diagnosticOnly=True,archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(entries=len(files),bytes=archive.stat().st_size,sha256=manifest['archiveSha256'])))
