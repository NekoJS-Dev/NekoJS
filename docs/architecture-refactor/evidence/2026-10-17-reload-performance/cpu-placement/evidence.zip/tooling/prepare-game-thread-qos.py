import json
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
source=(tools/'real-rcon-invocation-control.ps1').read_text(encoding='utf-8')
source=source.replace('real-rcon-invocation-control-6e5bb8f0','game-thread-qos-control-6e5bb8f0')
start=source.index('function Invoke-DirectRcon {')
end=source.index('New-Item -ItemType Directory',start)
source=source[:start]+'''function Invoke-ThreadPolicy([string]$Mode) {
    $result = & python 'D:\\mcmodDemo\\NekoJS-mult\\build\\priority-closeout\\game-thread-qos.py' $Mode $OutDir
    if ($LASTEXITCODE -ne 0) { throw 'Diagnostic thread policy control failed' }
    return ($result | ConvertFrom-Json)
}
'''+source[end:]
source=source.replace("-Tag 'invocation-control'", "-Tag 'thread-qos-control'")
source=source.replace('    $offset = (Get-Item -LiteralPath $outLog).Length', '''    $gameProcessId = @(Get-NetTCPConnection -LocalPort $RconPort -State Listen | Select-Object -ExpandProperty OwningProcess -Unique)
    if ($gameProcessId.Count -ne 1) { throw 'Diagnostic game PID is ambiguous' }
    $initial = & python 'D:\\mcmodDemo\\NekoJS-mult\\build\\priority-closeout\\game-thread-qos.py' init $OutDir $gameProcessId[0]
    if ($LASTEXITCODE -ne 0) { throw 'Diagnostic thread identification failed' }
    $offset = (Get-Item -LiteralPath $outLog).Length''')
source=source.replace("@('native', 'direct')", "@('original', 'high-qos')").replace("@('direct', 'native')", "@('high-qos', 'original')")
source=source.replace('                $startedUtc =', '                $threadBefore = Invoke-ThreadPolicy $arm\n                $startedUtc =')
source=source.replace("$response = if ($arm -eq 'native') { Invoke-Rcon -Command 'nekojs reload' } else { Invoke-DirectRcon }", "$response = Invoke-Rcon -Command 'nekojs reload'")
source=source.replace('                $rows += @{pair=', '                $threadAfter = Invoke-ThreadPolicy read\n                $null = Invoke-ThreadPolicy restore\n                $rows += @{threadBefore=$threadBefore;threadAfter=$threadAfter;pair=')
source=source.replace('    } finally { $stop = Stop-Server $proc }', '    } finally {\n        try { $null = Invoke-ThreadPolicy restore } finally { $stop = Stop-Server $proc }\n    }')
source=source.replace('REAL_RCON_CONTROL_COMPLETE','GAME_THREAD_QOS_CONTROL_COMPLETE')
(tools/'game-thread-qos-control.ps1').write_text(source,encoding='utf-8')
controller=(tools/'run-real-rcon-control.py').read_text(encoding='utf-8')
controller=controller.replace("alternatingArms=['native', 'direct']", "alternatingArms=['original', 'high-qos']")
controller=controller.replace('real-rcon-control','game-thread-qos-control').replace('real-rcon-invocation-control.ps1','game-thread-qos-control.ps1')
(tools/'run-game-thread-qos-control.py').write_text(controller,encoding='utf-8')
print(json.dumps(dict(prepared=True,sourceCodeChanged=False,formalRun=False,plannedPairs=20)))
