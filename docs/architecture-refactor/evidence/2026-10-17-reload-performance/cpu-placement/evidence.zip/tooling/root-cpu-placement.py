"""Observe CPU placement only; do not change affinity, priority, power or production code."""
import ctypes
from ctypes import wintypes
import json
import statistics
import struct
import subprocess
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
output=tools/'root-cpu-placement'
assert not output.exists()
output.mkdir()
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
query=kernel.GetSystemCpuSetInformation
query.argtypes=[ctypes.c_void_p,wintypes.ULONG,ctypes.POINTER(wintypes.ULONG),wintypes.HANDLE,wintypes.ULONG]
query.restype=wintypes.BOOL
length=wintypes.ULONG()
assert not query(None,0,ctypes.byref(length),None,0) and ctypes.get_last_error()==122
buffer=ctypes.create_string_buffer(length.value)
assert query(buffer,length.value,ctypes.byref(length),None,0)
raw=buffer.raw[:length.value]
topology=[]
offset=0
while offset<len(raw):
    size,kind=struct.unpack_from('<II',raw,offset)
    assert size>=32 and offset+size<=len(raw)
    if kind==0:
        identity,group,logical,core,cache,numa,efficiency,flags=struct.unpack_from('<IHBBBBBB',raw,offset+8)
        topology.append(dict(id=identity,group=group,logicalProcessor=logical,core=core,efficiencyClass=efficiency,flags=flags))
    offset+=size
assert topology and all(r['group']==0 for r in topology)
(output/'topology.json').write_text(json.dumps(dict(readOnly=True,rows=topology),indent=2)+'\n',encoding='utf-8')
source=(tools/'root-cpu-split/RootCpuSplit.java').read_text(encoding='utf-8').replace('public class RootCpuSplit','public class RootCpuPlacement')
source=source.replace('    static Map<String, EventGroup> groups()', '''    static final java.lang.invoke.MethodHandle PROCESSOR = java.lang.foreign.Linker.nativeLinker().downcallHandle(
        java.lang.foreign.SymbolLookup.libraryLookup("kernel32", java.lang.foreign.Arena.global()).find("GetCurrentProcessorNumber").orElseThrow(),
        java.lang.foreign.FunctionDescriptor.of(java.lang.foreign.ValueLayout.JAVA_INT));
    static int processor() { try { return (int) PROCESSOR.invokeExact(); } catch (Throwable e) { throw new AssertionError(e); } }
    static Map<String, EventGroup> groups()''')
source=source.replace('        var cpu =', '        processor();\n        var cpu =')
source=source.replace('                    long cpuStart =', '                    int processorBefore = processor();\n                    long cpuStart =')
source=source.replace('                    long nanos = System.nanoTime() - start;', '                    long nanos = System.nanoTime() - start;\n                    int processorAfter = processor();')
source=source.replace('                    samples.getLast().put("cpuNanos", cpuNanos);', '                    samples.getLast().put("processorBefore", processorBefore);\n                    samples.getLast().put("processorAfter", processorAfter);\n                    samples.getLast().put("cpuNanos", cpuNanos);')
(output/'RootCpuPlacement.java').write_text(source,encoding='utf-8')
classpath=(tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
classes=output/'classes';classes.mkdir()
commands=[('compile',[str(java/'javac.exe'),'-encoding','UTF-8','-cp',classpath,'-d',str(classes),str(output/'RootCpuPlacement.java')]),
          ('run',[str(java/'java.exe'),'--enable-native-access=ALL-UNNAMED','-cp',str(classes)+';'+classpath,'RootCpuPlacement',str(project),str(output)])]
for label,command in commands:
    with (output/(label+'.log')).open('xb') as out,(output/(label+'-stderr.log')).open('xb') as err:
        result=subprocess.run(command,cwd=project,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0,label
rows=json.loads((output/'samples.json').read_text(encoding='utf-8'))
classesByProcessor={r['logicalProcessor']:r['efficiencyClass'] for r in topology}
summary=dict(diagnosticOnly=True,policyChanged=False,allSamplesRetained=True,groups={})
for label,chosen in [('all',rows),('firstTen',rows[:10]),('lastTwenty',rows[10:])]:
    summary['groups'][label]=dict(wallMs=statistics.mean(r['nanos']/1e6 for r in chosen),
        placement=[dict(index=r['index'],before=r['processorBefore'],after=r['processorAfter'],beforeClass=classesByProcessor[r['processorBefore']],afterClass=classesByProcessor[r['processorAfter']]) for r in chosen])
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(topology=topology,summary=summary)))
