"""Component diagnostic: split owner-thread CPU into user and kernel observations."""
import json
import statistics
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
target = tools/'root-cpu-split'
assert not target.exists()
target.mkdir()
base = tools/'root-reload-diagnostic-v3'
source = (base/'RootReloadDiagnostic.java').read_text(encoding='utf-8')
source = source.replace('public class RootReloadDiagnostic', 'public class RootCpuSplit')
source = source.replace('        List<Map<String, Object>> samples = new ArrayList<>();', '''        List<Map<String, Object>> samples = new ArrayList<>();
        var cpu = java.lang.management.ManagementFactory.getThreadMXBean();
        if (!cpu.isCurrentThreadCpuTimeSupported() || !cpu.isThreadCpuTimeEnabled()) throw new AssertionError("CPU counters unavailable");
        cpu.getCurrentThreadCpuTime(); cpu.getCurrentThreadUserTime();''')
source = source.replace('            recording.enable("jdk.ExecutionSample").withPeriod(java.time.Duration.ofMillis(1));', '')
source = source.replace('            recording.start();', '')
source = source.replace('                    var result = root.reload(ScriptType.SERVER);', '''                    long cpuStart = cpu.getCurrentThreadCpuTime();
                    long userStart = cpu.getCurrentThreadUserTime();
                    var result = root.reload(ScriptType.SERVER);
                    long cpuNanos = cpu.getCurrentThreadCpuTime()-cpuStart;
                    long userNanos = cpu.getCurrentThreadUserTime()-userStart;''')
source = source.replace('                            "oldContextClosed", index > 0, "preparedEntries", cache.preparedEntryCount()));', '''                            "oldContextClosed", index > 0, "preparedEntries", cache.preparedEntryCount()));
                    samples.set(samples.size()-1, new LinkedHashMap<>(samples.getLast()));
                    samples.getLast().put("cpuNanos", cpuNanos);
                    samples.getLast().put("userNanos", userNanos);''')
source = source.replace('            recording.stop(); recording.dump(output.resolve("root-profile.jfr"));', '')
(target/'RootCpuSplit.java').write_text(source, encoding='utf-8')
classpath = (base/'runtime-classpath.txt').read_text().strip()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
classes = target/'classes'
classes.mkdir()
for label,command in [('compile',[str(java/'javac.exe'),'-cp',classpath,'-d',str(classes),str(target/'RootCpuSplit.java')]),
                      ('run',[str(java/'java.exe'),'-cp',str(classes)+';'+classpath,'RootCpuSplit',str(project),str(target)])]:
    with (target/(label+'.log')).open('xb') as out, (target/(label+'-stderr.log')).open('xb') as err:
        result = subprocess.run(command,cwd=project,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, label
rows = json.loads((target/'samples.json').read_text())
summary = dict(diagnosticOnly=True, noMinecraftRecipesRcon=True, samples=len(rows), allSamplesRetained=True, groups={})
for label,chosen in [('all',rows),('firstTen',rows[:10]),('lastTwenty',rows[10:])]:
    summary['groups'][label] = dict(wallMs=statistics.mean(r['nanos']/1e6 for r in chosen),
        cpuMs=statistics.mean(r['cpuNanos']/1e6 for r in chosen),userMs=statistics.mean(r['userNanos']/1e6 for r in chosen),
        kernelByDifferenceMs=statistics.mean((r['cpuNanos']-r['userNanos'])/1e6 for r in chosen))
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
