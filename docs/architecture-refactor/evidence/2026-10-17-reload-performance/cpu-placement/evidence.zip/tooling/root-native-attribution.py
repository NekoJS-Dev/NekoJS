"""Sample native leaves and file I/O in an unchanged-production root component."""
import hashlib
import json
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
output = tools/'root-native-attribution'
assert not output.exists()
output.mkdir()
source = (tools/'root-cpu-split/RootCpuSplit.java').read_text(encoding='utf-8')
source = source.replace('public class RootCpuSplit', 'public class RootNativeAttribution')
source = source.replace('            var core =', '''            recording.enable("jdk.NativeMethodSample").withPeriod(java.time.Duration.ofMillis(1));
            recording.enable("jdk.ExecutionSample").withPeriod(java.time.Duration.ofMillis(1));
            recording.enable("jdk.FileRead").withThreshold(java.time.Duration.ZERO).withStackTrace();
            recording.enable("jdk.FileWrite").withThreshold(java.time.Duration.ZERO).withStackTrace();
            recording.start();
            var core =''')
source = source.replace('        Files.writeString(output.resolve("samples.json")', '        Files.writeString(output.resolve("samples.json")')
source = source.replace('            }\n\n        }\n        Files.writeString', '            }\n            recording.stop(); recording.dump(output.resolve("root-native.jfr"));\n        }\n        Files.writeString')
assert 'recording.dump' in source
(output/'RootNativeAttribution.java').write_text(source,encoding='utf-8')
analysis = '''
import java.nio.file.*; import java.time.*; import java.util.*;
import jdk.jfr.consumer.*; import com.google.gson.*;
public class RootNativeAnalysis {
  static Map<String,Long> sort(Map<String,Long> map) {
    var result = new LinkedHashMap<String,Long>();
    map.entrySet().stream().sorted(Map.Entry.<String,Long>comparingByValue().reversed()).limit(60).forEach(e->result.put(e.getKey(),e.getValue())); return result;
  }
  public static void main(String[] args) throws Exception {
    var samples = JsonParser.parseString(Files.readString(Path.of(args[1]))).getAsJsonArray();
    var groups = new LinkedHashMap<String,Object>();
    for (int first : new int[]{0,10}) {
      Map<String,Long> leaves=new HashMap<>(), events=new HashMap<>(), ioNanos=new HashMap<>(), frames=new HashMap<>();
      try (var file = new RecordingFile(Path.of(args[0]))) {
        while (file.hasMoreEvents()) {
          var e=file.readEvent(); boolean inside=false;
          for (int i=first;i<samples.size();i++) { var r=samples.get(i).getAsJsonObject();
            if (!e.getStartTime().isBefore(Instant.parse(r.get("epochStart").getAsString())) && !e.getStartTime().isAfter(Instant.parse(r.get("epochEnd").getAsString()))) {inside=true;break;}
          }
          if (!inside) continue; String name=e.getEventType().getName();
          if (name.equals("jdk.FileRead")||name.equals("jdk.FileWrite")) {
            var thread=e.getThread(); if(thread==null||!thread.getJavaName().equals("main"))continue;
            ioNanos.merge(name+":"+e.getString("path"),e.getDuration().toNanos(),Long::sum); events.merge(name,1L,Long::sum);
          }
          if (!name.equals("jdk.ExecutionSample")&&!name.equals("jdk.NativeMethodSample"))continue;
          var t=e.getThread("sampledThread"); if(t==null||!t.getJavaName().equals("main")||e.getStackTrace()==null)continue;
          events.merge(name,1L,Long::sum);var fs=e.getStackTrace().getFrames();if(fs.isEmpty())continue;
          var leaf=fs.getFirst().getMethod(); leaves.merge(name+":"+leaf.getType().getName()+"."+leaf.getName(),1L,Long::sum);
          var seen=new HashSet<String>(); for(var f:fs) {var m=f.getMethod();String owner=m.getType().getName();
            if(owner.startsWith("com.tkisor.nekojs.")&&seen.add(owner+"."+m.getName()))frames.merge(owner+"."+m.getName(),1L,Long::sum);
          }
        }
      }
      groups.put(first==0?"all":"lastTwenty",Map.of("eventCounts",sort(events),"leaves",sort(leaves),"inclusiveNekoFrames",sort(frames),"fileIoNanos",sort(ioNanos)));
    }
    Files.writeString(Path.of(args[2]),new GsonBuilder().setPrettyPrinting().create().toJson(groups));
  }
}
'''
(output/'RootNativeAnalysis.java').write_text(analysis,encoding='utf-8')
classpath=(tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
classes=output/'classes';classes.mkdir()
commands=[('compile',[str(java/'javac.exe'),'-encoding','UTF-8','-cp',classpath,'-d',str(classes),str(output/'RootNativeAttribution.java'),str(output/'RootNativeAnalysis.java')]),
 ('run',[str(java/'java.exe'),'-cp',str(classes)+';'+classpath,'RootNativeAttribution',str(project),str(output)]),
 ('analyze',[str(java/'java.exe'),'-cp',str(classes)+';'+classpath,'RootNativeAnalysis',str(output/'root-native.jfr'),str(output/'samples.json'),str(output/'summary.json')])]
for label,command in commands:
    with (output/(label+'.log')).open('xb') as out,(output/(label+'-stderr.log')).open('xb') as err:
        result=subprocess.run(command,cwd=project,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0,label
(output/'input-binding.json').write_text(json.dumps(dict(binaryArchived=False,jfrSha256=hashlib.sha256((output/'root-native.jfr').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
result=json.loads((output/'summary.json').read_text(encoding='utf-8'))
print(json.dumps(result['lastTwenty']))
