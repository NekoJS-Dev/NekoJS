import json
import statistics
from pathlib import Path

root=Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/game-thread-qos-control-6e5bb8f0')
rows=json.loads((root/'observations.json').read_text(encoding='utf-8-sig'))
assert len(rows)==40
assert all('phase=COMMIT - no errors.' in r['response'] for r in rows)
summary=dict(diagnosticOnly=True,formalVerdictUnchanged='FAIL',allSamplesRetained=True,commands=len(rows),arms={})
for arm in ['original','high-qos']:
    chosen=[r for r in rows if r['arm']==arm]
    assert [r['pair'] for r in chosen]==list(range(1,21))
    summary['arms'][arm]={key:statistics.mean(r[key] for r in chosen) for key in ['rconMs','markerMs']}
    summary['arms'][arm]['threadCpuWindowMs']=statistics.mean(sum(r['threadAfter']['threadTimes100ns'][i]-r['threadBefore']['threadTimes100ns'][i] for i in [2,3])/1e4 for r in chosen)
summary['originalMinusHighRconPairedMs']=[sum(r['rconMs']*(1 if r['arm']=='original' else -1) for r in rows if r['pair']==pair) for pair in range(1,21)]
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
