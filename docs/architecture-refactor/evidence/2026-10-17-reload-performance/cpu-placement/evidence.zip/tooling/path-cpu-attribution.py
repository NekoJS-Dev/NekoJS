"""Attribute root reload path work using disposable shadow classes, never production edits."""
import hashlib
import json
import statistics
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
output = tools/'path-cpu-attribution'
assert not output.exists()
output.mkdir()
classpath = (tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
sources = output/'sources'
sources.mkdir()
bindings = {}

metrics = '''package diagnostic;
public final class PathCounters {
    private static final java.lang.management.ThreadMXBean CPU = java.lang.management.ManagementFactory.getThreadMXBean();
    private static final long[] counts = new long[2], wall = new long[2], cpu = new long[2], user = new long[2];
    public static long[] start() { return new long[]{System.nanoTime(), CPU.getCurrentThreadCpuTime(), CPU.getCurrentThreadUserTime()}; }
    public static void end(int bucket, long[] start) {
        wall[bucket] += System.nanoTime()-start[0]; cpu[bucket] += CPU.getCurrentThreadCpuTime()-start[1];
        user[bucket] += CPU.getCurrentThreadUserTime()-start[2]; counts[bucket]++;
    }
    public static void reset() { for (long[] a : new long[][]{counts, wall, cpu, user}) java.util.Arrays.fill(a, 0); }
    public static java.util.Map<String,Object> snapshot() {
        return java.util.Map.of("canonical", row(0), "containment", row(1));
    }
    private static java.util.Map<String,Long> row(int n) {
        return java.util.Map.of("calls",counts[n],"wallNanos",wall[n],"cpuNanos",cpu[n],"userNanos",user[n]);
    }
}
'''
(sources/'PathCounters.java').write_text(metrics, encoding='utf-8')

def instrument(relative, signature, bucket):
    file = project/relative
    original = file.read_bytes()
    text = original.decode('utf-8')
    start = text.index(signature) + len(signature)
    # These bounded methods have no braces in literals; balance their existing body.
    cursor, depth = start, 1
    while depth:
        if text[cursor] == '{': depth += 1
        if text[cursor] == '}': depth -= 1
        cursor += 1
    body = text[start:cursor-1]
    text = text[:start] + '\n        long[] diagnosticStart = diagnostic.PathCounters.start();\n        try {' + body + '\n        } finally { diagnostic.PathCounters.end('+str(bucket)+', diagnosticStart); }\n    ' + text[cursor-1:]
    target = sources/file.name
    target.write_text(text, encoding='utf-8')
    (sources/(file.stem+'.original.java')).write_bytes(original)
    bindings[relative] = dict(originalSha256=hashlib.sha256(original).hexdigest(), shadowSha256=hashlib.sha256(target.read_bytes()).hexdigest())
    return target

shadow = [instrument('common/src/main/java/com/tkisor/nekojs/core/module/NekoCanonicalPath.java', 'static Path pathOf(Path path) {', 0),
          instrument('common/src/main/java/com/tkisor/nekojs/core/fs/NekoJSPaths.java', 'private Path verifyInsideRoot(Path path, Path rt) throws IOException {', 1)]
probe = (tools/'root-cpu-split/RootCpuSplit.java').read_text(encoding='utf-8').replace('public class RootCpuSplit', 'public class PathCpuAttribution')
probe = probe.replace('                    long cpuStart =', '                    diagnostic.PathCounters.reset();\n                    long cpuStart =')
probe = probe.replace('                    samples.getLast().put("cpuNanos", cpuNanos);', '                    samples.getLast().put("pathCounters", diagnostic.PathCounters.snapshot());\n                    samples.getLast().put("cpuNanos", cpuNanos);')
(sources/'PathCpuAttribution.java').write_text(probe, encoding='utf-8')
classes = output/'classes'
classes.mkdir()
for label,command in [('compile',[str(java/'javac.exe'),'-encoding','UTF-8','-cp',classpath,'-d',str(classes),str(sources/'PathCounters.java'),*map(str,shadow),str(sources/'PathCpuAttribution.java')]),
                      ('run',[str(java/'java.exe'),'-cp',str(classes)+';'+classpath,'PathCpuAttribution',str(project),str(output)])]:
    with (output/(label+'.log')).open('xb') as out, (output/(label+'-stderr.log')).open('xb') as err:
        result = subprocess.run(command,cwd=project,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, label
rows = json.loads((output/'samples.json').read_text(encoding='utf-8'))
summary = dict(diagnosticOnly=True, instrumented=True, noMinecraftRecipesRcon=True, allSamplesRetained=True, groups={})
for label,chosen in [('all',rows),('firstTen',rows[:10]),('lastTwenty',rows[10:])]:
    group = dict(wallMs=statistics.mean(r['nanos']/1e6 for r in chosen), cpuMs=statistics.mean(r['cpuNanos']/1e6 for r in chosen))
    for category in ['canonical','containment']:
        group[category] = {key:statistics.mean(r['pathCounters'][category][key]/(1 if key=='calls' else 1e6) for r in chosen) for key in ['calls','wallNanos','cpuNanos','userNanos']}
    summary['groups'][label] = group
for relative,binding in bindings.items():
    assert hashlib.sha256((project/relative).read_bytes()).hexdigest() == binding['originalSha256']
(output/'source-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n',encoding='utf-8')
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
