"""Temporary owner-thread QoS contrast; always restore its observed original policy."""
import json
import statistics
import subprocess
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
output=tools/'root-thread-qos-control'
assert not output.exists()
output.mkdir()
policy='''import java.lang.foreign.*; import java.lang.invoke.*;
public final class OwnThreadPolicy {
  static final Linker LINKER=Linker.nativeLinker();
  static final SymbolLookup LIB=SymbolLookup.libraryLookup("kernel32",Arena.global());
  static MethodHandle fn(String name,FunctionDescriptor descriptor) {return LINKER.downcallHandle(LIB.find(name).orElseThrow(),descriptor);}
  static final MethodHandle THREAD=fn("GetCurrentThread",FunctionDescriptor.of(ValueLayout.ADDRESS));
  static final MethodHandle GET=fn("GetThreadInformation",FunctionDescriptor.of(ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.JAVA_INT));
  static final MethodHandle SET=fn("SetThreadInformation",FunctionDescriptor.of(ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.JAVA_INT));
  static MemorySegment thread() throws Throwable {return (MemorySegment)THREAD.invokeExact();}
  static int[] read() {
    try(var arena=Arena.ofConfined()) {
      var data=arena.allocate(12,4);data.set(ValueLayout.JAVA_INT,0,1);
      if((int)GET.invokeExact(thread(),3,data,12)==0)throw new AssertionError("GetThreadInformation failed");
      return new int[]{data.get(ValueLayout.JAVA_INT,0),data.get(ValueLayout.JAVA_INT,4),data.get(ValueLayout.JAVA_INT,8)};
    }catch(Throwable e){throw new AssertionError(e);}
  }
  static void write(int[] state) {
    try(var arena=Arena.ofConfined()) {
      var data=arena.allocate(12,4);for(int i=0;i<3;i++)data.set(ValueLayout.JAVA_INT,i*4L,state[i]);
      if((int)SET.invokeExact(thread(),3,data,12)==0)throw new AssertionError("SetThreadInformation failed");
      if(!java.util.Arrays.equals(state,read()))throw new AssertionError("Thread policy readback mismatch");
    }catch(Throwable e){throw new AssertionError(e);}
  }
}
'''
(output/'OwnThreadPolicy.java').write_text(policy,encoding='utf-8')
source=(tools/'root-cpu-placement/RootCpuPlacement.java').read_text(encoding='utf-8').replace('public class RootCpuPlacement','public class RootThreadQosControl')
source=source.replace('                for (int index = 0; index < 30; index++) {', '''                int[] originalPolicy = OwnThreadPolicy.read();
                Files.writeString(output.resolve("original-policy.json"), new Gson().toJson(originalPolicy));
                try {
                for (int index = 0; index < 50; index++) {
                    int pair = index < 10 ? -1 : (index-10)/2;
                    boolean high = index >= 10 && ((index-10)%2 == (pair%2 == 0 ? 1 : 0));
                    int[] chosenPolicy = high ? new int[]{originalPolicy[0],originalPolicy[1]|1,originalPolicy[2]&~1} : originalPolicy;
                    OwnThreadPolicy.write(chosenPolicy);''')
source=source.replace('                    int processorAfter = processor();', '                    int processorAfter = processor();\n                    OwnThreadPolicy.write(originalPolicy);')
source=source.replace('                    samples.getLast().put("processorBefore", processorBefore);', '''                    samples.getLast().put("pair", pair);
                    samples.getLast().put("arm", index < 10 ? "warmup-original" : high ? "high-qos" : "original");
                    samples.getLast().put("policyDuringReload", chosenPolicy);
                    samples.getLast().put("processorBefore", processorBefore);''')
source=source.replace('                }\n            }\n\n        }', '''                }
                } finally {
                    OwnThreadPolicy.write(originalPolicy);
                    Files.writeString(output.resolve("restored-policy.json"), new Gson().toJson(OwnThreadPolicy.read()));
                }
            }

        }''')
assert 'finally {' in source and 'index < 50' in source
(output/'RootThreadQosControl.java').write_text(source,encoding='utf-8')
classpath=(tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
classes=output/'classes';classes.mkdir()
commands=[('compile',[str(java/'javac.exe'),'-encoding','UTF-8','-cp',classpath,'-d',str(classes),str(output/'RootThreadQosControl.java'),str(output/'OwnThreadPolicy.java')]),
          ('run',[str(java/'java.exe'),'--enable-native-access=ALL-UNNAMED','-cp',str(classes)+';'+classpath,'RootThreadQosControl',str(project),str(output)])]
for label,command in commands:
    with (output/(label+'.log')).open('xb') as out,(output/(label+'-stderr.log')).open('xb') as err:
        result=subprocess.run(command,cwd=project,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0,label
rows=json.loads((output/'samples.json').read_text(encoding='utf-8'))
original=json.loads((output/'original-policy.json').read_text(encoding='utf-8'))
restored=json.loads((output/'restored-policy.json').read_text(encoding='utf-8'))
assert original==restored
summary=dict(diagnosticOnly=True,allSamplesRetained=True,initialSamples=10,pairedSamples=40,originalPolicy=original,restoredPolicy=restored,arms={})
for arm in ['warmup-original','original','high-qos']:
    chosen=[r for r in rows if r['arm']==arm]
    summary['arms'][arm]=dict(samples=len(chosen),wallMs=statistics.mean(r['nanos']/1e6 for r in chosen),cpuMs=statistics.mean(r['cpuNanos']/1e6 for r in chosen),
        beforeProcessors=sorted(set(r['processorBefore'] for r in chosen)),afterProcessors=sorted(set(r['processorAfter'] for r in chosen)))
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
