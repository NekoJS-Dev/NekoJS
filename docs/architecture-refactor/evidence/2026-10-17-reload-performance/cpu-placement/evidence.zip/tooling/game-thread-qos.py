"""Query/control one diagnostic server thread; reject thread-ID reuse and restore its original policy."""
import ctypes
from ctypes import wintypes
import json
import re
import subprocess
import sys
from pathlib import Path

mode, directory = sys.argv[1:3]
output=Path(directory)
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
class State(ctypes.Structure):
    _fields_=[('version',wintypes.ULONG),('control',wintypes.ULONG),('state',wintypes.ULONG)]
kernel.OpenThread.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
kernel.OpenThread.restype=wintypes.HANDLE
kernel.GetThreadInformation.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD]
kernel.SetThreadInformation.argtypes=kernel.GetThreadInformation.argtypes
kernel.GetThreadTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)]
kernel.GetProcessIdOfThread.argtypes=[wintypes.HANDLE]
kernel.GetProcessIdOfThread.restype=wintypes.DWORD
kernel.CloseHandle.argtypes=[wintypes.HANDLE]

def check(value,label):
    if not value: raise RuntimeError(f'{label} failed: Windows error {ctypes.get_last_error()}')

def times(handle):
    values=[wintypes.FILETIME() for _ in range(4)]
    check(kernel.GetThreadTimes(handle,*[ctypes.byref(v) for v in values]),'GetThreadTimes')
    return [v.dwLowDateTime+(v.dwHighDateTime<<32) for v in values]

def read(handle):
    state=State(1,0,0)
    check(kernel.GetThreadInformation(handle,3,ctypes.byref(state),ctypes.sizeof(state)),'GetThreadInformation')
    return [state.version,state.control,state.state]

bindingfile=output/'thread-policy-binding.json'
if mode=='init':
    assert not bindingfile.exists()
    pid=int(sys.argv[3])
    dump=subprocess.run(['C:/Program Files/Java/jdk-25.0.2/bin/jcmd.exe',str(pid),'Thread.print','-e'],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
    (output/'initial-thread-dump.txt').write_bytes(dump.stdout)
    (output/'initial-thread-dump-stderr.txt').write_bytes(dump.stderr)
    assert dump.returncode==0
    text=dump.stdout.decode('utf-8',errors='replace')
    match=re.search(r'^"Server thread"[^\r\n]*\bnid=(0x[0-9a-fA-F]+|\d+)\b',text,re.M)
    assert match, 'Server thread native ID missing'
    tid=int(match[1],16 if match[1].startswith('0x') else 10)
else:
    binding=json.loads(bindingfile.read_text(encoding='utf-8'))
    pid,tid=binding['processId'],binding['threadId']
handle=kernel.OpenThread(0x60,False,tid)
check(handle,'OpenThread')
try:
    assert kernel.GetProcessIdOfThread(handle)==pid, 'Thread no longer belongs to diagnostic game'
    counters=times(handle)
    if mode=='init':
        binding=dict(processId=pid,threadId=tid,createdAt=counters[0],originalPolicy=read(handle),changesRestrictedTo='diagnostic server owner thread')
        bindingfile.write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(binding))
    else:
        assert counters[0]==binding['createdAt'], 'Native thread ID reused'
        if mode in ['original','high-qos','restore']:
            target=list(binding['originalPolicy'])
            if mode=='high-qos': target[1]|=1;target[2]&=~1
            state=State(*target)
            check(kernel.SetThreadInformation(handle,3,ctypes.byref(state),ctypes.sizeof(state)),'SetThreadInformation')
            assert read(handle)==target
        elif mode!='read': raise ValueError(mode)
        result=dict(mode=mode,policy=read(handle),threadTimes100ns=times(handle))
        if mode=='restore': (output/'restored-thread-policy.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(result))
finally:
    check(kernel.CloseHandle(handle),'CloseHandle')
