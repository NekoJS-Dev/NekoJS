
import java.nio.file.*; import java.time.*; import java.util.*;
import jdk.jfr.consumer.*; import com.google.gson.*;
public class RootNativeAnalysis {
  static Map<String,Long> sort(Map<String,Long> map) {
    var result = new LinkedHashMap<String,Long>();
    map.entrySet().stream().sorted(Map.Entry.<String,Long>comparingByValue().reversed()).limit(60).forEach(e->result.put(e.getKey(),e.getValue())); return result;
  }
  public static void main(String[] args) throws Exception {
    var samples = JsonParser.parseString(Files.readString(Path.of(args[1]))).getAsJsonArray();
    var groups = new LinkedHashMap<String,Object>();
    for (int first : new int[]{0,10}) {
      Map<String,Long> leaves=new HashMap<>(), events=new HashMap<>(), ioNanos=new HashMap<>(), frames=new HashMap<>();
      try (var file = new RecordingFile(Path.of(args[0]))) {
        while (file.hasMoreEvents()) {
          var e=file.readEvent(); boolean inside=false;
          for (int i=first;i<samples.size();i++) { var r=samples.get(i).getAsJsonObject();
            if (!e.getStartTime().isBefore(Instant.parse(r.get("epochStart").getAsString())) && !e.getStartTime().isAfter(Instant.parse(r.get("epochEnd").getAsString()))) {inside=true;break;}
          }
          if (!inside) continue; String name=e.getEventType().getName();
          if (name.equals("jdk.FileRead")||name.equals("jdk.FileWrite")) {
            var thread=e.getThread(); if(thread==null||!thread.getJavaName().equals("main"))continue;
            ioNanos.merge(name+":"+e.getString("path"),e.getDuration().toNanos(),Long::sum); events.merge(name,1L,Long::sum);
          }
          if (!name.equals("jdk.ExecutionSample")&&!name.equals("jdk.NativeMethodSample"))continue;
          var t=e.getThread("sampledThread"); if(t==null||!t.getJavaName().equals("main")||e.getStackTrace()==null)continue;
          events.merge(name,1L,Long::sum);var fs=e.getStackTrace().getFrames();if(fs.isEmpty())continue;
          var leaf=fs.getFirst().getMethod(); leaves.merge(name+":"+leaf.getType().getName()+"."+leaf.getName(),1L,Long::sum);
          var seen=new HashSet<String>(); for(var f:fs) {var m=f.getMethod();String owner=m.getType().getName();
            if(owner.startsWith("com.tkisor.nekojs.")&&seen.add(owner+"."+m.getName()))frames.merge(owner+"."+m.getName(),1L,Long::sum);
          }
        }
      }
      groups.put(first==0?"all":"lastTwenty",Map.of("eventCounts",sort(events),"leaves",sort(leaves),"inclusiveNekoFrames",sort(frames),"fileIoNanos",sort(ioNanos)));
    }
    Files.writeString(Path.of(args[2]),new GsonBuilder().setPrettyPrinting().create().toJson(groups));
  }
}
