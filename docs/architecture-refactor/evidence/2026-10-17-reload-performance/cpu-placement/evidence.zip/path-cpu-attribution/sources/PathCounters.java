package diagnostic;
public final class PathCounters {
    private static final java.lang.management.ThreadMXBean CPU = java.lang.management.ManagementFactory.getThreadMXBean();
    private static final long[] counts = new long[2], wall = new long[2], cpu = new long[2], user = new long[2];
    public static long[] start() { return new long[]{System.nanoTime(), CPU.getCurrentThreadCpuTime(), CPU.getCurrentThreadUserTime()}; }
    public static void end(int bucket, long[] start) {
        wall[bucket] += System.nanoTime()-start[0]; cpu[bucket] += CPU.getCurrentThreadCpuTime()-start[1];
        user[bucket] += CPU.getCurrentThreadUserTime()-start[2]; counts[bucket]++;
    }
    public static void reset() { for (long[] a : new long[][]{counts, wall, cpu, user}) java.util.Arrays.fill(a, 0); }
    public static java.util.Map<String,Object> snapshot() {
        return java.util.Map.of("canonical", row(0), "containment", row(1));
    }
    private static java.util.Map<String,Long> row(int n) {
        return java.util.Map.of("calls",counts[n],"wallNanos",wall[n],"cpuNanos",cpu[n],"userNanos",user[n]);
    }
}
