import java.lang.foreign.*; import java.lang.invoke.*;
public final class OwnThreadPolicy {
  static final Linker LINKER=Linker.nativeLinker();
  static final SymbolLookup LIB=SymbolLookup.libraryLookup("kernel32",Arena.global());
  static MethodHandle fn(String name,FunctionDescriptor descriptor) {return LINKER.downcallHandle(LIB.find(name).orElseThrow(),descriptor);}
  static final MethodHandle THREAD=fn("GetCurrentThread",FunctionDescriptor.of(ValueLayout.ADDRESS));
  static final MethodHandle GET=fn("GetThreadInformation",FunctionDescriptor.of(ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.JAVA_INT));
  static final MethodHandle SET=fn("SetThreadInformation",FunctionDescriptor.of(ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.JAVA_INT));
  static MemorySegment thread() throws Throwable {return (MemorySegment)THREAD.invokeExact();}
  static int[] read() {
    try(var arena=Arena.ofConfined()) {
      var data=arena.allocate(12,4);data.set(ValueLayout.JAVA_INT,0,1);
      if((int)GET.invokeExact(thread(),3,data,12)==0)throw new AssertionError("GetThreadInformation failed");
      return new int[]{data.get(ValueLayout.JAVA_INT,0),data.get(ValueLayout.JAVA_INT,4),data.get(ValueLayout.JAVA_INT,8)};
    }catch(Throwable e){throw new AssertionError(e);}
  }
  static void write(int[] state) {
    try(var arena=Arena.ofConfined()) {
      var data=arena.allocate(12,4);for(int i=0;i<3;i++)data.set(ValueLayout.JAVA_INT,i*4L,state[i]);
      if((int)SET.invokeExact(thread(),3,data,12)==0)throw new AssertionError("SetThreadInformation failed");
      if(!java.util.Arrays.equals(state,read()))throw new AssertionError("Thread policy readback mismatch");
    }catch(Throwable e){throw new AssertionError(e);}
  }
}
