import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.api.event.EventGroup;
import com.tkisor.nekojs.api.plugin.IPluginRuntime;
import com.tkisor.nekojs.core.*;
import com.tkisor.nekojs.core.compiler.ScriptCompilerRegistry;
import com.tkisor.nekojs.core.config.SandboxConfig;
import com.tkisor.nekojs.core.error.DefaultErrorTracker;
import com.tkisor.nekojs.core.fs.*;
import com.tkisor.nekojs.core.lifecycle.NekoRuntimeRoot;
import com.tkisor.nekojs.core.pack.ScriptPackRegistry;
import com.tkisor.nekojs.script.prop.*;
import com.tkisor.nekojs.testfixture.*;
import graal.graalvm.polyglot.*;
import com.google.gson.Gson;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import jdk.jfr.*;

public class RootCpuSplit {
    static Map<String, EventGroup> groups() {
        Map<String, EventGroup> groups = new LinkedHashMap<>();
        for (var entry : Map.of("ServerEvents", List.of("started", "tagsUpdated", "tickPre", "stopped"),
                "PlayerEvents", List.of("loggedIn"), "LevelEvents", List.of("loaded"),
                "Perf02Bench", List.of("adapterRun")).entrySet()) {
            EventGroup group = EventGroup.of(entry.getKey());
            for (String name : entry.getValue()) group.server(name, Object.class);
            groups.put(entry.getKey(), group);
        }
        return groups;
    }
    public static void main(String[] arguments) throws Exception {
        Path project = Path.of(arguments[0]);
        Path output = Path.of(arguments[1]);
        Path game = output.resolve("game");
        TestPlatformInit.ensureInitialized(game);
        var paths = NekoJSPaths.fromGameDir(game);
        Field instance = NekoJSPaths.class.getDeclaredField("INSTANCE");
        instance.setAccessible(true); instance.set(null, paths);
        Path fixtures = project.resolve("bench/perf/fixtures/nekojs/server_scripts");
        Map<String, String> hashes = new TreeMap<>();
        try (var stream = Files.walk(fixtures)) {
            for (Path file : stream.filter(Files::isRegularFile).toList()) {
                Path target = paths.root().resolve("server_scripts").resolve(fixtures.relativize(file));
                Files.createDirectories(target.getParent()); Files.copy(file, target);
                if (!Arrays.equals(Files.readAllBytes(file), Files.readAllBytes(target))) throw new AssertionError(file);
            }
        }
        if (Files.exists(paths.root().resolve("perf-out/RUN_BENCH"))) throw new AssertionError("Unexpected benchmark mode");
        ScriptPackRegistry.get().deactivateWorldPacks(); ScriptPackRegistry.get().refreshGlobalPacks();
        Map<String, EventGroup> groups = groups();
        IPluginRuntime plugins = (IPluginRuntime) Proxy.newProxyInstance(IPluginRuntime.class.getClassLoader(), new Class<?>[]{IPluginRuntime.class},
                (proxy, method, args) -> {
                    if (method.getName().equals("eventGroups")) return groups;
                    if (method.getReturnType() == Map.class) return Map.of();
                    if (method.getReturnType() == List.class) return List.of();
                    return null;
                });
        var config = SandboxConfig.defaultConfig();
        var compilers = ScriptCompilerRegistry.createRuntimeRegistry();
        var tracker = new DefaultErrorTracker(paths, config);
        List<Map<String, Object>> samples = new ArrayList<>();
        var cpu = java.lang.management.ManagementFactory.getThreadMXBean();
        if (!cpu.isCurrentThreadCpuTimeSupported() || !cpu.isThreadCpuTimeEnabled()) throw new AssertionError("CPU counters unavailable");
        cpu.getCurrentThreadCpuTime(); cpu.getCurrentThreadUserTime();
        try (Engine engine = Engine.newBuilder().option("engine.WarnInterpreterOnly", "false").build();
                Recording recording = new Recording(Configuration.getConfiguration("profile"))) {


            var core = new NekoCoreContext(engine, config, new ClassFilter(config), tracker);
            var cache = NekoModuleTestFixtures.newCache(paths, compilers, config);
            var sandbox = new NekoSandboxFactory(core, paths, compilers, plugins, cache);
            var properties = new ScriptPropertyRegistry.Impl();
            properties.register(ScriptProperty.AFTER); properties.register(ScriptProperty.MODLOADED);
            properties.register(ScriptProperty.DISABLE); properties.register(ScriptProperty.PRIORITY); properties.freeze();
            var bridge = new DefaultScriptEventBridge(null); bridge.setPluginRuntime(plugins);
            try (var root = new NekoRuntimeRoot(core, plugins, bridge, properties, sandbox, cache)) {
                var manager = root.createScriptManager(ScriptType.SERVER);
                manager.discoverScripts();
                
                Context previous = null;
                for (int index = 0; index < 30; index++) {
                    String epochStart = java.time.Instant.now().toString(); long start = System.nanoTime();
                    long cpuStart = cpu.getCurrentThreadCpuTime();
                    long userStart = cpu.getCurrentThreadUserTime();
                    var result = root.reload(ScriptType.SERVER);
                    long cpuNanos = cpu.getCurrentThreadCpuTime()-cpuStart;
                    long userNanos = cpu.getCurrentThreadUserTime()-userStart;
                    long nanos = System.nanoTime() - start;
                    if (!result.success() || !result.phase().name().equals("COMMIT") || root.errors().count() != 0)
                        throw new AssertionError(result + " errors=" + root.errors());
                    Context current = manager.activeContextForPackOwner();
                    if (current == null || current == previous) throw new AssertionError("Context not replaced");
                    if (previous != null) {
                        boolean closed = false;
                        try { previous.eval("js", "1"); } catch (IllegalStateException expected) { closed = true; }
                        if (!closed) throw new AssertionError("Old Context remains usable");
                    }
                    if (cache.preparedEntryCount() != 6) throw new AssertionError("Expected six prepared entries: " + cache.preparedEntryCount());
                    previous = current;
                    samples.add(Map.of("index", index, "epochStart", epochStart, "epochEnd", java.time.Instant.now().toString(), "nanos", nanos, "generation", result.generation(), "contextReplaced", true,
                            "oldContextClosed", index > 0, "preparedEntries", cache.preparedEntryCount()));
                    samples.set(samples.size()-1, new LinkedHashMap<>(samples.getLast()));
                    samples.getLast().put("cpuNanos", cpuNanos);
                    samples.getLast().put("userNanos", userNanos);
                }
            }

        }
        Files.writeString(output.resolve("samples.json"), new Gson().toJson(samples));
    }
}
