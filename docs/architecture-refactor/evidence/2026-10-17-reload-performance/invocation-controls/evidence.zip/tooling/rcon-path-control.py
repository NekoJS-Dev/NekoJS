import hashlib
import json
import os
import secrets
import socket
import statistics
import struct
import subprocess
import threading
import time
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
output = tools/'rcon-path-control'
output.mkdir(exist_ok=False)
assert hashlib.sha256((project/'bench/perf/rcon.py').read_bytes()).hexdigest() == hashlib.sha256(Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/bench/perf/rcon.py').read_bytes()).hexdigest()
password = secrets.token_hex(16)
listener = socket.socket()
listener.bind(('127.0.0.1', 0))
listener.listen()
listener.settimeout(1)
stopping = threading.Event()
connections = []
failures = []


def exact(stream, count):
    data = b''
    while len(data) < count:
        part = stream.recv(count-len(data))
        if not part:
            raise RuntimeError('Control packet truncated')
        data += part
    return data


def receive(stream):
    size, = struct.unpack('<i', exact(stream, 4))
    assert 10 <= size <= 4096
    data = exact(stream, size)
    request, kind = struct.unpack('<ii', data[:8])
    assert data[-2:] == b'\0\0'
    return request, kind, data[8:-2].decode('ascii')


def send(stream, request, kind, text):
    body = struct.pack('<ii', request, kind)+text.encode('ascii')+b'\0\0'
    stream.sendall(struct.pack('<i', len(body))+body)


def serve():
    while not stopping.is_set():
        try:
            stream, _ = listener.accept()
        except socket.timeout:
            continue
        try:
            with stream:
                stream.settimeout(10)
                start = time.perf_counter_ns()
                request, kind, text = receive(stream)
                assert kind == 3 and text == password
                send(stream, request, 2, '')
                request, kind, text = receive(stream)
                assert kind == 2 and text == 'list'
                send(stream, request, 0, 'control-ok')
                connections.append(dict(index=len(connections)+1, serviceMs=(time.perf_counter_ns()-start)/1e6))
        except Exception as failure:
            failures.append(type(failure).__name__)


thread = threading.Thread(target=serve, daemon=True)
thread.start()
environment = dict(os.environ, NEKO_CONTROL_PORT=str(listener.getsockname()[1]),
                   NEKO_CONTROL_PASSWORD=password, NEKO_CONTROL_OUTPUT=str(output))
environment['PSModulePath'] = 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules;C:/Program Files/WindowsPowerShell/Modules'
try:
    result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                             str(tools/'rcon-path-control.ps1')],
                            cwd=project, env=environment, capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
finally:
    stopping.set()
    thread.join(2)
    listener.close()
assert not thread.is_alive()
for name, raw in [('stdout.log', result.stdout), ('stderr.log', result.stderr)]:
    (output/name).write_bytes(raw.replace(password.encode(), b'<REDACTED-CONTROL-CREDENTIAL>'))
(output/'server.json').write_text(json.dumps(dict(connections=connections, failures=failures), indent=2)+'\n')
assert result.returncode == 0 and not failures and len(connections) == 80
observations = json.loads((output/'observations.json').read_text(encoding='utf-8-sig'))
rows = observations['rows']
assert len(rows) == 80 and all(row['response'] == 'control-ok' for row in rows)
summary = dict(diagnosticOnly=True, noGame=True, commands=80,
    sourceHashes={path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in [
        project/'bench/perf/rcon.py', project/'bench/perf/sample.ps1']},
    meanMs={arm: statistics.mean(row['elapsedMs'] for row in rows if row['arm'] == arm) for arm in ['native-d', 'direct-d', 'native-c', 'direct-c']},
    meanServerServiceMs=statistics.mean(row['serviceMs'] for row in connections))
(output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary))
