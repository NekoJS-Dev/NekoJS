import hashlib
import json
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
target = project/'docs/architecture-refactor/evidence/2026-10-17-reload-performance/invocation-controls'
files = {}
for label, directory in [('failed-native-direct', 'rcon-invocation-control'),
                         ('native-direct', 'rcon-invocation-control-v2'), ('client-path', 'rcon-path-control'),
                         ('gradle', 'gradle-output-chain')]:
    for file in sorted((tools/directory).iterdir()):
        if file.is_file(): files[label+'/'+file.name] = file.read_bytes()
for name in ['rcon-invocation-control.py', 'rcon-invocation-control.ps1', 'rcon-path-control.py',
             'rcon-path-control.ps1', 'prepare-rcon-path-control.py', 'record-gradle-output-chain.py',
             'seal-invocation-controls.py']:
    files['tooling/'+name] = (tools/name).read_bytes()
files['tooling/original-rcon.py'] = (project/'bench/perf/rcon.py').read_bytes()
properties = dict(line.split('=', 1) for line in Path(
    'C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run/server.properties'
).read_text().splitlines() if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password'].encode()
redactions = {}
for name, data in list(files.items()):
    if secret in data:
        redactions[name] = dict(originalSha256=hashlib.sha256(data).hexdigest(), occurrences=data.count(secret))
        files[name] = data.replace(secret, b'<REDACTED-RCON-CREDENTIAL>')
assert not any(secret in data for data in files.values())
files['redactions.json'] = (json.dumps(redactions, indent=2)+'\n').encode()
packed = target/'evidence.zip'
assert not packed.exists()
with zipfile.ZipFile(packed, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()): archive.writestr(name, data)
manifest = dict(diagnosticOnly=True, archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
    entries={name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(entries=len(files), zipBytes=packed.stat().st_size, archiveSha256=manifest['archiveSha256'])))
