import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

tools = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout')
output = tools/'gradle-output-chain'
output.mkdir(exist_ok=False)
root = Path('D:/mcmodDemo/NekoJS/.gradle-<REDACTED-RCON-CREDENTIAL>/wrapper/dists/gradle-9.6.0-bin/42k10rwplmzkhuboz9kdazi7s/gradle-9.6.0/lib')
classes = {
    'org.gradle.launcher.daemon.server.exec.LogToClient$AsynchronousLogDispatcher': 'gradle-launcher-9.6.0.jar',
    'org.gradle.internal.logging.console.ThrottlingOutputEventListener': 'gradle-logging-9.6.0.jar',
    'org.gradle.internal.logging.sink.OutputEventRenderer': 'gradle-logging-9.6.0.jar',
    'org.gradle.internal.logging.events.UpdateNowEvent': 'gradle-logging-9.6.0.jar',
}
records = []
for name, jar_name in classes.items():
    jar = root/jar_name
    result = subprocess.run(['C:/Program Files/Java/jdk-25.0.2/bin/javap.exe', '-classpath', str(jar),
                             '-c', '-p', name], capture_output=True, text=True)
    assert result.returncode == 0
    text = result.stdout
    if name.endswith('OutputEventRenderer'):
        text = '\n'.join(section for section in re.split(r'(?=\n  (?:public|private|protected) )', text)
                         if any(method in section.split('Code:')[0] for method in ['addPlainConsole', 'throttled(']))
    filename = name.rsplit('.', 1)[1]+'.txt'
    (output/filename).write_text(text)
    with zipfile.ZipFile(jar) as archive:
        data = archive.read(name.replace('.', '/')+'.class')
    records.append(dict(className=name, jar=jar_name, jarSha256=hashlib.sha256(jar.read_bytes()).hexdigest(),
                        classSha256=hashlib.sha256(data).hexdigest(), output=filename))
(output/'manifest.json').write_text(json.dumps(dict(staticBytecodeInspection=True, gradleVersion='9.6.0',
    noRuntimeConfigurationChanged=True, records=records), indent=2)+'\n')
print(json.dumps(dict(classes=len(records), runtimeConfigurationChanged=False)))
