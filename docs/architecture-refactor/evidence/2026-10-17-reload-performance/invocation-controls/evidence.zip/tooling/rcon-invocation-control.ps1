$ErrorActionPreference = 'Stop'
$sampleDirectory = 'D:/mcmodDemo/NekoJS-mult/bench/perf'
$samplePath = Join-Path $sampleDirectory 'sample.ps1'
$parseTokens = $null
$parseErrors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($samplePath, [ref]$parseTokens, [ref]$parseErrors)
if ($parseErrors.Count -ne 0) { throw 'Sampler parse failed' }
$definition = $ast.FindAll({ param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Invoke-Rcon' }, $false)
if ($definition.Count -ne 1) { throw 'Original RCON function missing or ambiguous' }
. ([ScriptBlock]::Create($definition[0].Extent.Text.Replace('$PSScriptRoot', "'$sampleDirectory'")))
$RconPort = [int]$env:NEKO_CONTROL_PORT
$RconPass = $env:NEKO_CONTROL_PASSWORD
$pythonPath = (Get-Command python -CommandType Application | Select-Object -First 1).Source

function Invoke-DirectClient {
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $pythonPath
    $info.Arguments = '"' + (Join-Path $sampleDirectory 'rcon.py') + '" ' + $RconPort + ' ' + $RconPass + ' 180 list'
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $process = [System.Diagnostics.Process]::Start($info)
    try {
        $response = $process.StandardOutput.ReadToEnd()
        $failure = $process.StandardError.ReadToEnd()
        $process.WaitForExit()
        if ($process.ExitCode -ne 0 -or $failure.Length -ne 0) { throw 'Control client failed' }
        return $response.Trim()
    } finally { $process.Dispose() }
}

$rows = @()
for ($pair = 1; $pair -le 20; $pair++) {
    $order = if ($pair % 2 -eq 1) { @('native', 'direct') } else { @('direct', 'native') }
    foreach ($arm in $order) {
        Start-Sleep -Milliseconds 100
        $timer = [Diagnostics.Stopwatch]::StartNew()
        $response = if ($arm -eq 'native') { Invoke-Rcon -Command 'list' } else { Invoke-DirectClient }
        $elapsed = $timer.Elapsed.TotalMilliseconds
        if ($response -ne 'control-ok') { throw 'Control response mismatch' }
        $rows += @{pair=$pair;arm=$arm;elapsedMs=$elapsed;response=$response}
    }
}
@{diagnosticOnly=$true;noGame=$true;pythonPath=$pythonPath;powerShellVersion=$PSVersionTable.PSVersion.ToString();rows=$rows} |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $env:NEKO_CONTROL_OUTPUT 'observations.json') -Encoding UTF8
