import json
import statistics
from pathlib import Path

root = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/real-rcon-invocation-control-6e5bb8f0')
rows = json.loads((root/'observations.json').read_text(encoding='utf-8-sig'))
assert len(rows) == 40
assert all('phase=COMMIT - no errors.' in row['response'] for row in rows)
result = dict(diagnosticOnly=True, commands=len(rows), groups={})
for arm in ['native', 'direct']:
    selected = [row for row in rows if row['arm'] == arm]
    assert [row['pair'] for row in selected] == list(range(1, 21))
    result['groups'][arm] = dict(rconMs=statistics.mean(row['rconMs'] for row in selected),
                              markerMs=statistics.mean(row['markerMs'] for row in selected))
result['nativeMinusDirectRconPairedMs'] = [
    sum(row['rconMs'] * (1 if row['arm'] == 'native' else -1) for row in rows if row['pair'] == pair)
    for pair in range(1, 21)]
(root/'summary.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
