import hashlib
import json
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
control = tools/'real-rcon-invocation-control-6e5bb8f0'
target = project/'docs/architecture-refactor/evidence/2026-10-17-reload-performance/real-invocation-control'
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
properties = dict(line.split('=', 1) for line in (worktree/'versions/26.1.2/run/server.properties').read_text().splitlines()
                  if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password'].encode()
files, redactions = {}, {}


def add(file, name):
    data = file.read_bytes()
    assert name not in files
    if secret in data:
        redactions[name] = dict(originalSha256=hashlib.sha256(data).hexdigest(), occurrences=data.count(secret))
        data = data.replace(secret, b'<REDACTED-RCON-CREDENTIAL>')
    files[name] = data


for file in control.iterdir():
    if file.is_file(): add(file, 'control/'+file.name)
for name in ['real-rcon-invocation-control.ps1', 'run-real-rcon-control.py', 'real-rcon-control-bindings.json',
             'real-rcon-control-controller.log', 'real-rcon-control-controller-stderr.log', 'real-rcon-control-exit.json',
             'analyze-real-rcon-control.py', 'seal-real-rcon-control.py']:
    add(tools/name, 'tooling/'+name)
add(tools/'candidate-6e5bb8f0-formal/preparation.json', 'formal-preparation.json')
for name in ['sample.ps1', 'rcon.py']:
    add(worktree/'bench/perf'/name, 'fixed-harness/'+name)
files['redactions.json'] = (json.dumps(redactions, indent=2)+'\n').encode()
target.mkdir(exist_ok=True)
packed = target/'evidence.zip'
assert not packed.exists()
with zipfile.ZipFile(packed, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()): archive.writestr(name, data)
manifest = dict(diagnosticOnly=True, archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
                entries={name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(entries=len(files), zipBytes=packed.stat().st_size, archiveSha256=manifest['archiveSha256'])))
