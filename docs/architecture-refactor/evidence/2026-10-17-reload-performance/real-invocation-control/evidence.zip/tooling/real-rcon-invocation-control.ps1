$ErrorActionPreference = 'Stop'
$env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
$ProjectDir = 'C:\Users\11515\.codex\worktrees\domain-perf-0965\NekoJS-mult'
$OutDir = 'D:\mcmodDemo\NekoJS-mult\build\priority-closeout\real-rcon-invocation-control-6e5bb8f0'
$javaRoot = 'C:\Program Files\Java\jdk-25.0.2'
$env:JAVA_HOME = $javaRoot
$env:PATH = "$javaRoot\bin;$env:PATH"
$GradleUserHome = 'D:\mcmodDemo\NekoJS\.gradle-<REDACTED-RCON-CREDENTIAL>'
$Node = '26.1.2'
$ServerPort = 25871
$RconPort = 25872
$RconPass = $env:NEKO_PERF_RCON_PASS
$RunDir = Join-Path $ProjectDir 'versions\26.1.2\run'
$sampleDirectory = Join-Path $ProjectDir 'bench\perf'
$FixtureDir = Join-Path $sampleDirectory 'fixtures\nekojs'
$perfOut = Join-Path $RunDir 'nekojs\perf-out'
$GitRev = '6e5bb8f0'
$script:StdinOk = $null
$script:TestStdin = $false
$script:ReloadMarker = 'PERF02-SERVER tick-bench load'
if (Test-Path -LiteralPath $OutDir) { throw 'Diagnostic output already exists' }
if ((& git -C $ProjectDir rev-parse HEAD).Trim() -ne '6e5bb8f00c3747b828056589853cb0471477b18a') { throw 'Source mismatch' }
if (@(& git -C $ProjectDir status --porcelain).Count -ne 0) { throw 'Owned source is not clean' }
if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 25871,25872).Count) { throw 'Diagnostic ports occupied' }
foreach ($target in @($RunDir, (Join-Path $RunDir 'nekojs'), (Join-Path $RunDir '.neko_probe'), (Join-Path $RunDir 'world'))) {
    if (-not [IO.Path]::GetFullPath($target).StartsWith([IO.Path]::GetFullPath($RunDir), [StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside owned run directory' }
    if (Test-Path -LiteralPath $target) {
        $items = @((Get-Item -LiteralPath $target -Force)) + @(Get-ChildItem -LiteralPath $target -Recurse -Force)
        if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Reparse point on owned run path' }
    }
}
$ancestor = Get-Item -LiteralPath $RunDir
while ($ancestor) {
    if ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point on run ancestor' }
    $ancestor = $ancestor.Parent
}
$parseTokens = $null
$parseErrors = $null
$sampleAst = [Management.Automation.Language.Parser]::ParseFile((Join-Path $sampleDirectory 'sample.ps1'), [ref]$parseTokens, [ref]$parseErrors)
if ($parseErrors.Count) { throw 'Sampler parse failed' }
foreach ($definition in $sampleAst.FindAll({ param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] }, $false)) {
    . ([ScriptBlock]::Create($definition.Extent.Text.Replace('$PSScriptRoot', "'$sampleDirectory'")))
}
function Invoke-DirectRcon {
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = (Get-Command python -CommandType Application | Select-Object -First 1).Source
    $info.Arguments = '"' + (Join-Path $sampleDirectory 'rcon.py') + '" ' + $RconPort + ' "' + $RconPass + '" 180 "nekojs reload"'
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $client = [Diagnostics.Process]::Start($info)
    try {
        $response = $client.StandardOutput.ReadToEnd()
        $failure = $client.StandardError.ReadToEnd()
        $client.WaitForExit()
        if ($client.ExitCode -ne 0 -or $failure) { throw 'Direct RCON control failed' }
        return $response.Trim()
    } finally { $client.Dispose() }
}
New-Item -ItemType Directory -Path $OutDir | Out-Null
Write-EnvSnapshot
Deploy-Fixtures -Bench:$false
$session = Invoke-ServerSession -Tag 'invocation-control' -OnDone {
    param($proc, $outLog, $sw)
    $offset = (Get-Item -LiteralPath $outLog).Length
    $rows = @()
    try {
        for ($pair = 1; $pair -le 20; $pair++) {
            $order = if ($pair % 2 -eq 1) { @('native', 'direct') } else { @('direct', 'native') }
            foreach ($arm in $order) {
                Start-Sleep -Seconds 3
                [void](Read-LogTailUtf8 $outLog ([ref]$offset))
                $startedUtc = [DateTime]::UtcNow.ToString('o')
                $timer = [Diagnostics.Stopwatch]::StartNew()
                $response = if ($arm -eq 'native') { Invoke-Rcon -Command 'nekojs reload' } else { Invoke-DirectRcon }
                $rconMs = $timer.Elapsed.TotalMilliseconds
                if ($response -notmatch 'phase=COMMIT - no errors\.') { throw 'Reload control did not commit' }
                $markerMs = $null
                $deadline = [DateTime]::UtcNow.AddSeconds(10)
                while ([DateTime]::UtcNow -lt $deadline) {
                    $chunk = Read-LogTailUtf8 $outLog ([ref]$offset)
                    if ($chunk.Contains($script:ReloadMarker)) { $markerMs = $timer.Elapsed.TotalMilliseconds; break }
                    Start-Sleep -Milliseconds 100
                }
                if ($null -eq $markerMs) { throw 'Reload control marker missing' }
                $rows += @{pair=$pair;arm=$arm;startedUtc=$startedUtc;rconMs=$rconMs;markerMs=$markerMs;response=$response}
                $rows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $OutDir 'observations.json') -Encoding UTF8
            }
        }
    } finally { $stop = Stop-Server $proc }
    @{stopSent=$true;stopChannel=$stop.channel;killed=$stop.killed}
}
$session | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $OutDir 'session.json') -Encoding UTF8
if ($session.forcedKill -or $session.extra.killed -or $session.extra.stopChannel -ne 'rcon') { throw 'Diagnostic shutdown was not normal' }
Write-Output 'REAL_RCON_CONTROL_COMPLETE'
