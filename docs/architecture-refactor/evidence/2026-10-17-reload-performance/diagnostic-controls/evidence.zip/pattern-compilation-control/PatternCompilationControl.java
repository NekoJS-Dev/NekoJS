import java.nio.file.*;
import java.net.*;
import java.lang.reflect.*;
import java.util.*;
import com.google.gson.Gson;
public class PatternCompilationControl {
    static final String TARGET = "com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator";
    static class Loader extends URLClassLoader {
        Loader(Path root) throws Exception { super(new URL[]{root.toUri().toURL()}, PatternCompilationControl.class.getClassLoader()); }
        protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
            if (!name.equals(TARGET)) return super.loadClass(name, resolve);
            Class<?> result = findLoadedClass(name); if (result == null) result = findClass(name);
            if (resolve) resolveClass(result); return result;
        }
    }
    static long timed(Method method, List<String> sources, List<Set<String>> expected, int rounds) throws Exception {
        long start = System.nanoTime();
        for (int round = 0; round < rounds; round++) {
            for (int i = 0; i < sources.size(); i++) {
                Set<String> names = new HashSet<>(); method.invoke(null, sources.get(i), names);
                if (!names.equals(expected.get(i))) throw new AssertionError("Source-level identifiers changed");
            }
        }
        return System.nanoTime()-start;
    }
    public static void main(String[] args) throws Exception {
        Path output = Path.of(args[0]); Path fixtures = Path.of(args[1]);
        List<String> sources = new ArrayList<>();
        try (var files = Files.walk(fixtures)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".js")).sorted().toList()) sources.add(Files.readString(file));
        }
        if (sources.size() != 6) throw new AssertionError("Expected six original modules");
        try (var old = new Loader(output.resolve("baseline/classes")); var next = new Loader(output.resolve("candidate/classes"))) {
            Method a = old.loadClass(TARGET).getDeclaredMethod("collectSourceLevelNames", String.class, Set.class);
            Method b = next.loadClass(TARGET).getDeclaredMethod("collectSourceLevelNames", String.class, Set.class);
            a.setAccessible(true); b.setAccessible(true);
            List<Set<String>> expected = new ArrayList<>();
            for (String source : sources) { Set<String> names = new HashSet<>(); a.invoke(null, source, names); expected.add(names); }
            timed(a, sources, expected, 100); timed(b, sources, expected, 100);
            List<Map<String, Object>> pairs = new ArrayList<>();
            for (int pair = 0; pair < 10; pair++) {
                long av, bv;
                if (pair % 2 == 0) { av = timed(a, sources, expected, 100); bv = timed(b, sources, expected, 100); }
                else { bv = timed(b, sources, expected, 100); av = timed(a, sources, expected, 100); }
                pairs.add(Map.of("pair", pair, "baselineNs", av, "candidateNs", bv));
            }
            Files.writeString(output.resolve("pairs.json"), new Gson().toJson(pairs));
            Files.writeString(output.resolve("identifiers.json"), new Gson().toJson(expected));
        }
    }
}
