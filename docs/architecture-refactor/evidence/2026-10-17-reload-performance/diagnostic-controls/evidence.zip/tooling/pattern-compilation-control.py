import hashlib
import json
import re
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
output = project / 'build/priority-closeout/pattern-compilation-control'
assert not output.exists()
output.mkdir()
original = project / 'common/src/main/java/com/tkisor/nekojs/core/compiler/GlobalBindingMemberValidator.java'
old = original.read_text(encoding='utf-8')
fields = []

def replace(match):
    name = 'SOURCE_PATTERN_'+str(len(fields))
    fields.append('    private static final Pattern '+name+' = '+match.group()+';')
    return name

candidate, count = re.subn(r'Pattern\.compile\(("(?:\\.|[^"\\])*"(?:, Pattern\.MULTILINE)?)\)', replace, old)
assert count == 8, count
candidate = candidate.replace('    private GlobalBindingMemberValidator() {}', '\n'.join(fields)+'\n\n    private GlobalBindingMemberValidator() {}')
classpath = (output.parent / 'resolver-component/classpath.txt').read_text().strip()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')

def run(name, command):
    with (output / (name+'.log')).open('xb') as stdout, (output / (name+'-stderr.log')).open('xb') as stderr:
        result = subprocess.run(command, cwd=project, stdout=stdout, stderr=stderr)
    assert result.returncode == 0, name

for label, text in [('baseline', old), ('candidate', candidate)]:
    folder = output / label
    folder.mkdir()
    (folder / 'classes').mkdir()
    (folder / original.name).write_text(text, encoding='utf-8')
    run('compile-'+label, [str(java / 'javac.exe'), '-cp', classpath, '-encoding', 'UTF-8',
                          '-d', str(folder / 'classes'), str(folder / original.name)])
source = r'''import java.nio.file.*;
import java.net.*;
import java.lang.reflect.*;
import java.util.*;
import com.google.gson.Gson;
public class PatternCompilationControl {
    static final String TARGET = "com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator";
    static class Loader extends URLClassLoader {
        Loader(Path root) throws Exception { super(new URL[]{root.toUri().toURL()}, PatternCompilationControl.class.getClassLoader()); }
        protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
            if (!name.equals(TARGET)) return super.loadClass(name, resolve);
            Class<?> result = findLoadedClass(name); if (result == null) result = findClass(name);
            if (resolve) resolveClass(result); return result;
        }
    }
    static long timed(Method method, List<String> sources, List<Set<String>> expected, int rounds) throws Exception {
        long start = System.nanoTime();
        for (int round = 0; round < rounds; round++) {
            for (int i = 0; i < sources.size(); i++) {
                Set<String> names = new HashSet<>(); method.invoke(null, sources.get(i), names);
                if (!names.equals(expected.get(i))) throw new AssertionError("Source-level identifiers changed");
            }
        }
        return System.nanoTime()-start;
    }
    public static void main(String[] args) throws Exception {
        Path output = Path.of(args[0]); Path fixtures = Path.of(args[1]);
        List<String> sources = new ArrayList<>();
        try (var files = Files.walk(fixtures)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".js")).sorted().toList()) sources.add(Files.readString(file));
        }
        if (sources.size() != 6) throw new AssertionError("Expected six original modules");
        try (var old = new Loader(output.resolve("baseline/classes")); var next = new Loader(output.resolve("candidate/classes"))) {
            Method a = old.loadClass(TARGET).getDeclaredMethod("collectSourceLevelNames", String.class, Set.class);
            Method b = next.loadClass(TARGET).getDeclaredMethod("collectSourceLevelNames", String.class, Set.class);
            a.setAccessible(true); b.setAccessible(true);
            List<Set<String>> expected = new ArrayList<>();
            for (String source : sources) { Set<String> names = new HashSet<>(); a.invoke(null, source, names); expected.add(names); }
            timed(a, sources, expected, 100); timed(b, sources, expected, 100);
            List<Map<String, Object>> pairs = new ArrayList<>();
            for (int pair = 0; pair < 10; pair++) {
                long av, bv;
                if (pair % 2 == 0) { av = timed(a, sources, expected, 100); bv = timed(b, sources, expected, 100); }
                else { bv = timed(b, sources, expected, 100); av = timed(a, sources, expected, 100); }
                pairs.add(Map.of("pair", pair, "baselineNs", av, "candidateNs", bv));
            }
            Files.writeString(output.resolve("pairs.json"), new Gson().toJson(pairs));
            Files.writeString(output.resolve("identifiers.json"), new Gson().toJson(expected));
        }
    }
}
'''
(output / 'PatternCompilationControl.java').write_text(source, encoding='utf-8')
(output / 'classes').mkdir()
run('compile-control', [str(java / 'javac.exe'), '-cp', classpath, '-d', str(output / 'classes'), str(output / 'PatternCompilationControl.java')])
run('run', [str(java / 'java.exe'), '-cp', str(output / 'classes')+';'+classpath, 'PatternCompilationControl', str(output),
            str(project / 'bench/perf/fixtures/nekojs/server_scripts')])
pairs = json.loads((output / 'pairs.json').read_text())
summary = dict(diagnosticOnly=True, privateMethodMicrobenchmark=True, fixedPatterns=count,
    sources=6, pairs=10, roundsPerArm=100, originalSha256=hashlib.sha256(original.read_bytes()).hexdigest(),
    baselineMsPerSix=sum(p['baselineNs'] for p in pairs)/10/100/1e6,
    candidateMsPerSix=sum(p['candidateNs'] for p in pairs)/10/100/1e6)
(output / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(summary))
