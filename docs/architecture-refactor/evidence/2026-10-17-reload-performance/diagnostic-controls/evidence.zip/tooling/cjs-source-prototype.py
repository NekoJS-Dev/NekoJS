import json
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
root = project / 'build/priority-closeout/cjs-source-prototype'
assert not root.exists()
root.mkdir()
source = r'''import graal.graalvm.polyglot.*;
import graal.graalvm.polyglot.io.*;
import com.tkisor.nekojs.core.fs.*;
import com.tkisor.nekojs.core.config.SandboxConfig;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
public class CjsSourcePrototype {
    static final String HEADER = "(function anonymous(exports,require,module,__filename,__dirname\n) {\n";
    static final String CODE = "globalThis.count=(globalThis.count||0)+1; return JSON.stringify({count:count,globalThisValue:this===globalThis,dirname:__dirname,filename:__filename});";
    static final Source DYNAMIC = Source.newBuilder("js", "(function(code,filename,dirname){return new Function('exports','require','module','__filename','__dirname',code+'\\n//# sourceURL='+filename)({},()=>{}, {exports:{}},filename,dirname)})", "dynamic-executor").buildLiteral();
    static int realPaths;
    static long run(Engine engine, FileSystem fileSystem, Path game, List<Path> files, List<Source> sources, boolean cached, int rounds) throws Exception {
        long total=0;
        for (int round=0;round<rounds;round++) {
            try (Context context=Context.newBuilder("js").engine(engine).allowExperimentalOptions(true)
                .allowIO(IOAccess.newBuilder().fileSystem(fileSystem).build())
                .option("js.commonjs-require","true").option("js.commonjs-require-cwd",game.resolve("nekojs").toString())
                .option("js.nashorn-compat","true").option("js.strict","true").build()) {
                Value dynamic=context.eval(DYNAMIC);
                long start=System.nanoTime();
                for (int i=0;i<files.size();i++) {
                    Path file=files.get(i);
                    String result;
                    if (cached) {
                        Value function=context.eval(sources.get(i));
                        result=function.execute(context.eval("js","({})"), context.eval("js","(()=>{})"),
                            context.eval("js","({exports:{}})"), file.toString(),file.getParent().toString()).asString();
                    } else result=dynamic.execute(CODE,file.toString(),file.getParent().toString()).asString();
                    if (!result.contains("\"count\":"+(i+1)) || !result.contains("\"globalThisValue\":true")) throw new AssertionError(result);
                }
                total+=System.nanoTime()-start;
            }
        }
        return total;
    }
    public static void main(String[] args) throws Exception {
        Path game=Path.of(args[0]);
        Files.createDirectories(game.resolve("nekojs/server_scripts"));
        NekoJSPaths paths=NekoJSPaths.fromGameDir(game);
        FileSystem delegate=new NekoJSFileSystem(paths.root(),new SandboxPolicy(SandboxConfig.defaultConfig(),paths),paths);
        FileSystem counted=(FileSystem)Proxy.newProxyInstance(FileSystem.class.getClassLoader(),new Class<?>[]{FileSystem.class},(proxy,method,arguments)->{
            if(method.getName().equals("toRealPath")) realPaths++;
            try {return method.invoke(delegate,arguments);} catch(InvocationTargetException e){throw e.getCause();}
        });
        List<Path> files=new ArrayList<>();
        List<Source> sources=new ArrayList<>();
        for(int i=0;i<6;i++) {
            Path file=game.resolve("nekojs/server_scripts/"+i+".js").toAbsolutePath();
            Files.writeString(file,CODE);files.add(file);
            sources.add(Source.newBuilder("js",HEADER+CODE+"\n})",file.toString()).uri(file.toUri()).build());
        }
        try(Engine engine=Engine.newBuilder().option("engine.WarnInterpreterOnly","false").build()) {
            run(engine,counted,game,files,sources,false,5);run(engine,counted,game,files,sources,true,5);
            System.out.print("{\"pairs\":[");
            for(int p=0;p<10;p++) {
                long a,b;int ac,bc;
                if(p%2==0) {realPaths=0;a=run(engine,counted,game,files,sources,false,10);ac=realPaths;realPaths=0;b=run(engine,counted,game,files,sources,true,10);bc=realPaths;}
                else {realPaths=0;b=run(engine,counted,game,files,sources,true,10);bc=realPaths;realPaths=0;a=run(engine,counted,game,files,sources,false,10);ac=realPaths;}
                if(p>0)System.out.print(",");
                System.out.print("{\"dynamicNs\":"+a+",\"sourceNs\":"+b+",\"dynamicRealPaths\":"+ac+",\"sourceRealPaths\":"+bc+"}");
            }
            System.out.println("]}");
        }
    }
}
'''
(root / 'CjsSourcePrototype.java').write_text(source, encoding='utf-8')
classpath = (project / 'build/priority-closeout/resolver-component/classpath.txt').read_text().strip()
classes = root / 'classes'
classes.mkdir()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
for stage, arguments in [('compile', [str(java / 'javac.exe'), '-encoding', 'UTF-8', '-cp', classpath,
    '-d', str(classes), str(root / 'CjsSourcePrototype.java')]),
    ('run', [str(java / 'java.exe'), '-cp', str(classes)+';'+classpath, 'CjsSourcePrototype', str(root / 'game')])]:
    with (root / (stage+'.log')).open('xb') as out, (root / (stage+'-stderr.log')).open('xb') as err:
        result = subprocess.run(arguments, cwd=project, stdout=out, stderr=err)
        assert result.returncode == 0, 'See '+stage+'-stderr.log'
result = json.loads((root / 'run.log').read_text())
summary = dict(diagnosticOnly=True, equivalentCountAndThis=True,
    dynamicMsPerSix=sum(row['dynamicNs'] for row in result['pairs'])/10/10/1e6,
    sourceMsPerSix=sum(row['sourceNs'] for row in result['pairs'])/10/10/1e6,
    dynamicRealPathsPerContext=sum(row['dynamicRealPaths'] for row in result['pairs'])/10/10,
    sourceRealPathsPerContext=sum(row['sourceRealPaths'] for row in result['pairs'])/10/10)
(root / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
