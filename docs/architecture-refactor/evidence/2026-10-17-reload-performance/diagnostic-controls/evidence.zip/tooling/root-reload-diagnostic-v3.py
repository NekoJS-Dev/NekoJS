from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'root-reload-diagnostic.py').read_text(encoding='utf-8')
source = source.replace("'build/priority-closeout/root-reload-diagnostic'", "'build/priority-closeout/root-reload-diagnostic-v3'")
source = source.replace('Field contextField = manager.getClass().getDeclaredField("context"); contextField.setAccessible(true);', '')
source = source.replace('Context current = (Context) contextField.get(manager);', 'Context current = manager.activeContextForPackOwner();')
source = source.replace('long start = System.nanoTime();', 'String epochStart = java.time.Instant.now().toString(); long start = System.nanoTime();')
source = source.replace('"index", index, "nanos", nanos,', '"index", index, "epochStart", epochStart, "epochEnd", java.time.Instant.now().toString(), "nanos", nanos,')
source = source.replace('classes = output / \'classes\'', '''
classpath = ';'.join(p for p in classpath.split(';') if '/log4j-core/' not in p.replace('\\\\', '/') and '/log4j-api/' not in p.replace('\\\\', '/'))
dependencies = Path('C:/Users/11515/.gradle/caches/modules-2/files-2.1/org.apache.logging.log4j')
for artifact in ['log4j-api', 'log4j-core', 'log4j-slf4j2-impl']:
    matches = list((dependencies / artifact / '2.25.2').glob('*/'+artifact+'-2.25.2.jar'))
    assert len(matches) == 1, artifact
    classpath += ';'+str(matches[0])
(output / 'runtime-classpath.txt').write_text(classpath, encoding='utf-8')
classes = output / 'classes' ''')
source = source.replace('noMinecraftRecipesRcon=True,', 'noMinecraftRecipesRcon=True, log4jProvider="2.25.2",')
exec(compile(source, str(root / 'root-reload-diagnostic-v3.py'), 'exec'))
