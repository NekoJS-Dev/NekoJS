from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'cjs-source-prototype-v3.py').read_text(encoding='utf-8')
source = source.replace("exec(compile(source, str(root / 'cjs-source-prototype-v3.py'), 'exec'))", '''
source = source.replace("exec(compile(source, str(root / 'cjs-source-prototype-v3-generated.py'), 'exec'))", "source = source.replace(\"'build/priority-closeout/cjs-source-prototype-v3'\", \"'build/priority-closeout/cjs-source-prototype-v4'\")\\nsource = source.replace('globalThisValue\\\\\\\":true', 'globalThisValue\\\\\\\":false')\\nexec(compile(source, str(root / 'cjs-source-prototype-v4-generated.py'), 'exec'))")
exec(compile(source, str(root / 'cjs-source-prototype-v4.py'), 'exec'))
''')
exec(compile(source, str(root / 'cjs-source-prototype-v4.py'), 'exec'))
