from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'root-reload-diagnostic.py').read_text(encoding='utf-8')
source = source.replace("'build/priority-closeout/root-reload-diagnostic'", "'build/priority-closeout/root-reload-diagnostic-v2'")
source = source.replace('Field contextField = manager.getClass().getDeclaredField("context"); contextField.setAccessible(true);', '')
source = source.replace('Context current = (Context) contextField.get(manager);', 'Context current = manager.activeContextForPackOwner();')
exec(compile(source, str(root / 'root-reload-diagnostic-v2.py'), 'exec'))
