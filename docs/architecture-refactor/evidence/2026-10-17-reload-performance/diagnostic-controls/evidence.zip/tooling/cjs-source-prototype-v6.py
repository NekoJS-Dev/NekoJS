from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'cjs-source-prototype-v5.py').read_text(encoding='utf-8')
source = source.replace("'build/priority-closeout/cjs-source-prototype-v5'", "'build/priority-closeout/cjs-source-prototype-v6'")
source = source.replace("source = source.replace('globalThisValue\\\\\\\":true', 'globalThisValue\\\\\\\":false')\nassert 'globalThisValue\\\\\\\":false' in source", "source = source.replace('result.contains(\\\"\\\\\\\"globalThisValue\\\\\\\":true\\\")', 'result.contains(\\\"\\\\\\\"globalThisValue\\\\\\\":\\\"+(!cached))')")
source = source.replace('equivalentCountAndThis=True', 'equivalentCount=True, equivalentThis=False, rejectedForSemanticChange=True')
exec(compile(source, str(root / 'cjs-source-prototype-v6.py'), 'exec'))
