import json
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
root = project / 'build/priority-closeout/cjs-source-prototype-v5'
assert not root.exists()
root.mkdir()
source = (root.parent / 'cjs-source-prototype-v3/CjsSourcePrototype.java').read_text(encoding='utf-8')
source = source.replace('globalThisValue\\\":true', 'globalThisValue\\\":false')
assert 'globalThisValue\\\":false' in source
(root / 'CjsSourcePrototype.java').write_text(source, encoding='utf-8')
classpath = (root.parent / 'resolver-component/classpath.txt').read_text().strip()
classes = root / 'classes'
classes.mkdir()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
for stage, arguments in [('compile', [str(java / 'javac.exe'), '-encoding', 'UTF-8', '-cp', classpath,
    '-d', str(classes), str(root / 'CjsSourcePrototype.java')]),
    ('run', [str(java / 'java.exe'), '-cp', str(classes)+';'+classpath, 'CjsSourcePrototype', str(root / 'game')])]:
    with (root / (stage+'.log')).open('xb') as out, (root / (stage+'-stderr.log')).open('xb') as err:
        result = subprocess.run(arguments, cwd=project, stdout=out, stderr=err)
        assert result.returncode == 0, 'See '+stage+'-stderr.log'
result = json.loads((root / 'run.log').read_text())
summary = dict(diagnosticOnly=True, equivalentCountAndThis=True,
    dynamicMsPerSix=sum(row['dynamicNs'] for row in result['pairs'])/10/10/1e6,
    sourceMsPerSix=sum(row['sourceNs'] for row in result['pairs'])/10/10/1e6,
    dynamicExecutionRealPathsPerContext=sum(row['dynamicRealPaths'] for row in result['pairs'])/10/10,
    sourceExecutionRealPathsPerContext=sum(row['sourceRealPaths'] for row in result['pairs'])/10/10)
(root / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
