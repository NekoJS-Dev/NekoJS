from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'cjs-source-prototype-v2.py').read_text(encoding='utf-8')
source = source.replace("exec(compile(source, str(root / 'cjs-source-prototype-v2.py'), 'exec'))", '''
source = source.replace("'build/priority-closeout/cjs-source-prototype-v2'", "'build/priority-closeout/cjs-source-prototype-v3'")
source = source.replace('.option("js.nashorn-compat","true").option("js.strict","true")', '.option("js.nashorn-compat","true").option("js.ecmascript-version","latest").option("js.strict","true")')
source = source.replace('static int realPaths;', 'static int realPaths; static int executionRealPaths;')
source = source.replace('Value dynamic=context.eval(DYNAMIC);', 'Value dynamic=context.eval(DYNAMIC); Value exports=context.eval("js","({})"); Value require=context.eval("js","(()=>{})"); Value module=context.eval("js","({exports:{}})"); int before=realPaths;')
source = source.replace('function.execute(context.eval("js","({})"), context.eval("js","(()=>{})"),\\n                            context.eval("js","({exports:{}})"),', 'function.execute(exports, require, module,')
source = source.replace('total+=System.nanoTime()-start;', 'total+=System.nanoTime()-start; executionRealPaths+=realPaths-before;')
source = source.replace('realPaths=0;', 'realPaths=0;executionRealPaths=0;')
source = source.replace('ac=realPaths;', 'ac=executionRealPaths;').replace('bc=realPaths;', 'bc=executionRealPaths;')
exec(compile(source, str(root / 'cjs-source-prototype-v3-generated.py'), 'exec'))
''')
exec(compile(source, str(root / 'cjs-source-prototype-v3.py'), 'exec'))
