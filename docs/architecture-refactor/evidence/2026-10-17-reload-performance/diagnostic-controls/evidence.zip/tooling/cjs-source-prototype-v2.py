from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'cjs-source-prototype.py').read_text(encoding='utf-8')
source = source.replace("'build/priority-closeout/cjs-source-prototype'", "'build/priority-closeout/cjs-source-prototype-v2'")
source = source.replace('import java.nio.file.*;', '''import java.nio.file.*;
import graal.graalvm.polyglot.io.FileSystem;
import com.tkisor.nekojs.core.fs.SandboxPolicy;
import com.tkisor.nekojs.core.module.*;
import com.tkisor.nekojs.core.error.SourceMapRegistry;
import com.tkisor.nekojs.core.compiler.*;''')
source = source.replace('FileSystem delegate=new NekoJSFileSystem(paths.root(),new SandboxPolicy(SandboxConfig.defaultConfig(),paths),paths);', '''var config = SandboxConfig.defaultConfig();
        var cache = new NekoModulePipelineCache(new NekoModulePipeline(new NekoCompilationPipeline(),ScriptCompilerRegistry.createRuntimeRegistry(),config),
            new SourceMapRegistry(paths.root()),new NekoEsmVirtualModuleRegistry(paths.root()),NekoTrustContext.local());
        FileSystem delegate=new NekoJSFileSystem(paths.root(),new SandboxPolicy(config,paths),paths,cache);''')
exec(compile(source, str(root / 'cjs-source-prototype-v2.py'), 'exec'))
