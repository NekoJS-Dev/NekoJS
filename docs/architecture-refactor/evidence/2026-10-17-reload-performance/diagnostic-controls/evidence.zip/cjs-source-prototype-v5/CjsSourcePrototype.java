import graal.graalvm.polyglot.*;
import graal.graalvm.polyglot.io.*;
import com.tkisor.nekojs.core.fs.*;
import com.tkisor.nekojs.core.config.SandboxConfig;
import java.nio.file.*;
import graal.graalvm.polyglot.io.FileSystem;
import com.tkisor.nekojs.core.fs.SandboxPolicy;
import com.tkisor.nekojs.core.module.*;
import com.tkisor.nekojs.core.error.SourceMapRegistry;
import com.tkisor.nekojs.core.compiler.*;
import java.lang.reflect.*;
import java.util.*;
public class CjsSourcePrototype {
    static final String HEADER = "(function anonymous(exports,require,module,__filename,__dirname\n) {\n";
    static final String CODE = "globalThis.count=(globalThis.count||0)+1; return JSON.stringify({count:count,globalThisValue:this===globalThis,dirname:__dirname,filename:__filename});";
    static final Source DYNAMIC = Source.newBuilder("js", "(function(code,filename,dirname){return new Function('exports','require','module','__filename','__dirname',code+'\\n//# sourceURL='+filename)({},()=>{}, {exports:{}},filename,dirname)})", "dynamic-executor").buildLiteral();
    static int realPaths; static int executionRealPaths;
    static long run(Engine engine, FileSystem fileSystem, Path game, List<Path> files, List<Source> sources, boolean cached, int rounds) throws Exception {
        long total=0;
        for (int round=0;round<rounds;round++) {
            try (Context context=Context.newBuilder("js").engine(engine).allowExperimentalOptions(true)
                .allowIO(IOAccess.newBuilder().fileSystem(fileSystem).build())
                .option("js.commonjs-require","true").option("js.commonjs-require-cwd",game.resolve("nekojs").toString())
                .option("js.nashorn-compat","true").option("js.ecmascript-version","latest").option("js.strict","true").build()) {
                Value dynamic=context.eval(DYNAMIC); Value exports=context.eval("js","({})"); Value require=context.eval("js","(()=>{})"); Value module=context.eval("js","({exports:{}})"); int before=realPaths;
                long start=System.nanoTime();
                for (int i=0;i<files.size();i++) {
                    Path file=files.get(i);
                    String result;
                    if (cached) {
                        Value function=context.eval(sources.get(i));
                        result=function.execute(exports, require, module, file.toString(),file.getParent().toString()).asString();
                    } else result=dynamic.execute(CODE,file.toString(),file.getParent().toString()).asString();
                    if (!result.contains("\"count\":"+(i+1)) || !result.contains("\"globalThisValue\":false")) throw new AssertionError(result);
                }
                total+=System.nanoTime()-start; executionRealPaths+=realPaths-before;
            }
        }
        return total;
    }
    public static void main(String[] args) throws Exception {
        Path game=Path.of(args[0]);
        Files.createDirectories(game.resolve("nekojs/server_scripts"));
        NekoJSPaths paths=NekoJSPaths.fromGameDir(game);
        var config = SandboxConfig.defaultConfig();
        var cache = new NekoModulePipelineCache(new NekoModulePipeline(new NekoCompilationPipeline(),ScriptCompilerRegistry.createRuntimeRegistry(),config),
            new SourceMapRegistry(paths.root()),new NekoEsmVirtualModuleRegistry(paths.root()),NekoTrustContext.local());
        FileSystem delegate=new NekoJSFileSystem(paths.root(),new SandboxPolicy(config,paths),paths,cache);
        FileSystem counted=(FileSystem)Proxy.newProxyInstance(FileSystem.class.getClassLoader(),new Class<?>[]{FileSystem.class},(proxy,method,arguments)->{
            if(method.getName().equals("toRealPath")) realPaths++;
            try {return method.invoke(delegate,arguments);} catch(InvocationTargetException e){throw e.getCause();}
        });
        List<Path> files=new ArrayList<>();
        List<Source> sources=new ArrayList<>();
        for(int i=0;i<6;i++) {
            Path file=game.resolve("nekojs/server_scripts/"+i+".js").toAbsolutePath();
            Files.writeString(file,CODE);files.add(file);
            sources.add(Source.newBuilder("js",HEADER+CODE+"\n})",file.toString()).uri(file.toUri()).build());
        }
        try(Engine engine=Engine.newBuilder().option("engine.WarnInterpreterOnly","false").build()) {
            run(engine,counted,game,files,sources,false,5);run(engine,counted,game,files,sources,true,5);
            System.out.print("{\"pairs\":[");
            for(int p=0;p<10;p++) {
                long a,b;int ac,bc;
                if(p%2==0) {realPaths=0;executionRealPaths=0;a=run(engine,counted,game,files,sources,false,10);ac=executionRealPaths;realPaths=0;executionRealPaths=0;b=run(engine,counted,game,files,sources,true,10);bc=executionRealPaths;}
                else {realPaths=0;executionRealPaths=0;b=run(engine,counted,game,files,sources,true,10);bc=executionRealPaths;realPaths=0;executionRealPaths=0;a=run(engine,counted,game,files,sources,false,10);ac=executionRealPaths;}
                if(p>0)System.out.print(",");
                System.out.print("{\"dynamicNs\":"+a+",\"sourceNs\":"+b+",\"dynamicRealPaths\":"+ac+",\"sourceRealPaths\":"+bc+"}");
            }
            System.out.println("]}");
        }
    }
}
