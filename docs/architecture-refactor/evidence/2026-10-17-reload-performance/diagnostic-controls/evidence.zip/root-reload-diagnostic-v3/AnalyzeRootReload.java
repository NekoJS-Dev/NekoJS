import java.nio.file.*;
import java.time.*;
import java.util.*;
import jdk.jfr.consumer.*;
import com.google.gson.*;
public class AnalyzeRootReload {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]);
        var rows = JsonParser.parseString(Files.readString(root.resolve("samples.json"))).getAsJsonArray();
        List<Instant[]> windows = new ArrayList<>();
        for (int i = 10; i < rows.size(); i++) {
            var row = rows.get(i).getAsJsonObject();
            Instant start = Instant.parse(row.get("epochStart").getAsString());
            windows.add(new Instant[]{start, start.plusNanos(row.get("nanos").getAsLong())});
        }
        Map<String, Integer> nearest = new HashMap<>(), inclusive = new HashMap<>(), leaf = new HashMap<>();
        int count = 0;
        try (RecordingFile recording = new RecordingFile(root.resolve("root-profile.jfr"))) {
            while (recording.hasMoreEvents()) {
                var event = recording.readEvent();
                String type = event.getEventType().getName();
                if (!type.equals("jdk.ExecutionSample") && !type.equals("jdk.NativeMethodSample")) continue;
                if (!event.getThread("sampledThread").getJavaName().equals("main")) continue;
                Instant time = event.getStartTime();
                if (windows.stream().noneMatch(w -> !time.isBefore(w[0]) && !time.isAfter(w[1]))) continue;
                if (event.getStackTrace() == null) continue;
                count++; boolean found = false; boolean first = true;
                for (var frame : event.getStackTrace().getFrames()) {
                    var method = frame.getMethod();
                    String name = method.getType().getName()+"."+method.getName();
                    if (first) leaf.merge(name, 1, Integer::sum);
                    first = false;
                    if (!name.startsWith("com.tkisor.nekojs.")) continue;
                    inclusive.merge(name, 1, Integer::sum);
                    if (!found) nearest.merge(name, 1, Integer::sum);
                    found = true;
                }
                if (!found) nearest.merge("none", 1, Integer::sum);
            }
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("diagnosticOnly", true); result.put("sampleCountsNotMilliseconds", true);
        result.put("mainThreadSamples", count); result.put("nearestNekoFrames", sorted(nearest));
        result.put("inclusiveNekoFrames", sorted(inclusive)); result.put("leafFrames", sorted(leaf));
        Files.writeString(root.resolve("profile-summary.json"), new GsonBuilder().setPrettyPrinting().create().toJson(result));
    }
    static Map<String, Integer> sorted(Map<String, Integer> input) {
        Map<String, Integer> result = new LinkedHashMap<>();
        input.entrySet().stream().sorted(Map.Entry.<String, Integer>comparingByValue().reversed()).limit(40)
            .forEach(entry -> result.put(entry.getKey(), entry.getValue()));
        return result;
    }
}
