from pathlib import Path

tools = Path(__file__).resolve().parent
source = (tools / 'visibility-monitor.py').read_text(encoding='utf-8')
source = source.replace("offsets = {stdout_path: stdout_path.stat().st_size, stderr_path: stderr_path.stat().st_size}", '''
game = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run')
script_log = game / 'logs/nekojs/server.log'
game_log = game / 'logs/latest.log'
assert script_log.is_file() and game_log.is_file()
offsets = {path: path.stat().st_size for path in [stdout_path, stderr_path, script_log, game_log]}''')
source = source.replace("    commands = ['list', 'nekojs reload'] if pair % 2 else ['nekojs reload', 'list']", "    commands = ['nekojs reload']")
source = source.replace('        marker = None', '        marker = None\n        marker_sinks = {}')
source = source.replace("                    if path == stdout_path and 'PERF02-SERVER tick-bench load' in line:", '''                    if path != stderr_path and 'PERF02-SERVER tick-bench load' in line:
                        assert path.name not in marker_sinks, 'Duplicate marker at one sink'
                        marker_sinks[path.name] = dict(utcNs=observed_utc, parentElapsedMs=(time.perf_counter_ns()-started)/1e6)
                    if path == stdout_path and 'PERF02-SERVER tick-bench load' in line:''')
source = source.replace('(marker is not None and len(phases) == 3)', '(marker is not None and len(phases) == 3 and len(marker_sinks) == 3)')
source = source.replace('clientExit=client_exit, marker=marker, phases=phases,', 'clientExit=client_exit, marker=marker, markerSinks=marker_sinks, phases=phases,')
source = source.replace("and marker is not None and len(phases) == 3,", "and marker is not None and len(phases) == 3 and len(marker_sinks) == 3,")
source = source.replace('reloads=10, controls=10', 'reloads=10, controls=0')
(tools / 'visibility-monitor-sinks.py').write_text(source, encoding='utf-8')
controller = (tools / 'visibility.ps1').read_text(encoding='utf-8')
controller = controller.replace('diagnostic-visibility-6e5bb8f0', 'diagnostic-visibility-sinks-6e5bb8f0')
controller = controller.replace('visibility-monitor.py', 'visibility-monitor-sinks.py')
(tools / 'visibility-sinks.ps1').write_text(controller, encoding='utf-8')
runner = (tools / 'run-visibility.py').read_text(encoding='utf-8')
runner = runner.replace('visibility.ps1', 'visibility-sinks.ps1').replace('visibility-controller', 'visibility-sinks-controller').replace('visibility-exit', 'visibility-sinks-exit')
(tools / 'run-visibility-sinks.py').write_text(runner, encoding='utf-8')
print('VISIBILITY_SINKS_PREPARED')
