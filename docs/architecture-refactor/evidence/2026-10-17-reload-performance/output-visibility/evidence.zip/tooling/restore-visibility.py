import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
manifest = json.loads((tools / 'visibility-source-manifest.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == manifest['revision']
assert subprocess.check_output(['git', 'diff', '--name-only'], cwd=worktree, text=True).strip() == manifest['path']
for label in ['diagnostic-visibility-6e5bb8f0', 'diagnostic-visibility-sinks-6e5bb8f0']:
    session = json.loads((tools / label / 'session.json').read_text(encoding='utf-8-sig'))
    assert not session['forcedKill'] and not session['extra']['killed'] and session['extra']['stopChannel'] == 'rcon'
path = worktree / manifest['path']
assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['diagnosticSha256']
original = (tools / 'visibility-original-command.java').read_bytes()
assert hashlib.sha256(original).hexdigest() == manifest['originalSha256']
path.write_bytes(original)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
source = (tools / 'diagnostic-current-restored-build.ps1').read_text(encoding='utf-8')
source = source.replace('diagnostic-current-restored', 'visibility-restored')
script = tools / 'visibility-restored-build.ps1'
assert not script.exists()
script.write_text(source, encoding='utf-8')
result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(script)],
                        cwd='D:/mcmodDemo/NekoJS-mult', capture_output=True, text=True)
(tools / 'visibility-restored-controller.log').write_text(result.stdout, encoding='utf-8')
(tools / 'visibility-restored-controller-stderr.log').write_text(result.stderr, encoding='utf-8')
assert result.returncode == 0
count = 0
for root in [worktree / 'common/build/classes/java/main', worktree / 'versions/26.1.2/build/classes/java/main']:
    for file in root.rglob('*.class'):
        assert b'DEBUG-VISIBILITY-17' not in file.read_bytes(), file
        count += 1
assert count > 1500
record = dict(sourceRestoredAndClean=True, revision=manifest['revision'], rebuilt=True,
              mainClassesWithoutVisibilityTags=count)
(tools / 'diagnostic-visibility-sinks-6e5bb8f0/restoration.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
