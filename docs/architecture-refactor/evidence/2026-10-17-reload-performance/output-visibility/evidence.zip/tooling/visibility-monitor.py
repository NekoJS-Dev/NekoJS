import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

stdout_path, stderr_path, output = map(Path, sys.argv[1:4])
assert output.resolve().is_relative_to(Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout').resolve())
assert stdout_path.is_file() and stderr_path.is_file()
client_script = Path(__file__).resolve().parent / 'visibility-rcon.py'
offsets = {stdout_path: stdout_path.stat().st_size, stderr_path: stderr_path.stat().st_size}
pending = {stdout_path: '', stderr_path: ''}
observations = []


def read_new(path):
    with path.open('rb') as stream:
        stream.seek(offsets[path])
        data = stream.read()
        offsets[path] = stream.tell()
    return data.decode('utf-8', errors='replace')


for pair in range(1, 11):
    commands = ['list', 'nekojs reload'] if pair % 2 else ['nekojs reload', 'list']
    for command in commands:
        time.sleep(3)
        for path in offsets:
            read_new(path)
            pending[path] = ''
        index = len(observations)+1
        telemetry_file = output / ('client-'+str(index)+'.json')
        environment = dict(os.environ)
        environment['NEKO_RCON_TIMING_FILE'] = str(telemetry_file)
        started_utc = time.time_ns()
        started = time.perf_counter_ns()
        client = subprocess.Popen([sys.executable, str(client_script), '25872', environment['NEKO_PERF_RCON_PASS'], '180', command],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=environment,
            creationflags=subprocess.CREATE_NO_WINDOW)
        marker = None
        phases = {}
        client_exit = None
        response = None
        error = None
        timed_out = False
        while True:
            elapsed_ms = (time.perf_counter_ns()-started)/1e6
            for path in offsets:
                text = pending[path]+read_new(path)
                lines = text.split('\n')
                pending[path] = lines.pop()
                for line in lines:
                    observed_utc = time.time_ns()
                    if path == stdout_path and 'PERF02-SERVER tick-bench load' in line:
                        assert marker is None, 'More than one reload marker observed'
                        marker = dict(utcNs=observed_utc, parentElapsedMs=(time.perf_counter_ns()-started)/1e6)
                    phase = re.search(r'\[DEBUG-VISIBILITY-17\] (root-start|root-end|recipe-end) utcMs=(\d+) nano=(\d+)', line)
                    if path == stderr_path and phase:
                        assert phase[1] not in phases, 'Duplicate command phase'
                        phases[phase[1]] = dict(serverUtcMs=int(phase[2]), serverNano=int(phase[3]), observedUtcNs=observed_utc)
            if client.poll() is not None and client_exit is None:
                client_exit = dict(utcNs=time.time_ns(), parentElapsedMs=(time.perf_counter_ns()-started)/1e6,
                                   exitCode=client.returncode)
                raw_response, raw_error = client.communicate()
                response = raw_response.decode('utf-8', errors='replace').strip()
                error = raw_error.decode('utf-8', errors='replace').strip()
            if client_exit is not None:
                complete = command == 'list' or (marker is not None and len(phases) == 3)
                if complete or elapsed_ms-client_exit['parentElapsedMs'] > 3000:
                    break
            if elapsed_ms > 185000:
                timed_out = True
                if client.poll() is None:
                    client.kill()
                raw_response, raw_error = client.communicate()
                response = raw_response.decode('utf-8', errors='replace').strip()
                error = raw_error.decode('utf-8', errors='replace').strip()
                break
            time.sleep(.005)
        row = dict(index=index, pair=pair, command=command, parentStartedUtcNs=started_utc,
                   clientExit=client_exit, marker=marker, phases=phases, response=response, error=error,
                   timeout=timed_out)
        if telemetry_file.exists():
            row['clientTimeline'] = json.loads(telemetry_file.read_text())
        observations.append(row)
        (output / 'observations.json').write_text(json.dumps(observations, indent=2)+'\n', encoding='utf-8')
        assert not timed_out and client_exit['exitCode'] == 0 and not error, 'Diagnostic client failed'
        if command != 'list':
            assert 'phase=COMMIT - no errors.' in response and marker is not None and len(phases) == 3, 'Incomplete reload observation'
print(json.dumps(dict(diagnosticOnly=True, commands=len(observations), reloads=10, controls=10)))
