import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
revision = '6e5bb8f00c3747b828056589853cb0471477b18a'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
relative = 'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java'
path = worktree / relative
original = path.read_bytes()
backup = tools / 'visibility-original-command.java'
assert not backup.exists()
backup.write_bytes(original)
source = original.decode('utf-8')
replacements = {
    '            reloadResult = root.reload(type);': '''            System.err.println("[DEBUG-VISIBILITY-17] root-start utcMs=" + System.currentTimeMillis() + " nano=" + System.nanoTime());
            reloadResult = root.reload(type);
            System.err.println("[DEBUG-VISIBILITY-17] root-end utcMs=" + System.currentTimeMillis() + " nano=" + System.nanoTime());''',
    '                    recipeBroadcast = applyRecipeScripts(source);': '''                    recipeBroadcast = applyRecipeScripts(source);
                    System.err.println("[DEBUG-VISIBILITY-17] recipe-end utcMs=" + System.currentTimeMillis() + " nano=" + System.nanoTime());'''
}
for before, after in replacements.items():
    assert source.count(before) == 1, before
    source = source.replace(before, after)
path.write_text(source, encoding='utf-8', newline='\n')
(tools / 'visibility-source-manifest.json').write_text(json.dumps(dict(revision=revision, path=relative,
    originalSha256=hashlib.sha256(original).hexdigest(), diagnosticSha256=hashlib.sha256(path.read_bytes()).hexdigest()), indent=2)+'\n')
(tools / 'visibility.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', relative], cwd=worktree))

client = (worktree / 'bench/perf/rcon.py').read_text(encoding='utf-8')
client = 'import time\nTIMELINE = [("child-start", time.time_ns(), time.perf_counter_ns())]\n'+client
client = client.replace('import sys', '''import sys
import os
import json
TIMELINE.append(("imports-ready", time.time_ns(), time.perf_counter_ns()))
def mark(name):
    TIMELINE.append((name, time.time_ns(), time.perf_counter_ns()))''')
for before, after in {
    '    sock = socket.create_connection': '    mark("connect-start")\n    sock = socket.create_connection',
    '    sock.settimeout(timeout)': '    mark("connected")\n    sock.settimeout(timeout)',
    '        send_packet(sock, 1, 3, password)': '        mark("auth-send")\n        send_packet(sock, 1, 3, password)',
    '        auth = recv_packet(sock)': '        auth = recv_packet(sock)\n        mark("auth-received")',
    '            send_packet(sock, 10 + i, 2, command)': '            mark("command-send")\n            send_packet(sock, 10 + i, 2, command)',
    '            resp = recv_packet(sock)': '            resp = recv_packet(sock)\n            mark("response-received")',
    '        sock.close()': '''        sock.close()
        mark("child-finish")
        with open(os.environ["NEKO_RCON_TIMING_FILE"], "x", encoding="utf-8") as stream:
            json.dump(TIMELINE, stream)'''
}.items():
    assert client.count(before) == 1, before
    client = client.replace(before, after)
(tools / 'visibility-rcon.py').write_text(client, encoding='utf-8')

controller = (tools / 'diagnostic-current.ps1').read_text(encoding='utf-8').split('Write-EnvSnapshot\nDeploy-Fixtures -Bench:$false')[0]
controller = controller.replace('diagnostic-6e5bb8f0', 'diagnostic-visibility-6e5bb8f0').replace('$changedFiles.Count -ne 11', '$changedFiles.Count -ne 1')
controller += r'''
Write-EnvSnapshot
Deploy-Fixtures -Bench:$false
$session = Invoke-ServerSession -Tag 'visibility' -OnDone {
    param($proc, $outLog, $sw)
    $listeners = @(Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 25871)
    if ($listeners.Count -ne 1) { throw 'Expected one owned game listener' }
    $gameId = $listeners[0].OwningProcess
    $gameProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$gameId"
    if ($gameProcess.Name -ne 'java.exe' -or $gameProcess.ExecutablePath -ne "$javaRoot\bin\java.exe" -or -not $gameProcess.CommandLine.Contains($ProjectDir)) { throw 'Unexpected game process' }
    @{pid=$gameId;launcher=$proc.Id;revision='6e5bb8f00c3747b828056589853cb0471477b18a'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $diagnosticRoot 'jvm.json')
    $monitorInfo = New-Object System.Diagnostics.ProcessStartInfo
    $monitorInfo.FileName = 'python.exe'
    $monitorInfo.Arguments = '"D:\mcmodDemo\NekoJS-mult\build\priority-closeout\visibility-monitor.py" "' + $outLog + '" "' + (Join-Path $diagnosticRoot 'visibility-stderr.log') + '" "' + $diagnosticRoot + '"'
    $monitorInfo.UseShellExecute = $false
    $monitorInfo.CreateNoWindow = $true
    $monitorInfo.RedirectStandardOutput = $true
    $monitorInfo.RedirectStandardError = $true
    $monitor = [System.Diagnostics.Process]::Start($monitorInfo)
    $monitorOutput = $monitor.StandardOutput.ReadToEnd()
    $monitorError = $monitor.StandardError.ReadToEnd()
    $monitor.WaitForExit()
    Set-Content -LiteralPath (Join-Path $diagnosticRoot 'monitor-stdout.log') -Value $monitorOutput
    Set-Content -LiteralPath (Join-Path $diagnosticRoot 'monitor-stderr.log') -Value $monitorError
    $stop = Stop-Server $proc
    if ($monitor.ExitCode -ne 0) { throw 'Visibility diagnostic failed; see preserved monitor logs' }
    @{stopSent=$true;stopChannel=$stop.channel;killed=$stop.killed}
}
$session | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $diagnosticRoot 'session.json')
if ($session.forcedKill -or $session.extra.killed -or $session.extra.stopChannel -ne 'rcon') { throw 'Diagnostic stop was not normal' }
Write-Output 'VISIBILITY_DIAGNOSTIC_COMPLETE'
'''
(tools / 'visibility.ps1').write_text(controller, encoding='utf-8')
runner = (tools / 'run-diagnostic-current.py').read_text(encoding='utf-8').replace('diagnostic-current', 'visibility')
(tools / 'run-visibility.py').write_text(runner, encoding='utf-8')
print('VISIBILITY_DIAGNOSTIC_PREPARED')
