$ErrorActionPreference = 'Stop'
$env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
$ProjectDir = 'C:\Users\11515\.codex\worktrees\domain-perf-0965\NekoJS-mult'
$diagnosticRoot = 'D:\mcmodDemo\NekoJS-mult\build\priority-closeout\diagnostic-visibility-sinks-6e5bb8f0'
$javaRoot = 'C:\Program Files\Java\jdk-25.0.2'
$env:JAVA_HOME = $javaRoot
$env:PATH = "$javaRoot\bin;$env:PATH"
$Node = '26.1.2'
$GradleUserHome = 'D:\mcmodDemo\NekoJS\.gradle-<REDACTED-RCON-CREDENTIAL>'
$ServerPort = 25871
$RconPort = 25872
$RconPass = $env:NEKO_PERF_RCON_PASS
$RunDir = Join-Path $ProjectDir 'versions\26.1.2\run'
$FixtureDir = Join-Path $ProjectDir 'bench\perf\fixtures\nekojs'
$OutDir = $diagnosticRoot
$perfOut = Join-Path $RunDir 'nekojs\perf-out'
$script:StdinOk = $null
$script:TestStdin = $false
if (Test-Path -LiteralPath $diagnosticRoot) { throw 'Diagnostic evidence already exists' }
if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 25871,25872).Count -ne 0) { throw 'Diagnostic ports occupied' }
if ((& git -C $ProjectDir rev-parse HEAD).Trim() -ne '6e5bb8f00c3747b828056589853cb0471477b18a') { throw 'Diagnostic source mismatch' }
$changedFiles = @(& git -C $ProjectDir diff --name-only)
if ($changedFiles.Count -ne 1) { throw "Unexpected diagnostic diff" }
$checkedPath = Get-Item -LiteralPath $RunDir
while ($null -ne $checkedPath) {
    if (($checkedPath.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Diagnostic run path has reparse point' }
    $checkedPath = $checkedPath.Parent
}
New-Item -ItemType Directory -Path $diagnosticRoot | Out-Null
$changedFiles | ForEach-Object { @{path=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $ProjectDir $_)).Hash} } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $diagnosticRoot 'source-hashes.json')
$sampleDirectory = Join-Path $ProjectDir 'bench\perf'
$samplePath = Join-Path $sampleDirectory 'sample.ps1'
$parseTokens = $null
$parseErrors = $null
$sampleAst = [Management.Automation.Language.Parser]::ParseFile($samplePath, [ref]$parseTokens, [ref]$parseErrors)
if ($parseErrors.Count -ne 0) { throw 'Sampler parse failed' }
$functionNodes = $sampleAst.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst]}, $false)
foreach ($functionNode in $functionNodes) {
    $functionText = $functionNode.Extent.Text.Replace('$PSScriptRoot', "'$sampleDirectory'")
    . ([ScriptBlock]::Create($functionText))
}
function Invoke-Rcon {
    param([string]$Command, [int]$TimeoutMs = 180000)
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = 'python.exe'
    $startInfo.Arguments = '"' + (Join-Path $sampleDirectory 'rcon.py') + '" ' + $RconPort + ' "' + $RconPass + '" ' + ($TimeoutMs / 1000) + ' "' + $Command + '"'
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $client = [System.Diagnostics.Process]::Start($startInfo)
    $output = $client.StandardOutput.ReadToEnd()
    $errorOutput = $client.StandardError.ReadToEnd()
    $client.WaitForExit()
    if ($client.ExitCode -ne 0) { throw "Diagnostic RCON failed: $errorOutput" }
    return $output.Trim()
}

Write-EnvSnapshot
Deploy-Fixtures -Bench:$false
$session = Invoke-ServerSession -Tag 'visibility' -OnDone {
    param($proc, $outLog, $sw)
    $listeners = @(Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 25871)
    if ($listeners.Count -ne 1) { throw 'Expected one owned game listener' }
    $gameId = $listeners[0].OwningProcess
    $gameProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$gameId"
    if ($gameProcess.Name -ne 'java.exe' -or $gameProcess.ExecutablePath -ne "$javaRoot\bin\java.exe" -or -not $gameProcess.CommandLine.Contains($ProjectDir)) { throw 'Unexpected game process' }
    @{pid=$gameId;launcher=$proc.Id;revision='6e5bb8f00c3747b828056589853cb0471477b18a'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $diagnosticRoot 'jvm.json')
    $monitorInfo = New-Object System.Diagnostics.ProcessStartInfo
    $monitorInfo.FileName = 'python.exe'
    $monitorInfo.Arguments = '"D:\mcmodDemo\NekoJS-mult\build\priority-closeout\visibility-monitor-sinks.py" "' + $outLog + '" "' + (Join-Path $diagnosticRoot 'visibility-stderr.log') + '" "' + $diagnosticRoot + '"'
    $monitorInfo.UseShellExecute = $false
    $monitorInfo.CreateNoWindow = $true
    $monitorInfo.RedirectStandardOutput = $true
    $monitorInfo.RedirectStandardError = $true
    $monitor = [System.Diagnostics.Process]::Start($monitorInfo)
    $monitorOutput = $monitor.StandardOutput.ReadToEnd()
    $monitorError = $monitor.StandardError.ReadToEnd()
    $monitor.WaitForExit()
    Set-Content -LiteralPath (Join-Path $diagnosticRoot 'monitor-stdout.log') -Value $monitorOutput
    Set-Content -LiteralPath (Join-Path $diagnosticRoot 'monitor-stderr.log') -Value $monitorError
    $stop = Stop-Server $proc
    if ($monitor.ExitCode -ne 0) { throw 'Visibility diagnostic failed; see preserved monitor logs' }
    @{stopSent=$true;stopChannel=$stop.channel;killed=$stop.killed}
}
$session | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $diagnosticRoot 'session.json')
if ($session.forcedKill -or $session.extra.killed -or $session.extra.stopChannel -ne 'rcon') { throw 'Diagnostic stop was not normal' }
Write-Output 'VISIBILITY_DIAGNOSTIC_COMPLETE'
