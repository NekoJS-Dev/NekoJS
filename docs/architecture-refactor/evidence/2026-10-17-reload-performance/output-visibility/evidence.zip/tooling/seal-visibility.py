import hashlib
import importlib.util
import json
import sys
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
target = project/'docs/architecture-refactor/evidence/2026-10-17-reload-performance/output-visibility'
spec = importlib.util.spec_from_file_location('visibility_verifier', target/'verify.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
properties = dict(line.split('=', 1) for line in Path(
    'C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run/server.properties'
).read_text().splitlines() if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password'].encode()
files, redactions = {}, {}


def add(file, name):
    data = file.read_bytes()
    assert file.suffix != '.jfr' and name not in files
    if secret in data:
        redactions[name] = dict(originalSha256=hashlib.sha256(data).hexdigest(), occurrences=data.count(secret))
        data = data.replace(secret, b'<REDACTED-RCON-CREDENTIAL>')
    files[name] = data


for label, directory in [('command-control', 'diagnostic-visibility-6e5bb8f0'),
                         ('three-sinks', 'diagnostic-visibility-sinks-6e5bb8f0')]:
    output = tools/directory
    rows = json.loads((output/'observations.json').read_text())
    recomputed = module.summarize(rows)
    (output/'recomputed.json').write_text(json.dumps(recomputed, indent=2)+'\n')
    for file in output.iterdir():
        if file.is_file():
            add(file, label+'/'+file.name)
for file in tools.iterdir():
    if file.is_file() and 'visibility' in file.name:
        add(file, 'tooling/'+file.name)
add(project/'bench/perf/sample.ps1', 'tooling/original-sample.ps1')
add(project/'bench/perf/rcon.py', 'tooling/original-rcon.py')
original_sampler_sha = hashlib.sha256((project/'bench/perf/sample.ps1').read_bytes()).hexdigest()
assert original_sampler_sha == '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
files['redactions.json'] = (json.dumps(redactions, indent=2)+'\n').encode()
source = json.loads((tools/'visibility-source-manifest.json').read_text())
packed = target/'evidence.zip'
assert not packed.exists()
with zipfile.ZipFile(packed, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
manifest = dict(diagnosticOnly=True, revision=source['revision'], originalSourceSha256=source['originalSha256'],
    diagnosticSourceSha256=source['diagnosticSha256'],
    originalSamplerSha256=original_sampler_sha,
    archivedSamplerSha256=hashlib.sha256(files['tooling/original-sample.ps1']).hexdigest(),
    archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
    entries={name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(entries=len(files), zipBytes=packed.stat().st_size, archiveSha256=manifest['archiveSha256'])))
