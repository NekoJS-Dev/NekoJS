import hashlib
import json
import os
import socket
import subprocess
import time
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
worktree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
run = repo / 'build/priority-closeout/2026-10-20-24d35a5d-verification'
revision = '24d35a5d6ddc30f68c9719d9eb25c0ce898f8398'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip().startswith('46505ad2')
for port in [25871, 25872]:
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', port))
subprocess.run(['git', 'switch', '-c', 'codex/perf-final-24d35a5d', revision], cwd=worktree, check=True)
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME']+'/bin;'+environment['PATH']
args = [str(worktree/'gradlew.bat'), '-g', 'D:/mcmodDemo/NekoJS/.gradle-perf02',
        '-Dorg.gradle.java.home=C:/Program Files/Java/jdk-25.0.2', '--offline', '--no-parallel', '--console=plain',
        ':26.1.2:classes', ':26.1.2:jar', ':26.1.2:prepareServerRun']
start = time.monotonic()
with (run/'performance-prepare.log').open('xb') as output:
    code = subprocess.run(args, cwd=worktree, env=environment, stdout=output, stderr=subprocess.STDOUT,
                          creationflags=subprocess.CREATE_NO_WINDOW).returncode
result = dict(commit=revision, exitCode=code, seconds=round(time.monotonic()-start, 3), arguments=args)
(run/'performance-prepare-result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
assert code == 0, result

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def classes(root):
    out = {}
    for directory in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
        target = root/directory
        for path in sorted(target.rglob('*.class')):
            key = path.relative_to(target).as_posix()
            assert key not in out, key
            out[key] = digest(path)
    return out

main_classes, measured_classes = classes(repo), classes(worktree)
assert len(main_classes) > 1500 and main_classes == measured_classes
main_jars = list((repo/'versions/26.1.2/build/libs').glob('*.jar'))
measured_jars = list((worktree/'versions/26.1.2/build/libs').glob('*.jar'))
assert len(main_jars) == len(measured_jars) == 1
assert digest(main_jars[0]) == digest(measured_jars[0])
binding = dict(revision=revision, classesMatch=True, classCount=len(main_classes),
               classBindings=main_classes, jarsMatch=True, jarSha256=digest(main_jars[0]),
               artifactName=main_jars[0].name, bytes=main_jars[0].stat().st_size)
(run/'performance-source-binding.json').write_text(json.dumps(binding, indent=2)+'\n', encoding='utf-8')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
print(json.dumps(dict(preparation=result, classCount=len(main_classes), classesMatch=True,
                     jarsMatch=True, jarSha256=binding['jarSha256'])))
