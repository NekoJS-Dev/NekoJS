import gzip
import hashlib
import io
import json
import re
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

project=Path.cwd()
destination=project/'docs/architecture-refactor/evidence/ticket37-892-installed-validation'
archive_path=destination/'installed-evidence.zip'
assert not archive_path.exists()
sha=lambda data: hashlib.sha256(data).hexdigest()
files={}
secrets=[]
runs=[]
for name in ['ticket37-892-installed','ticket37-892-sam-installed']:
    trial=project/'build'/name
    preparation=json.loads((trial/'preparation-manifest.json').read_text(encoding='utf-8'))
    artifacts=[]
    for record in preparation['nodes']:
        node=record['node']
        server=trial/node
        exit_record=json.loads((server/'server-exit.json').read_text())
        assert exit_record['exitCode']==0
        for line in (server/'server.properties').read_text().splitlines():
            if line.startswith('rcon.password='):
                secrets.append(line.partition('=')[2].encode())
        jars=list((server/'mods').glob('nekojs-*.jar'))
        assert len(jars)==1
        assert sha(jars[0].read_bytes())==record['sha256']
        artifacts.append(dict(node=node,file=jars[0].name,sha256=record['sha256'],exit=exit_record))
        for path in server.iterdir():
            if path.is_file() and (path.name.startswith(('owned-','server-','runtime-','command-')) or path.name=='pyrightconfig.json'):
                files[path.relative_to(project/'build').as_posix()]=path
        for directory in ['logs','nekojs','.neko_probe','crash-reports']:
            for path in (server/directory).rglob('*'):
                if path.is_file() and path.suffix in ['.json','.log','.txt','.gz','.js','.mjs','.ts','.pyi','.md','.toml','.typed']:
                    files[path.relative_to(project/'build').as_posix()]=path
    for path in trial.iterdir():
        if path.is_file() and path.suffix in ['.json','.patch','.zip']:
            files[path.relative_to(project/'build').as_posix()]=path
    for path in (trial/'ide').rglob('*'):
        if path.is_file(): files[path.relative_to(project/'build').as_posix()]=path
    ide=json.loads((trial/'ide/summary.json').read_text(encoding='utf-8'))
    if name=='ticket37-892-installed':
        ide['nodes'][0]['typescriptAcceptance']='BLOCKED: generation failed; empty projects exited 0 but are not PASS'
    runs.append(dict(profile=name,sourceBase=preparation['sourceRevision'],productionPatchSha256=preparation.get('productionPatchSha256'),artifacts=artifacts,runtime=json.loads((trial/'runtime-summary.json').read_text(encoding='utf-8')),matrix=json.loads((trial/'matrix-summary.json').read_text(encoding='utf-8')),ide=ide))
repair=project/'build/ticket37-config-sync-repair'
for path in repair.glob('*892*'):
    if path.is_file() and path.suffix in ['.py','.txt','.xml','.json','.patch']:
        files['runner/'+path.name]=path
for name in ['run-other-nodes.py','prove-python-member-candidate.py','parse-ts-member-declarations.cjs']:
    files['runner/'+name]=repair/name
source_names=['common/src/main/java/com/tkisor/nekojs/probe/backend/typescript/FunctionalInterfaceAliasGenerator.java','common/src/main/java/com/tkisor/nekojs/core/reflect/FunctionalInterfaceResolver.java','common/src/test/java/com/tkisor/nekojs/probe/ProbeLinkageFixture.java','common/src/test/java/com/tkisor/nekojs/probe/ProbeUnavailableTypeTest.java']
for name in source_names:
    files['source/repair/'+name]=project/name
patch=subprocess.check_output(['git','diff','8922627e','--']+source_names)

def scan(data,suffix):
    if suffix=='.gz': return scan(gzip.decompress(data),'')
    if suffix=='.zip':
        with ZipFile(io.BytesIO(data)) as nested:
            for name in nested.namelist(): scan(nested.read(name),Path(name).suffix)
        return
    assert not any(secret and secret in data for secret in secrets),'Credential value in evidence'
    assert not re.search(rb'(?m)^rcon\.password=',data),'Credential line in evidence'

entries=[]
with ZipFile(archive_path,'x',ZIP_DEFLATED) as archive:
    def add(name,data):
        scan(data,Path(name).suffix)
        archive.writestr(name,data)
        entries.append(dict(path=name,bytes=len(data),sha256=sha(data)))
    for name,path in sorted(files.items()): add(name,path.read_bytes())
    for name in source_names:
        add('source/baseline/'+name,subprocess.check_output(['git','show','8922627e:'+name]))
    add('source/repair.patch',patch)
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in entries: assert sha(archive.read(record['path']))==record['sha256']
manifest=dict(sourceBase='8922627e75f903fb8efbbbf7ceb89dd51b1f50d0',repairWipAtBuild=True,fullSourcePatchSha256=sha(patch),runs=runs,archive=dict(file=archive_path.name,entries=len(entries),bytes=archive_path.stat().st_size,sha256=sha(archive_path.read_bytes())),entries=entries,independentReviews=dict(Standards='0 findings; read-only',Spec='0 findings; read-only'),exclusions=['server.properties/RCON secrets','worlds','accounts/launcher data','binaries/libraries','raw JFR'])
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for run in runs:
    prefix='baseline' if run['profile']=='ticket37-892-installed' else 'repair'
    (destination/(prefix+'-summary.json')).write_text(json.dumps({k:v for k,v in run.items() if k!='artifacts'},indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archive=manifest['archive'],fullSourcePatchSha256=sha(patch),matrix=[run['matrix']['total'] for run in runs])))
