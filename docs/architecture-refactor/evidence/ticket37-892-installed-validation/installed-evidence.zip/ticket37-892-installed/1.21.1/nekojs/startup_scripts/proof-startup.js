RegistryEvents.register(event => {
    event.soundEvent('installed_ec7:nullable', build => { build.fixedRange = null; });
    event.soundEvent('installed_ec7:named', 'basic', build => { build.setFixedRange(null); });
    event.item('installed_ec7:token', build => { build.maxStackSize = 16; });
    event.block('installed_ec7:stone', build => { build.item.maxStackSize = 16; });
    event.block('installed_ec7:no_item', build => { build.noItem(); });
    event.fluid('installed_ec7:spring', build => { build.lightLevel = 5; });
    event.fluid('installed_ec7:bare', build => { build.noBlock(); build.noBucket(); });
    console.info('EC7-INSTALLED-STARTUP-CALLBACKS-PASS');
});
