const Location = Java.type('net.minecraft.resources.ResourceLocation');
const builtin = Java.type('net.minecraft.core.registries.BuiltInRegistries');
const checks = [["minecraft:sound_event", "nullable", true], ["minecraft:sound_event", "named", true], ["minecraft:item", "token", true], ["minecraft:block", "stone", true], ["minecraft:item", "stone", true], ["minecraft:block", "no_item", true], ["minecraft:item", "no_item", false], ["minecraft:fluid", "spring", true], ["minecraft:fluid", "flowing_spring", true], ["minecraft:block", "spring", true], ["minecraft:item", "spring_bucket", true], ["minecraft:fluid", "bare", true], ["minecraft:block", "bare", false], ["minecraft:item", "bare_bucket", false]];
for (const check of checks) {
    const registry = builtin.REGISTRY.get(Location.parse(check[0]));
    if (registry.containsKey(Location.parse('installed_ec7:' + check[1])) !== check[2]) {
        throw new Error('Installed registration mismatch: ' + check[0] + '/' + check[1]);
    }
}
console.info('EC7-INSTALLED-REGISTRATIONS-PASS checks=' + checks.length);
const BlockBuilder = Java.type('com.tkisor.nekojs.wrapper.registry.gen.BlockBuilder');
const Surface = Java.type('com.tkisor.nekojs.wrapper.registry.gen.BuilderSurface');
const Fingerprints = Java.type('com.tkisor.nekojs.wrapper.registry.gen.StartupRegistryRuntime');
const propertyBuilder = new BlockBuilder(Location.parse('installed_ec7:fingerprint_only'));
const setterBuilder = new BlockBuilder(Location.parse('installed_ec7:fingerprint_only'));
const propertySurface = Surface.of(propertyBuilder);
const setterSurface = Surface.of(setterBuilder);
propertySurface.item.maxStackSize = 16;
setterSurface.item.setMaxStackSize(16);
const fingerprints = new Fingerprints('owned-installed-fingerprint');
const propertyFingerprint = fingerprints.definitionFingerprint(propertyBuilder);
const setterFingerprint = fingerprints.definitionFingerprint(setterBuilder);
if (propertyFingerprint !== setterFingerprint) throw new Error('Actual nested builder fingerprints differ');
setterSurface.item.maxStackSize = 15;
const changedFingerprint = fingerprints.definitionFingerprint(setterBuilder);
if (propertyFingerprint === changedFingerprint) throw new Error('Nested mutation is absent from the actual fingerprint');
console.info('EC7-INSTALLED-NESTED-FINGERPRINT-PASS property=' + propertyFingerprint
    + ' setter=' + setterFingerprint + ' changed=' + changedFingerprint);
const neoRegistries = Java.type('net.neoforged.neoforge.registries.NeoForgeRegistries');
const sourceFluid = builtin.FLUID.get(Location.parse('installed_ec7:spring'));
const flowingFluid = builtin.FLUID.get(Location.parse('installed_ec7:flowing_spring'));
const registeredType = neoRegistries.FLUID_TYPES.get(Location.parse('installed_ec7:spring'));
if (!sourceFluid.getFluidType().equals(registeredType) || !flowingFluid.getFluidType().equals(registeredType)) {
    throw new Error('Source, flowing and registered FluidType identities differ');
}
console.info('EC7-INSTALLED-FLUIDTYPE-IDENTITY-PASS source=true flowing=true');
