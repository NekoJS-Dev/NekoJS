import { $Optional, $OptionalView } from "java:java/util";

declare module "java:com/tkisor/nekojs/probe" {
    export class $ProbeCaptureReturnContractTest$Base {
        constructor(label: string);
        label: string;
    }

    export class $ProbeCaptureReturnContractTest$Child extends $ProbeCaptureReturnContractTest$Base {
        constructor();
        code: number;
    }

    export interface $ProbeCaptureReturnContractTest$Parent<T> {
        values(): $OptionalView<T>;
    }

    export interface $ProbeCaptureReturnContractTest$Middle<U> extends $ProbeCaptureReturnContractTest$Parent<U> {
    }

    export class $ProbeCaptureReturnContractTest$Implementation implements $ProbeCaptureReturnContractTest$Middle<$ProbeCaptureReturnContractTest$Base> {
        constructor();
        values(): $Optional<$ProbeCaptureReturnContractTest$Child>;
    }

    export class $ProbeCaptureReturnContractTest$RepeatedOverride extends $ProbeCaptureReturnContractTest$Implementation {
        constructor();
        values(): $Optional<$ProbeCaptureReturnContractTest$Child>;
    }

    export class $ProbeCaptureReturnContractTest$WildcardOverride implements $ProbeCaptureReturnContractTest$Middle<$ProbeCaptureReturnContractTest$Base> {
        constructor();
        values(): $OptionalView<$ProbeCaptureReturnContractTest$Child>;
    }

    export interface $ProbeCaptureReturnContractTest$ParameterParent<T> {
        values(input: T[]): $OptionalView<T>;
        values(input: T): $OptionalView<T>;
    }

    export class $ProbeCaptureReturnContractTest$ParameterImplementation implements $ProbeCaptureReturnContractTest$ParameterParent<$ProbeCaptureReturnContractTest$Base> {
        constructor();
        values(input: $ProbeCaptureReturnContractTest$Base[]): $Optional<$ProbeCaptureReturnContractTest$Child>;
        values(input: $ProbeCaptureReturnContractTest$Base): $Optional<$ProbeCaptureReturnContractTest$Child>;
        values(input: number): $Optional<string>;
    }

    export class $ProbeCaptureReturnContractTest$MethodBase {
        constructor();
        values(input: $ProbeCaptureReturnContractTest$Base[]): $Optional<$ProbeCaptureReturnContractTest$Child>;
        values(input: $ProbeCaptureReturnContractTest$Base): $Optional<$ProbeCaptureReturnContractTest$Child>;
    }

    export class $ProbeCaptureReturnContractTest$InheritedImplementation extends $ProbeCaptureReturnContractTest$MethodBase implements $ProbeCaptureReturnContractTest$ParameterParent<$ProbeCaptureReturnContractTest$Base> {
        constructor();
        values(input: $ProbeCaptureReturnContractTest$Base[]): $Optional<$ProbeCaptureReturnContractTest$Child>;
        values(input: $ProbeCaptureReturnContractTest$Base): $Optional<$ProbeCaptureReturnContractTest$Child>;
    }

    export type $ProbeCaptureReturnContractTest$Parent_<Host0 = any, CallbackResult = $Optional<Host0>> = (() => CallbackResult) | ($ProbeCaptureReturnContractTest$Parent<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "values": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $ProbeCaptureReturnContractTest$Middle_<Host0 = any, CallbackResult = $Optional<Host0>> = (() => CallbackResult) | ($ProbeCaptureReturnContractTest$Middle<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "values": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
