from pathlib import Path
from collections import Counter
import shutil,subprocess,re,json,tempfile
base=Path('common/build/probe-ts-capture-return-contract');out=Path(tempfile.mkdtemp(prefix='capture-return-no-facets-',dir='build'))
shutil.copytree(base,out,dirs_exist_ok=True)
for p in out.glob('@package/**/index.d.ts'):
 s=p.read_text(encoding='utf8');s=re.sub(r' & \$OptionalView<[^;\n]+>(?=;)','',s);p.write_text(s,encoding='utf8')
r=subprocess.run(['node','node_modules/typescript/bin/tsc','-p',str(out/'tsconfig.json')],capture_output=True,timeout=120)
(out/'tsc.txt').write_bytes(r.stdout);(out/'tsc-stderr.txt').write_bytes(r.stderr)
codes=dict(Counter(re.findall(r': error (TS\d+):',r.stdout.decode('utf8'))));record={'exitCode':r.returncode,'errorCodes':codes,'kind':'generated-declaration mutation control; only capture facets removed'}
(out/'summary.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(record);print(r.stdout.decode('utf8'))
assert r.returncode==2 and codes.get('TS2345',0)>=2 and not r.stderr
Path('build/capture-return-mutation-latest.json').write_text(json.dumps({'path':str(out.resolve()),**record},indent=2)+'\n',encoding='utf8')
