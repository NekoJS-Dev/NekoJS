from pathlib import Path
from zipfile import ZipFile
import re,json
changed=[];returns=0;imports=0
with ZipFile('build/capture-return-goldens-before.zip') as z:
 for n in z.namelist():
  p=Path(n);old=z.read(n);new=p.read_bytes()
  if old==new:continue
  a=old.decode('utf8').splitlines();b=new.decode('utf8').splitlines();assert len(a)==len(b),n
  for x,y in zip(a,b):
   if x==y:continue
   if x.startswith('import '):
    assert y.startswith('import ') and x.split(' from ')[1]==y.split(' from ')[1],(x,y)
    oldnames=set(x[x.index('{')+1:x.index('}')].strip().split(', '));newnames=set(y[y.index('{')+1:y.index('}')].strip().split(', '));assert oldnames<=newnames and newnames-oldnames <= {'$OptionalView','$ConstantDesc','$ConstantDesc_'},(x,y)
    imports+=1
   else:
    assert x.endswith(';') and re.match(r'\s+describeConstable\(\): \$Optional<',x),(x,y)
    assert y==x[:-1]+' & $OptionalView<(number | string | $ConstantDesc)>;',(x,y)
    returns+=1
  changed.append(n)
assert len(changed)==2 and returns==10 and imports==3,(changed,returns,imports)
result={'changedFiles':changed,'narrowReturnsRetainedWithFacet':returns,'importLines':imports,'allOtherBytesUnchanged':True};Path('build/capture-return-golden-diff.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(result)
