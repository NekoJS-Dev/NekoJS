declare class $Duration { static toString(): string; }
declare class $Instant { static toString(): string; }
export { $Duration, $Instant };
