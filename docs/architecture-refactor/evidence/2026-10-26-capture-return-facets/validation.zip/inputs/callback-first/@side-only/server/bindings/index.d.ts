// Bindings for server scripts
import { $ProbeWildcardOptionalCaptureTest$BooleanLike, $ProbeWildcardOptionalCaptureTest$ConstableLike } from "java:com/tkisor/nekojs/probe";

export {};

declare global {
    let ConstableLike: $ProbeWildcardOptionalCaptureTest$ConstableLike;
    let BooleanLike: $ProbeWildcardOptionalCaptureTest$BooleanLike;
}
