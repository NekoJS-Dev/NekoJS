import type { $BinaryOperator } from "java:java/util/function";
import type { $BinaryOperator_ } from "java:java/util/function";
import { $InputStream, $OutputStream, $PrintStream, $PrintWriter, $Reader, $Serializable, $Writer } from "java:java/io";
import { $Cloneable, $Comparable, $Comparable_, $Enum, $Iterable, $Runnable, $Runnable_, $Throwable } from "java:java/lang";
import { $Charset } from "java:java/nio/charset";
import { $Instant } from "java:java/time";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $Consumer, $Consumer_, $DoubleConsumer, $DoubleConsumer_, $DoubleSupplier, $DoubleSupplier_, $Function, $Function_, $IntConsumer, $IntConsumer_, $IntFunction, $IntFunction_, $IntSupplier, $IntSupplier_, $LongConsumer, $LongConsumer_, $LongSupplier, $LongSupplier_, $Predicate, $Predicate_, $Supplier, $Supplier_, $ToDoubleFunction, $ToDoubleFunction_, $ToIntFunction, $ToIntFunction_, $ToLongFunction, $ToLongFunction_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $DoubleStream, $IntStream, $LongStream, $Stream, $StreamView } from "java:java/util/stream";

export * as function from "java:java/util/function";
export * as stream from "java:java/util/stream";
export * as concurrent from "java:java/util/concurrent";

declare module "java:java/util" {
    export class $Optional<T> {
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        static empty<T>(): $Optional<T>;
        static ofNullable<T>(arg0: T): $Optional<T>;
        static of<T>(arg0: T): $Optional<T>;
        equals(arg0: unknown): boolean;
        filter(arg0: $Predicate_<T, T, boolean>): $Optional<T>;
        flatMap<U>(arg0: $Function_<T, $Optional<U>, T, $Optional<U>>): $Optional<U>;
        get(): T;
        hashCode(): number;
        ifPresentOrElse(arg0: $Consumer_<T, T>, arg1: $Runnable_): void;
        ifPresent(arg0: $Consumer_<T, T>): void;
        map<U>(arg0: $Function_<T, U, T, U>): $Optional<U>;
        orElseGet(arg0: $Supplier_<T, T>): T;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): T;
        orElseThrow(): T;
        orElse(arg0: T): T;
        or(arg0: $Supplier_<$Optional<T>, $Optional<T>>): $Optional<T>;
        stream(): $Stream<T>;
        toString(): string;
    }

    export class $Locale implements $Cloneable, $Serializable {
        constructor(arg0: string);
        constructor(arg0: string, arg1: string);
        constructor(arg0: string, arg1: string, arg2: string);
        static CANADA: $Locale;
        static CANADA_FRENCH: $Locale;
        static CHINA: $Locale;
        static CHINESE: $Locale;
        static ENGLISH: $Locale;
        static FRANCE: $Locale;
        static FRENCH: $Locale;
        static GERMAN: $Locale;
        static GERMANY: $Locale;
        static ITALIAN: $Locale;
        static ITALY: $Locale;
        static JAPAN: $Locale;
        static JAPANESE: $Locale;
        static KOREA: $Locale;
        static KOREAN: $Locale;
        static PRC: $Locale;
        static PRIVATE_USE_EXTENSION: string;
        static ROOT: $Locale;
        static SIMPLIFIED_CHINESE: $Locale;
        static TAIWAN: $Locale;
        static TRADITIONAL_CHINESE: $Locale;
        static UK: $Locale;
        static UNICODE_LOCALE_EXTENSION: string;
        static US: $Locale;
        get country(): string;
        getCountry(): string;
        get displayCountry(): string;
        getDisplayCountry(): string;
        get displayLanguage(): string;
        getDisplayLanguage(): string;
        get displayName(): string;
        getDisplayName(): string;
        get displayScript(): string;
        getDisplayScript(): string;
        get displayVariant(): string;
        getDisplayVariant(): string;
        get extensionKeys(): $Set<string>;
        getExtensionKeys(): $Set<string>;
        get iSO3Country(): string;
        getISO3Country(): string;
        get iSO3Language(): string;
        getISO3Language(): string;
        get language(): string;
        getLanguage(): string;
        get script(): string;
        getScript(): string;
        get unicodeLocaleAttributes(): $Set<string>;
        getUnicodeLocaleAttributes(): $Set<string>;
        get unicodeLocaleKeys(): $Set<string>;
        getUnicodeLocaleKeys(): $Set<string>;
        get variant(): string;
        getVariant(): string;
        static availableLocales(): $Stream<$Locale>;
        static caseFoldLanguageTag(arg0: string): string;
        static filterTags(arg0: ($List<$Locale$LanguageRange> | ($Locale$LanguageRange)[]), arg1: ($Collection<string> | (string)[]), arg2: $Locale$FilteringMode_): $List<string>;
        static filterTags(arg0: ($List<$Locale$LanguageRange> | ($Locale$LanguageRange)[]), arg1: ($Collection<string> | (string)[])): $List<string>;
        static filter(arg0: ($List<$Locale$LanguageRange> | ($Locale$LanguageRange)[]), arg1: ($Collection<$Locale> | ($Locale)[]), arg2: $Locale$FilteringMode_): $List<$Locale>;
        static filter(arg0: ($List<$Locale$LanguageRange> | ($Locale$LanguageRange)[]), arg1: ($Collection<$Locale> | ($Locale)[])): $List<$Locale>;
        static forLanguageTag(arg0: string): $Locale;
        static getAvailableLocales(): $Locale[];
        static getDefault(arg0: $Locale$Category_): $Locale;
        static getDefault(): $Locale;
        static getISOCountries(arg0: $Locale$IsoCountryCode_): $Set<string>;
        static getISOCountries(): string[];
        static getISOLanguages(): string[];
        static lookupTag(arg0: ($List<$Locale$LanguageRange> | ($Locale$LanguageRange)[]), arg1: ($Collection<string> | (string)[])): string;
        static lookup(arg0: ($List<$Locale$LanguageRange> | ($Locale$LanguageRange)[]), arg1: ($Collection<$Locale> | ($Locale)[])): $Locale;
        static of(arg0: string, arg1: string, arg2: string): $Locale;
        static of(arg0: string, arg1: string): $Locale;
        static of(arg0: string): $Locale;
        static setDefault(arg0: $Locale$Category_, arg1: $Locale): void;
        static setDefault(arg0: $Locale): void;
        clone(): unknown;
        equals(arg0: unknown): boolean;
        getDisplayCountry(arg0: $Locale): string;
        getDisplayLanguage(arg0: $Locale): string;
        getDisplayName(arg0: $Locale): string;
        getDisplayScript(arg0: $Locale): string;
        getDisplayVariant(arg0: $Locale): string;
        getExtension(arg0: string): string;
        getUnicodeLocaleType(arg0: string): string;
        hasExtensions(): boolean;
        hashCode(): number;
        stripExtensions(): $Locale;
        toLanguageTag(): string;
        toString(): string;
    }

    export interface $Set<E> extends $Collection<E> {
        addAll(arg0: ($Collection<E> | (E)[])): boolean;
        add(arg0: E): boolean;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $Iterator<E>;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        remove(arg0: unknown): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }
    export const $Set: {
        copyOf<E>(arg0: ($Collection<E> | (E)[])): $Set<E>;
        of<E>(arg0?: E[]): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E, arg9: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E): $Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E): $Set<E>;
        of<E>(arg0: E, arg1: E): $Set<E>;
        of<E>(arg0: E): $Set<E>;
        of<E>(): $Set<E>;
    };

    export interface $Enumeration<E> {
        asIterator(): $Iterator<E>;
        hasMoreElements(): boolean;
        nextElement(): E;
    }

    export interface $List<E> extends $SequencedCollection<E> {
        addAll(arg0: number, arg1: ($Collection<E> | (E)[])): boolean;
        addAll(arg0: ($Collection<E> | (E)[])): boolean;
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        add(arg0: E): boolean;
        add(arg0: number, arg1: E): void;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        getFirst(): E;
        getLast(): E;
        get(arg0: number): E;
        hashCode(): number;
        indexOf(arg0: unknown): number;
        isEmpty(): boolean;
        iterator(): $Iterator<E>;
        lastIndexOf(arg0: unknown): number;
        listIterator(arg0: number): $ListIterator<E>;
        listIterator(): $ListIterator<E>;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeFirst(): E;
        removeLast(): E;
        remove(arg0: number): E;
        remove(arg0: unknown): boolean;
        replaceAll(arg0: $UnaryOperator_<E, E, E>): void;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        reversed(): $List<E>;
        set(arg0: number, arg1: E): E;
        size(): number;
        sort(arg0: $Comparator_<E, E, E, number>): void;
        spliterator(): $Spliterator<E>;
        subList(arg0: number, arg1: number): $List<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }
    export const $List: {
        copyOf<E>(arg0: ($Collection<E> | (E)[])): $List<E>;
        of<E>(arg0?: E[]): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E, arg9: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E): $List<E>;
        of<E>(arg0: E, arg1: E, arg2: E): $List<E>;
        of<E>(arg0: E, arg1: E): $List<E>;
        of<E>(arg0: E): $List<E>;
        of<E>(): $List<E>;
    };

    export interface $Collection<E> extends $Iterable<E> {
        addAll(arg0: ($Collection<E> | (E)[])): boolean;
        add(arg0: E): boolean;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        remove(arg0: unknown): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export interface $Map<K, V> {
        clear(): void;
        computeIfAbsent(arg0: K, arg1: $Function_<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: unknown): boolean;
        containsValue(arg0: unknown): boolean;
        entrySet(): $Set<$Map$Entry<K, V>>;
        equals(arg0: unknown): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: unknown, arg1: V): V;
        get(arg0: unknown): V;
        hashCode(): number;
        isEmpty(): boolean;
        keySet(): $Set<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(arg0: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): void;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: unknown, arg1: unknown): boolean;
        remove(arg0: unknown): V;
        replaceAll(arg0: $BiFunction_<K, V, V, K, V, V>): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        values(): $Collection<V>;
    }
    export const $Map: {
        copyOf<K, V>(arg0: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): $Map<K, V>;
        entry<K, V>(arg0: K, arg1: V): $Map$Entry<K, V>;
        ofEntries<K, V>(arg0?: $Map$Entry<K, V>[]): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): $Map<K, V>;
        of<K, V>(arg0: K, arg1: V): $Map<K, V>;
        of<K, V>(): $Map<K, V>;
    };

    export interface $SortedMap<K, V> extends $SequencedMap<K, V> {
        comparator(): $Comparator<any>;
        entrySet(): $Set<$Map$Entry<K, V>>;
        firstKey(): K;
        headMap(arg0: K): $SortedMap<K, V>;
        keySet(): $Set<K>;
        lastKey(): K;
        putFirst(arg0: K, arg1: V): V;
        putLast(arg0: K, arg1: V): V;
        reversed(): $SortedMap<K, V>;
        subMap(arg0: K, arg1: K): $SortedMap<K, V>;
        tailMap(arg0: K): $SortedMap<K, V>;
        values(): $Collection<V>;
    }

    export interface $Iterator<E> {
        forEachRemaining(arg0: $Consumer_<E, E>): void;
        hasNext(): boolean;
        next(): E;
        remove(): void;
    }

    export interface $Spliterator<T> {
        characteristics(): number;
        estimateSize(): number;
        forEachRemaining(arg0: $Consumer_<T, T>): void;
        getComparator(): $Comparator<any>;
        getExactSizeIfKnown(): number;
        hasCharacteristics(arg0: number): boolean;
        tryAdvance(arg0: $Consumer_<T, T>): boolean;
        trySplit(): $Spliterator<T>;
    }
    export const $Spliterator: {
        readonly CONCURRENT: number;
        readonly DISTINCT: number;
        readonly IMMUTABLE: number;
        readonly NONNULL: number;
        readonly ORDERED: number;
        readonly SIZED: number;
        readonly SORTED: number;
        readonly SUBSIZED: number;
    };

    export class $Date implements $Serializable, $Cloneable, $Comparable<$Date> {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number);
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number);
        constructor(arg0: string);
        constructor(arg0: number);
        get date(): number;
        getDate(): number;
        set date(value: number);
        get day(): number;
        getDay(): number;
        get hours(): number;
        getHours(): number;
        set hours(value: number);
        get minutes(): number;
        getMinutes(): number;
        set minutes(value: number);
        get month(): number;
        getMonth(): number;
        set month(value: number);
        get seconds(): number;
        getSeconds(): number;
        set seconds(value: number);
        get timezoneOffset(): number;
        getTimezoneOffset(): number;
        get time(): number;
        getTime(): number;
        set time(value: number);
        get year(): number;
        getYear(): number;
        set year(value: number);
        static UTC(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): number;
        static from(arg0: $Instant): $Date;
        static parse(arg0: string): number;
        after(arg0: $Date): boolean;
        before(arg0: $Date): boolean;
        clone(): unknown;
        compareTo(arg0: $Date): number;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        setDate(arg0: number): void;
        setHours(arg0: number): void;
        setMinutes(arg0: number): void;
        setMonth(arg0: number): void;
        setSeconds(arg0: number): void;
        setTime(arg0: number): void;
        setYear(arg0: number): void;
        toGMTString(): string;
        toInstant(): $Instant;
        toLocaleString(): string;
        toString(): string;
    }

    export interface $Map$Entry<K, V> {
        equals(arg0: unknown): boolean;
        getKey(): K;
        getValue(): V;
        hashCode(): number;
        setValue(arg0: V): V;
    }
    export const $Map$Entry: {
        comparingByKey<K, V>(arg0: $Comparator_<K, K, K, number>): $Comparator<$Map$Entry<K, V>>;
        comparingByKey<K extends $Comparable<any>, V>(): $Comparator<$Map$Entry<K, V>>;
        comparingByValue<K, V>(arg0: $Comparator_<V, V, V, number>): $Comparator<$Map$Entry<K, V>>;
        comparingByValue<K, V extends $Comparable<any>>(): $Comparator<$Map$Entry<K, V>>;
        copyOf<K, V>(arg0: $Map$Entry<K, V>): $Map$Entry<K, V>;
    };

    export class $Properties extends $Hashtable<unknown, unknown> {
        constructor();
        constructor(arg0: number);
        constructor(arg0: $Properties);
        get empty(): boolean;
        isEmpty(): boolean;
        clear(): void;
        clone(): unknown;
        computeIfAbsent(arg0: unknown, arg1: $Function_<unknown, any, unknown, any>): unknown;
        computeIfPresent(arg0: unknown, arg1: $BiFunction_<unknown, unknown, any, unknown, unknown, any>): unknown;
        compute(arg0: unknown, arg1: $BiFunction_<unknown, unknown, any, unknown, unknown, any>): unknown;
        containsKey(arg0: unknown): boolean;
        containsValue(arg0: unknown): boolean;
        contains(arg0: unknown): boolean;
        elements(): $Enumeration<unknown>;
        entrySet(): $Set<$Map$Entry<unknown, unknown>>;
        equals(arg0: unknown): boolean;
        forEach(arg0: $BiConsumer_<unknown, unknown, unknown, unknown>): void;
        getOrDefault(arg0: unknown, arg1: unknown): unknown;
        getProperty(arg0: string, arg1: string): string;
        getProperty(arg0: string): string;
        get(arg0: unknown): unknown;
        hashCode(): number;
        keySet(): $Set<unknown>;
        keys(): $Enumeration<unknown>;
        list(arg0: $PrintStream): void;
        list(arg0: $PrintWriter): void;
        loadFromXML(arg0: $InputStream): void;
        load(arg0: $InputStream): void;
        load(arg0: $Reader): void;
        merge(arg0: unknown, arg1: unknown, arg2: $BiFunction_<unknown, unknown, any, unknown, unknown, any>): unknown;
        propertyNames(): $Enumeration<any>;
        putAll(arg0: ($Map<any, any> | (([any] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<any, PropertyKey>, any>>))): void;
        putIfAbsent(arg0: unknown, arg1: unknown): unknown;
        put(arg0: unknown, arg1: unknown): unknown;
        remove(arg0: unknown, arg1: unknown): boolean;
        remove(arg0: unknown): unknown;
        replaceAll(arg0: $BiFunction_<unknown, unknown, any, unknown, unknown, any>): void;
        replace(arg0: unknown, arg1: unknown, arg2: unknown): boolean;
        replace(arg0: unknown, arg1: unknown): unknown;
        save(arg0: $OutputStream, arg1: string): void;
        setProperty(arg0: string, arg1: string): unknown;
        size(): number;
        storeToXML(arg0: $OutputStream, arg1: string, arg2: string): void;
        storeToXML(arg0: $OutputStream, arg1: string, arg2: $Charset): void;
        storeToXML(arg0: $OutputStream, arg1: string): void;
        store(arg0: $OutputStream, arg1: string): void;
        store(arg0: $Writer, arg1: string): void;
        stringPropertyNames(): $Set<string>;
        toString(): string;
        values(): $Collection<unknown>;
    }

    export interface $Comparator<T> {
        compare(arg0: T, arg1: T): number;
        equals(arg0: unknown): boolean;
        reversed(): $Comparator<T>;
        thenComparingDouble(arg0: $ToDoubleFunction_<T, T, number>): $Comparator<T>;
        thenComparingInt(arg0: $ToIntFunction_<T, T, number>): $Comparator<T>;
        thenComparingLong(arg0: $ToLongFunction_<T, T, number>): $Comparator<T>;
        thenComparing(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        thenComparing<U>(arg0: $Function_<T, U, T, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<T>;
        thenComparing<U extends $Comparable<any>>(arg0: $Function_<T, U, T, U>): $Comparator<T>;
    }
    export const $Comparator: {
        comparingDouble<T>(arg0: $ToDoubleFunction_<T, T, number>): $Comparator<T>;
        comparingInt<T>(arg0: $ToIntFunction_<T, T, number>): $Comparator<T>;
        comparingLong<T>(arg0: $ToLongFunction_<T, T, number>): $Comparator<T>;
        comparing<T, U>(arg0: $Function_<T, U, T, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<T>;
        comparing<T, U extends $Comparable<any>>(arg0: $Function_<T, U, T, U>): $Comparator<T>;
        naturalOrder<T extends $Comparable<any>>(): $Comparator<T>;
        nullsFirst<T>(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        nullsLast<T>(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        reverseOrder<T extends $Comparable<any>>(): $Comparator<T>;
    };

    export interface $ListIterator<E> extends $Iterator<E> {
        add(arg0: E): void;
        hasNext(): boolean;
        hasPrevious(): boolean;
        nextIndex(): number;
        next(): E;
        previousIndex(): number;
        previous(): E;
        remove(): void;
        set(arg0: E): void;
    }

    export interface $SequencedCollection<E> extends $Collection<E> {
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        getFirst(): E;
        getLast(): E;
        removeFirst(): E;
        removeLast(): E;
        reversed(): $SequencedCollection<E>;
    }

    export class $Locale$Category {
        static DISPLAY: $Locale$Category;
        static FORMAT: $Locale$Category;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Locale$Category[];
        static valueOf(name: string): $Locale$Category;
    }
    export interface $Locale$Category extends $Enum<$Locale$Category> {}

    export class $Locale$FilteringMode {
        static AUTOSELECT_FILTERING: $Locale$FilteringMode;
        static EXTENDED_FILTERING: $Locale$FilteringMode;
        static IGNORE_EXTENDED_RANGES: $Locale$FilteringMode;
        static MAP_EXTENDED_RANGES: $Locale$FilteringMode;
        static REJECT_EXTENDED_RANGES: $Locale$FilteringMode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Locale$FilteringMode[];
        static valueOf(name: string): $Locale$FilteringMode;
    }
    export interface $Locale$FilteringMode extends $Enum<$Locale$FilteringMode> {}

    export class $Locale$IsoCountryCode {
        static PART1_ALPHA2: $Locale$IsoCountryCode;
        static PART1_ALPHA3: $Locale$IsoCountryCode;
        static PART3: $Locale$IsoCountryCode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Locale$IsoCountryCode[];
        static valueOf(name: string): $Locale$IsoCountryCode;
    }
    export interface $Locale$IsoCountryCode extends $Enum<$Locale$IsoCountryCode> {}

    export class $Locale$LanguageRange {
        constructor(arg0: string);
        constructor(arg0: string, arg1: number);
        static MAX_WEIGHT: number;
        static MIN_WEIGHT: number;
        get range(): string;
        getRange(): string;
        get weight(): number;
        getWeight(): number;
        static mapEquivalents(arg0: ($List<$Locale$LanguageRange> | ($Locale$LanguageRange)[]), arg1: ($Map<string, $List<string>> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, ($List<string> | (string)[])>>))): $List<$Locale$LanguageRange>;
        static parse(arg0: string, arg1: ($Map<string, $List<string>> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, ($List<string> | (string)[])>>))): $List<$Locale$LanguageRange>;
        static parse(arg0: string): $List<$Locale$LanguageRange>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $Hashtable<K, V> extends $Dictionary<K, V> implements $Map<K, V>, $Cloneable, $Serializable {
        constructor();
        constructor(arg0: number);
        constructor(arg0: number, arg1: number);
        constructor(arg0: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>)));
        get empty(): boolean;
        isEmpty(): boolean;
        clear(): void;
        clone(): unknown;
        computeIfAbsent(arg0: K, arg1: $Function_<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: unknown): boolean;
        containsValue(arg0: unknown): boolean;
        contains(arg0: unknown): boolean;
        elements(): $Enumeration<V>;
        entrySet(): $Set<$Map$Entry<K, V>>;
        equals(arg0: unknown): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: unknown, arg1: V): V;
        get(arg0: unknown): V;
        hashCode(): number;
        keySet(): $Set<K>;
        keys(): $Enumeration<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(arg0: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): void;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: unknown, arg1: unknown): boolean;
        remove(arg0: unknown): V;
        replaceAll(arg0: $BiFunction_<K, V, V, K, V, V>): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        toString(): string;
        values(): $Collection<V>;
    }

    export class $Dictionary<K, V> {
        constructor();
        get empty(): boolean;
        isEmpty(): boolean;
        elements(): $Enumeration<V>;
        get(arg0: unknown): V;
        keys(): $Enumeration<K>;
        put(arg0: K, arg1: V): V;
        remove(arg0: unknown): V;
        size(): number;
    }

    export interface $SequencedMap<K, V> extends $Map<K, V> {
        firstEntry(): $Map$Entry<K, V>;
        lastEntry(): $Map$Entry<K, V>;
        pollFirstEntry(): $Map$Entry<K, V>;
        pollLastEntry(): $Map$Entry<K, V>;
        putFirst(arg0: K, arg1: V): V;
        putLast(arg0: K, arg1: V): V;
        reversed(): $SequencedMap<K, V>;
        sequencedEntrySet(): $SequencedSet<$Map$Entry<K, V>>;
        sequencedKeySet(): $SequencedSet<K>;
        sequencedValues(): $SequencedCollection<V>;
    }

    export interface $SequencedSet<E> extends $SequencedCollection<E>, $Set<E> {
        addAll(arg0: ($Collection<E> | (E)[])): boolean;
        add(arg0: E): boolean;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        remove(arg0: unknown): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        reversed(): $SequencedSet<E>;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export class $IntSummaryStatistics implements $IntConsumer {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        get average(): number;
        getAverage(): number;
        get count(): number;
        getCount(): number;
        get max(): number;
        getMax(): number;
        get min(): number;
        getMin(): number;
        get sum(): number;
        getSum(): number;
        accept(arg0: number): void;
        andThen(arg0: $IntConsumer_<number>): $IntConsumer;
        combine(arg0: $IntSummaryStatistics): void;
        toString(): string;
    }

    export class $OptionalDouble {
        get asDouble(): number;
        getAsDouble(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        static empty(): $OptionalDouble;
        static of(arg0: number): $OptionalDouble;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        ifPresentOrElse(arg0: $DoubleConsumer_<number>, arg1: $Runnable_): void;
        ifPresent(arg0: $DoubleConsumer_<number>): void;
        orElseGet(arg0: $DoubleSupplier_<number>): number;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): number;
        orElseThrow(): number;
        orElse(arg0: number): number;
        stream(): $DoubleStream;
        toString(): string;
    }

    export class $OptionalInt {
        get asInt(): number;
        getAsInt(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        static empty(): $OptionalInt;
        static of(arg0: number): $OptionalInt;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        ifPresentOrElse(arg0: $IntConsumer_<number>, arg1: $Runnable_): void;
        ifPresent(arg0: $IntConsumer_<number>): void;
        orElseGet(arg0: $IntSupplier_<number>): number;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): number;
        orElseThrow(): number;
        orElse(arg0: number): number;
        stream(): $IntStream;
        toString(): string;
    }

    export interface $PrimitiveIterator$OfInt extends $PrimitiveIterator<number, $IntConsumer> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        nextInt(): number;
        next(): number;
    }

    export interface $Spliterator$OfInt extends $Spliterator$OfPrimitive<number, $IntConsumer, $Spliterator$OfInt> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $IntConsumer_<number>): boolean;
        trySplit(): $Spliterator$OfInt;
    }

    export interface $PrimitiveIterator<T, T_CONS> extends $Iterator<T> {
        forEachRemaining(arg0: T_CONS): void;
        forEachRemaining(arg0: $Consumer_<T, T>): void;
    }

    export interface $Spliterator$OfPrimitive<T, T_CONS, T_SPLITR extends $Spliterator$OfPrimitive<T, T_CONS, T_SPLITR>> extends $Spliterator<T> {
        forEachRemaining(arg0: T_CONS): void;
        forEachRemaining(arg0: $Consumer_<T, T>): void;
        tryAdvance(arg0: T_CONS): boolean;
        tryAdvance(arg0: $Consumer_<T, T>): boolean;
        trySplit(): T_SPLITR;
    }

    export class $DoubleSummaryStatistics implements $DoubleConsumer {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        get average(): number;
        getAverage(): number;
        get count(): number;
        getCount(): number;
        get max(): number;
        getMax(): number;
        get min(): number;
        getMin(): number;
        get sum(): number;
        getSum(): number;
        accept(arg0: number): void;
        andThen(arg0: $DoubleConsumer_<number>): $DoubleConsumer;
        combine(arg0: $DoubleSummaryStatistics): void;
        toString(): string;
    }

    export interface $PrimitiveIterator$OfDouble extends $PrimitiveIterator<number, $DoubleConsumer> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $DoubleConsumer_<number>): void;
        nextDouble(): number;
        next(): number;
    }

    export interface $Spliterator$OfDouble extends $Spliterator$OfPrimitive<number, $DoubleConsumer, $Spliterator$OfDouble> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $DoubleConsumer_<number>): void;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $DoubleConsumer_<number>): boolean;
        trySplit(): $Spliterator$OfDouble;
    }

    export class $LongSummaryStatistics implements $LongConsumer, $IntConsumer {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        get average(): number;
        getAverage(): number;
        get count(): number;
        getCount(): number;
        get max(): number;
        getMax(): number;
        get min(): number;
        getMin(): number;
        get sum(): number;
        getSum(): number;
        accept(arg0: number): void;
        accept(arg0: number): void;
        andThen(arg0: $IntConsumer_<number>): $IntConsumer;
        andThen(arg0: $LongConsumer_<number>): $LongConsumer;
        combine(arg0: $LongSummaryStatistics): void;
        toString(): string;
    }

    export class $OptionalLong {
        get asLong(): number;
        getAsLong(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        static empty(): $OptionalLong;
        static of(arg0: number): $OptionalLong;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        ifPresentOrElse(arg0: $LongConsumer_<number>, arg1: $Runnable_): void;
        ifPresent(arg0: $LongConsumer_<number>): void;
        orElseGet(arg0: $LongSupplier_<number>): number;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): number;
        orElseThrow(): number;
        orElse(arg0: number): number;
        stream(): $LongStream;
        toString(): string;
    }

    export interface $PrimitiveIterator$OfLong extends $PrimitiveIterator<number, $LongConsumer> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $LongConsumer_<number>): void;
        nextLong(): number;
        next(): number;
    }

    export interface $Spliterator$OfLong extends $Spliterator$OfPrimitive<number, $LongConsumer, $Spliterator$OfLong> {
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $LongConsumer_<number>): void;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $LongConsumer_<number>): boolean;
        trySplit(): $Spliterator$OfLong;
    }

    export type $Optional_<T> = T | null;
    export type $Set_<E> = $Set<E>;
    export type $List_<E> = ($List<E> | (E)[]);
    export type $Collection_<E> = ($Collection<E> | (E)[]);
    export type $Map_<K, V> = ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>));
    export type $SortedMap_<K, V> = $SortedMap<K, V>;
    export type $Iterator_<E> = E[];
    export type $Spliterator_<T> = T[];
    export type $Comparator_<Host0 = any, CallbackArg0 = Host0, CallbackArg1 = Host0, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($Comparator<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $SequencedCollection_<E> = $SequencedCollection<E>;
    export type $Locale$Category_ = $Locale$Category | "DISPLAY" | "FORMAT";
    export type $Locale$FilteringMode_ = $Locale$FilteringMode | "AUTOSELECT_FILTERING" | "EXTENDED_FILTERING" | "IGNORE_EXTENDED_RANGES" | "MAP_EXTENDED_RANGES" | "REJECT_EXTENDED_RANGES";
    export type $Locale$IsoCountryCode_ = $Locale$IsoCountryCode | "PART1_ALPHA2" | "PART1_ALPHA3" | "PART3";
    export type $SequencedMap_<K, V> = $SequencedMap<K, V>;
    export type $SequencedSet_<E> = $SequencedSet<E>;

    type $CaptureArgs<O> = O extends (...args: infer A) => infer R ? A
        : O extends { apply: (...args: infer A) => infer R } ? A : never;
    type $CaptureUnary<B> = ((value: B) => B) | ($UnaryOperator<B> & { readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }) | globalThis.NoInfer<{ readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }>;
    type $CaptureBinary<B> = ((left: B, right: B) => B) | ($BinaryOperator<B> & { readonly apply: (left: B, right: B) => B; readonly [Symbol.hasInstance]?: never }) | globalThis.NoInfer<{ readonly apply: (left: B, right: B) => B; readonly [Symbol.hasInstance]?: never }>;
    export interface $ListView<B> extends $SequencedCollectionView<B> {
        addAll(arg0: number, arg1: ($CollectionView<B> | (B)[])): boolean;
        addAll(arg0: ($CollectionView<B> | (B)[])): boolean;
        addFirst(arg0: B): void;
        addLast(arg0: B): void;
        add(arg0: B): boolean;
        add(arg0: number, arg1: B): void;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        getFirst(): B;
        getLast(): B;
        get(arg0: number): B;
        hashCode(): number;
        indexOf(arg0: unknown): number;
        isEmpty(): boolean;
        iterator(): $Iterator<B>;
        lastIndexOf(arg0: unknown): number;
        listIterator(arg0: number): $ListIteratorView<B>;
        listIterator(): $ListIteratorView<B>;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeFirst(): B;
        removeLast(): B;
        remove(arg0: number): B;
        remove(arg0: unknown): boolean;
        replaceAll(arg0: $UnaryOperator<B> & { readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }): void;
        replaceAll(arg0: ((value: B) => B) | globalThis.NoInfer<{ readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }>): void;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        reversed(): $ListView<B>;
        set(arg0: number, arg1: B): B;
        size(): number;
        sort(arg0: $Comparator_<B, B, B, number>): void;
        spliterator(): $Spliterator<B>;
        subList(arg0: number, arg1: number): $ListView<B>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }
    export interface $CollectionView<B> extends $Iterable<B> {
        addAll(arg0: ($CollectionView<B> | (B)[])): boolean;
        add(arg0: B): boolean;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $Iterator<B>;
        parallelStream(): $StreamView<B>;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeIf(arg0: $Predicate_<B, B, boolean>): boolean;
        remove(arg0: unknown): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        size(): number;
        spliterator(): $Spliterator<B>;
        stream(): $StreamView<B>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }
    export interface $SequencedCollectionView<B> extends $CollectionView<B> {
        addFirst(arg0: B): void;
        addLast(arg0: B): void;
        getFirst(): B;
        getLast(): B;
        removeFirst(): B;
        removeLast(): B;
        reversed(): $SequencedCollectionView<B>;
    }
    export interface $ListIteratorView<B> extends $Iterator<B> {
        add(arg0: B): void;
        hasNext(): boolean;
        hasPrevious(): boolean;
        nextIndex(): number;
        next(): B;
        previousIndex(): number;
        previous(): B;
        remove(): void;
        set(arg0: B): void;
    }
    type $OptionalInput<B> = globalThis.NoInfer<$Optional<any>> & { readonly get: () => B };
    export interface $OptionalView<B> {
        or(arg0: $Supplier_<$OptionalInput<B>, $OptionalInput<B>>): $OptionalView<B>;
        get empty(): boolean;
        isEmpty(): boolean;
        get present(): boolean;
        isPresent(): boolean;
        equals(arg0: unknown): boolean;
        filter(arg0: $Predicate_<B, B, boolean>): $OptionalView<B>;
        flatMap<U>(arg0: $Function_<B, $Optional<U>, B, $Optional<U>>): $OptionalView<U>;
        get(): B;
        hashCode(): number;
        ifPresentOrElse(arg0: $Consumer_<B, B>, arg1: $Runnable_): void;
        ifPresent(arg0: $Consumer_<B, B>): void;
        map<U>(arg0: $Function_<B, U, B, U>): $OptionalView<U>;
        orElseGet(arg0: $Supplier_<B, B>): B;
        orElseThrow<X extends $Throwable>(arg0: $Supplier_<X, X>): B;
        orElseThrow(): B;
        orElse(arg0: B): B;
        stream(): $StreamView<B>;
        toString(): string;
    }
}
