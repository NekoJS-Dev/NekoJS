"""Separate ordinary factory context from strict host operand checks."""

from collections import Counter
import json
from pathlib import Path
import re
import shutil
import subprocess

base = Path('build/capture-return-facets-20261026/supplier')
root = Path('build/capture-factory-context-20261026')
root.mkdir()
records = []
for mode in ['plain', 'direct', 'minimal', 'host-first', 'callback-first']:
    target = root / mode
    shutil.copytree(base, target)
    for module in ['util', 'util/stream']:
        path = target / '@package/java' / module / 'index.d.ts'
        text = path.read_text(encoding='utf-8')
        unary = '((value: B) => B) | ($UnaryOperator_<B, B, B> & { readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never })'
        binary = '((left: B, right: B) => B) | ($BinaryOperator_<B, B, B, B> & { readonly apply: (left: B, right: B) => B; readonly [Symbol.hasInstance]?: never })'
        if mode == 'plain':
            u, b = '$UnaryOperator_<B, B, B>', '$BinaryOperator_<B, B, B, B>'
        elif mode == 'minimal':
            u = '((value: B) => B) | { readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }'
            b = '((left: B, right: B) => B) | { readonly apply: (left: B, right: B) => B; readonly [Symbol.hasInstance]?: never }'
        else:
            u = '((value: B) => B) | ($UnaryOperator<B> & { readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }) | globalThis.NoInfer<{ readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }>'
            b = '((left: B, right: B) => B) | ($BinaryOperator<B> & { readonly apply: (left: B, right: B) => B; readonly [Symbol.hasInstance]?: never }) | globalThis.NoInfer<{ readonly apply: (left: B, right: B) => B; readonly [Symbol.hasInstance]?: never }>'
        assert unary in text and binary in text
        text = text.replace(unary, u).replace(binary, b)
        if module == 'util' and mode in ['host-first', 'callback-first']:
            host = '        replaceAll(arg0: $UnaryOperator<B> & { readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }): void;'
            callback = '        replaceAll(arg0: ((value: B) => B) | globalThis.NoInfer<{ readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never }>): void;'
            signatures = [host, callback] if mode == 'host-first' else [callback, host]
            assert '        replaceAll(arg0: $CaptureUnary<B>): void;' in text
            text = text.replace('        replaceAll(arg0: $CaptureUnary<B>): void;', '\n'.join(signatures))
        path.write_text(text, encoding='utf-8', newline='\n')
    result = subprocess.run(['node', 'node_modules/typescript/bin/tsc', '-p', str(target / 'tsconfig.json')], capture_output=True, timeout=120)
    (target / 'tsc.txt').write_bytes(result.stdout)
    (target / 'tsc-stderr.txt').write_bytes(result.stderr)
    assert result.returncode in (0, 2) and not result.stderr
    codes = Counter(re.findall(r': error (TS\d+):', result.stdout.decode('utf-8')))
    assert (result.returncode == 0) == (not codes)
    record = {'name': mode, 'exitCode': result.returncode, 'errorCodes': dict(codes)}
    records.append(record)
    print(json.dumps(record), flush=True)
(root / 'summary.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
