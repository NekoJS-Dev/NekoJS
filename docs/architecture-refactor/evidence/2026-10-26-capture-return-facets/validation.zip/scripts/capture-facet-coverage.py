"""Challenge the passing facet candidate with retained consumers and concrete host containers."""

from collections import Counter
import json
from pathlib import Path
import re
import shutil
import subprocess

target = Path('build/capture-facet-coverage-20261026')
shutil.copytree('build/capture-factory-context-20261026/host-first', target)
path = target / 'exercise.ts'
path.write_text(path.read_text(encoding='utf-8') + """
import type { $Collection, $List } from 'java:java/util';
import type { $Collector, $Stream } from 'java:java/util/stream';
declare const narrowCollection: $Collection<Narrow>;
list.addAll(narrowCollection);
list.addAll(0, narrowCollection);
list.replaceAll(value => upper);
list.replaceAll({apply: (value: Bound) => value});
// @ts-expect-error Proxy operators retain the actual operand domain.
list.replaceAll({apply: (value: Narrow) => value});
// @ts-expect-error Proxy operator results retain the bound.
list.replaceAll({apply: (value: Bound) => 'wrong'});
const replacement: Bound = result.stream().reduce((left, right) => upper).get();
const replacementSeeded: Bound = result.stream().reduce(upper, (left, right) => upper);
const proxyFallback: Bound = result.or({get: () => $Optional.of(narrow)}).get();
declare const collector: $Collector<Bound, unknown, string[]>;
const byCollector: string[] = result.stream().collect(collector);
const explicitCollector: string[] = result.stream().collect<string[], unknown>(collector);
declare const narrowCollector: $Collector<Narrow, unknown, Narrow[]>;
// @ts-expect-error A collector cannot assume narrower stream operands.
result.stream().collect(narrowCollector);
declare const wrongCollector: $Collector<string, unknown, string[]>;
// @ts-expect-error Unrelated collector operands remain rejected.
result.stream().collect(wrongCollector);
const rawOptional: $Optional<Bound> = result;
const rawStream: $Stream<Bound> = result.stream();
const rawList: $List<Bound> = list;
const listValue: Bound = rawList.get(0);
""", encoding='utf-8', newline='\n')
proc = subprocess.run(['node', 'node_modules/typescript/bin/tsc', '-p', str(target / 'tsconfig.json')], capture_output=True, timeout=120)
(target / 'tsc.txt').write_bytes(proc.stdout)
(target / 'tsc-stderr.txt').write_bytes(proc.stderr)
assert proc.returncode in (0, 2) and not proc.stderr
codes = Counter(re.findall(r': error (TS\d+):', proc.stdout.decode('utf-8')))
print(json.dumps({'exitCode': proc.returncode, 'errorCodes': dict(codes)}))
print(proc.stdout.decode('utf-8'))
