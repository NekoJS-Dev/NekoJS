from pathlib import Path
import shutil,subprocess,re
src=Path('build/capture-facet-inputs-20261026'); dst=Path('build/capture-facet-extends-20261026');shutil.copytree(src,dst)
p=dst/'@package/java/util/index.d.ts';s=p.read_text(encoding='utf8')
for v,n in [('List','List'),('Collection','Collection'),('SequencedCollection','SequencedCollection'),('ListIterator','ListIterator'),('Optional','Optional')]:
 s=re.sub(r'export interface \$'+v+r'View<B>(?: extends [^\n{]+)? \{','export interface $'+v+'View<B> extends $'+n+'<B> {',s)
p.write_text(s,encoding='utf8')
p=dst/'@package/java/util/stream/index.d.ts';s=p.read_text(encoding='utf8').replace('export interface $StreamView<B> {','export interface $StreamView<B> extends $Stream<B> {');p.write_text(s,encoding='utf8')
r=subprocess.run(['node','node_modules/typescript/bin/tsc','-p',str(dst/'tsconfig.json')],capture_output=True);(dst/'tsc.txt').write_bytes(r.stdout);print(r.returncode);print(r.stdout.decode())
