from pathlib import Path
import shutil,subprocess
base=Path('build/capture-facet-coverage-20261026')
target=Path('build/capture-facet-inputs-20261026')
shutil.copytree(base,target)
p=target/'@package/java/util/index.d.ts'
s=p.read_text(encoding='utf-8')
s=s.replace('($CollectionView<B> | (B)[])','($CollectionInput<B> | (B)[])')
s=s.replace('    type $OptionalInput<B>', '    type $CollectionInput<B> = globalThis.NoInfer<$Collection<any>> & { readonly iterator: () => $Iterator<B> };\n    type $OptionalInput<B>')
p.write_text(s,encoding='utf-8')
p=target/'@package/java/util/stream/index.d.ts'
s=p.read_text(encoding='utf-8')
s=s.replace('collect<R, A>(arg0: $Collector<B, A, R>): R;', 'collect<R, A>(arg0: $Collector<B, A, R> & { readonly accumulator: () => { readonly accept: (state: A, value: B) => void } }): R;')
p.write_text(s,encoding='utf-8')
r=subprocess.run(['node','node_modules/typescript/bin/tsc','-p',str(target/'tsconfig.json')],capture_output=True,timeout=120)
(target/'tsc.txt').write_bytes(r.stdout)
(target/'tsc-stderr.txt').write_bytes(r.stderr)
print('exit',r.returncode)
print(r.stdout.decode())
