"""Check receiver return facets without asserting that invariant containers are structural subtypes."""

from collections import Counter
import json
from pathlib import Path
import re
import shutil
import subprocess

base = Path('build/capture-bound-operators-v2-20261026/operators')
root = Path('build/capture-return-facets-20261026')
root.mkdir()
records = []

def ensure_import(text, names, module):
    headers = [line for line in text.splitlines() if line.startswith('import ') and f'from "{module}"' in line]
    missing = [name for name in names if not any(re.search(r'(?<![\w$])' + re.escape(name) + r'(?![\w$])', line) for line in headers)]
    return ('import type { ' + ', '.join(missing) + ' } from "' + module + '";\n' if missing else '') + text

for mode in ['facets', 'protocols', 'supplier']:
    target = root / mode
    shutil.copytree(base, target)
    bridges = []
    for path in target.glob('@package/**/index.d.ts'):
        text = path.read_text(encoding='utf-8')
        bound = '$ProbeWildcardOptionalCaptureTest$ConstDesc' if '/com/' in path.as_posix() else '$ConstantDesc'
        def bridge(match):
            bridges.append({'file': path.relative_to(target).as_posix(), 'narrow': match[2], 'bound': bound})
            return match[1] + match[2] + ' & $OptionalView<' + bound + '>;'
        text, count = re.subn(r'^(\s+describeConstable\(\): )(\$Optional<.+>);$', bridge, text, flags=re.M)
        if count:
            text = ensure_import(text, ['$OptionalView'], 'java:java/util')
            if bound == '$ConstantDesc': text = ensure_import(text, [bound], 'java:java/lang/constant')
            path.write_text(text, encoding='utf-8', newline='\n')
    assert len(bridges) == 6, bridges
    if mode in ['protocols', 'supplier']:
        for module in ['util', 'util/stream']:
            path = target / '@package/java' / module / 'index.d.ts'
            text = path.read_text(encoding='utf-8')
            text = ensure_import(text, ['$UnaryOperator', '$BinaryOperator'], 'java:java/util/function')
            text = text.replace('type $CaptureUnary<B> = $UnaryOperator_<B, B, B>;',
                'type $CaptureUnary<B> = ((value: B) => B) | ($UnaryOperator_<B, B, B> & { readonly apply: (value: B) => B; readonly [Symbol.hasInstance]?: never });')
            text = text.replace('type $CaptureBinary<B> = $BinaryOperator_<B, B, B, B>;',
                'type $CaptureBinary<B> = ((left: B, right: B) => B) | ($BinaryOperator_<B, B, B, B> & { readonly apply: (left: B, right: B) => B; readonly [Symbol.hasInstance]?: never });')
            text = text.replace('replaceAll<O extends $CaptureUnary<B>>(arg0: O & ([B] extends $CaptureArgs<O> ? O : never))',
                                'replaceAll(arg0: $CaptureUnary<B>)')
            text = text.replace('reduce<O extends $CaptureBinary<B>>(arg0: O & ([B, B] extends $CaptureArgs<O> ? O : never))',
                                'reduce(arg0: $CaptureBinary<B>)')
            text = text.replace('reduce<O extends $CaptureBinary<B>>(arg0: B, arg1: O & ([B, B] extends $CaptureArgs<O> ? O : never))',
                                'reduce(arg0: B, arg1: $CaptureBinary<B>)')
            if module == 'util' and mode == 'supplier':
                lines = [line for line in text.splitlines() if line.strip().startswith('or(') and line.strip().endswith('$OptionalView<B>;')]
                assert len(lines) == 1
                text = text.replace('    export interface $OptionalView<B>',
                    '    type $OptionalInput<B> = globalThis.NoInfer<$Optional<any>> & { readonly get: () => B };\n    export interface $OptionalView<B>')
                text = text.replace(lines[0], '        or(arg0: $Supplier_<$OptionalInput<B>, $OptionalInput<B>>): $OptionalView<B>;')
            path.write_text(text, encoding='utf-8', newline='\n')
    exercise_path = target / 'exercise.ts'
    exercise = exercise_path.read_text(encoding='utf-8') + """
const retainedReduce: number = result.stream().reduce(
    0, (count: number, value: Bound): number => count, (left: number, right: number): number => left);
const retainedCollect: string[] = result.stream().collect(
    (): string[] => [], (acc: string[], value: Bound): void => {}, (left: string[], right: string[]): void => {});
const retainedDeep: Bound = result.stream().findAny().stream().findFirst().get();
const retainedMap: string = result.map<string>((value: Bound) => value.label).get();
const retainedFlatMap: Bound = result.flatMap<Bound>(() => $Optional.of(upper)).get();
"""
    if mode == 'supplier':
        exercise += """
declare const ordinarySupplier: import('java:java/util/function').$Supplier<import('java:java/util').$Optional<Narrow>>;
const ordinaryFallback: Bound = result.or(ordinarySupplier).get();
const broadFallback: Bound = result.or(() => $Optional.of(upper)).get();
declare const wrongSupplier: import('java:java/util/function').$Supplier<import('java:java/util').$Optional<string>>;
// @ts-expect-error The supplier's actual payload remains bounded.
result.or(wrongSupplier);
// @ts-expect-error A proxy's payload remains bounded, without contextual any leakage.
result.or({get: () => $Optional.of('wrong')});
"""
    exercise_path.write_text(exercise, encoding='utf-8', newline='\n')
    result = subprocess.run(['node', 'node_modules/typescript/bin/tsc', '-p', str(target / 'tsconfig.json')], capture_output=True, timeout=120)
    (target / 'tsc.txt').write_bytes(result.stdout)
    (target / 'tsc-stderr.txt').write_bytes(result.stderr)
    assert result.returncode in (0, 2) and not result.stderr
    codes = Counter(re.findall(r': error (TS\d+):', result.stdout.decode('utf-8')))
    assert (result.returncode == 0) == (not codes)
    record = {'name': mode, 'exitCode': result.returncode, 'errorCodes': dict(codes), 'bridges': bridges}
    records.append(record)
    print(json.dumps({key: record[key] for key in ['name', 'exitCode', 'errorCodes']}), flush=True)
(root / 'summary.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
