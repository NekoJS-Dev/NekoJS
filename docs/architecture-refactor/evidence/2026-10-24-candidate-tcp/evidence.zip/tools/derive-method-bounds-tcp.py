"""Reuse the established physical-fault TCP proof with fresh exact-candidate fixtures."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
revision = '975496d3bddf6fc76b206921a1d09207120ca24d'
old_revision = 'b47734c6721ee8434df48c0b2a86b887d577f02e'
manifest = json.loads((repo / 'build/closeout-method-bounds-installed/preparation-manifest.json').read_text())
assert manifest['sourceRevision'] == revision
for node in ['26.1.2', '26.2.0']:
    row = next(value for value in manifest['nodes'] if value['node'] == node)
    installed = repo / 'build/closeout-method-bounds-installed' / node / 'mods' / row['artifact']
    built = repo / 'versions' / node / 'build/libs' / row['artifact']
    assert hashlib.sha256(installed.read_bytes()).hexdigest() == hashlib.sha256(built.read_bytes()).hexdigest() == row['sha256']
    with zipfile.ZipFile(installed) as archive:
        for name, digest in row['classBindings'].items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest

text = (tools / 'prepare-b477-dynamic-commit.py').read_text()
text = text.replace(old_revision, revision).replace("'b47734c6'", "'975496d3'")
text = text.replace('dynamic-commit-b47734c6-', 'dynamic-commit-975496d3-')
text = text.replace('build/closeout-7bea6d6d-installed', 'build/closeout-method-bounds-installed')
text = text.replace("29991 if short == '261' else 30091", "30191 if short == '261' else 30291")
assert 'b47734c6' not in text and '7bea6d6d' not in text
target = tools / 'prepare-method-bounds-tcp.py'
assert not target.exists()
target.write_text(text, newline='\n')
for short in ['261', '262']:
    text = (tools / f'run-dynamic-commit-b477-{short}.py').read_text()
    text = text.replace(old_revision, revision).replace('dynamic-commit-b47734c6-', 'dynamic-commit-975496d3-')
    target = tools / f'run-method-bounds-tcp-{short}.py'
    assert not target.exists()
    target.write_text(text, newline='\n')
text = (tools / 'verify-b477-dynamic-commit.py').read_text()
text = text.replace(old_revision, revision).replace('dynamic-commit-b47734c6-', 'dynamic-commit-975496d3-')
text = text.replace('dynamic-commit-b477-summary.json', 'method-bounds-tcp-summary.json')
text = text.replace("productionFix='b47734c6 intrusive holder cleanup'", "productionFix='Existing intrusive holder cleanup retained; current declaration candidate'")
target = tools / 'verify-method-bounds-tcp.py'
assert not target.exists()
target.write_text(text, newline='\n')
print('Prepared exact-candidate derivation; existing seven physical-fault stages unchanged.')
