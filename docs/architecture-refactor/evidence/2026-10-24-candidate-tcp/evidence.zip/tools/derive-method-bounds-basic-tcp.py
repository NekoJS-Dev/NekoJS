"""Bind the original eight protocol stages to fresh exact-candidate helpers."""
from pathlib import Path

tools = Path.cwd() / 'build/priority-closeout'
text = (tools / 'prepare-method-bounds-tcp.py').read_text()
text = text.replace('dynamic-commit-975496d3-', 'dynamic-basic-975496d3-')
text = text.replace("30191 if short == '261' else 30291", "30391 if short == '261' else 30491")
target = tools / 'prepare-method-bounds-basic-tcp.py'
assert not target.exists()
target.write_text(text, newline='\n')
for short, runner, old_root, old_port, port in [
    ('261', 'run-dynamic-tcp-v3.py', 'dynamic-tcp-d91ca974-v3', 28991, 30391),
    ('262', 'run-dynamic-tcp-262.py', 'dynamic-tcp-262-d91ca974-v1', 29091, 30491)]:
    new_root = f'dynamic-basic-975496d3-{short}-v1'
    text = (tools / runner).read_text().replace(old_root, new_root).replace(str(old_port), str(port))
    text = text.replace('d91ca974ba88fe3507281b47a3bdb574322c5c9d', '975496d3bddf6fc76b206921a1d09207120ca24d')
    target = tools / f'run-method-bounds-basic-tcp-{short}.py'
    assert not target.exists()
    target.write_text(text, newline='\n')
    text = (tools / 'verify-dynamic-tcp-v3.py').read_text().replace('dynamic-tcp-d91ca974-v3', new_root)
    text = text.replace("manifest = json.loads((root / 'artifact-manifest.json').read_text())\nexpected = next(value['sha256'] for value in manifest['artifacts'] if value['name'].startswith('nekojs-'))",
                        "manifest = json.loads((root / 'preparation.json').read_text())\nexpected = manifest['jar']['sha256']")
    text = text.replace("remaining=['26.2.0 runtime', 'final unified candidate', 'post-commit activation-failure degradation', 'maintainer release acceptance']",
                        "remaining=['Separate commit-failure proof, final render proof, full strict TSC, reload performance, maintainer release acceptance']")
    target = tools / f'verify-method-bounds-basic-tcp-{short}.py'
    assert not target.exists()
    target.write_text(text, newline='\n')
text = (tools / 'run-method-bounds-tcp-all.py').read_text()
text = text.replace('dynamic-commit-975496d3-', 'dynamic-basic-975496d3-')
text = text.replace('method-bounds-tcp-', 'method-bounds-basic-tcp-')
text = text.replace("subprocess.run([sys.executable, str(tools / 'verify-method-bounds-tcp.py')], check=True)",
                    "for short in ['261', '262']:\n    subprocess.run([sys.executable, str(tools / f'verify-method-bounds-basic-tcp-{short}.py')], check=True)")
assert 'verify-method-bounds-tcp.py' not in text
target = tools / 'run-method-bounds-basic-tcp-all.py'
assert not target.exists()
target.write_text(text, newline='\n')
print('Derived fresh eight-stage proofs; same NACK, timeout, late ACK and reconnect assertions.')
