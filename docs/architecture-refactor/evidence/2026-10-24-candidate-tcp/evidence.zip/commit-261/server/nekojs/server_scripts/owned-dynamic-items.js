DynamicRegistryEvents.dynamicRegistry(event => {
  event.item('nekojs_acceptance:tcp_seed', build => { build.maxStackSize = 16; build.rarity = 'rare'; });
  event.item('nekojs_acceptance:tcp_commit_fail', build => { build.maxStackSize = 16; build.rarity = 'rare'; });
  event.item('nekojs_acceptance:tcp_followup', build => { build.maxStackSize = 16; build.rarity = 'rare'; });
});
