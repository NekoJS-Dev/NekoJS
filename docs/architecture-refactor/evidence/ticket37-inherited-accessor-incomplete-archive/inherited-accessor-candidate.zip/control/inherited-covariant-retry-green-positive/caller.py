from fixture import PythonBeanMemberCollisionTest_PreciseGetterChild as Child
from fixture import PythonBeanMemberCollisionTest_PreciseValue as Precise
target = Child()
read: Precise = target.value
target.value = Precise()
