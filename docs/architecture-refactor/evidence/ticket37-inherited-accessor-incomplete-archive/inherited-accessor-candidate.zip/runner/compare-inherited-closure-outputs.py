import collections
import hashlib
import json
import re
from pathlib import Path

project = Path.cwd().resolve()
after = project / 'build/ticket37-inherited-closure-installed'
nodes = ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']

def ts_diagnostics(path):
    result = collections.Counter()
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if 'error TS' not in line:
            continue
        match = re.search(r'(\.neko_probe/[^()]+|nekojs/[^()]+)\(\d+,\d+\): error (TS\d+): (.*)',
            line.replace('\\', '/'))
        assert match, line
        result[tuple(match.groups())] += 1
    return result

def py_diagnostics(path):
    document = json.loads(path.read_text(encoding='utf-8-sig'))
    return collections.Counter((d['file'].replace('\\', '/').partition('/python/')[2],
        d.get('rule', 'none'), d['message']) for d in document['generalDiagnostics'])

def difference(before, current):
    return dict(before=sum(before.values()), after=sum(current.values()),
        removed=sum((before-current).values()), added=sum((current-before).values()),
        removedDiagnostics=[dict(file=k[0], code=k[1], message=k[2], count=v)
            for k,v in sorted((before-current).items())],
        addedDiagnostics=[dict(file=k[0], code=k[1], message=k[2], count=v)
            for k,v in sorted((current-before).items())])

for stage, directory in [('7e98', 'ticket37-interface-static-installed'),
                         ('rejected-candidate', 'ticket37-inherited-installed'), ('f469', 'ticket37-inherited-repaired-installed'), ('03cc', 'ticket37-inherited-final-installed'), ('ec765', 'ticket37-inherited-boundary-installed'), ('2d0b', 'ticket37-inherited-selective-installed')]:
    before = project / 'build' / directory
    rows = []
    for node in nodes:
        row = dict(node=node, typescript=[])
        for side in ['server', 'startup']:
            filename = node+'-'+side+'-tsc.txt'
            row['typescript'].append(dict(side=side, **difference(ts_diagnostics(before/'ide'/filename),
                ts_diagnostics(after/'ide'/filename))))
        row['python'] = difference(py_diagnostics(before/'ide'/(node+'-pyright.json')),
            py_diagnostics(after/'ide'/(node+'-pyright.json')))
        languages = []
        for language, extension in [('typescript', '*.d.ts'), ('python', '*.pyi')]:
            def files(server):
                return {p.relative_to(server/'.neko_probe'/language).as_posix():
                    hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in (server/'.neko_probe'/language).rglob(extension)}
            old_files, new_files = files(before/node), files(after/node)
            languages.append(dict(language=language, before=len(old_files), after=len(new_files),
                missing=sorted(old_files.keys()-new_files.keys()), added=sorted(new_files.keys()-old_files.keys()),
                changed=sum(old_files[k]!=new_files[k] for k in old_files.keys()&new_files.keys())))
        row['generation'] = languages
        def warnings(server):
            return sorted(set(json.loads((server/'runtime-verdict.json').read_text(encoding='utf-8'))
                .get('probeWarnings', [])))
        old_warnings, new_warnings = warnings(before/node), warnings(after/node)
        def identities(values):
            return sorted({tuple(re.search(r'Probe type (reflection failed|scan incomplete) for ([^;]+);',
                warning).groups()) for warning in values})
        row['omissions'] = dict(before=identities(old_warnings), after=identities(new_warnings),
            removedWarnings=sorted(set(old_warnings)-set(new_warnings)),
            addedWarnings=sorted(set(new_warnings)-set(old_warnings)))
        rows.append(row)
        print(json.dumps(dict(stage=stage, node=node,
            typescript=[{k:v for k,v in s.items() if not k.endswith('Diagnostics')} for s in row['typescript']],
            python={k:v for k,v in row['python'].items() if not k.endswith('Diagnostics')}, generation=languages)))
    (after/'ide'/('comparison-'+stage+'.json')).write_text(json.dumps(dict(baseline=directory,
        lineNumbersIgnored=True, nodes=rows), indent=2)+'\n', encoding='utf-8')
