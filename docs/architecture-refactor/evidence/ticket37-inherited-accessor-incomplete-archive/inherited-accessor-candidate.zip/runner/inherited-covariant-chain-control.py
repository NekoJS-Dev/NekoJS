import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

project = Path.cwd().resolve()
repair = project/'build/ticket37-config-sync-repair'
source = project/'common/src/main/java/com/tkisor/nekojs/probe/backend/python/PythonClassRenderer.java'
original = source.read_bytes()
needle = b'MethodDecl inheritedGetter = inheritedBeanGetter(d, visible);'
assert original.count(needle) == 1
controlled = original.replace(needle, b'MethodDecl inheritedGetter = visible.owner().beanGetterForField(field);')
pyright = 'C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js'
attempt = sys.argv[1] if len(sys.argv) > 1 else 'first'
prefix = f'inherited-covariant-{attempt}'

def compiler(stage, control):
    directory = repair/f'{prefix}-{stage}-{control}'
    directory.mkdir()
    shutil.copyfile(project/'common/build/probe-python-inherited-field-chain/fixture.pyi', directory/'fixture.pyi')
    (directory/'caller.py').write_text('from fixture import PythonBeanMemberCollisionTest_PreciseGetterChild as Child\n'
        'from fixture import PythonBeanMemberCollisionTest_PreciseValue as Precise\n'
        + ('from fixture import PythonBeanMemberCollisionTest_BaseValue as Base\n' if control == 'negative' else '')
        +
        'target = Child()\nread: Precise = target.value\ntarget.value = Precise()\n'
        + ('target.value = Base()\n' if control == 'negative' else ''))
    config = directory/'pyrightconfig.json'
    config.write_text(json.dumps(dict(typeCheckingMode='strict', include=['caller.py', 'fixture.pyi'])))
    with (directory/'pyright.json').open('xb') as stream:
        result = subprocess.run(['node', pyright, '--project', str(config), '--outputjson'], stdout=stream, stderr=subprocess.PIPE)
    assert not result.stderr
    report = json.loads((directory/'pyright.json').read_text())
    assert report['summary']['filesAnalyzed'] == 2
    errors = [d for d in report['generalDiagnostics'] if d['severity'] == 'error']
    caller_errors = [d for d in errors if Path(d['file']).name == 'caller.py']
    expected = 1 if stage == 'red' or control == 'negative' else 0
    assert len(caller_errors) == expected, caller_errors
    if stage == 'red': assert caller_errors[0]['rule'] == 'reportAssignmentType'
    elif control == 'negative': assert caller_errors[0]['rule'] == 'reportAttributeAccessIssue'
    return dict(stage=stage, control=control, exitCode=result.returncode, summary=report['summary'], errors=errors)

record = dict(originalSha256=hashlib.sha256(original).hexdigest(), controlledSha256=hashlib.sha256(controlled).hexdigest())
try:
    source.write_bytes(controlled)
    with (repair/f'{prefix}-controlled-red.txt').open('xb') as stream:
        result = subprocess.run([str(project/'gradlew.bat'), ':common:test', '--tests',
            '*PythonBeanMemberCollisionTest.covariantGetterOverridesNearestInheritedFieldProjection', '--console=plain'], stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 1
    assert b'covariantGetterOverridesNearestInheritedFieldProjection() FAILED' in (repair/f'{prefix}-controlled-red.txt').read_bytes()
    record['red'] = compiler('red', 'positive')
finally:
    source.write_bytes(original)
    record['restored'] = source.read_bytes() == original
    (repair/f'{prefix}-source-control.json').write_text(json.dumps(record, indent=2)+'\n')
assert record['restored']
with (repair/f'{prefix}-controlled-green.txt').open('xb') as stream:
    result = subprocess.run([str(project/'gradlew.bat'), ':common:test', '--tests',
        '*PythonBeanMemberCollisionTest.covariantGetterOverridesNearestInheritedFieldProjection', '--console=plain'], stdout=stream, stderr=subprocess.STDOUT)
assert result.returncode == 0
record['green'] = [compiler('green', control) for control in ['positive', 'negative']]
(repair/f'{prefix}-source-control.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
