from fixture import PythonBeanMemberCollisionTest_StringGetterChild
target = PythonBeanMemberCollisionTest_StringGetterChild()
read: str = target.value
target.value = False
explicit: str = target.getValue()
