import collections
import json
from pathlib import Path

for node in ['1.21.1', '26.1.2']:
    def entries(trial):
        document = json.loads((Path('build')/trial/'ide'/(node+'-pyright.json')).read_text())
        return collections.Counter((entry['file'].replace('\\', '/').partition('/python/')[2],
            entry.get('rule', 'none'), entry['message']) for entry in document['generalDiagnostics'])
    before = entries('ticket37-inherited-selective-installed')
    after = entries('ticket37-inherited-closure-installed')
    print(json.dumps(dict(node=node, added=[dict(file=key[0], rule=key[1], message=key[2], count=count)
        for key, count in (after-before).items()])))
