from fixture import PythonBeanMemberCollisionTest_NestedGetterChild

target = PythonBeanMemberCollisionTest_NestedGetterChild()
target.value = 7
