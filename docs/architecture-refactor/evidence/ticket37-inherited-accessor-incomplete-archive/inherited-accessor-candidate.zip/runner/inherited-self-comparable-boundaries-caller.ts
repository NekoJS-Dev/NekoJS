import {
    $TypeScriptInheritedInterfaceTest$Value as Value,
    $TypeScriptInheritedInterfaceTest$TextValue as TextValue,
    $TypeScriptInheritedInterfaceTest$RemappedChild as RemappedChild,
    $TypeScriptInheritedInterfaceTest$StaticSetter as StaticSetter,
    $TypeScriptInheritedInterfaceTest$GenericValue as GenericValue,
    $TypeScriptInheritedInterfaceTest$RootValue as RootValue,
    $TypeScriptInheritedInterfaceTest$Constrained as Constrained,
    $TypeScriptInheritedInterfaceTest$BoundedReceiver as Receiver,
    $TypeScriptInheritedInterfaceTest$BoundedHost as Host,
    $TypeScriptInheritedInterfaceTest$ObjectValue as ObjectValue,
    $TypeScriptInheritedInterfaceTest$ObjectChild as ObjectChild,
    $TypeScriptInheritedInterfaceTest$ObjectContract as ObjectContract,
    $TypeScriptInheritedInterfaceTest$ReadyValue as ReadyValue,
    $TypeScriptInheritedInterfaceTest$ReadyContract as ReadyContract,
    $TypeScriptInheritedInterfaceTest$ComparableReceiver as ComparableReceiver,
    $TypeScriptInheritedInterfaceTest$SelfComparable as SelfComparable,
    $TypeScriptInheritedInterfaceTest$OtherComparable as OtherComparable,
    $TypeScriptInheritedInterfaceTest$NumericBounds as NumericBounds,
    $TypeScriptInheritedInterfaceTest$OperationChild as OperationChild,
    $TypeScriptInheritedInterfaceTest$ParentOperation as ParentOperation,
    $TypeScriptInheritedInterfaceTest$BeanChild as BeanChild,
    $TypeScriptInheritedInterfaceTest$NestedGetterChild as NestedGetterChild,
} from '../../common/build/probe-ts-inherited-interface/index';

const value = new Value<string>('x');
const echo: string = value.echo('y');
const ownOverload: number = value.echo();
const identity: number = value.identity(3);
const array: string[] = value.array(['x']);
const size: number = value.size();
const text = new TextValue('x');
const inherited: string = text.echo('z');
// @ts-expect-error The real Java interface factory is not inherited by class instances.
value.factory();
// @ts-expect-error Hidden interface members remain unavailable in generated declarations.
value.hidden();
// @ts-expect-error Class type arguments constrain inherited default methods.
value.echo(3);
// @ts-expect-error Method type variables retain their actual return type.
const wrong: string = value.identity(3);
void [echo, ownOverload, identity, array, size, inherited, wrong];

const remapped = new RemappedChild();
const stringCall: string = remapped.call("x");
const numberCall: number = remapped.call(7);
// @ts-expect-error Remapping retains the actual parameter types.
remapped.call(true);
void [stringCall, numberCall];

const readOnly = new StaticSetter();
const read: string = readOnly.value;
StaticSetter.setValue("class operation");
// @ts-expect-error A static setter does not make an instance property writable.
readOnly.value = "invalid";
// @ts-expect-error Static operations remain unavailable on instances.
readOnly.setValue("invalid");
void read;

const generic = new GenericValue<string>();
const transformed: number = generic.transform("class value", 7);
const rootValue = new RootValue();
const constrained: Constrained<RootValue> = generic.bounded(rootValue);
// @ts-expect-error The inherited class argument remains string.
generic.transform(7, "method value");
// @ts-expect-error Actual method bounds reject unrelated primitive input.
generic.bounded(7);
void [transformed, constrained];
const receiver = new Receiver();
const callbackResult: RootValue = receiver.apply(input => input);
const actualHostResult: RootValue = receiver.apply(new Host());
// @ts-expect-error The actual bounded callback result rejects unrelated values.
receiver.apply(input => input.marker);
void [callbackResult, actualHostResult];

const objectValue: ObjectContract = new ObjectValue();
const equal: boolean = objectValue.equals(objectValue);
const hash: number = objectValue.hashCode();
const ready: ReadyContract = new ReadyValue();
const readyGetter: boolean = ready.getReady();
const readyPredicate: boolean = ready.isReady();
// @ts-expect-error No unrelated Object getter is introduced by the interface contract.
new ObjectValue().getClass();
void [equal, hash, readyGetter, readyPredicate];

const objectChild = new ObjectChild();
const childObjectEqual: boolean = objectChild.equals(objectChild);
const childStringEqual: boolean = objectChild.equals("child");
const childHash: number = objectChild.hashCode();
const childContract: ObjectContract = objectChild;
// @ts-expect-error Inherited interface requirements do not expose unrelated Object getters.
objectChild.getClass();
void [childObjectEqual, childStringEqual, childHash, childContract];
const operationChild = new OperationChild();
const inheritedOperation: string = operationChild.operation();
const operationContract: ParentOperation = operationChild;
const operationObjectEqual: boolean = operationChild.equals(operationChild);
const operationStringEqual: boolean = operationChild.equals("child");
void [inheritedOperation, operationContract, operationObjectEqual, operationStringEqual];
const beanChild = new BeanChild();
beanChild.value = "written";
beanChild.setValue("explicit");
const beanRead: string = beanChild.value;
// @ts-expect-error The inherited generic setter accepts the child's actual string argument.
beanChild.value = 7;
// @ts-expect-error Direct inherited setter calls retain their actual generic parameter.
beanChild.setValue(7);
void beanRead;

const nestedGetter = new NestedGetterChild();
nestedGetter.value = "written";
nestedGetter.setValue("explicit");
const nestedRead: string = nestedGetter.value;
// @ts-expect-error Nested getter names retain the real inherited string write type.
nestedGetter.value = 7;
// @ts-expect-error Explicit inherited setters keep their actual argument type.
nestedGetter.setValue(7);
void nestedRead;

const comparableReceiver = new ComparableReceiver();
const selectedNumber: number = comparableReceiver.apply(input => input + 1);
declare const primitiveHost: SelfComparable<number>;
const projectedNumber: number = primitiveHost.select(7);
// @ts-expect-error The real Integer callback cannot return a string.
comparableReceiver.apply(input => String(input));
// @ts-expect-error An unrelated host object does not satisfy the self-comparable bound.
declare const unrelatedComparable: SelfComparable<RootValue>;
// @ts-expect-error Symbols are not Java boxed self-comparable primitives.
declare const symbolComparable: SelfComparable<symbol>;
void [selectedNumber, projectedNumber, unrelatedComparable, symbolComparable];

const numericBounds = new NumericBounds();
const boundedNumericResult: number = numericBounds.select(7);
// @ts-expect-error Other bounds still constrain projected primitives.
numericBounds.select("invalid");
// @ts-expect-error A Comparable of a different type retains its actual host constraint.
declare const wrongComparableArgument: OtherComparable<number>;
const selectedFlag: boolean = comparableReceiver.flag(input => !input);
const selectedText: string = comparableReceiver.text(input => input + "!");
void [boundedNumericResult, wrongComparableArgument, selectedFlag, selectedText];
