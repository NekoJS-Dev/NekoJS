import hashlib
import json
import shutil
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
target = project/'build/ticket37-inherited-accessor-pre-review-artifacts'
assert not target.exists()
target.mkdir()
patch = subprocess.check_output(['git', 'diff', 'e48ea68', '--', 'common/src/main/java'])
(target/'production-source.patch').write_bytes(patch)
rows = []
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    libs = project/'versions'/node/'build/libs'
    jars = list(libs.glob('*-server.jar')) if node == '1.21.1' else [p for p in libs.glob('*.jar')
        if not p.name.endswith(('-dev.jar', '-sources.jar'))]
    assert len(jars) == 1
    jar = jars[0]
    (target/node).mkdir()
    shutil.copyfile(jar, target/node/jar.name)
    rows.append(dict(node=node, jar=jar.name, sha256=hashlib.sha256(jar.read_bytes()).hexdigest(), installed=False))
(target/'manifest.json').write_text(json.dumps(dict(sourceBase='e48ea68cafbde0007ac7271d99615c146199853b',
    productionPatchSha256=hashlib.sha256(patch).hexdigest(), status='Pre-review source; never installed', artifacts=rows), indent=2)+'\n')
print(json.dumps(rows))
