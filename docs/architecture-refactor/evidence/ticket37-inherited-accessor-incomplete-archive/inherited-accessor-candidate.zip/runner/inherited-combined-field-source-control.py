import hashlib
import json
import subprocess
import sys
from pathlib import Path

source = Path('common/src/main/java/com/tkisor/nekojs/probe/backend/python/PythonClassRenderer.java')
original = source.read_bytes()
needle = b'\n                    && !fields.contains(pyIdent(method.property))'
assert original.count(needle) == 1
controlled = original.replace(needle, b'')
directory = Path('build/ticket37-config-sync-repair')
stage = sys.argv[1]
with (directory/f'inherited-combined-field-source-control-{stage}.java').open('xb') as stream:
    stream.write(controlled)
result = None
try:
    source.write_bytes(controlled)
    log = directory/f'inherited-combined-field-confirmed-{stage}-red.txt'
    with log.open('xb') as stream:
        result = subprocess.run([str(Path('gradlew.bat').resolve()), ':common:test', '--tests',
            '*PythonBeanMemberCollisionTest.nestedAccessorAliasDoesNotReplaceDeclaredOrInheritedFields',
            '--console=plain'], stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 1, result.returncode
    assert 'nestedAccessorAliasDoesNotReplaceDeclaredOrInheritedFields() FAILED' in log.read_text(), log
    snapshot = subprocess.run(['C:/Users/11515/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/python.exe',
        str(directory/'snapshot-current-tests.py'), f'build/ticket37-inherited-combined-field-confirmed-{stage}-red', 'common'])
    assert snapshot.returncode == 0
finally:
    source.write_bytes(original)
    assert source.read_bytes() == original
    (directory/f'inherited-combined-field-source-control-{stage}.json').write_text(json.dumps(dict(
        originalSha256=hashlib.sha256(original).hexdigest(), controlledSha256=hashlib.sha256(controlled).hexdigest(),
        sourceRestored=True, testExit=None if result is None else result.returncode), indent=2)+'\n')
