import json
import subprocess
from pathlib import Path

directory = Path('build/ticket37-config-sync-repair')
rows = []
for control in ['positive', 'negative']:
    caller = directory/f'inherited-field-python-{control}.py'
    caller.write_text('from fixture import PythonBeanMemberCollisionTest_StringGetterChild\n'
        'target = PythonBeanMemberCollisionTest_StringGetterChild()\n'
        'read: str = target.value\n'
        'target.value = False\n'
        'explicit: str = target.getValue()\n'
        + ('target.value = "invalid"\n' if control == 'negative' else ''))
    config = directory/f'inherited-field-python-{control}-config.json'
    with config.open('x') as stream:
        json.dump(dict(typeCheckingMode='strict', include=[caller.name,
            '../../common/build/probe-python-inherited-field/fixture.pyi'],
            extraPaths=['../../common/build/probe-python-inherited-field']), stream, indent=2)
    report_path = directory/f'inherited-field-python-{control}-pyright.json'
    with report_path.open('xb') as stream:
        result = subprocess.run(['node', 'C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js',
            '--project', str(config), '--outputjson'], stdout=stream, stderr=subprocess.PIPE)
    assert not result.stderr
    report = json.loads(report_path.read_text())
    assert report['summary']['filesAnalyzed'] == 2
    errors = [d for d in report['generalDiagnostics'] if d['severity'] == 'error']
    rows.append(dict(control=control, exitCode=result.returncode, summary=report['summary'], errors=errors))
(directory/'inherited-field-python-summary.json').write_text(json.dumps(rows, indent=2)+'\n')
print(json.dumps(rows))
