from pathlib import Path

directory = Path('build/ticket37-config-sync-repair')
names = ['prepare-inherited-selective-installed.py', 'check-inherited-selective-ide.py',
         'await-inherited-selective-ide.py', 'compare-inherited-selective-outputs.py',
         'archive-inherited-selective-candidate.py', 'inherited-selective-ports.py']
for name in names:
    target = directory/name.replace('selective', 'closure')
    assert not target.exists(), target
    source = (directory/name).read_text().replace('inherited-selective-installed', 'inherited-closure-installed')
    if name == 'prepare-inherited-selective-installed.py':
        source = source.replace("shutil.copyfile(source / 'fabric-server-launch.jar', directory / 'fabric-server-launch.jar')",
            "shutil.copyfile(source / 'fabric-server-launch.jar', directory / 'fabric-server-launch.jar')\n"
            "        cached = project / 'build/ticket37-inherited-selective-installed' / node / '.fabric/server'\n"
            "        shutil.copytree(cached, directory / '.fabric/server')\n"
            "        assert not any(path.suffix == '.tmp' for path in (directory/'.fabric/server').iterdir())")
        source = source.replace("fixtureHashes=fixtures))", "fixtureHashes=fixtures, fabricServerCacheHashes={\n"
            "        p.name: hashlib.sha256(p.read_bytes()).hexdigest()\n"
            "        for p in (directory/'.fabric/server').glob('*.jar')} if node.endswith('-fabric') else {}))")
    if name == 'await-inherited-selective-ide.py':
        source = source.replace('check-inherited-selective-ide.py', 'check-inherited-closure-ide.py')
        source = source.replace('inherited-selective-ide-exit.json', 'inherited-closure-ide-exit.json')
    if name == 'archive-inherited-selective-candidate.py':
        source = source.replace('ticket37-inherited-selective-candidate', 'ticket37-inherited-closure-candidate')
        source = source.replace('inherited-selective-candidate.zip', 'inherited-closure-candidate.zip')
        source = source.replace("['ticket37-inherited-selective-matrix',", "['ticket37-inherited-closure-matrix', 'ticket37-inherited-getter-closure-red',\n"
            "               'ticket37-inherited-getter-closure-green', 'ticket37-inherited-nested-getter-alias-red',\n"
            "               'ticket37-inherited-nested-getter-alias-green', 'ticket37-inherited-selective-matrix',")
        source = source.replace("project/'build/ticket37-inherited-selective-matrix/summary.json'", "project/'build/ticket37-inherited-closure-matrix/summary.json'")
        source = source.replace("'probe-python-inherited-bean']", "'probe-python-inherited-bean', 'probe-python-nested-getter']")
        source = source.replace('full IDE failures and nested getter selection order remain under diagnosis', 'full IDE failures remain under diagnosis')
    target.write_text(source, encoding='utf-8')
    print(target)
