from fixture import PythonBeanMemberCollisionTest_NestedGetterChild
from fixture import PythonBeanMemberCollisionTest_GetterNamedField
from fixture import PythonBeanMemberCollisionTest_FieldAndNestedGetter
from fixture import PythonBeanMemberCollisionTest_InheritedFieldAndNestedGetter

target = PythonBeanMemberCollisionTest_NestedGetterChild()
target.value = "written"
read: str = target.value
explicit: str = target.getValue()
nested: str = target.getGetValue()
outer: str = target.getGetGetValue()
field = PythonBeanMemberCollisionTest_GetterNamedField()
field_read: bool = field.isLive
bean_read: bool = field.live
combined = PythonBeanMemberCollisionTest_FieldAndNestedGetter()
combined.isLive = False
combined_read: bool = combined.isLive
combined_explicit: bool = combined.getIsLive()
inherited = PythonBeanMemberCollisionTest_InheritedFieldAndNestedGetter()
inherited_read: bool = inherited.isLive
inherited_explicit: bool = inherited.getIsLive()
