from pathlib import Path

directory = Path('build/ticket37-config-sync-repair')
for name in ['prepare-inherited-closure-installed.py', 'check-inherited-closure-ide.py',
             'await-inherited-closure-ide.py', 'compare-inherited-closure-outputs.py',
             'archive-inherited-closure-candidate.py', 'inherited-closure-ports.py']:
    target = directory / name.replace('closure', 'accessor')
    assert not target.exists(), target
    source = (directory / name).read_text().replace('inherited-closure', 'inherited-accessor')
    if name == 'archive-inherited-closure-candidate.py':
        source = source.replace("['ticket37-inherited-accessor-matrix',", "['ticket37-inherited-accessor-matrix',\n"
            "               'ticket37-inherited-accessor-field-final-focused',\n"
            "               'ticket37-inherited-field-different-types-red', 'ticket37-inherited-field-different-types-green',\n"
            "               'ticket37-inherited-field-edited-ir-green',\n"
            "               'ticket37-inherited-getter-field-conflict-red',\n"
            "               'ticket37-inherited-combined-field-alias-red',\n"
            "               'ticket37-inherited-accessor-field-first-red',\n"
            "               'ticket37-inherited-combined-field-confirmed-red',\n"
            "               'ticket37-inherited-combined-field-confirmed-retry-red',\n"
            "               'ticket37-inherited-closure-matrix',")
        source = source.replace("'probe-python-nested-getter']", "'probe-python-nested-getter', 'probe-python-inherited-field']")
        source = source.replace("('comparison-2d0b.json', trial/'ide/comparison-2d0b.json')", 
            "('comparison-2d0b.json', trial/'ide/comparison-2d0b.json'), ('comparison-b306.json', trial/'ide/comparison-b306.json')")
    if name == 'compare-inherited-closure-outputs.py':
        source = source.replace("('2d0b', 'ticket37-inherited-selective-installed')", 
            "('2d0b', 'ticket37-inherited-selective-installed'), ('b306', 'ticket37-inherited-closure-installed')")
    target.write_text(source, encoding='utf-8')
    print(target)
