import json
import socket
from pathlib import Path

trial = Path('build/ticket37-inherited-closure-installed')
manifest = json.loads((trial/'preparation-manifest.json').read_text())
ports = []
for node in manifest['nodes']:
    assert json.loads((trial/node['node']/'server-exit.json').read_text())['exitCode'] == 0
    for port in [node['serverPort'], node['rconPort']]:
        with socket.socket() as guard:
            guard.bind(('127.0.0.1', port))
        ports.append(port)
record = dict(normalDirectServerExits=True, freeExclusivePorts=ports)
with (trial/'runtime-ports-freed.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record))
