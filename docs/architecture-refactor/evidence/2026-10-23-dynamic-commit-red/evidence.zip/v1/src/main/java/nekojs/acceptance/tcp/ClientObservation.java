package nekojs.acceptance.tcp;

import com.google.gson.Gson;
import com.tkisor.nekojs.core.fs.ClassFilter;
import com.tkisor.nekojs.platform.compat.McClientCompat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Drives only owned client lifecycle actions; production network queues and handlers remain untouched. */
@EventBusSubscriber(modid = "neko_tcp_acceptance", value = Dist.CLIENT)
public final class ClientObservation {
    private static String previous = "";
    private static String lastAction = "idle";

    @SubscribeEvent
    public static void tick(ClientTickEvent.Post event) throws Exception {
        Minecraft client = Minecraft.getInstance();
        String action = Files.readString(Path.of("action.txt")).trim();
        if (!lastAction.equals(action)) {
            lastAction = action;
            if (action.equals("close")) {
                System.out.println("OWNED-TCP-NORMAL-STOP");
                client.stop();
                return;
            }
            if (action.equals("fault:off")) {
                System.setProperty("nekojs.acceptance.commitFault", "false");
                System.out.println("OWNED-TCP-COMMIT-FAULT-DISABLED");
            }
            if (action.startsWith("block:")) {
                long millis = Long.parseLong(action.substring(6));
                if (millis < 1 || millis > 15000) throw new IllegalArgumentException("Owned delay exceeds fixture bounds");
                System.out.println("OWNED-TCP-OWNER-BLOCK-BEGIN " + millis);
                Thread.sleep(millis);
                System.out.println("OWNED-TCP-OWNER-BLOCK-END " + millis);
            }
            if (action.startsWith("connect:")) {
                String address = action.substring(8);
                ConnectScreen.startConnecting(new TitleScreen(), client, ServerAddress.parseString(address),
                        new ServerData("Owned TCP acceptance", address, ServerData.Type.OTHER), false, null);
            }
        }
        Map<String, Object> state = new LinkedHashMap<>();
        state.put("sameThread", client.isSameThread());
        state.put("connected", client.getConnection() != null && client.player != null);
        state.put("screen", McClientCompat.get().currentScreen() == null ? null : McClientCompat.get().currentScreen().getClass().getName());
        state.put("gateEnabled", ClassFilter.INSTANCE.config() != null && ClassFilter.INSTANCE.config().dynamicRegistryEnabled());
        state.put("items", RegistryObservation.items());
        state.put("faultEnabled", Boolean.parseBoolean(System.getProperty("nekojs.acceptance.commitFault", "true")));
        String json = new Gson().toJson(state);
        if (!previous.equals(json)) {
            RegistryObservation.write("client-observation", json);
            previous = json;
        }
    }
}
