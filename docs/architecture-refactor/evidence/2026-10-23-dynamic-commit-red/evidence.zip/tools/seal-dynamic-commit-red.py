"""Preserve the real disconnect failure before applying the holder cleanup fix."""
import hashlib
import json
import zipfile
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
dest = repo / 'docs/architecture-refactor/evidence/2026-10-23-dynamic-commit-red'
assert not dest.exists()
entries = {}
redactions = {}
results = []
for attempt in ['v1', 'v2', 'v3']:
    root = tools / ('dynamic-commit-1f877b0f-261-' + attempt)
    result = json.loads((root / 'run-result.json').read_text())
    assert result['verdict'] == 'NOT GREEN' and not result['forced']
    results.append(dict(attempt=attempt, **result))
    props = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines() if '=' in line and not line.startswith('#'))
    secret = props['rcon.password']
    files = [file for file in root.iterdir() if file.is_file() and (file.suffix == '.json' or file.name.endswith(('-stdout.log', '-stderr.log')) or file.name == 'run-driver.py')]
    files += [file for file in (root / 'src').rglob('*') if file.is_file()]
    files += list(root.glob('*/crash-reports/*.txt'))
    for side in ['server', 'clientA', 'clientB']:
        files += list((root / side).glob('*.json*'))
    for file in files:
        name = attempt + '/' + file.relative_to(root).as_posix()
        original = data = file.read_bytes()
        if secret:
            for encoding in ['utf8', 'utf-16-le', 'utf-16-be']:
                data = data.replace(secret.encode(encoding), '[REDACTED]'.encode(encoding))
        entries[name] = data
        if data != original:
            redactions[name] = hashlib.sha256(original).hexdigest()
assert len(results[2]['stages']) == 4
assert results[2]['exits'] == dict(server=0, clientA=4294967295, clientB=0)
assert results[0]['exits'] == dict(server=1)
assert results[1]['exits'] == dict(server=0, clientA=0, clientB=4294967295)
assert b'Some intrusive holders were not registered' in next(data for name, data in entries.items() if name.startswith('v3/clientA/crash-reports/'))
for name in ['prepare-dynamic-commit-failure.py', 'derive-dynamic-commit-runner.py',
             'bind-dynamic-commit-candidate.py', 'seal-dynamic-commit-red.py']:
    entries['tools/' + name] = (tools / name).read_bytes()
entries['summary.json'] = (json.dumps(dict(productionRevision='1f877b0fa7435be6fea61a44ff2e9266ce2c3c2a',
    verdict='NOT GREEN', attempts=results, actualDefect='Failed physical registration retains new unregistered intrusive holders; later NeoForge disconnect freeze crashes.',
    scope='26.1.2 real TCP with installed candidate, server plus two remote clients.',
    proposedFix='Shared RegistrySurgery failure boundary; preserve preexisting holders and remove only new unbound identities.',
    limitations=['First v1 driver was overwritten before freezing; v1 helper source/log/result retained.',
        '26.2.0 failure case not executed.', 'Recovery stages 5-7 remain unverified.',
        'No maintainer acceptance or release conclusion.']), indent=2) + '\n').encode()
dest.mkdir()
with zipfile.ZipFile(dest / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(dest / 'manifest.json').write_text(json.dumps(dict(archiveSha256=hashlib.sha256((dest / 'evidence.zip').read_bytes()).hexdigest(),
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())},
    redactedOriginalHashes=redactions), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(dest / 'evidence.zip').stat().st_size, verdict='NOT GREEN')))
