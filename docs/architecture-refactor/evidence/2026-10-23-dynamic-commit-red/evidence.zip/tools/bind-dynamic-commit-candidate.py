"""Bind the observed installed candidate to committed sources and the frozen normal build."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
revision = '1f877b0fa7435be6fea61a44ff2e9266ce2c3c2a'
tracked = subprocess.check_output(['git', 'ls-files'], text=True).splitlines()
paths = [name for name in tracked if '/src/main/' in '/' + name or name.startswith('src/main/')
         or name.endswith(('.gradle', '.gradle.kts')) or name in ['gradle.properties', 'gradle/libs.versions.toml']]
batch = subprocess.run(['git', 'cat-file', '--batch'], input=''.join(revision + ':' + name + '\n' for name in paths).encode(),
                       stdout=subprocess.PIPE, check=True).stdout
offset = 0
sources = {}
for name in paths:
    boundary = batch.index(b'\n', offset)
    header = batch[offset:boundary].decode().split()
    assert len(header) == 3 and header[1] == 'blob', (name, header)
    size = int(header[2])
    data = batch[boundary + 1:boundary + 1 + size]
    offset = boundary + size + 2
    current = (repo / name).read_bytes()
    assert current.replace(b'\r\n', b'\n') == data.replace(b'\r\n', b'\n'), name
    sources[name] = dict(committedBlob=header[0], workingSha256=hashlib.sha256(current).hexdigest())
with zipfile.ZipFile(repo / 'docs/architecture-refactor/evidence/2026-10-23-event-node-followup/evidence.zip') as archive:
    frozen = json.loads(archive.read('summary.json'))
assert frozen['productionRevision'] == revision
bindings = {}
for short, attempt, node in [('261', 'v3', '26.1.2'), ('262', 'v2', '26.2.0')]:
    root = tools / f'dynamic-commit-1f877b0f-{short}-{attempt}'
    prep = json.loads((root / 'preparation.json').read_text())
    assert prep['jar'] == frozen['artifacts'][node]
    jar = root / 'server/mods' / prep['jar']['name']
    assert hashlib.sha256(jar.read_bytes()).hexdigest() == prep['jar']['sha256']
    classes = {}
    with zipfile.ZipFile(jar) as archive:
        for directory in [repo / 'common/build/classes/java/main', repo / 'versions' / node / 'build/classes/java/main']:
            for file in directory.rglob('*.class'):
                name = file.relative_to(directory).as_posix()
                digest = hashlib.sha256(file.read_bytes()).hexdigest()
                assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
                classes[name] = digest
    binding = dict(productionRevision=revision, sourceVerification='Current tracked production sources/configuration equal committed bytes after line-ending normalization.',
        sourceBindings=sources, classBindings=classes, jar=prep['jar'], frozenOrdinaryBuildSummary=frozen,
        timing='Post-run provenance verification; does not replace historical preparation.json.')
    (root / 'candidate-binding.json').write_text(json.dumps(binding, indent=2) + '\n')
    bindings[node] = dict(sourceFiles=len(sources), compiledClasses=len(classes), jar=prep['jar'])
print(json.dumps(bindings))
