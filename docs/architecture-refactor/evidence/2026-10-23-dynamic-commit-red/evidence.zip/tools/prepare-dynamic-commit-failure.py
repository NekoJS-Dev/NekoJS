"""Prepare fresh installed TCP fixtures with a narrowly scoped helper-only physical fault."""
import hashlib
import json
import shutil
import socket
import sys
from pathlib import Path

repo = Path.cwd()
node = sys.argv[1]
assert node in ['26.1.2', '26.2.0']
short = '261' if node == '26.1.2' else '262'
port = 29991 if short == '261' else 30091
loader = '26.1.2.71' if short == '261' else '26.2.0.57'
server_loader = '26.1.2.71' if short == '261' else '26.2.0.75'
source = repo / 'build/priority-closeout/dynamic-tcp-d91ca974-v1'
installed = repo / 'build/closeout-7bea6d6d-installed' / node
attempt = sys.argv[2] if len(sys.argv) > 2 else 'v1'
assert attempt in ['v1', 'v2', 'v3']
root = repo / f'build/priority-closeout/dynamic-commit-1f877b0f-{short}-{attempt}'
assert not root.exists()
for check_port in [port, port + 1]:
    with socket.socket() as connection:
        connection.bind(('127.0.0.1', check_port))
root.mkdir()
shutil.copyfile(source / 'settings.gradle', root / 'settings.gradle')
build = (source / 'build.gradle').read_text(encoding='utf8').replace(source.name, root.name)
build = build.replace('26.1.2.71', loader).replace('neoforge-26.1.2-', f'neoforge-{node}-').replace('28791', str(port))
build = build.replace("jvmArguments.addAll('-Xmx2G',", "jvmArguments.add('-Dneoforge.warnings.logofile.hide=true')\n            jvmArguments.addAll('-Xmx2G',")
(root / 'build.gradle').write_text(build, encoding='utf8')
shutil.copytree(source / 'src', root / 'src')
java_root = root / 'src/main/java/nekojs/acceptance/tcp'
client = java_root / 'ClientObservation.java'
text = client.read_text(encoding='utf8')
text = text.replace('import com.tkisor.nekojs.core.fs.ClassFilter;',
    'import com.tkisor.nekojs.core.fs.ClassFilter;\nimport com.tkisor.nekojs.platform.compat.McClientCompat;')
text = text.replace('client.screen', 'McClientCompat.get().currentScreen()')
text = text.replace('if (action.startsWith("block:")) {',
    'if (action.equals("fault:off")) {\n                System.setProperty("nekojs.acceptance.commitFault", "false");\n                System.out.println("OWNED-TCP-COMMIT-FAULT-DISABLED");\n            }\n            if (action.startsWith("block:")) {')
text = text.replace('state.put("items", RegistryObservation.items());',
    'state.put("items", RegistryObservation.items());\n        state.put("faultEnabled", Boolean.parseBoolean(System.getProperty("nekojs.acceptance.commitFault", "true")));')
text = text.replace('RegistryObservation.write("client-observation", json);\n            previous = json;',
    'if (RegistryObservation.write("client-observation", json)) previous = json;')
client.write_text(text, encoding='utf8')
registry = java_root / 'RegistryObservation.java'
text = registry.read_text(encoding='utf8').replace('"tcp_disconnect"}', '"tcp_disconnect", "tcp_commit_fail", "tcp_followup"}')
text = text.replace('private RegistryObservation() {}', 'private RegistryObservation() {}\n\n    private static int publishRetries;')
text = text.replace('static void write(String name, String json)', 'static boolean write(String name, String json)')
text = text.replace('Files.move(pending, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);',
    '''try {
            Files.move(pending, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (java.nio.file.AccessDeniedException denied) {
            // Windows readers can briefly deny replacement; retry on a later tick without blocking it.
            if (++publishRetries > 100) throw denied;
            if (publishRetries == 1) System.out.println("OWNED-TCP-OBSERVATION-PUBLISH-RETRY " + name);
            return false;
        }
        publishRetries = 0;''')
text = text.replace('StandardOpenOption.APPEND);', 'StandardOpenOption.APPEND);\n        return true;')
registry.write_text(text, encoding='utf8')
server = java_root / 'ServerObservation.java'
server.write_text(server.read_text(encoding='utf8').replace('RegistryObservation.write("server-observation", json);\n            previous = json;',
    'if (RegistryObservation.write("server-observation", json)) previous = json;'), encoding='utf8')
acceptance = java_root / 'AcceptanceMod.java'
acceptance.write_text(acceptance.read_text(encoding='utf8').replace('"com.tkisor.nekojs.dynamic.DynamicRegistryFacade"}',
    '"com.tkisor.nekojs.dynamic.DynamicRegistryFacade", "com.tkisor.nekojs.core.dynamic.txn.DynamicRegistryClientParticipant", "com.tkisor.nekojs.probe.backend.typescript.EventDeclarationGenerator"}'), encoding='utf8')
(java_root / 'mixin').mkdir()
(java_root / 'mixin/CommitFaultMixin.java').write_text('''package nekojs.acceptance.tcp.mixin;

import net.minecraft.core.Holder;
import net.minecraft.core.MappedRegistry;
import net.minecraft.core.RegistrationInfo;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Rejects only the owned client A fixture key at the actual physical registration boundary. */
@Mixin(MappedRegistry.class)
public abstract class CommitFaultMixin<T> {
    @Inject(method = "register(Lnet/minecraft/resources/ResourceKey;Ljava/lang/Object;Lnet/minecraft/core/RegistrationInfo;)Lnet/minecraft/core/Holder$Reference;",
            at = @At("HEAD"), require = 1)
    private void ownedCommitFault(ResourceKey<T> key, T value, RegistrationInfo info,
            CallbackInfoReturnable<Holder.Reference<T>> callback) {
        if (!key.identifier().toString().equals("nekojs_acceptance:tcp_commit_fail")) return;
        String owner = System.getProperty("nekojs.acceptance.owner", "");
        if (!owner.endsWith("-clientA") || (Object) this != BuiltInRegistries.ITEM
                || !Boolean.parseBoolean(System.getProperty("nekojs.acceptance.commitFault", "true"))) return;
        System.out.println("OWNED-TCP-COMMIT-FAULT owner=" + owner + " thread=" + Thread.currentThread().getName());
        throw new IllegalStateException("OWNED-TCP-COMMIT-FAULT physical registration rejected for " + key.identifier());
    }
}
''', encoding='utf8')
resources = root / 'src/main/resources'
(resources / 'owned-commit-fault.mixins.json').write_text(json.dumps(dict(required=True,
    minVersion='0.8', package='nekojs.acceptance.tcp.mixin', compatibilityLevel='JAVA_25',
    mixins=['CommitFaultMixin'], injectors=dict(defaultRequire=1)), indent=2) + '\n')
toml = resources / 'META-INF/neoforge.mods.toml'
with toml.open('a', encoding='utf8') as output:
    output.write('\n[[mixins]]\nconfig="owned-commit-fault.mixins.json"\n')
jar = next((repo / 'versions' / node / 'build/libs').glob('*.jar'))
for side in ['server', 'clientA', 'clientB']:
    directory = root / side
    (directory / 'nekojs/config').mkdir(parents=True)
    for folder in ['server_scripts', 'startup_scripts', 'client_scripts', 'data']:
        (directory / 'nekojs' / folder).mkdir()
    (directory / 'nekojs/config/engine.toml').write_text('[dynamicRegistry]\nenabled = true\n')
    (directory / 'action.txt').write_text('idle')
    (directory / 'mods').mkdir()
    for file in (installed / 'mods').glob('graal*.jar'):
        shutil.copyfile(file, directory / 'mods' / file.name)
    shutil.copyfile(jar, directory / 'mods' / jar.name)
    if side != 'server':
        shutil.copyfile(source / side / 'options.txt', directory / 'options.txt')
shutil.copyfile(source / 'server/eula.txt', root / 'server/eula.txt')
properties = (source / 'server/server.properties').read_text().replace('28791', str(port)).replace('28792', str(port + 1))
properties = '\n'.join(line for line in properties.splitlines() if not line.startswith('pause-when-empty-seconds='))
(root / 'server/server.properties').write_text(properties + '\npause-when-empty-seconds=-1\n')
(root / 'server/libraries').symlink_to((installed / 'libraries').resolve(), target_is_directory=True)
bindings = {}
for name in ['26.1.2', '26.2.0']:
    if name != node:
        continue
    for file in (repo / 'versions' / name / 'build/classes/java/main').rglob('*.class'):
        bindings[file.relative_to(repo / 'versions' / name / 'build/classes/java/main').as_posix()] = hashlib.sha256(file.read_bytes()).hexdigest()
(root / 'preparation.json').write_text(json.dumps(dict(productionRevision='1f877b0fa7435be6fea61a44ff2e9266ce2c3c2a',
    freshWorld=True, clientLoader=loader, serverLoader=server_loader, port=port,
    jar=dict(name=jar.name, sha256=hashlib.sha256(jar.read_bytes()).hexdigest()), classBindings=bindings,
    isolation='Only owned directories opt into dynamic activation; helper fault is clientA plus exact ITEM key.',
    status='PREPARATION ONLY'), indent=2) + '\n')
print(root)
