"""Reuse the frozen owned lifecycle driver while replacing its acceptance scenario."""
import hashlib
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
base = (tools / 'run-dynamic-tcp-v3.py').read_text(encoding='utf8')
body = '''try:
    java = 'C:/Program Files/Java/jdk-25.0.2/bin/java.exe'
    prep = json.loads((root / 'preparation.json').read_text())
    jar_name = prep['jar']['name']
    server = start('server', [java, '-Xms512M', '-Xmx2G',
        '-Dnekojs.acceptance.owner=' + root.name + '-server',
        '-Dnekojs.acceptance.jar=' + str(root / 'server/mods' / jar_name),
        '@libraries/net/neoforged/neoforge/' + prep['serverLoader'] + '/win_args.txt', 'nogui'], 'server')
    wait(lambda: 'Done (' in log('server') and snapshot('server'), 300, 'server startup')
    server_ready = True
    assert 'OWNED-TCP-INSTALLED-SOURCE-PASS' in log('server')
    assert snapshot('server')['ledgerEmpty'] and snapshot('server')['ackTimeoutMillis'] == 10000
    assert not any(value['present'] for value in snapshot('server')['items'].values())
    a = start_client('clientA', 'clientA')
    wait(lambda: snapshot('clientA') and snapshot('clientA')['connected'], 300, 'client A join')
    b = start_client('clientB', 'clientB')
    wait(lambda: snapshot('clientB') and snapshot('clientB')['connected'], 300, 'client B join')
    assert snapshot('clientA')['gateEnabled'] and snapshot('clientB')['gateEnabled']
    assert 'OWNED-TCP-COMMIT-FAULT owner=' not in log('clientA')
    note('01-empty-two-enabled-clients')
    generation = reload_items(['tcp_seed'])
    terminal(generation, True)
    wait(lambda: all(item_present(side, 'tcp_seed') for side in ['server', 'clientA', 'clientB']), 30, 'normal physical activation')
    wait(lambda: len({value['participantId'] for value in outcomes(generation, 'activation-report')}) == 2, 30, 'normal dual reports')
    note('02-normal-dual-commit')
    generation = reload_items(['tcp_seed', 'tcp_commit_fail'])
    terminal(generation, True)
    wait(lambda: outcomes(generation, 'activation-failed-post-commit'), 30, 'real failed activation report')
    wait(lambda: item_present('server', 'tcp_commit_fail') and item_present('clientB', 'tcp_commit_fail'), 30, 'server and B physical activation')
    players = {value['name']: value['id'] for value in snapshot('server')['players']}
    assert {value['participantId'] for value in outcomes(generation, 'ack')} == set(players.values())
    failed = outcomes(generation, 'activation-failed-post-commit')
    assert len(failed) == 1 and failed[0]['participantId'] == players['OwnedTcpA']
    assert 'OWNED-TCP-COMMIT-FAULT' in failed[0]['reason']
    assert not item_present('clientA', 'tcp_commit_fail') and item_present('clientA', 'tcp_seed')
    assert snapshot('server')['status'] == 'COMMITTED' and snapshot('server')['activatedGeneration'] == generation
    assert any(value['generation'] == generation and value['phase'] == 'COMMIT' and value['passed'] for value in snapshot('server')['phaseLog'])
    note('03-real-commit-activation-failure')
    wait(lambda: outcomes(generation, 'state-sync-rejected'), 30, 'post-commit catch-up rejection')
    assert all(value['participantId'] == players['OwnedTcpA'] for value in outcomes(generation, 'state-sync-rejected'))
    assert log('clientA').count('OWNED-TCP-COMMIT-FAULT owner=') == 2
    assert 'thread=Render thread' in log('clientA')
    assert 'OWNED-TCP-COMMIT-FAULT owner=' not in log('clientB') + log('server')
    assert snapshot('clientA')['connected'] and snapshot('clientB')['connected']
    assert item_present('clientA', 'tcp_seed') and not item_present('clientA', 'tcp_commit_fail')
    note('04-failed-catch-up-retains-prior-client-state')
    rejected_before = len(outcomes(generation, 'state-sync-rejected'))
    command('kick OwnedTcpA Owned COMMIT failure reconnect acceptance')
    wait(lambda: not snapshot('clientA')['connected'] and len(snapshot('server')['players']) == 1, 30, 'A kicked')
    signal('clientA', 'connect:127.0.0.1:' + str(prep['port']))
    wait(lambda: len(outcomes(generation, 'state-sync-rejected')) > rejected_before, 90, 'configuration catch-up rejection')
    wait(lambda: not snapshot('clientA')['connected'] and 'DisconnectedScreen' in (snapshot('clientA').get('screen') or ''), 30, 'rejected A remains outside play')
    assert len(snapshot('server')['players']) == 1 and snapshot('clientB')['connected']
    assert not item_present('clientA', 'tcp_commit_fail') and snapshot('server')['activatedGeneration'] == generation
    assert log('clientA').count('OWNED-TCP-COMMIT-FAULT owner=') == 3
    assert outcomes(generation, 'state-sync-sent')
    note('05-reconnect-rejected-before-play')
    signal('clientA', 'fault:off')
    wait(lambda: snapshot('clientA') and not snapshot('clientA')['faultEnabled'], 30, 'fixture fault disabled')
    signal('clientA', 'connect:127.0.0.1:' + str(prep['port']))
    wait(lambda: snapshot('clientA')['connected'] and len(snapshot('server')['players']) == 2, 90, 'A recovery reconnect')
    wait(lambda: item_present('clientA', 'tcp_commit_fail') and outcomes(generation, 'state-sync-completed'), 30, 'successful physical catch-up')
    assert snapshot('server')['activatedGeneration'] == generation
    assert log('clientA').count('OWNED-TCP-COMMIT-FAULT owner=') == 3
    note('06-same-client-recovery-after-fault-removed')
    generation = reload_items(['tcp_seed', 'tcp_commit_fail', 'tcp_followup'])
    terminal(generation, True)
    wait(lambda: all(item_present(side, 'tcp_followup') for side in ['server', 'clientA', 'clientB']), 30, 'follow-up physical activation')
    wait(lambda: len({value['participantId'] for value in outcomes(generation, 'activation-report')}) == 2, 30, 'follow-up dual activation reports')
    assert {value['participantId'] for value in outcomes(generation, 'ack')} == set(players.values())
    assert not outcomes(generation, 'activation-failed-post-commit')
    for side in ['server', 'clientA', 'clientB']:
        for path in ['tcp_seed', 'tcp_commit_fail', 'tcp_followup']:
            assert snapshot(side)['items'][path] == dict(present=True, maxStackSize=16, rarity='RARE')
    note('07-subsequent-dual-commit-after-recovery')
'''
prefix, tail = base.split('\ntry:\n    java = ', 1)
_, cleanup = tail.split('\nexcept Exception as error:\n    result[\'errors\']', 1)
prefix = prefix.replace("(root / 'clientB/nekojs/config/engine.toml').write_text('[dynamicRegistry]\\nenabled = false\\n')", '')
prefix = prefix.replace('d91ca974ba88fe3507281b47a3bdb574322c5c9d', '1f877b0fa7435be6fea61a44ff2e9266ce2c3c2a')
runner = prefix + '\n' + body + "except Exception as error:\n    result['errors']" + cleanup
runner = runner.replace("len(result['stages']) == 8", "len(result['stages']) == 7")
for short in ['261', '262']:
    attempt = 'v3' if short == '261' else 'v2'
    name = f'dynamic-commit-1f877b0f-{short}-{attempt}'
    content = runner.replace('dynamic-tcp-d91ca974-v3', name)
    (tools / f'run-dynamic-commit-{short}.py').write_text(content, encoding='utf8')
print('Derived two owned drivers from base SHA-256', hashlib.sha256(base.encode()).hexdigest())
