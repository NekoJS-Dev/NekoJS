import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

root = Path('docs/architecture-refactor/evidence/ticket37-inherited-accessor-candidate')
manifest = json.loads((root/'manifest.json').read_text())
with ZipFile(root/manifest['archive']['file']) as archive:
    assert archive.testzip() is None
    for row in manifest['entries']:
        assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
    for stage in ['7e98', 'rejected-candidate', 'f469', '03cc', 'ec765', '2d0b', 'b306']:
        name = f'comparison-{stage}.json'
        current = Path('build/ticket37-inherited-accessor-installed/ide')/name
        assert current.read_bytes() == (root/name).read_bytes()
        assert archive.read(f'ticket37-inherited-accessor-installed/ide/{name}') == current.read_bytes()
    name = 'runner/inherited-accessor-comparisons.txt'
    assert archive.read(name) == Path('build/ticket37-config-sync-repair/inherited-accessor-comparisons.txt').read_bytes()
audit = json.loads((root/'golden-audit.json').read_text())
print(json.dumps(dict(entries=len(manifest['entries']), archiveSha256=hashlib.sha256(
    (root/manifest['archive']['file']).read_bytes()).hexdigest(), comparisonsComplete=True,
    goldenPackages=len(audit['files']), aliasChanges=sum(len(row['aliasChanges']) for row in audit['files']))))
