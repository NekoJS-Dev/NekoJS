from pathlib import Path
import json,re,subprocess
from zipfile import ZipFile
from collections import Counter
repo=Path.cwd(); target=repo/'build/bean-migration-prototype';target.mkdir(exist_ok=True)
archive=repo/'docs/architecture-refactor/evidence/2026-10-27-stream-capture-11c9a180/artifacts.zip'
changes=[]
with ZipFile(archive) as z:
 for name in z.namelist():
  if not name.startswith('installed/inputs/'):continue
  rel=name[len('installed/inputs/'):];dest=target/rel;data=z.read(name)
  if rel.endswith('@package/net/minecraft/core/index.d.ts'):
   text=data.decode()
   def edit(m):
    body=m[0]; edited,n=re.subn(r'^        [xyz]\(\): number;\r?\n','',body,flags=re.M)
    if n: changes.append(dict(file=rel,owner='SectionPos',removed=n))
    return edited
   text=re.sub(r'    export (?:class|interface) \$SectionPos(?: |\{)[\s\S]*?\n    }',edit,text)
   data=text.encode()
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 summary=json.loads(z.read('installed/ide-check-summary.json'));results=[]
 for node in summary['nodes']:
  for entry in node['typescript']:
   stem=node['node']+'-'+entry['side']; config=json.loads(z.read('installed/ide/'+stem+'-tsconfig.json'))
   config['extends']=str(target/node['node']/'nekojs'/(entry['side']+'_scripts')/'jsconfig.json')
   path=target/(stem+'.json');path.write_text(json.dumps(config))
   r=subprocess.run(['node',str(repo/'node_modules/typescript/bin/tsc'),'-p',str(path)],capture_output=True,timeout=180)
   (target/(stem+'-tsc.txt')).write_bytes(r.stdout)
   count=len(re.findall(r': error TS\d+:',r.stdout.decode()))
   assert r.returncode==2 and count>0 and not r.stderr
   results.append(dict(entry=stem,exitCode=r.returncode,count=count))
   print(stem,count,flush=True)
(target/'proposal.json').write_text(json.dumps(dict(changes=changes,entries=results,total=sum(x['count'] for x in results)),indent=2))
print('TOTAL',sum(x['count'] for x in results),changes,flush=True)
