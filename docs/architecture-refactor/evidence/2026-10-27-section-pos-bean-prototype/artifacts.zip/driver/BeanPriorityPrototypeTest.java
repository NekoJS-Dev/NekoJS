package com.tkisor.nekojs.probe;

import com.tkisor.nekojs.core.NekoSharedHostAccess;
import graal.graalvm.polyglot.Context;
import net.minecraft.core.SectionPos;
import net.minecraft.core.Vec3i;
import org.junit.jupiter.api.Test;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Records the actual Bean and method priority without assuming a declaration policy. */
class BeanPriorityPrototypeTest {
    @Test
    void recordCoordinateAccess() throws Exception {
        try (Context context = Context.newBuilder("js").allowExperimentalOptions(true)
                .allowHostAccess(new NekoSharedHostAccess(List.of()).get())
                .option("js.nashorn-compat", "true").option("js.ecmascript-version", "2022").build()) {
            context.getBindings("js").putMember("base", new Vec3i(1, 2, 3));
            context.getBindings("js").putMember("section", SectionPos.of(4, 5, 6));
            var result = context.eval("js", """
                JSON.stringify([base, section].map(value => {
                    const observations = {};
                    for (const key of ['x','y','z','getX','getY','getZ','x()','y()','z()']) {
                        try {
                            const member = value[key];
                            observations[key] = {kind:typeof member, result:typeof member === 'function' ? member() : member};
                        } catch (error) { observations[key] = {error:String(error)}; }
                    }
                    return observations;
                }))
                """).asString();
            var expressions = List.of("base.x", "base.getX()", "section.x", "section.x()", "section['x()']()", "section['getX()']()", "section.y()", "section['y()']()", "section.z()", "section['z()']()");
            var observations = new com.google.gson.JsonObject();
            observations.add("memberReads", com.google.gson.JsonParser.parseString(result));
            for (String expression : expressions) {
                var observation = new com.google.gson.JsonObject();
                try {
                    var value = context.eval("js", expression);
                    observation.addProperty("number", value.asInt());
                } catch (Exception error) { observation.addProperty("error", error.toString()); }
                observations.add(expression, observation);
            }
            Files.writeString(Path.of("build/bean-priority-runtime.json"), observations + "\n");
            System.out.println(result);
        }
    }
}
