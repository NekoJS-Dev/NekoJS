import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec, $DynamicOps, $Keyable, $Keyable_, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Int2IntMap } from "java:it/unimi/dsi/fastutil/ints";
import { $LongConsumer, $LongConsumer_ } from "java:it/unimi/dsi/fastutil/longs";
import { $Comparable, $Comparable_, $Enum, $Iterable, $Record } from "java:java/lang";
import { $AbstractList, $Collection, $Comparator, $Comparator_, $Iterator, $List, $Map$Entry, $Optional, $OptionalView, $Set, $Spliterator } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $Consumer, $Consumer_, $Function, $Function_, $IntFunction, $IntFunction_, $Predicate, $Predicate_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $FabricRegistry } from "java:net/fabricmc/fabric/api/event/registry";
import { $RemovableIdMapper } from "java:net/fabricmc/fabric/impl/registry/sync";
import { $RegistryMixin } from "java:net/fabricmc/fabric/mixin/registry/sync";
import { $DataComponentLookup, $DataComponentMap } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $RegistryOps, $ResourceKey } from "java:net/minecraft/resources";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $TagKey, $TagKey_, $TagLoader$LoadResult } from "java:net/minecraft/tags";
import { $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $ChunkPos, $Level } from "java:net/minecraft/world/level";
import { $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $ChunkAccess } from "java:net/minecraft/world/level/chunk";
import { $EntityAccess } from "java:net/minecraft/world/level/entity";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $Vector3i } from "java:org/joml";
import { $Logger } from "java:org/slf4j";

export * as component from "java:net/minecraft/core/component";
export * as particles from "java:net/minecraft/core/particles";

declare module "java:net/minecraft/core" {
    export class $AxisCycle {
        static BACKWARD: $AxisCycle;
        static FORWARD: $AxisCycle;
        static NONE: $AxisCycle;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AxisCycle[];
        static valueOf(name: string): $AxisCycle;
    }
    export interface $AxisCycle extends $Enum<$AxisCycle> {}

    export class $BlockPos {
        constructor(x: number, y: number, z: number);
        constructor(vec3i: $Vec3i);
        static CODEC: $Codec<$BlockPos>;
        static MAX_HORIZONTAL_COORDINATE: number;
        static PACKED_HORIZONTAL_LENGTH: number;
        static PACKED_Y_LENGTH: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $BlockPos>;
        static ZERO: $BlockPos;
        static asLong(x: number, y: number, z: number): number;
        static betweenClosedStream(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): $Stream<$BlockPos>;
        static betweenClosedStream(a: $BlockPos_, b: $BlockPos_): $Stream<$BlockPos>;
        static betweenClosedStream(boundingBox: $BoundingBox): $Stream<$BlockPos>;
        static betweenClosedStream(box: $AABB): $Stream<$BlockPos>;
        static betweenClosed(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): $Iterable<$BlockPos>;
        static betweenClosed(a: $BlockPos_, b: $BlockPos_): $Iterable<$BlockPos>;
        static betweenClosed(box: $AABB): $Iterable<$BlockPos>;
        static betweenCornersInDirection(firstCornerX: number, firstCornerY: number, firstCornerZ: number, secondCornerX: number, secondCornerY: number, secondCornerZ: number, direction: $Vec3_): $Iterable<$BlockPos>;
        static betweenCornersInDirection(firstCorner: $BlockPos_, secondCorner: $BlockPos_, direction: $Vec3_): $Iterable<$BlockPos>;
        static betweenCornersInDirection(aabb: $AABB, direction: $Vec3_): $Iterable<$BlockPos>;
        static breadthFirstTraversal(startPos: $BlockPos_, maxDepth: number, maxCount: number, neighbourProvider: $BiConsumer_<$BlockPos, $Consumer<$BlockPos>, $BlockPos, $Consumer<$BlockPos>>, nodeProcessor: $Function_<$BlockPos, $BlockPos$TraversalNodeStatus, $BlockPos, $BlockPos$TraversalNodeStatus_>): number;
        static containing(x: number, y: number, z: number): $BlockPos;
        static containing(pos: $Position): $BlockPos;
        static findClosestMatch(startPos: $BlockPos_, horizontalSearchRadius: number, verticalSearchRadius: number, predicate: $Predicate_<$BlockPos, $BlockPos, boolean>): $Optional<$BlockPos>;
        static getFlatIndex(neighborBlockNode: number): number;
        static getX(blockNode: number): number;
        static getY(blockNode: number): number;
        static getZ(blockNode: number): number;
        static max(a: $BlockPos_, b: $BlockPos_): $BlockPos;
        static min(a: $BlockPos_, b: $BlockPos_): $BlockPos;
        static offset(blockNode: number, stepX: number, stepY: number, stepZ: number): number;
        static offset(blockNode: number, offset: $Direction_): number;
        static of(blockNode: number): $BlockPos;
        static randomBetweenClosed(random: $RandomSource, limit: number, minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): $Iterable<$BlockPos>;
        static randomInCube(random: $RandomSource, limit: number, center: $BlockPos_, sizeToScanInAllDirections: number): $Iterable<$BlockPos>;
        static spiralAround(center: $BlockPos_, radius: number, firstDirection: $Direction_, secondDirection: $Direction_): $Iterable<$BlockPos$MutableBlockPos>;
        static squareOutSouthEast(from: $BlockPos_): $Stream<$BlockPos>;
        static withinManhattanStream(origin: $BlockPos_, reachX: number, reachY: number, reachZ: number): $Stream<$BlockPos>;
        static withinManhattan(origin: $BlockPos_, reachX: number, reachY: number, reachZ: number): $Iterable<$BlockPos>;
        static offsetCodec(maxOffsetPerAxis: number): $Codec<$Vec3i>;
    }
    export interface $BlockPos extends $Vec3i {
        get bottomCenter(): $Vec3;
        getBottomCenter(): $Vec3;
        get center(): $Vec3;
        getCenter(): $Vec3;
        above(steps: number): $BlockPos;
        above(): $BlockPos;
        asLong(): number;
        atY(y: number): $BlockPos;
        below(steps: number): $BlockPos;
        below(): $BlockPos;
        clampLocationWithin(location: $Vec3_): $Vec3;
        cross(upVector: $Vec3i): $BlockPos;
        east(steps: number): $BlockPos;
        east(): $BlockPos;
        immutable(): $BlockPos;
        multiply(xScale: number, yScale: number, zScale: number): $Vec3i;
        multiply(scale: number): $BlockPos;
        mutable(): $BlockPos$MutableBlockPos;
        north(steps: number): $BlockPos;
        north(): $BlockPos;
        offset(x: number, y: number, z: number): $BlockPos;
        offset(vec: $Vec3i): $BlockPos;
        relative(axis: $Direction$Axis_, steps: number): $BlockPos;
        relative(direction: $Direction_, steps: number): $BlockPos;
        relative(direction: $Direction_): $BlockPos;
        rotate(rotation: $Rotation_): $BlockPos;
        south(steps: number): $BlockPos;
        south(): $BlockPos;
        subtract(vec: $Vec3i): $BlockPos;
        west(steps: number): $BlockPos;
        west(): $BlockPos;
    }

    export class $BlockPos$MutableBlockPos extends $BlockPos {
        constructor();
        constructor(x: number, y: number, z: number);
        constructor(x: number, y: number, z: number);
        above(steps: number): $BlockPos;
        above(): $BlockPos;
        below(steps: number): $BlockPos;
        below(): $BlockPos;
        clamp(axis: $Direction$Axis_, minimum: number, maximum: number): $BlockPos$MutableBlockPos;
        cross(upVector: $Vec3i): $BlockPos;
        east(steps: number): $BlockPos;
        east(): $BlockPos;
        immutable(): $BlockPos;
        move(x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        move(direction: $Direction_, steps: number): $BlockPos$MutableBlockPos;
        move(direction: $Direction_): $BlockPos$MutableBlockPos;
        move(pos: $Vec3i): $BlockPos$MutableBlockPos;
        multiply(xScale: number, yScale: number, zScale: number): $Vec3i;
        multiply(scale: number): $BlockPos;
        north(steps: number): $BlockPos;
        north(): $BlockPos;
        offset(x: number, y: number, z: number): $BlockPos;
        offset(vec: $Vec3i): $BlockPos;
        relative(axis: $Direction$Axis_, steps: number): $BlockPos;
        relative(direction: $Direction_, steps: number): $BlockPos;
        relative(direction: $Direction_): $BlockPos;
        rotate(rotation: $Rotation_): $BlockPos;
        setWithOffset(pos: $Vec3i, x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        setWithOffset(pos: $Vec3i, direction: $Direction_): $BlockPos$MutableBlockPos;
        setWithOffset(pos: $Vec3i, offset: $Vec3i): $BlockPos$MutableBlockPos;
        setX(x: number): $BlockPos$MutableBlockPos;
        setY(y: number): $BlockPos$MutableBlockPos;
        setZ(z: number): $BlockPos$MutableBlockPos;
        set(x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        set(x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        set(pos: number): $BlockPos$MutableBlockPos;
        set(transform: $AxisCycle_, x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        set(vec: $Vec3i): $BlockPos$MutableBlockPos;
        south(steps: number): $BlockPos;
        south(): $BlockPos;
        subtract(vec: $Vec3i): $BlockPos;
        west(steps: number): $BlockPos;
        west(): $BlockPos;
    }

    export class $BlockPos$TraversalNodeStatus {
        static ACCEPT: $BlockPos$TraversalNodeStatus;
        static SKIP: $BlockPos$TraversalNodeStatus;
        static STOP: $BlockPos$TraversalNodeStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BlockPos$TraversalNodeStatus[];
        static valueOf(name: string): $BlockPos$TraversalNodeStatus;
    }
    export interface $BlockPos$TraversalNodeStatus extends $Enum<$BlockPos$TraversalNodeStatus> {}

    export interface $ClientAsset {
        id(): $Identifier;
    }

    export class $ClientAsset$ResourceTexture extends $Record implements $ClientAsset$Texture {
        constructor(texture: $Identifier_);
        constructor(id: $Identifier_, texturePath: $Identifier_);
        static CODEC: $Codec<$ClientAsset$ResourceTexture>;
        static DEFAULT_FIELD_CODEC: $MapCodec<$ClientAsset$ResourceTexture>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientAsset$ResourceTexture>;
        equals(o: unknown): boolean;
        hashCode(): number;
        id(): $Identifier;
        texturePath(): $Identifier;
        toString(): string;
    }

    export interface $ClientAsset$Texture extends $ClientAsset {
        texturePath(): $Identifier;
    }

    export class $Direction {
        static DOWN: $Direction;
        static EAST: $Direction;
        static NORTH: $Direction;
        static SOUTH: $Direction;
        static UP: $Direction;
        static WEST: $Direction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction[];
        static valueOf(name: string): $Direction;
    }
    export interface $Direction extends $Enum<$Direction>, $StringRepresentable {}

    export class $Direction$Axis {
        static X: $Direction$Axis;
        static Y: $Direction$Axis;
        static Z: $Direction$Axis;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$Axis[];
        static valueOf(name: string): $Direction$Axis;
    }
    export interface $Direction$Axis extends $Enum<$Direction$Axis>, $Predicate<$Direction>, $StringRepresentable {}

    export class $Direction$AxisDirection {
        static NEGATIVE: $Direction$AxisDirection;
        static POSITIVE: $Direction$AxisDirection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$AxisDirection[];
        static valueOf(name: string): $Direction$AxisDirection;
    }
    export interface $Direction$AxisDirection extends $Enum<$Direction$AxisDirection> {}

    export class $Direction$Plane {
        static HORIZONTAL: $Direction$Plane;
        static VERTICAL: $Direction$Plane;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$Plane[];
        static valueOf(name: string): $Direction$Plane;
    }
    export interface $Direction$Plane extends $Enum<$Direction$Plane>, $Predicate<$Direction>, $Iterable<$Direction> {}

    export class $Direction8 {
        static EAST: $Direction8;
        static NORTH: $Direction8;
        static NORTH_EAST: $Direction8;
        static NORTH_WEST: $Direction8;
        static SOUTH: $Direction8;
        static SOUTH_EAST: $Direction8;
        static SOUTH_WEST: $Direction8;
        static WEST: $Direction8;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction8[];
        static valueOf(name: string): $Direction8;
    }
    export interface $Direction8 extends $Enum<$Direction8> {}

    export class $GlobalPos extends $Record {
        constructor(dimension: $ResourceKey<$Level>, pos: $BlockPos_);
        static CODEC: $Codec<$GlobalPos>;
        static MAP_CODEC: $MapCodec<$GlobalPos>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $GlobalPos>;
        static of(dimension: $ResourceKey<$Level>, pos: $BlockPos_): $GlobalPos;
        dimension(): $ResourceKey<$Level>;
        equals(o: unknown): boolean;
        hashCode(): number;
        isCloseEnough(dimension: $ResourceKey<$Level>, pos: $BlockPos_, maxDistance: number): boolean;
        pos(): $BlockPos;
        toString(): string;
    }

    export interface $Holder<T> {
        areComponentsBound(): boolean;
        canSerializeIn(registry: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        getRegisteredName(): string;
        isBound(): boolean;
        is(predicate: $Predicate_<$ResourceKey<T>, $ResourceKey<T>, boolean>): boolean;
        is(holder: $Holder_<T>): boolean;
        is(key: $Identifier_): boolean;
        is(key: $ResourceKey<T>): boolean;
        is(tag: $TagKey_<T>): boolean;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }
    export const $Holder: {
        direct<T>(value: T, components: $DataComponentMap): $Holder<T>;
        direct<T>(value: T): $Holder<T>;
    };

    export class $Holder$Kind {
        static DIRECT: $Holder$Kind;
        static REFERENCE: $Holder$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Holder$Kind[];
        static valueOf(name: string): $Holder$Kind;
    }
    export interface $Holder$Kind extends $Enum<$Holder$Kind> {}

    export class $Holder$Reference<T> implements $Holder<T> {
        get registeredName(): string;
        getRegisteredName(): string;
        get bound(): boolean;
        isBound(): boolean;
        static createIntrusive<T>(owner: $HolderOwner<T>, value: T): $Holder$Reference<T>;
        static createStandAlone<T>(owner: $HolderOwner<T>, key: $ResourceKey<T>): $Holder$Reference<T>;
        areComponentsBound(): boolean;
        bindComponents(components: $DataComponentMap): void;
        bindValue(value: T): void;
        canSerializeIn(context: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        is(predicate: $Predicate_<$ResourceKey<T>, $ResourceKey<T>, boolean>): boolean;
        is(holder: $Holder_<T>): boolean;
        is(key: $Identifier_): boolean;
        is(key: $ResourceKey<T>): boolean;
        is(tag: $TagKey_<T>): boolean;
        key(): $ResourceKey<T>;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        toString(): string;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export interface $HolderGetter<T> {
        getOrThrow(id: $ResourceKey<T>): $Holder$Reference<T>;
        getOrThrow(id: $TagKey_<T>): $HolderSet$Named<T>;
        getRandomElementOf(tag: $TagKey_<T>, random: $RandomSource): $Optional<$Holder<T>>;
        get(id: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        get(id: $TagKey_<T>): $Optional<$HolderSet$Named<T>>;
    }

    export interface $HolderGetter$Provider {
        getOrThrow<T>(id: $ResourceKey<T>): $Holder$Reference<T>;
        getOrThrow<T>(id: $TagKey_<T>): $HolderSet$Named<T>;
        get<T>(id: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        get<T>(id: $TagKey_<T>): $Optional<$HolderSet$Named<T>>;
        lookupOrThrow<T>(key: $ResourceKey<$Registry<T>>): $HolderGetter<T>;
        lookup<T>(key: $ResourceKey<$Registry<T>>): $OptionalView<$HolderGetter<T>>;
    }

    export interface $HolderLookup<T> extends $HolderGetter<T> {
        listElementIds(): $Stream<$ResourceKey<T>>;
        listElements(): $Stream<$Holder$Reference<T>>;
        listTagIds(): $Stream<$TagKey<T>>;
        listTags(): $Stream<$HolderSet$Named<T>>;
    }

    export interface $HolderLookup$Provider extends $HolderGetter$Provider {
        allRegistriesLifecycle(): $Lifecycle;
        createSerializationContext<V>(parent: $DynamicOps<V>): $RegistryOps<V>;
        listRegistries(): $Stream<$HolderLookup$RegistryLookup<any>>;
        listRegistryKeys(): $Stream<$ResourceKey<$Registry<any>>>;
        lookupOrThrow<T>(key: $ResourceKey<$Registry<T>>): $HolderLookup$RegistryLookup<T>;
        lookup<T>(key: $ResourceKey<$Registry<T>>): $OptionalView<$HolderLookup$RegistryLookup<T>> & $OptionalView<$HolderGetter<T>>;
    }
    export const $HolderLookup$Provider: {
        create(lookups: $Stream<$HolderLookup$RegistryLookup<any>>): $HolderLookup$Provider;
    };

    export interface $HolderLookup$RegistryLookup<T> extends $HolderLookup<T>, $HolderOwner<T> {
        filterElements(filter: $Predicate_<T, T, boolean>): $HolderLookup$RegistryLookup<T>;
        filterFeatures(enabledFeatures: $FeatureFlagSet): $HolderLookup$RegistryLookup<T>;
        key(): $ResourceKey<$Registry<T>>;
        registryLifecycle(): $Lifecycle;
    }

    export interface $HolderOwner<T> {
        canSerializeIn(context: $HolderOwner<T>): boolean;
    }

    export interface $HolderSet<T> extends $Iterable<$Holder<T>> {
        canSerializeIn(owner: $HolderOwner<T>): boolean;
        contains(value: $Holder_<T>): boolean;
        getRandomElement(random: $RandomSource): $Optional<$Holder<T>>;
        get(index: number): $Holder<T>;
        isBound(): boolean;
        size(): number;
        stream(): $Stream<$Holder<T>>;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }
    export const $HolderSet: {
        direct<T>(values: ($List<$Holder<T>> | ($Holder_<T>)[])): $HolderSet$Direct<T>;
        direct<E, T>(holderGetter: $Function_<E, $Holder<T>, E, $Holder_<T>>, elements?: E[]): $HolderSet$Direct<T>;
        direct<E, T>(holderGetter: $Function_<E, $Holder<T>, E, $Holder_<T>>, elements: ($Collection<E> | (E)[])): $HolderSet$Direct<T>;
        direct<T>(values?: $Holder_<T>[]): $HolderSet$Direct<T>;
        emptyNamed<T>(owner: $HolderOwner<T>, key: $TagKey_<T>): $HolderSet$Named<T>;
        empty<T>(): $HolderSet<T>;
    };

    export class $HolderSet$Direct<T> extends $HolderSet$ListBacked<T> {
        get bound(): boolean;
        isBound(): boolean;
        contains(value: $Holder_<T>): boolean;
        equals(obj: unknown): boolean;
        forEach(arg0: $Consumer_<$Holder<T>, $Holder<T>>): void;
        hashCode(): number;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export class $HolderSet$ListBacked<T> implements $HolderSet<T> {
        constructor();
        get bound(): boolean;
        isBound(): boolean;
        canSerializeIn(owner: $HolderOwner<T>): boolean;
        contains(value: $Holder_<T>): boolean;
        forEach(arg0: $Consumer_<$Holder<T>, $Holder<T>>): void;
        getRandomElement(random: $RandomSource): $Optional<$Holder<T>>;
        get(index: number): $Holder<T>;
        iterator(): $Iterator<$Holder<T>>;
        size(): number;
        spliterator(): $Spliterator<$Holder<T>>;
        stream(): $Stream<$Holder<T>>;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export class $HolderSet$Named<T> extends $HolderSet$ListBacked<T> {
        contents: $List<$Holder<T>>;
        get bound(): boolean;
        isBound(): boolean;
        canSerializeIn(context: $HolderOwner<T>): boolean;
        contains(value: $Holder_<T>): boolean;
        forEach(arg0: $Consumer_<$Holder<T>, $Holder<T>>): void;
        key(): $TagKey<T>;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export interface $IdMap<T> extends $Iterable<T> {
        byIdOrThrow(id: number): T;
        byId(id: number): T;
        getIdOrThrow(value: T): number;
        getId(thing: T): number;
        size(): number;
    }
    export const $IdMap: {
        readonly DEFAULT: number;
    };

    export class $IdMapper<T> implements $IdMap<T>, $RemovableIdMapper<any> {
        constructor();
        constructor(expectedSize: number);
        addMapping(thing: T, id: number): void;
        add(thing: T): void;
        byIdOrThrow(id: number): T;
        byId(id: number): T;
        contains(id: number): boolean;
        fabric_clear(): void;
        fabric_remapIds(arg0: $Int2IntMap): void;
        fabric_remapId(arg0: number, arg1: number): void;
        fabric_removeId(arg0: number): void;
        fabric_remove(arg0: unknown): void;
        forEach(arg0: $Consumer_<T, T>): void;
        getIdOrThrow(value: T): number;
        getId(thing: T): number;
        iterator(): $Iterator<T>;
        size(): number;
        spliterator(): $Spliterator<T>;
    }

    export class $LayeredRegistryAccess<T> {
        constructor(keys: ($List<T> | (T)[]));
        compositeAccess(): $RegistryAccess$Frozen;
        getAccessForLoading(forLayer: T): $RegistryAccess$Frozen;
        getAccessFrom(forLayer: T): $RegistryAccess$Frozen;
        getLayer(layer: T): $RegistryAccess$Frozen;
        replaceFrom(fromLayer: T, layers: ($List<$RegistryAccess$Frozen> | ($RegistryAccess$Frozen)[])): $LayeredRegistryAccess<T>;
        replaceFrom(fromLayer: T, layers?: $RegistryAccess$Frozen[]): $LayeredRegistryAccess<T>;
    }

    export class $NonNullList<E> extends $AbstractList<E> {
        get first(): E;
        getFirst(): E;
        get last(): E;
        getLast(): E;
        static createWithCapacity<E>(capacity: number): $NonNullList<E>;
        static create<E>(): $NonNullList<E>;
        static of<E>(defaultValue: E, values?: E[]): $NonNullList<E>;
        static withSize<E>(size: number, defaultValue: E): $NonNullList<E>;
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        add(arg0: E): boolean;
        add(index: number, element: E): void;
        clear(): void;
        equals(arg0: unknown): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        get(index: number): E;
        hashCode(): number;
        parallelStream(): $Stream<E>;
        removeFirst(): E;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        removeLast(): E;
        remove(index: number): E;
        remove(arg0: unknown): boolean;
        replaceAll(arg0: $UnaryOperator_<E, E, E>): void;
        reversed(): $List<E>;
        set(index: number, element: E): E;
        size(): number;
        sort(arg0: $Comparator_<E, E, E, number>): void;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export interface $Position {
        "x()"(): number;
        "y()"(): number;
        "z()"(): number;
    }

    export class $RegistrationInfo extends $Record {
        constructor(knownPackInfo: $Optional<$KnownPack>, lifecycle: $Lifecycle);
        static BUILT_IN: $RegistrationInfo;
        equals(o: unknown): boolean;
        hashCode(): number;
        knownPackInfo(): $Optional<$KnownPack>;
        lifecycle(): $Lifecycle;
        toString(): string;
    }

    export interface $Registry<T> extends $IdMap<T>, $Keyable, $HolderLookup$RegistryLookup<T>, $FabricRegistry, $RegistryMixin {
        addAlias(arg0: $Identifier_, arg1: $Identifier_): void;
        asHolderIdMap(): $IdMap<$Holder<T>>;
        byNameCodec(): $Codec<T>;
        componentLookup(): $DataComponentLookup<T>;
        containsKey(key: $Identifier_): boolean;
        containsKey(key: $ResourceKey<T>): boolean;
        createIntrusiveHolder(value: T): $Holder$Reference<T>;
        entrySet(): $Set<$Map$Entry<$ResourceKey<T>, T>>;
        freeze(): $Registry<T>;
        getAny(): $Optional<$Holder$Reference<T>>;
        getId(thing: T): number;
        getKey(thing: T): $Identifier;
        getOptional(key: $Identifier_): $Optional<T>;
        getOptional(key: $ResourceKey<T>): $Optional<T>;
        getRandom(random: $RandomSource): $Optional<$Holder$Reference<T>>;
        getResourceKey(thing: T): $Optional<$ResourceKey<T>>;
        getTagOrEmpty(id: $TagKey_<T>): $Iterable<$Holder<T>>;
        getTags(): $Stream<$HolderSet$Named<T>>;
        getValueOrThrow(key: $ResourceKey<T>): T;
        getValue(key: $Identifier_): T;
        getValue(key: $ResourceKey<T>): T;
        get(id: number): $Optional<$Holder$Reference<T>>;
        get(id: $Identifier_): $Optional<$Holder$Reference<T>>;
        get(id: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        get(id: $TagKey_<T>): $Optional<$HolderSet$Named<T>>;
        holderByNameCodec(): $Codec<$Holder<T>>;
        keySet(): $Set<$Identifier>;
        keys<U>(ops: $DynamicOps<U>): $Stream<U>;
        key(): $ResourceKey<$Registry<T>>;
        prepareTagReload(tags: $TagLoader$LoadResult<T>): $Registry$PendingTags<T>;
        registrationInfo(element: $ResourceKey<T>): $Optional<$RegistrationInfo>;
        registryKeySet(): $Set<$ResourceKey<T>>;
        stream(): $Stream<T>;
        wrapAsHolder(value: T): $Holder<T>;
    }
    export const $Registry: {
        registerForHolder<R, T extends R>(registry: $Registry<R>, location: $Identifier_, value: T): $Holder$Reference<T>;
        registerForHolder<R, T extends R>(registry: $Registry<R>, key: $ResourceKey<R>, value: T): $Holder$Reference<T>;
        register<T>(registry: $Registry<any>, name: string, value: T): T;
        register<V, T extends V>(registry: $Registry<V>, location: $Identifier_, value: T): T;
        register<V, T extends V>(registry: $Registry<V>, key: $ResourceKey<V>, value: T): T;
    };

    export interface $Registry$PendingTags<T> {
        apply(): void;
        key(): $ResourceKey<$Registry<T>>;
        lookup(): $HolderLookup$RegistryLookup<T>;
        size(): number;
    }

    export interface $RegistryAccess extends $HolderLookup$Provider {
        freeze(): $RegistryAccess$Frozen;
        listRegistryKeys(): $Stream<$ResourceKey<$Registry<any>>>;
        lookupOrThrow<E>(name: $ResourceKey<$Registry<E>>): $Registry<E>;
        lookup<E>(registryKey: $ResourceKey<$Registry<E>>): $Optional<$Registry<E>> & $OptionalView<$HolderLookup$RegistryLookup<E>> & $OptionalView<$HolderGetter<E>>;
        registries(): $Stream<$RegistryAccess$RegistryEntry<any>>;
    }
    export const $RegistryAccess: {
        fromRegistryOfRegistries(registries: $Registry<$Registry<any>>): $RegistryAccess$Frozen;
        readonly EMPTY: $RegistryAccess$Frozen;
        readonly LOGGER: $Logger;
    };

    export interface $RegistryAccess$Frozen extends $RegistryAccess {
    }

    export class $RegistryAccess$RegistryEntry<T> extends $Record {
        constructor(key: $ResourceKey<$Registry<T>>, value: $Registry<T>);
        equals(o: unknown): boolean;
        hashCode(): number;
        key(): $ResourceKey<$Registry<T>>;
        toString(): string;
        value(): $Registry<T>;
    }

    export class $Rotations extends $Record {
        constructor(x: number, y: number, z: number);
        static CODEC: $Codec<$Rotations>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Rotations>;
        equals(o: unknown): boolean;
        hashCode(): number;
        toString(): string;
        x(): number;
        y(): number;
        z(): number;
    }

    export class $SectionPos {
        private constructor();
        static SECTION_BITS: number;
        static SECTION_HALF_SIZE: number;
        static SECTION_MASK: number;
        static SECTION_MAX_INDEX: number;
        static SECTION_SIZE: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $SectionPos>;
        static aroundAndAtBlockPos(blockX: number, blockY: number, blockZ: number, sectionConsumer: $LongConsumer_<number>): void;
        static aroundAndAtBlockPos(blockPos: number, sectionConsumer: $LongConsumer_<number>): void;
        static aroundAndAtBlockPos(blockPos: $BlockPos_, sectionConsumer: $LongConsumer_<number>): void;
        static aroundChunk(center: $ChunkPos, radius: number, minSection: number, maxSection: number): $Stream<$SectionPos>;
        static asLong(x: number, y: number, z: number): number;
        static asLong(pos: $BlockPos_): number;
        static betweenClosedStream(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): $Stream<$SectionPos>;
        static blockToSectionCoord(coord: number): number;
        static blockToSectionCoord(blockCoord: number): number;
        static blockToSection(blockNode: number): number;
        static bottomOf(chunk: $ChunkAccess): $SectionPos;
        static cube(center: $SectionPos, radius: number): $Stream<$SectionPos>;
        static getZeroNode(x: number, z: number): number;
        static getZeroNode(sectionNode: number): number;
        static offset(sectionNode: number, stepX: number, stepY: number, stepZ: number): number;
        static offset(sectionNode: number, offset: $Direction_): number;
        static of(x: number, y: number, z: number): $SectionPos;
        static of(sectionNode: number): $SectionPos;
        static of(pos: $BlockPos_): $SectionPos;
        static of(pos: $Position): $SectionPos;
        static of(pos: $ChunkPos, sectionY: number): $SectionPos;
        static of(entity: $EntityAccess): $SectionPos;
        static posToSectionCoord(pos: number): number;
        static sectionRelativePos(pos: $BlockPos_): number;
        static sectionRelativeX(relative: number): number;
        static sectionRelativeY(relative: number): number;
        static sectionRelativeZ(relative: number): number;
        static sectionRelative(blockCoord: number): number;
        static sectionToBlockCoord(sectionCoord: number, offset: number): number;
        static sectionToBlockCoord(sectionCoord: number): number;
        static sectionToChunk(sectionNode: number): number;
        static x(sectionNode: number): number;
        static y(sectionNode: number): number;
        static z(sectionNode: number): number;
        static offsetCodec(maxOffsetPerAxis: number): $Codec<$Vec3i>;
    }
    export interface $SectionPos extends $Vec3i {
        asLong(): number;
        blocksInside(): $Stream<$BlockPos>;
        center(): $BlockPos;
        chunk(): $ChunkPos;
        maxBlockX(): number;
        maxBlockY(): number;
        maxBlockZ(): number;
        minBlockX(): number;
        minBlockY(): number;
        minBlockZ(): number;
        offset(x: number, y: number, z: number): $SectionPos;
        offset(vec: $Vec3i): $Vec3i;
        origin(): $BlockPos;
        relativeToBlockPos(relative: number): $BlockPos;
        relativeToBlockX(relative: number): number;
        relativeToBlockY(relative: number): number;
        relativeToBlockZ(relative: number): number;
    }

    export interface $TypedInstance<T> {
        is(rawType: T): boolean;
        is(type: $Holder_<T>): boolean;
        is(set: $HolderSet<T>): boolean;
        is(type: $ResourceKey<T>): boolean;
        is(tag: $TagKey_<T>): boolean;
        tags(): $Stream<$TagKey<T>>;
        typeHolder(): $Holder<T>;
    }

    export class $Vec3i implements $Comparable<$Vec3i> {
        constructor(x: number, y: number, z: number);
        static CODEC: $Codec<$Vec3i>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Vec3i>;
        static ZERO: $Vec3i;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        static offsetCodec(maxOffsetPerAxis: number): $Codec<$Vec3i>;
        above(steps: number): $Vec3i;
        above(): $Vec3i;
        below(steps: number): $Vec3i;
        below(): $Vec3i;
        closerThan(pos: $Vec3i, distance: number): boolean;
        closerToCenterThan(pos: $Position, distance: number): boolean;
        compareTo(pos: $Vec3i): number;
        cross(upVector: $Vec3i): $Vec3i;
        distChessboard(pos: $Vec3i): number;
        distManhattan(pos: $Vec3i): number;
        distSqr(pos: $Vec3i): number;
        distToCenterSqr(x: number, y: number, z: number): number;
        distToCenterSqr(pos: $Position): number;
        distToLowCornerSqr(x: number, y: number, z: number): number;
        east(steps: number): $Vec3i;
        east(): $Vec3i;
        equals(o: unknown): boolean;
        get(axis: $Direction$Axis_): number;
        hashCode(): number;
        multiply(xScale: number, yScale: number, zScale: number): $Vec3i;
        multiply(scale: number): $Vec3i;
        north(steps: number): $Vec3i;
        north(): $Vec3i;
        offset(x: number, y: number, z: number): $Vec3i;
        offset(vec: $Vec3i): $Vec3i;
        relative(axis: $Direction$Axis_, steps: number): $Vec3i;
        relative(direction: $Direction_, steps: number): $Vec3i;
        relative(direction: $Direction_): $Vec3i;
        south(steps: number): $Vec3i;
        south(): $Vec3i;
        subtract(vec: $Vec3i): $Vec3i;
        toMutable(): $Vector3i;
        toShortString(): string;
        toString(): string;
        west(steps: number): $Vec3i;
        west(): $Vec3i;
    }

    export type $AxisCycle_ = $AxisCycle | "BACKWARD" | "FORWARD" | "NONE";
    export type $BlockPos_ = $BlockPos | $Vec3 | { x: number, y: number, z: number } | number[];
    export type $BlockPos$TraversalNodeStatus_ = $BlockPos$TraversalNodeStatus | "ACCEPT" | "SKIP" | "STOP";
    export type $ClientAsset_<CallbackResult = $Identifier_> = (() => CallbackResult) | ($ClientAsset & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "id": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Direction_ = $Direction | "DOWN" | "EAST" | "NORTH" | "SOUTH" | "UP" | "WEST";
    export type $Direction$Axis_ = $Direction$Axis | "X" | "Y" | "Z";
    export type $Direction$AxisDirection_ = $Direction$AxisDirection | "NEGATIVE" | "POSITIVE";
    export type $Direction$Plane_ = $Direction$Plane | "HORIZONTAL" | "VERTICAL";
    export type $Direction8_ = $Direction8 | "EAST" | "NORTH" | "NORTH_EAST" | "NORTH_WEST" | "SOUTH" | "SOUTH_EAST" | "SOUTH_WEST" | "WEST";
    /** registry entry id, e.g. 'minecraft:sharpness' (namespace defaults to minecraft) */
    export type $Holder_<T = any> = $Holder<T> | string;
    export type $Holder$Kind_ = $Holder$Kind | "DIRECT" | "REFERENCE";
    export type $HolderGetter$Provider_<CallbackArg0 = $ResourceKey<$Registry<any>>, CallbackResult = $Optional<$HolderGetter<any>>> = ((arg0: CallbackArg0) => CallbackResult) | ($HolderGetter$Provider & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "lookup": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $TypedInstance_<Host0 = any, CallbackResult = $Holder_<Host0>> = (() => CallbackResult) | ($TypedInstance<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "typeHolder": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
