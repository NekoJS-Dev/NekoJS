import hashlib,json,subprocess
from pathlib import Path
root=Path('build/priority-closeout/2026-10-24-method-bounds-performance-preparation')
revision=json.loads((root/'performance-source-binding.json').read_text(encoding='utf-8'))['revision']
blob=subprocess.check_output(['git','show',revision+':bench/perf/sample.ps1'])
working=Path('D:/mcmodDemo/NekoJS-perf-606d1fff/bench/perf/sample.ps1').read_bytes()
assert blob.replace(b'\r\n',b'\n')==working.replace(b'\r\n',b'\n')
assert hashlib.sha256(working).hexdigest()=='1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
(root/'provenance.json').write_text(json.dumps(dict(revision=revision,originalSamplerSha256=hashlib.sha256(working).hexdigest(),samplerGitBlobSha256=hashlib.sha256(blob).hexdigest(),sameSamplerAfterLineEndNormalization=True,preliminaryProvenanceCheck='The first Git-blob vs Windows-file raw hash comparison failed; CRLF/LF normalization proves equal contents. The unmodified execution wrapper independently checked the original raw file hash before starting collection.',wrapperSha256=hashlib.sha256((root/'formal-performance.py').read_bytes()).hexdigest(),policy='Original runServer sampler, fixtures, warmup2, samples5, reloads5, thresholds285.3ms/41173ms; no other owned game or compiler test jobs during collection.'),indent=2)+'\n',encoding='utf-8')
print('Execution sampler hash unchanged; Git LF source and CRLF working file recorded separately.')
