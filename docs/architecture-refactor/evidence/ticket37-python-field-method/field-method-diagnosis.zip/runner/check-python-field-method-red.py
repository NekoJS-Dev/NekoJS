import ast
import json
import shutil
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
target = root/'build/ticket37-python-field-method-red-compiler'
assert not target.exists()
shutil.copytree(root/'common/build/probe-python-field-method-collision', target/'generated')
files = sorted((target/'generated').rglob('*.pyi'))
assert files
for path in files: ast.parse(path.read_text(encoding='utf-8'))
name = 'PythonFieldMethodCollisionTest_HostFixture'
module = 'nekojs._java.com.tkisor.nekojs.probe.backend.python'
(target/'positive.py').write_text(f'''from {module} import {name}
def read_locked(value: {name}) -> bool:
    return value.locked
def invoke_locked(value: {name}) -> bool:
    return value.locked()
def write_locked(value: {name}) -> None:
    value.locked = True
def read_x(value: {name}) -> float:
    return value.x
def invoke_x(value: {name}) -> float:
    return value.x()
''', encoding='utf-8')
(target/'negative.py').write_text(f'''from {module} import {name}
def invalid(value: {name}) -> None:
    value.locked(17)
    value.locked = "wrong"
    value.x(17)
''', encoding='utf-8')
rows = []
pyright = 'C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js'
for name, mode, include in [('whole-basic', 'basic', ['generated/**/*.pyi']), ('whole-strict', 'strict', ['generated/**/*.pyi']),
                            ('positive-strict', 'strict', ['positive.py']), ('negative-strict', 'strict', ['negative.py'])]:
    config = target/(name+'-config.json')
    config.write_text(json.dumps(dict(include=include, extraPaths=['generated'], typeCheckingMode=mode), indent=2)+'\n', encoding='utf-8')
    result = subprocess.run(['node', pyright, '--project', str(config), '--outputjson'], capture_output=True)
    assert not result.stderr
    (target/(name+'-pyright.json')).write_bytes(result.stdout)
    document = json.loads(result.stdout)
    if name.startswith('whole-'): assert document['summary']['filesAnalyzed'] == len(files)
    rows.append(dict(check=name, exitCode=result.returncode, summary=document['summary'], diagnostics=document['generalDiagnostics']))
(target/'summary.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf-8')
print(json.dumps([{key:value for key,value in row.items() if key != 'diagnostics'} for row in rows]))
assert rows[0]['exitCode'] == rows[2]['exitCode'] == 1, 'Baseline must reproduce whole-output and valid-caller failures'
