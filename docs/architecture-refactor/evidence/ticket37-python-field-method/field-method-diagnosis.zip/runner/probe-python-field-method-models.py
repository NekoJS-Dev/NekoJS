import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
target = root/'build/ticket37-python-field-method-model-controls'
assert not target.exists()
target.mkdir()
models = dict(methods_only='''class Host:
    def locked(self) -> bool: ...
    def x(self) -> float: ...
''', fields_only='''class Host:
    locked: bool
    x: float
''', callable_values='''from typing import Protocol
class BoolCall(Protocol):
    def __call__(self) -> bool: ...
    def __bool__(self) -> bool: ...
class FloatCall(float):
    def __call__(self) -> float: ...
class Host:
    @property
    def locked(self) -> BoolCall: ...
    @locked.setter
    def locked(self, value: bool) -> None: ...
    @property
    def x(self) -> FloatCall: ...
''')
caller = '''from model import Host
def read_locked(value: Host) -> bool:
    return value.locked
def invoke_locked(value: Host) -> bool:
    return value.locked()
def write_locked(value: Host) -> None:
    value.locked = True
def read_x(value: Host) -> float:
    return value.x
def invoke_x(value: Host) -> float:
    return value.x()
'''
detached = '''from model import Host
def invalid_detached(value: Host) -> float:
    stored = value.x
    return stored()
'''
pyright = 'C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js'
rows = []
for model, source in models.items():
    directory = target/model
    directory.mkdir()
    (directory/'model.pyi').write_text(source, encoding='utf-8')
    (directory/'positive.py').write_text(caller, encoding='utf-8')
    (directory/'detached.py').write_text(detached, encoding='utf-8')
    for name in ['positive', 'detached']:
        config = directory/(name+'-config.json')
        config.write_text(json.dumps(dict(include=[name+'.py'], typeCheckingMode='strict'), indent=2)+'\n', encoding='utf-8')
        result = subprocess.run(['node', pyright, '--project', str(config), '--outputjson'], capture_output=True)
        assert not result.stderr
        (directory/(name+'-pyright.json')).write_bytes(result.stdout)
        document = json.loads(result.stdout)
        assert document['summary']['filesAnalyzed'] == 1
        rows.append(dict(model=model, caller=name, exitCode=result.returncode, summary=document['summary'], diagnostics=document['generalDiagnostics']))
(target/'summary.json').write_text(json.dumps(dict(purpose='Standalone counterexample models; generated backend output is never modified', rows=rows), indent=2)+'\n', encoding='utf-8')
print(json.dumps([{key:value for key,value in row.items() if key != 'diagnostics'} for row in rows]))
assert all(row['exitCode'] == 1 for row in rows if row['caller'] == 'positive')
assert rows[-1]['model'] == 'callable_values' and rows[-1]['exitCode'] == 0, 'Callable-value model must exhibit the runtime-inaccurate detached-call acceptance'
