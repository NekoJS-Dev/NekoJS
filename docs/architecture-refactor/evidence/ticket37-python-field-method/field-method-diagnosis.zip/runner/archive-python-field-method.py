import gzip
import hashlib
import io
import json
import subprocess
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd().resolve()
repair = root/'build/ticket37-config-sync-repair'
destination = root/'docs/architecture-refactor/evidence/ticket37-python-field-method'
base = '0a212fbb26d22d7337c25d1e7e1ebe84bd0392c2'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == base
assert not subprocess.check_output(['git', 'diff', base, '--', 'common/src/main/java'])
summary = json.loads((root/'build/ticket37-python-field-method-common-check/summary.json').read_text())
assert summary['total']['failures'] == summary['total']['errors'] == 0
assert 'BUILD SUCCESSFUL' in (repair/'python-field-method-common-check.txt').read_text(encoding='utf-8-sig')
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
for directory in (root/'build').iterdir():
    if directory.is_dir() and directory.name.startswith('ticket37-python-field-method-'):
        for path in directory.rglob('*'):
            if path.is_file(): files['control/'+directory.name+'/'+path.relative_to(directory).as_posix()] = path
for name in ['probe-python-field-method-host-facts', 'probe-python-field-method-collision']:
    directory = root/'common/build'/name
    for path in directory.rglob('*'):
        if path.is_file(): files['generated/'+name+'/'+path.relative_to(directory).as_posix()] = path
for path in repair.iterdir():
    if path.is_file() and ('python-field-method' in path.name or path.name == 'snapshot-current-tests.py') and path.name != 'python-field-method-archive.txt':
        files['runner/'+path.name] = path
paths = ['common/src/test/java/com/tkisor/nekojs/probe/backend/python/PythonFieldMethodCollisionTest.java',
         'common/src/test/java/com/tkisor/nekojs/probe/backend/python/PythonProbeBackendIntegrationTest.java']
for name in paths: files['source/repair/'+name] = root/name
secrets = []
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    props = (root/'build/ticket37-python-typing-callable-installed'/node/'server.properties').read_text()
    secrets.extend(line.partition('=')[2].encode() for line in props.splitlines() if line.startswith('rcon.password='))
def scan(data, suffix):
    if suffix == '.gz': return scan(gzip.decompress(data), '')
    if suffix == '.zip':
        with ZipFile(io.BytesIO(data)) as nested:
            for name in nested.namelist(): scan(nested.read(name), Path(name).suffix)
        return
    assert not any(secret and secret in data for secret in secrets)
patch = subprocess.check_output(['git', 'diff', '--abbrev=9', base, '--', *paths])
archive_path = destination/'field-method-diagnosis.zip'
assert not archive_path.exists()
entries = []
with ZipFile(archive_path, 'x', ZIP_DEFLATED) as archive:
    def add(name, data):
        scan(data, Path(name).suffix)
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
    for name, path in sorted(files.items()): add(name, path.read_bytes())
    add('source/test.patch', patch)
    name = paths[1]
    add('source/baseline/'+name, subprocess.check_output(['git', 'show', base+':'+name]))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(entries)
    for entry in entries: assert sha(archive.read(entry['path'])) == entry['sha256']
red = json.loads((root/'build/ticket37-python-field-method-red-compiler/summary.json').read_text())
models = json.loads((root/'build/ticket37-python-field-method-model-controls/summary.json').read_text())
manifest = dict(status='DIAGNOSIS ONLY: declarations and full IDE remain FAIL', sourceBase=base,
    productionUnchanged=True, testPatchSha256=sha(patch), testSourceFiles={name:sha((root/name).read_bytes()) for name in paths},
    commonCheck=summary, commonCheckDirectExit=0, nodeMatrix='NOT RUN for these new test-only changes; prior 4739 matrix separate',
    realHostFacts=json.loads((root/'common/build/probe-python-field-method-host-facts/host-facts.json').read_text()),
    originalCompiler=red, standaloneModels=models,
    independentReviews=dict(Standards='0 hard findings/0 heuristics; read-only', Spec='0 findings; read-only'),
    archive=dict(file=archive_path.name, entries=len(entries), bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes())),
    entries=entries, maintainerAcceptance='NOT RECORDED', automation='PAUSED',
    limitations=['Only tested model candidates rejected; no universal impossibility claimed', 'No production fix', 'Full IDE still FAIL', 'Exact prior production performance PASS remains separately pinned'])
(destination/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(archive=manifest['archive'], commonCheck=summary['total'], testPatchSha256=sha(patch), compilerErrors=[row['summary']['errorCount'] for row in red])))
