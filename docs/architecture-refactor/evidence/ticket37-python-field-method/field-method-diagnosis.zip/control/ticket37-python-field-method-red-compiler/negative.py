from nekojs._java.com.tkisor.nekojs.probe.backend.python import PythonFieldMethodCollisionTest_HostFixture
def invalid(value: PythonFieldMethodCollisionTest_HostFixture) -> None:
    value.locked(17)
    value.locked = "wrong"
    value.x(17)
