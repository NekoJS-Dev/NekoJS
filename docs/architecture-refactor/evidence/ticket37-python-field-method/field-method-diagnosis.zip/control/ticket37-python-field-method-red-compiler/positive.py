from nekojs._java.com.tkisor.nekojs.probe.backend.python import PythonFieldMethodCollisionTest_HostFixture
def read_locked(value: PythonFieldMethodCollisionTest_HostFixture) -> bool:
    return value.locked
def invoke_locked(value: PythonFieldMethodCollisionTest_HostFixture) -> bool:
    return value.locked()
def write_locked(value: PythonFieldMethodCollisionTest_HostFixture) -> None:
    value.locked = True
def read_x(value: PythonFieldMethodCollisionTest_HostFixture) -> float:
    return value.x
def invoke_x(value: PythonFieldMethodCollisionTest_HostFixture) -> float:
    return value.x()
