class Host:
    locked: bool
    x: float
