from model import Host
def invalid_detached(value: Host) -> float:
    stored = value.x
    return stored()
