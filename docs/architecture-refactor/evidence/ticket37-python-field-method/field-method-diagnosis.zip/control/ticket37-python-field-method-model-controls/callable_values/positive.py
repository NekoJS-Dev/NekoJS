from model import Host
def read_locked(value: Host) -> bool:
    return value.locked
def invoke_locked(value: Host) -> bool:
    return value.locked()
def write_locked(value: Host) -> None:
    value.locked = True
def read_x(value: Host) -> float:
    return value.x
def invoke_x(value: Host) -> float:
    return value.x()
