from pathlib import Path
for locale in ['cn','us']:
 p=Path('wiki/probe-type-generation_'+locale+'.md')
 p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
