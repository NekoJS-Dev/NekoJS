from pathlib import Path
for f, name in [('src/main/java/com/tkisor/nekojs/api/NeoForgeCatalogPlatformProvider.java','NeoForgeCatalogPlatformProvider'),('src/fabric/java/com/tkisor/nekojs/fabric/FabricCatalogPlatformProvider.java','FabricCatalogPlatformProvider')]:
 p=Path(f)
 s=p.read_text(encoding='utf-8')
 s=s.replace('import net.minecraft.core.registries.BuiltInRegistries;\n','').replace('import java.util.LinkedHashMap;\n','').replace('import java.util.Map;\n','')
 start=s.index('    @Override\n    public Collection<RegistryTypeCatalogEntry> registryTypes()')
 end=s.index('\n    /**', start)
 s=s[:start]+f'''    @Override
    public Collection<RegistryTypeCatalogEntry> registryTypes() {{
        return RegistryTypeCatalogs.snapshot(RegistryTypeCatalogs.builtInSources(), List.of(), {name}::tagIds);
    }}

    @Override
    public Collection<RegistryTypeCatalogEntry> registryTypes(List<JSTypeAdapter<?>> adapters) {{
        Collection<RegistryTypeCatalogEntry> provided = registryTypes();
        return RegistryTypeCatalogs.append(provided, RegistryTypeCatalogs.builtInSources(), adapters,
                {name}::tagIds);
    }}
''' + s[end:]
 p.write_text(s, encoding='utf-8')
