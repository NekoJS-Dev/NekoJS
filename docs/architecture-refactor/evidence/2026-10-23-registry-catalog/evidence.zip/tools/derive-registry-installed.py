from pathlib import Path
p=Path('build/priority-closeout')
s=(p/'freeze-7bea6d6d-matrix.py').read_text().replace("revision = subprocess.check_output(['git','rev-parse','7bea6d6d'],text=True).strip()", "revision = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()")
s=s.replace("'src/main','versions'", "'src/main','src/fabric','versions'").replace('source-facts-full-matrix.log','registry-catalog-full-matrix.log').replace('7bea6d6d-matrix','registry-catalog-matrix')
(p/'freeze-registry-matrix.py').write_text(s,encoding='utf-8')
for src,dest in [('prepare-1f877b0f-installed.py','prepare-registry-catalog-installed.py'),('run-1f877b0f-installed.py','run-registry-catalog-installed.py'),('check-1f877b0f-ide.py','check-registry-catalog-ide.py')]:
 s=(p/src).read_text(encoding='utf-8').replace('1f877b0f','registry-catalog')
 if src.startswith('prepare'):
  s=s.replace("['git', 'rev-parse', 'registry-catalog']", "['git', 'rev-parse', 'HEAD']")
  s=s.replace('event-dependency-remaining-node-builds.log','registry-catalog-full-matrix.log').replace('event-dependency-node-normal-check.log','registry-catalog-full-matrix.log')
  s=s.replace("'src/main','versions'", "'src/main','src/fabric','versions'")
  s=s.replace("'src/main', 'versions'", "'src/main', 'src/fabric', 'versions'")
 (p/dest).write_text(s,encoding='utf-8')
print('Prepared exact HEAD binding; no installation or runtime started.')
