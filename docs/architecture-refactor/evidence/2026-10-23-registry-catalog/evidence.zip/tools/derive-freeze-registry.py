from pathlib import Path
p=Path('build/priority-closeout/freeze-registry-focused.py')
s=p.read_text().replace("registry-catalog-focused-xml'", "registry-catalog-focused-v2-xml'")
s=s.replace("'RegistryTypeCatalogsTest', 'BlockStateRegistryShapeTest'", "'RegistryTypeCatalogsTest', 'BlockStateRegistryShapeTest', 'CatalogOverrideTest'")
s=s.replace('else 6','else 9')
Path('build/priority-closeout/freeze-registry-focused-v2.py').write_text(s)
