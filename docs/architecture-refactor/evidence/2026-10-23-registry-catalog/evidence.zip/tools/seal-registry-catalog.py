import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
repo=Path.cwd(); tools=repo/'build/priority-closeout'
out=repo/'docs/architecture-refactor/evidence/2026-10-23-registry-catalog'
assert not out.exists()
rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
files=subprocess.check_output(['git','diff','--name-only','8c33877c',rev],text=True).splitlines()
entries={}
def add(name,p): entries[name]=p.read_bytes()
for f in files:
 p=repo/f
 if p.is_file():
  assert p.read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show',rev+':'+f]).replace(b'\r\n',b'\n'),f
  add('source/'+f,p)
entries['source.patch']=subprocess.check_output(['git','diff','8c33877c',rev])
for p in tools.glob('registry-catalog*'):
 if p.is_file(): add('tools/'+p.name,p)
 elif p.name in ['registry-catalog-focused-v2-xml','registry-catalog-matrix','registry-catalog-common-red-fixtures']:
  for f in p.rglob('*'):
   if f.is_file(): add(p.name+'/'+f.relative_to(p).as_posix(),f)
for p in (repo/'common/build/probe-ts-registry-catalog').rglob('*'):
 if p.is_file(): add('final-fixtures/'+p.relative_to(repo/'common/build/probe-ts-registry-catalog').as_posix(),p)
for glob in ['derive-registry-installed.py','fix-registry-provider-override.py','update-registry-wiki.py','normalize-registry-wiki.py','record-registry-findings.py','freeze-registry-focused-v2.py','derive-freeze-registry.py','freeze-registry-matrix.py','seal-registry-catalog.py','bean-receiver-hypothesis*']:
 for p in tools.glob(glob):
  if p.is_file(): add('tools/'+p.name,p)
mat=json.loads((tools/'registry-catalog-matrix/summary.json').read_text())
assert mat['sourceRevision']==rev
focused=json.loads((tools/'registry-catalog-focused-v2-xml/counts.json').read_text())
assert sum(c['tests'] for c in focused.values())==48
summary=dict(productionRevision=rev,matrix=mat,focused=focused,strictModes=['full','server'],targetedTypeChain='PASS',
 review=dict(standardsHard=0,standardsSmells=0,specFindings=0,readOnly=True),
 fullInstalledIde='NOT RUN when freezing source checks; preceding installed source FAIL 5857',
 performance='NOT RUN for this source; previous formal reload FAIL 340.0 / 292.8 ms',maintainerAcceptance=False)
entries['summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
out.mkdir()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,d in sorted(entries.items()): z.writestr(n,d)
(out/'manifest.json').write_text(json.dumps(dict(archiveSha256=hashlib.sha256((out/'evidence.zip').read_bytes()).hexdigest(),entries={n:dict(size=len(d),sha256=hashlib.sha256(d).hexdigest()) for n,d in sorted(entries.items())}),indent=2)+'\n')
print(json.dumps(dict(revision=rev,entries=len(entries),bytes=(out/'evidence.zip').stat().st_size,total=mat['total'])))
