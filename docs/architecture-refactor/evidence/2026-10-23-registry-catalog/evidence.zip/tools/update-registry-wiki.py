from pathlib import Path
for lang in ('us','cn'):
 p=Path(f'wiki/probe-type-generation_{lang}.md')
 s=p.read_text(encoding='utf-8')
 if lang=='us':
  s=s.replace('Built-in providers retain their platform aliases and add the actual registry sources held by published `SimpleRegistryBasedAdapter` instances.', 'Built-in providers also call existing no-argument overrides, retain their explicit metadata, and add missing aliases from the actual registry sources held by published `SimpleRegistryBasedAdapter` instances.')
  s=s.replace('The same alias may reuse the same Registry object. Different Registry objects sharing an alias, or names colliding with generated `Tag` / `Namespace` symbols, reject generation with `NEKO-4052`.', 'Known physical sources may reuse an alias only for the same Registry object. Different known Registry objects sharing an alias, conflicting explicit metadata, or names colliding with generated `Tag` / `Namespace` symbols reject generation with `NEKO-4052`. Legacy explicit metadata carries no physical source identity; its provider remains responsible for matching its declared aliases to adapters.')
 else:
  s=s.replace('内置 provider 保留原平台别名，并追加已发布 `SimpleRegistryBasedAdapter` 实际持有的注册表来源。', '内置 provider 也会调用已有无参覆盖方法，保留其显式元数据，并追加已发布 `SimpleRegistryBasedAdapter` 实际持有的注册表来源中缺少的别名。')
  s=s.replace('同一别名可复用同一个 Registry 对象；同名不同 Registry，或与生成的 `Tag` / `Namespace` 类型名冲突时，以 `NEKO-4052` 拒绝生成。', '已知实际来源的同一别名只能复用同一个 Registry 对象；已知来源同名不同 Registry、显式元数据冲突，或与生成的 `Tag` / `Namespace` 类型名冲突时，以 `NEKO-4052` 拒绝生成。旧式显式元数据不携带实际来源标识，provider 仍须负责其声明别名与适配器匹配。')
 p.write_text(s, encoding='utf-8')
