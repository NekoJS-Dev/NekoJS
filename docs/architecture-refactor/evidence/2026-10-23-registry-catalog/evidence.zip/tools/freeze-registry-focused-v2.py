"""Preserve the focused matrix before full checks replace test reports."""
import json
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path.cwd()
dest = repo / 'build/priority-closeout/registry-catalog-focused-v2-xml'
assert not dest.exists()
counts = {}
for name in ['common', '1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    source = repo / ('common' if name == 'common' else 'versions/' + name) / 'build/test-results/test'
    target = dest / name
    target.mkdir(parents=True)
    count = dict(tests=0, skipped=0, failures=0, errors=0)
    for file in source.glob('TEST-*.xml'):
        assert any(key in file.name for key in ['NekoScriptCatalogRegistryTypesTest',
                                                'RegistryTypeCatalogsTest', 'BlockStateRegistryShapeTest', 'CatalogOverrideTest']), file
        suite = ET.parse(file).getroot()
        for key in count:
            count[key] += int(suite.attrib.get(key, 0))
        shutil.copy2(file, target / file.name)
    assert count == dict(tests=3 if name == 'common' else 9, skipped=0, failures=0, errors=0), (name, count)
    counts[name] = count
(dest / 'counts.json').write_text(json.dumps(counts, indent=2) + '\n')
print(json.dumps(counts))
