import json, shutil, subprocess, xml.etree.ElementTree as ET
from pathlib import Path

p = Path.cwd()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
checkout_revision = revision
revision = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',revision,'HEAD','--','common/src/main','src/main','src/fabric','versions','buildSrc'],text=True).strip()
log = p/'build/priority-closeout/registry-catalog-full-matrix.log'
assert 'BUILD SUCCESSFUL' in log.read_text(encoding='utf8')
out = p/'build/priority-closeout/registry-catalog-matrix'
assert not out.exists()
out.mkdir()
shutil.copyfile(log, out/log.name)
rows = []
for module in ['common', 'common-api-processor', *['versions/'+n for n in ['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']]]:
    tasks = ['test'] if not module.startswith('versions/') else ['test','platformGateTest']
    for task in tasks:
        paths = sorted((p/module/'build/test-results'/task).glob('TEST-*.xml'))
        assert paths, (module,task)
        totals = dict.fromkeys(['tests','failures','errors','skipped'], 0)
        for path in paths:
            root = ET.parse(path).getroot()
            for name in totals:
                totals[name] += int(root.get(name,'0'))
            dest = out/module/task/path.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path,dest)
        assert totals['failures'] == totals['errors'] == 0, (module,task,totals)
        rows.append(dict(module=module,task=task,suites=len(paths),**totals))
document = dict(sourceRevision=revision, checkoutRevision=checkout_revision, modules=rows, total={key:sum(row[key] for row in rows) for key in totals})
(out/'summary.json').write_text(json.dumps(document,indent=2)+'\n',encoding='utf8')
print(json.dumps(document))
