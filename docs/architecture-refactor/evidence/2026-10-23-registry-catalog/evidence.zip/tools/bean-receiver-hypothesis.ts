export {};
type NumericMember<R> = number & { (this: R): number };
declare class Vector { x: NumericMember<Vector>; }
declare const vector: Vector;
const value: number = vector.x;
const direct: number = vector.x();
const extracted = vector.x;
// @ts-expect-error Extracted primitive reads must not become callable.
extracted();
// @ts-expect-error Assigning a primitive read to a function would promise an invalid call.
const coerced: () => number = vector.x;
coerced();
// @ts-expect-error A primitive member has no callable Function.call operation.
vector.x.call(vector);
