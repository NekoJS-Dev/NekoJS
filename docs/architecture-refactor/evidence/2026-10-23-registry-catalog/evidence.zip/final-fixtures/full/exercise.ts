import type { $NekoScriptCatalogRegistryTypesTest$Use as Use } from 'java:com/tkisor/nekojs/api/catalog';
import type { RegistryTypes } from '@special/types';
declare const use: Use;
use.accept('fixture:one');
use.accept('fixture:two');
const tag: RegistryTypes.FixtureEntryTag = 'fixture:group';
// @ts-expect-error Registry metadata retains its finite value set.
use.accept('fixture:missing');
// @ts-expect-error Tags are collected independently of values.
const badTag: RegistryTypes.FixtureEntryTag = 'fixture:one';
