import type { RegistryTypes } from "@special/types";
declare module "java:com/tkisor/nekojs/api/catalog" {
    export class $NekoScriptCatalogRegistryTypesTest$Entry {
        constructor();
        label: string;
    }

    export class $NekoScriptCatalogRegistryTypesTest$Use {
        constructor();
        accept(value: $NekoScriptCatalogRegistryTypesTest$Entry_): void;
    }

    export type $NekoScriptCatalogRegistryTypesTest$Entry_ = $NekoScriptCatalogRegistryTypesTest$Entry | RegistryTypes.FixtureEntry;
}
