declare module "@special/types" {
    export namespace RegistryTypes {
        type Existing = "fixture:old";
        type ExistingTag = string;
        type FixtureEntry = "fixture:one" | "fixture:two";
        type FixtureEntryTag = "fixture:group";
        type Namespace = "fixture";
    }
}

export * as types from "@special/types";
