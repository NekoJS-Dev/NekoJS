declare module "@special/types" {
    export namespace RegistryTypes {
        type Existing = "fixture:old";
        type ExistingTag = string;
        type Namespace = "fixture";
    }
}

export * as types from "@special/types";
