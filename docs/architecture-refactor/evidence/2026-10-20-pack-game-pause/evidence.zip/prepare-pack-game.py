"""Prepare an isolated Fabric observation mod and native-game fixtures."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

repo=Path('D:/mcmodDemo/NekoJS-mult')
out=repo/'build/priority-closeout/pack-game-cc55c4ce-v3'
assert not out.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip().startswith('cc55c4ce')
out.mkdir()
(out/'game/mods').mkdir(parents=True)
source=repo/'build/priority-closeout/PackGameObservation.java'
(out/source.name).write_bytes(source.read_bytes())
for name in ('prepare-pack-game.py', 'run-pack-game.py'):
    (out/name).write_bytes((repo/'build/priority-closeout'/name).read_bytes())
init="""gradle.projectsEvaluated {
    def target = gradle.rootProject.findProject(':26.2.0-fabric')
    if (target == null) return
    target.tasks.register('packGameClasspath') {
        doLast { new File('%s').text = target.sourceSets.main.compileClasspath.asPath }
    }
    target.extensions.getByName('loom').runs.named('server') {
        runDir('%s')
        vmArg('-XX:NativeMemoryTracking=summary')
        vmArg('-Dneko.pack.observation=%s')
    }
}
""" % ((out/'compile-classpath.txt').as_posix(),(out/'game').as_posix(),out.as_posix())
(out/'observation.gradle').write_text(init,encoding='utf-8')
fixtures={}
def write(name,text):
    path=out/'game'/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text,encoding='utf-8')
    fixtures[name]=text
write('nekojs/startup_scripts/startup.js','console.info("PACK-GAME-OBSERVATION startup");\n')
write('nekojs/server_scripts/server.js','console.info("PACK-GAME-OBSERVATION legacy");\n')
for index in range(8):
    owner='pack'+str(index)
    prefix='nekojs/packs/'+owner+'/'
    write(prefix+'manifest.json',json.dumps(dict(formatVersion=1,id=owner,version='1.0.0',entries={'server':['main.js']}),indent=2)+'\n')
    write(prefix+'.neko_pack.state.json','{"enabled":false}\n')
    write(prefix+'server_scripts/main.js','''
if (typeof globalThis.privateOwner !== 'undefined') throw new Error('Owner Context was reused');
const ownerName = '%s';
const generationToken = Java.type('java.util.UUID').randomUUID().toString();
globalThis.privateOwner = ownerName;
globalThis.privateToken = generationToken;
globalThis.privatePayload = new Array(4096).fill('payload');
const probe = Java.type('neko.acceptance.PackGameObservation');
ServerEvents.tickPost(event => probe.tick(ownerName, generationToken));
setImmediate(() => probe.immediate(ownerName, generationToken));
setInterval(() => probe.interval(ownerName, generationToken), 3600000);
''' % owner)
(out/'fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n',encoding='utf-8')
bindings={}
for relative in ['common/build/classes/java/main','versions/26.2.0-fabric/build/classes/java/main']:
    directory=repo/relative
    for path in sorted(directory.rglob('*.class')):
        key=path.relative_to(directory).as_posix()
        assert key not in bindings
        bindings[key]=hashlib.sha256(path.read_bytes()).hexdigest()
(out/'source-binding.json').write_text(json.dumps(dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    classes=bindings,observerSha256=hashlib.sha256(source.read_bytes()).hexdigest()),indent=2)+'\n')
print('PREPARED',out)
