package com.tkisor.nekojs.core.compiler;

import com.google.gson.Gson;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.api.event.ScriptBindingSchema;
import com.tkisor.nekojs.core.fs.NekoJSPaths;
import com.tkisor.nekojs.core.lifecycle.NekoRuntimeRoot;
import com.tkisor.nekojs.core.module.NekoModulePipelineCache;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Diagnostic-only same-thread contrast; never enters the published runtime. */
public final class SuccessfulSyntaxReuseProbe {
    private record Fixture(Path path, String source, ScriptSourcePreflight.ParsedSource syntax) {}
    private record Sample(int pair, String arm, int rounds, long nanos) {}

    public static String measure(NekoRuntimeRoot root) throws Exception {
        var access = NekoRuntimeRoot.class.getDeclaredMethod("preparationCache");
        access.setAccessible(true);
        var cache = (NekoModulePipelineCache) access.invoke(root);
        var active = cache.activeBindingSchemaView(ScriptType.SERVER);
        if (active.schemas().isEmpty() || active.globals().isEmpty()) {
            throw new IllegalStateException("Live schema/globals are required for syntax contrast");
        }
        List<Fixture> fixtures = new ArrayList<>();
        try (var files = Files.walk(NekoJSPaths.get().root().resolve("server_scripts"))) {
            for (Path path : files.filter(Files::isRegularFile)
                    .filter(file -> file.toString().endsWith(".js")).sorted().toList()) {
                fixtures.add(fixture(path, Files.readString(path)));
            }
        }
        if (fixtures.size() != 6) throw new IllegalStateException("Expected six physical recursive fixtures");

        List<String> observed = new ArrayList<>();
        var view = new ScriptBindingSchema.View(active.schemas(), active.globals(),
                diagnostic -> observed.add(diagnostic.type() + ":" + diagnostic.callbackKind()
                        + ":" + diagnostic.throwable().getMessage()));
        for (Fixture fixture : fixtures) validate(fixture, view, false);
        List<String> expected = List.copyOf(observed);
        observed.clear();
        for (Fixture fixture : fixtures) validate(fixture, view, true);
        if (!observed.equals(expected)) throw new IllegalStateException("Live fixture diagnostics differ");

        for (int warmup = 0; warmup < 10; warmup++) {
            sample(fixtures, view, observed, expected, warmup % 2 == 0, 5);
            sample(fixtures, view, observed, expected, warmup % 2 != 0, 5);
        }
        List<Sample> samples = new ArrayList<>();
        for (int pair = 0; pair < 20; pair++) {
            for (boolean reuse : pair % 2 == 0 ? List.of(false, true) : List.of(true, false)) {
                samples.add(new Sample(pair + 1, reuse ? "successful-syntax-reuse" : "per-call-parse", 20,
                        sample(fixtures, view, observed, expected, reuse, 20)));
            }
        }
        var extra = fixture(fixtures.getFirst().path(),
                "SyntaxControlFixture.missing();\r\nSyntaxControlFixture.valid();");
        int schemaCases = 0;
        for (Set<String> members : List.of(Set.of("valid"), Set.of("valid", "missing"), Set.of("valid"))) {
            var checks = new ArrayList<String>();
            var current = new ScriptBindingSchema.View(Map.of("SyntaxControlFixture",
                    new ScriptBindingSchema.BindingMembers(members)), Set.of("console"),
                    diagnostic -> checks.add(diagnostic.callbackKind() + ":" + diagnostic.throwable().getMessage()));
            validate(extra, current, false);
            var baseline = List.copyOf(checks);
            checks.clear();
            validate(extra, current, true);
            if (!checks.equals(baseline)) throw new IllegalStateException("Current schema contrast differs");
            if (checks.isEmpty() != members.contains("missing")) {
                throw new IllegalStateException("Current schema was not reapplied");
            }
            schemaCases++;
        }
        return new Gson().toJson(Map.of("diagnosticOnly", true, "fixtures", fixtures.size(),
                "schemaBindings", active.schemas().size(), "knownGlobals", active.globals().size(),
                "diagnosticsPerSix", expected.size(), "currentSchemaCases", schemaCases,
                "successfulTreesOnly", true, "samples", samples));
    }

    private static Fixture fixture(Path path, String source) {
        var syntax = new ScriptSourcePreflight.ParsedSource(source);
        try {
            syntax.ast();
        } catch (Throwable failure) {
            throw new IllegalStateException("Syntax contrast requires successful parses: " + path, failure);
        }
        return new Fixture(path, source, syntax);
    }

    private static long sample(List<Fixture> fixtures, ScriptBindingSchema.View view,
                               List<String> observed, List<String> expected, boolean reuse, int rounds) {
        long started = System.nanoTime();
        for (int round = 0; round < rounds; round++) {
            observed.clear();
            for (Fixture fixture : fixtures) validate(fixture, view, reuse);
            if (!observed.equals(expected)) throw new IllegalStateException("Repeated diagnostics differ");
        }
        return System.nanoTime() - started;
    }

    private static void validate(Fixture fixture, ScriptBindingSchema.View view, boolean reuse) {
        if (reuse) {
            GlobalBindingMemberValidator.validate(fixture.path(), fixture.source(), view, fixture.syntax());
            EventCallbackSourceValidator.validate(fixture.path(), fixture.source(), view, fixture.syntax());
        } else {
            ScriptSourcePreflight.validate(fixture.path(), fixture.source(), view);
        }
    }
}
