import hashlib
import json
import os
import socket
import subprocess
import time
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
worktree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
run = repo / 'build/priority-closeout/successful-syntax-control-46505ad2'
assert not run.exists(), 'Preserve previous diagnostic attempts'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == '46505ad2c7652cc90fd723766e3c40340d0c7dcb'
for port in [25871, 25872]:
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', port))
run.mkdir()
command = worktree/'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java'
original = command.read_bytes()
(run/'original-command.java').write_bytes(original)
probe = worktree/'common/src/main/java/com/tkisor/nekojs/core/compiler/SuccessfulSyntaxReuseProbe.java'
assert not probe.exists()
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME']+'/bin;'+environment['PATH']
environment['PSModulePath'] = 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules;C:/Program Files/WindowsPowerShell/Modules'
gradle = [str(worktree/'gradlew.bat'), '-g', 'D:/mcmodDemo/NekoJS/.gradle-perf02',
          '-Dorg.gradle.java.home=C:/Program Files/Java/jdk-25.0.2', '--offline', '--no-parallel', '--console=plain',
          ':26.1.2:classes', ':26.1.2:jar', ':26.1.2:prepareServerRun']

def execute(label, args):
    print('DIAGNOSTIC_START', label, flush=True)
    start = time.monotonic()
    with (run/(label+'.log')).open('xb') as out:
        code = subprocess.run(args, cwd=worktree, env=environment, stdout=out, stderr=subprocess.STDOUT,
                              creationflags=subprocess.CREATE_NO_WINDOW).returncode
    result = dict(exitCode=code, seconds=round(time.monotonic()-start, 3), arguments=args)
    (run/(label+'-result.json')).write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print('DIAGNOSTIC_EXIT', label, code, flush=True)
    assert code == 0, label

try:
    probe.write_bytes((repo/'build/priority-closeout/SuccessfulSyntaxReuseProbe.java').read_bytes())
    (run/'SuccessfulSyntaxReuseProbe.java').write_bytes(probe.read_bytes())
    source = original.decode('utf-8')
    needle = 'reloadResult = root.reload(type);'
    assert source.count(needle) == 1
    source = source.replace(needle, needle+'\n            if (type == ScriptType.SERVER && reloadResult.success()) {\n'
        '                NekoJS.LOGGER.info("[DEBUG-SYNTAX-CONTROL-19] {}",\n'
        '                        com.tkisor.nekojs.core.compiler.SuccessfulSyntaxReuseProbe.measure(root));\n'
        '            }')
    command.write_bytes(source.encode('utf-8'))
    (run/'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=worktree))
    execute('build-diagnostic', gradle)
    outputs = worktree/'bench/perf/out'
    before = set(outputs.iterdir())
    execute('run-diagnostic', ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
        str(worktree/'bench/perf/sample.ps1'), '-Mode', 'reload', '-Node', '26.1.2', '-Warmup', '2',
        '-Samples', '5', '-Reloads', '1', '-GradleUserHome', 'D:/mcmodDemo/NekoJS/.gradle-perf02',
        '-ServerPort', '25871', '-RconPort', '25872'])
    created = sorted(set(outputs.iterdir())-before)
    (run/'output-directories.json').write_text(json.dumps([str(path) for path in created], indent=2)+'\n', encoding='utf-8')
    assert len(created) == 1
finally:
    command.write_bytes(original)
    if probe.exists():
        assert probe.resolve().is_relative_to(worktree.resolve())
        probe.unlink()
    execute('build-restored', gradle)
    assert command.read_bytes() == original
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
    expected = json.loads((repo/'build/priority-closeout/2026-10-19-46505ad2-verification/performance-source-binding.json').read_text())
    actual = {}
    for directory in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
        root = worktree/directory
        for path in root.rglob('*.class'):
            name = path.relative_to(root).as_posix()
            assert name not in actual
            actual[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == expected['classBindings']
    jars = list((worktree/'versions/26.1.2/build/libs').glob('*.jar'))
    assert len(jars) == 1 and hashlib.sha256(jars[0].read_bytes()).hexdigest() == expected['jarSha256']
    (run/'restoration.json').write_text(json.dumps(dict(sourceRestored=True, worktreeClean=True,
        classesMatchFormal=True, classCount=len(actual), jarMatchesFormal=True,
        jarSha256=expected['jarSha256']), indent=2)+'\n', encoding='utf-8')
    print('RESTORATION_COMPLETE', len(actual), flush=True)
