import { $Codec, $Dynamic, $DynamicOps } from "java:com/mojang/serialization";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $Map, $UUID } from "java:java/util";
import { $DoublePredicate, $DoublePredicate_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";

declare module "java:net/minecraft/world/entity/ai/gossip" {
    export class $GossipContainer {
        constructor();
        static DISCARD_THRESHOLD: number;
        get gossipEntries(): $Map<$UUID, $Object2IntMap<$GossipType>>;
        getGossipEntries(): $Map<$UUID, $Object2IntMap<$GossipType>>;
        add(arg0: string, arg1: $GossipType_, arg2: number): void;
        decay(): void;
        getCountForType(arg0: $GossipType_, arg1: $DoublePredicate_<number, boolean>): number;
        getReputation(arg0: string, arg1: $Predicate_<$GossipType, $GossipType, boolean>): number;
        remove(arg0: string, arg1: $GossipType_, arg2: number): void;
        remove(arg0: string, arg1: $GossipType_): void;
        remove(arg0: $GossipType_): void;
        store<T>(arg0: $DynamicOps<T>): T;
        transferFrom(arg0: $GossipContainer, arg1: $RandomSource, arg2: number): void;
        update(arg0: $Dynamic<any>): void;
    }

    export class $GossipType {
        static MAJOR_NEGATIVE: $GossipType;
        static MAJOR_POSITIVE: $GossipType;
        static MINOR_NEGATIVE: $GossipType;
        static MINOR_POSITIVE: $GossipType;
        static TRADING: $GossipType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GossipType[];
        static valueOf(name: string): $GossipType;
    }

    export type $GossipType_ = $GossipType | "MAJOR_NEGATIVE" | "MAJOR_POSITIVE" | "MINOR_NEGATIVE" | "MINOR_POSITIVE" | "TRADING";
}
