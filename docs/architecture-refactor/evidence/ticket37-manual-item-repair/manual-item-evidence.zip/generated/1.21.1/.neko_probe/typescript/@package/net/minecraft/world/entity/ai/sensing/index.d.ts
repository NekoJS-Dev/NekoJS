import { $Entity, $Mob } from "java:net/minecraft/world/entity";

declare module "java:net/minecraft/world/entity/ai/sensing" {
    export class $Sensing {
        constructor(arg0: $Mob);
        hasLineOfSight(arg0: $Entity): boolean;
        tick(): void;
    }

}
