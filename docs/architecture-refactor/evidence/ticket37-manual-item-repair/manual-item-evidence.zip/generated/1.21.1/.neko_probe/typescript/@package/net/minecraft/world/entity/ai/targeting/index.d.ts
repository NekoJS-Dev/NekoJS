import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $LivingEntity } from "java:net/minecraft/world/entity";

declare module "java:net/minecraft/world/entity/ai/targeting" {
    export class $TargetingConditions {
        static DEFAULT: $TargetingConditions;
        static forCombat(): $TargetingConditions;
        static forNonCombat(): $TargetingConditions;
        copy(): $TargetingConditions;
        ignoreInvisibilityTesting(): $TargetingConditions;
        ignoreLineOfSight(): $TargetingConditions;
        range(arg0: number): $TargetingConditions;
        selector(arg0: $Predicate_<$LivingEntity, $LivingEntity, boolean>): $TargetingConditions;
        test(arg0: $LivingEntity, arg1: $LivingEntity): boolean;
    }

}
