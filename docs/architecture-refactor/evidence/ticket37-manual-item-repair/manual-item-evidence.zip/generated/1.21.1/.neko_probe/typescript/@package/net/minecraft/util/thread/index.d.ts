import { $Either } from "java:com/mojang/datafixers/util";
import { $AutoCloseable, $AutoCloseable_, $Exception, $Runnable, $Runnable_ } from "java:java/lang";
import { $List } from "java:java/util";
import { $CompletableFuture, $Executor, $Executor_ } from "java:java/util/concurrent";
import { $BooleanSupplier, $BooleanSupplier_, $Consumer, $Consumer_, $Function, $Function_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $MetricSampler, $ProfilerMeasured, $ProfilerMeasured_ } from "java:net/minecraft/util/profiling/metrics";

declare module "java:net/minecraft/util/thread" {
    export class $BlockableEventLoop<R extends $Runnable> implements $ProfilerMeasured, $ProcessorHandle<R>, $Executor {
        get pendingTasksCount(): number;
        getPendingTasksCount(): number;
        get sameThread(): boolean;
        isSameThread(): boolean;
        askEither<Source>(arg0: $Function_<$ProcessorHandle<$Either<Source, $Exception>>, R, $ProcessorHandle<$Either<Source, $Exception>>, R>): $CompletableFuture<Source>;
        ask<Source>(arg0: $Function_<$ProcessorHandle<Source>, R, $ProcessorHandle<Source>, R>): $CompletableFuture<Source>;
        close(): void;
        executeBlocking(arg0: $Runnable_): void;
        executeIfPossible(arg0: $Runnable_): void;
        execute(arg0: $Runnable_): void;
        managedBlock(arg0: $BooleanSupplier_<boolean>): void;
        name(): string;
        pollTask(): boolean;
        profiledMetrics(): $List<$MetricSampler>;
        submitAsync(arg0: $Runnable_): $CompletableFuture<void>;
        submit(arg0: $Runnable_): $CompletableFuture<void>;
        submit<V>(arg0: $Supplier_<V, V>): $CompletableFuture<V>;
        tell(arg0: R): void;
        waitForTasks(): void;
    }

    export interface $ProcessorHandle<Msg> extends $AutoCloseable {
        askEither<Source>(arg0: $Function_<$ProcessorHandle<$Either<Source, $Exception>>, Msg, $ProcessorHandle<$Either<Source, $Exception>>, Msg>): $CompletableFuture<Source>;
        ask<Source>(arg0: $Function_<$ProcessorHandle<Source>, Msg, $ProcessorHandle<Source>, Msg>): $CompletableFuture<Source>;
        close(): void;
        name(): string;
        tell(arg0: Msg): void;
    }
    export const $ProcessorHandle: {
        of<Msg>(arg0: string, arg1: $Consumer_<Msg, Msg>): $ProcessorHandle<Msg>;
    };

    export class $ProcessorMailbox<T> implements $ProfilerMeasured, $ProcessorHandle<T>, $AutoCloseable, $Runnable {
        constructor(arg0: $StrictQueue<any, $Runnable>, arg1: $Executor_<$Runnable>, arg2: string);
        static create(arg0: $Executor_<$Runnable>, arg1: string): $ProcessorMailbox<$Runnable>;
        askEither<Source>(arg0: $Function_<$ProcessorHandle<$Either<Source, $Exception>>, T, $ProcessorHandle<$Either<Source, $Exception>>, T>): $CompletableFuture<Source>;
        ask<Source>(arg0: $Function_<$ProcessorHandle<Source>, T, $ProcessorHandle<Source>, T>): $CompletableFuture<Source>;
        close(): void;
        hasWork(): boolean;
        name(): string;
        profiledMetrics(): $List<$MetricSampler>;
        runAll(): void;
        run(): void;
        size(): number;
        tell(arg0: T): void;
        toString(): string;
    }

    export class $ReentrantBlockableEventLoop<R extends $Runnable> extends $BlockableEventLoop<R> {
        constructor(arg0: string);
        askEither<Source>(arg0: $Function_<$ProcessorHandle<$Either<Source, $Exception>>, R, $ProcessorHandle<$Either<Source, $Exception>>, R>): $CompletableFuture<Source>;
        ask<Source>(arg0: $Function_<$ProcessorHandle<Source>, R, $ProcessorHandle<Source>, R>): $CompletableFuture<Source>;
        close(): void;
        doRunTask(arg0: R): void;
        scheduleExecutables(): boolean;
    }

    export interface $StrictQueue<T, F> {
        isEmpty(): boolean;
        pop(): F;
        push(arg0: T): boolean;
        size(): number;
    }

}
