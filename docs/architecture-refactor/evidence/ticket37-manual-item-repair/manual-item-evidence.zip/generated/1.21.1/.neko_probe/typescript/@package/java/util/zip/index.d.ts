import { $Closeable, $Closeable_, $File, $InputStream } from "java:java/io";
import { $Cloneable } from "java:java/lang";
import { $Charset } from "java:java/nio/charset";
import { $FileTime } from "java:java/nio/file/attribute";
import { $LocalDateTime } from "java:java/time";
import { $Enumeration } from "java:java/util";
import { $Stream } from "java:java/util/stream";

declare module "java:java/util/zip" {
    export class $ZipEntry implements $ZipConstants, $Cloneable {
        constructor(arg0: string);
        constructor(arg0: $ZipEntry);
        static DEFLATED: number;
        static STORED: number;
        get comment(): string;
        getComment(): string;
        set comment(value: string);
        get compressedSize(): number;
        getCompressedSize(): number;
        set compressedSize(value: number);
        get crc(): number;
        getCrc(): number;
        set crc(value: number);
        get creationTime(): $FileTime;
        getCreationTime(): $FileTime;
        set creationTime(value: $FileTime);
        get extra(): number[];
        getExtra(): number[];
        set extra(value: number[]);
        get lastAccessTime(): $FileTime;
        getLastAccessTime(): $FileTime;
        set lastAccessTime(value: $FileTime);
        get lastModifiedTime(): $FileTime;
        getLastModifiedTime(): $FileTime;
        set lastModifiedTime(value: $FileTime);
        get method(): number;
        getMethod(): number;
        set method(value: number);
        get name(): string;
        getName(): string;
        get size(): number;
        getSize(): number;
        set size(value: number);
        get timeLocal(): $LocalDateTime;
        getTimeLocal(): $LocalDateTime;
        set timeLocal(value: $LocalDateTime);
        get time(): number;
        getTime(): number;
        set time(value: number);
        get directory(): boolean;
        isDirectory(): boolean;
        clone(): object;
        hashCode(): number;
        setComment(arg0: string): void;
        setCompressedSize(arg0: number): void;
        setCrc(arg0: number): void;
        setCreationTime(arg0: $FileTime): $ZipEntry;
        setExtra(arg0: number[]): void;
        setLastAccessTime(arg0: $FileTime): $ZipEntry;
        setLastModifiedTime(arg0: $FileTime): $ZipEntry;
        setMethod(arg0: number): void;
        setSize(arg0: number): void;
        setTimeLocal(arg0: $LocalDateTime): void;
        setTime(arg0: number): void;
        toString(): string;
    }

    export class $ZipFile implements $ZipConstants, $Closeable {
        constructor(arg0: string);
        constructor(arg0: string, arg1: number);
        constructor(arg0: string, arg1: number, arg2: $Charset);
        constructor(arg0: string, arg1: $Charset);
        constructor(arg0: string);
        constructor(arg0: string, arg1: $Charset);
        static OPEN_DELETE: number;
        static OPEN_READ: number;
        get comment(): string;
        getComment(): string;
        get name(): string;
        getName(): string;
        close(): void;
        entries(): $Enumeration<$ZipEntry>;
        getEntry(arg0: string): $ZipEntry;
        getInputStream(arg0: $ZipEntry): $InputStream;
        size(): number;
        stream(): $Stream<$ZipEntry>;
    }

}
