import { $List, $UUID } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $Function, $Function_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $MinMaxBounds$Doubles } from "java:net/minecraft/advancements/critereon";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $Entity, $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/commands/arguments/selector" {
    export class $EntitySelector {
        constructor(arg0: number, arg1: boolean, arg2: boolean, arg3: $Predicate_<$Entity, $Entity, boolean>[], arg4: $MinMaxBounds$Doubles, arg5: $Function_<$Vec3, $Vec3, $Vec3, $Vec3_>, arg6: $AABB, arg7: $BiConsumer_<$Vec3, $List<$Entity>, $Vec3, $List<$Entity>>, arg8: boolean, arg9: string, arg10: string, arg11: $EntityType_, arg12: boolean);
        static INFINITE: number;
        static ORDER_ARBITRARY: $BiConsumer<$Vec3, $List<$Entity>>;
        contextFreePredicates: $List<$Predicate<$Entity>>;
        get maxResults(): number;
        getMaxResults(): number;
        get selfSelector(): boolean;
        isSelfSelector(): boolean;
        get worldLimited(): boolean;
        isWorldLimited(): boolean;
        static joinNames(arg0: $Entity[]): $Component;
        findEntities(arg0: $CommandSourceStack): $List<$Entity>;
        findPlayers(arg0: $CommandSourceStack): $List<$ServerPlayer>;
        findSingleEntity(arg0: $CommandSourceStack): $Entity;
        findSinglePlayer(arg0: $CommandSourceStack): $ServerPlayer;
        includesEntities(): boolean;
        usesSelector(): boolean;
    }

}
