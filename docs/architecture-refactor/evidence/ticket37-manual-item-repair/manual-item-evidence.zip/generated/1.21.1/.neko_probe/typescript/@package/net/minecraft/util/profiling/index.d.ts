import { $Comparable, $Comparable_ } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $List } from "java:java/util";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $MetricCategory, $MetricCategory_ } from "java:net/minecraft/util/profiling/metrics";

export * as metrics from "java:net/minecraft/util/profiling/metrics";

declare module "java:net/minecraft/util/profiling" {
    export interface $ProfileResults {
        getEndTimeNano(): number;
        getEndTimeTicks(): number;
        getNanoDuration(): number;
        getProfilerResults(): string;
        getStartTimeNano(): number;
        getStartTimeTicks(): number;
        getTickDuration(): number;
        getTimes(arg0: string): $List<$ResultField>;
        saveResults(arg0: string): boolean;
    }
    export const $ProfileResults: {
        demanglePath(arg0: string): string;
        readonly PATH_SEPARATOR: string;
    };

    export interface $ProfilerFiller {
        endTick(): void;
        incrementCounter(arg0: string, arg1: number): void;
        incrementCounter(arg0: string): void;
        incrementCounter(arg0: $Supplier_<string, string>, arg1: number): void;
        incrementCounter(arg0: $Supplier_<string, string>): void;
        markForCharting(arg0: $MetricCategory_): void;
        popPush(arg0: string): void;
        popPush(arg0: $Supplier_<string, string>): void;
        pop(): void;
        push(arg0: string): void;
        push(arg0: $Supplier_<string, string>): void;
        startTick(): void;
    }
    export const $ProfilerFiller: {
        tee(arg0: $ProfilerFiller, arg1: $ProfilerFiller): $ProfilerFiller;
        readonly ROOT: string;
    };

    export class $ResultField implements $Comparable<$ResultField> {
        constructor(arg0: string, arg1: number, arg2: number, arg3: number);
        count: number;
        globalPercentage: number;
        name: string;
        percentage: number;
        get color(): number;
        getColor(): number;
        compareTo(arg0: $ResultField): number;
    }

}
