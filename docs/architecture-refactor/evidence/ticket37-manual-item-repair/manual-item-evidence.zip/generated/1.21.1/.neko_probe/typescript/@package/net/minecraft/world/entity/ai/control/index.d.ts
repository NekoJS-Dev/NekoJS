import { $Entity, $Mob } from "java:net/minecraft/world/entity";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/ai/control" {
    export interface $Control {
    }

    export class $JumpControl implements $Control {
        constructor(arg0: $Mob);
        jump(): void;
        tick(): void;
    }

    export class $LookControl implements $Control {
        constructor(arg0: $Mob);
        get wantedX(): number;
        getWantedX(): number;
        get wantedY(): number;
        getWantedY(): number;
        get wantedZ(): number;
        getWantedZ(): number;
        get lookingAtTarget(): boolean;
        isLookingAtTarget(): boolean;
        setLookAt(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): void;
        setLookAt(arg0: number, arg1: number, arg2: number): void;
        setLookAt(arg0: $Entity, arg1: number, arg2: number): void;
        setLookAt(arg0: $Entity): void;
        setLookAt(arg0: $Vec3_): void;
        tick(): void;
    }

    export class $MoveControl implements $Control {
        constructor(arg0: $Mob);
        static MIN_SPEED: number;
        static MIN_SPEED_SQR: number;
        get speedModifier(): number;
        getSpeedModifier(): number;
        get wantedX(): number;
        getWantedX(): number;
        get wantedY(): number;
        getWantedY(): number;
        get wantedZ(): number;
        getWantedZ(): number;
        hasWanted(): boolean;
        setWantedPosition(arg0: number, arg1: number, arg2: number, arg3: number): void;
        strafe(arg0: number, arg1: number): void;
        tick(): void;
    }

}
