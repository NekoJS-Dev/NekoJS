import { $Set } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Entity, $Mob } from "java:net/minecraft/world/entity";
import { $Level } from "java:net/minecraft/world/level";
import { $NodeEvaluator, $Path, $PathType, $PathType_ } from "java:net/minecraft/world/level/pathfinder";

declare module "java:net/minecraft/world/entity/ai/navigation" {
    export class $PathNavigation {
        constructor(arg0: $Mob, arg1: $Level);
        get maxDistanceToWaypoint(): number;
        getMaxDistanceToWaypoint(): number;
        get nodeEvaluator(): $NodeEvaluator;
        getNodeEvaluator(): $NodeEvaluator;
        get path(): $Path;
        getPath(): $Path;
        get targetPos(): $BlockPos;
        getTargetPos(): $BlockPos;
        get done(): boolean;
        isDone(): boolean;
        get inProgress(): boolean;
        isInProgress(): boolean;
        get stuck(): boolean;
        isStuck(): boolean;
        canCutCorner(arg0: $PathType_): boolean;
        canFloat(): boolean;
        createPath(arg0: number, arg1: number, arg2: number, arg3: number): $Path;
        createPath(arg0: $BlockPos_[], arg1: number): $Path;
        createPath(arg0: $Stream<$BlockPos>, arg1: number): $Path;
        createPath(arg0: $BlockPos_, arg1: number, arg2: number): $Path;
        createPath(arg0: $BlockPos_, arg1: number): $Path;
        createPath(arg0: $Entity, arg1: number): $Path;
        isStableDestination(arg0: $BlockPos_): boolean;
        moveTo(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        moveTo(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): boolean;
        moveTo(arg0: $Entity, arg1: number): boolean;
        moveTo(arg0: $Path, arg1: number): boolean;
        recomputePath(): void;
        resetMaxVisitedNodesMultiplier(): void;
        setCanFloat(arg0: boolean): void;
        setMaxVisitedNodesMultiplier(arg0: number): void;
        setSpeedModifier(arg0: number): void;
        shouldRecomputePath(arg0: $BlockPos_): boolean;
        stop(): void;
        tick(): void;
    }

}
