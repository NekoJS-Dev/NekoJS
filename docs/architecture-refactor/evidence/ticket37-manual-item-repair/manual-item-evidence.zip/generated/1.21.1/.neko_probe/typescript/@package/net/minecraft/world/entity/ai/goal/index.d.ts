import { $EnumSet, $Set } from "java:java/util";
import { $Predicate, $Predicate_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $ProfilerFiller } from "java:net/minecraft/util/profiling";

declare module "java:net/minecraft/world/entity/ai/goal" {
    export class $Goal {
        constructor();
        get flags(): $EnumSet<$Goal$Flag>;
        getFlags(): $EnumSet<$Goal$Flag>;
        set flags(value: $EnumSet<$Goal$Flag>);
        get interruptable(): boolean;
        isInterruptable(): boolean;
        canContinueToUse(): boolean;
        canUse(): boolean;
        requiresUpdateEveryTick(): boolean;
        setFlags(arg0: $EnumSet<$Goal$Flag>): void;
        start(): void;
        stop(): void;
        tick(): void;
        toString(): string;
    }

    export class $Goal$Flag {
        static JUMP: $Goal$Flag;
        static LOOK: $Goal$Flag;
        static MOVE: $Goal$Flag;
        static TARGET: $Goal$Flag;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Goal$Flag[];
        static valueOf(name: string): $Goal$Flag;
    }

    export class $GoalSelector {
        constructor(arg0: $Supplier_<$ProfilerFiller, $ProfilerFiller>);
        get availableGoals(): $Set<$WrappedGoal>;
        getAvailableGoals(): $Set<$WrappedGoal>;
        addGoal(arg0: number, arg1: $Goal): void;
        disableControlFlag(arg0: $Goal$Flag_): void;
        enableControlFlag(arg0: $Goal$Flag_): void;
        removeAllGoals(arg0: $Predicate_<$Goal, $Goal, boolean>): void;
        removeGoal(arg0: $Goal): void;
        setControlFlag(arg0: $Goal$Flag_, arg1: boolean): void;
        tickRunningGoals(arg0: boolean): void;
        tick(): void;
    }

    export class $WrappedGoal extends $Goal {
        constructor(arg0: number, arg1: $Goal);
        get flags(): $EnumSet<$Goal$Flag>;
        getFlags(): $EnumSet<$Goal$Flag>;
        set flags(value: $EnumSet<$Goal$Flag>);
        get goal(): $Goal;
        getGoal(): $Goal;
        get priority(): number;
        getPriority(): number;
        get interruptable(): boolean;
        isInterruptable(): boolean;
        get running(): boolean;
        isRunning(): boolean;
        canBeReplacedBy(arg0: $WrappedGoal): boolean;
        canContinueToUse(): boolean;
        canUse(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        requiresUpdateEveryTick(): boolean;
        setFlags(arg0: $EnumSet<$Goal$Flag>): void;
        start(): void;
        stop(): void;
        tick(): void;
    }

    export type $Goal$Flag_ = $Goal$Flag | "JUMP" | "LOOK" | "MOVE" | "TARGET";
}
