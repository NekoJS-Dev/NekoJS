import type { RegistryTypes } from "@special/types";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Int2DoubleFunction, $Int2IntFunction } from "java:it/unimi/dsi/fastutil/ints";
import { $Comparable, $Comparable_, $Record, $Runnable, $Runnable_ } from "java:java/lang";
import { $Map, $Set } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $Consumer, $Consumer_ } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $Holder, $Holder_, $Registry } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleOptions_ } from "java:net/minecraft/core/particles";
import { $CompoundTag, $CompoundTag_, $Tag } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $Entity$RemovalReason, $Entity$RemovalReason_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Attribute, $AttributeMap, $AttributeModifier, $AttributeModifier$Operation, $AttributeModifier$Operation_, $Attribute_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $FeatureElement, $FeatureElement_, $FeatureFlag, $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $IClientMobEffectExtensions } from "java:net/neoforged/neoforge/client/extensions/common";
import { $EffectCure } from "java:net/neoforged/neoforge/common";
import { $IMobEffectExtension } from "java:net/neoforged/neoforge/common/extensions";

declare module "java:net/minecraft/world/effect" {
    export class $MobEffect implements $FeatureElement, $IMobEffectExtension {
        static CODEC: $Codec<$Holder<$MobEffect>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$MobEffect>>;
        attributeModifiers: $Map<$Holder<$Attribute>, $MobEffect$AttributeTemplate>;
        get blendDurationTicks(): number;
        getBlendDurationTicks(): number;
        get category(): $MobEffectCategory;
        getCategory(): $MobEffectCategory;
        get color(): number;
        getColor(): number;
        get descriptionId(): string;
        getDescriptionId(): string;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get beneficial(): boolean;
        isBeneficial(): boolean;
        get instantenous(): boolean;
        isInstantenous(): boolean;
        addAttributeModifiers(arg0: $AttributeMap, arg1: number): void;
        addAttributeModifier(arg0: $Holder_, arg1: $ResourceLocation_, arg2: number, arg3: $AttributeModifier$Operation_): $MobEffect;
        addAttributeModifier(arg0: $Holder_, arg1: $ResourceLocation_, arg2: $AttributeModifier$Operation_, arg3: $Int2DoubleFunction): $MobEffect;
        applyEffectTick(arg0: $LivingEntity, arg1: number): boolean;
        applyInstantenousEffect(arg0: $Entity, arg1: $Entity, arg2: $LivingEntity, arg3: number, arg4: number): void;
        createModifiers(arg0: number, arg1: $BiConsumer_<$Holder<$Attribute>, $AttributeModifier, $Holder<$Attribute>, $AttributeModifier>): void;
        createParticleOptions(arg0: $MobEffectInstance): $ParticleOptions;
        fillEffectCures(arg0: $EffectCure[], arg1: $MobEffectInstance): void;
        getSortOrder(arg0: $MobEffectInstance): number;
        initializeClient(arg0: $Consumer_<$IClientMobEffectExtensions, $IClientMobEffectExtensions>): void;
        isEnabled(arg0: $FeatureFlagSet): boolean;
        onEffectAdded(arg0: $LivingEntity, arg1: number): void;
        onEffectStarted(arg0: $LivingEntity, arg1: number): void;
        onMobHurt(arg0: $LivingEntity, arg1: number, arg2: $DamageSource, arg3: number): void;
        onMobRemoved(arg0: $LivingEntity, arg1: number, arg2: $Entity$RemovalReason_): void;
        removeAttributeModifiers(arg0: $AttributeMap): void;
        requiredFeatures(arg0?: $FeatureFlag[]): $MobEffect;
        requiredFeatures(): $FeatureFlagSet;
        setBlendDuration(arg0: number): $MobEffect;
        shouldApplyEffectTickThisTick(arg0: number, arg1: number): boolean;
        withSoundOnAdded(arg0: $SoundEvent_): $MobEffect;
    }

    export class $MobEffect$AttributeTemplate extends $Record {
        constructor(arg0: $ResourceLocation_, arg1: number, arg2: $AttributeModifier$Operation_);
        constructor(id: $ResourceLocation_, amount: number, operation: $AttributeModifier$Operation_, curve: $Int2DoubleFunction);
        amount(): number;
        create(arg0: number): $AttributeModifier;
        curve(): $Int2DoubleFunction;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        operation(): $AttributeModifier$Operation;
        toString(): string;
    }

    export class $MobEffectCategory {
        static BENEFICIAL: $MobEffectCategory;
        static HARMFUL: $MobEffectCategory;
        static NEUTRAL: $MobEffectCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MobEffectCategory[];
        static valueOf(name: string): $MobEffectCategory;
    }

    export class $MobEffectInstance implements $Comparable<$MobEffectInstance> {
        constructor(arg0: $Holder_);
        constructor(arg0: $Holder_, arg1: number);
        constructor(arg0: $Holder_, arg1: number, arg2: number);
        constructor(arg0: $Holder_, arg1: number, arg2: number, arg3: boolean, arg4: boolean);
        constructor(arg0: $Holder_, arg1: number, arg2: number, arg3: boolean, arg4: boolean, arg5: boolean);
        constructor(arg0: $Holder_, arg1: number, arg2: number, arg3: boolean, arg4: boolean, arg5: boolean, arg6: $MobEffectInstance);
        constructor(arg0: $MobEffectInstance);
        static CODEC: $Codec<$MobEffectInstance>;
        static INFINITE_DURATION: number;
        static MAX_AMPLIFIER: number;
        static MIN_AMPLIFIER: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $MobEffectInstance>;
        get amplifier(): number;
        getAmplifier(): number;
        get cures(): $Set<$EffectCure>;
        getCures(): $Set<$EffectCure>;
        get descriptionId(): string;
        getDescriptionId(): string;
        get duration(): number;
        getDuration(): number;
        get effect(): $Holder<$MobEffect>;
        getEffect(): $Holder<$MobEffect>;
        get particleOptions(): $ParticleOptions;
        getParticleOptions(): $ParticleOptions;
        get ambient(): boolean;
        isAmbient(): boolean;
        get infiniteDuration(): boolean;
        isInfiniteDuration(): boolean;
        get visible(): boolean;
        isVisible(): boolean;
        static load(arg0: $CompoundTag_): $MobEffectInstance;
        compareTo(arg0: $MobEffectInstance): number;
        copyBlendState(arg0: $MobEffectInstance): void;
        endsWithin(arg0: number): boolean;
        equals(arg0: object): boolean;
        getBlendFactor(arg0: $LivingEntity, arg1: number): number;
        hashCode(): number;
        is(arg0: $Holder_): boolean;
        mapDuration(arg0: $Int2IntFunction): number;
        onEffectAdded(arg0: $LivingEntity): void;
        onEffectStarted(arg0: $LivingEntity): void;
        onMobHurt(arg0: $LivingEntity, arg1: $DamageSource, arg2: number): void;
        onMobRemoved(arg0: $LivingEntity, arg1: $Entity$RemovalReason_): void;
        save(): $Tag;
        showIcon(): boolean;
        skipBlending(): void;
        tick(arg0: $LivingEntity, arg1: $Runnable_): boolean;
        toString(): string;
        update(arg0: $MobEffectInstance): boolean;
    }

    export class $MobEffects {
        constructor();
        static ABSORPTION: $Holder<$MobEffect>;
        static BAD_OMEN: $Holder<$MobEffect>;
        static BLINDNESS: $Holder<$MobEffect>;
        static CONDUIT_POWER: $Holder<$MobEffect>;
        static CONFUSION: $Holder<$MobEffect>;
        static DAMAGE_BOOST: $Holder<$MobEffect>;
        static DAMAGE_RESISTANCE: $Holder<$MobEffect>;
        static DARKNESS: $Holder<$MobEffect>;
        static DIG_SLOWDOWN: $Holder<$MobEffect>;
        static DIG_SPEED: $Holder<$MobEffect>;
        static DOLPHINS_GRACE: $Holder<$MobEffect>;
        static FIRE_RESISTANCE: $Holder<$MobEffect>;
        static GLOWING: $Holder<$MobEffect>;
        static HARM: $Holder<$MobEffect>;
        static HEAL: $Holder<$MobEffect>;
        static HEALTH_BOOST: $Holder<$MobEffect>;
        static HERO_OF_THE_VILLAGE: $Holder<$MobEffect>;
        static HUNGER: $Holder<$MobEffect>;
        static INFESTED: $Holder<$MobEffect>;
        static INVISIBILITY: $Holder<$MobEffect>;
        static JUMP: $Holder<$MobEffect>;
        static LEVITATION: $Holder<$MobEffect>;
        static LUCK: $Holder<$MobEffect>;
        static MOVEMENT_SLOWDOWN: $Holder<$MobEffect>;
        static MOVEMENT_SPEED: $Holder<$MobEffect>;
        static NIGHT_VISION: $Holder<$MobEffect>;
        static OOZING: $Holder<$MobEffect>;
        static POISON: $Holder<$MobEffect>;
        static RAID_OMEN: $Holder<$MobEffect>;
        static REGENERATION: $Holder<$MobEffect>;
        static SATURATION: $Holder<$MobEffect>;
        static SLOW_FALLING: $Holder<$MobEffect>;
        static TRIAL_OMEN: $Holder<$MobEffect>;
        static UNLUCK: $Holder<$MobEffect>;
        static WATER_BREATHING: $Holder<$MobEffect>;
        static WEAKNESS: $Holder<$MobEffect>;
        static WEAVING: $Holder<$MobEffect>;
        static WIND_CHARGED: $Holder<$MobEffect>;
        static WITHER: $Holder<$MobEffect>;
        static bootstrap(arg0: $Registry<$MobEffect>): $Holder<$MobEffect>;
    }

    export type $MobEffect_ = $MobEffect | RegistryTypes.MobEffect | $NekoId | string;
    export type $MobEffectCategory_ = $MobEffectCategory | "BENEFICIAL" | "HARMFUL" | "NEUTRAL";
}
