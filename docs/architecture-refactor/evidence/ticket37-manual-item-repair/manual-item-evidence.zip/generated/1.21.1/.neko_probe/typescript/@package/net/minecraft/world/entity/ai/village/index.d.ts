export * as poi from "java:net/minecraft/world/entity/ai/village/poi";

declare module "java:net/minecraft/world/entity/ai/village" {
    export interface $ReputationEventType {
    }
    export const $ReputationEventType: {
        register(arg0: string): $ReputationEventType;
        readonly GOLEM_KILLED: $ReputationEventType;
        readonly TRADE: $ReputationEventType;
        readonly VILLAGER_HURT: $ReputationEventType;
        readonly VILLAGER_KILLED: $ReputationEventType;
        readonly ZOMBIE_VILLAGER_CURED: $ReputationEventType;
    };

}
