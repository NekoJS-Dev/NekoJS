import { $ImmutableList } from "java:com/google/common/collect";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult, $Dynamic, $DynamicOps, $RecordBuilder } from "java:com/mojang/serialization";
import { $Collection, $List, $Map, $Optional, $Set } from "java:java/util";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $BehaviorControl } from "java:net/minecraft/world/entity/ai/behavior";
import { $ExpirableValue, $MemoryModuleType, $MemoryStatus, $MemoryStatus_ } from "java:net/minecraft/world/entity/ai/memory";
import { $Sensor, $SensorType } from "java:net/minecraft/world/entity/ai/sensing";
import { $Activity, $Activity_, $Schedule, $Schedule_ } from "java:net/minecraft/world/entity/schedule";

export * as attributes from "java:net/minecraft/world/entity/ai/attributes";
export * as behavior from "java:net/minecraft/world/entity/ai/behavior";
export * as control from "java:net/minecraft/world/entity/ai/control";
export * as goal from "java:net/minecraft/world/entity/ai/goal";
export * as gossip from "java:net/minecraft/world/entity/ai/gossip";
export * as memory from "java:net/minecraft/world/entity/ai/memory";
export * as navigation from "java:net/minecraft/world/entity/ai/navigation";
export * as sensing from "java:net/minecraft/world/entity/ai/sensing";
export * as targeting from "java:net/minecraft/world/entity/ai/targeting";
export * as village from "java:net/minecraft/world/entity/ai/village";

declare module "java:net/minecraft/world/entity/ai" {
    export class $Brain<E extends $LivingEntity> {
        constructor(arg0: $MemoryModuleType<any>[], arg1: $SensorType<$Sensor<any>>[], arg2: $ImmutableList<$Brain$MemoryValue<any>>, arg3: $Supplier_<$Codec<$Brain<E>>, $Codec<$Brain<E>>>);
        get activeActivities(): $Set<$Activity>;
        getActiveActivities(): $Set<$Activity>;
        get activeNonCoreActivity(): $Optional<$Activity>;
        getActiveNonCoreActivity(): $Optional<$Activity>;
        get memories(): $Map<$MemoryModuleType<any>, $Optional<$ExpirableValue<any>>>;
        getMemories(): $Map<$MemoryModuleType<any>, $Optional<$ExpirableValue<any>>>;
        get runningBehaviors(): $List<$BehaviorControl<any>>;
        getRunningBehaviors(): $List<$BehaviorControl<any>>;
        get schedule(): $Schedule;
        getSchedule(): $Schedule;
        set schedule(value: $Schedule_);
        static codec<E extends $LivingEntity>(arg0: $MemoryModuleType<any>[], arg1: $SensorType<$Sensor<any>>[]): $Codec<$Brain<E>>;
        static provider<E extends $LivingEntity>(arg0: $MemoryModuleType<any>[], arg1: $SensorType<$Sensor<any>>[]): $Brain$Provider<E>;
        addActivityAndRemoveMemoriesWhenStopped(arg0: $Activity_, arg1: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, arg2: $Pair<$MemoryModuleType<any>, $MemoryStatus>[], arg3: $MemoryModuleType<any>[]): void;
        addActivityAndRemoveMemoryWhenStopped(arg0: $Activity_, arg1: number, arg2: $ImmutableList<$BehaviorControl<any>>, arg3: $MemoryModuleType<any>): void;
        addActivityWithConditions(arg0: $Activity_, arg1: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, arg2: $Pair<$MemoryModuleType<any>, $MemoryStatus>[]): void;
        addActivity(arg0: $Activity_, arg1: $ImmutableList<$Pair<number, $BehaviorControl<any>>>): void;
        addActivity(arg0: $Activity_, arg1: number, arg2: $ImmutableList<$BehaviorControl<any>>): void;
        checkMemory(arg0: $MemoryModuleType<any>, arg1: $MemoryStatus_): boolean;
        clearMemories(): void;
        copyWithoutBehaviors(): $Brain<E>;
        eraseMemory<U>(arg0: $MemoryModuleType<U>): void;
        getMemoryInternal<U>(arg0: $MemoryModuleType<U>): $Optional<U>;
        getMemory<U>(arg0: $MemoryModuleType<U>): $Optional<U>;
        getTimeUntilExpiry<U>(arg0: $MemoryModuleType<U>): number;
        hasMemoryValue(arg0: $MemoryModuleType<any>): boolean;
        isActive(arg0: $Activity_): boolean;
        isMemoryValue<U>(arg0: $MemoryModuleType<U>, arg1: U): boolean;
        removeAllBehaviors(): void;
        serializeStart<T>(arg0: $DynamicOps<T>): $DataResult<T>;
        setActiveActivityIfPossible(arg0: $Activity_): void;
        setActiveActivityToFirstValid(arg0: $Activity_[]): void;
        setCoreActivities(arg0: $Activity_[]): void;
        setDefaultActivity(arg0: $Activity_): void;
        setMemoryWithExpiry<U>(arg0: $MemoryModuleType<U>, arg1: U, arg2: number): void;
        setMemory<U>(arg0: $MemoryModuleType<U>, arg1: U): void;
        setMemory<U>(arg0: $MemoryModuleType<U>, arg1: $Optional<U>): void;
        setSchedule(arg0: $Schedule_): void;
        stopAll(arg0: $ServerLevel, arg1: E): void;
        tick(arg0: $ServerLevel, arg1: E): void;
        updateActivityFromSchedule(arg0: number, arg1: number): void;
        useDefaultActivity(): void;
    }

    export class $Brain$MemoryValue<U> {
        serialize<T>(arg0: $DynamicOps<T>, arg1: $RecordBuilder<T>): void;
    }

    export class $Brain$Provider<E extends $LivingEntity> {
        makeBrain(arg0: $Dynamic<any>): $Brain<E>;
    }

}
