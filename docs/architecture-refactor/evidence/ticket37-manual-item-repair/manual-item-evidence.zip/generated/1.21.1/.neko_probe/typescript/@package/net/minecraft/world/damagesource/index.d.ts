import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Holder, $Holder_, $Registry, $RegistryAccess } from "java:net/minecraft/core";
import { $BootstrapContext } from "java:net/minecraft/data/worldgen";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $Style } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $Entity, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $AbstractArrow, $Fireball, $FireworkRocketEntity, $WitherSkull } from "java:net/minecraft/world/entity/projectile";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Explosion } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $ExtensionInfo, $IExtensibleEnum } from "java:net/neoforged/fml/common/asm/enumextension";
import { $IDeathMessageProvider, $IDeathMessageProvider_, $IScalingFunction, $IScalingFunction_ } from "java:net/neoforged/neoforge/common/damagesource";

declare module "java:net/minecraft/world/damagesource" {
    export class $CombatEntry extends $Record {
        constructor(arg0: $DamageSource, arg1: number, arg2: $FallLocation, arg3: number);
        damage(): number;
        equals(arg0: object): boolean;
        fallDistance(): number;
        fallLocation(): $FallLocation;
        hashCode(): number;
        source(): $DamageSource;
        toString(): string;
    }

    export class $CombatTracker {
        constructor(arg0: $LivingEntity);
        static INTENTIONAL_GAME_DESIGN_STYLE: $Style;
        static RESET_COMBAT_STATUS_TIME: number;
        static RESET_DAMAGE_STATUS_TIME: number;
        get combatDuration(): number;
        getCombatDuration(): number;
        get deathMessage(): $Component;
        getDeathMessage(): $Component;
        get mostSignificantFall(): $CombatEntry;
        getMostSignificantFall(): $CombatEntry;
        getFallMessage(arg0: $CombatEntry, arg1: $Entity): $Component;
        recheckStatus(): void;
        recordDamage(arg0: $DamageSource, arg1: number): void;
    }

    export class $DamageEffects {
        static BURNING: $DamageEffects;
        static DROWNING: $DamageEffects;
        static FREEZING: $DamageEffects;
        static HURT: $DamageEffects;
        static POKING: $DamageEffects;
        static THORNS: $DamageEffects;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DamageEffects[];
        static valueOf(name: string): $DamageEffects;
    }

    export class $DamageScaling {
        static ALWAYS: $DamageScaling;
        static NEVER: $DamageScaling;
        static WHEN_CAUSED_BY_LIVING_NON_PLAYER: $DamageScaling;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DamageScaling[];
        static valueOf(name: string): $DamageScaling;
    }

    export class $DamageSource {
        constructor(arg0: $Holder_);
        constructor(arg0: $Holder_, arg1: $Entity);
        constructor(arg0: $Holder_, arg1: $Entity, arg2: $Entity);
        constructor(arg0: $Holder_, arg1: $Entity, arg2: $Entity, arg3: $Vec3_);
        constructor(arg0: $Holder_, arg1: $Vec3_);
        get directEntity(): $Entity;
        getDirectEntity(): $Entity;
        get entity(): $Entity;
        getEntity(): $Entity;
        get foodExhaustion(): number;
        getFoodExhaustion(): number;
        get msgId(): string;
        getMsgId(): string;
        get sourcePosition(): $Vec3;
        getSourcePosition(): $Vec3;
        get weaponItem(): $ItemStack;
        getWeaponItem(): $ItemStack;
        get creativePlayer(): boolean;
        isCreativePlayer(): boolean;
        get direct(): boolean;
        isDirect(): boolean;
        getLocalizedDeathMessage(arg0: $LivingEntity): $Component;
        is(arg0: $ResourceKey<$DamageType>): boolean;
        is(arg0: $TagKey_): boolean;
        scalesWithDifficulty(): boolean;
        sourcePositionRaw(): $Vec3;
        toString(): string;
        typeHolder(): $Holder<$DamageType>;
        type(): $DamageType;
    }

    export class $DamageSources {
        constructor(arg0: $RegistryAccess);
        damageTypes: $Registry<$DamageType>;
        anvil(arg0: $Entity): $DamageSource;
        arrow(arg0: $AbstractArrow, arg1: $Entity): $DamageSource;
        badRespawnPointExplosion(arg0: $Vec3_): $DamageSource;
        cactus(): $DamageSource;
        campfire(): $DamageSource;
        cramming(): $DamageSource;
        dragonBreath(): $DamageSource;
        drown(): $DamageSource;
        dryOut(): $DamageSource;
        explosion(arg0: $Entity, arg1: $Entity): $DamageSource;
        explosion(arg0: $Explosion): $DamageSource;
        fallingBlock(arg0: $Entity): $DamageSource;
        fallingStalactite(arg0: $Entity): $DamageSource;
        fall(): $DamageSource;
        fellOutOfWorld(): $DamageSource;
        fireball(arg0: $Fireball, arg1: $Entity): $DamageSource;
        fireworks(arg0: $FireworkRocketEntity, arg1: $Entity): $DamageSource;
        flyIntoWall(): $DamageSource;
        freeze(): $DamageSource;
        genericKill(): $DamageSource;
        generic(): $DamageSource;
        hotFloor(): $DamageSource;
        inFire(): $DamageSource;
        inWall(): $DamageSource;
        indirectMagic(arg0: $Entity, arg1: $Entity): $DamageSource;
        lava(): $DamageSource;
        lightningBolt(): $DamageSource;
        magic(): $DamageSource;
        mobAttack(arg0: $LivingEntity): $DamageSource;
        mobProjectile(arg0: $Entity, arg1: $LivingEntity): $DamageSource;
        noAggroMobAttack(arg0: $LivingEntity): $DamageSource;
        onFire(): $DamageSource;
        outOfBorder(): $DamageSource;
        playerAttack(arg0: $Player): $DamageSource;
        sonicBoom(arg0: $Entity): $DamageSource;
        source(arg0: $ResourceKey<$DamageType>, arg1: $Entity, arg2: $Entity): $DamageSource;
        source(arg0: $ResourceKey<$DamageType>, arg1: $Entity): $DamageSource;
        source(arg0: $ResourceKey<$DamageType>): $DamageSource;
        spit(arg0: $Entity, arg1: $LivingEntity): $DamageSource;
        stalagmite(): $DamageSource;
        starve(): $DamageSource;
        sting(arg0: $LivingEntity): $DamageSource;
        sweetBerryBush(): $DamageSource;
        thorns(arg0: $Entity): $DamageSource;
        thrown(arg0: $Entity, arg1: $Entity): $DamageSource;
        trident(arg0: $Entity, arg1: $Entity): $DamageSource;
        windCharge(arg0: $Entity, arg1: $LivingEntity): $DamageSource;
        witherSkull(arg0: $WitherSkull, arg1: $Entity): $DamageSource;
        wither(): $DamageSource;
    }

    export class $DamageType extends $Record {
        constructor(arg0: string, arg1: number);
        constructor(arg0: string, arg1: number, arg2: $DamageEffects_);
        constructor(arg0: string, arg1: $DamageScaling_, arg2: number);
        constructor(arg0: string, arg1: $DamageScaling_, arg2: number, arg3: $DamageEffects_);
        constructor(arg0: string, arg1: $DamageScaling_, arg2: number, arg3: $DamageEffects_, arg4: $DeathMessageType_);
        static CODEC: $Codec<$Holder<$DamageType>>;
        static DIRECT_CODEC: $Codec<$DamageType>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$DamageType>>;
        deathMessageType(): $DeathMessageType;
        effects(): $DamageEffects;
        equals(arg0: object): boolean;
        exhaustion(): number;
        hashCode(): number;
        msgId(): string;
        scaling(): $DamageScaling;
        toString(): string;
    }

    export interface $DamageTypes {
    }
    export const $DamageTypes: {
        bootstrap(arg0: $BootstrapContext<$DamageType>): void;
        readonly ARROW: $ResourceKey<$DamageType>;
        readonly BAD_RESPAWN_POINT: $ResourceKey<$DamageType>;
        readonly CACTUS: $ResourceKey<$DamageType>;
        readonly CAMPFIRE: $ResourceKey<$DamageType>;
        readonly CRAMMING: $ResourceKey<$DamageType>;
        readonly DRAGON_BREATH: $ResourceKey<$DamageType>;
        readonly DROWN: $ResourceKey<$DamageType>;
        readonly DRY_OUT: $ResourceKey<$DamageType>;
        readonly EXPLOSION: $ResourceKey<$DamageType>;
        readonly FALL: $ResourceKey<$DamageType>;
        readonly FALLING_ANVIL: $ResourceKey<$DamageType>;
        readonly FALLING_BLOCK: $ResourceKey<$DamageType>;
        readonly FALLING_STALACTITE: $ResourceKey<$DamageType>;
        readonly FELL_OUT_OF_WORLD: $ResourceKey<$DamageType>;
        readonly FIREBALL: $ResourceKey<$DamageType>;
        readonly FIREWORKS: $ResourceKey<$DamageType>;
        readonly FLY_INTO_WALL: $ResourceKey<$DamageType>;
        readonly FREEZE: $ResourceKey<$DamageType>;
        readonly GENERIC: $ResourceKey<$DamageType>;
        readonly GENERIC_KILL: $ResourceKey<$DamageType>;
        readonly HOT_FLOOR: $ResourceKey<$DamageType>;
        readonly INDIRECT_MAGIC: $ResourceKey<$DamageType>;
        readonly IN_FIRE: $ResourceKey<$DamageType>;
        readonly IN_WALL: $ResourceKey<$DamageType>;
        readonly LAVA: $ResourceKey<$DamageType>;
        readonly LIGHTNING_BOLT: $ResourceKey<$DamageType>;
        readonly MAGIC: $ResourceKey<$DamageType>;
        readonly MOB_ATTACK: $ResourceKey<$DamageType>;
        readonly MOB_ATTACK_NO_AGGRO: $ResourceKey<$DamageType>;
        readonly MOB_PROJECTILE: $ResourceKey<$DamageType>;
        readonly ON_FIRE: $ResourceKey<$DamageType>;
        readonly OUTSIDE_BORDER: $ResourceKey<$DamageType>;
        readonly PLAYER_ATTACK: $ResourceKey<$DamageType>;
        readonly PLAYER_EXPLOSION: $ResourceKey<$DamageType>;
        readonly SONIC_BOOM: $ResourceKey<$DamageType>;
        readonly SPIT: $ResourceKey<$DamageType>;
        readonly STALAGMITE: $ResourceKey<$DamageType>;
        readonly STARVE: $ResourceKey<$DamageType>;
        readonly STING: $ResourceKey<$DamageType>;
        readonly SWEET_BERRY_BUSH: $ResourceKey<$DamageType>;
        readonly THORNS: $ResourceKey<$DamageType>;
        readonly THROWN: $ResourceKey<$DamageType>;
        readonly TRIDENT: $ResourceKey<$DamageType>;
        readonly UNATTRIBUTED_FIREBALL: $ResourceKey<$DamageType>;
        readonly WIND_CHARGE: $ResourceKey<$DamageType>;
        readonly WITHER: $ResourceKey<$DamageType>;
        readonly WITHER_SKULL: $ResourceKey<$DamageType>;
    };

    export class $DeathMessageType {
        static DEFAULT: $DeathMessageType;
        static FALL_VARIANTS: $DeathMessageType;
        static INTENTIONAL_GAME_DESIGN: $DeathMessageType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DeathMessageType[];
        static valueOf(name: string): $DeathMessageType;
    }

    export class $FallLocation extends $Record {
        constructor(arg0: string);
        static GENERIC: $FallLocation;
        static LADDER: $FallLocation;
        static OTHER_CLIMBABLE: $FallLocation;
        static SCAFFOLDING: $FallLocation;
        static TWISTING_VINES: $FallLocation;
        static VINES: $FallLocation;
        static WATER: $FallLocation;
        static WEEPING_VINES: $FallLocation;
        static blockToFallLocation(arg0: $BlockState_): $FallLocation;
        static getCurrentFallLocation(arg0: $LivingEntity): $FallLocation;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): string;
        languageKey(): string;
        toString(): string;
    }

    export type $DamageEffects_ = $DamageEffects | "BURNING" | "DROWNING" | "FREEZING" | "HURT" | "POKING" | "THORNS";
    export type $DamageScaling_ = $DamageScaling | "ALWAYS" | "NEVER" | "WHEN_CAUSED_BY_LIVING_NON_PLAYER";
    export type $DeathMessageType_ = $DeathMessageType | "DEFAULT" | "FALL_VARIANTS" | "INTENTIONAL_GAME_DESIGN";
}
