import type { RegistryTypes } from "@special/types";
import { $DataFixer } from "java:com/mojang/datafixers";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Record, $Runnable, $Runnable_ } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Optional, $Set } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiPredicate, $BiPredicate_, $BooleanSupplier, $BooleanSupplier_, $Consumer, $Consumer_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Holder, $Holder_, $RegistryAccess, $SectionPos } from "java:net/minecraft/core";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $RandomSource } from "java:net/minecraft/util";
import { $ChunkPos, $LevelHeightAccessor, $LevelReader } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $LevelChunkSection } from "java:net/minecraft/world/level/chunk";
import { $ChunkIOErrorReporter, $RegionStorageInfo, $SectionStorage } from "java:net/minecraft/world/level/chunk/storage";

declare module "java:net/minecraft/world/entity/ai/village/poi" {
    export class $PoiManager extends $SectionStorage<$PoiSection> {
        constructor(arg0: $RegionStorageInfo, arg1: string, arg2: $DataFixer, arg3: boolean, arg4: $RegistryAccess, arg5: $ChunkIOErrorReporter, arg6: $LevelHeightAccessor);
        static MAX_VILLAGE_DISTANCE: number;
        static VILLAGE_SECTION_SIZE: number;
        add(arg0: $BlockPos_, arg1: $Holder_): void;
        checkConsistencyWithBlocks(arg0: $SectionPos, arg1: $LevelChunkSection): void;
        ensureLoadedAndValid(arg0: $LevelReader, arg1: $BlockPos_, arg2: number): void;
        existsAtPosition(arg0: $ResourceKey<$PoiType>, arg1: $BlockPos_): boolean;
        exists(arg0: $BlockPos_, arg1: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>): boolean;
        findAllClosestFirstWithType(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $Predicate_<$BlockPos, $BlockPos, boolean>, arg2: $BlockPos_, arg3: number, arg4: $PoiManager$Occupancy_): $Stream<$Pair<$Holder<$PoiType>, $BlockPos>>;
        findAllWithType(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $Predicate_<$BlockPos, $BlockPos, boolean>, arg2: $BlockPos_, arg3: number, arg4: $PoiManager$Occupancy_): $Stream<$Pair<$Holder<$PoiType>, $BlockPos>>;
        findAll(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $Predicate_<$BlockPos, $BlockPos, boolean>, arg2: $BlockPos_, arg3: number, arg4: $PoiManager$Occupancy_): $Stream<$BlockPos>;
        findClosestWithType(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $BlockPos_, arg2: number, arg3: $PoiManager$Occupancy_): $Optional<$Pair<$Holder<$PoiType>, $BlockPos>>;
        findClosest(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $Predicate_<$BlockPos, $BlockPos, boolean>, arg2: $BlockPos_, arg3: number, arg4: $PoiManager$Occupancy_): $Optional<$BlockPos>;
        findClosest(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $BlockPos_, arg2: number, arg3: $PoiManager$Occupancy_): $Optional<$BlockPos>;
        find(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $Predicate_<$BlockPos, $BlockPos, boolean>, arg2: $BlockPos_, arg3: number, arg4: $PoiManager$Occupancy_): $Optional<$BlockPos>;
        getCountInRange(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $BlockPos_, arg2: number, arg3: $PoiManager$Occupancy_): number;
        getFreeTickets(arg0: $BlockPos_): number;
        getInChunk(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $ChunkPos, arg2: $PoiManager$Occupancy_): $Stream<$PoiRecord>;
        getInRange(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $BlockPos_, arg2: number, arg3: $PoiManager$Occupancy_): $Stream<$PoiRecord>;
        getInSquare(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $BlockPos_, arg2: number, arg3: $PoiManager$Occupancy_): $Stream<$PoiRecord>;
        getRandom(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $Predicate_<$BlockPos, $BlockPos, boolean>, arg2: $PoiManager$Occupancy_, arg3: $BlockPos_, arg4: number, arg5: $RandomSource): $Optional<$BlockPos>;
        getType(arg0: $BlockPos_): $Optional<$Holder<$PoiType>>;
        release(arg0: $BlockPos_): boolean;
        remove(arg0: number): void;
        remove(arg0: $BlockPos_): void;
        sectionsToVillage(arg0: $SectionPos): number;
        take(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $BiPredicate_<$Holder<$PoiType>, $BlockPos, $Holder<$PoiType>, $BlockPos, boolean>, arg2: $BlockPos_, arg3: number): $Optional<$BlockPos>;
        tick(arg0: $BooleanSupplier_<boolean>): void;
    }

    export class $PoiManager$Occupancy {
        static ANY: $PoiManager$Occupancy;
        static HAS_SPACE: $PoiManager$Occupancy;
        static IS_OCCUPIED: $PoiManager$Occupancy;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PoiManager$Occupancy[];
        static valueOf(name: string): $PoiManager$Occupancy;
    }

    export class $PoiRecord {
        constructor(arg0: $BlockPos_, arg1: $Holder_, arg2: $Runnable_);
        get freeTickets(): number;
        getFreeTickets(): number;
        get poiType(): $Holder<$PoiType>;
        getPoiType(): $Holder<$PoiType>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get occupied(): boolean;
        isOccupied(): boolean;
        static codec(arg0: $Runnable_): $Codec<$PoiRecord>;
        equals(arg0: object): boolean;
        hasSpace(): boolean;
        hashCode(): number;
    }

    export class $PoiSection {
        constructor(arg0: $Runnable_);
        static codec(arg0: $Runnable_): $Codec<$PoiSection>;
        add(arg0: $BlockPos_, arg1: $Holder_): void;
        exists(arg0: $BlockPos_, arg1: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>): boolean;
        getFreeTickets(arg0: $BlockPos_): number;
        getRecords(arg0: $Predicate_<$Holder<$PoiType>, $Holder<$PoiType>, boolean>, arg1: $PoiManager$Occupancy_): $Stream<$PoiRecord>;
        getType(arg0: $BlockPos_): $Optional<$Holder<$PoiType>>;
        refresh(arg0: $Consumer_<$BiConsumer<$BlockPos, $Holder<$PoiType>>, $BiConsumer<$BlockPos, $Holder<$PoiType>>>): void;
        release(arg0: $BlockPos_): boolean;
        remove(arg0: $BlockPos_): void;
    }

    export class $PoiType extends $Record {
        constructor(matchingStates: $BlockState_[], maxTickets: number, validRange: number);
        static NONE: $Predicate<$Holder<$PoiType>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        is(arg0: $BlockState_): boolean;
        matchingStates(): $Set<$BlockState>;
        maxTickets(): number;
        toString(): string;
        validRange(): number;
    }

    export type $PoiManager$Occupancy_ = $PoiManager$Occupancy | "ANY" | "HAS_SPACE" | "IS_OCCUPIED";
    export type $PoiType_ = $PoiType | RegistryTypes.PoiType | $NekoId | string;
}
