# Manual nested item installed acceptance

Exact source base and one-file canonical producer patch, five current official
JARs from final matrix. Fresh owned worlds/original cached loaders/fixtures.
Run all five real Probe generation/runtime checks with normal RCON/direct exits,
strict unchanged default editor includes and all Python stubs. Compare current
whole diagnostic headers to prior exact d109, retain other actual failures.
Verify actual manual duplicate item disappears on three NeoForge nodes and
Fabric files remain unchanged. Never hand-edit generated output or hide gates.
Current d109 performance and client proofs do not certify this later patch.
