import json
import os
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
installed = project / 'build/ticket37-current-d109-installed'
assert json.loads((installed/'runner-exit.json').read_text())['exitCode']==0
assert json.loads((installed/'proof-runner-exit.json').read_text())['exitCode']==0
assert json.loads((installed/'ide-runner-exit.json').read_text())['exitCode']==0
for row in json.loads((installed/'preparation-manifest.json').read_text())['nodes']:
    assert json.loads((installed/row['node']/'server-exit.json').read_text())['exitCode']==0
replacements = {
    '93f4b259ffafb6466918582fcfa950c2c2480d77':'d10912ebbf24d9d5df75a908dc7a5529da09979a',
    'ticket37-perf-93f4b259':'ticket37-perf-d10912eb',
    'guard-same-name-performance.ps1':'guard-current-d109-performance.ps1',
    'same-name-performance-preparation-exit.json':'current-d109-performance-preparation-exit.json',
    'same-name-performance-groups-exits.json':'current-d109-performance-groups-exits.json',
}
for original,target in (
    ('prepare-same-name-performance.ps1','prepare-current-d109-performance.ps1'),
    ('guard-same-name-performance.ps1','guard-current-d109-performance.ps1'),
    ('run-same-name-performance.py','run-current-d109-performance.py')):
    text=(helpers/original).read_text()
    for before,after in replacements.items(): text=text.replace(before,after)
    destination=helpers/target
    assert not destination.exists()
    destination.write_text(text)
environment=dict(os.environ)
environment['PSModulePath']=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(helpers/'prepare-current-d109-performance.ps1')],
    env=environment,creationflags=subprocess.CREATE_NO_WINDOW)
(helpers/'current-d109-performance-preparation-exit.json').write_text(json.dumps(dict(exitCode=result.returncode,sourceRevision=replacements['93f4b259ffafb6466918582fcfa950c2c2480d77'])))
raise SystemExit(result.returncode)
