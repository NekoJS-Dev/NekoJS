declare const vector: { readonly x: number & (() => number) };
const numericRead: number = vector.x;
const directCall: number = vector.x();
const extracted = vector.x;
const extractedCall: number = extracted();
