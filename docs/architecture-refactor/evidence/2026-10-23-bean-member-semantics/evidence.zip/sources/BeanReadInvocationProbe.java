import com.tkisor.nekojs.core.NekoSharedHostAccess;
import graal.graalvm.polyglot.Context;
import graal.graalvm.polyglot.PolyglotException;
import net.minecraft.core.SectionPos;
import net.minecraft.world.phys.Vec3;
import com.google.gson.GsonBuilder;
import java.nio.file.*;
import java.util.*;

/** Records actual host read/invoke behavior without a Minecraft launcher or applied Mixins. */
public final class BeanReadInvocationProbe {
    public static void main(String[] args) throws Exception {
        var result = new LinkedHashMap<String, Object>();
        result.put("scope", "Untransformed Minecraft classes, production HostAccess, no launcher or applied Mixins");
        result.put("vec3Source", Vec3.class.getProtectionDomain().getCodeSource().getLocation().toString());
        result.put("sectionPosSource", SectionPos.class.getProtectionDomain().getCodeSource().getLocation().toString());
        var rows = new ArrayList<Map<String, Object>>();
        try (Context context = Context.newBuilder("js").allowExperimentalOptions(true)
                .allowHostAccess(new NekoSharedHostAccess(List.of()).get())
                .allowHostClassLookup(name -> false).allowCreateProcess(false)
                .option("js.nashorn-compat", "true").option("js.foreign-object-prototype", "true")
                .option("js.ecmascript-version", "latest").option("js.strict", "true")
                .option("js.v8-compat", "true").build()) {
            context.getBindings("js").putMember("vector", new Vec3(7, 8, 9));
            context.getBindings("js").putMember("section", SectionPos.of(11, 12, 13));
            for (String expression : List.of("typeof vector.x", "vector.x", "vector.x()",
                    "(() => { const member = vector.x; return member(); })()",
                    "typeof section.x", "section.x()", "section.getX()",
                    "(() => { const member = section.x; return member(); })()")) {
                var row = new LinkedHashMap<String, Object>();
                row.put("expression", expression);
                try {
                    var value = context.eval("js", expression);
                    row.put("success", true);
                    row.put("value", value.isNumber() ? value.asDouble() : value.toString());
                } catch (PolyglotException e) {
                    row.put("success", false);
                    row.put("guestException", e.isGuestException());
                    row.put("message", e.getMessage());
                }
                rows.add(row);
            }
        }
        result.put("observations", rows);
        Files.writeString(Path.of(args[0]), new GsonBuilder().setPrettyPrinting().create().toJson(result));
        System.out.println("BEAN_READ_INVOCATION_RECORDED");
    }
}
