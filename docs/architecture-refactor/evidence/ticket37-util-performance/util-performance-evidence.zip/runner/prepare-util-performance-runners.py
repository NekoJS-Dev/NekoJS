import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
runner = root/'build/ticket37-config-sync-repair'
revision = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
assert revision == '60139fffffa6e54b2248797c2a32d4fd75025a54'
for name in ['prepare-f84-performance.ps1', 'guard-f84-performance.ps1', 'run-f84-performance.py', 'prepare-f84-performance.py', 'archive-f84-performance.py', 'verify-f84-performance.py']:
    text = (runner/name).read_text(encoding='utf-8')
    text = text.replace('f84e2adbc36cac31ec8b2da8a448fbc0b8bbebae', revision).replace('f84e2adb','60139fff')
    text = text.replace('ticket37-node-ambient-installed','ticket37-node-util-predicate-installed').replace('node-ambient-ide-exit','node-util-predicate-ide-exit')
    text = text.replace('f84-performance','util-performance')
    if name == 'archive-f84-performance.py':
        start = text.index('compiled = []')
        end = text.index('fixture_hashes =', start)
        text = text[:start] + """compiled = []
relative = 'common/build/resources/main/nekojs/node/modules/util.ts'
assert (owned/relative).read_bytes() == (root/relative).read_bytes()
resource = (owned/relative).read_bytes()
installed = root/'build/ticket37-node-util-predicate-installed'
preparation = json.loads((installed/'preparation-manifest.json').read_text())
for row in preparation['nodes']:
    artifacts = list((installed/row['node']/'mods').glob('nekojs-*.jar'))
    assert len(artifacts) == 1 and sha(artifacts[0].read_bytes()) == row['sha256']
    with ZipFile(artifacts[0]) as jar: assert jar.read('nekojs/node/modules/util.ts') == resource
compiled.append(dict(path=relative, sha256=sha(resource), actualFiveInstalledResourcesByteEqual=True))
""" + text[end:]
        text = text.replace('compiledClasses=compiled', 'compiledResources=compiled').replace('No causal claim about Node declaration change','No causal claim about the util annotation correction')
    if name == 'verify-f84-performance.py':
        text = text.replace('compiledClassesMatchInstalledBuild=True', 'compiledResourcesMatchFiveInstalledArtifacts=True')
    target = runner/name.replace('f84-performance', 'util-performance')
    assert not target.exists()
    target.write_text(text, encoding='utf-8')
out = root/'docs/architecture-refactor/evidence/ticket37-util-performance'
assert not out.exists()
out.mkdir()
plan = dict(sourceRevision=revision, groups=['reload-confirmed-1','reload-confirmed-2','startup-confirmed'], unchangedSampler=True,
    samplesPerGroup=5, startupThreshold=41173, reloadThreshold=285.3, noDiscardedValues=True,
    startAfterOwnedServersAndCompilersSettle=True)
(out/'PLAN.json').write_text(json.dumps(plan, indent=2)+'\n', encoding='utf-8')
print(json.dumps(plan))
