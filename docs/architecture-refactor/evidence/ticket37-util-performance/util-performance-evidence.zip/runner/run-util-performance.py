import json
import os
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
repair = root/'build/ticket37-config-sync-repair'
owned = root/'build/ticket37-perf-owned-ac810fa7'
destination = root/'build/ticket37-perf-60139fff'
revision = '60139fffffa6e54b2248797c2a32d4fd75025a54'
assert json.loads((repair/'util-performance-preparation-exit.json').read_text())['exitCode'] == 0
child_env = dict(os.environ)
child_env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
child_env['JAVA_HOME'] = r'C:\Program Files\Java\jdk-25.0.2'
child_env['PATH'] = child_env['JAVA_HOME']+r'\bin;'+child_env['PATH']
records = []
for group, mode in [('reload-confirmed-1', 'reload'), ('reload-confirmed-2', 'reload'), ('startup-confirmed', 'startup')]:
    with (destination/(group+'-guard.txt')).open('xb') as output:
        guard = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(repair/'guard-util-performance.ps1')], stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW, env=child_env)
    assert guard.returncode == 0
    print('FORMAL_GROUP_START='+group, flush=True)
    with (destination/(group+'.txt')).open('xb') as output:
        sampler = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(owned/'bench/perf/sample.ps1'), '-Mode', mode, '-Node', '26.1.2', '-Warmup', '2', '-Samples', '5', '-Reloads', '5', '-GradleUserHome', 'D:/mcmodDemo/NekoJS/.gradle-perf02', '-ServerPort', '25871', '-RconPort', '25872'], cwd=owned, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW, env=child_env)
    record = dict(group=group, mode=mode, samplerExit=sampler.returncode, sourceRevision=revision,
        capture='Python subprocess redirected files, direct OS wait returncode')
    (destination/(group+'-exit.json')).write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    records.append(record)
    print('FORMAL_GROUP='+group+' EXIT='+str(sampler.returncode), flush=True)
    assert sampler.returncode == 0, record
(repair/'util-performance-groups-exits.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
