export * as wrapoperation from "java:com/llamalad7/mixinextras/injector/wrapoperation";

