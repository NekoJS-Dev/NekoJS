declare module "java:com/llamalad7/mixinextras/sugar/ref" {
    export interface $LocalRef<T> {
        get(): T;
        set(arg0: T): void;
    }

}
