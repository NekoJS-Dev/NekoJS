import { $CharSequence } from "java:java/lang";
import { $Predicate as $NekoImport$Predicate, $Predicate_ as $NekoImport$Predicate_ } from "java:java/util/function";

declare module "java:com/google/common/base" {
    export interface $Predicate<T> extends $NekoImport$Predicate<T> {
        apply(input: T): boolean;
        equals(obj: unknown): boolean;
        test(input: T): boolean;
    }

    export class $CharMatcher implements $Predicate<string> {
        static anyOf(sequence: $CharSequence): $CharMatcher;
        static any(): $CharMatcher;
        static ascii(): $CharMatcher;
        static breakingWhitespace(): $CharMatcher;
        static digit(): $CharMatcher;
        static forPredicate(predicate: $Predicate_<string, string, boolean>): $CharMatcher;
        static inRange(startInclusive: string, endInclusive: string): $CharMatcher;
        static invisible(): $CharMatcher;
        static isNot(match: string): $CharMatcher;
        static is(match: string): $CharMatcher;
        static javaDigit(): $CharMatcher;
        static javaIsoControl(): $CharMatcher;
        static javaLetterOrDigit(): $CharMatcher;
        static javaLetter(): $CharMatcher;
        static javaLowerCase(): $CharMatcher;
        static javaUpperCase(): $CharMatcher;
        static noneOf(sequence: $CharSequence): $CharMatcher;
        static none(): $CharMatcher;
        static singleWidth(): $CharMatcher;
        static whitespace(): $CharMatcher;
        and(other: $CharMatcher): $CharMatcher;
        and(arg0: $NekoImport$Predicate_<string, string, boolean>): $NekoImport$Predicate<string>;
        apply(character: string): boolean;
        collapseFrom(sequence: $CharSequence, replacement: string): string;
        countIn(sequence: $CharSequence): number;
        equals(arg0: unknown): boolean;
        indexIn(sequence: $CharSequence, start: number): number;
        indexIn(sequence: $CharSequence): number;
        lastIndexIn(sequence: $CharSequence): number;
        matchesAllOf(sequence: $CharSequence): boolean;
        matchesAnyOf(sequence: $CharSequence): boolean;
        matchesNoneOf(sequence: $CharSequence): boolean;
        matches(c: string): boolean;
        negate(): $CharMatcher;
        or(other: $CharMatcher): $CharMatcher;
        or(arg0: $NekoImport$Predicate_<string, string, boolean>): $NekoImport$Predicate<string>;
        precomputed(): $CharMatcher;
        removeFrom(sequence: $CharSequence): string;
        replaceFrom(sequence: $CharSequence, replacement: string): string;
        replaceFrom(sequence: $CharSequence, replacement: $CharSequence): string;
        retainFrom(sequence: $CharSequence): string;
        test(character: string): boolean;
        toString(): string;
        trimAndCollapseFrom(sequence: $CharSequence, replacement: string): string;
        trimFrom(sequence: $CharSequence): string;
        trimLeadingFrom(sequence: $CharSequence): string;
        trimTrailingFrom(sequence: $CharSequence): string;
    }

    export type $Predicate_<Host0 = any, CallbackArg0 = Host0, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($Predicate<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
