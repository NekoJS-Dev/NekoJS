import { $MinecraftSessionService } from "java:com/mojang/authlib/minecraft";
import { $PropertyMap } from "java:com/mojang/authlib/properties";
import { $NameAndId } from "java:com/mojang/authlib/yggdrasil/response";
import { $Enum, $Exception, $Record } from "java:java/lang";
import { $Proxy, $URL } from "java:java/net";
import { $Map, $Optional, $UUID } from "java:java/util";

export * as properties from "java:com/mojang/authlib/properties";
export * as minecraft from "java:com/mojang/authlib/minecraft";
export * as yggdrasil from "java:com/mojang/authlib/yggdrasil";

declare module "java:com/mojang/authlib" {
    export class $GameProfile extends $Record {
        constructor(arg0: $UUID, arg1: string);
        constructor(id: $UUID, name: string, properties: $PropertyMap);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        id(): $UUID;
        name(): string;
        properties(): $PropertyMap;
        toString(): string;
    }

    export interface $GameProfileRepository {
        findProfileByName(arg0: string): $Optional<$NameAndId>;
        findProfilesByNames(arg0: string[], arg1: $ProfileLookupCallback): void;
    }

    export interface $ProfileLookupCallback {
        onProfileLookupFailed(arg0: string, arg1: $Exception): void;
        onProfileLookupSucceeded(arg0: string, arg1: $UUID): void;
    }

    export class $SignatureState {
        static INVALID: $SignatureState;
        static SIGNED: $SignatureState;
        static UNSIGNED: $SignatureState;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SignatureState[];
        static valueOf(name: string): $SignatureState;
    }
    export interface $SignatureState extends $Enum<$SignatureState> {}

    export class $Environment extends $Record {
        constructor(sessionHost: string, servicesHost: string, profilesHost: string, name: string);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        name(): string;
        profilesHost(): string;
        servicesHost(): string;
        sessionHost(): string;
        toString(): string;
    }

    export class $HttpAuthenticationService implements $AuthenticationService {
        get proxy(): $Proxy;
        getProxy(): $Proxy;
        static buildQuery(arg0: ($Map<string, unknown> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, unknown>>))): string;
        static concatenateURL(arg0: $URL, arg1: string): $URL;
        static constantURL(arg0: string): $URL;
        createMinecraftSessionService(): $MinecraftSessionService;
        createProfileRepository(): $GameProfileRepository;
    }

    export interface $AuthenticationService {
        createMinecraftSessionService(): $MinecraftSessionService;
        createProfileRepository(): $GameProfileRepository;
    }

    export type $SignatureState_ = $SignatureState | "INVALID" | "SIGNED" | "UNSIGNED";
}
