import { $Predicate as $NekoImport$Predicate, $Predicate_ as $NekoImport$Predicate_ } from "java:com/google/common/base";
import { $Serializable } from "java:java/io";
import { $Comparable, $Comparable_, $Enum, $Iterable } from "java:java/lang";
import { $AbstractCollection, $Collection, $Comparator, $Comparator_, $Iterator, $List, $ListIterator, $Map, $Map$Entry, $RandomAccess, $Set, $Spliterator } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $BinaryOperator, $BinaryOperator_, $Consumer, $Consumer_, $Function, $Function_, $IntFunction, $IntFunction_, $ObjIntConsumer, $ObjIntConsumer_, $Predicate as $NekoImport$Predicate1, $Predicate_ as $NekoImport$Predicate_1, $ToIntFunction, $ToIntFunction_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Collector, $Stream } from "java:java/util/stream";

declare module "java:com/google/common/collect" {
    export class $Range<C extends ($Comparable<any> | string | number | boolean)> implements $NekoImport$Predicate<C>, $Serializable {
        get empty(): boolean;
        isEmpty(): boolean;
        static all<C extends $Comparable<any>>(): $Range<C>;
        static atLeast<C extends $Comparable<any>>(endpoint: C): $Range<C>;
        static atMost<C extends $Comparable<any>>(endpoint: C): $Range<C>;
        static closedOpen<C extends $Comparable<any>>(lower: C, upper: C): $Range<C>;
        static closed<C extends $Comparable<any>>(lower: C, upper: C): $Range<C>;
        static downTo<C extends $Comparable<any>>(endpoint: C, boundType: $BoundType_): $Range<C>;
        static encloseAll<C extends $Comparable<any>>(values: ($Iterable<C> | (C)[])): $Range<C>;
        static greaterThan<C extends $Comparable<any>>(endpoint: C): $Range<C>;
        static lessThan<C extends $Comparable<any>>(endpoint: C): $Range<C>;
        static openClosed<C extends $Comparable<any>>(lower: C, upper: C): $Range<C>;
        static open<C extends $Comparable<any>>(lower: C, upper: C): $Range<C>;
        static range<C extends $Comparable<any>>(lower: C, lowerType: $BoundType_, upper: C, upperType: $BoundType_): $Range<C>;
        static singleton<C extends $Comparable<any>>(value: C): $Range<C>;
        static upTo<C extends $Comparable<any>>(endpoint: C, boundType: $BoundType_): $Range<C>;
        and(arg0: $NekoImport$Predicate_1<C, C, boolean>): $NekoImport$Predicate1<C>;
        apply(input: C): boolean;
        canonical(domain: $DiscreteDomain<C>): $Range<C>;
        containsAll(values: ($Iterable<C> | (C)[])): boolean;
        contains(value: C): boolean;
        encloses(other: $Range<C>): boolean;
        equals(object: unknown): boolean;
        gap(otherRange: $Range<C>): $Range<C>;
        hasLowerBound(): boolean;
        hasUpperBound(): boolean;
        hashCode(): number;
        intersection(connectedRange: $Range<C>): $Range<C>;
        isConnected(other: $Range<C>): boolean;
        lowerBoundType(): $BoundType;
        lowerEndpoint(): C;
        negate(): $NekoImport$Predicate1<C>;
        or(arg0: $NekoImport$Predicate_1<C, C, boolean>): $NekoImport$Predicate1<C>;
        span(other: $Range<C>): $Range<C>;
        test(input: C): boolean;
        toString(): string;
        upperBoundType(): $BoundType;
        upperEndpoint(): C;
    }

    export class $BoundType {
        static CLOSED: $BoundType;
        static OPEN: $BoundType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BoundType[];
        static valueOf(name: string): $BoundType;
    }
    export interface $BoundType extends $Enum<$BoundType> {}

    export class $DiscreteDomain<C extends ($Comparable<any> | string | number | boolean)> {
        static bigIntegers(): $DiscreteDomain<number>;
        static integers(): $DiscreteDomain<number>;
        static longs(): $DiscreteDomain<number>;
        distance(start: C, end: C): number;
        maxValue(): C;
        minValue(): C;
        next(value: C): C;
        previous(value: C): C;
    }

    export class $ForwardingMultimap<K, V> extends $ForwardingObject implements $Multimap<K, V> {
        get empty(): boolean;
        isEmpty(): boolean;
        asMap(): $Map<K, $Collection<V>>;
        clear(): void;
        containsEntry(key: unknown, value: unknown): boolean;
        containsKey(key: unknown): boolean;
        containsValue(value: unknown): boolean;
        entries(): $Collection<$Map$Entry<K, V>>;
        equals(object: unknown): boolean;
        forEach(action: $BiConsumer_<K, V, K, V>): void;
        get(key: K): $Collection<V>;
        hashCode(): number;
        keySet(): $Set<K>;
        keys(): $Multiset<K>;
        putAll(key: K, values: ($Iterable<V> | (V)[])): boolean;
        putAll(multimap: $Multimap<K, V>): boolean;
        put(key: K, value: V): boolean;
        removeAll(key: unknown): $Collection<V>;
        remove(key: unknown, value: unknown): boolean;
        replaceValues(key: K, values: ($Iterable<V> | (V)[])): $Collection<V>;
        size(): number;
        values(): $Collection<V>;
    }

    export interface $Multimap<K, V> {
        asMap(): $Map<K, $Collection<V>>;
        clear(): void;
        containsEntry(key: unknown, value: unknown): boolean;
        containsKey(key: unknown): boolean;
        containsValue(value: unknown): boolean;
        entries(): $Collection<$Map$Entry<K, V>>;
        equals(obj: unknown): boolean;
        forEach(action: $BiConsumer_<K, V, K, V>): void;
        get(key: K): $Collection<V>;
        hashCode(): number;
        isEmpty(): boolean;
        keySet(): $Set<K>;
        keys(): $Multiset<K>;
        putAll(key: K, values: ($Iterable<V> | (V)[])): boolean;
        putAll(multimap: $Multimap<K, V>): boolean;
        put(key: K, value: V): boolean;
        removeAll(key: unknown): $Collection<V>;
        remove(key: unknown, value: unknown): boolean;
        replaceValues(key: K, values: ($Iterable<V> | (V)[])): $Collection<V>;
        size(): number;
        values(): $Collection<V>;
    }

    export class $ForwardingObject {
        toString(): string;
    }

    export interface $Multiset<E> extends $Collection<E> {
        add(element: E, occurrences: number): number;
        add(element: E): boolean;
        containsAll(elements: ($Collection<any> | (any)[])): boolean;
        contains(element: unknown): boolean;
        count(element: unknown): number;
        elementSet(): $Set<E>;
        entrySet(): $Set<$Multiset$Entry<E>>;
        equals(object: unknown): boolean;
        forEachEntry(action: $ObjIntConsumer_<E, E, number>): void;
        forEach(action: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $Iterator<E>;
        removeAll(c: ($Collection<any> | (any)[])): boolean;
        remove(element: unknown, occurrences: number): number;
        remove(element: unknown): boolean;
        retainAll(c: ($Collection<any> | (any)[])): boolean;
        setCount(element: E, oldCount: number, newCount: number): boolean;
        setCount(element: E, count: number): number;
        size(): number;
        spliterator(): $Spliterator<E>;
        toString(): string;
    }

    export interface $Multiset$Entry<E> {
        equals(o: unknown): boolean;
        getCount(): number;
        getElement(): E;
        hashCode(): number;
        toString(): string;
    }

    export class $ImmutableList<E> extends $ImmutableCollection<E> implements $List<E>, $RandomAccess {
        get first(): E;
        getFirst(): E;
        get last(): E;
        getLast(): E;
        get empty(): boolean;
        isEmpty(): boolean;
        static builderWithExpectedSize<E>(expectedSize: number): $ImmutableList$Builder<E>;
        static builder<E>(): $ImmutableList$Builder<E>;
        static copyOf<E>(elements: E[]): $ImmutableList<E>;
        static copyOf<E>(elements: ($Iterable<E> | (E)[])): $ImmutableList<E>;
        static copyOf<E>(elements: ($Collection<E> | (E)[])): $ImmutableList<E>;
        static copyOf<E>(elements: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E, e9: E, e10: E, e11: E, e12: E, others?: E[]): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E, e9: E, e10: E, e11: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E, e9: E, e10: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E, e9: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E): $ImmutableList<E>;
        static of<E>(e1: E): $ImmutableList<E>;
        static of<E>(): $ImmutableList<E>;
        static sortedCopyOf<E extends $Comparable<any>>(elements: ($Iterable<E> | (E)[])): $ImmutableList<E>;
        static sortedCopyOf<E>(comparator: $Comparator_<E, E, E, number>, elements: ($Iterable<E> | (E)[])): $ImmutableList<E>;
        static toImmutableList<E>(): $Collector<E, any, $ImmutableList<E>>;
        addAll(index: number, newElements: ($Collection<E> | (E)[])): boolean;
        addAll(newElements: ($Collection<E> | (E)[])): boolean;
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        add(e: E): boolean;
        add(index: number, element: E): void;
        asList(): $ImmutableList<E>;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(object: unknown): boolean;
        equals(obj: unknown): boolean;
        forEach(consumer: $Consumer_<E, E>): void;
        get(arg0: number): E;
        hashCode(): number;
        indexOf(object: unknown): number;
        iterator(): $UnmodifiableIterator<E>;
        lastIndexOf(object: unknown): number;
        listIterator(index: number): $UnmodifiableListIterator<E>;
        listIterator(): $UnmodifiableListIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(oldElements: ($Collection<any> | (any)[])): boolean;
        removeFirst(): E;
        removeIf(filter: $NekoImport$Predicate_1<E, E, boolean>): boolean;
        removeLast(): E;
        remove(index: number): E;
        remove(object: unknown): boolean;
        replaceAll(operator: $UnaryOperator_<E, E, E>): void;
        retainAll(elementsToKeep: ($Collection<any> | (any)[])): boolean;
        reversed(): $List<E>;
        reverse(): $ImmutableList<E>;
        set(index: number, element: E): E;
        size(): number;
        sort(c: $Comparator_<E, E, E, number>): void;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        subList(fromIndex: number, toIndex: number): $ImmutableList<E>;
        toArray<T>(other: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export class $ImmutableCollection<E> extends $AbstractCollection<E> implements $Serializable {
        addAll(newElements: ($Collection<E> | (E)[])): boolean;
        add(e: E): boolean;
        asList(): $ImmutableList<E>;
        clear(): void;
        contains(object: unknown): boolean;
        equals(arg0: unknown): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $UnmodifiableIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(oldElements: ($Collection<any> | (any)[])): boolean;
        removeIf(filter: $NekoImport$Predicate_1<E, E, boolean>): boolean;
        remove(object: unknown): boolean;
        retainAll(elementsToKeep: ($Collection<any> | (any)[])): boolean;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(other: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export class $ImmutableList$Builder<E> extends $ImmutableCollection$Builder<E> {
        constructor();
        addAll(elements: ($Iterable<E> | (E)[])): $ImmutableList$Builder<E>;
        addAll(elements: E): $ImmutableList$Builder<E>;
        add(elements?: E[]): $ImmutableList$Builder<E>;
        add(element: E): $ImmutableList$Builder<E>;
        build(): $ImmutableList<E>;
    }

    export class $UnmodifiableIterator<E> implements $Iterator<E> {
        forEachRemaining(arg0: $Consumer_<E, E>): void;
        hasNext(): boolean;
        next(): E;
        remove(): void;
    }

    export class $UnmodifiableListIterator<E> extends $UnmodifiableIterator<E> implements $ListIterator<E> {
        add(e: E): void;
        forEachRemaining(arg0: $Consumer_<E, E>): void;
        hasNext(): boolean;
        hasPrevious(): boolean;
        nextIndex(): number;
        next(): E;
        previousIndex(): number;
        previous(): E;
        remove(): void;
        set(e: E): void;
    }

    export class $ImmutableCollection$Builder<E> {
        addAll(elements: ($Iterable<E> | (E)[])): $ImmutableCollection$Builder<E>;
        addAll(elements: E): $ImmutableCollection$Builder<E>;
        add(elements?: E[]): $ImmutableCollection$Builder<E>;
        add(element: E): $ImmutableCollection$Builder<E>;
        build(): $ImmutableCollection<E>;
    }

    export class $ForwardingSet<E> extends $ForwardingCollection<E> implements $Set<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(collection: ($Collection<E> | (E)[])): boolean;
        add(element: E): boolean;
        clear(): void;
        containsAll(collection: ($Collection<any> | (any)[])): boolean;
        contains(object: unknown): boolean;
        equals(object: unknown): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(collection: ($Collection<any> | (any)[])): boolean;
        removeIf(arg0: $NekoImport$Predicate_1<E, E, boolean>): boolean;
        remove(object: unknown): boolean;
        retainAll(collection: ($Collection<any> | (any)[])): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(array: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export class $ForwardingCollection<E> extends $ForwardingObject implements $Collection<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(collection: ($Collection<E> | (E)[])): boolean;
        add(element: E): boolean;
        clear(): void;
        containsAll(collection: ($Collection<any> | (any)[])): boolean;
        contains(object: unknown): boolean;
        equals(arg0: unknown): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(collection: ($Collection<any> | (any)[])): boolean;
        removeIf(arg0: $NekoImport$Predicate_1<E, E, boolean>): boolean;
        remove(object: unknown): boolean;
        retainAll(collection: ($Collection<any> | (any)[])): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(array: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export class $ImmutableSet<E> extends $ImmutableCollection<E> implements $Set<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        static builderWithExpectedSize<E>(expectedSize: number): $ImmutableSet$Builder<E>;
        static builder<E>(): $ImmutableSet$Builder<E>;
        static copyOf<E>(elements: E[]): $ImmutableSet<E>;
        static copyOf<E>(elements: ($Iterable<E> | (E)[])): $ImmutableSet<E>;
        static copyOf<E>(elements: ($Collection<E> | (E)[])): $ImmutableSet<E>;
        static copyOf<E>(elements: E): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, others?: E[]): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E, e3: E): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E): $ImmutableSet<E>;
        static of<E>(e1: E): $ImmutableSet<E>;
        static of<E>(): $ImmutableSet<E>;
        static toImmutableSet<E>(): $Collector<E, any, $ImmutableSet<E>>;
        addAll(newElements: ($Collection<E> | (E)[])): boolean;
        add(e: E): boolean;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(object: unknown): boolean;
        equals(object: unknown): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $UnmodifiableIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(oldElements: ($Collection<any> | (any)[])): boolean;
        removeIf(filter: $NekoImport$Predicate_1<E, E, boolean>): boolean;
        remove(object: unknown): boolean;
        retainAll(elementsToKeep: ($Collection<any> | (any)[])): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(other: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export class $ImmutableSet$Builder<E> extends $ImmutableCollection$Builder<E> {
        constructor();
        addAll(elements: ($Iterable<E> | (E)[])): $ImmutableSet$Builder<E>;
        addAll(elements: E): $ImmutableSet$Builder<E>;
        add(elements?: E[]): $ImmutableSet$Builder<E>;
        add(element: E): $ImmutableSet$Builder<E>;
        build(): $ImmutableSet<E>;
    }

    export class $ImmutableMap$Builder<K, V> {
        constructor();
        buildKeepingLast(): $ImmutableMap<K, V>;
        buildOrThrow(): $ImmutableMap<K, V>;
        build(): $ImmutableMap<K, V>;
        orderEntriesByValue(valueComparator: $Comparator_<V, V, V, number>): $ImmutableMap$Builder<K, V>;
        putAll(entries: ($Iterable<$Map$Entry<K, V>> | ($Map$Entry<K, V>)[])): $ImmutableMap$Builder<K, V>;
        putAll(map: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): $ImmutableMap$Builder<K, V>;
        put(key: K, value: V): $ImmutableMap$Builder<K, V>;
        put(entry: $Map$Entry<K, V>): $ImmutableMap$Builder<K, V>;
    }

    export class $ImmutableMap<K, V> implements $Map<K, V>, $Serializable {
        get empty(): boolean;
        isEmpty(): boolean;
        static builderWithExpectedSize<K, V>(expectedSize: number): $ImmutableMap$Builder<K, V>;
        static builder<K, V>(): $ImmutableMap$Builder<K, V>;
        static copyOf<K, V>(entries: ($Iterable<$Map$Entry<K, V>> | ($Map$Entry<K, V>)[])): $ImmutableMap<K, V>;
        static copyOf<K, V>(map: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): $ImmutableMap<K, V>;
        static ofEntries<K, V>(entries?: $Map$Entry<K, V>[]): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V, k7: K, v7: V, k8: K, v8: V, k9: K, v9: V, k10: K, v10: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V, k7: K, v7: V, k8: K, v8: V, k9: K, v9: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V, k7: K, v7: V, k8: K, v8: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V, k7: K, v7: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V): $ImmutableMap<K, V>;
        static of<K, V>(k1: K, v1: V): $ImmutableMap<K, V>;
        static of<K, V>(): $ImmutableMap<K, V>;
        static toImmutableMap<T, K, V>(keyFunction: $Function_<T, K, T, K>, valueFunction: $Function_<T, V, T, V>, mergeFunction: $BinaryOperator_<V, V, V, V>): $Collector<T, any, $ImmutableMap<K, V>>;
        static toImmutableMap<T, K, V>(keyFunction: $Function_<T, K, T, K>, valueFunction: $Function_<T, V, T, V>): $Collector<T, any, $ImmutableMap<K, V>>;
        asMultimap(): $ImmutableSetMultimap<K, V>;
        clear(): void;
        computeIfAbsent(key: K, mappingFunction: $Function_<K, V, K, V>): V;
        computeIfPresent(key: K, remappingFunction: $BiFunction_<K, V, V, K, V, V>): V;
        compute(key: K, remappingFunction: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(key: unknown): boolean;
        containsValue(value: unknown): boolean;
        entrySet(): $ImmutableSet<$Map$Entry<K, V>>;
        equals(object: unknown): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(key: unknown, defaultValue: V): V;
        get(key: unknown): V;
        hashCode(): number;
        keySet(): $ImmutableSet<K>;
        merge(key: K, value: V, function_: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(map: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): void;
        putIfAbsent(key: K, value: V): V;
        put(k: K, v: V): V;
        remove(key: unknown, value: unknown): boolean;
        remove(o: unknown): V;
        replaceAll(function_: $BiFunction_<K, V, V, K, V, V>): void;
        replace(key: K, oldValue: V, newValue: V): boolean;
        replace(key: K, value: V): V;
        size(): number;
        toString(): string;
        values(): $ImmutableCollection<V>;
    }

    export class $ImmutableSetMultimap<K, V> extends $ImmutableMultimap<K, V> implements $SetMultimap<K, V> {
        static builderWithExpectedKeys<K1, V1>(expectedKeys: number): $ImmutableMultimap$Builder<K1, V1>;
        static builderWithExpectedKeys<K, V>(expectedKeys: number): $ImmutableSetMultimap$Builder<K, V>;
        static builder<K1, V1>(): $ImmutableMultimap$Builder<K1, V1>;
        static builder<K, V>(): $ImmutableSetMultimap$Builder<K, V>;
        static copyOf<K, V>(multimap: $Multimap<K, V>): $ImmutableSetMultimap<K, V>;
        static copyOf<K1, V1>(multimap: $Multimap<K1, V1>): $ImmutableMultimap<K1, V1>;
        static copyOf<K, V>(entries: ($Iterable<$Map$Entry<K, V>> | ($Map$Entry<K, V>)[])): $ImmutableSetMultimap<K, V>;
        static copyOf<K1, V1>(entries: ($Iterable<$Map$Entry<K1, V1>> | ($Map$Entry<K1, V1>)[])): $ImmutableMultimap<K1, V1>;
        static flatteningToImmutableSetMultimap<T, K, V>(keyFunction: $Function_<T, K, T, K>, valuesFunction: $Function_<T, $Stream<V>, T, $Stream<V>>): $Collector<T, any, $ImmutableSetMultimap<K, V>>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1, k5: K1, v5: V1): $ImmutableMultimap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1): $ImmutableMultimap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1): $ImmutableMultimap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1): $ImmutableMultimap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1): $ImmutableMultimap<K1, V1>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V): $ImmutableSetMultimap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V): $ImmutableSetMultimap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V): $ImmutableSetMultimap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V): $ImmutableSetMultimap<K, V>;
        static of<K, V>(k1: K, v1: V): $ImmutableSetMultimap<K, V>;
        static of<K1, V1>(): $ImmutableMultimap<K1, V1>;
        static of<K, V>(): $ImmutableSetMultimap<K, V>;
        static toImmutableSetMultimap<T, K, V>(keyFunction: $Function_<T, K, T, K>, valueFunction: $Function_<T, V, T, V>): $Collector<T, any, $ImmutableSetMultimap<K, V>>;
        asMap(): $ImmutableMap<K, $Collection<V>>;
        clear(): void;
        containsKey(key: unknown): boolean;
        containsValue(value: unknown): boolean;
        entries(): $ImmutableSet<$Map$Entry<K, V>>;
        forEach(action: $BiConsumer_<K, V, K, V>): void;
        get(key: K): $ImmutableSet<V>;
        inverse(): $ImmutableSetMultimap<V, K>;
        keySet(): $ImmutableSet<K>;
        keys(): $ImmutableMultiset<K>;
        putAll(key: K, values: ($Iterable<V> | (V)[])): boolean;
        putAll(multimap: $Multimap<K, V>): boolean;
        put(key: K, value: V): boolean;
        removeAll(key: unknown): $ImmutableSet<V>;
        remove(key: unknown, value: unknown): boolean;
        replaceValues(key: K, values: ($Iterable<V> | (V)[])): $ImmutableSet<V>;
        size(): number;
        values(): $ImmutableCollection<V>;
    }

    export class $ImmutableMultimap<K, V> extends $BaseImmutableMultimap<K, V> implements $Serializable {
        static builderWithExpectedKeys<K, V>(expectedKeys: number): $ImmutableMultimap$Builder<K, V>;
        static builder<K, V>(): $ImmutableMultimap$Builder<K, V>;
        static copyOf<K, V>(multimap: $Multimap<K, V>): $ImmutableMultimap<K, V>;
        static copyOf<K, V>(entries: ($Iterable<$Map$Entry<K, V>> | ($Map$Entry<K, V>)[])): $ImmutableMultimap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V): $ImmutableMultimap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V): $ImmutableMultimap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V): $ImmutableMultimap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V): $ImmutableMultimap<K, V>;
        static of<K, V>(k1: K, v1: V): $ImmutableMultimap<K, V>;
        static of<K, V>(): $ImmutableMultimap<K, V>;
        asMap(): $ImmutableMap<K, $Collection<V>>;
        clear(): void;
        containsKey(key: unknown): boolean;
        containsValue(value: unknown): boolean;
        entries(): $ImmutableCollection<$Map$Entry<K, V>>;
        forEach(action: $BiConsumer_<K, V, K, V>): void;
        get(key: K): $ImmutableCollection<V>;
        inverse(): $ImmutableMultimap<V, K>;
        keySet(): $ImmutableSet<K>;
        keys(): $ImmutableMultiset<K>;
        putAll(key: K, values: ($Iterable<V> | (V)[])): boolean;
        putAll(multimap: $Multimap<K, V>): boolean;
        put(key: K, value: V): boolean;
        removeAll(key: unknown): $ImmutableCollection<V>;
        remove(key: unknown, value: unknown): boolean;
        replaceValues(key: K, values: ($Iterable<V> | (V)[])): $ImmutableCollection<V>;
        size(): number;
        values(): $ImmutableCollection<V>;
    }

    export class $ImmutableMultimap$Builder<K, V> {
        constructor();
        build(): $ImmutableMultimap<K, V>;
        expectedValuesPerKey(expectedValuesPerKey: number): $ImmutableMultimap$Builder<K, V>;
        orderKeysBy(keyComparator: $Comparator_<K, K, K, number>): $ImmutableMultimap$Builder<K, V>;
        orderValuesBy(valueComparator: $Comparator_<V, V, V, number>): $ImmutableMultimap$Builder<K, V>;
        putAll(key: K, values?: V[]): $ImmutableMultimap$Builder<K, V>;
        putAll(key: K, values: ($Iterable<V> | (V)[])): $ImmutableMultimap$Builder<K, V>;
        putAll(multimap: $Multimap<K, V>): $ImmutableMultimap$Builder<K, V>;
        putAll(entries: ($Iterable<$Map$Entry<K, V>> | ($Map$Entry<K, V>)[])): $ImmutableMultimap$Builder<K, V>;
        put(key: K, value: V): $ImmutableMultimap$Builder<K, V>;
        put(entry: $Map$Entry<K, V>): $ImmutableMultimap$Builder<K, V>;
    }

    export class $ImmutableMultiset<E> extends $ImmutableCollection<E> implements $Multiset<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        static builder<E>(): $ImmutableMultiset$Builder<E>;
        static copyOf<E>(elements: E[]): $ImmutableMultiset<E>;
        static copyOf<E>(elements: ($Iterable<E> | (E)[])): $ImmutableMultiset<E>;
        static copyOf<E>(elements: E): $ImmutableMultiset<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, others?: E[]): $ImmutableMultiset<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E): $ImmutableMultiset<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E): $ImmutableMultiset<E>;
        static of<E>(e1: E, e2: E, e3: E): $ImmutableMultiset<E>;
        static of<E>(e1: E, e2: E): $ImmutableMultiset<E>;
        static of<E>(e1: E): $ImmutableMultiset<E>;
        static of<E>(): $ImmutableMultiset<E>;
        static toImmutableMultiset<T, E>(elementFunction: $Function_<T, E, T, E>, countFunction: $ToIntFunction_<T, T, number>): $Collector<T, any, $ImmutableMultiset<E>>;
        static toImmutableMultiset<E>(): $Collector<E, any, $ImmutableMultiset<E>>;
        addAll(newElements: ($Collection<E> | (E)[])): boolean;
        add(element: E, occurrences: number): number;
        add(e: E): boolean;
        asList(): $ImmutableList<E>;
        clear(): void;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(object: unknown): boolean;
        count(element: unknown): number;
        elementSet(): $ImmutableSet<E>;
        entrySet(): $ImmutableSet<$Multiset$Entry<E>>;
        equals(object: unknown): boolean;
        forEachEntry(action: $ObjIntConsumer_<E, E, number>): void;
        forEach(action: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $UnmodifiableIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(oldElements: ($Collection<any> | (any)[])): boolean;
        removeIf(filter: $NekoImport$Predicate_1<E, E, boolean>): boolean;
        remove(element: unknown, occurrences: number): number;
        remove(object: unknown): boolean;
        retainAll(elementsToKeep: ($Collection<any> | (any)[])): boolean;
        setCount(element: E, oldCount: number, newCount: number): boolean;
        setCount(element: E, count: number): number;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(other: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
        toString(): string;
    }

    export class $ImmutableSetMultimap$Builder<K, V> extends $ImmutableMultimap$Builder<K, V> {
        constructor();
        build(): $ImmutableSetMultimap<K, V>;
        expectedValuesPerKey(expectedValuesPerKey: number): $ImmutableSetMultimap$Builder<K, V>;
        orderKeysBy(keyComparator: $Comparator_<K, K, K, number>): $ImmutableSetMultimap$Builder<K, V>;
        orderValuesBy(valueComparator: $Comparator_<V, V, V, number>): $ImmutableSetMultimap$Builder<K, V>;
        putAll(key: K, values?: V[]): $ImmutableSetMultimap$Builder<K, V>;
        putAll(key: K, values: ($Iterable<V> | (V)[])): $ImmutableSetMultimap$Builder<K, V>;
        putAll(multimap: $Multimap<K, V>): $ImmutableSetMultimap$Builder<K, V>;
        putAll(entries: ($Iterable<$Map$Entry<K, V>> | ($Map$Entry<K, V>)[])): $ImmutableSetMultimap$Builder<K, V>;
        put(key: K, value: V): $ImmutableSetMultimap$Builder<K, V>;
        put(entry: $Map$Entry<K, V>): $ImmutableSetMultimap$Builder<K, V>;
    }

    export interface $SetMultimap<K, V> extends $Multimap<K, V> {
        asMap(): $Map<K, $Collection<V>>;
        entries(): $Set<$Map$Entry<K, V>>;
        equals(obj: unknown): boolean;
        get(key: K): $Set<V>;
        removeAll(key: unknown): $Set<V>;
        replaceValues(key: K, values: ($Iterable<V> | (V)[])): $Set<V>;
    }

    export class $BaseImmutableMultimap<K, V> extends $AbstractMultimap<K, V> {
        clear(): void;
        containsKey(key: unknown): boolean;
        equals(object: unknown): boolean;
        forEach(action: $BiConsumer_<K, V, K, V>): void;
        get(key: K): $Collection<V>;
        hashCode(): number;
        removeAll(key: unknown): $Collection<V>;
        size(): number;
    }

    export class $AbstractMultimap<K, V> implements $Multimap<K, V> {
        get empty(): boolean;
        isEmpty(): boolean;
        asMap(): $Map<K, $Collection<V>>;
        clear(): void;
        containsEntry(key: unknown, value: unknown): boolean;
        containsKey(key: unknown): boolean;
        containsValue(value: unknown): boolean;
        entries(): $Collection<$Map$Entry<K, V>>;
        equals(object: unknown): boolean;
        forEach(action: $BiConsumer_<K, V, K, V>): void;
        get(key: K): $Collection<V>;
        hashCode(): number;
        keySet(): $Set<K>;
        keys(): $Multiset<K>;
        putAll(key: K, values: ($Iterable<V> | (V)[])): boolean;
        putAll(multimap: $Multimap<K, V>): boolean;
        put(key: K, value: V): boolean;
        removeAll(key: unknown): $Collection<V>;
        remove(key: unknown, value: unknown): boolean;
        replaceValues(key: K, values: ($Iterable<V> | (V)[])): $Collection<V>;
        size(): number;
        toString(): string;
        values(): $Collection<V>;
    }

    export class $ImmutableMultiset$Builder<E> extends $ImmutableCollection$Builder<E> {
        constructor();
        addAll(elements: ($Iterable<E> | (E)[])): $ImmutableMultiset$Builder<E>;
        addAll(elements: E): $ImmutableMultiset$Builder<E>;
        addCopies(element: E, occurrences: number): $ImmutableMultiset$Builder<E>;
        add(elements?: E[]): $ImmutableMultiset$Builder<E>;
        add(element: E): $ImmutableMultiset$Builder<E>;
        build(): $ImmutableMultiset<E>;
        setCount(element: E, count: number): $ImmutableMultiset$Builder<E>;
    }

    export class $ImmutableBiMap<K, V> extends $ImmutableMap<K, V> implements $BiMap<K, V> {
        get empty(): boolean;
        isEmpty(): boolean;
        static builderWithExpectedSize<K, V>(expectedSize: number): $ImmutableBiMap$Builder<K, V>;
        static builderWithExpectedSize<K1, V1>(expectedSize: number): $ImmutableMap$Builder<K1, V1>;
        static builder<K, V>(): $ImmutableBiMap$Builder<K, V>;
        static builder<K1, V1>(): $ImmutableMap$Builder<K1, V1>;
        static copyOf<K, V>(entries: ($Iterable<$Map$Entry<K, V>> | ($Map$Entry<K, V>)[])): $ImmutableBiMap<K, V>;
        static copyOf<K1, V1>(entries: ($Iterable<$Map$Entry<K1, V1>> | ($Map$Entry<K1, V1>)[])): $ImmutableMap<K1, V1>;
        static copyOf<K, V>(map: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): $ImmutableBiMap<K, V>;
        static copyOf<K1, V1>(map: ($Map<K1, V1> | (([K1] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K1, PropertyKey>, V1>>))): $ImmutableMap<K1, V1>;
        static ofEntries<K, V>(entries?: $Map$Entry<K, V>[]): $ImmutableBiMap<K, V>;
        static ofEntries<K1, V1>(entries?: $Map$Entry<K1, V1>[]): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1, k5: K1, v5: V1, k6: K1, v6: V1, k7: K1, v7: V1, k8: K1, v8: V1, k9: K1, v9: V1, k10: K1, v10: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1, k5: K1, v5: V1, k6: K1, v6: V1, k7: K1, v7: V1, k8: K1, v8: V1, k9: K1, v9: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1, k5: K1, v5: V1, k6: K1, v6: V1, k7: K1, v7: V1, k8: K1, v8: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1, k5: K1, v5: V1, k6: K1, v6: V1, k7: K1, v7: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1, k5: K1, v5: V1, k6: K1, v6: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1, k5: K1, v5: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1, k4: K1, v4: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1, k3: K1, v3: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1, k2: K1, v2: V1): $ImmutableMap<K1, V1>;
        static of<K1, V1>(k1: K1, v1: V1): $ImmutableMap<K1, V1>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V, k7: K, v7: V, k8: K, v8: V, k9: K, v9: V, k10: K, v10: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V, k7: K, v7: V, k8: K, v8: V, k9: K, v9: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V, k7: K, v7: V, k8: K, v8: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V, k7: K, v7: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V, k6: K, v6: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V, k5: K, v5: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V, k4: K, v4: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V, k3: K, v3: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V, k2: K, v2: V): $ImmutableBiMap<K, V>;
        static of<K, V>(k1: K, v1: V): $ImmutableBiMap<K, V>;
        static of<K, V>(): $ImmutableBiMap<K, V>;
        static of<K1, V1>(): $ImmutableMap<K1, V1>;
        static toImmutableBiMap<T, K, V>(keyFunction: $Function_<T, K, T, K>, valueFunction: $Function_<T, V, T, V>): $Collector<T, any, $ImmutableBiMap<K, V>>;
        static toImmutableMap<T, K, V>(keyFunction: $Function_<T, K, T, K>, valueFunction: $Function_<T, V, T, V>, mergeFunction: $BinaryOperator_<V, V, V, V>): $Collector<T, any, $ImmutableMap<K, V>>;
        static toImmutableMap<T, K, V>(keyFunction: $Function_<T, K, T, K>, valueFunction: $Function_<T, V, T, V>): $Collector<T, any, $ImmutableMap<K, V>>;
        clear(): void;
        computeIfAbsent(key: K, mappingFunction: $Function_<K, V, K, V>): V;
        computeIfPresent(key: K, remappingFunction: $BiFunction_<K, V, V, K, V, V>): V;
        compute(key: K, remappingFunction: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(key: unknown): boolean;
        containsValue(value: unknown): boolean;
        entrySet(): $ImmutableSet<$Map$Entry<K, V>>;
        equals(object: unknown): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        forcePut(key: K, value: V): V;
        getOrDefault(key: unknown, defaultValue: V): V;
        get(key: unknown): V;
        hashCode(): number;
        inverse(): $ImmutableBiMap<V, K>;
        keySet(): $ImmutableSet<K>;
        merge(key: K, value: V, function_: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(map: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): void;
        putIfAbsent(key: K, value: V): V;
        put(k: K, v: V): V;
        remove(key: unknown, value: unknown): boolean;
        remove(o: unknown): V;
        replaceAll(function_: $BiFunction_<K, V, V, K, V, V>): void;
        replace(key: K, oldValue: V, newValue: V): boolean;
        replace(key: K, value: V): V;
        size(): number;
        values(): $ImmutableSet<V>;
    }

    export interface $BiMap<K, V> extends $Map<K, V> {
        forcePut(key: K, value: V): V;
        inverse(): $BiMap<V, K>;
        putAll(map: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): void;
        put(key: K, value: V): V;
        values(): $Set<V>;
    }

    export class $ImmutableBiMap$Builder<K, V> extends $ImmutableMap$Builder<K, V> {
        constructor();
        buildKeepingLast(): $ImmutableBiMap<K, V>;
        buildOrThrow(): $ImmutableBiMap<K, V>;
        build(): $ImmutableBiMap<K, V>;
        orderEntriesByValue(valueComparator: $Comparator_<V, V, V, number>): $ImmutableBiMap$Builder<K, V>;
        putAll(entries: ($Iterable<$Map$Entry<K, V>> | ($Map$Entry<K, V>)[])): $ImmutableBiMap$Builder<K, V>;
        putAll(map: ($Map<K, V> | (([K] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<K, PropertyKey>, V>>))): $ImmutableBiMap$Builder<K, V>;
        put(key: K, value: V): $ImmutableBiMap$Builder<K, V>;
        put(entry: $Map$Entry<K, V>): $ImmutableBiMap$Builder<K, V>;
    }

    export type $BoundType_ = $BoundType | "CLOSED" | "OPEN";
}
