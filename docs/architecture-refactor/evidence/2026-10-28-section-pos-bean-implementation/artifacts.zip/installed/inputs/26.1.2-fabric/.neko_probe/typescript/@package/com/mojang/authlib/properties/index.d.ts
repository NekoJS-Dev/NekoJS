import { $ForwardingMultimap, $Multimap } from "java:com/google/common/collect";
import { $Record } from "java:java/lang";
import { $PublicKey } from "java:java/security";
import { $BiConsumer, $BiConsumer_ } from "java:java/util/function";

declare module "java:com/mojang/authlib/properties" {
    export class $PropertyMap extends $ForwardingMultimap<string, $Property> {
        constructor(arg0: $Multimap<string, $Property>);
        static EMPTY: $PropertyMap;
        equals(object: unknown): boolean;
        forEach(action: $BiConsumer_<string, $Property, string, $Property>): void;
        hashCode(): number;
    }

    export class $Property extends $Record {
        constructor(arg0: string, arg1: string);
        constructor(name: string, value: string, signature: string);
        equals(arg0: unknown): boolean;
        hasSignature(): boolean;
        hashCode(): number;
        isSignatureValid(arg0: $PublicKey): boolean;
        name(): string;
        signature(): string;
        toString(): string;
        value(): string;
    }

}
