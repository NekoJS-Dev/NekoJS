export * as injector from "java:com/llamalad7/mixinextras/injector";
export * as sugar from "java:com/llamalad7/mixinextras/sugar";

