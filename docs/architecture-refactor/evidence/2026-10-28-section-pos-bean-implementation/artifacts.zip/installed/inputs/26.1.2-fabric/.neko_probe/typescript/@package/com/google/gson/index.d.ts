import { $Iterable } from "java:java/lang";
import { $Iterator, $List, $Map, $Map$Entry, $Set, $Spliterator } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";

declare module "java:com/google/gson" {
    export class $JsonObject extends $JsonElement {
        constructor();
        get asJsonArray(): $JsonArray;
        getAsJsonArray(): $JsonArray;
        get asJsonObject(): $JsonObject;
        getAsJsonObject(): $JsonObject;
        get asJsonPrimitive(): $JsonPrimitive;
        getAsJsonPrimitive(): $JsonPrimitive;
        get empty(): boolean;
        isEmpty(): boolean;
        addProperty(arg0: string, arg1: boolean): void;
        addProperty(arg0: string, arg1: string): void;
        addProperty(arg0: string, arg1: number): void;
        addProperty(arg0: string, arg1: string): void;
        add(arg0: string, arg1: $JsonElement): void;
        asMap(): $Map<string, $JsonElement>;
        deepCopy(): $JsonObject;
        entrySet(): $Set<$Map$Entry<string, $JsonElement>>;
        equals(arg0: unknown): boolean;
        getAsJsonArray(arg0: string): $JsonArray;
        getAsJsonObject(arg0: string): $JsonObject;
        getAsJsonPrimitive(arg0: string): $JsonPrimitive;
        get(arg0: string): $JsonElement;
        hashCode(): number;
        has(arg0: string): boolean;
        keySet(): $Set<string>;
        remove(arg0: string): $JsonElement;
        size(): number;
    }

    export class $JsonArray extends $JsonElement implements $Iterable<$JsonElement> {
        constructor();
        constructor(arg0: number);
        get asBigDecimal(): number;
        getAsBigDecimal(): number;
        get asBigInteger(): number;
        getAsBigInteger(): number;
        get asBoolean(): boolean;
        getAsBoolean(): boolean;
        get asByte(): number;
        getAsByte(): number;
        get asCharacter(): string;
        getAsCharacter(): string;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get asString(): string;
        getAsString(): string;
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(arg0: $JsonArray): void;
        add(arg0: $JsonElement): void;
        add(arg0: boolean): void;
        add(arg0: string): void;
        add(arg0: number): void;
        add(arg0: string): void;
        asList(): $List<$JsonElement>;
        contains(arg0: $JsonElement): boolean;
        deepCopy(): $JsonArray;
        equals(arg0: unknown): boolean;
        forEach(arg0: $Consumer_<$JsonElement, $JsonElement>): void;
        get(arg0: number): $JsonElement;
        hashCode(): number;
        iterator(): $Iterator<$JsonElement>;
        remove(arg0: $JsonElement): boolean;
        remove(arg0: number): $JsonElement;
        set(arg0: number, arg1: $JsonElement): $JsonElement;
        size(): number;
        spliterator(): $Spliterator<$JsonElement>;
    }

    export class $JsonElement {
        constructor();
        get asBigDecimal(): number;
        getAsBigDecimal(): number;
        get asBigInteger(): number;
        getAsBigInteger(): number;
        get asBoolean(): boolean;
        getAsBoolean(): boolean;
        get asByte(): number;
        getAsByte(): number;
        get asCharacter(): string;
        getAsCharacter(): string;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asJsonArray(): $JsonArray;
        getAsJsonArray(): $JsonArray;
        get asJsonNull(): $JsonNull;
        getAsJsonNull(): $JsonNull;
        get asJsonObject(): $JsonObject;
        getAsJsonObject(): $JsonObject;
        get asJsonPrimitive(): $JsonPrimitive;
        getAsJsonPrimitive(): $JsonPrimitive;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get asString(): string;
        getAsString(): string;
        get jsonArray(): boolean;
        isJsonArray(): boolean;
        get jsonNull(): boolean;
        isJsonNull(): boolean;
        get jsonObject(): boolean;
        isJsonObject(): boolean;
        get jsonPrimitive(): boolean;
        isJsonPrimitive(): boolean;
        deepCopy(): $JsonElement;
        toString(): string;
    }

    export class $JsonPrimitive extends $JsonElement {
        constructor(arg0: boolean);
        constructor(arg0: string);
        constructor(arg0: number);
        constructor(arg0: string);
        get asBigDecimal(): number;
        getAsBigDecimal(): number;
        get asBigInteger(): number;
        getAsBigInteger(): number;
        get asBoolean(): boolean;
        getAsBoolean(): boolean;
        get asByte(): number;
        getAsByte(): number;
        get asCharacter(): string;
        getAsCharacter(): string;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get asString(): string;
        getAsString(): string;
        get boolean(): boolean;
        isBoolean(): boolean;
        get number(): boolean;
        isNumber(): boolean;
        get string(): boolean;
        isString(): boolean;
        deepCopy(): $JsonPrimitive;
        equals(arg0: unknown): boolean;
        hashCode(): number;
    }

    export class $JsonNull extends $JsonElement {
        constructor();
        static INSTANCE: $JsonNull;
        deepCopy(): $JsonNull;
        equals(arg0: unknown): boolean;
        hashCode(): number;
    }

}
