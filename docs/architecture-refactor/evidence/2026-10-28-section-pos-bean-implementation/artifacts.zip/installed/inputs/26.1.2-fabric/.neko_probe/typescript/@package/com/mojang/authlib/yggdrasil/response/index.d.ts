import { $Record } from "java:java/lang";
import { $ByteBuffer } from "java:java/nio";
import { $UUID } from "java:java/util";

declare module "java:com/mojang/authlib/yggdrasil/response" {
    export class $NameAndId extends $Record {
        constructor(id: $UUID, name: string);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        id(): $UUID;
        name(): string;
        toString(): string;
    }

    export class $KeyPairResponse extends $Record {
        constructor(keyPair: $KeyPairResponse$KeyPair, publicKeySignature: $ByteBuffer, expiresAt: string, refreshedAfter: string);
        equals(arg0: unknown): boolean;
        expiresAt(): string;
        hashCode(): number;
        keyPair(): $KeyPairResponse$KeyPair;
        publicKeySignature(): $ByteBuffer;
        refreshedAfter(): string;
        toString(): string;
    }

    export class $KeyPairResponse$KeyPair extends $Record {
        constructor(privateKey: string, publicKey: string);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        privateKey(): string;
        publicKey(): string;
        toString(): string;
    }

}
