declare module "java:com/llamalad7/mixinextras/injector/wrapoperation" {
    export interface $Operation<R> {
        call(arg0?: unknown[]): R;
    }

    export type $Operation_<Host0 = any, CallbackArg0 = unknown[], CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Operation<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "call": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
