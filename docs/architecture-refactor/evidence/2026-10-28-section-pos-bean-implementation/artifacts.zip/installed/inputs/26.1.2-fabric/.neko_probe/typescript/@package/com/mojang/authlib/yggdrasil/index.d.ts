import { $Environment, $GameProfile, $GameProfileRepository, $HttpAuthenticationService } from "java:com/mojang/authlib";
import { $MinecraftSessionService, $UserApiService } from "java:com/mojang/authlib/minecraft";
import { $Property } from "java:com/mojang/authlib/properties";
import { $Enum, $Record } from "java:java/lang";
import { $Proxy } from "java:java/net";
import { $Signature } from "java:java/security";
import { $Collection, $Set } from "java:java/util";
import { $Supplier, $Supplier_ } from "java:java/util/function";

export * as response from "java:com/mojang/authlib/yggdrasil/response";
export * as request from "java:com/mojang/authlib/yggdrasil/request";

declare module "java:com/mojang/authlib/yggdrasil" {
    export interface $ServicesKeySet {
        keys(arg0: $ServicesKeyType_): $Collection<$ServicesKeyInfo>;
    }
    export const $ServicesKeySet: {
        lazy(arg0: $Supplier_<$ServicesKeySet, $ServicesKeySet_<$ServicesKeyType, ($Collection<$ServicesKeyInfo> | ($ServicesKeyInfo)[])>>): $ServicesKeySet;
        readonly EMPTY: $ServicesKeySet;
    };

    export class $YggdrasilAuthenticationService extends $HttpAuthenticationService {
        constructor(arg0: $Proxy);
        constructor(arg0: $Proxy, arg1: $Environment);
        get servicesKeySet(): $ServicesKeySet;
        getServicesKeySet(): $ServicesKeySet;
        static createOffline(arg0: $Proxy, arg1: $Environment): $YggdrasilAuthenticationService;
        static createOffline(arg0: $Proxy): $YggdrasilAuthenticationService;
        createMinecraftSessionService(): $MinecraftSessionService;
        createProfileRepository(): $GameProfileRepository;
        createUserApiService(arg0: string): $UserApiService;
    }

    export class $ProfileResult extends $Record {
        constructor(arg0: $GameProfile);
        constructor(profile: $GameProfile, actions: $Set<$ProfileActionType>);
        actions(): $Set<$ProfileActionType>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        profile(): $GameProfile;
        toString(): string;
    }

    export class $ProfileActionType {
        static FORCED_NAME_CHANGE: $ProfileActionType;
        static USING_BANNED_SKIN: $ProfileActionType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ProfileActionType[];
        static valueOf(name: string): $ProfileActionType;
    }
    export interface $ProfileActionType extends $Enum<$ProfileActionType> {}

    export interface $ServicesKeyInfo {
        keyBitCount(): number;
        signatureBitCount(): number;
        signature(): $Signature;
        validateProperty(arg0: $Property): boolean;
    }

    export class $ServicesKeyType {
        static PROFILE_KEY: $ServicesKeyType;
        static PROFILE_PROPERTY: $ServicesKeyType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServicesKeyType[];
        static valueOf(name: string): $ServicesKeyType;
    }
    export interface $ServicesKeyType extends $Enum<$ServicesKeyType> {}

    export type $ServicesKeySet_<CallbackArg0 = $ServicesKeyType, CallbackResult = ($Collection<$ServicesKeyInfo> | ($ServicesKeyInfo)[])> = ((arg0: CallbackArg0) => CallbackResult) | ($ServicesKeySet & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "keys": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $ProfileActionType_ = $ProfileActionType | "FORCED_NAME_CHANGE" | "USING_BANNED_SKIN";
    export type $ServicesKeyType_ = $ServicesKeyType | "PROFILE_KEY" | "PROFILE_PROPERTY";
}
