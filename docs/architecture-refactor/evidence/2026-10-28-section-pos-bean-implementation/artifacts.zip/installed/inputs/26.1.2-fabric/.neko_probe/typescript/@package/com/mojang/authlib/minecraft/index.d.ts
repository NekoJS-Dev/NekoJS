import { $JsonObject } from "java:com/google/gson";
import { $GameProfile, $SignatureState, $SignatureState_ } from "java:com/mojang/authlib";
import { $AbuseReportLimits } from "java:com/mojang/authlib/minecraft/report";
import { $Property } from "java:com/mojang/authlib/properties";
import { $ProfileResult } from "java:com/mojang/authlib/yggdrasil";
import { $AbuseReportRequest } from "java:com/mojang/authlib/yggdrasil/request";
import { $KeyPairResponse } from "java:com/mojang/authlib/yggdrasil/response";
import { $Enum, $Record, $Runnable, $Runnable_ } from "java:java/lang";
import { $InetAddress } from "java:java/net";
import { $Instant } from "java:java/time";
import { $Map, $Set, $UUID } from "java:java/util";
import { $Executor, $Executor_ } from "java:java/util/concurrent";

export * as report from "java:com/mojang/authlib/minecraft/report";

declare module "java:com/mojang/authlib/minecraft" {
    export interface $MinecraftSessionService {
        fetchProfile(arg0: $UUID, arg1: boolean): $ProfileResult;
        getPackedTextures(arg0: $GameProfile): $Property;
        getSecurePropertyValue(arg0: $Property): string;
        getTextures(arg0: $GameProfile): $MinecraftProfileTextures;
        hasJoinedServer(arg0: string, arg1: string, arg2: $InetAddress): $ProfileResult;
        joinServer(arg0: $UUID, arg1: string, arg2: string): void;
        unpackTextures(arg0: $Property): $MinecraftProfileTextures;
    }

    export class $MinecraftProfileTextures extends $Record {
        constructor(skin: $MinecraftProfileTexture, cape: $MinecraftProfileTexture, elytra: $MinecraftProfileTexture, signatureState: $SignatureState_);
        static EMPTY: $MinecraftProfileTextures;
        cape(): $MinecraftProfileTexture;
        elytra(): $MinecraftProfileTexture;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        signatureState(): $SignatureState;
        skin(): $MinecraftProfileTexture;
        toString(): string;
    }

    export class $MinecraftProfileTexture {
        constructor(arg0: string, arg1: ($Map<string, string> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, string>>)));
        static PROFILE_TEXTURE_COUNT: number;
        get hash(): string;
        getHash(): string;
        get url(): string;
        getUrl(): string;
        getMetadata(arg0: string): string;
        toString(): string;
    }

    export interface $UserApiService {
        canSendReports(): boolean;
        fetchProperties(): $UserApiService$UserProperties;
        getAbuseReportLimits(): $AbuseReportLimits;
        getKeyPair(): $KeyPairResponse;
        isBlockedPlayer(arg0: $UUID): boolean;
        newTelemetrySession(arg0: $Executor_<$Runnable>): $TelemetrySession;
        refreshBlockList(): void;
        reportAbuse(arg0: $AbuseReportRequest): void;
    }
    export const $UserApiService: {
        readonly OFFLINE: $UserApiService;
        readonly OFFLINE_PROPERTIES: $UserApiService$UserProperties;
    };

    export interface $TelemetrySession {
        createNewEvent(arg0: string): $TelemetryEvent;
        isEnabled(): boolean;
    }
    export const $TelemetrySession: {
        readonly DISABLED: $TelemetrySession;
    };

    export class $UserApiService$UserProperties extends $Record {
        constructor(flags: $Set<$UserApiService$UserFlag>, bannedScopes: ($Map<string, $BanDetails> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, $BanDetails>>)));
        bannedScopes(): $Map<string, $BanDetails>;
        equals(arg0: unknown): boolean;
        flags(): $Set<$UserApiService$UserFlag>;
        flag(arg0: $UserApiService$UserFlag_): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $TelemetryEvent extends $TelemetryPropertyContainer {
        send(): void;
    }
    export const $TelemetryEvent: {
        readonly EMPTY: $TelemetryEvent;
    };

    export interface $TelemetryPropertyContainer {
        addNullProperty(arg0: string): void;
        addProperty(arg0: string, arg1: boolean): void;
        addProperty(arg0: string, arg1: number): void;
        addProperty(arg0: string, arg1: string): void;
        addProperty(arg0: string, arg1: number): void;
    }
    export const $TelemetryPropertyContainer: {
        forJsonObject(arg0: $JsonObject): $TelemetryPropertyContainer;
    };

    export class $BanDetails extends $Record {
        constructor(id: $UUID, expires: $Instant, reason: string, reasonMessage: string);
        static MULTIPLAYER_SCOPE: string;
        equals(arg0: unknown): boolean;
        expires(): $Instant;
        hashCode(): number;
        id(): $UUID;
        reasonMessage(): string;
        reason(): string;
        toString(): string;
    }

    export class $UserApiService$UserFlag {
        static CHAT_ALLOWED: $UserApiService$UserFlag;
        static OPTIONAL_TELEMETRY_AVAILABLE: $UserApiService$UserFlag;
        static PROFANITY_FILTER_ENABLED: $UserApiService$UserFlag;
        static REALMS_ALLOWED: $UserApiService$UserFlag;
        static SERVERS_ALLOWED: $UserApiService$UserFlag;
        static TELEMETRY_ENABLED: $UserApiService$UserFlag;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $UserApiService$UserFlag[];
        static valueOf(name: string): $UserApiService$UserFlag;
    }
    export interface $UserApiService$UserFlag extends $Enum<$UserApiService$UserFlag> {}

    export type $UserApiService$UserFlag_ = $UserApiService$UserFlag | "CHAT_ALLOWED" | "OPTIONAL_TELEMETRY_AVAILABLE" | "PROFANITY_FILTER_ENABLED" | "REALMS_ALLOWED" | "SERVERS_ALLOWED" | "TELEMETRY_ENABLED";
}
