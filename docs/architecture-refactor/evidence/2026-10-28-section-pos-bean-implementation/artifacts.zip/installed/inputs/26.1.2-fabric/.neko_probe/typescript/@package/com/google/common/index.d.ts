export * as collect from "java:com/google/common/collect";
export * as base from "java:com/google/common/base";
export * as reflect from "java:com/google/common/reflect";

