import type { RegistryTypes } from "@special/types";
import { $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Record } from "java:java/lang";
import { $Set } from "java:java/util";
import { $LootContext } from "java:net/minecraft/world/level/storage/loot";
import { $LootContextParam } from "java:net/minecraft/world/level/storage/loot/parameters";
import { $ScoreHolder, $ScoreHolder_ } from "java:net/minecraft/world/scores";

declare module "java:net/minecraft/world/level/storage/loot/providers/score" {
    export class $LootScoreProviderType extends $Record {
        constructor(arg0: $MapCodec<$ScoreboardNameProvider>);
        codec(): $MapCodec<$ScoreboardNameProvider>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $ScoreboardNameProvider {
        getReferencedContextParams(): $Set<$LootContextParam<any>>;
        getScoreHolder(arg0: $LootContext): $ScoreHolder;
        getType(): $LootScoreProviderType;
    }

    export type $LootScoreProviderType_ = $LootScoreProviderType | RegistryTypes.LootScoreProviderType | $NekoId | string;
}
