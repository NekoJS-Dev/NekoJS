// Bindings for test scripts
import { $RecipeSchemaBinding } from "java:com/tkisor/nekojs/bindings";
import { $BlockJS, $CapabilitiesJS, $ClientDataJS, $ColorJS, $DamageSourceJS, $DataMapJS, $FluidIngredientJS, $FluidJS, $IngredientFactory, $ItemJS, $KMathJS, $OnceJS, $OnceJS$ClearOnceJS, $ParticleOptionsJS, $StringUtilsJS, $TestJS, $TextIcons, $TimeJS, $UUIDJS, $UtilsJS } from "java:com/tkisor/nekojs/bindings/static_access";
import { $EntitySelectorsJS } from "java:com/tkisor/nekojs/util/selector";
import { $FluidAmounts } from "java:com/tkisor/nekojs/wrapper";
import { $ClientDataSyncJS } from "java:com/tkisor/nekojs/wrapper/clientdata";
import { $NetworkJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $Math } from "java:java/lang";
import { $BlockPos, $Direction } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleTypes } from "java:net/minecraft/core/particles";
import { $CompoundTag } from "java:net/minecraft/nbt";
import { $Component, $MutableComponent } from "java:net/minecraft/network/chat";
import { $ResourceLocation } from "java:net/minecraft/resources";
import { $SoundEvents } from "java:net/minecraft/sounds";
import { $DamageSource, $DamageTypes } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance, $MobEffects } from "java:net/minecraft/world/effect";
import { $EntityType } from "java:net/minecraft/world/entity";
import { $DyeColor, $Item, $ItemStack, $Items } from "java:net/minecraft/world/item";
import { $Ingredient } from "java:net/minecraft/world/item/crafting";
import { $Block, $Blocks } from "java:net/minecraft/world/level/block";
import { $Fluid, $Fluids } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3 } from "java:net/minecraft/world/phys";
import { $Capabilities } from "java:net/neoforged/neoforge/capabilities";
import { $FluidStack } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient } from "java:net/neoforged/neoforge/fluids/crafting";
type NekoFluidIngredientHelper = $FluidIngredientJS;
type NekoFluidHelper = $FluidJS;
type NekoTestHelper = $TestJS;
type NekoItemHelper = $ItemJS;
type NekoIngredientHelper = $IngredientFactory;

export {};

declare global {
    let Component: typeof $Component;
    let ClientData: typeof $ClientDataSyncJS;
    let Blocks: typeof $Blocks;
    let MobEffectInstance: typeof $MobEffectInstance;
    let Network: typeof $NetworkJS;
    let EntityType: typeof $EntityType;
    let Fluids: typeof $Fluids;
    let DyeColor: typeof $DyeColor;
    let TextIcons: typeof $TextIcons;
    let Utils: $UtilsJS;
    let Time: $TimeJS;
    let clientData: $ClientDataJS;
    let Vec3: typeof $Vec3;
    let EntitySelectors: $EntitySelectorsJS;
    let once: $OnceJS;
    let Block: $BlockJS & typeof $Block;
    let DamageSource: $DamageSourceJS & typeof $DamageSource;
    let SoundEvents: typeof $SoundEvents;
    let AABB: typeof $AABB;
    let RecipeSchema: $RecipeSchemaBinding;
    let JavaMath: typeof $Math;
    let ParticleTypes: typeof $ParticleTypes;
    let MobEffects: typeof $MobEffects;
    let ItemStack: typeof $ItemStack;
    let ResourceLocation: typeof $ResourceLocation;
    let BlockPos: typeof $BlockPos;
    /** Script-friendly FluidIngredient and SizedFluidIngredient helper. */
    let FluidIngredient: NekoFluidIngredientHelper & typeof $FluidIngredient;
    /** Script-friendly FluidStack helper. */
    let Fluid: NekoFluidHelper & typeof $Fluid;
    let StringUtils: $StringUtilsJS;
    let DataMap: $DataMapJS;
    let KMath: typeof $KMathJS;
    let FluidStack: typeof $FluidStack;
    let clearOnce: $OnceJS$ClearOnceJS;
    let Direction: typeof $Direction;
    /** Test-script assertion and smoke test helper. */
    let Test: NekoTestHelper;
    let UUID: $UUIDJS;
    let Capabilities: $CapabilitiesJS & typeof $Capabilities;
    let Color: $ColorJS;
    let DamageTypes: typeof $DamageTypes;
    /** Script-friendly ItemStack factory and helpers (KubeJS-style: Item.of(id)); delegates of/empty to the helper, rest to MC Item. */
    let Item: NekoItemHelper & typeof $Item;
    let Items: typeof $Items;
    let FluidAmounts: typeof $FluidAmounts;
    /** Script-friendly Ingredient and IngredientJS helper. */
    let Ingredient: NekoIngredientHelper & typeof $Ingredient;
    let ParticleOptions: $ParticleOptionsJS & typeof $ParticleOptions;
    let CompoundTag: typeof $CompoundTag;
    let MutableComponent: typeof $MutableComponent;
}
