import { $Dynamic } from "java:com/mojang/serialization";
import { $Class } from "java:java/lang";
import { $Set } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $CompoundTag, $CompoundTag_, $ListTag } from "java:net/minecraft/nbt";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $MinecraftServer } from "java:net/minecraft/server";

declare module "java:net/minecraft/world/level/timers" {
    export interface $TimerCallback<T> {
        handle(arg0: T, arg1: $TimerQueue<T>, arg2: number): void;
    }

    export class $TimerCallback$Serializer<T, C extends $TimerCallback<T>> {
        constructor(arg0: $ResourceLocation_, arg1: $Class<any>);
        get cls(): $Class<any>;
        getCls(): $Class<any>;
        get id(): $ResourceLocation;
        getId(): $ResourceLocation;
        deserialize(arg0: $CompoundTag_): C;
        serialize(arg0: $CompoundTag_, arg1: C): void;
    }

    export class $TimerCallbacks<C> {
        constructor();
        static SERVER_CALLBACKS: $TimerCallbacks<$MinecraftServer>;
        deserialize(arg0: $CompoundTag_): $TimerCallback<C>;
        register(arg0: $TimerCallback$Serializer<C, any>): $TimerCallbacks<C>;
        serialize<T extends $TimerCallback<C>>(arg0: T): $CompoundTag;
    }

    export class $TimerQueue<T> {
        constructor(arg0: $TimerCallbacks<T>);
        constructor(arg0: $TimerCallbacks<T>, arg1: $Stream<$Dynamic<any>>);
        get eventsIds(): $Set<string>;
        getEventsIds(): $Set<string>;
        remove(arg0: string): number;
        schedule(arg0: string, arg1: number, arg2: $TimerCallback_<T, T, $TimerQueue<T>, number>): void;
        store(): $ListTag;
        tick(arg0: T, arg1: number): void;
    }

    export type $TimerCallback_<Host0 = any, CallbackArg0 = Host0, CallbackArg1 = $TimerQueue<Host0>, CallbackArg2 = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void) | ($TimerCallback<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "handle": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void } & { readonly [Symbol.hasInstance]?: never }>);
}
