import { $JsonElement, $JsonObject, $JsonObject_ } from "java:com/google/gson";
import { $Codec, $DynamicOps, $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Collection, $List, $Map, $Optional } from "java:java/util";
import { $Holder, $HolderLookup$Provider, $Holder_, $Registry } from "java:net/minecraft/core";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";

declare module "java:net/neoforged/neoforge/common/conditions" {
    export interface $ICondition {
        codec(): $MapCodec<$ICondition>;
        test(arg0: $ICondition$IContext_<$ResourceKey<$Registry<any>>, ($Map<$ResourceLocation, $Collection<$Holder<any>>> | (([$ResourceLocation_] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$ResourceLocation_, PropertyKey>, ($Collection<$Holder<any>> | ($Holder_<any>)[])>>))>): boolean;
    }
    export const $ICondition: {
        conditionsMatched<V>(arg0: $DynamicOps<V>, arg1: V): boolean;
        getConditionally<V, T>(arg0: $Codec<T>, arg1: $DynamicOps<V>, arg2: V): $Optional<T>;
        getWithConditionalCodec<V, T>(arg0: $Codec<$Optional<T>>, arg1: $DynamicOps<V>, arg2: V): $Optional<T>;
        getWithWithConditionsCodec<V, T>(arg0: $Codec<$Optional<$WithConditions<T>>>, arg1: $DynamicOps<V>, arg2: V): $Optional<T>;
        writeConditions(arg0: $DynamicOps<$JsonElement>, arg1: $JsonObject_, arg2: ($List<$ICondition> | ($ICondition)[])): void;
        writeConditions(arg0: $HolderLookup$Provider, arg1: $JsonObject_, arg2: ($List<$ICondition> | ($ICondition)[])): void;
        writeConditions(arg0: $HolderLookup$Provider, arg1: $JsonObject_, arg2?: $ICondition[]): void;
        readonly CODEC: $Codec<$ICondition>;
        readonly LIST_CODEC: $Codec<$List<$ICondition>>;
    };

    export interface $ICondition$IContext {
        getAllTags<T>(arg0: $ResourceKey<$Registry<T>>): $Map<$ResourceLocation, $Collection<$Holder<T>>>;
        getTag<T>(arg0: $TagKey_<T>): $Collection<$Holder<T>>;
    }
    export const $ICondition$IContext: {
        readonly EMPTY: $ICondition$IContext;
        readonly TAGS_INVALID: $ICondition$IContext;
    };

    export class $WithConditions<A> extends $Record {
        constructor(arg0: A);
        constructor(arg0: A, arg1?: $ICondition[]);
        constructor(conditions: ($List<$ICondition> | ($ICondition)[]), carrier: A);
        static builder<A>(arg0: A): $WithConditions$Builder<A>;
        carrier(): A;
        conditions(): $List<$ICondition>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $WithConditions$Builder<T> {
        constructor();
        addCondition(arg0: ($Collection<$ICondition> | ($ICondition)[])): $WithConditions$Builder<T>;
        addCondition(arg0?: $ICondition[]): $WithConditions$Builder<T>;
        build(): $WithConditions<T>;
        withCarrier(arg0: T): $WithConditions$Builder<T>;
    }

    export type $ICondition$IContext_<CallbackArg0 = $ResourceKey<$Registry<any>>, CallbackResult = ($Map<$ResourceLocation, $Collection<$Holder<any>>> | (([$ResourceLocation_] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$ResourceLocation_, PropertyKey>, ($Collection<$Holder<any>> | ($Holder_<any>)[])>>))> = ((arg0: CallbackArg0) => CallbackResult) | ($ICondition$IContext & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "getAllTags": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
