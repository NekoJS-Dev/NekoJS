import { $Runnable, $Runnable_ } from "java:java/lang";
import { $Collection, $Map } from "java:java/util";
import { $CompletableFuture, $Executor, $Executor_ } from "java:java/util/concurrent";
import { $Holder, $HolderLookup$Provider, $Holder_, $Registry } from "java:net/minecraft/core";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $PreparableReloadListener, $PreparableReloadListener$PreparationBarrier, $PreparableReloadListener$PreparationBarrier_, $PreparableReloadListener_, $ResourceManager } from "java:net/minecraft/server/packs/resources";
import { $ProfilerFiller } from "java:net/minecraft/util/profiling";
import { $ICondition$IContext, $ICondition$IContext_ } from "java:net/neoforged/neoforge/common/conditions";

declare module "java:net/neoforged/neoforge/resource" {
    export class $ContextAwareReloadListener implements $PreparableReloadListener {
        constructor();
        get name(): string;
        getName(): string;
        injectContext(arg0: $ICondition$IContext_<$ResourceKey<$Registry<any>>, ($Map<$ResourceLocation, $Collection<$Holder<any>>> | (([$ResourceLocation_] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$ResourceLocation_, PropertyKey>, ($Collection<$Holder<any>> | ($Holder_<any>)[])>>))>, arg1: $HolderLookup$Provider): void;
        reload(arg0: $PreparableReloadListener$PreparationBarrier_<any, $CompletableFuture<any>>, arg1: $ResourceManager, arg2: $ProfilerFiller, arg3: $ProfilerFiller, arg4: $Executor_<$Runnable>, arg5: $Executor_<$Runnable>): $CompletableFuture<void>;
    }

}
