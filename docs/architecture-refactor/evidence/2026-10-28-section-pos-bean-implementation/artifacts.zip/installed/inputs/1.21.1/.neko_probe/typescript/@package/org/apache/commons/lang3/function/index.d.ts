declare module "java:org/apache/commons/lang3/function" {
    export interface $TriConsumer<T, U, V> {
        accept(arg0: T, arg1: U, arg2: V): void;
        andThen(arg0: $TriConsumer_<T, U, V, T, U, V>): $TriConsumer<T, U, V>;
    }

    export type $TriConsumer_<Host0 = any, Host1 = any, Host2 = any, CallbackArg0 = Host0, CallbackArg1 = Host1, CallbackArg2 = Host2> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void) | ($TriConsumer<Host0, Host1, Host2> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "accept": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void } & { readonly [Symbol.hasInstance]?: never }>);
}
