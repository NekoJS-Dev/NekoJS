import { $DataFixer } from "java:com/mojang/datafixers";
import { $Dynamic, $Lifecycle } from "java:com/mojang/serialization";
import { $File } from "java:java/io";
import { $AutoCloseable, $AutoCloseable_, $Comparable, $Comparable_, $Enum, $Iterable, $Record } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Instant, $LocalDateTime } from "java:java/time";
import { $Iterator, $List, $Optional, $Set, $Spliterator, $UUID } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $CrashReportCategory } from "java:net/minecraft";
import { $BlockPos, $BlockPos_, $HolderLookup$Provider, $Registry, $RegistryAccess, $RegistryAccess$Frozen } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Component, $Component_, $MutableComponent } from "java:net/minecraft/network/chat";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $MinecraftServer, $WorldLoader$PackConfig } from "java:net/minecraft/server";
import { $PackRepository } from "java:net/minecraft/server/packs/repository";
import { $DataFixTypes, $DataFixTypes_ } from "java:net/minecraft/util/datafix";
import { $Difficulty, $Difficulty_ } from "java:net/minecraft/world";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $GameRules, $GameType, $GameType_, $Level, $LevelHeightAccessor, $LevelSettings, $WorldDataConfiguration } from "java:net/minecraft/world/level";
import { $WorldBorder$Settings } from "java:net/minecraft/world/level/border";
import { $LevelStem } from "java:net/minecraft/world/level/dimension";
import { $EndDragonFight$Data } from "java:net/minecraft/world/level/dimension/end";
import { $WorldDimensions$Complete, $WorldOptions } from "java:net/minecraft/world/level/levelgen";
import { $SavedData, $SavedData$Factory } from "java:net/minecraft/world/level/saveddata";
import { $TimerQueue } from "java:net/minecraft/world/level/timers";
import { $DirectoryValidator } from "java:net/minecraft/world/level/validation";

export * as loot from "java:net/minecraft/world/level/storage/loot";

declare module "java:net/minecraft/world/level/storage" {
    export class $CommandStorage {
        constructor(arg0: $DimensionDataStorage);
        get(arg0: $ResourceLocation_): $CompoundTag;
        keys(): $Stream<$ResourceLocation>;
        set(arg0: $ResourceLocation_, arg1: $CompoundTag_): void;
    }

    export class $DataVersion {
        constructor(arg0: number);
        constructor(arg0: number, arg1: string);
        static MAIN_SERIES: string;
        get series(): string;
        getSeries(): string;
        get version(): number;
        getVersion(): number;
        get sideSeries(): boolean;
        isSideSeries(): boolean;
        isCompatible(arg0: $DataVersion): boolean;
    }

    export class $DimensionDataStorage {
        constructor(arg0: $File, arg1: $DataFixer, arg2: $HolderLookup$Provider);
        computeIfAbsent<T extends $SavedData>(arg0: $SavedData$Factory<T>, arg1: string): T;
        get<T extends $SavedData>(arg0: $SavedData$Factory<T>, arg1: string): T;
        readTagFromDisk(arg0: string, arg1: $DataFixTypes_, arg2: number): $CompoundTag;
        save(): void;
        set(arg0: string, arg1: $SavedData): void;
    }

    export interface $LevelData {
        fillCrashReportCategory(arg0: $CrashReportCategory, arg1: $LevelHeightAccessor): void;
        getDayTime(): number;
        getDifficulty(): $Difficulty;
        getGameRules(): $GameRules;
        getGameTime(): number;
        getSpawnAngle(): number;
        getSpawnPos(): $BlockPos;
        isDifficultyLocked(): boolean;
        isHardcore(): boolean;
        isRaining(): boolean;
        isThundering(): boolean;
        setRaining(arg0: boolean): void;
    }

    export class $LevelDataAndDimensions extends $Record {
        constructor(arg0: $WorldData, arg1: $WorldDimensions$Complete);
        dimensions(): $WorldDimensions$Complete;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
        worldData(): $WorldData;
    }

    export class $LevelResource {
        constructor(arg0: string);
        static DATAPACK_DIR: $LevelResource;
        static GENERATED_DIR: $LevelResource;
        static ICON_FILE: $LevelResource;
        static LEVEL_DATA_FILE: $LevelResource;
        static LOCK_FILE: $LevelResource;
        static MAP_RESOURCE_FILE: $LevelResource;
        static OLD_LEVEL_DATA_FILE: $LevelResource;
        static PLAYER_ADVANCEMENTS_DIR: $LevelResource;
        static PLAYER_DATA_DIR: $LevelResource;
        static PLAYER_OLD_DATA_DIR: $LevelResource;
        static PLAYER_STATS_DIR: $LevelResource;
        static ROOT: $LevelResource;
        get id(): string;
        getId(): string;
        toString(): string;
    }

    export class $LevelStorageSource {
        constructor(arg0: $Path, arg1: $Path, arg2: $DirectoryValidator, arg3: $DataFixer);
        static ALLOWED_SYMLINKS_CONFIG_NAME: string;
        get backupPath(): $Path;
        getBackupPath(): $Path;
        get baseDir(): $Path;
        getBaseDir(): $Path;
        get name(): string;
        getName(): string;
        get worldDirValidator(): $DirectoryValidator;
        getWorldDirValidator(): $DirectoryValidator;
        static createDefault(arg0: $Path): $LevelStorageSource;
        static getLevelDataAndDimensions(arg0: $Dynamic<any>, arg1: $WorldDataConfiguration, arg2: $Registry<$LevelStem>, arg3: $RegistryAccess$Frozen): $LevelDataAndDimensions;
        static getPackConfig(arg0: $Dynamic<any>, arg1: $PackRepository, arg2: boolean): $WorldLoader$PackConfig;
        static parseValidator(arg0: $Path): $DirectoryValidator;
        static readDataConfig(arg0: $Dynamic<any>): $WorldDataConfiguration;
        createAccess(arg0: string): $LevelStorageSource$LevelStorageAccess;
        findLevelCandidates(): $LevelStorageSource$LevelCandidates;
        getLevelPath(arg0: string): $Path;
        isNewLevelIdAcceptable(arg0: string): boolean;
        levelExists(arg0: string): boolean;
        loadLevelSummaries(arg0: $LevelStorageSource$LevelCandidates): $CompletableFuture<$List<$LevelSummary>>;
        validateAndCreateAccess(arg0: string): $LevelStorageSource$LevelStorageAccess;
    }

    export class $LevelStorageSource$LevelCandidates extends $Record implements $Iterable<$LevelStorageSource$LevelDirectory> {
        constructor(levels: ($List<$LevelStorageSource$LevelDirectory> | ($LevelStorageSource$LevelDirectory)[]));
        get empty(): boolean;
        isEmpty(): boolean;
        equals(arg0: unknown): boolean;
        forEach(arg0: $Consumer_<$LevelStorageSource$LevelDirectory, $LevelStorageSource$LevelDirectory>): void;
        hashCode(): number;
        iterator(): $Iterator<$LevelStorageSource$LevelDirectory>;
        levels(): $List<$LevelStorageSource$LevelDirectory>;
        spliterator(): $Spliterator<$LevelStorageSource$LevelDirectory>;
        toString(): string;
    }

    export class $LevelStorageSource$LevelDirectory extends $Record {
        constructor(path: $Path);
        corruptedDataFile(arg0: $LocalDateTime): $Path;
        dataFile(): $Path;
        directoryName(): string;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        iconFile(): $Path;
        lockFile(): $Path;
        oldDataFile(): $Path;
        path(): $Path;
        rawDataFile(arg0: $LocalDateTime): $Path;
        resourcePath(arg0: $LevelResource): $Path;
        toString(): string;
    }

    export class $LevelStorageSource$LevelStorageAccess implements $AutoCloseable {
        get dataTagFallback(): $Dynamic<any>;
        getDataTagFallback(): $Dynamic<any>;
        get dataTag(): $Dynamic<any>;
        getDataTag(): $Dynamic<any>;
        get iconFile(): $Optional<$Path>;
        getIconFile(): $Optional<$Path>;
        get levelDirectory(): $LevelStorageSource$LevelDirectory;
        getLevelDirectory(): $LevelStorageSource$LevelDirectory;
        get levelId(): string;
        getLevelId(): string;
        get worldDir(): $Path;
        getWorldDir(): $Path;
        checkForLowDiskSpace(): boolean;
        close(): void;
        createPlayerStorage(): $PlayerDataStorage;
        deleteLevel(): void;
        estimateDiskSpace(): number;
        getDimensionPath(arg0: $ResourceKey<$Level>): $Path;
        getFileModificationTime(arg0: boolean): $Instant;
        getLevelPath(arg0: $LevelResource): $Path;
        getSummary(arg0: $Dynamic<any>): $LevelSummary;
        hasWorldData(): boolean;
        makeWorldBackup(): number;
        parent(): $LevelStorageSource;
        readAdditionalLevelSaveData(arg0: boolean): void;
        renameAndDropPlayer(arg0: string): void;
        renameLevel(arg0: string): void;
        restoreLevelDataFromOld(): boolean;
        safeClose(): void;
        saveDataTag(arg0: $RegistryAccess, arg1: $WorldData, arg2: $CompoundTag_): void;
        saveDataTag(arg0: $RegistryAccess, arg1: $WorldData): void;
    }

    export class $LevelSummary implements $Comparable<$LevelSummary> {
        constructor(arg0: $LevelSettings, arg1: $LevelVersion, arg2: string, arg3: boolean, arg4: boolean, arg5: boolean, arg6: $Path);
        static PLAY_WORLD: $Component;
        get gameMode(): $GameType;
        getGameMode(): $GameType;
        get icon(): $Path;
        getIcon(): $Path;
        get info(): $Component;
        getInfo(): $Component;
        get lastPlayed(): number;
        getLastPlayed(): number;
        get levelId(): string;
        getLevelId(): string;
        get levelName(): string;
        getLevelName(): string;
        get settings(): $LevelSettings;
        getSettings(): $LevelSettings;
        get worldVersionName(): $MutableComponent;
        getWorldVersionName(): $MutableComponent;
        get compatible(): boolean;
        isCompatible(): boolean;
        get disabled(): boolean;
        isDisabled(): boolean;
        get downgrade(): boolean;
        isDowngrade(): boolean;
        get experimental(): boolean;
        isExperimental(): boolean;
        get hardcore(): boolean;
        isHardcore(): boolean;
        get locked(): boolean;
        isLocked(): boolean;
        backupStatus(): $LevelSummary$BackupStatus;
        canDelete(): boolean;
        canEdit(): boolean;
        canRecreate(): boolean;
        canUpload(): boolean;
        compareTo(arg0: unknown): number;
        compareTo(arg0: $LevelSummary): number;
        hasCommands(): boolean;
        levelVersion(): $LevelVersion;
        primaryActionActive(): boolean;
        primaryActionMessage(): $Component;
        requiresManualConversion(): boolean;
        shouldBackup(): boolean;
    }

    export class $LevelSummary$BackupStatus {
        static DOWNGRADE: $LevelSummary$BackupStatus;
        static NONE: $LevelSummary$BackupStatus;
        static UPGRADE_TO_SNAPSHOT: $LevelSummary$BackupStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LevelSummary$BackupStatus[];
        static valueOf(name: string): $LevelSummary$BackupStatus;
    }
    export interface $LevelSummary$BackupStatus extends $Enum<$LevelSummary$BackupStatus> {}

    export class $LevelVersion {
        static parse(arg0: $Dynamic<any>): $LevelVersion;
        lastPlayed(): number;
        levelDataVersion(): number;
        minecraftVersionName(): string;
        minecraftVersion(): $DataVersion;
        snapshot(): boolean;
    }

    export class $PlayerDataStorage {
        constructor(arg0: $LevelStorageSource$LevelStorageAccess, arg1: $DataFixer);
        get playerDir(): $File;
        getPlayerDir(): $File;
        load(arg0: $Player): $Optional<$CompoundTag>;
        save(arg0: $Player): void;
    }

    export interface $ServerLevelData extends $WritableLevelData {
        fillCrashReportCategory(arg0: $CrashReportCategory, arg1: $LevelHeightAccessor): void;
        getClearWeatherTime(): number;
        getDayTimeFraction(): number;
        getDayTimePerTick(): number;
        getGameType(): $GameType;
        getLevelName(): string;
        getRainTime(): number;
        getScheduledEvents(): $TimerQueue<$MinecraftServer>;
        getThunderTime(): number;
        getWanderingTraderId(): $UUID;
        getWanderingTraderSpawnChance(): number;
        getWanderingTraderSpawnDelay(): number;
        getWorldBorder(): $WorldBorder$Settings;
        isAllowCommands(): boolean;
        isInitialized(): boolean;
        setClearWeatherTime(arg0: number): void;
        setDayTimeFraction(arg0: number): void;
        setDayTimePerTick(arg0: number): void;
        setDayTime(arg0: number): void;
        setGameTime(arg0: number): void;
        setGameType(arg0: $GameType_): void;
        setInitialized(arg0: boolean): void;
        setRainTime(arg0: number): void;
        setThunderTime(arg0: number): void;
        setThundering(arg0: boolean): void;
        setWanderingTraderId(arg0: $UUID): void;
        setWanderingTraderSpawnChance(arg0: number): void;
        setWanderingTraderSpawnDelay(arg0: number): void;
        setWorldBorder(arg0: $WorldBorder$Settings): void;
    }

    export interface $WorldData {
        createTag(arg0: $RegistryAccess, arg1: $CompoundTag_): $CompoundTag;
        enabledFeatures(): $FeatureFlagSet;
        endDragonFightData(): $EndDragonFight$Data;
        fillCrashReportCategory(arg0: $CrashReportCategory): void;
        getCustomBossEvents(): $CompoundTag;
        getDataConfiguration(): $WorldDataConfiguration;
        getDifficulty(): $Difficulty;
        getGameRules(): $GameRules;
        getGameType(): $GameType;
        getKnownServerBrands(): $Set<string>;
        getLevelName(): string;
        getLevelSettings(): $LevelSettings;
        getLoadedPlayerTag(): $CompoundTag;
        getRemovedFeatureFlags(): $Set<string>;
        getStorageVersionName(arg0: number): string;
        getVersion(): number;
        isAllowCommands(): boolean;
        isDebugWorld(): boolean;
        isDifficultyLocked(): boolean;
        isFlatWorld(): boolean;
        isHardcore(): boolean;
        overworldData(): $ServerLevelData;
        setCustomBossEvents(arg0: $CompoundTag_): void;
        setDataConfiguration(arg0: $WorldDataConfiguration): void;
        setDifficultyLocked(arg0: boolean): void;
        setDifficulty(arg0: $Difficulty_): void;
        setEndDragonFightData(arg0: $EndDragonFight$Data): void;
        setGameType(arg0: $GameType_): void;
        setModdedInfo(arg0: string, arg1: boolean): void;
        wasModded(): boolean;
        worldGenOptions(): $WorldOptions;
        worldGenSettingsLifecycle(): $Lifecycle;
    }
    export const $WorldData: {
        readonly ANVIL_VERSION_ID: number;
        readonly MCREGION_VERSION_ID: number;
    };

    export interface $WritableLevelData extends $LevelData {
        setSpawn(arg0: $BlockPos_, arg1: number): void;
    }

    export class $PrimaryLevelData$SpecialWorldProperty {
        static DEBUG: $PrimaryLevelData$SpecialWorldProperty;
        static FLAT: $PrimaryLevelData$SpecialWorldProperty;
        static NONE: $PrimaryLevelData$SpecialWorldProperty;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PrimaryLevelData$SpecialWorldProperty[];
        static valueOf(name: string): $PrimaryLevelData$SpecialWorldProperty;
    }
    export interface $PrimaryLevelData$SpecialWorldProperty extends $Enum<$PrimaryLevelData$SpecialWorldProperty> {}

    export type $LevelSummary$BackupStatus_ = $LevelSummary$BackupStatus | "DOWNGRADE" | "NONE" | "UPGRADE_TO_SNAPSHOT";
    export type $PrimaryLevelData$SpecialWorldProperty_ = $PrimaryLevelData$SpecialWorldProperty | "DEBUG" | "FLAT" | "NONE";
}
