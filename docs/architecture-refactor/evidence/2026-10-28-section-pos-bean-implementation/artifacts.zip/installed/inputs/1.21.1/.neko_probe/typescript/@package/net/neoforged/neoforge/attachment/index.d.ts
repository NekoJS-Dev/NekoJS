import { $Codec } from "java:com/mojang/serialization";
import { $Optional } from "java:java/util";
import { $BiPredicate, $BiPredicate_, $Function, $Function_, $Predicate, $Predicate_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $Tag } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $INBTSerializable } from "java:net/neoforged/neoforge/common/util";

declare module "java:net/neoforged/neoforge/attachment" {
    export class $AttachmentHolder implements $IAttachmentHolder {
        constructor();
        static ATTACHMENTS_NBT_KEY: string;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        hasAttachments(): boolean;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        serializeAttachments(arg0: $HolderLookup$Provider): $CompoundTag;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
    }

    export class $AttachmentHolder$AsField extends $AttachmentHolder {
        constructor(arg0: $IAttachmentHolder);
        deserializeInternal(arg0: $HolderLookup$Provider, arg1: $CompoundTag_): void;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
    }

    export interface $AttachmentSyncHandler<T> {
        read(arg0: $IAttachmentHolder, arg1: $RegistryFriendlyByteBuf, arg2: T): T;
        sendToPlayer(arg0: $IAttachmentHolder, arg1: $ServerPlayer): boolean;
        write(arg0: $RegistryFriendlyByteBuf, arg1: T, arg2: boolean): void;
    }

    export class $AttachmentType<T> {
        static builder<T>(arg0: $Function_<$IAttachmentHolder, T, $IAttachmentHolder, T>): $AttachmentType$Builder<T>;
        static builder<T>(arg0: $Supplier_<T, T>): $AttachmentType$Builder<T>;
        static serializable<S extends $Tag, T extends $INBTSerializable<S>>(arg0: $Function_<$IAttachmentHolder, T, $IAttachmentHolder, T>): $AttachmentType$Builder<T>;
        static serializable<S extends $Tag, T extends $INBTSerializable<S>>(arg0: $Supplier_<T, T>): $AttachmentType$Builder<T>;
    }

    export class $AttachmentType$Builder<T> {
        build(): $AttachmentType<T>;
        copyHandler(arg0: $IAttachmentCopyHandler_<T, T, $IAttachmentHolder, $HolderLookup$Provider, T>): $AttachmentType$Builder<T>;
        copyOnDeath(): $AttachmentType$Builder<T>;
        serialize(arg0: $Codec<T>, arg1: $Predicate_<T, T, boolean>): $AttachmentType$Builder<T>;
        serialize(arg0: $Codec<T>): $AttachmentType$Builder<T>;
        serialize(arg0: $IAttachmentSerializer<any, T>): $AttachmentType$Builder<T>;
        sync(arg0: $BiPredicate_<$IAttachmentHolder, $ServerPlayer, $IAttachmentHolder, $ServerPlayer, boolean>, arg1: $StreamCodec<any, T>): $AttachmentType$Builder<T>;
        sync(arg0: $StreamCodec<any, T>): $AttachmentType$Builder<T>;
        sync(arg0: $AttachmentSyncHandler<T>): $AttachmentType$Builder<T>;
    }

    export interface $IAttachmentCopyHandler<T> {
        copy(arg0: T, arg1: $IAttachmentHolder, arg2: $HolderLookup$Provider): T;
    }

    export interface $IAttachmentHolder {
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        hasAttachments(): boolean;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
    }

    export interface $IAttachmentSerializer<S extends $Tag, T> {
        read(arg0: $IAttachmentHolder, arg1: S, arg2: $HolderLookup$Provider): T;
        write(arg0: T, arg1: $HolderLookup$Provider): S;
    }

    export type $IAttachmentCopyHandler_<Host0 = any, CallbackArg0 = Host0, CallbackArg1 = $IAttachmentHolder, CallbackArg2 = $HolderLookup$Provider, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($IAttachmentCopyHandler<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "copy": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
