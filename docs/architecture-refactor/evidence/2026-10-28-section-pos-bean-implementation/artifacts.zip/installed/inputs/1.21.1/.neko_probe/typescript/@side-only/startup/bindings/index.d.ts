// Bindings for startup scripts
import { $RecipeSchemaBinding } from "java:com/tkisor/nekojs/bindings";
import { $BlockJS, $CapabilitiesJS, $ClientDataJS, $ColorJS, $DamageSourceJS, $DataMapJS, $FluidIngredientJS, $FluidJS, $IngredientFactory, $ItemJS, $KMathJS, $NativeEventsJS, $OnceJS, $OnceJS$ClearOnceJS, $ParticleOptionsJS, $StringUtilsJS, $TextIcons, $TimeJS, $UUIDJS, $UtilsJS } from "java:com/tkisor/nekojs/bindings/static_access";
import { $FluidAmounts } from "java:com/tkisor/nekojs/wrapper";
import { $ClientDataSyncJS } from "java:com/tkisor/nekojs/wrapper/clientdata";
import { $NetworkJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $Math } from "java:java/lang";
import { $BlockPos, $Direction } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleTypes } from "java:net/minecraft/core/particles";
import { $CompoundTag } from "java:net/minecraft/nbt";
import { $Component, $MutableComponent } from "java:net/minecraft/network/chat";
import { $ResourceLocation } from "java:net/minecraft/resources";
import { $SoundEvents } from "java:net/minecraft/sounds";
import { $DamageSource, $DamageTypes } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance, $MobEffects } from "java:net/minecraft/world/effect";
import { $EntityType } from "java:net/minecraft/world/entity";
import { $DyeColor, $Item, $ItemStack, $Items } from "java:net/minecraft/world/item";
import { $Ingredient } from "java:net/minecraft/world/item/crafting";
import { $Block, $Blocks } from "java:net/minecraft/world/level/block";
import { $Fluid, $Fluids } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3 } from "java:net/minecraft/world/phys";
import { $Capabilities } from "java:net/neoforged/neoforge/capabilities";
import { $FluidStack } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient } from "java:net/neoforged/neoforge/fluids/crafting";
type NekoFluidIngredientHelper = $FluidIngredientJS;
type NekoFluidHelper = $FluidJS;
type NekoItemHelper = $ItemJS;
type NekoIngredientHelper = $IngredientFactory;

export {};

declare global {
    let FluidAmounts: typeof $FluidAmounts;
    let CompoundTag: typeof $CompoundTag;
    let EntityType: typeof $EntityType;
    let Capabilities: $CapabilitiesJS & typeof $Capabilities;
    let ItemStack: typeof $ItemStack;
    let AABB: typeof $AABB;
    /** Script-friendly FluidIngredient and SizedFluidIngredient helper. */
    let FluidIngredient: NekoFluidIngredientHelper & typeof $FluidIngredient;
    let clearOnce: $OnceJS$ClearOnceJS;
    let Utils: $UtilsJS;
    let ClientData: typeof $ClientDataSyncJS;
    /** Startup-side native NeoForge event bridge. */
    let NativeEvents: $NativeEventsJS;
    let ParticleTypes: typeof $ParticleTypes;
    let DamageTypes: typeof $DamageTypes;
    let Vec3: typeof $Vec3;
    let once: $OnceJS;
    let Color: $ColorJS;
    let ParticleOptions: $ParticleOptionsJS & typeof $ParticleOptions;
    let DyeColor: typeof $DyeColor;
    let Network: typeof $NetworkJS;
    /** Script-friendly FluidStack helper. */
    let Fluid: NekoFluidHelper & typeof $Fluid;
    let Direction: typeof $Direction;
    let Fluids: typeof $Fluids;
    let SoundEvents: typeof $SoundEvents;
    let ResourceLocation: typeof $ResourceLocation;
    let FluidStack: typeof $FluidStack;
    let DamageSource: $DamageSourceJS & typeof $DamageSource;
    let Time: $TimeJS;
    let Items: typeof $Items;
    let DataMap: $DataMapJS;
    let Component: typeof $Component;
    let MobEffects: typeof $MobEffects;
    let TextIcons: typeof $TextIcons;
    let JavaMath: typeof $Math;
    let RecipeSchema: $RecipeSchemaBinding;
    let MutableComponent: typeof $MutableComponent;
    let BlockPos: typeof $BlockPos;
    let StringUtils: $StringUtilsJS;
    let KMath: typeof $KMathJS;
    let MobEffectInstance: typeof $MobEffectInstance;
    let Block: $BlockJS & typeof $Block;
    let UUID: $UUIDJS;
    /** Script-friendly ItemStack factory and helpers (KubeJS-style: Item.of(id)); delegates of/empty to the helper, rest to MC Item. */
    let Item: NekoItemHelper & typeof $Item;
    let clientData: $ClientDataJS;
    let Blocks: typeof $Blocks;
    /** Script-friendly Ingredient and IngredientJS helper. */
    let Ingredient: NekoIngredientHelper & typeof $Ingredient;
}
