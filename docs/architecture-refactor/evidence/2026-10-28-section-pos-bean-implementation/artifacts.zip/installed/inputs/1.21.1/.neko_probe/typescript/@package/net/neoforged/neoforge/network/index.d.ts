import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Inventory } from "java:net/minecraft/world/entity/player";
import { $AbstractContainerMenu, $MenuType$MenuSupplier, $MenuType$MenuSupplier_ } from "java:net/minecraft/world/inventory";

export * as bundle from "java:net/neoforged/neoforge/network/bundle";
export * as connection from "java:net/neoforged/neoforge/network/connection";

declare module "java:net/neoforged/neoforge/network" {
    export interface $IContainerFactory<T extends $AbstractContainerMenu> extends $MenuType$MenuSupplier<T> {
        create(arg0: number, arg1: $Inventory, arg2: $RegistryFriendlyByteBuf): T;
        create(arg0: number, arg1: $Inventory): T;
    }

    export type $IContainerFactory_<Host0 extends $AbstractContainerMenu = any, CallbackArg0 = number, CallbackArg1 = $Inventory, CallbackArg2 = $RegistryFriendlyByteBuf, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($IContainerFactory<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "create": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
