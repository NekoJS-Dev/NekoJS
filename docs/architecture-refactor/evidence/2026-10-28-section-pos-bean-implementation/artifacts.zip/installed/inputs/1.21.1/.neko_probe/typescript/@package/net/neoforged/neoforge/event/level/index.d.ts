import { $EnumSet, $List } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $UseOnContext } from "java:net/minecraft/world/item/context";
import { $Explosion, $Level, $LevelAccessor } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $ChunkAccess } from "java:net/minecraft/world/level/chunk";
import { $PortalShape } from "java:net/minecraft/world/level/portal";
import { $Event, $ICancellableEvent } from "java:net/neoforged/bus/api";
import { $ItemAbility } from "java:net/neoforged/neoforge/common";
import { $BlockSnapshot } from "java:net/neoforged/neoforge/common/util";

declare module "java:net/neoforged/neoforge/event/level" {
    export class $BlockEvent extends $Event {
        constructor(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $BlockState_);
        get level(): $LevelAccessor;
        getLevel(): $LevelAccessor;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
    }

    export class $BlockEvent$BlockToolModificationEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $BlockState_, arg1: $UseOnContext, arg2: $ItemAbility, arg3: boolean);
        get context(): $UseOnContext;
        getContext(): $UseOnContext;
        get finalState(): $BlockState;
        getFinalState(): $BlockState;
        set finalState(value: $BlockState_);
        get heldItemStack(): $ItemStack;
        getHeldItemStack(): $ItemStack;
        get itemAbility(): $ItemAbility;
        getItemAbility(): $ItemAbility;
        get player(): $Player;
        getPlayer(): $Player;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        get simulated(): boolean;
        isSimulated(): boolean;
        setCanceled(arg0: boolean): void;
        setFinalState(arg0: $BlockState_): void;
    }

    export class $BlockEvent$EntityMultiPlaceEvent extends $BlockEvent$EntityPlaceEvent implements $ICancellableEvent {
        constructor(arg0: ($List<$BlockSnapshot> | ($BlockSnapshot)[]), arg1: $BlockState_, arg2: $Entity);
        get replacedBlockSnapshots(): $List<$BlockSnapshot>;
        getReplacedBlockSnapshots(): $List<$BlockSnapshot>;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $BlockEvent$EntityPlaceEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $BlockSnapshot, arg1: $BlockState_, arg2: $Entity);
        get blockSnapshot(): $BlockSnapshot;
        getBlockSnapshot(): $BlockSnapshot;
        get entity(): $Entity;
        getEntity(): $Entity;
        get placedAgainst(): $BlockState;
        getPlacedAgainst(): $BlockState;
        get placedBlock(): $BlockState;
        getPlacedBlock(): $BlockState;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $BlockEvent$FarmlandTrampleEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: number, arg4: $Entity);
        get entity(): $Entity;
        getEntity(): $Entity;
        get fallDistance(): number;
        getFallDistance(): number;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $BlockEvent$FluidPlaceBlockEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $BlockState_);
        get liquidPos(): $BlockPos;
        getLiquidPos(): $BlockPos;
        get newState(): $BlockState;
        getNewState(): $BlockState;
        set newState(value: $BlockState_);
        get originalState(): $BlockState;
        getOriginalState(): $BlockState;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
        setNewState(arg0: $BlockState_): void;
    }

    export class $BlockEvent$NeighborNotifyEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: $EnumSet<$Direction>, arg4: boolean);
        get forceRedstoneUpdate(): boolean;
        getForceRedstoneUpdate(): boolean;
        get notifiedSides(): $EnumSet<$Direction>;
        getNotifiedSides(): $EnumSet<$Direction>;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $BlockEvent$PortalSpawnEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $BlockState_, arg3: $PortalShape);
        get portalSize(): $PortalShape;
        getPortalSize(): $PortalShape;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $ChunkEvent extends $LevelEvent {
        constructor(arg0: $ChunkAccess);
        constructor(arg0: $ChunkAccess, arg1: $LevelAccessor);
        get chunk(): $ChunkAccess;
        getChunk(): $ChunkAccess;
    }

    export class $ChunkEvent$Unload extends $ChunkEvent {
        constructor(arg0: $ChunkAccess);
    }

    export class $ExplosionEvent extends $Event {
        constructor(arg0: $Level, arg1: $Explosion);
        get explosion(): $Explosion;
        getExplosion(): $Explosion;
        get level(): $Level;
        getLevel(): $Level;
    }

    export class $ExplosionEvent$Detonate extends $ExplosionEvent {
        constructor(arg0: $Level, arg1: $Explosion, arg2: ($List<$Entity> | ($Entity)[]));
        get affectedBlocks(): $List<$BlockPos>;
        getAffectedBlocks(): $List<$BlockPos>;
        get affectedEntities(): $List<$Entity>;
        getAffectedEntities(): $List<$Entity>;
    }

    export class $ExplosionEvent$Start extends $ExplosionEvent implements $ICancellableEvent {
        constructor(arg0: $Level, arg1: $Explosion);
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $LevelEvent extends $Event {
        constructor(arg0: $LevelAccessor);
        get level(): $LevelAccessor;
        getLevel(): $LevelAccessor;
    }

    export class $LevelEvent$Load extends $LevelEvent {
        constructor(arg0: $LevelAccessor);
    }

    export class $LevelEvent$Save extends $LevelEvent {
        constructor(arg0: $LevelAccessor);
    }

    export class $LevelEvent$Unload extends $LevelEvent {
        constructor(arg0: $LevelAccessor);
    }

}
