import { $Either } from "java:com/mojang/datafixers/util";
import { $Collection } from "java:java/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_ } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $LivingEntity, $Mob, $MobSpawnType, $MobSpawnType_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $ICancellableEvent } from "java:net/neoforged/bus/api";
import { $DamageContainer, $DamageContainer$Reduction, $DamageContainer$Reduction_ } from "java:net/neoforged/neoforge/common/damagesource";
import { $EntityEvent } from "java:net/neoforged/neoforge/event/entity";

declare module "java:net/neoforged/neoforge/event/entity/living" {
    export class $FinalizeSpawnEvent extends $MobSpawnEvent implements $ICancellableEvent {
        constructor(arg0: $Mob, arg1: $ServerLevelAccessor, arg2: number, arg3: number, arg4: number, arg5: $DifficultyInstance, arg6: $MobSpawnType_, arg7: $SpawnGroupData, arg8: $Either<$BlockEntity, $Entity>);
        get difficulty(): $DifficultyInstance;
        getDifficulty(): $DifficultyInstance;
        set difficulty(value: $DifficultyInstance);
        get spawnData(): $SpawnGroupData;
        getSpawnData(): $SpawnGroupData;
        set spawnData(value: $SpawnGroupData);
        get spawnType(): $MobSpawnType;
        getSpawnType(): $MobSpawnType;
        get spawner(): $Either<$BlockEntity, $Entity>;
        getSpawner(): $Either<$BlockEntity, $Entity>;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        get spawnCancelled(): boolean;
        isSpawnCancelled(): boolean;
        set spawnCancelled(value: boolean);
        setCanceled(arg0: boolean): void;
        setDifficulty(arg0: $DifficultyInstance): void;
        setSpawnCancelled(arg0: boolean): void;
        setSpawnData(arg0: $SpawnGroupData): void;
    }

    export class $LivingDamageEvent extends $LivingEvent {
    }

    export class $LivingDamageEvent$Post extends $LivingDamageEvent {
        constructor(arg0: $LivingEntity, arg1: $DamageContainer);
        get blockedDamage(): number;
        getBlockedDamage(): number;
        get newDamage(): number;
        getNewDamage(): number;
        get originalDamage(): number;
        getOriginalDamage(): number;
        get postAttackInvulnerabilityTicks(): number;
        getPostAttackInvulnerabilityTicks(): number;
        get shieldDamage(): number;
        getShieldDamage(): number;
        get source(): $DamageSource;
        getSource(): $DamageSource;
        getReduction(arg0: $DamageContainer$Reduction_): number;
    }

    export class $LivingDamageEvent$Pre extends $LivingDamageEvent {
        constructor(arg0: $LivingEntity, arg1: $DamageContainer);
        get container(): $DamageContainer;
        getContainer(): $DamageContainer;
        get newDamage(): number;
        getNewDamage(): number;
        set newDamage(value: number);
        get originalDamage(): number;
        getOriginalDamage(): number;
        get source(): $DamageSource;
        getSource(): $DamageSource;
        setNewDamage(arg0: number): void;
    }

    export class $LivingDeathEvent extends $LivingEvent implements $ICancellableEvent {
        constructor(arg0: $LivingEntity, arg1: $DamageSource);
        get source(): $DamageSource;
        getSource(): $DamageSource;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $LivingDropsEvent extends $LivingEvent implements $ICancellableEvent {
        constructor(arg0: $LivingEntity, arg1: $DamageSource, arg2: ($Collection<$ItemEntity> | ($ItemEntity)[]), arg3: boolean);
        get drops(): $Collection<$ItemEntity>;
        getDrops(): $Collection<$ItemEntity>;
        get source(): $DamageSource;
        getSource(): $DamageSource;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        get recentlyHit(): boolean;
        isRecentlyHit(): boolean;
        setCanceled(arg0: boolean): void;
    }

    export class $LivingEntityUseItemEvent extends $LivingEvent {
        get duration(): number;
        getDuration(): number;
        set duration(value: number);
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        setDuration(arg0: number): void;
    }

    export class $LivingEntityUseItemEvent$Finish extends $LivingEntityUseItemEvent {
        constructor(arg0: $LivingEntity, arg1: $ItemStack_, arg2: number, arg3: $ItemStack_);
        get resultStack(): $ItemStack;
        getResultStack(): $ItemStack;
        set resultStack(value: $ItemStack_);
        setResultStack(arg0: $ItemStack_): void;
    }

    export class $LivingEntityUseItemEvent$Start extends $LivingEntityUseItemEvent implements $ICancellableEvent {
        constructor(arg0: $LivingEntity, arg1: $ItemStack_, arg2: number);
        constructor(arg0: $LivingEntity, arg1: $ItemStack_, arg2: $InteractionHand_, arg3: number);
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $LivingEntityUseItemEvent$Stop extends $LivingEntityUseItemEvent implements $ICancellableEvent {
        constructor(arg0: $LivingEntity, arg1: $ItemStack_, arg2: number);
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $LivingEntityUseItemEvent$Tick extends $LivingEntityUseItemEvent implements $ICancellableEvent {
        constructor(arg0: $LivingEntity, arg1: $ItemStack_, arg2: number);
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

    export class $LivingEvent extends $EntityEvent {
        constructor(arg0: $LivingEntity);
        get entity(): $LivingEntity;
        getEntity(): $LivingEntity;
    }

    export class $LivingShieldBlockEvent extends $LivingEvent implements $ICancellableEvent {
        constructor(arg0: $LivingEntity, arg1: $DamageContainer, arg2: boolean);
        get blockedDamage(): number;
        getBlockedDamage(): number;
        set blockedDamage(value: number);
        get blocked(): boolean;
        getBlocked(): boolean;
        set blocked(value: boolean);
        get damageContainer(): $DamageContainer;
        getDamageContainer(): $DamageContainer;
        get damageSource(): $DamageSource;
        getDamageSource(): $DamageSource;
        get originalBlockedDamage(): number;
        getOriginalBlockedDamage(): number;
        get originalBlock(): boolean;
        getOriginalBlock(): boolean;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setBlockedDamage(arg0: number): void;
        setBlocked(arg0: boolean): void;
        setCanceled(arg0: boolean): void;
        setShieldDamage(arg0: number): void;
        shieldDamage(): number;
    }

    export class $MobSpawnEvent extends $EntityEvent {
        get entity(): $Mob;
        getEntity(): $Mob;
        get level(): $ServerLevelAccessor;
        getLevel(): $ServerLevelAccessor;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
    }

}
