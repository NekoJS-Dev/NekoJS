import { $DoubleList } from "java:it/unimi/dsi/fastutil/doubles";
import { $List, $Optional } from "java:java/util";
import { $AxisCycle, $AxisCycle_, $BlockPos, $BlockPos_, $Direction, $Direction$Axis, $Direction$Axis_, $Direction_ } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Item, $Item_ } from "java:net/minecraft/world/item";
import { $FluidState } from "java:net/minecraft/world/level/material";
import { $AABB, $BlockHitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/phys/shapes" {
    export interface $CollisionContext {
        canStandOnFluid(arg0: $FluidState, arg1: $FluidState): boolean;
        isAbove(arg0: $VoxelShape, arg1: $BlockPos_, arg2: boolean): boolean;
        isDescending(): boolean;
        isHoldingItem(arg0: $Item_): boolean;
    }
    export const $CollisionContext: {
        empty(): $CollisionContext;
        of(arg0: $Entity): $CollisionContext;
    };

    export class $DiscreteVoxelShape {
        get xSize(): number;
        getXSize(): number;
        get ySize(): number;
        getYSize(): number;
        get zSize(): number;
        getZSize(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        fill(arg0: number, arg1: number, arg2: number): void;
        firstFull(arg0: $Direction$Axis_, arg1: number, arg2: number): number;
        firstFull(arg0: $Direction$Axis_): number;
        forAllBoxes(arg0: $DiscreteVoxelShape$IntLineConsumer_<number, number, number, number, number, number>, arg1: boolean): void;
        forAllEdges(arg0: $DiscreteVoxelShape$IntLineConsumer_<number, number, number, number, number, number>, arg1: boolean): void;
        forAllFaces(arg0: $DiscreteVoxelShape$IntFaceConsumer_<$Direction, number, number, number>): void;
        getSize(arg0: $Direction$Axis_): number;
        isFullWide(arg0: number, arg1: number, arg2: number): boolean;
        isFullWide(arg0: $AxisCycle_, arg1: number, arg2: number, arg3: number): boolean;
        isFull(arg0: number, arg1: number, arg2: number): boolean;
        isFull(arg0: $AxisCycle_, arg1: number, arg2: number, arg3: number): boolean;
        lastFull(arg0: $Direction$Axis_, arg1: number, arg2: number): number;
        lastFull(arg0: $Direction$Axis_): number;
    }

    export interface $DiscreteVoxelShape$IntFaceConsumer {
        consume(arg0: $Direction_, arg1: number, arg2: number, arg3: number): void;
    }

    export interface $DiscreteVoxelShape$IntLineConsumer {
        consume(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): void;
    }

    export interface $Shapes$DoubleLineConsumer {
        consume(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): void;
    }

    export class $VoxelShape {
        get empty(): boolean;
        isEmpty(): boolean;
        bounds(): $AABB;
        clip(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_): $BlockHitResult;
        closestPointTo(arg0: $Vec3_): $Optional<$Vec3>;
        collide(arg0: $Direction$Axis_, arg1: $AABB, arg2: number): number;
        forAllBoxes(arg0: $Shapes$DoubleLineConsumer_<number, number, number, number, number, number>): void;
        forAllEdges(arg0: $Shapes$DoubleLineConsumer_<number, number, number, number, number, number>): void;
        getCoords(arg0: $Direction$Axis_): $DoubleList;
        getFaceShape(arg0: $Direction_): $VoxelShape;
        max(arg0: $Direction$Axis_, arg1: number, arg2: number): number;
        max(arg0: $Direction$Axis_): number;
        min(arg0: $Direction$Axis_, arg1: number, arg2: number): number;
        min(arg0: $Direction$Axis_): number;
        move(arg0: number, arg1: number, arg2: number): $VoxelShape;
        optimize(): $VoxelShape;
        singleEncompassing(): $VoxelShape;
        toAabbs(): $List<$AABB>;
        toString(): string;
    }

    export type $DiscreteVoxelShape$IntFaceConsumer_<CallbackArg0 = $Direction, CallbackArg1 = number, CallbackArg2 = number, CallbackArg3 = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => void) | ($DiscreteVoxelShape$IntFaceConsumer & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "consume": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $DiscreteVoxelShape$IntLineConsumer_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackArg3 = number, CallbackArg4 = number, CallbackArg5 = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4, arg5: CallbackArg5) => void) | ($DiscreteVoxelShape$IntLineConsumer & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "consume": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4, arg5: CallbackArg5) => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Shapes$DoubleLineConsumer_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackArg3 = number, CallbackArg4 = number, CallbackArg5 = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4, arg5: CallbackArg5) => void) | ($Shapes$DoubleLineConsumer & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "consume": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4, arg5: CallbackArg5) => void } & { readonly [Symbol.hasInstance]?: never }>);
}
