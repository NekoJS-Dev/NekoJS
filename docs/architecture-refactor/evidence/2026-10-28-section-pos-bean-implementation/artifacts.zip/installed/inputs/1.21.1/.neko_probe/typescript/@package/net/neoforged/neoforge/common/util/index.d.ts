import { $Enum } from "java:java/lang";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $Tag } from "java:net/minecraft/nbt";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $Level, $LevelAccessor } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";

declare module "java:net/neoforged/neoforge/common/util" {
    export class $BlockSnapshot {
        get currentState(): $BlockState;
        getCurrentState(): $BlockState;
        get dimension(): $ResourceKey<$Level>;
        getDimension(): $ResourceKey<$Level>;
        get flags(): number;
        getFlags(): number;
        get level(): $LevelAccessor;
        getLevel(): $LevelAccessor;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
        get tag(): $CompoundTag;
        getTag(): $CompoundTag;
        static create(arg0: $ResourceKey<$Level>, arg1: $LevelAccessor, arg2: $BlockPos_, arg3: number): $BlockSnapshot;
        static create(arg0: $ResourceKey<$Level>, arg1: $LevelAccessor, arg2: $BlockPos_): $BlockSnapshot;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        recreateBlockEntity(arg0: $HolderLookup$Provider): $BlockEntity;
        restoreBlockEntity(arg0: $LevelAccessor, arg1: $BlockPos_): boolean;
        restoreToLocation(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: number): boolean;
        restore(arg0: number): boolean;
        restore(): boolean;
        toString(): string;
    }

    export interface $INBTSerializable<T extends $Tag> {
        deserializeNBT(arg0: $HolderLookup$Provider, arg1: T): void;
        serializeNBT(arg0: $HolderLookup$Provider): T;
    }

    export class $Lazy<T> implements $Supplier<T> {
        static of<T>(arg0: $Supplier_<T, T>): $Lazy<T>;
        get(): T;
        invalidate(): void;
    }

    export class $TriState {
        static DEFAULT: $TriState;
        static FALSE: $TriState;
        static TRUE: $TriState;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TriState[];
        static valueOf(name: string): $TriState;
    }
    export interface $TriState extends $Enum<$TriState> {}

    export type $TriState_ = $TriState | "DEFAULT" | "FALSE" | "TRUE";
}
