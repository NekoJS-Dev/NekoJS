import { $Enum } from "java:java/lang";
import { $Optional, $Set } from "java:java/util";
import { $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";

declare module "java:net/minecraft/world/scores/criteria" {
    export class $ObjectiveCriteria {
        static AIR: $ObjectiveCriteria;
        static ARMOR: $ObjectiveCriteria;
        static DEATH_COUNT: $ObjectiveCriteria;
        static DUMMY: $ObjectiveCriteria;
        static EXPERIENCE: $ObjectiveCriteria;
        static FOOD: $ObjectiveCriteria;
        static HEALTH: $ObjectiveCriteria;
        static KILLED_BY_TEAM: $ObjectiveCriteria[];
        static KILL_COUNT_ALL: $ObjectiveCriteria;
        static KILL_COUNT_PLAYERS: $ObjectiveCriteria;
        static LEVEL: $ObjectiveCriteria;
        static TEAM_KILL: $ObjectiveCriteria[];
        static TRIGGER: $ObjectiveCriteria;
        get defaultRenderType(): $ObjectiveCriteria$RenderType;
        getDefaultRenderType(): $ObjectiveCriteria$RenderType;
        get name(): string;
        getName(): string;
        get readOnly(): boolean;
        isReadOnly(): boolean;
        static byName(arg0: string): $Optional<$ObjectiveCriteria>;
        static getCustomCriteriaNames(): $Set<string>;
    }

    export class $ObjectiveCriteria$RenderType {
        static HEARTS: $ObjectiveCriteria$RenderType;
        static INTEGER: $ObjectiveCriteria$RenderType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ObjectiveCriteria$RenderType[];
        static valueOf(name: string): $ObjectiveCriteria$RenderType;
    }
    export interface $ObjectiveCriteria$RenderType extends $Enum<$ObjectiveCriteria$RenderType>, $StringRepresentable {}

    export type $ObjectiveCriteria$RenderType_ = $ObjectiveCriteria$RenderType | "HEARTS" | "INTEGER";
}
