import { $Serializable } from "java:java/io";
import { $Throwable } from "java:java/lang";
import { $Iterator } from "java:java/util";
import { $Level, $Level_ } from "java:org/slf4j/event";
import { $LoggingEventBuilder } from "java:org/slf4j/spi";

export * as event from "java:org/slf4j/event";
export * as spi from "java:org/slf4j/spi";

declare module "java:org/slf4j" {
    export interface $Logger {
        atDebug(): $LoggingEventBuilder;
        atError(): $LoggingEventBuilder;
        atInfo(): $LoggingEventBuilder;
        atLevel(arg0: $Level_): $LoggingEventBuilder;
        atTrace(): $LoggingEventBuilder;
        atWarn(): $LoggingEventBuilder;
        debug(arg0: string, arg1?: unknown[]): void;
        debug(arg0: string, arg1: unknown, arg2: unknown): void;
        debug(arg0: string, arg1: unknown): void;
        debug(arg0: string, arg1: $Throwable): void;
        debug(arg0: string): void;
        debug(arg0: $Marker, arg1: string, arg2?: unknown[]): void;
        debug(arg0: $Marker, arg1: string, arg2: unknown, arg3: unknown): void;
        debug(arg0: $Marker, arg1: string, arg2: unknown): void;
        debug(arg0: $Marker, arg1: string, arg2: $Throwable): void;
        debug(arg0: $Marker, arg1: string): void;
        error(arg0: string, arg1?: unknown[]): void;
        error(arg0: string, arg1: unknown, arg2: unknown): void;
        error(arg0: string, arg1: unknown): void;
        error(arg0: string, arg1: $Throwable): void;
        error(arg0: string): void;
        error(arg0: $Marker, arg1: string, arg2?: unknown[]): void;
        error(arg0: $Marker, arg1: string, arg2: unknown, arg3: unknown): void;
        error(arg0: $Marker, arg1: string, arg2: unknown): void;
        error(arg0: $Marker, arg1: string, arg2: $Throwable): void;
        error(arg0: $Marker, arg1: string): void;
        getName(): string;
        info(arg0: string, arg1?: unknown[]): void;
        info(arg0: string, arg1: unknown, arg2: unknown): void;
        info(arg0: string, arg1: unknown): void;
        info(arg0: string, arg1: $Throwable): void;
        info(arg0: string): void;
        info(arg0: $Marker, arg1: string, arg2?: unknown[]): void;
        info(arg0: $Marker, arg1: string, arg2: unknown, arg3: unknown): void;
        info(arg0: $Marker, arg1: string, arg2: unknown): void;
        info(arg0: $Marker, arg1: string, arg2: $Throwable): void;
        info(arg0: $Marker, arg1: string): void;
        isDebugEnabled(arg0: $Marker): boolean;
        isDebugEnabled(): boolean;
        isEnabledForLevel(arg0: $Level_): boolean;
        isErrorEnabled(arg0: $Marker): boolean;
        isErrorEnabled(): boolean;
        isInfoEnabled(arg0: $Marker): boolean;
        isInfoEnabled(): boolean;
        isTraceEnabled(arg0: $Marker): boolean;
        isTraceEnabled(): boolean;
        isWarnEnabled(arg0: $Marker): boolean;
        isWarnEnabled(): boolean;
        makeLoggingEventBuilder(arg0: $Level_): $LoggingEventBuilder;
        trace(arg0: string, arg1?: unknown[]): void;
        trace(arg0: string, arg1: unknown, arg2: unknown): void;
        trace(arg0: string, arg1: unknown): void;
        trace(arg0: string, arg1: $Throwable): void;
        trace(arg0: string): void;
        trace(arg0: $Marker, arg1: string, arg2?: unknown[]): void;
        trace(arg0: $Marker, arg1: string, arg2: unknown, arg3: unknown): void;
        trace(arg0: $Marker, arg1: string, arg2: unknown): void;
        trace(arg0: $Marker, arg1: string, arg2: $Throwable): void;
        trace(arg0: $Marker, arg1: string): void;
        warn(arg0: string, arg1?: unknown[]): void;
        warn(arg0: string, arg1: unknown, arg2: unknown): void;
        warn(arg0: string, arg1: unknown): void;
        warn(arg0: string, arg1: $Throwable): void;
        warn(arg0: string): void;
        warn(arg0: $Marker, arg1: string, arg2?: unknown[]): void;
        warn(arg0: $Marker, arg1: string, arg2: unknown, arg3: unknown): void;
        warn(arg0: $Marker, arg1: string, arg2: unknown): void;
        warn(arg0: $Marker, arg1: string, arg2: $Throwable): void;
        warn(arg0: $Marker, arg1: string): void;
    }
    export const $Logger: {
        readonly ROOT_LOGGER_NAME: string;
    };

    export interface $Marker extends $Serializable {
        add(arg0: $Marker): void;
        contains(arg0: string): boolean;
        contains(arg0: $Marker): boolean;
        equals(arg0: unknown): boolean;
        getName(): string;
        hasChildren(): boolean;
        hasReferences(): boolean;
        hashCode(): number;
        iterator(): $Iterator<$Marker>;
        remove(arg0: $Marker): boolean;
    }
    export const $Marker: {
        readonly ANY_MARKER: string;
        readonly ANY_NON_NULL_MARKER: string;
    };

}
