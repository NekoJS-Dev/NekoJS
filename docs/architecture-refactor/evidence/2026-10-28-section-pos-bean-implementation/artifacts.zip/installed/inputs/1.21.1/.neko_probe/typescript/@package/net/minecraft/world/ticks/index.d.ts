import { $Hash$Strategy } from "java:it/unimi/dsi/fastutil";
import { $Enum, $Record } from "java:java/lang";
import { $Comparator, $Comparator_, $List, $Optional } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $Consumer, $Consumer_, $Function, $Function_, $LongPredicate, $LongPredicate_, $Predicate, $Predicate_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Vec3i } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $ListTag, $Tag } from "java:net/minecraft/nbt";
import { $ProfilerFiller } from "java:net/minecraft/util/profiling";
import { $Container } from "java:net/minecraft/world";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";

declare module "java:net/minecraft/world/ticks" {
    export interface $ContainerSingleItem extends $Container {
        clearContent(): void;
        getContainerSize(): number;
        getItem(arg0: number): $ItemStack;
        getTheItem(): $ItemStack;
        isEmpty(): boolean;
        removeItemNoUpdate(arg0: number): $ItemStack;
        removeItem(arg0: number, arg1: number): $ItemStack;
        removeTheItem(): $ItemStack;
        setItem(arg0: number, arg1: $ItemStack_): void;
        setTheItem(arg0: $ItemStack_): void;
        splitTheItem(arg0: number): $ItemStack;
    }

    export interface $ContainerSingleItem$BlockContainerSingleItem extends $ContainerSingleItem {
        getContainerBlockEntity(): $BlockEntity;
        stillValid(arg0: $Player): boolean;
    }

    export class $LevelChunkTicks<T> implements $SerializableTickContainer<T>, $TickContainerAccess<T> {
        constructor();
        constructor(arg0: ($List<$SavedTick<T>> | ($SavedTick<T>)[]));
        get all(): $Stream<$ScheduledTick<T>>;
        getAll(): $Stream<$ScheduledTick<T>>;
        static load<T>(arg0: $ListTag, arg1: $Function_<string, $Optional<T>, string, $Optional<T>>, arg2: $ChunkPos): $LevelChunkTicks<T>;
        count(): number;
        hasScheduledTick(arg0: $BlockPos_, arg1: T): boolean;
        peek(): $ScheduledTick<T>;
        poll(): $ScheduledTick<T>;
        removeIf(arg0: $Predicate_<$ScheduledTick<T>, $ScheduledTick<T>, boolean>): void;
        save(arg0: number, arg1: $Function_<T, string, T, string>): $ListTag;
        save(arg0: number, arg1: $Function_<any, any, any, any>): $Tag;
        schedule(arg0: $ScheduledTick<T>): void;
        setOnTickAdded(arg0: $BiConsumer_<$LevelChunkTicks<T>, $ScheduledTick<T>, $LevelChunkTicks<T>, $ScheduledTick<T>>): void;
        unpack(arg0: number): void;
    }

    export interface $LevelTickAccess<T> extends $TickAccess<T> {
        willTickThisTick(arg0: $BlockPos_, arg1: T): boolean;
    }

    export class $LevelTicks<T> implements $LevelTickAccess<T> {
        constructor(arg0: $LongPredicate_<number, boolean>, arg1: $Supplier_<$ProfilerFiller, $ProfilerFiller>);
        addContainer(arg0: $ChunkPos, arg1: $LevelChunkTicks<T>): void;
        clearArea(arg0: $BoundingBox): void;
        copyAreaFrom(arg0: $LevelTicks<T>, arg1: $BoundingBox, arg2: $Vec3i): void;
        copyArea(arg0: $BoundingBox, arg1: $Vec3i): void;
        count(): number;
        hasScheduledTick(arg0: $BlockPos_, arg1: T): boolean;
        removeContainer(arg0: $ChunkPos): void;
        schedule(arg0: $ScheduledTick<T>): void;
        tick(arg0: number, arg1: number, arg2: $BiConsumer_<$BlockPos, T, $BlockPos, T>): void;
        willTickThisTick(arg0: $BlockPos_, arg1: T): boolean;
    }

    export class $ProtoChunkTicks<T> implements $SerializableTickContainer<T>, $TickContainerAccess<T> {
        constructor();
        static load<T>(arg0: $ListTag, arg1: $Function_<string, $Optional<T>, string, $Optional<T>>, arg2: $ChunkPos): $ProtoChunkTicks<T>;
        count(): number;
        hasScheduledTick(arg0: $BlockPos_, arg1: T): boolean;
        save(arg0: number, arg1: $Function_<T, string, T, string>): $Tag;
        scheduledTicks(): $List<$SavedTick<T>>;
        schedule(arg0: $ScheduledTick<T>): void;
    }

    export class $SavedTick<T> extends $Record {
        constructor(arg0: T, arg1: $BlockPos_, arg2: number, arg3: $TickPriority_);
        static UNIQUE_TICK_HASH: $Hash$Strategy<$SavedTick<any>>;
        static loadTickList<T>(arg0: $ListTag, arg1: $Function_<string, $Optional<T>, string, $Optional<T>>, arg2: $ChunkPos, arg3: $Consumer_<$SavedTick<T>, $SavedTick<T>>): void;
        static loadTick<T>(arg0: $CompoundTag_, arg1: $Function_<string, $Optional<T>, string, $Optional<T>>): $Optional<$SavedTick<T>>;
        static probe<T>(arg0: T, arg1: $BlockPos_): $SavedTick<T>;
        static saveTick<T>(arg0: $ScheduledTick<T>, arg1: $Function_<T, string, T, string>, arg2: number): $CompoundTag;
        delay(): number;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        pos(): $BlockPos;
        priority(): $TickPriority;
        save(arg0: $Function_<T, string, T, string>): $CompoundTag;
        toString(): string;
        type(): T;
        unpack(arg0: number, arg1: number): $ScheduledTick<T>;
    }

    export class $ScheduledTick<T> extends $Record {
        constructor(arg0: T, arg1: $BlockPos_, arg2: number, arg3: number);
        constructor(arg0: T, arg1: $BlockPos_, arg2: number, arg3: $TickPriority_, arg4: number);
        static DRAIN_ORDER: $Comparator<$ScheduledTick<any>>;
        static INTRA_TICK_DRAIN_ORDER: $Comparator<$ScheduledTick<any>>;
        static UNIQUE_TICK_HASH: $Hash$Strategy<$ScheduledTick<any>>;
        static probe<T>(arg0: T, arg1: $BlockPos_): $ScheduledTick<T>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        pos(): $BlockPos;
        priority(): $TickPriority;
        subTickOrder(): number;
        toString(): string;
        triggerTick(): number;
        type(): T;
    }

    export interface $SerializableTickContainer<T> {
        save(arg0: number, arg1: $Function_<T, string, T, string>): $Tag;
    }

    export interface $TickAccess<T> {
        count(): number;
        hasScheduledTick(arg0: $BlockPos_, arg1: T): boolean;
        schedule(arg0: $ScheduledTick<T>): void;
    }

    export interface $TickContainerAccess<T> extends $TickAccess<T> {
    }

    export class $TickPriority {
        static EXTREMELY_HIGH: $TickPriority;
        static EXTREMELY_LOW: $TickPriority;
        static HIGH: $TickPriority;
        static LOW: $TickPriority;
        static NORMAL: $TickPriority;
        static VERY_HIGH: $TickPriority;
        static VERY_LOW: $TickPriority;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TickPriority[];
        static valueOf(name: string): $TickPriority;
    }
    export interface $TickPriority extends $Enum<$TickPriority> {}

    export type $SerializableTickContainer_<Host0 = any, CallbackArg0 = number, CallbackArg1 = $Function<Host0, string>, CallbackResult = $Tag> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($SerializableTickContainer<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "save": (arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $TickPriority_ = $TickPriority | "EXTREMELY_HIGH" | "EXTREMELY_LOW" | "HIGH" | "LOW" | "NORMAL" | "VERY_HIGH" | "VERY_LOW";
}
