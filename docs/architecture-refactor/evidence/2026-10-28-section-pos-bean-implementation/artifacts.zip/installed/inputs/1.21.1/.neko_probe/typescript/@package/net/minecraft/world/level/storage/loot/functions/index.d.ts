import { $MapCodec } from "java:com/mojang/serialization";
import { $Iterable, $Record } from "java:java/lang";
import { $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function, $Function_ } from "java:java/util/function";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LootContext, $LootContextUser } from "java:net/minecraft/world/level/storage/loot";

declare module "java:net/minecraft/world/level/storage/loot/functions" {
    export interface $FunctionUserBuilder<T extends $FunctionUserBuilder<T>> {
        apply<E>(arg0: E[], arg1: $Function_<E, $LootItemFunction$Builder, E, $LootItemFunction$Builder_<$LootItemFunction>>): T;
        apply<E>(arg0: ($Iterable<E> | (E)[]), arg1: $Function_<E, $LootItemFunction$Builder, E, $LootItemFunction$Builder_<$LootItemFunction>>): T;
        apply(arg0: $LootItemFunction$Builder_<$LootItemFunction>): T;
        unwrap(): T;
    }

    export interface $LootItemFunction extends $LootContextUser, $BiFunction<$ItemStack, $LootContext, $ItemStack> {
        getType(): $LootItemFunctionType<$LootItemFunction>;
    }
    export const $LootItemFunction: {
        decorate(arg0: $BiFunction_<$ItemStack, $LootContext, $ItemStack, $ItemStack, $LootContext, $ItemStack_>, arg1: $Consumer_<$ItemStack, $ItemStack>, arg2: $LootContext): $Consumer<$ItemStack>;
    };

    export interface $LootItemFunction$Builder {
        build(): $LootItemFunction;
    }

    export class $LootItemFunctionType<T extends $LootItemFunction> extends $Record {
        constructor(arg0: $MapCodec<T>);
        codec(): $MapCodec<T>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export type $LootItemFunction$Builder_<CallbackResult = $LootItemFunction> = (() => CallbackResult) | ($LootItemFunction$Builder & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "build": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
