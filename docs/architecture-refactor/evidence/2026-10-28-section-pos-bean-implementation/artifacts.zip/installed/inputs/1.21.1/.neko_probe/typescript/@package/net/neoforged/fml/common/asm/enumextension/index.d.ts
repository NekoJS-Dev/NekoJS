import { $Class, $Enum, $Record } from "java:java/lang";

declare module "java:net/neoforged/fml/common/asm/enumextension" {
    export class $ExtensionInfo extends $Record {
        constructor(extended: boolean, vanillaCount: number, totalCount: number, netCheck: $NetworkedEnum$NetworkCheck_);
        static nonExtended<T extends ($Enum<T>) & ($IExtensibleEnum)>(arg0: $Class<T>): $ExtensionInfo;
        equals(arg0: unknown): boolean;
        extended(): boolean;
        hashCode(): number;
        netCheck(): $NetworkedEnum$NetworkCheck;
        toString(): string;
        totalCount(): number;
        vanillaCount(): number;
    }

    export interface $IExtensibleEnum {
    }

    export class $NetworkedEnum$NetworkCheck {
        static BIDIRECTIONAL: $NetworkedEnum$NetworkCheck;
        static CLIENTBOUND: $NetworkedEnum$NetworkCheck;
        static SERVERBOUND: $NetworkedEnum$NetworkCheck;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $NetworkedEnum$NetworkCheck[];
        static valueOf(name: string): $NetworkedEnum$NetworkCheck;
    }
    export interface $NetworkedEnum$NetworkCheck extends $Enum<$NetworkedEnum$NetworkCheck> {}

    export type $NetworkedEnum$NetworkCheck_ = $NetworkedEnum$NetworkCheck | "BIDIRECTIONAL" | "CLIENTBOUND" | "SERVERBOUND";
}
