import { $File } from "java:java/io";
import { $Record } from "java:java/lang";
import { $BiFunction, $BiFunction_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $DataFixTypes, $DataFixTypes_ } from "java:net/minecraft/util/datafix";

export * as maps from "java:net/minecraft/world/level/saveddata/maps";

declare module "java:net/minecraft/world/level/saveddata" {
    export class $SavedData {
        constructor();
        get dirty(): boolean;
        isDirty(): boolean;
        set dirty(value: boolean);
        save(arg0: $File, arg1: $HolderLookup$Provider): void;
        save(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): $CompoundTag;
        setDirty(arg0: boolean): void;
        setDirty(): void;
    }

    export class $SavedData$Factory<T extends $SavedData> extends $Record {
        constructor(arg0: $Supplier_<T, T>, arg1: $BiFunction_<$CompoundTag, $HolderLookup$Provider, T, $CompoundTag, $HolderLookup$Provider, T>);
        constructor(constructor: $Supplier_<T, T>, deserializer: $BiFunction_<$CompoundTag, $HolderLookup$Provider, T, $CompoundTag, $HolderLookup$Provider, T>, type: $DataFixTypes_);
        ["constructor"](): $Supplier<T>;
        deserializer(): $BiFunction<$CompoundTag, $HolderLookup$Provider, T>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
        type(): $DataFixTypes;
    }

}
