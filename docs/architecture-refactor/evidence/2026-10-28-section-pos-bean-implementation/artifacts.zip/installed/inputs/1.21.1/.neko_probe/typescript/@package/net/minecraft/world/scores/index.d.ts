import { $GameProfile } from "java:com/mojang/authlib";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $File } from "java:java/io";
import { $Enum, $Record } from "java:java/lang";
import { $Collection } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Component, $Component_, $MutableComponent } from "java:net/minecraft/network/chat";
import { $NumberFormat } from "java:net/minecraft/network/chat/numbers";
import { $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $SavedData } from "java:net/minecraft/world/level/saveddata";
import { $ObjectiveCriteria, $ObjectiveCriteria$RenderType, $ObjectiveCriteria$RenderType_ } from "java:net/minecraft/world/scores/criteria";

export * as criteria from "java:net/minecraft/world/scores/criteria";

declare module "java:net/minecraft/world/scores" {
    export class $DisplaySlot {
        static BELOW_NAME: $DisplaySlot;
        static LIST: $DisplaySlot;
        static SIDEBAR: $DisplaySlot;
        static TEAM_AQUA: $DisplaySlot;
        static TEAM_BLACK: $DisplaySlot;
        static TEAM_BLUE: $DisplaySlot;
        static TEAM_DARK_AQUA: $DisplaySlot;
        static TEAM_DARK_BLUE: $DisplaySlot;
        static TEAM_DARK_GRAY: $DisplaySlot;
        static TEAM_DARK_GREEN: $DisplaySlot;
        static TEAM_DARK_PURPLE: $DisplaySlot;
        static TEAM_DARK_RED: $DisplaySlot;
        static TEAM_GOLD: $DisplaySlot;
        static TEAM_GRAY: $DisplaySlot;
        static TEAM_GREEN: $DisplaySlot;
        static TEAM_LIGHT_PURPLE: $DisplaySlot;
        static TEAM_RED: $DisplaySlot;
        static TEAM_WHITE: $DisplaySlot;
        static TEAM_YELLOW: $DisplaySlot;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DisplaySlot[];
        static valueOf(name: string): $DisplaySlot;
    }
    export interface $DisplaySlot extends $Enum<$DisplaySlot>, $StringRepresentable {}

    export class $Objective {
        constructor(arg0: $Scoreboard, arg1: string, arg2: $ObjectiveCriteria, arg3: $Component_, arg4: $ObjectiveCriteria$RenderType_, arg5: boolean, arg6: $NumberFormat);
        get criteria(): $ObjectiveCriteria;
        getCriteria(): $ObjectiveCriteria;
        get displayName(): $Component;
        getDisplayName(): $Component;
        set displayName(value: $Component_);
        get formattedDisplayName(): $Component;
        getFormattedDisplayName(): $Component;
        get name(): string;
        getName(): string;
        get renderType(): $ObjectiveCriteria$RenderType;
        getRenderType(): $ObjectiveCriteria$RenderType;
        set renderType(value: $ObjectiveCriteria$RenderType_);
        get scoreboard(): $Scoreboard;
        getScoreboard(): $Scoreboard;
        displayAutoUpdate(): boolean;
        numberFormatOrDefault(arg0: $NumberFormat): $NumberFormat;
        numberFormat(): $NumberFormat;
        setDisplayAutoUpdate(arg0: boolean): void;
        setDisplayName(arg0: $Component_): void;
        setNumberFormat(arg0: $NumberFormat): void;
        setRenderType(arg0: $ObjectiveCriteria$RenderType_): void;
    }

    export class $PlayerScoreEntry extends $Record {
        constructor(arg0: string, arg1: number, arg2: $Component_, arg3: $NumberFormat);
        get hidden(): boolean;
        isHidden(): boolean;
        display(): $Component;
        equals(arg0: unknown): boolean;
        formatValue(arg0: $NumberFormat): $MutableComponent;
        hashCode(): number;
        numberFormatOverride(): $NumberFormat;
        ownerName(): $Component;
        owner(): string;
        toString(): string;
        value(): number;
    }

    export class $PlayerTeam extends $Team {
        constructor(arg0: $Scoreboard, arg1: string);
        get collisionRule(): $Team$CollisionRule;
        getCollisionRule(): $Team$CollisionRule;
        set collisionRule(value: $Team$CollisionRule_);
        get color(): $ChatFormatting;
        getColor(): $ChatFormatting;
        set color(value: $ChatFormatting_);
        get deathMessageVisibility(): $Team$Visibility;
        getDeathMessageVisibility(): $Team$Visibility;
        set deathMessageVisibility(value: $Team$Visibility_);
        get displayName(): $Component;
        getDisplayName(): $Component;
        set displayName(value: $Component_);
        get formattedDisplayName(): $MutableComponent;
        getFormattedDisplayName(): $MutableComponent;
        get nameTagVisibility(): $Team$Visibility;
        getNameTagVisibility(): $Team$Visibility;
        set nameTagVisibility(value: $Team$Visibility_);
        get name(): string;
        getName(): string;
        get playerPrefix(): $Component;
        getPlayerPrefix(): $Component;
        set playerPrefix(value: $Component_);
        get playerSuffix(): $Component;
        getPlayerSuffix(): $Component;
        set playerSuffix(value: $Component_);
        get players(): $Collection<string>;
        getPlayers(): $Collection<string>;
        get scoreboard(): $Scoreboard;
        getScoreboard(): $Scoreboard;
        get allowFriendlyFire(): boolean;
        isAllowFriendlyFire(): boolean;
        set allowFriendlyFire(value: boolean);
        static formatNameForTeam(arg0: $Team, arg1: $Component_): $MutableComponent;
        canSeeFriendlyInvisibles(): boolean;
        getFormattedName(arg0: $Component_): $MutableComponent;
        packOptions(): number;
        setAllowFriendlyFire(arg0: boolean): void;
        setCollisionRule(arg0: $Team$CollisionRule_): void;
        setColor(arg0: $ChatFormatting_): void;
        setDeathMessageVisibility(arg0: $Team$Visibility_): void;
        setDisplayName(arg0: $Component_): void;
        setNameTagVisibility(arg0: $Team$Visibility_): void;
        setPlayerPrefix(arg0: $Component_): void;
        setPlayerSuffix(arg0: $Component_): void;
        setSeeFriendlyInvisibles(arg0: boolean): void;
        unpackOptions(arg0: number): void;
    }

    export interface $ReadOnlyScoreInfo {
        formatValue(arg0: $NumberFormat): $MutableComponent;
        isLocked(): boolean;
        numberFormat(): $NumberFormat;
        value(): number;
    }
    export const $ReadOnlyScoreInfo: {
        safeFormatValue(arg0: $ReadOnlyScoreInfo, arg1: $NumberFormat): $MutableComponent;
    };

    export interface $ScoreAccess {
        add(arg0: number): number;
        display(arg0: $Component_): void;
        display(): $Component;
        get(): number;
        increment(): number;
        locked(): boolean;
        lock(): void;
        numberFormatOverride(arg0: $NumberFormat): void;
        reset(): void;
        set(arg0: number): void;
        unlock(): void;
    }

    export interface $ScoreHolder {
        getDisplayName(): $Component;
        getFeedbackDisplayName(): $Component;
        getScoreboardName(): string;
    }
    export const $ScoreHolder: {
        forNameOnly(arg0: string): $ScoreHolder;
        fromGameProfile(arg0: $GameProfile): $ScoreHolder;
        readonly WILDCARD: $ScoreHolder;
        readonly WILDCARD_NAME: string;
    };

    export class $Scoreboard {
        constructor();
        static HIDDEN_SCORE_PREFIX: string;
        get objectiveNames(): $Collection<string>;
        getObjectiveNames(): $Collection<string>;
        get objectives(): $Collection<$Objective>;
        getObjectives(): $Collection<$Objective>;
        get playerTeams(): $Collection<$PlayerTeam>;
        getPlayerTeams(): $Collection<$PlayerTeam>;
        get teamNames(): $Collection<string>;
        getTeamNames(): $Collection<string>;
        get trackedPlayers(): $Collection<$ScoreHolder>;
        getTrackedPlayers(): $Collection<$ScoreHolder>;
        addObjective(arg0: string, arg1: $ObjectiveCriteria, arg2: $Component_, arg3: $ObjectiveCriteria$RenderType_, arg4: boolean, arg5: $NumberFormat): $Objective;
        addPlayerTeam(arg0: string): $PlayerTeam;
        addPlayerToTeam(arg0: string, arg1: $PlayerTeam): boolean;
        entityRemoved(arg0: $Entity): void;
        forAllObjectives(arg0: $ObjectiveCriteria, arg1: $ScoreHolder_<string>, arg2: $Consumer_<$ScoreAccess, $ScoreAccess>): void;
        getDisplayObjective(arg0: $DisplaySlot_): $Objective;
        getObjective(arg0: string): $Objective;
        getOrCreatePlayerScore(arg0: $ScoreHolder_<string>, arg1: $Objective, arg2: boolean): $ScoreAccess;
        getOrCreatePlayerScore(arg0: $ScoreHolder_<string>, arg1: $Objective): $ScoreAccess;
        getPlayerScoreInfo(arg0: $ScoreHolder_<string>, arg1: $Objective): $ReadOnlyScoreInfo;
        getPlayerTeam(arg0: string): $PlayerTeam;
        getPlayersTeam(arg0: string): $PlayerTeam;
        listPlayerScores(arg0: $Objective): $Collection<$PlayerScoreEntry>;
        listPlayerScores(arg0: $ScoreHolder_<string>): $Object2IntMap<$Objective>;
        onObjectiveAdded(arg0: $Objective): void;
        onObjectiveChanged(arg0: $Objective): void;
        onObjectiveRemoved(arg0: $Objective): void;
        onPlayerRemoved(arg0: $ScoreHolder_<string>): void;
        onPlayerScoreRemoved(arg0: $ScoreHolder_<string>, arg1: $Objective): void;
        onTeamAdded(arg0: $PlayerTeam): void;
        onTeamChanged(arg0: $PlayerTeam): void;
        onTeamRemoved(arg0: $PlayerTeam): void;
        removeObjective(arg0: $Objective): void;
        removePlayerFromTeam(arg0: string, arg1: $PlayerTeam): void;
        removePlayerFromTeam(arg0: string): boolean;
        removePlayerTeam(arg0: $PlayerTeam): void;
        resetAllPlayerScores(arg0: $ScoreHolder_<string>): void;
        resetSinglePlayerScore(arg0: $ScoreHolder_<string>, arg1: $Objective): void;
        setDisplayObjective(arg0: $DisplaySlot_, arg1: $Objective): void;
    }

    export class $ScoreboardSaveData extends $SavedData {
        constructor(arg0: $Scoreboard);
        static FILE_ID: string;
        load(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): $ScoreboardSaveData;
        save(arg0: $File, arg1: $HolderLookup$Provider): void;
        save(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): $CompoundTag;
    }

    export class $Team {
        constructor();
        get collisionRule(): $Team$CollisionRule;
        getCollisionRule(): $Team$CollisionRule;
        get color(): $ChatFormatting;
        getColor(): $ChatFormatting;
        get deathMessageVisibility(): $Team$Visibility;
        getDeathMessageVisibility(): $Team$Visibility;
        get nameTagVisibility(): $Team$Visibility;
        getNameTagVisibility(): $Team$Visibility;
        get name(): string;
        getName(): string;
        get players(): $Collection<string>;
        getPlayers(): $Collection<string>;
        get allowFriendlyFire(): boolean;
        isAllowFriendlyFire(): boolean;
        canSeeFriendlyInvisibles(): boolean;
        getFormattedName(arg0: $Component_): $MutableComponent;
        isAlliedTo(arg0: $Team): boolean;
    }

    export class $Team$CollisionRule {
        static ALWAYS: $Team$CollisionRule;
        static NEVER: $Team$CollisionRule;
        static PUSH_OTHER_TEAMS: $Team$CollisionRule;
        static PUSH_OWN_TEAM: $Team$CollisionRule;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Team$CollisionRule[];
        static valueOf(name: string): $Team$CollisionRule;
    }
    export interface $Team$CollisionRule extends $Enum<$Team$CollisionRule> {}

    export class $Team$Visibility {
        static ALWAYS: $Team$Visibility;
        static HIDE_FOR_OTHER_TEAMS: $Team$Visibility;
        static HIDE_FOR_OWN_TEAM: $Team$Visibility;
        static NEVER: $Team$Visibility;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Team$Visibility[];
        static valueOf(name: string): $Team$Visibility;
    }
    export interface $Team$Visibility extends $Enum<$Team$Visibility> {}

    export type $DisplaySlot_ = $DisplaySlot | "BELOW_NAME" | "LIST" | "SIDEBAR" | "TEAM_AQUA" | "TEAM_BLACK" | "TEAM_BLUE" | "TEAM_DARK_AQUA" | "TEAM_DARK_BLUE" | "TEAM_DARK_GRAY" | "TEAM_DARK_GREEN" | "TEAM_DARK_PURPLE" | "TEAM_DARK_RED" | "TEAM_GOLD" | "TEAM_GRAY" | "TEAM_GREEN" | "TEAM_LIGHT_PURPLE" | "TEAM_RED" | "TEAM_WHITE" | "TEAM_YELLOW";
    export type $ScoreHolder_<CallbackResult = string> = (() => CallbackResult) | ($ScoreHolder & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "getScoreboardName": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Team$CollisionRule_ = $Team$CollisionRule | "ALWAYS" | "NEVER" | "PUSH_OTHER_TEAMS" | "PUSH_OWN_TEAM";
    export type $Team$Visibility_ = $Team$Visibility | "ALWAYS" | "HIDE_FOR_OTHER_TEAMS" | "HIDE_FOR_OWN_TEAM" | "NEVER";
}
