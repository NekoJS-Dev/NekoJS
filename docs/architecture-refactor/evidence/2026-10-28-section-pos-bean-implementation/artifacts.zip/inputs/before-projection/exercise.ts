import { $BeanMethodProjectionTest$Child as Child } from 'java:com/tkisor/nekojs/probe';
import type { $BeanMethodProjectionTest$Parent as Parent, $BeanMethodProjectionTest$Bounded as Bounded } from 'java:com/tkisor/nekojs/probe';
declare const child: Child;
const parent: Parent = child;
const bounded: Bounded<Child> = {value: child};
const property: number = child.x;
const getter: number = child.getX();
const staticResult: number = Child.x(4);
// @ts-expect-error The approved redundant method spelling is migrated.
child.x();
// @ts-expect-error The preserved property is a number, not a string.
const wrong: string = child.x;
// @ts-expect-error The original parent bound remains enforced.
type Invalid = Bounded<number>;
