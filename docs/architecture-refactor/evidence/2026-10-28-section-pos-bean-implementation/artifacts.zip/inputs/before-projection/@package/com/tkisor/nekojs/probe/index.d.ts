declare module "java:com/tkisor/nekojs/probe" {
    export class $BeanMethodProjectionTest$Parent {
        constructor();
        get x(): number;
        getX(): number;
    }

    export class $BeanMethodProjectionTest$Child extends $BeanMethodProjectionTest$Parent {
        constructor();
        static x(value: number): number;
        x(): number;
    }

    export class $BeanMethodProjectionTest$Bounded<T extends $BeanMethodProjectionTest$Parent> {
        constructor();
        value: T;
    }

}
