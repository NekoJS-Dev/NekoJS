import { $ItemTooltipEventJS } from "java:com/tkisor/nekojs/wrapper/event/item";
import { $NetworkDataEventJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $String } from "java:java/lang";
import { $Item, $Item_ } from "java:net/minecraft/world/item";

declare module "@side-only/client/events" {
}

export {};

declare global {
    namespace NetworkEvents {
        function client(handler: ((event: $NetworkDataEventJS) => void)): void;
        function client(extra: string, handler: ((event: $NetworkDataEventJS) => void)): void;
    }

    namespace ItemEvents {
        function tooltip(handler: ((event: $ItemTooltipEventJS) => void)): void;
        function tooltip(extra: $Item_, handler: ((event: $ItemTooltipEventJS) => void)): void;
    }

}
