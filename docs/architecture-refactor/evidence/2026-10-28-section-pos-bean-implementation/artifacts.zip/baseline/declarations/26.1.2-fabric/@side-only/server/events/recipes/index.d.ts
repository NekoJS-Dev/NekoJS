import { $RecipeJsonBuilder } from "java:com/tkisor/nekojs/api/recipe";
import { $List_, $Map_ } from "java:java/util";
import { $ItemStack_ } from "java:net/minecraft/world/item";
import { $Ingredient_ } from "java:net/minecraft/world/item/crafting";


    /**
     * Top-level recipe registry. Access via event.recipes.<namespace>.<type>(...)
     */
    export class DocumentedRecipes {
        minecraft: {
            crafting_shapeless(result: $ItemStack_, ingredients: $Ingredient_[]): $RecipeJsonBuilder;
            crafting_shaped(result: $ItemStack_, pattern: string[], keys: { [key: string]: $Ingredient_ }): $RecipeJsonBuilder;
        };
}
