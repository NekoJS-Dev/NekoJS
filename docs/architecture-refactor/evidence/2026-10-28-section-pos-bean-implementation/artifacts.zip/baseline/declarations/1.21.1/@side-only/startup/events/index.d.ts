/// <reference path="../../../@event-builders/index.d.ts" />

import { $ScriptEventRegistrationEvent } from "java:com/tkisor/nekojs/api/event";
import { $VillagerTradeDeclarationEventJS, $VillagerTradeReloadEventJS } from "java:com/tkisor/nekojs/core/villager";
import { $BlockEntityTickEvent, $RandomTickEvent } from "java:com/tkisor/nekojs/event/level";
import { $ProbeAddGlobalEventJS, $ProbeAssignTypeEventJS, $ProbeModifyTypeEventJS, $ProbeSnippetEventJS } from "java:com/tkisor/nekojs/probe/events";
import { $DataGeneratorJS } from "java:com/tkisor/nekojs/wrapper";
import { $BlockBrokenEventJS } from "java:com/tkisor/nekojs/wrapper/event/block";
import { $GoalRegisterEventJS } from "java:com/tkisor/nekojs/wrapper/event/entity";
import { $InventoryChangedEventJS } from "java:com/tkisor/nekojs/wrapper/event/player";
import { $CapabilityRegistryEventJS } from "java:com/tkisor/nekojs/wrapper/event/registry";
import { $ItemModificationEventJS, $LootTableEventJS, $RecipeEventJS, $TagEventJS } from "java:com/tkisor/nekojs/wrapper/event/server";
import { $NetworkDataEventJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $String } from "java:java/lang";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $Item, $Item_ } from "java:net/minecraft/world/item";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntityType, $BlockEntityType_ } from "java:net/minecraft/world/level/block/entity";
import { $CommandEvent, $LootTableLoadEvent, $OnDatapackSyncEvent, $RegisterCommandsEvent, $ServerChatEvent, $TagsUpdatedEvent } from "java:net/neoforged/neoforge/event";
import { $EntityJoinLevelEvent, $EntityLeaveLevelEvent } from "java:net/neoforged/neoforge/event/entity";
import { $ItemTossEvent } from "java:net/neoforged/neoforge/event/entity/item";
import { $FinalizeSpawnEvent, $LivingDamageEvent$Post, $LivingDamageEvent$Pre, $LivingDeathEvent, $LivingDropsEvent, $LivingEntityUseItemEvent$Finish, $LivingEntityUseItemEvent$Start, $LivingEntityUseItemEvent$Stop, $LivingEntityUseItemEvent$Tick } from "java:net/neoforged/neoforge/event/entity/living";
import { $AdvancementEvent$AdvancementEarnEvent, $ItemEntityPickupEvent$Post, $ItemEntityPickupEvent$Pre, $ItemTooltipEvent, $PlayerContainerEvent$Close, $PlayerContainerEvent$Open, $PlayerDestroyItemEvent, $PlayerEvent$Clone, $PlayerEvent$ItemCraftedEvent, $PlayerEvent$ItemSmeltedEvent, $PlayerEvent$PlayerChangedDimensionEvent, $PlayerEvent$PlayerLoggedInEvent, $PlayerEvent$PlayerLoggedOutEvent, $PlayerEvent$PlayerRespawnEvent, $PlayerInteractEvent$EntityInteract, $PlayerInteractEvent$LeftClickBlock, $PlayerInteractEvent$RightClickBlock, $PlayerInteractEvent$RightClickItem } from "java:net/neoforged/neoforge/event/entity/player";
import { $BlockEvent$BlockToolModificationEvent, $BlockEvent$EntityMultiPlaceEvent, $BlockEvent$EntityPlaceEvent, $BlockEvent$FarmlandTrampleEvent, $BlockEvent$FluidPlaceBlockEvent, $BlockEvent$NeighborNotifyEvent, $BlockEvent$PortalSpawnEvent, $ExplosionEvent$Detonate, $ExplosionEvent$Start, $LevelEvent$Load, $LevelEvent$Save, $LevelEvent$Unload } from "java:net/neoforged/neoforge/event/level";
import { $ServerAboutToStartEvent, $ServerStartedEvent, $ServerStartingEvent, $ServerStoppedEvent, $ServerStoppingEvent } from "java:net/neoforged/neoforge/event/server";
import { $EntityTickEvent$Post, $EntityTickEvent$Pre, $LevelTickEvent$Post, $LevelTickEvent$Pre, $PlayerTickEvent$Post, $PlayerTickEvent$Pre, $ServerTickEvent$Post, $ServerTickEvent$Pre } from "java:net/neoforged/neoforge/event/tick";

interface StartupRegistryEvent {
    block(id: string, build: (build: NekoStartupBuilders.BlockBuilder) => void): NekoStartupBuilders.BlockBuilder;
    block(id: string, typeName: "basic", build: (build: NekoStartupBuilders.BlockBuilder) => void): NekoStartupBuilders.BlockBuilder;
    block(id: string, typeName: string, build: (build: any) => void): any;
    creativeModeTab(id: string, build: (build: NekoStartupBuilders.CreativeTabBuilder) => void): NekoStartupBuilders.CreativeTabBuilder;
    creativeModeTab(id: string, typeName: "basic", build: (build: NekoStartupBuilders.CreativeTabBuilder) => void): NekoStartupBuilders.CreativeTabBuilder;
    creativeModeTab(id: string, typeName: string, build: (build: any) => void): any;
    enchantment(id: string, build: (build: NekoStartupBuilders.EnchantmentBuilder) => void): NekoStartupBuilders.EnchantmentBuilder;
    enchantment(id: string, typeName: "basic", build: (build: NekoStartupBuilders.EnchantmentBuilder) => void): NekoStartupBuilders.EnchantmentBuilder;
    enchantment(id: string, typeName: string, build: (build: any) => void): any;
    entityType(id: string, build: (build: NekoStartupBuilders.EntityTypeBuilder) => void): NekoStartupBuilders.EntityTypeBuilder;
    entityType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.EntityTypeBuilder) => void): NekoStartupBuilders.EntityTypeBuilder;
    entityType(id: string, typeName: string, build: (build: any) => void): any;
    fluid(id: string, build: (build: NekoStartupBuilders.FluidBuilder) => void): NekoStartupBuilders.FluidBuilder;
    fluid(id: string, typeName: "basic", build: (build: NekoStartupBuilders.FluidBuilder) => void): NekoStartupBuilders.FluidBuilder;
    fluid(id: string, typeName: string, build: (build: any) => void): any;
    item(id: string, build: (build: NekoStartupBuilders.ItemBuilder) => void): NekoStartupBuilders.ItemBuilder;
    item(id: string, typeName: "basic", build: (build: NekoStartupBuilders.ItemBuilder) => void): NekoStartupBuilders.ItemBuilder;
    item(id: string, typeName: string, build: (build: any) => void): any;
    mobEffect(id: string, build: (build: NekoStartupBuilders.MobEffectBuilder) => void): NekoStartupBuilders.MobEffectBuilder;
    mobEffect(id: string, typeName: "basic", build: (build: NekoStartupBuilders.MobEffectBuilder) => void): NekoStartupBuilders.MobEffectBuilder;
    mobEffect(id: string, typeName: string, build: (build: any) => void): any;
    particleType(id: string, build: (build: NekoStartupBuilders.ParticleTypeBuilder) => void): NekoStartupBuilders.ParticleTypeBuilder;
    particleType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.ParticleTypeBuilder) => void): NekoStartupBuilders.ParticleTypeBuilder;
    particleType(id: string, typeName: string, build: (build: any) => void): any;
    potion(id: string, build: (build: NekoStartupBuilders.PotionBuilder) => void): NekoStartupBuilders.PotionBuilder;
    potion(id: string, typeName: "basic", build: (build: NekoStartupBuilders.PotionBuilder) => void): NekoStartupBuilders.PotionBuilder;
    potion(id: string, typeName: string, build: (build: any) => void): any;
    soundEvent(id: string, build: (build: NekoStartupBuilders.SoundEventBuilder) => void): NekoStartupBuilders.SoundEventBuilder;
    soundEvent(id: string, typeName: "basic", build: (build: NekoStartupBuilders.SoundEventBuilder) => void): NekoStartupBuilders.SoundEventBuilder;
    soundEvent(id: string, typeName: string, build: (build: any) => void): any;
    villagerType(id: string, build: (build: NekoStartupBuilders.VillagerTypeBuilder) => void): NekoStartupBuilders.VillagerTypeBuilder;
    villagerType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.VillagerTypeBuilder) => void): NekoStartupBuilders.VillagerTypeBuilder;
    villagerType(id: string, typeName: string, build: (build: any) => void): any;
    custom(id: string, typeName: string, build: (build: any) => void): any;
    register(registry: string, id: string, supplier: () => unknown): any;
}

declare module "@side-only/startup/events" {
}

export {};

declare global {
    namespace CapabilityEvents {
        function register(handler: ((event: $CapabilityRegistryEventJS) => void)): void;
    }

    namespace CommandEvents {
        function register(handler: ((event: $RegisterCommandsEvent) => void)): void;
        function command(handler: ((event: $CommandEvent) => void)): void;
    }

    namespace GoalEvents {
        function register(handler: ((event: $GoalRegisterEventJS) => void)): void;
    }

    namespace EntityEvents {
        function damagePre(handler: ((event: $LivingDamageEvent$Pre) => void)): void;
        function damagePre(extra: $EntityType_<any>, handler: ((event: $LivingDamageEvent$Pre) => void)): void;
        function damagePost(handler: ((event: $LivingDamageEvent$Post) => void)): void;
        function damagePost(extra: $EntityType_<any>, handler: ((event: $LivingDamageEvent$Post) => void)): void;
        function death(handler: ((event: $LivingDeathEvent) => void)): void;
        function death(extra: $EntityType_<any>, handler: ((event: $LivingDeathEvent) => void)): void;
        function drops(handler: ((event: $LivingDropsEvent) => void)): void;
        function drops(extra: $EntityType_<any>, handler: ((event: $LivingDropsEvent) => void)): void;
        function finalizeSpawn(handler: ((event: $FinalizeSpawnEvent) => void)): void;
        function finalizeSpawn(extra: $EntityType_<any>, handler: ((event: $FinalizeSpawnEvent) => void)): void;
        function tickPre(handler: ((event: $EntityTickEvent$Pre) => void)): void;
        function tickPre(extra: $EntityType_<any>, handler: ((event: $EntityTickEvent$Pre) => void)): void;
        function tickPost(handler: ((event: $EntityTickEvent$Post) => void)): void;
        function tickPost(extra: $EntityType_<any>, handler: ((event: $EntityTickEvent$Post) => void)): void;
        function joinLevel(handler: ((event: $EntityJoinLevelEvent) => void)): void;
        function joinLevel(extra: $EntityType_<any>, handler: ((event: $EntityJoinLevelEvent) => void)): void;
        function leaveLevel(handler: ((event: $EntityLeaveLevelEvent) => void)): void;
        function leaveLevel(extra: $EntityType_<any>, handler: ((event: $EntityLeaveLevelEvent) => void)): void;
        function useItemStarted(handler: ((event: $LivingEntityUseItemEvent$Start) => void)): void;
        function useItemStarted(extra: $Item_, handler: ((event: $LivingEntityUseItemEvent$Start) => void)): void;
        function useItemStopped(handler: ((event: $LivingEntityUseItemEvent$Stop) => void)): void;
        function useItemStopped(extra: $Item_, handler: ((event: $LivingEntityUseItemEvent$Stop) => void)): void;
        function useItemFinished(handler: ((event: $LivingEntityUseItemEvent$Finish) => void)): void;
        function useItemFinished(extra: $Item_, handler: ((event: $LivingEntityUseItemEvent$Finish) => void)): void;
        function useItemTick(handler: ((event: $LivingEntityUseItemEvent$Tick) => void)): void;
        function useItemTick(extra: $Item_, handler: ((event: $LivingEntityUseItemEvent$Tick) => void)): void;
    }

    namespace PlayerEvents {
        function loggedIn(handler: ((event: $PlayerEvent$PlayerLoggedInEvent) => void)): void;
        function loggedOut(handler: ((event: $PlayerEvent$PlayerLoggedOutEvent) => void)): void;
        function chat(handler: ((event: $ServerChatEvent) => void)): void;
        function tickPost(handler: ((event: $PlayerTickEvent$Post) => void)): void;
        function tickPre(handler: ((event: $PlayerTickEvent$Pre) => void)): void;
        function cloned(handler: ((event: $PlayerEvent$Clone) => void)): void;
        function respawned(handler: ((event: $PlayerEvent$PlayerRespawnEvent) => void)): void;
        function changedDimension(handler: ((event: $PlayerEvent$PlayerChangedDimensionEvent) => void)): void;
        function advancement(handler: ((event: $AdvancementEvent$AdvancementEarnEvent) => void)): void;
        function containerOpened(handler: ((event: $PlayerContainerEvent$Open) => void)): void;
        function inventoryOpened(handler: ((event: $PlayerContainerEvent$Open) => void)): void;
        function containerClosed(handler: ((event: $PlayerContainerEvent$Close) => void)): void;
        function inventoryClosed(handler: ((event: $PlayerContainerEvent$Close) => void)): void;
        function entityInteract(handler: ((event: $PlayerInteractEvent$EntityInteract) => void)): void;
        function crafted(handler: ((event: $PlayerEvent$ItemCraftedEvent) => void)): void;
        function crafted(extra: $Item_, handler: ((event: $PlayerEvent$ItemCraftedEvent) => void)): void;
        function smelted(handler: ((event: $PlayerEvent$ItemSmeltedEvent) => void)): void;
        function smelted(extra: $Item_, handler: ((event: $PlayerEvent$ItemSmeltedEvent) => void)): void;
        function destroyed(handler: ((event: $PlayerDestroyItemEvent) => void)): void;
        function destroyed(extra: $Item_, handler: ((event: $PlayerDestroyItemEvent) => void)): void;
        function inventoryChanged(handler: ((event: $InventoryChangedEventJS) => void)): void;
        function inventoryChanged(extra: $Item_, handler: ((event: $InventoryChangedEventJS) => void)): void;
    }

    namespace LevelEvents {
        function loaded(handler: ((event: $LevelEvent$Load) => void)): void;
        function unloaded(handler: ((event: $LevelEvent$Unload) => void)): void;
        function saved(handler: ((event: $LevelEvent$Save) => void)): void;
        function tickPre(handler: ((event: $LevelTickEvent$Pre) => void)): void;
        function tickPost(handler: ((event: $LevelTickEvent$Post) => void)): void;
        function tick(handler: ((event: $LevelTickEvent$Post) => void)): void;
        function explosionStart(handler: ((event: $ExplosionEvent$Start) => void)): void;
        function beforeExplosion(handler: ((event: $ExplosionEvent$Start) => void)): void;
        function explosionDetonate(handler: ((event: $ExplosionEvent$Detonate) => void)): void;
        function afterExplosion(handler: ((event: $ExplosionEvent$Detonate) => void)): void;
    }

    namespace BlockEvents {
        function broken(handler: ((event: $BlockBrokenEventJS) => void)): void;
        function broken(extra: $Block_, handler: ((event: $BlockBrokenEventJS) => void)): void;
        function entityPlaced(handler: ((event: $BlockEvent$EntityPlaceEvent) => void)): void;
        function entityPlaced(extra: $Block_, handler: ((event: $BlockEvent$EntityPlaceEvent) => void)): void;
        function entityMultiPlaced(handler: ((event: $BlockEvent$EntityMultiPlaceEvent) => void)): void;
        function entityMultiPlaced(extra: $Block_, handler: ((event: $BlockEvent$EntityMultiPlaceEvent) => void)): void;
        function neighborNotify(handler: ((event: $BlockEvent$NeighborNotifyEvent) => void)): void;
        function neighborNotify(extra: $Block_, handler: ((event: $BlockEvent$NeighborNotifyEvent) => void)): void;
        function fluidPlaced(handler: ((event: $BlockEvent$FluidPlaceBlockEvent) => void)): void;
        function fluidPlaced(extra: $Block_, handler: ((event: $BlockEvent$FluidPlaceBlockEvent) => void)): void;
        function farmlandTrample(handler: ((event: $BlockEvent$FarmlandTrampleEvent) => void)): void;
        function farmlandTrample(extra: $Block_, handler: ((event: $BlockEvent$FarmlandTrampleEvent) => void)): void;
        function portalSpawn(handler: ((event: $BlockEvent$PortalSpawnEvent) => void)): void;
        function portalSpawn(extra: $Block_, handler: ((event: $BlockEvent$PortalSpawnEvent) => void)): void;
        function toolModification(handler: ((event: $BlockEvent$BlockToolModificationEvent) => void)): void;
        function toolModification(extra: $Block_, handler: ((event: $BlockEvent$BlockToolModificationEvent) => void)): void;
        function rightClicked(handler: ((event: $PlayerInteractEvent$RightClickBlock) => void)): void;
        function rightClicked(extra: $Block_, handler: ((event: $PlayerInteractEvent$RightClickBlock) => void)): void;
        function placed(handler: ((event: $BlockEvent$EntityPlaceEvent) => void)): void;
        function placed(extra: $Block_, handler: ((event: $BlockEvent$EntityPlaceEvent) => void)): void;
        function leftClicked(handler: ((event: $PlayerInteractEvent$LeftClickBlock) => void)): void;
        function leftClicked(extra: $Block_, handler: ((event: $PlayerInteractEvent$LeftClickBlock) => void)): void;
        function randomTick(handler: ((event: $RandomTickEvent) => void)): void;
        function randomTick(extra: $Block_, handler: ((event: $RandomTickEvent) => void)): void;
        function blockEntityTick(handler: ((event: $BlockEntityTickEvent) => void)): void;
        function blockEntityTick(extra: $BlockEntityType_<any>, handler: ((event: $BlockEntityTickEvent) => void)): void;
    }

    namespace NetworkEvents {
        function server(handler: ((event: $NetworkDataEventJS) => void)): void;
        function server(extra: string, handler: ((event: $NetworkDataEventJS) => void)): void;
        function client(handler: ((event: $NetworkDataEventJS) => void)): void;
        function client(extra: string, handler: ((event: $NetworkDataEventJS) => void)): void;
    }

    namespace ItemEvents {
        function rightClicked(handler: ((event: $PlayerInteractEvent$RightClickItem) => void)): void;
        function rightClicked(extra: $Item_, handler: ((event: $PlayerInteractEvent$RightClickItem) => void)): void;
        function modification(handler: ((event: $ItemModificationEventJS) => void)): void;
        function tooltip(handler: ((event: $ItemTooltipEvent) => void)): void;
        function tooltip(extra: $Item_, handler: ((event: $ItemTooltipEvent) => void)): void;
        function canPickUp(handler: ((event: $ItemEntityPickupEvent$Pre) => void)): void;
        function canPickUp(extra: $Item_, handler: ((event: $ItemEntityPickupEvent$Pre) => void)): void;
        function pickedUpPre(handler: ((event: $ItemEntityPickupEvent$Pre) => void)): void;
        function pickedUpPre(extra: $Item_, handler: ((event: $ItemEntityPickupEvent$Pre) => void)): void;
        function pickedUp(handler: ((event: $ItemEntityPickupEvent$Post) => void)): void;
        function pickedUp(extra: $Item_, handler: ((event: $ItemEntityPickupEvent$Post) => void)): void;
        function dropped(handler: ((event: $ItemTossEvent) => void)): void;
        function dropped(extra: $Item_, handler: ((event: $ItemTossEvent) => void)): void;
        function entityInteracted(handler: ((event: $PlayerInteractEvent$EntityInteract) => void)): void;
        function entityInteracted(extra: $Item_, handler: ((event: $PlayerInteractEvent$EntityInteract) => void)): void;
        function foodEaten(handler: ((event: $LivingEntityUseItemEvent$Finish) => void)): void;
        function foodEaten(extra: $Item_, handler: ((event: $LivingEntityUseItemEvent$Finish) => void)): void;
    }

    namespace ServerEvents {
        function tickPre(handler: ((event: $ServerTickEvent$Pre) => void)): void;
        function tickPost(handler: ((event: $ServerTickEvent$Post) => void)): void;
        function recipes(handler: ((event: $RecipeEventJS) => void)): void;
        function afterRecipes(handler: ((event: $RecipeEventJS) => void)): void;
        function generateData(handler: ((event: $DataGeneratorJS) => void)): void;
        function generateData(extra: string, handler: ((event: $DataGeneratorJS) => void)): void;
        function aboutToStart(handler: ((event: $ServerAboutToStartEvent) => void)): void;
        function starting(handler: ((event: $ServerStartingEvent) => void)): void;
        function started(handler: ((event: $ServerStartedEvent) => void)): void;
        function stopping(handler: ((event: $ServerStoppingEvent) => void)): void;
        function stopped(handler: ((event: $ServerStoppedEvent) => void)): void;
        function datapackSync(handler: ((event: $OnDatapackSyncEvent) => void)): void;
        function tagsUpdated(handler: ((event: $TagsUpdatedEvent) => void)): void;
        function lootTableLoad(handler: ((event: $LootTableLoadEvent) => void)): void;
        function lootTables(handler: ((event: $LootTableEventJS) => void)): void;
        function tags(handler: ((event: $TagEventJS) => void)): void;
        function tags(extra: $ResourceLocation_, handler: ((event: $TagEventJS) => void)): void;
        function tradeDeclaration(handler: ((event: $VillagerTradeDeclarationEventJS) => void)): void;
        function tradeReload(handler: ((event: $VillagerTradeReloadEventJS) => void)): void;
    }

    namespace ScriptEvents {
        function server(handler: ((event: $ScriptEventRegistrationEvent) => void)): void;
        function client(handler: ((event: $ScriptEventRegistrationEvent) => void)): void;
    }

    namespace ProbeEvents {
        function modifyType(handler: ((event: $ProbeModifyTypeEventJS) => void)): void;
        function assignType(handler: ((event: $ProbeAssignTypeEventJS) => void)): void;
        function addGlobal(handler: ((event: $ProbeAddGlobalEventJS) => void)): void;
        function snippets(handler: ((event: $ProbeSnippetEventJS) => void)): void;
    }

    namespace RegistryEvents {
        function register(handler: ((event: StartupRegistryEvent) => void)): void;
    }

}
