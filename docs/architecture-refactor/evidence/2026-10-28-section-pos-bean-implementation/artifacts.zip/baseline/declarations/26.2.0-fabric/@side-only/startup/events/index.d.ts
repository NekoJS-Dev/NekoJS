/// <reference path="../../../@event-builders/index.d.ts" />

import { $ScriptEventRegistrationEvent } from "java:com/tkisor/nekojs/api/event";
import { $VillagerTradeDeclarationEventJS, $VillagerTradeReloadEventJS } from "java:com/tkisor/nekojs/core/villager";
import { $BlockBrokenEventJS, $BlockLeftClickEventJS, $BlockRightClickEventJS } from "java:com/tkisor/nekojs/wrapper/event/block";
import { $EntityJoinLevelEventJS, $EntityLeaveLevelEventJS, $EntityTickEventJS, $GoalRegisterEventJS, $LivingDamageEventJS, $LivingDeathEventJS, $LivingDropsEventJS, $MobFinalizeSpawnEventJS } from "java:com/tkisor/nekojs/wrapper/event/entity";
import { $ItemDroppedEventJS, $ItemEntityPickupEventJS, $ItemRightClickEventJS, $ItemTooltipEventJS, $ItemUseFinishedEventJS, $PlayerEntityInteractEventJS as $NekoImport$PlayerEntityInteractEventJS } from "java:com/tkisor/nekojs/wrapper/event/item";
import { $LevelEventJS } from "java:com/tkisor/nekojs/wrapper/event/level";
import { $InventoryChangedEventJS, $PlayerAdvancementEventJS, $PlayerChangedDimensionEventJS, $PlayerCloneEventJS, $PlayerContainerEventJS, $PlayerCraftedEventJS, $PlayerDestroyItemEventJS, $PlayerEntityInteractEventJS as $NekoImport$PlayerEntityInteractEventJS1, $PlayerLifecycleEventJS, $PlayerRespawnEventJS, $PlayerTickEventJS, $ServerChatEventJS } from "java:com/tkisor/nekojs/wrapper/event/player";
import { $CapabilityRegistryEventJS } from "java:com/tkisor/nekojs/wrapper/event/registry";
import { $BlockModificationEventJS, $CommandRegistryEventJS, $DatapackSyncEventJS, $ItemModificationEventJS, $LootTableLoadEventJS, $RecipeEventJS, $ServerLifecycleEventJS, $ServerTickEventJS, $TagUpdatedEventJS } from "java:com/tkisor/nekojs/wrapper/event/server";
import { $NetworkDataEventJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $String } from "java:java/lang";
import { $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $Item, $Item_ } from "java:net/minecraft/world/item";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";

interface StartupRegistryEvent {
    block(id: string, build: (build: NekoStartupBuilders.BlockBuilder) => void): NekoStartupBuilders.BlockBuilder;
    block(id: string, typeName: "basic", build: (build: NekoStartupBuilders.BlockBuilder) => void): NekoStartupBuilders.BlockBuilder;
    block(id: string, typeName: string, build: (build: any) => void): any;
    creativeModeTab(id: string, build: (build: NekoStartupBuilders.CreativeTabBuilder) => void): NekoStartupBuilders.CreativeTabBuilder;
    creativeModeTab(id: string, typeName: "basic", build: (build: NekoStartupBuilders.CreativeTabBuilder) => void): NekoStartupBuilders.CreativeTabBuilder;
    creativeModeTab(id: string, typeName: string, build: (build: any) => void): any;
    enchantment(id: string, build: (build: NekoStartupBuilders.EnchantmentBuilder) => void): NekoStartupBuilders.EnchantmentBuilder;
    enchantment(id: string, typeName: "basic", build: (build: NekoStartupBuilders.EnchantmentBuilder) => void): NekoStartupBuilders.EnchantmentBuilder;
    enchantment(id: string, typeName: string, build: (build: any) => void): any;
    entityType(id: string, build: (build: NekoStartupBuilders.EntityTypeBuilder) => void): NekoStartupBuilders.EntityTypeBuilder;
    entityType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.EntityTypeBuilder) => void): NekoStartupBuilders.EntityTypeBuilder;
    entityType(id: string, typeName: string, build: (build: any) => void): any;
    item(id: string, build: (build: NekoStartupBuilders.ItemBuilder) => void): NekoStartupBuilders.ItemBuilder;
    item(id: string, typeName: "basic", build: (build: NekoStartupBuilders.ItemBuilder) => void): NekoStartupBuilders.ItemBuilder;
    item(id: string, typeName: string, build: (build: any) => void): any;
    mobEffect(id: string, build: (build: NekoStartupBuilders.MobEffectBuilder) => void): NekoStartupBuilders.MobEffectBuilder;
    mobEffect(id: string, typeName: "basic", build: (build: NekoStartupBuilders.MobEffectBuilder) => void): NekoStartupBuilders.MobEffectBuilder;
    mobEffect(id: string, typeName: string, build: (build: any) => void): any;
    particleType(id: string, build: (build: NekoStartupBuilders.ParticleTypeBuilder) => void): NekoStartupBuilders.ParticleTypeBuilder;
    particleType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.ParticleTypeBuilder) => void): NekoStartupBuilders.ParticleTypeBuilder;
    particleType(id: string, typeName: string, build: (build: any) => void): any;
    potion(id: string, build: (build: NekoStartupBuilders.PotionBuilder) => void): NekoStartupBuilders.PotionBuilder;
    potion(id: string, typeName: "basic", build: (build: NekoStartupBuilders.PotionBuilder) => void): NekoStartupBuilders.PotionBuilder;
    potion(id: string, typeName: string, build: (build: any) => void): any;
    soundEvent(id: string, build: (build: NekoStartupBuilders.SoundEventBuilder) => void): NekoStartupBuilders.SoundEventBuilder;
    soundEvent(id: string, typeName: "basic", build: (build: NekoStartupBuilders.SoundEventBuilder) => void): NekoStartupBuilders.SoundEventBuilder;
    soundEvent(id: string, typeName: string, build: (build: any) => void): any;
    villagerType(id: string, build: (build: NekoStartupBuilders.VillagerTypeBuilder) => void): NekoStartupBuilders.VillagerTypeBuilder;
    villagerType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.VillagerTypeBuilder) => void): NekoStartupBuilders.VillagerTypeBuilder;
    villagerType(id: string, typeName: string, build: (build: any) => void): any;
    custom(id: string, typeName: string, build: (build: any) => void): any;
    register(registry: string, id: string, supplier: () => unknown): any;
}

declare module "@side-only/startup/events" {
}

export {};

declare global {
    namespace PlayerEvents {
        function loggedIn(handler: ((event: $PlayerLifecycleEventJS) => void)): void;
        function loggedOut(handler: ((event: $PlayerLifecycleEventJS) => void)): void;
        function tickPre(handler: ((event: $PlayerTickEventJS) => void)): void;
        function tickPost(handler: ((event: $PlayerTickEventJS) => void)): void;
        function cloned(handler: ((event: $PlayerCloneEventJS) => void)): void;
        function respawned(handler: ((event: $PlayerRespawnEventJS) => void)): void;
        function chat(handler: ((event: $ServerChatEventJS) => void)): void;
        function containerOpened(handler: ((event: $PlayerContainerEventJS) => void)): void;
        function inventoryOpened(handler: ((event: $PlayerContainerEventJS) => void)): void;
        function containerClosed(handler: ((event: $PlayerContainerEventJS) => void)): void;
        function inventoryClosed(handler: ((event: $PlayerContainerEventJS) => void)): void;
        function crafted(handler: ((event: $PlayerCraftedEventJS) => void)): void;
        function crafted(extra: $Item_, handler: ((event: $PlayerCraftedEventJS) => void)): void;
        function smelted(handler: ((event: $PlayerCraftedEventJS) => void)): void;
        function smelted(extra: $Item_, handler: ((event: $PlayerCraftedEventJS) => void)): void;
        function destroyed(handler: ((event: $PlayerDestroyItemEventJS) => void)): void;
        function destroyed(extra: $Item_, handler: ((event: $PlayerDestroyItemEventJS) => void)): void;
        function advancement(handler: ((event: $PlayerAdvancementEventJS) => void)): void;
        function entityInteract(handler: ((event: $NekoImport$PlayerEntityInteractEventJS1) => void)): void;
        function changedDimension(handler: ((event: $PlayerChangedDimensionEventJS) => void)): void;
        function inventoryChanged(handler: ((event: $InventoryChangedEventJS) => void)): void;
        function inventoryChanged(extra: $Item_, handler: ((event: $InventoryChangedEventJS) => void)): void;
    }

    namespace RegistryEvents {
        function register(handler: ((event: StartupRegistryEvent) => void)): void;
    }

    namespace CommandEvents {
        function register(handler: ((event: $CommandRegistryEventJS) => void)): void;
    }

    namespace CapabilityEvents {
        function register(handler: ((event: $CapabilityRegistryEventJS) => void)): void;
    }

    namespace ItemEvents {
        function rightClicked(handler: ((event: $ItemRightClickEventJS) => void)): void;
        function rightClicked(extra: $Item_, handler: ((event: $ItemRightClickEventJS) => void)): void;
        function tooltip(handler: ((event: $ItemTooltipEventJS) => void)): void;
        function tooltip(extra: $Item_, handler: ((event: $ItemTooltipEventJS) => void)): void;
        function canPickUp(handler: ((event: $ItemEntityPickupEventJS) => void)): void;
        function canPickUp(extra: $Item_, handler: ((event: $ItemEntityPickupEventJS) => void)): void;
        function pickedUpPre(handler: ((event: $ItemEntityPickupEventJS) => void)): void;
        function pickedUpPre(extra: $Item_, handler: ((event: $ItemEntityPickupEventJS) => void)): void;
        function pickedUp(handler: ((event: $ItemEntityPickupEventJS) => void)): void;
        function pickedUp(extra: $Item_, handler: ((event: $ItemEntityPickupEventJS) => void)): void;
        function dropped(handler: ((event: $ItemDroppedEventJS) => void)): void;
        function dropped(extra: $Item_, handler: ((event: $ItemDroppedEventJS) => void)): void;
        function foodEaten(handler: ((event: $ItemUseFinishedEventJS) => void)): void;
        function foodEaten(extra: $Item_, handler: ((event: $ItemUseFinishedEventJS) => void)): void;
        function entityInteracted(handler: ((event: $NekoImport$PlayerEntityInteractEventJS) => void)): void;
        function entityInteracted(extra: $Item_, handler: ((event: $NekoImport$PlayerEntityInteractEventJS) => void)): void;
        function modification(handler: ((event: $ItemModificationEventJS) => void)): void;
    }

    namespace BlockEvents {
        function broken(handler: ((event: $BlockBrokenEventJS) => void)): void;
        function broken(extra: $Block_, handler: ((event: $BlockBrokenEventJS) => void)): void;
        function modification(handler: ((event: $BlockModificationEventJS) => void)): void;
        function rightClicked(handler: ((event: $BlockRightClickEventJS) => void)): void;
        function rightClicked(extra: $Block_, handler: ((event: $BlockRightClickEventJS) => void)): void;
        function leftClicked(handler: ((event: $BlockLeftClickEventJS) => void)): void;
        function leftClicked(extra: $Block_, handler: ((event: $BlockLeftClickEventJS) => void)): void;
    }

    namespace ScriptEvents {
        function server(handler: ((event: $ScriptEventRegistrationEvent) => void)): void;
        function client(handler: ((event: $ScriptEventRegistrationEvent) => void)): void;
    }

    namespace ServerEvents {
        function aboutToStart(handler: ((event: $ServerLifecycleEventJS) => void)): void;
        function starting(handler: ((event: $ServerLifecycleEventJS) => void)): void;
        function started(handler: ((event: $ServerLifecycleEventJS) => void)): void;
        function stopping(handler: ((event: $ServerLifecycleEventJS) => void)): void;
        function stopped(handler: ((event: $ServerLifecycleEventJS) => void)): void;
        function tickPre(handler: ((event: $ServerTickEventJS) => void)): void;
        function tickPost(handler: ((event: $ServerTickEventJS) => void)): void;
        function datapackSync(handler: ((event: $DatapackSyncEventJS) => void)): void;
        function tagsUpdated(handler: ((event: $TagUpdatedEventJS) => void)): void;
        function lootTableLoad(handler: ((event: $LootTableLoadEventJS) => void)): void;
        function recipes(handler: ((event: $RecipeEventJS) => void)): void;
        function afterRecipes(handler: ((event: $RecipeEventJS) => void)): void;
        function tradeDeclaration(handler: ((event: $VillagerTradeDeclarationEventJS) => void)): void;
        function tradeReload(handler: ((event: $VillagerTradeReloadEventJS) => void)): void;
    }

    namespace GoalEvents {
        function register(handler: ((event: $GoalRegisterEventJS) => void)): void;
    }

    namespace EntityEvents {
        function joinLevel(handler: ((event: $EntityJoinLevelEventJS) => void)): void;
        function joinLevel(extra: $EntityType_<any>, handler: ((event: $EntityJoinLevelEventJS) => void)): void;
        function death(handler: ((event: $LivingDeathEventJS) => void)): void;
        function death(extra: $EntityType_<any>, handler: ((event: $LivingDeathEventJS) => void)): void;
        function damagePre(handler: ((event: $LivingDamageEventJS) => void)): void;
        function damagePre(extra: $EntityType_<any>, handler: ((event: $LivingDamageEventJS) => void)): void;
        function damagePost(handler: ((event: $LivingDamageEventJS) => void)): void;
        function damagePost(extra: $EntityType_<any>, handler: ((event: $LivingDamageEventJS) => void)): void;
        function drops(handler: ((event: $LivingDropsEventJS) => void)): void;
        function drops(extra: $EntityType_<any>, handler: ((event: $LivingDropsEventJS) => void)): void;
        function finalizeSpawn(handler: ((event: $MobFinalizeSpawnEventJS) => void)): void;
        function finalizeSpawn(extra: $EntityType_<any>, handler: ((event: $MobFinalizeSpawnEventJS) => void)): void;
        function tickPre(handler: ((event: $EntityTickEventJS) => void)): void;
        function tickPre(extra: $EntityType_<any>, handler: ((event: $EntityTickEventJS) => void)): void;
        function tickPost(handler: ((event: $EntityTickEventJS) => void)): void;
        function tickPost(extra: $EntityType_<any>, handler: ((event: $EntityTickEventJS) => void)): void;
        function leaveLevel(handler: ((event: $EntityLeaveLevelEventJS) => void)): void;
        function leaveLevel(extra: $EntityType_<any>, handler: ((event: $EntityLeaveLevelEventJS) => void)): void;
    }

    namespace NetworkEvents {
        function server(handler: ((event: $NetworkDataEventJS) => void)): void;
        function server(extra: string, handler: ((event: $NetworkDataEventJS) => void)): void;
        function client(handler: ((event: $NetworkDataEventJS) => void)): void;
        function client(extra: string, handler: ((event: $NetworkDataEventJS) => void)): void;
    }

    namespace LevelEvents {
        function loaded(handler: ((event: $LevelEventJS) => void)): void;
        function unloaded(handler: ((event: $LevelEventJS) => void)): void;
        function tickPre(handler: ((event: $LevelEventJS) => void)): void;
        function tickPost(handler: ((event: $LevelEventJS) => void)): void;
    }

}
