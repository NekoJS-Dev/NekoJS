"""Prepare the unchanged formal policy for a committed, checked source-facts candidate."""
import json
import subprocess
import sys
from pathlib import Path

repo=Path('D:/mcmodDemo/NekoJS-mult')
tools=repo/'build/priority-closeout'
revision=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=repo,text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==revision
source_files=json.loads((tools/'source-facts-review/binding.json').read_text())['files']
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',*source_files],cwd=repo,text=True).strip()
label='2026-10-22-source-facts-'+revision[:8]
out=tools/label
assert not out.exists()
out.mkdir()
old=tools/'2026-10-22-4405b0b0-verification'
source=(tools/'prepare-perf-4405b0b0.py').read_text()
source=source.replace('2026-10-22-4405b0b0-verification',label)
source=source.replace('4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349',revision)
source=source.replace("startswith('26844b7e')","startswith('4405b0b0')")
source=source.replace('codex/perf-final-4405b0b0','codex/perf-source-facts-'+revision[:8])
(out/'prepare.py').write_text(source,encoding='utf-8')
for name in ['formal-performance.py','judge-performance.py']:
    (out/name).write_bytes((old/name).read_bytes())
(out/'provenance.json').write_text(json.dumps(dict(source=old.name,unchangedFormalRunner=True,
    unchangedJudge=True,targetRevision=revision),indent=2)+'\n')
print(out)
