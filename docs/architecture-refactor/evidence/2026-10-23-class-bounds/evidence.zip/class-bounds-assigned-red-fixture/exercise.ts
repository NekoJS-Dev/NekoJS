import type { $TypeScriptClassBoundsTest$Bounded as Bounded } from 'java:com/tkisor/nekojs/probe';
declare const valid: Bounded<{base: number; alternate(): string}>;
const alternate: string = valid.value.alternate();
// @ts-expect-error The second bound is required alongside the first.
declare const missingSecondary: Bounded<{base: number}>;
// @ts-expect-error The first bound remains required.
declare const missingPrimary: Bounded<{alternate(): string}>;
