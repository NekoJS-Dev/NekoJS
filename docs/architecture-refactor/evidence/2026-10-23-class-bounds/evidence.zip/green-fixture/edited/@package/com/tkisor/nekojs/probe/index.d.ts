declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptClassBoundsTest$Bounded<T extends string> {
        constructor();
        value: T;
    }

    export type $TypeScriptClassBoundsTest$Bounded_<T extends string = any> = $TypeScriptClassBoundsTest$Bounded<T> | string;
}
