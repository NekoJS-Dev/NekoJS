import { $SecondaryBound, $SecondaryBound_ } from "java:com/tkisor/nekojs/testfixture/probe";

declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptClassBoundsTest$Bounded<T extends ($TypeScriptClassBoundsTest$Primary) & ($SecondaryBound)> {
        constructor();
        value: T;
    }

    export class $TypeScriptClassBoundsTest$Primary {
        constructor();
        base: number;
    }

}
