declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptClassBoundsTest$Bounded<T extends ($TypeScriptClassBoundsTest$Primary) & ($TypeScriptClassBoundsTest$Replacement)> {
        constructor();
        value: T;
    }

    export class $TypeScriptClassBoundsTest$Primary {
        constructor();
        base: number;
    }

    export interface $TypeScriptClassBoundsTest$Replacement {
        alternate(): string;
    }

    export type $TypeScriptClassBoundsTest$Bounded_<T extends ($TypeScriptClassBoundsTest$Primary) & ($TypeScriptClassBoundsTest$Replacement) = any> = $TypeScriptClassBoundsTest$Bounded<T> | string;
    export type $TypeScriptClassBoundsTest$Replacement_<CallbackResult = string> = (() => CallbackResult) | ($TypeScriptClassBoundsTest$Replacement & { readonly [Symbol.hasInstance]?: never });
}
