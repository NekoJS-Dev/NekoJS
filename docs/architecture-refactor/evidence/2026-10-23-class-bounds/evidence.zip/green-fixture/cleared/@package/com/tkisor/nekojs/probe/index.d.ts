declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptClassBoundsTest$Bounded<T> {
        constructor();
        value: T;
    }

    export type $TypeScriptClassBoundsTest$Bounded_<T = any> = $TypeScriptClassBoundsTest$Bounded<T> | string;
}
