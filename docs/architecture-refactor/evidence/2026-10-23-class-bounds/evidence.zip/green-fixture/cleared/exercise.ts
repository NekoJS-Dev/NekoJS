import type { $TypeScriptClassBoundsTest$Bounded as Bounded,
    $TypeScriptClassBoundsTest$Bounded_ as Input } from 'java:com/tkisor/nekojs/probe';
declare const bounded: Bounded<string>;
const result: string = bounded.value;
const encoded: Input<string> = 'encoded';
// @ts-expect-error An explicit type argument still controls the value.
const wrong: boolean = bounded.value;
declare const unbounded: Bounded<number>;
