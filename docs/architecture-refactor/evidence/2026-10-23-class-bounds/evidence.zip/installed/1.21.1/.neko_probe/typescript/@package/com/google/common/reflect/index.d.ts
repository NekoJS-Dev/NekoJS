import { $ForwardingSet, $ImmutableList } from "java:com/google/common/collect";
import { $Serializable } from "java:java/io";
import { $Class, $Throwable } from "java:java/lang";
import { $Annotation, $Annotation_ } from "java:java/lang/annotation";
import { $AccessFlag, $AccessFlag_, $AnnotatedElement, $AnnotatedType, $Constructor, $Member, $Method, $Type, $TypeVariable } from "java:java/lang/reflect";
import { $Set, $Spliterator } from "java:java/util";
import { $Consumer, $Consumer_, $IntFunction, $IntFunction_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";

declare module "java:com/google/common/reflect" {
    export class $TypeToken<T> extends $TypeCapture<T> implements $Serializable {
        get componentType(): $TypeToken<any>;
        getComponentType(): $TypeToken<any>;
        get rawType(): $Class<any>;
        getRawType(): $Class<any>;
        get types(): $TypeToken$TypeSet;
        getTypes(): $TypeToken$TypeSet;
        get type(): $Type;
        getType(): $Type;
        get array(): boolean;
        isArray(): boolean;
        get primitive(): boolean;
        isPrimitive(): boolean;
        static of<T>(type: $Class<T>): $TypeToken<T>;
        static of(type: $Type): $TypeToken<any>;
        ["constructor"](constructor: $Constructor<any>): $Invokable<T, T>;
        equals(o: unknown): boolean;
        getSubtype(subclass: $Class<any>): $TypeToken<T>;
        getSupertype(superclass: $Class<any>): $TypeToken<any>;
        hashCode(): number;
        isSubtypeOf(type: $TypeToken<any>): boolean;
        isSubtypeOf(supertype: $Type): boolean;
        isSupertypeOf(type: $TypeToken<any>): boolean;
        isSupertypeOf(type: $Type): boolean;
        method(method: $Method): $Invokable<T, unknown>;
        resolveType(type: $Type): $TypeToken<any>;
        toString(): string;
        unwrap(): $TypeToken<T>;
        where<X>(typeParam: $TypeParameter<X>, typeArg: $TypeToken<X>): $TypeToken<T>;
        where<X>(typeParam: $TypeParameter<X>, typeArg: $Class<X>): $TypeToken<T>;
        wrap(): $TypeToken<T>;
    }

    export class $Invokable<T, R> implements $AnnotatedElement, $Member {
        get annotatedReturnType(): $AnnotatedType;
        getAnnotatedReturnType(): $AnnotatedType;
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaringClass(): $Class<any>;
        getDeclaringClass(): $Class<any>;
        get exceptionTypes(): $ImmutableList<$TypeToken<$Throwable>>;
        getExceptionTypes(): $ImmutableList<$TypeToken<$Throwable>>;
        get modifiers(): number;
        getModifiers(): number;
        get name(): string;
        getName(): string;
        get ownerType(): $TypeToken<T>;
        getOwnerType(): $TypeToken<T>;
        get parameters(): $ImmutableList<$Parameter>;
        getParameters(): $ImmutableList<$Parameter>;
        get returnType(): $TypeToken<R>;
        getReturnType(): $TypeToken<R>;
        get typeParameters(): $TypeVariable<any>[];
        getTypeParameters(): $TypeVariable<any>[];
        get abstract(): boolean;
        isAbstract(): boolean;
        get accessible(): boolean;
        isAccessible(): boolean;
        set accessible(value: boolean);
        get final(): boolean;
        isFinal(): boolean;
        get native(): boolean;
        isNative(): boolean;
        get overridable(): boolean;
        isOverridable(): boolean;
        get packagePrivate(): boolean;
        isPackagePrivate(): boolean;
        get private(): boolean;
        isPrivate(): boolean;
        get protected(): boolean;
        isProtected(): boolean;
        get public(): boolean;
        isPublic(): boolean;
        get static(): boolean;
        isStatic(): boolean;
        get synchronized(): boolean;
        isSynchronized(): boolean;
        get synthetic(): boolean;
        isSynthetic(): boolean;
        get varArgs(): boolean;
        isVarArgs(): boolean;
        static from<T>(constructor: $Constructor<T>): $Invokable<T, T>;
        static from(method: $Method): $Invokable<any, unknown>;
        accessFlags(): $Set<$AccessFlag>;
        equals(obj: unknown): boolean;
        getAnnotationsByType<T1 extends $Annotation>(arg0: $Class<T1>): T1[];
        getAnnotation<A extends $Annotation>(annotationClass: $Class<A>): A;
        getDeclaredAnnotationsByType<T1 extends $Annotation>(arg0: $Class<T1>): T1[];
        getDeclaredAnnotation<T1 extends $Annotation>(arg0: $Class<T1>): T1;
        hashCode(): number;
        invoke(receiver: T, args?: unknown[]): R;
        isAnnotationPresent(annotationClass: $Class<$Annotation>): boolean;
        returning<R1 extends R>(returnType: $TypeToken<R1>): $Invokable<T, R1>;
        returning<R1 extends R>(returnType: $Class<R1>): $Invokable<T, R1>;
        setAccessible(flag: boolean): void;
        toString(): string;
        trySetAccessible(): boolean;
    }

    export class $TypeCapture<T> {
    }

    export class $TypeParameter<T> extends $TypeCapture<T> {
        equals(o: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $TypeToken$TypeSet extends $ForwardingSet<$TypeToken<any>> implements $Serializable {
        classes(): $TypeToken$TypeSet;
        equals(object: unknown): boolean;
        forEach(arg0: $Consumer_<$TypeToken<any>, $TypeToken<any>>): void;
        hashCode(): number;
        interfaces(): $TypeToken$TypeSet;
        parallelStream(): $Stream<$TypeToken<any>>;
        rawTypes(): $Set<$Class<any>>;
        removeIf(arg0: $Predicate_<$TypeToken<any>, $TypeToken<any>, boolean>): boolean;
        spliterator(): $Spliterator<$TypeToken<any>>;
        stream(): $Stream<$TypeToken<any>>;
        toArray<T>(array: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }

    export class $Parameter implements $AnnotatedElement {
        get annotatedType(): $AnnotatedType;
        getAnnotatedType(): $AnnotatedType;
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaringInvokable(): $Invokable<any, any>;
        getDeclaringInvokable(): $Invokable<any, any>;
        get type(): $TypeToken<any>;
        getType(): $TypeToken<any>;
        equals(obj: unknown): boolean;
        getAnnotationsByType<A extends $Annotation>(annotationType: $Class<A>): A[];
        getAnnotation<A extends $Annotation>(annotationType: $Class<A>): A;
        getDeclaredAnnotationsByType<A extends $Annotation>(annotationType: $Class<A>): A[];
        getDeclaredAnnotation<A extends $Annotation>(annotationType: $Class<A>): A;
        hashCode(): number;
        isAnnotationPresent(annotationType: $Class<$Annotation>): boolean;
        toString(): string;
    }

}
