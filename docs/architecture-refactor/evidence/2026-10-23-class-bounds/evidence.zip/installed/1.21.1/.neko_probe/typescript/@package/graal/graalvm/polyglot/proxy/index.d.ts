import { $Value } from "java:graal/graalvm/polyglot";
import { $Map } from "java:java/util";

declare module "java:graal/graalvm/polyglot/proxy" {
    export interface $ProxyExecutable extends $Proxy {
        execute(arguments_?: $Value[]): unknown;
    }

    export interface $ProxyObject extends $Proxy {
        getMemberKeys(): unknown;
        getMember(key: string): unknown;
        hasMember(key: string): boolean;
        putMember(key: string, value: $Value): void;
        removeMember(key: string): boolean;
    }
    export const $ProxyObject: {
        fromMap(values: ($Map<string, unknown> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, unknown>>))): $ProxyObject;
    };

    export interface $Proxy {
    }

    export type $ProxyExecutable_<CallbackArg0 = $Value[], CallbackResult = unknown> = ((arg0: CallbackArg0) => CallbackResult) | ($ProxyExecutable & { readonly [Symbol.hasInstance]?: never });
}
