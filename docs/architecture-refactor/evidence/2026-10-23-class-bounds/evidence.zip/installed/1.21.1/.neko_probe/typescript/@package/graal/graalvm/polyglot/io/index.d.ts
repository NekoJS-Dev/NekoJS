import { $OutputStream } from "java:java/io";
import { $Process } from "java:java/lang";
import { $URI } from "java:java/net";
import { $ByteBuffer } from "java:java/nio";
import { $SeekableByteChannel } from "java:java/nio/channels";
import { $Charset } from "java:java/nio/charset";
import { $AccessMode, $AccessMode_, $CopyOption, $DirectoryStream, $DirectoryStream$Filter, $DirectoryStream$Filter_, $FileSystem as $NekoImport$FileSystem, $LinkOption, $LinkOption_, $OpenOption, $Path } from "java:java/nio/file";
import { $FileAttribute } from "java:java/nio/file/attribute";
import { $List, $Map, $Set } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $IntStream } from "java:java/util/stream";

declare module "java:graal/graalvm/polyglot/io" {
    export interface $FileSystem {
        checkAccess(path: $Path, modes: $Set<$AccessMode>, linkOptions?: $LinkOption_[]): void;
        copy(source: $Path, target: $Path, options?: $CopyOption[]): void;
        createDirectory(dir: $Path, attrs?: $FileAttribute<any>[]): void;
        createLink(link: $Path, existing: $Path): void;
        createSymbolicLink(link: $Path, target: $Path, attrs?: $FileAttribute<any>[]): void;
        delete(path: $Path): void;
        getEncoding(path: $Path): $Charset;
        getFileStoreBlockSize(path: $Path): number;
        getFileStoreTotalSpace(path: $Path): number;
        getFileStoreUnallocatedSpace(path: $Path): number;
        getFileStoreUsableSpace(path: $Path): number;
        getMimeType(path: $Path): string;
        getPathSeparator(): string;
        getSeparator(): string;
        getTempDirectory(): $Path;
        isFileStoreReadOnly(path: $Path): boolean;
        isSameFile(path1: $Path, path2: $Path, options?: $LinkOption_[]): boolean;
        move(source: $Path, target: $Path, options?: $CopyOption[]): void;
        newByteChannel(path: $Path, options: $Set<$OpenOption>, attrs?: $FileAttribute<any>[]): $SeekableByteChannel;
        newDirectoryStream(dir: $Path, filter: $DirectoryStream$Filter_<$Path, $Path, boolean>): $DirectoryStream<$Path>;
        parsePath(path: string): $Path;
        parsePath(uri: $URI): $Path;
        readAttributes(path: $Path, attributes: string, options?: $LinkOption_[]): $Map<string, unknown>;
        readSymbolicLink(link: $Path): $Path;
        setAttribute(path: $Path, attribute: string, value: unknown, options?: $LinkOption_[]): void;
        setCurrentWorkingDirectory(currentWorkingDirectory: $Path): void;
        toAbsolutePath(path: $Path): $Path;
        toRealPath(path: $Path, linkOptions?: $LinkOption_[]): $Path;
    }
    export const $FileSystem: {
        allowInternalResourceAccess(fileSystem: $FileSystem): $FileSystem;
        allowInternalResources(fileSystem: $FileSystem): $FileSystem;
        allowLanguageHomeAccess(fileSystem: $FileSystem): $FileSystem;
        newCompositeFileSystem(fallbackFileSystem: $FileSystem, delegates?: $FileSystem$Selector[]): $FileSystem;
        newDefaultFileSystem(): $FileSystem;
        newDenyIOFileSystem(): $FileSystem;
        newFileSystem(fileSystem: $NekoImport$FileSystem): $FileSystem;
        newReadOnlyFileSystem(fileSystem: $FileSystem): $FileSystem;
    };

    export class $IOAccess {
        static ALL: $IOAccess;
        static NONE: $IOAccess;
        static newBuilder(prototype: $IOAccess): $IOAccess$Builder;
        static newBuilder(): $IOAccess$Builder;
        equals(obj: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $MessageTransport {
        open(uri: $URI, peerEndpoint: $MessageEndpoint): $MessageEndpoint;
    }

    export interface $ProcessHandler {
        start(command: $ProcessHandler$ProcessCommand): $Process;
    }

    export interface $ByteSequence {
        byteAt(index: number): number;
        bytes(): $IntStream;
        length(): number;
        subSequence(startIndex: number, endIndex: number): $ByteSequence;
        toByteArray(): number[];
    }
    export const $ByteSequence: {
        create(buffer: number[]): $ByteSequence;
    };

    export class $FileSystem$Selector implements $Predicate<$Path> {
        get fileSystem(): $FileSystem;
        getFileSystem(): $FileSystem;
        static of(fileSystem: $FileSystem, predicate: $Predicate_<$Path, $Path, boolean>): $FileSystem$Selector;
        and(arg0: $Predicate_<$Path, $Path, boolean>): $Predicate<$Path>;
        negate(): $Predicate<$Path>;
        or(arg0: $Predicate_<$Path, $Path, boolean>): $Predicate<$Path>;
        test(path: $Path): boolean;
    }

    export class $IOAccess$Builder {
        allowHostFileAccess(allow: boolean): $IOAccess$Builder;
        allowHostSocketAccess(allow: boolean): $IOAccess$Builder;
        build(): $IOAccess;
        fileSystem(fileSystem: $FileSystem): $IOAccess$Builder;
    }

    export interface $MessageEndpoint {
        sendBinary(data: $ByteBuffer): void;
        sendClose(): void;
        sendPing(data: $ByteBuffer): void;
        sendPong(data: $ByteBuffer): void;
        sendText(text: string): void;
    }

    export class $ProcessHandler$ProcessCommand {
        get command(): $List<string>;
        getCommand(): $List<string>;
        get directory(): string;
        getDirectory(): string;
        get environment(): $Map<string, string>;
        getEnvironment(): $Map<string, string>;
        get errorRedirect(): $ProcessHandler$Redirect;
        getErrorRedirect(): $ProcessHandler$Redirect;
        get inputRedirect(): $ProcessHandler$Redirect;
        getInputRedirect(): $ProcessHandler$Redirect;
        get outputRedirect(): $ProcessHandler$Redirect;
        getOutputRedirect(): $ProcessHandler$Redirect;
        get redirectErrorStream(): boolean;
        isRedirectErrorStream(): boolean;
        static create(cmd: ($List<string> | (string)[]), cwd: string, environment: ($Map<string, string> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, string>>)), redirectErrorStream: boolean, inputRedirect: $ProcessHandler$Redirect, outputRedirect: $ProcessHandler$Redirect, errorRedirect: $ProcessHandler$Redirect): $ProcessHandler$ProcessCommand;
    }

    export class $ProcessHandler$Redirect {
        static INHERIT: $ProcessHandler$Redirect;
        static PIPE: $ProcessHandler$Redirect;
        get outputStream(): $OutputStream;
        getOutputStream(): $OutputStream;
        static createRedirectToStream(stream: $OutputStream): $ProcessHandler$Redirect;
        equals(obj: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export type $MessageTransport_<CallbackArg0 = $URI, CallbackArg1 = $MessageEndpoint, CallbackResult = $MessageEndpoint> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($MessageTransport & { readonly [Symbol.hasInstance]?: never });
    export type $ProcessHandler_<CallbackArg0 = $ProcessHandler$ProcessCommand, CallbackResult = $Process> = ((arg0: CallbackArg0) => CallbackResult) | ($ProcessHandler & { readonly [Symbol.hasInstance]?: never });
}
