import { $Iterable, $Runnable, $Runnable_, $StackTraceElement, $Thread, $Thread$State, $Thread$State_, $Throwable } from "java:java/lang";
import { $Collection, $EventListener, $Iterator, $List, $Spliterator } from "java:java/util";
import { $AbstractExecutorService, $Callable, $Callable_, $Future as $NekoImport$Future, $Future$State, $Future$State_, $ScheduledExecutorService, $ScheduledFuture as $NekoImport$ScheduledFuture, $TimeUnit, $TimeUnit_ } from "java:java/util/concurrent";
import { $Consumer, $Consumer_ } from "java:java/util/function";

declare module "java:io/netty/util/concurrent" {
    export interface $Future<V> extends $NekoImport$Future<V> {
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Future<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Future<V>;
        awaitUninterruptibly(arg0: number, arg1: $TimeUnit_): boolean;
        awaitUninterruptibly(arg0: number): boolean;
        awaitUninterruptibly(): $Future<V>;
        await(arg0: number, arg1: $TimeUnit_): boolean;
        await(arg0: number): boolean;
        await(): $Future<V>;
        cancel(arg0: boolean): boolean;
        cause(): $Throwable;
        getNow(): V;
        isCancellable(): boolean;
        isSuccess(): boolean;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Future<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Future<V>;
        syncUninterruptibly(): $Future<V>;
        sync(): $Future<V>;
    }

    export interface $GenericFutureListener<F extends $Future<any>> extends $EventListener {
        operationComplete(arg0: F): void;
    }

    export interface $EventExecutor extends $EventExecutorGroup {
        inEventLoop(arg0: $Thread): boolean;
        inEventLoop(): boolean;
        newFailedFuture<V>(arg0: $Throwable): $Future<V>;
        newProgressivePromise<V>(): $ProgressivePromise<V>;
        newPromise<V>(): $Promise<V>;
        newSucceededFuture<V>(arg0: V): $Future<V>;
        next(): $EventExecutor;
        parent(): $EventExecutorGroup;
    }

    export interface $EventExecutorGroup extends $ScheduledExecutorService, $Iterable<$EventExecutor> {
        isShuttingDown(): boolean;
        iterator(): $Iterator<$EventExecutor>;
        next(): $EventExecutor;
        scheduleAtFixedRate(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        scheduleAtFixedRate(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $NekoImport$ScheduledFuture<any>;
        scheduleWithFixedDelay(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        scheduleWithFixedDelay(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $NekoImport$ScheduledFuture<any>;
        schedule(arg0: $Runnable_, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<any>;
        schedule(arg0: $Runnable_, arg1: number, arg2: $TimeUnit_): $NekoImport$ScheduledFuture<any>;
        schedule<V>(arg0: $Callable_<V, V>, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<V>;
        schedule<V>(arg0: $Callable_<V, V>, arg1: number, arg2: $TimeUnit_): $NekoImport$ScheduledFuture<V>;
        shutdownGracefully(arg0: number, arg1: number, arg2: $TimeUnit_): $Future<any>;
        shutdownGracefully(): $Future<any>;
        shutdownNow(): $List<$Runnable>;
        shutdown(): void;
        submit<T>(arg0: $Runnable_, arg1: T): $Future<T>;
        submit<T>(arg0: $Runnable_, arg1: T): $NekoImport$Future<T>;
        submit(arg0: $Runnable_): $Future<any>;
        submit(arg0: $Runnable_): $NekoImport$Future<any>;
        submit<T>(arg0: $Callable_<T, T>): $Future<T>;
        submit<T>(arg0: $Callable_<T, T>): $NekoImport$Future<T>;
        terminationFuture(): $Future<any>;
    }

    export interface $ProgressiveFuture<V> extends $Future<V> {
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Future<V>;
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $ProgressiveFuture<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Future<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $ProgressiveFuture<V>;
        awaitUninterruptibly(arg0: number, arg1: $TimeUnit_): boolean;
        awaitUninterruptibly(arg0: number): boolean;
        awaitUninterruptibly(): $Future<V>;
        awaitUninterruptibly(): $ProgressiveFuture<V>;
        await(arg0: number, arg1: $TimeUnit_): boolean;
        await(arg0: number): boolean;
        await(): $Future<V>;
        await(): $ProgressiveFuture<V>;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Future<V>;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $ProgressiveFuture<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Future<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $ProgressiveFuture<V>;
        syncUninterruptibly(): $Future<V>;
        syncUninterruptibly(): $ProgressiveFuture<V>;
        sync(): $Future<V>;
        sync(): $ProgressiveFuture<V>;
    }

    export interface $ProgressivePromise<V> extends $Promise<V>, $ProgressiveFuture<V> {
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Future<V>;
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $ProgressiveFuture<V>;
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $ProgressivePromise<V>;
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Promise<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Future<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $ProgressiveFuture<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $ProgressivePromise<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Promise<V>;
        awaitUninterruptibly(arg0: number, arg1: $TimeUnit_): boolean;
        awaitUninterruptibly(arg0: number): boolean;
        awaitUninterruptibly(): $ProgressiveFuture<V>;
        awaitUninterruptibly(): $ProgressivePromise<V>;
        awaitUninterruptibly(): $Promise<V>;
        await(arg0: number, arg1: $TimeUnit_): boolean;
        await(arg0: number): boolean;
        await(): $ProgressiveFuture<V>;
        await(): $ProgressivePromise<V>;
        await(): $Promise<V>;
        cancel(arg0: boolean): boolean;
        cause(): $Throwable;
        exceptionNow(): $Throwable;
        getNow(): V;
        get(arg0: number, arg1: $TimeUnit_): V;
        get(): V;
        isCancellable(): boolean;
        isCancelled(): boolean;
        isDone(): boolean;
        isSuccess(): boolean;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Future<V>;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $ProgressiveFuture<V>;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $ProgressivePromise<V>;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Promise<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Future<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $ProgressiveFuture<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $ProgressivePromise<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Promise<V>;
        resultNow(): V;
        setFailure(arg0: $Throwable): $ProgressivePromise<V>;
        setFailure(arg0: $Throwable): $Promise<V>;
        setProgress(arg0: number, arg1: number): $ProgressivePromise<V>;
        setSuccess(arg0: V): $ProgressivePromise<V>;
        setSuccess(arg0: V): $Promise<V>;
        state(): $Future$State;
        syncUninterruptibly(): $ProgressiveFuture<V>;
        syncUninterruptibly(): $ProgressivePromise<V>;
        syncUninterruptibly(): $Promise<V>;
        sync(): $ProgressiveFuture<V>;
        sync(): $ProgressivePromise<V>;
        sync(): $Promise<V>;
        tryProgress(arg0: number, arg1: number): boolean;
    }

    export interface $Promise<V> extends $Future<V> {
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Future<V>;
        addListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Promise<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Future<V>;
        addListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Promise<V>;
        awaitUninterruptibly(arg0: number, arg1: $TimeUnit_): boolean;
        awaitUninterruptibly(arg0: number): boolean;
        awaitUninterruptibly(): $Future<V>;
        awaitUninterruptibly(): $Promise<V>;
        await(arg0: number, arg1: $TimeUnit_): boolean;
        await(arg0: number): boolean;
        await(): $Future<V>;
        await(): $Promise<V>;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Future<V>;
        removeListeners(arg0?: $GenericFutureListener_<$Future<any>, $Future<any>>[]): $Promise<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Future<V>;
        removeListener(arg0: $GenericFutureListener_<$Future<any>, $Future<any>>): $Promise<V>;
        setFailure(arg0: $Throwable): $Promise<V>;
        setSuccess(arg0: V): $Promise<V>;
        setUncancellable(): boolean;
        syncUninterruptibly(): $Future<V>;
        syncUninterruptibly(): $Promise<V>;
        sync(): $Future<V>;
        sync(): $Promise<V>;
        tryFailure(arg0: $Throwable): boolean;
        trySuccess(arg0: V): boolean;
    }

    export interface $OrderedEventExecutor extends $EventExecutor {
    }

    export interface $ScheduledFuture<V> extends $Future<V>, $NekoImport$ScheduledFuture<V> {
        cancel(arg0: boolean): boolean;
        exceptionNow(): $Throwable;
        get(arg0: number, arg1: $TimeUnit_): V;
        get(): V;
        isCancelled(): boolean;
        isDone(): boolean;
        resultNow(): V;
        state(): $Future$State;
    }

    export class $MultithreadEventExecutorGroup extends $AbstractEventExecutorGroup {
        isShutdown(): boolean;
        get shuttingDown(): boolean;
        isShuttingDown(): boolean;
        get terminated(): boolean;
        isTerminated(): boolean;
        awaitTermination(arg0: number, arg1: $TimeUnit_): boolean;
        close(): void;
        executorCount(): number;
        forEach(arg0: $Consumer_<$EventExecutor, $EventExecutor>): void;
        iterator(): $Iterator<$EventExecutor>;
        next(): $EventExecutor;
        shutdownGracefully(arg0: number, arg1: number, arg2: $TimeUnit_): $Future<any>;
        shutdownGracefully(): $Future<any>;
        shutdown(): void;
        spliterator(): $Spliterator<$EventExecutor>;
        terminationFuture(): $Future<any>;
    }

    export interface $EventExecutorChooserFactory {
        newChooser(arg0: $EventExecutor[]): $EventExecutorChooserFactory$EventExecutorChooser;
    }

    export interface $RejectedExecutionHandler {
        rejected(arg0: $Runnable_, arg1: $SingleThreadEventExecutor): void;
    }

    export interface $EventExecutorChooserFactory$EventExecutorChooser {
        next(): $EventExecutor;
    }

    export class $AbstractEventExecutorGroup implements $EventExecutorGroup {
        constructor();
        isShutdown(): boolean;
        get shuttingDown(): boolean;
        isShuttingDown(): boolean;
        get terminated(): boolean;
        isTerminated(): boolean;
        awaitTermination(arg0: number, arg1: $TimeUnit_): boolean;
        close(): void;
        execute(arg0: $Runnable_): void;
        forEach(arg0: $Consumer_<$EventExecutor, $EventExecutor>): void;
        invokeAll<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[]), arg1: number, arg2: $TimeUnit_): $List<$NekoImport$Future<T>>;
        invokeAll<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[])): $List<$NekoImport$Future<T>>;
        invokeAny<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[]), arg1: number, arg2: $TimeUnit_): T;
        invokeAny<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[])): T;
        iterator(): $Iterator<$EventExecutor>;
        next(): $EventExecutor;
        scheduleAtFixedRate(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        scheduleWithFixedDelay(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        schedule(arg0: $Runnable_, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<any>;
        schedule<V>(arg0: $Callable_<V, V>, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<V>;
        shutdownGracefully(arg0: number, arg1: number, arg2: $TimeUnit_): $Future<any>;
        shutdownGracefully(): $Future<any>;
        shutdownNow(): $List<$Runnable>;
        shutdown(): void;
        spliterator(): $Spliterator<$EventExecutor>;
        submit<T>(arg0: $Runnable_, arg1: T): $Future<T>;
        submit(arg0: $Runnable_): $Future<any>;
        submit<T>(arg0: $Callable_<T, T>): $Future<T>;
        terminationFuture(): $Future<any>;
    }

    export class $SingleThreadEventExecutor extends $AbstractScheduledEventExecutor implements $OrderedEventExecutor {
        isShutdown(): boolean;
        get shuttingDown(): boolean;
        isShuttingDown(): boolean;
        get terminated(): boolean;
        isTerminated(): boolean;
        addShutdownHook(arg0: $Runnable_): void;
        awaitTermination(arg0: number, arg1: $TimeUnit_): boolean;
        close(): void;
        execute(arg0: $Runnable_): void;
        forEach(arg0: $Consumer_<$EventExecutor, $EventExecutor>): void;
        inEventLoop(arg0: $Thread): boolean;
        inEventLoop(): boolean;
        invokeAll<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[]), arg1: number, arg2: $TimeUnit_): $List<$NekoImport$Future<T>>;
        invokeAll<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[])): $List<$NekoImport$Future<T>>;
        invokeAny<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[]), arg1: number, arg2: $TimeUnit_): T;
        invokeAny<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[])): T;
        iterator(): $Iterator<$EventExecutor>;
        lazyExecute(arg0: $Runnable_): void;
        newFailedFuture<V>(arg0: $Throwable): $Future<V>;
        newProgressivePromise<V>(): $ProgressivePromise<V>;
        newPromise<V>(): $Promise<V>;
        newSucceededFuture<V>(arg0: V): $Future<V>;
        next(): $EventExecutor;
        parent(): $EventExecutorGroup;
        pendingTasks(): number;
        removeShutdownHook(arg0: $Runnable_): void;
        scheduleAtFixedRate(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        scheduleWithFixedDelay(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        schedule(arg0: $Runnable_, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<any>;
        schedule<V>(arg0: $Callable_<V, V>, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<V>;
        shutdownGracefully(arg0: number, arg1: number, arg2: $TimeUnit_): $Future<any>;
        shutdownGracefully(): $Future<any>;
        shutdownNow(): $List<$Runnable>;
        shutdown(): void;
        spliterator(): $Spliterator<$EventExecutor>;
        submit<T>(arg0: $Runnable_, arg1: T): $Future<T>;
        submit(arg0: $Runnable_): $Future<any>;
        submit<T>(arg0: $Callable_<T, T>): $Future<T>;
        terminationFuture(): $Future<any>;
        threadProperties(): $ThreadProperties;
    }

    export class $AbstractScheduledEventExecutor extends $AbstractEventExecutor {
        isShutdown(): boolean;
        get shuttingDown(): boolean;
        isShuttingDown(): boolean;
        get terminated(): boolean;
        isTerminated(): boolean;
        awaitTermination(arg0: number, arg1: $TimeUnit_): boolean;
        close(): void;
        execute(arg0: $Runnable_): void;
        forEach(arg0: $Consumer_<$EventExecutor, $EventExecutor>): void;
        inEventLoop(arg0: $Thread): boolean;
        inEventLoop(): boolean;
        scheduleAtFixedRate(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        scheduleWithFixedDelay(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        schedule(arg0: $Runnable_, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<any>;
        schedule<V>(arg0: $Callable_<V, V>, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<V>;
        shutdownGracefully(arg0: number, arg1: number, arg2: $TimeUnit_): $Future<any>;
        shutdownGracefully(): $Future<any>;
        shutdown(): void;
        spliterator(): $Spliterator<$EventExecutor>;
        terminationFuture(): $Future<any>;
    }

    export interface $ThreadProperties {
        id(): number;
        isAlive(): boolean;
        isDaemon(): boolean;
        isInterrupted(): boolean;
        name(): string;
        priority(): number;
        stackTrace(): $StackTraceElement[];
        state(): $Thread$State;
    }

    export class $AbstractEventExecutor extends $AbstractExecutorService implements $EventExecutor {
        isShutdown(): boolean;
        get shuttingDown(): boolean;
        isShuttingDown(): boolean;
        get terminated(): boolean;
        isTerminated(): boolean;
        awaitTermination(arg0: number, arg1: $TimeUnit_): boolean;
        close(): void;
        execute(arg0: $Runnable_): void;
        forEach(arg0: $Consumer_<$EventExecutor, $EventExecutor>): void;
        inEventLoop(arg0: $Thread): boolean;
        inEventLoop(): boolean;
        invokeAll<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[]), arg1: number, arg2: $TimeUnit_): $List<$NekoImport$Future<T>>;
        invokeAll<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[])): $List<$NekoImport$Future<T>>;
        invokeAny<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[]), arg1: number, arg2: $TimeUnit_): T;
        invokeAny<T>(arg0: ($Collection<$Callable<T>> | ($Callable_<T, T>)[])): T;
        iterator(): $Iterator<$EventExecutor>;
        lazyExecute(arg0: $Runnable_): void;
        newFailedFuture<V>(arg0: $Throwable): $Future<V>;
        newProgressivePromise<V>(): $ProgressivePromise<V>;
        newPromise<V>(): $Promise<V>;
        newSucceededFuture<V>(arg0: V): $Future<V>;
        next(): $EventExecutor;
        parent(): $EventExecutorGroup;
        scheduleAtFixedRate(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        scheduleWithFixedDelay(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        schedule(arg0: $Runnable_, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<any>;
        schedule<V>(arg0: $Callable_<V, V>, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<V>;
        shutdownGracefully(arg0: number, arg1: number, arg2: $TimeUnit_): $Future<any>;
        shutdownGracefully(): $Future<any>;
        shutdownNow(): $List<$Runnable>;
        shutdown(): void;
        spliterator(): $Spliterator<$EventExecutor>;
        submit<T>(arg0: $Runnable_, arg1: T): $Future<T>;
        submit(arg0: $Runnable_): $Future<any>;
        submit<T>(arg0: $Callable_<T, T>): $Future<T>;
        terminationFuture(): $Future<any>;
    }

    export type $GenericFutureListener_<Host0 extends $Future<any> = any, CallbackArg0 = Host0> = ((arg0: CallbackArg0) => void) | ($GenericFutureListener<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $EventExecutorChooserFactory_<CallbackArg0 = $EventExecutor[], CallbackResult = $EventExecutorChooserFactory$EventExecutorChooser_<$EventExecutor>> = ((arg0: CallbackArg0) => CallbackResult) | ($EventExecutorChooserFactory & { readonly [Symbol.hasInstance]?: never });
    export type $RejectedExecutionHandler_<CallbackArg0 = $Runnable, CallbackArg1 = $SingleThreadEventExecutor> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($RejectedExecutionHandler & { readonly [Symbol.hasInstance]?: never });
    export type $EventExecutorChooserFactory$EventExecutorChooser_<CallbackResult = $EventExecutor> = (() => CallbackResult) | ($EventExecutorChooserFactory$EventExecutorChooser & { readonly [Symbol.hasInstance]?: never });
}
