import type { $TypeScriptClassBoundsTest$Bounded as Bounded,
    $TypeScriptClassBoundsTest$Bounded_ as Input } from 'java:com/tkisor/nekojs/probe';
declare const left: Bounded<{base: number; alternate(): string}>;
declare const right: Bounded<{base: number; alternateNumber(): number}>;
const encoded: Input<{base: number; alternate(): string}> = 'encoded';
// @ts-expect-error Every union alternative must still satisfy the first bound.
declare const missingPrimary: Bounded<{alternate(): string}>;
// @ts-expect-error Adapter aliases retain the same intersection grouping.
declare const invalidInput: Input<{alternate(): string}>;
