import type { $TypeScriptClassBoundsTest$Bounded as Bounded } from 'java:com/tkisor/nekojs/probe';
declare const valid: Bounded<{base: number; marker(): string}>;
const marker: string = valid.value.marker();
// @ts-expect-error The second bound is required alongside the first.
declare const missingSecondary: Bounded<{base: number}>;
// @ts-expect-error The first bound remains required.
declare const missingPrimary: Bounded<{marker(): string}>;
import type { $TypeScriptClassBoundsTest$Bounded_ as Input,
    $RenamedBounded as Renamed } from 'java:com/tkisor/nekojs/probe';
const encoded: Input<{base: number; marker(): string}> = 'encoded';
declare const renamed: Renamed<{base: number; marker(): string}>;
const canonical: Bounded<{base: number; marker(): string}> = renamed;
// @ts-expect-error Adapter aliases retain the second bound.
declare const invalidInput: Input<{base: number}>;
