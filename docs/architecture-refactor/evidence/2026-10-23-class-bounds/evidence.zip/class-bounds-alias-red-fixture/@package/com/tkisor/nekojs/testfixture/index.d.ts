export * as probe from "java:com/tkisor/nekojs/testfixture/probe";

