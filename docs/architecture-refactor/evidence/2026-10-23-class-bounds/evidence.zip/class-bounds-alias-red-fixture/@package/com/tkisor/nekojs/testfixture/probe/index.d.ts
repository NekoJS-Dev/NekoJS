declare module "java:com/tkisor/nekojs/testfixture/probe" {
    export interface $SecondaryBound {
        marker(): string;
    }

    export type $SecondaryBound_<CallbackResult = string> = (() => CallbackResult) | ($SecondaryBound & { readonly [Symbol.hasInstance]?: never });
}
