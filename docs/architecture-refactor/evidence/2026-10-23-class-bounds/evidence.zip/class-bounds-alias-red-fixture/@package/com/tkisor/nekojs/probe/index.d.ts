import { $SecondaryBound, $SecondaryBound_ } from "java:com/tkisor/nekojs/testfixture/probe";

declare module "java:com/tkisor/nekojs/probe" {
    export class $RenamedBounded<T extends $TypeScriptClassBoundsTest$Primary & $SecondaryBound> {
        constructor();
        value: T;
    }
    export type $TypeScriptClassBoundsTest$Bounded<T extends $TypeScriptClassBoundsTest$Primary> = $RenamedBounded<T>;
    export const $TypeScriptClassBoundsTest$Bounded: typeof $RenamedBounded;

    export class $TypeScriptClassBoundsTest$Primary {
        constructor();
        base: number;
    }

    export type $TypeScriptClassBoundsTest$Bounded_<T extends $TypeScriptClassBoundsTest$Primary = any> = $TypeScriptClassBoundsTest$Bounded<T> | string;
}
