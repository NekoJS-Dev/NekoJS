declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptClassBoundsTest$Bounded<T extends $TypeScriptClassBoundsTest$Primary> {
        constructor();
        value: T;
    }

    export class $TypeScriptClassBoundsTest$Primary {
        constructor();
        base: number;
    }

}
