$env:PSModulePath = "C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules"
$ErrorActionPreference = 'Stop'
$ownedRoot = 'C:\Users\11515\.codex\worktrees\reload-perf-8ed398\NekoJS-mult'
$evidenceRoot = 'D:\mcmodDemo\NekoJS-mult\build\reload-performance-20261015\formal-candidate'
$expectedRevision = 'e473479af6dcb0f9483b36a0d93207721904025f'
$expectedSampler = '1F9C5D14A1A586DA4B3F1CA8E71B2407CE089EE8BEE185418963E1B5745DF0B4'
$javaRoot = 'C:\Program Files\Java\jdk-25.0.2'
$env:JAVA_HOME = $javaRoot
$env:PATH = "$javaRoot\bin;$env:PATH"
if (Test-Path -LiteralPath $evidenceRoot) { throw 'Formal evidence already exists' }
New-Item -ItemType Directory -Path $evidenceRoot | Out-Null
Set-Location -LiteralPath $ownedRoot
$samplerPath = Join-Path $ownedRoot 'bench\perf\sample.ps1'
function Assert-Inputs {
    if ((& git rev-parse HEAD).Trim() -ne $expectedRevision) { throw 'Unexpected source revision' }
    if (@(& git status --porcelain).Count -ne 0) { throw 'Source checkout is not clean' }
    if ((Get-FileHash -LiteralPath $samplerPath).Hash -ne $expectedSampler) { throw 'Sampler changed' }
    $runRoot = Join-Path $ownedRoot 'versions\26.1.2\run'
    $checkedPath = Get-Item -LiteralPath $runRoot
    while ($null -ne $checkedPath) {
        if (($checkedPath.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Run path contains a reparse point' }
        $checkedPath = $checkedPath.Parent
    }
    if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 25871,25872).Count -ne 0) { throw 'Benchmark ports occupied' }
}
Assert-Inputs
$compiledClassesBefore = @{}
foreach ($classDirectory in @('common/build/classes/java/main','versions/26.1.2/build/classes/java/main')) {
    Get-ChildItem -LiteralPath (Join-Path $ownedRoot $classDirectory) -Recurse -File -Filter '*.class' | ForEach-Object { $compiledClassesBefore[$_.FullName.Substring($ownedRoot.Length + 1).Replace('\','/')] = (Get-FileHash -LiteralPath $_.FullName).Hash }
}
$compiledClassesBefore | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $evidenceRoot 'compiled-classes-before.json') -Encoding utf8
$fixtures = @(Get-ChildItem -LiteralPath (Join-Path $ownedRoot 'bench\perf\fixtures\nekojs') -Recurse -File | Sort-Object FullName | ForEach-Object {
    @{ path = $_.FullName.Substring($ownedRoot.Length + 1); sha256 = (Get-FileHash -LiteralPath $_.FullName).Hash }
})
@{ revision = $expectedRevision; samplerSha256 = $expectedSampler; javaRoot = $javaRoot; fixtures = $fixtures; reloadGroups = 2; samplesPerGroup = 5; reloadThresholdMs = 285.3; startupWarmup = 2; startupSamples = 5; startupThresholdMs = 41173; earlierCapture = 'Baseline and diagnostic failures retained separately; candidate groups declared before measurement' } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $evidenceRoot 'binding.json') -Encoding utf8
$groups = @(
    @{ name = 'reload-1'; mode = 'reload' },
    @{ name = 'reload-2'; mode = 'reload' },
    @{ name = 'startup'; mode = 'startup' }
)
foreach ($group in $groups) {
    Assert-Inputs
    $name = $group.name
    $sampleArgs = '-NoProfile -ExecutionPolicy Bypass -File "' + $samplerPath + '" -Mode ' + $group.mode + ' -Node 26.1.2 -Warmup 2 -Samples 5 -Reloads 5 -GradleUserHome "D:\mcmodDemo\NekoJS\.gradle-perf02" -ServerPort 25871 -RconPort 25872'
    Write-Output "FORMAL_${name}_BEGIN"
    $sampleProcess = Start-Process -FilePath 'powershell.exe' -ArgumentList $sampleArgs -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $evidenceRoot "$name.stdout.log") -RedirectStandardError (Join-Path $evidenceRoot "$name.stderr.log")
    $null = $sampleProcess.Handle
    $sampleProcess.WaitForExit()
    $sampleExit = $sampleProcess.ExitCode
    @{ name = $name; pid = $sampleProcess.Id; directExit = $sampleExit; endedUtc = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $evidenceRoot "$name.exit.json") -Encoding utf8
    if ($sampleExit -ne 0) { throw "Sampler $name failed: $sampleExit" }
    Write-Output "FORMAL_${name}_COLLECTED"
}
Assert-Inputs
$artifacts = @(Get-ChildItem -LiteralPath (Join-Path $ownedRoot 'versions\26.1.2\build\libs') -Filter '*.jar' -File | ForEach-Object { @{ name = $_.Name; sha256 = (Get-FileHash -LiteralPath $_.FullName).Hash } })
$artifacts | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $evidenceRoot 'artifacts.json') -Encoding utf8
foreach ($classEntry in $compiledClassesBefore.GetEnumerator()) {
    if ((Get-FileHash -LiteralPath (Join-Path $ownedRoot $classEntry.Key)).Hash -ne $classEntry.Value) { throw 'Compiled classes changed during measurement' }
}
Write-Output 'FORMAL_COLLECTION_COMPLETE'

