declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptRawOutputTest$Slot<T> {
        constructor(value: T);
        value: T;
        get(): T;
    }

    export class $TypeScriptRawOutputTest$RawBound<T extends $TypeScriptRawOutputTest$Slot> {
        constructor();
        value: T;
    }

    export class $TypeScriptRawOutputTest$NestedBound<T extends $TypeScriptRawOutputTest$Slot<$TypeScriptRawOutputTest$Slot>> {
        constructor();
        value: T;
    }

    export interface $TypeScriptRawOutputTest$Factory<T extends $TypeScriptRawOutputTest$Slot> {
        create(value: T): $TypeScriptRawOutputTest$Slot;
    }

    export class $TypeScriptRawOutputTest$Api {
        constructor();
        array: $TypeScriptRawOutputTest$Slot[];
        nested: $TypeScriptRawOutputTest$Slot<$TypeScriptRawOutputTest$Slot>;
        raw: $TypeScriptRawOutputTest$Slot;
        wildcard: $TypeScriptRawOutputTest$Slot<$TypeScriptRawOutputTest$Slot>;
        callback(factory: $TypeScriptRawOutputTest$Factory_<$TypeScriptRawOutputTest$Slot<any>, $TypeScriptRawOutputTest$Slot<any>, $TypeScriptRawOutputTest$Slot<any>>): $TypeScriptRawOutputTest$Slot;
        exact(): $TypeScriptRawOutputTest$Slot<string>;
        rawResult(): $TypeScriptRawOutputTest$Slot;
    }

    export type $TypeScriptRawOutputTest$Factory_<Host0 extends $TypeScriptRawOutputTest$Slot = any, CallbackArg0 = Host0, CallbackResult = $TypeScriptRawOutputTest$Slot<any>> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptRawOutputTest$Factory<Host0> & { readonly [Symbol.hasInstance]?: never });
}
