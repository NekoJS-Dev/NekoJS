"""Run the selected raw-use-site regressions with the existing local toolchain."""
import os
import subprocess
import sys
from pathlib import Path

repo = Path.cwd()
env = os.environ.copy()
env['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
env['GRADLE_USER_HOME'] = 'D:/mcmodDemo/NekoJS/.gradle-perf02'
env['PATH'] = env['JAVA_HOME'] + '/bin;' + env['PATH']
args = [str(repo / 'gradlew.bat'), ':common:test', '--tests',
        'com.tkisor.nekojs.probe.ir.TypeScriptRawOutputTest',
        '-Dorg.gradle.java.home=' + env['JAVA_HOME'], '--offline', '--no-parallel', '--console=plain']
result = subprocess.run(args, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        creationflags=subprocess.CREATE_NO_WINDOW)
sys.stdout.buffer.write(result.stdout)
sys.exit(result.returncode)
