"""Freeze raw generic regressions and full common checks for the exact committed source."""
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
dest = repo / 'docs/architecture-refactor/evidence/2026-10-23-raw-generic-output'
assert not dest.exists()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision.startswith('c0bc2dbe')
entries = {}
def add(name, file):
    entries[name] = file.read_bytes()

sources = ['common/src/main/java/com/tkisor/nekojs/probe/backend/typescript/FunctionalInterfaceAliasGenerator.java',
           'common/src/main/java/com/tkisor/nekojs/probe/backend/typescript/JavaTypeScriptProjection.java',
           'common/src/main/java/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.java',
           'common/src/test/java/com/tkisor/nekojs/probe/ir/TypeScriptRawOutputTest.java', 'package.json']
for name in sources:
    data = (repo / name).read_bytes().replace(b'\r\n', b'\n')
    assert data == subprocess.check_output(['git', 'show', revision + ':' + name]).replace(b'\r\n', b'\n'), name
    add('source/' + name, repo / name)
entries['source.patch'] = subprocess.check_output(['git', 'diff', 'a9cd4f09', revision, '--', *sources,
    'common/src/main/java/com/tkisor/nekojs/probe/backend/typescript/JavaObjectTypeProjection.java'])
counts = dict(tests=0, failures=0, errors=0, skipped=0)
for file in (repo / 'common/build/test-results/test').glob('TEST-*.xml'):
    add('common-xml/' + file.name, file)
    suite = ET.parse(file).getroot()
    for key in counts:
        counts[key] += int(suite.attrib.get(key, 0))
assert counts['tests'] == 2420 and counts['skipped'] == 4 and counts['failures'] == counts['errors'] == 0, counts
for folder in ['raw-output-probe-xml', 'raw-output-red-fixtures']:
    for file in (tools / folder).rglob('*'):
        if file.is_file():
            add(folder + '/' + file.relative_to(tools / folder).as_posix(), file)
for file in (repo / 'common/build/probe-ts-raw-output').rglob('*'):
    if file.is_file():
        add('final-fixtures/' + file.relative_to(repo / 'common/build/probe-ts-raw-output').as_posix(), file)
for file in tools.glob('raw-output-*'):
    if file.is_file():
        add('tools/' + file.name, file)
for name in ['run-raw-output-check.py', 'freeze-raw-output-probe.py', 'seal-raw-output.py']:
    add('tools/' + name, tools / name)
summary = dict(productionRevision=revision, common=counts, probe=json.loads(
    (tools / 'raw-output-probe-xml/counts.json').read_text()), strictModes=['plain', 'renamed', 'edited'],
    fullTargetedTypeChain='PASS', fullInstalledIde='NOT RUN for this source; preceding source still FAIL 5857',
    nodeBuilds='NOT RUN for this source', performance='NOT RUN for this source; previous formal reload FAIL',
    review=dict(standardsHard=0, standardsSmells=0, specFindings=0, readOnly=True), maintainerAcceptance=False)
entries['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
dest.mkdir()
with zipfile.ZipFile(dest / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(dest / 'manifest.json').write_text(json.dumps(dict(
    archiveSha256=hashlib.sha256((dest / 'evidence.zip').read_bytes()).hexdigest(),
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
             for name, data in sorted(entries.items())}), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(dest / 'evidence.zip').stat().st_size, common=counts)))
