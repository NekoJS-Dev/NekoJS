"""Preserve the selected Probe results before the full common check replaces reports."""
import json
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path.cwd()
dest = repo / 'build/priority-closeout/raw-output-probe-xml'
assert not dest.exists()
dest.mkdir()
counts = dict(tests=0, failures=0, errors=0, skipped=0)
for source in (repo / 'common/build/test-results/test').glob('TEST-*.xml'):
    assert '.probe.' in source.name, source.name
    suite = ET.parse(source).getroot()
    for key in counts:
        counts[key] += int(suite.attrib.get(key, 0))
    shutil.copy2(source, dest / source.name)
assert counts['failures'] == counts['errors'] == 0
(dest / 'counts.json').write_text(json.dumps(counts, indent=2) + '\n')
print(json.dumps(counts))
