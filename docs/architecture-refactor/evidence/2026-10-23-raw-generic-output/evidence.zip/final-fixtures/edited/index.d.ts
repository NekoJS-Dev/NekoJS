import { $Comparable, $Comparable_ } from "java:java/lang";

declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptRawOutputTest$Slot<T> {
        constructor(value: T);
        value: T;
        get(): T;
    }

    export class $TypeScriptRawOutputTest$RawBound<T extends $TypeScriptRawOutputTest$Slot<string>> {
        constructor();
        value: T;
    }

    export class $TypeScriptRawOutputTest$NestedBound<T extends $TypeScriptRawOutputTest$Slot<$TypeScriptRawOutputTest$Slot<any>>> {
        constructor();
        value: T;
    }

    export class $TypeScriptRawOutputTest$RawComparable<T extends ($Comparable<any> | string | number | boolean)> {
        constructor();
        value: T;
        static numbers(): $TypeScriptRawOutputTest$RawComparable<number>;
    }

    export interface $TypeScriptRawOutputTest$Factory<T extends $TypeScriptRawOutputTest$Slot<any>> {
        create(value: T): $TypeScriptRawOutputTest$Slot<any>;
    }

    export interface $TypeScriptRawOutputTest$CompareFactory<T extends ($Comparable<any> | string | number | boolean)> {
        create(): T;
    }

    export class $TypeScriptRawOutputTest$Api {
        constructor();
        array: $TypeScriptRawOutputTest$Slot<any>[];
        nested: $TypeScriptRawOutputTest$Slot<$TypeScriptRawOutputTest$Slot<any>>;
        raw: $TypeScriptRawOutputTest$Slot<string>;
        wildcard: $TypeScriptRawOutputTest$Slot<$TypeScriptRawOutputTest$Slot<any>>;
        callback(factory: $TypeScriptRawOutputTest$Factory_<$TypeScriptRawOutputTest$Slot<any>, $TypeScriptRawOutputTest$Slot<any>, $TypeScriptRawOutputTest$Slot<any>>): $TypeScriptRawOutputTest$Slot<any>;
        compareCallback(factory: $TypeScriptRawOutputTest$CompareFactory_<string, string>): string;
        exact(): $TypeScriptRawOutputTest$Slot<string>;
        rawResult(): boolean;
    }

    export type $TypeScriptRawOutputTest$Factory_<Host0 extends $TypeScriptRawOutputTest$Slot<any> = any, CallbackArg0 = Host0, CallbackResult = $TypeScriptRawOutputTest$Slot<any>> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptRawOutputTest$Factory<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptRawOutputTest$CompareFactory_<Host0 extends ($Comparable<any> | string | number | boolean) = any, CallbackResult = Host0> = (() => CallbackResult) | ($TypeScriptRawOutputTest$CompareFactory<Host0> & { readonly [Symbol.hasInstance]?: never });
}
