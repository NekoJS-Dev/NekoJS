import { $TypeScriptRawOutputTest$Api as Api, $TypeScriptRawOutputTest$Slot as Slot,
    $TypeScriptRawOutputTest$RawBound as RawBound, $TypeScriptRawOutputTest$NestedBound as NestedBound,
    $TypeScriptRawOutputTest$RawComparable as RawComparable
    } from 'java:com/tkisor/nekojs/probe/ir';
declare const api: Api;
const exact: string = api.exact().value;
api.array[0].value = 'raw';
api.nested.value.value = 7;
api.wildcard.value.value = true;
api.callback(value => value);
api.compareCallback(() => 'value');
declare const bounded: RawBound<Slot<string>>;
const value: string = bounded.value.value;
declare const nested: NestedBound<Slot<Slot<number>>>;
const number: number = nested.value.value.value;
const comparableNumber: number = RawComparable.numbers().value;
declare const comparableString: RawComparable<string>;
// @ts-expect-error Raw Comparable still requires a compatible Java host or primitive.
declare const invalidComparable: RawComparable<{ unrelated: string }>;
// @ts-expect-error An explicit type argument still preserves its value type.
const wrong: number = api.exact().value;
// @ts-expect-error A raw upper bound is still a host bound.
declare const invalid: RawBound<number>;
const edited: string = api.raw.value;
const editedResult: boolean = api.rawResult();
// @ts-expect-error An edited field must not revert to raw erasure.
api.raw.value = 7;
// @ts-expect-error An edited bound must not revert to raw erasure.
declare const invalidEdited: RawBound<Slot<number>>;
