declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptInheritedBeanTest$FieldParent {
        constructor();
        flag: boolean;
    }

    export class $TypeScriptInheritedBeanTest$ReadChild extends $TypeScriptInheritedBeanTest$FieldParent {
        constructor();
        readonly flag: boolean;
        isFlag(): boolean;
    }

    export class $TypeScriptInheritedBeanTest$ReadLeaf extends $TypeScriptInheritedBeanTest$ReadChild {
        constructor();
        readonly flag: boolean;
        isFlag(): boolean;
    }

    export class $TypeScriptInheritedBeanTest$WriteChild extends $TypeScriptInheritedBeanTest$FieldParent {
        constructor();
        flag: boolean;
        isFlag(): boolean;
        setFlag(value: boolean): void;
    }

    export class $TypeScriptInheritedBeanTest$WriteLeaf extends $TypeScriptInheritedBeanTest$WriteChild {
        constructor();
        flag: boolean;
        isFlag(): boolean;
        setFlag(value: boolean): void;
    }

    export class $TypeScriptInheritedBeanTest$AccessorParent {
        constructor();
        get flag(): boolean;
        set flag(value: boolean);
        isFlag(): boolean;
        setFlag(value: boolean): void;
    }

    export class $TypeScriptInheritedBeanTest$AccessorChild extends $TypeScriptInheritedBeanTest$AccessorParent {
        constructor();
        get flag(): boolean;
        isFlag(): boolean;
        set flag(value: boolean);
        setFlag(value: boolean): void;
    }

    export class $TypeScriptInheritedBeanTest$FieldBeanChild extends $TypeScriptInheritedBeanTest$FieldParent {
        constructor();
        flag: boolean;
        isFlag(): boolean;
    }

    export class $TypeScriptInheritedBeanTest$FieldBeanLeaf extends $TypeScriptInheritedBeanTest$FieldBeanChild {
        constructor();
        readonly flag: boolean;
        isFlag(): boolean;
    }

}
