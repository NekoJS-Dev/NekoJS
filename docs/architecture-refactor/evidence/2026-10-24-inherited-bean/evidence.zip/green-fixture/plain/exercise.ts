import type { $TypeScriptInheritedBeanTest$FieldParent as Parent,
  $TypeScriptInheritedBeanTest$ReadChild as ReadChild,
  $TypeScriptInheritedBeanTest$ReadLeaf as ReadLeaf,
  $TypeScriptInheritedBeanTest$WriteChild as WriteChild,
  $TypeScriptInheritedBeanTest$WriteLeaf as WriteLeaf,
  $TypeScriptInheritedBeanTest$AccessorChild as AccessorChild,
  $TypeScriptInheritedBeanTest$FieldBeanChild as FieldBeanChild,
  $TypeScriptInheritedBeanTest$FieldBeanLeaf as FieldBeanLeaf } from 'java:com/tkisor/nekojs/probe/ir';
declare const read: ReadChild;
declare const leaf: ReadLeaf;
declare const write: WriteChild;
declare const writeLeaf: WriteLeaf;
declare const accessor: AccessorChild;
declare const fieldBean: FieldBeanChild;
declare const fieldLeaf: FieldBeanLeaf;
const parent: Parent = read;
const readValue: boolean = read.flag;
const methodValue: boolean = read.isFlag();
const leafValue: boolean = leaf.flag;
write.flag = true;
write.setFlag(false);
writeLeaf.flag = false;
writeLeaf.setFlag(true);
accessor.flag = true;
fieldBean.flag = true;
const fieldRead: boolean = fieldBean.isFlag();
const fieldLeafRead: boolean = fieldLeaf.flag;
// @ts-expect-error An inherited field does not broaden a getter-only alias's declared write support.
fieldLeaf.flag = true;
// @ts-expect-error A getter-only Bean remains read-only on its concrete type.
read.flag = true;
// @ts-expect-error The projected read-only shape survives another subclass.
leaf.flag = false;
// @ts-expect-error A writer keeps its original boolean input.
write.flag = 'flag';
// @ts-expect-error Real setter methods retain their input type.
writeLeaf.setFlag('flag');
// @ts-expect-error A boolean property does not acquire a callable intersection.
read.flag();
