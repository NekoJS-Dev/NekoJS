import { $EventTypes$Key as $NekoImport$EventTypes$Key, $EventTypes$Key_ as $NekoImport$EventTypes$Key_, $EventTypes$Payload as $NekoImport$EventTypes$Payload } from "java:othermod/events";
import { $EventTypes$Key as $NekoImport$EventTypes$Key1, $EventTypes$Key_ as $NekoImport$EventTypes$Key_1, $EventTypes$Payload as $NekoImport$EventTypes$Payload1 } from "java:othermod/events/second";

declare module "@side-only/test/events" {
}

export {};

declare global {
    namespace IdentityEvents {
        function first(handler: ((event: $NekoImport$EventTypes$Payload) => void)): void;
        function first(extra: $NekoImport$EventTypes$Key_, handler: ((event: $NekoImport$EventTypes$Payload) => void)): void;
        function second(handler: ((event: $NekoImport$EventTypes$Payload1) => void)): void;
        function second(extra: $NekoImport$EventTypes$Key_1, handler: ((event: $NekoImport$EventTypes$Payload1) => void)): void;
        function arrays(handler: ((event: $NekoImport$EventTypes$Payload1) => void)): void;
        function arrays(extra: $NekoImport$EventTypes$Key_1[], handler: ((event: $NekoImport$EventTypes$Payload1) => void)): void;
    }

}
