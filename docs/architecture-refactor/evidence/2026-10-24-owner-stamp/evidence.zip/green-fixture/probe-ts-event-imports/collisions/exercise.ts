import type { $EventTypes$Key as FirstKey } from 'java:othermod/events';
import type { $EventTypes$Key as SecondKey } from 'java:othermod/events/second';
declare const first: FirstKey;
declare const second: SecondKey;
IdentityEvents.first(first, event => {
    const count: number = event.count;
    // @ts-expect-error The other event's fields must remain unavailable.
    event.text;
});
IdentityEvents.second(second, event => {
    const text: string = event.text;
    // @ts-expect-error An import collision must not substitute the first payload.
    event.count;
});
IdentityEvents.first('first', event => {});
IdentityEvents.second('second', event => {});
IdentityEvents.arrays([second, 'second'], event => { const text: string = event.text; });
// @ts-expect-error Dispatch adapter aliases retain their Java identity.
IdentityEvents.first(second, event => {});
// @ts-expect-error Literal inputs must use the matching adapter.
IdentityEvents.second('first', event => {});
// @ts-expect-error Array dispatch inputs use the same local import mapping.
IdentityEvents.arrays([first], event => {});
