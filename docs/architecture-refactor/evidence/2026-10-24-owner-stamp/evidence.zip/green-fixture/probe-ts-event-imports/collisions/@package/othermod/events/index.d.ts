export * as second from "java:othermod/events/second";

declare module "java:othermod/events" {
    export class $EventTypes$Payload {
        constructor();
        count: number;
    }

    export class $EventTypes$Key {
        constructor();
        name: string;
    }

    export type $EventTypes$Key_ = $EventTypes$Key | "first";
}
