declare module "java:othermod/events/second" {
    export class $EventTypes$Payload {
        constructor();
        text: string;
    }

    export class $EventTypes$Key {
        constructor();
        id: number;
    }

    export type $EventTypes$Key_ = $EventTypes$Key | "second";
}
