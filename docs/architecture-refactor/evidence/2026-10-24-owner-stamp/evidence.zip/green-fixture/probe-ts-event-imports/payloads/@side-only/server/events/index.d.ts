/// <reference path="../../../@event-builders/index.d.ts" />

import { $EventTypes$Payload as $NekoImport$EventTypes$Payload } from "java:othermod/events";

interface $EventTypes$Payload {
    readonly accepted: boolean;
}

declare module "@side-only/server/events" {
}

export {};

declare global {
    namespace PayloadEvents {
        function reflected(handler: ((event: $NekoImport$EventTypes$Payload) => void)): void;
        function scripted(handler: ((event: $EventTypes$Payload) => void)): void;
        namespace custom {
            function post(payload?: any): void;
        }
        function custom(handler: ((payload: any) => void)): void;
    }

}
