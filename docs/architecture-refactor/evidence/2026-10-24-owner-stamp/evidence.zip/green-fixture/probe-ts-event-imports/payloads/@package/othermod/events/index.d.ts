declare module "java:othermod/events" {
    export class $EventTypes$Payload {
        constructor();
        count: number;
    }

}
