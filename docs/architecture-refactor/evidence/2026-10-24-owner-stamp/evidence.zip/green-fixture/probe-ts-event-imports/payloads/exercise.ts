PayloadEvents.reflected(event => {
    const count: number = event.count;
    // @ts-expect-error Local payload names must not replace reflected types.
    event.accepted;
});
PayloadEvents.scripted(event => {
    const accepted: boolean = event.accepted;
    // @ts-expect-error Builder payloads retain their read-only contract.
    event.accepted = false;
    // @ts-expect-error Replaced payloads do not expose host fields.
    event.hiddenHostMember;
});
PayloadEvents.custom(payload => {});
PayloadEvents.custom.post({ custom: 12 });
