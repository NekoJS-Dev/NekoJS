import { $TypeScriptOwnerGenericTest$Owner$Inner } from "java:com/tkisor/nekojs/probe/ir";

declare module "@side-only/test/events" {
}

export {};

declare global {
    namespace OwnerEvents {
        function visit(handler: ((event: $TypeScriptOwnerGenericTest$Owner$Inner<any, any>) => void)): void;
        function visit(extra: $TypeScriptOwnerGenericTest$Owner$Inner<any, any>, handler: ((event: $TypeScriptOwnerGenericTest$Owner$Inner<any, any>) => void)): void;
    }

}
