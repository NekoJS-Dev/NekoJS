declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptOwnerGenericTest$Owner$Inner<T extends $TypeScriptOwnerGenericTest$Owner<T>, V> implements $TypeScriptOwnerGenericTest$CapturedContract<T> {
        constructor(this$0: $TypeScriptOwnerGenericTest$Owner<any>, value: V);
        value: V;
        choose<T1>(input: T1): T;
        update(value: V): T;
    }

    export interface $TypeScriptOwnerGenericTest$CapturedContract<X> {
        choose<T>(input: T): X;
    }

    export class $TypeScriptOwnerGenericTest$Owner<T extends $TypeScriptOwnerGenericTest$Owner<T>> {
        constructor();
    }

}
