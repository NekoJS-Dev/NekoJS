import type { $TypeScriptOwnerGenericTest$Owner$Inner as Inner } from 'java:com/tkisor/nekojs/probe/ir';
declare const inner: Inner<any, string>;
const returned: OwnerOutput = ownedAccept(inner);
returned.update('value');
// @ts-expect-error Explicit raw manual references retain the host member shape.
returned.missing;
// @ts-expect-error Raw manual inputs do not accept scalar values.
ownedAccept(12);
OwnerEvents.visit(inner, event => {
    event.update('value');
    // @ts-expect-error A raw inner event still retains its actual member names.
    event.missing;
});
// @ts-expect-error Raw dispatch erasure preserves the host shape.
OwnerEvents.visit(12, event => {});
