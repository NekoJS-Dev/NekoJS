import type { $TypeScriptOwnerGenericTest$Concrete as Concrete } from 'java:com/tkisor/nekojs/probe/ir';
declare const concrete: Concrete;
const updated: Concrete = concrete.text.update('value');
const chosen: Concrete = concrete.text.choose<number>(12);
// @ts-expect-error An inherited method's variable must not replace its captured result variable.
const wrongChosen: string = concrete.text.choose<number>(12);
// @ts-expect-error The inherited method retains its own explicit type parameter.
concrete.text.choose<string>(12);
const count: number = updated.count;
const text: string = concrete.text.value;
concrete.consume(concrete.text);
concrete.factory(() => concrete.text);
concrete.sink(value => { const owner: Concrete = value.update('value'); });
concrete.raw.update(12);
const leafOwner: Concrete = concrete.leaf.owner();
const middle: string = concrete.leaf.middle;
const leaf: boolean = concrete.leaf.leaf;
const boundaryKey: number = concrete.boundary.key;
const boundaryValue: string = concrete.boundary.value;
const shadowMember: string = concrete.shadow.member;
const shadowLeaf: boolean = concrete.shadow.leaf;
// @ts-expect-error Three levels retain each argument's identity.
const wrongLeaf: string = concrete.leaf.leaf;
// @ts-expect-error Same-spelled Java variables belong to different declarations.
const wrongShadow: number = concrete.shadow.member;
// @ts-expect-error Captured owners retain their actual result contract.
const wrong: string = concrete.text.update('value');
// @ts-expect-error The inner argument keeps its own identity.
concrete.text.update(12);
// @ts-expect-error Parameterized inner input types preserve their owner and member arguments.
concrete.consume(concrete.number);
// @ts-expect-error Callback results retain captured and member arguments.
concrete.factory(() => concrete.number);
