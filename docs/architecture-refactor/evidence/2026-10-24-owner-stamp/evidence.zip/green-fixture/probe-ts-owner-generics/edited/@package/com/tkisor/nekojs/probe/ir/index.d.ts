declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptOwnerGenericTest$Owner<T extends $TypeScriptOwnerGenericTest$Owner<T>> {
        constructor();
    }

    export class $RenamedInner<T extends $TypeScriptOwnerGenericTest$Owner<T>, V> implements $TypeScriptOwnerGenericTest$CapturedContract<T> {
        constructor(this$0: $TypeScriptOwnerGenericTest$Owner<any>, value: V);
        value: string;
        choose<T1>(input: T1): T;
        update(value: V): boolean;
    }
    export type $TypeScriptOwnerGenericTest$Owner$Inner<T extends $TypeScriptOwnerGenericTest$Owner<T>, V> = $RenamedInner<T, V>;
    export const $TypeScriptOwnerGenericTest$Owner$Inner: typeof $RenamedInner;

    export class $TypeScriptOwnerGenericTest$Concrete extends $TypeScriptOwnerGenericTest$Owner<$TypeScriptOwnerGenericTest$Concrete> {
        constructor();
        boundary: $TypeScriptOwnerGenericTest$Owner$Boundary$Child<number, string>;
        count: number;
        leaf: $TypeScriptOwnerGenericTest$Owner$Inner$Leaf<$TypeScriptOwnerGenericTest$Concrete, string, boolean>;
        number: $TypeScriptOwnerGenericTest$Owner$Inner<$TypeScriptOwnerGenericTest$Concrete, number>;
        raw: $TypeScriptOwnerGenericTest$Owner$Inner<any, any>;
        shadow: $TypeScriptOwnerGenericTest$Shadow$Member$Leaf<number, string, boolean>;
        text: $TypeScriptOwnerGenericTest$Owner$Inner<$TypeScriptOwnerGenericTest$Concrete, string>;
        consume(value: $TypeScriptOwnerGenericTest$Owner$Inner_<$TypeScriptOwnerGenericTest$Concrete, string>): void;
        factory(factory: $TypeScriptOwnerGenericTest$InnerFactory_<$TypeScriptOwnerGenericTest$Owner$Inner_<$TypeScriptOwnerGenericTest$Concrete, string>>): void;
        sink(sink: $TypeScriptOwnerGenericTest$InnerSink_<$TypeScriptOwnerGenericTest$Owner$Inner<$TypeScriptOwnerGenericTest$Concrete, string>>): void;
    }

    export interface $TypeScriptOwnerGenericTest$InnerFactory {
        make(): $TypeScriptOwnerGenericTest$Owner$Inner<$TypeScriptOwnerGenericTest$Concrete, string>;
    }

    export interface $TypeScriptOwnerGenericTest$InnerSink {
        accept(value: $TypeScriptOwnerGenericTest$Owner$Inner_<$TypeScriptOwnerGenericTest$Concrete, string>): void;
    }

    export class $TypeScriptOwnerGenericTest$Owner$Boundary$Child<K, V> {
        constructor(this$0: $TypeScriptOwnerGenericTest$Owner$Boundary<any>);
        key: K;
        value: V;
    }

    export class $TypeScriptOwnerGenericTest$Owner$Inner$Leaf<T extends $TypeScriptOwnerGenericTest$Owner<T>, V, W> {
        constructor(this$1: $TypeScriptOwnerGenericTest$Owner$Inner_);
        leaf: W;
        middle: V;
        owner(): T;
    }

    export class $TypeScriptOwnerGenericTest$Shadow$Member$Leaf<T, T1, T11> {
        constructor(this$1: $TypeScriptOwnerGenericTest$Shadow$Member<any, any>);
        leaf: T11;
        member: T1;
    }

    export class $TypeScriptOwnerGenericTest$Owner$Boundary<K> {
        constructor();
    }

    export interface $TypeScriptOwnerGenericTest$CapturedContract<X> {
        choose<T>(input: T): X;
    }

    export class $TypeScriptOwnerGenericTest$Shadow$Member<T, T1> {
        constructor(this$0: $TypeScriptOwnerGenericTest$Shadow<any>);
        value: T1;
    }

    export class $TypeScriptOwnerGenericTest$Shadow<T> {
        constructor();
    }

    export type $TypeScriptOwnerGenericTest$Owner$Inner_<T extends $TypeScriptOwnerGenericTest$Owner<T> = any, V = any> = $TypeScriptOwnerGenericTest$Owner$Inner<T, V> | "inner";
    export type $TypeScriptOwnerGenericTest$InnerFactory_<CallbackResult = $TypeScriptOwnerGenericTest$Owner$Inner_<$TypeScriptOwnerGenericTest$Concrete, string>> = (() => CallbackResult) | ($TypeScriptOwnerGenericTest$InnerFactory & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptOwnerGenericTest$InnerSink_<CallbackArg0 = $TypeScriptOwnerGenericTest$Owner$Inner<$TypeScriptOwnerGenericTest$Concrete, string>> = ((arg0: CallbackArg0) => void) | ($TypeScriptOwnerGenericTest$InnerSink & { readonly [Symbol.hasInstance]?: never });
}
