import type { $TypeScriptOwnerGenericTest$Concrete as Concrete,
    $TypeScriptOwnerGenericTest$Owner$Inner_ as Input } from 'java:com/tkisor/nekojs/probe/ir';
declare const concrete: Concrete;
const updated: boolean = concrete.text.update('value');
const text: string = concrete.number.value;
const input: Input<Concrete, string> = concrete.text;
concrete.consume(input);
concrete.consume('inner');
// @ts-expect-error Explicit return edits must not be rebuilt from the owner signature.
const wrong: Concrete = concrete.text.update('value');
// @ts-expect-error Explicit field edits win over reflected member variables.
const wrongField: number = concrete.number.value;
// @ts-expect-error The adapter keeps the explicit inner argument.
const wrongInput: Input<Concrete, string> = concrete.number;
