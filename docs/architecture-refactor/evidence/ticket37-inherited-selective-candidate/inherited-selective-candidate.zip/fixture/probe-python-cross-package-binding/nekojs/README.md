# NekoJS Python type stubs

This package provides type information (PEP 484/561 `.pyi` stubs) so that
**pyright / Pylance / Jedi** can offer completion for NekoJS Python scripts.

## Enable completion

Add this magic line at the **top** of your `.py` script:

```python
from nekojs import *
```

- At runtime, the NekoJS transpiler **strips** this line (it emits no JavaScript
  and does not affect the source map). It exists purely for the type checker.
- The type checker resolves `nekojs` to this stub package via the `extraPaths`
  entries that NekoJS writes into pyrightconfig.json files (game root,
  `nekojs/`, and each script directory). Note Pylance only honors the config
  at the **workspace root** - open the game directory (or `nekojs/`) in your
  editor, not a parent folder of it.

After `from nekojs import *`, the global bindings (`Item`, `ServerEvents`,
`Utils`, ...) and the Java types they expose become visible for completion.

## Regenerate

Run `/nekojs probe python` in-game to refresh these stubs.

## Notes

- Java types are organized under `nekojs._java.<java.package>`.
- Generics are flattened (type variables render as `Any`); member names, parameter
  counts, and field types are preserved — sufficient for day-to-day completion.
- `py.typed` marks this as a typed package (PEP 561).
