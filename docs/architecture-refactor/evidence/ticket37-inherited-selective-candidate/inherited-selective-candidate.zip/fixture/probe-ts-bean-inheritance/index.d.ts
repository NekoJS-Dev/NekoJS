    export interface $TypeScriptInheritedInterfaceTest$LevelSource {
        getLevel(): string;
        level(): string;
        setLevel(input: string): void;
    }
    export class $TypeScriptInheritedInterfaceTest$LevelMethods implements $TypeScriptInheritedInterfaceTest$LevelSource {
        constructor();
        getLevel(): string;
        level(): string;
        setLevel(input: string): void;
    }
    export class $TypeScriptInheritedInterfaceTest$LevelParent {
        constructor();
        get level(): string;
        getLevel(): string;
    }
    export class $TypeScriptInheritedInterfaceTest$LevelField extends $TypeScriptInheritedInterfaceTest$LevelParent {
        constructor();
        get level(): string;
        set level(value: string);
        getLevel(): string;
    }
    export class $TypeScriptInheritedInterfaceTest$DifferentLevelField extends $TypeScriptInheritedInterfaceTest$LevelParent {
        constructor();
        get level(): string;
        set level(value: number);
        getLevel(): string;
    }
    export class $TypeScriptInheritedInterfaceTest$SetterNameCollision {
        constructor();
        getSetName(): string;
        setName(input: string): void;
    }
