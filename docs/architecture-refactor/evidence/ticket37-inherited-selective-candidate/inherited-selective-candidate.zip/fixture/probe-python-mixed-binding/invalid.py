from fixture import PythonBeanMemberCollisionTest_MixedMatches as Mixed
Mixed.matches('word')
Mixed().matches('x', 'x')
