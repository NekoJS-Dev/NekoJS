from typing import assert_type
from fixture import PythonBeanMemberCollisionTest_MixedMatches as Mixed
from fixture import PythonBeanMemberCollisionTest_MixedChild as Child
from fixture import PythonBeanMemberCollisionTest_SameNameChild as Same
from fixture import PythonBeanMemberCollisionTest_FieldChild as Field
from fixture import PythonBeanMemberCollisionTest_StaticFieldName as StaticField
mixed = Mixed()
assert_type(Mixed.matches('x', 'x'), bool)
assert_type(mixed.matches('word'), int)
assert_type(Mixed.matches('x', 'x', True), bool)
assert_type(Child.matches('x', 'x'), bool)
assert_type(Child().matches('word'), int)
assert_type(Child.combine('x', 'x'), bool)
assert_type(Child().combine(7), int)
assert_type(Same.matches('x', 'x'), bool)
assert_type(Same.matches('x', 'x', True), bool)
assert_type(Same.matches('x', 'x', 7), bool)
assert_type(Same().matches('word'), int)
field = Field()
assert_type(field.level, str)
field.level = 9
assert_type(StaticField.tag('class'), str)
assert_type(StaticField().tag, bool)
