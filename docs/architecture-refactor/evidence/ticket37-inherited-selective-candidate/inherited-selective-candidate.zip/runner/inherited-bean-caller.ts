import { $TypeScriptInheritedInterfaceTest$LevelMethods as Methods,
    $TypeScriptInheritedInterfaceTest$LevelParent as Parent,
    $TypeScriptInheritedInterfaceTest$LevelField as Field,
    $TypeScriptInheritedInterfaceTest$DifferentLevelField as Different,
    $TypeScriptInheritedInterfaceTest$SetterNameCollision as SetterCollision } from '../../common/build/probe-ts-bean-inheritance/index';
const methods = new Methods();
const realMethod: string = methods.level();
const getter: string = methods.getLevel();
methods.setLevel('written');
const parent = new Parent();
const read: string = parent.level;
// @ts-expect-error A getter without a setter remains readonly.
parent.level = 'invalid';
const field = new Field();
field.level = 'written';
const inherited: string = field.getLevel();
// @ts-expect-error Real member types remain constrained.
methods.setLevel(7);
void [realMethod, getter, read, inherited];
const different = new Different();
const differentRead: string = different.level;
different.level = 9;
// @ts-expect-error Direct field writes retain their actual Java integer type.
different.level = 'invalid';
// @ts-expect-error Bean reads use the real getter's string type.
const wrongRead: number = different.level;
const collision = new SetterCollision();
collision.setName('written');
const explicitGetter: string = collision.getSetName();
void [differentRead, wrongRead, explicitGetter];
