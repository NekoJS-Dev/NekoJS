import collections
import json
import re
from pathlib import Path

project=Path.cwd()
before=project/'build/ticket37-interface-static-installed'
after=project/'build/ticket37-inherited-installed'
rows=[]
def diagnostics(path):
    lines=path.read_text(encoding='utf-8-sig').splitlines()
    result=collections.Counter()
    for line in lines:
        if 'error TS' not in line: continue
        match=re.search(r'(\.neko_probe/[^()]+|nekojs/[^()]+)\(\d+,\d+\): error (TS\d+): (.*)',line.replace('\\','/'))
        assert match,line
        result[(match[1],match[2],match[3])]+=1
    return result
for node in ['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']:
    sides=[]
    for side in ['server','startup']:
        old=diagnostics(before/'ide'/(node+'-'+side+'-tsc.txt'))
        new=diagnostics(after/'ide'/(node+'-'+side+'-tsc.txt'))
        sides.append(dict(side=side,before=sum(old.values()),after=sum(new.values()),removed=sum((old-new).values()),added=sum((new-old).values()),ts1070Before=sum(v for k,v in old.items() if k[1]=='TS1070'),ts1070After=sum(v for k,v in new.items() if k[1]=='TS1070'),removedDiagnostics=[dict(file=k[0],code=k[1],message=k[2],count=v) for k,v in sorted((old-new).items())],addedDiagnostics=[dict(file=k[0],code=k[1],message=k[2],count=v) for k,v in sorted((new-old).items())]))
    rows.append(dict(node=node,sides=sides))
(after/'ide/comparison.json').write_text(json.dumps(dict(beforeSource='7e98fd15175d15c8dad062bf40e2a284e04eaf51',afterProductionPatchSha256=json.loads((after/'matrix-summary.json').read_text(encoding='utf-8'))['productionPatchSha256'],sameFixtures=True,lineNumbersIgnored=True,nodes=rows),indent=2)+'\n',encoding='utf-8')
for row in rows:
    print(json.dumps(dict(node=row['node'],sides=[{k:v for k,v in r.items() if not k.endswith('Diagnostics')} for r in row['sides']])))
