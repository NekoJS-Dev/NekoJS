import {
    $TypeScriptInheritedInterfaceTest$Value as Value,
    $TypeScriptInheritedInterfaceTest$TextValue as TextValue,
    $TypeScriptInheritedInterfaceTest$RemappedChild as RemappedChild,
    $TypeScriptInheritedInterfaceTest$StaticSetter as StaticSetter,
    $TypeScriptInheritedInterfaceTest$GenericValue as GenericValue,
    $TypeScriptInheritedInterfaceTest$RootValue as RootValue,
    $TypeScriptInheritedInterfaceTest$Constrained as Constrained,
    $TypeScriptInheritedInterfaceTest$BoundedReceiver as Receiver,
    $TypeScriptInheritedInterfaceTest$BoundedHost as Host,
} from '../../common/build/probe-ts-inherited-interface/index';

const value = new Value<string>('x');
const echo: string = value.echo('y');
const ownOverload: number = value.echo();
const identity: number = value.identity(3);
const array: string[] = value.array(['x']);
const size: number = value.size();
const text = new TextValue('x');
const inherited: string = text.echo('z');
// @ts-expect-error The real Java interface factory is not inherited by class instances.
value.factory();
// @ts-expect-error Hidden interface members remain unavailable in generated declarations.
value.hidden();
// @ts-expect-error Class type arguments constrain inherited default methods.
value.echo(3);
// @ts-expect-error Method type variables retain their actual return type.
const wrong: string = value.identity(3);
void [echo, ownOverload, identity, array, size, inherited, wrong];

const remapped = new RemappedChild();
const stringCall: string = remapped.call("x");
const numberCall: number = remapped.call(7);
// @ts-expect-error Remapping retains the actual parameter types.
remapped.call(true);
void [stringCall, numberCall];

const readOnly = new StaticSetter();
const read: string = readOnly.value;
StaticSetter.setValue("class operation");
// @ts-expect-error A static setter does not make an instance property writable.
readOnly.value = "invalid";
// @ts-expect-error Static operations remain unavailable on instances.
readOnly.setValue("invalid");
void read;

const generic = new GenericValue<string>();
const transformed: number = generic.transform("class value", 7);
const rootValue = new RootValue();
const constrained: Constrained<RootValue> = generic.bounded(rootValue);
// @ts-expect-error The inherited class argument remains string.
generic.transform(7, "method value");
// @ts-expect-error Actual method bounds reject unrelated primitive input.
generic.bounded(7);
void [transformed, constrained];
const receiver = new Receiver();
const callbackResult: RootValue = receiver.apply(input => input);
const actualHostResult: RootValue = receiver.apply(new Host());
// @ts-expect-error The actual bounded callback result rejects unrelated values.
receiver.apply(input => input.marker);
void [callbackResult, actualHostResult];
