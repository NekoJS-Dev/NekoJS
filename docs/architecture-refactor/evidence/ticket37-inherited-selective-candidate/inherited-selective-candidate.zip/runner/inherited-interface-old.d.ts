    export interface $TypeScriptInheritedInterfaceTest$Values<T> {
        array(input: T[]): T[];
        echo(input: T): T;
        identity<R>(input: R): R;
        value(): T;
    }
    export const $TypeScriptInheritedInterfaceTest$Values: {
        factory(): string;
    };
    export interface $TypeScriptInheritedInterfaceTest$ChildValues<T> extends $TypeScriptInheritedInterfaceTest$Values<T> {
    }
    export interface $TypeScriptInheritedInterfaceTest$Sized {
        size(): number;
    }
    export class $TypeScriptInheritedInterfaceTest$Value<T> implements $TypeScriptInheritedInterfaceTest$ChildValues<T>, $TypeScriptInheritedInterfaceTest$Sized {
        constructor(input: T);
        value(): T;
    }
    export class $TypeScriptInheritedInterfaceTest$TextValue extends $TypeScriptInheritedInterfaceTest$Value<string> {
        constructor(input: string);
    }
