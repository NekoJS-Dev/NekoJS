import shutil
from pathlib import Path

output = Path('build/ticket37-config-sync-repair/inherited-setter-output-red')
assert not output.exists()
output.mkdir()
for name in ['probe-ts-inherited-interface', 'probe-python-inherited-bean']:
    shutil.copytree(Path('common/build')/name, output/name)
print('Preserved generated red declarations before the shared selection repair.')
