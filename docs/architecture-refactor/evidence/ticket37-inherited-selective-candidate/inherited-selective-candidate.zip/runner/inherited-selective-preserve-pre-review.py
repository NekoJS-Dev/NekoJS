import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
output = root/'build/ticket37-inherited-selective-pre-review-artifacts'
assert not output.exists()
output.mkdir()
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--', 'common/src/main/java'])
(output/'production-source.patch').write_bytes(patch)
rows = []
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    jars = list((root/'versions'/node/'build/libs').glob('*-server.jar')) if node == '1.21.1' else [
        p for p in (root/'versions'/node/'build/libs').glob('*.jar') if not p.name.endswith(('-dev.jar', '-sources.jar'))]
    assert len(jars) == 1
    destination = output/node
    destination.mkdir()
    shutil.copyfile(jars[0], destination/jars[0].name)
    rows.append(dict(node=node, artifact=jars[0].name, sha256=hashlib.sha256(jars[0].read_bytes()).hexdigest()))
(output/'manifest.json').write_text(json.dumps(dict(status='PRE-REVIEW: never installed or launched',
    sourceBase=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    productionPatchSha256=hashlib.sha256(patch).hexdigest(), artifacts=rows,
    gradleOuterExit='NOT OBSERVED: session unavailable after new user input',
    gradleBuildVerdict='BUILD SUCCESSFUL in preserved log; complete XML zero failures'), indent=2)+'\n')
print('Preserved pre-review exact JARs and patch; no installed-runtime claim.')
