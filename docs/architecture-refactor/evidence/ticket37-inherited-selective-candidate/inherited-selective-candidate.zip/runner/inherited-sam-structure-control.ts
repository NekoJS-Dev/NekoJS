import { $TypeScriptInheritedInterfaceTest$BoundedCallback as Host,
    $TypeScriptInheritedInterfaceTest$RootValue as Root,
    $TypeScriptInheritedInterfaceTest$BoundedHost as HostInstance } from '../../common/build/probe-ts-inherited-interface/index';
type CallableOrHost = ((input: Root) => Root) | (Host<Root> & { readonly [Symbol.hasInstance]?: never });
const callback: CallableOrHost = input => input;
const host: CallableOrHost = new HostInstance();
// @ts-expect-error Function.apply cannot bypass the callable return contract through the host branch.
const bad: CallableOrHost = (input: Root) => input.marker;
void [callback, host, bad];
