import hashlib
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd().resolve()
output = root / sys.argv[1]
assert output.parent == root / 'build' and not output.exists()
output.mkdir()
rows = []
with ZipFile(output / 'xml.zip', 'x', ZIP_DEFLATED) as archive:
    for project in sys.argv[2:]:
        row = dict(project=project, xml=0, tests=0, skipped=0, failures=0, errors=0)
        for path in sorted((root / project / 'build/test-results/test').glob('TEST-*.xml')):
            document = ET.parse(path).getroot()
            row['xml'] += 1
            for name in ['tests', 'skipped', 'failures', 'errors']:
                row[name] += int(document.get(name, '0'))
            archive.writestr(path.relative_to(root).as_posix(), path.read_bytes())
        rows.append(row)
summary = dict(projects=rows, total={key: sum(r[key] for r in rows)
    for key in ['xml', 'tests', 'skipped', 'failures', 'errors']},
    xmlSha256=hashlib.sha256((output / 'xml.zip').read_bytes()).hexdigest())
(output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
