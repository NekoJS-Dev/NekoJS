import json
import subprocess
import sys
from pathlib import Path

directory = Path('build/ticket37-config-sync-repair')
stage = sys.argv[1]
assert stage in ['red', 'green']
rows = []
for control in ['positive', 'negative']:
    config = directory/f'inherited-setter-python-{stage}-{control}-config.json'
    config.write_text(json.dumps(dict(typeCheckingMode='strict',
        include=[f'inherited-setter-python-{control}.py', '../../common/build/probe-python-inherited-bean/fixture.pyi'],
        extraPaths=['../../common/build/probe-python-inherited-bean']), indent=2)+'\n')
    result_path = directory/f'inherited-setter-python-{stage}-{control}-pyright.json'
    with result_path.open('xb') as stream:
        result = subprocess.run(['node', 'C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js',
            '--project', str(config), '--outputjson'], stdout=stream, stderr=subprocess.PIPE)
    assert not result.stderr, result.stderr.decode()
    report = json.loads(result_path.read_text())
    assert report['summary']['filesAnalyzed'] == 2
    rows.append(dict(control=control, exitCode=result.returncode, summary=report['summary']))
    if stage == 'green' and control == 'positive':
        assert result.returncode == 0 and report['summary']['errorCount'] == 0, report
    if control == 'negative':
        assert result.returncode == 1 and report['summary']['errorCount'] >= 1
        if stage == 'green':
            errors = [entry for entry in report['generalDiagnostics'] if entry['severity'] == 'error']
            assert len(errors) == 1 and errors[0].get('rule') == 'reportAttributeAccessIssue'
            assert 'str' in errors[0]['message'], errors
    if stage == 'red' and control == 'positive':
        assert result.returncode == 1 and report['summary']['errorCount'] >= 1
(directory/f'inherited-setter-python-{stage}-summary.json').write_text(json.dumps(rows, indent=2)+'\n')
print(json.dumps(rows))
