import gzip
import hashlib
import io
import json
import re
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

project=Path.cwd()
trial=project/'build/ticket37-inherited-installed'
repair=project/'build/ticket37-config-sync-repair'
destination=project/'docs/architecture-refactor/evidence/ticket37-inherited-methods'
archive_path=destination/'inherited-method-evidence.zip'
assert not archive_path.exists()
sha=lambda data:hashlib.sha256(data).hexdigest()
files={}
secrets=[]
preparation=json.loads((trial/'preparation-manifest.json').read_text(encoding='utf-8'))
artifacts=[]
for record in preparation['nodes']:
    server=trial/record['node']
    exit_record=json.loads((server/'server-exit.json').read_text())
    assert exit_record['exitCode']==0
    for line in (server/'server.properties').read_text().splitlines():
        if line.startswith('rcon.password='):secrets.append(line.partition('=')[2].encode())
    jars=list((server/'mods').glob('nekojs-*.jar'))
    assert len(jars)==1 and sha(jars[0].read_bytes())==record['sha256']
    assert jars[0].read_bytes()==(project/'versions'/record['node']/'build/libs'/jars[0].name).read_bytes()
    artifacts.append(dict(node=record['node'],file=jars[0].name,sha256=record['sha256'],exit=exit_record))
    for path in server.iterdir():
        if path.is_file() and (path.name.startswith(('owned-','server-','runtime-','command-')) or path.name=='pyrightconfig.json'):
            files[path.relative_to(project/'build').as_posix()]=path
    for folder in ['logs','nekojs','.neko_probe','crash-reports']:
        for path in (server/folder).rglob('*'):
            if path.is_file() and path.suffix in ['.json','.log','.txt','.gz','.js','.mjs','.ts','.pyi','.md','.toml','.typed']:
                files[path.relative_to(project/'build').as_posix()]=path
for path in trial.iterdir():
    if path.is_file() and path.suffix in ['.json','.patch','.zip']:files[path.relative_to(project/'build').as_posix()]=path
for path in (trial/'ide').rglob('*'):
    if path.is_file():files[path.relative_to(project/'build').as_posix()]=path
for stage in ['first','review']:
    for path in (project/('build/ticket37-inherited-methods-matrix-'+stage)).iterdir():
        if path.is_file(): files['earlier-matrix/'+stage+'/'+path.name]=path
for path in repair.glob('*inherited*'):
    if path.is_file() and path.suffix in ['.py','.cjs','.txt','.xml','.ts','.json']:files['runner/'+path.name]=path
for name in ['run-other-nodes.py','prove-python-member-candidate.py','parse-ts-member-declarations.cjs']:
    files['runner/'+name]=repair/name
for path in (project/'common/build/probe-ts-inherited-interface').rglob('*'):
    if path.is_file():files['fixture/'+path.relative_to(project/'common/build/probe-ts-inherited-interface').as_posix()]=path
source_names=['common/src/main/java/com/tkisor/nekojs/probe/ir/TypeReflector.java','common/src/main/java/com/tkisor/nekojs/core/reflect/FunctionalInterfaceResolver.java','common/src/test/java/com/tkisor/nekojs/probe/ir/TypeScriptInheritedInterfaceTest.java']
goldens=subprocess.check_output(['git','diff','--name-only','e48ea68','--','common/src/test/resources/nekojs/probe/legacy-tree'],text=True).splitlines()
assert len(goldens)==3
for name in source_names+goldens:files['source/repair/'+name]=project/name
patch=subprocess.check_output(['git','diff','e48ea68','--']+source_names+goldens)

def scan(data,suffix):
    if suffix=='.gz':return scan(gzip.decompress(data),'')
    if suffix=='.zip':
        with ZipFile(io.BytesIO(data)) as nested:
            for name in nested.namelist():scan(nested.read(name),Path(name).suffix)
        return
    assert not any(secret and secret in data for secret in secrets),'Credential value in evidence'
    assert not re.search(rb'(?m)^rcon\.password=',data),'Credential line in evidence'

entries=[]
with ZipFile(archive_path,'x',ZIP_DEFLATED) as archive:
    def add(name,data):
        scan(data,Path(name).suffix)
        archive.writestr(name,data)
        entries.append(dict(path=name,bytes=len(data),sha256=sha(data)))
    for name,path in sorted(files.items()):add(name,path.read_bytes())
    for name in source_names[:2]+goldens:add('source/baseline/'+name,subprocess.check_output(['git','show','e48ea68:'+name]))
    add('source/tracked-repair.patch',patch)
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in entries:assert sha(archive.read(record['path']))==record['sha256']
matrix=json.loads((trial/'matrix-summary.json').read_text(encoding='utf-8'))
manifest=dict(sourceBase=preparation['sourceRevision'],sourceWipAtBuild=True,productionPatchSha256=matrix['productionPatchSha256'],trackedPatchSha256=sha(patch),newTest=dict(path=source_names[2],sha256=sha((project/source_names[2]).read_bytes()),includedAsSeparateSourceEntry=True),goldenAudit=json.loads((repair/'inherited-interface-golden-audit.json').read_text(encoding='utf-8')),artifacts=artifacts,matrix=matrix,runtime=json.loads((trial/'runtime-summary.json').read_text(encoding='utf-8')),ide=json.loads((trial/'ide/summary.json').read_text(encoding='utf-8')),archive=dict(file=archive_path.name,entries=len(entries),bytes=archive_path.stat().st_size,sha256=sha(archive_path.read_bytes())),entries=entries,previousEvidence=dict(path='../ticket37-interface-static-surface/interface-static-evidence.zip',sha256='cddbd9800ca1bee8b8f11feb865177561faab49a14449ad1cc812f2a4ca775f6'),independentReviews=dict(Standards='Initial static setter P2 and Javadoc P3 resolved; final0 confirmed findings; read-only',Spec='Initial remapped overload and setter priority P2s resolved; final0 confirmed findings; read-only'),maintainerAcceptance='NOT RECORDED: golden additions reviewed by agents; no human acceptance invented',exclusions=['server.properties/RCON secrets','worlds','account/launcher data','binaries/libraries','raw JFR'])
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for name,path in [('matrix-summary.json',trial/'matrix-summary.json'),('ide-summary.json',trial/'ide/summary.json'),('ide-comparison.json',trial/'ide/comparison.json'),('golden-audit.json',repair/'inherited-interface-golden-audit.json'),('generation-comparison.json',trial/'generation-comparison.json')]:
    (destination/name).write_bytes(path.read_bytes())
print(json.dumps(dict(archive=manifest['archive'],productionPatchSha256=manifest['productionPatchSha256'],newTest=manifest['newTest'],matrix=matrix['total'])))
