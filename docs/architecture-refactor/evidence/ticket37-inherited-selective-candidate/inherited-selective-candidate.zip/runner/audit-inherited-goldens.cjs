const fs=require('fs'),cp=require('child_process'),ts=require('../../node_modules/typescript');
const base='e48ea68cafbde0007ac7271d99615c146199853b';
const paths=cp.execFileSync('git',['diff','--name-only',base,'--','common/src/test/resources/nekojs/probe/legacy-tree'],{encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
if(paths.length!==3)throw Error('Expected three regenerated golden files');
function surface(text,file){
 const source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS),out={classes:{},other:[]};
 function visit(nodes){for(const n of nodes){
  if(ts.isModuleDeclaration(n)&&n.body&&ts.isModuleBlock(n.body)){visit(n.body.statements);continue;}
  if(ts.isClassDeclaration(n)){out.classes[n.name.text]={header:n.getText(source).split('{')[0].trim(),members:n.members.map(m=>m.getText(source).replaceAll('\r\n','\n'))};}
  else out.other.push(n.getText(source).replaceAll('\r\n','\n'));
 }}visit(source.statements);return out;
}
const rows=[];
for(const file of paths){
 const old=surface(cp.execFileSync('git',['show',base+':'+file],{encoding:'utf8'}),file),now=surface(fs.readFileSync(file,'utf8'),file),added=[];
 if(JSON.stringify(old.other)!==JSON.stringify(now.other))throw Error('Other declarations changed '+file);
 if(JSON.stringify(Object.keys(old.classes))!==JSON.stringify(Object.keys(now.classes)))throw Error('Class set changed');
 for(const [name,def]of Object.entries(old.classes)){
  const actual=now.classes[name];if(def.header!==actual.header)throw Error('Class header changed '+name);
  const remaining=[...actual.members];
  for(const member of def.members){const at=remaining.indexOf(member);if(at<0)throw Error('Existing member changed '+name+': '+member);remaining.splice(at,1);}
  for(const member of remaining)added.push({class:name,member});
 }
 rows.push({file,added,existingMembersAndHeadersPreserved:true,otherDeclarationsPreserved:true});
}
fs.writeFileSync('build/ticket37-config-sync-repair/inherited-interface-golden-audit.json',JSON.stringify({typescriptVersion:ts.version,sourceBase:base,files:rows,addedMembers:rows.reduce((n,r)=>n+r.added.length,0),allPassed:true},null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({file:r.file,added:r.added.length}))));
