const fs = require('node:fs');
const path = require('node:path');
const ts = require('../../node_modules/typescript');
const configPath = process.argv[2];
const outputPath = process.argv[3];
let changed = 0;
function merge(text, fileName) {
    const source = ts.createSourceFile(fileName, text, ts.ScriptTarget.Latest, true);
    const insertions = [];
    function visit(node) {
        if (ts.isClassDeclaration(node) && node.name) {
            const interfaces = node.heritageClauses?.find(clause => clause.token === ts.SyntaxKind.ImplementsKeyword);
            if (interfaces) {
                const parameters = node.typeParameters?.map(p => p.getText(source)).join(', ');
                const generics = parameters ? `<${parameters}>` : '';
                const types = interfaces.types.map(p => p.getText(source)).join(', ');
                insertions.push({ position: node.end, text: `\n    export interface ${node.name.text}${generics} extends ${types} {}` });
                changed++;
            }
        }
        ts.forEachChild(node, visit);
    }
    visit(source);
    for (const insertion of insertions.sort((a,b) => b.position - a.position)) {
        text = text.slice(0, insertion.position) + insertion.text + text.slice(insertion.position);
    }
    return text;
}
let options, fileNames;
if (configPath.endsWith('.ts')) {
    options = { strict: true, skipLibCheck: false, noEmit: true, target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.CommonJS };
    fileNames = [configPath];
} else {
    const config = ts.readConfigFile(configPath, ts.sys.readFile);
    if (config.error) throw new Error(ts.flattenDiagnosticMessageText(config.error.messageText, '\n'));
    const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, path.dirname(path.resolve(configPath)), { skipLibCheck: false, noEmit: true });
    options = parsed.options; fileNames = parsed.fileNames;
}
const host = ts.createCompilerHost(options);
const readFile = host.readFile.bind(host);
host.readFile = file => {
    const original = readFile(file);
    return original !== undefined && file.endsWith('.d.ts') && !file.includes('node_modules') ? merge(original, file) : original;
};
const program = ts.createProgram(fileNames, options, host);
const diagnostics = ts.getPreEmitDiagnostics(program).map(row => ({ file: row.file?.fileName, code: row.code, message: ts.flattenDiagnosticMessageText(row.messageText, '\n') }));
const counts = {};
diagnostics.forEach(row => counts[row.code] = (counts[row.code] || 0) + 1);
const result = { overlayOnly: true, changedClasses: changed, diagnostics: diagnostics.length, codes: counts, details: diagnostics };
fs.writeFileSync(outputPath, JSON.stringify(result, null, 2)+'\n');
console.log(JSON.stringify({ overlayOnly: true, changedClasses: changed, diagnostics: diagnostics.length, codes: counts }));
