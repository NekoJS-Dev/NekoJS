const fs = require('fs'), cp = require('child_process'), ts = require('../../node_modules/typescript');
const base = 'e48ea68cafbde0007ac7271d99615c146199853b';
const paths = cp.execFileSync('git', ['diff', '--name-only', base, '--', 'common/src/test/resources/nekojs/probe/legacy-tree'], {encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
const untracked = cp.execFileSync('git', ['ls-files', '--others', '--exclude-standard', '--', 'common/src/test/resources/nekojs/probe/legacy-tree'], {encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
paths.push(...untracked);
function surface(text, file) {
    const source = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
    if (source.parseDiagnostics.length) throw Error('Invalid declaration syntax: '+file);
    const declarations = {}, aliases = {}, imports = [];
    function visit(nodes) { for (const node of nodes) {
        if (ts.isImportDeclaration(node)) imports.push(node.getText(source));
        if (ts.isTypeAliasDeclaration(node)) aliases[node.name.text] = node.getText(source).replaceAll('\r\n', '\n');
        if (ts.isModuleDeclaration(node) && node.body && ts.isModuleBlock(node.body)) { visit(node.body.statements); continue; }
        if (ts.isClassDeclaration(node) || ts.isInterfaceDeclaration(node)) declarations[node.name.text] = {
            header: node.getText(source).split('{')[0].trim(),
            members: node.members.map(member => member.getText(source).replaceAll('\r\n', '\n')),
        };
    }}
    visit(source.statements);
    return {declarations, aliases, imports};
}
const rows = [];
for (const file of paths) {
    const oldSurface = surface(untracked.includes(file) ? '' : cp.execFileSync('git', ['show', base+':'+file], {encoding:'utf8'}), file);
    const newSurface = surface(fs.readFileSync(file, 'utf8'), file);
    const before = oldSurface.declarations, after = newSurface.declarations;
    const aliasChanges = [...new Set([...Object.keys(oldSurface.aliases), ...Object.keys(newSurface.aliases)])].filter(name => oldSurface.aliases[name] !== newSurface.aliases[name]).map(name => ({name, before:oldSurface.aliases[name] ?? null, after:newSurface.aliases[name] ?? null}));
    const importChanges = {removed:oldSurface.imports.filter(value => !newSurface.imports.includes(value)), added:newSurface.imports.filter(value => !oldSurface.imports.includes(value))};
    const addedTypes = Object.keys(after).filter(name => !before[name]), changed = [];
    for (const [name, previous] of Object.entries(before)) {
        if (!after[name]) throw Error('Existing type removed: '+name);
        const remaining = [...after[name].members], removed = [];
        for (const member of previous.members) {
            const at = remaining.indexOf(member);
            if (at < 0) removed.push(member); else remaining.splice(at, 1);
        }
        if (remaining.length || removed.length || previous.header !== after[name].header)
            changed.push({name, oldHeader:previous.header, newHeader:after[name].header, removed, added:remaining});
    }
    rows.push({file, addedTypes, changed, aliasChanges, importChanges, existingTypesPreserved:true});
}
fs.writeFileSync('build/ticket37-config-sync-repair/inherited-selective-golden-audit.json', JSON.stringify({sourceBase:base, typescriptVersion:ts.version, files:rows}, null, 2)+'\n');
console.log(JSON.stringify(rows.map(row => ({file:row.file, addedTypes:row.addedTypes, changedTypes:row.changed.length, removedMembers:row.changed.reduce((n,r)=>n+r.removed.length,0), addedMembers:row.changed.reduce((n,r)=>n+r.added.length,0)}))));
