from pathlib import Path
import time
import subprocess
import json

root = Path('build/ticket37-inherited-selective-installed')
nodes = ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']
deadline = time.monotonic() + 600
while not all((root / node / 'runtime-verdict.json').exists() for node in nodes):
    assert time.monotonic() < deadline, 'Owned runtime proof deadline exceeded'
    time.sleep(1)
for node in nodes:
    document = json.loads((root / node / 'runtime-verdict.json').read_text(encoding='utf-8'))
    assert document['checks'].get('typescriptGenerated') and document['checks'].get('pythonGenerated')
python = 'C:/Users/11515/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/python.exe'
result = subprocess.run([python, 'build/ticket37-config-sync-repair/check-inherited-selective-ide.py'])
Path('build/ticket37-config-sync-repair/inherited-selective-ide-exit.json').write_text(json.dumps(
    dict(exitCode=result.returncode, meaning='Collection exit; TSC/Pyright exits remain separately recorded')),
    encoding='utf-8')
raise SystemExit(result.returncode)
