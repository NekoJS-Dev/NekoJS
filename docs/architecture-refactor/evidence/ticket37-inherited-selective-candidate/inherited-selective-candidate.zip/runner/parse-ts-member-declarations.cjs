const fs = require('fs'), path = require('path'), ts = require('../../node_modules/typescript');
const root = path.resolve(process.argv[2]);
const output = process.argv[3];
function files(dir) {
  return fs.readdirSync(dir, {withFileTypes:true}).flatMap(e => e.isDirectory() ? files(path.join(dir,e.name)) : e.name.endsWith('.d.ts') ? [path.join(dir,e.name)] : []);
}
const results = [];
for (const node of ['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']) {
  const folder = path.join(root,node,'.neko_probe','typescript');
  const declarations = files(folder), diagnostics=[];
  for(const file of declarations) {
    const source = ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
    for(const d of source.parseDiagnostics) {
      const loc=source.getLineAndCharacterOfPosition(d.start ?? 0);
      diagnostics.push({file:path.relative(folder,file).replaceAll('\\','/'),line:loc.line+1,column:loc.character+1,code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')});
    }
  }
  results.push({node,files:declarations.length,syntaxDiagnostics:diagnostics.length,diagnostics});
}
fs.writeFileSync(output,JSON.stringify({typescriptVersion:ts.version,purpose:'Read-only isolated declaration parse, separate from full default-includes strict TSC',nodes:results},null,2)+'\n');
console.log(JSON.stringify(results.map(({node,files,syntaxDiagnostics})=>({node,files,syntaxDiagnostics}))));
