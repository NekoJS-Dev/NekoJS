from fixture import PythonBeanMemberCollisionTest_GetterChild

bean = PythonBeanMemberCollisionTest_GetterChild()
bean.value = "written"
saved: str = bean.value
