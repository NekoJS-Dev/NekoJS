import gzip
import hashlib
import io
import json
import re
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

project = Path.cwd().resolve()
trial = project / 'build/ticket37-inherited-selective-installed'
repair = project / 'build/ticket37-config-sync-repair'
destination = project / 'docs/architecture-refactor/evidence/ticket37-inherited-selective-candidate'
assert not destination.exists()
destination.mkdir()
archive_path = destination / 'inherited-selective-candidate.zip'
sha = lambda data: hashlib.sha256(data).hexdigest()
preparation = json.loads((trial/'preparation-manifest.json').read_text(encoding='utf-8'))
production_patch = subprocess.check_output(['git', 'diff', preparation['sourceRevision'], '--', 'common/src/main/java'])
assert sha(production_patch) == preparation['productionPatchSha256']
files, secrets, artifacts = {}, [], []
for record in preparation['nodes']:
    server = trial / record['node']
    exit_record = json.loads((server/'server-exit.json').read_text())
    assert exit_record['exitCode'] == 0
    for line in (server/'server.properties').read_text().splitlines():
        if line.startswith('rcon.password='): secrets.append(line.partition('=')[2].encode())
    jars = list((server/'mods').glob('nekojs-*.jar'))
    assert len(jars) == 1 and sha(jars[0].read_bytes()) == record['sha256']
    assert jars[0].read_bytes() == (project/'versions'/record['node']/'build/libs'/jars[0].name).read_bytes()
    artifacts.append(dict(node=record['node'], artifact=jars[0].name, sha256=record['sha256'], exit=exit_record))
    for path in server.iterdir():
        if path.is_file() and (path.name.startswith(('owned-', 'server-', 'runtime-', 'command-'))
                or path.name == 'pyrightconfig.json'):
            files[path.relative_to(project/'build').as_posix()] = path
    for folder in ['logs', 'nekojs', '.neko_probe', 'crash-reports']:
        for path in (server/folder).rglob('*'):
            if path.is_file() and path.suffix in ['.json', '.log', '.txt', '.gz', '.js', '.mjs', '.ts', '.pyi', '.md', '.toml', '.typed']:
                files[path.relative_to(project/'build').as_posix()] = path
for path in trial.iterdir():
    if path.is_file() and path.suffix in ['.json', '.patch']:
        files[path.relative_to(project/'build').as_posix()] = path
for path in (trial/'ide').rglob('*'):
    if path.is_file(): files[path.relative_to(project/'build').as_posix()] = path
for folder in ['ticket37-inherited-selective-matrix', 'ticket37-inherited-boundary-matrix-red', 'ticket37-inherited-boundary-matrix',
               'ticket37-inherited-selective-pre-review-matrix', 'ticket37-inherited-selective-setter-red',
               'ticket37-inherited-selective-setter-generated-red', 'ticket37-inherited-selective-setter-focused-green',
               'ticket37-inherited-boundary-order-and-object-red', 'ticket37-inherited-ancestor-selection-red', 'ticket37-inherited-repair-common-red',
               'ticket37-inherited-inflight-first-red',
               'ticket37-inherited-inflight-cause-red', 'ticket37-inherited-inflight-cause-control-red',
               'ticket37-inherited-boundary-focused-green', 'ticket37-inherited-selective-focused-green',
               'ticket37-inherited-review-boundaries-red', 'ticket37-inherited-next-matrix', 'ticket37-inherited-final-review-red', 'ticket37-inherited-actual-new-red', 'ticket37-inherited-remaining-member-red', 'ticket37-inherited-self-comparable-red', 'ticket37-inherited-final-matrix']:
    for path in (project/'build'/folder).iterdir():
        if path.is_file(): files[folder+'/'+path.name] = path
for path in repair.rglob('*'):
    if path.is_file() and 'inherited' in path.name and path.suffix in ['.py', '.cjs', '.txt', '.xml', '.ts', '.json', '.java']:
        files['runner/'+path.relative_to(repair).as_posix()] = path
for folder in ['python-binding-descriptor-control', 'python-binding-metaclass-control']:
    for path in (repair/folder).iterdir():
        if path.is_file(): files['control/'+folder+'/'+path.name] = path
for name in ['run-other-nodes.py', 'prove-python-member-candidate.py', 'parse-ts-member-declarations.cjs', 'snapshot-current-tests.py']:
    files['runner/'+name] = repair/name
for name in ['close-order-control.py', 'close-order-original.java', 'InheritedGetterOrderControl.java']:
    files['control/'+name] = repair/name
files['control/probe-field-method-control.json'] = project/'common/build/probe-field-method-control.json'
for path in (repair/'inherited-setter-output-red').rglob('*'):
    if path.is_file(): files['control/setter-red/'+path.relative_to(repair/'inherited-setter-output-red').as_posix()] = path
for name in ['manifest.json', 'production-source.patch']:
    files['control/selective-pre-review/'+name] = project/'build/ticket37-inherited-selective-pre-review-artifacts'/name
for folder in ['probe-ts-inherited-interface', 'probe-ts-bean-inheritance', 'probe-python-mixed-binding', 'probe-python-cross-package-binding', 'probe-python-inherited-bean']:
    for path in (project/'common/build'/folder).rglob('*'):
        if path.is_file(): files['fixture/'+folder+'/'+path.relative_to(project/'common/build'/folder).as_posix()] = path
source_names = subprocess.check_output(['git', 'diff', '--name-only', preparation['sourceRevision'], '--',
    'common/src/main/java', 'common/src/test/java', 'common/src/test/resources/nekojs/probe/legacy-tree'], text=True).splitlines()
new_sources = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--',
    'common/src/test/java/com/tkisor/nekojs/probe/ir/TypeScriptInheritedInterfaceTest.java',
    'common/src/test/resources/nekojs/probe/legacy-tree'], text=True).splitlines()
source_names += new_sources
for name in source_names: files['source/repair/'+name] = project/name
def scan(data, suffix):
    if suffix == '.gz': return scan(gzip.decompress(data), '')
    if suffix == '.zip':
        with ZipFile(io.BytesIO(data)) as nested:
            for name in nested.namelist(): scan(nested.read(name), Path(name).suffix)
        return
    assert not any(secret and secret in data for secret in secrets), 'Credential value in evidence'
    assert not re.search(rb'(?m)^rcon\.password=', data), 'Credential line in evidence'
entries = []
with ZipFile(archive_path, 'x', ZIP_DEFLATED) as archive:
    def add(name, data):
        scan(data, Path(name).suffix)
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
    for name, path in sorted(files.items()): add(name, path.read_bytes())
    for name in source_names:
        if name not in new_sources:
            add('source/baseline/'+name, subprocess.check_output(['git', 'show', preparation['sourceRevision']+':'+name]))
    add('source/production.patch', production_patch)
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in entries: assert sha(archive.read(record['path'])) == record['sha256']
manifest = dict(status='NOT ACCEPTED: full IDE failures and nested getter selection order remain under diagnosis',
    sourceBase=preparation['sourceRevision'], sourceWipAtBuild=True,
    productionPatchSha256=preparation['productionPatchSha256'], artifacts=artifacts,
    matrix=json.loads((project/'build/ticket37-inherited-selective-matrix/summary.json').read_text()),
    runtime=json.loads((trial/'runtime-summary.json').read_text()),
    ide=json.loads((trial/'ide/summary.json').read_text()),
    archive=dict(file=archive_path.name, entries=len(entries), bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes())),
    maintainerAcceptance='NOT RECORDED', exclusions=['RCON credentials/server.properties', 'worlds',
        'launcher/account data', 'binaries/libraries', 'raw JFR'], entries=entries)
(destination/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
for name, path in [('matrix-summary.json', project/'build/ticket37-inherited-selective-matrix/summary.json'),
    ('ide-summary.json', trial/'ide/summary.json'), ('golden-audit.json', repair/'inherited-selective-golden-audit.json'),
    ('comparison-7e98.json', trial/'ide/comparison-7e98.json'),
    ('comparison-rejected-candidate.json', trial/'ide/comparison-rejected-candidate.json'), ('comparison-f469.json', trial/'ide/comparison-f469.json'), ('comparison-03cc.json', trial/'ide/comparison-03cc.json'), ('comparison-ec765.json', trial/'ide/comparison-ec765.json')]:
    (destination/name).write_bytes(path.read_bytes())
print(json.dumps(dict(archive=manifest['archive'], productionPatchSha256=manifest['productionPatchSha256'],
    matrix=manifest['matrix']['total'])))
