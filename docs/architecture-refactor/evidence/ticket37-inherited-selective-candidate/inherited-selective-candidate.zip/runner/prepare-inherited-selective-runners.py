from pathlib import Path

directory = Path('build/ticket37-config-sync-repair')
for prefix in ['prepare', 'check', 'await', 'compare', 'audit', 'archive']:
    suffix = {
        'prepare': 'installed.py', 'check': 'ide.py', 'await': 'ide.py',
        'compare': 'outputs.py', 'audit': 'goldens.cjs', 'archive': 'candidate.py',
    }[prefix]
    source = directory / f'{prefix}-inherited-boundary-{suffix}'
    destination = directory / f'{prefix}-inherited-selective-{suffix}'
    assert not destination.exists()
    text = source.read_text(encoding='utf-8').replace('inherited-boundary', 'inherited-selective')
    if prefix == 'compare':
        text = text.replace("('03cc', 'ticket37-inherited-final-installed')", "('03cc', 'ticket37-inherited-final-installed'), ('ec765', 'ticket37-inherited-boundary-installed')")
    if prefix == 'archive':
        text = text.replace("'ticket37-inherited-selective-matrix-red',", "'ticket37-inherited-boundary-matrix-red', 'ticket37-inherited-boundary-matrix',")
        text = text.replace("'ticket37-inherited-selective-order-and-object-red',", "'ticket37-inherited-boundary-order-and-object-red', 'ticket37-inherited-ancestor-selection-red',")
        text = text.replace("'ticket37-inherited-selective-focused-green',", "'ticket37-inherited-boundary-focused-green', 'ticket37-inherited-selective-focused-green',")
        text = text.replace("('comparison-03cc.json', trial/'ide/comparison-03cc.json')", "('comparison-03cc.json', trial/'ide/comparison-03cc.json'), ('comparison-ec765.json', trial/'ide/comparison-ec765.json')")
    destination.write_text(text, encoding='utf-8', newline='')
print('Created separate selective candidate runners; previous trial and evidence remain unchanged.')
