from pathlib import Path
import json,hashlib,re
root=Path.cwd();after=root/'build/ticket37-inherited-installed';before=root/'build/ticket37-interface-static-installed'
rows=[]
for node in ['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']:
 b=before/node;a=after/node
 old=json.loads((b/'runtime-verdict.json').read_text(encoding='utf-8'));new=json.loads((a/'runtime-verdict.json').read_text(encoding='utf-8'))
 languages=[]
 for language,extension in [('typescript','*.d.ts'),('python','*.pyi')]:
  def files(server):return {p.relative_to(server/'.neko_probe'/language).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (server/'.neko_probe'/language).rglob(extension)}
  old_files=files(b);new_files=files(a)
  languages.append(dict(language=language,before=len(old_files),after=len(new_files),missing=sorted(old_files.keys()-new_files.keys()),added=sorted(new_files.keys()-old_files.keys()),changed=sum(old_files[k]!=new_files[k] for k in old_files.keys()&new_files.keys())))
 old_warn=sorted(set(old.get('probeWarnings',[])));new_warn=sorted(set(new.get('probeWarnings',[])))
 def identities(warnings):
  return sorted({tuple(re.search(r'Probe type (reflection failed|scan incomplete) for ([^;]+);',warning).groups()) for warning in warnings})
 old_ids=identities(old_warn);new_ids=identities(new_warn)
 rows.append(dict(node=node,languages=languages,omissionIdentitiesBefore=old_ids,omissionIdentitiesAfter=new_ids,omissionIdentitiesPreserved=(old_ids==new_ids),warningsBefore=old_warn,warningsAfter=new_warn,removedWarnings=sorted(set(old_warn)-set(new_warn)),addedWarnings=sorted(set(new_warn)-set(old_warn))))
(after/'generation-comparison.json').write_text(json.dumps(dict(beforeSource='7e98fd15175d15c8dad062bf40e2a284e04eaf51',nodes=rows),indent=2)+'\n',encoding='utf-8')
for row in rows:print(json.dumps({k:v for k,v in row.items() if k not in ['warningsBefore','warningsAfter']}))
