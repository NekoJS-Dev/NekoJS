import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root=Path.cwd()
output=root/'build/ticket37-inherited-methods-matrix-first'
output.mkdir(exist_ok=False)
rows=[]
with ZipFile(output/'matrix-xml.zip','x',ZIP_DEFLATED) as archive:
    for project in ['common','common-api-processor']+['versions/'+n for n in ['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']]:
        row=dict(project=project,xml=0,tests=0,skipped=0,failures=0,errors=0)
        for path in sorted((root/project/'build/test-results/test').glob('TEST-*.xml')):
            document=ET.parse(path).getroot()
            row['xml']+=1
            for name in ['tests','skipped','failures','errors']:
                row[name]+=int(document.get(name,'0'))
            archive.writestr(path.relative_to(root).as_posix(),path.read_bytes())
        rows.append(row)
total={key:sum(r[key] for r in rows) for key in ['xml','tests','skipped','failures','errors']}
assert total['failures']==total['errors']==0
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='e48ea68cafbde0007ac7271d99615c146199853b'
patch=subprocess.check_output(['git','diff','e48ea68','--','common/src/main/java/com/tkisor/nekojs/probe/ir/TypeReflector.java','common/src/main/java/com/tkisor/nekojs/core/reflect/FunctionalInterfaceResolver.java'])
(output/'production-source.patch').write_bytes(patch)
summary=dict(productionPatchSha256=hashlib.sha256(patch).hexdigest(),sourceRevision='e48ea68cafbde0007ac7271d99615c146199853b',projects=rows,total=total,exitCode=0,commonAndProcessor='common tests executed after focused checks; processor UP-TO-DATE; all five node test tasks executed',xmlArchiveSha256=hashlib.sha256((output/'matrix-xml.zip').read_bytes()).hexdigest())
(output/'matrix-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
