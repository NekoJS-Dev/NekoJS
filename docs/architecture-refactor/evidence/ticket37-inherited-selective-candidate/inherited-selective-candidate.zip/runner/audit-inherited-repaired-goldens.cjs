const fs = require('fs'), cp = require('child_process'), ts = require('../../node_modules/typescript');
const base = 'e48ea68cafbde0007ac7271d99615c146199853b';
const paths = cp.execFileSync('git', ['diff', '--name-only', base, '--', 'common/src/test/resources/nekojs/probe/legacy-tree'], {encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
const untracked = cp.execFileSync('git', ['ls-files', '--others', '--exclude-standard', '--', 'common/src/test/resources/nekojs/probe/legacy-tree'], {encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
paths.push(...untracked);
function surface(text, file) {
    const source = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
    if (source.parseDiagnostics.length) throw Error('Invalid declaration syntax: '+file);
    const declarations = {};
    function visit(nodes) { for (const node of nodes) {
        if (ts.isModuleDeclaration(node) && node.body && ts.isModuleBlock(node.body)) { visit(node.body.statements); continue; }
        if (ts.isClassDeclaration(node) || ts.isInterfaceDeclaration(node)) declarations[node.name.text] = {
            header: node.getText(source).split('{')[0].trim(),
            members: node.members.map(member => member.getText(source).replaceAll('\r\n', '\n')),
        };
    }}
    visit(source.statements);
    return declarations;
}
const rows = [];
for (const file of paths) {
    const before = surface(untracked.includes(file) ? '' : cp.execFileSync('git', ['show', base+':'+file], {encoding:'utf8'}), file);
    const after = surface(fs.readFileSync(file, 'utf8'), file);
    const addedTypes = Object.keys(after).filter(name => !before[name]), changed = [];
    for (const [name, previous] of Object.entries(before)) {
        if (!after[name]) throw Error('Existing type removed: '+name);
        const remaining = [...after[name].members], removed = [];
        for (const member of previous.members) {
            const at = remaining.indexOf(member);
            if (at < 0) removed.push(member); else remaining.splice(at, 1);
        }
        if (remaining.length || removed.length || previous.header !== after[name].header)
            changed.push({name, oldHeader:previous.header, newHeader:after[name].header, removed, added:remaining});
    }
    rows.push({file, addedTypes, changed, existingTypesPreserved:true});
}
fs.writeFileSync('build/ticket37-config-sync-repair/inherited-repaired-golden-audit.json', JSON.stringify({sourceBase:base, typescriptVersion:ts.version, files:rows}, null, 2)+'\n');
console.log(JSON.stringify(rows.map(row => ({file:row.file, addedTypes:row.addedTypes, changedTypes:row.changed.length, removedMembers:row.changed.reduce((n,r)=>n+r.removed.length,0), addedMembers:row.changed.reduce((n,r)=>n+r.added.length,0)}))));
