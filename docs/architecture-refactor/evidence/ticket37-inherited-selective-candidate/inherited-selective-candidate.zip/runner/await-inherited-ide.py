from pathlib import Path
import time,subprocess,json
root=Path('build/ticket37-inherited-installed')
nodes=['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']
deadline=time.monotonic()+600
while not all((root/n/'runtime-verdict.json').exists() for n in nodes):
 assert time.monotonic()<deadline,'Owned runtime proof deadline exceeded'
 time.sleep(1)
for n in nodes:
 document=json.loads((root/n/'runtime-verdict.json').read_text(encoding='utf-8'))
 assert document['checks'].get('typescriptGenerated') and document['checks'].get('pythonGenerated'),(n,document['errors'])
python='C:/Users/11515/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/python.exe'
result=subprocess.run([python,'build/ticket37-config-sync-repair/check-inherited-installed-ide.py'])
Path('build/ticket37-config-sync-repair/inherited-ide-runner-exit.json').write_text(json.dumps({'exitCode':result.returncode,'meaning':'Evidence collection exit; individual TSC/Pyright exits remain separately recorded'}),encoding='utf-8')
raise SystemExit(result.returncode)
