from fixture import PythonBeanMemberCollisionTest_GetterChild

bean = PythonBeanMemberCollisionTest_GetterChild()
bean.value = 7
