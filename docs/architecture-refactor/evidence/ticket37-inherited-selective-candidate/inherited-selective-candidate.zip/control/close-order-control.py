from pathlib import Path

root = Path.cwd()
source = root / 'common/src/test/java/com/tkisor/nekojs/script/Ticket07RuntimeThreadsTest.java'
snapshot = root / 'build/ticket37-config-sync-repair/close-order-original.java'
assert not snapshot.exists()
snapshot.write_bytes(source.read_bytes())
text = source.read_text(encoding='utf-8')
start = text.index('    void closePreemptsRemainingCandidateScriptsAndNeverCommits()')
end = text.index('    void closeIsPrioritizedOverNotStartedReload()', start)
fragment = text[start:end]
fragment = fragment.replace('            try {\n                Future<NekoReloadException>', '''            CountDownLatch workerEntered = new CountDownLatch(1);
            CountDownLatch releaseWorker = new CountDownLatch(1);
            pool.submit(() -> {
                workerEntered.countDown();
                releaseWorker.await();
                return null;
            });
            assertTrue(workerEntered.await(30, TimeUnit.SECONDS));
            try {
                Future<NekoReloadException>''', 1)
fragment = fragment.replace('                assertTrue(h.manager.isClosed());', '                assertTrue(h.manager.isClosed());\n                releaseWorker.countDown();', 1)
fragment = fragment.replace('            } finally {\n                pool.shutdownNow();', '            } finally {\n                releaseWorker.countDown();\n                pool.shutdownNow();', 1)
assert fragment != text[start:end]
source.write_text(text[:start] + fragment + text[end:], encoding='utf-8', newline='')
print('Temporary control holds the executor before reload starts; original assertion is retained.')
