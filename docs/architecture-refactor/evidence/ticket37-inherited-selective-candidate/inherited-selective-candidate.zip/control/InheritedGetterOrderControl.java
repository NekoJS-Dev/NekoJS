import com.tkisor.nekojs.probe.ir.TypeReflector;
import java.util.Arrays;

public class InheritedGetterOrderControl {
    public static class Parent {
        private String value;
        public String getValue() { return value; }
        public void setValue(String input) { value = input; }
        public String getGetValue() { return "nested"; }
    }
    public static class Child extends Parent {
        public String getGetGetValue() { return "outer"; }
    }
    public static void main(String[] args) {
        Child child = new Child();
        child.setValue("written");
        if (!"written".equals(child.getValue())) throw new AssertionError("Real setter failed");
        System.out.println("visible=" + Arrays.stream(Child.class.getMethods())
                .filter(m -> m.getDeclaringClass() != Object.class).map(m -> m.getName()).toList());
        var names = TypeReflector.declarationMethods(Child.class).stream().map(m -> m.getName()).toList();
        System.out.println("selected=" + names);
        if (names.contains("getValue") && !names.contains("setValue")) {
            throw new AssertionError("Selected inherited getter lost its actual setter");
        }
        if (!names.contains("getValue")) throw new AssertionError("Nested getter closure is incomplete");
    }
}
