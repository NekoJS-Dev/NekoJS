from typing import assert_type
from fixture import Mixed
assert_type(Mixed.matches('x', 'x'), bool)
assert_type(Mixed().matches('word'), int)
