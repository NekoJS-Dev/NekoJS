"""Run isolated native Fabric directory resource acceptance, one node per invocation."""
import hashlib
import json
import os
import re
import socket
import subprocess
import sys
import time
import uuid
import zipfile
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
node = sys.argv[1]
assert node in ('26.1.2-fabric', '26.2.0-fabric')
revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert revision.startswith('acdad763')
out = repo/'build/priority-closeout'/('fabric-directory-live-'+revision[:8]+'-v2-'+node)
assert not out.exists(), 'Preserve previous acceptance attempts'
for port in (25881,25882):
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',port))
out.mkdir()
game = out/'game'
game.mkdir()
assert game.resolve().is_relative_to((repo/'build/priority-closeout').resolve())
password = uuid.uuid4().hex
environment = dict(os.environ)
environment['JAVA_HOME']='C:/Program Files/Java/jdk-25.0.2'
environment['PATH']=environment['JAVA_HOME']+'/bin;'+environment['PATH']
relative_fixtures = {}

def write(relative, content):
    path = game/relative
    assert path.resolve().is_relative_to(game.resolve())
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(content,encoding='utf-8',newline='\n')
    relative_fixtures[relative]=content

def data(root, name, score):
    write(root+'/data/bridge/function/'+name+'.mcfunction',f'scoreboard players set {name.upper()} bridge {score}\n')

def pack(relative, identifier, script, enabled=True, loaders=None):
    manifest=dict(formatVersion=1,id=identifier,version='1.0.0',entries={'server':['main.js']})
    if loaders is not None:manifest['environment']={'loaders':loaders}
    write(relative+'/manifest.json',json.dumps(manifest,indent=2)+'\n')
    write(relative+'/server_scripts/main.js',script)
    if not enabled:write(relative+'/.neko_pack.state.json','{"enabled":false}\n')

global_root='nekojs/packs/global-data'
world_root='world/nekojs_packs/world-data'
disabled_root='nekojs/packs/disabled-data'
blocked_root='nekojs/packs/blocked-data'
write('eula.txt','eula=true\n')
write('server.properties', '\n'.join([
    'server-port=25881','server-ip=127.0.0.1','enable-rcon=true','rcon.port=25882',
    'rcon.password='+password,'online-mode=false','level-name=world','level-seed=20261020',
    'level-type=minecraft:normal','generate-structures=false','view-distance=2','simulation-distance=2',
    'spawn-protection=0','max-players=1','enable-command-block=false','motd=Fabric directory acceptance'])+'\n')
write('nekojs/startup_scripts/startup.js','console.info("FABRIC-BRIDGE-LIVE startup");\n')
pack(global_root,'global-data','console.info("FABRIC-BRIDGE-LIVE global entry");\n')
world_script=(repo/'build/priority-closeout/fabric-directory-world-fixture.js').read_text(encoding='utf-8')
pack(world_root,'world-data',world_script)
pack(disabled_root,'disabled-data','throw new Error("Disabled pack executed");\n',enabled=False)
pack(blocked_root,'blocked-data','throw new Error("Blocked pack executed");\n',loaders=['neoforge'])
for root,name,score in [('nekojs','base_only',1),(global_root,'global_only',2),(world_root,'world_only',3),
                        (disabled_root,'disabled_only',4),(blocked_root,'blocked_only',5)]:
    data(root,name,score)
for root,score in [('nekojs',10),(global_root,20),(world_root,30)]:data(root,'winner',score)
for root,value in [('nekojs','stone'),(global_root,'dirt'),(world_root,'cobblestone')]:
    write(root+'/data/bridge/tags/block/additive.json',json.dumps({'replace':False,'values':['minecraft:'+value]})+'\n')
mc_version='26.2' if node=='26.2.0-fabric' else '26.1.2'
native_jar=Path('D:/mcmodDemo/NekoJS/.gradle-perf02/caches/fabric-loom')/mc_version/'minecraft-merged.jar'
with zipfile.ZipFile(native_jar) as native:
    recipe=json.loads(native.read('data/minecraft/recipe/iron_ingot_from_smelting_iron_ore.json'))
recipe['result']={'id':'minecraft:gold_ingot'}
write(world_root+'/data/bridge/recipe/world_data.json',json.dumps(recipe,indent=2)+'\n')
snapshot = {name:hashlib.sha256(content.encode()).hexdigest() for name,content in relative_fixtures.items()
    if name not in ('server.properties','eula.txt')}
(out/'fixtures.json').write_text(json.dumps({name:content for name,content in relative_fixtures.items()
    if name not in ('server.properties','eula.txt')},indent=2)+'\n',encoding='utf-8')
(out/'fixture-hashes.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8')
init = out/'isolated-run.gradle'
init.write_text("gradle.projectsEvaluated {\n"+
    "    def target = gradle.rootProject.findProject(':"+node+"')\n"+
    "    if (target == null) return\n    target.extensions.getByName('loom').runs.named('server') {\n"+
    "        runDir('"+game.as_posix()+"')\n    }\n}\n",encoding='utf-8')
arguments=[str(repo/'gradlew.bat'),'-g','D:/mcmodDemo/NekoJS/.gradle-perf02',
    '-Dorg.gradle.java.home=C:/Program Files/Java/jdk-25.0.2','--offline','--no-parallel','--console=plain',
    '-I',str(init),':'+node+':runServer']
observations=[]

def rcon(command):
    started=time.monotonic()
    result=subprocess.run(['python','-X','utf8',str(repo/'bench/perf/rcon.py'),'25882',password,'180',command],
        cwd=repo,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    response=result.stdout.decode('utf-8',errors='replace')
    observations.append(dict(command=command,response=response,exitCode=result.returncode,seconds=time.monotonic()-started))
    (out/'commands.json').write_text(json.dumps(observations,indent=2)+'\n',encoding='utf-8')
    assert result.returncode==0, 'RCON command failed: '+command
    return response

def score(name, expected):
    response=rcon('scoreboard players get '+name+' bridge')
    match=re.search(r'has (-?\d+)',response)
    assert match and int(match.group(1))==expected, 'Unexpected score: '+name

def function(name, expected):
    rcon('function bridge:'+name)
    score(name.upper(),expected)

def block_tag(block, present):
    rcon('setblock 0 200 0 minecraft:'+block)
    name='TAG_'+block.upper()
    rcon('scoreboard players set '+name+' bridge 0')
    rcon('execute '+('if' if present else 'unless')+' block 0 200 0 #bridge:additive run scoreboard players set '+name+' bridge 1')
    score(name,1)

def wait_winner(expected):
    deadline=time.monotonic()+90
    while time.monotonic()<deadline:
        rcon('function bridge:winner')
        response=rcon('scoreboard players get WINNER bridge')
        if re.search(r'has '+str(expected)+r'\b',response):return
        time.sleep(1)
    raise AssertionError('Native reload did not publish the expected WORLD state')

def save_fixtures(name):
    (out/name).write_text(json.dumps({key:content for key,content in relative_fixtures.items()
        if key not in ('server.properties','eula.txt')},indent=2)+'\n',encoding='utf-8')

ready=False
normal_stop=False
accepted=False
start=time.monotonic()
process=None
try:
    with (out/'launcher.log').open('xb') as log:
        process=subprocess.Popen(arguments,cwd=repo,env=environment,stdout=log,stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        (out/'launcher.json').write_text(json.dumps(dict(pid=process.pid,node=node,gameDirectory=str(game),
            revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()),indent=2)+'\n')
        latest=game/'logs/latest.log'
        deadline=time.monotonic()+420
        while time.monotonic()<deadline:
            if process.poll() is not None:raise AssertionError('Fabric launcher exited before acceptance')
            text=latest.read_text(encoding='utf-8',errors='replace') if latest.exists() else ''
            if 'Done (' in text and 'FABRIC-BRIDGE-LIVE started recipes ok' in text:
                ready=True
                break
            time.sleep(1)
        assert ready,'Fabric startup deadline exceeded'
        assert 'FABRIC-BRIDGE-LIVE started recipes ok' in text,'Initial WORLD recipe acceptance marker missing'
        assert 'FABRIC-BRIDGE-LIVE global entry' in text and 'FABRIC-BRIDGE-LIVE world entry' in text
        rcon('scoreboard objectives add bridge dummy')
        for name,value in [('base_only',1),('global_only',2),('world_only',3),('winner',30)]:function(name,value)
        for name in ['disabled_only','blocked_only']:
            assert 'Unknown function' in rcon('function bridge:'+name), 'Excluded function was mounted'
        rcon('forceload add 0 0')
        chunk_deadline=time.monotonic()+30
        while time.monotonic()<chunk_deadline:
            loaded=rcon('execute if loaded 0 200 0 run say FABRIC-BRIDGE-LIVE chunk ready')
            if 'FABRIC-BRIDGE-LIVE chunk ready' in loaded:break
            time.sleep(1)
        else:raise AssertionError('Acceptance chunk did not load')
        for block in ['stone','dirt','cobblestone']:block_tag(block,True)
        data(world_root,'winner',31)
        write(world_root+'/data/bridge/tags/block/additive.json',json.dumps({'replace':False,'values':['minecraft:andesite']})+'\n')
        (out/'fixtures-after.json').write_text(json.dumps({name:content for name,content in relative_fixtures.items()
            if name not in ('server.properties','eula.txt')},indent=2)+'\n',encoding='utf-8')
        rcon('reload')
        wait_winner(31)
        for block in ['stone','dirt','andesite']:block_tag(block,True)
        block_tag('cobblestone',False)
        function('global_only',2)
        function('world_only',3)
        assert 'phase=COMMIT - no errors.' in rcon('nekojs reload'),'Script reload did not commit cleanly'
        # Script and native data reloads have separate publication boundaries.
        # Remove listeners before withdrawing their data, and restore data before listeners.
        write(world_root+'/.neko_pack.state.json','{"enabled":false}\n')
        save_fixtures('fixtures-disabled.json')
        assert 'phase=COMMIT - no errors.' in rcon('nekojs reload'),'WORLD disable did not commit cleanly'
        rcon('reload')
        wait_winner(20)
        assert 'Unknown function' in rcon('function bridge:world_only'),'Disabled WORLD data remained mounted'
        for block in ['stone','dirt']:block_tag(block,True)
        block_tag('andesite',False)
        write(world_root+'/.neko_pack.state.json','{"enabled":true}\n')
        save_fixtures('fixtures-restored.json')
        rcon('reload')
        wait_winner(31)
        function('world_only',3)
        block_tag('andesite',True)
        assert 'phase=COMMIT - no errors.' in rcon('nekojs reload'),'WORLD restore did not commit cleanly'
        rcon('stop')
        process.wait(timeout=90)
        normal_stop=process.returncode==0
        assert normal_stop,'Fabric launcher did not finish normally'
        accepted=True
finally:
    if process is not None and process.poll() is None:
        try:
            rcon('stop')
            process.wait(timeout=60)
            normal_stop=process.returncode==0
        except (AssertionError,subprocess.TimeoutExpired):
            # Only terminate the process tree created by this controller; never other JVMs.
            subprocess.run(['taskkill.exe','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    result=dict(node=node,ready=ready,accepted=accepted,normalStop=normal_stop,revision=revision,launcherExitCode=None if process is None else process.poll(),
        seconds=time.monotonic()-start,diagnosticOnly=False,clientAssetsAccepted=False)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==revision
print('FABRIC_DIRECTORY_SERVER_ACCEPTANCE_COMPLETE',node,flush=True)
