console.info("FABRIC-BRIDGE-LIVE world entry");

let recipeCallbackRan = false;
const dataRecipeId = "bridge:world_data";
const scriptRecipeId = "bridge:world_script";

ServerEvents.recipes(event => {
    if (!event.exists(dataRecipeId)) {
        throw new Error("WORLD data recipe was missing from the recipe event");
    }
    const definition = JSON.parse(event.getJson(dataRecipeId));
    definition.ingredient = "minecraft:copper_ore";
    definition.result = {id: "minecraft:diamond"};
    definition.experience = 0.25;
    event.setJson(scriptRecipeId, JSON.stringify(definition));
    if (!event.exists(scriptRecipeId)) {
        throw new Error("WORLD script recipe was missing from the recipe event");
    }
    recipeCallbackRan = true;
});

ServerEvents.started(event => {
    if (!recipeCallbackRan) {
        throw new Error("WORLD recipe callback did not run before the first started event");
    }
    const ResourceKey = Java.type("net.minecraft.resources.ResourceKey");
    const Registries = Java.type("net.minecraft.core.registries.Registries");
    const Identifier = Java.type("net.minecraft.resources.Identifier");
    const manager = event.server.recipeManager;
    for (const id of [dataRecipeId, scriptRecipeId]) {
        const key = ResourceKey.create(Registries.RECIPE, Identifier.parse(id));
        if (!manager.byKey(key).isPresent()) {
            throw new Error("Recipe was missing from the native manager at first started: " + id);
        }
    }
    console.info("FABRIC-BRIDGE-LIVE started recipes ok");
});
