import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

repo=Path('D:/mcmodDemo/NekoJS-mult')
tools=repo/'build/priority-closeout'
revision='acdad763a1133cef475eecf5983e9c1a42da1436'
out=repo/'docs/architecture-refactor/evidence/2026-10-20-fabric-directory-server'
assert not out.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==revision
files={}
results={}
for node in ['26.1.2-fabric','26.2.0-fabric']:
    run=tools/('fabric-directory-live-acdad763-v3-'+node)
    result=json.loads((run/'result.json').read_text())
    assert result['accepted'] and result['normalStop'] and result['launcherExitCode']==0
    assert not result['clientAssetsAccepted'] and result['revision']==revision
    results[node]=result
    for path in run.iterdir():
        if path.is_file():files['accepted/'+node+'/'+path.name]=path.read_bytes()
    files['accepted/'+node+'/latest.log']=(run/'game/logs/latest.log').read_bytes()
    binding=json.loads((run/'source-binding.json').read_text())
    jar=repo/'versions'/node/'build/libs'/binding['artifactName']
    content=jar.read_bytes()
    assert hashlib.sha256(content).hexdigest()==binding['artifactSha256']
    with zipfile.ZipFile(jar) as packaged:
        for name,digest in binding['classes'].items():
            assert hashlib.sha256(packaged.read(name)).hexdigest()==digest,name
    files['artifacts/'+binding['artifactName']]=content
for attempt in ['fabric-directory-live-acdad763-26.1.2-fabric',
                'fabric-directory-live-acdad763-v2-26.1.2-fabric']:
    run=tools/attempt
    for path in run.iterdir():
        if path.is_file():files['failed/'+attempt+'/'+path.name]=path.read_bytes()
    log=run/'game/logs/latest.log'
    if log.is_file():files['failed/'+attempt+'/latest.log']=log.read_bytes()
for name in ['fabric-directory-live-acdad763-v3.py','fabric-directory-world-fixture.js',
             'seal-fabric-directory-live.py']:
    files['tools/'+name]=(tools/name).read_bytes()
production_delta=subprocess.check_output(['git','diff','26844b7e',revision,'--',
    'common/src/main','src/main','src/fabric','src/neoforge','versions/*/src/main'],cwd=repo)
assert not production_delta
files['production-delta-from-measured-source.patch']=production_delta
files['binding.json']=(json.dumps(dict(revision=revision,performanceRevision='26844b7e65a6e71f7623af631192b03bbd5543b4',
    productionDeltaEmpty=True,sourceRuntimeAcceptance=True,installedJarAcceptance=False,
    clientAssetsAccepted=False),indent=2)+'\n').encode()
manifest={name:hashlib.sha256(content).hexdigest() for name,content in sorted(files.items())}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out.mkdir()
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as target:
    for name,content in sorted(files.items()):target.writestr(name,content)
(out/'verification.json').write_text(json.dumps(dict(revision=revision,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    bytes=archive.stat().st_size,entries=len(files),results=results),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(entries=len(files),bytes=archive.stat().st_size,results=results)))
