from typing import assert_type
from nekojs._events.startup import StartupRegistryEvent
from nekojs._registry_builders import SoundEventBuilder, PotionBuilder

def configure_sound(build: SoundEventBuilder) -> None:
    build.fixedRange = None
    build.setFixedRange(None)

def configure_potion(build: PotionBuilder) -> None:
    build.effect('minecraft:speed', 60, 1)
    build.effect('minecraft:speed', 60, 1, True, False)

def use_event(event: StartupRegistryEvent) -> None:
    assert_type(event.soundEvent('test:default', configure_sound), SoundEventBuilder)
    assert_type(event.soundEvent('test:named', 'basic', configure_sound), SoundEventBuilder)
    assert_type(event.potion('test:potion', configure_potion), PotionBuilder)
    event.register('minecraft:sound_event', 'test:raw', lambda: object())
