from pathlib import Path
r=Path.cwd(); out=r/'build/ticket15-startup-declarations'
for name in ['prepare-installed.ps1','run-installed.ps1']:
    s=(r/'build/ticket37-ts-event-dependencies'/name).read_text(encoding='utf-8-sig').replace('ticket37-ts-installed-26.2','ticket15-startup-installed-26.2').replace('25893','25895').replace('25894','25896').replace('ts-event-dependencies-proof-world','startup-declarations-proof-world').replace('Owned TS event dependency proof','Owned STARTUP declaration proof').replace('ticket37-installed-proof.py','ticket15-startup-declarations/installed-proof.py')
    (out/name).write_text(s,encoding='utf-8')
s=(r/'build/ticket37-installed-proof.py').read_text(encoding='utf-8-sig')
s=s.replace("    command('nekojs registry')", "    command('nekojs registry')",1)
s=s.replace("    command('forceload add 0 0')", "    log = (root / 'server-stdout.log').read_text(encoding='utf-8', errors='replace')\n    if 'STARTUP-INSTALLED-REGISTRATIONS-PASS checks=14' not in log:\n        raise RuntimeError('STARTUP registration checks did not complete')\n    command('forceload add 0 0')")
s=s.replace("    command('summon minecraft:pig", "    placed = command('setblock 2 80 0 ticket15_startup:stone')\n    if 'changed' not in placed.lower():\n        raise RuntimeError('Registered STARTUP block placement failed')\n    placed_fluid = command('setblock 3 80 0 ticket15_startup:spring')\n    if 'changed' not in placed_fluid.lower():\n        raise RuntimeError('Registered STARTUP fluid block placement failed')\n    command('summon minecraft:pig",1)
(out/'installed-proof.py').write_text(s,encoding='utf-8')
