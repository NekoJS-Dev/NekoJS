import ast,json
from pathlib import Path
w=Path('build/ticket15-startup-declarations'); root=Path('build/ticket15-startup-reviewed-installed-26.2')
for side in ['server','startup']:
    (w/f'reviewed-live-strict-{side}.json').write_text(json.dumps({'extends':f'../ticket15-startup-reviewed-installed-26.2/nekojs/{side}_scripts/jsconfig.json','compilerOptions':{'noEmit':True,'skipLibCheck':False}},indent=2)+'\n')
cfg={'extends':'reviewed-live-strict-startup.json','files':['caller.ts']}
(w/'reviewed-live-caller-tsconfig.json').write_text(json.dumps(cfg,indent=2)+'\n')
py='../ticket15-startup-reviewed-installed-26.2/.neko_probe/python'
for kind,includes in [('focused',['caller.py',py+'/nekojs/_events/startup/__init__.pyi',py+'/nekojs/_registry_builders/__init__.pyi']),('full',[py]),('negative',['caller-negative.py'])]:
    (w/f'reviewed-live-{kind}-pyright.json').write_text(json.dumps({'include':includes,'extraPaths':[py],'typeCheckingMode':'strict','pythonVersion':'3.12'},indent=2)+'\n')
fs=list((root/'.neko_probe/python').rglob('*.pyi'))
for f in fs: ast.parse(f.read_text(encoding='utf-8'),filename=str(f))
print('REVIEWED_ACTUAL_PYTHON_AST_PASS',len(fs))
