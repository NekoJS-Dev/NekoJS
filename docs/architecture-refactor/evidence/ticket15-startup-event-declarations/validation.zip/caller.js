RegistryEvents.register(function (event) {
    var sound = event.soundEvent('test:nullable', function (build) {
        build.fixedRange = null;
        build.setFixedRange(null);
    });
    event.soundEvent('test:named', 'basic', function (build) { build.fixedRange = 16; });
    event.item('test:item', function (build) { build.maxStackSize = 16; });
    event.potion('test:potion', function (build) {
        build.effect('minecraft:speed', 60, 1);
        build.effect('minecraft:speed', 60, 1, true, false);
        // @ts-expect-error The runtime has no four-argument Potion effect overload.
        build.effect('minecraft:speed', 60, 1, true);
    });
    event.register('minecraft:sound_event', 'test:supplier', function () { return ({}); });
    // @ts-expect-error STARTUP returns a builder surface, not a dynamic boolean.
    var dynamic = sound;
    // @ts-expect-error STARTUP requires an executable callback.
    event.soundEvent('test:missing');
    // @ts-expect-error STARTUP requires an executable callback.
    event.soundEvent('test:null', null);
    // @ts-expect-error Selected builder does not expose item configuration.
    event.soundEvent('test:wrong', function (build) { build.maxStackSize = 16; });
    // @ts-expect-error create is a host adapter factory, not a script event member.
    event.create('test:invalid', function () { });
    void dynamic;
});
