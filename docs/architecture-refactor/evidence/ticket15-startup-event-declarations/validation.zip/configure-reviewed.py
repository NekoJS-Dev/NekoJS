from pathlib import Path
w=Path('build/ticket15-startup-declarations')
s=(w/'final-matrix-audit.py').read_text(encoding='utf-8-sig').replace('full-matrix-final','full-matrix-reviewed').replace('matrix-capture','reviewed-matrix-capture').replace("f'tsconfig-{capture.name}","f'tsconfig-reviewed-{capture.name}").replace("f'pyright-{capture.name}","f'pyright-reviewed-{capture.name}")
(w/'reviewed-matrix-audit.py').write_text(s,encoding='utf-8')
for name in ['prepare-installed','run-installed']:
    s=(w/(name+'.ps1')).read_text(encoding='utf-8-sig').replace('ticket15-startup-installed-26.2','ticket15-startup-reviewed-installed-26.2').replace('25895','25897').replace('25896','25898')
    (w/(name+'-reviewed.ps1')).write_text(s,encoding='utf-8')
