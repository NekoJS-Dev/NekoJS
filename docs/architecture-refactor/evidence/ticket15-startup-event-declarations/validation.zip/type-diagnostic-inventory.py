import collections,json,re
from pathlib import Path
w=Path('build/ticket15-startup-declarations')
for name in ['reviewed-live-strict-server.txt','reviewed-live-strict-startup.txt','reviewed-live-caller-tsc.txt']:
    lines=[s for s in (w/name).read_text(encoding='utf-8-sig').splitlines() if ': error TS' in s]
    groups=collections.Counter(re.search('error (TS[0-9]+)',s)[1] for s in lines)
    print(name,len(lines),dict(groups))
    if name.endswith('caller-tsc.txt'): print('CALLER_DIAGNOSTICS',[s for s in lines if 'declarations/caller.ts(' in s])
for name in ['reviewed-live-full-pyright-output.json','reviewed-live-focused-pyright-output.json','reviewed-live-negative-pyright-output.json']:
    data=json.loads((w/name).read_text(encoding='utf-8-sig')); print(name,data['summary'])
    rules=collections.Counter(d.get('rule','other') for d in data['generalDiagnostics']); print(dict(rules))
    if 'negative' in name: print([(d['range']['start']['line']+1,d.get('rule')) for d in data['generalDiagnostics']])
