RegistryEvents.register(event => {
    const sound: NekoStartupBuilders.SoundEventBuilder = event.soundEvent('test:nullable', build => {
        build.fixedRange = null;
        build.setFixedRange(null);
    });
    event.soundEvent('test:named', 'basic', build => { build.fixedRange = 16; });
    event.item('test:item', build => { build.maxStackSize = 16; });
    event.potion('test:potion', build => {
        build.effect('minecraft:speed', 60, 1);
        build.effect('minecraft:speed', 60, 1, true, false);
        // @ts-expect-error The runtime has no four-argument Potion effect overload.
        build.effect('minecraft:speed', 60, 1, true);
    });
    event.register('minecraft:sound_event', 'test:supplier', () => ({}));
    // @ts-expect-error STARTUP returns a builder surface, not a dynamic boolean.
    const dynamic: boolean = sound;
    // @ts-expect-error STARTUP requires an executable callback.
    event.soundEvent('test:missing');
    // @ts-expect-error STARTUP requires an executable callback.
    event.soundEvent('test:null', null);
    // @ts-expect-error Selected builder does not expose item configuration.
    event.soundEvent('test:wrong', build => { build.maxStackSize = 16; });
    // @ts-expect-error create is a host adapter factory, not a script event member.
    event.create('test:invalid', () => {});
    void dynamic;
});
