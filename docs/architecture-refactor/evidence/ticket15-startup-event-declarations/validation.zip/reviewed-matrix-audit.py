import ast,json,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd(); out=root/'build/ticket15-startup-declarations'
files=[]
for module in [root/'common',root/'common-api-processor',*sorted((root/'versions').iterdir())]:
    files.extend(sorted((module/'build/test-results/test').glob('TEST-*.xml')))
totals=dict(tests=0,skipped=0,failures=0,errors=0,reports=len(files))
with zipfile.ZipFile(out/'full-matrix-reviewed-xml.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in files:
        e=ET.parse(f).getroot()
        for k in ('tests','skipped','failures','errors'): totals[k]+=int(e.get(k,0))
        z.write(f,f.relative_to(root).as_posix())
print(json.dumps(totals)); (out/'full-matrix-reviewed-summary.json').write_text(json.dumps(totals,indent=2)+'\n')
for capture in sorted((out/'reviewed-matrix-capture').iterdir()):
    p=capture.relative_to(out).as_posix()
    config={'compilerOptions':{'strict':True,'noEmit':True,'skipLibCheck':False,'target':'ES2022','types':[]},'files':[p+'/typescript/@side-only/startup/events/index.d.ts',p+'/typescript/@manual/index.d.ts','caller.ts']}
    (out/f'tsconfig-reviewed-{capture.name}.json').write_text(json.dumps(config,indent=2)+'\n')
    cfg={'include':['caller.py',p+'/python/nekojs/_events/startup/__init__.pyi',p+'/python/nekojs/_registry_builders/__init__.pyi'],'extraPaths':[p+'/python'],'typeCheckingMode':'strict','pythonVersion':'3.12'}
    (out/f'pyright-reviewed-{capture.name}.json').write_text(json.dumps(cfg,indent=2)+'\n')
    fs=list((capture/'python').rglob('*.pyi'))
    for f in fs: ast.parse(f.read_text(encoding='utf-8'),filename=str(f))
    print(capture.name,'AST_PASS',len(fs))
