import json,ast,collections,re
from pathlib import Path
p=Path.cwd(); w=p/'build/ticket15-startup-declarations'; root=p/'build/ticket15-startup-installed-26.2'
for side in ['server','startup']:
    (w/f'live-strict-{side}.json').write_text(json.dumps({'extends':f'../ticket15-startup-installed-26.2/nekojs/{side}_scripts/jsconfig.json','compilerOptions':{'noEmit':True,'skipLibCheck':False}},indent=2)+'\n')
t='../ticket15-startup-installed-26.2/.neko_probe/typescript'
(w/'live-caller-tsconfig.json').write_text(json.dumps({'compilerOptions':{'strict':True,'noEmit':True,'skipLibCheck':False,'target':'ES2022','types':[]},'files':[t+'/@side-only/startup/events/index.d.ts',t+'/@manual/index.d.ts','caller.ts']},indent=2)+'\n')
py='../ticket15-startup-installed-26.2/.neko_probe/python'
(w/'live-focused-pyright.json').write_text(json.dumps({'include':['caller.py',py+'/nekojs/_events/startup/__init__.pyi',py+'/nekojs/_registry_builders/__init__.pyi'],'extraPaths':[py],'typeCheckingMode':'strict','pythonVersion':'3.12'},indent=2)+'\n')
(w/'live-full-pyright.json').write_text(json.dumps({'include':[py],'extraPaths':[py],'typeCheckingMode':'strict','pythonVersion':'3.12'},indent=2)+'\n')
files=list((root/'.neko_probe/python').rglob('*.pyi'))
for f in files: ast.parse(f.read_text(encoding='utf-8'),filename=str(f))
print('ACTUAL_PYTHON_AST_PASS',len(files))
