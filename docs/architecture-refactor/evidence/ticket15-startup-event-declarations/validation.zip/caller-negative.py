from typing import assert_type
from nekojs._events.startup import StartupRegistryEvent
from nekojs._registry_builders import SoundEventBuilder, PotionBuilder

def configure_sound(build: SoundEventBuilder) -> None:
    build.fixedRange = None

def configure_potion(build: PotionBuilder) -> None:
    build.effect('minecraft:speed', 60, 1, True)

def use_event(event: StartupRegistryEvent) -> None:
    event.soundEvent('test:missing')
    event.soundEvent('test:null', None)
    event.soundEvent('test:wrong_builder', configure_potion)
    assert_type(event.soundEvent('test:result', configure_sound), bool)
    event.create('test:host_factory', configure_sound)
