import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec, $DynamicOps, $Keyable, $Lifecycle } from "java:com/mojang/serialization";
import { $Enum, $Iterable, $Record, $Runnable, $String } from "java:java/lang";
import { $Iterator, $List, $Map$Entry, $Optional, $Set, $Spliterator } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $DataComponentLookup, $DataComponentMap } from "java:net/minecraft/core/component";
import { $Identifier, $ResourceKey } from "java:net/minecraft/resources";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $TagKey, $TagLoader$LoadResult } from "java:net/minecraft/tags";
import { $RandomSource } from "java:net/minecraft/util";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $IHolderExtension, $PendingTagsExtension } from "java:net/neoforged/neoforge/common/extensions";
import { $IRegistryExtension } from "java:net/neoforged/neoforge/registries";
import { $DataMapType } from "java:net/neoforged/neoforge/registries/datamaps";

export * as component from "java:net/minecraft/core/component";

declare module "java:net/minecraft/core" {
    export interface $Holder<T> extends $IHolderExtension {
        areComponentsBound(): boolean;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        direct<T>(arg0: T, arg1: $DataComponentMap): $Holder<T>;
        direct<T>(arg0: T): $Holder<T>;
        getRegisteredName(): string;
        isBound(): boolean;
        is(arg0: $Predicate<$ResourceKey<T>>): boolean;
        is(arg0: $Holder<T>): boolean;
        is(arg0: $Identifier): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $TagKey<T>): boolean;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export class $Holder$Kind {
        static DIRECT: $Holder$Kind;
        static REFERENCE: $Holder$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Holder$Kind[];
        static valueOf(name: string): $Holder$Kind;
    }

    export class $Holder$Reference<T> implements $Holder {
        get key(): $ResourceKey<T>;
        getKey(): $ResourceKey<T>;
        get bound(): boolean;
        isBound(): boolean;
        static createIntrusive<T>(arg0: $HolderOwner<T>, arg1: T): $Holder$Reference<T>;
        static createStandAlone<T>(arg0: $HolderOwner<T>, arg1: $ResourceKey<T>): $Holder$Reference<T>;
        areComponentsBound(): boolean;
        bindComponents(arg0: $DataComponentMap): void;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        equals(arg0: object): boolean;
        getData<A>(arg0: $DataMapType<T, A>): A;
        hashCode(): number;
        is(arg0: $Predicate<$ResourceKey<T>>): boolean;
        is(arg0: $Holder<T>): boolean;
        is(arg0: $Identifier): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $TagKey<T>): boolean;
        key(): $ResourceKey<T>;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        toString(): string;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrapLookup(): $HolderLookup$RegistryLookup<T>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export interface $HolderLookup<T> extends $HolderGetter {
        listElementIds(): $Stream<$ResourceKey<T>>;
        listElements(): $Stream<$Holder$Reference<T>>;
        listTagIds(): $Stream<$TagKey<T>>;
        listTags(): $Stream<$HolderSet$Named<T>>;
    }

    export interface $HolderLookup$RegistryLookup<T> extends $HolderLookup, $HolderOwner {
        filterElements(arg0: $Predicate<T>): $HolderLookup$RegistryLookup<T>;
        filterFeatures(arg0: $FeatureFlagSet): $HolderLookup$RegistryLookup<T>;
        getData<A>(arg0: $DataMapType<T, A>, arg1: $ResourceKey<T>): A;
        key(): $ResourceKey<$Registry<T>>;
        registryLifecycle(): $Lifecycle;
    }

    export interface $HolderOwner<T> {
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
    }

    export class $HolderSet$ListBacked<T> implements $HolderSet {
        constructor();
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        getRandomElement(arg0: $RandomSource): $Optional<$Holder<T>>;
        get(arg0: number): $Holder<T>;
        iterator(): $Iterator<$Holder<T>>;
        size(): number;
        spliterator(): $Spliterator<$Holder<T>>;
        stream(): $Stream<$Holder<T>>;
    }

    export class $HolderSet$Named<T> extends $HolderSet$ListBacked {
        get bound(): boolean;
        isBound(): boolean;
        get immediatelyResolvable(): boolean;
        isImmediatelyResolvable(): boolean;
        addInvalidationListener(arg0: $Runnable): void;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        contains(arg0: $Holder<T>): boolean;
        key(): $TagKey<T>;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export interface $IdMap<T> extends $Iterable {
        byIdOrThrow(arg0: number): T;
        byId(arg0: number): T;
        getIdOrThrow(arg0: T): number;
        getId(arg0: T): number;
        size(): number;
        static DEFAULT: number;
    }

    export class $RegistrationInfo extends $Record {
        constructor(knownPackInfo: $Optional<$KnownPack>, lifecycle: $Lifecycle);
        static BUILT_IN: $RegistrationInfo;
        equals(arg0: object): boolean;
        hashCode(): number;
        knownPackInfo(): $Optional<$KnownPack>;
        lifecycle(): $Lifecycle;
        toString(): string;
    }

    export interface $Registry<T> extends $IdMap, $Keyable, $HolderLookup$RegistryLookup, $IRegistryExtension {
        asHolderIdMap(): $IdMap<$Holder<T>>;
        byNameCodec(): $Codec<T>;
        componentLookup(): $DataComponentLookup<T>;
        containsKey(arg0: $Identifier): boolean;
        containsKey(arg0: $ResourceKey<T>): boolean;
        createIntrusiveHolder(arg0: T): $Holder$Reference<T>;
        entrySet(): $Set<$Map$Entry<$ResourceKey<T>, T>>;
        freeze(): $Registry<T>;
        getAny(): $Optional<$Holder$Reference<T>>;
        getId(arg0: T): number;
        getKey(arg0: T): $Identifier;
        getOptional(arg0: $Identifier): $Optional<T>;
        getOptional(arg0: $ResourceKey<T>): $Optional<T>;
        getRandom(arg0: $RandomSource): $Optional<$Holder$Reference<T>>;
        getResourceKey(arg0: T): $Optional<$ResourceKey<T>>;
        getTagOrEmpty(arg0: $TagKey<T>): $Iterable<$Holder<T>>;
        getTags(): $Stream<$HolderSet$Named<T>>;
        getValueOrThrow(arg0: $ResourceKey<T>): T;
        getValue(arg0: $Identifier): T;
        getValue(arg0: $ResourceKey<T>): T;
        get(arg0: number): $Optional<$Holder$Reference<T>>;
        get(arg0: $Identifier): $Optional<$Holder$Reference<T>>;
        holderByNameCodec(): $Codec<$Holder<T>>;
        keySet(): $Set<$Identifier>;
        keys<U>(arg0: $DynamicOps<U>): $Stream<U>;
        key(): $ResourceKey<$Registry<T>>;
        prepareTagReload(arg0: $TagLoader$LoadResult<T>): $Registry$PendingTags<T>;
        registerForHolder<R, T>(arg0: $Registry<R>, arg1: $Identifier, arg2: T): $Holder$Reference<T>;
        registerForHolder<R, T>(arg0: $Registry<R>, arg1: $ResourceKey<R>, arg2: T): $Holder$Reference<T>;
        register<T>(arg0: $Registry<any>, arg1: string, arg2: T): T;
        register<V, T>(arg0: $Registry<V>, arg1: $Identifier, arg2: T): T;
        register<V, T>(arg0: $Registry<V>, arg1: $ResourceKey<V>, arg2: T): T;
        registrationInfo(arg0: $ResourceKey<T>): $Optional<$RegistrationInfo>;
        registryKeySet(): $Set<$ResourceKey<T>>;
        stream(): $Stream<T>;
        wrapAsHolder(arg0: T): $Holder<T>;
    }

    export interface $Registry$PendingTags<T> extends $PendingTagsExtension {
        apply(): void;
        key(): $ResourceKey<$Registry<T>>;
        lookup(): $HolderLookup$RegistryLookup<T>;
        size(): number;
    }

    export type $Holder$Kind_ = $Holder$Kind | "DIRECT" | "REFERENCE";
}
