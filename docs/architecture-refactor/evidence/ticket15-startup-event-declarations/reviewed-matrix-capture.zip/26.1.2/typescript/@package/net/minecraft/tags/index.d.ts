import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Record, $String } from "java:java/lang";
import { $List, $Map, $Optional } from "java:java/util";
import { $Holder } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $ResourceKey } from "java:net/minecraft/resources";

declare module "java:net/minecraft/tags" {
    export class $TagKey<T> extends $Record {
        constructor(registry: $ResourceKey<$Registry<T>>, location: $Identifier);
        static codec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static create<T>(arg0: $ResourceKey<$Registry<T>>, arg1: $Identifier): $TagKey<T>;
        static hashedCodec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static streamCodec<T>(arg0: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $TagKey<T>>;
        cast<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$TagKey<E>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        isFor(arg0: $ResourceKey<$Registry<any>>): boolean;
        location(): $Identifier;
        registry(): $ResourceKey<$Registry<T>>;
        toString(): string;
    }

    export class $TagLoader$LoadResult<T> extends $Record {
        constructor(key: $ResourceKey<$Registry<T>>, tags: { [key: $TagKey<T>]: $Holder<T>[] });
        equals(arg0: object): boolean;
        hashCode(): number;
        key(): $ResourceKey<$Registry<T>>;
        tags(): $Map<$TagKey<T>, $List<$Holder<T>>>;
        toString(): string;
    }

}
