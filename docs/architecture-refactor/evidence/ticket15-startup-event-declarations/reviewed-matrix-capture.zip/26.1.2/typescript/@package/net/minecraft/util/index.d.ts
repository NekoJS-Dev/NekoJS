import { $PositionalRandomFactory } from "java:net/minecraft/world/level/levelgen";

declare module "java:net/minecraft/util" {
    export interface $RandomSource {
        consumeCount(arg0: number): void;
        createThreadLocalInstance(arg0: number): $RandomSource;
        createThreadLocalInstance(): $RandomSource;
        createThreadSafe(): $RandomSource;
        create(arg0: number): $RandomSource;
        create(): $RandomSource;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextGaussian(): number;
        nextIntBetweenInclusive(arg0: number, arg1: number): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(): number;
        setSeed(arg0: number): void;
        triangle(arg0: number, arg1: number): number;
        triangle(arg0: number, arg1: number): number;
        static GAUSSIAN_SPREAD_FACTOR: number;
    }

}
