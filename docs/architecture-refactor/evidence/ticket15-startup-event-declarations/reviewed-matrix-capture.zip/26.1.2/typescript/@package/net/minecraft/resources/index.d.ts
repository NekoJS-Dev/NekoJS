import { $StringReader } from "java:com/mojang/brigadier";
import { $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Comparable, $String } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Optional } from "java:java/util";
import { $UnaryOperator } from "java:java/util/function";
import { $Registry } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/resources" {
    export class $Identifier implements $Comparable {
        static ALLOWED_NAMESPACE_CHARACTERS: string;
        static CODEC: $Codec<$Identifier>;
        static DEFAULT_NAMESPACE: string;
        static ERROR_INVALID: $SimpleCommandExceptionType;
        static NAMESPACE_SEPARATOR: string;
        static REALMS_NAMESPACE: string;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Identifier>;
        get namespace(): string;
        getNamespace(): string;
        get path(): string;
        getPath(): string;
        static bySeparator(arg0: string, arg1: string): $Identifier;
        static fromNamespaceAndPath(arg0: string, arg1: string): $Identifier;
        static isAllowedInIdentifier(arg0: string): boolean;
        static isValidNamespace(arg0: string): boolean;
        static isValidPath(arg0: string): boolean;
        static parse(arg0: string): $Identifier;
        static readNonEmpty(arg0: $StringReader): $Identifier;
        static read(arg0: $StringReader): $Identifier;
        static read(arg0: string): $DataResult<$Identifier>;
        static tryBuild(arg0: string, arg1: string): $Identifier;
        static tryBySeparator(arg0: string, arg1: string): $Identifier;
        static tryParse(arg0: string): $Identifier;
        static validNamespaceChar(arg0: string): boolean;
        static validPathChar(arg0: string): boolean;
        static withDefaultNamespace(arg0: string): $Identifier;
        compareNamespaced(arg0: $Identifier): number;
        compareTo(arg0: $Identifier): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        resolveAgainst(arg0: string): $Path;
        toDebugFileName(): string;
        toLanguageKey(arg0: string, arg1: string): string;
        toLanguageKey(arg0: string): string;
        toLanguageKey(): string;
        toShortLanguageKey(): string;
        toShortString(): string;
        toString(): string;
        withPath(arg0: string): $Identifier;
        withPath(arg0: $UnaryOperator<string>): $Identifier;
        withPrefix(arg0: string): $Identifier;
        withSuffix(arg0: string): $Identifier;
    }

    export class $ResourceKey<T> implements $Comparable {
        static codec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$ResourceKey<T>>;
        static createRegistryKey<T>(arg0: $Identifier): $ResourceKey<$Registry<T>>;
        static create<T>(arg0: $ResourceKey<$Registry<T>>, arg1: $Identifier): $ResourceKey<T>;
        static streamCodec<T>(arg0: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $ResourceKey<T>>;
        cast<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$ResourceKey<E>>;
        compareTo(arg0: $ResourceKey<any>): number;
        identifier(): $Identifier;
        isFor(arg0: $ResourceKey<$Registry<any>>): boolean;
        registryKey(): $ResourceKey<$Registry<T>>;
        registry(): $Identifier;
        toString(): string;
    }

}
