import { $String, $StringBuilder } from "java:java/lang";
import { $BlockPos } from "java:net/minecraft/core";
import { $Identifier } from "java:net/minecraft/resources";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/world/level/levelgen" {
    export interface $PositionalRandomFactory {
        at(arg0: number, arg1: number, arg2: number): $RandomSource;
        at(arg0: $BlockPos): $RandomSource;
        fromHashOf(arg0: string): $RandomSource;
        fromHashOf(arg0: $Identifier): $RandomSource;
        fromSeed(arg0: number): $RandomSource;
        parityConfigString(arg0: $StringBuilder): void;
    }

}
