import { $Codec } from "java:com/mojang/serialization";
import { $Iterable } from "java:java/lang";
import { $Collection, $Iterator, $Map, $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $Holder } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/core/component" {
    export class $DataComponentLookup<T> {
        constructor(arg0: $Iterable<$Holder<T>>);
        findAll<C>(arg0: $DataComponentType<C>, arg1: C): $Collection<$Holder<T>>;
        findAll<C>(arg0: $DataComponentType<C>): $Collection<$Holder<T>>;
        findMatching<C>(arg0: $DataComponentType<C>, arg1: $Predicate<C>): $Stream<$Holder<T>>;
    }

    export interface $DataComponentMap extends $Iterable, $DataComponentGetter {
        builder(): $DataComponentMap$Builder;
        composite(arg0: $DataComponentMap, arg1: $DataComponentMap): $DataComponentMap;
        filter(arg0: $Predicate<$DataComponentType<any>>): $DataComponentMap;
        has(arg0: $DataComponentType<any>): boolean;
        isEmpty(): boolean;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        makeCodecFromMap(arg0: $Codec<{ [key: $DataComponentType<any>]: object }>): $Codec<$DataComponentMap>;
        makeCodec(arg0: $Codec<$DataComponentType<any>>): $Codec<$DataComponentMap>;
        size(): number;
        stream(): $Stream<$TypedDataComponent<any>>;
        static CODEC: $Codec<$DataComponentMap>;
        static EMPTY: $DataComponentMap;
    }

    export interface $DataComponentType<T> {
        builder<T>(): $DataComponentType$Builder<T>;
        codecOrThrow(): $Codec<T>;
        codec(): $Codec<T>;
        ignoreSwapAnimation(): boolean;
        isTransient(): boolean;
        streamCodec(): $StreamCodec<any, T>;
        static CODEC: $Codec<$DataComponentType<any>>;
        static PERSISTENT_CODEC: $Codec<$DataComponentType<any>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentType<any>>;
        static VALUE_MAP_CODEC: $Codec<$Map<$DataComponentType<any>, object>>;
    }

}
