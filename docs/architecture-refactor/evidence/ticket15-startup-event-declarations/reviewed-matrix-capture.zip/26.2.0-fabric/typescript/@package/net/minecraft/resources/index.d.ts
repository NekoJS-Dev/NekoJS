import { $StringReader } from "java:com/mojang/brigadier";
import { $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Comparable, $String } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Optional } from "java:java/util";
import { $UnaryOperator } from "java:java/util/function";
import { $Registry } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/resources" {
    export class $Identifier implements $Comparable {
        static ALLOWED_NAMESPACE_CHARACTERS: string;
        static CODEC: $Codec<$Identifier>;
        static DEFAULT_NAMESPACE: string;
        static ERROR_INVALID: $SimpleCommandExceptionType;
        static NAMESPACE_SEPARATOR: string;
        static REALMS_NAMESPACE: string;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Identifier>;
        get namespace(): string;
        getNamespace(): string;
        get path(): string;
        getPath(): string;
        static bySeparator(identifier: string, separator: string): $Identifier;
        static fromNamespaceAndPath(namespace: string, path: string): $Identifier;
        static isAllowedInIdentifier(c: string): boolean;
        static isValidNamespace(namespace: string): boolean;
        static isValidPath(path: string): boolean;
        static parse(identifier: string): $Identifier;
        static readNonEmpty(reader: $StringReader): $Identifier;
        static read(reader: $StringReader): $Identifier;
        static read(input: string): $DataResult<$Identifier>;
        static tryBuild(namespace: string, path: string): $Identifier;
        static tryBySeparator(identifier: string, separator: string): $Identifier;
        static tryParse(identifier: string): $Identifier;
        static validPathChar(c: string): boolean;
        static withDefaultNamespace(path: string): $Identifier;
        compareTo(o: $Identifier): number;
        equals(o: object): boolean;
        hashCode(): number;
        resolveAgainst(root: string): $Path;
        toDebugFileName(): string;
        toLanguageKey(prefix: string, suffix: string): string;
        toLanguageKey(prefix: string): string;
        toLanguageKey(): string;
        toShortLanguageKey(): string;
        toShortString(): string;
        toString(): string;
        withPath(newPath: string): $Identifier;
        withPath(modifier: $UnaryOperator<string>): $Identifier;
        withPrefix(prefix: string): $Identifier;
        withSuffix(suffix: string): $Identifier;
    }

    export class $ResourceKey<T> {
        static codec<T>(registryName: $ResourceKey<$Registry<T>>): $Codec<$ResourceKey<T>>;
        static createRegistryKey<T>(identifier: $Identifier): $ResourceKey<$Registry<T>>;
        static create<T>(registryName: $ResourceKey<$Registry<T>>, location: $Identifier): $ResourceKey<T>;
        static streamCodec<T>(registryName: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $ResourceKey<T>>;
        cast<E>(registry: $ResourceKey<$Registry<E>>): $Optional<$ResourceKey<E>>;
        dependent<E>(registryKey: $ResourceKey<$Registry<E>>, suffix: string): $ResourceKey<E>;
        dependent<E>(registryKey: $ResourceKey<$Registry<E>>, decoration: $UnaryOperator<string>): $ResourceKey<E>;
        identifier(): $Identifier;
        isFor(registry: $ResourceKey<$Registry<any>>): boolean;
        registryKey(): $ResourceKey<$Registry<T>>;
        registry(): $Identifier;
        toString(): string;
    }

}
