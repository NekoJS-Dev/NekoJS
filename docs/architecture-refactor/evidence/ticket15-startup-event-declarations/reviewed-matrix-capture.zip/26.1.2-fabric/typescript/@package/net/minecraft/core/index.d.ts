import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec, $DynamicOps, $Keyable, $Lifecycle } from "java:com/mojang/serialization";
import { $Enum, $Iterable, $Record, $String } from "java:java/lang";
import { $Iterator, $List, $Map$Entry, $Optional, $Set, $Spliterator } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $FabricRegistry } from "java:net/fabricmc/fabric/api/event/registry";
import { $DataComponentLookup, $DataComponentMap } from "java:net/minecraft/core/component";
import { $Identifier, $ResourceKey } from "java:net/minecraft/resources";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $TagKey, $TagLoader$LoadResult } from "java:net/minecraft/tags";
import { $RandomSource } from "java:net/minecraft/util";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";

export * as component from "java:net/minecraft/core/component";

declare module "java:net/minecraft/core" {
    export interface $Holder<T> {
        areComponentsBound(): boolean;
        canSerializeIn(registry: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        direct<T>(value: T, components: $DataComponentMap): $Holder<T>;
        direct<T>(value: T): $Holder<T>;
        getRegisteredName(): string;
        isBound(): boolean;
        is(predicate: $Predicate<$ResourceKey<T>>): boolean;
        is(holder: $Holder<T>): boolean;
        is(key: $Identifier): boolean;
        is(key: $ResourceKey<T>): boolean;
        is(tag: $TagKey<T>): boolean;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export class $Holder$Kind {
        static DIRECT: $Holder$Kind;
        static REFERENCE: $Holder$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Holder$Kind[];
        static valueOf(name: string): $Holder$Kind;
    }

    export class $Holder$Reference<T> implements $Holder {
        get bound(): boolean;
        isBound(): boolean;
        static createIntrusive<T>(owner: $HolderOwner<T>, value: T): $Holder$Reference<T>;
        static createStandAlone<T>(owner: $HolderOwner<T>, key: $ResourceKey<T>): $Holder$Reference<T>;
        areComponentsBound(): boolean;
        bindComponents(components: $DataComponentMap): void;
        canSerializeIn(context: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        is(predicate: $Predicate<$ResourceKey<T>>): boolean;
        is(holder: $Holder<T>): boolean;
        is(key: $Identifier): boolean;
        is(key: $ResourceKey<T>): boolean;
        is(tag: $TagKey<T>): boolean;
        key(): $ResourceKey<T>;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        toString(): string;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export interface $HolderLookup<T> extends $HolderGetter {
        listElementIds(): $Stream<$ResourceKey<T>>;
        listElements(): $Stream<$Holder$Reference<T>>;
        listTagIds(): $Stream<$TagKey<T>>;
        listTags(): $Stream<$HolderSet$Named<T>>;
    }

    export interface $HolderLookup$RegistryLookup<T> extends $HolderLookup, $HolderOwner {
        filterElements(filter: $Predicate<T>): $HolderLookup$RegistryLookup<T>;
        filterFeatures(enabledFeatures: $FeatureFlagSet): $HolderLookup$RegistryLookup<T>;
        key(): $ResourceKey<$Registry<T>>;
        registryLifecycle(): $Lifecycle;
    }

    export interface $HolderOwner<T> {
        canSerializeIn(context: $HolderOwner<T>): boolean;
    }

    export class $HolderSet$ListBacked<T> implements $HolderSet {
        constructor();
        canSerializeIn(owner: $HolderOwner<T>): boolean;
        getRandomElement(random: $RandomSource): $Optional<$Holder<T>>;
        get(index: number): $Holder<T>;
        iterator(): $Iterator<$Holder<T>>;
        size(): number;
        spliterator(): $Spliterator<$Holder<T>>;
        stream(): $Stream<$Holder<T>>;
    }

    export class $HolderSet$Named<T> extends $HolderSet$ListBacked {
        get bound(): boolean;
        isBound(): boolean;
        canSerializeIn(context: $HolderOwner<T>): boolean;
        contains(value: $Holder<T>): boolean;
        key(): $TagKey<T>;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export interface $IdMap<T> extends $Iterable {
        byIdOrThrow(id: number): T;
        byId(id: number): T;
        getIdOrThrow(value: T): number;
        getId(thing: T): number;
        size(): number;
        static DEFAULT: number;
    }

    export class $RegistrationInfo extends $Record {
        constructor(knownPackInfo: $Optional<$KnownPack>, lifecycle: $Lifecycle);
        static BUILT_IN: $RegistrationInfo;
        equals(o: object): boolean;
        hashCode(): number;
        knownPackInfo(): $Optional<$KnownPack>;
        lifecycle(): $Lifecycle;
        toString(): string;
    }

    export interface $Registry<T> extends $IdMap, $Keyable, $HolderLookup$RegistryLookup, $FabricRegistry {
        asHolderIdMap(): $IdMap<$Holder<T>>;
        byNameCodec(): $Codec<T>;
        componentLookup(): $DataComponentLookup<T>;
        containsKey(key: $Identifier): boolean;
        containsKey(key: $ResourceKey<T>): boolean;
        createIntrusiveHolder(value: T): $Holder$Reference<T>;
        entrySet(): $Set<$Map$Entry<$ResourceKey<T>, T>>;
        freeze(): $Registry<T>;
        getAny(): $Optional<$Holder$Reference<T>>;
        getId(thing: T): number;
        getKey(thing: T): $Identifier;
        getOptional(key: $Identifier): $Optional<T>;
        getOptional(key: $ResourceKey<T>): $Optional<T>;
        getRandom(random: $RandomSource): $Optional<$Holder$Reference<T>>;
        getResourceKey(thing: T): $Optional<$ResourceKey<T>>;
        getTagOrEmpty(id: $TagKey<T>): $Iterable<$Holder<T>>;
        getTags(): $Stream<$HolderSet$Named<T>>;
        getValueOrThrow(key: $ResourceKey<T>): T;
        getValue(key: $Identifier): T;
        getValue(key: $ResourceKey<T>): T;
        get(id: number): $Optional<$Holder$Reference<T>>;
        get(id: $Identifier): $Optional<$Holder$Reference<T>>;
        holderByNameCodec(): $Codec<$Holder<T>>;
        keySet(): $Set<$Identifier>;
        keys<U>(ops: $DynamicOps<U>): $Stream<U>;
        key(): $ResourceKey<$Registry<T>>;
        prepareTagReload(tags: $TagLoader$LoadResult<T>): $Registry$PendingTags<T>;
        registerForHolder<R, T>(registry: $Registry<R>, location: $Identifier, value: T): $Holder$Reference<T>;
        registerForHolder<R, T>(registry: $Registry<R>, key: $ResourceKey<R>, value: T): $Holder$Reference<T>;
        register<T>(registry: $Registry<any>, name: string, value: T): T;
        register<V, T>(registry: $Registry<V>, location: $Identifier, value: T): T;
        register<V, T>(registry: $Registry<V>, key: $ResourceKey<V>, value: T): T;
        registrationInfo(element: $ResourceKey<T>): $Optional<$RegistrationInfo>;
        registryKeySet(): $Set<$ResourceKey<T>>;
        stream(): $Stream<T>;
        wrapAsHolder(value: T): $Holder<T>;
    }

    export interface $Registry$PendingTags<T> {
        apply(): void;
        key(): $ResourceKey<$Registry<T>>;
        lookup(): $HolderLookup$RegistryLookup<T>;
        size(): number;
    }

    export type $Holder$Kind_ = $Holder$Kind | "DIRECT" | "REFERENCE";
}
