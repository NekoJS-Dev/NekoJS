import { $AutoCloseable, $Comparable, $String } from "java:java/lang";
import { $URI, $URL } from "java:java/net";
import { $Path } from "java:java/nio/file";

declare module "java:java/io" {
    export interface $Closeable extends $AutoCloseable {
        close(): void;
    }

    export class $File implements $Serializable, $Comparable {
        constructor(arg0: string, arg1: string);
        constructor(arg0: string);
        constructor(arg0: string, arg1: string);
        constructor(arg0: $URI);
        static pathSeparator: string;
        static pathSeparatorChar: string;
        static separator: string;
        static separatorChar: string;
        get absoluteFile(): $File;
        getAbsoluteFile(): $File;
        get absolutePath(): string;
        getAbsolutePath(): string;
        get canonicalFile(): $File;
        getCanonicalFile(): $File;
        get canonicalPath(): string;
        getCanonicalPath(): string;
        get freeSpace(): number;
        getFreeSpace(): number;
        get name(): string;
        getName(): string;
        get parentFile(): $File;
        getParentFile(): $File;
        get parent(): string;
        getParent(): string;
        get path(): string;
        getPath(): string;
        get totalSpace(): number;
        getTotalSpace(): number;
        get usableSpace(): number;
        getUsableSpace(): number;
        get absolute(): boolean;
        isAbsolute(): boolean;
        get directory(): boolean;
        isDirectory(): boolean;
        get file(): boolean;
        isFile(): boolean;
        get hidden(): boolean;
        isHidden(): boolean;
        static createTempFile(arg0: string, arg1: string, arg2: string): $File;
        static createTempFile(arg0: string, arg1: string): $File;
        static listRoots(): $File[];
        canExecute(): boolean;
        canRead(): boolean;
        canWrite(): boolean;
        compareTo(arg0: string): number;
        createNewFile(): boolean;
        deleteOnExit(): void;
        delete(): boolean;
        equals(arg0: object): boolean;
        exists(): boolean;
        hashCode(): number;
        lastModified(): number;
        length(): number;
        listFiles(arg0: $FileFilter): $File[];
        listFiles(arg0: $FilenameFilter): $File[];
        listFiles(): $File[];
        list(arg0: $FilenameFilter): string[];
        list(): string[];
        mkdirs(): boolean;
        mkdir(): boolean;
        renameTo(arg0: string): boolean;
        setExecutable(arg0: boolean, arg1: boolean): boolean;
        setReadOnly(): boolean;
        setReadable(arg0: boolean, arg1: boolean): boolean;
        setWritable(arg0: boolean, arg1: boolean): boolean;
        toPath(): $Path;
        toString(): string;
        toURI(): $URI;
        toURL(): $URL;
    }

    export interface $FileFilter {
        accept(arg0: string): boolean;
    }

    export interface $FilenameFilter {
        accept(arg0: string, arg1: string): boolean;
    }

    export class $InputStream implements $Closeable {
        constructor();
        static nullInputStream(): $InputStream;
        available(): number;
        close(): void;
        markSupported(): boolean;
        mark(arg0: number): void;
        readAllBytes(): number[];
        readNBytes(arg0: number[], arg1: number, arg2: number): number;
        readNBytes(arg0: number): number[];
        read(arg0: number[], arg1: number, arg2: number): number;
        read(arg0: number[]): number;
        read(): number;
        reset(): void;
        skipNBytes(arg0: number): void;
        skip(arg0: number): number;
        transferTo(arg0: $OutputStream): number;
    }

    export class $OutputStream implements $Closeable, $Flushable {
        constructor();
        static nullOutputStream(): $OutputStream;
        close(): void;
        flush(): void;
        write(arg0: number[], arg1: number, arg2: number): void;
        write(arg0: number[]): void;
        write(arg0: number): void;
    }

    export interface $Serializable {
    }

}
