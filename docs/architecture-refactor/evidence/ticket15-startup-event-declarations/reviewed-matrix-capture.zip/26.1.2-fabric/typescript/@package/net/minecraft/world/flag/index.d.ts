declare module "java:net/minecraft/world/flag" {
    export class $FeatureFlagSet {
        static MAX_CONTAINER_SIZE: number;
        get empty(): boolean;
        isEmpty(): boolean;
        static of(flag: $FeatureFlag, flags?: $FeatureFlag[]): $FeatureFlagSet;
        static of(flag: $FeatureFlag): $FeatureFlagSet;
        static of(): $FeatureFlagSet;
        contains(flag: $FeatureFlag): boolean;
        equals(o: object): boolean;
        hashCode(): number;
        intersects(set: $FeatureFlagSet): boolean;
        isSubsetOf(set: $FeatureFlagSet): boolean;
        join(other: $FeatureFlagSet): $FeatureFlagSet;
        subtract(other: $FeatureFlagSet): $FeatureFlagSet;
    }

}
