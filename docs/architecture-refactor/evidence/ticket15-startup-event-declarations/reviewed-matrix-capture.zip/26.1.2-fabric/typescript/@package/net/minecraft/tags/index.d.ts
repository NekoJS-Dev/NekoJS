import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Record, $String } from "java:java/lang";
import { $List, $Map, $Optional } from "java:java/util";
import { $FabricTagKey } from "java:net/fabricmc/fabric/api/tag";
import { $Holder } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $ResourceKey } from "java:net/minecraft/resources";

declare module "java:net/minecraft/tags" {
    export class $TagKey<T> extends $Record implements $FabricTagKey {
        constructor(registry: $ResourceKey<$Registry<T>>, location: $Identifier);
        static codec<T>(registryName: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static create<T>(registry: $ResourceKey<$Registry<T>>, location: $Identifier): $TagKey<T>;
        static hashedCodec<T>(registryName: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static streamCodec<T>(registryName: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $TagKey<T>>;
        cast<E>(registry: $ResourceKey<$Registry<E>>): $Optional<$TagKey<E>>;
        equals(o: object): boolean;
        hashCode(): number;
        isFor(registry: $ResourceKey<$Registry<any>>): boolean;
        location(): $Identifier;
        registry(): $ResourceKey<$Registry<T>>;
        toString(): string;
    }

    export class $TagLoader$LoadResult<T> extends $Record {
        constructor(key: $ResourceKey<$Registry<T>>, tags: { [key: $TagKey<T>]: $Holder<T>[] });
        equals(o: object): boolean;
        hashCode(): number;
        key(): $ResourceKey<$Registry<T>>;
        tags(): $Map<$TagKey<T>, $List<$Holder<T>>>;
        toString(): string;
    }

}
