import { $Closeable, $File } from "java:java/io";
import { $Class, $Comparable, $Iterable, $String } from "java:java/lang";
import { $URI } from "java:java/net";
import { $UserPrincipalLookupService } from "java:java/nio/file/attribute";
import { $FileSystemProvider } from "java:java/nio/file/spi";
import { $Iterator, $List, $Set } from "java:java/util";
import { $TimeUnit, $TimeUnit_ } from "java:java/util/concurrent";

export * as attribute from "java:java/nio/file/attribute";
export * as spi from "java:java/nio/file/spi";

declare module "java:java/nio/file" {
    export class $FileStore {
        get blockSize(): number;
        getBlockSize(): number;
        get totalSpace(): number;
        getTotalSpace(): number;
        get unallocatedSpace(): number;
        getUnallocatedSpace(): number;
        get usableSpace(): number;
        getUsableSpace(): number;
        get readOnly(): boolean;
        isReadOnly(): boolean;
        getAttribute(arg0: string): object;
        getFileStoreAttributeView<V>(arg0: $Class<V>): V;
        name(): string;
        supportsFileAttributeView(arg0: $Class<$FileAttributeView>): boolean;
        supportsFileAttributeView(arg0: string): boolean;
        type(): string;
    }

    export class $FileSystem implements $Closeable {
        get fileStores(): $Iterable<$FileStore>;
        getFileStores(): $Iterable<$FileStore>;
        get rootDirectories(): $Iterable<$Path>;
        getRootDirectories(): $Iterable<$Path>;
        get separator(): string;
        getSeparator(): string;
        get userPrincipalLookupService(): $UserPrincipalLookupService;
        getUserPrincipalLookupService(): $UserPrincipalLookupService;
        get open(): boolean;
        isOpen(): boolean;
        get readOnly(): boolean;
        isReadOnly(): boolean;
        close(): void;
        getPathMatcher(arg0: string): $PathMatcher;
        getPath(arg0: string, arg1?: string[]): $Path;
        newWatchService(): $WatchService;
        provider(): $FileSystemProvider;
        supportedFileAttributeViews(): $Set<string>;
    }

    export interface $Path extends $Comparable, $Iterable, $Watchable {
        compareTo(arg0: string): number;
        endsWith(arg0: string): boolean;
        endsWith(arg0: string): boolean;
        equals(arg0: object): boolean;
        getFileName(): $Path;
        getFileSystem(): $FileSystem;
        getNameCount(): number;
        getName(arg0: number): $Path;
        getParent(): $Path;
        getRoot(): $Path;
        hashCode(): number;
        isAbsolute(): boolean;
        iterator(): $Iterator<$Path>;
        normalize(): $Path;
        of(arg0: string, arg1?: string[]): $Path;
        of(arg0: $URI): $Path;
        register(arg0: $WatchService, arg1: $WatchEvent$Kind<any>[], arg2?: $WatchEvent$Modifier[]): $WatchKey;
        register(arg0: $WatchService, arg1?: $WatchEvent$Kind<any>[]): $WatchKey;
        relativize(arg0: string): $Path;
        resolveSibling(arg0: string): $Path;
        resolveSibling(arg0: string): $Path;
        resolve(arg0: string, arg1?: string[]): $Path;
        resolve(arg0: string): $Path;
        resolve(arg0: string, arg1?: string[]): $Path;
        resolve(arg0: string): $Path;
        startsWith(arg0: string): boolean;
        startsWith(arg0: string): boolean;
        subpath(arg0: number, arg1: number): $Path;
        toAbsolutePath(): $Path;
        toFile(): $File;
        toRealPath(arg0?: $LinkOption_[]): $Path;
        toString(): string;
        toUri(): $URI;
    }

    export interface $PathMatcher {
        matches(arg0: string): boolean;
    }

    export interface $WatchEvent<T> {
        context(): T;
        count(): number;
        kind(): $WatchEvent$Kind<T>;
    }

    export interface $WatchEvent$Kind<T> {
        name(): string;
        type(): $Class<T>;
    }

    export interface $WatchKey {
        cancel(): void;
        isValid(): boolean;
        pollEvents(): $List<$WatchEvent<any>>;
        reset(): boolean;
        watchable(): $Watchable;
    }

    export interface $WatchService extends $Closeable {
        close(): void;
        poll(arg0: number, arg1: $TimeUnit_): $WatchKey;
        poll(): $WatchKey;
        take(): $WatchKey;
    }

    export interface $Watchable {
        register(arg0: $WatchService, arg1: $WatchEvent$Kind<any>[], arg2?: $WatchEvent$Modifier[]): $WatchKey;
        register(arg0: $WatchService, arg1?: $WatchEvent$Kind<any>[]): $WatchKey;
    }

}
