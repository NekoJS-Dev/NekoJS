import { $String, $StringBuilder } from "java:java/lang";
import { $BlockPos } from "java:net/minecraft/core";
import { $Identifier } from "java:net/minecraft/resources";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/world/level/levelgen" {
    export interface $PositionalRandomFactory {
        at(x: number, y: number, z: number): $RandomSource;
        at(pos: $BlockPos): $RandomSource;
        fromHashOf(name: string): $RandomSource;
        fromHashOf(name: $Identifier): $RandomSource;
        fromSeed(seed: number): $RandomSource;
        parityConfigString(sb: $StringBuilder): void;
    }

}
