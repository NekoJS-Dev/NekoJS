import { $Codec } from "java:com/mojang/serialization";
import { $Iterable } from "java:java/lang";
import { $Collection, $Iterator, $Map, $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $Holder } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/core/component" {
    export class $DataComponentLookup<T> {
        constructor(elements: $Iterable<$Holder<T>>);
        findAll<C>(type: $DataComponentType<C>, value: C): $Collection<$Holder<T>>;
        findAll<C>(type: $DataComponentType<C>): $Collection<$Holder<T>>;
        findMatching<C>(type: $DataComponentType<C>, predicate: $Predicate<C>): $Stream<$Holder<T>>;
    }

    export interface $DataComponentMap extends $Iterable, $DataComponentGetter {
        builder(): $DataComponentMap$Builder;
        composite(prototype: $DataComponentMap, overrides: $DataComponentMap): $DataComponentMap;
        filter(predicate: $Predicate<$DataComponentType<any>>): $DataComponentMap;
        has(type: $DataComponentType<any>): boolean;
        isEmpty(): boolean;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        makeCodecFromMap(mapCodec: $Codec<{ [key: $DataComponentType<any>]: object }>): $Codec<$DataComponentMap>;
        makeCodec(componentTypeCodec: $Codec<$DataComponentType<any>>): $Codec<$DataComponentMap>;
        size(): number;
        stream(): $Stream<$TypedDataComponent<any>>;
        static CODEC: $Codec<$DataComponentMap>;
        static EMPTY: $DataComponentMap;
    }

    export interface $DataComponentType<T> {
        builder<T>(): $DataComponentType$Builder<T>;
        codecOrThrow(): $Codec<T>;
        codec(): $Codec<T>;
        ignoreSwapAnimation(): boolean;
        isTransient(): boolean;
        streamCodec(): $StreamCodec<any, T>;
        static CODEC: $Codec<$DataComponentType<any>>;
        static PERSISTENT_CODEC: $Codec<$DataComponentType<any>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentType<any>>;
        static VALUE_MAP_CODEC: $Codec<$Map<$DataComponentType<any>, object>>;
    }

}
