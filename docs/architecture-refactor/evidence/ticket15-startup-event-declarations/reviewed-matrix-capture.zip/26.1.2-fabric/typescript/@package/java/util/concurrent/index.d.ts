import { $Enum, $String, $Thread } from "java:java/lang";
import { $Duration } from "java:java/time";
import { $ChronoUnit } from "java:java/time/temporal";

declare module "java:java/util/concurrent" {
    export class $TimeUnit {
        static DAYS: $TimeUnit;
        static HOURS: $TimeUnit;
        static MICROSECONDS: $TimeUnit;
        static MILLISECONDS: $TimeUnit;
        static MINUTES: $TimeUnit;
        static NANOSECONDS: $TimeUnit;
        static SECONDS: $TimeUnit;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TimeUnit[];
        static valueOf(name: string): $TimeUnit;
    }

    export type $TimeUnit_ = $TimeUnit | "DAYS" | "HOURS" | "MICROSECONDS" | "MILLISECONDS" | "MINUTES" | "NANOSECONDS" | "SECONDS";
}
