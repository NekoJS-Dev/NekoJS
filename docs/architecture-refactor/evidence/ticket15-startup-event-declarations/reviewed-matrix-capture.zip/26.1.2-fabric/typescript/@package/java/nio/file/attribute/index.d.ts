import { $String } from "java:java/lang";

declare module "java:java/nio/file/attribute" {
    export class $UserPrincipalLookupService {
        lookupPrincipalByGroupName(arg0: string): $GroupPrincipal;
        lookupPrincipalByName(arg0: string): $UserPrincipal;
    }

}
