import { $ByteBuf } from "java:io/netty/buffer";
import { $Record, $String } from "java:java/lang";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/server/packs/repository" {
    export class $KnownPack extends $Record {
        constructor(namespace: string, id: string, version: string);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $KnownPack>;
        static VANILLA_NAMESPACE: string;
        get vanilla(): boolean;
        isVanilla(): boolean;
        static vanilla(id: string): $KnownPack;
        equals(o: object): boolean;
        hashCode(): number;
        id(): string;
        namespace(): string;
        toString(): string;
        version(): string;
    }

}
