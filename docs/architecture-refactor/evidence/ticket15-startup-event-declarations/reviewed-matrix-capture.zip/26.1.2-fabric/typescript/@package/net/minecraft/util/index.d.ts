import { $PositionalRandomFactory } from "java:net/minecraft/world/level/levelgen";

declare module "java:net/minecraft/util" {
    export interface $RandomSource {
        consumeCount(rounds: number): void;
        createThreadLocalInstance(seed: number): $RandomSource;
        createThreadLocalInstance(): $RandomSource;
        createThreadSafe(): $RandomSource;
        create(seed: number): $RandomSource;
        create(): $RandomSource;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextGaussian(): number;
        nextIntBetweenInclusive(min: number, maxInclusive: number): number;
        nextInt(origin: number, bound: number): number;
        nextInt(bound: number): number;
        nextInt(): number;
        nextLong(): number;
        setSeed(seed: number): void;
        triangle(mean: number, spread: number): number;
        triangle(mean: number, spread: number): number;
        static GAUSSIAN_SPREAD_FACTOR: number;
    }

}
