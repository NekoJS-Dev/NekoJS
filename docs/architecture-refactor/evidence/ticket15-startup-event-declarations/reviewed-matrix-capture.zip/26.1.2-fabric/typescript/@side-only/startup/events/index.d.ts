/// <reference path="../../../@event-builders/index.d.ts" />

interface StartupRegistryEvent {
    block(id: string, build: (build: NekoStartupBuilders.BlockBuilder) => void): NekoStartupBuilders.BlockBuilder;
    block(id: string, typeName: "basic", build: (build: NekoStartupBuilders.BlockBuilder) => void): NekoStartupBuilders.BlockBuilder;
    creativeModeTab(id: string, build: (build: NekoStartupBuilders.CreativeTabBuilder) => void): NekoStartupBuilders.CreativeTabBuilder;
    creativeModeTab(id: string, typeName: "basic", build: (build: NekoStartupBuilders.CreativeTabBuilder) => void): NekoStartupBuilders.CreativeTabBuilder;
    enchantment(id: string, build: (build: NekoStartupBuilders.EnchantmentBuilder) => void): NekoStartupBuilders.EnchantmentBuilder;
    enchantment(id: string, typeName: "basic", build: (build: NekoStartupBuilders.EnchantmentBuilder) => void): NekoStartupBuilders.EnchantmentBuilder;
    entityType(id: string, build: (build: NekoStartupBuilders.EntityTypeBuilder) => void): NekoStartupBuilders.EntityTypeBuilder;
    entityType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.EntityTypeBuilder) => void): NekoStartupBuilders.EntityTypeBuilder;
    item(id: string, build: (build: NekoStartupBuilders.ItemBuilder) => void): NekoStartupBuilders.ItemBuilder;
    item(id: string, typeName: "basic", build: (build: NekoStartupBuilders.ItemBuilder) => void): NekoStartupBuilders.ItemBuilder;
    mobEffect(id: string, build: (build: NekoStartupBuilders.MobEffectBuilder) => void): NekoStartupBuilders.MobEffectBuilder;
    mobEffect(id: string, typeName: "basic", build: (build: NekoStartupBuilders.MobEffectBuilder) => void): NekoStartupBuilders.MobEffectBuilder;
    particleType(id: string, build: (build: NekoStartupBuilders.ParticleTypeBuilder) => void): NekoStartupBuilders.ParticleTypeBuilder;
    particleType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.ParticleTypeBuilder) => void): NekoStartupBuilders.ParticleTypeBuilder;
    potion(id: string, build: (build: NekoStartupBuilders.PotionBuilder) => void): NekoStartupBuilders.PotionBuilder;
    potion(id: string, typeName: "basic", build: (build: NekoStartupBuilders.PotionBuilder) => void): NekoStartupBuilders.PotionBuilder;
    soundEvent(id: string, build: (build: NekoStartupBuilders.SoundEventBuilder) => void): NekoStartupBuilders.SoundEventBuilder;
    soundEvent(id: string, typeName: "basic", build: (build: NekoStartupBuilders.SoundEventBuilder) => void): NekoStartupBuilders.SoundEventBuilder;
    villagerType(id: string, build: (build: NekoStartupBuilders.VillagerTypeBuilder) => void): NekoStartupBuilders.VillagerTypeBuilder;
    villagerType(id: string, typeName: "basic", build: (build: NekoStartupBuilders.VillagerTypeBuilder) => void): NekoStartupBuilders.VillagerTypeBuilder;
    custom(id: string, typeName: string, build: (build: any) => void): any;
    register(registry: string, id: string, supplier: () => unknown): unknown;
}

declare module "@side-only/startup/events" {
}

export {};

declare global {
    namespace RegistryEvents {
        function register(handler: ((event: StartupRegistryEvent) => void)): void;
    }

}
