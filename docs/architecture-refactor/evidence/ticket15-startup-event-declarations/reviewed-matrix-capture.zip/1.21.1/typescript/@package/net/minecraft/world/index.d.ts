export * as flag from "java:net/minecraft/world/flag";
export * as level from "java:net/minecraft/world/level";

