export * as codec from "java:net/minecraft/network/codec";

