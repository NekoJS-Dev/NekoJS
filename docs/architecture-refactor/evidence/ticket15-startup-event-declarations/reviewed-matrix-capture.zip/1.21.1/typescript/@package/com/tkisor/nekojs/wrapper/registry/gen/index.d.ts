import { $Value } from "java:graal/graalvm/polyglot";
import { $ProxyObject } from "java:graal/graalvm/polyglot/proxy";
import { $Record, $String } from "java:java/lang";
import { $List, $Map } from "java:java/util";
import { $Supplier } from "java:java/util/function";
import { $ResourceKey, $ResourceLocation } from "java:net/minecraft/resources";

declare module "java:com/tkisor/nekojs/wrapper/registry/gen" {
    export class $RegistryEventJS implements $ProxyObject {
        get memberKeys(): object;
        getMemberKeys(): object;
        static create(repository: $RegistryRepository, node: string): $RegistryEventJS;
        getMember(name: string): object;
        hasMember(name: string): boolean;
        putMember(name: string, value: $Value): void;
        removeMember(name: string): boolean;
    }

    export class $RegistryObjectBuilder<T> implements $Supplier {
        id: $ResourceLocation;
        build(): T;
        get(): T;
        handleAdditionalObjects(registry: $RegistryObjectBuilder$AdditionalObjectRegistry): void;
    }

    export interface $RegistryObjectBuilder$AdditionalObjectRegistry {
        additional(registry: $ResourceKey<$Registry<any>>, id: $ResourceLocation, supplier: $Supplier<any>): void;
    }

    export class $RegistryRepository {
        constructor();
        get empty(): boolean;
        isEmpty(): boolean;
        addAdditional(registry: $ResourceKey<$Registry<any>>, id: $ResourceLocation, supplier: $Supplier<any>, source: $ResourceLocation): void;
        add(registry: $ResourceKey<$Registry<any>>, builder: $RegistryObjectBuilder<any>, typeName: string, origin: string): void;
        add(registry: $ResourceKey<$Registry<any>>, builder: $RegistryObjectBuilder<any>): void;
        drainAdditional(registry: $ResourceKey<$Registry<any>>): $List<$RegistryRepository$Additional>;
        drain(registry: $ResourceKey<$Registry<any>>): $List<$RegistryRepository$Entry>;
        undeliveredAdditional(): $Map<$ResourceKey<$Registry<any>>, $List<$RegistryRepository$Additional>>;
        undrained(): $Map<$ResourceKey<$Registry<any>>, $List<$RegistryRepository$Entry>>;
    }

    export class $RegistryRepository$Additional extends $Record {
        constructor(registry: $ResourceKey<$Registry<any>>, id: $ResourceLocation, supplier: $Supplier<any>, source: $ResourceLocation);
        equals(o: object): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        registry(): $ResourceKey<$Registry<any>>;
        source(): $ResourceLocation;
        supplier(): $Supplier<any>;
        toString(): string;
    }

    export class $RegistryRepository$Entry extends $Record {
        constructor(builder: $RegistryObjectBuilder<any>, typeName: string, origin: string);
        builder(): $RegistryObjectBuilder<any>;
        equals(o: object): boolean;
        hashCode(): number;
        origin(): string;
        toString(): string;
        typeName(): string;
    }

}
