export * as core from "java:net/minecraft/core";
export * as network from "java:net/minecraft/network";
export * as resources from "java:net/minecraft/resources";
export * as server from "java:net/minecraft/server";
export * as tags from "java:net/minecraft/tags";
export * as util from "java:net/minecraft/util";
export * as world from "java:net/minecraft/world";

