export * as wrapper from "java:com/tkisor/nekojs/wrapper";

