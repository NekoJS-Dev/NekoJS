export * as registry from "java:com/tkisor/nekojs/wrapper/registry";

