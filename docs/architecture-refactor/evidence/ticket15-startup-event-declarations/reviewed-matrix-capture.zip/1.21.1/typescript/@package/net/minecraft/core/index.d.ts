import { $Either, $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DynamicOps, $Keyable, $Lifecycle } from "java:com/mojang/serialization";
import { $Enum, $Iterable, $Record, $Runnable, $String } from "java:java/lang";
import { $Iterator, $List, $Map, $Map$Entry, $Optional, $Set, $Spliterator } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $ResourceKey, $ResourceLocation } from "java:net/minecraft/resources";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $TagKey } from "java:net/minecraft/tags";
import { $RandomSource } from "java:net/minecraft/util";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $IHolderExtension } from "java:net/neoforged/neoforge/common/extensions";
import { $IRegistryExtension } from "java:net/neoforged/neoforge/registries";
import { $DataMapType } from "java:net/neoforged/neoforge/registries/datamaps";

declare module "java:net/minecraft/core" {
    export interface $Holder<T> extends $IHolderExtension {
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        direct<T>(arg0: T): $Holder<T>;
        getRegisteredName(): string;
        isBound(): boolean;
        is(arg0: $Predicate<$ResourceKey<T>>): boolean;
        is(arg0: $Holder<T>): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $ResourceLocation): boolean;
        is(arg0: $TagKey<T>): boolean;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export class $Holder$Kind {
        static DIRECT: $Holder$Kind;
        static REFERENCE: $Holder$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Holder$Kind[];
        static valueOf(name: string): $Holder$Kind;
    }

    export class $Holder$Reference<T> implements $Holder {
        get key(): $ResourceKey<T>;
        getKey(): $ResourceKey<T>;
        get bound(): boolean;
        isBound(): boolean;
        static createIntrusive<T>(arg0: $HolderOwner<T>, arg1: T): $Holder$Reference<T>;
        static createStandAlone<T>(arg0: $HolderOwner<T>, arg1: $ResourceKey<T>): $Holder$Reference<T>;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        equals(arg0: object): boolean;
        getData<A>(arg0: $DataMapType<T, A>): A;
        hashCode(): number;
        is(arg0: $Predicate<$ResourceKey<T>>): boolean;
        is(arg0: $Holder<T>): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $ResourceLocation): boolean;
        is(arg0: $TagKey<T>): boolean;
        key(): $ResourceKey<T>;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        toString(): string;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrapLookup(): $HolderLookup$RegistryLookup<T>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export interface $HolderLookup<T> extends $HolderGetter {
        listElementIds(): $Stream<$ResourceKey<T>>;
        listElements(): $Stream<$Holder$Reference<T>>;
        listTagIds(): $Stream<$TagKey<T>>;
        listTags(): $Stream<$HolderSet$Named<T>>;
    }

    export interface $HolderLookup$RegistryLookup<T> extends $HolderLookup, $HolderOwner {
        filterElements(arg0: $Predicate<T>): $HolderLookup$RegistryLookup<T>;
        filterFeatures(arg0: $FeatureFlagSet): $HolderLookup$RegistryLookup<T>;
        getData<A>(arg0: $DataMapType<T, A>, arg1: $ResourceKey<T>): A;
        key(): $ResourceKey<$Registry<T>>;
        registryLifecycle(): $Lifecycle;
    }

    export interface $HolderOwner<T> {
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
    }

    export class $HolderSet$ListBacked<T> implements $HolderSet {
        constructor();
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        getRandomElement(arg0: $RandomSource): $Optional<$Holder<T>>;
        get(arg0: number): $Holder<T>;
        iterator(): $Iterator<$Holder<T>>;
        size(): number;
        spliterator(): $Spliterator<$Holder<T>>;
        stream(): $Stream<$Holder<T>>;
    }

    export class $HolderSet$Named<T> extends $HolderSet$ListBacked {
        addInvalidationListener(arg0: $Runnable): void;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        contains(arg0: $Holder<T>): boolean;
        key(): $TagKey<T>;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export interface $IdMap<T> extends $Iterable {
        byIdOrThrow(arg0: number): T;
        byId(arg0: number): T;
        getIdOrThrow(arg0: T): number;
        getId(arg0: T): number;
        size(): number;
        static DEFAULT: number;
    }

    export class $RegistrationInfo extends $Record {
        constructor(knownPackInfo: $Optional<$KnownPack>, lifecycle: $Lifecycle);
        static BUILT_IN: $RegistrationInfo;
        equals(arg0: object): boolean;
        hashCode(): number;
        knownPackInfo(): $Optional<$KnownPack>;
        lifecycle(): $Lifecycle;
        toString(): string;
    }

    export interface $Registry<T> extends $Keyable, $IdMap, $IRegistryExtension {
        asHolderIdMap(): $IdMap<$Holder<T>>;
        asLookup(): $HolderLookup$RegistryLookup<T>;
        asTagAddingLookup(): $HolderLookup$RegistryLookup<T>;
        bindTags(arg0: { [key: $TagKey<T>]: $Holder<T>[] }): void;
        byNameCodec(): $Codec<T>;
        containsKey(arg0: $ResourceKey<T>): boolean;
        containsKey(arg0: $ResourceLocation): boolean;
        createIntrusiveHolder(arg0: T): $Holder$Reference<T>;
        entrySet(): $Set<$Map$Entry<$ResourceKey<T>, T>>;
        freeze(): $Registry<T>;
        getAny(): $Optional<$Holder$Reference<T>>;
        getHolderOrThrow(arg0: $ResourceKey<T>): $Holder$Reference<T>;
        getHolder(arg0: number): $Optional<$Holder$Reference<T>>;
        getHolder(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        getHolder(arg0: $ResourceLocation): $Optional<$Holder$Reference<T>>;
        getId(arg0: T): number;
        getKey(arg0: T): $ResourceLocation;
        getOptional(arg0: $ResourceKey<T>): $Optional<T>;
        getOptional(arg0: $ResourceLocation): $Optional<T>;
        getOrCreateTag(arg0: $TagKey<T>): $HolderSet$Named<T>;
        getOrThrow(arg0: $ResourceKey<T>): T;
        getRandomElementOf(arg0: $TagKey<T>, arg1: $RandomSource): $Optional<$Holder<T>>;
        getRandom(arg0: $RandomSource): $Optional<$Holder$Reference<T>>;
        getResourceKey(arg0: T): $Optional<$ResourceKey<T>>;
        getTagNames(): $Stream<$TagKey<T>>;
        getTagOrEmpty(arg0: $TagKey<T>): $Iterable<$Holder<T>>;
        getTags(): $Stream<$Pair<$TagKey<T>, $HolderSet$Named<T>>>;
        getTag(arg0: $TagKey<T>): $Optional<$HolderSet$Named<T>>;
        get(arg0: $ResourceKey<T>): T;
        get(arg0: $ResourceLocation): T;
        holderByNameCodec(): $Codec<$Holder<T>>;
        holderOwner(): $HolderOwner<T>;
        holders(): $Stream<$Holder$Reference<T>>;
        keySet(): $Set<$ResourceLocation>;
        keys<U>(arg0: $DynamicOps<U>): $Stream<U>;
        key(): $ResourceKey<$Registry<T>>;
        registerForHolder<T>(arg0: $Registry<T>, arg1: $ResourceKey<T>, arg2: T): $Holder$Reference<T>;
        registerForHolder<T>(arg0: $Registry<T>, arg1: $ResourceLocation, arg2: T): $Holder$Reference<T>;
        register<T>(arg0: $Registry<any>, arg1: string, arg2: T): T;
        register<V, T>(arg0: $Registry<V>, arg1: $ResourceKey<V>, arg2: T): T;
        register<V, T>(arg0: $Registry<V>, arg1: $ResourceLocation, arg2: T): T;
        registrationInfo(arg0: $ResourceKey<T>): $Optional<$RegistrationInfo>;
        registryKeySet(): $Set<$ResourceKey<T>>;
        registryLifecycle(): $Lifecycle;
        resetTags(): void;
        stream(): $Stream<T>;
        wrapAsHolder(arg0: T): $Holder<T>;
    }

    export type $Holder$Kind_ = $Holder$Kind | "DIRECT" | "REFERENCE";
}
