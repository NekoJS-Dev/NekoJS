import { $StringReader } from "java:com/mojang/brigadier";
import { $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Comparable, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $UnaryOperator } from "java:java/util/function";
import { $Registry } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/resources" {
    export class $ResourceKey<T> implements $Comparable {
        static codec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$ResourceKey<T>>;
        static createRegistryKey<T>(arg0: $ResourceLocation): $ResourceKey<$Registry<T>>;
        static create<T>(arg0: $ResourceKey<$Registry<T>>, arg1: $ResourceLocation): $ResourceKey<T>;
        static streamCodec<T>(arg0: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $ResourceKey<T>>;
        cast<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$ResourceKey<E>>;
        compareTo(arg0: $ResourceKey<any>): number;
        isFor(arg0: $ResourceKey<$Registry<any>>): boolean;
        location(): $ResourceLocation;
        registryKey(): $ResourceKey<$Registry<T>>;
        registry(): $ResourceLocation;
        toString(): string;
    }

    export class $ResourceLocation implements $Comparable {
        static CODEC: $Codec<$ResourceLocation>;
        static DEFAULT_NAMESPACE: string;
        static ERROR_INVALID: $SimpleCommandExceptionType;
        static NAMESPACE_SEPARATOR: string;
        static REALMS_NAMESPACE: string;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ResourceLocation>;
        get namespace(): string;
        getNamespace(): string;
        get path(): string;
        getPath(): string;
        static bySeparator(arg0: string, arg1: string): $ResourceLocation;
        static fromNamespaceAndPath(arg0: string, arg1: string): $ResourceLocation;
        static isAllowedInResourceLocation(arg0: string): boolean;
        static isValidNamespace(arg0: string): boolean;
        static isValidPath(arg0: string): boolean;
        static parse(arg0: string): $ResourceLocation;
        static readNonEmpty(arg0: $StringReader): $ResourceLocation;
        static read(arg0: $StringReader): $ResourceLocation;
        static read(arg0: string): $DataResult<$ResourceLocation>;
        static tryBuild(arg0: string, arg1: string): $ResourceLocation;
        static tryBySeparator(arg0: string, arg1: string): $ResourceLocation;
        static tryParse(arg0: string): $ResourceLocation;
        static validNamespaceChar(arg0: string): boolean;
        static validPathChar(arg0: string): boolean;
        static withDefaultNamespace(arg0: string): $ResourceLocation;
        compareNamespaced(arg0: $ResourceLocation): number;
        compareTo(arg0: $ResourceLocation): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toDebugFileName(): string;
        toLanguageKey(arg0: string, arg1: string): string;
        toLanguageKey(arg0: string): string;
        toLanguageKey(): string;
        toShortLanguageKey(): string;
        toString(): string;
        withPath(arg0: string): $ResourceLocation;
        withPath(arg0: $UnaryOperator<string>): $ResourceLocation;
        withPrefix(arg0: string): $ResourceLocation;
        withSuffix(arg0: string): $ResourceLocation;
    }

}
