import { $Function3, $Function4, $Function5, $Function6 } from "java:com/mojang/datafixers/util";
import { $BiFunction, $Function, $UnaryOperator } from "java:java/util/function";

declare module "java:net/minecraft/network/codec" {
    export interface $StreamCodec<B, V> extends $StreamDecoder, $StreamEncoder {
        apply<O>(arg0: $StreamCodec$CodecOperation<B, V, O>): $StreamCodec<B, O>;
        cast<S>(): $StreamCodec<S, V>;
        composite<B, C, T1>(arg0: $StreamCodec<any, T1>, arg1: $Function<C, T1>, arg2: $Function<T1, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2>(arg0: $StreamCodec<any, T1>, arg1: $Function<C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function<C, T2>, arg4: $BiFunction<T1, T2, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3>(arg0: $StreamCodec<any, T1>, arg1: $Function<C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function<C, T2>, arg4: $StreamCodec<any, T3>, arg5: $Function<C, T3>, arg6: $Function3<T1, T2, T3, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4>(arg0: $StreamCodec<any, T1>, arg1: $Function<C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function<C, T2>, arg4: $StreamCodec<any, T3>, arg5: $Function<C, T3>, arg6: $StreamCodec<any, T4>, arg7: $Function<C, T4>, arg8: $Function4<T1, T2, T3, T4, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5>(arg0: $StreamCodec<any, T1>, arg1: $Function<C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function<C, T2>, arg4: $StreamCodec<any, T3>, arg5: $Function<C, T3>, arg6: $StreamCodec<any, T4>, arg7: $Function<C, T4>, arg8: $StreamCodec<any, T5>, arg9: $Function<C, T5>, arg10: $Function5<T1, T2, T3, T4, T5, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6>(arg0: $StreamCodec<any, T1>, arg1: $Function<C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function<C, T2>, arg4: $StreamCodec<any, T3>, arg5: $Function<C, T3>, arg6: $StreamCodec<any, T4>, arg7: $Function<C, T4>, arg8: $StreamCodec<any, T5>, arg9: $Function<C, T5>, arg10: $StreamCodec<any, T6>, arg11: $Function<C, T6>, arg12: $Function6<T1, T2, T3, T4, T5, T6, C>): $StreamCodec<B, C>;
        dispatch<U>(arg0: $Function<any, V>, arg1: $Function<any, $StreamCodec<any, U>>): $StreamCodec<B, U>;
        mapStream<O>(arg0: $Function<O, B>): $StreamCodec<O, V>;
        map<O>(arg0: $Function<any, O>, arg1: $Function<any, V>): $StreamCodec<B, O>;
        ofMember<B, V>(arg0: $StreamMemberEncoder<B, V>, arg1: $StreamDecoder<B, V>): $StreamCodec<B, V>;
        of<B, V>(arg0: $StreamEncoder<B, V>, arg1: $StreamDecoder<B, V>): $StreamCodec<B, V>;
        recursive<B, T>(arg0: $UnaryOperator<$StreamCodec<B, T>>): $StreamCodec<B, T>;
        unit<B, V>(arg0: V): $StreamCodec<B, V>;
    }

    export interface $StreamCodec$CodecOperation<B, S, T> {
        apply(arg0: $StreamCodec<B, S>): $StreamCodec<B, T>;
    }

    export interface $StreamDecoder<I, T> {
        decode(arg0: I): T;
    }

    export interface $StreamEncoder<O, T> {
        encode(arg0: O, arg1: T): void;
    }

    export interface $StreamMemberEncoder<O, T> {
        encode(arg0: T, arg1: O): void;
    }

}
