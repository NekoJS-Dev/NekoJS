import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $ResourceKey, $ResourceLocation } from "java:net/minecraft/resources";

declare module "java:net/minecraft/tags" {
    export class $TagKey<T> extends $Record {
        constructor(registry: $ResourceKey<$Registry<T>>, location: $ResourceLocation);
        static codec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static create<T>(arg0: $ResourceKey<$Registry<T>>, arg1: $ResourceLocation): $TagKey<T>;
        static hashedCodec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        cast<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$TagKey<E>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        isFor(arg0: $ResourceKey<$Registry<any>>): boolean;
        location(): $ResourceLocation;
        registry(): $ResourceKey<$Registry<T>>;
        toString(): string;
    }

}
