declare module "java:net/minecraft/world/flag" {
    export class $FeatureFlagSet {
        static MAX_CONTAINER_SIZE: number;
        get empty(): boolean;
        isEmpty(): boolean;
        static of(arg0: $FeatureFlag, arg1?: $FeatureFlag[]): $FeatureFlagSet;
        static of(arg0: $FeatureFlag): $FeatureFlagSet;
        static of(): $FeatureFlagSet;
        contains(arg0: $FeatureFlag): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        intersects(arg0: $FeatureFlagSet): boolean;
        isSubsetOf(arg0: $FeatureFlagSet): boolean;
        join(arg0: $FeatureFlagSet): $FeatureFlagSet;
        subtract(arg0: $FeatureFlagSet): $FeatureFlagSet;
    }

}
