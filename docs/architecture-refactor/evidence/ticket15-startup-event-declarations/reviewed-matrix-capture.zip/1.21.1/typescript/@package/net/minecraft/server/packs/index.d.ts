export * as repository from "java:net/minecraft/server/packs/repository";

