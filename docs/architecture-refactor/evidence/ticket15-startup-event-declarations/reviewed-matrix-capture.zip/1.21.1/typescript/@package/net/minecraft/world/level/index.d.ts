export * as levelgen from "java:net/minecraft/world/level/levelgen";

