export * as packs from "java:net/minecraft/server/packs";

