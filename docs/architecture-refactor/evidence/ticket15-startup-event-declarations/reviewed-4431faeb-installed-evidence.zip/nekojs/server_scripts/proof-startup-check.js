const startupChecks = [
    ['minecraft:sound_event', 'nullable', true], ['minecraft:sound_event', 'named', true],
    ['minecraft:item', 'token', true], ['minecraft:block', 'stone', true],
    ['minecraft:item', 'stone', true], ['minecraft:block', 'no_item', true],
    ['minecraft:item', 'no_item', false], ['minecraft:fluid', 'spring', true],
    ['minecraft:fluid', 'flowing_spring', true], ['minecraft:block', 'spring', true],
    ['minecraft:item', 'spring_bucket', true], ['minecraft:fluid', 'bare', true],
    ['minecraft:block', 'bare', false], ['minecraft:item', 'bare_bucket', false]
];
for (const check of startupChecks) {
    const actual = Registry.get(check[0]).has('ticket15_startup:' + check[1]);
    if (actual !== check[2]) throw new Error('STARTUP registration mismatch: ' + check[0] + '/' + check[1]);
}
console.info('STARTUP-INSTALLED-REGISTRATIONS-PASS checks=' + startupChecks.length);
