import { $String } from "java:java/lang";
import { $Consumer, $Supplier } from "java:java/util/function";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";

declare module "java:com/tkisor/nekojs/wrapper/pdata" {
    export class $PersistentDataJS {
        constructor(getter: $Supplier<$CompoundTag_>, saver: $Consumer<$CompoundTag_>);
        constructor(getter: $Supplier<$CompoundTag_>, saver: $Consumer<$CompoundTag_>, dirtyMarker: $Runnable, syncer: $Runnable);
        static readOnly(getter: $Supplier<$CompoundTag_>): $PersistentDataJS;
        clear(): $PersistentDataJS;
        contains(key: string): boolean;
        copyTag(): $CompoundTag;
        edit(editor: $Consumer<$CompoundTag_>): $PersistentDataJS;
        getBoolean(key: string): boolean;
        getByteArray(key: string): number[];
        getByte(key: string): number;
        getCompound(key: string): $CompoundTag;
        getDouble(key: string): number;
        getFloat(key: string): number;
        getIntArray(key: string): number[];
        getInt(key: string): number;
        getLongArray(key: string): number[];
        getLong(key: string): number;
        getShort(key: string): number;
        getString(key: string): string;
        get(key: string): object;
        markDirty(): $PersistentDataJS;
        merge(other: $CompoundTag_): $PersistentDataJS;
        putBoolean(key: string, value: boolean): $PersistentDataJS;
        putByteArray(key: string, value: number[]): $PersistentDataJS;
        putByte(key: string, value: number): $PersistentDataJS;
        putCompound(key: string, value: $CompoundTag_): $PersistentDataJS;
        putDouble(key: string, value: number): $PersistentDataJS;
        putFloat(key: string, value: number): $PersistentDataJS;
        putIntArray(key: string, value: number[]): $PersistentDataJS;
        putInt(key: string, value: number): $PersistentDataJS;
        putLongArray(key: string, value: number[]): $PersistentDataJS;
        putLong(key: string, value: number): $PersistentDataJS;
        putShort(key: string, value: number): $PersistentDataJS;
        putString(key: string, value: string): $PersistentDataJS;
        remove(key: string): $PersistentDataJS;
        replaceTag(tag: $CompoundTag_): $PersistentDataJS;
        sync(): $PersistentDataJS;
    }

}
