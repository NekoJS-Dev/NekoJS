import { $JsonElement } from "java:com/google/gson";
import { $DataFixer } from "java:com/mojang/datafixers";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Iterable, $Record, $String } from "java:java/lang";
import { $DecimalFormat } from "java:java/text";
import { $Collection, $Iterator, $List } from "java:java/util";
import { $Consumer, $Predicate } from "java:java/util/function";
import { $Registry } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $RecipeBookType, $RecipeBookType_ } from "java:net/minecraft/world/inventory";
import { $Recipe, $RecipeHolder } from "java:net/minecraft/world/item/crafting";
import { $RecipeDisplayEntry } from "java:net/minecraft/world/item/crafting/display";
import { $ObjectiveCriteria } from "java:net/minecraft/world/scores/criteria";

declare module "java:net/minecraft/stats" {
    export class $RecipeBook {
        constructor();
        get bookSettings(): $RecipeBookSettings;
        getBookSettings(): $RecipeBookSettings;
        set bookSettings(value: $RecipeBookSettings);
        isFiltering(arg0: $RecipeBookType_): boolean;
        isOpen(arg0: $RecipeBookType_): boolean;
        setBookSetting(arg0: $RecipeBookType_, arg1: boolean, arg2: boolean): void;
        setFiltering(arg0: $RecipeBookType_, arg1: boolean): void;
        setOpen(arg0: $RecipeBookType_, arg1: boolean): void;
    }

    export class $RecipeBookSettings {
        constructor();
        static MAP_CODEC: $MapCodec<$RecipeBookSettings>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $RecipeBookSettings>;
        copy(): $RecipeBookSettings;
        getSettings(arg0: $RecipeBookType_): $RecipeBookSettings$TypeSettings;
        isFiltering(arg0: $RecipeBookType_): boolean;
        isOpen(arg0: $RecipeBookType_): boolean;
        replaceFrom(arg0: $RecipeBookSettings): void;
        setFiltering(arg0: $RecipeBookType_, arg1: boolean): void;
        setOpen(arg0: $RecipeBookType_, arg1: boolean): void;
    }

    export class $RecipeBookSettings$TypeSettings extends $Record {
        constructor(open: boolean, filtering: boolean);
        static BLAST_FURNACE_MAP_CODEC: $MapCodec<$RecipeBookSettings$TypeSettings>;
        static CRAFTING_MAP_CODEC: $MapCodec<$RecipeBookSettings$TypeSettings>;
        static DEFAULT: $RecipeBookSettings$TypeSettings;
        static FURNACE_MAP_CODEC: $MapCodec<$RecipeBookSettings$TypeSettings>;
        static SMOKER_MAP_CODEC: $MapCodec<$RecipeBookSettings$TypeSettings>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $RecipeBookSettings$TypeSettings>;
        static codec(arg0: string, arg1: string): $MapCodec<$RecipeBookSettings$TypeSettings>;
        equals(arg0: object): boolean;
        filtering(): boolean;
        hashCode(): number;
        open(): boolean;
        toString(): string;
    }

    export class $ServerRecipeBook extends $RecipeBook {
        constructor(arg0: $ServerRecipeBook$DisplayResolver);
        static RECIPE_BOOK_TAG: string;
        addRecipes(arg0: $RecipeHolder<any>[], arg1: $ServerPlayer): number;
        add(arg0: $ResourceKey<$Recipe<any>>): void;
        contains(arg0: $ResourceKey<$Recipe<any>>): boolean;
        copyOverData(arg0: $ServerRecipeBook): void;
        loadUntrusted(arg0: $ServerRecipeBook$Packed, arg1: $Predicate<$ResourceKey<$Recipe<any>>>): void;
        pack(): $ServerRecipeBook$Packed;
        removeHighlight(arg0: $ResourceKey<$Recipe<any>>): void;
        removeRecipes(arg0: $RecipeHolder<any>[], arg1: $ServerPlayer): number;
        remove(arg0: $ResourceKey<$Recipe<any>>): void;
        sendInitialRecipeBook(arg0: $ServerPlayer): void;
    }

    export interface $ServerRecipeBook$DisplayResolver {
        displaysForRecipe(arg0: $ResourceKey<$Recipe<any>>, arg1: $Consumer<$RecipeDisplayEntry>): void;
    }

    export class $ServerRecipeBook$Packed extends $Record {
        constructor(settings: $RecipeBookSettings, known: $ResourceKey<$Recipe<any>>[], highlight: $ResourceKey<$Recipe<any>>[]);
        static CODEC: $Codec<$ServerRecipeBook$Packed>;
        equals(arg0: object): boolean;
        hashCode(): number;
        highlight(): $List<$ResourceKey<$Recipe<any>>>;
        known(): $List<$ResourceKey<$Recipe<any>>>;
        settings(): $RecipeBookSettings;
        toString(): string;
    }

    export class $ServerStatsCounter extends $StatsCounter {
        constructor(arg0: $MinecraftServer, arg1: string);
        markAllDirty(): void;
        parse(arg0: $DataFixer, arg1: $JsonElement): void;
        save(): void;
        sendStats(arg0: $ServerPlayer): void;
        setValue(arg0: $Player, arg1: $Stat<any>, arg2: number): void;
    }

    export class $Stat<T> extends $ObjectiveCriteria {
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Stat<any>>;
        get type(): $StatType<T>;
        getType(): $StatType<T>;
        get value(): T;
        getValue(): T;
        static buildName<T>(arg0: $StatType<T>, arg1: T): string;
        equals(arg0: object): boolean;
        format(arg0: number): string;
        hashCode(): number;
        toString(): string;
    }

    export interface $StatFormatter {
        format(arg0: number): string;
        static DECIMAL_FORMAT: $DecimalFormat;
        static DEFAULT: $StatFormatter;
        static DISTANCE: $StatFormatter;
        static DIVIDE_BY_TEN: $StatFormatter;
        static TIME: $StatFormatter;
    }

    export class $StatType<T> implements $Iterable {
        constructor(arg0: $Registry<T>, arg1: $Component_);
        get displayName(): $Component;
        getDisplayName(): $Component;
        get registry(): $Registry<T>;
        getRegistry(): $Registry<T>;
        contains(arg0: T): boolean;
        get(arg0: T, arg1: $StatFormatter): $Stat<T>;
        get(arg0: T): $Stat<T>;
        iterator(): $Iterator<$Stat<T>>;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, $Stat<T>>;
    }

    export class $StatsCounter {
        constructor();
        getValue(arg0: $Stat<any>): number;
        getValue<T>(arg0: $StatType<T>, arg1: T): number;
        increment(arg0: $Player, arg1: $Stat<any>, arg2: number): void;
        setValue(arg0: $Player, arg1: $Stat<any>, arg2: number): void;
    }

}
