import { $Optional } from "java:java/util";

declare module "java:com/mojang/datafixers/functions" {
    export interface $PointFreeRule {
        all(arg0: $PointFreeRule): $PointFreeRule;
        choice(arg0?: $PointFreeRule[]): $PointFreeRule;
        everywhere(arg0: $PointFreeRule, arg1: $PointFreeRule): $PointFreeRule;
        many(arg0: $PointFreeRule): $PointFreeRule;
        nop(): $PointFreeRule;
        once(arg0: $PointFreeRule): $PointFreeRule;
        one(arg0: $PointFreeRule): $PointFreeRule;
        rewriteOrNop<A>(arg0: $PointFree<A>): $PointFree<A>;
        rewrite<A>(arg0: $PointFree<A>): $Optional<$PointFree<A>>;
        seq(arg0?: $PointFreeRule[]): $PointFreeRule;
    }

}
