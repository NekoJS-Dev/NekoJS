import { $String } from "java:java/lang";
import { $BiFunction, $Supplier } from "java:java/util/function";
import { $Direction, $Direction_ } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockCapability, $EntityCapability, $IBlockCapabilityProvider, $ItemCapability, $RegisterCapabilitiesEvent } from "java:net/neoforged/neoforge/capabilities";

declare module "java:com/tkisor/nekojs/wrapper/event/registry" {
    export class $CapabilityRegistryEventJS {
        constructor();
        apply(event: $RegisterCapabilitiesEvent): void;
        registerBlockEntityContext(typeId: string, capability: string, provider: $BiFunction<$BlockEntity, $Direction_, any>): void;
        registerBlockEntityNative<T, C>(typeId: string, capability: $BlockCapability<T, C>, provider: $BiFunction<$BlockEntity, C, T>): void;
        registerBlockEntity(typeId: string, capability: string, provider: $Supplier<any>): void;
        registerBlockNative<T, C>(blockId: string, capability: $BlockCapability<T, C>, provider: $IBlockCapabilityProvider<T, C>): void;
        registerBlock(blockId: string, capability: string, provider: $IBlockCapabilityProvider<any, object>): void;
        registerEntityNative<T, C>(typeId: string, capability: $EntityCapability<T, C>, provider: $BiFunction<$Entity, C, T>): void;
        registerEntity(typeId: string, capability: string, provider: $BiFunction<$Entity, object, any>): void;
        registerItemNative<T, C>(itemId: string, capability: $ItemCapability<T, C>, provider: $BiFunction<$ItemStack_, C, T>): void;
        registerItem(itemId: string, capability: string, provider: $BiFunction<$ItemStack_, object, any>): void;
    }

}
