import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";

declare module "java:net/minecraft/advancements/triggers" {
    export class $Criterion<T extends $CriterionTriggerInstance> extends $Record {
        constructor(trigger: $CriterionTrigger<T>, triggerInstance: T);
        static CODEC: $Codec<$Criterion<any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        triggerInstance(): T;
        trigger(): $CriterionTrigger<T>;
    }

    export interface $CriterionTrigger<T extends $CriterionTriggerInstance> {
        codec(): $Codec<T>;
        createCriterion(arg0: T): $Criterion<T>;
    }

}
