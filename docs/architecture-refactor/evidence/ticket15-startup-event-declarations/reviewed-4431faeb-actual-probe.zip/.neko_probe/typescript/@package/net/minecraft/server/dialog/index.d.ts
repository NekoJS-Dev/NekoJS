import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Integer, $Record, $String } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $IntFunction } from "java:java/util/function";
import { $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Action } from "java:net/minecraft/server/dialog/action";
import { $DialogBody } from "java:net/minecraft/server/dialog/body";
import { $InputControl } from "java:net/minecraft/server/dialog/input";
import { $StringRepresentable } from "java:net/minecraft/util";

export * as action from "java:net/minecraft/server/dialog/action";
export * as body from "java:net/minecraft/server/dialog/body";
export * as input from "java:net/minecraft/server/dialog/input";

declare module "java:net/minecraft/server/dialog" {
    export class $CommonDialogData extends $Record {
        constructor(title: $Component_, externalTitle: $Optional<$Component_>, canCloseWithEscape: boolean, pause: boolean, afterAction: $DialogAction_, body: $DialogBody[], inputs: $Input[]);
        static MAP_CODEC: $MapCodec<$CommonDialogData>;
        afterAction(): $DialogAction;
        body(): $List<$DialogBody>;
        canCloseWithEscape(): boolean;
        computeExternalTitle(): $Component;
        equals(arg0: object): boolean;
        externalTitle(): $Optional<$Component>;
        hashCode(): number;
        inputs(): $List<$Input>;
        pause(): boolean;
        title(): $Component;
        toString(): string;
    }

    export interface $Dialog {
        codec(): $MapCodec<$Dialog>;
        common(): $CommonDialogData;
        onCancel(): $Optional<$Action>;
        static CODEC: $Codec<$Holder<$Dialog>>;
        static CONTEXT_FREE_STREAM_CODEC: $StreamCodec<$ByteBuf, $Dialog>;
        static DIRECT_CODEC: $Codec<$Dialog>;
        static LIST_CODEC: $Codec<$HolderSet<$Dialog>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$Dialog>>;
        static WIDTH_CODEC: $Codec<number>;
    }

    export class $DialogAction {
        static CLOSE: $DialogAction;
        static NONE: $DialogAction;
        static WAIT_FOR_RESPONSE: $DialogAction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DialogAction[];
        static valueOf(name: string): $DialogAction;
    }

    export class $Input extends $Record {
        constructor(key: string, control: $InputControl);
        static CODEC: $Codec<$Input>;
        control(): $InputControl;
        equals(arg0: object): boolean;
        hashCode(): number;
        key(): string;
        toString(): string;
    }

    export type $DialogAction_ = $DialogAction | "CLOSE" | "NONE" | "WAIT_FOR_RESPONSE";
}
