import { $App, $Applicative, $K1 } from "java:com/mojang/datafixers/kinds";
import { $Function3, $Function4, $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult, $DynamicOps, $Lifecycle, $MapCodec, $MapEncoder, $MapLike, $RecordBuilder } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Map } from "java:java/util";
import { $BiFunction, $Function } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";

declare module "java:com/mojang/serialization/codecs" {
    export interface $BaseMapCodec<K, V> {
        decode<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>): $DataResult<$Map<K, V>>;
        elementCodec(): $Codec<V>;
        encode<T>(arg0: { [key: K]: V }, arg1: $DynamicOps<T>, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
        keyCodec(): $Codec<K>;
    }

    export interface $PrimitiveCodec<A> extends $Codec {
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<A, T>>;
        encode<T>(arg0: A, arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
        read<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<A>;
        write<T>(arg0: $DynamicOps<T>, arg1: A): T;
    }

    export class $RecordCodecBuilder<O, F> implements $App {
        static build<O>(arg0: $App<$RecordCodecBuilder$Mu<O>, O>): $MapCodec<O>;
        static create<O>(arg0: $Function<$RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>>): $Codec<O>;
        static deprecated<O, F>(arg0: F, arg1: number): $RecordCodecBuilder<O, F>;
        static instance<O>(): $RecordCodecBuilder$Instance<O>;
        static mapCodec<O>(arg0: $Function<$RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>>): $MapCodec<O>;
        static of<O, F>(arg0: $Function<O, F>, arg1: $MapCodec<F>): $RecordCodecBuilder<O, F>;
        static of<O, F>(arg0: $Function<O, F>, arg1: string, arg2: $Codec<F>): $RecordCodecBuilder<O, F>;
        static point<O, F>(arg0: F, arg1: $Lifecycle): $RecordCodecBuilder<O, F>;
        static point<O, F>(arg0: F): $RecordCodecBuilder<O, F>;
        static stable<O, F>(arg0: F): $RecordCodecBuilder<O, F>;
        static unbox<O, F>(arg0: $App<$RecordCodecBuilder$Mu<O>, F>): $RecordCodecBuilder<O, F>;
        dependent<E>(arg0: $Function<O, E>, arg1: $MapEncoder<E>, arg2: $Function<any, $MapDecoder<E>>): $RecordCodecBuilder<O, E>;
    }

    export class $RecordCodecBuilder$Instance<O> implements $Applicative {
        constructor();
        ap2<A, B, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $BiFunction<A, B, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, A>, arg2: $App<$RecordCodecBuilder$Mu<O>, B>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap3<T1, T2, T3, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function3<T1, T2, T3, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap4<T1, T2, T3, T4, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function4<T1, T2, T3, T4, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>): $App<$RecordCodecBuilder$Mu<O>, R>;
        deprecated<A>(arg0: A, arg1: number): $App<$RecordCodecBuilder$Mu<O>, A>;
        lift1<A, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function<A, R>>): $Function<$App<$RecordCodecBuilder$Mu<O>, A>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        map<T, R>(arg0: $Function<any, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T>): $App<$RecordCodecBuilder$Mu<O>, R>;
        point<A>(arg0: A, arg1: $Lifecycle): $App<$RecordCodecBuilder$Mu<O>, A>;
        point<A>(arg0: A): $App<$RecordCodecBuilder$Mu<O>, A>;
        stable<A>(arg0: A): $App<$RecordCodecBuilder$Mu<O>, A>;
    }

    export class $RecordCodecBuilder$Mu<O> implements $K1 {
        constructor();
    }

    export class $SimpleMapCodec<K, V> extends $MapCodec implements $BaseMapCodec {
        constructor(arg0: $Codec<K>, arg1: $Codec<V>, arg2: $Keyable);
        decode<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>): $DataResult<$Map<K, V>>;
        elementCodec(): $Codec<V>;
        encode<T>(arg0: { [key: K]: V }, arg1: $DynamicOps<T>, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        keyCodec(): $Codec<K>;
        keys<T>(arg0: $DynamicOps<T>): $Stream<T>;
        toString(): string;
    }

    export class $UnboundedMapCodec<K, V> extends $Record implements $BaseMapCodec, $Codec {
        constructor(keyCodec: $Codec<K>, elementCodec: $Codec<V>);
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<$Map<K, V>, T>>;
        elementCodec(): $Codec<V>;
        encode<T>(arg0: { [key: K]: V }, arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        keyCodec(): $Codec<K>;
        toString(): string;
    }

}
