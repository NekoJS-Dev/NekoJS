import { $ScriptType, $ScriptType_ } from "java:com/tkisor/nekojs/api";
import { $String } from "java:java/lang";

declare module "java:com/tkisor/nekojs/api/event" {
    export interface $ScriptEventRegistrar {
        register(targetType: $ScriptType_, groupName: string, eventName: string, sourceScriptId: string): void;
    }

    export class $ScriptEventRegistrationEvent {
        constructor(targetType: $ScriptType_, registrar: $ScriptEventRegistrar);
        register(config: object): void;
        register(groupName: string, eventName: string): void;
        targetType(): $ScriptType;
    }

}
