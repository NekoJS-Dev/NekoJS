import { $Codec } from "java:com/mojang/serialization";
import { $Record, $Runnable, $String } from "java:java/lang";
import { $Collection, $Set, $UUID } from "java:java/util";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ServerBossEvent, $ServerPlayer } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $BossEvent$BossBarColor, $BossEvent$BossBarColor_, $BossEvent$BossBarOverlay, $BossEvent$BossBarOverlay_ } from "java:net/minecraft/world";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";

declare module "java:net/minecraft/server/bossevents" {
    export class $CustomBossEvent extends $ServerBossEvent {
        constructor(arg0: string, arg1: $Identifier_, arg2: $Component_, arg3: $Runnable);
        get displayName(): $Component;
        getDisplayName(): $Component;
        static load(arg0: string, arg1: $Identifier_, arg2: $CustomBossEvent$Packed, arg3: $Runnable): $CustomBossEvent;
        addPlayer(arg0: $ServerPlayer): void;
        customId(): $Identifier;
        max(): number;
        onPlayerConnect(arg0: $ServerPlayer): void;
        onPlayerDisconnect(arg0: $ServerPlayer): void;
        pack(): $CustomBossEvent$Packed;
        removeAllPlayers(): void;
        removePlayer(arg0: $ServerPlayer): void;
        setDirty(): void;
        value(): number;
    }

    export class $CustomBossEvent$Packed extends $Record {
        constructor(name: $Component_, visible: boolean, value: number, max: number, color: $BossEvent$BossBarColor_, overlay: $BossEvent$BossBarOverlay_, darkenScreen: boolean, playBossMusic: boolean, createWorldFog: boolean, players: string[]);
        static CODEC: $Codec<$CustomBossEvent$Packed>;
        color(): $BossEvent$BossBarColor;
        createWorldFog(): boolean;
        darkenScreen(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        max(): number;
        name(): $Component;
        overlay(): $BossEvent$BossBarOverlay;
        playBossMusic(): boolean;
        players(): $Set<$UUID>;
        toString(): string;
        value(): number;
        visible(): boolean;
    }

    export class $CustomBossEvents extends $SavedData {
        constructor();
        static TYPE: $SavedDataType<$CustomBossEvents>;
        get events(): $Collection<$CustomBossEvent>;
        getEvents(): $Collection<$CustomBossEvent>;
        get ids(): $Collection<$Identifier>;
        getIds(): $Collection<$Identifier>;
        create(arg0: $RandomSource, arg1: $Identifier_, arg2: $Component_): $CustomBossEvent;
        get(arg0: $Identifier_): $CustomBossEvent;
        onPlayerConnect(arg0: $ServerPlayer): void;
        onPlayerDisconnect(arg0: $ServerPlayer): void;
        remove(arg0: $CustomBossEvent): void;
    }

}
