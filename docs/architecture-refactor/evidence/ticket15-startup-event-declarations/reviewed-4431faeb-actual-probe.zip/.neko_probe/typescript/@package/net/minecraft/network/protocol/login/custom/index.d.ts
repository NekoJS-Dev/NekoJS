import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/network/protocol/login/custom" {
    export interface $CustomQueryPayload {
        id(): $Identifier;
        write(arg0: $FriendlyByteBuf): void;
    }

}
