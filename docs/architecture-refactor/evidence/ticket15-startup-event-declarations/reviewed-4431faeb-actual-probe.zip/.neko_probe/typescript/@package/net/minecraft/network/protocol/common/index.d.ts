import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List, $Map, $Optional, $UUID } from "java:java/util";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $Tag } from "java:net/minecraft/nbt";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $CustomPacketPayload } from "java:net/minecraft/network/protocol/common/custom";
import { $ClientCookiePacketListener, $ServerCookiePacketListener } from "java:net/minecraft/network/protocol/cookie";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLinks$UntrustedEntry } from "java:net/minecraft/server";
import { $Dialog } from "java:net/minecraft/server/dialog";
import { $ClientInformation } from "java:net/minecraft/server/level";
import { $TagNetworkSerialization$NetworkPayload } from "java:net/minecraft/tags";
import { $IClientCommonPacketListenerExtension, $IServerCommonPacketListenerExtension } from "java:net/neoforged/neoforge/common/extensions";

export * as custom from "java:net/minecraft/network/protocol/common/custom";

declare module "java:net/minecraft/network/protocol/common" {
    export interface $ClientCommonPacketListener extends $ClientCookiePacketListener, $IClientCommonPacketListenerExtension {
        handleClearDialog(arg0: $ClientboundClearDialogPacket): void;
        handleCustomPayload(arg0: $ClientboundCustomPayloadPacket): void;
        handleCustomReportDetails(arg0: $ClientboundCustomReportDetailsPacket): void;
        handleDisconnect(arg0: $ClientboundDisconnectPacket): void;
        handleKeepAlive(arg0: $ClientboundKeepAlivePacket): void;
        handlePing(arg0: $ClientboundPingPacket): void;
        handleResourcePackPop(arg0: $ClientboundResourcePackPopPacket): void;
        handleResourcePackPush(arg0: $ClientboundResourcePackPushPacket): void;
        handleServerLinks(arg0: $ClientboundServerLinksPacket): void;
        handleShowDialog(arg0: $ClientboundShowDialogPacket): void;
        handleStoreCookie(arg0: $ClientboundStoreCookiePacket): void;
        handleTransfer(arg0: $ClientboundTransferPacket): void;
        handleUpdateTags(arg0: $ClientboundUpdateTagsPacket): void;
    }

    export class $ClientboundClearDialogPacket implements $Packet {
        static INSTANCE: $ClientboundClearDialogPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundClearDialogPacket>;
        handle(arg0: $ClientCommonPacketListener): void;
        type(): $PacketType<$ClientboundClearDialogPacket>;
    }

    export class $ClientboundCustomPayloadPacket extends $Record implements $Packet {
        constructor(payload: $CustomPacketPayload);
        static CONFIG_STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundCustomPayloadPacket>;
        static GAMEPLAY_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundCustomPayloadPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        payload(): $CustomPacketPayload;
        toString(): string;
        type(): $PacketType<$ClientboundCustomPayloadPacket>;
    }

    export class $ClientboundCustomReportDetailsPacket extends $Record implements $Packet {
        constructor(details: { [key: string]: string });
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundCustomReportDetailsPacket>;
        details(): $Map<string, string>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundCustomReportDetailsPacket>;
    }

    export class $ClientboundDisconnectPacket extends $Record implements $Packet {
        constructor(reason: $Component_);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundDisconnectPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        reason(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundDisconnectPacket>;
    }

    export class $ClientboundKeepAlivePacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundKeepAlivePacket>;
        get id(): number;
        getId(): number;
        handle(arg0: $ClientCommonPacketListener): void;
        type(): $PacketType<$ClientboundKeepAlivePacket>;
    }

    export class $ClientboundPingPacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPingPacket>;
        get id(): number;
        getId(): number;
        handle(arg0: $ClientCommonPacketListener): void;
        type(): $PacketType<$ClientboundPingPacket>;
    }

    export class $ClientboundResourcePackPopPacket extends $Record implements $Packet {
        constructor(id: $Optional<string>);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundResourcePackPopPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        id(): $Optional<$UUID>;
        toString(): string;
        type(): $PacketType<$ClientboundResourcePackPopPacket>;
    }

    export class $ClientboundResourcePackPushPacket extends $Record implements $Packet {
        constructor(id: string, url: string, hash: string, required: boolean, prompt: $Optional<$Component_>);
        static MAX_HASH_LENGTH: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundResourcePackPushPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        hash(): string;
        id(): $UUID;
        prompt(): $Optional<$Component>;
        required(): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundResourcePackPushPacket>;
        url(): string;
    }

    export class $ClientboundServerLinksPacket extends $Record implements $Packet {
        constructor(links: $ServerLinks$UntrustedEntry[]);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundServerLinksPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        links(): $List<$ServerLinks$UntrustedEntry>;
        toString(): string;
        type(): $PacketType<$ClientboundServerLinksPacket>;
    }

    export class $ClientboundShowDialogPacket extends $Record implements $Packet {
        constructor(dialog: $Holder<$Dialog>);
        static CONTEXT_FREE_STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundShowDialogPacket>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundShowDialogPacket>;
        dialog(): $Holder<$Dialog>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundShowDialogPacket>;
    }

    export class $ClientboundStoreCookiePacket extends $Record implements $Packet {
        constructor(key: $Identifier_, payload: number[]);
        static PAYLOAD_STREAM_CODEC: $StreamCodec<$ByteBuf, number[]>;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundStoreCookiePacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        key(): $Identifier;
        payload(): number[];
        toString(): string;
        type(): $PacketType<$ClientboundStoreCookiePacket>;
    }

    export class $ClientboundTransferPacket extends $Record implements $Packet {
        constructor(host: string, port: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundTransferPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        host(): string;
        port(): number;
        toString(): string;
        type(): $PacketType<$ClientboundTransferPacket>;
    }

    export class $ClientboundUpdateTagsPacket implements $Packet {
        constructor(arg0: { [key: $ResourceKey<$Registry<any>>]: $TagNetworkSerialization$NetworkPayload });
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundUpdateTagsPacket>;
        get tags(): $Map<$ResourceKey<$Registry<any>>, $TagNetworkSerialization$NetworkPayload>;
        getTags(): $Map<$ResourceKey<$Registry<any>>, $TagNetworkSerialization$NetworkPayload>;
        handle(arg0: $ClientCommonPacketListener): void;
        type(): $PacketType<$ClientboundUpdateTagsPacket>;
    }

    export interface $ServerCommonPacketListener extends $ServerCookiePacketListener, $IServerCommonPacketListenerExtension {
        handleClientInformation(arg0: $ServerboundClientInformationPacket): void;
        handleCustomClickAction(arg0: $ServerboundCustomClickActionPacket): void;
        handleCustomPayload(arg0: $ServerboundCustomPayloadPacket): void;
        handleKeepAlive(arg0: $ServerboundKeepAlivePacket): void;
        handlePong(arg0: $ServerboundPongPacket): void;
        handleResourcePackResponse(arg0: $ServerboundResourcePackPacket): void;
    }

    export class $ServerboundClientInformationPacket extends $Record implements $Packet {
        constructor(information: $ClientInformation);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundClientInformationPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCommonPacketListener): void;
        hashCode(): number;
        information(): $ClientInformation;
        toString(): string;
        type(): $PacketType<$ServerboundClientInformationPacket>;
    }

    export class $ServerboundCustomClickActionPacket extends $Record implements $Packet {
        constructor(id: $Identifier_, payload: $Optional<$Tag>);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundCustomClickActionPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCommonPacketListener): void;
        hashCode(): number;
        id(): $Identifier;
        payload(): $Optional<$Tag>;
        toString(): string;
        type(): $PacketType<$ServerboundCustomClickActionPacket>;
    }

    export class $ServerboundCustomPayloadPacket extends $Record implements $Packet {
        constructor(payload: $CustomPacketPayload);
        static CONFIG_STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCustomPayloadPacket>;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCustomPayloadPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCommonPacketListener): void;
        hashCode(): number;
        payload(): $CustomPacketPayload;
        toString(): string;
        type(): $PacketType<$ServerboundCustomPayloadPacket>;
    }

    export class $ServerboundKeepAlivePacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundKeepAlivePacket>;
        get id(): number;
        getId(): number;
        handle(arg0: $ServerCommonPacketListener): void;
        type(): $PacketType<$ServerboundKeepAlivePacket>;
    }

    export class $ServerboundPongPacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPongPacket>;
        get id(): number;
        getId(): number;
        handle(arg0: $ServerCommonPacketListener): void;
        type(): $PacketType<$ServerboundPongPacket>;
    }

    export class $ServerboundResourcePackPacket extends $Record implements $Packet {
        constructor(id: string, action: $ServerboundResourcePackPacket$Action_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundResourcePackPacket>;
        action(): $ServerboundResourcePackPacket$Action;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCommonPacketListener): void;
        hashCode(): number;
        id(): $UUID;
        toString(): string;
        type(): $PacketType<$ServerboundResourcePackPacket>;
    }

    export class $ServerboundResourcePackPacket$Action {
        static ACCEPTED: $ServerboundResourcePackPacket$Action;
        static DECLINED: $ServerboundResourcePackPacket$Action;
        static DISCARDED: $ServerboundResourcePackPacket$Action;
        static DOWNLOADED: $ServerboundResourcePackPacket$Action;
        static FAILED_DOWNLOAD: $ServerboundResourcePackPacket$Action;
        static FAILED_RELOAD: $ServerboundResourcePackPacket$Action;
        static INVALID_URL: $ServerboundResourcePackPacket$Action;
        static SUCCESSFULLY_LOADED: $ServerboundResourcePackPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundResourcePackPacket$Action[];
        static valueOf(name: string): $ServerboundResourcePackPacket$Action;
    }

    export type $ServerboundResourcePackPacket$Action_ = $ServerboundResourcePackPacket$Action | "ACCEPTED" | "DECLINED" | "DISCARDED" | "DOWNLOADED" | "FAILED_DOWNLOAD" | "FAILED_RELOAD" | "INVALID_URL" | "SUCCESSFULLY_LOADED";
}
