import { $Enum, $String } from "java:java/lang";
import { $Map, $Optional } from "java:java/util";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";

export * as worldgen from "java:net/minecraft/data/worldgen";

declare module "java:net/minecraft/data" {
    export class $BlockFamily {
        get baseBlock(): $Block;
        getBaseBlock(): $Block;
        get recipeGroupPrefix(): $Optional<string>;
        getRecipeGroupPrefix(): $Optional<string>;
        get recipeUnlockedBy(): $Optional<string>;
        getRecipeUnlockedBy(): $Optional<string>;
        get variants(): $Map<$BlockFamily$Variant, $Block>;
        getVariants(): $Map<$BlockFamily$Variant, $Block>;
        get(arg0: $BlockFamily$Variant_): $Block;
        shouldGenerateCraftingRecipe(): boolean;
        shouldGenerateModel(): boolean;
        shouldGenerateSmeltingRecipe(): boolean;
        shouldGenerateStonecutterRecipe(): boolean;
    }

    export class $BlockFamily$Variant {
        static BRICKS: $BlockFamily$Variant;
        static BUTTON: $BlockFamily$Variant;
        static CHISELED: $BlockFamily$Variant;
        static COBBLED: $BlockFamily$Variant;
        static CRACKED: $BlockFamily$Variant;
        static CUSTOM_FENCE: $BlockFamily$Variant;
        static CUSTOM_FENCE_GATE: $BlockFamily$Variant;
        static CUSTOM_HANGING_SIGN: $BlockFamily$Variant;
        static CUSTOM_WALL_HANGING_SIGN: $BlockFamily$Variant;
        static CUT: $BlockFamily$Variant;
        static DOOR: $BlockFamily$Variant;
        static FENCE: $BlockFamily$Variant;
        static FENCE_GATE: $BlockFamily$Variant;
        static HANGING_SIGN: $BlockFamily$Variant;
        static LOG: $BlockFamily$Variant;
        static MOSAIC: $BlockFamily$Variant;
        static PILLAR: $BlockFamily$Variant;
        static POLISHED: $BlockFamily$Variant;
        static PRESSURE_PLATE: $BlockFamily$Variant;
        static SIGN: $BlockFamily$Variant;
        static SLAB: $BlockFamily$Variant;
        static STAIRS: $BlockFamily$Variant;
        static STRIPPED_LOG: $BlockFamily$Variant;
        static TILES: $BlockFamily$Variant;
        static TRAPDOOR: $BlockFamily$Variant;
        static WALL: $BlockFamily$Variant;
        static WALL_HANGING_SIGN: $BlockFamily$Variant;
        static WALL_SIGN: $BlockFamily$Variant;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BlockFamily$Variant[];
        static valueOf(name: string): $BlockFamily$Variant;
    }

    export type $BlockFamily$Variant_ = $BlockFamily$Variant | "BRICKS" | "BUTTON" | "CHISELED" | "COBBLED" | "CRACKED" | "CUSTOM_FENCE" | "CUSTOM_FENCE_GATE" | "CUSTOM_HANGING_SIGN" | "CUSTOM_WALL_HANGING_SIGN" | "CUT" | "DOOR" | "FENCE" | "FENCE_GATE" | "HANGING_SIGN" | "LOG" | "MOSAIC" | "PILLAR" | "POLISHED" | "PRESSURE_PLATE" | "SIGN" | "SLAB" | "STAIRS" | "STRIPPED_LOG" | "TILES" | "TRAPDOOR" | "WALL" | "WALL_HANGING_SIGN" | "WALL_SIGN";
}
