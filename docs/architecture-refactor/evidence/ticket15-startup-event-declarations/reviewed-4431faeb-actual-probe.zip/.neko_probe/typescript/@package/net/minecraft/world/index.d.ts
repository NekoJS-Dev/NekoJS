import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Iterable, $Record, $String } from "java:java/lang";
import { $Iterator, $List, $Set, $UUID } from "java:java/util";
import { $BiConsumer, $Predicate, $UnaryOperator } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $NonNullList } from "java:net/minecraft/core";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $RandomSource, $StringRepresentable, $StringRepresentable$EnumCodec } from "java:net/minecraft/util";
import { $ContainerUser, $Entity, $EquipmentSlot, $EquipmentSlot_, $SlotAccess, $SlotProvider } from "java:net/minecraft/world/entity";
import { $Player, $StackedItemContents } from "java:net/minecraft/world/entity/player";
import { $MenuConstructor, $StackedContentsCompatible } from "java:net/minecraft/world/inventory";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $RandomSupport$Seed128bit } from "java:net/minecraft/world/level/levelgen";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";
import { $ValueInput$TypedInputList, $ValueOutput$TypedOutputList } from "java:net/minecraft/world/level/storage";
import { $ContainerExtension, $IMenuProviderExtension } from "java:net/neoforged/neoforge/common/extensions";

export * as attribute from "java:net/minecraft/world/attribute";
export * as clock from "java:net/minecraft/world/clock";
export * as damagesource from "java:net/minecraft/world/damagesource";
export * as effect from "java:net/minecraft/world/effect";
export * as entity from "java:net/minecraft/world/entity";
export * as flag from "java:net/minecraft/world/flag";
export * as food from "java:net/minecraft/world/food";
export * as inventory from "java:net/minecraft/world/inventory";
export * as item from "java:net/minecraft/world/item";
export * as level from "java:net/minecraft/world/level";
export * as phys from "java:net/minecraft/world/phys";
export * as scores from "java:net/minecraft/world/scores";
export * as ticks from "java:net/minecraft/world/ticks";
export * as timeline from "java:net/minecraft/world/timeline";
export * as waypoints from "java:net/minecraft/world/waypoints";

declare module "java:net/minecraft/world" {
    export class $BossEvent {
        constructor(arg0: string, arg1: $Component_, arg2: $BossEvent$BossBarColor_, arg3: $BossEvent$BossBarOverlay_);
        get color(): $BossEvent$BossBarColor;
        getColor(): $BossEvent$BossBarColor;
        set color(value: $BossEvent$BossBarColor_);
        get id(): $UUID;
        getId(): $UUID;
        get name(): $Component;
        getName(): $Component;
        set name(value: $Component_);
        get overlay(): $BossEvent$BossBarOverlay;
        getOverlay(): $BossEvent$BossBarOverlay;
        set overlay(value: $BossEvent$BossBarOverlay_);
        get progress(): number;
        getProgress(): number;
        set progress(value: number);
        shouldCreateWorldFog(): boolean;
        shouldDarkenScreen(): boolean;
        shouldPlayBossMusic(): boolean;
    }

    export class $BossEvent$BossBarColor {
        static BLUE: $BossEvent$BossBarColor;
        static GREEN: $BossEvent$BossBarColor;
        static PINK: $BossEvent$BossBarColor;
        static PURPLE: $BossEvent$BossBarColor;
        static RED: $BossEvent$BossBarColor;
        static WHITE: $BossEvent$BossBarColor;
        static YELLOW: $BossEvent$BossBarColor;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BossEvent$BossBarColor[];
        static valueOf(name: string): $BossEvent$BossBarColor;
    }

    export class $BossEvent$BossBarOverlay {
        static NOTCHED_10: $BossEvent$BossBarOverlay;
        static NOTCHED_12: $BossEvent$BossBarOverlay;
        static NOTCHED_20: $BossEvent$BossBarOverlay;
        static NOTCHED_6: $BossEvent$BossBarOverlay;
        static PROGRESS: $BossEvent$BossBarOverlay;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BossEvent$BossBarOverlay[];
        static valueOf(name: string): $BossEvent$BossBarOverlay;
    }

    export interface $Clearable {
        clearContent(): void;
    }

    export interface $Container extends $Clearable, $Iterable, $SlotProvider, $ContainerExtension {
        canPlaceItem(arg0: number, arg1: $ItemStack_): boolean;
        canTakeItem(arg0: $Container, arg1: number, arg2: $ItemStack_): boolean;
        countItem(arg0: $Item_): number;
        getContainerSize(): number;
        getEntitiesWithContainerOpen(): $List<$ContainerUser>;
        getItem(arg0: number): $ItemStack;
        getMaxStackSize(arg0: $ItemStack_): number;
        getMaxStackSize(): number;
        getSlot(arg0: number): $SlotAccess;
        hasAnyMatching(arg0: $Predicate<$ItemStack_>): boolean;
        hasAnyOf(arg0: $Item_[]): boolean;
        isEmpty(): boolean;
        iterator(): $Iterator<$ItemStack>;
        removeItemNoUpdate(arg0: number): $ItemStack;
        removeItem(arg0: number, arg1: number): $ItemStack;
        setChanged(): void;
        setItem(arg0: number, arg1: $ItemStack_): void;
        startOpen(arg0: $ContainerUser): void;
        stillValidBlockEntity(arg0: $BlockEntity, arg1: $Player, arg2: number): boolean;
        stillValidBlockEntity(arg0: $BlockEntity, arg1: $Player): boolean;
        stillValid(arg0: $Player): boolean;
        stopOpen(arg0: $ContainerUser): void;
        static DEFAULT_DISTANCE_BUFFER: number;
    }

    export class $Difficulty {
        static EASY: $Difficulty;
        static HARD: $Difficulty;
        static NORMAL: $Difficulty;
        static PEACEFUL: $Difficulty;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Difficulty[];
        static valueOf(name: string): $Difficulty;
    }

    export class $DifficultyInstance {
        constructor(arg0: $Difficulty_, arg1: number, arg2: number, arg3: number);
        get difficulty(): $Difficulty;
        getDifficulty(): $Difficulty;
        get effectiveDifficulty(): number;
        getEffectiveDifficulty(): number;
        get specialMultiplier(): number;
        getSpecialMultiplier(): number;
        get hard(): boolean;
        isHard(): boolean;
        isHarderThan(arg0: number): boolean;
    }

    export class $InteractionHand {
        static MAIN_HAND: $InteractionHand;
        static OFF_HAND: $InteractionHand;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $InteractionHand[];
        static valueOf(name: string): $InteractionHand;
    }

    export interface $InteractionResult {
        consumesAction(): boolean;
        static CONSUME: $InteractionResult$Success;
        static FAIL: $InteractionResult$Fail;
        static PASS: $InteractionResult$Pass;
        static SUCCESS: $InteractionResult$Success;
        static SUCCESS_SERVER: $InteractionResult$Success;
        static TRY_WITH_EMPTY_HAND: $InteractionResult$TryEmptyHandInteraction;
    }

    export class $InteractionResult$Fail extends $Record implements $InteractionResult {
        constructor();
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $InteractionResult$ItemContext extends $Record {
        constructor(wasItemInteraction: boolean, heldItemTransformedTo: $ItemStack_);
        static DEFAULT: $InteractionResult$ItemContext;
        static NONE: $InteractionResult$ItemContext;
        equals(arg0: object): boolean;
        hashCode(): number;
        heldItemTransformedTo(): $ItemStack;
        toString(): string;
        wasItemInteraction(): boolean;
    }

    export class $InteractionResult$Pass extends $Record implements $InteractionResult {
        constructor();
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $InteractionResult$Success extends $Record implements $InteractionResult {
        constructor(swingSource: $InteractionResult$SwingSource_, itemContext: $InteractionResult$ItemContext);
        consumesAction(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        heldItemTransformedTo(arg0: $ItemStack_): $InteractionResult$Success;
        heldItemTransformedTo(): $ItemStack;
        itemContext(): $InteractionResult$ItemContext;
        swingSource(): $InteractionResult$SwingSource;
        toString(): string;
        wasItemInteraction(): boolean;
        withoutItem(): $InteractionResult$Success;
    }

    export class $InteractionResult$SwingSource {
        static CLIENT: $InteractionResult$SwingSource;
        static NONE: $InteractionResult$SwingSource;
        static SERVER: $InteractionResult$SwingSource;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $InteractionResult$SwingSource[];
        static valueOf(name: string): $InteractionResult$SwingSource;
    }

    export class $InteractionResult$TryEmptyHandInteraction extends $Record implements $InteractionResult {
        constructor();
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $ItemStackWithSlot extends $Record {
        constructor(slot: number, stack: $ItemStack_);
        static CODEC: $Codec<$ItemStackWithSlot>;
        equals(arg0: object): boolean;
        hashCode(): number;
        isValidInContainer(arg0: number): boolean;
        slot(): number;
        stack(): $ItemStack;
        toString(): string;
    }

    export interface $MenuProvider extends $MenuConstructor, $IMenuProviderExtension {
        getDisplayName(): $Component;
    }

    export interface $Nameable {
        getCustomName(): $Component;
        getDisplayName(): $Component;
        getName(): $Component;
        getPlainTextName(): string;
        hasCustomName(): boolean;
    }

    export class $RandomSequence {
        constructor(arg0: number, arg1: $Optional<$Identifier_>);
        constructor(arg0: number, arg1: $Identifier_);
        constructor(arg0: $XoroshiroRandomSource);
        static CODEC: $Codec<$RandomSequence>;
        static seedForKey(arg0: $Identifier_): $RandomSupport$Seed128bit;
        random(): $RandomSource;
    }

    export class $RandomSequences extends $SavedData {
        constructor();
        static CODEC: $Codec<$RandomSequences>;
        static TYPE: $SavedDataType<$RandomSequences>;
        clear(): number;
        forAllSequences(arg0: $BiConsumer<$Identifier_, $RandomSequence>): void;
        get(arg0: $Identifier_, arg1: number): $RandomSource;
        reset(arg0: $Identifier_, arg1: number, arg2: number, arg3: boolean, arg4: boolean): void;
        reset(arg0: $Identifier_, arg1: number): void;
        setSeedDefaults(arg0: number, arg1: boolean, arg2: boolean): void;
    }

    export class $SimpleContainer implements $Container, $StackedContentsCompatible {
        constructor(arg0: number);
        constructor(arg0?: $ItemStack_[]);
        get containerSize(): number;
        getContainerSize(): number;
        get items(): $NonNullList<$ItemStack>;
        getItems(): $NonNullList<$ItemStack>;
        get empty(): boolean;
        isEmpty(): boolean;
        addItem(arg0: $ItemStack_): $ItemStack;
        canAddItem(arg0: $ItemStack_): boolean;
        clearContent(): void;
        fillStackedContents(arg0: $StackedItemContents): void;
        fromItemList(arg0: $ValueInput$TypedInputList<$ItemStack_>): void;
        getItem(arg0: number): $ItemStack;
        removeAllItems(): $List<$ItemStack>;
        removeItemNoUpdate(arg0: number): $ItemStack;
        removeItemType(arg0: $Item_, arg1: number): $ItemStack;
        removeItem(arg0: number, arg1: number): $ItemStack;
        setChanged(): void;
        setItem(arg0: number, arg1: $ItemStack_, arg2: boolean): void;
        setItem(arg0: number, arg1: $ItemStack_): void;
        stillValid(arg0: $Player): boolean;
        storeAsItemList(arg0: $ValueOutput$TypedOutputList<$ItemStack_>): void;
        toString(): string;
    }

    export class $Stopwatch extends $Record {
        constructor(arg0: number);
        constructor(creationTime: number, accumulatedElapsedTime: number);
        accumulatedElapsedTime(): number;
        creationTime(): number;
        elapsedMilliseconds(arg0: number): number;
        elapsedSeconds(arg0: number): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $Stopwatches extends $SavedData {
        static TYPE: $SavedDataType<$Stopwatches>;
        get dirty(): boolean;
        isDirty(): boolean;
        static currentTime(): number;
        add(arg0: $Identifier_, arg1: $Stopwatch): boolean;
        get(arg0: $Identifier_): $Stopwatch;
        ids(): $List<$Identifier>;
        remove(arg0: $Identifier_): boolean;
        update(arg0: $Identifier_, arg1: $UnaryOperator<$Stopwatch>): boolean;
    }

    export class $TickRateManager {
        constructor();
        static MIN_TICKRATE: number;
        get frozen(): boolean;
        isFrozen(): boolean;
        set frozen(value: boolean);
        get steppingForward(): boolean;
        isSteppingForward(): boolean;
        frozenTicksToRun(): number;
        isEntityFrozen(arg0: $Entity): boolean;
        millisecondsPerTick(): number;
        nanosecondsPerTick(): number;
        runsNormally(): boolean;
        tickrate(): number;
        tick(): void;
    }

    export type $BossEvent$BossBarColor_ = $BossEvent$BossBarColor | "BLUE" | "GREEN" | "PINK" | "PURPLE" | "RED" | "WHITE" | "YELLOW";
    export type $BossEvent$BossBarOverlay_ = $BossEvent$BossBarOverlay | "NOTCHED_10" | "NOTCHED_12" | "NOTCHED_20" | "NOTCHED_6" | "PROGRESS";
    export type $Difficulty_ = $Difficulty | "EASY" | "HARD" | "NORMAL" | "PEACEFUL";
    export type $InteractionHand_ = $InteractionHand | "MAIN_HAND" | "OFF_HAND";
    export type $InteractionResult$SwingSource_ = $InteractionResult$SwingSource | "CLIENT" | "NONE" | "SERVER";
}
