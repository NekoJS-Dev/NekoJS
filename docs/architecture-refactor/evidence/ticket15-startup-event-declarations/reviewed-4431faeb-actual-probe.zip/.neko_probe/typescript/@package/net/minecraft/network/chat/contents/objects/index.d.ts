import { $MapCodec } from "java:com/mojang/serialization";
import { $String } from "java:java/lang";
import { $FontDescription } from "java:net/minecraft/network/chat";

declare module "java:net/minecraft/network/chat/contents/objects" {
    export interface $ObjectInfo {
        codec(): $MapCodec<$ObjectInfo>;
        defaultFallback(): string;
        fontDescription(): $FontDescription;
    }

}
