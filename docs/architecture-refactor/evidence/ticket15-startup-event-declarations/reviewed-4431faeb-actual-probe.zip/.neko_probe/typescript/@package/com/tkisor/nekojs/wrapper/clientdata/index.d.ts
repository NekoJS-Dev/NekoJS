import { $String } from "java:java/lang";
import { $ServerPlayer } from "java:net/minecraft/server/level";

declare module "java:com/tkisor/nekojs/wrapper/clientdata" {
    /**
     * Server-side API to push key-value data to clients; client scripts read it via clientData.get(key).
     * Values must be JSON types (string/number/bool/object/array/null); re-pushed keys overwrite on the client.
     */
    export class $ClientDataSyncJS {
        /**
         * Pushes the value under the key to one specific player.
         * @param player the receiving server-side player
         * @param key data key the client reads with clientData.get(key)
         * @param value JSON-compatible value (string/number/bool/object/array/null)
         */
        static syncTo(player: $ServerPlayer, key: string, value: object): void;
        /**
         * Pushes the value under the key to every connected player.
         * @param key data key the client reads with clientData.get(key)
         * @param value JSON-compatible value (string/number/bool/object/array/null)
         */
        static sync(key: string, value: object): void;
    }

}
