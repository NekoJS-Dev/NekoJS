import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $NekoWrapper } from "java:com/tkisor/nekojs/wrapper";
import { $String } from "java:java/lang";
import { $Fluid, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $FluidStack, $FluidStack_ } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient, $FluidIngredient_, $SizedFluidIngredient, $SizedFluidIngredient_ } from "java:net/neoforged/neoforge/fluids/crafting";

declare module "java:com/tkisor/nekojs/wrapper/fluid" {
    /**
     * A fluid ingredient built from OR-combined alternatives.
     * Use withAmount(n) to turn it into a sized fluid ingredient requiring n millibuckets.
     */
    export class $FluidIngredientJS implements $NekoWrapper {
        constructor();
        /**
         * Creates a fluid ingredient matching any of the given fluid ids.
         * @param ids fluid ids; '#tag', '@mod', '*', and '/regex/' selector strings also work
         */
        constructor(ids?: string[]);
        /**
         * Creates a fluid ingredient from an existing FluidIngredient.
         * @param ingredient the ingredient to wrap
         */
        constructor(ingredient: $FluidIngredient_);
        /**
         * Checks whether no alternative has been added yet.
         * @returns true when the wrapper holds no alternatives
         */
        get empty(): boolean;
        isEmpty(): boolean;
        /**
         * Adds a NekoId as another accepted alternative.
         * @param id fluid id as a NekoId
         * @returns this, for chaining
         */
        or(id: $NekoId): $FluidIngredientJS;
        /**
         * Adds all alternatives of another FluidIngredientJS.
         * @param other wrapper whose combined alternatives are OR-joined into this one
         * @returns this, for chaining
         */
        or(other: $FluidIngredientJS): $FluidIngredientJS;
        /**
         * Adds a fluid id as another accepted alternative.
         * @param id fluid id or selector string like '#tag'
         * @returns this, for chaining
         */
        or(id: string): $FluidIngredientJS;
        /**
         * Adds a fluid as another accepted alternative.
         * @param fluid the fluid to accept
         * @returns this, for chaining
         */
        or(fluid: $Fluid_): $FluidIngredientJS;
        /**
         * Adds the fluid of a stack as another accepted alternative.
         * @param stack the fluid stack whose fluid is accepted
         * @returns this, for chaining
         */
        or(stack: $FluidStack_): $FluidIngredientJS;
        /**
         * Adds an existing FluidIngredient as another accepted alternative.
         * @param ingredient the ingredient to OR in
         * @returns this, for chaining
         */
        or(ingredient: $FluidIngredient_): $FluidIngredientJS;
        /**
         * Alias of withAmount(amount).
         * @param amount required amount in millibuckets
         * @returns a SizedFluidIngredient matching the same fluids with the given amount
         */
        sized(amount: number): $SizedFluidIngredient;
        /**
         * Unwraps to a single FluidIngredient; throws when no alternative has been added.
         * @returns the single alternative as-is, or a combined OR ingredient when several were added
         */
        unwrap(): $FluidIngredient;
        /**
         * Turns this ingredient into a sized one requiring the given amount.
         * @param amount required amount in millibuckets
         * @returns a SizedFluidIngredient matching the same fluids with the given amount
         */
        withAmount(amount: number): $SizedFluidIngredient;
    }

}
