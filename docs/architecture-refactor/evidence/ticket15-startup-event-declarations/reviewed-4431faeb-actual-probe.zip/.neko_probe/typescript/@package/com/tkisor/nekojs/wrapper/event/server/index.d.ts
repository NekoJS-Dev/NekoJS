import { $JsonElement, $JsonObject } from "java:com/google/gson";
import { $RecipeCreationContext, $RecipeEntryJS, $RecipeFilter, $RecipeFilter_, $RecipeJsonBuilder, $RecipeJsonValue, $RecipeJsonValue_, $RecipeLifecycleContext } from "java:com/tkisor/nekojs/api/recipe";
import { $RecipeTypeDefinitionRegistry } from "java:com/tkisor/nekojs/api/recipe/definition";
import { $RecipeRegistryProxy } from "java:com/tkisor/nekojs/wrapper";
import { $Value } from "java:graal/graalvm/polyglot";
import { $ProxyObject } from "java:graal/graalvm/polyglot/proxy";
import { $Boolean, $Double, $Exception, $Float, $Integer, $Record, $String } from "java:java/lang";
import { $List, $Map, $Set } from "java:java/util";
import { $Consumer, $Predicate } from "java:java/util/function";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_, $Recipe, $RecipeHolder } from "java:net/minecraft/world/item/crafting";
import { $LootTableLoadEvent } from "java:net/neoforged/neoforge/event";
import { $FluidStack, $FluidStack_ } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient, $FluidIngredient_, $SizedFluidIngredient, $SizedFluidIngredient_ } from "java:net/neoforged/neoforge/fluids/crafting";

import { DocumentedRecipes } from "@side-only/server/events/recipes";

declare module "java:com/tkisor/nekojs/wrapper/event/server" {
    export class $BlockModificationEventJS {
        constructor(plan: $ModificationCandidatePlan);
        /**
         * Number of declarations recorded so far during this event.
         * @returns how many declarations this event has collected
         */
        get modifiedCount(): number;
        getModifiedCount(): number;
        /**
         * Records a runtime property modification declaration for one block.
         * @param blockId block id like 'minecraft:stone' (the 'minecraft:' prefix is optional)
         * @param modifier callback receiving a block property view; assign block.hardness / block.resistance / block.lightLevel / block.requiresTool / block.friction / block.jumpFactor
         */
        modify(blockId: string, modifier: $Consumer<$BlockModificationJS>): void;
    }

    export class $BlockModificationJS implements $ProxyObject {
        /**
         * Current surface friction of the block (0..1; ice is 0.98, default 0.6).
         * @returns the current friction: the pending change if set, otherwise the block's live value
         */
        get friction(): number;
        getFriction(): number;
        set friction(value: number);
        /**
         * Current destroy-time hardness of the block.
         * Reads the live value until you assign a new one; -1-style unbreakable is not allowed here (set a very high value instead).
         * @returns the current hardness: the pending change if set, otherwise the block's live value
         */
        get hardness(): number;
        getHardness(): number;
        set hardness(value: number);
        /**
         * Current jump factor of the block (vanilla blocks use 0.5..1).
         * @returns the current jump factor: the pending change if set, otherwise the block's live value
         */
        get jumpFactor(): number;
        getJumpFactor(): number;
        set jumpFactor(value: number);
        /**
         * Current light emission of the block (0..15).
         * @returns the current light level: the pending change if set, otherwise the block's live value
         */
        get lightLevel(): number;
        getLightLevel(): number;
        set lightLevel(value: number);
        get memberKeys(): object;
        getMemberKeys(): object;
        /**
         * Whether the block requires the correct tool tier to drop loot.
         * @returns the current flag: the pending change if set, otherwise the block's live value
         */
        get requiresTool(): boolean;
        getRequiresTool(): boolean;
        set requiresTool(value: boolean);
        /**
         * Current blast resistance of the block.
         * @returns the current resistance: the pending change if set, otherwise the block's live value
         */
        get resistance(): number;
        getResistance(): number;
        set resistance(value: number);
        getMember(name: string): object;
        hasMember(name: string): boolean;
        putMember(name: string, value: $Value): void;
        removeMember(name: string): boolean;
    }

    export class $ItemModificationComponents$FoodSpec extends $Record {
        constructor(nutrition: number, saturation: number, canAlwaysEat: boolean, eatSeconds: number);
        static fromNormalized(map: { [key: string]: object }): $ItemModificationComponents$FoodSpec;
        canAlwaysEat(): boolean;
        eatSeconds(): number;
        equals(o: object): boolean;
        hashCode(): number;
        nutrition(): number;
        saturation(): number;
        toNormalized(): $Map<string, object>;
        toString(): string;
    }

    export class $ItemModificationComponents$ToolSpec extends $Record {
        constructor(miningSpeed: number, damagePerBlock: number, canDestroyBlocksInCreative: boolean);
        static fromNormalized(map: { [key: string]: object }): $ItemModificationComponents$ToolSpec;
        canDestroyBlocksInCreative(): boolean;
        damagePerBlock(): number;
        equals(o: object): boolean;
        hashCode(): number;
        miningSpeed(): number;
        toNormalized(): $Map<string, object>;
        toString(): string;
    }

    export class $ItemModificationEventJS {
        constructor(plan: $ModificationCandidatePlan);
        get modifiedCount(): number;
        getModifiedCount(): number;
        modify(itemId: string, modifier: $Consumer<$ItemModificationJS>): void;
    }

    export class $ItemModificationJS implements $ProxyObject {
        constructor();
        /**
         * Replaces the item's base attack damage modifier (minecraft:base_attack_damage, ADD_VALUE on mainhand), keeping every other attribute entry - including attack speed.
         * The value is a bonus on top of the player's base attack damage (2.0 on 26.x), so total damage = 2.0 + value.
         * @returns Pending attack damage override, or null when not set.
         */
        get attackDamage(): number;
        getAttackDamage(): number;
        set attackDamage(value: number);
        /**
         * Replaces the item's base attack speed modifier (minecraft:base_attack_speed, ADD_VALUE on mainhand), keeping every other attribute entry - including attack damage.
         * The value is a bonus on top of the player's base attack speed (4.0 on 26.x): a sword uses -2.4 for a total of 1.6.
         * @returns Pending attack speed override, or null when not set.
         */
        get attackSpeed(): number;
        getAttackSpeed(): number;
        set attackSpeed(value: number);
        get fireResistant(): boolean;
        getFireResistant(): boolean;
        set fireResistant(value: boolean);
        /**
         * The pending food override as { nutrition, saturation, canAlwaysEat, eatSeconds }, or null when unset (keep current food) or when removal was requested with item.food = null.
         * @returns Pending food spec, or null.
         */
        get food(): $ItemModificationComponents$FoodSpec;
        getFood(): $ItemModificationComponents$FoodSpec;
        set food(value: object);
        get maxDamage(): number;
        getMaxDamage(): number;
        set maxDamage(value: number);
        get maxStackSize(): number;
        getMaxStackSize(): number;
        set maxStackSize(value: number);
        get memberKeys(): object;
        getMemberKeys(): object;
        get rarity(): string;
        getRarity(): string;
        set rarity(value: object);
        /**
         * The pending tool override as { miningSpeed, damagePerBlock, canDestroyBlocksInCreative }, or null when unset or when removal was requested.
         * @returns Pending tool spec, or null.
         */
        get tool(): $ItemModificationComponents$ToolSpec;
        getTool(): $ItemModificationComponents$ToolSpec;
        set tool(value: object);
        getMember(name: string): object;
        hasMember(name: string): boolean;
        putMember(name: string, value: $Value): void;
        removeMember(name: string): boolean;
    }

    export class $LootEntryJS {
        constructor(json: $JsonObject);
        static of(item: object): $LootEntryJS;
        group(children?: object[]): $LootEntryJS;
        item(item: object): $LootEntryJS;
        name(id: string): $LootEntryJS;
        toJson(): $JsonObject;
        type(type: string): $LootEntryJS;
        weight(weight: number): $LootEntryJS;
        when(condition: object): $LootEntryJS;
    }

    /**
     * Wrapper for one loot pool inside a loot table.
     * JSON-first: edits are applied directly to the underlying JsonObject.
     */
    export class $LootPoolJS {
        constructor(json: $JsonObject);
        /**
         * Gets the entries of this pool.
         * @returns live LootEntryJS wrappers over the existing 'entries' array; edits write straight through to the JSON
         */
        get entries(): $List<$LootEntryJS>;
        getEntries(): $List<$LootEntryJS>;
        /**
         * Appends one loot entry.
         * @param entry item id, '#tag', ItemStack, entry JS object, or a LootEntryJS.of(...) result
         * @returns this, for chaining
         */
        addEntry(entry: object): $LootPoolJS;
        /**
         * Appends an empty loot entry and lets the callback fill it in.
         * @param consumer callback receiving the new LootEntryJS
         * @returns this, for chaining
         */
        addEntry(consumer: $Consumer<$LootEntryJS>): $LootPoolJS;
        /**
         * Sets how many times this pool rolls.
         * @param rolls a number, or a [min, max] array for a random roll count
         * @returns this, for chaining
         */
        rolls(rolls: object): $LootPoolJS;
        /**
         * Gets the raw loot pool JSON.
         * @returns the underlying JsonObject; mutations apply directly to this pool
         */
        toJson(): $JsonObject;
        /**
         * Appends a condition that must pass for this pool to roll.
         * @param condition complete condition JSON, e.g. {condition: 'minecraft:random_chance', chance: 0.5}
         * @returns this, for chaining
         */
        when(condition: object): $LootPoolJS;
    }

    export class $LootTableEventJS {
        constructor();
        get ids(): $List<string>;
        getIds(): $List<string>;
        static onLootTableLoad(event: $LootTableLoadEvent): void;
        create(id: string, json: object): void;
        getJson(id: string): $JsonElement;
        modifyBlockLoot(blockId: string, consumer: $Consumer<$LootTableJS>): void;
        modifyBlockLoot(filter: $Predicate<string>, consumer: $Consumer<$LootTableJS>): void;
        modifyEntityLoot(entityId: string, consumer: $Consumer<$LootTableJS>): void;
        modifyEntityLoot(filter: $Predicate<string>, consumer: $Consumer<$LootTableJS>): void;
        modify(id: string, consumer: $Consumer<$LootTableJS>): void;
        remove(id: string): void;
        setJson(id: string, json: object): void;
    }

    /**
     * Wrapper for the loot table being modified in a ServerEvents.lootTables.modify callback.
     * JSON-first: edits are applied directly to the underlying JsonObject and take effect when the callback returns.
     */
    export class $LootTableJS {
        constructor(json: $JsonObject);
        /**
         * Gets the pools of this loot table.
         * @returns live LootPoolJS wrappers over the existing 'pools' array; edits write straight through to the JSON
         */
        get pools(): $List<$LootPoolJS>;
        getPools(): $List<$LootPoolJS>;
        /**
         * Gets the loot table type id.
         * @returns the type id like 'minecraft:chest', or null when the table has no type set
         */
        get type(): string;
        getType(): string;
        set type(value: string);
        /**
         * Appends a loot pool from raw JSON: a JS object, a JSON string, or a prebuilt pool object.
         * @param pool complete pool JSON as a JS object or JSON string
         * @returns this, for chaining
         */
        addPool(pool: object): $LootTableJS;
        /**
         * Appends an empty loot pool and lets the callback fill it in.
         * @param consumer callback receiving the new LootPoolJS
         * @returns this, for chaining
         */
        addPool(consumer: $Consumer<$LootPoolJS>): $LootTableJS;
        /**
         * Gets the raw loot table JSON.
         * @returns the underlying JsonObject; mutations apply directly to this table
         */
        toJson(): $JsonObject;
    }

    export class $RecipeEventJS implements $RecipeLifecycleContext {
        constructor(originalJsons: { [key: $Identifier_]: $JsonElement }, registries: $HolderLookup$Provider);
        constructor(originalJsons: { [key: $Identifier_]: $JsonElement }, registries: $HolderLookup$Provider, recipeTypeDefinitions: $RecipeTypeDefinitionRegistry);
        get finalJsons(): $Map<$Identifier, $JsonElement>;
        getFinalJsons(): $Map<$Identifier, $JsonElement>;
        get recipeTypeDefinitions(): $RecipeTypeDefinitionRegistry;
        getRecipeTypeDefinitions(): $RecipeTypeDefinitionRegistry;
        get recipes(): DocumentedRecipes;
        static getIngredients(recipe: $Recipe<any>): $List<$Ingredient>;
        static getRecipeOutputId(recipe: $Recipe<any>, registries: $HolderLookup$Provider): string;
        static getRecipeOutputId(recipe: $Recipe<any>): string;
        static ingredientMatches(ingredient: $Ingredient_, tagKey: $TagKey<$Item_>, itemID: $Identifier_, registries: $HolderLookup$Provider): boolean;
        static recipeGroup(recipe: $Recipe<any>): string;
        static recipeHolderId(holder: $RecipeHolder<any>): $Identifier;
        all(): $List<$RecipeEntryJS>;
        blasting(result: $ItemStack_, ingredient: $Ingredient_, xp: number, cookTime: number): $RecipeJsonBuilder;
        blasting(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        builder(type: string): $RecipeJsonBuilder;
        campfireCooking(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        count(filter: $RecipeFilter_): number;
        count(): number;
        custom(recipeJson: $JsonObject): $RecipeJsonBuilder;
        custom(value: $RecipeJsonValue_): $RecipeJsonBuilder;
        custom(type: string, value: $RecipeJsonValue_): $RecipeJsonBuilder;
        describeRecipe(id: $Identifier_, json: $JsonObject): string;
        dump(filter: $RecipeFilter_): string;
        dump(): string;
        exists(filter: $RecipeFilter_): boolean;
        exists(id: string): boolean;
        find(filter: $RecipeFilter_): $List<$RecipeEntryJS>;
        forEach(filter: $RecipeFilter_, callback: $Consumer<$RecipeEntryJS>): void;
        forEach(callback: $Consumer<$RecipeEntryJS>): void;
        formatRecipeError(prefix: string, id: $Identifier_, json: $JsonObject, e: $Exception): string;
        generateRecipeId(prefix: string): $Identifier;
        getJson(id: string): string;
        getRecipeContext(id: $Identifier_): $RecipeCreationContext;
        get(id: string): $RecipeEntryJS;
        ids(): $Set<string>;
        modify(filter: $RecipeFilter_, callback: $Consumer<$RecipeEntryJS>): void;
        print(filter: $RecipeFilter_): void;
        print(): void;
        removeById(id: string): void;
        removeRecipeContext(id: $Identifier_): void;
        remove(filter: $RecipeFilter_): void;
        replaceInput(filter: $RecipeFilter_, match: $Ingredient_, replacement: $Ingredient_): void;
        replaceOutput(filter: $RecipeFilter_, match: $Ingredient_, replacement: $ItemStack_): void;
        serializeFluidIngredient(ingredient: $FluidIngredient_): $JsonElement;
        serializeFluidStack(stack: $FluidStack_): $JsonElement;
        serializeIngredient(ingredient: $Ingredient_): $JsonElement;
        serializeResult(stack: $ItemStack_): $JsonElement;
        serializeSizedFluidIngredient(ingredient: $SizedFluidIngredient_): $JsonElement;
        setJson(id: string, json: string): void;
        setRecipeContext(id: $Identifier_, context: $RecipeCreationContext): void;
        shaped(result: $ItemStack_, pattern: string[], keys: { [key: string]: $Ingredient_ }): $RecipeJsonBuilder;
        shapeless(result: $ItemStack_, ingredients: $Ingredient_[]): $RecipeJsonBuilder;
        smelting(result: $ItemStack_, ingredient: $Ingredient_, xp: number, cookTime: number): $RecipeJsonBuilder;
        smelting(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        smoking(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        validateRecipe(id: $Identifier_, json: $JsonObject): void;
    }

    export class $TagEventJS {
        constructor(registryId: $Identifier_, sourceMap: { [key: $Identifier_]: $TagLoader$EntryWithSource[] });
        get registry(): $Identifier;
        getRegistry(): $Identifier;
        add(tag: string, entry: string): void;
        add(tag: $Identifier_, entry: $Identifier_): void;
        apply(): void;
        getEntries(tag: string): $List<string>;
        removeAll(tag: string): void;
        removeAll(tag: $Identifier_): void;
        remove(tag: string, entry: string): void;
        remove(tag: $Identifier_, entry: $Identifier_): void;
        replaceAll(tag: string, entries?: string[]): void;
        replaceAll(tag: $Identifier_, entries?: string[]): void;
    }

}
