import { $GameProfile, $GameProfileRepository } from "java:com/mojang/authlib";
import { $MinecraftSessionService } from "java:com/mojang/authlib/minecraft";
import { $ServicesKeySet, $YggdrasilAuthenticationService } from "java:com/mojang/authlib/yggdrasil";
import { $CommandDispatcher } from "java:com/mojang/brigadier";
import { $DataFixer } from "java:com/mojang/datafixers";
import { $Either, $Pair } from "java:com/mojang/datafixers/util";
import { $AttachedData } from "java:com/tkisor/nekojs/api/data";
import { $ServerExtension } from "java:com/tkisor/nekojs/api/inject";
import { $ByteBuf } from "java:io/netty/buffer";
import { $File } from "java:java/io";
import { $AutoCloseable, $Enum, $Iterable, $Record, $Runnable, $String, $Thread, $Throwable, $Void } from "java:java/lang";
import { $Proxy, $URI } from "java:java/net";
import { $Path } from "java:java/nio/file";
import { $KeyPair } from "java:java/security";
import { $Collection, $List, $Map, $Optional, $Set, $UUID } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $Consumer, $Function, $Supplier } from "java:java/util/function";
import { $SystemReport } from "java:net/minecraft";
import { $AdvancementHolder, $AdvancementProgress, $AdvancementTree } from "java:net/minecraft/advancements";
import { $CriterionTrigger } from "java:net/minecraft/advancements/triggers";
import { $CommandSource, $CommandSourceStack, $Commands, $Commands$CommandSelection, $Commands$CommandSelection_ } from "java:net/minecraft/commands";
import { $CommandFunction } from "java:net/minecraft/commands/functions";
import { $BlockPos, $BlockPos_, $HolderLookup$Provider, $LayeredRegistryAccess, $Registry, $Registry$PendingTags, $RegistryAccess$Frozen } from "java:net/minecraft/core";
import { $Tag } from "java:net/minecraft/nbt";
import { $PacketProcessor } from "java:net/minecraft/network";
import { $ChatDecorator, $ChatType$Bound, $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ServerStatus } from "java:net/minecraft/network/protocol/status";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $CustomBossEvents } from "java:net/minecraft/server/bossevents";
import { $DedicatedServerProperties } from "java:net/minecraft/server/dedicated";
import { $ServerLevel, $ServerPlayer, $ServerPlayerGameMode } from "java:net/minecraft/server/level";
import { $ChunkLoadStatusView, $LevelLoadListener } from "java:net/minecraft/server/level/progress";
import { $ServerConnectionListener, $TextFilter } from "java:net/minecraft/server/network";
import { $NotificationManager, $ServerActivityMonitor } from "java:net/minecraft/server/notifications";
import { $PackRepository } from "java:net/minecraft/server/packs/repository";
import { $CloseableResourceManager, $PreparableReloadListener, $PreparableReloadListener$PreparationBarrier, $PreparableReloadListener$SharedState, $ResourceManager, $SimpleJsonResourceReloadListener } from "java:net/minecraft/server/packs/resources";
import { $LevelBasedPermissionSet, $PermissionSet } from "java:net/minecraft/server/permissions";
import { $NameAndId, $PlayerList, $ProfileResolver, $UserNameToIdResolver } from "java:net/minecraft/server/players";
import { $ModCheck, $RandomSource, $SignatureValidator } from "java:net/minecraft/util";
import { $ServerDebugSubscribers } from "java:net/minecraft/util/debug";
import { $ProfileResults } from "java:net/minecraft/util/profiling";
import { $ReentrantBlockableEventLoop } from "java:net/minecraft/util/thread";
import { $Difficulty, $Difficulty_, $RandomSequences, $Stopwatches, $TickRateManager } from "java:net/minecraft/world";
import { $ServerClockManager } from "java:net/minecraft/world/clock";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $PotionBrewing } from "java:net/minecraft/world/item/alchemy";
import { $RecipeManager } from "java:net/minecraft/world/item/crafting";
import { $ChunkPos, $GameType, $GameType_, $Level, $LevelSettings, $WorldDataConfiguration } from "java:net/minecraft/world/level";
import { $FuelValues } from "java:net/minecraft/world/level/block/entity";
import { $ChunkIOErrorReporter, $RegionStorageInfo } from "java:net/minecraft/world/level/chunk/storage";
import { $GameRule, $GameRules } from "java:net/minecraft/world/level/gamerules";
import { $WorldGenSettings } from "java:net/minecraft/world/level/levelgen";
import { $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";
import { $WeatherData } from "java:net/minecraft/world/level/saveddata";
import { $CommandStorage, $LevelData$RespawnData, $LevelDataAndDimensions$WorldDataAndGenSettings, $LevelResource, $SavedDataStorage, $WorldData } from "java:net/minecraft/world/level/storage";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $TimerQueue } from "java:net/minecraft/world/level/timers";
import { $DisplaySlot, $DisplaySlot_, $Objective, $PlayerTeam, $ScoreHolder, $Scoreboard, $ScoreboardSaveData, $ScoreboardSaveData$Packed } from "java:net/minecraft/world/scores";
import { $ICondition$IContext } from "java:net/neoforged/neoforge/common/conditions";
import { $ListenerKey } from "java:net/neoforged/neoforge/resource";

export * as bossevents from "java:net/minecraft/server/bossevents";
export * as dedicated from "java:net/minecraft/server/dedicated";
export * as dialog from "java:net/minecraft/server/dialog";
export * as jsonrpc from "java:net/minecraft/server/jsonrpc";
export * as level from "java:net/minecraft/server/level";
export * as network from "java:net/minecraft/server/network";
export * as notifications from "java:net/minecraft/server/notifications";
export * as packs from "java:net/minecraft/server/packs";
export * as permissions from "java:net/minecraft/server/permissions";
export * as players from "java:net/minecraft/server/players";
export * as waypoints from "java:net/minecraft/server/waypoints";

declare module "java:net/minecraft/server" {
    export class $MinecraftServer extends $ReentrantBlockableEventLoop implements $CommandSource, $ServerInfo, $ChunkIOErrorReporter, $ServerExtension {
        constructor(arg0: $Thread, arg1: $LevelStorageSource$LevelStorageAccess, arg2: $PackRepository, arg3: $WorldStem, arg4: $Optional<$GameRules>, arg5: $Proxy, arg6: $DataFixer, arg7: $Services, arg8: $LevelLoadListener, arg9: boolean, arg10: $NotificationManager);
        static ABSOLUTE_MAX_WORLD_SIZE: number;
        static ANONYMOUS_PLAYER_PROFILE: $NameAndId;
        static DEFAULT_GAME_RULES: $Supplier<$GameRules>;
        static DEMO_SETTINGS: $LevelSettings;
        static SERVER_THREAD_NAME: string;
        static SPAWN_POSITION_SEARCH_RADIUS: number;
        static VANILLA_BRAND: string;
        get absoluteMaxWorldSize(): number;
        getAbsoluteMaxWorldSize(): number;
        get advancements(): $ServerAdvancementManager;
        getAdvancements(): $ServerAdvancementManager;
        get allLevels(): $Iterable<$ServerLevel>;
        getAllLevels(): $Iterable<$ServerLevel>;
        get averageTickTimeNanos(): number;
        getAverageTickTimeNanos(): number;
        get chatDecorator(): $ChatDecorator;
        getChatDecorator(): $ChatDecorator;
        get chatSpamThresholdSeconds(): number;
        getChatSpamThresholdSeconds(): number;
        get codeOfConducts(): $Map<string, string>;
        getCodeOfConducts(): $Map<string, string>;
        get commandSpamThresholdSeconds(): number;
        getCommandSpamThresholdSeconds(): number;
        get commandStorage(): $CommandStorage;
        getCommandStorage(): $CommandStorage;
        get commands(): $Commands;
        getCommands(): $Commands;
        get compressionThreshold(): number;
        getCompressionThreshold(): number;
        get connection(): $ServerConnectionListener;
        getConnection(): $ServerConnectionListener;
        get currentSmoothedTickTime(): number;
        getCurrentSmoothedTickTime(): number;
        get customBossEvents(): $CustomBossEvents;
        getCustomBossEvents(): $CustomBossEvents;
        get dataStorage(): $SavedDataStorage;
        getDataStorage(): $SavedDataStorage;
        get defaultGameType(): $GameType;
        getDefaultGameType(): $GameType;
        set defaultGameType(value: $GameType_);
        get fixerUpper(): $DataFixer;
        getFixerUpper(): $DataFixer;
        get forcedGameType(): $GameType;
        getForcedGameType(): $GameType;
        get functionCompilationPermissions(): $PermissionSet;
        getFunctionCompilationPermissions(): $PermissionSet;
        get functions(): $ServerFunctionManager;
        getFunctions(): $ServerFunctionManager;
        get gameRules(): $GameRules;
        getGameRules(): $GameRules;
        get globalGameRules(): $GameRules;
        getGlobalGameRules(): $GameRules;
        get keyPair(): $KeyPair;
        getKeyPair(): $KeyPair;
        get levelLoadListener(): $LevelLoadListener;
        getLevelLoadListener(): $LevelLoadListener;
        get localIp(): string;
        getLocalIp(): string;
        set localIp(value: string);
        get maxChainedNeighborUpdates(): number;
        getMaxChainedNeighborUpdates(): number;
        get moddedStatus(): $ModCheck;
        getModdedStatus(): $ModCheck;
        get motd(): string;
        getMotd(): string;
        set motd(value: string);
        get nextTickTime(): number;
        getNextTickTime(): number;
        get packRepository(): $PackRepository;
        getPackRepository(): $PackRepository;
        get playerCount(): number;
        getPlayerCount(): number;
        get playerList(): $PlayerList;
        getPlayerList(): $PlayerList;
        set playerList(value: $PlayerList);
        get playerNames(): string[];
        getPlayerNames(): string[];
        get port(): number;
        getPort(): number;
        set port(value: number);
        get preventProxyConnections(): boolean;
        getPreventProxyConnections(): boolean;
        set preventProxyConnections(value: boolean);
        get proxy(): $Proxy;
        getProxy(): $Proxy;
        get randomSequences(): $RandomSequences;
        getRandomSequences(): $RandomSequences;
        get rateLimitPacketsPerSecond(): number;
        getRateLimitPacketsPerSecond(): number;
        get recipeManager(): $RecipeManager;
        getRecipeManager(): $RecipeManager;
        get resourceManager(): $ResourceManager;
        getResourceManager(): $ResourceManager;
        get respawnData(): $LevelData$RespawnData;
        getRespawnData(): $LevelData$RespawnData;
        set respawnData(value: $LevelData$RespawnData);
        get runningThread(): $Thread;
        getRunningThread(): $Thread;
        get scheduledEvents(): $TimerQueue<$MinecraftServer>;
        getScheduledEvents(): $TimerQueue<$MinecraftServer>;
        get scoreboard(): $ServerScoreboard;
        getScoreboard(): $ServerScoreboard;
        get serverActivityMonitor(): $ServerActivityMonitor;
        getServerActivityMonitor(): $ServerActivityMonitor;
        get serverDirectory(): $Path;
        getServerDirectory(): $Path;
        get serverModName(): string;
        getServerModName(): string;
        get serverResourcePack(): $Optional<$MinecraftServer$ServerResourcePackInfo>;
        getServerResourcePack(): $Optional<$MinecraftServer$ServerResourcePackInfo>;
        get serverResources(): $MinecraftServer$ReloadableResources;
        getServerResources(): $MinecraftServer$ReloadableResources;
        get serverVersion(): string;
        getServerVersion(): string;
        get singleplayerProfile(): $GameProfile;
        getSingleplayerProfile(): $GameProfile;
        set singleplayerProfile(value: $GameProfile);
        get statusJson(): string;
        getStatusJson(): string;
        get status(): $ServerStatus;
        getStatus(): $ServerStatus;
        get stopwatches(): $Stopwatches;
        getStopwatches(): $Stopwatches;
        get structureManager(): $StructureTemplateManager;
        getStructureManager(): $StructureTemplateManager;
        get tickCount(): number;
        getTickCount(): number;
        get tickTimesNanos(): number[];
        getTickTimesNanos(): number[];
        get weatherData(): $WeatherData;
        getWeatherData(): $WeatherData;
        get worldData(): $WorldData;
        getWorldData(): $WorldData;
        get worldGenSettings(): $WorldGenSettings;
        getWorldGenSettings(): $WorldGenSettings;
        get worldScreenshotFile(): $Optional<$Path>;
        getWorldScreenshotFile(): $Optional<$Path>;
        get autoSave(): boolean;
        isAutoSave(): boolean;
        set autoSave(value: boolean);
        get currentlySaving(): boolean;
        isCurrentlySaving(): boolean;
        get dedicatedServer(): boolean;
        isDedicatedServer(): boolean;
        get demo(): boolean;
        isDemo(): boolean;
        set demo(value: boolean);
        get enforceWhitelist(): boolean;
        isEnforceWhitelist(): boolean;
        set enforceWhitelist(value: boolean);
        get hardcore(): boolean;
        isHardcore(): boolean;
        get paused(): boolean;
        isPaused(): boolean;
        get published(): boolean;
        isPublished(): boolean;
        get ready(): boolean;
        isReady(): boolean;
        get recordingMetrics(): boolean;
        isRecordingMetrics(): boolean;
        get resourcePackRequired(): boolean;
        isResourcePackRequired(): boolean;
        get running(): boolean;
        isRunning(): boolean;
        get shutdown(): boolean;
        isShutdown(): boolean;
        get singleplayer(): boolean;
        isSingleplayer(): boolean;
        get stopped(): boolean;
        isStopped(): boolean;
        get tickTimeLoggingEnabled(): boolean;
        isTickTimeLoggingEnabled(): boolean;
        get timeProfilerRunning(): boolean;
        isTimeProfilerRunning(): boolean;
        get usingWhitelist(): boolean;
        isUsingWhitelist(): boolean;
        set usingWhitelist(value: boolean);
        static configurePackRepository(arg0: $PackRepository, arg1: $WorldDataConfiguration, arg2: boolean, arg3: boolean): $WorldDataConfiguration;
        static spin<S>(arg0: $Function<$Thread, S>): S;
        acceptsFailure(): boolean;
        acceptsSuccess(): boolean;
        acceptsTransfers(): boolean;
        addTickable(arg0: $Runnable): void;
        allowFlight(): boolean;
        cancelRecordingMetrics(): void;
        clockManager(): $ServerClockManager;
        close(): void;
        createChunkLoadStatusView(arg0: number): $ChunkLoadStatusView;
        createCommandSourceStack(): $CommandSourceStack;
        createGameModeForPlayer(arg0: $ServerPlayer): $ServerPlayerGameMode;
        createTextFilterForPlayer(arg0: $ServerPlayer): $TextFilter;
        debugSubscribers(): $ServerDebugSubscribers;
        dumpServerProperties(arg0: string): void;
        enforceGameTypeForPlayers(arg0: $GameType_): number;
        enforceSecureProfile(): boolean;
        executeIfPossible(arg0: $Runnable): void;
        fillServerSystemReport(arg0: $SystemReport): $SystemReport;
        fillSystemReport(arg0: $SystemReport): $SystemReport;
        findRespawnDimension(): $ServerLevel;
        finishRecordingMetrics(): void;
        forceGameTimeSynchronization(): void;
        forceSynchronousWrites(): boolean;
        forgeGetWorldMap(): $Map<$ResourceKey<$Level>, $ServerLevel>;
        fuelValues(): $FuelValues;
        getFile(arg0: string): $Path;
        getLevel(arg0: $ResourceKey<$Level>): $ServerLevel;
        getProfilePermissions(arg0: $NameAndId): $LevelBasedPermissionSet;
        getRandomSequence(arg0: $Identifier_): $RandomSource;
        getScaledTrackingDistance(arg0: number): number;
        getTickTime(arg0: $ResourceKey<$Level>): number[];
        getWorldPath(arg0: $LevelResource): $Path;
        halt(arg0: boolean): void;
        handleCustomClickAction(arg0: $Identifier_, arg1: $Optional<$Tag>, arg2: $ServerPlayer, arg3: $GameProfile): void;
        handleCustomClickAction(arg0: $Identifier_, arg1: $Optional<$Tag>): void;
        hidesOnlinePlayers(): boolean;
        invalidateStatus(): void;
        isSingleplayerOwner(arg0: $NameAndId): boolean;
        isUnderSpawnProtection(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $Player): boolean;
        kickUnlistedPlayers(): void;
        levelKeys(): $Set<$ResourceKey<$Level>>;
        logChatMessage(arg0: $Component_, arg1: $ChatType$Bound, arg2: string): void;
        logIPs(): boolean;
        markWorldsDirty(): void;
        data(): $AttachedData;
        notificationManager(): $NotificationManager;
        onGameRuleChanged<T>(arg0: $GameRule<T>, arg1: T): void;
        onTickRateChanged(): void;
        operatorUserPermissions(): $LevelBasedPermissionSet;
        overworld(): $ServerLevel;
        packetProcessor(): $PacketProcessor;
        playerIdleTimeout(): number;
        potionBrewing(): $PotionBrewing;
        publishServer(arg0: $MinecraftServer$MultiplayerScope_, arg1: $GameType_, arg2: boolean, arg3: number): boolean;
        registries(): $LayeredRegistryAccess<$RegistryLayer>;
        registryAccess(): $RegistryAccess$Frozen;
        reloadResources(arg0: string[]): $CompletableFuture<void>;
        reloadableRegistries(): $ReloadableServerRegistries$Holder;
        repliesToStatus(): boolean;
        reportChunkLoadFailure(arg0: $Throwable, arg1: $RegionStorageInfo, arg2: $ChunkPos): void;
        reportChunkSaveFailure(arg0: $Throwable, arg1: $RegionStorageInfo, arg2: $ChunkPos): void;
        reportPacketHandlingException(arg0: $Throwable, arg1: $PacketType<any>): void;
        saveAllChunks(arg0: boolean, arg1: boolean, arg2: boolean): boolean;
        saveEverything(arg0: boolean, arg1: boolean, arg2: boolean): boolean;
        scheduleExecutables(): boolean;
        sendLowDiskSpaceWarning(): void;
        sendSystemMessage(arg0: $Component_): void;
        serverLinks(): $ServerLinks;
        services(): $Services;
        setDifficulty(arg0: $Difficulty_, arg1: boolean): void;
        setWeatherParameters(arg0: number, arg1: number, arg2: boolean, arg3: boolean): void;
        shouldInformAdmins(): boolean;
        shouldRconBroadcast(): boolean;
        startRecordingMetrics(arg0: $Consumer<$ProfileResults>, arg1: $Consumer<string>): void;
        startTimeProfiler(): void;
        stopRecordingMetrics(): void;
        stopTimeProfiler(): $ProfileResults;
        tickRateManager(): $ServerTickRateManager;
        unpublishServer(): boolean;
        updateMobSpawningFlags(): void;
        useNativeTransport(): boolean;
        usesAuthentication(): boolean;
        wrapRunnable(arg0: $Runnable): $TickTask;
    }

    export class $MinecraftServer$MultiplayerScope {
        static LAN: $MinecraftServer$MultiplayerScope;
        static OFF: $MinecraftServer$MultiplayerScope;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MinecraftServer$MultiplayerScope[];
        static valueOf(name: string): $MinecraftServer$MultiplayerScope;
    }

    export class $MinecraftServer$ReloadableResources extends $Record implements $AutoCloseable {
        constructor(resourceManager: $CloseableResourceManager, managers: $ReloadableServerResources);
        close(): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        managers(): $ReloadableServerResources;
        resourceManager(): $CloseableResourceManager;
        toString(): string;
    }

    export class $MinecraftServer$ServerResourcePackInfo extends $Record {
        constructor(id: string, url: string, hash: string, isRequired: boolean, prompt: $Component_);
        get required(): boolean;
        isRequired(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        hash(): string;
        id(): $UUID;
        prompt(): $Component;
        toString(): string;
        url(): string;
    }

    export class $PlayerAdvancements {
        constructor(arg0: $DataFixer, arg1: $PlayerList, arg2: $ServerAdvancementManager, arg3: string, arg4: $ServerPlayer);
        award(arg0: $AdvancementHolder, arg1: string): boolean;
        clearTriggers(): void;
        flushDirty(arg0: $ServerPlayer, arg1: boolean): void;
        getOrStartProgress(arg0: $AdvancementHolder): $AdvancementProgress;
        getTriggerMapForType<T>(arg0: $CriterionTrigger<T>): $Map<$PlayerAdvancements$TriggerInstanceKey, T>;
        reload(arg0: $ServerAdvancementManager): void;
        revoke(arg0: $AdvancementHolder, arg1: string): boolean;
        save(): void;
    }

    export class $PlayerAdvancements$TriggerInstanceKey extends $Record {
        constructor(advancement: $AdvancementHolder, criterion: string);
        advancement(): $AdvancementHolder;
        criterion(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $RegistryLayer {
        static DIMENSIONS: $RegistryLayer;
        static RELOADABLE: $RegistryLayer;
        static STATIC: $RegistryLayer;
        static WORLDGEN: $RegistryLayer;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RegistryLayer[];
        static valueOf(name: string): $RegistryLayer;
    }

    export class $ReloadableServerRegistries$Holder {
        constructor(arg0: $HolderLookup$Provider);
        getLootTable(arg0: $ResourceKey<$LootTable>): $LootTable;
        lookup(): $HolderLookup$Provider;
    }

    export class $ReloadableServerResources {
        get advancements(): $ServerAdvancementManager;
        getAdvancements(): $ServerAdvancementManager;
        get commands(): $Commands;
        getCommands(): $Commands;
        get conditionContext(): $ICondition$IContext;
        getConditionContext(): $ICondition$IContext;
        get functionLibrary(): $ServerFunctionLibrary;
        getFunctionLibrary(): $ServerFunctionLibrary;
        get recipeManager(): $RecipeManager;
        getRecipeManager(): $RecipeManager;
        get registryLookup(): $HolderLookup$Provider;
        getRegistryLookup(): $HolderLookup$Provider;
        static loadResources(arg0: $ResourceManager, arg1: $LayeredRegistryAccess<$RegistryLayer_>, arg2: $Registry$PendingTags<any>[], arg3: $FeatureFlagSet, arg4: $Commands$CommandSelection_, arg5: $PermissionSet, arg6: $Executor, arg7: $Executor): $CompletableFuture<$ReloadableServerResources>;
        fullRegistries(): $ReloadableServerRegistries$Holder;
        getListener<T>(arg0: $ListenerKey<T>): T;
        listeners(): $List<$PreparableReloadListener>;
        updateComponentsAndStaticRegistryTags(): void;
    }

    export class $ServerAdvancementManager extends $SimpleJsonResourceReloadListener {
        constructor(arg0: $HolderLookup$Provider);
        get allAdvancements(): $Collection<$AdvancementHolder>;
        getAllAdvancements(): $Collection<$AdvancementHolder>;
        get(arg0: $Identifier_): $AdvancementHolder;
        tree(): $AdvancementTree;
    }

    export class $ServerFunctionLibrary implements $PreparableReloadListener {
        constructor(arg0: $PermissionSet, arg1: $CommandDispatcher<$CommandSourceStack>);
        static TYPE_KEY: $ResourceKey<$Registry<$CommandFunction<$CommandSourceStack>>>;
        get availableTags(): $Iterable<$Identifier>;
        getAvailableTags(): $Iterable<$Identifier>;
        get functions(): $Map<$Identifier, $CommandFunction<$CommandSourceStack>>;
        getFunctions(): $Map<$Identifier, $CommandFunction<$CommandSourceStack>>;
        getFunction(arg0: $Identifier_): $Optional<$CommandFunction<$CommandSourceStack>>;
        getTag(arg0: $Identifier_): $List<$CommandFunction<$CommandSourceStack>>;
        reload(arg0: $PreparableReloadListener$SharedState, arg1: $Executor, arg2: $PreparableReloadListener$PreparationBarrier, arg3: $Executor): $CompletableFuture<void>;
    }

    export class $ServerFunctionManager {
        constructor(arg0: $MinecraftServer, arg1: $ServerFunctionLibrary);
        get dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        getDispatcher(): $CommandDispatcher<$CommandSourceStack>;
        get functionNames(): $Iterable<$Identifier>;
        getFunctionNames(): $Iterable<$Identifier>;
        get gameLoopSender(): $CommandSourceStack;
        getGameLoopSender(): $CommandSourceStack;
        get tagNames(): $Iterable<$Identifier>;
        getTagNames(): $Iterable<$Identifier>;
        execute(arg0: $CommandFunction<$CommandSourceStack>, arg1: $CommandSourceStack): void;
        getTag(arg0: $Identifier_): $List<$CommandFunction<$CommandSourceStack>>;
        get(arg0: $Identifier_): $Optional<$CommandFunction<$CommandSourceStack>>;
        replaceLibrary(arg0: $ServerFunctionLibrary): void;
        tick(): void;
    }

    export interface $ServerInfo {
        getMaxPlayers(): number;
        getMotd(): string;
        getPlayerCount(): number;
        getServerVersion(): string;
    }

    export interface $ServerInterface extends $ServerInfo {
        getLevelIdName(): string;
        getPlayerNames(): string[];
        getPluginNames(): string;
        getProperties(): $DedicatedServerProperties;
        getServerIp(): string;
        getServerName(): string;
        getServerPort(): number;
        runCommand(arg0: string): string;
    }

    export class $ServerLinks extends $Record {
        constructor(entries: $ServerLinks$Entry[]);
        static EMPTY: $ServerLinks;
        static TYPE_STREAM_CODEC: $StreamCodec<$ByteBuf, $Either<$ServerLinks$KnownLinkType, $Component>>;
        static UNTRUSTED_LINKS_STREAM_CODEC: $StreamCodec<$ByteBuf, $List<$ServerLinks$UntrustedEntry>>;
        get empty(): boolean;
        isEmpty(): boolean;
        entries(): $List<$ServerLinks$Entry>;
        equals(arg0: object): boolean;
        findKnownType(arg0: $ServerLinks$KnownLinkType_): $Optional<$ServerLinks$Entry>;
        hashCode(): number;
        toString(): string;
        untrust(): $List<$ServerLinks$UntrustedEntry>;
    }

    export class $ServerLinks$Entry extends $Record {
        constructor(type: $Either<$ServerLinks$KnownLinkType_, $Component_>, link: $URI);
        static custom(arg0: $Component_, arg1: $URI): $ServerLinks$Entry;
        static knownType(arg0: $ServerLinks$KnownLinkType_, arg1: $URI): $ServerLinks$Entry;
        displayName(): $Component;
        equals(arg0: object): boolean;
        hashCode(): number;
        link(): $URI;
        toString(): string;
        type(): $Either<$ServerLinks$KnownLinkType, $Component>;
    }

    export class $ServerLinks$KnownLinkType {
        static ANNOUNCEMENTS: $ServerLinks$KnownLinkType;
        static BUG_REPORT: $ServerLinks$KnownLinkType;
        static COMMUNITY: $ServerLinks$KnownLinkType;
        static COMMUNITY_GUIDELINES: $ServerLinks$KnownLinkType;
        static FEEDBACK: $ServerLinks$KnownLinkType;
        static FORUMS: $ServerLinks$KnownLinkType;
        static NEWS: $ServerLinks$KnownLinkType;
        static STATUS: $ServerLinks$KnownLinkType;
        static SUPPORT: $ServerLinks$KnownLinkType;
        static WEBSITE: $ServerLinks$KnownLinkType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerLinks$KnownLinkType[];
        static valueOf(name: string): $ServerLinks$KnownLinkType;
    }

    export class $ServerLinks$UntrustedEntry extends $Record {
        constructor(type: $Either<$ServerLinks$KnownLinkType_, $Component_>, link: string);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerLinks$UntrustedEntry>;
        equals(arg0: object): boolean;
        hashCode(): number;
        link(): string;
        toString(): string;
        type(): $Either<$ServerLinks$KnownLinkType, $Component>;
    }

    export class $ServerScoreboard extends $Scoreboard {
        constructor(arg0: $MinecraftServer);
        addPlayerToTeam(arg0: string, arg1: $PlayerTeam): boolean;
        getObjectiveDisplaySlotCount(arg0: $Objective): number;
        getStartTrackingPackets(arg0: $Objective): $List<$Packet<any>>;
        getStopTrackingPackets(arg0: $Objective): $List<$Packet<any>>;
        load(arg0: $ScoreboardSaveData$Packed): void;
        onObjectiveAdded(arg0: $Objective): void;
        onObjectiveChanged(arg0: $Objective): void;
        onObjectiveRemoved(arg0: $Objective): void;
        onPlayerRemoved(arg0: $ScoreHolder): void;
        onPlayerScoreRemoved(arg0: $ScoreHolder, arg1: $Objective): void;
        onTeamAdded(arg0: $PlayerTeam): void;
        onTeamChanged(arg0: $PlayerTeam): void;
        onTeamRemoved(arg0: $PlayerTeam): void;
        removePlayerFromTeam(arg0: string, arg1: $PlayerTeam): void;
        setDisplayObjective(arg0: $DisplaySlot_, arg1: $Objective): void;
        startTrackingObjective(arg0: $Objective): void;
        stopTrackingObjective(arg0: $Objective): void;
        storeToSaveDataIfDirty(arg0: $ScoreboardSaveData): void;
    }

    export class $ServerTickRateManager extends $TickRateManager {
        constructor(arg0: $MinecraftServer);
        get sprinting(): boolean;
        isSprinting(): boolean;
        checkShouldSprintThisTick(): boolean;
        endTickWork(): void;
        requestGameToSprint(arg0: number): boolean;
        stepGameIfPaused(arg0: number): boolean;
        stopSprinting(): boolean;
        stopStepping(): boolean;
        updateJoiningPlayer(arg0: $ServerPlayer): void;
    }

    export class $Services extends $Record {
        constructor(sessionService: $MinecraftSessionService, servicesKeySet: $ServicesKeySet, profileRepository: $GameProfileRepository, nameToIdCache: $UserNameToIdResolver, profileResolver: $ProfileResolver);
        static create(arg0: $YggdrasilAuthenticationService, arg1: string): $Services;
        canValidateProfileKeys(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        nameToIdCache(): $UserNameToIdResolver;
        profileKeySignatureValidator(): $SignatureValidator;
        profileRepository(): $GameProfileRepository;
        profileResolver(): $ProfileResolver;
        servicesKeySet(): $ServicesKeySet;
        sessionService(): $MinecraftSessionService;
        toString(): string;
    }

    export class $TickTask implements $Runnable {
        constructor(arg0: number, arg1: $Runnable);
        get tick(): number;
        getTick(): number;
        run(): void;
    }

    export class $WorldLoader$PackConfig extends $Record {
        constructor(packRepository: $PackRepository, initialDataConfig: $WorldDataConfiguration, safeMode: boolean, initMode: boolean);
        createResourceManager(): $Pair<$WorldDataConfiguration, $CloseableResourceManager>;
        equals(arg0: object): boolean;
        hashCode(): number;
        initMode(): boolean;
        initialDataConfig(): $WorldDataConfiguration;
        packRepository(): $PackRepository;
        safeMode(): boolean;
        toString(): string;
    }

    export class $WorldStem extends $Record implements $AutoCloseable {
        constructor(resourceManager: $CloseableResourceManager, dataPackResources: $ReloadableServerResources, registries: $LayeredRegistryAccess<$RegistryLayer_>, worldDataAndGenSettings: $LevelDataAndDimensions$WorldDataAndGenSettings);
        close(): void;
        dataPackResources(): $ReloadableServerResources;
        equals(arg0: object): boolean;
        hashCode(): number;
        registries(): $LayeredRegistryAccess<$RegistryLayer>;
        resourceManager(): $CloseableResourceManager;
        toString(): string;
        worldDataAndGenSettings(): $LevelDataAndDimensions$WorldDataAndGenSettings;
    }

    export type $MinecraftServer$MultiplayerScope_ = $MinecraftServer$MultiplayerScope | "LAN" | "OFF";
    export type $RegistryLayer_ = $RegistryLayer | "DIMENSIONS" | "RELOADABLE" | "STATIC" | "WORLDGEN";
    export type $ServerLinks$KnownLinkType_ = $ServerLinks$KnownLinkType | "ANNOUNCEMENTS" | "BUG_REPORT" | "COMMUNITY" | "COMMUNITY_GUIDELINES" | "FEEDBACK" | "FORUMS" | "NEWS" | "STATUS" | "SUPPORT" | "WEBSITE";
}
