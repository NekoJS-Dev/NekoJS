import { $Command, $RedirectModifier, $SingleRedirectModifier } from "java:com/mojang/brigadier";
import { $ArgumentType } from "java:com/mojang/brigadier/arguments";
import { $SuggestionProvider } from "java:com/mojang/brigadier/suggestion";
import { $ArgumentCommandNode, $CommandNode, $LiteralCommandNode } from "java:com/mojang/brigadier/tree";
import { $String } from "java:java/lang";
import { $Collection } from "java:java/util";
import { $Predicate } from "java:java/util/function";

declare module "java:com/mojang/brigadier/builder" {
    export class $ArgumentBuilder<S, T extends $ArgumentBuilder<S, T>> {
        constructor();
        get arguments(): $Collection<$CommandNode<S>>;
        getArguments(): $Collection<$CommandNode<S>>;
        get command(): $Command<S>;
        getCommand(): $Command<S>;
        get redirectModifier(): $RedirectModifier<S>;
        getRedirectModifier(): $RedirectModifier<S>;
        get redirect(): $CommandNode<S>;
        getRedirect(): $CommandNode<S>;
        get requirement(): $Predicate<S>;
        getRequirement(): $Predicate<S>;
        get fork(): boolean;
        isFork(): boolean;
        build(): $CommandNode<S>;
        executes(arg0: $Command<S>): T;
        fork(arg0: $CommandNode<S>, arg1: $RedirectModifier<S>): T;
        forward(arg0: $CommandNode<S>, arg1: $RedirectModifier<S>, arg2: boolean): T;
        redirect(arg0: $CommandNode<S>, arg1: $SingleRedirectModifier<S>): T;
        redirect(arg0: $CommandNode<S>): T;
        requires(arg0: $Predicate<S>): T;
        then(arg0: $ArgumentBuilder<S, any>): T;
        then(arg0: $CommandNode<S>): T;
    }

    export class $LiteralArgumentBuilder<S> extends $ArgumentBuilder {
        get literal(): string;
        getLiteral(): string;
        static literal<S>(arg0: string): $LiteralArgumentBuilder<S>;
        build(): $LiteralCommandNode<S>;
    }

    export class $RequiredArgumentBuilder<S, T> extends $ArgumentBuilder {
        get name(): string;
        getName(): string;
        get suggestionsProvider(): $SuggestionProvider<S>;
        getSuggestionsProvider(): $SuggestionProvider<S>;
        get type(): $ArgumentType<T>;
        getType(): $ArgumentType<T>;
        static argument<S, T>(arg0: string, arg1: $ArgumentType<T>): $RequiredArgumentBuilder<S, T>;
        build(): $ArgumentCommandNode<S, T>;
        suggests(arg0: $SuggestionProvider<S>): $RequiredArgumentBuilder<S, T>;
    }

}
