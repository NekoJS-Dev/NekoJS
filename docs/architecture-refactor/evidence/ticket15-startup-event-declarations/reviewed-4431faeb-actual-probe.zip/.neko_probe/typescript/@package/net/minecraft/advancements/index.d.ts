import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $Comparable, $Enum, $Iterable, $Record, $String } from "java:java/lang";
import { $Instant } from "java:java/time";
import { $Collection, $List, $Map, $Optional, $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $Criterion } from "java:net/minecraft/advancements/triggers";
import { $CacheableFunction } from "java:net/minecraft/commands";
import { $ClientAsset$ResourceTexture, $HolderGetter$Provider } from "java:net/minecraft/core";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $MutableComponent } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $ProblemReporter, $StringRepresentable } from "java:net/minecraft/util";
import { $ItemStackTemplate } from "java:net/minecraft/world/item";
import { $Recipe } from "java:net/minecraft/world/item/crafting";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $WithConditions } from "java:net/neoforged/neoforge/common/conditions";

export * as predicates from "java:net/minecraft/advancements/predicates";
export * as triggers from "java:net/minecraft/advancements/triggers";

declare module "java:net/minecraft/advancements" {
    export class $Advancement extends $Record {
        constructor(arg0: $Optional<$Identifier_>, arg1: $Optional<$DisplayInfo>, arg2: $AdvancementRewards, arg3: { [key: string]: $Criterion<any> }, arg4: $AdvancementRequirements, arg5: boolean);
        constructor(parent: $Optional<$Identifier_>, display: $Optional<$DisplayInfo>, rewards: $AdvancementRewards, criteria: { [key: string]: $Criterion<any> }, requirements: $AdvancementRequirements, sendsTelemetryEvent: boolean, name: $Optional<$Component_>);
        static CODEC: $Codec<$Advancement>;
        static CONDITIONAL_CODEC: $Codec<$Optional<$WithConditions<$Advancement>>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Advancement>;
        get root(): boolean;
        isRoot(): boolean;
        static name(arg0: $AdvancementHolder): $Component;
        criteria(): $Map<string, $Criterion<any>>;
        display(): $Optional<$DisplayInfo>;
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        parent(): $Optional<$Identifier>;
        requirements(): $AdvancementRequirements;
        rewards(): $AdvancementRewards;
        sendsTelemetryEvent(): boolean;
        toString(): string;
        validate(arg0: $ProblemReporter, arg1: $HolderGetter$Provider): void;
    }

    export class $AdvancementHolder extends $Record {
        constructor(id: $Identifier_, value: $Advancement);
        static LIST_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $List<$AdvancementHolder>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $AdvancementHolder>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
        value(): $Advancement;
    }

    export class $AdvancementNode {
        constructor(arg0: $AdvancementHolder, arg1: $AdvancementNode);
        static getRoot(arg0: $AdvancementNode): $AdvancementNode;
        addChild(arg0: $AdvancementNode): void;
        advancement(): $Advancement;
        children(): $Iterable<$AdvancementNode>;
        equals(arg0: object): boolean;
        hashCode(): number;
        holder(): $AdvancementHolder;
        parent(): $AdvancementNode;
        root(): $AdvancementNode;
        toString(): string;
    }

    export class $AdvancementProgress implements $Comparable {
        constructor();
        static CODEC: $Codec<$AdvancementProgress>;
        get completedCriteria(): $Iterable<string>;
        getCompletedCriteria(): $Iterable<string>;
        get firstProgressDate(): $Instant;
        getFirstProgressDate(): $Instant;
        get percent(): number;
        getPercent(): number;
        get progressText(): $Component;
        getProgressText(): $Component;
        get remainingCriteria(): $Iterable<string>;
        getRemainingCriteria(): $Iterable<string>;
        get done(): boolean;
        isDone(): boolean;
        static fromNetwork(arg0: $FriendlyByteBuf): $AdvancementProgress;
        compareTo(arg0: $AdvancementProgress): number;
        getCriterion(arg0: string): $CriterionProgress;
        grantProgress(arg0: string): boolean;
        hasProgress(): boolean;
        revokeProgress(arg0: string): boolean;
        serializeToNetwork(arg0: $FriendlyByteBuf): void;
        toString(): string;
        update(arg0: $AdvancementRequirements): void;
    }

    export class $AdvancementRequirements extends $Record {
        constructor(requirements: string[][]);
        constructor(arg0: $FriendlyByteBuf);
        static CODEC: $Codec<$AdvancementRequirements>;
        static EMPTY: $AdvancementRequirements;
        get empty(): boolean;
        isEmpty(): boolean;
        static allOf(arg0: string[]): $AdvancementRequirements;
        static anyOf(arg0: string[]): $AdvancementRequirements;
        count(arg0: $Predicate<string>): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        names(): $Set<string>;
        requirements(): $List<$List<string>>;
        size(): number;
        test(arg0: $Predicate<string>): boolean;
        toString(): string;
        validate(arg0: string[]): $DataResult<$AdvancementRequirements>;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $AdvancementRewards extends $Record {
        constructor(experience: number, loot: $ResourceKey<$LootTable>[], recipes: $ResourceKey<$Recipe<any>>[], function_: $Optional<$CacheableFunction>);
        static CODEC: $Codec<$AdvancementRewards>;
        static EMPTY: $AdvancementRewards;
        equals(arg0: object): boolean;
        experience(): number;
        function(): $Optional<$CacheableFunction>;
        grant(arg0: $ServerPlayer): void;
        hashCode(): number;
        loot(): $List<$ResourceKey<$LootTable>>;
        recipes(): $List<$ResourceKey<$Recipe<any>>>;
        toString(): string;
    }

    export class $AdvancementTree {
        constructor();
        addAll(arg0: $AdvancementHolder[]): void;
        clear(): void;
        get(arg0: $AdvancementHolder): $AdvancementNode;
        get(arg0: $Identifier_): $AdvancementNode;
        nodes(): $Collection<$AdvancementNode>;
        remove(arg0: $Identifier_[]): void;
        roots(): $Iterable<$AdvancementNode>;
    }

    export interface $AdvancementTree$Listener {
        onAddAdvancementRoot(arg0: $AdvancementNode): void;
        onAddAdvancementTask(arg0: $AdvancementNode): void;
        onAdvancementsCleared(): void;
        onRemoveAdvancementRoot(arg0: $AdvancementNode): void;
        onRemoveAdvancementTask(arg0: $AdvancementNode): void;
    }

    export class $AdvancementType {
        static CHALLENGE: $AdvancementType;
        static GOAL: $AdvancementType;
        static TASK: $AdvancementType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AdvancementType[];
        static valueOf(name: string): $AdvancementType;
    }

    export class $CriterionProgress {
        constructor();
        constructor(arg0: $Instant);
        get obtained(): $Instant;
        getObtained(): $Instant;
        get done(): boolean;
        isDone(): boolean;
        static fromNetwork(arg0: $FriendlyByteBuf): $CriterionProgress;
        grant(): void;
        revoke(): void;
        serializeToNetwork(arg0: $FriendlyByteBuf): void;
        toString(): string;
    }

    export class $DisplayInfo {
        constructor(arg0: $ItemStackTemplate, arg1: $Component_, arg2: $Component_, arg3: $Optional<$ClientAsset$ResourceTexture>, arg4: $AdvancementType_, arg5: boolean, arg6: boolean, arg7: boolean);
        static CODEC: $Codec<$DisplayInfo>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DisplayInfo>;
        get background(): $Optional<$ClientAsset$ResourceTexture>;
        getBackground(): $Optional<$ClientAsset$ResourceTexture>;
        get description(): $Component;
        getDescription(): $Component;
        get icon(): $ItemStackTemplate;
        getIcon(): $ItemStackTemplate;
        get title(): $Component;
        getTitle(): $Component;
        get type(): $AdvancementType;
        getType(): $AdvancementType;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get hidden(): boolean;
        isHidden(): boolean;
        setLocation(arg0: number, arg1: number): void;
        shouldAnnounceChat(): boolean;
        shouldShowToast(): boolean;
    }

    export type $AdvancementType_ = $AdvancementType | "CHALLENGE" | "GOAL" | "TASK";
}
