declare module "java:java/security/spec" {
    export interface $AlgorithmParameterSpec {
    }

}
