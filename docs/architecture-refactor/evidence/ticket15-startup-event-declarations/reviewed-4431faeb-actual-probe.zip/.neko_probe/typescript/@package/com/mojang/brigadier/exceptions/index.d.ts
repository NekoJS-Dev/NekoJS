import { $ImmutableStringReader, $Message } from "java:com/mojang/brigadier";
import { $Exception, $String } from "java:java/lang";

declare module "java:com/mojang/brigadier/exceptions" {
    export interface $BuiltInExceptionProvider {
        dispatcherExpectedArgumentSeparator(): $SimpleCommandExceptionType;
        dispatcherParseException(): $DynamicCommandExceptionType;
        dispatcherUnknownArgument(): $SimpleCommandExceptionType;
        dispatcherUnknownCommand(): $SimpleCommandExceptionType;
        doubleTooHigh(): $Dynamic2CommandExceptionType;
        doubleTooLow(): $Dynamic2CommandExceptionType;
        floatTooHigh(): $Dynamic2CommandExceptionType;
        floatTooLow(): $Dynamic2CommandExceptionType;
        integerTooHigh(): $Dynamic2CommandExceptionType;
        integerTooLow(): $Dynamic2CommandExceptionType;
        literalIncorrect(): $DynamicCommandExceptionType;
        longTooHigh(): $Dynamic2CommandExceptionType;
        longTooLow(): $Dynamic2CommandExceptionType;
        readerExpectedBool(): $SimpleCommandExceptionType;
        readerExpectedDouble(): $SimpleCommandExceptionType;
        readerExpectedEndOfQuote(): $SimpleCommandExceptionType;
        readerExpectedFloat(): $SimpleCommandExceptionType;
        readerExpectedInt(): $SimpleCommandExceptionType;
        readerExpectedLong(): $SimpleCommandExceptionType;
        readerExpectedStartOfQuote(): $SimpleCommandExceptionType;
        readerExpectedSymbol(): $DynamicCommandExceptionType;
        readerInvalidBool(): $DynamicCommandExceptionType;
        readerInvalidDouble(): $DynamicCommandExceptionType;
        readerInvalidEscape(): $DynamicCommandExceptionType;
        readerInvalidFloat(): $DynamicCommandExceptionType;
        readerInvalidInt(): $DynamicCommandExceptionType;
        readerInvalidLong(): $DynamicCommandExceptionType;
    }

    export interface $CommandExceptionType {
    }

    export class $CommandSyntaxException extends $Exception {
        constructor(arg0: $CommandExceptionType, arg1: $Message);
        constructor(arg0: $CommandExceptionType, arg1: $Message, arg2: string, arg3: number);
        static BUILT_IN_EXCEPTIONS: $BuiltInExceptionProvider;
        static CONTEXT_AMOUNT: number;
        static ENABLE_COMMAND_STACK_TRACES: boolean;
        get context(): string;
        getContext(): string;
        get cursor(): number;
        getCursor(): number;
        get input(): string;
        getInput(): string;
        get message(): string;
        getMessage(): string;
        get rawMessage(): $Message;
        getRawMessage(): $Message;
        get type(): $CommandExceptionType;
        getType(): $CommandExceptionType;
    }

    export class $Dynamic2CommandExceptionType implements $CommandExceptionType {
        constructor(arg0: $Dynamic2CommandExceptionType$Function);
        createWithContext(arg0: $ImmutableStringReader, arg1: object, arg2: object): $CommandSyntaxException;
        create(arg0: object, arg1: object): $CommandSyntaxException;
    }

    export interface $Dynamic2CommandExceptionType$Function {
        apply(arg0: object, arg1: object): $Message;
    }

    export class $DynamicCommandExceptionType implements $CommandExceptionType {
        constructor(arg0: $Function<object, $Message>);
        createWithContext(arg0: $ImmutableStringReader, arg1: object): $CommandSyntaxException;
        create(arg0: object): $CommandSyntaxException;
    }

    export class $SimpleCommandExceptionType implements $CommandExceptionType {
        constructor(arg0: $Message);
        createWithContext(arg0: $ImmutableStringReader): $CommandSyntaxException;
        create(): $CommandSyntaxException;
        toString(): string;
    }

}
