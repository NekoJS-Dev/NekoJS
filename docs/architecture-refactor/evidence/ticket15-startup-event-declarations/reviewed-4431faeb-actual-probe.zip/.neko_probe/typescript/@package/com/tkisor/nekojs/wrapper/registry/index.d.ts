export * as gen from "java:com/tkisor/nekojs/wrapper/registry/gen";

