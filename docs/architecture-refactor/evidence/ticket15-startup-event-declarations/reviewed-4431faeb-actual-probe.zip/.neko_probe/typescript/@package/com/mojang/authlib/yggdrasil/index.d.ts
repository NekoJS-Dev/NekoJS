import { $Environment, $GameProfile, $GameProfileRepository, $HttpAuthenticationService } from "java:com/mojang/authlib";
import { $MinecraftSessionService, $UserApiService } from "java:com/mojang/authlib/minecraft";
import { $Property } from "java:com/mojang/authlib/properties";
import { $FriendData, $PresenceResponse } from "java:com/mojang/authlib/yggdrasil/response";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Proxy } from "java:java/net";
import { $Signature } from "java:java/security";
import { $Duration } from "java:java/time";
import { $Collection, $Optional, $Set, $UUID } from "java:java/util";
import { $Consumer, $Supplier } from "java:java/util/function";

export * as request from "java:com/mojang/authlib/yggdrasil/request";
export * as response from "java:com/mojang/authlib/yggdrasil/response";

declare module "java:com/mojang/authlib/yggdrasil" {
    export interface $FriendsService {
        acceptIncomingFriendRequest(arg0: string): $FriendsService$ResultCode;
        declineIncomingFriendRequest(arg0: string): $FriendsService$ResultCode;
        getFriendData(arg0: $Consumer<$FriendData>): $FriendsService$ResultCode;
        getFriendsPollInterval(): $Optional<$Duration>;
        getPresencePollInterval(): $Optional<$Duration>;
        presence(arg0: string): $PresenceResponse;
        removeFriend(arg0: string): $FriendsService$ResultCode;
        revokeOutgoingFriendRequest(arg0: string): $FriendsService$ResultCode;
        sendFriendRequest(arg0: string): $FriendsService$ResultCode;
        sendFriendRequest(arg0: string): $FriendsService$ResultCode;
        updateFriendSettings(arg0: boolean, arg1: boolean): $FriendsService$ResultCode;
    }

    export class $FriendsService$ResultCode {
        static CONNECTION_ISSUE: $FriendsService$ResultCode;
        static ERROR: $FriendsService$ResultCode;
        static FORBIDDEN: $FriendsService$ResultCode;
        static GENERIC_ERROR: $FriendsService$ResultCode;
        static SERVICE_NOT_AVAILABLE: $FriendsService$ResultCode;
        static SUCCESS: $FriendsService$ResultCode;
        static TEMPORARY_UNAVAILABLE: $FriendsService$ResultCode;
        static TOO_MANY_REQUESTS: $FriendsService$ResultCode;
        static UNAUTHORIZED: $FriendsService$ResultCode;
        static UNKNOWN_PROFILE: $FriendsService$ResultCode;
        static UPGRADE_NEEDED: $FriendsService$ResultCode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $FriendsService$ResultCode[];
        static valueOf(name: string): $FriendsService$ResultCode;
    }

    export class $ProfileActionType {
        static FORCED_NAME_CHANGE: $ProfileActionType;
        static USING_BANNED_SKIN: $ProfileActionType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ProfileActionType[];
        static valueOf(name: string): $ProfileActionType;
    }

    export class $ProfileResult extends $Record {
        constructor(arg0: $GameProfile);
        constructor(profile: $GameProfile, actions: $ProfileActionType_[]);
        actions(): $Set<$ProfileActionType>;
        equals(arg0: object): boolean;
        hashCode(): number;
        profile(): $GameProfile;
        toString(): string;
    }

    export interface $ServicesKeyInfo {
        keyBitCount(): number;
        signatureBitCount(): number;
        signature(): $Signature;
        validateProperty(arg0: $Property): boolean;
    }

    export interface $ServicesKeySet {
        keys(arg0: $ServicesKeyType_): $Collection<$ServicesKeyInfo>;
        lazy(arg0: $Supplier<$ServicesKeySet>): $ServicesKeySet;
        static EMPTY: $ServicesKeySet;
    }

    export class $ServicesKeyType {
        static PROFILE_KEY: $ServicesKeyType;
        static PROFILE_PROPERTY: $ServicesKeyType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServicesKeyType[];
        static valueOf(name: string): $ServicesKeyType;
    }

    export class $YggdrasilAuthenticationService extends $HttpAuthenticationService {
        constructor(arg0: $Proxy);
        constructor(arg0: $Proxy, arg1: $Environment);
        get servicesKeySet(): $ServicesKeySet;
        getServicesKeySet(): $ServicesKeySet;
        static createOffline(arg0: $Proxy, arg1: $Environment): $YggdrasilAuthenticationService;
        static createOffline(arg0: $Proxy): $YggdrasilAuthenticationService;
        createFriendsService(arg0: string): $FriendsService;
        createMinecraftSessionService(): $MinecraftSessionService;
        createProfileRepository(): $GameProfileRepository;
        createUserApiService(arg0: string): $UserApiService;
    }

    export type $FriendsService$ResultCode_ = $FriendsService$ResultCode | "CONNECTION_ISSUE" | "ERROR" | "FORBIDDEN" | "GENERIC_ERROR" | "SERVICE_NOT_AVAILABLE" | "SUCCESS" | "TEMPORARY_UNAVAILABLE" | "TOO_MANY_REQUESTS" | "UNAUTHORIZED" | "UNKNOWN_PROFILE" | "UPGRADE_NEEDED";
    export type $ProfileActionType_ = $ProfileActionType | "FORCED_NAME_CHANGE" | "USING_BANNED_SKIN";
    export type $ServicesKeyType_ = $ServicesKeyType | "PROFILE_KEY" | "PROFILE_PROPERTY";
}
