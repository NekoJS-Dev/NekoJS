import { $String } from "java:java/lang";
import { $DedicatedServer } from "java:net/minecraft/server/dedicated";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $IpBanListEntry, $NameAndId, $ServerOpListEntry, $UserBanListEntry } from "java:net/minecraft/server/players";
import { $GameRule } from "java:net/minecraft/world/level/gamerules";

declare module "java:net/minecraft/server/notifications" {
    export class $NotificationManager implements $NotificationService {
        constructor();
        ipBanned(arg0: $IpBanListEntry): void;
        ipUnbanned(arg0: string): void;
        onGameRuleChanged<T>(arg0: $GameRule<T>, arg1: T): void;
        playerAddedToAllowlist(arg0: $NameAndId): void;
        playerBanned(arg0: $UserBanListEntry): void;
        playerDeoped(arg0: $ServerOpListEntry): void;
        playerJoined(arg0: $ServerPlayer): void;
        playerLeft(arg0: $ServerPlayer): void;
        playerOped(arg0: $ServerOpListEntry): void;
        playerRemovedFromAllowlist(arg0: $NameAndId): void;
        playerUnbanned(arg0: $NameAndId): void;
        registerService(arg0: $NotificationService): void;
        serverActivityOccured(): void;
        serverSaveCompleted(): void;
        serverSaveStarted(): void;
        serverShuttingDown(): void;
        serverStarted(): void;
        server(): $DedicatedServer;
        statusHeartbeat(): void;
    }

    export interface $NotificationService {
        ipBanned(arg0: $IpBanListEntry): void;
        ipUnbanned(arg0: string): void;
        onGameRuleChanged<T>(arg0: $GameRule<T>, arg1: T): void;
        playerAddedToAllowlist(arg0: $NameAndId): void;
        playerBanned(arg0: $UserBanListEntry): void;
        playerDeoped(arg0: $ServerOpListEntry): void;
        playerJoined(arg0: $ServerPlayer): void;
        playerLeft(arg0: $ServerPlayer): void;
        playerOped(arg0: $ServerOpListEntry): void;
        playerRemovedFromAllowlist(arg0: $NameAndId): void;
        playerUnbanned(arg0: $NameAndId): void;
        serverActivityOccured(): void;
        serverSaveCompleted(): void;
        serverSaveStarted(): void;
        serverShuttingDown(): void;
        serverStarted(): void;
        statusHeartbeat(): void;
    }

    export class $ServerActivityMonitor {
        constructor(arg0: $NotificationManager, arg1: number);
        reportLoginActivity(): void;
        tick(): void;
    }

}
