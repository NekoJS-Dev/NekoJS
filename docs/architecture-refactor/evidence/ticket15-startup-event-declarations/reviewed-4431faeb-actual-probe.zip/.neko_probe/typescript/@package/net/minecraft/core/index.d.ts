import { $ImmutableList } from "java:com/google/common/collect";
import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec, $DynamicOps, $Keyable, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $LongConsumer } from "java:it/unimi/dsi/fastutil/longs";
import { $Comparable, $Enum, $Iterable, $Record, $Runnable, $String } from "java:java/lang";
import { $AbstractList, $Collection, $Iterator, $List, $Map, $Map$Entry, $Optional, $Set, $Spliterator } from "java:java/util";
import { $BiConsumer, $Consumer, $Function, $IntFunction, $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $DataComponentLookup, $DataComponentMap } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $RegistryOps, $ResourceKey } from "java:net/minecraft/resources";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $TagKey, $TagKey_, $TagLoader$LoadResult } from "java:net/minecraft/tags";
import { $RandomSource, $StringRepresentable, $StringRepresentable$EnumCodec } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $ChunkPos, $Level } from "java:net/minecraft/world/level";
import { $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $ChunkAccess } from "java:net/minecraft/world/level/chunk";
import { $EntityAccess } from "java:net/minecraft/world/level/entity";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $IHolderExtension, $IHolderLookupProviderExtension, $IHolderSetExtension, $PendingTagsExtension, $TypedInstanceExtension } from "java:net/neoforged/neoforge/common/extensions";
import { $IRegistryExtension } from "java:net/neoforged/neoforge/registries";
import { $DataMapType } from "java:net/neoforged/neoforge/registries/datamaps";
import { $Matrix4fc, $Quaternionf, $Vector3f, $Vector3fc, $Vector3i } from "java:org/joml";
import { $Logger } from "java:org/slf4j";

export * as component from "java:net/minecraft/core/component";
export * as particles from "java:net/minecraft/core/particles";

declare module "java:net/minecraft/core" {
    export class $AxisCycle {
        static BACKWARD: $AxisCycle;
        static FORWARD: $AxisCycle;
        static NONE: $AxisCycle;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AxisCycle[];
        static valueOf(name: string): $AxisCycle;
    }

    export class $BlockPos extends $Vec3i {
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: $Vec3i);
        static CODEC: $Codec<$BlockPos>;
        static MAX_HORIZONTAL_COORDINATE: number;
        static PACKED_HORIZONTAL_LENGTH: number;
        static PACKED_Y_LENGTH: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $BlockPos>;
        static ZERO: $BlockPos;
        static asLong(arg0: number, arg1: number, arg2: number): number;
        static betweenClosedStream(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): $Stream<$BlockPos>;
        static betweenClosedStream(arg0: $BlockPos_, arg1: $BlockPos_): $Stream<$BlockPos>;
        static betweenClosedStream(arg0: $BoundingBox): $Stream<$BlockPos>;
        static betweenClosedStream(arg0: $AABB): $Stream<$BlockPos>;
        static betweenClosed(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): $Iterable<$BlockPos>;
        static betweenClosed(arg0: $BlockPos_, arg1: $BlockPos_): $Iterable<$BlockPos>;
        static betweenClosed(arg0: $AABB): $Iterable<$BlockPos>;
        static betweenCornersInDirection(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: $Vec3_): $Iterable<$BlockPos>;
        static betweenCornersInDirection(arg0: $BlockPos_, arg1: $BlockPos_, arg2: $Vec3_): $Iterable<$BlockPos>;
        static betweenCornersInDirection(arg0: $AABB, arg1: $Vec3_): $Iterable<$BlockPos>;
        static breadthFirstTraversal(arg0: $BlockPos_, arg1: number, arg2: number, arg3: $BiConsumer<$BlockPos_, $Consumer<$BlockPos_>>, arg4: $Function<$BlockPos_, $BlockPos$TraversalNodeStatus_>): number;
        static containing(arg0: number, arg1: number, arg2: number): $BlockPos;
        static containing(arg0: $Position): $BlockPos;
        static findClosestMatch(arg0: $BlockPos_, arg1: number, arg2: number, arg3: $Predicate<$BlockPos_>): $Optional<$BlockPos>;
        static getFlatIndex(arg0: number): number;
        static getX(arg0: number): number;
        static getY(arg0: number): number;
        static getZ(arg0: number): number;
        static max(arg0: $BlockPos_, arg1: $BlockPos_): $BlockPos;
        static min(arg0: $BlockPos_, arg1: $BlockPos_): $BlockPos;
        static neighborColumn(arg0: number, arg1: number, arg2: number, arg3: number): $Iterable<$BlockPos>;
        static offset(arg0: number, arg1: number, arg2: number, arg3: number): number;
        static offset(arg0: number, arg1: $Direction_): number;
        static of(arg0: number): $BlockPos;
        static randomBetweenClosed(arg0: $RandomSource, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): $Iterable<$BlockPos>;
        static randomInCube(arg0: $RandomSource, arg1: number, arg2: $BlockPos_, arg3: number): $Iterable<$BlockPos>;
        static spiralAround(arg0: $BlockPos_, arg1: number, arg2: $Direction_, arg3: $Direction_): $Iterable<$BlockPos$MutableBlockPos>;
        static squareOutSouthEast(arg0: $BlockPos_): $Stream<$BlockPos>;
        static withinManhattanStream(arg0: $BlockPos_, arg1: number, arg2: number, arg3: number): $Stream<$BlockPos>;
        static withinManhattan(arg0: $BlockPos_, arg1: number, arg2: number, arg3: number): $Iterable<$BlockPos>;
        above(arg0: number): $BlockPos;
        above(): $BlockPos;
        asLong(): number;
        atY(arg0: number): $BlockPos;
        below(arg0: number): $BlockPos;
        below(): $BlockPos;
        clampLocationWithin(arg0: $Vec3_): $Vec3;
        cross(arg0: $Vec3i): $BlockPos;
        east(arg0: number): $BlockPos;
        east(): $BlockPos;
        immutable(): $BlockPos;
        multiply(arg0: number): $BlockPos;
        mutable(): $BlockPos$MutableBlockPos;
        north(arg0: number): $BlockPos;
        north(): $BlockPos;
        offset(arg0: number, arg1: number, arg2: number): $BlockPos;
        offset(arg0: $Vec3i): $BlockPos;
        relative(arg0: $Direction$Axis_, arg1: number): $BlockPos;
        relative(arg0: $Direction_, arg1: number): $BlockPos;
        relative(arg0: $Direction_): $BlockPos;
        rotate(arg0: $Rotation_): $BlockPos;
        south(arg0: number): $BlockPos;
        south(): $BlockPos;
        subtract(arg0: $Vec3i): $BlockPos;
        west(arg0: number): $BlockPos;
        west(): $BlockPos;
    }

    export class $BlockPos$MutableBlockPos extends $BlockPos {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: number, arg1: number, arg2: number);
        clamp(arg0: $Direction$Axis_, arg1: number, arg2: number): $BlockPos$MutableBlockPos;
        immutable(): $BlockPos;
        move(arg0: number, arg1: number, arg2: number): $BlockPos$MutableBlockPos;
        move(arg0: $Direction_, arg1: number): $BlockPos$MutableBlockPos;
        move(arg0: $Direction_): $BlockPos$MutableBlockPos;
        move(arg0: $Vec3i): $BlockPos$MutableBlockPos;
        multiply(arg0: number): $BlockPos;
        offset(arg0: number, arg1: number, arg2: number): $BlockPos;
        relative(arg0: $Direction$Axis_, arg1: number): $BlockPos;
        relative(arg0: $Direction_, arg1: number): $BlockPos;
        rotate(arg0: $Rotation_): $BlockPos;
        setWithOffset(arg0: $Vec3i, arg1: number, arg2: number, arg3: number): $BlockPos$MutableBlockPos;
        setWithOffset(arg0: $Vec3i, arg1: $Direction_): $BlockPos$MutableBlockPos;
        setWithOffset(arg0: $Vec3i, arg1: $Vec3i): $BlockPos$MutableBlockPos;
        set(arg0: number, arg1: number, arg2: number): $BlockPos$MutableBlockPos;
        set(arg0: number, arg1: number, arg2: number): $BlockPos$MutableBlockPos;
        set(arg0: number): $BlockPos$MutableBlockPos;
        set(arg0: $AxisCycle_, arg1: number, arg2: number, arg3: number): $BlockPos$MutableBlockPos;
        set(arg0: $Vec3i): $BlockPos$MutableBlockPos;
    }

    export class $BlockPos$TraversalNodeStatus {
        static ACCEPT: $BlockPos$TraversalNodeStatus;
        static SKIP: $BlockPos$TraversalNodeStatus;
        static STOP: $BlockPos$TraversalNodeStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BlockPos$TraversalNodeStatus[];
        static valueOf(name: string): $BlockPos$TraversalNodeStatus;
    }

    export class $ClientAsset$ResourceTexture extends $Record implements $ClientAsset$Texture {
        constructor(arg0: $Identifier_);
        constructor(id: $Identifier_, texturePath: $Identifier_);
        static CODEC: $Codec<$ClientAsset$ResourceTexture>;
        static DEFAULT_FIELD_CODEC: $MapCodec<$ClientAsset$ResourceTexture>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientAsset$ResourceTexture>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        texturePath(): $Identifier;
        toString(): string;
    }

    export interface $ClientAsset$Texture extends $ClientAsset {
        texturePath(): $Identifier;
    }

    export class $Direction {
        static DOWN: $Direction;
        static EAST: $Direction;
        static NORTH: $Direction;
        static SOUTH: $Direction;
        static UP: $Direction;
        static WEST: $Direction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction[];
        static valueOf(name: string): $Direction;
    }

    export class $Direction$Axis {
        static X: $Direction$Axis;
        static Y: $Direction$Axis;
        static Z: $Direction$Axis;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$Axis[];
        static valueOf(name: string): $Direction$Axis;
    }

    export class $Direction$AxisDirection {
        static NEGATIVE: $Direction$AxisDirection;
        static POSITIVE: $Direction$AxisDirection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$AxisDirection[];
        static valueOf(name: string): $Direction$AxisDirection;
    }

    export class $Direction$Plane {
        static HORIZONTAL: $Direction$Plane;
        static VERTICAL: $Direction$Plane;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$Plane[];
        static valueOf(name: string): $Direction$Plane;
    }

    export class $Direction8 {
        static EAST: $Direction8;
        static NORTH: $Direction8;
        static NORTH_EAST: $Direction8;
        static NORTH_WEST: $Direction8;
        static SOUTH: $Direction8;
        static SOUTH_EAST: $Direction8;
        static SOUTH_WEST: $Direction8;
        static WEST: $Direction8;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction8[];
        static valueOf(name: string): $Direction8;
    }

    export class $FrontAndTop {
        static DOWN_EAST: $FrontAndTop;
        static DOWN_NORTH: $FrontAndTop;
        static DOWN_SOUTH: $FrontAndTop;
        static DOWN_WEST: $FrontAndTop;
        static EAST_UP: $FrontAndTop;
        static NORTH_UP: $FrontAndTop;
        static SOUTH_UP: $FrontAndTop;
        static UP_EAST: $FrontAndTop;
        static UP_NORTH: $FrontAndTop;
        static UP_SOUTH: $FrontAndTop;
        static UP_WEST: $FrontAndTop;
        static WEST_UP: $FrontAndTop;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $FrontAndTop[];
        static valueOf(name: string): $FrontAndTop;
    }

    export class $GlobalPos extends $Record {
        constructor(dimension: $ResourceKey<$Level>, pos: $BlockPos_);
        static CODEC: $Codec<$GlobalPos>;
        static MAP_CODEC: $MapCodec<$GlobalPos>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $GlobalPos>;
        static of(arg0: $ResourceKey<$Level>, arg1: $BlockPos_): $GlobalPos;
        dimension(): $ResourceKey<$Level>;
        equals(arg0: object): boolean;
        hashCode(): number;
        isCloseEnough(arg0: $ResourceKey<$Level>, arg1: $BlockPos_, arg2: number): boolean;
        pos(): $BlockPos;
        toString(): string;
    }

    export interface $Holder<T> extends $IHolderExtension {
        areComponentsBound(): boolean;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        direct<T>(arg0: T, arg1: $DataComponentMap): $Holder<T>;
        direct<T>(arg0: T): $Holder<T>;
        getRegisteredName(): string;
        isBound(): boolean;
        is(arg0: $Predicate<$ResourceKey<T>>): boolean;
        is(arg0: $Holder<T>): boolean;
        is(arg0: $Identifier_): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $TagKey<T>): boolean;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export class $Holder$Kind {
        static DIRECT: $Holder$Kind;
        static REFERENCE: $Holder$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Holder$Kind[];
        static valueOf(name: string): $Holder$Kind;
    }

    export class $Holder$Reference<T> implements $Holder {
        get key(): $ResourceKey<T>;
        getKey(): $ResourceKey<T>;
        get bound(): boolean;
        isBound(): boolean;
        static createIntrusive<T>(arg0: $HolderOwner<T>, arg1: T): $Holder$Reference<T>;
        static createStandAlone<T>(arg0: $HolderOwner<T>, arg1: $ResourceKey<T>): $Holder$Reference<T>;
        areComponentsBound(): boolean;
        bindComponents(arg0: $DataComponentMap): void;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        equals(arg0: object): boolean;
        getData<A>(arg0: $DataMapType<T, A>): A;
        hashCode(): number;
        is(arg0: $Predicate<$ResourceKey<T>>): boolean;
        is(arg0: $Holder<T>): boolean;
        is(arg0: $Identifier_): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $TagKey<T>): boolean;
        key(): $ResourceKey<T>;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        toString(): string;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrapLookup(): $HolderLookup$RegistryLookup<T>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export interface $HolderGetter<T> {
        getOrThrow(arg0: $ResourceKey<T>): $Holder$Reference<T>;
        getOrThrow(arg0: $TagKey<T>): $HolderSet$Named<T>;
        getRandomElementOf(arg0: $TagKey<T>, arg1: $RandomSource): $Optional<$Holder<T>>;
        get(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        get(arg0: $TagKey<T>): $Optional<$HolderSet$Named<T>>;
    }

    export interface $HolderGetter$Provider {
        getOrThrow<T>(arg0: $ResourceKey<T>): $Holder$Reference<T>;
        getOrThrow<T>(arg0: $TagKey<T>): $HolderSet$Named<T>;
        get<T>(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        get<T>(arg0: $TagKey<T>): $Optional<$HolderSet$Named<T>>;
        lookupOrThrow<T>(arg0: $ResourceKey<$Registry<T>>): $HolderGetter<T>;
        lookup<T>(arg0: $ResourceKey<$Registry<T>>): $Optional<$HolderGetter<T>>;
    }

    export interface $HolderLookup<T> extends $HolderGetter {
        listElementIds(): $Stream<$ResourceKey<T>>;
        listElements(): $Stream<$Holder$Reference<T>>;
        listTagIds(): $Stream<$TagKey<T>>;
        listTags(): $Stream<$HolderSet$Named<T>>;
    }

    export interface $HolderLookup$Provider extends $HolderGetter$Provider, $IHolderLookupProviderExtension {
        allRegistriesLifecycle(): $Lifecycle;
        createSerializationContext<V>(arg0: $DynamicOps<V>): $RegistryOps<V>;
        create(arg0: $Stream<$HolderLookup$RegistryLookup<any>>): $HolderLookup$Provider;
        listRegistries(): $Stream<$HolderLookup$RegistryLookup<any>>;
        listRegistryKeys(): $Stream<$ResourceKey<$Registry<any>>>;
        lookupOrThrow<T>(arg0: $ResourceKey<$Registry<T>>): $HolderLookup$RegistryLookup<T>;
        lookup<T>(arg0: $ResourceKey<$Registry<T>>): $Optional<$HolderLookup$RegistryLookup<T>>;
    }

    export interface $HolderLookup$RegistryLookup<T> extends $HolderLookup, $HolderOwner {
        filterElements(arg0: $Predicate<T>): $HolderLookup$RegistryLookup<T>;
        filterFeatures(arg0: $FeatureFlagSet): $HolderLookup$RegistryLookup<T>;
        getDataMap<A>(arg0: $DataMapType<T, A>): $Map<$ResourceKey<T>, A>;
        getData<A>(arg0: $DataMapType<T, A>, arg1: $ResourceKey<T>): A;
        key(): $ResourceKey<$Registry<T>>;
        registryLifecycle(): $Lifecycle;
    }

    export interface $HolderOwner<T> {
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
    }

    export interface $HolderSet<T> extends $Iterable, $IHolderSetExtension {
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        contains(arg0: $Holder<T>): boolean;
        direct<T>(arg0: $Holder<T>[]): $HolderSet$Direct<T>;
        direct<E, T>(arg0: $Function<E, $Holder<T>>, arg1?: E[]): $HolderSet$Direct<T>;
        direct<E, T>(arg0: $Function<E, $Holder<T>>, arg1: E[]): $HolderSet$Direct<T>;
        direct<T>(arg0?: $Holder<T>[]): $HolderSet$Direct<T>;
        emptyNamed<T>(arg0: $HolderOwner<T>, arg1: $TagKey<T>): $HolderSet$Named<T>;
        empty<T>(): $HolderSet<T>;
        getRandomElement(arg0: $RandomSource): $Optional<$Holder<T>>;
        get(arg0: number): $Holder<T>;
        isBound(): boolean;
        size(): number;
        stream(): $Stream<$Holder<T>>;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export class $HolderSet$Direct<T> extends $HolderSet$ListBacked {
        get bound(): boolean;
        isBound(): boolean;
        contains(arg0: $Holder<T>): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export class $HolderSet$ListBacked<T> implements $HolderSet {
        constructor();
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        getRandomElement(arg0: $RandomSource): $Optional<$Holder<T>>;
        get(arg0: number): $Holder<T>;
        iterator(): $Iterator<$Holder<T>>;
        size(): number;
        spliterator(): $Spliterator<$Holder<T>>;
        stream(): $Stream<$Holder<T>>;
    }

    export class $HolderSet$Named<T> extends $HolderSet$ListBacked {
        get bound(): boolean;
        isBound(): boolean;
        get immediatelyResolvable(): boolean;
        isImmediatelyResolvable(): boolean;
        addInvalidationListener(arg0: $Runnable): void;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        contains(arg0: $Holder<T>): boolean;
        key(): $TagKey<T>;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export interface $IdMap<T> extends $Iterable {
        byIdOrThrow(arg0: number): T;
        byId(arg0: number): T;
        getIdOrThrow(arg0: T): number;
        getId(arg0: T): number;
        size(): number;
        static DEFAULT: number;
    }

    export class $IdMapper<T> implements $IdMap {
        constructor();
        constructor(arg0: number);
        addMapping(arg0: T, arg1: number): void;
        add(arg0: T): void;
        byId(arg0: number): T;
        contains(arg0: number): boolean;
        getId(arg0: T): number;
        iterator(): $Iterator<T>;
        size(): number;
    }

    export class $LayeredRegistryAccess<T> {
        constructor(arg0: T[]);
        compositeAccess(): $RegistryAccess$Frozen;
        getAccessForLoading(arg0: T): $RegistryAccess$Frozen;
        getAccessFrom(arg0: T): $RegistryAccess$Frozen;
        getLayer(arg0: T): $RegistryAccess$Frozen;
        replaceFrom(arg0: T, arg1: $RegistryAccess$Frozen[]): $LayeredRegistryAccess<T>;
        replaceFrom(arg0: T, arg1?: $RegistryAccess$Frozen[]): $LayeredRegistryAccess<T>;
    }

    export class $NonNullList<E> extends $AbstractList {
        static codecOf<E>(arg0: $Codec<E>): $Codec<$NonNullList<E>>;
        static copyOf<E>(arg0: E[]): $NonNullList<E>;
        static createWithCapacity<E>(arg0: number): $NonNullList<E>;
        static create<E>(): $NonNullList<E>;
        static of<E>(arg0: E, arg1?: E[]): $NonNullList<E>;
        static withSize<E>(arg0: number, arg1: E): $NonNullList<E>;
        add(arg0: number, arg1: E): void;
        clear(): void;
        get(arg0: number): E;
        remove(arg0: number): E;
        set(arg0: number, arg1: E): E;
        size(): number;
    }

    export interface $Position {
        x(): number;
        y(): number;
        z(): number;
    }

    export class $RegistrationInfo extends $Record {
        constructor(knownPackInfo: $Optional<$KnownPack>, lifecycle: $Lifecycle);
        static BUILT_IN: $RegistrationInfo;
        equals(arg0: object): boolean;
        hashCode(): number;
        knownPackInfo(): $Optional<$KnownPack>;
        lifecycle(): $Lifecycle;
        toString(): string;
    }

    export interface $Registry<T> extends $IdMap, $Keyable, $HolderLookup$RegistryLookup, $IRegistryExtension {
        asHolderIdMap(): $IdMap<$Holder<T>>;
        byNameCodec(): $Codec<T>;
        componentLookup(): $DataComponentLookup<T>;
        containsKey(arg0: $Identifier_): boolean;
        containsKey(arg0: $ResourceKey<T>): boolean;
        createIntrusiveHolder(arg0: T): $Holder$Reference<T>;
        entrySet(): $Set<$Map$Entry<$ResourceKey<T>, T>>;
        freeze(): $Registry<T>;
        getAny(): $Optional<$Holder$Reference<T>>;
        getDataMap<A>(arg0: $DataMapType<T, A>): $Map<$ResourceKey<T>, A>;
        getId(arg0: T): number;
        getKey(arg0: T): $Identifier;
        getOptional(arg0: $Identifier_): $Optional<T>;
        getOptional(arg0: $ResourceKey<T>): $Optional<T>;
        getRandom(arg0: $RandomSource): $Optional<$Holder$Reference<T>>;
        getResourceKey(arg0: T): $Optional<$ResourceKey<T>>;
        getTagOrEmpty(arg0: $TagKey<T>): $Iterable<$Holder<T>>;
        getTags(): $Stream<$HolderSet$Named<T>>;
        getValueOrThrow(arg0: $ResourceKey<T>): T;
        getValue(arg0: $Identifier_): T;
        getValue(arg0: $ResourceKey<T>): T;
        get(arg0: number): $Optional<$Holder$Reference<T>>;
        get(arg0: $Identifier_): $Optional<$Holder$Reference<T>>;
        holderByNameCodec(): $Codec<$Holder<T>>;
        keySet(): $Set<$Identifier>;
        keys<U>(arg0: $DynamicOps<U>): $Stream<U>;
        key(): $ResourceKey<$Registry<T>>;
        prepareTagReload(arg0: $TagLoader$LoadResult<T>): $Registry$PendingTags<T>;
        registerForHolder<R, T>(arg0: $Registry<R>, arg1: $Identifier_, arg2: T): $Holder$Reference<T>;
        registerForHolder<R, T>(arg0: $Registry<R>, arg1: $ResourceKey<R>, arg2: T): $Holder$Reference<T>;
        register<T>(arg0: $Registry<any>, arg1: string, arg2: T): T;
        register<V, T>(arg0: $Registry<V>, arg1: $Identifier_, arg2: T): T;
        register<V, T>(arg0: $Registry<V>, arg1: $ResourceKey<V>, arg2: T): T;
        registrationInfo(arg0: $ResourceKey<T>): $Optional<$RegistrationInfo>;
        registryKeySet(): $Set<$ResourceKey<T>>;
        stream(): $Stream<T>;
        wrapAsHolder(arg0: T): $Holder<T>;
    }

    export interface $Registry$PendingTags<T> extends $PendingTagsExtension {
        apply(): void;
        key(): $ResourceKey<$Registry<T>>;
        lookup(): $HolderLookup$RegistryLookup<T>;
        size(): number;
    }

    export interface $RegistryAccess extends $HolderLookup$Provider {
        freeze(): $RegistryAccess$Frozen;
        fromRegistryOfRegistries(arg0: $Registry<$Registry<any>>): $RegistryAccess$Frozen;
        listRegistryKeys(): $Stream<$ResourceKey<$Registry<any>>>;
        lookupOrThrow<E>(arg0: $ResourceKey<$Registry<E>>): $Registry<E>;
        lookup<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$Registry<E>>;
        registries(): $Stream<$RegistryAccess$RegistryEntry<any>>;
        static EMPTY: $RegistryAccess$Frozen;
        static LOGGER: $Logger;
    }

    export interface $RegistryAccess$Frozen extends $RegistryAccess {
    }

    export class $RegistryAccess$RegistryEntry<T> extends $Record {
        constructor(key: $ResourceKey<$Registry<T>>, value: $Registry<T>);
        equals(arg0: object): boolean;
        hashCode(): number;
        key(): $ResourceKey<$Registry<T>>;
        toString(): string;
        value(): $Registry<T>;
    }

    export class $SectionPos extends $Vec3i {
        static SECTION_BITS: number;
        static SECTION_BLOCK_COUNT: number;
        static SECTION_HALF_SIZE: number;
        static SECTION_MASK: number;
        static SECTION_MAX_INDEX: number;
        static SECTION_SIZE: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $SectionPos>;
        static aroundAndAtBlockPos(arg0: number, arg1: number, arg2: number, arg3: $LongConsumer): void;
        static aroundAndAtBlockPos(arg0: number, arg1: $LongConsumer): void;
        static aroundAndAtBlockPos(arg0: $BlockPos_, arg1: $LongConsumer): void;
        static aroundChunk(arg0: $ChunkPos, arg1: number, arg2: number, arg3: number): $Stream<$SectionPos>;
        static asLong(arg0: number, arg1: number, arg2: number): number;
        static asLong(arg0: $BlockPos_): number;
        static betweenClosedStream(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): $Stream<$SectionPos>;
        static blockToSectionCoord(arg0: number): number;
        static blockToSectionCoord(arg0: number): number;
        static blockToSection(arg0: number): number;
        static bottomOf(arg0: $ChunkAccess): $SectionPos;
        static cube(arg0: $SectionPos, arg1: number): $Stream<$SectionPos>;
        static getZeroNode(arg0: number, arg1: number): number;
        static getZeroNode(arg0: number): number;
        static offset(arg0: number, arg1: number, arg2: number, arg3: number): number;
        static offset(arg0: number, arg1: $Direction_): number;
        static of(arg0: number, arg1: number, arg2: number): $SectionPos;
        static of(arg0: number): $SectionPos;
        static of(arg0: $BlockPos_): $SectionPos;
        static of(arg0: $Position): $SectionPos;
        static of(arg0: $ChunkPos, arg1: number): $SectionPos;
        static of(arg0: $EntityAccess): $SectionPos;
        static posToSectionCoord(arg0: number): number;
        static sectionRelativePos(arg0: $BlockPos_): number;
        static sectionRelativeX(arg0: number): number;
        static sectionRelativeY(arg0: number): number;
        static sectionRelativeZ(arg0: number): number;
        static sectionRelative(arg0: number): number;
        static sectionToBlockCoord(arg0: number, arg1: number): number;
        static sectionToBlockCoord(arg0: number): number;
        static sectionToChunk(arg0: number): number;
        static x(arg0: number): number;
        static y(arg0: number): number;
        static z(arg0: number): number;
        asLong(): number;
        blocksInside(): $Stream<$BlockPos>;
        center(): $BlockPos;
        chunk(): $ChunkPos;
        maxBlockX(): number;
        maxBlockY(): number;
        maxBlockZ(): number;
        minBlockX(): number;
        minBlockY(): number;
        minBlockZ(): number;
        offset(arg0: number, arg1: number, arg2: number): $SectionPos;
        origin(): $BlockPos;
        relativeToBlockPos(arg0: number): $BlockPos;
        relativeToBlockX(arg0: number): number;
        relativeToBlockY(arg0: number): number;
        relativeToBlockZ(arg0: number): number;
        x(): number;
        y(): number;
        z(): number;
    }

    export interface $TypedInstance<T> extends $TypedInstanceExtension {
        is(arg0: T): boolean;
        is(arg0: $Holder<T>): boolean;
        is(arg0: $HolderSet<T>): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $TagKey<T>): boolean;
        tags(): $Stream<$TagKey<T>>;
        typeHolder(): $Holder<T>;
    }

    export class $Vec3i implements $Comparable {
        constructor(arg0: number, arg1: number, arg2: number);
        static CODEC: $Codec<$Vec3i>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Vec3i>;
        static ZERO: $Vec3i;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        static offsetCodec(arg0: number): $Codec<$Vec3i>;
        above(arg0: number): $Vec3i;
        above(): $Vec3i;
        below(arg0: number): $Vec3i;
        below(): $Vec3i;
        closerThan(arg0: $Vec3i, arg1: number): boolean;
        closerToCenterThan(arg0: $Position, arg1: number): boolean;
        compareTo(arg0: $Vec3i): number;
        cross(arg0: $Vec3i): $Vec3i;
        distChessboard(arg0: $Vec3i): number;
        distManhattan(arg0: $Vec3i): number;
        distSqr(arg0: $Vec3i): number;
        distToCenterSqr(arg0: number, arg1: number, arg2: number): number;
        distToCenterSqr(arg0: $Position): number;
        distToLowCornerSqr(arg0: number, arg1: number, arg2: number): number;
        east(arg0: number): $Vec3i;
        east(): $Vec3i;
        equals(arg0: object): boolean;
        get(arg0: $Direction$Axis_): number;
        hashCode(): number;
        multiply(arg0: number, arg1: number, arg2: number): $Vec3i;
        multiply(arg0: number): $Vec3i;
        north(arg0: number): $Vec3i;
        north(): $Vec3i;
        offset(arg0: number, arg1: number, arg2: number): $Vec3i;
        offset(arg0: $Vec3i): $Vec3i;
        relative(arg0: $Direction$Axis_, arg1: number): $Vec3i;
        relative(arg0: $Direction_, arg1: number): $Vec3i;
        relative(arg0: $Direction_): $Vec3i;
        south(arg0: number): $Vec3i;
        south(): $Vec3i;
        subtract(arg0: $Vec3i): $Vec3i;
        toMutable(): $Vector3i;
        toShortString(): string;
        toString(): string;
        west(arg0: number): $Vec3i;
        west(): $Vec3i;
    }

    export type $AxisCycle_ = $AxisCycle | "BACKWARD" | "FORWARD" | "NONE";
    export type $BlockPos_ = $BlockPos | $Vec3 | { x: number, y: number, z: number } | number[];
    export type $BlockPos$TraversalNodeStatus_ = $BlockPos$TraversalNodeStatus | "ACCEPT" | "SKIP" | "STOP";
    export type $Direction_ = $Direction | "DOWN" | "EAST" | "NORTH" | "SOUTH" | "UP" | "WEST";
    export type $Direction$Axis_ = $Direction$Axis | "X" | "Y" | "Z";
    export type $Direction$AxisDirection_ = $Direction$AxisDirection | "NEGATIVE" | "POSITIVE";
    export type $Direction$Plane_ = $Direction$Plane | "HORIZONTAL" | "VERTICAL";
    export type $Direction8_ = $Direction8 | "EAST" | "NORTH" | "NORTH_EAST" | "NORTH_WEST" | "SOUTH" | "SOUTH_EAST" | "SOUTH_WEST" | "WEST";
    export type $FrontAndTop_ = $FrontAndTop | "DOWN_EAST" | "DOWN_NORTH" | "DOWN_SOUTH" | "DOWN_WEST" | "EAST_UP" | "NORTH_UP" | "SOUTH_UP" | "UP_EAST" | "UP_NORTH" | "UP_SOUTH" | "UP_WEST" | "WEST_UP";
    /** registry entry id, e.g. 'minecraft:sharpness' (namespace defaults to minecraft) */
    export type $Holder_ = $Holder | string;
    export type $Holder$Kind_ = $Holder$Kind | "DIRECT" | "REFERENCE";
}
