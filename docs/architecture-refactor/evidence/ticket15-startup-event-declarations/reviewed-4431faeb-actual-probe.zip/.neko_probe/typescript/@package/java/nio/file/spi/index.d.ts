import { $InputStream, $OutputStream } from "java:java/io";
import { $Class, $String } from "java:java/lang";
import { $URI } from "java:java/net";
import { $AsynchronousFileChannel, $FileChannel, $SeekableByteChannel } from "java:java/nio/channels";
import { $AccessMode, $CopyOption, $DirectoryStream, $DirectoryStream$Filter, $FileStore, $FileSystem, $LinkOption, $OpenOption, $Path } from "java:java/nio/file";
import { $FileAttribute } from "java:java/nio/file/attribute";
import { $List, $Map, $Set } from "java:java/util";
import { $ExecutorService } from "java:java/util/concurrent";

declare module "java:java/nio/file/spi" {
    export class $FileSystemProvider {
        get scheme(): string;
        getScheme(): string;
        static installedProviders(): $List<$FileSystemProvider>;
        checkAccess(arg0: string, arg1?: $AccessMode_[]): void;
        copy(arg0: string, arg1: string, arg2?: $CopyOption[]): void;
        createDirectory(arg0: string, arg1?: $FileAttribute<any>[]): void;
        createLink(arg0: string, arg1: string): void;
        createSymbolicLink(arg0: string, arg1: string, arg2?: $FileAttribute<any>[]): void;
        deleteIfExists(arg0: string): boolean;
        delete(arg0: string): void;
        exists(arg0: string, arg1?: $LinkOption_[]): boolean;
        getFileAttributeView<V>(arg0: string, arg1: $Class<V>, arg2?: $LinkOption_[]): V;
        getFileStore(arg0: string): $FileStore;
        getFileSystem(arg0: $URI): $FileSystem;
        getPath(arg0: $URI): $Path;
        isHidden(arg0: string): boolean;
        isSameFile(arg0: string, arg1: string): boolean;
        move(arg0: string, arg1: string, arg2?: $CopyOption[]): void;
        newAsynchronousFileChannel(arg0: string, arg1: $OpenOption[], arg2: $ExecutorService, arg3?: $FileAttribute<any>[]): $AsynchronousFileChannel;
        newByteChannel(arg0: string, arg1: $OpenOption[], arg2?: $FileAttribute<any>[]): $SeekableByteChannel;
        newDirectoryStream(arg0: string, arg1: $DirectoryStream$Filter<any>): $DirectoryStream<$Path>;
        newFileChannel(arg0: string, arg1: $OpenOption[], arg2?: $FileAttribute<any>[]): $FileChannel;
        newFileSystem(arg0: $URI, arg1: { [key: string]: any }): $FileSystem;
        newFileSystem(arg0: string, arg1: { [key: string]: any }): $FileSystem;
        newInputStream(arg0: string, arg1?: $OpenOption[]): $InputStream;
        newOutputStream(arg0: string, arg1?: $OpenOption[]): $OutputStream;
        readAttributesIfExists<A>(arg0: string, arg1: $Class<A>, arg2?: $LinkOption_[]): A;
        readAttributes<A>(arg0: string, arg1: $Class<A>, arg2?: $LinkOption_[]): A;
        readAttributes(arg0: string, arg1: string, arg2?: $LinkOption_[]): $Map<string, object>;
        readSymbolicLink(arg0: string): $Path;
        setAttribute(arg0: string, arg1: string, arg2: object, arg3?: $LinkOption_[]): void;
    }

}
