import { $Codec, $DataResult, $DynamicOps } from "java:com/mojang/serialization";
import { $Class, $Iterable, $Record, $String } from "java:java/lang";
import { $Collection, $Iterator, $Map, $Map$Entry, $Optional, $Set } from "java:java/util";
import { $Consumer, $Predicate, $Supplier } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $Holder, $HolderLookup$Provider, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $IDataComponentHolderExtension, $IDataComponentMapBuilderExtensions } from "java:net/neoforged/neoforge/common/extensions";

declare module "java:net/minecraft/core/component" {
    export class $DataComponentExactPredicate implements $Predicate {
        static CODEC: $Codec<$DataComponentExactPredicate>;
        static EMPTY: $DataComponentExactPredicate;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentExactPredicate>;
        get empty(): boolean;
        isEmpty(): boolean;
        static allOf(arg0: $DataComponentMap): $DataComponentExactPredicate;
        static builder(): $DataComponentExactPredicate$Builder;
        static expect<T>(arg0: $DataComponentType<T>, arg1: T): $DataComponentExactPredicate;
        static someOf(arg0: $DataComponentMap, arg1?: $DataComponentType<any>[]): $DataComponentExactPredicate;
        alwaysMatches(): boolean;
        asPatch(): $DataComponentPatch;
        equals(arg0: object): boolean;
        hashCode(): number;
        test(arg0: $DataComponentGetter): boolean;
        toString(): string;
    }

    export class $DataComponentExactPredicate$Builder {
        build(): $DataComponentExactPredicate;
        expect<T>(arg0: $DataComponentType<any>, arg1: T): $DataComponentExactPredicate$Builder;
        expect<T>(arg0: $TypedDataComponent<T>): $DataComponentExactPredicate$Builder;
    }

    export interface $DataComponentGetter {
        getOrDefault<T>(arg0: $Supplier<$DataComponentType<T>>, arg1: T): T;
        getOrDefault<T>(arg0: $DataComponentType<T>, arg1: T): T;
        getTyped<T>(arg0: $DataComponentType<T>): $TypedDataComponent<T>;
        get<T>(arg0: $Supplier<$DataComponentType<T>>): T;
        get<T>(arg0: $DataComponentType<T>): T;
        has<T>(arg0: $Supplier<$DataComponentType<T>>): boolean;
        has(arg0: $DataComponentType<any>): boolean;
    }

    export interface $DataComponentHolder extends $DataComponentGetter, $IDataComponentHolderExtension {
        getAllOfType<T>(arg0: $Class<T>): $Stream<T>;
        getComponents(): $DataComponentMap;
        getOrDefault<T>(arg0: $DataComponentType<T>, arg1: T): T;
        get<T>(arg0: $DataComponentType<T>): T;
        has(arg0: $DataComponentType<any>): boolean;
    }

    export interface $DataComponentInitializers$Initializer<T> {
        add<C>(arg0: $DataComponentType<C>, arg1: C): $DataComponentInitializers$Initializer<T>;
        andThen(arg0: $DataComponentInitializers$Initializer<T>): $DataComponentInitializers$Initializer<T>;
        run(arg0: $DataComponentMap$Builder, arg1: $HolderLookup$Provider, arg2: $ResourceKey<T>): void;
    }

    export interface $DataComponentInitializers$SingleComponentInitializer<C> {
        asInitializer<T>(arg0: $DataComponentType<C>): $DataComponentInitializers$Initializer<T>;
        create(arg0: $HolderLookup$Provider): C;
    }

    export class $DataComponentLookup<T> {
        constructor(arg0: $Iterable<$Holder<T>>);
        findAll<C>(arg0: $DataComponentType<C>, arg1: C): $Collection<$Holder<T>>;
        findAll<C>(arg0: $DataComponentType<C>): $Collection<$Holder<T>>;
        findMatching<C>(arg0: $DataComponentType<C>, arg1: $Predicate<C>): $Stream<$Holder<T>>;
    }

    export interface $DataComponentMap extends $Iterable, $DataComponentGetter {
        builder(): $DataComponentMap$Builder;
        composite(arg0: $DataComponentMap, arg1: $DataComponentMap): $DataComponentMap;
        filter(arg0: $Predicate<$DataComponentType<any>>): $DataComponentMap;
        has(arg0: $DataComponentType<any>): boolean;
        isEmpty(): boolean;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        makeCodecFromMap(arg0: $Codec<{ [key: $DataComponentType<any>]: object }>): $Codec<$DataComponentMap>;
        makeCodec(arg0: $Codec<$DataComponentType<any>>): $Codec<$DataComponentMap>;
        size(): number;
        stream(): $Stream<$TypedDataComponent<any>>;
        static CODEC: $Codec<$DataComponentMap>;
        static EMPTY: $DataComponentMap;
    }

    export class $DataComponentMap$Builder implements $IDataComponentMapBuilderExtensions {
        addAll(arg0: $DataComponentMap): $DataComponentMap$Builder;
        addValidator(arg0: $Consumer<$DataComponentMap>): $DataComponentMap$Builder;
        build(): $DataComponentMap;
        get<T>(arg0: $DataComponentType<T>): T;
        set<T>(arg0: $DataComponentType<T>, arg1: T): $DataComponentMap$Builder;
    }

    export class $DataComponentPatch {
        static CODEC: $Codec<$DataComponentPatch>;
        static DELIMITED_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentPatch>;
        static EMPTY: $DataComponentPatch;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentPatch>;
        get empty(): boolean;
        isEmpty(): boolean;
        static builder(): $DataComponentPatch$Builder;
        entrySet(): $Set<$Map$Entry<$DataComponentType<any>, $Optional<any>>>;
        equals(arg0: object): boolean;
        forget(arg0: $Predicate<$DataComponentType<any>>): $DataComponentPatch;
        getPatch<T>(arg0: $DataComponentType<T>): $Optional<T>;
        get<T>(arg0: $DataComponentGetter, arg1: $DataComponentType<T>): T;
        hashCode(): number;
        size(): number;
        split(): $DataComponentPatch$SplitResult;
        toString(): string;
    }

    export class $DataComponentPatch$Builder {
        build(): $DataComponentPatch;
        remove<T>(arg0: $DataComponentType<T>): $DataComponentPatch$Builder;
        set<T>(arg0: $Iterable<$TypedDataComponent<any>>): $DataComponentPatch$Builder;
        set<T>(arg0: $DataComponentType<T>, arg1: T): $DataComponentPatch$Builder;
        set<T>(arg0: $TypedDataComponent<T>): $DataComponentPatch$Builder;
    }

    export class $DataComponentPatch$SplitResult extends $Record {
        constructor(added: $DataComponentMap, removed: $DataComponentType<any>[]);
        static EMPTY: $DataComponentPatch$SplitResult;
        added(): $DataComponentMap;
        equals(arg0: object): boolean;
        hashCode(): number;
        removed(): $Set<$DataComponentType<any>>;
        toString(): string;
    }

    export interface $DataComponentType<T> {
        builder<T>(): $DataComponentType$Builder<T>;
        codecOrThrow(): $Codec<T>;
        codec(): $Codec<T>;
        ignoreSwapAnimation(): boolean;
        isTransient(): boolean;
        streamCodec(): $StreamCodec<any, T>;
        static CODEC: $Codec<$DataComponentType<any>>;
        static PERSISTENT_CODEC: $Codec<$DataComponentType<any>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentType<any>>;
        static VALUE_MAP_CODEC: $Codec<$Map<$DataComponentType<any>, object>>;
    }

    export class $DataComponentType$Builder<T> {
        constructor();
        build(): $DataComponentType<T>;
        cacheEncoding(): $DataComponentType$Builder<T>;
        ignoreSwapAnimation(): $DataComponentType$Builder<T>;
        networkSynchronized(arg0: $StreamCodec<any, T>): $DataComponentType$Builder<T>;
        persistent(arg0: $Codec<T>): $DataComponentType$Builder<T>;
    }

    export class $PatchedDataComponentMap implements $DataComponentMap {
        constructor(arg0: $DataComponentMap);
        get patchEmpty(): boolean;
        isPatchEmpty(): boolean;
        static fromPatch(arg0: $DataComponentMap, arg1: $DataComponentPatch): $PatchedDataComponentMap;
        applyPatch(arg0: $DataComponentPatch): void;
        asPatch(): $DataComponentPatch;
        clearPatch(): void;
        copy(): $PatchedDataComponentMap;
        equals(arg0: object): boolean;
        get<T>(arg0: $DataComponentType<T>): T;
        hasNonDefault(arg0: $DataComponentType<any>): boolean;
        hashCode(): number;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        patchEquals(arg0: $DataComponentPatch): boolean;
        remove<T>(arg0: $DataComponentType<T>): T;
        restorePatch(arg0: $DataComponentPatch): void;
        set<T>(arg0: $DataComponentType<T>, arg1: T): T;
        set<T>(arg0: $TypedDataComponent<T>): T;
        size(): number;
        toImmutableMap(): $DataComponentMap;
        toString(): string;
    }

    export class $TypedDataComponent<T> extends $Record {
        constructor(type: $DataComponentType<T>, value: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $TypedDataComponent<any>>;
        static createUnchecked<T>(arg0: $DataComponentType<T>, arg1: object): $TypedDataComponent<T>;
        applyTo(arg0: $PatchedDataComponentMap): void;
        encodeValue<D>(arg0: $DynamicOps<D>): $DataResult<D>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $DataComponentType<T>;
        value(): T;
    }

}
