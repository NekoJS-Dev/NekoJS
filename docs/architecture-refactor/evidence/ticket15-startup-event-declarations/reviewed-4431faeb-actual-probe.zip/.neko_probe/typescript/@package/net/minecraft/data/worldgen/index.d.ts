import { $Lifecycle } from "java:com/mojang/serialization";
import { $Optional } from "java:java/util";
import { $Holder$Reference, $HolderGetter, $HolderLookup } from "java:net/minecraft/core";
import { $ResourceKey } from "java:net/minecraft/resources";

declare module "java:net/minecraft/data/worldgen" {
    export interface $BootstrapContext<T> {
        holderLookup<S>(arg0: $ResourceKey<$Registry<S>>): $Optional<$HolderLookup<S>>;
        lookup<S>(arg0: $ResourceKey<$Registry<S>>): $HolderGetter<S>;
        register(arg0: $ResourceKey<T>, arg1: T, arg2: $Lifecycle): $Holder$Reference<T>;
        register(arg0: $ResourceKey<T>, arg1: T): $Holder$Reference<T>;
    }

}
