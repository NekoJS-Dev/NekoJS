import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Record, $String } from "java:java/lang";
import { $Collection, $List, $Map, $Optional } from "java:java/util";
import { $Consumer, $Predicate } from "java:java/util/function";
import { $Holder, $Holder_, $Registry } from "java:net/minecraft/core";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ExtraCodecs$TagOrElementLocation } from "java:net/minecraft/util";

declare module "java:net/minecraft/tags" {
    export class $TagEntry {
        static CODEC: $Codec<$TagEntry>;
        id: $Identifier;
        required: boolean;
        tag: boolean;
        get id(): $Identifier;
        getId(): $Identifier;
        get required(): boolean;
        isRequired(): boolean;
        get tag(): boolean;
        isTag(): boolean;
        static element(arg0: $Identifier_): $TagEntry;
        static optionalElement(arg0: $Identifier_): $TagEntry;
        static optionalTag(arg0: $Identifier_): $TagEntry;
        static tag(arg0: $Identifier_): $TagEntry;
        build<T>(arg0: $TagEntry$Lookup<T>, arg1: $Consumer<T>): boolean;
        elementOrTag(): $ExtraCodecs$TagOrElementLocation;
        toString(): string;
        verifyIfPresent(arg0: $Predicate<$Identifier_>, arg1: $Predicate<$Identifier_>): boolean;
        visitOptionalDependencies(arg0: $Consumer<$Identifier_>): void;
        visitRequiredDependencies(arg0: $Consumer<$Identifier_>): void;
    }

    export interface $TagEntry$Lookup<T> {
        element(arg0: $Identifier_, arg1: boolean): T;
        tag(arg0: $Identifier_): $Collection<T>;
    }

    export class $TagKey<T> extends $Record {
        constructor(registry: $ResourceKey<$Registry<T>>, location: $Identifier_);
        static codec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static create<T>(arg0: $ResourceKey<$Registry<T>>, arg1: $Identifier_): $TagKey<T>;
        static hashedCodec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static streamCodec<T>(arg0: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $TagKey<T>>;
        cast<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$TagKey<E>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        isFor(arg0: $ResourceKey<$Registry<any>>): boolean;
        location(): $Identifier;
        registry(): $ResourceKey<$Registry<T>>;
        toString(): string;
    }

    export class $TagLoader$EntryWithSource extends $Record {
        constructor(arg0: $TagEntry, arg1: string);
        constructor(entry: $TagEntry, source: string, remove: boolean);
        entry(): $TagEntry;
        equals(arg0: object): boolean;
        hashCode(): number;
        remove(): boolean;
        source(): string;
        toString(): string;
    }

    export class $TagLoader$LoadResult<T> extends $Record {
        constructor(key: $ResourceKey<$Registry<T>>, tags: { [key: $TagKey<T>]: $Holder<T>[] });
        equals(arg0: object): boolean;
        hashCode(): number;
        key(): $ResourceKey<$Registry<T>>;
        tags(): $Map<$TagKey<T>, $List<$Holder<T>>>;
        toString(): string;
    }

    export class $TagNetworkSerialization$NetworkPayload {
        constructor(arg0: { [key: $Identifier_]: $IntList });
        static EMPTY: $TagNetworkSerialization$NetworkPayload;
        get empty(): boolean;
        isEmpty(): boolean;
        static read(arg0: $FriendlyByteBuf): $TagNetworkSerialization$NetworkPayload;
        resolve<T>(arg0: $Registry<T>): $TagLoader$LoadResult<T>;
        size(): number;
        write(arg0: $FriendlyByteBuf): void;
    }

    export type $TagKey_ = string | { type?: string, tag: string };
}
