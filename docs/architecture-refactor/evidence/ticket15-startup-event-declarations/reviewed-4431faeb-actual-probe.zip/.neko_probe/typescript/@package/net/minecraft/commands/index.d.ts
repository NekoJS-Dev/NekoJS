import { $CharMatcher } from "java:com/google/common/base";
import { $CommandDispatcher, $Message, $ParseResults, $ResultConsumer, $StringReader } from "java:com/mojang/brigadier";
import { $ArgumentType } from "java:com/mojang/brigadier/arguments";
import { $LiteralArgumentBuilder, $RequiredArgumentBuilder } from "java:com/mojang/brigadier/builder";
import { $CommandContext } from "java:com/mojang/brigadier/context";
import { $CommandExceptionType, $CommandSyntaxException, $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Suggestions, $SuggestionsBuilder } from "java:com/mojang/brigadier/suggestion";
import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Iterable, $String } from "java:java/lang";
import { $Collection, $Optional, $Set } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $BinaryOperator, $Consumer, $Function, $Predicate, $Supplier, $UnaryOperator } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $EntityAnchorArgument$Anchor, $EntityAnchorArgument$Anchor_ } from "java:net/minecraft/commands/arguments";
import { $ExecutionContext, $TraceCallbacks } from "java:net/minecraft/commands/execution";
import { $CommandFunction } from "java:net/minecraft/commands/functions";
import { $HolderLookup, $HolderLookup$Provider, $RegistryAccess } from "java:net/minecraft/core";
import { $ChatType$Bound, $Component, $Component_, $OutgoingChatMessage, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer, $ServerFunctionManager } from "java:net/minecraft/server";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $PermissionCheck, $PermissionProviderCheck, $PermissionSet, $PermissionSetSupplier } from "java:net/minecraft/server/permissions";
import { $TaskChainer } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Level } from "java:net/minecraft/world/level";
import { $Vec2, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $ICommandSourceExtension, $ICommandSourceStackExtension } from "java:net/neoforged/neoforge/common/extensions";

export * as arguments from "java:net/minecraft/commands/arguments";
export * as execution from "java:net/minecraft/commands/execution";
export * as functions from "java:net/minecraft/commands/functions";

declare module "java:net/minecraft/commands" {
    export class $CacheableFunction {
        constructor(arg0: $Identifier_);
        static CODEC: $Codec<$CacheableFunction>;
        get id(): $Identifier;
        getId(): $Identifier;
        equals(arg0: object): boolean;
        get(arg0: $ServerFunctionManager): $Optional<$CommandFunction<$CommandSourceStack>>;
        hashCode(): number;
    }

    export interface $CommandBuildContext extends $HolderLookup$Provider {
        enabledFeatures(): $FeatureFlagSet;
        simple(arg0: $HolderLookup$Provider, arg1: $FeatureFlagSet): $CommandBuildContext;
    }

    export interface $CommandResultCallback {
        chain(arg0: $CommandResultCallback, arg1: $CommandResultCallback): $CommandResultCallback;
        onFailure(): void;
        onResult(arg0: boolean, arg1: number): void;
        onSuccess(arg0: number): void;
        static EMPTY: $CommandResultCallback;
    }

    export interface $CommandSigningContext {
        getArgument(arg0: string): $PlayerChatMessage;
        static ANONYMOUS: $CommandSigningContext;
    }

    export interface $CommandSource extends $ICommandSourceExtension {
        acceptsFailure(): boolean;
        acceptsSuccess(): boolean;
        alwaysAccepts(): boolean;
        sendSystemMessage(arg0: $Component_): void;
        shouldInformAdmins(): boolean;
        static NULL: $CommandSource;
    }

    export class $CommandSourceStack implements $SharedSuggestionProvider, $ExecutionCommandSource, $ICommandSourceStackExtension {
        constructor(arg0: $CommandSource, arg1: $Vec3_, arg2: $Vec2, arg3: $ServerLevel, arg4: $PermissionSet, arg5: string, arg6: $Component_, arg7: $MinecraftServer, arg8: $Entity);
        static ERROR_NOT_ENTITY: $SimpleCommandExceptionType;
        static ERROR_NOT_PLAYER: $SimpleCommandExceptionType;
        source: $CommandSource;
        get allTeams(): $Collection<string>;
        getAllTeams(): $Collection<string>;
        get anchor(): $EntityAnchorArgument$Anchor;
        getAnchor(): $EntityAnchorArgument$Anchor;
        get availableSounds(): $Stream<$Identifier>;
        getAvailableSounds(): $Stream<$Identifier>;
        get chatMessageChainer(): $TaskChainer;
        getChatMessageChainer(): $TaskChainer;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get entityOrException(): $Entity;
        getEntityOrException(): $Entity;
        get entity(): $Entity;
        getEntity(): $Entity;
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
        get onlinePlayerNames(): $Collection<string>;
        getOnlinePlayerNames(): $Collection<string>;
        get playerOrException(): $ServerPlayer;
        getPlayerOrException(): $ServerPlayer;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get position(): $Vec3;
        getPosition(): $Vec3;
        get rotation(): $Vec2;
        getRotation(): $Vec2;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get signingContext(): $CommandSigningContext;
        getSigningContext(): $CommandSigningContext;
        get textName(): string;
        getTextName(): string;
        get silent(): boolean;
        isSilent(): boolean;
        callback(): $CommandResultCallback;
        customSuggestion(arg0: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        enabledFeatures(): $FeatureFlagSet;
        facing(arg0: $Entity, arg1: $EntityAnchorArgument$Anchor_): $CommandSourceStack;
        facing(arg0: $Vec3_): $CommandSourceStack;
        handleError(arg0: $CommandExceptionType, arg1: $Message, arg2: boolean, arg3: $TraceCallbacks): void;
        levels(): $Set<$ResourceKey<$Level>>;
        permissions(): $PermissionSet;
        registryAccess(): $RegistryAccess;
        sendChatMessage(arg0: $OutgoingChatMessage, arg1: boolean, arg2: $ChatType$Bound): void;
        sendFailure(arg0: $Component_): void;
        sendSuccess(arg0: $Supplier<$Component_>, arg1: boolean): void;
        sendSystemMessage(arg0: $Component_): void;
        shouldFilterMessageTo(arg0: $ServerPlayer): boolean;
        suggestRegistryElements(arg0: $ResourceKey<$Registry<any>>, arg1: $SharedSuggestionProvider$ElementSuggestionType_, arg2: $SuggestionsBuilder, arg3: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        withAnchor(arg0: $EntityAnchorArgument$Anchor_): $CommandSourceStack;
        withCallback(arg0: $CommandResultCallback, arg1: $BinaryOperator<$CommandResultCallback>): $CommandSourceStack;
        withCallback(arg0: $CommandResultCallback): $CommandSourceStack;
        withEntity(arg0: $Entity): $CommandSourceStack;
        withLevel(arg0: $ServerLevel): $CommandSourceStack;
        withMaximumPermission(arg0: $PermissionSet): $CommandSourceStack;
        withPermission(arg0: $PermissionSet): $CommandSourceStack;
        withPosition(arg0: $Vec3_): $CommandSourceStack;
        withRotation(arg0: $Vec2): $CommandSourceStack;
        withSigningContext(arg0: $CommandSigningContext, arg1: $TaskChainer): $CommandSourceStack;
        withSource(arg0: $CommandSource): $CommandSourceStack;
        withSuppressedOutput(): $CommandSourceStack;
    }

    export class $Commands {
        constructor(arg0: $Commands$CommandSelection_, arg1: $CommandBuildContext);
        static COMMAND_PREFIX: string;
        static LEVEL_ADMINS: $PermissionCheck;
        static LEVEL_ALL: $PermissionCheck;
        static LEVEL_GAMEMASTERS: $PermissionCheck;
        static LEVEL_MODERATORS: $PermissionCheck;
        static LEVEL_OWNERS: $PermissionCheck;
        get dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        getDispatcher(): $CommandDispatcher<$CommandSourceStack>;
        static argument<T>(arg0: string, arg1: $ArgumentType<T>): $RequiredArgumentBuilder<$CommandSourceStack, T>;
        static createCompilationContext(arg0: $PermissionSet): $CommandSourceStack;
        static createValidationContext(arg0: $HolderLookup$Provider): $CommandBuildContext;
        static createValidator(arg0: $Commands$ParseFunction): $Predicate<string>;
        static executeCommandInContext(arg0: $CommandSourceStack, arg1: $Consumer<$ExecutionContext<$CommandSourceStack>>): void;
        static getParseException<S>(arg0: $ParseResults<S>): $CommandSyntaxException;
        static hasPermission<T>(arg0: $PermissionCheck): $PermissionProviderCheck<T>;
        static literal(arg0: string): $LiteralArgumentBuilder<$CommandSourceStack>;
        static mapSource<S>(arg0: $ParseResults<S>, arg1: $UnaryOperator<S>): $ParseResults<S>;
        static trimOptionalPrefix(arg0: string): string;
        static validateParseResults<S>(arg0: $ParseResults<S>): void;
        static validate(): void;
        performCommand(arg0: $ParseResults<$CommandSourceStack>, arg1: string): void;
        performPrefixedCommand(arg0: $CommandSourceStack, arg1: string): void;
        sendCommands(arg0: $ServerPlayer): void;
    }

    export class $Commands$CommandSelection {
        static ALL: $Commands$CommandSelection;
        static DEDICATED: $Commands$CommandSelection;
        static INTEGRATED: $Commands$CommandSelection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Commands$CommandSelection[];
        static valueOf(name: string): $Commands$CommandSelection;
    }

    export interface $Commands$ParseFunction {
        parse(arg0: $StringReader): void;
    }

    export interface $ExecutionCommandSource<T extends $ExecutionCommandSource<T>> extends $PermissionSetSupplier {
        callback(): $CommandResultCallback;
        clearCallbacks(): T;
        dispatcher(): $CommandDispatcher<T>;
        handleError(arg0: $CommandExceptionType, arg1: $Message, arg2: boolean, arg3: $TraceCallbacks): void;
        handleError(arg0: $CommandSyntaxException, arg1: boolean, arg2: $TraceCallbacks): void;
        isSilent(): boolean;
        resultConsumer<T>(): $ResultConsumer<T>;
        withCallback(arg0: $CommandResultCallback): T;
    }

    export interface $SharedSuggestionProvider extends $PermissionSetSupplier {
        customSuggestion(arg0: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        enabledFeatures(): $FeatureFlagSet;
        filterResources<T>(arg0: $Iterable<T>, arg1: string, arg2: string, arg3: $Function<T, $Identifier_>, arg4: $Consumer<T>): void;
        filterResources<T>(arg0: $Iterable<T>, arg1: string, arg2: $Function<T, $Identifier_>, arg3: $Consumer<T>): void;
        getAbsoluteCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        getAllTeams(): $Collection<string>;
        getAvailableSounds(): $Stream<$Identifier>;
        getCustomTabSuggestions(): $Collection<string>;
        getOnlinePlayerNames(): $Collection<string>;
        getRelevantCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        getSelectedEntities(): $Collection<string>;
        levels(): $Set<$ResourceKey<$Level>>;
        listSuggestions<S>(arg0: $CommandContext<S>, arg1: $SuggestionsBuilder, arg2: $ResourceKey<$Registry<any>>, arg3: $SharedSuggestionProvider$ElementSuggestionType_): $CompletableFuture<$Suggestions>;
        matchesSubStr(arg0: string, arg1: string): boolean;
        registryAccess(): $RegistryAccess;
        suggest2DCoordinates(arg0: string, arg1: $SharedSuggestionProvider$TextCoordinates[], arg2: $SuggestionsBuilder, arg3: $Predicate<string>): $CompletableFuture<$Suggestions>;
        suggestCoordinates(arg0: string, arg1: $SharedSuggestionProvider$TextCoordinates[], arg2: $SuggestionsBuilder, arg3: $Predicate<string>): $CompletableFuture<$Suggestions>;
        suggestRegistryElements(arg0: $HolderLookup<any>, arg1: $SharedSuggestionProvider$ElementSuggestionType_, arg2: $SuggestionsBuilder): void;
        suggestRegistryElements(arg0: $ResourceKey<$Registry<any>>, arg1: $SharedSuggestionProvider$ElementSuggestionType_, arg2: $SuggestionsBuilder, arg3: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        suggestResource<T>(arg0: $Iterable<T>, arg1: $SuggestionsBuilder, arg2: $Function<T, $Identifier_>, arg3: $Function<T, $Message>): $CompletableFuture<$Suggestions>;
        suggestResource(arg0: $Iterable<$Identifier_>, arg1: $SuggestionsBuilder, arg2: string): $CompletableFuture<$Suggestions>;
        suggestResource(arg0: $Iterable<$Identifier_>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggestResource<T>(arg0: $Stream<T>, arg1: $SuggestionsBuilder, arg2: $Function<T, $Identifier_>, arg3: $Function<T, $Message>): $CompletableFuture<$Suggestions>;
        suggestResource(arg0: $Stream<$Identifier_>, arg1: $SuggestionsBuilder, arg2: string): $CompletableFuture<$Suggestions>;
        suggestResource(arg0: $Stream<$Identifier_>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest<T>(arg0: $Iterable<T>, arg1: $SuggestionsBuilder, arg2: $Function<T, string>, arg3: $Function<T, $Message>): $CompletableFuture<$Suggestions>;
        suggest(arg0: $Iterable<string>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest(arg0: string[], arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest(arg0: $Stream<string>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        static MATCH_SPLITTER: $CharMatcher;
    }

    export class $SharedSuggestionProvider$ElementSuggestionType {
        static ALL: $SharedSuggestionProvider$ElementSuggestionType;
        static ELEMENTS: $SharedSuggestionProvider$ElementSuggestionType;
        static TAGS: $SharedSuggestionProvider$ElementSuggestionType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SharedSuggestionProvider$ElementSuggestionType[];
        static valueOf(name: string): $SharedSuggestionProvider$ElementSuggestionType;
    }

    export class $SharedSuggestionProvider$TextCoordinates {
        constructor(arg0: string, arg1: string, arg2: string);
        static DEFAULT_GLOBAL: $SharedSuggestionProvider$TextCoordinates;
        static DEFAULT_LOCAL: $SharedSuggestionProvider$TextCoordinates;
        x: string;
        y: string;
        z: string;
    }

    export type $Commands$CommandSelection_ = $Commands$CommandSelection | "ALL" | "DEDICATED" | "INTEGRATED";
    export type $SharedSuggestionProvider$ElementSuggestionType_ = $SharedSuggestionProvider$ElementSuggestionType | "ALL" | "ELEMENTS" | "TAGS";
}
