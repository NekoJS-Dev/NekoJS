import { $Boolean, $Integer, $String } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Map, $Optional, $Properties } from "java:java/util";
import { $Supplier, $UnaryOperator } from "java:java/util/function";
import { $SystemReport } from "java:net/minecraft";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $BlockPos, $BlockPos_, $HolderLookup$Provider, $RegistryAccess } from "java:net/minecraft/core";
import { $MinecraftServer, $MinecraftServer$ServerResourcePackInfo, $ServerInterface, $ServerLinks } from "java:net/minecraft/server";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $TextFilter } from "java:net/minecraft/server/network";
import { $LevelBasedPermissionSet, $PermissionSet } from "java:net/minecraft/server/permissions";
import { $NameAndId, $PlayerList } from "java:net/minecraft/server/players";
import { $Difficulty, $Difficulty_ } from "java:net/minecraft/world";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $DataPackConfig, $GameType, $GameType_ } from "java:net/minecraft/world/level";
import { $WorldDimensions, $WorldOptions } from "java:net/minecraft/world/level/levelgen";

declare module "java:net/minecraft/server/dedicated" {
    export class $DedicatedPlayerList extends $PlayerList {
        constructor(arg0: $DedicatedServer, arg1: $LayeredRegistryAccess<$RegistryLayer_>, arg2: $PlayerDataStorage);
        get server(): $DedicatedServer;
        getServer(): $DedicatedServer;
        canBypassPlayerLimit(arg0: $NameAndId): boolean;
        isWhiteListed(arg0: $NameAndId): boolean;
        reloadWhiteList(): void;
    }

    export class $DedicatedServer extends $MinecraftServer implements $ServerInterface {
        constructor(arg0: $Thread, arg1: $LevelStorageSource$LevelStorageAccess, arg2: $PackRepository, arg3: $WorldStem, arg4: $Optional<$GameRules>, arg5: $DedicatedServerSettings, arg6: $DataFixer, arg7: $Services, arg8: $ManagementServer, arg9: $NotificationManager);
        get absoluteMaxWorldSize(): number;
        getAbsoluteMaxWorldSize(): number;
        get chatSpamThresholdSeconds(): number;
        getChatSpamThresholdSeconds(): number;
        get codeOfConducts(): $Map<string, string>;
        getCodeOfConducts(): $Map<string, string>;
        get commandSpamThresholdSeconds(): number;
        getCommandSpamThresholdSeconds(): number;
        get compressionThreshold(): number;
        getCompressionThreshold(): number;
        get forcedGameType(): $GameType;
        getForcedGameType(): $GameType;
        get functionCompilationPermissions(): $PermissionSet;
        getFunctionCompilationPermissions(): $PermissionSet;
        get levelIdName(): string;
        getLevelIdName(): string;
        get maxChainedNeighborUpdates(): number;
        getMaxChainedNeighborUpdates(): number;
        get maxPlayers(): number;
        getMaxPlayers(): number;
        set maxPlayers(value: number);
        get maxTickLength(): number;
        getMaxTickLength(): number;
        get motd(): string;
        getMotd(): string;
        set motd(value: string);
        get playerList(): $DedicatedPlayerList;
        getPlayerList(): $DedicatedPlayerList;
        get pluginNames(): string;
        getPluginNames(): string;
        get properties(): $DedicatedServerProperties;
        getProperties(): $DedicatedServerProperties;
        get rateLimitPacketsPerSecond(): number;
        getRateLimitPacketsPerSecond(): number;
        get serverIp(): string;
        getServerIp(): string;
        get serverName(): string;
        getServerName(): string;
        get serverPort(): number;
        getServerPort(): number;
        get serverResourcePack(): $Optional<$MinecraftServer$ServerResourcePackInfo>;
        getServerResourcePack(): $Optional<$MinecraftServer$ServerResourcePackInfo>;
        get dedicatedServer(): boolean;
        isDedicatedServer(): boolean;
        get enforceWhitelist(): boolean;
        isEnforceWhitelist(): boolean;
        set enforceWhitelist(value: boolean);
        get published(): boolean;
        isPublished(): boolean;
        get tickTimeLoggingEnabled(): boolean;
        isTickTimeLoggingEnabled(): boolean;
        get usingWhitelist(): boolean;
        isUsingWhitelist(): boolean;
        set usingWhitelist(value: boolean);
        acceptsTransfers(): boolean;
        allowFlight(): boolean;
        createTextFilterForPlayer(arg0: $ServerPlayer): $TextFilter;
        dumpServerProperties(arg0: string): void;
        enforceSecureProfile(): boolean;
        entityBroadcastRangePercentage(): number;
        fillServerSystemReport(arg0: $SystemReport): $SystemReport;
        forceGameMode(): boolean;
        forceSynchronousWrites(): boolean;
        gameMode(): $GameType;
        getScaledTrackingDistance(arg0: number): number;
        handleConsoleInputs(): void;
        handleConsoleInput(arg0: string, arg1: $CommandSourceStack): void;
        hidesOnlinePlayers(): boolean;
        isSingleplayerOwner(arg0: $NameAndId): boolean;
        isUnderSpawnProtection(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $Player): boolean;
        logIPs(): boolean;
        operatorUserPermissions(): $LevelBasedPermissionSet;
        pauseWhenEmptySeconds(): number;
        playerIdleTimeout(): number;
        repliesToStatus(): boolean;
        runCommand(arg0: string): string;
        saveAllChunks(arg0: boolean, arg1: boolean, arg2: boolean): boolean;
        sendLowDiskSpaceWarning(): void;
        serverLinks(): $ServerLinks;
        shouldInformAdmins(): boolean;
        shouldRconBroadcast(): boolean;
        showGui(): void;
        simulationDistance(): number;
        spawnProtectionRadius(): number;
        statusHeartbeatInterval(): number;
        useNativeTransport(): boolean;
        viewDistance(): number;
    }

    export class $DedicatedServerProperties extends $Settings {
        constructor(arg0: $Properties);
        static MANAGEMENT_SERVER_TLS_ENABLED_KEY: string;
        static MANAGEMENT_SERVER_TLS_KEYSTORE_KEY: string;
        static MANAGEMENT_SERVER_TLS_KEYSTORE_PASSWORD_KEY: string;
        acceptsTransfers: $Settings$MutableValue<boolean>;
        allowFlight: $Settings$MutableValue<boolean>;
        announcePlayerAchievements: boolean;
        broadcastConsoleToOps: boolean;
        broadcastRconToOps: boolean;
        bugReportLink: string;
        chatSpamThresholdSeconds: number;
        codeOfConduct: boolean;
        commandSpamThresholdSeconds: number;
        difficulty: $Settings$MutableValue<$Difficulty>;
        enableJmxMonitoring: boolean;
        enableQuery: boolean;
        enableRcon: boolean;
        enableStatus: $Settings$MutableValue<boolean>;
        enforceSecureProfile: boolean;
        enforceWhitelist: $Settings$MutableValue<boolean>;
        entityBroadcastRangePercentage: $Settings$MutableValue<number>;
        forceGameMode: $Settings$MutableValue<boolean>;
        functionPermissions: $LevelBasedPermissionSet;
        gameMode: $Settings$MutableValue<$GameType>;
        hardcore: boolean;
        hideOnlinePlayers: $Settings$MutableValue<boolean>;
        initialDataPackConfiguration: $DataPackConfig;
        levelName: string;
        logIPs: boolean;
        managementServerAllowedOrigins: string;
        managementServerEnabled: boolean;
        managementServerHost: string;
        managementServerPort: number;
        managementServerSecret: string;
        managementServerTlsEnabled: boolean;
        managementServerTlsKeystore: string;
        managementServerTlsKeystorePassword: string;
        maxChainedNeighborUpdates: number;
        maxPlayers: $Settings$MutableValue<number>;
        maxTickTime: number;
        maxWorldSize: number;
        motd: $Settings$MutableValue<string>;
        networkCompressionThreshold: number;
        onlineMode: boolean;
        opPermissions: $Settings$MutableValue<$LevelBasedPermissionSet>;
        pauseWhenEmptySeconds: $Settings$MutableValue<number>;
        playerIdleTimeout: $Settings$MutableValue<number>;
        preventProxyConnections: boolean;
        queryPort: number;
        rateLimitPacketsPerSecond: number;
        rconPassword: string;
        rconPort: number;
        regionFileComression: string;
        serverIp: string;
        serverPort: number;
        serverResourcePackInfo: $Optional<$MinecraftServer$ServerResourcePackInfo>;
        simulationDistance: $Settings$MutableValue<number>;
        spawnProtection: $Settings$MutableValue<number>;
        statusHeartbeatInterval: $Settings$MutableValue<number>;
        syncChunkWrites: boolean;
        textFilteringConfig: string;
        textFilteringVersion: number;
        useNativeTransport: boolean;
        viewDistance: $Settings$MutableValue<number>;
        whiteList: $Settings$MutableValue<boolean>;
        worldOptions: $WorldOptions;
        static deserializePermission(arg0: string): $LevelBasedPermissionSet;
        static fromFile(arg0: string): $DedicatedServerProperties;
        static serializePermission(arg0: $LevelBasedPermissionSet): string;
        createDimensions(arg0: $HolderLookup$Provider): $WorldDimensions;
    }

    export class $DedicatedServerSettings {
        constructor(arg0: string);
        get properties(): $DedicatedServerProperties;
        getProperties(): $DedicatedServerProperties;
        forceSave(): void;
        update(arg0: $UnaryOperator<$DedicatedServerProperties>): $DedicatedServerSettings;
    }

    export class $Settings<T extends $Settings<T>> {
        constructor(arg0: $Properties);
        static loadFromFile(arg0: string): $Properties;
        store(arg0: string): void;
    }

    export class $Settings$MutableValue<V> implements $Supplier {
        get(): V;
        update(arg0: $RegistryAccess, arg1: V): T;
    }

}
