import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Record, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ItemStackTemplate } from "java:net/minecraft/world/item";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $PositionSource } from "java:net/minecraft/world/level/gameevent";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $Vector3f } from "java:org/joml";

declare module "java:net/minecraft/core/particles" {
    export class $BlockParticleOption implements $ParticleOptions {
        constructor(arg0: $ParticleType<$BlockParticleOption>, arg1: $BlockState_);
        constructor(arg0: $ParticleType<$BlockParticleOption>, arg1: $BlockState_, arg2: $BlockPos_);
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
        get type(): $ParticleType<$BlockParticleOption>;
        getType(): $ParticleType<$BlockParticleOption>;
        static codec(arg0: $ParticleType<$BlockParticleOption>): $MapCodec<$BlockParticleOption>;
        static streamCodec(arg0: $ParticleType<$BlockParticleOption>): $StreamCodec<any, $BlockParticleOption>;
    }

    export class $ColorParticleOption implements $ParticleOptions {
        get alpha(): number;
        getAlpha(): number;
        get blue(): number;
        getBlue(): number;
        get green(): number;
        getGreen(): number;
        get red(): number;
        getRed(): number;
        get type(): $ParticleType<$ColorParticleOption>;
        getType(): $ParticleType<$ColorParticleOption>;
        static codec(arg0: $ParticleType<$ColorParticleOption>): $MapCodec<$ColorParticleOption>;
        static create(arg0: $ParticleType<$ColorParticleOption>, arg1: number, arg2: number, arg3: number): $ColorParticleOption;
        static create(arg0: $ParticleType<$ColorParticleOption>, arg1: number): $ColorParticleOption;
        static streamCodec(arg0: $ParticleType<$ColorParticleOption>): $StreamCodec<any, $ColorParticleOption>;
    }

    export class $DustColorTransitionOptions extends $ScalableParticleOptionsBase {
        constructor(arg0: number, arg1: number, arg2: number);
        static CODEC: $MapCodec<$DustColorTransitionOptions>;
        static SCULK_PARTICLE_COLOR: number;
        static SCULK_TO_REDSTONE: $DustColorTransitionOptions;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DustColorTransitionOptions>;
        get fromColor(): $Vector3f;
        getFromColor(): $Vector3f;
        get toColor(): $Vector3f;
        getToColor(): $Vector3f;
        get type(): $ParticleType<$DustColorTransitionOptions>;
        getType(): $ParticleType<$DustColorTransitionOptions>;
    }

    export class $DustParticleOptions extends $ScalableParticleOptionsBase {
        constructor(arg0: number, arg1: number);
        static CODEC: $MapCodec<$DustParticleOptions>;
        static REDSTONE: $DustParticleOptions;
        static REDSTONE_PARTICLE_COLOR: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DustParticleOptions>;
        get color(): $Vector3f;
        getColor(): $Vector3f;
        get type(): $ParticleType<$DustParticleOptions>;
        getType(): $ParticleType<$DustParticleOptions>;
    }

    export class $ExplosionParticleInfo extends $Record {
        constructor(particle: $ParticleOptions, scaling: number, speed: number);
        static CODEC: $MapCodec<$ExplosionParticleInfo>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ExplosionParticleInfo>;
        equals(arg0: object): boolean;
        hashCode(): number;
        particle(): $ParticleOptions;
        scaling(): number;
        speed(): number;
        toString(): string;
    }

    export class $GeyserBaseParticleOptions extends $Record implements $ParticleOptions {
        constructor(type: $ParticleType<$GeyserBaseParticleOptions>, waterBlocks: number, burstImpulseBase: number);
        get type(): $ParticleType<$GeyserBaseParticleOptions>;
        getType(): $ParticleType<$GeyserBaseParticleOptions>;
        static codec(arg0: $ParticleType<$GeyserBaseParticleOptions>): $MapCodec<$GeyserBaseParticleOptions>;
        static streamCodec(arg0: $ParticleType<$GeyserBaseParticleOptions>): $StreamCodec<any, $GeyserBaseParticleOptions>;
        burstImpulseBase(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $ParticleType<$GeyserBaseParticleOptions>;
        waterBlocks(): number;
    }

    export class $GeyserParticleOptions extends $Record implements $ParticleOptions {
        constructor(type: $ParticleType<$GeyserParticleOptions>, waterBlocks: number);
        get type(): $ParticleType<$GeyserParticleOptions>;
        getType(): $ParticleType<$GeyserParticleOptions>;
        static codec(arg0: $ParticleType<$GeyserParticleOptions>): $MapCodec<$GeyserParticleOptions>;
        static streamCodec(arg0: $ParticleType<$GeyserParticleOptions>): $StreamCodec<any, $GeyserParticleOptions>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $ParticleType<$GeyserParticleOptions>;
        waterBlocks(): number;
    }

    export class $ItemParticleOption implements $ParticleOptions {
        constructor(arg0: $ParticleType<$ItemParticleOption>, arg1: $Item_);
        constructor(arg0: $ParticleType<$ItemParticleOption>, arg1: $ItemStackTemplate);
        get item(): $ItemStackTemplate;
        getItem(): $ItemStackTemplate;
        get type(): $ParticleType<$ItemParticleOption>;
        getType(): $ParticleType<$ItemParticleOption>;
        static codec(arg0: $ParticleType<$ItemParticleOption>): $MapCodec<$ItemParticleOption>;
        static streamCodec(arg0: $ParticleType<$ItemParticleOption>): $StreamCodec<any, $ItemParticleOption>;
    }

    export interface $ParticleOptions {
        getType(): $ParticleType<any>;
    }

    export class $ParticleType<T extends $ParticleOptions> {
        get overrideLimiter(): boolean;
        getOverrideLimiter(): boolean;
        codec(): $MapCodec<T>;
        streamCodec(): $StreamCodec<any, T>;
    }

    export class $ParticleTypes {
        constructor();
        static ANGRY_VILLAGER: $SimpleParticleType;
        static ASH: $SimpleParticleType;
        static BLOCK: $ParticleType<$BlockParticleOption>;
        static BLOCK_CRUMBLE: $ParticleType<$BlockParticleOption>;
        static BLOCK_MARKER: $ParticleType<$BlockParticleOption>;
        static BUBBLE: $SimpleParticleType;
        static BUBBLE_COLUMN_UP: $SimpleParticleType;
        static BUBBLE_POP: $SimpleParticleType;
        static CAMPFIRE_COSY_SMOKE: $SimpleParticleType;
        static CAMPFIRE_SIGNAL_SMOKE: $SimpleParticleType;
        static CHERRY_LEAVES: $SimpleParticleType;
        static CLOUD: $SimpleParticleType;
        static CODEC: $Codec<$ParticleOptions>;
        static COMPOSTER: $SimpleParticleType;
        static COPPER_FIRE_FLAME: $SimpleParticleType;
        static CRIMSON_SPORE: $SimpleParticleType;
        static CRIT: $SimpleParticleType;
        static CURRENT_DOWN: $SimpleParticleType;
        static DAMAGE_INDICATOR: $SimpleParticleType;
        static DOLPHIN: $SimpleParticleType;
        static DRAGON_BREATH: $ParticleType<$PowerParticleOption>;
        static DRIPPING_DRIPSTONE_LAVA: $SimpleParticleType;
        static DRIPPING_DRIPSTONE_WATER: $SimpleParticleType;
        static DRIPPING_HONEY: $SimpleParticleType;
        static DRIPPING_LAVA: $SimpleParticleType;
        static DRIPPING_OBSIDIAN_TEAR: $SimpleParticleType;
        static DRIPPING_WATER: $SimpleParticleType;
        static DUST: $ParticleType<$DustParticleOptions>;
        static DUST_COLOR_TRANSITION: $ParticleType<$DustColorTransitionOptions>;
        static DUST_PILLAR: $ParticleType<$BlockParticleOption>;
        static DUST_PLUME: $SimpleParticleType;
        static EFFECT: $ParticleType<$SpellParticleOption>;
        static EGG_CRACK: $SimpleParticleType;
        static ELDER_GUARDIAN: $SimpleParticleType;
        static ELECTRIC_SPARK: $SimpleParticleType;
        static ENCHANT: $SimpleParticleType;
        static ENCHANTED_HIT: $SimpleParticleType;
        static END_ROD: $SimpleParticleType;
        static ENTITY_EFFECT: $ParticleType<$ColorParticleOption>;
        static EXPLOSION: $SimpleParticleType;
        static EXPLOSION_EMITTER: $SimpleParticleType;
        static FALLING_DRIPSTONE_LAVA: $SimpleParticleType;
        static FALLING_DRIPSTONE_WATER: $SimpleParticleType;
        static FALLING_DUST: $ParticleType<$BlockParticleOption>;
        static FALLING_HONEY: $SimpleParticleType;
        static FALLING_LAVA: $SimpleParticleType;
        static FALLING_NECTAR: $SimpleParticleType;
        static FALLING_OBSIDIAN_TEAR: $SimpleParticleType;
        static FALLING_SPORE_BLOSSOM: $SimpleParticleType;
        static FALLING_WATER: $SimpleParticleType;
        static FIREFLY: $SimpleParticleType;
        static FIREWORK: $SimpleParticleType;
        static FISHING: $SimpleParticleType;
        static FLAME: $SimpleParticleType;
        static FLASH: $ParticleType<$ColorParticleOption>;
        static GEYSER: $ParticleType<$GeyserParticleOptions>;
        static GEYSER_BASE: $ParticleType<$GeyserBaseParticleOptions>;
        static GEYSER_PLUME: $ParticleType<$GeyserParticleOptions>;
        static GEYSER_POOF: $ParticleType<$GeyserBaseParticleOptions>;
        static GLOW: $SimpleParticleType;
        static GLOW_SQUID_INK: $SimpleParticleType;
        static GUST: $SimpleParticleType;
        static GUST_EMITTER_LARGE: $SimpleParticleType;
        static GUST_EMITTER_SMALL: $SimpleParticleType;
        static HAPPY_VILLAGER: $SimpleParticleType;
        static HEART: $SimpleParticleType;
        static INFESTED: $SimpleParticleType;
        static INSTANT_EFFECT: $ParticleType<$SpellParticleOption>;
        static ITEM: $ParticleType<$ItemParticleOption>;
        static ITEM_COBWEB: $SimpleParticleType;
        static ITEM_SLIME: $SimpleParticleType;
        static ITEM_SNOWBALL: $SimpleParticleType;
        static LANDING_HONEY: $SimpleParticleType;
        static LANDING_LAVA: $SimpleParticleType;
        static LANDING_OBSIDIAN_TEAR: $SimpleParticleType;
        static LARGE_SMOKE: $SimpleParticleType;
        static LAVA: $SimpleParticleType;
        static MYCELIUM: $SimpleParticleType;
        static NAUTILUS: $SimpleParticleType;
        static NOTE: $SimpleParticleType;
        static NOXIOUS_GAS: $SimpleParticleType;
        static NOXIOUS_GAS_CLOUD: $SimpleParticleType;
        static OMINOUS_SPAWNING: $SimpleParticleType;
        static PALE_OAK_LEAVES: $SimpleParticleType;
        static PAUSE_MOB_GROWTH: $SimpleParticleType;
        static POOF: $SimpleParticleType;
        static PORTAL: $SimpleParticleType;
        static RAID_OMEN: $SimpleParticleType;
        static RAIN: $SimpleParticleType;
        static RESET_MOB_GROWTH: $SimpleParticleType;
        static REVERSE_PORTAL: $SimpleParticleType;
        static SCRAPE: $SimpleParticleType;
        static SCULK_CHARGE: $ParticleType<$SculkChargeParticleOptions>;
        static SCULK_CHARGE_POP: $SimpleParticleType;
        static SCULK_SOUL: $SimpleParticleType;
        static SHRIEK: $ParticleType<$ShriekParticleOption>;
        static SMALL_FLAME: $SimpleParticleType;
        static SMALL_GUST: $SimpleParticleType;
        static SMOKE: $SimpleParticleType;
        static SNEEZE: $SimpleParticleType;
        static SNOWFLAKE: $SimpleParticleType;
        static SONIC_BOOM: $SimpleParticleType;
        static SOUL: $SimpleParticleType;
        static SOUL_FIRE_FLAME: $SimpleParticleType;
        static SPIT: $SimpleParticleType;
        static SPLASH: $SimpleParticleType;
        static SPORE_BLOSSOM_AIR: $SimpleParticleType;
        static SQUID_INK: $SimpleParticleType;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ParticleOptions>;
        static SULFUR_BUBBLES: $SimpleParticleType;
        static SULFUR_CUBE_GOO: $SimpleParticleType;
        static SWEEP_ATTACK: $SimpleParticleType;
        static TINTED_LEAVES: $ParticleType<$ColorParticleOption>;
        static TOTEM_OF_UNDYING: $SimpleParticleType;
        static TRAIL: $ParticleType<$TrailParticleOption>;
        static TRIAL_OMEN: $SimpleParticleType;
        static TRIAL_SPAWNER_DETECTED_PLAYER: $SimpleParticleType;
        static TRIAL_SPAWNER_DETECTED_PLAYER_OMINOUS: $SimpleParticleType;
        static UNDERWATER: $SimpleParticleType;
        static VAULT_CONNECTION: $SimpleParticleType;
        static VIBRATION: $ParticleType<$VibrationParticleOption>;
        static WARPED_SPORE: $SimpleParticleType;
        static WAX_OFF: $SimpleParticleType;
        static WAX_ON: $SimpleParticleType;
        static WHITE_ASH: $SimpleParticleType;
        static WHITE_SMOKE: $SimpleParticleType;
        static WITCH: $SimpleParticleType;
    }

    export class $PowerParticleOption implements $ParticleOptions {
        get power(): number;
        getPower(): number;
        get type(): $ParticleType<$PowerParticleOption>;
        getType(): $ParticleType<$PowerParticleOption>;
        static codec(arg0: $ParticleType<$PowerParticleOption>): $MapCodec<$PowerParticleOption>;
        static create(arg0: $ParticleType<$PowerParticleOption>, arg1: number): $PowerParticleOption;
        static streamCodec(arg0: $ParticleType<$PowerParticleOption>): $StreamCodec<any, $PowerParticleOption>;
    }

    export class $ScalableParticleOptionsBase implements $ParticleOptions {
        constructor(arg0: number);
        static MAX_SCALE: number;
        static MIN_SCALE: number;
        get scale(): number;
        getScale(): number;
    }

    export class $SculkChargeParticleOptions extends $Record implements $ParticleOptions {
        constructor(roll: number);
        static CODEC: $MapCodec<$SculkChargeParticleOptions>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $SculkChargeParticleOptions>;
        get type(): $ParticleType<$SculkChargeParticleOptions>;
        getType(): $ParticleType<$SculkChargeParticleOptions>;
        equals(arg0: object): boolean;
        hashCode(): number;
        roll(): number;
        toString(): string;
    }

    export class $ShriekParticleOption implements $ParticleOptions {
        constructor(arg0: number);
        static CODEC: $MapCodec<$ShriekParticleOption>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ShriekParticleOption>;
        get delay(): number;
        getDelay(): number;
        get type(): $ParticleType<$ShriekParticleOption>;
        getType(): $ParticleType<$ShriekParticleOption>;
    }

    export class $SimpleParticleType extends $ParticleType implements $ParticleOptions {
        constructor(arg0: boolean);
        get type(): $SimpleParticleType;
        getType(): $SimpleParticleType;
        codec(): $MapCodec<$SimpleParticleType>;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, $SimpleParticleType>;
    }

    export class $SpellParticleOption implements $ParticleOptions {
        get blue(): number;
        getBlue(): number;
        get green(): number;
        getGreen(): number;
        get power(): number;
        getPower(): number;
        get red(): number;
        getRed(): number;
        get type(): $ParticleType<$SpellParticleOption>;
        getType(): $ParticleType<$SpellParticleOption>;
        static codec(arg0: $ParticleType<$SpellParticleOption>): $MapCodec<$SpellParticleOption>;
        static create(arg0: $ParticleType<$SpellParticleOption>, arg1: number, arg2: number, arg3: number, arg4: number): $SpellParticleOption;
        static create(arg0: $ParticleType<$SpellParticleOption>, arg1: number, arg2: number): $SpellParticleOption;
        static streamCodec(arg0: $ParticleType<$SpellParticleOption>): $StreamCodec<any, $SpellParticleOption>;
    }

    export class $TrailParticleOption extends $Record implements $ParticleOptions {
        constructor(target: $Vec3_, color: number, duration: number);
        static CODEC: $MapCodec<$TrailParticleOption>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $TrailParticleOption>;
        get type(): $ParticleType<$TrailParticleOption>;
        getType(): $ParticleType<$TrailParticleOption>;
        color(): number;
        duration(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        target(): $Vec3;
        toString(): string;
    }

    export class $VibrationParticleOption implements $ParticleOptions {
        constructor(arg0: $PositionSource, arg1: number);
        static CODEC: $MapCodec<$VibrationParticleOption>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $VibrationParticleOption>;
        get arrivalInTicks(): number;
        getArrivalInTicks(): number;
        get destination(): $PositionSource;
        getDestination(): $PositionSource;
        get type(): $ParticleType<$VibrationParticleOption>;
        getType(): $ParticleType<$VibrationParticleOption>;
    }

    export type $ParticleType_ = $ParticleType | RegistryTypes.ParticleType | $NekoId | string;
}
