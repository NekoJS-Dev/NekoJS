import { $Record, $String } from "java:java/lang";

declare module "java:com/mojang/authlib/minecraft/report" {
    export class $AbuseReportLimits extends $Record {
        constructor(maxOpinionCommentsLength: number, maxReportedMessageCount: number, maxEvidenceMessageCount: number, leadingContextMessageCount: number, trailingContextMessageCount: number);
        static DEFAULTS: $AbuseReportLimits;
        equals(arg0: object): boolean;
        hashCode(): number;
        leadingContextMessageCount(): number;
        maxEvidenceMessageCount(): number;
        maxOpinionCommentsLength(): number;
        maxReportedMessageCount(): number;
        toString(): string;
        trailingContextMessageCount(): number;
    }

}
