import { $JsonElement } from "java:com/google/gson";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List, $Map, $Set } from "java:java/util";

declare module "java:com/tkisor/nekojs/api/recipe/definition" {
    export class $RecipeFieldDefinition extends $Record {
        constructor(name: string, path: string, kind: $RecipeFieldKind_, array: boolean, optional: boolean, defaultValue: $JsonElement, role: $RecipeFieldRole_);
        array(): boolean;
        defaultValue(): $JsonElement;
        equals(o: object): boolean;
        hashCode(): number;
        kind(): $RecipeFieldKind;
        name(): string;
        optional(): boolean;
        path(): string;
        required(): boolean;
        role(): $RecipeFieldRole;
        toString(): string;
    }

    export class $RecipeFieldKind {
        static BOOLEAN: $RecipeFieldKind;
        static FLUID_INGREDIENT: $RecipeFieldKind;
        static FLUID_STACK: $RecipeFieldKind;
        static INGREDIENT: $RecipeFieldKind;
        static INT: $RecipeFieldKind;
        static ITEM_STACK: $RecipeFieldKind;
        static JSON: $RecipeFieldKind;
        static NUMBER: $RecipeFieldKind;
        static SIZED_FLUID_INGREDIENT: $RecipeFieldKind;
        static STRING: $RecipeFieldKind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RecipeFieldKind[];
        static valueOf(name: string): $RecipeFieldKind;
    }

    export class $RecipeFieldRole {
        static INPUT: $RecipeFieldRole;
        static OTHER: $RecipeFieldRole;
        static OUTPUT: $RecipeFieldRole;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RecipeFieldRole[];
        static valueOf(name: string): $RecipeFieldRole;
    }

    export class $RecipeTypeDefinition extends $Record {
        constructor(namespace: string, name: string, type: string, idPrefix: string, constructors: string[][], fields: { [key: string]: $RecipeFieldDefinition }, unique: string[]);
        constructors(): $List<$List<string>>;
        equals(o: object): boolean;
        fields(): $Map<string, $RecipeFieldDefinition>;
        hashCode(): number;
        idPrefix(): string;
        key(): string;
        namespace(): string;
        name(): string;
        prefix(): string;
        toString(): string;
        type(): string;
        unique(): $List<string>;
    }

    export class $RecipeTypeDefinitionRegistry {
        constructor(definitions: { [key: string]: { [key: string]: $RecipeTypeDefinition } });
        static EMPTY: $RecipeTypeDefinitionRegistry;
        static builder(): $RecipeTypeDefinitionRegistry$Builder;
        get(namespace: string, type: string): $RecipeTypeDefinition;
        hasNamespace(namespace: string): boolean;
        hasType(namespace: string, type: string): boolean;
        merge(other: $RecipeTypeDefinitionRegistry): $RecipeTypeDefinitionRegistry;
        namespaces(): $Set<string>;
        types(namespace: string): $Set<string>;
    }

    export class $RecipeTypeDefinitionRegistry$Builder {
        constructor();
        add(definition: $RecipeTypeDefinition): $RecipeTypeDefinitionRegistry$Builder;
        build(): $RecipeTypeDefinitionRegistry;
    }

    export type $RecipeFieldKind_ = $RecipeFieldKind | "BOOLEAN" | "FLUID_INGREDIENT" | "FLUID_STACK" | "INGREDIENT" | "INT" | "ITEM_STACK" | "JSON" | "NUMBER" | "SIZED_FLUID_INGREDIENT" | "STRING";
    export type $RecipeFieldRole_ = $RecipeFieldRole | "INPUT" | "OTHER" | "OUTPUT";
}
