import { $Serializable } from "java:java/io";
import { $Enum, $Long, $String } from "java:java/lang";
import { $Duration } from "java:java/time";
import { $ResolverStyle, $ResolverStyle_ } from "java:java/time/format";
import { $List, $Locale, $Map } from "java:java/util";

declare module "java:java/time/temporal" {
    export class $ChronoUnit {
        static CENTURIES: $ChronoUnit;
        static DAYS: $ChronoUnit;
        static DECADES: $ChronoUnit;
        static ERAS: $ChronoUnit;
        static FOREVER: $ChronoUnit;
        static HALF_DAYS: $ChronoUnit;
        static HOURS: $ChronoUnit;
        static MICROS: $ChronoUnit;
        static MILLENNIA: $ChronoUnit;
        static MILLIS: $ChronoUnit;
        static MINUTES: $ChronoUnit;
        static MONTHS: $ChronoUnit;
        static NANOS: $ChronoUnit;
        static SECONDS: $ChronoUnit;
        static WEEKS: $ChronoUnit;
        static YEARS: $ChronoUnit;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChronoUnit[];
        static valueOf(name: string): $ChronoUnit;
    }

    export interface $Temporal extends $TemporalAccessor {
        isSupported(arg0: $TemporalUnit): boolean;
        minus(arg0: $TemporalAmount): $Temporal;
        minus(arg0: number, arg1: $TemporalUnit): $Temporal;
        plus(arg0: $TemporalAmount): $Temporal;
        plus(arg0: number, arg1: $TemporalUnit): $Temporal;
        until(arg0: $Temporal, arg1: $TemporalUnit): number;
        with(arg0: $TemporalAdjuster): $Temporal;
        with(arg0: $TemporalField, arg1: number): $Temporal;
    }

    export interface $TemporalAccessor {
        getLong(arg0: $TemporalField): number;
        get(arg0: $TemporalField): number;
        isSupported(arg0: $TemporalField): boolean;
        query<R>(arg0: $TemporalQuery<R>): R;
        range(arg0: $TemporalField): $ValueRange;
    }

    export interface $TemporalAdjuster {
        adjustInto(arg0: $Temporal): $Temporal;
    }

    export interface $TemporalAmount {
        addTo(arg0: $Temporal): $Temporal;
        getUnits(): $List<$TemporalUnit>;
        get(arg0: $TemporalUnit): number;
        subtractFrom(arg0: $Temporal): $Temporal;
    }

    export interface $TemporalField {
        adjustInto<R>(arg0: R, arg1: number): R;
        getBaseUnit(): $TemporalUnit;
        getDisplayName(arg0: $Locale): string;
        getFrom(arg0: $TemporalAccessor): number;
        getRangeUnit(): $TemporalUnit;
        isDateBased(): boolean;
        isSupportedBy(arg0: $TemporalAccessor): boolean;
        isTimeBased(): boolean;
        rangeRefinedBy(arg0: $TemporalAccessor): $ValueRange;
        range(): $ValueRange;
        resolve(arg0: { [key: $TemporalField]: number }, arg1: $TemporalAccessor, arg2: $ResolverStyle_): $TemporalAccessor;
        toString(): string;
    }

    export interface $TemporalQuery<R> {
        queryFrom(arg0: $TemporalAccessor): R;
    }

    export interface $TemporalUnit {
        addTo<R>(arg0: R, arg1: number): R;
        between(arg0: $Temporal, arg1: $Temporal): number;
        getDuration(): $Duration;
        isDateBased(): boolean;
        isDurationEstimated(): boolean;
        isSupportedBy(arg0: $Temporal): boolean;
        isTimeBased(): boolean;
        toString(): string;
    }

    export class $ValueRange implements $Serializable {
        get largestMinimum(): number;
        getLargestMinimum(): number;
        get maximum(): number;
        getMaximum(): number;
        get minimum(): number;
        getMinimum(): number;
        get smallestMaximum(): number;
        getSmallestMaximum(): number;
        get fixed(): boolean;
        isFixed(): boolean;
        get intValue(): boolean;
        isIntValue(): boolean;
        static of(arg0: number, arg1: number, arg2: number, arg3: number): $ValueRange;
        static of(arg0: number, arg1: number, arg2: number): $ValueRange;
        static of(arg0: number, arg1: number): $ValueRange;
        checkValidIntValue(arg0: number, arg1: $TemporalField): number;
        checkValidValue(arg0: number, arg1: $TemporalField): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        isValidIntValue(arg0: number): boolean;
        isValidValue(arg0: number): boolean;
        toString(): string;
    }

    export type $ChronoUnit_ = $ChronoUnit | "CENTURIES" | "DAYS" | "DECADES" | "ERAS" | "FOREVER" | "HALF_DAYS" | "HOURS" | "MICROS" | "MILLENNIA" | "MILLIS" | "MINUTES" | "MONTHS" | "NANOS" | "SECONDS" | "WEEKS" | "YEARS";
}
