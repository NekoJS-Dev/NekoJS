import { $JsonElement } from "java:com/google/gson";
import { $ChannelHandlerContext, $SimpleChannelInboundHandler } from "java:io/netty/channel";
import { $SslContext } from "java:io/netty/handler/ssl";
import { $String, $Throwable } from "java:java/lang";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Holder$Reference } from "java:net/minecraft/core";
import { $MinecraftApi } from "java:net/minecraft/server/jsonrpc/internalapi";
import { $NotificationManager } from "java:net/minecraft/server/notifications";

export * as internalapi from "java:net/minecraft/server/jsonrpc/internalapi";
export * as security from "java:net/minecraft/server/jsonrpc/security";

declare module "java:net/minecraft/server/jsonrpc" {
    export class $Connection extends $SimpleChannelInboundHandler {
        constructor(arg0: $Channel, arg1: $ManagementServer, arg2: $MinecraftApi, arg3: $JsonRpcLogger);
        channelActive(arg0: $ChannelHandlerContext): void;
        channelInactive(arg0: $ChannelHandlerContext): void;
        dispatchIncomingRequest(arg0: string, arg1: $JsonElement): $JsonElement;
        exceptionCaught(arg0: $ChannelHandlerContext, arg1: $Throwable): void;
        sendNotification<Params>(arg0: $Holder$Reference<$OutgoingRpcMethod<Params, any>>, arg1: Params): void;
        sendNotification(arg0: $Holder$Reference<$OutgoingRpcMethod<void, any>>): void;
        sendRequest<Params, Result>(arg0: $Holder$Reference<$OutgoingRpcMethod<Params, Result>>, arg1: Params): $CompletableFuture<Result>;
        sendRequest<Result>(arg0: $Holder$Reference<$OutgoingRpcMethod<void, Result>>): $CompletableFuture<Result>;
        tick(): void;
    }

    export class $ManagementServer {
        constructor(arg0: $HostAndPort, arg1: $AuthenticationHandler);
        constructor(arg0: $HostAndPort, arg1: $AuthenticationHandler, arg2: $EventLoopGroup);
        get port(): number;
        getPort(): number;
        onConnected(arg0: $Connection): void;
        onDisconnected(arg0: $Connection): void;
        scheduleHeartbeat(arg0: $NotificationManager, arg1: number): boolean;
        startWithTls(arg0: $MinecraftApi, arg1: $SslContext): void;
        startWithoutTls(arg0: $MinecraftApi): void;
        stop(arg0: boolean): void;
        tick(): void;
    }

}
