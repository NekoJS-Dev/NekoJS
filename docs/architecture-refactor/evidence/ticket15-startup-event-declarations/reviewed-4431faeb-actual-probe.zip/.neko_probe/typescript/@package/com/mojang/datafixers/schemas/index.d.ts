import { $DSL$TypeReference } from "java:com/mojang/datafixers";
import { $Type } from "java:com/mojang/datafixers/types";
import { $TaggedChoice$TaggedChoiceType, $TypeTemplate } from "java:com/mojang/datafixers/types/templates";
import { $String } from "java:java/lang";
import { $Map, $Set } from "java:java/util";
import { $Function, $Supplier } from "java:java/util/function";

declare module "java:com/mojang/datafixers/schemas" {
    export class $Schema {
        constructor(arg0: number, arg1: $Schema);
        get parent(): $Schema;
        getParent(): $Schema;
        get versionKey(): number;
        getVersionKey(): number;
        findChoiceType(arg0: $DSL$TypeReference): $TaggedChoice$TaggedChoiceType<any>;
        getChoiceType(arg0: $DSL$TypeReference, arg1: string): $Type<any>;
        getTypeRaw(arg0: $DSL$TypeReference): $Type<any>;
        getType(arg0: $DSL$TypeReference): $Type<any>;
        id(arg0: string): $TypeTemplate;
        registerBlockEntities(arg0: $Schema): $Map<string, $Supplier<$TypeTemplate>>;
        registerEntities(arg0: $Schema): $Map<string, $Supplier<$TypeTemplate>>;
        registerSimple(arg0: { [key: string]: $Supplier<$TypeTemplate> }, arg1: string): void;
        registerTypes(arg0: $Schema, arg1: { [key: string]: $Supplier<$TypeTemplate> }, arg2: { [key: string]: $Supplier<$TypeTemplate> }): void;
        registerType(arg0: boolean, arg1: $DSL$TypeReference, arg2: $Supplier<$TypeTemplate>): void;
        register(arg0: { [key: string]: $Supplier<$TypeTemplate> }, arg1: string, arg2: $Function<string, $TypeTemplate>): void;
        register(arg0: { [key: string]: $Supplier<$TypeTemplate> }, arg1: string, arg2: $Supplier<$TypeTemplate>): void;
        resolveTemplate(arg0: string): $TypeTemplate;
        types(): $Set<string>;
    }

}
