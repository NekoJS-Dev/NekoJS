export * as data from "java:net/minecraft/network/chat/contents/data";
export * as objects from "java:net/minecraft/network/chat/contents/objects";

