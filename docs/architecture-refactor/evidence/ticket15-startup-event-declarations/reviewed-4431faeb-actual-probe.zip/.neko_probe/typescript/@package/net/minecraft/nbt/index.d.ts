import { $Codec, $DynamicOps, $MapCodec } from "java:com/mojang/serialization";
import { $DataInput, $DataOutput } from "java:java/io";
import { $Boolean, $Byte, $Double, $Enum, $Float, $Integer, $Iterable, $Long, $Number, $Record, $Short, $String, $StringBuilder } from "java:java/lang";
import { $AbstractList, $Collection, $Iterator, $Map, $Map$Entry, $Optional, $Set } from "java:java/util";
import { $BiConsumer } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";

declare module "java:net/minecraft/nbt" {
    export class $ByteArrayTag implements $CollectionTag {
        constructor(arg0: number[]);
        static TYPE: $TagType<$ByteArrayTag>;
        get asByteArray(): number[];
        getAsByteArray(): number[];
        get id(): number;
        getId(): number;
        get type(): $TagType<$ByteArrayTag>;
        getType(): $TagType<$ByteArrayTag>;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        addTag(arg0: number, arg1: $Tag): boolean;
        asByteArray(): $Optional<number[]>;
        clear(): void;
        copy(): $Tag;
        equals(arg0: object): boolean;
        get(arg0: number): $ByteTag;
        hashCode(): number;
        remove(arg0: number): $ByteTag;
        setTag(arg0: number, arg1: $Tag): boolean;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $ByteTag extends $Record implements $NumericTag {
        constructor(value: number);
        static ONE: $ByteTag;
        static TYPE: $TagType<$ByteTag>;
        static ZERO: $ByteTag;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ByteTag>;
        getType(): $TagType<$ByteTag>;
        static valueOf(arg0: boolean): $ByteTag;
        static valueOf(arg0: number): $ByteTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $ByteTag;
        doubleValue(): number;
        equals(arg0: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(arg0: $DataOutput): void;
    }

    export interface $CollectionTag extends $Tag, $Iterable {
        addTag(arg0: number, arg1: $Tag): boolean;
        clear(): void;
        get(arg0: number): $Tag;
        isEmpty(): boolean;
        iterator(): $Iterator<$Tag>;
        remove(arg0: number): $Tag;
        setTag(arg0: number, arg1: $Tag): boolean;
        size(): number;
        stream(): $Stream<$Tag>;
    }

    export class $CompoundTag implements $Tag {
        constructor();
        constructor(arg0: number);
        static CODEC: $Codec<$CompoundTag>;
        static TYPE: $TagType<$CompoundTag>;
        tags: $Map<string, $Tag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$CompoundTag>;
        getType(): $TagType<$CompoundTag>;
        get empty(): boolean;
        isEmpty(): boolean;
        static readNamedTagData(arg0: $TagType<any>, arg1: string, arg2: $DataInput, arg3: $NbtAccounter): $Tag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        asCompound(): $Optional<$CompoundTag>;
        contains(arg0: string): boolean;
        copy(): $CompoundTag;
        entrySet(): $Set<$Map$Entry<string, $Tag>>;
        equals(arg0: object): boolean;
        forEach(arg0: $BiConsumer<string, $Tag>): void;
        getBooleanOr(arg0: string, arg1: boolean): boolean;
        getBoolean(arg0: string): $Optional<boolean>;
        getByteArray(arg0: string): $Optional<number[]>;
        getByteOr(arg0: string, arg1: number): number;
        getByte(arg0: string): $Optional<number>;
        getCompoundOrEmpty(arg0: string): $CompoundTag;
        getCompound(arg0: string): $Optional<$CompoundTag>;
        getDoubleOr(arg0: string, arg1: number): number;
        getDouble(arg0: string): $Optional<number>;
        getFloatOr(arg0: string, arg1: number): number;
        getFloat(arg0: string): $Optional<number>;
        getIntArray(arg0: string): $Optional<number[]>;
        getIntOr(arg0: string, arg1: number): number;
        getInt(arg0: string): $Optional<number>;
        getListOrEmpty(arg0: string): $ListTag;
        getList(arg0: string): $Optional<$ListTag>;
        getLongArray(arg0: string): $Optional<number[]>;
        getLongOr(arg0: string, arg1: number): number;
        getLong(arg0: string): $Optional<number>;
        getShortOr(arg0: string, arg1: number): number;
        getShort(arg0: string): $Optional<number>;
        getStringOr(arg0: string, arg1: string): string;
        getString(arg0: string): $Optional<string>;
        get(arg0: string): $Tag;
        hashCode(): number;
        keySet(): $Set<string>;
        merge(arg0: $CompoundTag_): $CompoundTag;
        putBoolean(arg0: string, arg1: boolean): void;
        putByteArray(arg0: string, arg1: number[]): void;
        putByte(arg0: string, arg1: number): void;
        putDouble(arg0: string, arg1: number): void;
        putFloat(arg0: string, arg1: number): void;
        putIntArray(arg0: string, arg1: number[]): void;
        putInt(arg0: string, arg1: number): void;
        putLongArray(arg0: string, arg1: number[]): void;
        putLong(arg0: string, arg1: number): void;
        putShort(arg0: string, arg1: number): void;
        putString(arg0: string, arg1: string): void;
        put(arg0: string, arg1: $Tag): $Tag;
        read<T>(arg0: $MapCodec<T>, arg1: $DynamicOps<$Tag>): $Optional<T>;
        read<T>(arg0: $MapCodec<T>): $Optional<T>;
        read<T>(arg0: string, arg1: $Codec<T>, arg2: $DynamicOps<$Tag>): $Optional<T>;
        read<T>(arg0: string, arg1: $Codec<T>): $Optional<T>;
        remove(arg0: string): $Tag;
        sizeInBytes(): number;
        size(): number;
        storeNullable<T>(arg0: string, arg1: $Codec<T>, arg2: T): void;
        storeNullable<T>(arg0: string, arg1: $Codec<T>, arg2: $DynamicOps<$Tag>, arg3: T): void;
        store<T>(arg0: $MapCodec<T>, arg1: T): void;
        store<T>(arg0: $MapCodec<T>, arg1: $DynamicOps<$Tag>, arg2: T): void;
        store<T>(arg0: string, arg1: $Codec<T>, arg2: T): void;
        store<T>(arg0: string, arg1: $Codec<T>, arg2: $DynamicOps<$Tag>, arg3: T): void;
        toString(): string;
        values(): $Collection<$Tag>;
        write(arg0: $DataOutput): void;
    }

    export class $DoubleTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$DoubleTag>;
        static ZERO: $DoubleTag;
        get id(): number;
        getId(): number;
        get type(): $TagType<$DoubleTag>;
        getType(): $TagType<$DoubleTag>;
        static valueOf(arg0: number): $DoubleTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $DoubleTag;
        doubleValue(): number;
        equals(arg0: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(arg0: $DataOutput): void;
    }

    export class $EndTag implements $Tag {
        static INSTANCE: $EndTag;
        static TYPE: $TagType<$EndTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$EndTag>;
        getType(): $TagType<$EndTag>;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $EndTag;
        sizeInBytes(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $FloatTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$FloatTag>;
        static ZERO: $FloatTag;
        get id(): number;
        getId(): number;
        get type(): $TagType<$FloatTag>;
        getType(): $TagType<$FloatTag>;
        static valueOf(arg0: number): $FloatTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $FloatTag;
        doubleValue(): number;
        equals(arg0: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(arg0: $DataOutput): void;
    }

    export class $IntArrayTag implements $CollectionTag {
        constructor(arg0: number[]);
        static TYPE: $TagType<$IntArrayTag>;
        get asIntArray(): number[];
        getAsIntArray(): number[];
        get id(): number;
        getId(): number;
        get type(): $TagType<$IntArrayTag>;
        getType(): $TagType<$IntArrayTag>;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        addTag(arg0: number, arg1: $Tag): boolean;
        asIntArray(): $Optional<number[]>;
        clear(): void;
        copy(): $IntArrayTag;
        equals(arg0: object): boolean;
        get(arg0: number): $IntTag;
        hashCode(): number;
        remove(arg0: number): $IntTag;
        setTag(arg0: number, arg1: $Tag): boolean;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $IntTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$IntTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$IntTag>;
        getType(): $TagType<$IntTag>;
        static valueOf(arg0: number): $IntTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $IntTag;
        doubleValue(): number;
        equals(arg0: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(arg0: $DataOutput): void;
    }

    export class $ListTag extends $AbstractList implements $CollectionTag {
        constructor();
        constructor(arg0: number);
        static TYPE: $TagType<$ListTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ListTag>;
        getType(): $TagType<$ListTag>;
        get empty(): boolean;
        isEmpty(): boolean;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        addAndUnwrap(arg0: $Tag): void;
        addTag(arg0: number, arg1: $Tag): boolean;
        add(arg0: number, arg1: $Tag): void;
        asList(): $Optional<$ListTag>;
        clear(): void;
        compoundStream(): $Stream<$CompoundTag>;
        copy(): $ListTag;
        equals(arg0: object): boolean;
        getCompoundOrEmpty(arg0: number): $CompoundTag;
        getCompound(arg0: number): $Optional<$CompoundTag>;
        getDoubleOr(arg0: number, arg1: number): number;
        getDouble(arg0: number): $Optional<number>;
        getFloatOr(arg0: number, arg1: number): number;
        getFloat(arg0: number): $Optional<number>;
        getIntArray(arg0: number): $Optional<number[]>;
        getIntOr(arg0: number, arg1: number): number;
        getInt(arg0: number): $Optional<number>;
        getListOrEmpty(arg0: number): $ListTag;
        getList(arg0: number): $Optional<$ListTag>;
        getLongArray(arg0: number): $Optional<number[]>;
        getShortOr(arg0: number, arg1: number): number;
        getShort(arg0: number): $Optional<number>;
        getStringOr(arg0: number, arg1: string): string;
        getString(arg0: number): $Optional<string>;
        get(arg0: number): $Tag;
        hashCode(): number;
        remove(arg0: number): $Tag;
        setTag(arg0: number, arg1: $Tag): boolean;
        set(arg0: number, arg1: $Tag): $Tag;
        sizeInBytes(): number;
        size(): number;
        stream(): $Stream<$Tag>;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $LongArrayTag implements $CollectionTag {
        constructor(arg0: number[]);
        static TYPE: $TagType<$LongArrayTag>;
        get asLongArray(): number[];
        getAsLongArray(): number[];
        get id(): number;
        getId(): number;
        get type(): $TagType<$LongArrayTag>;
        getType(): $TagType<$LongArrayTag>;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        addTag(arg0: number, arg1: $Tag): boolean;
        asLongArray(): $Optional<number[]>;
        clear(): void;
        copy(): $LongArrayTag;
        equals(arg0: object): boolean;
        get(arg0: number): $LongTag;
        hashCode(): number;
        remove(arg0: number): $LongTag;
        setTag(arg0: number, arg1: $Tag): boolean;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $LongTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$LongTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$LongTag>;
        getType(): $TagType<$LongTag>;
        static valueOf(arg0: number): $LongTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $LongTag;
        doubleValue(): number;
        equals(arg0: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(arg0: $DataOutput): void;
    }

    export class $NbtAccounter {
        constructor(arg0: number, arg1: number);
        static DEFAULT_NBT_QUOTA: number;
        static UNCOMPRESSED_NBT_QUOTA: number;
        get depth(): number;
        getDepth(): number;
        get usage(): number;
        getUsage(): number;
        static create(arg0: number): $NbtAccounter;
        static defaultQuota(): $NbtAccounter;
        static uncompressedQuota(): $NbtAccounter;
        static unlimitedHeap(): $NbtAccounter;
        accountBytes(arg0: number, arg1: number): void;
        accountBytes(arg0: number): void;
        popDepth(): void;
        pushDepth(): void;
        readUTF(arg0: string): string;
    }

    export interface $NumericTag extends $PrimitiveTag {
        asBoolean(): $Optional<boolean>;
        asByte(): $Optional<number>;
        asDouble(): $Optional<number>;
        asFloat(): $Optional<number>;
        asInt(): $Optional<number>;
        asLong(): $Optional<number>;
        asNumber(): $Optional<number>;
        asShort(): $Optional<number>;
        box(): number;
        byteValue(): number;
        doubleValue(): number;
        floatValue(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
    }

    export interface $PrimitiveTag extends $Tag {
        copy(): $Tag;
    }

    export class $ShortTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$ShortTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ShortTag>;
        getType(): $TagType<$ShortTag>;
        static valueOf(arg0: number): $ShortTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $ShortTag;
        doubleValue(): number;
        equals(arg0: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(arg0: $DataOutput): void;
    }

    export interface $StreamTagVisitor {
        visitContainerEnd(): $StreamTagVisitor$ValueResult;
        visitElement(arg0: $TagType<any>, arg1: number): $StreamTagVisitor$EntryResult;
        visitEnd(): $StreamTagVisitor$ValueResult;
        visitEntry(arg0: $TagType<any>, arg1: string): $StreamTagVisitor$EntryResult;
        visitEntry(arg0: $TagType<any>): $StreamTagVisitor$EntryResult;
        visitList(arg0: $TagType<any>, arg1: number): $StreamTagVisitor$ValueResult;
        visitRootEntry(arg0: $TagType<any>): $StreamTagVisitor$ValueResult;
        visit(arg0: number[]): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: number[]): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: string): $StreamTagVisitor$ValueResult;
        visit(arg0: number[]): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
    }

    export class $StreamTagVisitor$EntryResult {
        static BREAK: $StreamTagVisitor$EntryResult;
        static ENTER: $StreamTagVisitor$EntryResult;
        static HALT: $StreamTagVisitor$EntryResult;
        static SKIP: $StreamTagVisitor$EntryResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StreamTagVisitor$EntryResult[];
        static valueOf(name: string): $StreamTagVisitor$EntryResult;
    }

    export class $StreamTagVisitor$ValueResult {
        static BREAK: $StreamTagVisitor$ValueResult;
        static CONTINUE: $StreamTagVisitor$ValueResult;
        static HALT: $StreamTagVisitor$ValueResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StreamTagVisitor$ValueResult[];
        static valueOf(name: string): $StreamTagVisitor$ValueResult;
    }

    export class $StringTag extends $Record implements $PrimitiveTag {
        constructor(value: string);
        static TYPE: $TagType<$StringTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$StringTag>;
        getType(): $TagType<$StringTag>;
        static escapeWithoutQuotes(arg0: string, arg1: $StringBuilder): void;
        static escapeWithoutQuotes(arg0: string): string;
        static quoteAndEscape(arg0: string, arg1: $StringBuilder): void;
        static quoteAndEscape(arg0: string): string;
        static skipString(arg0: $DataInput): void;
        static valueOf(arg0: string): $StringTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        asString(): $Optional<string>;
        copy(): $StringTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): string;
        write(arg0: $DataOutput): void;
    }

    export interface $Tag {
        acceptAsRoot(arg0: $StreamTagVisitor): void;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        asBoolean(): $Optional<boolean>;
        asByteArray(): $Optional<number[]>;
        asByte(): $Optional<number>;
        asCompound(): $Optional<$CompoundTag>;
        asDouble(): $Optional<number>;
        asFloat(): $Optional<number>;
        asIntArray(): $Optional<number[]>;
        asInt(): $Optional<number>;
        asList(): $Optional<$ListTag>;
        asLongArray(): $Optional<number[]>;
        asLong(): $Optional<number>;
        asNumber(): $Optional<number>;
        asShort(): $Optional<number>;
        asString(): $Optional<string>;
        copy(): $Tag;
        getId(): number;
        getType(): $TagType<any>;
        sizeInBytes(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
        static ARRAY_HEADER: number;
        static MAX_DEPTH: number;
        static OBJECT_HEADER: number;
        static OBJECT_REFERENCE: number;
        static STRING_SIZE: number;
        static TAG_BYTE: number;
        static TAG_BYTE_ARRAY: number;
        static TAG_COMPOUND: number;
        static TAG_DOUBLE: number;
        static TAG_END: number;
        static TAG_FLOAT: number;
        static TAG_INT: number;
        static TAG_INT_ARRAY: number;
        static TAG_LIST: number;
        static TAG_LONG: number;
        static TAG_LONG_ARRAY: number;
        static TAG_SHORT: number;
        static TAG_STRING: number;
    }

    export interface $TagType<T extends $Tag> {
        createInvalid(arg0: number): $TagType<$EndTag>;
        getName(): string;
        getPrettyName(): string;
        load(arg0: $DataInput, arg1: $NbtAccounter): T;
        parseRoot(arg0: $DataInput, arg1: $StreamTagVisitor, arg2: $NbtAccounter): void;
        parse(arg0: $DataInput, arg1: $StreamTagVisitor, arg2: $NbtAccounter): $StreamTagVisitor$ValueResult;
        skip(arg0: $DataInput, arg1: number, arg2: $NbtAccounter): void;
        skip(arg0: $DataInput, arg1: $NbtAccounter): void;
    }

    export interface $TagVisitor {
        visitByteArray(arg0: $ByteArrayTag): void;
        visitByte(arg0: $ByteTag): void;
        visitCompound(arg0: $CompoundTag_): void;
        visitDouble(arg0: $DoubleTag): void;
        visitEnd(arg0: $EndTag): void;
        visitFloat(arg0: $FloatTag): void;
        visitIntArray(arg0: $IntArrayTag): void;
        visitInt(arg0: $IntTag): void;
        visitList(arg0: $ListTag): void;
        visitLongArray(arg0: $LongArrayTag): void;
        visitLong(arg0: $LongTag): void;
        visitShort(arg0: $ShortTag): void;
        visitString(arg0: $StringTag): void;
    }

    export type $CompoundTag_ = $CompoundTag | { [key: string]: any };
    export type $StreamTagVisitor$EntryResult_ = $StreamTagVisitor$EntryResult | "BREAK" | "ENTER" | "HALT" | "SKIP";
    export type $StreamTagVisitor$ValueResult_ = $StreamTagVisitor$ValueResult | "BREAK" | "CONTINUE" | "HALT";
}
