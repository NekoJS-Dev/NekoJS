import { $GameProfile } from "java:com/mojang/authlib";
import { $Channel, $ChannelFutureListener, $EventLoopGroup } from "java:io/netty/channel";
import { $Class, $Exception, $Record, $String } from "java:java/lang";
import { $InetAddress, $SocketAddress } from "java:java/net";
import { $List, $Set, $UUID } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Connection, $DisconnectionDetails, $PacketProcessor, $TickablePacketListener } from "java:net/minecraft/network";
import { $ChatType$Bound, $Component, $Component_, $FilterMask, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ServerCommonPacketListener, $ServerboundClientInformationPacket, $ServerboundCustomClickActionPacket, $ServerboundCustomPayloadPacket, $ServerboundKeepAlivePacket, $ServerboundPongPacket, $ServerboundResourcePackPacket } from "java:net/minecraft/network/protocol/common";
import { $ServerboundCookieResponsePacket } from "java:net/minecraft/network/protocol/cookie";
import { $GameProtocols$Context, $ServerGamePacketListener, $ServerboundAcceptTeleportationPacket, $ServerboundAttackPacket, $ServerboundBlockEntityTagQueryPacket, $ServerboundChangeDifficultyPacket, $ServerboundChangeGameModePacket, $ServerboundChatAckPacket, $ServerboundChatCommandPacket, $ServerboundChatCommandSignedPacket, $ServerboundChatPacket, $ServerboundChatSessionUpdatePacket, $ServerboundChunkBatchReceivedPacket, $ServerboundClientCommandPacket, $ServerboundClientTickEndPacket, $ServerboundCommandSuggestionPacket, $ServerboundConfigurationAcknowledgedPacket, $ServerboundContainerButtonClickPacket, $ServerboundContainerClickPacket, $ServerboundContainerClosePacket, $ServerboundContainerSlotStateChangedPacket, $ServerboundDebugSubscriptionRequestPacket, $ServerboundEditBookPacket, $ServerboundEntityTagQueryPacket, $ServerboundInteractPacket, $ServerboundJigsawGeneratePacket, $ServerboundLockDifficultyPacket, $ServerboundMovePlayerPacket, $ServerboundMoveVehiclePacket, $ServerboundPaddleBoatPacket, $ServerboundPickItemFromBlockPacket, $ServerboundPickItemFromEntityPacket, $ServerboundPlaceRecipePacket, $ServerboundPlayerAbilitiesPacket, $ServerboundPlayerActionPacket, $ServerboundPlayerCommandPacket, $ServerboundPlayerInputPacket, $ServerboundPlayerLoadedPacket, $ServerboundRecipeBookChangeSettingsPacket, $ServerboundRecipeBookSeenRecipePacket, $ServerboundRenameItemPacket, $ServerboundSeenAdvancementsPacket, $ServerboundSelectBundleItemPacket, $ServerboundSelectTradePacket, $ServerboundSetBeaconPacket, $ServerboundSetCarriedItemPacket, $ServerboundSetCommandBlockPacket, $ServerboundSetCommandMinecartPacket, $ServerboundSetCreativeModeSlotPacket, $ServerboundSetGameRulePacket, $ServerboundSetJigsawBlockPacket, $ServerboundSetStructureBlockPacket, $ServerboundSetTestBlockPacket, $ServerboundSignUpdatePacket, $ServerboundSpectatorActionPacket, $ServerboundSwingPacket, $ServerboundTeleportToEntityPacket, $ServerboundTestInstanceBlockActionPacket, $ServerboundUseItemOnPacket, $ServerboundUseItemPacket } from "java:net/minecraft/network/protocol/game";
import { $ServerboundPingRequestPacket } from "java:net/minecraft/network/protocol/ping";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $ClientInformation, $ServerPlayer } from "java:net/minecraft/server/level";
import { $PositionMoveRotation, $Relative, $Relative_ } from "java:net/minecraft/world/entity";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $LevelChunk } from "java:net/minecraft/world/level/chunk";
import { $ConnectionType, $ConnectionType_ } from "java:net/neoforged/neoforge/network/connection";

declare module "java:net/minecraft/server/network" {
    export class $CommonListenerCookie extends $Record {
        constructor(arg0: $GameProfile, arg1: number, arg2: $ClientInformation, arg3: boolean);
        constructor(gameProfile: $GameProfile, latency: number, clientInformation: $ClientInformation, transferred: boolean, connectionType: $ConnectionType_);
        static createInitial(arg0: $GameProfile, arg1: boolean): $CommonListenerCookie;
        clientInformation(): $ClientInformation;
        connectionType(): $ConnectionType;
        equals(arg0: object): boolean;
        gameProfile(): $GameProfile;
        hashCode(): number;
        latency(): number;
        toString(): string;
        transferred(): boolean;
    }

    export class $EventLoopGroupHolder {
        static local(): $EventLoopGroupHolder;
        static remote(arg0: boolean): $EventLoopGroupHolder;
        channelCls(): $Class<$Channel>;
        eventLoopGroup(): $EventLoopGroup;
        serverChannelCls(): $Class<$ServerChannel>;
        serverEventLoopGroup(): $EventLoopGroup;
    }

    export class $FilteredText extends $Record {
        constructor(raw: string, mask: $FilterMask);
        static EMPTY: $FilteredText;
        get filtered(): boolean;
        isFiltered(): boolean;
        static fullyFiltered(arg0: string): $FilteredText;
        static passThrough(arg0: string): $FilteredText;
        equals(arg0: object): boolean;
        filteredOrEmpty(): string;
        filtered(): string;
        hashCode(): number;
        mask(): $FilterMask;
        raw(): string;
        toString(): string;
    }

    export class $PlayerChunkSender {
        constructor(arg0: boolean);
        static MAX_CHUNKS_PER_TICK: number;
        static MIN_CHUNKS_PER_TICK: number;
        dropChunk(arg0: $ServerPlayer, arg1: $ChunkPos): void;
        isPending(arg0: number): boolean;
        markChunkPendingToSend(arg0: $LevelChunk): void;
        onChunkBatchReceivedByClient(arg0: number): void;
        sendNextChunks(arg0: $ServerPlayer): void;
    }

    export class $ServerCommonPacketListenerImpl implements $ServerCommonPacketListener {
        constructor(arg0: $MinecraftServer, arg1: $Connection, arg2: $CommonListenerCookie);
        static LATENCY_CHECK_INTERVAL: number;
        get connectionType(): $ConnectionType;
        getConnectionType(): $ConnectionType;
        get connection(): $Connection;
        getConnection(): $Connection;
        get owner(): $GameProfile;
        getOwner(): $GameProfile;
        get packetProcessor(): $PacketProcessor;
        getPacketProcessor(): $PacketProcessor;
        disconnect(arg0: $DisconnectionDetails): void;
        disconnect(arg0: $Component_): void;
        handleCookieResponse(arg0: $ServerboundCookieResponsePacket): void;
        handleCustomClickAction(arg0: $ServerboundCustomClickActionPacket): void;
        handleCustomPayload(arg0: $ServerboundCustomPayloadPacket): void;
        handleKeepAlive(arg0: $ServerboundKeepAlivePacket): void;
        handlePong(arg0: $ServerboundPongPacket): void;
        handleResourcePackResponse(arg0: $ServerboundResourcePackPacket): void;
        latency(): number;
        onDisconnect(arg0: $DisconnectionDetails): void;
        onPacketError(arg0: $Packet, arg1: $Exception): void;
        resumeFlushing(): void;
        send(arg0: $Packet<any>, arg1: $ChannelFutureListener): void;
        send(arg0: $Packet<any>): void;
        suspendFlushing(): void;
    }

    export class $ServerConnectionListener {
        constructor(arg0: $MinecraftServer);
        running: boolean;
        get connections(): $List<$Connection>;
        getConnections(): $List<$Connection>;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get sessionId(): $UUID;
        getSessionId(): $UUID;
        acceptChannel(arg0: $Channel, arg1: string): void;
        startMemoryChannel(): $SocketAddress;
        startTcpServerListener(arg0: $InetAddress, arg1: number): void;
        stopTcpServerListener(): void;
        stop(): void;
        tick(): void;
    }

    export class $ServerGamePacketListenerImpl extends $ServerCommonPacketListenerImpl implements $ServerGamePacketListener, $ServerPlayerConnection, $TickablePacketListener, $GameProtocols$Context {
        constructor(arg0: $MinecraftServer, arg1: $Connection, arg2: $ServerPlayer, arg3: $CommonListenerCookie);
        static CLIENT_LOADED_TIMEOUT_TIME: number;
        chunkSender: $PlayerChunkSender;
        player: $ServerPlayer;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get remoteAddress(): $SocketAddress;
        getRemoteAddress(): $SocketAddress;
        get acceptingMessages(): boolean;
        isAcceptingMessages(): boolean;
        ackBlockChangesUpTo(arg0: number): void;
        handleAcceptPlayerLoad(arg0: $ServerboundPlayerLoadedPacket): void;
        handleAcceptTeleportPacket(arg0: $ServerboundAcceptTeleportationPacket): void;
        handleAnimate(arg0: $ServerboundSwingPacket): void;
        handleAttack(arg0: $ServerboundAttackPacket): void;
        handleBlockEntityTagQuery(arg0: $ServerboundBlockEntityTagQueryPacket): void;
        handleBundleItemSelectedPacket(arg0: $ServerboundSelectBundleItemPacket): void;
        handleChangeDifficulty(arg0: $ServerboundChangeDifficultyPacket): void;
        handleChangeGameMode(arg0: $ServerboundChangeGameModePacket): void;
        handleChatAck(arg0: $ServerboundChatAckPacket): void;
        handleChatCommand(arg0: $ServerboundChatCommandPacket): void;
        handleChatSessionUpdate(arg0: $ServerboundChatSessionUpdatePacket): void;
        handleChat(arg0: $ServerboundChatPacket): void;
        handleChunkBatchReceived(arg0: $ServerboundChunkBatchReceivedPacket): void;
        handleClientCommand(arg0: $ServerboundClientCommandPacket): void;
        handleClientInformation(arg0: $ServerboundClientInformationPacket): void;
        handleClientTickEnd(arg0: $ServerboundClientTickEndPacket): void;
        handleConfigurationAcknowledged(arg0: $ServerboundConfigurationAcknowledgedPacket): void;
        handleContainerButtonClick(arg0: $ServerboundContainerButtonClickPacket): void;
        handleContainerClick(arg0: $ServerboundContainerClickPacket): void;
        handleContainerClose(arg0: $ServerboundContainerClosePacket): void;
        handleContainerSlotStateChanged(arg0: $ServerboundContainerSlotStateChangedPacket): void;
        handleCustomCommandSuggestions(arg0: $ServerboundCommandSuggestionPacket): void;
        handleCustomPayload(arg0: $ServerboundCustomPayloadPacket): void;
        handleDebugSubscriptionRequest(arg0: $ServerboundDebugSubscriptionRequestPacket): void;
        handleEditBook(arg0: $ServerboundEditBookPacket): void;
        handleEntityTagQuery(arg0: $ServerboundEntityTagQueryPacket): void;
        handleInteract(arg0: $ServerboundInteractPacket): void;
        handleJigsawGenerate(arg0: $ServerboundJigsawGeneratePacket): void;
        handleLockDifficulty(arg0: $ServerboundLockDifficultyPacket): void;
        handleMovePlayer(arg0: $ServerboundMovePlayerPacket): void;
        handleMoveVehicle(arg0: $ServerboundMoveVehiclePacket): void;
        handlePaddleBoat(arg0: $ServerboundPaddleBoatPacket): void;
        handlePickItemFromBlock(arg0: $ServerboundPickItemFromBlockPacket): void;
        handlePickItemFromEntity(arg0: $ServerboundPickItemFromEntityPacket): void;
        handlePingRequest(arg0: $ServerboundPingRequestPacket): void;
        handlePlaceRecipe(arg0: $ServerboundPlaceRecipePacket): void;
        handlePlayerAbilities(arg0: $ServerboundPlayerAbilitiesPacket): void;
        handlePlayerAction(arg0: $ServerboundPlayerActionPacket): void;
        handlePlayerCommand(arg0: $ServerboundPlayerCommandPacket): void;
        handlePlayerInput(arg0: $ServerboundPlayerInputPacket): void;
        handleRecipeBookChangeSettingsPacket(arg0: $ServerboundRecipeBookChangeSettingsPacket): void;
        handleRecipeBookSeenRecipePacket(arg0: $ServerboundRecipeBookSeenRecipePacket): void;
        handleRenameItem(arg0: $ServerboundRenameItemPacket): void;
        handleSeenAdvancements(arg0: $ServerboundSeenAdvancementsPacket): void;
        handleSelectTrade(arg0: $ServerboundSelectTradePacket): void;
        handleSetBeaconPacket(arg0: $ServerboundSetBeaconPacket): void;
        handleSetCarriedItem(arg0: $ServerboundSetCarriedItemPacket): void;
        handleSetCommandBlock(arg0: $ServerboundSetCommandBlockPacket): void;
        handleSetCommandMinecart(arg0: $ServerboundSetCommandMinecartPacket): void;
        handleSetCreativeModeSlot(arg0: $ServerboundSetCreativeModeSlotPacket): void;
        handleSetGameRule(arg0: $ServerboundSetGameRulePacket): void;
        handleSetJigsawBlock(arg0: $ServerboundSetJigsawBlockPacket): void;
        handleSetStructureBlock(arg0: $ServerboundSetStructureBlockPacket): void;
        handleSetTestBlock(arg0: $ServerboundSetTestBlockPacket): void;
        handleSignUpdate(arg0: $ServerboundSignUpdatePacket): void;
        handleSignedChatCommand(arg0: $ServerboundChatCommandSignedPacket): void;
        handleSpectatorAction(arg0: $ServerboundSpectatorActionPacket): void;
        handleTeleportToEntityPacket(arg0: $ServerboundTeleportToEntityPacket): void;
        handleTestInstanceBlockAction(arg0: $ServerboundTestInstanceBlockActionPacket): void;
        handleUseItemOn(arg0: $ServerboundUseItemOnPacket): void;
        handleUseItem(arg0: $ServerboundUseItemPacket): void;
        hasClientLoaded(): boolean;
        hasInfiniteMaterials(): boolean;
        markClientLoaded(): void;
        markClientUnloadedAfterDeath(): void;
        onDisconnect(arg0: $DisconnectionDetails): void;
        resetFlyingTicks(): void;
        resetPosition(): void;
        sendDisguisedChatMessage(arg0: $Component_, arg1: $ChatType$Bound): void;
        sendPlayerChatMessage(arg0: $PlayerChatMessage, arg1: $ChatType$Bound): void;
        shouldHandleMessage(arg0: $Packet<any>): boolean;
        switchToConfig(): void;
        teleport(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): void;
        teleport(arg0: $PositionMoveRotation, arg1: $Relative_[]): void;
        tickClientLoadTimeout(): void;
        tick(): void;
    }

    export interface $ServerPlayerConnection {
        getPlayer(): $ServerPlayer;
        send(arg0: $Packet<any>): void;
    }

    export interface $TextFilter {
        join(): void;
        leave(): void;
        processMessageBundle(arg0: string[]): $CompletableFuture<$List<$FilteredText>>;
        processStreamMessage(arg0: string): $CompletableFuture<$FilteredText>;
        static DUMMY: $TextFilter;
    }

}
