import { $ContextChain } from "java:com/mojang/brigadier/context";
import { $AutoCloseable, $Record, $String } from "java:java/lang";
import { $CommandResultCallback } from "java:net/minecraft/commands";
import { $InstantiatedFunction } from "java:net/minecraft/commands/functions";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ProfilerFiller } from "java:net/minecraft/util/profiling";

declare module "java:net/minecraft/commands/execution" {
    export class $CommandQueueEntry<T> extends $Record {
        constructor(frame: $Frame, action: $EntryAction<T>);
        action(): $EntryAction<T>;
        equals(arg0: object): boolean;
        execute(arg0: $ExecutionContext<T>): void;
        frame(): $Frame;
        hashCode(): number;
        toString(): string;
    }

    export interface $EntryAction<T> {
        execute(arg0: $ExecutionContext<T>, arg1: $Frame): void;
    }

    export class $ExecutionContext<T> implements $AutoCloseable {
        constructor(arg0: number, arg1: number, arg2: $ProfilerFiller);
        static queueInitialCommandExecution<T>(arg0: $ExecutionContext<T>, arg1: string, arg2: $ContextChain<T>, arg3: T, arg4: $CommandResultCallback): void;
        static queueInitialFunctionCall<T>(arg0: $ExecutionContext<T>, arg1: $InstantiatedFunction<T>, arg2: T, arg3: $CommandResultCallback): void;
        close(): void;
        discardAtDepthOrHigher(arg0: number): void;
        forkLimit(): number;
        frameControlForDepth(arg0: number): $Frame$FrameControl;
        incrementCost(): void;
        profiler(): $ProfilerFiller;
        queueNext(arg0: $CommandQueueEntry<T>): void;
        runCommandQueue(): void;
        tracer(arg0: $TraceCallbacks): void;
        tracer(): $TraceCallbacks;
    }

    export class $Frame extends $Record {
        constructor(depth: number, returnValueConsumer: $CommandResultCallback, frameControl: $Frame$FrameControl);
        depth(): number;
        discard(): void;
        equals(arg0: object): boolean;
        frameControl(): $Frame$FrameControl;
        hashCode(): number;
        returnFailure(): void;
        returnSuccess(arg0: number): void;
        returnValueConsumer(): $CommandResultCallback;
        toString(): string;
    }

    export interface $Frame$FrameControl {
        discard(): void;
    }

    export interface $TraceCallbacks extends $AutoCloseable {
        close(): void;
        onCall(arg0: number, arg1: $Identifier_, arg2: number): void;
        onCommand(arg0: number, arg1: string): void;
        onError(arg0: string): void;
        onReturn(arg0: number, arg1: string, arg2: number): void;
    }

    export interface $UnboundEntryAction<T> {
        bind(arg0: T): $EntryAction<T>;
        execute(arg0: T, arg1: $ExecutionContext<T>, arg2: $Frame): void;
    }

}
