import { $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $ConnectionProtocol, $ConnectionProtocol_ } from "java:net/minecraft/network";
import { $StreamCodec, $StreamDecoder, $StreamMemberEncoder } from "java:net/minecraft/network/codec";
import { $PacketFlow, $PacketFlow_ } from "java:net/minecraft/network/protocol";
import { $ClientboundCustomPayloadPacket, $ServerboundCustomPayloadPacket } from "java:net/minecraft/network/protocol/common";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/network/protocol/common/custom" {
    export interface $CustomPacketPayload {
        codec<B, T>(arg0: $StreamMemberEncoder<B, T>, arg1: $StreamDecoder<B, T>): $StreamCodec<B, T>;
        codec<B>(arg0: $CustomPacketPayload$FallbackProvider<B>, arg1: $CustomPacketPayload$TypeAndCodec<any, any>[], arg2: $ConnectionProtocol_, arg3: $PacketFlow_): $StreamCodec<B, $CustomPacketPayload>;
        createType<T>(arg0: string): $CustomPacketPayload$Type<T>;
        toVanillaClientbound(): $ClientboundCustomPayloadPacket;
        toVanillaServerbound(): $ServerboundCustomPayloadPacket;
        type(): $CustomPacketPayload$Type<$CustomPacketPayload>;
    }

    export interface $CustomPacketPayload$FallbackProvider<B extends $FriendlyByteBuf> {
        create(arg0: $Identifier_): $StreamCodec<B, $CustomPacketPayload>;
    }

    export class $CustomPacketPayload$Type<T extends $CustomPacketPayload> extends $Record {
        constructor(id: $Identifier_);
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
    }

    export class $CustomPacketPayload$TypeAndCodec<B extends $FriendlyByteBuf, T extends $CustomPacketPayload> extends $Record {
        constructor(type: $CustomPacketPayload$Type<T>, codec: $StreamCodec<B, T>);
        codec(): $StreamCodec<B, T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $CustomPacketPayload$Type<T>;
    }

}
