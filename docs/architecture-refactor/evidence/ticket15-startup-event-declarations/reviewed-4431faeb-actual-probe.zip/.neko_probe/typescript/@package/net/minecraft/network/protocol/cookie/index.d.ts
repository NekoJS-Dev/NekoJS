import { $Record, $String } from "java:java/lang";
import { $ClientboundPacketListener, $FriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ServerPacketListener } from "java:net/minecraft/network/protocol/game";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/network/protocol/cookie" {
    export interface $ClientCookiePacketListener extends $ClientboundPacketListener {
        handleRequestCookie(arg0: $ClientboundCookieRequestPacket): void;
    }

    export class $ClientboundCookieRequestPacket extends $Record implements $Packet {
        constructor(key: $Identifier_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundCookieRequestPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCookiePacketListener): void;
        hashCode(): number;
        key(): $Identifier;
        toString(): string;
        type(): $PacketType<$ClientboundCookieRequestPacket>;
    }

    export interface $ServerCookiePacketListener extends $ServerPacketListener {
        handleCookieResponse(arg0: $ServerboundCookieResponsePacket): void;
    }

    export class $ServerboundCookieResponsePacket extends $Record implements $Packet {
        constructor(key: $Identifier_, payload: number[]);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCookieResponsePacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCookiePacketListener): void;
        hashCode(): number;
        key(): $Identifier;
        payload(): number[];
        toString(): string;
        type(): $PacketType<$ServerboundCookieResponsePacket>;
    }

}
