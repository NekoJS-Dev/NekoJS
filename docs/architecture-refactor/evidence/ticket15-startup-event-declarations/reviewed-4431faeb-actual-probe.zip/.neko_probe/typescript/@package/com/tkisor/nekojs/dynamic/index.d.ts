import { $String } from "java:java/lang";
import { $Consumer } from "java:java/util/function";

declare module "java:com/tkisor/nekojs/dynamic" {
    /** Handle for a DynamicRegistry registration; the entry itself lives in the vanilla registry. */
    export class $DynamicEntryHandle {
        /**
         * The registered entry id, e.g. 'mymod:ruby'.
         * @returns entry id string
         */
        id(): string;
        /**
         * The registration mode: 'world' or 'reloadable'.
         * @returns mode name string
         */
        mode(): string;
        /**
         * The script id that claimed this entry, e.g. 'nekojs:server/packs/foo/main.js'.
         * @returns owning script id string
         */
        owner(): string;
        toString(): string;
    }

    /**
     * Runtime (post-server-start) registry registration for SERVER scripts: soundEvent, mobEffect, item.
     * Requires a running server and engine.toml [dynamicRegistry] enabled=true (default false).
     * Entries survive /nekojs reload; scripts re-claim ids by registering them again.
     */
    export class $DynamicRegistryJS {
        static INSTANCE: $DynamicRegistryJS;
        /**
         * Registers (or re-claims) an item and binds its default components immediately.
         * @param id item id like 'mymod:ruby'
         * @param config builder callback: mode(...) / maxStackSize(...) / rarity(...) / fireResistant(...)
         * @returns handle exposing id() / mode() / owner()
         */
        item(id: string, config: $Consumer<$DynamicRegistryJS$ItemBuilder>): $DynamicEntryHandle;
        /**
         * Registers (or re-claims) an item with default options (64 stack size, common rarity).
         * @param id item id like 'mymod:ruby'
         * @returns handle exposing id() / mode() / owner()
         */
        item(id: string): $DynamicEntryHandle;
        /**
         * Registers (or re-claims) a mob effect configured by the builder callback.
         * @param id entry id like 'mymod:wither_touch'
         * @param config builder callback: mode(...) / category(...) / color(...)
         * @returns handle exposing id() / mode() / owner()
         */
        mobEffect(id: string, config: $Consumer<$DynamicRegistryJS$MobEffectBuilder>): $DynamicEntryHandle;
        /**
         * Registers (or re-claims) a mob effect with default options (mode 'world').
         * @param id entry id like 'mymod:wither_touch'
         * @returns handle exposing id() / mode() / owner()
         */
        mobEffect(id: string): $DynamicEntryHandle;
        /**
         * Registers (or re-claims) a sound event configured by the builder callback.
         * @param id entry id like 'mymod:boom'
         * @param config builder callback: mode(...) / fixedRange(...)
         * @returns handle exposing id() / mode() / owner()
         */
        soundEvent(id: string, config: $Consumer<$DynamicRegistryJS$SoundEventBuilder>): $DynamicEntryHandle;
        /**
         * Registers (or re-claims) a sound event with default options (mode 'world').
         * @param id entry id like 'mymod:boom'
         * @returns handle exposing id() / mode() / owner()
         */
        soundEvent(id: string): $DynamicEntryHandle;
    }

    /** Item options for DynamicRegistry.item. */
    export class $DynamicRegistryJS$ItemBuilder extends $DynamicRegistryJS$ModeBuilder {
        constructor();
        /** Sets whether the item is fire resistant (default false). */
        fireResistant(value: boolean): $DynamicRegistryJS$ItemBuilder;
        /** Marks the item fire resistant. */
        fireResistant(): $DynamicRegistryJS$ItemBuilder;
        /** Maximum stack size (1..99); defaults to 64. */
        maxStackSize(size: number): $DynamicRegistryJS$ItemBuilder;
        /** Registration mode: 'world' (default) or 'reloadable'. */
        mode(mode: string): $DynamicRegistryJS$ItemBuilder;
        /** Rarity: 'common' (default), 'uncommon', 'rare' or 'epic'. */
        rarity(rarity: string): $DynamicRegistryJS$ItemBuilder;
    }

    /** Mob effect options for DynamicRegistry.mobEffect. */
    export class $DynamicRegistryJS$MobEffectBuilder extends $DynamicRegistryJS$ModeBuilder {
        constructor();
        /** Category: 'neutral' (default), 'beneficial' or 'harmful'. */
        category(category: string): $DynamicRegistryJS$MobEffectBuilder;
        /** Effect color as an ARGB int, e.g. 0x8B0000. */
        color(color: number): $DynamicRegistryJS$MobEffectBuilder;
        /** Registration mode: 'world' (default) or 'reloadable'. */
        mode(mode: string): $DynamicRegistryJS$MobEffectBuilder;
    }

    /** Base options shared by every DynamicRegistry builder. */
    export class $DynamicRegistryJS$ModeBuilder {
    }

    /** Sound event options for DynamicRegistry.soundEvent. */
    export class $DynamicRegistryJS$SoundEventBuilder extends $DynamicRegistryJS$ModeBuilder {
        constructor();
        /** Fixed audible range in blocks; omitted means the sound definition decides. */
        fixedRange(range: number): $DynamicRegistryJS$SoundEventBuilder;
        /** Registration mode: 'world' (default) or 'reloadable'. */
        mode(mode: string): $DynamicRegistryJS$SoundEventBuilder;
    }

}
