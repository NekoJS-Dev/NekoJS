import { $String } from "java:java/lang";
import { $Principal } from "java:java/security";

declare module "java:java/nio/file/attribute" {
    export interface $FileAttribute<T> {
        name(): string;
        value(): T;
    }

    export interface $GroupPrincipal extends $UserPrincipal {
    }

    export interface $UserPrincipal extends $Principal {
    }

    export class $UserPrincipalLookupService {
        lookupPrincipalByGroupName(arg0: string): $GroupPrincipal;
        lookupPrincipalByName(arg0: string): $UserPrincipal;
    }

}
