import { $Enum, $String } from "java:java/lang";

declare module "java:java/math" {
    export class $RoundingMode {
        static CEILING: $RoundingMode;
        static DOWN: $RoundingMode;
        static FLOOR: $RoundingMode;
        static HALF_DOWN: $RoundingMode;
        static HALF_EVEN: $RoundingMode;
        static HALF_UP: $RoundingMode;
        static UNNECESSARY: $RoundingMode;
        static UP: $RoundingMode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RoundingMode[];
        static valueOf(name: string): $RoundingMode;
    }

    export type $RoundingMode_ = $RoundingMode | "CEILING" | "DOWN" | "FLOOR" | "HALF_DOWN" | "HALF_EVEN" | "HALF_UP" | "UNNECESSARY" | "UP";
}
