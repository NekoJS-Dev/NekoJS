import { $Serializable } from "java:java/io";
import { $Cloneable, $Enum, $Number, $String, $StringBuffer } from "java:java/lang";
import { $RoundingMode, $RoundingMode_ } from "java:java/math";
import { $Currency, $Date, $Locale, $Map, $Set } from "java:java/util";

declare module "java:java/text" {
    export interface $AttributedCharacterIterator extends $CharacterIterator {
        getAllAttributeKeys(): $Set<$AttributedCharacterIterator$Attribute>;
        getAttributes(): $Map<$AttributedCharacterIterator$Attribute, object>;
        getAttribute(arg0: $AttributedCharacterIterator$Attribute): object;
        getRunLimit(arg0: $AttributedCharacterIterator$Attribute): number;
        getRunLimit(arg0: $AttributedCharacterIterator$Attribute[]): number;
        getRunLimit(): number;
        getRunStart(arg0: $AttributedCharacterIterator$Attribute): number;
        getRunStart(arg0: $AttributedCharacterIterator$Attribute[]): number;
        getRunStart(): number;
    }

    export class $AttributedCharacterIterator$Attribute implements $Serializable {
        static INPUT_METHOD_SEGMENT: $AttributedCharacterIterator$Attribute;
        static LANGUAGE: $AttributedCharacterIterator$Attribute;
        static READING: $AttributedCharacterIterator$Attribute;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $CharacterIterator extends $Cloneable {
        clone(): object;
        current(): string;
        first(): string;
        getBeginIndex(): number;
        getEndIndex(): number;
        getIndex(): number;
        last(): string;
        next(): string;
        previous(): string;
        setIndex(arg0: number): string;
        static DONE: string;
    }

    export class $DecimalFormat extends $NumberFormat {
        constructor();
        constructor(arg0: string);
        constructor(arg0: string, arg1: $DecimalFormatSymbols);
        get currency(): $Currency;
        getCurrency(): $Currency;
        set currency(value: $Currency);
        get decimalFormatSymbols(): $DecimalFormatSymbols;
        getDecimalFormatSymbols(): $DecimalFormatSymbols;
        set decimalFormatSymbols(value: $DecimalFormatSymbols);
        get groupingSize(): number;
        getGroupingSize(): number;
        set groupingSize(value: number);
        get maximumFractionDigits(): number;
        getMaximumFractionDigits(): number;
        set maximumFractionDigits(value: number);
        get maximumIntegerDigits(): number;
        getMaximumIntegerDigits(): number;
        set maximumIntegerDigits(value: number);
        get minimumFractionDigits(): number;
        getMinimumFractionDigits(): number;
        set minimumFractionDigits(value: number);
        get minimumIntegerDigits(): number;
        getMinimumIntegerDigits(): number;
        set minimumIntegerDigits(value: number);
        get multiplier(): number;
        getMultiplier(): number;
        set multiplier(value: number);
        get negativePrefix(): string;
        getNegativePrefix(): string;
        set negativePrefix(value: string);
        get negativeSuffix(): string;
        getNegativeSuffix(): string;
        set negativeSuffix(value: string);
        get positivePrefix(): string;
        getPositivePrefix(): string;
        set positivePrefix(value: string);
        get positiveSuffix(): string;
        getPositiveSuffix(): string;
        set positiveSuffix(value: string);
        get roundingMode(): $RoundingMode;
        getRoundingMode(): $RoundingMode;
        set roundingMode(value: $RoundingMode_);
        get decimalSeparatorAlwaysShown(): boolean;
        isDecimalSeparatorAlwaysShown(): boolean;
        set decimalSeparatorAlwaysShown(value: boolean);
        get parseBigDecimal(): boolean;
        isParseBigDecimal(): boolean;
        set parseBigDecimal(value: boolean);
        get strict(): boolean;
        isStrict(): boolean;
        set strict(value: boolean);
        applyLocalizedPattern(arg0: string): void;
        applyPattern(arg0: string): void;
        clone(): object;
        equals(arg0: object): boolean;
        formatToCharacterIterator(arg0: object): $AttributedCharacterIterator;
        format(arg0: number, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: object, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: number, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        hashCode(): number;
        parse(arg0: string, arg1: $ParsePosition): number;
        toLocalizedPattern(): string;
        toPattern(): string;
        toString(): string;
    }

    export class $DecimalFormatSymbols implements $Cloneable, $Serializable {
        constructor();
        constructor(arg0: $Locale);
        get currencySymbol(): string;
        getCurrencySymbol(): string;
        set currencySymbol(value: string);
        get currency(): $Currency;
        getCurrency(): $Currency;
        set currency(value: $Currency);
        get decimalSeparator(): string;
        getDecimalSeparator(): string;
        set decimalSeparator(value: string);
        get digit(): string;
        getDigit(): string;
        set digit(value: string);
        get exponentSeparator(): string;
        getExponentSeparator(): string;
        set exponentSeparator(value: string);
        get groupingSeparator(): string;
        getGroupingSeparator(): string;
        set groupingSeparator(value: string);
        get infinity(): string;
        getInfinity(): string;
        set infinity(value: string);
        get internationalCurrencySymbol(): string;
        getInternationalCurrencySymbol(): string;
        set internationalCurrencySymbol(value: string);
        get locale(): $Locale;
        getLocale(): $Locale;
        get minusSign(): string;
        getMinusSign(): string;
        set minusSign(value: string);
        get monetaryDecimalSeparator(): string;
        getMonetaryDecimalSeparator(): string;
        set monetaryDecimalSeparator(value: string);
        get monetaryGroupingSeparator(): string;
        getMonetaryGroupingSeparator(): string;
        set monetaryGroupingSeparator(value: string);
        get naN(): string;
        getNaN(): string;
        set naN(value: string);
        get patternSeparator(): string;
        getPatternSeparator(): string;
        set patternSeparator(value: string);
        get perMill(): string;
        getPerMill(): string;
        set perMill(value: string);
        get percent(): string;
        getPercent(): string;
        set percent(value: string);
        get zeroDigit(): string;
        getZeroDigit(): string;
        set zeroDigit(value: string);
        static getAvailableLocales(): $Locale[];
        static getInstance(arg0: $Locale): $DecimalFormatSymbols;
        static getInstance(): $DecimalFormatSymbols;
        clone(): object;
        equals(arg0: object): boolean;
        hashCode(): number;
    }

    export class $FieldPosition {
        constructor(arg0: number);
        constructor(arg0: $Format$Field);
        constructor(arg0: $Format$Field, arg1: number);
        get beginIndex(): number;
        getBeginIndex(): number;
        set beginIndex(value: number);
        get endIndex(): number;
        getEndIndex(): number;
        set endIndex(value: number);
        get fieldAttribute(): $Format$Field;
        getFieldAttribute(): $Format$Field;
        get field(): number;
        getField(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $Format implements $Serializable, $Cloneable {
        clone(): object;
        formatToCharacterIterator(arg0: object): $AttributedCharacterIterator;
        format(arg0: object, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: object): string;
        parseObject(arg0: string, arg1: $ParsePosition): object;
        parseObject(arg0: string): object;
    }

    export class $Format$Field extends $AttributedCharacterIterator$Attribute {
    }

    export class $NumberFormat extends $Format {
        static FRACTION_FIELD: number;
        static INTEGER_FIELD: number;
        get currency(): $Currency;
        getCurrency(): $Currency;
        set currency(value: $Currency);
        get maximumFractionDigits(): number;
        getMaximumFractionDigits(): number;
        set maximumFractionDigits(value: number);
        get maximumIntegerDigits(): number;
        getMaximumIntegerDigits(): number;
        set maximumIntegerDigits(value: number);
        get minimumFractionDigits(): number;
        getMinimumFractionDigits(): number;
        set minimumFractionDigits(value: number);
        get minimumIntegerDigits(): number;
        getMinimumIntegerDigits(): number;
        set minimumIntegerDigits(value: number);
        get roundingMode(): $RoundingMode;
        getRoundingMode(): $RoundingMode;
        set roundingMode(value: $RoundingMode_);
        get groupingUsed(): boolean;
        isGroupingUsed(): boolean;
        set groupingUsed(value: boolean);
        get parseIntegerOnly(): boolean;
        isParseIntegerOnly(): boolean;
        set parseIntegerOnly(value: boolean);
        get strict(): boolean;
        isStrict(): boolean;
        set strict(value: boolean);
        static getAvailableLocales(): $Locale[];
        static getCompactNumberInstance(arg0: $Locale, arg1: $NumberFormat$Style_): $NumberFormat;
        static getCompactNumberInstance(): $NumberFormat;
        static getCurrencyInstance(arg0: $Locale): $NumberFormat;
        static getCurrencyInstance(): $NumberFormat;
        static getInstance(arg0: $Locale): $NumberFormat;
        static getInstance(): $NumberFormat;
        static getIntegerInstance(arg0: $Locale): $NumberFormat;
        static getIntegerInstance(): $NumberFormat;
        static getNumberInstance(arg0: $Locale): $NumberFormat;
        static getNumberInstance(): $NumberFormat;
        static getPercentInstance(arg0: $Locale): $NumberFormat;
        static getPercentInstance(): $NumberFormat;
        clone(): object;
        equals(arg0: object): boolean;
        format(arg0: number, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: number): string;
        format(arg0: object, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: number, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: number): string;
        hashCode(): number;
        parseObject(arg0: string, arg1: $ParsePosition): object;
        parse(arg0: string, arg1: $ParsePosition): number;
        parse(arg0: string): number;
    }

    export class $NumberFormat$Style {
        static LONG: $NumberFormat$Style;
        static SHORT: $NumberFormat$Style;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $NumberFormat$Style[];
        static valueOf(name: string): $NumberFormat$Style;
    }

    export class $ParsePosition {
        constructor(arg0: number);
        get errorIndex(): number;
        getErrorIndex(): number;
        set errorIndex(value: number);
        get index(): number;
        getIndex(): number;
        set index(value: number);
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $SimpleDateFormat extends $DateFormat {
        constructor();
        constructor(arg0: string);
        constructor(arg0: string, arg1: $DateFormatSymbols);
        constructor(arg0: string, arg1: $Locale);
        get2DigitYearStart(): $Date;
        get dateFormatSymbols(): $DateFormatSymbols;
        getDateFormatSymbols(): $DateFormatSymbols;
        set dateFormatSymbols(value: $DateFormatSymbols);
        applyLocalizedPattern(arg0: string): void;
        applyPattern(arg0: string): void;
        clone(): object;
        equals(arg0: object): boolean;
        formatToCharacterIterator(arg0: object): $AttributedCharacterIterator;
        format(arg0: $Date, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        hashCode(): number;
        parse(arg0: string, arg1: $ParsePosition): $Date;
        toLocalizedPattern(): string;
        toPattern(): string;
        toString(): string;
    }

    export type $NumberFormat$Style_ = $NumberFormat$Style | "LONG" | "SHORT";
}
