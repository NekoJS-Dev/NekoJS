export * as minecraft from "java:net/minecraft";
export * as neoforged from "java:net/neoforged";

