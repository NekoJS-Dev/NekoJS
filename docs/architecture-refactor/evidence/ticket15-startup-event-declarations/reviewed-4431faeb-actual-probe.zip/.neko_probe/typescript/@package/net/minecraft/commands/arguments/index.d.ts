import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $BiConsumer, $Supplier } from "java:java/util/function";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $CompoundTag, $CompoundTag_, $Tag } from "java:net/minecraft/nbt";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $MessageSignature, $SignableCommand } from "java:net/minecraft/network/chat";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as selector from "java:net/minecraft/commands/arguments/selector";

declare module "java:net/minecraft/commands/arguments" {
    export class $ArgumentSignatures extends $Record {
        constructor(entries: $ArgumentSignatures$Entry[]);
        constructor(arg0: $FriendlyByteBuf);
        static EMPTY: $ArgumentSignatures;
        static signCommand(arg0: $SignableCommand<any>, arg1: $ArgumentSignatures$Signer): $ArgumentSignatures;
        entries(): $List<$ArgumentSignatures$Entry>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $ArgumentSignatures$Entry extends $Record {
        constructor(name: string, signature: $MessageSignature);
        constructor(arg0: $FriendlyByteBuf);
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): string;
        signature(): $MessageSignature;
        toString(): string;
        write(arg0: $FriendlyByteBuf): void;
    }

    export interface $ArgumentSignatures$Signer {
        sign(arg0: string): $MessageSignature;
    }

    export class $EntityAnchorArgument$Anchor {
        static EYES: $EntityAnchorArgument$Anchor;
        static FEET: $EntityAnchorArgument$Anchor;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EntityAnchorArgument$Anchor[];
        static valueOf(name: string): $EntityAnchorArgument$Anchor;
    }

    export class $NbtPathArgument$NbtPath {
        constructor(arg0: string, arg1: $NbtPathArgument$Node[], arg2: $Object2IntMap<$NbtPathArgument$Node>);
        static CODEC: $Codec<$NbtPathArgument$NbtPath>;
        static isTooDeep(arg0: $Tag, arg1: number): boolean;
        static of(arg0: string): $NbtPathArgument$NbtPath;
        asString(): string;
        countMatching(arg0: $Tag): number;
        getOrCreate(arg0: $Tag, arg1: $Supplier<$Tag>): $List<$Tag>;
        get(arg0: $Tag): $List<$Tag>;
        insert(arg0: number, arg1: $CompoundTag_, arg2: $Tag[]): number;
        remove(arg0: $Tag): number;
        set(arg0: $Tag, arg1: $Tag): number;
        toString(): string;
    }

    export interface $NbtPathArgument$Node {
        collect(arg0: $Tag[], arg1: $BiConsumer<$Tag, $Tag[]>): $List<$Tag>;
        createPreferredParentTag(): $Tag;
        getOrCreateTag(arg0: $Tag, arg1: $Supplier<$Tag>, arg2: $Tag[]): void;
        getOrCreate(arg0: $Tag[], arg1: $Supplier<$Tag>): $List<$Tag>;
        getTag(arg0: $Tag, arg1: $Tag[]): void;
        get(arg0: $Tag[]): $List<$Tag>;
        removeTag(arg0: $Tag): number;
        setTag(arg0: $Tag, arg1: $Supplier<$Tag>): number;
    }

    export type $EntityAnchorArgument$Anchor_ = $EntityAnchorArgument$Anchor | "EYES" | "FEET";
}
