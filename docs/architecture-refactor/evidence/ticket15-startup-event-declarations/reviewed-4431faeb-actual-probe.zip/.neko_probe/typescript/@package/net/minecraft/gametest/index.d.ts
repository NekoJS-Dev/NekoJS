export * as framework from "java:net/minecraft/gametest/framework";

