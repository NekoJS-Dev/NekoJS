import { $JsonObject } from "java:com/google/gson";
import { $GameProfile } from "java:com/mojang/authlib";
import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec } from "java:com/mojang/serialization";
import { $File } from "java:java/io";
import { $Boolean, $Record, $String } from "java:java/lang";
import { $SocketAddress } from "java:java/net";
import { $SimpleDateFormat } from "java:java/text";
import { $Collection, $Date, $List, $Map, $Optional, $UUID } from "java:java/util";
import { $Function } from "java:java/util/function";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Connection } from "java:net/minecraft/network";
import { $ChatType$Bound, $Component, $Component_, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer, $PlayerAdvancements } from "java:net/minecraft/server";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $CommonListenerCookie, $ServerGamePacketListenerImpl } from "java:net/minecraft/server/network";
import { $LevelBasedPermissionSet } from "java:net/minecraft/server/permissions";
import { $ServerStatsCounter } from "java:net/minecraft/stats";
import { $Entity$RemovalReason, $Entity$RemovalReason_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Level } from "java:net/minecraft/world/level";
import { $PlayerDataStorage } from "java:net/minecraft/world/level/storage";
import { $IPlayerListExtension } from "java:net/neoforged/neoforge/common/extensions";

declare module "java:net/minecraft/server/players" {
    export class $BanListEntry<T> extends $StoredUserEntry {
        constructor(arg0: T, arg1: $Date, arg2: string, arg3: $Date, arg4: string);
        static DATE_FORMAT: $SimpleDateFormat;
        static EXPIRES_NEVER: string;
        get created(): $Date;
        getCreated(): $Date;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get expires(): $Date;
        getExpires(): $Date;
        get reasonMessage(): $Component;
        getReasonMessage(): $Component;
        get reason(): string;
        getReason(): string;
        get source(): string;
        getSource(): string;
        equals(arg0: object): boolean;
        hasExpired(): boolean;
        hashCode(): number;
    }

    export class $IpBanList extends $StoredUserList {
        constructor(arg0: string, arg1: $NotificationService);
        add(arg0: $IpBanListEntry): boolean;
        clear(): void;
        get(arg0: $SocketAddress): $IpBanListEntry;
        isBanned(arg0: string): boolean;
        isBanned(arg0: $SocketAddress): boolean;
        remove(arg0: string): boolean;
    }

    export class $IpBanListEntry extends $BanListEntry {
        constructor(arg0: $JsonObject);
        constructor(arg0: string);
        constructor(arg0: string, arg1: $Date, arg2: string, arg3: $Date, arg4: string);
        get displayName(): $Component;
        getDisplayName(): $Component;
    }

    export class $NameAndId extends $Record {
        constructor(arg0: $GameProfile);
        constructor(arg0: $NameAndId);
        constructor(id: string, name: string);
        static CODEC: $Codec<$NameAndId>;
        static createOffline(arg0: string): $NameAndId;
        static fromJson(arg0: $JsonObject): $NameAndId;
        appendTo(arg0: $JsonObject): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $UUID;
        name(): string;
        toString(): string;
    }

    export class $PlayerList implements $IPlayerListExtension {
        constructor(arg0: $MinecraftServer, arg1: $LayeredRegistryAccess<$RegistryLayer_>, arg2: $PlayerDataStorage, arg3: $NotificationService);
        static CHAT_FILTERED_FULL: $Component;
        static DUPLICATE_LOGIN_DISCONNECT_MESSAGE: $Component;
        static IPBANLIST_FILE: $File;
        static OPLIST_FILE: $File;
        static USERBANLIST_FILE: $File;
        static WHITELIST_FILE: $File;
        get bans(): $UserBanList;
        getBans(): $UserBanList;
        get ipBans(): $IpBanList;
        getIpBans(): $IpBanList;
        get maxPlayers(): number;
        getMaxPlayers(): number;
        get opNames(): string[];
        getOpNames(): string[];
        get ops(): $ServerOpList;
        getOps(): $ServerOpList;
        get playerCount(): number;
        getPlayerCount(): number;
        get playerIo(): $PlayerDataStorage;
        getPlayerIo(): $PlayerDataStorage;
        get playerNamesArray(): string[];
        getPlayerNamesArray(): string[];
        get playersByUUID(): $Map<$UUID, $ServerPlayer>;
        getPlayersByUUID(): $Map<$UUID, $ServerPlayer>;
        get players(): $List<$ServerPlayer>;
        getPlayers(): $List<$ServerPlayer>;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get simulationDistance(): number;
        getSimulationDistance(): number;
        set simulationDistance(value: number);
        get viewDistance(): number;
        getViewDistance(): number;
        set viewDistance(value: number);
        get whiteListNames(): string[];
        getWhiteListNames(): string[];
        get whiteList(): $UserWhiteList;
        getWhiteList(): $UserWhiteList;
        get allowCommandsForAllPlayers(): boolean;
        isAllowCommandsForAllPlayers(): boolean;
        set allowCommandsForAllPlayers(value: boolean);
        get usingWhitelist(): boolean;
        isUsingWhitelist(): boolean;
        addWorldborderListener(arg0: $ServerLevel): void;
        broadcastAll(arg0: $Packet<any>, arg1: $ResourceKey<$Level>): void;
        broadcastAll(arg0: $Packet<any>): void;
        broadcastChatMessage(arg0: $PlayerChatMessage, arg1: $CommandSourceStack, arg2: $ChatType$Bound): void;
        broadcastChatMessage(arg0: $PlayerChatMessage, arg1: $ServerPlayer, arg2: $ChatType$Bound): void;
        broadcastSystemMessage(arg0: $Component_, arg1: boolean): void;
        broadcastSystemMessage(arg0: $Component_, arg1: $Function<$ServerPlayer, $Component_>, arg2: boolean): void;
        broadcastSystemToAllExceptTeam(arg0: $Player, arg1: $Component_): void;
        broadcastSystemToTeam(arg0: $Player, arg1: $Component_): void;
        broadcast(arg0: $Player, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $ResourceKey<$Level>, arg6: $Packet<any>): void;
        canBypassPlayerLimit(arg0: $NameAndId): boolean;
        canPlayerLogin(arg0: $SocketAddress, arg1: $NameAndId): $Component;
        deop(arg0: $NameAndId): void;
        disconnectAllPlayersWithProfile(arg0: string): boolean;
        getPlayerAdvancements(arg0: $ServerPlayer): $PlayerAdvancements;
        getPlayerByName(arg0: string): $ServerPlayer;
        getPlayerStats(arg0: $Player): $ServerStatsCounter;
        getPlayersWithAddress(arg0: string): $List<$ServerPlayer>;
        getPlayer(arg0: string): $ServerPlayer;
        getPlayer(arg0: string): $ServerPlayer;
        isOp(arg0: $NameAndId): boolean;
        isWhiteListed(arg0: $NameAndId): boolean;
        loadPlayerData(arg0: $NameAndId): $Optional<$CompoundTag>;
        op(arg0: $NameAndId, arg1: $Optional<$LevelBasedPermissionSet>, arg2: $Optional<boolean>): void;
        op(arg0: $NameAndId): void;
        placeNewPlayer(arg0: $Connection, arg1: $ServerPlayer, arg2: $CommonListenerCookie): void;
        reloadResources(): void;
        reloadWhiteList(): void;
        removeAll(): void;
        remove(arg0: $ServerPlayer): void;
        respawn(arg0: $ServerPlayer, arg1: boolean, arg2: $Entity$RemovalReason_): $ServerPlayer;
        saveAll(): void;
        sendActiveEffects(arg0: $LivingEntity, arg1: $ServerGamePacketListenerImpl): void;
        sendActivePlayerEffects(arg0: $ServerPlayer): void;
        sendAllPlayerInfo(arg0: $ServerPlayer): void;
        sendLevelInfo(arg0: $ServerPlayer, arg1: $ServerLevel): void;
        sendPlayerPermissionLevel(arg0: $ServerPlayer): void;
        tick(): void;
    }

    export interface $ProfileResolver {
        fetchById(arg0: string): $Optional<$GameProfile>;
        fetchByNameOrId(arg0: $Either<string, string>): $Optional<$GameProfile>;
        fetchByName(arg0: string): $Optional<$GameProfile>;
    }

    export class $ServerOpList extends $StoredUserList {
        constructor(arg0: string, arg1: $NotificationService);
        get userList(): string[];
        getUserList(): string[];
        add(arg0: $ServerOpListEntry): boolean;
        canBypassPlayerLimit(arg0: $NameAndId): boolean;
        clear(): void;
        remove(arg0: $NameAndId): boolean;
    }

    export class $ServerOpListEntry extends $StoredUserEntry {
        constructor(arg0: $JsonObject);
        constructor(arg0: $NameAndId, arg1: $LevelBasedPermissionSet, arg2: boolean);
        get bypassesPlayerLimit(): boolean;
        getBypassesPlayerLimit(): boolean;
        permissions(): $LevelBasedPermissionSet;
    }

    export class $StoredUserEntry<T> {
        constructor(arg0: T);
        get user(): T;
        getUser(): T;
        hasExpired(): boolean;
    }

    export class $StoredUserList<K, V extends $StoredUserEntry<K>> {
        constructor(arg0: string, arg1: $NotificationService);
        get entries(): $Collection<V>;
        getEntries(): $Collection<V>;
        get file(): $File;
        getFile(): $File;
        get userList(): string[];
        getUserList(): string[];
        get empty(): boolean;
        isEmpty(): boolean;
        add(arg0: V): boolean;
        clear(): void;
        get(arg0: K): V;
        load(): void;
        remove(arg0: K): boolean;
        remove(arg0: $StoredUserEntry<K>): boolean;
        save(): void;
    }

    export class $UserBanList extends $StoredUserList {
        constructor(arg0: string, arg1: $NotificationService);
        get userList(): string[];
        getUserList(): string[];
        add(arg0: $UserBanListEntry): boolean;
        clear(): void;
        isBanned(arg0: $NameAndId): boolean;
        remove(arg0: $NameAndId): boolean;
    }

    export class $UserBanListEntry extends $BanListEntry {
        constructor(arg0: $JsonObject);
        constructor(arg0: $NameAndId);
        constructor(arg0: $NameAndId, arg1: $Date, arg2: string, arg3: $Date, arg4: string);
        get displayName(): $Component;
        getDisplayName(): $Component;
    }

    export interface $UserNameToIdResolver {
        add(arg0: $NameAndId): void;
        get(arg0: string): $Optional<$NameAndId>;
        get(arg0: string): $Optional<$NameAndId>;
        resolveOfflineUsers(arg0: boolean): void;
        save(): void;
    }

    export class $UserWhiteList extends $StoredUserList {
        constructor(arg0: string, arg1: $NotificationService);
        get userList(): string[];
        getUserList(): string[];
        add(arg0: $UserWhiteListEntry): boolean;
        clear(): void;
        isWhiteListed(arg0: $NameAndId): boolean;
        remove(arg0: $NameAndId): boolean;
    }

    export class $UserWhiteListEntry extends $StoredUserEntry {
        constructor(arg0: $JsonObject);
        constructor(arg0: $NameAndId);
    }

}
