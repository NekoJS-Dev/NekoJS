import { $Record, $String } from "java:java/lang";
import { $ByteBuffer } from "java:java/nio";
import { $List, $UUID } from "java:java/util";

declare module "java:com/mojang/authlib/yggdrasil/response" {
    export class $FriendData extends $Record {
        constructor(friends: $FriendDto[], incomingRequests: $FriendDto[], outgoingRequests: $FriendDto[]);
        static empty(): $FriendData;
        equals(arg0: object): boolean;
        friends(): $List<$FriendDto>;
        hashCode(): number;
        incomingRequests(): $List<$FriendDto>;
        outgoingRequests(): $List<$FriendDto>;
        toString(): string;
    }

    export class $KeyPairResponse extends $Record {
        constructor(keyPair: $KeyPairResponse$KeyPair, publicKeySignature: $ByteBuffer, expiresAt: string, refreshedAfter: string);
        equals(arg0: object): boolean;
        expiresAt(): string;
        hashCode(): number;
        keyPair(): $KeyPairResponse$KeyPair;
        publicKeySignature(): $ByteBuffer;
        refreshedAfter(): string;
        toString(): string;
    }

    export class $NameAndId extends $Record {
        constructor(id: string, name: string);
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $UUID;
        name(): string;
        toString(): string;
    }

    export class $PresenceResponse extends $Record {
        constructor(presence: $PresenceStatusDto[]);
        static empty(): $PresenceResponse;
        equals(arg0: object): boolean;
        hashCode(): number;
        presence(): $List<$PresenceStatusDto>;
        toString(): string;
    }

}
