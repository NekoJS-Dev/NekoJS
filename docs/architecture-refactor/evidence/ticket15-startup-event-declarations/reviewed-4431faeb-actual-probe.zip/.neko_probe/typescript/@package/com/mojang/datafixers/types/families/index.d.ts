import { $FamilyOptic, $RewriteResult, $TypeRewriteRule, $TypedOptic } from "java:com/mojang/datafixers";
import { $PointFreeRule } from "java:com/mojang/datafixers/functions";
import { $Type, $Type$FieldNotFoundException, $Type$TypeMatcher } from "java:com/mojang/datafixers/types";
import { $RecursivePoint$RecursivePointType, $TypeTemplate } from "java:com/mojang/datafixers/types/templates";
import { $Either } from "java:com/mojang/datafixers/util";
import { $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $IntFunction } from "java:java/util/function";

declare module "java:com/mojang/datafixers/types/families" {
    export class $RecursiveTypeFamily implements $TypeFamily {
        constructor(arg0: string, arg1: $TypeTemplate);
        apply(arg0: number): $RecursivePoint$RecursivePointType<any>;
        buildMuType<A>(arg0: $Type<A>, arg1: $RecursiveTypeFamily): $RecursivePoint$RecursivePointType<A>;
        equals(arg0: object): boolean;
        everywhere(arg0: number, arg1: $TypeRewriteRule, arg2: $PointFreeRule): $Optional<$RewriteResult<any, any>>;
        findType<A, B>(arg0: number, arg1: $Type<A>, arg2: $Type<B>, arg3: $Type$TypeMatcher<A, B>, arg4: boolean): $Either<$TypedOptic<any, any, A, B>, $Type$FieldNotFoundException>;
        fold(arg0: $Algebra, arg1: $RecursiveTypeFamily): $IntFunction<$RewriteResult<any, any>>;
        hashCode(): number;
        name(): string;
        size(): number;
        template(): $TypeTemplate;
        toString(): string;
    }

    export interface $TypeFamily {
        apply(arg0: number): $Type<any>;
        familyOptic<A, B>(arg0: $IntFunction<$TypedOptic<any, any, A, B>>): $FamilyOptic<A, B>;
    }

}
