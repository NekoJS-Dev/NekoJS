import { $Range } from "java:com/google/common/collect";
import { $StringReader } from "java:com/mojang/brigadier";
import { $DynamicCommandExceptionType, $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Double, $Record, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Function, $Supplier } from "java:java/util/function";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/advancements/predicates" {
    export interface $MinMaxBounds<T extends number> {
        bounds(): $MinMaxBounds$Bounds<T>;
        isAny(): boolean;
        max(): $Optional<T>;
        min(): $Optional<T>;
        validateContainedInRange<V, B>(arg0: $MinMaxBounds<V>): $Function<B, $DataResult<B>>;
        static ERROR_EMPTY: $SimpleCommandExceptionType;
        static ERROR_SWAPPED: $SimpleCommandExceptionType;
    }

    export class $MinMaxBounds$Bounds<T extends number> extends $Record {
        constructor(min: $Optional<T>, max: $Optional<T>);
        get any(): boolean;
        isAny(): boolean;
        static any<T>(): $MinMaxBounds$Bounds<T>;
        static atLeast<T>(arg0: T): $MinMaxBounds$Bounds<T>;
        static atMost<T>(arg0: T): $MinMaxBounds$Bounds<T>;
        static between<T>(arg0: T, arg1: T): $MinMaxBounds$Bounds<T>;
        static createCodec<T>(arg0: $Codec<T>): $Codec<$MinMaxBounds$Bounds<T>>;
        static createStreamCodec<B, T>(arg0: $StreamCodec<B, T>): $StreamCodec<B, $MinMaxBounds$Bounds<T>>;
        static exactly<T>(arg0: T): $MinMaxBounds$Bounds<T>;
        static fromReader<T>(arg0: $StringReader, arg1: $Function<string, T>, arg2: $Supplier<$DynamicCommandExceptionType>): $MinMaxBounds$Bounds<T>;
        areSwapped(): boolean;
        asPoint(): $Optional<T>;
        asRange(): $Range<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        map<U>(arg0: $Function<T, U>): $MinMaxBounds$Bounds<U>;
        max(): $Optional<T>;
        min(): $Optional<T>;
        toString(): string;
        validateSwappedBoundsInCodec(): $DataResult<$MinMaxBounds$Bounds<T>>;
    }

    export class $MinMaxBounds$Doubles extends $Record implements $MinMaxBounds {
        constructor(bounds: $MinMaxBounds$Bounds<number>, boundsSqr: $MinMaxBounds$Bounds<number>);
        static ANY: $MinMaxBounds$Doubles;
        static CODEC: $Codec<$MinMaxBounds$Doubles>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $MinMaxBounds$Doubles>;
        static atLeast(arg0: number): $MinMaxBounds$Doubles;
        static atMost(arg0: number): $MinMaxBounds$Doubles;
        static between(arg0: number, arg1: number): $MinMaxBounds$Doubles;
        static exactly(arg0: number): $MinMaxBounds$Doubles;
        static fromReader(arg0: $StringReader): $MinMaxBounds$Doubles;
        boundsSqr(): $MinMaxBounds$Bounds<number>;
        bounds(): $MinMaxBounds$Bounds<number>;
        equals(arg0: object): boolean;
        hashCode(): number;
        matchesSqr(arg0: number): boolean;
        matches(arg0: number): boolean;
        toString(): string;
    }

}
