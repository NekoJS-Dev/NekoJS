import { $ChannelHandlerContext } from "java:io/netty/channel";
import { $Enum, $Iterable, $Record, $String } from "java:java/lang";
import { $Consumer, $Function } from "java:java/util/function";
import { $StreamCodec, $StreamDecoder, $StreamMemberEncoder } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $IPacketFlowExtension } from "java:net/neoforged/neoforge/common/extensions";

export * as common from "java:net/minecraft/network/protocol/common";
export * as cookie from "java:net/minecraft/network/protocol/cookie";
export * as game from "java:net/minecraft/network/protocol/game";
export * as login from "java:net/minecraft/network/protocol/login";
export * as ping from "java:net/minecraft/network/protocol/ping";
export * as status from "java:net/minecraft/network/protocol/status";

declare module "java:net/minecraft/network/protocol" {
    export class $BundleDelimiterPacket<T extends $PacketListener> implements $Packet {
        constructor();
        handle(arg0: T): void;
        type(): $PacketType<$BundleDelimiterPacket<T>>;
    }

    export class $BundlePacket<T extends $PacketListener> implements $Packet {
        subPackets(): $Iterable<$Packet<any>>;
        type(): $PacketType<$BundlePacket<T>>;
    }

    export interface $BundlerInfo {
        createForPacket<T, P>(arg0: $PacketType<P>, arg1: $Function<$Iterable<$Packet<any>>, P>, arg2: $BundleDelimiterPacket<any>): $BundlerInfo;
        startPacketBundling(arg0: $Packet<any>): $BundlerInfo$Bundler;
        unbundlePacket(arg0: $Packet<any>, arg1: $Consumer<$Packet<any>>, arg2: $ChannelHandlerContext): void;
        unbundlePacket(arg0: $Packet<any>, arg1: $Consumer<$Packet<any>>): void;
        static BUNDLE_SIZE_LIMIT: number;
    }

    export interface $BundlerInfo$Bundler {
        addPacket(arg0: $Packet<any>): $Packet<any>;
    }

    export interface $Packet<T extends $PacketListener> {
        codec<B, T>(arg0: $StreamMemberEncoder<B, T>, arg1: $StreamDecoder<B, T>): $StreamCodec<B, T>;
        handle(arg0: T): void;
        isSkippable(): boolean;
        isTerminal(): boolean;
        type(): $PacketType<$Packet<T>>;
    }

    export class $PacketFlow {
        static CLIENTBOUND: $PacketFlow;
        static SERVERBOUND: $PacketFlow;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PacketFlow[];
        static valueOf(name: string): $PacketFlow;
    }

    export class $PacketType<T extends $Packet<any>> extends $Record {
        constructor(flow: $PacketFlow_, id: $Identifier_);
        equals(arg0: object): boolean;
        flow(): $PacketFlow;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
    }

    export type $PacketFlow_ = $PacketFlow | "CLIENTBOUND" | "SERVERBOUND";
}
