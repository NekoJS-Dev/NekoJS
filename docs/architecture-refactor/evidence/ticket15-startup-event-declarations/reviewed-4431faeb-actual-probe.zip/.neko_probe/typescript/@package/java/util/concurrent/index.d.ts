import { $AutoCloseable, $Enum, $Runnable, $String, $Thread, $Throwable, $Void } from "java:java/lang";
import { $Duration } from "java:java/time";
import { $ChronoUnit, $ChronoUnit_ } from "java:java/time/temporal";
import { $Collection, $List } from "java:java/util";
import { $BiConsumer, $BiFunction, $Consumer, $Function, $Supplier } from "java:java/util/function";

declare module "java:java/util/concurrent" {
    export interface $Callable<V> {
        call(): V;
    }

    export class $CompletableFuture<T> implements $Future, $CompletionStage {
        constructor();
        get numberOfDependents(): number;
        getNumberOfDependents(): number;
        get cancelled(): boolean;
        isCancelled(): boolean;
        get completedExceptionally(): boolean;
        isCompletedExceptionally(): boolean;
        get done(): boolean;
        isDone(): boolean;
        static allOf(arg0?: $CompletableFuture<any>[]): $CompletableFuture<void>;
        static anyOf(arg0?: $CompletableFuture<any>[]): $CompletableFuture<object>;
        static completedFuture<U>(arg0: U): $CompletableFuture<U>;
        static completedStage<U>(arg0: U): $CompletionStage<U>;
        static delayedExecutor(arg0: number, arg1: $TimeUnit_, arg2: $Executor): $Executor;
        static delayedExecutor(arg0: number, arg1: $TimeUnit_): $Executor;
        static failedFuture<U>(arg0: $Throwable): $CompletableFuture<U>;
        static failedStage<U>(arg0: $Throwable): $CompletionStage<U>;
        static runAsync(arg0: $Runnable, arg1: $Executor): $CompletableFuture<void>;
        static runAsync(arg0: $Runnable): $CompletableFuture<void>;
        static supplyAsync<U>(arg0: $Supplier<U>, arg1: $Executor): $CompletableFuture<U>;
        static supplyAsync<U>(arg0: $Supplier<U>): $CompletableFuture<U>;
        acceptEitherAsync(arg0: $CompletionStage<T>, arg1: $Consumer<any>, arg2: $Executor): $CompletableFuture<void>;
        acceptEitherAsync(arg0: $CompletionStage<T>, arg1: $Consumer<any>): $CompletableFuture<void>;
        acceptEither(arg0: $CompletionStage<T>, arg1: $Consumer<any>): $CompletableFuture<void>;
        applyToEitherAsync<U>(arg0: $CompletionStage<T>, arg1: $Function<any, U>, arg2: $Executor): $CompletableFuture<U>;
        applyToEitherAsync<U>(arg0: $CompletionStage<T>, arg1: $Function<any, U>): $CompletableFuture<U>;
        applyToEither<U>(arg0: $CompletionStage<T>, arg1: $Function<any, U>): $CompletableFuture<U>;
        cancel(arg0: boolean): boolean;
        completeAsync(arg0: $Supplier<T>, arg1: $Executor): $CompletableFuture<T>;
        completeAsync(arg0: $Supplier<T>): $CompletableFuture<T>;
        completeExceptionally(arg0: $Throwable): boolean;
        completeOnTimeout(arg0: T, arg1: number, arg2: $TimeUnit_): $CompletableFuture<T>;
        complete(arg0: T): boolean;
        copy(): $CompletableFuture<T>;
        defaultExecutor(): $Executor;
        exceptionNow(): $Throwable;
        exceptionallyAsync(arg0: $Function<$Throwable, T>, arg1: $Executor): $CompletableFuture<T>;
        exceptionallyAsync(arg0: $Function<$Throwable, T>): $CompletableFuture<T>;
        exceptionallyComposeAsync(arg0: $Function<$Throwable, $CompletionStage<T>>, arg1: $Executor): $CompletableFuture<T>;
        exceptionallyComposeAsync(arg0: $Function<$Throwable, $CompletionStage<T>>): $CompletableFuture<T>;
        exceptionallyCompose(arg0: $Function<$Throwable, $CompletionStage<T>>): $CompletableFuture<T>;
        exceptionally(arg0: $Function<$Throwable, T>): $CompletableFuture<T>;
        getNow(arg0: T): T;
        get(arg0: number, arg1: $TimeUnit_): T;
        get(): T;
        handleAsync<U>(arg0: $BiFunction<any, $Throwable, U>, arg1: $Executor): $CompletableFuture<U>;
        handleAsync<U>(arg0: $BiFunction<any, $Throwable, U>): $CompletableFuture<U>;
        handle<U>(arg0: $BiFunction<any, $Throwable, U>): $CompletableFuture<U>;
        join(): T;
        minimalCompletionStage(): $CompletionStage<T>;
        newIncompleteFuture<U>(): $CompletableFuture<U>;
        obtrudeException(arg0: $Throwable): void;
        obtrudeValue(arg0: T): void;
        orTimeout(arg0: number, arg1: $TimeUnit_): $CompletableFuture<T>;
        resultNow(): T;
        runAfterBothAsync(arg0: $CompletionStage<any>, arg1: $Runnable, arg2: $Executor): $CompletableFuture<void>;
        runAfterBothAsync(arg0: $CompletionStage<any>, arg1: $Runnable): $CompletableFuture<void>;
        runAfterBoth(arg0: $CompletionStage<any>, arg1: $Runnable): $CompletableFuture<void>;
        runAfterEitherAsync(arg0: $CompletionStage<any>, arg1: $Runnable, arg2: $Executor): $CompletableFuture<void>;
        runAfterEitherAsync(arg0: $CompletionStage<any>, arg1: $Runnable): $CompletableFuture<void>;
        runAfterEither(arg0: $CompletionStage<any>, arg1: $Runnable): $CompletableFuture<void>;
        state(): $Future$State;
        thenAcceptAsync(arg0: $Consumer<any>, arg1: $Executor): $CompletableFuture<void>;
        thenAcceptAsync(arg0: $Consumer<any>): $CompletableFuture<void>;
        thenAcceptBothAsync<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer<any, any>, arg2: $Executor): $CompletableFuture<void>;
        thenAcceptBothAsync<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer<any, any>): $CompletableFuture<void>;
        thenAcceptBoth<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer<any, any>): $CompletableFuture<void>;
        thenAccept(arg0: $Consumer<any>): $CompletableFuture<void>;
        thenApplyAsync<U>(arg0: $Function<any, U>, arg1: $Executor): $CompletableFuture<U>;
        thenApplyAsync<U>(arg0: $Function<any, U>): $CompletableFuture<U>;
        thenApply<U>(arg0: $Function<any, U>): $CompletableFuture<U>;
        thenCombineAsync<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction<any, any, V>, arg2: $Executor): $CompletableFuture<V>;
        thenCombineAsync<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction<any, any, V>): $CompletableFuture<V>;
        thenCombine<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction<any, any, V>): $CompletableFuture<V>;
        thenComposeAsync<U>(arg0: $Function<any, $CompletionStage<U>>, arg1: $Executor): $CompletableFuture<U>;
        thenComposeAsync<U>(arg0: $Function<any, $CompletionStage<U>>): $CompletableFuture<U>;
        thenCompose<U>(arg0: $Function<any, $CompletionStage<U>>): $CompletableFuture<U>;
        thenRunAsync(arg0: $Runnable, arg1: $Executor): $CompletableFuture<void>;
        thenRunAsync(arg0: $Runnable): $CompletableFuture<void>;
        thenRun(arg0: $Runnable): $CompletableFuture<void>;
        toCompletableFuture(): $CompletableFuture<T>;
        toString(): string;
        whenCompleteAsync(arg0: $BiConsumer<any, any>, arg1: $Executor): $CompletableFuture<T>;
        whenCompleteAsync(arg0: $BiConsumer<any, any>): $CompletableFuture<T>;
        whenComplete(arg0: $BiConsumer<any, any>): $CompletableFuture<T>;
    }

    export interface $CompletionStage<T> {
        acceptEitherAsync(arg0: $CompletionStage<T>, arg1: $Consumer<any>, arg2: $Executor): $CompletionStage<void>;
        acceptEitherAsync(arg0: $CompletionStage<T>, arg1: $Consumer<any>): $CompletionStage<void>;
        acceptEither(arg0: $CompletionStage<T>, arg1: $Consumer<any>): $CompletionStage<void>;
        applyToEitherAsync<U>(arg0: $CompletionStage<T>, arg1: $Function<any, U>, arg2: $Executor): $CompletionStage<U>;
        applyToEitherAsync<U>(arg0: $CompletionStage<T>, arg1: $Function<any, U>): $CompletionStage<U>;
        applyToEither<U>(arg0: $CompletionStage<T>, arg1: $Function<any, U>): $CompletionStage<U>;
        exceptionallyAsync(arg0: $Function<$Throwable, T>, arg1: $Executor): $CompletionStage<T>;
        exceptionallyAsync(arg0: $Function<$Throwable, T>): $CompletionStage<T>;
        exceptionallyComposeAsync(arg0: $Function<$Throwable, $CompletionStage<T>>, arg1: $Executor): $CompletionStage<T>;
        exceptionallyComposeAsync(arg0: $Function<$Throwable, $CompletionStage<T>>): $CompletionStage<T>;
        exceptionallyCompose(arg0: $Function<$Throwable, $CompletionStage<T>>): $CompletionStage<T>;
        exceptionally(arg0: $Function<$Throwable, T>): $CompletionStage<T>;
        handleAsync<U>(arg0: $BiFunction<any, $Throwable, U>, arg1: $Executor): $CompletionStage<U>;
        handleAsync<U>(arg0: $BiFunction<any, $Throwable, U>): $CompletionStage<U>;
        handle<U>(arg0: $BiFunction<any, $Throwable, U>): $CompletionStage<U>;
        runAfterBothAsync(arg0: $CompletionStage<any>, arg1: $Runnable, arg2: $Executor): $CompletionStage<void>;
        runAfterBothAsync(arg0: $CompletionStage<any>, arg1: $Runnable): $CompletionStage<void>;
        runAfterBoth(arg0: $CompletionStage<any>, arg1: $Runnable): $CompletionStage<void>;
        runAfterEitherAsync(arg0: $CompletionStage<any>, arg1: $Runnable, arg2: $Executor): $CompletionStage<void>;
        runAfterEitherAsync(arg0: $CompletionStage<any>, arg1: $Runnable): $CompletionStage<void>;
        runAfterEither(arg0: $CompletionStage<any>, arg1: $Runnable): $CompletionStage<void>;
        thenAcceptAsync(arg0: $Consumer<any>, arg1: $Executor): $CompletionStage<void>;
        thenAcceptAsync(arg0: $Consumer<any>): $CompletionStage<void>;
        thenAcceptBothAsync<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer<any, any>, arg2: $Executor): $CompletionStage<void>;
        thenAcceptBothAsync<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer<any, any>): $CompletionStage<void>;
        thenAcceptBoth<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer<any, any>): $CompletionStage<void>;
        thenAccept(arg0: $Consumer<any>): $CompletionStage<void>;
        thenApplyAsync<U>(arg0: $Function<any, U>, arg1: $Executor): $CompletionStage<U>;
        thenApplyAsync<U>(arg0: $Function<any, U>): $CompletionStage<U>;
        thenApply<U>(arg0: $Function<any, U>): $CompletionStage<U>;
        thenCombineAsync<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction<any, any, V>, arg2: $Executor): $CompletionStage<V>;
        thenCombineAsync<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction<any, any, V>): $CompletionStage<V>;
        thenCombine<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction<any, any, V>): $CompletionStage<V>;
        thenComposeAsync<U>(arg0: $Function<any, $CompletionStage<U>>, arg1: $Executor): $CompletionStage<U>;
        thenComposeAsync<U>(arg0: $Function<any, $CompletionStage<U>>): $CompletionStage<U>;
        thenCompose<U>(arg0: $Function<any, $CompletionStage<U>>): $CompletionStage<U>;
        thenRunAsync(arg0: $Runnable, arg1: $Executor): $CompletionStage<void>;
        thenRunAsync(arg0: $Runnable): $CompletionStage<void>;
        thenRun(arg0: $Runnable): $CompletionStage<void>;
        toCompletableFuture(): $CompletableFuture<T>;
        whenCompleteAsync(arg0: $BiConsumer<any, any>, arg1: $Executor): $CompletionStage<T>;
        whenCompleteAsync(arg0: $BiConsumer<any, any>): $CompletionStage<T>;
        whenComplete(arg0: $BiConsumer<any, any>): $CompletionStage<T>;
    }

    export interface $Executor {
        execute(arg0: $Runnable): void;
    }

    export interface $ExecutorService extends $Executor, $AutoCloseable {
        awaitTermination(arg0: number, arg1: $TimeUnit_): boolean;
        close(): void;
        invokeAll<T>(arg0: $Callable<T>[], arg1: number, arg2: $TimeUnit_): $List<$Future<T>>;
        invokeAll<T>(arg0: $Callable<T>[]): $List<$Future<T>>;
        invokeAny<T>(arg0: $Callable<T>[], arg1: number, arg2: $TimeUnit_): T;
        invokeAny<T>(arg0: $Callable<T>[]): T;
        isShutdown(): boolean;
        isTerminated(): boolean;
        shutdownNow(): $List<$Runnable>;
        shutdown(): void;
        submit<T>(arg0: $Runnable, arg1: T): $Future<T>;
        submit(arg0: $Runnable): $Future<any>;
        submit<T>(arg0: $Callable<T>): $Future<T>;
    }

    export interface $Future<V> {
        cancel(arg0: boolean): boolean;
        exceptionNow(): $Throwable;
        get(arg0: number, arg1: $TimeUnit_): V;
        get(): V;
        isCancelled(): boolean;
        isDone(): boolean;
        resultNow(): V;
        state(): $Future$State;
    }

    export class $Future$State {
        static CANCELLED: $Future$State;
        static FAILED: $Future$State;
        static RUNNING: $Future$State;
        static SUCCESS: $Future$State;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Future$State[];
        static valueOf(name: string): $Future$State;
    }

    export interface $ThreadFactory {
        newThread(arg0: $Runnable): $Thread;
    }

    export class $TimeUnit {
        static DAYS: $TimeUnit;
        static HOURS: $TimeUnit;
        static MICROSECONDS: $TimeUnit;
        static MILLISECONDS: $TimeUnit;
        static MINUTES: $TimeUnit;
        static NANOSECONDS: $TimeUnit;
        static SECONDS: $TimeUnit;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TimeUnit[];
        static valueOf(name: string): $TimeUnit;
    }

    export type $Future$State_ = $Future$State | "CANCELLED" | "FAILED" | "RUNNING" | "SUCCESS";
    export type $TimeUnit_ = $TimeUnit | "DAYS" | "HOURS" | "MICROSECONDS" | "MILLISECONDS" | "MINUTES" | "NANOSECONDS" | "SECONDS";
}
