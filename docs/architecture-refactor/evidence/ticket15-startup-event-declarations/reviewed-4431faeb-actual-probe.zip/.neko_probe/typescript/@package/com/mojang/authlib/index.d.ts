import { $MinecraftSessionService } from "java:com/mojang/authlib/minecraft";
import { $PropertyMap } from "java:com/mojang/authlib/properties";
import { $NameAndId } from "java:com/mojang/authlib/yggdrasil/response";
import { $Enum, $Exception, $Record, $String } from "java:java/lang";
import { $Proxy, $URL } from "java:java/net";
import { $Map, $Optional, $UUID } from "java:java/util";

export * as minecraft from "java:com/mojang/authlib/minecraft";
export * as properties from "java:com/mojang/authlib/properties";
export * as yggdrasil from "java:com/mojang/authlib/yggdrasil";

declare module "java:com/mojang/authlib" {
    export interface $AuthenticationService {
        createMinecraftSessionService(): $MinecraftSessionService;
        createProfileRepository(): $GameProfileRepository;
    }

    export class $Environment extends $Record {
        constructor(sessionHost: string, servicesHost: string, profilesHost: string, name: string);
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): string;
        profilesHost(): string;
        servicesHost(): string;
        sessionHost(): string;
        toString(): string;
    }

    export class $GameProfile extends $Record {
        constructor(arg0: string, arg1: string);
        constructor(id: string, name: string, properties: $PropertyMap);
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $UUID;
        name(): string;
        properties(): $PropertyMap;
        toString(): string;
    }

    export interface $GameProfileRepository {
        findProfileByName(arg0: string): $Optional<$NameAndId>;
        findProfilesByNames(arg0: string[], arg1: $ProfileLookupCallback): void;
    }

    export class $HttpAuthenticationService implements $AuthenticationService {
        get proxy(): $Proxy;
        getProxy(): $Proxy;
        static buildQuery(arg0: { [key: string]: object }): string;
        static concatenateURL(arg0: $URL, arg1: string): $URL;
        static constantURL(arg0: string): $URL;
    }

    export interface $ProfileLookupCallback {
        onProfileLookupFailed(arg0: string, arg1: $Exception): void;
        onProfileLookupSucceeded(arg0: string, arg1: string): void;
    }

    export class $SignatureState {
        static INVALID: $SignatureState;
        static SIGNED: $SignatureState;
        static UNSIGNED: $SignatureState;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SignatureState[];
        static valueOf(name: string): $SignatureState;
    }

    export type $SignatureState_ = $SignatureState | "INVALID" | "SIGNED" | "UNSIGNED";
}
