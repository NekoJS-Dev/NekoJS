import { $String } from "java:java/lang";
import { $List, $Map } from "java:java/util";

export * as static_access from "java:com/tkisor/nekojs/bindings/static_access";

declare module "java:com/tkisor/nekojs/bindings" {
    export class $RecipeSchemaBinding {
        constructor();
        describe(namespace: string, type: string): $Map<string, object>;
        jsonTypes(namespace: string): $List<string>;
        namespaces(): $List<string>;
        types(namespace: string): $List<string>;
    }

}
