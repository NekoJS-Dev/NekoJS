import { $AttachedData } from "java:com/tkisor/nekojs/api/data";
import { $BlockSpec, $BlockStateSpec, $EntitySpec, $ItemSpec, $ItemStackSpec, $LevelSpec, $LivingEntitySpec, $MutableComponentSpec, $PlayerSpec, $ServerSpec } from "java:com/tkisor/nekojs/api/spec/inject";
import { $PersistentDataJS } from "java:com/tkisor/nekojs/wrapper/item";
import { $PersistentDataJS } from "java:com/tkisor/nekojs/wrapper/pdata";
import { $Boolean, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $ClickEvent, $Component, $Component_, $HoverEvent, $MutableComponent, $Style, $TextColor } from "java:net/minecraft/network/chat";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $Entity, $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ItemLore } from "java:net/minecraft/world/item/component";
import { $Ingredient, $Ingredient_ } from "java:net/minecraft/world/item/crafting";
import { $Enchantment } from "java:net/minecraft/world/item/enchantment";
import { $ItemLike, $ItemLike_, $Level } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";

declare module "java:com/tkisor/nekojs/api/inject" {
    export interface $BlockExtension extends $BlockSpec {
        getId(): string;
        getName(): string;
    }

    export interface $BlockStateExtension extends $BlockStateSpec {
        getId(): string;
        hasTag(tagLocation: string): boolean;
        is(idOrTag: string): boolean;
    }

    export interface $EntityExtension extends $EntitySpec {
        getRegistryId(): string;
        getLevel(): object;
        hasTag(tag: string): boolean;
        kill(): boolean;
        pdata(): $PersistentDataJS;
        remove(): void;
        teleport(x: number, y: number, z: number): void;
        static NEKO_PDATA_KEY: string;
    }

    export interface $ItemExtension extends $ItemSpec {
        getId(): string;
    }

    export interface $ItemStackExtension extends $ItemStackSpec {
        areComponentsEqual(stack: $ItemStack_): boolean;
        areItemsEqual(stack: $ItemStack_): boolean;
        asIngredient(): $Ingredient;
        enchantById(id: string, level: number): $ItemStack;
        equalsIgnoringCount(stack: $ItemStack_): boolean;
        getBlock(): $Block;
        getId(): string;
        getLore(): $ItemLore;
        getMod(): string;
        hasEnchantment(id: string, level: number): boolean;
        hasEnchantment(enchantment: $Holder<$Enchantment>, level: number): boolean;
        hasGlint(): boolean;
        isUnbreakable(): boolean;
        matches(other: object): boolean;
        matches(stack: $ItemStack_): boolean;
        matches(ingredient: $Ingredient_): boolean;
        matches(item: $ItemLike_): boolean;
        pdata(): $PersistentDataJS;
        setCountAndReturn(count: number): $ItemStack;
        setGlint(enchanted: boolean): void;
        setLore(lines: $Component_[]): void;
        setLore(lore: $ItemLore): void;
        setUnbreakable(unbreakable: boolean): void;
        strictNBT(): $Ingredient;
        weakNBT(): $Ingredient;
        withCount(count: number): object;
    }

    export interface $LevelExtension extends $LevelSpec {
        data(): $AttachedData<$Level>;
        getBlockState(x: number, y: number, z: number): $BlockState;
        getId(): string;
        getPlayers(): $List<$Player>;
        getTime(): number;
        isDay(): boolean;
        isRaining(): boolean;
        setBlock(x: number, y: number, z: number, block: object): boolean;
        setRaining(raining: boolean): void;
        setTime(time: number): void;
        spawnEntity(type: $EntityType<any>, x: number, y: number, z: number): $Entity;
        spawnLightning(x: number, y: number, z: number): $Entity;
    }

    export interface $LivingEntityExtension extends $LivingEntitySpec {
        addEffect(effectId: string, duration: number, amplifier: number): boolean;
        damage(amount: number): void;
        getChestItem(): object;
        getFeetItem(): object;
        getHeadItem(): object;
        getLegsItem(): object;
        getOffHandItem(): object;
        removeEffect(effectId: string): boolean;
    }

    export interface $MutableComponentExtension extends $Component, $MutableComponentSpec {
        aqua(): $MutableComponent;
        black(): $MutableComponent;
        blue(): $MutableComponent;
        bold(value: boolean): $MutableComponent;
        bold(): $MutableComponent;
        clickChangePage(page: number): $MutableComponent;
        clickCopy(text: string): $MutableComponent;
        clickOpenFile(path: string): $MutableComponent;
        clickOpenUrl(url: string): $MutableComponent;
        clickSuggestCommand(command: string): $MutableComponent;
        click(s: $ClickEvent): $MutableComponent;
        color(c: $TextColor): $MutableComponent;
        darkAqua(): $MutableComponent;
        darkBlue(): $MutableComponent;
        darkGray(): $MutableComponent;
        darkGreen(): $MutableComponent;
        darkPurple(): $MutableComponent;
        darkRed(): $MutableComponent;
        font(font: string): object;
        gold(): $MutableComponent;
        gray(): $MutableComponent;
        green(): $MutableComponent;
        hasStyle(): boolean;
        hoverEntity(entity: $Entity): $MutableComponent;
        hoverItem(stack: $ItemStack_): $MutableComponent;
        hoverText(text: $Component_): $MutableComponent;
        hover(hover: $HoverEvent): $MutableComponent;
        insertion(s: string): $MutableComponent;
        italic(value: boolean): $MutableComponent;
        italic(): $MutableComponent;
        lightPurple(): $MutableComponent;
        noColor(): $MutableComponent;
        obfuscated(value: boolean): $MutableComponent;
        obfuscated(): $MutableComponent;
        red(): $MutableComponent;
        strikethrough(value: boolean): $MutableComponent;
        strikethrough(): $MutableComponent;
        underlined(value: boolean): $MutableComponent;
        underlined(): $MutableComponent;
        white(): $MutableComponent;
        yellow(): $MutableComponent;
        setStyle(format: $Style): $MutableComponent;
        withStyle(format: $ChatFormatting_): $MutableComponent;
    }

    export interface $PlayerExtension extends $PlayerSpec {
        addXpLevels(levels: number): void;
        addXpPoints(points: number): void;
        data(): $AttachedData<$Player>;
        getGamemode(): string;
        getXpLevel(): number;
        give(stack: object): void;
        isOp(): boolean;
        kick(reason: object): void;
        sendMessage(message: object): void;
        setGamemode(gamemode: string): void;
        setXpLevel(level: number): void;
    }

    export interface $ServerExtension extends $ServerSpec {
        data(): $AttachedData<$MinecraftServer>;
    }

}
