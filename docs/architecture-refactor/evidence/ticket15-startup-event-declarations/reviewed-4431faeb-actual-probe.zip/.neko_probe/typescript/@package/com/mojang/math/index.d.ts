import { $Enum, $String } from "java:java/lang";
import { $Direction, $Direction$Axis, $Direction$Axis_, $Direction_, $FrontAndTop, $FrontAndTop_ } from "java:net/minecraft/core";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $Matrix3fc, $Vector3f, $Vector3i } from "java:org/joml";

declare module "java:com/mojang/math" {
    export class $OctahedralGroup {
        static IDENTITY: $OctahedralGroup;
        static INVERSION: $OctahedralGroup;
        static INVERT_X: $OctahedralGroup;
        static INVERT_Y: $OctahedralGroup;
        static INVERT_Z: $OctahedralGroup;
        static ROT_120_NNN: $OctahedralGroup;
        static ROT_120_NNP: $OctahedralGroup;
        static ROT_120_NPN: $OctahedralGroup;
        static ROT_120_NPP: $OctahedralGroup;
        static ROT_120_PNN: $OctahedralGroup;
        static ROT_120_PNP: $OctahedralGroup;
        static ROT_120_PPN: $OctahedralGroup;
        static ROT_120_PPP: $OctahedralGroup;
        static ROT_180_EDGE_XY_NEG: $OctahedralGroup;
        static ROT_180_EDGE_XY_POS: $OctahedralGroup;
        static ROT_180_EDGE_XZ_NEG: $OctahedralGroup;
        static ROT_180_EDGE_XZ_POS: $OctahedralGroup;
        static ROT_180_EDGE_YZ_NEG: $OctahedralGroup;
        static ROT_180_EDGE_YZ_POS: $OctahedralGroup;
        static ROT_180_FACE_XY: $OctahedralGroup;
        static ROT_180_FACE_XZ: $OctahedralGroup;
        static ROT_180_FACE_YZ: $OctahedralGroup;
        static ROT_60_REF_NNN: $OctahedralGroup;
        static ROT_60_REF_NNP: $OctahedralGroup;
        static ROT_60_REF_NPN: $OctahedralGroup;
        static ROT_60_REF_NPP: $OctahedralGroup;
        static ROT_60_REF_PNN: $OctahedralGroup;
        static ROT_60_REF_PNP: $OctahedralGroup;
        static ROT_60_REF_PPN: $OctahedralGroup;
        static ROT_60_REF_PPP: $OctahedralGroup;
        static ROT_90_REF_X_NEG: $OctahedralGroup;
        static ROT_90_REF_X_POS: $OctahedralGroup;
        static ROT_90_REF_Y_NEG: $OctahedralGroup;
        static ROT_90_REF_Y_POS: $OctahedralGroup;
        static ROT_90_REF_Z_NEG: $OctahedralGroup;
        static ROT_90_REF_Z_POS: $OctahedralGroup;
        static ROT_90_X_NEG: $OctahedralGroup;
        static ROT_90_X_POS: $OctahedralGroup;
        static ROT_90_Y_NEG: $OctahedralGroup;
        static ROT_90_Y_POS: $OctahedralGroup;
        static ROT_90_Z_NEG: $OctahedralGroup;
        static ROT_90_Z_POS: $OctahedralGroup;
        static SWAP_NEG_XY: $OctahedralGroup;
        static SWAP_NEG_XZ: $OctahedralGroup;
        static SWAP_NEG_YZ: $OctahedralGroup;
        static SWAP_XY: $OctahedralGroup;
        static SWAP_XZ: $OctahedralGroup;
        static SWAP_YZ: $OctahedralGroup;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $OctahedralGroup[];
        static valueOf(name: string): $OctahedralGroup;
    }

    export class $SymmetricGroup3 {
        static P123: $SymmetricGroup3;
        static P132: $SymmetricGroup3;
        static P213: $SymmetricGroup3;
        static P231: $SymmetricGroup3;
        static P312: $SymmetricGroup3;
        static P321: $SymmetricGroup3;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SymmetricGroup3[];
        static valueOf(name: string): $SymmetricGroup3;
    }

    export type $OctahedralGroup_ = $OctahedralGroup | "IDENTITY" | "INVERSION" | "INVERT_X" | "INVERT_Y" | "INVERT_Z" | "ROT_120_NNN" | "ROT_120_NNP" | "ROT_120_NPN" | "ROT_120_NPP" | "ROT_120_PNN" | "ROT_120_PNP" | "ROT_120_PPN" | "ROT_120_PPP" | "ROT_180_EDGE_XY_NEG" | "ROT_180_EDGE_XY_POS" | "ROT_180_EDGE_XZ_NEG" | "ROT_180_EDGE_XZ_POS" | "ROT_180_EDGE_YZ_NEG" | "ROT_180_EDGE_YZ_POS" | "ROT_180_FACE_XY" | "ROT_180_FACE_XZ" | "ROT_180_FACE_YZ" | "ROT_60_REF_NNN" | "ROT_60_REF_NNP" | "ROT_60_REF_NPN" | "ROT_60_REF_NPP" | "ROT_60_REF_PNN" | "ROT_60_REF_PNP" | "ROT_60_REF_PPN" | "ROT_60_REF_PPP" | "ROT_90_REF_X_NEG" | "ROT_90_REF_X_POS" | "ROT_90_REF_Y_NEG" | "ROT_90_REF_Y_POS" | "ROT_90_REF_Z_NEG" | "ROT_90_REF_Z_POS" | "ROT_90_X_NEG" | "ROT_90_X_POS" | "ROT_90_Y_NEG" | "ROT_90_Y_POS" | "ROT_90_Z_NEG" | "ROT_90_Z_POS" | "SWAP_NEG_XY" | "SWAP_NEG_XZ" | "SWAP_NEG_YZ" | "SWAP_XY" | "SWAP_XZ" | "SWAP_YZ";
    export type $SymmetricGroup3_ = $SymmetricGroup3 | "P123" | "P132" | "P213" | "P231" | "P312" | "P321";
}
