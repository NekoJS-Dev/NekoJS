import { $CommandDispatcher, $StringReader } from "java:com/mojang/brigadier";
import { $CharSequence, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $UnboundEntryAction } from "java:net/minecraft/commands/execution";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/commands/functions" {
    export interface $CommandFunction<T> {
        checkCommandLineLength(arg0: $CharSequence): void;
        fromLines<T>(arg0: $Identifier_, arg1: $CommandDispatcher<T>, arg2: T, arg3: string[]): $CommandFunction<T>;
        id(): $Identifier;
        instantiate(arg0: $CompoundTag_, arg1: $CommandDispatcher<T>): $InstantiatedFunction<T>;
        parseCommand<T>(arg0: $CommandDispatcher<T>, arg1: T, arg2: $StringReader): $UnboundEntryAction<T>;
    }

    export interface $InstantiatedFunction<T> {
        entries(): $List<$UnboundEntryAction<T>>;
        id(): $Identifier;
    }

}
