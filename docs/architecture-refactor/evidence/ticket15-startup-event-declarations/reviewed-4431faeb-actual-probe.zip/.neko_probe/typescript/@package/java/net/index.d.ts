import { $InputStream, $OutputStream, $Serializable } from "java:java/io";
import { $Class, $Comparable, $Enum, $String } from "java:java/lang";
import { $Permission } from "java:java/security";
import { $Enumeration, $List, $Map } from "java:java/util";
import { $Stream } from "java:java/util/stream";

declare module "java:java/net" {
    export class $ContentHandler {
        constructor();
        getContent(arg0: $URLConnection, arg1: $Class[]): object;
        getContent(arg0: $URLConnection): object;
    }

    export interface $ContentHandlerFactory {
        createContentHandler(arg0: string): $ContentHandler;
    }

    export interface $FileNameMap {
        getContentTypeFor(arg0: string): string;
    }

    export class $InetAddress implements $Serializable {
        get address(): number[];
        getAddress(): number[];
        get canonicalHostName(): string;
        getCanonicalHostName(): string;
        get hostAddress(): string;
        getHostAddress(): string;
        get hostName(): string;
        getHostName(): string;
        get anyLocalAddress(): boolean;
        isAnyLocalAddress(): boolean;
        get linkLocalAddress(): boolean;
        isLinkLocalAddress(): boolean;
        get loopbackAddress(): boolean;
        isLoopbackAddress(): boolean;
        get mCGlobal(): boolean;
        isMCGlobal(): boolean;
        get mCLinkLocal(): boolean;
        isMCLinkLocal(): boolean;
        get mCNodeLocal(): boolean;
        isMCNodeLocal(): boolean;
        get mCOrgLocal(): boolean;
        isMCOrgLocal(): boolean;
        get mCSiteLocal(): boolean;
        isMCSiteLocal(): boolean;
        get multicastAddress(): boolean;
        isMulticastAddress(): boolean;
        get siteLocalAddress(): boolean;
        isSiteLocalAddress(): boolean;
        static getAllByName(arg0: string): $InetAddress[];
        static getByAddress(arg0: number[]): $InetAddress;
        static getByAddress(arg0: string, arg1: number[]): $InetAddress;
        static getByName(arg0: string): $InetAddress;
        static getLocalHost(): $InetAddress;
        static getLoopbackAddress(): $InetAddress;
        static ofLiteral(arg0: string): $InetAddress;
        equals(arg0: object): boolean;
        hashCode(): number;
        isReachable(arg0: number): boolean;
        isReachable(arg0: $NetworkInterface, arg1: number, arg2: number): boolean;
        toString(): string;
    }

    export class $InetSocketAddress extends $SocketAddress {
        constructor(arg0: number);
        constructor(arg0: string, arg1: number);
        constructor(arg0: $InetAddress, arg1: number);
        get address(): $InetAddress;
        getAddress(): $InetAddress;
        get hostName(): string;
        getHostName(): string;
        get hostString(): string;
        getHostString(): string;
        get port(): number;
        getPort(): number;
        get unresolved(): boolean;
        isUnresolved(): boolean;
        static createUnresolved(arg0: string, arg1: number): $InetSocketAddress;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $InterfaceAddress {
        get address(): $InetAddress;
        getAddress(): $InetAddress;
        get broadcast(): $InetAddress;
        getBroadcast(): $InetAddress;
        get networkPrefixLength(): number;
        getNetworkPrefixLength(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $NetworkInterface {
        get displayName(): string;
        getDisplayName(): string;
        get hardwareAddress(): number[];
        getHardwareAddress(): number[];
        get index(): number;
        getIndex(): number;
        get inetAddresses(): $Enumeration<$InetAddress>;
        getInetAddresses(): $Enumeration<$InetAddress>;
        get interfaceAddresses(): $List<$InterfaceAddress>;
        getInterfaceAddresses(): $List<$InterfaceAddress>;
        get mTU(): number;
        getMTU(): number;
        get name(): string;
        getName(): string;
        get parent(): $NetworkInterface;
        getParent(): $NetworkInterface;
        get subInterfaces(): $Enumeration<$NetworkInterface>;
        getSubInterfaces(): $Enumeration<$NetworkInterface>;
        get loopback(): boolean;
        isLoopback(): boolean;
        get pointToPoint(): boolean;
        isPointToPoint(): boolean;
        get up(): boolean;
        isUp(): boolean;
        get virtual(): boolean;
        isVirtual(): boolean;
        static getByIndex(arg0: number): $NetworkInterface;
        static getByInetAddress(arg0: $InetAddress): $NetworkInterface;
        static getByName(arg0: string): $NetworkInterface;
        static getNetworkInterfaces(): $Enumeration<$NetworkInterface>;
        static networkInterfaces(): $Stream<$NetworkInterface>;
        equals(arg0: object): boolean;
        hashCode(): number;
        inetAddresses(): $Stream<$InetAddress>;
        subInterfaces(): $Stream<$NetworkInterface>;
        supportsMulticast(): boolean;
        toString(): string;
    }

    export class $Proxy {
        constructor(arg0: $Proxy$Type_, arg1: $SocketAddress);
        static NO_PROXY: $Proxy;
        address(): $SocketAddress;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $Proxy$Type;
    }

    export class $Proxy$Type {
        static DIRECT: $Proxy$Type;
        static HTTP: $Proxy$Type;
        static SOCKS: $Proxy$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Proxy$Type[];
        static valueOf(name: string): $Proxy$Type;
    }

    export class $SocketAddress implements $Serializable {
        constructor();
    }

    export class $URI implements $Comparable, $Serializable {
        constructor(arg0: string);
        constructor(arg0: string, arg1: string, arg2: string);
        constructor(arg0: string, arg1: string, arg2: string, arg3: number, arg4: string, arg5: string, arg6: string);
        constructor(arg0: string, arg1: string, arg2: string, arg3: string);
        constructor(arg0: string, arg1: string, arg2: string, arg3: string, arg4: string);
        get authority(): string;
        getAuthority(): string;
        get fragment(): string;
        getFragment(): string;
        get host(): string;
        getHost(): string;
        get path(): string;
        getPath(): string;
        get port(): number;
        getPort(): number;
        get query(): string;
        getQuery(): string;
        get rawAuthority(): string;
        getRawAuthority(): string;
        get rawFragment(): string;
        getRawFragment(): string;
        get rawPath(): string;
        getRawPath(): string;
        get rawQuery(): string;
        getRawQuery(): string;
        get rawSchemeSpecificPart(): string;
        getRawSchemeSpecificPart(): string;
        get rawUserInfo(): string;
        getRawUserInfo(): string;
        get schemeSpecificPart(): string;
        getSchemeSpecificPart(): string;
        get scheme(): string;
        getScheme(): string;
        get userInfo(): string;
        getUserInfo(): string;
        get absolute(): boolean;
        isAbsolute(): boolean;
        get opaque(): boolean;
        isOpaque(): boolean;
        static create(arg0: string): $URI;
        compareTo(arg0: $URI): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        normalize(): $URI;
        parseServerAuthority(): $URI;
        relativize(arg0: $URI): $URI;
        resolve(arg0: string): $URI;
        resolve(arg0: $URI): $URI;
        toASCIIString(): string;
        toString(): string;
        toURL(): $URL;
    }

    export class $URL implements $Serializable {
        constructor(arg0: string);
        constructor(arg0: string, arg1: string, arg2: number, arg3: string);
        constructor(arg0: string, arg1: string, arg2: number, arg3: string, arg4: $URLStreamHandler);
        constructor(arg0: string, arg1: string, arg2: string);
        constructor(arg0: $URL, arg1: string);
        constructor(arg0: $URL, arg1: string, arg2: $URLStreamHandler);
        get authority(): string;
        getAuthority(): string;
        get content(): object;
        getContent(): object;
        get defaultPort(): number;
        getDefaultPort(): number;
        get file(): string;
        getFile(): string;
        get host(): string;
        getHost(): string;
        get path(): string;
        getPath(): string;
        get port(): number;
        getPort(): number;
        get protocol(): string;
        getProtocol(): string;
        get query(): string;
        getQuery(): string;
        get ref(): string;
        getRef(): string;
        get userInfo(): string;
        getUserInfo(): string;
        static of(arg0: $URI, arg1: $URLStreamHandler): $URL;
        static setURLStreamHandlerFactory(arg0: $URLStreamHandlerFactory): void;
        equals(arg0: object): boolean;
        getContent(arg0: $Class<any>[]): object;
        hashCode(): number;
        openConnection(arg0: $Proxy): $URLConnection;
        openConnection(): $URLConnection;
        openStream(): $InputStream;
        sameFile(arg0: $URL): boolean;
        toExternalForm(): string;
        toString(): string;
        toURI(): $URI;
    }

    export class $URLConnection {
        get allowUserInteraction(): boolean;
        getAllowUserInteraction(): boolean;
        set allowUserInteraction(value: boolean);
        get connectTimeout(): number;
        getConnectTimeout(): number;
        set connectTimeout(value: number);
        get contentEncoding(): string;
        getContentEncoding(): string;
        get contentLengthLong(): number;
        getContentLengthLong(): number;
        get contentLength(): number;
        getContentLength(): number;
        get contentType(): string;
        getContentType(): string;
        get content(): object;
        getContent(): object;
        get date(): number;
        getDate(): number;
        get defaultUseCaches(): boolean;
        getDefaultUseCaches(): boolean;
        set defaultUseCaches(value: boolean);
        get doInput(): boolean;
        getDoInput(): boolean;
        set doInput(value: boolean);
        get doOutput(): boolean;
        getDoOutput(): boolean;
        set doOutput(value: boolean);
        get expiration(): number;
        getExpiration(): number;
        get headerFields(): $Map<string, $List<string>>;
        getHeaderFields(): $Map<string, $List<string>>;
        get ifModifiedSince(): number;
        getIfModifiedSince(): number;
        set ifModifiedSince(value: number);
        get inputStream(): $InputStream;
        getInputStream(): $InputStream;
        get lastModified(): number;
        getLastModified(): number;
        get outputStream(): $OutputStream;
        getOutputStream(): $OutputStream;
        get permission(): $Permission;
        getPermission(): $Permission;
        get readTimeout(): number;
        getReadTimeout(): number;
        set readTimeout(value: number);
        get requestProperties(): $Map<string, $List<string>>;
        getRequestProperties(): $Map<string, $List<string>>;
        get uRL(): $URL;
        getURL(): $URL;
        get useCaches(): boolean;
        getUseCaches(): boolean;
        set useCaches(value: boolean);
        static getDefaultAllowUserInteraction(): boolean;
        static getDefaultRequestProperty(arg0: string): string;
        static getDefaultUseCaches(arg0: string): boolean;
        static getFileNameMap(): $FileNameMap;
        static guessContentTypeFromName(arg0: string): string;
        static guessContentTypeFromStream(arg0: $InputStream): string;
        static setContentHandlerFactory(arg0: $ContentHandlerFactory): void;
        static setDefaultAllowUserInteraction(arg0: boolean): void;
        static setDefaultRequestProperty(arg0: string, arg1: string): void;
        static setDefaultUseCaches(arg0: string, arg1: boolean): void;
        static setFileNameMap(arg0: $FileNameMap): void;
        addRequestProperty(arg0: string, arg1: string): void;
        connect(): void;
        getContent(arg0: $Class<any>[]): object;
        getHeaderFieldDate(arg0: string, arg1: number): number;
        getHeaderFieldInt(arg0: string, arg1: number): number;
        getHeaderFieldKey(arg0: number): string;
        getHeaderFieldLong(arg0: string, arg1: number): number;
        getHeaderField(arg0: number): string;
        getHeaderField(arg0: string): string;
        getRequestProperty(arg0: string): string;
        setRequestProperty(arg0: string, arg1: string): void;
        toString(): string;
    }

    export class $URLStreamHandler {
        constructor();
    }

    export interface $URLStreamHandlerFactory {
        createURLStreamHandler(arg0: string): $URLStreamHandler;
    }

    export type $Proxy$Type_ = $Proxy$Type | "DIRECT" | "HTTP" | "SOCKS";
}
