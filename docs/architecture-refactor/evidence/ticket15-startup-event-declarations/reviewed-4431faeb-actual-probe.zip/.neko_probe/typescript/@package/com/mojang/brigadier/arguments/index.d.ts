import { $StringReader } from "java:com/mojang/brigadier";
import { $CommandContext } from "java:com/mojang/brigadier/context";
import { $Suggestions, $SuggestionsBuilder } from "java:com/mojang/brigadier/suggestion";
import { $String } from "java:java/lang";
import { $Collection } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";

declare module "java:com/mojang/brigadier/arguments" {
    export interface $ArgumentType<T> {
        getExamples(): $Collection<string>;
        listSuggestions<S>(arg0: $CommandContext<S>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        parse<S>(arg0: $StringReader, arg1: S): T;
        parse(arg0: $StringReader): T;
    }

}
