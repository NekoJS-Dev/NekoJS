package com.tkisor.nekojs.probe.ir;

import com.tkisor.nekojs.core.NekoSharedHostAccess;
import com.tkisor.nekojs.core.NekoJSMemberRemapper;
import com.tkisor.nekojs.api.annotation.HideFromJS;
import com.tkisor.nekojs.api.annotation.Remap;
import com.tkisor.nekojs.core.config.SandboxConfig;
import com.tkisor.nekojs.core.fs.ClassFilter;
import com.tkisor.nekojs.probe.types.TypeAliasRegistry;
import graal.graalvm.polyglot.Context;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class TypeScriptInheritedInterfaceTest {
    public interface Values<T> {
        T value();
        default T echo(T input) { return input; }
        default <R> R identity(R input) { return input; }
        default T[] array(T[] input) { return input; }
        @HideFromJS
        default String hidden() { return "hidden"; }
        static String factory() { return "factory"; }
    }

    public interface ChildValues<T> extends Values<T> {}

    public interface Sized {
        default int size() { return 1; }
    }

    public static class Value<T> implements ChildValues<T>, Sized {
        private final T input;
        public Value(T input) { this.input = input; }
        public T value() { return input; }
        public int echo() { return 7; }
    }

    public static class TextValue extends Value<String> {
        public TextValue(String input) { super(input); }
    }

    public static class RemappedParent {
        @Remap("call")
        public String base(String input) { return input; }
    }

    public static class RemappedChild extends RemappedParent {
        @Remap("call")
        public int local(int input) { return input; }
    }

    public interface WideSetter {
        default void setValue(CharSequence input) {}
    }

    public static class OwnSetter implements WideSetter {
        private String value;
        public String getValue() { return value; }
        public void setValue(String input) { value = input; }
    }

    public interface ReadOnlyValue {
        default String getValue() { return "read"; }
    }

    public static class StaticSetter implements ReadOnlyValue {
        public static void setValue(String input) {}
    }

    @Test
    void inheritedInterfaceMembersRemainCallableAndProduceRealDeclarations() throws Exception {
        var reflector = new TypeReflector();
        var renderer = new TypeScriptClassRenderer(new TypeAliasRegistry());
        StringBuilder output = new StringBuilder();
        for (Class<?> type : List.of(Values.class, ChildValues.class, Sized.class, Value.class, TextValue.class,
                RemappedParent.class, RemappedChild.class, ReadOnlyValue.class, StaticSetter.class)) {
            output.append(renderer.render(reflector.reflect(type)));
        }
        Path declaration = Path.of("build", "probe-ts-inherited-interface", "index.d.ts");
        Files.createDirectories(declaration.getParent());
        Files.writeString(declaration, output);
        try (Context context = context()) {
            assertTrue(context.eval("js", "var Text = Java.type('" + TextValue.class.getName()
                    + "'); var value = new Text('x'); value.value() === 'x'"
                    + " && value.echo('y') === 'y' && value.echo() === 7"
                    + " && value.identity(3) === 3 && value.size() === 1").asBoolean());
        }
        String value = renderer.render(reflector.reflect(Value.class));
        assertTrue(value.contains("echo(input: T): T;"), value);
        String text = renderer.render(reflector.reflect(TextValue.class));
        assertTrue(text.contains("echo(input: string): string;"), text);
    }

    @Test
    void superclassOverloadsUseTheirExposedNames() throws Exception {
        var remapper = new NekoJSMemberRemapper();
        assertEquals("call", remapper.remapMethod(RemappedParent.class.getMethod("base", String.class), RemappedChild.class));
        assertEquals("call", remapper.remapMethod(RemappedChild.class.getMethod("local", int.class), RemappedChild.class));
        try (Context context = context()) {
            context.getBindings("js").putMember("remapped", new RemappedChild());
            assertTrue(context.eval("js", "remapped.base('x') === 'x' && remapped.local(7) === 7").asBoolean());
        }
        var reflector = new TypeReflector();
        var declaration = reflector.reflect(RemappedChild.class);
        var calls = declaration.methods.stream().filter(method -> "call".equals(method.effectiveName())).toList();
        assertEquals(2, calls.size(), "Both actual remapped overloads must remain available");
        assertTrue(calls.stream().anyMatch(method -> method.params.get(0).type.sourceType == String.class));
        assertTrue(calls.stream().anyMatch(method -> method.params.get(0).type.sourceType == int.class));
    }

    @Test
    void declaredSetterRetainsItsBeanWriteType() {
        var declaration = new TypeReflector().reflect(OwnSetter.class);
        var getter = declaration.methods.stream().filter(method -> method.isGetter && "value".equals(method.property))
                .findFirst().orElseThrow();
        assertEquals(String.class, getter.setterParamType.sourceType);
        assertEquals("string", getter.setterParamType.ref.name());
        String output = new TypeScriptClassRenderer(new TypeAliasRegistry()).render(declaration);
        assertTrue(output.contains("set value(value: string);"), output);
        OwnSetter target = new OwnSetter();
        try (Context context = context()) {
            context.getBindings("js").putMember("target", target);
            context.eval("js", "target.setValue('written')");
        }
        assertEquals("written", target.getValue());
    }

    @Test
    void staticSetterDoesNotMakeInheritedInstanceGetterWritable() {
        var declaration = new TypeReflector().reflect(StaticSetter.class);
        var getter = declaration.methods.stream().filter(method -> method.isGetter && "value".equals(method.property))
                .findFirst().orElseThrow();
        assertNull(getter.setterParamType);
        String output = new TypeScriptClassRenderer(new TypeAliasRegistry()).render(declaration);
        assertTrue(output.contains("get value(): string;"), output);
        assertTrue(output.contains("static setValue(input: string): void;"), output);
        assertTrue(!output.contains("set value("), output);
    }

    private static Context context() {
        return Context.newBuilder("js")
                .allowExperimentalOptions(true)
                .allowHostAccess(new NekoSharedHostAccess(List.of()).get())
                .allowHostClassLookup(new ClassFilter(SandboxConfig.defaultConfig()))
                .allowCreateProcess(false)
                .option("js.nashorn-compat", "true")
                .build();
    }
}
