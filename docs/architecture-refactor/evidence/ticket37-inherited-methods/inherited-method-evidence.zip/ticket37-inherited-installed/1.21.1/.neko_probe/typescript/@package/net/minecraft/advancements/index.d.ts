import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $Comparable, $Comparable_, $Iterable, $Record } from "java:java/lang";
import { $Instant } from "java:java/time";
import { $Collection, $List, $Map, $Optional, $Set } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $CacheableFunction } from "java:net/minecraft/commands";
import { $HolderGetter$Provider, $HolderGetter$Provider_ } from "java:net/minecraft/core";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $MutableComponent } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $PlayerAdvancements } from "java:net/minecraft/server";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $ProblemReporter, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $WithConditions } from "java:net/neoforged/neoforge/common/conditions";

export * as critereon from "java:net/minecraft/advancements/critereon";

declare module "java:net/minecraft/advancements" {
    export class $Advancement extends $Record {
        constructor(arg0: $Optional<$ResourceLocation_>, arg1: $Optional<$DisplayInfo>, arg2: $AdvancementRewards, arg3: { [key: string]: $Criterion<any> }, arg4: $AdvancementRequirements, arg5: boolean);
        constructor(parent: $Optional<$ResourceLocation_>, display: $Optional<$DisplayInfo>, rewards: $AdvancementRewards, criteria: { [key: string]: $Criterion<any> }, requirements: $AdvancementRequirements, sendsTelemetryEvent: boolean, name: $Optional<$Component_>);
        static CODEC: $Codec<$Advancement>;
        static CONDITIONAL_CODEC: $Codec<$Optional<$WithConditions<$Advancement>>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Advancement>;
        get root(): boolean;
        isRoot(): boolean;
        static name(arg0: $AdvancementHolder): $Component;
        criteria(): $Map<string, $Criterion<any>>;
        display(): $Optional<$DisplayInfo>;
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        parent(): $Optional<$ResourceLocation>;
        requirements(): $AdvancementRequirements;
        rewards(): $AdvancementRewards;
        sendsTelemetryEvent(): boolean;
        toString(): string;
        validate(arg0: $ProblemReporter, arg1: $HolderGetter$Provider_<$ResourceKey<$Registry<any>>, $Optional<$HolderGetter<any>>>): void;
    }

    export class $AdvancementHolder extends $Record {
        constructor(arg0: $ResourceLocation_, arg1: $Advancement);
        static LIST_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $List<$AdvancementHolder>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $AdvancementHolder>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        toString(): string;
        value(): $Advancement;
    }

    export class $AdvancementNode {
        constructor(arg0: $AdvancementHolder, arg1: $AdvancementNode);
        static getRoot(arg0: $AdvancementNode): $AdvancementNode;
        addChild(arg0: $AdvancementNode): void;
        advancement(): $Advancement;
        children(): $Iterable<$AdvancementNode>;
        equals(arg0: object): boolean;
        hashCode(): number;
        holder(): $AdvancementHolder;
        parent(): $AdvancementNode;
        root(): $AdvancementNode;
        toString(): string;
    }

    export class $AdvancementProgress implements $Comparable<$AdvancementProgress> {
        constructor();
        static CODEC: $Codec<$AdvancementProgress>;
        get completedCriteria(): $Iterable<string>;
        getCompletedCriteria(): $Iterable<string>;
        get firstProgressDate(): $Instant;
        getFirstProgressDate(): $Instant;
        get percent(): number;
        getPercent(): number;
        get progressText(): $Component;
        getProgressText(): $Component;
        get remainingCriteria(): $Iterable<string>;
        getRemainingCriteria(): $Iterable<string>;
        get done(): boolean;
        isDone(): boolean;
        static fromNetwork(arg0: $FriendlyByteBuf): $AdvancementProgress;
        compareTo(arg0: $AdvancementProgress): number;
        getCriterion(arg0: string): $CriterionProgress;
        grantProgress(arg0: string): boolean;
        hasProgress(): boolean;
        revokeProgress(arg0: string): boolean;
        serializeToNetwork(arg0: $FriendlyByteBuf): void;
        toString(): string;
        update(arg0: $AdvancementRequirements): void;
    }

    export class $AdvancementRequirements extends $Record {
        constructor(arg0: string[][]);
        constructor(arg0: $FriendlyByteBuf);
        static CODEC: $Codec<$AdvancementRequirements>;
        static EMPTY: $AdvancementRequirements;
        get empty(): boolean;
        isEmpty(): boolean;
        static allOf(arg0: string[]): $AdvancementRequirements;
        static anyOf(arg0: string[]): $AdvancementRequirements;
        count(arg0: $Predicate_<string, string, boolean>): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        names(): $Set<string>;
        requirements(): $List<$List<string>>;
        size(): number;
        test(arg0: $Predicate_<string, string, boolean>): boolean;
        toString(): string;
        validate(arg0: string[]): $DataResult<$AdvancementRequirements>;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $AdvancementRewards extends $Record {
        constructor(experience: number, loot: $ResourceKey<$LootTable>[], recipes: $ResourceLocation_[], function_: $Optional<$CacheableFunction>);
        static CODEC: $Codec<$AdvancementRewards>;
        static EMPTY: $AdvancementRewards;
        equals(arg0: object): boolean;
        experience(): number;
        function(): $Optional<$CacheableFunction>;
        grant(arg0: $ServerPlayer): void;
        hashCode(): number;
        loot(): $List<$ResourceKey<$LootTable>>;
        recipes(): $List<$ResourceLocation>;
        toString(): string;
    }

    export class $AdvancementTree {
        constructor();
        addAll(arg0: $AdvancementHolder[]): void;
        clear(): void;
        get(arg0: $AdvancementHolder): $AdvancementNode;
        get(arg0: $ResourceLocation_): $AdvancementNode;
        nodes(): $Collection<$AdvancementNode>;
        remove(arg0: $ResourceLocation_[]): void;
        roots(): $Iterable<$AdvancementNode>;
    }

    export interface $AdvancementTree$Listener {
        onAddAdvancementRoot(arg0: $AdvancementNode): void;
        onAddAdvancementTask(arg0: $AdvancementNode): void;
        onAdvancementsCleared(): void;
        onRemoveAdvancementRoot(arg0: $AdvancementNode): void;
        onRemoveAdvancementTask(arg0: $AdvancementNode): void;
    }

    export class $AdvancementType {
        static CHALLENGE: $AdvancementType;
        static GOAL: $AdvancementType;
        static TASK: $AdvancementType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AdvancementType[];
        static valueOf(name: string): $AdvancementType;
    }

    export class $Criterion<T extends $CriterionTriggerInstance> extends $Record {
        constructor(arg0: $CriterionTrigger<T>, arg1: T);
        static CODEC: $Codec<$Criterion<any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        triggerInstance(): T;
        trigger(): $CriterionTrigger<T>;
    }

    export class $CriterionProgress {
        constructor();
        constructor(arg0: $Instant);
        get obtained(): $Instant;
        getObtained(): $Instant;
        get done(): boolean;
        isDone(): boolean;
        static fromNetwork(arg0: $FriendlyByteBuf): $CriterionProgress;
        grant(): void;
        revoke(): void;
        serializeToNetwork(arg0: $FriendlyByteBuf): void;
        toString(): string;
    }

    export interface $CriterionTrigger<T extends $CriterionTriggerInstance> {
        addPlayerListener(arg0: $PlayerAdvancements, arg1: $CriterionTrigger$Listener<T>): void;
        codec(): $Codec<T>;
        createCriterion(arg0: T): $Criterion<T>;
        removePlayerListeners(arg0: $PlayerAdvancements): void;
        removePlayerListener(arg0: $PlayerAdvancements, arg1: $CriterionTrigger$Listener<T>): void;
    }

    export class $CriterionTrigger$Listener<T extends $CriterionTriggerInstance> extends $Record {
        constructor(arg0: T, arg1: $AdvancementHolder, arg2: string);
        advancement(): $AdvancementHolder;
        criterion(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        run(arg0: $PlayerAdvancements): void;
        toString(): string;
        trigger(): T;
    }

    export class $DisplayInfo {
        constructor(arg0: $ItemStack_, arg1: $Component_, arg2: $Component_, arg3: $Optional<$ResourceLocation_>, arg4: $AdvancementType_, arg5: boolean, arg6: boolean, arg7: boolean);
        static CODEC: $Codec<$DisplayInfo>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DisplayInfo>;
        get background(): $Optional<$ResourceLocation>;
        getBackground(): $Optional<$ResourceLocation>;
        get description(): $Component;
        getDescription(): $Component;
        get icon(): $ItemStack;
        getIcon(): $ItemStack;
        get title(): $Component;
        getTitle(): $Component;
        get type(): $AdvancementType;
        getType(): $AdvancementType;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get hidden(): boolean;
        isHidden(): boolean;
        setLocation(arg0: number, arg1: number): void;
        shouldAnnounceChat(): boolean;
        shouldShowToast(): boolean;
    }

    export type $AdvancementType_ = $AdvancementType | "CHALLENGE" | "GOAL" | "TASK";
}
