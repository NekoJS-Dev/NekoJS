import { $Either, $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DynamicOps, $Keyable, $Keyable_, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $LongConsumer } from "java:it/unimi/dsi/fastutil/longs";
import { $Comparable, $Comparable_, $Iterable, $Record, $Runnable, $Runnable_ } from "java:java/lang";
import { $AbstractList, $Collection, $Comparator, $Comparator_, $Iterator, $List, $Map, $Map$Entry, $Optional, $Set, $Spliterator } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $Consumer, $Consumer_, $Function, $Function_, $IntFunction, $IntFunction_, $Predicate, $Predicate_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $ListTag } from "java:net/minecraft/nbt";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $RegistryOps, $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $RandomSource, $StringRepresentable, $StringRepresentable$EnumCodec, $StringRepresentable_ } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $ChunkPos, $Level } from "java:net/minecraft/world/level";
import { $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $ChunkAccess } from "java:net/minecraft/world/level/chunk";
import { $EntityAccess } from "java:net/minecraft/world/level/entity";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $IHolderExtension, $IHolderLookupProviderExtension, $IHolderSetExtension, $IHolderSetExtension$SerializationType, $IHolderSetExtension$SerializationType_ } from "java:net/neoforged/neoforge/common/extensions";
import { $IRegistryExtension } from "java:net/neoforged/neoforge/registries";
import { $DataMapType } from "java:net/neoforged/neoforge/registries/datamaps";
import { $Matrix4f, $Quaternionf, $Vector3f } from "java:org/joml";
import { $Logger } from "java:org/slf4j";

export * as component from "java:net/minecraft/core/component";
export * as particles from "java:net/minecraft/core/particles";

declare module "java:net/minecraft/core" {
    export class $AxisCycle {
        static BACKWARD: $AxisCycle;
        static FORWARD: $AxisCycle;
        static NONE: $AxisCycle;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AxisCycle[];
        static valueOf(name: string): $AxisCycle;
    }

    export class $BlockPos extends $Vec3i {
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: $Vec3i);
        static CODEC: $Codec<$BlockPos>;
        static PACKED_Y_LENGTH: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $BlockPos>;
        static ZERO: $BlockPos;
        get bottomCenter(): $Vec3;
        getBottomCenter(): $Vec3;
        get center(): $Vec3;
        getCenter(): $Vec3;
        static asLong(arg0: number, arg1: number, arg2: number): number;
        static betweenClosedStream(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): $Stream<$BlockPos>;
        static betweenClosedStream(arg0: $BlockPos_, arg1: $BlockPos_): $Stream<$BlockPos>;
        static betweenClosedStream(arg0: $BoundingBox): $Stream<$BlockPos>;
        static betweenClosedStream(arg0: $AABB): $Stream<$BlockPos>;
        static betweenClosed(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): $Iterable<$BlockPos>;
        static betweenClosed(arg0: $BlockPos_, arg1: $BlockPos_): $Iterable<$BlockPos>;
        static breadthFirstTraversal(arg0: $BlockPos_, arg1: number, arg2: number, arg3: $BiConsumer_<$BlockPos, $Consumer<$BlockPos>, $BlockPos, $Consumer<$BlockPos>>, arg4: $Predicate_<$BlockPos, $BlockPos, boolean>): number;
        static containing(arg0: number, arg1: number, arg2: number): $BlockPos;
        static containing(arg0: $Position): $BlockPos;
        static findClosestMatch(arg0: $BlockPos_, arg1: number, arg2: number, arg3: $Predicate_<$BlockPos, $BlockPos, boolean>): $Optional<$BlockPos>;
        static getFlatIndex(arg0: number): number;
        static getX(arg0: number): number;
        static getY(arg0: number): number;
        static getZ(arg0: number): number;
        static max(arg0: $BlockPos_, arg1: $BlockPos_): $BlockPos;
        static min(arg0: $BlockPos_, arg1: $BlockPos_): $BlockPos;
        static offset(arg0: number, arg1: number, arg2: number, arg3: number): number;
        static offset(arg0: number, arg1: $Direction_): number;
        static of(arg0: number): $BlockPos;
        static randomBetweenClosed(arg0: $RandomSource, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): $Iterable<$BlockPos>;
        static randomInCube(arg0: $RandomSource, arg1: number, arg2: $BlockPos_, arg3: number): $Iterable<$BlockPos>;
        static spiralAround(arg0: $BlockPos_, arg1: number, arg2: $Direction_, arg3: $Direction_): $Iterable<$BlockPos$MutableBlockPos>;
        static squareOutSouthEast(arg0: $BlockPos_): $Stream<$BlockPos>;
        static withinManhattanStream(arg0: $BlockPos_, arg1: number, arg2: number, arg3: number): $Stream<$BlockPos>;
        static withinManhattan(arg0: $BlockPos_, arg1: number, arg2: number, arg3: number): $Iterable<$BlockPos>;
        above(arg0: number): $BlockPos;
        above(): $BlockPos;
        asLong(): number;
        atY(arg0: number): $BlockPos;
        below(arg0: number): $BlockPos;
        below(): $BlockPos;
        clampLocationWithin(arg0: $Vec3_): $Vec3;
        cross(arg0: $Vec3i): $BlockPos;
        east(arg0: number): $BlockPos;
        east(): $BlockPos;
        immutable(): $BlockPos;
        multiply(arg0: number): $BlockPos;
        mutable(): $BlockPos$MutableBlockPos;
        north(arg0: number): $BlockPos;
        north(): $BlockPos;
        offset(arg0: number, arg1: number, arg2: number): $BlockPos;
        offset(arg0: $Vec3i): $BlockPos;
        relative(arg0: $Direction$Axis_, arg1: number): $BlockPos;
        relative(arg0: $Direction_, arg1: number): $BlockPos;
        relative(arg0: $Direction_): $BlockPos;
        rotate(arg0: $Rotation_): $BlockPos;
        south(arg0: number): $BlockPos;
        south(): $BlockPos;
        subtract(arg0: $Vec3i): $BlockPos;
        west(arg0: number): $BlockPos;
        west(): $BlockPos;
    }

    export class $BlockPos$MutableBlockPos extends $BlockPos {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: number, arg1: number, arg2: number);
        above(arg0: number): $BlockPos;
        above(): $BlockPos;
        below(arg0: number): $BlockPos;
        below(): $BlockPos;
        clamp(arg0: $Direction$Axis_, arg1: number, arg2: number): $BlockPos$MutableBlockPos;
        cross(arg0: $Vec3i): $BlockPos;
        east(arg0: number): $BlockPos;
        east(): $BlockPos;
        immutable(): $BlockPos;
        move(arg0: number, arg1: number, arg2: number): $BlockPos$MutableBlockPos;
        move(arg0: $Direction_, arg1: number): $BlockPos$MutableBlockPos;
        move(arg0: $Direction_): $BlockPos$MutableBlockPos;
        move(arg0: $Vec3i): $BlockPos$MutableBlockPos;
        multiply(arg0: number): $BlockPos;
        north(arg0: number): $BlockPos;
        north(): $BlockPos;
        offset(arg0: number, arg1: number, arg2: number): $BlockPos;
        offset(arg0: $Vec3i): $BlockPos;
        relative(arg0: $Direction$Axis_, arg1: number): $BlockPos;
        relative(arg0: $Direction_, arg1: number): $BlockPos;
        relative(arg0: $Direction_): $BlockPos;
        rotate(arg0: $Rotation_): $BlockPos;
        setWithOffset(arg0: $Vec3i, arg1: number, arg2: number, arg3: number): $BlockPos$MutableBlockPos;
        setWithOffset(arg0: $Vec3i, arg1: $Direction_): $BlockPos$MutableBlockPos;
        setWithOffset(arg0: $Vec3i, arg1: $Vec3i): $BlockPos$MutableBlockPos;
        set(arg0: number, arg1: number, arg2: number): $BlockPos$MutableBlockPos;
        set(arg0: number, arg1: number, arg2: number): $BlockPos$MutableBlockPos;
        set(arg0: number): $BlockPos$MutableBlockPos;
        set(arg0: $AxisCycle_, arg1: number, arg2: number, arg3: number): $BlockPos$MutableBlockPos;
        set(arg0: $Vec3i): $BlockPos$MutableBlockPos;
        south(arg0: number): $BlockPos;
        south(): $BlockPos;
        subtract(arg0: $Vec3i): $BlockPos;
        west(arg0: number): $BlockPos;
        west(): $BlockPos;
    }

    export class $Direction {
        static DOWN: $Direction;
        static EAST: $Direction;
        static NORTH: $Direction;
        static SOUTH: $Direction;
        static UP: $Direction;
        static WEST: $Direction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction[];
        static valueOf(name: string): $Direction;
    }

    export class $Direction$Axis {
        static X: $Direction$Axis;
        static Y: $Direction$Axis;
        static Z: $Direction$Axis;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$Axis[];
        static valueOf(name: string): $Direction$Axis;
    }

    export class $Direction$AxisDirection {
        static NEGATIVE: $Direction$AxisDirection;
        static POSITIVE: $Direction$AxisDirection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$AxisDirection[];
        static valueOf(name: string): $Direction$AxisDirection;
    }

    export class $Direction$Plane {
        static HORIZONTAL: $Direction$Plane;
        static VERTICAL: $Direction$Plane;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$Plane[];
        static valueOf(name: string): $Direction$Plane;
    }

    export class $Direction8 {
        static EAST: $Direction8;
        static NORTH: $Direction8;
        static NORTH_EAST: $Direction8;
        static NORTH_WEST: $Direction8;
        static SOUTH: $Direction8;
        static SOUTH_EAST: $Direction8;
        static SOUTH_WEST: $Direction8;
        static WEST: $Direction8;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction8[];
        static valueOf(name: string): $Direction8;
    }

    export class $FrontAndTop {
        static DOWN_EAST: $FrontAndTop;
        static DOWN_NORTH: $FrontAndTop;
        static DOWN_SOUTH: $FrontAndTop;
        static DOWN_WEST: $FrontAndTop;
        static EAST_UP: $FrontAndTop;
        static NORTH_UP: $FrontAndTop;
        static SOUTH_UP: $FrontAndTop;
        static UP_EAST: $FrontAndTop;
        static UP_NORTH: $FrontAndTop;
        static UP_SOUTH: $FrontAndTop;
        static UP_WEST: $FrontAndTop;
        static WEST_UP: $FrontAndTop;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $FrontAndTop[];
        static valueOf(name: string): $FrontAndTop;
    }

    export class $GlobalPos extends $Record {
        constructor(arg0: $ResourceKey<$Level>, arg1: $BlockPos_);
        static CODEC: $Codec<$GlobalPos>;
        static MAP_CODEC: $MapCodec<$GlobalPos>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $GlobalPos>;
        static of(arg0: $ResourceKey<$Level>, arg1: $BlockPos_): $GlobalPos;
        dimension(): $ResourceKey<$Level>;
        equals(arg0: object): boolean;
        hashCode(): number;
        pos(): $BlockPos;
        toString(): string;
    }

    export interface $Holder<T> extends $IHolderExtension<T> {
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        getRegisteredName(): string;
        isBound(): boolean;
        is(arg0: $Predicate_<$ResourceKey<T>, $ResourceKey<T>, boolean>): boolean;
        is(arg0: $Holder_): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $ResourceLocation_): boolean;
        is(arg0: $TagKey_): boolean;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }
    export const $Holder: {
        direct<T>(arg0: T): $Holder<T>;
    };

    export class $Holder$Kind {
        static DIRECT: $Holder$Kind;
        static REFERENCE: $Holder$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Holder$Kind[];
        static valueOf(name: string): $Holder$Kind;
    }

    export class $Holder$Reference<T> implements $Holder<T> {
        get delegate(): $Holder<T>;
        getDelegate(): $Holder<T>;
        get key(): $ResourceKey<T>;
        getKey(): $ResourceKey<T>;
        get registeredName(): string;
        getRegisteredName(): string;
        get bound(): boolean;
        isBound(): boolean;
        static createIntrusive<T>(arg0: $HolderOwner<T>, arg1: T): $Holder$Reference<T>;
        static createStandAlone<T>(arg0: $HolderOwner<T>, arg1: $ResourceKey<T>): $Holder$Reference<T>;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        equals(arg0: object): boolean;
        getData<A>(arg0: $DataMapType<T, A>): A;
        hashCode(): number;
        is(arg0: $Predicate_<$ResourceKey<T>, $ResourceKey<T>, boolean>): boolean;
        is(arg0: $Holder_): boolean;
        is(arg0: $ResourceKey<T>): boolean;
        is(arg0: $ResourceLocation_): boolean;
        is(arg0: $TagKey_): boolean;
        key(): $ResourceKey<T>;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        toString(): string;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrapLookup(): $HolderLookup$RegistryLookup<T>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export interface $HolderGetter<T> {
        getOrThrow(arg0: $ResourceKey<T>): $Holder$Reference<T>;
        getOrThrow(arg0: $TagKey_): $HolderSet$Named<T>;
        get(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        get(arg0: $TagKey_): $Optional<$HolderSet$Named<T>>;
    }

    export interface $HolderGetter$Provider {
        get<T>(arg0: $ResourceKey<$Registry<T>>, arg1: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        lookupOrThrow<T>(arg0: $ResourceKey<$Registry<T>>): $HolderGetter<T>;
        lookup<T>(arg0: $ResourceKey<$Registry<T>>): $Optional<$HolderGetter<T>>;
    }

    export interface $HolderLookup<T> extends $HolderGetter<T> {
        listElementIds(): $Stream<$ResourceKey<T>>;
        listElements(): $Stream<$Holder$Reference<T>>;
        listTagIds(): $Stream<$TagKey<T>>;
        listTags(): $Stream<$HolderSet$Named<T>>;
    }

    export interface $HolderLookup$Provider extends $IHolderLookupProviderExtension {
        asGetterLookup(): $HolderGetter$Provider;
        createSerializationContext<V>(arg0: $DynamicOps<V>): $RegistryOps<V>;
        listRegistries(): $Stream<$ResourceKey<$Registry<any>>>;
        lookupOrThrow<T>(arg0: $ResourceKey<$Registry<T>>): $HolderLookup$RegistryLookup<T>;
        lookup<T>(arg0: $ResourceKey<$Registry<T>>): $Optional<$HolderLookup$RegistryLookup<T>>;
    }
    export const $HolderLookup$Provider: {
        create(arg0: $Stream<$HolderLookup$RegistryLookup<any>>): $HolderLookup$Provider;
    };

    export interface $HolderLookup$RegistryLookup<T> extends $HolderLookup<T>, $HolderOwner<T> {
        filterElements(arg0: $Predicate_<T, T, boolean>): $HolderLookup$RegistryLookup<T>;
        filterFeatures(arg0: $FeatureFlagSet): $HolderLookup$RegistryLookup<T>;
        getData<A>(arg0: $DataMapType<T, A>, arg1: $ResourceKey<T>): A;
        key(): $ResourceKey<$Registry<T>>;
        registryLifecycle(): $Lifecycle;
    }

    export interface $HolderOwner<T> {
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
    }

    export interface $HolderSet<T> extends $Iterable<$Holder<T>>, $IHolderSetExtension<T> {
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        contains(arg0: $Holder_): boolean;
        getRandomElement(arg0: $RandomSource): $Optional<$Holder<T>>;
        get(arg0: number): $Holder<T>;
        size(): number;
        stream(): $Stream<$Holder<T>>;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }
    export const $HolderSet: {
        direct<T>(arg0: $Holder_[]): $HolderSet$Direct<T>;
        direct<E, T>(arg0: $Function_<E, $Holder<T>, E, $Holder_>, arg1?: E[]): $HolderSet$Direct<T>;
        direct<E, T>(arg0: $Function_<E, $Holder<T>, E, $Holder_>, arg1: E[]): $HolderSet$Direct<T>;
        direct<T>(arg0?: $Holder_[]): $HolderSet$Direct<T>;
        emptyNamed<T>(arg0: $HolderOwner<T>, arg1: $TagKey_): $HolderSet$Named<T>;
        empty<T>(): $HolderSet<T>;
    };

    export class $HolderSet$Direct<T> extends $HolderSet$ListBacked<T> {
        addInvalidationListener(arg0: $Runnable_): void;
        contains(arg0: $Holder_): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<$Holder<T>, $Holder<T>>): void;
        hashCode(): number;
        serializationType(): $IHolderSetExtension$SerializationType;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export class $HolderSet$ListBacked<T> implements $HolderSet<T> {
        constructor();
        addInvalidationListener(arg0: $Runnable_): void;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        contains(arg0: $Holder_): boolean;
        forEach(arg0: $Consumer_<$Holder<T>, $Holder<T>>): void;
        getRandomElement(arg0: $RandomSource): $Optional<$Holder<T>>;
        get(arg0: number): $Holder<T>;
        iterator(): $Iterator<$Holder<T>>;
        serializationType(): $IHolderSetExtension$SerializationType;
        size(): number;
        spliterator(): $Spliterator<$Holder<T>>;
        stream(): $Stream<$Holder<T>>;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export class $HolderSet$Named<T> extends $HolderSet$ListBacked<T> {
        addInvalidationListener(arg0: $Runnable_): void;
        canSerializeIn(arg0: $HolderOwner<T>): boolean;
        contains(arg0: $Holder_): boolean;
        forEach(arg0: $Consumer_<$Holder<T>, $Holder<T>>): void;
        key(): $TagKey<T>;
        serializationType(): $IHolderSetExtension$SerializationType;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export interface $IdMap<T> extends $Iterable<T> {
        byIdOrThrow(arg0: number): T;
        byId(arg0: number): T;
        getIdOrThrow(arg0: T): number;
        getId(arg0: T): number;
        size(): number;
    }
    export const $IdMap: {
        readonly DEFAULT: number;
    };

    export class $IdMapper<T> implements $IdMap<T> {
        constructor();
        constructor(arg0: number);
        addMapping(arg0: T, arg1: number): void;
        add(arg0: T): void;
        byIdOrThrow(arg0: number): T;
        byId(arg0: number): T;
        contains(arg0: number): boolean;
        forEach(arg0: $Consumer_<T, T>): void;
        getIdOrThrow(arg0: T): number;
        getId(arg0: T): number;
        iterator(): $Iterator<T>;
        size(): number;
        spliterator(): $Spliterator<T>;
    }

    export class $LayeredRegistryAccess<T> {
        constructor(arg0: T[]);
        compositeAccess(): $RegistryAccess$Frozen;
        getAccessForLoading(arg0: T): $RegistryAccess$Frozen;
        getAccessFrom(arg0: T): $RegistryAccess$Frozen;
        getLayer(arg0: T): $RegistryAccess$Frozen;
        replaceFrom(arg0: T, arg1: $RegistryAccess$Frozen[]): $LayeredRegistryAccess<T>;
        replaceFrom(arg0: T, arg1?: $RegistryAccess$Frozen[]): $LayeredRegistryAccess<T>;
    }

    export class $NonNullList<E> extends $AbstractList<E> {
        get first(): E;
        getFirst(): E;
        get last(): E;
        getLast(): E;
        static codecOf<E>(arg0: $Codec<E>): $Codec<$NonNullList<E>>;
        static copyOf<E>(arg0: E[]): $NonNullList<E>;
        static createWithCapacity<E>(arg0: number): $NonNullList<E>;
        static create<E>(): $NonNullList<E>;
        static of<E>(arg0: E, arg1?: E[]): $NonNullList<E>;
        static withSize<E>(arg0: number, arg1: E): $NonNullList<E>;
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        add(arg0: E): boolean;
        add(arg0: number, arg1: E): void;
        clear(): void;
        forEach(arg0: $Consumer_<E, E>): void;
        get(arg0: number): E;
        parallelStream(): $Stream<E>;
        removeFirst(): E;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        removeLast(): E;
        remove(arg0: number): E;
        remove(arg0: object): boolean;
        replaceAll(arg0: $UnaryOperator_<E, E, E>): void;
        reversed(): $List<E>;
        set(arg0: number, arg1: E): E;
        size(): number;
        sort(arg0: $Comparator_<E, E, E, number>): void;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export interface $Position {
        x(): number;
        y(): number;
        z(): number;
    }

    export class $RegistrationInfo extends $Record {
        constructor(arg0: $Optional<$KnownPack>, arg1: $Lifecycle);
        static BUILT_IN: $RegistrationInfo;
        equals(arg0: object): boolean;
        hashCode(): number;
        knownPackInfo(): $Optional<$KnownPack>;
        lifecycle(): $Lifecycle;
        toString(): string;
    }

    export interface $Registry<T> extends $Keyable, $IdMap<T>, $IRegistryExtension<T> {
        asHolderIdMap(): $IdMap<$Holder<T>>;
        asLookup(): $HolderLookup$RegistryLookup<T>;
        asTagAddingLookup(): $HolderLookup$RegistryLookup<T>;
        bindTags(arg0: { [key: $TagKey_]: $Holder_[] }): void;
        byNameCodec(): $Codec<T>;
        containsKey(arg0: $ResourceKey<T>): boolean;
        containsKey(arg0: $ResourceLocation_): boolean;
        createIntrusiveHolder(arg0: T): $Holder$Reference<T>;
        entrySet(): $Set<$Map$Entry<$ResourceKey<T>, T>>;
        freeze(): $Registry<T>;
        getAny(): $Optional<$Holder$Reference<T>>;
        getHolderOrThrow(arg0: $ResourceKey<T>): $Holder$Reference<T>;
        getHolder(arg0: number): $Optional<$Holder$Reference<T>>;
        getHolder(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        getHolder(arg0: $ResourceLocation_): $Optional<$Holder$Reference<T>>;
        getId(arg0: T): number;
        getKey(arg0: T): $ResourceLocation;
        getOptional(arg0: $ResourceKey<T>): $Optional<T>;
        getOptional(arg0: $ResourceLocation_): $Optional<T>;
        getOrCreateTag(arg0: $TagKey_): $HolderSet$Named<T>;
        getOrThrow(arg0: $ResourceKey<T>): T;
        getRandomElementOf(arg0: $TagKey_, arg1: $RandomSource): $Optional<$Holder<T>>;
        getRandom(arg0: $RandomSource): $Optional<$Holder$Reference<T>>;
        getResourceKey(arg0: T): $Optional<$ResourceKey<T>>;
        getTagNames(): $Stream<$TagKey<T>>;
        getTagOrEmpty(arg0: $TagKey_): $Iterable<$Holder<T>>;
        getTags(): $Stream<$Pair<$TagKey<T>, $HolderSet$Named<T>>>;
        getTag(arg0: $TagKey_): $Optional<$HolderSet$Named<T>>;
        get(arg0: $ResourceKey<T>): T;
        get(arg0: $ResourceLocation_): T;
        holderByNameCodec(): $Codec<$Holder<T>>;
        holderOwner(): $HolderOwner<T>;
        holders(): $Stream<$Holder$Reference<T>>;
        keySet(): $Set<$ResourceLocation>;
        keys<U>(arg0: $DynamicOps<U>): $Stream<U>;
        key(): $ResourceKey<$Registry<T>>;
        registrationInfo(arg0: $ResourceKey<T>): $Optional<$RegistrationInfo>;
        registryKeySet(): $Set<$ResourceKey<T>>;
        registryLifecycle(): $Lifecycle;
        resetTags(): void;
        stream(): $Stream<T>;
        wrapAsHolder(arg0: T): $Holder<T>;
    }
    export const $Registry: {
        registerForHolder<T>(arg0: $Registry<T>, arg1: $ResourceKey<T>, arg2: T): $Holder$Reference<T>;
        registerForHolder<T>(arg0: $Registry<T>, arg1: $ResourceLocation_, arg2: T): $Holder$Reference<T>;
        register<T>(arg0: $Registry<any>, arg1: string, arg2: T): T;
        register<V, T>(arg0: $Registry<V>, arg1: $ResourceKey<V>, arg2: T): T;
        register<V, T>(arg0: $Registry<V>, arg1: $ResourceLocation_, arg2: T): T;
    };

    export interface $RegistryAccess extends $HolderLookup$Provider {
        allRegistriesLifecycle(): $Lifecycle;
        freeze(): $RegistryAccess$Frozen;
        listRegistries(): $Stream<$ResourceKey<$Registry<any>>>;
        lookup<T>(arg0: $ResourceKey<$Registry<T>>): $Optional<$HolderLookup$RegistryLookup<T>>;
        registries(): $Stream<$RegistryAccess$RegistryEntry<any>>;
        registryOrThrow<E>(arg0: $ResourceKey<$Registry<E>>): $Registry<E>;
        registry<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$Registry<E>>;
    }
    export const $RegistryAccess: {
        fromRegistryOfRegistries(arg0: $Registry<$Registry<any>>): $RegistryAccess$Frozen;
        readonly EMPTY: $RegistryAccess$Frozen;
        readonly LOGGER: $Logger;
    };

    export interface $RegistryAccess$Frozen extends $RegistryAccess {
    }

    export class $RegistryAccess$RegistryEntry<T> extends $Record {
        constructor(arg0: $ResourceKey<$Registry<T>>, arg1: $Registry<T>);
        equals(arg0: object): boolean;
        hashCode(): number;
        key(): $ResourceKey<$Registry<T>>;
        toString(): string;
        value(): $Registry<T>;
    }

    export class $Rotations {
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: $ListTag);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Rotations>;
        get wrappedX(): number;
        getWrappedX(): number;
        get wrappedY(): number;
        getWrappedY(): number;
        get wrappedZ(): number;
        getWrappedZ(): number;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        equals(arg0: object): boolean;
        save(): $ListTag;
    }

    export class $SectionPos extends $Vec3i {
        static SECTION_BITS: number;
        static SECTION_HALF_SIZE: number;
        static SECTION_MASK: number;
        static SECTION_MAX_INDEX: number;
        static SECTION_SIZE: number;
        static aroundAndAtBlockPos(arg0: number, arg1: number, arg2: number, arg3: $LongConsumer): void;
        static aroundAndAtBlockPos(arg0: number, arg1: $LongConsumer): void;
        static aroundAndAtBlockPos(arg0: $BlockPos_, arg1: $LongConsumer): void;
        static aroundChunk(arg0: $ChunkPos, arg1: number, arg2: number, arg3: number): $Stream<$SectionPos>;
        static asLong(arg0: number, arg1: number, arg2: number): number;
        static asLong(arg0: $BlockPos_): number;
        static betweenClosedStream(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): $Stream<$SectionPos>;
        static blockToSectionCoord(arg0: number): number;
        static blockToSectionCoord(arg0: number): number;
        static blockToSection(arg0: number): number;
        static bottomOf(arg0: $ChunkAccess): $SectionPos;
        static cube(arg0: $SectionPos, arg1: number): $Stream<$SectionPos>;
        static getZeroNode(arg0: number, arg1: number): number;
        static getZeroNode(arg0: number): number;
        static offset(arg0: number, arg1: number, arg2: number, arg3: number): number;
        static offset(arg0: number, arg1: $Direction_): number;
        static of(arg0: number, arg1: number, arg2: number): $SectionPos;
        static of(arg0: number): $SectionPos;
        static of(arg0: $BlockPos_): $SectionPos;
        static of(arg0: $Position): $SectionPos;
        static of(arg0: $ChunkPos, arg1: number): $SectionPos;
        static of(arg0: $EntityAccess): $SectionPos;
        static posToSectionCoord(arg0: number): number;
        static sectionRelativePos(arg0: $BlockPos_): number;
        static sectionRelativeX(arg0: number): number;
        static sectionRelativeY(arg0: number): number;
        static sectionRelativeZ(arg0: number): number;
        static sectionRelative(arg0: number): number;
        static sectionToBlockCoord(arg0: number, arg1: number): number;
        static sectionToBlockCoord(arg0: number): number;
        static x(arg0: number): number;
        static y(arg0: number): number;
        static z(arg0: number): number;
        asLong(): number;
        blocksInside(): $Stream<$BlockPos>;
        center(): $BlockPos;
        chunk(): $ChunkPos;
        maxBlockX(): number;
        maxBlockY(): number;
        maxBlockZ(): number;
        minBlockX(): number;
        minBlockY(): number;
        minBlockZ(): number;
        offset(arg0: number, arg1: number, arg2: number): $SectionPos;
        offset(arg0: $Vec3i): $Vec3i;
        origin(): $BlockPos;
        relativeToBlockPos(arg0: number): $BlockPos;
        relativeToBlockX(arg0: number): number;
        relativeToBlockY(arg0: number): number;
        relativeToBlockZ(arg0: number): number;
        x(): number;
        y(): number;
        z(): number;
    }

    export class $Vec3i implements $Comparable<$Vec3i> {
        constructor(arg0: number, arg1: number, arg2: number);
        static CODEC: $Codec<$Vec3i>;
        static ZERO: $Vec3i;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        static offsetCodec(arg0: number): $Codec<$Vec3i>;
        above(arg0: number): $Vec3i;
        above(): $Vec3i;
        below(arg0: number): $Vec3i;
        below(): $Vec3i;
        closerThan(arg0: $Vec3i, arg1: number): boolean;
        closerToCenterThan(arg0: $Position, arg1: number): boolean;
        compareTo(arg0: $Vec3i): number;
        cross(arg0: $Vec3i): $Vec3i;
        distManhattan(arg0: $Vec3i): number;
        distSqr(arg0: $Vec3i): number;
        distToCenterSqr(arg0: number, arg1: number, arg2: number): number;
        distToCenterSqr(arg0: $Position): number;
        distToLowCornerSqr(arg0: number, arg1: number, arg2: number): number;
        east(arg0: number): $Vec3i;
        east(): $Vec3i;
        equals(arg0: object): boolean;
        get(arg0: $Direction$Axis_): number;
        hashCode(): number;
        multiply(arg0: number): $Vec3i;
        north(arg0: number): $Vec3i;
        north(): $Vec3i;
        offset(arg0: number, arg1: number, arg2: number): $Vec3i;
        offset(arg0: $Vec3i): $Vec3i;
        relative(arg0: $Direction$Axis_, arg1: number): $Vec3i;
        relative(arg0: $Direction_, arg1: number): $Vec3i;
        relative(arg0: $Direction_): $Vec3i;
        south(arg0: number): $Vec3i;
        south(): $Vec3i;
        subtract(arg0: $Vec3i): $Vec3i;
        toShortString(): string;
        toString(): string;
        west(arg0: number): $Vec3i;
        west(): $Vec3i;
    }

    export type $AxisCycle_ = $AxisCycle | "BACKWARD" | "FORWARD" | "NONE";
    export type $BlockPos_ = $BlockPos | $Vec3 | { x: number, y: number, z: number } | number[];
    export type $Direction_ = $Direction | "DOWN" | "EAST" | "NORTH" | "SOUTH" | "UP" | "WEST";
    export type $Direction$Axis_ = $Direction$Axis | "X" | "Y" | "Z";
    export type $Direction$AxisDirection_ = $Direction$AxisDirection | "NEGATIVE" | "POSITIVE";
    export type $Direction$Plane_ = $Direction$Plane | "HORIZONTAL" | "VERTICAL";
    export type $Direction8_ = $Direction8 | "EAST" | "NORTH" | "NORTH_EAST" | "NORTH_WEST" | "SOUTH" | "SOUTH_EAST" | "SOUTH_WEST" | "WEST";
    export type $FrontAndTop_ = $FrontAndTop | "DOWN_EAST" | "DOWN_NORTH" | "DOWN_SOUTH" | "DOWN_WEST" | "EAST_UP" | "NORTH_UP" | "SOUTH_UP" | "UP_EAST" | "UP_NORTH" | "UP_SOUTH" | "UP_WEST" | "WEST_UP";
    /** registry entry id, e.g. 'minecraft:sharpness' (namespace defaults to minecraft) */
    export type $Holder_ = $Holder | string;
    export type $Holder$Kind_ = $Holder$Kind | "DIRECT" | "REFERENCE";
    export type $HolderGetter$Provider_<CallbackArg0 = $ResourceKey<$Registry<any>>, CallbackResult = $Optional<$HolderGetter<any>>> = ((arg0: CallbackArg0) => CallbackResult) | $HolderGetter$Provider;
}
