import { $Collection, $UUID } from "java:java/util";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ServerBossEvent, $ServerPlayer } from "java:net/minecraft/server/level";

declare module "java:net/minecraft/server/bossevents" {
    export class $CustomBossEvent extends $ServerBossEvent {
        constructor(arg0: $ResourceLocation_, arg1: $Component_);
        get displayName(): $Component;
        getDisplayName(): $Component;
        get max(): number;
        getMax(): number;
        set max(value: number);
        get textId(): $ResourceLocation;
        getTextId(): $ResourceLocation;
        get value(): number;
        getValue(): number;
        set value(value: number);
        static load(arg0: $CompoundTag_, arg1: $ResourceLocation_, arg2: $HolderLookup$Provider): $CustomBossEvent;
        addOfflinePlayer(arg0: string): void;
        addPlayer(arg0: $ServerPlayer): void;
        onPlayerConnect(arg0: $ServerPlayer): void;
        onPlayerDisconnect(arg0: $ServerPlayer): void;
        removeAllPlayers(): void;
        removePlayer(arg0: $ServerPlayer): void;
        save(arg0: $HolderLookup$Provider): $CompoundTag;
    }

    export class $CustomBossEvents {
        constructor();
        get events(): $Collection<$CustomBossEvent>;
        getEvents(): $Collection<$CustomBossEvent>;
        get ids(): $Collection<$ResourceLocation>;
        getIds(): $Collection<$ResourceLocation>;
        create(arg0: $ResourceLocation_, arg1: $Component_): $CustomBossEvent;
        get(arg0: $ResourceLocation_): $CustomBossEvent;
        load(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): void;
        onPlayerConnect(arg0: $ServerPlayer): void;
        onPlayerDisconnect(arg0: $ServerPlayer): void;
        remove(arg0: $CustomBossEvent): void;
        save(arg0: $HolderLookup$Provider): $CompoundTag;
    }

}
