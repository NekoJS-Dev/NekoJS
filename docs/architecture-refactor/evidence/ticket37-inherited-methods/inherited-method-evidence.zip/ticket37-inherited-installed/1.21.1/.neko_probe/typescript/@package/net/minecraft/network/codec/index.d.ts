import { $Function3, $Function3_, $Function4, $Function4_, $Function5, $Function5_, $Function6, $Function6_ } from "java:com/mojang/datafixers/util";
import { $BiFunction, $BiFunction_, $Function, $Function_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";

declare module "java:net/minecraft/network/codec" {
    export interface $StreamCodec<B, V> extends $StreamDecoder<B, V>, $StreamEncoder<B, V> {
        apply<O>(arg0: $StreamCodec$CodecOperation_<B, V, O, $StreamCodec<B, V>, $StreamCodec<B, O>>): $StreamCodec<B, O>;
        cast<S>(): $StreamCodec<S, V>;
        dispatch<U>(arg0: $Function_<U, V, U, V>, arg1: $Function_<V, $StreamCodec<B, U>, V, $StreamCodec<any, U>>): $StreamCodec<B, U>;
        mapStream<O>(arg0: $Function_<O, B, O, B>): $StreamCodec<O, V>;
        map<O>(arg0: $Function_<V, O, V, O>, arg1: $Function_<O, V, O, V>): $StreamCodec<B, O>;
    }
    export const $StreamCodec: {
        composite<B, C, T1>(arg0: $StreamCodec<any, T1>, arg1: $Function_<C, T1, C, T1>, arg2: $Function_<T1, C, T1, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2>(arg0: $StreamCodec<any, T1>, arg1: $Function_<C, T1, C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function_<C, T2, C, T2>, arg4: $BiFunction_<T1, T2, C, T1, T2, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3>(arg0: $StreamCodec<any, T1>, arg1: $Function_<C, T1, C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function_<C, T2, C, T2>, arg4: $StreamCodec<any, T3>, arg5: $Function_<C, T3, C, T3>, arg6: $Function3_<T1, T2, T3, C, T1, T2, T3, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4>(arg0: $StreamCodec<any, T1>, arg1: $Function_<C, T1, C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function_<C, T2, C, T2>, arg4: $StreamCodec<any, T3>, arg5: $Function_<C, T3, C, T3>, arg6: $StreamCodec<any, T4>, arg7: $Function_<C, T4, C, T4>, arg8: $Function4_<T1, T2, T3, T4, C, T1, T2, T3, T4, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5>(arg0: $StreamCodec<any, T1>, arg1: $Function_<C, T1, C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function_<C, T2, C, T2>, arg4: $StreamCodec<any, T3>, arg5: $Function_<C, T3, C, T3>, arg6: $StreamCodec<any, T4>, arg7: $Function_<C, T4, C, T4>, arg8: $StreamCodec<any, T5>, arg9: $Function_<C, T5, C, T5>, arg10: $Function5_<T1, T2, T3, T4, T5, C, T1, T2, T3, T4, T5, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6>(arg0: $StreamCodec<any, T1>, arg1: $Function_<C, T1, C, T1>, arg2: $StreamCodec<any, T2>, arg3: $Function_<C, T2, C, T2>, arg4: $StreamCodec<any, T3>, arg5: $Function_<C, T3, C, T3>, arg6: $StreamCodec<any, T4>, arg7: $Function_<C, T4, C, T4>, arg8: $StreamCodec<any, T5>, arg9: $Function_<C, T5, C, T5>, arg10: $StreamCodec<any, T6>, arg11: $Function_<C, T6, C, T6>, arg12: $Function6_<T1, T2, T3, T4, T5, T6, C, T1, T2, T3, T4, T5, T6, C>): $StreamCodec<B, C>;
        ofMember<B, V>(arg0: $StreamMemberEncoder_<B, V, V, B>, arg1: $StreamDecoder_<B, V, B, V>): $StreamCodec<B, V>;
        of<B, V>(arg0: $StreamEncoder_<B, V, B, V>, arg1: $StreamDecoder_<B, V, B, V>): $StreamCodec<B, V>;
        recursive<B, T>(arg0: $UnaryOperator_<$StreamCodec<B, T>, $StreamCodec<B, T>, $StreamCodec<B, T>>): $StreamCodec<B, T>;
        unit<B, V>(arg0: V): $StreamCodec<B, V>;
    };

    export interface $StreamCodec$CodecOperation<B, S, T> {
        apply(arg0: $StreamCodec<B, S>): $StreamCodec<B, T>;
    }

    export interface $StreamDecoder<I, T> {
        decode(arg0: I): T;
    }

    export interface $StreamEncoder<O, T> {
        encode(arg0: O, arg1: T): void;
    }

    export interface $StreamMemberEncoder<O, T> {
        encode(arg0: T, arg1: O): void;
    }

    export type $StreamCodec$CodecOperation_<Host0 = any, Host1 = any, Host2 = any, CallbackArg0 = $StreamCodec<Host0, Host1>, CallbackResult = $StreamCodec<Host0, Host2>> = ((arg0: CallbackArg0) => CallbackResult) | $StreamCodec$CodecOperation<Host0, Host1, Host2>;
    export type $StreamDecoder_<Host0 = any, Host1 = any, CallbackArg0 = Host0, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | $StreamDecoder<Host0, Host1>;
    export type $StreamEncoder_<Host0 = any, Host1 = any, CallbackArg0 = Host0, CallbackArg1 = Host1> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | $StreamEncoder<Host0, Host1>;
    export type $StreamMemberEncoder_<Host0 = any, Host1 = any, CallbackArg0 = Host1, CallbackArg1 = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | $StreamMemberEncoder<Host0, Host1>;
}
