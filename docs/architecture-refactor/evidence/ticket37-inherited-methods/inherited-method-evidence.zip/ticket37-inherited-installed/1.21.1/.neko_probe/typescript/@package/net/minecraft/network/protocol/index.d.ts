import { $ChannelHandlerContext } from "java:io/netty/channel";
import { $Iterable, $Record } from "java:java/lang";
import { $Consumer, $Consumer_, $Function, $Function_ } from "java:java/util/function";
import { $StreamCodec, $StreamDecoder, $StreamDecoder_, $StreamMemberEncoder, $StreamMemberEncoder_ } from "java:net/minecraft/network/codec";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $IPacketFlowExtension } from "java:net/neoforged/neoforge/common/extensions";

export * as common from "java:net/minecraft/network/protocol/common";
export * as cookie from "java:net/minecraft/network/protocol/cookie";
export * as game from "java:net/minecraft/network/protocol/game";
export * as login from "java:net/minecraft/network/protocol/login";
export * as ping from "java:net/minecraft/network/protocol/ping";
export * as status from "java:net/minecraft/network/protocol/status";

declare module "java:net/minecraft/network/protocol" {
    export class $BundleDelimiterPacket<T extends $PacketListener> implements $Packet<T> {
        constructor();
        get skippable(): boolean;
        isSkippable(): boolean;
        get terminal(): boolean;
        isTerminal(): boolean;
        handle(arg0: T): void;
        type(): $PacketType<$BundleDelimiterPacket<T>>;
    }

    export interface $BundlerInfo {
        startPacketBundling(arg0: $Packet<any>): $BundlerInfo$Bundler;
        unbundlePacket(arg0: $Packet<any>, arg1: $Consumer_<$Packet<any>, $Packet<any>>, arg2: $ChannelHandlerContext): void;
        unbundlePacket(arg0: $Packet<any>, arg1: $Consumer_<$Packet<any>, $Packet<any>>): void;
    }
    export const $BundlerInfo: {
        createForPacket<T, P>(arg0: $PacketType<P>, arg1: $Function_<$Iterable<$Packet<T>>, P, $Iterable<$Packet<T>>, P>, arg2: $BundleDelimiterPacket<any>): $BundlerInfo;
        readonly BUNDLE_SIZE_LIMIT: number;
    };

    export interface $BundlerInfo$Bundler {
        addPacket(arg0: $Packet<any>): $Packet<any>;
    }

    export interface $Packet<T extends $PacketListener> {
        handle(arg0: T): void;
        isSkippable(): boolean;
        isTerminal(): boolean;
        type(): $PacketType<$Packet<T>>;
    }
    export const $Packet: {
        codec<B, T>(arg0: $StreamMemberEncoder_<B, T, T, B>, arg1: $StreamDecoder_<B, T, B, T>): $StreamCodec<B, T>;
    };

    export class $PacketFlow {
        static CLIENTBOUND: $PacketFlow;
        static SERVERBOUND: $PacketFlow;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PacketFlow[];
        static valueOf(name: string): $PacketFlow;
    }

    export class $PacketType<T extends $Packet<any>> extends $Record {
        constructor(arg0: $PacketFlow_, arg1: $ResourceLocation_);
        equals(arg0: object): boolean;
        flow(): $PacketFlow;
        hashCode(): number;
        id(): $ResourceLocation;
        toString(): string;
    }

    export type $BundlerInfo$Bundler_<CallbackArg0 = $Packet<any>, CallbackResult = $Packet<any>> = ((arg0: CallbackArg0) => CallbackResult) | $BundlerInfo$Bundler;
    export type $PacketFlow_ = $PacketFlow | "CLIENTBOUND" | "SERVERBOUND";
}
