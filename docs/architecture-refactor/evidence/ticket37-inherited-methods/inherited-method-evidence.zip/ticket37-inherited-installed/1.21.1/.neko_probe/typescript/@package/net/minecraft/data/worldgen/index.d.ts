import { $Lifecycle } from "java:com/mojang/serialization";
import { $Optional } from "java:java/util";
import { $Holder$Reference, $HolderGetter, $HolderLookup$RegistryLookup, $Registry } from "java:net/minecraft/core";
import { $ResourceKey } from "java:net/minecraft/resources";

declare module "java:net/minecraft/data/worldgen" {
    export interface $BootstrapContext<T> {
        lookup<S>(arg0: $ResourceKey<$Registry<S>>): $HolderGetter<S>;
        register(arg0: $ResourceKey<T>, arg1: T, arg2: $Lifecycle): $Holder$Reference<T>;
        register(arg0: $ResourceKey<T>, arg1: T): $Holder$Reference<T>;
        registryLookup<S>(arg0: $ResourceKey<$Registry<S>>): $Optional<$HolderLookup$RegistryLookup<S>>;
    }

}
