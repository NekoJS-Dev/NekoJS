import { $Class, $Record } from "java:java/lang";
import { $List } from "java:java/util";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/network/syncher" {
    export class $EntityDataAccessor<T> extends $Record {
        constructor(arg0: number, arg1: $EntityDataSerializer<T>);
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): number;
        serializer(): $EntityDataSerializer<T>;
        toString(): string;
    }

    export interface $EntityDataSerializer<T> {
        codec(): $StreamCodec<any, T>;
        copy(arg0: T): T;
        createAccessor(arg0: number): $EntityDataAccessor<T>;
    }
    export const $EntityDataSerializer: {
        forValueType<T>(arg0: $StreamCodec<any, T>): $EntityDataSerializer<T>;
    };

    export interface $SyncedDataHolder {
        onSyncedDataUpdated(arg0: $SynchedEntityData$DataValue<any>[]): void;
        onSyncedDataUpdated(arg0: $EntityDataAccessor<any>): void;
    }

    export class $SynchedEntityData {
        get nonDefaultValues(): $List<$SynchedEntityData$DataValue<any>>;
        getNonDefaultValues(): $List<$SynchedEntityData$DataValue<any>>;
        get dirty(): boolean;
        isDirty(): boolean;
        static defineId<T>(arg0: $Class<$SyncedDataHolder>, arg1: $EntityDataSerializer<T>): $EntityDataAccessor<T>;
        assignValues(arg0: $SynchedEntityData$DataValue<any>[]): void;
        get<T>(arg0: $EntityDataAccessor<T>): T;
        packDirty(): $List<$SynchedEntityData$DataValue<any>>;
        set<T>(arg0: $EntityDataAccessor<T>, arg1: T, arg2: boolean): void;
        set<T>(arg0: $EntityDataAccessor<T>, arg1: T): void;
    }

    export class $SynchedEntityData$DataValue<T> extends $Record {
        constructor(id: number, serializer: $EntityDataSerializer<T>, value: T);
        static create<T>(arg0: $EntityDataAccessor<T>, arg1: T): $SynchedEntityData$DataValue<T>;
        static read(arg0: $RegistryFriendlyByteBuf, arg1: number): $SynchedEntityData$DataValue<any>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): number;
        serializer(): $EntityDataSerializer<T>;
        toString(): string;
        value(): T;
        write(arg0: $RegistryFriendlyByteBuf): void;
    }

}
