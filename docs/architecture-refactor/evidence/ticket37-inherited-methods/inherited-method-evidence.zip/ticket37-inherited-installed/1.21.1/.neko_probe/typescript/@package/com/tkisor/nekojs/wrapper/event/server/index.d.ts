import { $JsonElement, $JsonObject } from "java:com/google/gson";
import { $RecipeCreationContext, $RecipeEntryJS, $RecipeFilter, $RecipeFilter_, $RecipeJsonBuilder, $RecipeJsonValue, $RecipeJsonValue_, $RecipeLifecycleContext } from "java:com/tkisor/nekojs/api/recipe";
import { $RecipeTypeDefinitionRegistry } from "java:com/tkisor/nekojs/api/recipe/definition";
import { $RecipeRegistryProxy } from "java:com/tkisor/nekojs/wrapper";
import { $Value } from "java:graal/graalvm/polyglot";
import { $ProxyObject } from "java:graal/graalvm/polyglot/proxy";
import { $Exception } from "java:java/lang";
import { $List, $Map, $Set } from "java:java/util";
import { $Consumer, $Consumer_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_, $Recipe, $RecipeHolder } from "java:net/minecraft/world/item/crafting";
import { $LootTableLoadEvent } from "java:net/neoforged/neoforge/event";
import { $FluidStack, $FluidStack_ } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient, $FluidIngredient_, $SizedFluidIngredient, $SizedFluidIngredient_ } from "java:net/neoforged/neoforge/fluids/crafting";

import { DocumentedRecipes } from "@side-only/server/events/recipes";

declare module "java:com/tkisor/nekojs/wrapper/event/server" {
    export class $ItemModificationEventJS {
        constructor(plan: $ModificationCandidatePlan);
        get modifiedCount(): number;
        getModifiedCount(): number;
        modify(itemId: string, modifier: $Consumer_<$ItemModificationJS, $ItemModificationJS>): void;
    }

    export class $ItemModificationJS implements $ProxyObject {
        constructor();
        get fireResistant(): boolean;
        getFireResistant(): boolean;
        set fireResistant(value: boolean);
        get maxDamage(): number;
        getMaxDamage(): number;
        set maxDamage(value: number);
        get maxStackSize(): number;
        getMaxStackSize(): number;
        set maxStackSize(value: number);
        get memberKeys(): object;
        getMemberKeys(): object;
        get rarity(): string;
        getRarity(): string;
        set rarity(value: object);
        getMember(name: string): object;
        hasMember(name: string): boolean;
        putMember(name: string, value: $Value): void;
        removeMember(name: string): boolean;
    }

    export class $LootEntryJS {
        constructor(json: $JsonObject);
        static of(item: object): $LootEntryJS;
        group(children?: object[]): $LootEntryJS;
        item(item: object): $LootEntryJS;
        name(id: string): $LootEntryJS;
        toJson(): $JsonObject;
        type(type: string): $LootEntryJS;
        weight(weight: number): $LootEntryJS;
        when(condition: object): $LootEntryJS;
    }

    /**
     * Wrapper for one loot pool inside a loot table.
     * JSON-first: edits are applied directly to the underlying JsonObject.
     */
    export class $LootPoolJS {
        constructor(json: $JsonObject);
        /**
         * Gets the entries of this pool.
         * @returns live LootEntryJS wrappers over the existing 'entries' array; edits write straight through to the JSON
         */
        get entries(): $List<$LootEntryJS>;
        getEntries(): $List<$LootEntryJS>;
        /**
         * Appends one loot entry.
         * @param entry item id, '#tag', ItemStack, entry JS object, or a LootEntryJS.of(...) result
         * @returns this, for chaining
         */
        addEntry(entry: object): $LootPoolJS;
        /**
         * Appends an empty loot entry and lets the callback fill it in.
         * @param consumer callback receiving the new LootEntryJS
         * @returns this, for chaining
         */
        addEntry(consumer: $Consumer_<$LootEntryJS, $LootEntryJS>): $LootPoolJS;
        /**
         * Sets how many times this pool rolls.
         * @param rolls a number, or a [min, max] array for a random roll count
         * @returns this, for chaining
         */
        rolls(rolls: object): $LootPoolJS;
        /**
         * Gets the raw loot pool JSON.
         * @returns the underlying JsonObject; mutations apply directly to this pool
         */
        toJson(): $JsonObject;
        /**
         * Appends a condition that must pass for this pool to roll.
         * @param condition complete condition JSON, e.g. {condition: 'minecraft:random_chance', chance: 0.5}
         * @returns this, for chaining
         */
        when(condition: object): $LootPoolJS;
    }

    export class $LootTableEventJS {
        constructor();
        get ids(): $List<string>;
        getIds(): $List<string>;
        static onLootTableLoad(event: $LootTableLoadEvent): void;
        create(id: string, json: object): void;
        getJson(id: string): $JsonElement;
        modifyBlockLoot(blockId: string, consumer: $Consumer_<$LootTableJS, $LootTableJS>): void;
        modifyBlockLoot(filter: $Predicate_<string, string, boolean>, consumer: $Consumer_<$LootTableJS, $LootTableJS>): void;
        modifyEntityLoot(entityId: string, consumer: $Consumer_<$LootTableJS, $LootTableJS>): void;
        modifyEntityLoot(filter: $Predicate_<string, string, boolean>, consumer: $Consumer_<$LootTableJS, $LootTableJS>): void;
        modify(id: string, consumer: $Consumer_<$LootTableJS, $LootTableJS>): void;
        remove(id: string): void;
        setJson(id: string, json: object): void;
    }

    /**
     * Wrapper for the loot table being modified in a ServerEvents.lootTables.modify callback.
     * JSON-first: edits are applied directly to the underlying JsonObject and take effect when the callback returns.
     */
    export class $LootTableJS {
        constructor(json: $JsonObject);
        /**
         * Gets the pools of this loot table.
         * @returns live LootPoolJS wrappers over the existing 'pools' array; edits write straight through to the JSON
         */
        get pools(): $List<$LootPoolJS>;
        getPools(): $List<$LootPoolJS>;
        /**
         * Gets the loot table type id.
         * @returns the type id like 'minecraft:chest', or null when the table has no type set
         */
        get type(): string;
        getType(): string;
        set type(value: string);
        /**
         * Appends a loot pool from raw JSON: a JS object, a JSON string, or a prebuilt pool object.
         * @param pool complete pool JSON as a JS object or JSON string
         * @returns this, for chaining
         */
        addPool(pool: object): $LootTableJS;
        /**
         * Appends an empty loot pool and lets the callback fill it in.
         * @param consumer callback receiving the new LootPoolJS
         * @returns this, for chaining
         */
        addPool(consumer: $Consumer_<$LootPoolJS, $LootPoolJS>): $LootTableJS;
        /**
         * Gets the raw loot table JSON.
         * @returns the underlying JsonObject; mutations apply directly to this table
         */
        toJson(): $JsonObject;
    }

    export class $RecipeEventJS implements $RecipeLifecycleContext {
        constructor(originalJsons: { [key: $ResourceLocation_]: $JsonElement }, registries: $HolderLookup$Provider);
        constructor(originalJsons: { [key: $ResourceLocation_]: $JsonElement }, registries: $HolderLookup$Provider, recipeTypeDefinitions: $RecipeTypeDefinitionRegistry);
        get finalJsons(): $Map<$ResourceLocation, $JsonElement>;
        getFinalJsons(): $Map<$ResourceLocation, $JsonElement>;
        get recipeTypeDefinitions(): $RecipeTypeDefinitionRegistry;
        getRecipeTypeDefinitions(): $RecipeTypeDefinitionRegistry;
        get recipes(): DocumentedRecipes;
        static getIngredients(recipe: $Recipe<any>): $List<$Ingredient>;
        static getRecipeOutputId(recipe: $Recipe<any>, registries: $HolderLookup$Provider): string;
        static ingredientMatches(ingredient: $Ingredient_, tagKey: $TagKey_, itemID: $ResourceLocation_, registries: $HolderLookup$Provider): boolean;
        static recipeGroup(recipe: $Recipe<any>): string;
        static recipeHolderId(holder: $RecipeHolder<any>): $ResourceLocation;
        all(): $List<$RecipeEntryJS>;
        blasting(result: $ItemStack_, ingredient: $Ingredient_, xp: number, cookTime: number): $RecipeJsonBuilder;
        blasting(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        builder(type: string): $RecipeJsonBuilder;
        campfireCooking(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        count(filter: $RecipeFilter_): number;
        count(): number;
        custom(recipeJson: $JsonObject): $RecipeJsonBuilder;
        custom(value: $RecipeJsonValue_): $RecipeJsonBuilder;
        custom(type: string, value: $RecipeJsonValue_): $RecipeJsonBuilder;
        describeRecipe(id: $ResourceLocation_, json: $JsonObject): string;
        dump(filter: $RecipeFilter_): string;
        dump(): string;
        exists(filter: $RecipeFilter_): boolean;
        exists(id: string): boolean;
        find(filter: $RecipeFilter_): $List<$RecipeEntryJS>;
        forEach(filter: $RecipeFilter_, callback: $Consumer_<$RecipeEntryJS, $RecipeEntryJS>): void;
        forEach(callback: $Consumer_<$RecipeEntryJS, $RecipeEntryJS>): void;
        formatRecipeError(prefix: string, id: $ResourceLocation_, json: $JsonObject, e: $Exception): string;
        generateRecipeId(prefix: string): $ResourceLocation;
        getJson(id: string): string;
        getRecipeContext(id: $ResourceLocation_): $RecipeCreationContext;
        get(id: string): $RecipeEntryJS;
        ids(): $Set<string>;
        modify(filter: $RecipeFilter_, callback: $Consumer_<$RecipeEntryJS, $RecipeEntryJS>): void;
        print(filter: $RecipeFilter_): void;
        print(): void;
        removeById(id: string): void;
        removeRecipeContext(id: $ResourceLocation_): void;
        remove(filter: $RecipeFilter_): void;
        replaceInput(filter: $RecipeFilter_, match: $Ingredient_, replacement: $Ingredient_): void;
        replaceOutput(filter: $RecipeFilter_, match: $Ingredient_, replacement: $ItemStack_): void;
        serializeFluidIngredient(ingredient: $FluidIngredient_): $JsonElement;
        serializeFluidStack(stack: $FluidStack_): $JsonElement;
        serializeIngredient(ingredient: $Ingredient_): $JsonElement;
        serializeResult(stack: $ItemStack_): $JsonElement;
        serializeSizedFluidIngredient(ingredient: $SizedFluidIngredient_): $JsonElement;
        setJson(id: string, json: string): void;
        setRecipeContext(id: $ResourceLocation_, context: $RecipeCreationContext): void;
        shaped(result: $ItemStack_, pattern: string[], keys: { [key: string]: $Ingredient_ }): $RecipeJsonBuilder;
        shapeless(result: $ItemStack_, ingredients: $Ingredient_[]): $RecipeJsonBuilder;
        smelting(result: $ItemStack_, ingredient: $Ingredient_, xp: number, cookTime: number): $RecipeJsonBuilder;
        smelting(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        smoking(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        validateRecipe(id: $ResourceLocation_, json: $JsonObject): void;
    }

    export class $TagEventJS {
        constructor(registryId: $ResourceLocation_, sourceMap: { [key: $ResourceLocation_]: $TagLoader$EntryWithSource[] });
        get registry(): $ResourceLocation;
        getRegistry(): $ResourceLocation;
        add(tag: string, entry: string): void;
        add(tag: $ResourceLocation_, entry: $ResourceLocation_): void;
        apply(): void;
        getEntries(tag: string): $List<string>;
        removeAll(tag: string): void;
        removeAll(tag: $ResourceLocation_): void;
        remove(tag: string, entry: string): void;
        remove(tag: $ResourceLocation_, entry: $ResourceLocation_): void;
        replaceAll(tag: string, entries?: string[]): void;
        replaceAll(tag: $ResourceLocation_, entries?: string[]): void;
    }

}
