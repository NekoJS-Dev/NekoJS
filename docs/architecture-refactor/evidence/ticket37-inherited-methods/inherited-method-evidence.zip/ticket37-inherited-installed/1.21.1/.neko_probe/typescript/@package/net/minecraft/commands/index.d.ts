import { $CommandDispatcher, $Message, $Message_, $ParseResults, $ResultConsumer, $ResultConsumer_, $StringReader } from "java:com/mojang/brigadier";
import { $ArgumentType, $ArgumentType_ } from "java:com/mojang/brigadier/arguments";
import { $LiteralArgumentBuilder, $RequiredArgumentBuilder } from "java:com/mojang/brigadier/builder";
import { $CommandContext } from "java:com/mojang/brigadier/context";
import { $CommandExceptionType, $CommandSyntaxException, $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Suggestions, $SuggestionsBuilder } from "java:com/mojang/brigadier/suggestion";
import { $Codec } from "java:com/mojang/serialization";
import { $Iterable } from "java:java/lang";
import { $Collection, $Optional, $Set } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $BinaryOperator, $BinaryOperator_, $Consumer, $Consumer_, $Function, $Function_, $Predicate, $Predicate_, $Supplier, $Supplier_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $AdvancementHolder } from "java:net/minecraft/advancements";
import { $EntityAnchorArgument$Anchor, $EntityAnchorArgument$Anchor_ } from "java:net/minecraft/commands/arguments";
import { $ExecutionContext, $TraceCallbacks } from "java:net/minecraft/commands/execution";
import { $CommandFunction } from "java:net/minecraft/commands/functions";
import { $HolderLookup$Provider, $Registry, $RegistryAccess } from "java:net/minecraft/core";
import { $ChatType$Bound, $Component, $Component_, $OutgoingChatMessage, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $MinecraftServer, $ServerFunctionManager } from "java:net/minecraft/server";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $TaskChainer, $TaskChainer_ } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $RecipeManager } from "java:net/minecraft/world/item/crafting";
import { $Level } from "java:net/minecraft/world/level";
import { $Vec2, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $Scoreboard } from "java:net/minecraft/world/scores";
import { $ICommandSourceStackExtension } from "java:net/neoforged/neoforge/common/extensions";

export * as arguments from "java:net/minecraft/commands/arguments";
export * as execution from "java:net/minecraft/commands/execution";
export * as functions from "java:net/minecraft/commands/functions";

declare module "java:net/minecraft/commands" {
    export class $CacheableFunction {
        constructor(arg0: $ResourceLocation_);
        static CODEC: $Codec<$CacheableFunction>;
        get id(): $ResourceLocation;
        getId(): $ResourceLocation;
        equals(arg0: object): boolean;
        get(arg0: $ServerFunctionManager): $Optional<$CommandFunction<$CommandSourceStack>>;
    }

    export interface $CommandBuildContext extends $HolderLookup$Provider {
    }
    export const $CommandBuildContext: {
        simple(arg0: $HolderLookup$Provider, arg1: $FeatureFlagSet): $CommandBuildContext;
    };

    export interface $CommandResultCallback {
        onFailure(): void;
        onResult(arg0: boolean, arg1: number): void;
        onSuccess(arg0: number): void;
    }
    export const $CommandResultCallback: {
        chain(arg0: $CommandResultCallback_<boolean, number>, arg1: $CommandResultCallback_<boolean, number>): $CommandResultCallback;
        readonly EMPTY: $CommandResultCallback;
    };

    export interface $CommandSigningContext {
        getArgument(arg0: string): $PlayerChatMessage;
    }
    export const $CommandSigningContext: {
        readonly ANONYMOUS: $CommandSigningContext;
    };

    export interface $CommandSource {
        acceptsFailure(): boolean;
        acceptsSuccess(): boolean;
        alwaysAccepts(): boolean;
        sendSystemMessage(arg0: $Component_): void;
        shouldInformAdmins(): boolean;
    }
    export const $CommandSource: {
        readonly NULL: $CommandSource;
    };

    export class $CommandSourceStack implements $ExecutionCommandSource<$CommandSourceStack>, $SharedSuggestionProvider, $ICommandSourceStackExtension {
        constructor(arg0: $CommandSource, arg1: $Vec3_, arg2: $Vec2, arg3: $ServerLevel, arg4: number, arg5: string, arg6: $Component_, arg7: $MinecraftServer, arg8: $Entity);
        static ERROR_NOT_ENTITY: $SimpleCommandExceptionType;
        static ERROR_NOT_PLAYER: $SimpleCommandExceptionType;
        source: $CommandSource;
        get absoluteCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        getAbsoluteCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        get allTeams(): $Collection<string>;
        getAllTeams(): $Collection<string>;
        get anchor(): $EntityAnchorArgument$Anchor;
        getAnchor(): $EntityAnchorArgument$Anchor;
        get availableSounds(): $Stream<$ResourceLocation>;
        getAvailableSounds(): $Stream<$ResourceLocation>;
        get chatMessageChainer(): $TaskChainer;
        getChatMessageChainer(): $TaskChainer;
        get customTabSugggestions(): $Collection<string>;
        getCustomTabSugggestions(): $Collection<string>;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get entityOrException(): $Entity;
        getEntityOrException(): $Entity;
        get entity(): $Entity;
        getEntity(): $Entity;
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
        get onlinePlayerNames(): $Collection<string>;
        getOnlinePlayerNames(): $Collection<string>;
        get playerOrException(): $ServerPlayer;
        getPlayerOrException(): $ServerPlayer;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get position(): $Vec3;
        getPosition(): $Vec3;
        get recipeManager(): $RecipeManager;
        getRecipeManager(): $RecipeManager;
        get recipeNames(): $Stream<$ResourceLocation>;
        getRecipeNames(): $Stream<$ResourceLocation>;
        get relevantCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        getRelevantCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        get rotation(): $Vec2;
        getRotation(): $Vec2;
        get scoreboard(): $Scoreboard;
        getScoreboard(): $Scoreboard;
        get selectedEntities(): $Collection<string>;
        getSelectedEntities(): $Collection<string>;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get signingContext(): $CommandSigningContext;
        getSigningContext(): $CommandSigningContext;
        get textName(): string;
        getTextName(): string;
        get unsidedLevel(): $Level;
        getUnsidedLevel(): $Level;
        get silent(): boolean;
        isSilent(): boolean;
        callback(): $CommandResultCallback;
        clearCallbacks(): $CommandSourceStack;
        customSuggestion(arg0: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        enabledFeatures(): $FeatureFlagSet;
        facing(arg0: $Entity, arg1: $EntityAnchorArgument$Anchor_): $CommandSourceStack;
        facing(arg0: $Vec3_): $CommandSourceStack;
        getAdvancement(arg0: $ResourceLocation_): $AdvancementHolder;
        handleError(arg0: $CommandExceptionType, arg1: $Message_<string>, arg2: boolean, arg3: $TraceCallbacks): void;
        handleError(arg0: $CommandSyntaxException, arg1: boolean, arg2: $TraceCallbacks): void;
        hasPermission(arg0: number): boolean;
        levels(): $Set<$ResourceKey<$Level>>;
        registryAccess(): $RegistryAccess;
        sendChatMessage(arg0: $OutgoingChatMessage, arg1: boolean, arg2: $ChatType$Bound): void;
        sendFailure(arg0: $Component_): void;
        sendSuccess(arg0: $Supplier_<$Component, $Component_>, arg1: boolean): void;
        sendSystemMessage(arg0: $Component_): void;
        shouldFilterMessageTo(arg0: $ServerPlayer): boolean;
        suggestRegistryElements(arg0: $Registry<any>, arg1: $SharedSuggestionProvider$ElementSuggestionType_, arg2: $SuggestionsBuilder): void;
        suggestRegistryElements(arg0: $ResourceKey<$Registry<any>>, arg1: $SharedSuggestionProvider$ElementSuggestionType_, arg2: $SuggestionsBuilder, arg3: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        withAnchor(arg0: $EntityAnchorArgument$Anchor_): $CommandSourceStack;
        withCallback(arg0: $CommandResultCallback_<boolean, number>, arg1: $BinaryOperator_<$CommandResultCallback, $CommandResultCallback, $CommandResultCallback, $CommandResultCallback_<boolean, number>>): $CommandSourceStack;
        withCallback(arg0: $CommandResultCallback_<boolean, number>): $CommandSourceStack;
        withEntity(arg0: $Entity): $CommandSourceStack;
        withLevel(arg0: $ServerLevel): $CommandSourceStack;
        withMaximumPermission(arg0: number): $CommandSourceStack;
        withPermission(arg0: number): $CommandSourceStack;
        withPosition(arg0: $Vec3_): $CommandSourceStack;
        withRotation(arg0: $Vec2): $CommandSourceStack;
        withSigningContext(arg0: $CommandSigningContext_<string, $PlayerChatMessage>, arg1: $TaskChainer_<$CompletableFuture<any>, $Consumer<any>>): $CommandSourceStack;
        withSource(arg0: $CommandSource): $CommandSourceStack;
        withSuppressedOutput(): $CommandSourceStack;
    }

    export class $Commands {
        constructor(arg0: $Commands$CommandSelection_, arg1: $CommandBuildContext);
        static LEVEL_ADMINS: number;
        static LEVEL_ALL: number;
        static LEVEL_GAMEMASTERS: number;
        static LEVEL_MODERATORS: number;
        static LEVEL_OWNERS: number;
        get dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        getDispatcher(): $CommandDispatcher<$CommandSourceStack>;
        static argument<T>(arg0: string, arg1: $ArgumentType_<T, $StringReader, T>): $RequiredArgumentBuilder<$CommandSourceStack, T>;
        static createValidationContext(arg0: $HolderLookup$Provider): $CommandBuildContext;
        static createValidator(arg0: $Commands$ParseFunction_<$StringReader>): $Predicate<string>;
        static executeCommandInContext(arg0: $CommandSourceStack, arg1: $Consumer_<$ExecutionContext<$CommandSourceStack>, $ExecutionContext<$CommandSourceStack>>): void;
        static getParseException<S>(arg0: $ParseResults<S>): $CommandSyntaxException;
        static literal(arg0: string): $LiteralArgumentBuilder<$CommandSourceStack>;
        static mapSource<S>(arg0: $ParseResults<S>, arg1: $UnaryOperator_<S, S, S>): $ParseResults<S>;
        static validateParseResults<S>(arg0: $ParseResults<S>): void;
        static validate(): void;
        performCommand(arg0: $ParseResults<$CommandSourceStack>, arg1: string): void;
        performPrefixedCommand(arg0: $CommandSourceStack, arg1: string): void;
        sendCommands(arg0: $ServerPlayer): void;
    }

    export class $Commands$CommandSelection {
        static ALL: $Commands$CommandSelection;
        static DEDICATED: $Commands$CommandSelection;
        static INTEGRATED: $Commands$CommandSelection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Commands$CommandSelection[];
        static valueOf(name: string): $Commands$CommandSelection;
    }

    export interface $Commands$ParseFunction {
        parse(arg0: $StringReader): void;
    }

    export interface $ExecutionCommandSource<T extends $ExecutionCommandSource<T>> {
        callback(): $CommandResultCallback;
        clearCallbacks(): T;
        dispatcher(): $CommandDispatcher<T>;
        handleError(arg0: $CommandExceptionType, arg1: $Message_<string>, arg2: boolean, arg3: $TraceCallbacks): void;
        handleError(arg0: $CommandSyntaxException, arg1: boolean, arg2: $TraceCallbacks): void;
        hasPermission(arg0: number): boolean;
        isSilent(): boolean;
        withCallback(arg0: $CommandResultCallback_<boolean, number>): T;
    }
    export const $ExecutionCommandSource: {
        resultConsumer<T>(): $ResultConsumer<T>;
    };

    export interface $SharedSuggestionProvider {
        customSuggestion(arg0: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        enabledFeatures(): $FeatureFlagSet;
        getAbsoluteCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        getAllTeams(): $Collection<string>;
        getAvailableSounds(): $Stream<$ResourceLocation>;
        getCustomTabSugggestions(): $Collection<string>;
        getOnlinePlayerNames(): $Collection<string>;
        getRecipeNames(): $Stream<$ResourceLocation>;
        getRelevantCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        getSelectedEntities(): $Collection<string>;
        hasPermission(arg0: number): boolean;
        levels(): $Set<$ResourceKey<$Level>>;
        registryAccess(): $RegistryAccess;
        suggestRegistryElements(arg0: $Registry<any>, arg1: $SharedSuggestionProvider$ElementSuggestionType_, arg2: $SuggestionsBuilder): void;
        suggestRegistryElements(arg0: $ResourceKey<$Registry<any>>, arg1: $SharedSuggestionProvider$ElementSuggestionType_, arg2: $SuggestionsBuilder, arg3: $CommandContext<any>): $CompletableFuture<$Suggestions>;
    }
    export const $SharedSuggestionProvider: {
        filterResources<T>(arg0: $Iterable<T>, arg1: string, arg2: string, arg3: $Function_<T, $ResourceLocation, T, $ResourceLocation_>, arg4: $Consumer_<T, T>): void;
        filterResources<T>(arg0: $Iterable<T>, arg1: string, arg2: $Function_<T, $ResourceLocation, T, $ResourceLocation_>, arg3: $Consumer_<T, T>): void;
        matchesSubStr(arg0: string, arg1: string): boolean;
        suggest2DCoordinates(arg0: string, arg1: $SharedSuggestionProvider$TextCoordinates[], arg2: $SuggestionsBuilder, arg3: $Predicate_<string, string, boolean>): $CompletableFuture<$Suggestions>;
        suggestCoordinates(arg0: string, arg1: $SharedSuggestionProvider$TextCoordinates[], arg2: $SuggestionsBuilder, arg3: $Predicate_<string, string, boolean>): $CompletableFuture<$Suggestions>;
        suggestResource<T>(arg0: $Iterable<T>, arg1: $SuggestionsBuilder, arg2: $Function_<T, $ResourceLocation, T, $ResourceLocation_>, arg3: $Function_<T, $Message, T, $Message_<string>>): $CompletableFuture<$Suggestions>;
        suggestResource(arg0: $Iterable<$ResourceLocation_>, arg1: $SuggestionsBuilder, arg2: string): $CompletableFuture<$Suggestions>;
        suggestResource(arg0: $Iterable<$ResourceLocation_>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggestResource<T>(arg0: $Stream<T>, arg1: $SuggestionsBuilder, arg2: $Function_<T, $ResourceLocation, T, $ResourceLocation_>, arg3: $Function_<T, $Message, T, $Message_<string>>): $CompletableFuture<$Suggestions>;
        suggestResource(arg0: $Stream<$ResourceLocation_>, arg1: $SuggestionsBuilder, arg2: string): $CompletableFuture<$Suggestions>;
        suggestResource(arg0: $Stream<$ResourceLocation_>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest<T>(arg0: $Iterable<T>, arg1: $SuggestionsBuilder, arg2: $Function_<T, string, T, string>, arg3: $Function_<T, $Message, T, $Message_<string>>): $CompletableFuture<$Suggestions>;
        suggest(arg0: $Iterable<string>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest(arg0: string[], arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest(arg0: $Stream<string>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
    };

    export class $SharedSuggestionProvider$ElementSuggestionType {
        static ALL: $SharedSuggestionProvider$ElementSuggestionType;
        static ELEMENTS: $SharedSuggestionProvider$ElementSuggestionType;
        static TAGS: $SharedSuggestionProvider$ElementSuggestionType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SharedSuggestionProvider$ElementSuggestionType[];
        static valueOf(name: string): $SharedSuggestionProvider$ElementSuggestionType;
    }

    export class $SharedSuggestionProvider$TextCoordinates {
        constructor(arg0: string, arg1: string, arg2: string);
        static DEFAULT_GLOBAL: $SharedSuggestionProvider$TextCoordinates;
        static DEFAULT_LOCAL: $SharedSuggestionProvider$TextCoordinates;
        x: string;
        y: string;
        z: string;
    }

    export type $CommandResultCallback_<CallbackArg0 = boolean, CallbackArg1 = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | $CommandResultCallback;
    export type $CommandSigningContext_<CallbackArg0 = string, CallbackResult = $PlayerChatMessage> = ((arg0: CallbackArg0) => CallbackResult) | $CommandSigningContext;
    export type $Commands$CommandSelection_ = $Commands$CommandSelection | "ALL" | "DEDICATED" | "INTEGRATED";
    export type $Commands$ParseFunction_<CallbackArg0 = $StringReader> = ((arg0: CallbackArg0) => void) | $Commands$ParseFunction;
    export type $SharedSuggestionProvider$ElementSuggestionType_ = $SharedSuggestionProvider$ElementSuggestionType | "ALL" | "ELEMENTS" | "TAGS";
}
