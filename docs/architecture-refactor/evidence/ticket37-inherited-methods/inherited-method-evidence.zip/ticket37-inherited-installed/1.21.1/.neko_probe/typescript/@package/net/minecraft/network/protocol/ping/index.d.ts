import { $ByteBuf } from "java:io/netty/buffer";
import { $Record } from "java:java/lang";
import { $FriendlyByteBuf, $PacketListener } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";

declare module "java:net/minecraft/network/protocol/ping" {
    export interface $ClientPongPacketListener extends $PacketListener {
        handlePongResponse(arg0: $ClientboundPongResponsePacket): void;
    }

    export class $ClientboundPongResponsePacket extends $Record implements $Packet<$ClientPongPacketListener> {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPongResponsePacket>;
        get skippable(): boolean;
        isSkippable(): boolean;
        get terminal(): boolean;
        isTerminal(): boolean;
        equals(arg0: object): boolean;
        handle(arg0: $ClientPongPacketListener): void;
        hashCode(): number;
        time(): number;
        toString(): string;
        type(): $PacketType<$ClientboundPongResponsePacket>;
    }

    export interface $ServerPingPacketListener extends $PacketListener {
        handlePingRequest(arg0: $ServerboundPingRequestPacket): void;
    }

    export class $ServerboundPingRequestPacket implements $Packet<$ServerPingPacketListener> {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundPingRequestPacket>;
        get time(): number;
        getTime(): number;
        get skippable(): boolean;
        isSkippable(): boolean;
        get terminal(): boolean;
        isTerminal(): boolean;
        handle(arg0: $ServerPingPacketListener): void;
        type(): $PacketType<$ServerboundPingRequestPacket>;
    }

}
