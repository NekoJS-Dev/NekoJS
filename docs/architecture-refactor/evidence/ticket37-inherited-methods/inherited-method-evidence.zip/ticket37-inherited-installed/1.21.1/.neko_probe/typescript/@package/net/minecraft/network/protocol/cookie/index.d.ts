import { $Record } from "java:java/lang";
import { $ClientboundPacketListener, $FriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ServerPacketListener } from "java:net/minecraft/network/protocol/game";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/network/protocol/cookie" {
    export interface $ClientCookiePacketListener extends $ClientboundPacketListener {
        handleRequestCookie(arg0: $ClientboundCookieRequestPacket): void;
    }

    export class $ClientboundCookieRequestPacket extends $Record implements $Packet<$ClientCookiePacketListener> {
        constructor(arg0: $ResourceLocation_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundCookieRequestPacket>;
        get skippable(): boolean;
        isSkippable(): boolean;
        get terminal(): boolean;
        isTerminal(): boolean;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCookiePacketListener): void;
        hashCode(): number;
        key(): $ResourceLocation;
        toString(): string;
        type(): $PacketType<$ClientboundCookieRequestPacket>;
    }

    export interface $ServerCookiePacketListener extends $ServerPacketListener {
        handleCookieResponse(arg0: $ServerboundCookieResponsePacket): void;
    }

    export class $ServerboundCookieResponsePacket extends $Record implements $Packet<$ServerCookiePacketListener> {
        constructor(arg0: $ResourceLocation_, arg1: number[]);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCookieResponsePacket>;
        get skippable(): boolean;
        isSkippable(): boolean;
        get terminal(): boolean;
        isTerminal(): boolean;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCookiePacketListener): void;
        hashCode(): number;
        key(): $ResourceLocation;
        payload(): number[];
        toString(): string;
        type(): $PacketType<$ServerboundCookieResponsePacket>;
    }

}
