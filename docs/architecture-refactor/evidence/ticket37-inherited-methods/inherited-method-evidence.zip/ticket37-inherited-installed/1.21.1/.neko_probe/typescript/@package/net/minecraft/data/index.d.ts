export * as worldgen from "java:net/minecraft/data/worldgen";

