import { $ApiTypeRef } from "java:com/tkisor/nekojs/api/surface";
import { $TypeDecl } from "java:com/tkisor/nekojs/probe/ir";
import { $Record } from "java:java/lang";
import { $List, $Map, $Set } from "java:java/util";

declare module "java:com/tkisor/nekojs/probe/events" {
    export class $ClassEditor {
        addMethod(name: string, returnType: object, paramSpecs?: object[]): $ClassEditor;
        addParam(name: string, paramName: string, type: object): $ClassEditor;
        addStaticMethod(name: string, returnType: object, paramSpecs?: object[]): $ClassEditor;
        changeFieldType(name: string, type: object): $ClassEditor;
        changeParamType(name: string, index: number, type: object): $ClassEditor;
        changeParamType(name: string, paramName: string, type: object): $ClassEditor;
        changeReturnType(name: string, type: object): $ClassEditor;
        changeSuper(type: object): $ClassEditor;
        hasField(name: string): boolean;
        hasMethod(name: string): boolean;
        hideField(name: string): $ClassEditor;
        hideMethod(name: string): $ClassEditor;
        hide(): $ClassEditor;
        markOptional(name: string, paramName: string): $ClassEditor;
        removeParam(name: string, index: number): $ClassEditor;
        renameClass(newName: string): $ClassEditor;
        renameField(name: string, newName: string): $ClassEditor;
        renameMethod(name: string, newName: string): $ClassEditor;
        renameParam(name: string, paramName: string, newName: string): $ClassEditor;
        setFieldDoc(name: string, doc: string): $ClassEditor;
        setMethodDoc(name: string, doc: string): $ClassEditor;
    }

    export class $GlobalDecl extends $Record {
        constructor(name: string, type: $ApiTypeRef);
        equals(o: object): boolean;
        hashCode(): number;
        name(): string;
        toString(): string;
        type(): $ApiTypeRef;
    }

    export class $ProbeAddGlobalEventJS {
        constructor();
        add(name: string, typeDesc: object): void;
        globals(): $List<$GlobalDecl>;
    }

    export class $ProbeAssignTypeEventJS {
        constructor();
        static applyTo(d: $TypeDecl, map: { [key: string]: $ApiTypeRef }): number;
        assignments(): $Map<string, $ApiTypeRef>;
        assign(javaFqn: string, typeDesc: object): void;
        has(javaFqn: string): boolean;
    }

    export class $ProbeModifyTypeEventJS {
        constructor(decls: { [key: string]: $TypeDecl });
        static collectEditedSymbolFqns(d: $TypeDecl, classPackage: string): $Set<string>;
        array(element: object): $ApiTypeRef;
        forClass(fqn: string): $ClassEditor;
        hasClass(fqn: string): boolean;
        type(desc: object): $ApiTypeRef;
        union(a: object, b: object, rest?: object[]): $ApiTypeRef;
    }

    export class $ProbeSnippetEventJS {
        constructor();
        add(name: string, prefix: string, body: string, description: string): void;
        add(name: string, prefix: string, body: string): void;
        snippets(): $List<$Snippet>;
    }

    export class $Snippet extends $Record {
        constructor(name: string, prefix: string, body: string, description: string);
        body(): string;
        description(): string;
        equals(o: object): boolean;
        hashCode(): number;
        name(): string;
        prefix(): string;
        toString(): string;
    }

}
