import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/network/protocol/login/custom" {
    export interface $CustomQueryPayload {
        id(): $ResourceLocation;
        write(arg0: $FriendlyByteBuf): void;
    }

}
