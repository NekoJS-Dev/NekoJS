import { $CommandDispatcher, $StringReader } from "java:com/mojang/brigadier";
import { $CharSequence } from "java:java/lang";
import { $List } from "java:java/util";
import { $UnboundEntryAction, $UnboundEntryAction_ } from "java:net/minecraft/commands/execution";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/commands/functions" {
    export interface $CommandFunction<T> {
        id(): $ResourceLocation;
        instantiate(arg0: $CompoundTag_, arg1: $CommandDispatcher<T>): $InstantiatedFunction<T>;
    }
    export const $CommandFunction: {
        checkCommandLineLength(arg0: $CharSequence): void;
        fromLines<T>(arg0: $ResourceLocation_, arg1: $CommandDispatcher<T>, arg2: T, arg3: string[]): $CommandFunction<T>;
        parseCommand<T>(arg0: $CommandDispatcher<T>, arg1: T, arg2: $StringReader): $UnboundEntryAction<T>;
    };

    export interface $InstantiatedFunction<T> {
        entries(): $List<$UnboundEntryAction<T>>;
        id(): $ResourceLocation;
    }

}
