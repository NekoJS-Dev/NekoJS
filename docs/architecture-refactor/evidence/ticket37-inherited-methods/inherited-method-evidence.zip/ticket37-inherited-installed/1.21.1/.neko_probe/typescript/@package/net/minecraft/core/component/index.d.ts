import { $Codec, $DataResult, $DynamicOps } from "java:com/mojang/serialization";
import { $Iterable, $Record } from "java:java/lang";
import { $Iterator, $Map, $Map$Entry, $Optional, $Set, $Spliterator } from "java:java/util";
import { $Consumer, $Consumer_, $Predicate, $Predicate_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $IDataComponentHolderExtension, $IDataComponentMapBuilderExtensions } from "java:net/neoforged/neoforge/common/extensions";

declare module "java:net/minecraft/core/component" {
    export interface $DataComponentHolder extends $IDataComponentHolderExtension {
        getComponents(): $DataComponentMap;
        getOrDefault<T>(arg0: $DataComponentType<T>, arg1: T): T;
        get<T>(arg0: $DataComponentType<T>): T;
        has(arg0: $DataComponentType<any>): boolean;
    }

    export interface $DataComponentMap extends $Iterable<$TypedDataComponent<any>> {
        filter(arg0: $Predicate_<$DataComponentType<any>, $DataComponentType<any>, boolean>): $DataComponentMap;
        getOrDefault<T>(arg0: $DataComponentType<T>, arg1: T): T;
        getTyped<T>(arg0: $DataComponentType<T>): $TypedDataComponent<T>;
        get<T>(arg0: $DataComponentType<T>): T;
        has(arg0: $DataComponentType<any>): boolean;
        isEmpty(): boolean;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        size(): number;
        stream(): $Stream<$TypedDataComponent<any>>;
    }
    export const $DataComponentMap: {
        builder(): $DataComponentMap$Builder;
        composite(arg0: $DataComponentMap, arg1: $DataComponentMap): $DataComponentMap;
        makeCodecFromMap(arg0: $Codec<{ [key: $DataComponentType<any>]: object }>): $Codec<$DataComponentMap>;
        makeCodec(arg0: $Codec<$DataComponentType<any>>): $Codec<$DataComponentMap>;
        readonly CODEC: $Codec<$DataComponentMap>;
        readonly EMPTY: $DataComponentMap;
    };

    export class $DataComponentMap$Builder implements $IDataComponentMapBuilderExtensions {
        addAll(arg0: $DataComponentMap): $DataComponentMap$Builder;
        build(): $DataComponentMap;
        set<T>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>, arg1: T): $DataComponentMap$Builder;
        set<T>(arg0: $DataComponentType<T>, arg1: T): $DataComponentMap$Builder;
    }

    export class $DataComponentPatch {
        static CODEC: $Codec<$DataComponentPatch>;
        static EMPTY: $DataComponentPatch;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentPatch>;
        get empty(): boolean;
        isEmpty(): boolean;
        static builder(): $DataComponentPatch$Builder;
        entrySet(): $Set<$Map$Entry<$DataComponentType<any>, $Optional<any>>>;
        equals(arg0: object): boolean;
        forget(arg0: $Predicate_<$DataComponentType<any>, $DataComponentType<any>, boolean>): $DataComponentPatch;
        get<T>(arg0: $DataComponentType<T>): $Optional<T>;
        hashCode(): number;
        size(): number;
        split(): $DataComponentPatch$SplitResult;
        toString(): string;
    }

    export class $DataComponentPatch$Builder {
        build(): $DataComponentPatch;
        remove<T>(arg0: $DataComponentType<T>): $DataComponentPatch$Builder;
        set<T>(arg0: $DataComponentType<T>, arg1: T): $DataComponentPatch$Builder;
        set<T>(arg0: $TypedDataComponent<T>): $DataComponentPatch$Builder;
    }

    export class $DataComponentPatch$SplitResult extends $Record {
        constructor(added: $DataComponentMap, removed: $DataComponentType<any>[]);
        static EMPTY: $DataComponentPatch$SplitResult;
        added(): $DataComponentMap;
        equals(arg0: object): boolean;
        hashCode(): number;
        removed(): $Set<$DataComponentType<any>>;
        toString(): string;
    }

    export class $DataComponentPredicate implements $Predicate<$DataComponentMap> {
        static CODEC: $Codec<$DataComponentPredicate>;
        static EMPTY: $DataComponentPredicate;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentPredicate>;
        static allOf(arg0: $DataComponentMap): $DataComponentPredicate;
        static builder(): $DataComponentPredicate$Builder;
        alwaysMatches(): boolean;
        and(arg0: $Predicate_<$DataComponentMap, $DataComponentMap, boolean>): $Predicate<$DataComponentMap>;
        asPatch(): $DataComponentPatch;
        equals(arg0: object): boolean;
        hashCode(): number;
        negate(): $Predicate<$DataComponentMap>;
        or(arg0: $Predicate_<$DataComponentMap, $DataComponentMap, boolean>): $Predicate<$DataComponentMap>;
        test(arg0: $DataComponentHolder_<$DataComponentMap>): boolean;
        test(arg0: $DataComponentMap): boolean;
        toString(): string;
    }

    export class $DataComponentPredicate$Builder {
        build(): $DataComponentPredicate;
        expect<T>(arg0: $DataComponentType<any>, arg1: T): $DataComponentPredicate$Builder;
    }

    export interface $DataComponentType<T> {
        codecOrThrow(): $Codec<T>;
        codec(): $Codec<T>;
        isTransient(): boolean;
        streamCodec(): $StreamCodec<any, T>;
    }
    export const $DataComponentType: {
        builder<T>(): $DataComponentType$Builder<T>;
        readonly CODEC: $Codec<$DataComponentType<any>>;
        readonly PERSISTENT_CODEC: $Codec<$DataComponentType<any>>;
        readonly STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentType<any>>;
        readonly VALUE_MAP_CODEC: $Codec<$Map<$DataComponentType<any>, object>>;
    };

    export class $DataComponentType$Builder<T> {
        constructor();
        build(): $DataComponentType<T>;
        cacheEncoding(): $DataComponentType$Builder<T>;
        networkSynchronized(arg0: $StreamCodec<any, T>): $DataComponentType$Builder<T>;
        persistent(arg0: $Codec<T>): $DataComponentType$Builder<T>;
    }

    export class $PatchedDataComponentMap implements $DataComponentMap {
        constructor(arg0: $DataComponentMap);
        get empty(): boolean;
        isEmpty(): boolean;
        get patchEmpty(): boolean;
        isPatchEmpty(): boolean;
        static fromPatch(arg0: $DataComponentMap, arg1: $DataComponentPatch): $PatchedDataComponentMap;
        applyPatch(arg0: $DataComponentPatch): void;
        asPatch(): $DataComponentPatch;
        copy(): $PatchedDataComponentMap;
        equals(arg0: object): boolean;
        filter(arg0: $Predicate_<$DataComponentType<any>, $DataComponentType<any>, boolean>): $DataComponentMap;
        forEach(arg0: $Consumer_<$TypedDataComponent<any>, $TypedDataComponent<any>>): void;
        getOrDefault<T>(arg0: $DataComponentType<T>, arg1: T): T;
        getTyped<T>(arg0: $DataComponentType<T>): $TypedDataComponent<T>;
        get<T>(arg0: $DataComponentType<T>): T;
        hashCode(): number;
        has(arg0: $DataComponentType<any>): boolean;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        remove<T>(arg0: $DataComponentType<T>): T;
        restorePatch(arg0: $DataComponentPatch): void;
        set<T>(arg0: $DataComponentType<any>, arg1: T): T;
        size(): number;
        spliterator(): $Spliterator<$TypedDataComponent<any>>;
        stream(): $Stream<$TypedDataComponent<any>>;
        toString(): string;
    }

    export class $TypedDataComponent<T> extends $Record {
        constructor(arg0: $DataComponentType<T>, arg1: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $TypedDataComponent<any>>;
        static createUnchecked<T>(arg0: $DataComponentType<T>, arg1: object): $TypedDataComponent<T>;
        applyTo(arg0: $PatchedDataComponentMap): void;
        encodeValue<D>(arg0: $DynamicOps<D>): $DataResult<D>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $DataComponentType<T>;
        value(): T;
    }

    export type $DataComponentHolder_<CallbackResult = $DataComponentMap> = (() => CallbackResult) | $DataComponentHolder;
}
