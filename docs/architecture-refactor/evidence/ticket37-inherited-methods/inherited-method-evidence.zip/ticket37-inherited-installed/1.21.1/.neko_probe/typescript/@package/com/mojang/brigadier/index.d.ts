import { $LiteralArgumentBuilder } from "java:com/mojang/brigadier/builder";
import { $CommandContext, $CommandContextBuilder } from "java:com/mojang/brigadier/context";
import { $CommandSyntaxException } from "java:com/mojang/brigadier/exceptions";
import { $Suggestions } from "java:com/mojang/brigadier/suggestion";
import { $CommandNode, $LiteralCommandNode, $RootCommandNode } from "java:com/mojang/brigadier/tree";
import { $Collection, $Map } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";

export * as arguments from "java:com/mojang/brigadier/arguments";
export * as builder from "java:com/mojang/brigadier/builder";
export * as context from "java:com/mojang/brigadier/context";
export * as exceptions from "java:com/mojang/brigadier/exceptions";
export * as suggestion from "java:com/mojang/brigadier/suggestion";
export * as tree from "java:com/mojang/brigadier/tree";

declare module "java:com/mojang/brigadier" {
    export interface $AmbiguityConsumer<S> {
        ambiguous(arg0: $CommandNode<S>, arg1: $CommandNode<S>, arg2: $CommandNode<S>, arg3: string[]): void;
    }

    export interface $Command<S> {
        run(arg0: $CommandContext<S>): number;
    }
    export const $Command: {
        readonly SINGLE_SUCCESS: number;
    };

    export class $CommandDispatcher<S> {
        constructor();
        constructor(arg0: $RootCommandNode<S>);
        static ARGUMENT_SEPARATOR: string;
        static ARGUMENT_SEPARATOR_CHAR: string;
        get root(): $RootCommandNode<S>;
        getRoot(): $RootCommandNode<S>;
        execute(arg0: $ParseResults<S>): number;
        execute(arg0: $StringReader, arg1: S): number;
        execute(arg0: string, arg1: S): number;
        findAmbiguities(arg0: $AmbiguityConsumer_<S, $CommandNode<S>, $CommandNode<S>, $CommandNode<S>, $Collection<string>>): void;
        findNode(arg0: string[]): $CommandNode<S>;
        getAllUsage(arg0: $CommandNode<S>, arg1: S, arg2: boolean): string[];
        getCompletionSuggestions(arg0: $ParseResults<S>, arg1: number): $CompletableFuture<$Suggestions>;
        getCompletionSuggestions(arg0: $ParseResults<S>): $CompletableFuture<$Suggestions>;
        getPath(arg0: $CommandNode<S>): $Collection<string>;
        getSmartUsage(arg0: $CommandNode<S>, arg1: S): $Map<$CommandNode<S>, string>;
        parse(arg0: $StringReader, arg1: S): $ParseResults<S>;
        parse(arg0: string, arg1: S): $ParseResults<S>;
        register(arg0: $LiteralArgumentBuilder<S>): $LiteralCommandNode<S>;
    }

    export interface $ImmutableStringReader {
        canRead(arg0: number): boolean;
        canRead(): boolean;
        getCursor(): number;
        getRead(): string;
        getRemainingLength(): number;
        getRemaining(): string;
        getString(): string;
        getTotalLength(): number;
        peek(arg0: number): string;
        peek(): string;
    }

    export interface $Message {
        getString(): string;
    }

    export class $ParseResults<S> {
        constructor(arg0: $CommandContextBuilder<S>);
        constructor(arg0: $CommandContextBuilder<S>, arg1: $ImmutableStringReader, arg2: { [key: $CommandNode<S>]: $CommandSyntaxException });
        get context(): $CommandContextBuilder<S>;
        getContext(): $CommandContextBuilder<S>;
        get exceptions(): $Map<$CommandNode<S>, $CommandSyntaxException>;
        getExceptions(): $Map<$CommandNode<S>, $CommandSyntaxException>;
        get reader(): $ImmutableStringReader;
        getReader(): $ImmutableStringReader;
    }

    export interface $RedirectModifier<S> {
        apply(arg0: $CommandContext<S>): $Collection<S>;
    }

    export interface $ResultConsumer<S> {
        onCommandComplete(arg0: $CommandContext<S>, arg1: boolean, arg2: number): void;
    }

    export interface $SingleRedirectModifier<S> {
        apply(arg0: $CommandContext<S>): S;
    }

    export class $StringReader implements $ImmutableStringReader {
        constructor(arg0: $StringReader);
        constructor(arg0: string);
        get cursor(): number;
        getCursor(): number;
        set cursor(value: number);
        get read(): string;
        getRead(): string;
        get remainingLength(): number;
        getRemainingLength(): number;
        get remaining(): string;
        getRemaining(): string;
        get string(): string;
        getString(): string;
        get totalLength(): number;
        getTotalLength(): number;
        static isAllowedInUnquotedString(arg0: string): boolean;
        static isAllowedNumber(arg0: string): boolean;
        static isQuotedStringStart(arg0: string): boolean;
        canRead(arg0: number): boolean;
        canRead(): boolean;
        expect(arg0: string): void;
        peek(arg0: number): string;
        peek(): string;
        readBoolean(): boolean;
        readDouble(): number;
        readFloat(): number;
        readInt(): number;
        readLong(): number;
        readQuotedString(): string;
        readStringUntil(arg0: string): string;
        readString(): string;
        readUnquotedString(): string;
        read(): string;
        skipWhitespace(): void;
        skip(): void;
    }

    export type $AmbiguityConsumer_<Host0 = any, CallbackArg0 = $CommandNode<Host0>, CallbackArg1 = $CommandNode<Host0>, CallbackArg2 = $CommandNode<Host0>, CallbackArg3 = $Collection<string>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => void) | $AmbiguityConsumer<Host0>;
    export type $Command_<Host0 = any, CallbackArg0 = $CommandContext<Host0>, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | $Command<Host0>;
    export type $Message_<CallbackResult = string> = (() => CallbackResult) | $Message;
    export type $RedirectModifier_<Host0 = any, CallbackArg0 = $CommandContext<Host0>, CallbackResult = Host0[]> = ((arg0: CallbackArg0) => CallbackResult) | $RedirectModifier<Host0>;
    export type $ResultConsumer_<Host0 = any, CallbackArg0 = $CommandContext<Host0>, CallbackArg1 = boolean, CallbackArg2 = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void) | $ResultConsumer<Host0>;
    export type $SingleRedirectModifier_<Host0 = any, CallbackArg0 = $CommandContext<Host0>, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | $SingleRedirectModifier<Host0>;
}
