import { $Command, $Command_, $RedirectModifier, $RedirectModifier_, $SingleRedirectModifier, $SingleRedirectModifier_ } from "java:com/mojang/brigadier";
import { $ArgumentType, $ArgumentType_ } from "java:com/mojang/brigadier/arguments";
import { $SuggestionProvider, $SuggestionProvider_ } from "java:com/mojang/brigadier/suggestion";
import { $ArgumentCommandNode, $CommandNode, $LiteralCommandNode } from "java:com/mojang/brigadier/tree";
import { $Collection } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";

declare module "java:com/mojang/brigadier/builder" {
    export class $ArgumentBuilder<S, T extends $ArgumentBuilder<S, T>> {
        constructor();
        get arguments(): $Collection<$CommandNode<S>>;
        getArguments(): $Collection<$CommandNode<S>>;
        get command(): $Command<S>;
        getCommand(): $Command<S>;
        get redirectModifier(): $RedirectModifier<S>;
        getRedirectModifier(): $RedirectModifier<S>;
        get redirect(): $CommandNode<S>;
        getRedirect(): $CommandNode<S>;
        get requirement(): $Predicate<S>;
        getRequirement(): $Predicate<S>;
        get fork(): boolean;
        isFork(): boolean;
        build(): $CommandNode<S>;
        executes(arg0: $Command_<S, $CommandContext<S>, number>): T;
        fork(arg0: $CommandNode<S>, arg1: $RedirectModifier_<S, $CommandContext<S>, S[]>): T;
        forward(arg0: $CommandNode<S>, arg1: $RedirectModifier_<S, $CommandContext<S>, S[]>, arg2: boolean): T;
        redirect(arg0: $CommandNode<S>, arg1: $SingleRedirectModifier_<S, $CommandContext<S>, S>): T;
        redirect(arg0: $CommandNode<S>): T;
        requires(arg0: $Predicate_<S, S, boolean>): T;
        then(arg0: $ArgumentBuilder<S, any>): T;
        then(arg0: $CommandNode<S>): T;
    }

    export class $LiteralArgumentBuilder<S> extends $ArgumentBuilder<S, $LiteralArgumentBuilder<S>> {
        get literal(): string;
        getLiteral(): string;
        static literal<S>(arg0: string): $LiteralArgumentBuilder<S>;
        build(): $LiteralCommandNode<S>;
    }

    export class $RequiredArgumentBuilder<S, T> extends $ArgumentBuilder<S, $RequiredArgumentBuilder<S, T>> {
        get name(): string;
        getName(): string;
        get suggestionsProvider(): $SuggestionProvider<S>;
        getSuggestionsProvider(): $SuggestionProvider<S>;
        get type(): $ArgumentType<T>;
        getType(): $ArgumentType<T>;
        static argument<S, T>(arg0: string, arg1: $ArgumentType_<T, $StringReader, T>): $RequiredArgumentBuilder<S, T>;
        build(): $ArgumentCommandNode<S, T>;
        suggests(arg0: $SuggestionProvider_<S, $CommandContext<S>, $SuggestionsBuilder, $CompletableFuture<$Suggestions>>): $RequiredArgumentBuilder<S, T>;
    }

}
