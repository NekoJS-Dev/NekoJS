import { $AutoCloseable, $AutoCloseable_, $Runnable, $Runnable_, $Thread, $Throwable } from "java:java/lang";
import { $Duration } from "java:java/time";
import { $ChronoUnit, $ChronoUnit_ } from "java:java/time/temporal";
import { $Collection, $List } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function, $Function_, $Supplier, $Supplier_ } from "java:java/util/function";

declare module "java:java/util/concurrent" {
    export interface $Callable<V> {
        call(): V;
    }

    export class $CompletableFuture<T> implements $Future<T>, $CompletionStage<T> {
        constructor();
        get numberOfDependents(): number;
        getNumberOfDependents(): number;
        get cancelled(): boolean;
        isCancelled(): boolean;
        get completedExceptionally(): boolean;
        isCompletedExceptionally(): boolean;
        get done(): boolean;
        isDone(): boolean;
        static allOf(arg0?: $CompletableFuture<any>[]): $CompletableFuture<void>;
        static anyOf(arg0?: $CompletableFuture<any>[]): $CompletableFuture<object>;
        static completedFuture<U>(arg0: U): $CompletableFuture<U>;
        static completedStage<U>(arg0: U): $CompletionStage<U>;
        static delayedExecutor(arg0: number, arg1: $TimeUnit_, arg2: $Executor_<$Runnable>): $Executor;
        static delayedExecutor(arg0: number, arg1: $TimeUnit_): $Executor;
        static failedFuture<U>(arg0: $Throwable): $CompletableFuture<U>;
        static failedStage<U>(arg0: $Throwable): $CompletionStage<U>;
        static runAsync(arg0: $Runnable_, arg1: $Executor_<$Runnable>): $CompletableFuture<void>;
        static runAsync(arg0: $Runnable_): $CompletableFuture<void>;
        static supplyAsync<U>(arg0: $Supplier_<U, U>, arg1: $Executor_<$Runnable>): $CompletableFuture<U>;
        static supplyAsync<U>(arg0: $Supplier_<U, U>): $CompletableFuture<U>;
        acceptEitherAsync(arg0: $CompletionStage<T>, arg1: $Consumer_<T, T>, arg2: $Executor_<$Runnable>): $CompletableFuture<void>;
        acceptEitherAsync(arg0: $CompletionStage<T>, arg1: $Consumer_<T, T>): $CompletableFuture<void>;
        acceptEither(arg0: $CompletionStage<T>, arg1: $Consumer_<T, T>): $CompletableFuture<void>;
        applyToEitherAsync<U>(arg0: $CompletionStage<T>, arg1: $Function_<T, U, T, U>, arg2: $Executor_<$Runnable>): $CompletableFuture<U>;
        applyToEitherAsync<U>(arg0: $CompletionStage<T>, arg1: $Function_<T, U, T, U>): $CompletableFuture<U>;
        applyToEither<U>(arg0: $CompletionStage<T>, arg1: $Function_<T, U, T, U>): $CompletableFuture<U>;
        cancel(arg0: boolean): boolean;
        completeAsync(arg0: $Supplier_<T, T>, arg1: $Executor_<$Runnable>): $CompletableFuture<T>;
        completeAsync(arg0: $Supplier_<T, T>): $CompletableFuture<T>;
        completeExceptionally(arg0: $Throwable): boolean;
        completeOnTimeout(arg0: T, arg1: number, arg2: $TimeUnit_): $CompletableFuture<T>;
        complete(arg0: T): boolean;
        copy(): $CompletableFuture<T>;
        defaultExecutor(): $Executor;
        exceptionNow(): $Throwable;
        exceptionallyAsync(arg0: $Function_<$Throwable, T, $Throwable, T>, arg1: $Executor_<$Runnable>): $CompletableFuture<T>;
        exceptionallyAsync(arg0: $Function_<$Throwable, T, $Throwable, T>): $CompletableFuture<T>;
        exceptionallyComposeAsync(arg0: $Function_<$Throwable, $CompletionStage<T>, $Throwable, $CompletionStage<T>>, arg1: $Executor_<$Runnable>): $CompletableFuture<T>;
        exceptionallyComposeAsync(arg0: $Function_<$Throwable, $CompletionStage<T>, $Throwable, $CompletionStage<T>>): $CompletableFuture<T>;
        exceptionallyCompose(arg0: $Function_<$Throwable, $CompletionStage<T>, $Throwable, $CompletionStage<T>>): $CompletableFuture<T>;
        exceptionally(arg0: $Function_<$Throwable, T, $Throwable, T>): $CompletableFuture<T>;
        getNow(arg0: T): T;
        get(arg0: number, arg1: $TimeUnit_): T;
        get(): T;
        handleAsync<U>(arg0: $BiFunction_<T, $Throwable, U, T, $Throwable, U>, arg1: $Executor_<$Runnable>): $CompletableFuture<U>;
        handleAsync<U>(arg0: $BiFunction_<T, $Throwable, U, T, $Throwable, U>): $CompletableFuture<U>;
        handle<U>(arg0: $BiFunction_<T, $Throwable, U, T, $Throwable, U>): $CompletableFuture<U>;
        join(): T;
        minimalCompletionStage(): $CompletionStage<T>;
        newIncompleteFuture<U>(): $CompletableFuture<U>;
        obtrudeException(arg0: $Throwable): void;
        obtrudeValue(arg0: T): void;
        orTimeout(arg0: number, arg1: $TimeUnit_): $CompletableFuture<T>;
        resultNow(): T;
        runAfterBothAsync(arg0: $CompletionStage<any>, arg1: $Runnable_, arg2: $Executor_<$Runnable>): $CompletableFuture<void>;
        runAfterBothAsync(arg0: $CompletionStage<any>, arg1: $Runnable_): $CompletableFuture<void>;
        runAfterBoth(arg0: $CompletionStage<any>, arg1: $Runnable_): $CompletableFuture<void>;
        runAfterEitherAsync(arg0: $CompletionStage<any>, arg1: $Runnable_, arg2: $Executor_<$Runnable>): $CompletableFuture<void>;
        runAfterEitherAsync(arg0: $CompletionStage<any>, arg1: $Runnable_): $CompletableFuture<void>;
        runAfterEither(arg0: $CompletionStage<any>, arg1: $Runnable_): $CompletableFuture<void>;
        state(): $Future$State;
        thenAcceptAsync(arg0: $Consumer_<T, T>, arg1: $Executor_<$Runnable>): $CompletableFuture<void>;
        thenAcceptAsync(arg0: $Consumer_<T, T>): $CompletableFuture<void>;
        thenAcceptBothAsync<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer_<T, U, T, U>, arg2: $Executor_<$Runnable>): $CompletableFuture<void>;
        thenAcceptBothAsync<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer_<T, U, T, U>): $CompletableFuture<void>;
        thenAcceptBoth<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer_<T, U, T, U>): $CompletableFuture<void>;
        thenAccept(arg0: $Consumer_<T, T>): $CompletableFuture<void>;
        thenApplyAsync<U>(arg0: $Function_<T, U, T, U>, arg1: $Executor_<$Runnable>): $CompletableFuture<U>;
        thenApplyAsync<U>(arg0: $Function_<T, U, T, U>): $CompletableFuture<U>;
        thenApply<U>(arg0: $Function_<T, U, T, U>): $CompletableFuture<U>;
        thenCombineAsync<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction_<T, U, V, T, U, V>, arg2: $Executor_<$Runnable>): $CompletableFuture<V>;
        thenCombineAsync<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction_<T, U, V, T, U, V>): $CompletableFuture<V>;
        thenCombine<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction_<T, U, V, T, U, V>): $CompletableFuture<V>;
        thenComposeAsync<U>(arg0: $Function_<T, $CompletionStage<U>, T, $CompletionStage<U>>, arg1: $Executor_<$Runnable>): $CompletableFuture<U>;
        thenComposeAsync<U>(arg0: $Function_<T, $CompletionStage<U>, T, $CompletionStage<U>>): $CompletableFuture<U>;
        thenCompose<U>(arg0: $Function_<T, $CompletionStage<U>, T, $CompletionStage<U>>): $CompletableFuture<U>;
        thenRunAsync(arg0: $Runnable_, arg1: $Executor_<$Runnable>): $CompletableFuture<void>;
        thenRunAsync(arg0: $Runnable_): $CompletableFuture<void>;
        thenRun(arg0: $Runnable_): $CompletableFuture<void>;
        toCompletableFuture(): $CompletableFuture<T>;
        toString(): string;
        whenCompleteAsync(arg0: $BiConsumer_<T, $Throwable, T, $Throwable>, arg1: $Executor_<$Runnable>): $CompletableFuture<T>;
        whenCompleteAsync(arg0: $BiConsumer_<T, $Throwable, T, $Throwable>): $CompletableFuture<T>;
        whenComplete(arg0: $BiConsumer_<T, $Throwable, T, $Throwable>): $CompletableFuture<T>;
    }

    export interface $CompletionStage<T> {
        acceptEitherAsync(arg0: $CompletionStage<T>, arg1: $Consumer_<T, T>, arg2: $Executor_<$Runnable>): $CompletionStage<void>;
        acceptEitherAsync(arg0: $CompletionStage<T>, arg1: $Consumer_<T, T>): $CompletionStage<void>;
        acceptEither(arg0: $CompletionStage<T>, arg1: $Consumer_<T, T>): $CompletionStage<void>;
        applyToEitherAsync<U>(arg0: $CompletionStage<T>, arg1: $Function_<T, U, T, U>, arg2: $Executor_<$Runnable>): $CompletionStage<U>;
        applyToEitherAsync<U>(arg0: $CompletionStage<T>, arg1: $Function_<T, U, T, U>): $CompletionStage<U>;
        applyToEither<U>(arg0: $CompletionStage<T>, arg1: $Function_<T, U, T, U>): $CompletionStage<U>;
        exceptionallyAsync(arg0: $Function_<$Throwable, T, $Throwable, T>, arg1: $Executor_<$Runnable>): $CompletionStage<T>;
        exceptionallyAsync(arg0: $Function_<$Throwable, T, $Throwable, T>): $CompletionStage<T>;
        exceptionallyComposeAsync(arg0: $Function_<$Throwable, $CompletionStage<T>, $Throwable, $CompletionStage<T>>, arg1: $Executor_<$Runnable>): $CompletionStage<T>;
        exceptionallyComposeAsync(arg0: $Function_<$Throwable, $CompletionStage<T>, $Throwable, $CompletionStage<T>>): $CompletionStage<T>;
        exceptionallyCompose(arg0: $Function_<$Throwable, $CompletionStage<T>, $Throwable, $CompletionStage<T>>): $CompletionStage<T>;
        exceptionally(arg0: $Function_<$Throwable, T, $Throwable, T>): $CompletionStage<T>;
        handleAsync<U>(arg0: $BiFunction_<T, $Throwable, U, T, $Throwable, U>, arg1: $Executor_<$Runnable>): $CompletionStage<U>;
        handleAsync<U>(arg0: $BiFunction_<T, $Throwable, U, T, $Throwable, U>): $CompletionStage<U>;
        handle<U>(arg0: $BiFunction_<T, $Throwable, U, T, $Throwable, U>): $CompletionStage<U>;
        runAfterBothAsync(arg0: $CompletionStage<any>, arg1: $Runnable_, arg2: $Executor_<$Runnable>): $CompletionStage<void>;
        runAfterBothAsync(arg0: $CompletionStage<any>, arg1: $Runnable_): $CompletionStage<void>;
        runAfterBoth(arg0: $CompletionStage<any>, arg1: $Runnable_): $CompletionStage<void>;
        runAfterEitherAsync(arg0: $CompletionStage<any>, arg1: $Runnable_, arg2: $Executor_<$Runnable>): $CompletionStage<void>;
        runAfterEitherAsync(arg0: $CompletionStage<any>, arg1: $Runnable_): $CompletionStage<void>;
        runAfterEither(arg0: $CompletionStage<any>, arg1: $Runnable_): $CompletionStage<void>;
        thenAcceptAsync(arg0: $Consumer_<T, T>, arg1: $Executor_<$Runnable>): $CompletionStage<void>;
        thenAcceptAsync(arg0: $Consumer_<T, T>): $CompletionStage<void>;
        thenAcceptBothAsync<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer_<T, U, T, U>, arg2: $Executor_<$Runnable>): $CompletionStage<void>;
        thenAcceptBothAsync<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer_<T, U, T, U>): $CompletionStage<void>;
        thenAcceptBoth<U>(arg0: $CompletionStage<U>, arg1: $BiConsumer_<T, U, T, U>): $CompletionStage<void>;
        thenAccept(arg0: $Consumer_<T, T>): $CompletionStage<void>;
        thenApplyAsync<U>(arg0: $Function_<T, U, T, U>, arg1: $Executor_<$Runnable>): $CompletionStage<U>;
        thenApplyAsync<U>(arg0: $Function_<T, U, T, U>): $CompletionStage<U>;
        thenApply<U>(arg0: $Function_<T, U, T, U>): $CompletionStage<U>;
        thenCombineAsync<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction_<T, U, V, T, U, V>, arg2: $Executor_<$Runnable>): $CompletionStage<V>;
        thenCombineAsync<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction_<T, U, V, T, U, V>): $CompletionStage<V>;
        thenCombine<U, V>(arg0: $CompletionStage<U>, arg1: $BiFunction_<T, U, V, T, U, V>): $CompletionStage<V>;
        thenComposeAsync<U>(arg0: $Function_<T, $CompletionStage<U>, T, $CompletionStage<U>>, arg1: $Executor_<$Runnable>): $CompletionStage<U>;
        thenComposeAsync<U>(arg0: $Function_<T, $CompletionStage<U>, T, $CompletionStage<U>>): $CompletionStage<U>;
        thenCompose<U>(arg0: $Function_<T, $CompletionStage<U>, T, $CompletionStage<U>>): $CompletionStage<U>;
        thenRunAsync(arg0: $Runnable_, arg1: $Executor_<$Runnable>): $CompletionStage<void>;
        thenRunAsync(arg0: $Runnable_): $CompletionStage<void>;
        thenRun(arg0: $Runnable_): $CompletionStage<void>;
        toCompletableFuture(): $CompletableFuture<T>;
        whenCompleteAsync(arg0: $BiConsumer_<T, $Throwable, T, $Throwable>, arg1: $Executor_<$Runnable>): $CompletionStage<T>;
        whenCompleteAsync(arg0: $BiConsumer_<T, $Throwable, T, $Throwable>): $CompletionStage<T>;
        whenComplete(arg0: $BiConsumer_<T, $Throwable, T, $Throwable>): $CompletionStage<T>;
    }

    export interface $Executor {
        execute(arg0: $Runnable_): void;
    }

    export interface $ExecutorService extends $Executor, $AutoCloseable {
        awaitTermination(arg0: number, arg1: $TimeUnit_): boolean;
        close(): void;
        invokeAll<T>(arg0: $Callable_<T, T>[], arg1: number, arg2: $TimeUnit_): $List<$Future<T>>;
        invokeAll<T>(arg0: $Callable_<T, T>[]): $List<$Future<T>>;
        invokeAny<T>(arg0: $Callable_<T, T>[], arg1: number, arg2: $TimeUnit_): T;
        invokeAny<T>(arg0: $Callable_<T, T>[]): T;
        isShutdown(): boolean;
        isTerminated(): boolean;
        shutdownNow(): $List<$Runnable>;
        shutdown(): void;
        submit<T>(arg0: $Runnable_, arg1: T): $Future<T>;
        submit(arg0: $Runnable_): $Future<any>;
        submit<T>(arg0: $Callable_<T, T>): $Future<T>;
    }

    export interface $Future<V> {
        cancel(arg0: boolean): boolean;
        exceptionNow(): $Throwable;
        get(arg0: number, arg1: $TimeUnit_): V;
        get(): V;
        isCancelled(): boolean;
        isDone(): boolean;
        resultNow(): V;
        state(): $Future$State;
    }

    export class $Future$State {
        static CANCELLED: $Future$State;
        static FAILED: $Future$State;
        static RUNNING: $Future$State;
        static SUCCESS: $Future$State;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Future$State[];
        static valueOf(name: string): $Future$State;
    }

    export interface $ThreadFactory {
        newThread(arg0: $Runnable_): $Thread;
    }

    export class $TimeUnit {
        static DAYS: $TimeUnit;
        static HOURS: $TimeUnit;
        static MICROSECONDS: $TimeUnit;
        static MILLISECONDS: $TimeUnit;
        static MINUTES: $TimeUnit;
        static NANOSECONDS: $TimeUnit;
        static SECONDS: $TimeUnit;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TimeUnit[];
        static valueOf(name: string): $TimeUnit;
    }

    export type $Callable_<Host0 = any, CallbackResult = Host0> = (() => CallbackResult) | $Callable<Host0>;
    export type $Executor_<CallbackArg0 = $Runnable> = ((arg0: CallbackArg0) => void) | $Executor;
    export type $Future$State_ = $Future$State | "CANCELLED" | "FAILED" | "RUNNING" | "SUCCESS";
    export type $ThreadFactory_<CallbackArg0 = $Runnable, CallbackResult = $Thread> = ((arg0: CallbackArg0) => CallbackResult) | $ThreadFactory;
    export type $TimeUnit_ = $TimeUnit | "DAYS" | "HOURS" | "MICROSECONDS" | "MILLISECONDS" | "MINUTES" | "NANOSECONDS" | "SECONDS";
}
