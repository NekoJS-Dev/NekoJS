import { $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Stream } from "java:java/util/stream";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";

declare module "java:net/minecraft/network/chat/contents" {
    export interface $DataSource {
        getData(arg0: $CommandSourceStack): $Stream<$CompoundTag>;
        type(): $DataSource$Type<any>;
    }
    export const $DataSource: {
        readonly CODEC: $MapCodec<$DataSource>;
    };

    export class $DataSource$Type<T extends $DataSource> extends $Record implements $StringRepresentable {
        constructor(arg0: $MapCodec<T>, arg1: string);
        get serializedName(): string;
        getSerializedName(): string;
        codec(): $MapCodec<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): string;
        toString(): string;
    }

}
