"""Freeze ordinary checks and runtime artifacts for the four affected modern nodes."""
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-23-holder-modern-builds'
assert not out.exists()
log = (tools / 'b47734c6-modern-builds.log').read_bytes()
assert b'BUILD SUCCESSFUL' in log
revision = subprocess.check_output(['git', 'rev-parse', 'b47734c6'], text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', revision, '--', 'common/src/main', 'src/main', 'versions', 'buildSrc'], text=True).strip()
entries = {'run/build.log': log, 'tools/freeze-b477-modern-builds.py': Path(__file__).read_bytes()}
artifacts = {}
tests = {}
for node in ['26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    directory = repo / 'versions' / node / 'build'
    jar = next((directory / 'libs').glob('*.jar'))
    bindings = {}
    with zipfile.ZipFile(jar) as archive:
        for source in [repo / 'common/build/classes/java/main', directory / 'classes/java/main']:
            for file in source.rglob('*.class'):
                name = file.relative_to(source).as_posix()
                data = file.read_bytes()
                assert archive.read(name) == data, (node, name)
                bindings[name] = hashlib.sha256(data).hexdigest()
    artifacts[node] = dict(name=jar.name, sha256=hashlib.sha256(jar.read_bytes()).hexdigest())
    entries['bindings/' + node + '.json'] = (json.dumps(bindings, indent=2) + '\n').encode()
    counts = dict(tests=0, skipped=0, failures=0, errors=0)
    for task in ['test', 'platformGateTest']:
        for file in (directory / 'test-results' / task).glob('TEST-*.xml'):
            data = file.read_bytes()
            suite = ET.fromstring(data)
            for key in counts:
                counts[key] += int(suite.get(key, 0))
            entries['xml/' + node + '/' + task + '/' + file.name] = data
    assert counts == dict(tests=690 if 'fabric' not in node else 416,
        skipped=81 if 'fabric' not in node else 37, failures=0, errors=0), (node, counts)
    tests[node] = counts
summary = dict(productionRevision=revision, artifacts=artifacts, tests=tests,
    scope='Four modern nodes only; common and legacy source unchanged by holder fix.',
    tcp='Separate actual recovery fixture; no claim from build checks.', maintainerAcceptance=False)
entries['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
(tools / 'b47734c6-modern-build-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
out.mkdir()
with zipfile.ZipFile(out / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(out / 'manifest.json').write_text(json.dumps(dict(archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())}), indent=2) + '\n')
print(json.dumps(summary))
