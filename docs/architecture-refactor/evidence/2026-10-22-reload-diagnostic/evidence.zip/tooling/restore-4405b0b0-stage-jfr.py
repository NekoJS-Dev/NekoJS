import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
out = tools/'4405b0b0-stage-jfr-v2'
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
binding = json.loads((out/'binding.json').read_text())
state = json.loads((out/'session/session.json').read_text(encoding='utf-8-sig'))
assert not state['forcedKill'] and not state['extra']['killed'] and state['extra']['stopChannel'] == 'rcon'
assert subprocess.check_output(['git','diff','--name-only'],cwd=tree,text=True).splitlines() == sorted(r['path'] for r in binding['bindings'])
for row in binding['bindings']:
    path = tree/row['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['instrumentedSha256']
    original = (out/path.name).read_bytes()
    assert hashlib.sha256(original).hexdigest() == row['originalSha256']
    path.write_bytes(original)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True).strip()
(out/'restoration.json').write_text(json.dumps(dict(sourceRestored=True,normalStop=True,
    instrumentedJfrSha256=hashlib.sha256((out/'session/reload.jfr').read_bytes()).hexdigest()),indent=2)+'\n')
print('ISOLATED_SOURCE_RESTORED')
