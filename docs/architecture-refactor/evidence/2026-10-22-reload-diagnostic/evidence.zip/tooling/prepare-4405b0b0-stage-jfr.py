"""Install owned, temporary stage events in the isolated performance checkout."""
import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = tools / '4405b0b0-stage-jfr-v2'
assert not out.exists()
assert subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True).strip() == ''
revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()
assert revision == '4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349'
out.mkdir()
event = '''
    @jdk.jfr.Name("neko.ReloadStage")
    @jdk.jfr.StackTrace(false)
    private static final class ReloadStage extends jdk.jfr.Event implements AutoCloseable {
        String stage;
        long wallNs;
        long cpuNs;
        private long startWall;
        private long startCpu;
        static ReloadStage begin(String name) {
            var event = new ReloadStage();
            event.stage = name;
            event.startCpu = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            event.startWall = System.nanoTime();
            event.begin();
            return event;
        }
        @Override public void close() {
            end();
            wallNs = System.nanoTime() - startWall;
            cpuNs = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime() - startCpu;
            commit();
        }
    }
'''
paths = ['src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java',
    'common/src/main/java/com/tkisor/nekojs/script/ScriptManager.java']
bindings = []
for relative in paths:
    path = tree / relative
    original = path.read_bytes()
    (out / path.name).write_bytes(original)
    source = original.decode('utf-8')
    if path.name == 'NekoJSCommands.java':
        edits = [('        NekoRuntimeRoot.ReloadResult reloadResult;\n        try {',
                  '        NekoRuntimeRoot.ReloadResult reloadResult;\n        try (var profile = ReloadStage.begin("command")) {')]
        for stage, line in [('root', '            reloadResult = root.reload(type);'),
                            ('recipe', '                    recipeBroadcast = applyRecipeScripts(source);')]:
            edits.append((line, f'            try (var stageProfile = ReloadStage.begin("{stage}")) {{\n'+line+'\n            }'))
    else:
        edits = [
            ('                    try {\n                        candidateEnvironment = createCandidateEnvironment(candidateGeneration);',
             '                    try (var stageProfile = ReloadStage.begin("preparation")) {\n                        candidateEnvironment = createCandidateEnvironment(candidateGeneration);'),
            ('                    try {\n                        environmentFactory.installEnvironmentBindings(',
             '                    try (var stageProfile = ReloadStage.begin("bindings")) {\n                        environmentFactory.installEnvironmentBindings('),
            ('                    try {\n                        candidateScripts = discoverWithPacks();',
             '                    try (var stageProfile = ReloadStage.begin("execution")) {\n                        candidateScripts = discoverWithPacks();'),
            ('                    commitGeneration(candidateGeneration, candidateEnvironment, candidateScripts, oldEnvironment);',
             '                    try (var stageProfile = ReloadStage.begin("commit")) {\n                    commitGeneration(candidateGeneration, candidateEnvironment, candidateScripts, oldEnvironment);\n                    }')]
    for before, after in edits:
        assert source.count(before) == 1, (relative, before)
        source = source.replace(before, after)
    end = source.rfind('\n}\n//?}')+1 if path.name == 'NekoJSCommands.java' else source.rfind('}')
    assert end > 0
    source = source[:end] + event + source[end:]
    path.write_text(source,encoding='utf-8',newline='\n')
    bindings.append(dict(path=relative,originalSha256=hashlib.sha256(original).hexdigest(),
        instrumentedSha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(out/'binding.json').write_text(json.dumps(dict(revision=revision,diagnosticOnly=True,bindings=bindings),indent=2)+'\n',encoding='utf-8')
(out/'instrumentation.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths],cwd=tree))
controller = (tools/'4405b0b0-reload-jfr/diagnostic.ps1').read_text(encoding='utf-8')
controller = controller.replace('4405b0b0-reload-jfr/session','4405b0b0-stage-jfr-v2/session')
controller = controller.replace(').Count -ne 0)', ').Count -ne 2)')
(out/'diagnostic.ps1').write_text(controller,encoding='utf-8',newline='\n')
(out/'run.py').write_bytes((tools/'4405b0b0-reload-jfr/run.py').read_bytes())
print('TEMPORARY_STAGE_EVENTS_PREPARED')
