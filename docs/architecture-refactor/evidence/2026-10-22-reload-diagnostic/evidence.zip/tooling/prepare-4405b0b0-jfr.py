"""Reuse managed server/RCON diagnostics without instrumenting production classes."""
import hashlib
import json
from pathlib import Path

tools = Path(__file__).resolve().parent
destination = tools / '4405b0b0-reload-jfr'
assert not destination.exists() or not any(destination.iterdir())
destination.mkdir(exist_ok=True)
old_tree = 'C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult'
tree = 'D:/mcmodDemo/NekoJS-perf-606d1fff'
revision = '4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349'
source = (tools / 'stage-jfr-v2-diagnostic.ps1').read_text(encoding='utf-8')
source = source.replace(old_tree.replace('/', '\\'), tree.replace('/', '\\'))
source = source.replace('stage-jfr-4550a385/session-v2'.replace('/', '\\'), '4405b0b0-reload-jfr/session'.replace('/', '\\'))
source = source.replace('stage-jfr-4550a385/session-v2', '4405b0b0-reload-jfr/session')
source = source.replace('4550a3859b40f215084016082f97fa28eb1ac250', revision)
source = source.replace("$GitRev = '4550a385'", "$GitRev = '4405b0b0'")
source = source.replace(').Count -ne 1)', ').Count -ne 0)')
source = source.replace('$pair -le 20', '$pair -le 10')
source = source.replace('STAGE_JFR_COMPLETE', 'CANDIDATE_JFR_COMPLETE')
assert old_tree.replace('/', '\\') not in source
assert '4550a385' not in source
(destination / 'diagnostic.ps1').write_text(source, encoding='utf-8', newline='\n')
runner = (tools / 'run-stage-jfr-v2.py').read_text(encoding='utf-8')
runner = runner.replace("tools = Path(__file__).resolve().parent", "tools = Path(__file__).resolve().parent")
runner = runner.replace(old_tree, tree)
runner = runner.replace('stage-jfr-v2-diagnostic.ps1', 'diagnostic.ps1')
runner = runner.replace('stage-jfr-v2-controller', 'controller').replace('stage-jfr-v2-exit', 'exit')
(destination / 'run.py').write_text(runner, encoding='utf-8', newline='\n')
binding = dict(revision=revision, diagnosticOnly=True, productionInstrumentation=False,
    pairs=10, sourceController='stage-jfr-v2-diagnostic.ps1',
    sourceControllerSha256=hashlib.sha256((tools / 'stage-jfr-v2-diagnostic.ps1').read_bytes()).hexdigest(),
    sourceRunnerSha256=hashlib.sha256((tools / 'run-stage-jfr-v2.py').read_bytes()).hexdigest())
(destination / 'binding.json').write_text(json.dumps(binding, indent=2)+'\n', encoding='utf-8')
print('JFR_PREPARED')
