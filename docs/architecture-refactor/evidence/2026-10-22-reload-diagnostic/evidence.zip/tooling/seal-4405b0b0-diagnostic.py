"""Export stage/stack analysis while keeping potentially sensitive raw JFR local."""
import hashlib
import json
import zipfile
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
tools = repo/'build/priority-closeout'
out = repo/'docs/architecture-refactor/evidence/2026-10-22-reload-diagnostic'
assert not out.exists()
out.mkdir()
properties = dict(line.split('=',1) for line in Path('D:/mcmodDemo/NekoJS-perf-606d1fff/versions/26.1.2/run/server.properties').read_text().splitlines() if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password']
entries = {}
redactions = {}
roots = ['4405b0b0-reload-jfr','4405b0b0-stage-jfr','4405b0b0-stage-jfr-v2']
with zipfile.ZipFile(out/'evidence.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def add(path,name):
        original = path.read_bytes()
        if original.startswith((b'\xff\xfe',b'\xfe\xff')): data = original.decode('utf-16').encode('utf-8')
        else: data = original
        if secret.encode() in data:
            redactions[name] = hashlib.sha256(original).hexdigest()
            data = data.replace(secret.encode(),b'<REDACTED>')
        assert secret.encode() not in data and secret.encode('utf-16-le') not in data
        entries[name] = hashlib.sha256(data).hexdigest()
        z.writestr(name,data)
    for name in roots:
        root = tools/name
        for path in sorted(root.rglob('*')):
            if path.is_file() and path.suffix in {'.json','.py','.ps1','.java','.log','.txt','.tsv','.patch'}:
                add(path,name+'/'+path.relative_to(root).as_posix())
    for name in ['prepare-4405b0b0-jfr.py','prepare-4405b0b0-stage-jfr.py','restore-4405b0b0-stage-jfr.py',
                 'ReloadStageAnalysis.java','seal-4405b0b0-diagnostic.py']:
        add(tools/name,'tooling/'+name)
manifest = dict(revision='4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349',diagnosticOnly=True,
    archiveSha256=hashlib.sha256((out/'evidence.zip').read_bytes()).hexdigest(),entries=entries,redactions=redactions,
    rawJfrExcluded='Raw recordings can contain environment and JVM properties; only derived stage/stack analysis is exported.',
    rawJfrSha256={name:hashlib.sha256((tools/name/'session/reload.jfr').read_bytes()).hexdigest()
        for name in ['4405b0b0-reload-jfr','4405b0b0-stage-jfr-v2']})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(entries=len(entries),bytes=(out/'evidence.zip').stat().st_size)))
