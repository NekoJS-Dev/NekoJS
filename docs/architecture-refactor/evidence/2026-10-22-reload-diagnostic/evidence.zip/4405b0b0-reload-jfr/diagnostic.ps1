$ErrorActionPreference = 'Stop'
$env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
$ProjectDir = 'D:\mcmodDemo\NekoJS-perf-606d1fff'
$OutDir = 'D:\mcmodDemo\NekoJS-mult\build\priority-closeout\4405b0b0-reload-jfr/session'
$javaRoot = 'C:\Program Files\Java\jdk-25.0.2'
$env:JAVA_HOME = $javaRoot
$env:PATH = "$javaRoot\bin;$env:PATH"
$GradleUserHome = 'D:\mcmodDemo\NekoJS\.gradle-<REDACTED>'
$Node = '26.1.2'
$ServerPort = 25871
$RconPort = 25872
$RconPass = $env:NEKO_PERF_RCON_PASS
$RunDir = Join-Path $ProjectDir 'versions\26.1.2\run'
$sampleDirectory = Join-Path $ProjectDir 'bench\perf'
$FixtureDir = Join-Path $sampleDirectory 'fixtures\nekojs'
$perfOut = Join-Path $RunDir 'nekojs\perf-out'
$GitRev = '4405b0b0'
$script:StdinOk = $null
$script:TestStdin = $false
$script:ReloadMarker = 'PERF02-SERVER tick-bench load'
if (Test-Path -LiteralPath $OutDir) { throw 'Diagnostic output already exists' }
if ((& git -C $ProjectDir rev-parse HEAD).Trim() -ne '4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349') { throw 'Source mismatch' }
if (@(& git -C $ProjectDir diff --name-only).Count -ne 0) { throw 'Owned source is not clean' }
if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 25871,25872).Count) { throw 'Diagnostic ports occupied' }
foreach ($target in @($RunDir, (Join-Path $RunDir 'nekojs'), (Join-Path $RunDir '.neko_probe'), (Join-Path $RunDir 'world'))) {
    if (-not [IO.Path]::GetFullPath($target).StartsWith([IO.Path]::GetFullPath($RunDir), [StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside owned run directory' }
    if (Test-Path -LiteralPath $target) {
        $items = @((Get-Item -LiteralPath $target -Force)) + @(Get-ChildItem -LiteralPath $target -Recurse -Force)
        if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Reparse point on owned run path' }
    }
}
$ancestor = Get-Item -LiteralPath $RunDir
while ($ancestor) {
    if ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point on run ancestor' }
    $ancestor = $ancestor.Parent
}
$parseTokens = $null
$parseErrors = $null
$sampleAst = [Management.Automation.Language.Parser]::ParseFile((Join-Path $sampleDirectory 'sample.ps1'), [ref]$parseTokens, [ref]$parseErrors)
if ($parseErrors.Count) { throw 'Sampler parse failed' }
foreach ($definition in $sampleAst.FindAll({ param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] }, $false)) {
    . ([ScriptBlock]::Create($definition.Extent.Text.Replace('$PSScriptRoot', "'$sampleDirectory'")))
}
function Invoke-DirectRcon {
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = (Get-Command python -CommandType Application | Select-Object -First 1).Source
    $info.Arguments = '"' + (Join-Path $sampleDirectory 'rcon.py') + '" ' + $RconPort + ' "' + $RconPass + '" 180 "nekojs reload"'
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $client = [Diagnostics.Process]::Start($info)
    try {
        $response = $client.StandardOutput.ReadToEnd()
        $failure = $client.StandardError.ReadToEnd()
        $client.WaitForExit()
        if ($client.ExitCode -ne 0 -or $failure) { throw 'Direct RCON control failed' }
        return $response.Trim()
    } finally { $client.Dispose() }
}


New-Item -ItemType Directory -Path $OutDir | Out-Null
Write-EnvSnapshot
Deploy-Fixtures -Bench:$false
$session = Invoke-ServerSession -Tag 'stages' -OnDone {
    param($proc, $outLog, $sw)
    $recording = $false
    $rows = @()
    try {
        $listeners = @(Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 25871)
        if ($listeners.Count -ne 1) { throw 'Expected one owned game listener' }
        $gameId = $listeners[0].OwningProcess
        $game = Get-CimInstance Win32_Process -Filter "ProcessId=$gameId"
        if ($game.ExecutablePath -ne "$javaRoot\bin\java.exe" -or -not $game.CommandLine.Contains($ProjectDir)) { throw 'Unexpected game owner' }
        @{pid=$gameId;launcher=$proc.Id} | ConvertTo-Json | Set-Content (Join-Path $OutDir 'owner.json') -Encoding UTF8
        & "$javaRoot\bin\jcmd.exe" $gameId JFR.start name=reloadStages settings=profile 'jdk.ExecutionSample#period=2ms' 'jdk.NativeMethodSample#period=2ms' | Set-Content (Join-Path $OutDir 'jfr-start.txt')
        if ($LASTEXITCODE -ne 0) { throw 'JFR start failed' }
        $recording = $true
        $offset = (Get-Item -LiteralPath $outLog).Length
        for ($pair = 1; $pair -le 10; $pair++) {
            $commands = if ($pair % 2) { @('list', 'nekojs reload') } else { @('nekojs reload', 'list') }
            foreach ($command in $commands) {
                Start-Sleep -Seconds 3
                [void](Read-LogTailUtf8 $outLog ([ref]$offset))
                $started = [DateTime]::UtcNow.ToString('o')
                $timer = [Diagnostics.Stopwatch]::StartNew()
                $response = Invoke-Rcon -Command $command
                $rconMs = $timer.Elapsed.TotalMilliseconds
                $returned = [DateTime]::UtcNow.ToString('o')
                $markerMs = $null
                if ($command -eq 'nekojs reload') {
                    if ($response -notmatch 'phase=COMMIT - no errors\.') { throw 'Reload diagnostic did not commit' }
                    $deadline = [DateTime]::UtcNow.AddSeconds(10)
                    while ([DateTime]::UtcNow -lt $deadline) {
                        $chunk = Read-LogTailUtf8 $outLog ([ref]$offset)
                        if ($chunk.Contains($script:ReloadMarker)) { $markerMs = $timer.Elapsed.TotalMilliseconds; break }
                        Start-Sleep -Milliseconds 100
                    }
                    if ($null -eq $markerMs) { throw 'Reload diagnostic marker missing' }
                } elseif ($response -notmatch 'There are 0 of a max of \d+ players online:') { throw 'Query control response invalid' }
                $rows += @{pair=$pair;command=$command;startedUtc=$started;returnedUtc=$returned;rconMs=$rconMs;markerMs=$markerMs;response=$response}
                $rows | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $OutDir 'observations.json') -Encoding UTF8
            }
        }
    } finally {
        if ($recording) {
            & "$javaRoot\bin\jcmd.exe" $gameId JFR.stop name=reloadStages ("filename=" + (Join-Path $OutDir 'reload.jfr')) | Set-Content (Join-Path $OutDir 'jfr-stop.txt')
            $recording = $false
        }
        $stop = Stop-Server $proc
    }
    @{stopSent=$true;stopChannel=$stop.channel;killed=$stop.killed}
}
$session | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $OutDir 'session.json') -Encoding UTF8
if ($session.forcedKill -or $session.extra.killed -or $session.extra.stopChannel -ne 'rcon') { throw 'Diagnostic shutdown was not normal' }
Write-Output 'CANDIDATE_JFR_COMPLETE'
