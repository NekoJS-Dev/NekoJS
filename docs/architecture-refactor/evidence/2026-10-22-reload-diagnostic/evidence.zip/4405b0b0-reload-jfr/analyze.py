"""Restrict JFR analysis to recorded reload command windows."""
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
session = root / 'session'
rows = json.loads((session / 'observations.json').read_text(encoding='utf-8-sig'))
assert len(rows) == 20
reloads = [row for row in rows if row['command'] == 'nekojs reload']
(root / 'windows.tsv').write_text(''.join(row['startedUtc']+'\t'+row['returnedUtc']+'\n' for row in reloads), encoding='utf-8')
old = root.parent / 'existing-cpu-jfr-analysis/ExistingCpuJfrAnalysis.java'
source = old.read_text(encoding='utf-8')
source = source.replace('Map<String,Long> leaves = ', 'Map<String,Long> inclusive = new HashMap<>(), nearest = new HashMap<>(), stacks = new HashMap<>();\n        Map<String,Long> leaves = ')
source = source.replace('                samples++;', '''                samples++;
                boolean firstNeko = true;
                var unique = new HashSet<String>();
                var fullStack = new ArrayList<String>();
                for (var frame : frames) {
                    var method = frame.getMethod();
                    String label = method.getType().getName()+"."+method.getName()+":"+frame.getLineNumber();
                    fullStack.add(label);
                    if (label.startsWith("com.tkisor.nekojs.")) {
                        unique.add(label);
                        if (firstNeko) nearest.merge(label, 1L, Long::sum);
                        firstNeko = false;
                    }
                }
                for (String label : unique) inclusive.merge(label, 1L, Long::sum);
                stacks.merge(String.join("\\n", fullStack), 1L, Long::sum);''')
source = source.replace('result.put("serverRootSamples",samples);', '''result.put("serverRootSamples",samples);
        result.put("inclusiveNekoFrames",sorted(inclusive));
        result.put("nearestNekoFrames",sorted(nearest));
        result.put("stacks",sorted(stacks));''')
target = root / 'ExistingCpuJfrAnalysis.java'
target.write_text(source, encoding='utf-8', newline='\n')
classpath = (root.parent / 'root-reload-diagnostic-v3/runtime-classpath.txt').read_text().strip()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
classes = root / 'analysis-classes'
classes.mkdir(exist_ok=True)
commands = [[str(java/'javac.exe'), '-cp', classpath, '-d', str(classes), str(target)],
    [str(java/'java.exe'), '-cp', str(classes)+';'+classpath, 'ExistingCpuJfrAnalysis',
        str(session/'reload.jfr'), str(root/'windows.tsv'), str(root/'analysis.json')]]
for i, command in enumerate(commands):
    with (root / f'analysis-{i}.log').open('xb') as out, (root / f'analysis-{i}-stderr.log').open('xb') as err:
        result = subprocess.run(command, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, i
d = json.loads((root/'analysis.json').read_text())
print(json.dumps({key: value for key, value in d.items() if key != 'stacks'}, indent=2))
