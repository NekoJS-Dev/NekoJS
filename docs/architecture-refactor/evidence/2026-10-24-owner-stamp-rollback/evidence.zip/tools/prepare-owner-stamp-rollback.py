"""Bind the existing four-stage rollback rehearsal to the installed method-bound candidate."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
installed = repo / 'build/closeout-owner-stamp-installed'
prep = json.loads((installed / 'preparation-manifest.json').read_text())
revision = '6e43b82789a7dbf7b9659dc1c21fefecac662649'
assert prep['sourceRevision'] == revision
node = next(row for row in prep['nodes'] if row['node'] == '26.1.2')
artifact = installed / node['node'] / 'mods' / node['artifact']
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == node['sha256'] == '7b0dd1544837cf86ba35ccc4817da40cde54ff7c07544fc3b25fd5437027e8ae'
with zipfile.ZipFile(artifact) as jar:
    for name, digest in node['classBindings'].items():
        assert hashlib.sha256(jar.read(name)).hexdigest() == digest
original = (tools / 'rollback-4405b0b0.py').read_text()
text = original.replace('build/closeout-4405b0b0-rollback', 'build/closeout-owner-stamp-rollback')
text = text.replace('build/closeout-4405b0b0-installed/26.1.2', 'build/closeout-owner-stamp-installed/26.1.2')
text = text.replace("'4405b0b0'", repr(revision)).replace('29331 + index * 10', '32631 + index * 10')
assert original != text and '4405b0b0' not in text
output = tools / 'rollback-owner-stamp.py'
assert not output.exists()
output.write_text(text, encoding='utf-8', newline='\n')
(tools / 'owner-stamp-rollback-binding.json').write_text(json.dumps(dict(
    sourceRevision=revision, candidate=node, originalToolSha256=hashlib.sha256(original.encode()).hexdigest(),
    preparedToolSha256=hashlib.sha256(output.read_bytes()).hexdigest(),
    scope='Same four-stage public pdata and physical world proof; fresh owned directories and ports.'), indent=2) + '\n')
print(json.dumps(dict(prepared=True, classBindings=len(node['classBindings']), candidateSha256=node['sha256'])))
