import json
import os
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
helpers = root / 'build/ticket37-config-sync-repair'
revision = '7d77308bfa400721304b20940ada91092180a1ed'
work = root / ('build/ticket37-perf-' + revision[:8])
assert json.loads((helpers / 'node-assert-performance-runner-exit.json').read_text())['exitCode'] == 0
env = dict(os.environ)
env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
with (work / 'final-owned-guard.txt').open('xb') as output:
    result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                             str(helpers / 'guard-node-assert-performance.ps1')], env=env, stdout=output,
                            stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
(work / 'final-owned-guard-exit.json').write_text(json.dumps(dict(exitCode=result.returncode)))
assert result.returncode == 0
text = (helpers / 'archive-manual-item-performance.py').read_text()
text = text.replace('63d538dc14e7d7cdcf00f6217c5617fd285e7933', revision)
text = text.replace('ticket37-perf-63d538dc', 'ticket37-perf-' + revision[:8])
text = text.replace('manual-item-performance', 'node-assert-performance')
text = text.replace('ticket37-manual-item-installed', 'ticket37-node-assert-installed')
text = text.replace('ticket37-manual-item-repair', 'ticket37-node-assert-repair')
target = helpers / 'archive-node-assert-performance.py'
assert not target.exists()
target.write_text(text)
print(target)
