import json
import os
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
helpers = root / 'build/ticket37-config-sync-repair'
installed = root / 'build/ticket37-node-assert-installed'
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision == '7d77308bfa400721304b20940ada91092180a1ed'
for name in ('runner', 'proof-runner', 'ide-runner'):
    assert json.loads((installed / (name + '-exit.json')).read_text())['exitCode'] == 0
for row in json.loads((installed / 'preparation-manifest.json').read_text())['nodes']:
    assert json.loads((installed / row['node'] / 'server-exit.json').read_text())['exitCode'] == 0
assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'common/src/main', 'src/main'], text=True).strip()
for name in ('prepare-manual-item-performance.ps1', 'guard-manual-item-performance.ps1', 'run-manual-item-performance.py'):
    text = (helpers / name).read_text()
    text = text.replace('63d538dc14e7d7cdcf00f6217c5617fd285e7933', revision)
    text = text.replace('ticket37-perf-63d538dc', 'ticket37-perf-' + revision[:8])
    text = text.replace('manual-item-performance', 'node-assert-performance')
    target = helpers / name.replace('manual-item-performance', 'node-assert-performance')
    assert not target.exists()
    target.write_text(text)
env = dict(os.environ)
env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                         str(helpers / 'prepare-node-assert-performance.ps1')], env=env,
                        creationflags=subprocess.CREATE_NO_WINDOW)
(helpers / 'node-assert-performance-preparation-exit.json').write_text(json.dumps(dict(exitCode=result.returncode, sourceRevision=revision)))
raise SystemExit(result.returncode)
