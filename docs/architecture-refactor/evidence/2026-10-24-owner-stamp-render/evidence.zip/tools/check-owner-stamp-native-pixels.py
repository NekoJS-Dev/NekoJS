"""Run the already-derived numeric checks after all thirty originals were actually viewed."""
import json
from pathlib import Path
import subprocess
import sys

tools = Path(__file__).resolve().parent
for short, count in [('121', 16), ('261', 7), ('262', 7)]:
    root = tools / f'posteffects-{short}-installed-6e43b827-v1'
    review = json.loads((root / 'agent-image-review.json').read_text(encoding='utf-8'))
    assert len(review['images']) == count and review['maintainerAcceptance'] is False
    assert review['originalRunScreenshotsReviewed'] is False
    with (tools / f'owner-stamp-native-{short}-pixel-review.log').open('xb') as output:
        code = subprocess.run([sys.executable, str(tools / f'review-owner-stamp-native-{short}.py')],
            stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW).returncode
    assert code == 0, short
    print('CURRENT_PIXEL_AND_SOURCE_REVIEW_PASS', short, flush=True)
