"""Record the primary agent's completed viewing of the fourteen original modern PNGs."""
import hashlib
import json
from pathlib import Path

tools = Path(__file__).resolve().parent
expected = ['clear-before', 'effect-before', 'clear-after', 'effect-after',
            'retained-rejected', 'clear-recovered', 'effect-recovered']
for short in ['261', '262']:
    root = tools / f'posteffects-{short}-installed-6e43b827-v1'
    manifest = json.loads((root / 'artifact-manifest.json').read_text(encoding='utf-8'))
    run = json.loads((root / 'run-result.json').read_text(encoding='utf-8'))
    assert [stage['step'] for stage in run['stages']] == expected
    assert run['screenshotsReviewed'] is False
    images = []
    for stage in run['stages']:
        path = root / stage['image']
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest == stage['sha256']
        images.append(dict(name=path.name, sha256=digest))
    review = dict(candidateSourceRevision=manifest['sourceRevision'],
        reviewer='main agent; each original PNG viewed through view_image',
        maintainerAcceptance=False, verdict='PASS within the stated frame scope', images=images,
        observations=['Clear-before, clear-after and clear-recovered show sharp wall stripes and ground texture.',
            'Effect-before, effect-after and effect-recovered show blurred wall stripes and ground texture.',
            'The rejected-candidate retained frame remains blurred.',
            'Native chat, tutorial and HUD remain visible outside the tested wall; originals were not cropped or changed.'],
        limits=['Agent visual review only; not maintainer acceptance or physical display presentation.'],
        originalRunScreenshotsReviewed=run['screenshotsReviewed'])
    target = root / 'agent-image-review.json'
    assert not target.exists()
    target.write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(dict(node=short, originalImagesViewed=len(images), maintainerAcceptance=False)))
