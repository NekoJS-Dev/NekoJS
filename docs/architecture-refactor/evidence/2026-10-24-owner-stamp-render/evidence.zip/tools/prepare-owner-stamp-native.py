"""Replay the established installed-client render proofs with fresh current-candidate inputs."""
import hashlib
import json
from pathlib import Path
import shutil
import socket
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
installed = repo / 'build/closeout-owner-stamp-installed'
prep = json.loads((installed / 'preparation-manifest.json').read_text(encoding='utf-8'))
assert prep['sourceRevision'] == '6e43b82789a7dbf7b9659dc1c21fefecac662649'
for short, node, version, old_port, port, runner in [
    ('121', '1.21.1', 'v2', 29491, 32991, 'run-posteffects-121-installed-v2.py'),
    ('261', '26.1.2', 'v1', 29591, 33091, 'run-posteffects-261-4405b0b0.py'),
    ('262', '26.2.0', 'v1', 29691, 33191, 'run-posteffects-262-4405b0b0.py')]:
    source = tools / f'posteffects-{short}-installed-4405b0b0-{version}'
    root = tools / f'posteffects-{short}-installed-6e43b827-v1'
    assert not root.exists()
    for number in [port, port + 1]:
        with socket.socket() as check:
            check.bind(('127.0.0.1', number))
    row = next(value for value in prep['nodes'] if value['node'] == node)
    root.mkdir()
    for name in ['settings.gradle', 'build.gradle']:
        (root / name).write_text((source / name).read_text(encoding='utf-8').replace(source.name, root.name)
                                .replace(str(old_port), str(port)), newline='\n')
    shutil.copytree(source / 'src', root / 'src')
    artifacts = {}
    for side in ['server', 'client']:
        for folder in ['config', 'startup_scripts', side + '_scripts']:
            shutil.copytree(source / side / 'nekojs' / folder, root / side / 'nekojs' / folder,
                            ignore=shutil.ignore_patterns('*.rejected*'))
        (root / side / 'mods').mkdir()
        for dependency in (source / side / 'mods').glob('*.jar'):
            if not dependency.name.startswith('nekojs-'):
                shutil.copyfile(dependency, root / side / 'mods' / dependency.name)
        artifact = installed / node / 'mods' / row['artifact']
        if side == 'client' and node == '1.21.1':
            artifact = repo / 'versions/1.21.1/build/libs' / row['artifact'].replace('-server.jar', '.jar')
        digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
        if side == 'server':
            assert digest == row['sha256']
        with zipfile.ZipFile(artifact) as archive:
            for name, expected in row['classBindings'].items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == expected, (node, side, name)
        shutil.copyfile(artifact, root / side / 'mods' / artifact.name)
        artifacts[side] = dict(name=artifact.name, sha256=digest)
    (root / 'client/nekojs/data').mkdir()
    (root / 'client/nekojs/data/step.txt').write_text('idle')
    shutil.copyfile(source / 'client/options.txt', root / 'client/options.txt')
    shutil.copyfile(source / 'server/eula.txt', root / 'server/eula.txt')
    properties = (source / 'server/server.properties').read_text(encoding='utf-8').replace(str(old_port), str(port)).replace(str(old_port + 1), str(port + 1))
    properties = '\n'.join(line for line in properties.splitlines() if not line.startswith('pause-when-empty-seconds='))
    (root / 'server/server.properties').write_text(properties + '\npause-when-empty-seconds=-1\n')
    (root / 'server/libraries').symlink_to((source / 'server/libraries').resolve(), target_is_directory=True)
    (root / 'artifact-manifest.json').write_text(json.dumps(dict(sourceRevision=prep['sourceRevision'],
        nodeClassBindings=row['classBindings'], artifacts=artifacts), indent=2) + '\n')
    (root / 'preparation.json').write_text(json.dumps(dict(sourceRevision=prep['sourceRevision'], node=node,
        freshWorld=True, priorSuccessfulFixture=source.name, oldPort=old_port, newPort=port,
        emptyServerPauseSeconds=-1, stageContract='Existing 16 legacy / 7 modern stages unchanged.'), indent=2) + '\n')
    text = (tools / runner).read_text(encoding='utf-8').replace(source.name, root.name)
    target = tools / f'run-owner-stamp-native-{short}.py'
    assert not target.exists()
    target.write_text(text, newline='\n')
    print(json.dumps(dict(node=node, prepared=True, artifacts=artifacts, classes=len(row['classBindings']))))
