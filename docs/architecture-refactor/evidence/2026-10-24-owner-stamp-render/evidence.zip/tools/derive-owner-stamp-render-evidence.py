"""Rebind the existing render archive and pixel verifier to this exact candidate."""
import ast
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
def current(source):
    source = source.replace('975496d3bddf6fc76b206921a1d09207120ca24d', '6e43b82789a7dbf7b9659dc1c21fefecac662649')
    source = source.replace('975496d3', '6e43b827').replace('method-bounds', 'owner-stamp')
    source = source.replace('2026-10-24-candidate-render', '2026-10-24-owner-stamp-render')
    source = source.replace('2026-10-24-candidate-tcp', '2026-10-24-owner-stamp-tcp')
    source = source.replace('== 1100', '== 1101').replace('(1570 if short', '(1571 if short').replace('else 1641)', 'else 1642)')
    source = source.replace('.read_text()', ".read_text(encoding='utf-8')")
    return source
source = current((tools / 'seal-method-bounds-native.py').read_text(encoding='utf-8'))
source = source.replace("'review-owner-stamp-native.py',", "'check-owner-stamp-native-pixels.py', 'record-owner-stamp-modern-image-review.py', 'derive-owner-stamp-native.py', 'derive-owner-stamp-render-evidence.py',")
source = source.replace('owner-stamp-runtime-binding-v3.log', 'owner-stamp-native-runtime-binding.log')
source = source.replace('owner-stamp-native-controller.log', 'owner-stamp-native-driver.log')
ast.parse(source)
target = tools / 'seal-owner-stamp-native.py'
assert not target.exists()
target.write_text(source, encoding='utf-8', newline='\n')
source = current((repo / 'docs/architecture-refactor/evidence/2026-10-24-candidate-render/verify.py').read_text(encoding='utf-8'))
ast.parse(source)
target = tools / 'owner-stamp-render-evidence-verify.py'
assert not target.exists()
target.write_text(source, encoding='utf-8', newline='\n')
print('Derived unchanged pixel thresholds, 30-frame and 13-native-key checks for the exact current artifacts.')
