"""Execute the three installed-client render proofs serially after protocol acceptance finishes."""
import json
from pathlib import Path
import subprocess
import sys

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
for short in ['261', '262']:
    review = tools / f'dynamic-basic-6e43b827-{short}-v1/acceptance-review.json'
    assert json.loads(review.read_text(encoding='utf-8'))['verdict'] == 'PASS'
for short in ['121', '261', '262']:
    with (tools / f'owner-stamp-native-{short}-run.log').open('xb') as log:
        code = subprocess.run([sys.executable, str(tools / f'run-owner-stamp-native-{short}.py')],
            stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW).returncode
    result = json.loads((tools / f'posteffects-{short}-installed-6e43b827-v1/run-result.json').read_text(encoding='utf-8'))
    assert code == 0 and result['mechanicalVerdict'] == 'PASS'
    assert not result['errors'] and not result['forced'] and result['clientExit'] == result['serverExit'] == 0
    print('CURRENT_INSTALLED_RENDER_MECHANICAL_PASS', short, len(result['stages']), flush=True)
