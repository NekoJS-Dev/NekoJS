"""Prepare the original installed-client stages for the frozen six-artifact candidate."""
from pathlib import Path

root = Path(__file__).resolve().parent
names = ['prepare-method-bounds-native.py', 'run-method-bounds-native-all.py',
         'review-method-bounds-native-121.py', 'review-method-bounds-native-261.py',
         'review-method-bounds-native-262.py', 'review-method-bounds-native.py']
for name in names:
    source = (root / name).read_text(encoding='utf-8')
    source = source.replace('975496d3bddf6fc76b206921a1d09207120ca24d', '6e43b82789a7dbf7b9659dc1c21fefecac662649')
    source = source.replace('975496d3', '6e43b827').replace('method-bounds', 'owner-stamp')
    source = source.replace('29491, 31091', '29491, 32991').replace('29591, 31191', '29591, 33091')
    source = source.replace('29691, 31291', '29691, 33191')
    source = source.replace('.read_text()', ".read_text(encoding='utf-8')")
    target = root / name.replace('method-bounds', 'owner-stamp')
    assert not target.exists()
    target.write_text(source, encoding='utf-8', newline='\n')
print('Prepared new helper scripts; original 16/7/7 render stages and assertions retained.')
