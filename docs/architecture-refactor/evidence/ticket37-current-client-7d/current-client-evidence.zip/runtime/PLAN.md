# Current 7d multiplayer/client acceptance

Exact official NF26.2 JAR, three SHA/class-bound copies, fresh owned world/profiles,
synthetic clients A/B, server25991/RCON25992, no HTTP bridge, no native window/input
automation. Launch through hidden console subprocesses; game renderer may create
windows, no separate OS desktop is claimed. Native owner-tick Screenshot.grab
after ten ticks yields actual pixels; it does not prove the first rendered frame.

Read both real joins/configuration catch-ups, build deterministic contrast scene,
capture clear/blur pairs before and after resource reload and candidate failure/
recovery. Run actual server dynamic reload with two ACKs/activated reports. Preserve
every failure/direct exit. Normal tick-owner client stop and server RCON stop.
Remaining abort/join barrier/pack download/other-node clients/first pixel are separate
acceptances. No production/security edits or unrelated desktop/process operations.
No maintainer or release PASS. Raw worlds/credentials/arguments/crash files local.
