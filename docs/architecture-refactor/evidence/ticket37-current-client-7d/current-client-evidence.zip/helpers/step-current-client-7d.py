import hashlib
import json
import sys
import time
from pathlib import Path

root = Path.cwd().resolve() / 'build/ticket37-current-client-7d'
letter, step = sys.argv[1:]
assert letter in ('A', 'B')
assert step == 'reload' or step.startswith(('clear-', 'vanilla-'))
client = root / ('client' + letter)
before = set((client / 'screenshots').glob('*.png'))
signal = client / 'nekojs/data/visual-step.txt'
pending = signal.with_suffix('.pending')
pending.write_text(step + '\n', encoding='ascii')
pending.replace(signal)
started = time.monotonic()
new = []
while time.monotonic() - started < 60:
    new = sorted(set((client / 'screenshots').glob('*.png')) - before)
    if step == 'reload':
        log = (client / 'stdout.log').read_text(encoding='utf-8', errors='replace')
        if signal.read_text().strip() == 'idle' and 'SEMANTIC-RESOURCE-RELOAD requested=true' in log:
            break
    elif new and new[0].stat().st_size > 100:
        break
    if (client / 'exit.json').exists():
        break
    time.sleep(0.1)
row = dict(client=letter, step=step, seconds=round(time.monotonic()-started,3),
    screenshots=[dict(file=path.name, bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in new],
    result='REQUESTED' if step == 'reload' and signal.read_text().strip() == 'idle' else 'PASS' if new else 'FAIL',
    firstPixelFrame=False)
with (root / 'native-captures.jsonl').open('a', encoding='utf-8') as output:
    output.write(json.dumps(row) + '\n')
print(json.dumps(row))
sys.exit(1 if row['result'] == 'FAIL' else 0)
