from pathlib import Path

helpers = Path.cwd() / 'build/ticket37-config-sync-repair'
path = helpers / 'await-current-client-generation.py'
assert not path.exists()
source = (helpers / 'await-semantic-generation.py').read_text(encoding='utf-8').replace('ticket37-semantic-pair-d109', 'ticket37-current-client-7d')
source = source.replace("read_text(errors='replace')", "read_text(encoding='utf-8', errors='replace')")
path.write_text(source, encoding='utf-8')
