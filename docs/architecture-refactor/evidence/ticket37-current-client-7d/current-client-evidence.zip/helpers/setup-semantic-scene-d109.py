import subprocess
import sys
from pathlib import Path

root = Path.cwd().resolve()
script = root / 'build/ticket37-config-sync-repair/rcon-semantic-pair-d109.py'
commands = ['time set noon', 'weather clear', 'fill -2 72 -13 18 84 -1 air',
            'fill -2 71 -14 18 71 1 stone', 'fill 0 72 0 16 82 0 black_concrete']
commands += ['fill ' + str(x) + ' 72 0 ' + str(x+1) + ' 82 0 white_concrete' for x in (2,6,10,14)]
commands += ['tp NekoClient93A 8.5 72 -12.5 0 0', 'tp NekoClient93B 5.5 72 -12.5 0 0']
for command in commands:
    result = subprocess.run([sys.executable, str(script), command], creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0
