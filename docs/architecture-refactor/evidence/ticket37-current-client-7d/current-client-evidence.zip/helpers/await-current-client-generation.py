import json
import sys
import time
from pathlib import Path

root = Path.cwd().resolve() / 'build/ticket37-current-client-7d'
generation = int(sys.argv[1])
letters = sys.argv[2:] or ['A', 'B']
started = time.monotonic()
ready = False
while time.monotonic() - started < 45:
    records = {}
    for letter in letters:
        rows = []
        for line in (root / ('client' + letter) / 'stdout.log').read_text(encoding='utf-8', errors='replace').splitlines():
            if 'SEMANTIC-FIRST-HUD ' in line:
                rows.append(json.loads(line.split('SEMANTIC-FIRST-HUD ',1)[1]))
        records[letter] = rows
    ready = all(any(row['generation'] == generation and row['declared'] for row in rows) for rows in records.values())
    if ready:
        break
    time.sleep(0.1)
row = dict(generation=generation, clients=records, seconds=round(time.monotonic()-started,3), result='PASS' if ready else 'FAIL')
with (root / 'generation-awaits.jsonl').open('a', encoding='utf-8') as output:
    output.write(json.dumps(row) + '\n')
print(json.dumps(row))
sys.exit(0 if ready else 1)
