from pathlib import Path
import subprocess
import sys

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
root = project / 'build/ticket37-semantic-pair-d109'
assert not root.exists()
sources = {
    'prepare-pair-profiles-d109.py': 'prepare-semantic-profiles-d109.py',
    'run-native-pair-d109.py': 'run-semantic-pair-d109.py',
    'rcon-native-pair-d109.py': 'rcon-semantic-pair-d109.py',
    'close-native-pair-d109.py': 'close-semantic-pair-d109.py',
    'setup-pair-scene-d109.py': 'setup-semantic-scene-d109.py',
}
for original, target in sources.items():
    destination = helpers / target
    assert not destination.exists()
    text = (helpers / original).read_text(encoding='utf-8')
    text = text.replace('ticket37-native-pair-d109', 'ticket37-semantic-pair-d109')
    text = text.replace('25983', '25985').replace('25984', '25986')
    text = text.replace('rcon-native-pair-d109.py', 'rcon-semantic-pair-d109.py')
    destination.write_text(text, encoding='utf-8')
subprocess.run([sys.executable, str(helpers / sources['prepare-pair-profiles-d109.py'])], check=True)
for letter in ('A', 'B'):
    client = root / ('client' + letter)
    signal = str(client / 'nekojs/data/visual-step.txt').replace('\\', '/')
    fixture = '''const visualFs = require('node:fs');
const Minecraft = Java.type('net.minecraft.client.Minecraft');
const Screenshot = Java.type('net.minecraft.client.Screenshot');
const signal = '__SIGNAL__';
let previous = '';
let pendingCapture = null;
let captureTicks = 0;
let firstHud = false;
ClientEvents.postEffects(event => {
    event.register('minecraft:invert', { blurRadius: 16, blurRounds: 1 });
    event.register('ticket37_client93:inline_blur', { blurRadius: 16, blurRounds: 1 });
});
ClientEvents.hud(() => {
    if (firstHud) return;
    firstHud = true;
    console.info('SEMANTIC-FIRST-HUD ' + JSON.stringify({ generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('ticket37_client93:inline_blur') }));
});
ClientEvents.tickPost(() => {
    const minecraft = Minecraft.getInstance();
    if (minecraft.player === null || !visualFs.existsSync(signal)) return;
    const step = String(visualFs.readFileSync(signal, 'utf8')).trim();
    if (step !== previous) {
        previous = step;
        if (step === 'close') {
            console.info('LIFECYCLE-OWNED-STOP requested=true');
            minecraft.stop();
            return;
        }
        if (step === 'reload') {
            visualFs.writeFileSync(signal, 'idle\\n');
            console.info('SEMANTIC-RESOURCE-RELOAD requested=true');
            minecraft.reloadResourcePacks();
            return;
        }
        if (step.startsWith('clear-') || step.startsWith('vanilla-')) {
            const accepted = step.startsWith('vanilla-') ? PostEffects.set('minecraft:invert') : PostEffects.clear();
            console.info('SEMANTIC-VISUAL-STEP ' + JSON.stringify({ step, accepted, generation: PostEffects.activeGeneration(), current: PostEffects.current(), active: PostEffects.isActive() }));
            pendingCapture = step;
            captureTicks = 0;
        }
    }
    if (pendingCapture !== null && ++captureTicks === 10) {
        console.info('SEMANTIC-NATIVE-CAPTURE ' + JSON.stringify({ step: pendingCapture, generation: PostEffects.activeGeneration(), current: PostEffects.current(), active: PostEffects.isActive() }));
        Screenshot.grab(minecraft, false);
        pendingCapture = null;
    }
});
'''.replace('__SIGNAL__', signal)
    (client / 'nekojs/client_scripts/visual-proof.js').write_text(fixture, encoding='utf-8')
(root / 'SEMANTIC-PLAN.md').write_text('''# Concurrent semantic game acceptance

Exact current d109 official JAR, no bridge, no cross-process Sky activation.
Fresh owned server/world, synthetic clients A/B, ports25985/25986.
Read real joins and configuration catch-ups. Set a deterministic contrast
wall through owned RCON. Request native Minecraft Screenshot.grab(mc,false)
on each client tick owner after ten ticks, without a guest async consumer.
Capture clear/blur before and after resource reload. Force one invalid local
CLIENT candidate, retain prior generation, remove only that owned fixture,
reload and verify recovery. Then real two-client server dynamic reload,
actual ACK/activation reports, readback and normal owner-thread/RCON exits.
No first-pixel, all-node, pack-download or human conclusion inferred.
Keep all failures; no world, credentials, binary artifacts or raw hs_err in Git.
Inherited PLAN is a template, not this run's plan.
''', encoding='utf-8')
print('SEMANTIC_PAIR_PREPARED')
