import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
work = project / 'build/ticket37-current-client-7d'
assert not work.exists()
production = '7d77308bfa400721304b20940ada91092180a1ed'
artifact_sha = '2a64c34ca2d7abc3e8b2cd6402b17f204b3c10b4d15fcd1c2ebc917b3dd9aff2'
def adapt(text):
    return text.replace('ticket37-semantic-pair-d109', 'ticket37-current-client-7d').replace('25985', '25991').replace('25986', '25992').replace('NekoClient93', 'NekoClient7d')
source = adapt((helpers / 'prepare-semantic-profiles-d109.py').read_text(encoding='utf-8'))
source = source.replace('d10912ebbf24d9d5df75a908dc7a5529da09979a', production)
source = source.replace('ticket37-same-name-import-installed', 'ticket37-node-assert-installed')
source = source.replace('fde6c16ba1b6fbca43dfc87aff4bf9709c1925bcb2d72c307f2e73346922f092', artifact_sha)
exec(compile(source, str(helpers / 'prepare-semantic-profiles-d109.py'), 'exec'))
runtime = json.loads((project / 'docs/architecture-refactor/evidence/ticket37-node-assert-repair/runtime-summary.json').read_text())
entry = next(node for node in runtime['nodes'] if node['node'] == '26.2.0')
assert entry['sha256'] == artifact_sha and len(entry['classBindings']) == 1592
for directory in ('server', 'clientA', 'clientB'):
    artifact = work / directory / 'mods' / entry['artifact']
    assert hashlib.sha256(artifact.read_bytes()).hexdigest() == artifact_sha
    with ZipFile(artifact) as jar:
        for name, digest in entry['classBindings'].items():
            assert hashlib.sha256(jar.read(name)).hexdigest() == digest, name
    assert not list((work / directory / 'mods').glob('*mcp*'))
for letter in ('A', 'B'):
    old = project / 'build/ticket37-semantic-pair-d109' / ('client' + letter) / 'nekojs/client_scripts/visual-proof.js'
    fixture = adapt(old.read_text(encoding='utf-8'))
    assert 'Screenshot.grab(minecraft, false)' in fixture
    assert 'pauseOnLostFocus = false' in fixture and 'showScreen(null)' in fixture
    assert 'SEMANTIC-NATIVE-CAPTURE' in fixture
    (work / ('client' + letter) / 'nekojs/client_scripts/visual-proof.js').write_text(fixture, encoding='utf-8')
    options = work / ('client' + letter) / 'options.txt'
    options.write_text(options.read_text(encoding='utf-8') + 'pauseOnLostFocus:false\n', encoding='utf-8')
for original, target in [('run-semantic-pair-d109.py', 'run-current-client-7d.py'),
                         ('rcon-semantic-pair-d109.py', 'rcon-current-client-7d.py'),
                         ('close-semantic-pair-d109.py', 'close-current-client-7d.py'),
                         ('setup-semantic-scene-d109.py', 'setup-current-scene-7d.py'),
                         ('step-semantic-pair-d109.py', 'step-current-client-7d.py')]:
    destination = helpers / target
    assert not destination.exists()
    text = adapt((helpers / original).read_text(encoding='utf-8')).replace('rcon-semantic-pair-d109.py', 'rcon-current-client-7d.py')
    destination.write_text(text, encoding='utf-8')
preparation = json.loads((work / 'preparation.json').read_text())
preparation['classBindings'] = entry['classBindings']
preparation['installedCopies'] = 3
preparation['httpBridgeInstalled'] = False
preparation['crossProcessWindowActivation'] = False
(work / 'preparation.json').write_text(json.dumps(preparation, indent=2), encoding='utf-8')
(work / 'PLAN.md').write_text('''# Current 7d multiplayer/client acceptance

Exact official NF26.2 JAR, three SHA/class-bound copies, fresh owned world/profiles,
synthetic clients A/B, server25991/RCON25992, no HTTP bridge, no native window/input
automation. Launch through hidden console subprocesses; game renderer may create
windows, no separate OS desktop is claimed. Native owner-tick Screenshot.grab
after ten ticks yields actual pixels; it does not prove the first rendered frame.

Read both real joins/configuration catch-ups, build deterministic contrast scene,
capture clear/blur pairs before and after resource reload and candidate failure/
recovery. Run actual server dynamic reload with two ACKs/activated reports. Preserve
every failure/direct exit. Normal tick-owner client stop and server RCON stop.
Remaining abort/join barrier/pack download/other-node clients/first pixel are separate
acceptances. No production/security edits or unrelated desktop/process operations.
No maintainer or release PASS. Raw worlds/credentials/arguments/crash files local.
''', encoding='utf-8')
print(json.dumps(dict(result='PREPARED', productionRevision=production, artifactSha256=artifact_sha, installedCopies=3, classBindings=1592, bridge=False)))
