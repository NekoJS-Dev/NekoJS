import hashlib
import io
import json
import shutil
import socket
import subprocess
import zipfile
from pathlib import Path
from PIL import Image

project = Path.cwd().resolve()
root = project / 'build/ticket37-semantic-pair-d109'
destination = project / 'docs/architecture-refactor/evidence/ticket37-semantic-pair-d109'
assert not destination.exists()
destination.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {}
def add(path, name):
    assert name not in entries
    entries[name] = path.read_bytes()
def readings(letter, marker):
    text = (root / ('client' + letter) / 'stdout.log').read_text(errors='replace')
    return [json.loads(line.split(marker + ' ',1)[1]) for line in text.splitlines() if marker + ' ' in line]

for port in (25985,25986):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1',port))
exits = {node:json.loads((root/node/'exit.json').read_text())['exitCode'] for node in ('server','clientA','clientB')}
assert all(code == 0 for code in exits.values())
assert not list(root.glob('client*/hs_err*'))
secret = dict(line.split('=',1) for line in (root/'server/server.properties').read_text().splitlines() if '=' in line)['rcon.password'].encode()
bindings = {}
artifact_sha = 'fde6c16ba1b6fbca43dfc87aff4bf9709c1925bcb2d72c307f2e73346922f092'
for node in ('server','clientA','clientB'):
    path = root/node/'mods/nekojs-neoforge-26.2.0-1.1.0-preview3.jar'
    assert sha(path.read_bytes()) == artifact_sha
    with zipfile.ZipFile(path) as jar:
        for name in jar.namelist():
            if not name.startswith('com/tkisor/nekojs/') or not name.endswith('.class'):
                continue
            options = [project/'versions/26.2.0/build/classes/java/main'/name, project/'common/build/classes/java/main'/name]
            compiled = next((p for p in options if p.is_file()),None)
            if compiled is not None:
                digest = sha(jar.read(name))
                assert digest == sha(compiled.read_bytes())
                if node == 'server': bindings[name] = digest
assert len(bindings) == 1592
captures = [json.loads(line) for line in (root/'native-captures.jsonl').read_text().splitlines()]
images = [row for row in captures if row['screenshots']]
assert len(images) == 18
hud = {letter:readings(letter,'SEMANTIC-FIRST-HUD') for letter in ('A','B')}
steps = {letter:readings(letter,'SEMANTIC-NATIVE-CAPTURE') for letter in ('A','B')}
for letter in ('A','B'):
    assert [row['generation'] for row in hud[letter]] == [1,2,3,4,5]
    rejected = next(row for row in steps[letter] if row['step']=='vanilla-rejected')
    assert rejected['generation']==4 and rejected['active'] and rejected['current']=='minecraft:invert'
    assert '[NEKO-1008]' in (root/('client'+letter)/'stdout.log').read_text(errors='replace')
text = (root/'server/stdout.log').read_text(errors='replace')
sync = [json.loads(line.split('CONFIG-SYNC-PROOF ',1)[1]) for line in text.splitlines() if 'CONFIG-SYNC-PROOF ' in line][-1]
assert sync['status']=='COMMITTED' and sync['activatedGeneration']==3
for outcome in ('ack','activation-report'):
    assert len({row['participant'] for row in sync['outcomes'] if row['generation']==3 and row['outcome']==outcome})==2
pixel_pairs = []
def edge(data):
    with Image.open(io.BytesIO(data)) as original:
        original.verify()
    with Image.open(io.BytesIO(data)) as original:
        frame = original.convert('RGB')
        assert frame.size == (854,480)
        return max(sum(abs(a-b) for a,b in zip(frame.getpixel((x,180)),frame.getpixel((x+1,180)))) for x in range(170,519))
for letter in ('A','B'):
    for phase,generation in (('corrected',3),('after-reload',4),('recovered',5)):
        pair = {}
        for mode in ('clear','vanilla'):
            row = next(row for row in images if row['client']==letter and row['step']==mode+'-'+phase)
            image_row = row['screenshots'][0]
            path = root/('client'+letter)/'screenshots'/image_row['file']
            assert sha(path.read_bytes())==image_row['sha256']
            state = next(value for value in steps[letter] if value['step']==row['step'])
            assert state['generation']==generation and state['active']==(mode=='vanilla')
            pair[mode] = dict(file=image_row['file'], sha256=image_row['sha256'], maximumAdjacentRgbDifference=edge(path.read_bytes()))
        assert pair['clear']['maximumAdjacentRgbDifference'] > pair['vanilla']['maximumAdjacentRgbDifference']
        pixel_pairs.append(dict(client=letter,phase=phase,generation=generation,images=pair,agentVisualInspection='PASS: actual clear wall and blurred wall; no menu/overlay'))
        if phase=='after-reload':
            for mode in ('clear','vanilla'):
                shutil.copyfile(root/('client'+letter)/'screenshots'/pair[mode]['file'],destination/(letter.lower()+'-'+mode+'.png'))
for name in ('preparation.json','PLAN.md','SEMANTIC-PLAN.md','rcon.jsonl','native-captures.jsonl','generation-awaits.jsonl',
             'visual-fixture-A-initial.js','visual-fixture-B-initial.js','owned-rejected-A.fixture.txt','owned-rejected-B.fixture.txt'):
    add(root/name,'runtime/'+name)
for node in ('server','clientA','clientB'):
    for name in ('stdout.log','stderr.log','exit.json','owned-process.json'):
        add(root/node/name,'runtime/'+node+'/'+name)
    for folder in ('startup_scripts','server_scripts','client_scripts'):
        for path in (root/node/'nekojs'/folder).glob('*.js'):
            add(path,'runtime/'+node+'/'+folder+'/'+path.name)
    if node!='server':
        add(root/node/'close-probe.json','runtime/'+node+'/close-probe.json')
        add(root/node/'options.txt','runtime/'+node+'/options.txt')
        for path in (root/node/'screenshots').glob('*.png'):
            add(path,'runtime/'+node+'/screenshots/'+path.name)
helpers = project/'build/ticket37-config-sync-repair'
for name in ('prepare-semantic-pair-d109.py','prepare-semantic-profiles-d109.py','run-semantic-pair-d109.py',
             'rcon-semantic-pair-d109.py','close-semantic-pair-d109.py','setup-semantic-scene-d109.py',
             'step-semantic-pair-d109.py','await-semantic-generation.py','archive-semantic-pair-d109.py'):
    add(helpers/name,'helpers/'+name)
for name,data in entries.items():
    assert secret not in data,name
summary = dict(checkoutRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    productionRevision='d10912ebbf24d9d5df75a908dc7a5529da09979a',artifactSha256=artifact_sha,
    compiledClassBindings=bindings,firstHud=hud,steps=steps,pixelPairs=pixel_pairs,sync=sync,directExits=exits,
    nativeScreenshots=18,firstPairA='FAIL: paused menu, retained original images',
    correctedPixels='PASS: six clear/blur pairs at declaration generations3/4/5',
    rejectedCandidatePixels='PASS: native blur remains at generation4 after real syntax rejection',
    noBridge=True,noCrossProcessSkyActivation=True,firstPixel='NOT_VERIFIED',
    downloadWindow='NOT_RUN',crossNodeClient='NOT_RUN',humanAcceptance='NOT_RECORDED',overall='NOT_COMPLETE')
(destination/'runtime-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
archive = destination/'semantic-pair-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as output:
    for name,data in sorted(entries.items()): output.writestr(name,data)
manifest = dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
    entries=[dict(name=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(entries.items())],
    exclusions=['credentials/server.properties','worlds','launcher argfiles','binary artifacts/native DLLs','raw JFR/hs_err','unrelated user files/screenshots'])
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    assert all(sha(output.read(row['name']))==row['sha256'] for row in manifest['entries'])
print(json.dumps(dict(result='PASS',entries=len(entries),bytes=manifest['bytes'],sha256=manifest['sha256'],pairs=pixel_pairs)))
