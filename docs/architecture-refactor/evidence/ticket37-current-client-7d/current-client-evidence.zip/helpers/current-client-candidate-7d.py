import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd().resolve() / 'build/ticket37-current-client-7d'
helpers = Path.cwd() / 'build/ticket37-config-sync-repair'
mode = sys.argv[1]
assert mode in ('reject', 'recover')
fixture = b'const rejectedCandidate = ;\n'
before = {}
for letter in ('A', 'B'):
    client = root / ('client' + letter)
    source = client / 'nekojs/client_scripts/owned-rejected.js'
    assert source.resolve().is_relative_to(client.resolve()) and not source.is_symlink()
    log = (client / 'stdout.log').read_text(encoding='utf-8', errors='replace')
    before[letter] = len(log)
    if mode == 'reject':
        assert not source.exists()
        (root / ('owned-rejected-' + letter + '.fixture.txt')).write_bytes(fixture)
        source.write_bytes(fixture)
    else:
        assert source.read_bytes() == fixture
        source.unlink()
    result = subprocess.run([sys.executable, str(helpers / 'step-current-client-7d.py'), letter, 'reload'], creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0
started = time.monotonic()
while time.monotonic() - started < 45:
    signals = {letter:(root / ('client' + letter) / 'stdout.log').read_text(encoding='utf-8', errors='replace')[offset:]
               for letter, offset in before.items()}
    if mode == 'reject':
        ready = all('[NEKO-1008]' in text and 'owned-rejected.js' in text for text in signals.values())
    else:
        ready = all('SEMANTIC-FIRST-HUD ' in text for text in signals.values())
    if ready:
        break
    assert not any((root / ('client' + letter) / 'exit.json').exists() for letter in ('A', 'B'))
    time.sleep(0.1)
row = dict(mode=mode, ready=ready, seconds=round(time.monotonic()-started,3),
           fixtureSha256=hashlib.sha256(fixture).hexdigest(), signals=signals)
path = root / (mode + '-candidate.json')
assert not path.exists()
path.write_text(json.dumps(row, indent=2), encoding='utf-8')
print(json.dumps(dict(mode=mode, ready=ready, seconds=row['seconds'])))
sys.exit(0 if ready else 1)
