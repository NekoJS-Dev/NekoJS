import hashlib
import json
import zipfile
from pathlib import Path

p = Path.cwd()
raw = p / 'build/priority-closeout'
trial = raw / 'posteffects-262-installed-d91ca974-v1'
out = p / 'docs/architecture-refactor/evidence/2026-10-22-posteffects-262-installed'
assert not (out / 'evidence.zip').exists()
assert json.loads((trial / 'pixel-review.json').read_text())['verdict'] == 'PASS'
out.mkdir(exist_ok=True)
entries = {}
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    def add(f, name):
        assert name not in entries
        data = f.read_bytes()
        entries[name] = dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
        z.writestr(name, data)
    for f in sorted(trial.iterdir()):
        if f.is_file() and f.suffix in {'.json', '.jsonl', '.log', '.png', '.gradle'}:
            add(f, f.name)
    for f in sorted((trial / 'src').rglob('*')):
        if f.is_file():
            add(f, 'src/' + f.relative_to(trial / 'src').as_posix())
    for side in ['client', 'server']:
        for name in ['stdout.log', 'stderr.log', 'installed-source.json', 'owned-process.json']:
            f = trial / side / name
            if f.exists():
                add(f, side + '/' + name)
        for f in sorted((trial / side / 'nekojs').rglob('*')):
            if f.is_file() and f.suffix in {'.js', '.toml'} and 'data' not in f.relative_to(trial / side / 'nekojs').parts:
                add(f, side + '/nekojs/' + f.relative_to(trial / side / 'nekojs').as_posix())
    for name in ['prepare-262-installed-project.py', 'run-posteffects-262-installed.py',
                 'review-262-installed.py', '262-installed-native-run.log', 'seal-262-installed-native.py']:
        add(raw / name, 'tooling/' + name)
(out / 'manifest.json').write_text(json.dumps(dict(entries=entries,
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    sourceRevision='d91ca974ba88fe3507281b47a3bdb574322c5c9d'), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size)))
