import json
import shutil
from pathlib import Path

p = Path.cwd()
source = p / 'build/priority-closeout/posteffects-261-installed-d91ca974-v2'
root = p / 'build/priority-closeout/posteffects-262-installed-d91ca974-v1'
installed = p / 'build/closeout-d91ca974-installed/26.2.0'
assert not root.exists()
root.mkdir()
shutil.copyfile(source / 'settings.gradle', root / 'settings.gradle')
build = (source / 'build.gradle').read_text().replace(source.name, root.name)
build = build.replace('26.1.2.71', '26.2.0.57').replace('neoforge-26.1.2-', 'neoforge-26.2.0-')
build = build.replace('28691', '29191').replace("jvmArguments.add('-Dnekojs.acceptance.owner=",
    "jvmArguments.add('-Dneoforge.warnings.logofile.hide=true')\n            jvmArguments.add('-Dnekojs.acceptance.owner=")
(root / 'build.gradle').write_text(build)
shutil.copytree(source / 'src', root / 'src')
for side in ['client', 'server']:
    directory = root / side
    for folder in ['config', 'startup_scripts', side + '_scripts']:
        shutil.copytree(source / side / 'nekojs' / folder, directory / 'nekojs' / folder)
    shutil.copytree(installed / 'mods', directory / 'mods')
for folder in ['startup_scripts', 'client_scripts']:
    frame = root / 'client/nekojs' / folder / 'frame.js'
    frame.write_text(frame.read_text().replace('mc.getOverlay()', 'mc.gui.overlay()')
        .replace('mc.getMainRenderTarget()', 'mc.gameRenderer.mainRenderTarget()'))
(root / 'client/nekojs/data').mkdir()
(root / 'client/nekojs/data/step.txt').write_text('idle')
shutil.copyfile(source / 'client/options.txt', root / 'client/options.txt')
shutil.copyfile(source / 'server/eula.txt', root / 'server/eula.txt')
(root / 'server/server.properties').write_text((source / 'server/server.properties').read_text()
    .replace('28691', '29191').replace('28692', '29192'))
(root / 'server/libraries').symlink_to((installed / 'libraries').resolve(), target_is_directory=True)
tcp = p / 'build/priority-closeout/dynamic-tcp-262-d91ca974-v1'
shutil.copyfile(tcp / 'artifact-manifest.json', root / 'artifact-manifest.json')
runner = (p / 'build/priority-closeout/run-posteffects-261-installed-v2.py').read_text()
runner = runner.replace(source.name, root.name).replace('26.1.2.71', '26.2.0.75')
runner = runner.replace('.js.rejected-installed-run', '.js.rejected-installed-262-run')
(p / 'build/priority-closeout/run-posteffects-262-installed.py').write_text(runner)
(root / 'preparation.json').write_text(json.dumps(dict(sourceRevision='d91ca974', freshWorld=True,
    clientLoader='26.2.0.57', serverLoader='26.2.0.75',
    method='Installed NekoJS JAR; independent helper source mod; synthetic native F3T; render-frame screenshots.'), indent=2) + '\n')
print(root)
