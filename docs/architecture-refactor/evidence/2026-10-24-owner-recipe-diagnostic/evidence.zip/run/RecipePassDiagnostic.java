package com.tkisor.nekojs.core.error;

/** Temporary recipe-pass measurements for the owned diagnostic checkout only. */
@jdk.jfr.Name("neko.RecipePass6e")
@jdk.jfr.Label("Recipe pass diagnostic")
@jdk.jfr.StackTrace(false)
public final class RecipePassDiagnostic extends jdk.jfr.Event {
    public int beforeCount;
    public int afterFilterCount;
    public int finalJsonCount;
    public int decodedCount;
    public long filterNanos;
    public long copyNanos;
    public long recipeHooksNanos;
    public long decodeNanos;
    public long mapBuildNanos;
    public long afterHooksNanos;
}
