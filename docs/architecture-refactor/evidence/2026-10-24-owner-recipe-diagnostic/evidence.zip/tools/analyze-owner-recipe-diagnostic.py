"""Associate all recipe passes with observed commands and retain every phase value."""
from collections import Counter
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent / '6e43b827-recipe-diagnostic'
events = json.loads((root / 'events.json').read_text(encoding='utf-8-sig'))['recording']['events']
cpu_events = json.loads((root / 'cpu-events.json').read_text(encoding='utf-8-sig'))['recording']['events']
observations = json.loads((root / 'session/observations.json').read_text(encoding='utf-8-sig'))
session = json.loads((root / 'session/session.json').read_text(encoding='utf-8-sig'))
assert not session['forcedKill'] and not session['extra']['killed'] and session['extra']['stopChannel'] == 'rcon'
assert len(observations) == 20
reloads = [row for row in observations if row['command'] == 'nekojs reload']
assert len(reloads) == len(events) == 10
fields = ['filterNanos', 'copyNanos', 'recipeHooksNanos', 'decodeNanos', 'mapBuildNanos', 'afterHooksNanos']
rows, seen, selected = [], set(), []
inclusive, leaves = Counter(), Counter()
for observation in reloads:
    assert 'phase=COMMIT - no errors.' in observation['response'] and observation['markerMs'] is not None
    start, end = datetime.fromisoformat(observation['startedUtc']), datetime.fromisoformat(observation['returnedUtc'])
    current = [(index, event['values']) for index, event in enumerate(events)
               if start <= datetime.fromisoformat(event['values']['startTime']) <= end]
    assert len(current) == 1
    index, values = current[0]
    assert index not in seen and values['eventThread']['javaName'] == 'Server thread'
    seen.add(index)
    assert [values[key] for key in ['beforeCount', 'afterFilterCount', 'finalJsonCount', 'decodedCount']] == [1515] * 4
    duration = float(values['duration'].removeprefix('PT').removesuffix('S'))
    pass_start = datetime.fromisoformat(values['startTime'])
    pass_end = pass_start + timedelta(seconds=duration)
    row = dict(pair=observation['pair'], markerMs=observation['markerMs'], durationMs=duration * 1000,
               **{field: values[field] for field in fields},
               **{key: values[key] for key in ['beforeCount', 'afterFilterCount', 'finalJsonCount', 'decodedCount']})
    rows.append(row)
    for event in cpu_events:
        sample = event['values']
        thread = sample.get('sampledThread') or sample.get('eventThread') or {}
        if thread.get('javaName') != 'Server thread' or not pass_start <= datetime.fromisoformat(sample['startTime']) <= pass_end:
            continue
        stack = sample.get('stackTrace') or {}
        frames = stack.get('frames') or []
        methods = [frame['method']['type']['name'].replace('/', '.') + '.' + frame['method']['name'] for frame in frames]
        selected.append(dict(pair=observation['pair'], type=event['type'], startTime=sample['startTime'], methods=methods))
        inclusive.update(set(methods))
        if methods:
            leaves[methods[0]] += 1
assert len(seen) == len(events)
result = dict(sourceRevision=json.loads((root / 'binding.json').read_text())['revision'], diagnosticOnly=True,
    successfulReloads=10, controlQueries=10, normalStops=1, recipePasses=10, recipesPerPass=1515,
    rows=rows, meanMs={field: statistics.mean(row[field] for row in rows) / 1e6 for field in fields},
    sampledStacks=len(selected), inclusiveMethods=inclusive.most_common(), leafMethods=leaves.most_common(),
    rawEventsSha256=hashlib.sha256((root / 'events.json').read_bytes()).hexdigest(),
    rawCpuEventsSha256=hashlib.sha256((root / 'cpu-events.json').read_bytes()).hexdigest(),
    limits=['Instrumented ten-reload diagnostic, different cadence and JFR overhead; not a policy sample.',
        'Sample counts are not milliseconds or precise attribution; retain every event and phase value.',
        'One pass per command is established only for this original flat fixture, not directory datapack reloads.',
        'Measurements do not authorize caching mutable recipe instances or changing event and failure timing.'])
(root / 'selected-stacks.json').write_text(json.dumps(selected, indent=2) + '\n')
(root / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['rows', 'limits', 'inclusiveMethods', 'leafMethods']}))
