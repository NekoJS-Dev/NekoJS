"""Instrument recipe passes only in the owned performance checkout."""
import hashlib
import json
from pathlib import Path
import subprocess

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = tools / '6e43b827-recipe-diagnostic'
revision = '6e43b82789a7dbf7b9659dc1c21fefecac662649'
relative = 'src/main/java/com/tkisor/nekojs/mixin/RecipeManagerMixin.java'
helper_relative = 'common/src/main/java/com/tkisor/nekojs/core/error/RecipePassDiagnostic.java'
assert not out.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
assert not (tree / helper_relative).exists()
out.mkdir()
target = tree / relative
original = target.read_bytes()
(out / 'RecipeManagerMixin.java.original').write_bytes(original)
source = original.decode('utf-8').replace('\r\n', '\n')
edits = [
    ('    public void nekojs$applyScripts() {',
     '    public void nekojs$applyScripts() {\n        var profile = new com.tkisor.nekojs.core.error.RecipePassDiagnostic();\n        profile.begin();\n        long phaseStarted = System.nanoTime();'),
    ('        RecipeEventJS eventJS = new RecipeEventJS(this.nekojs$rawJsons, this.registries, RecipeTypeDefinitionStorage.current());',
     '        profile.filterNanos = System.nanoTime() - phaseStarted;\n        profile.beforeCount = beforeCount;\n        profile.afterFilterCount = this.nekojs$rawJsons.size();\n        phaseStarted = System.nanoTime();\n        RecipeEventJS eventJS = new RecipeEventJS(this.nekojs$rawJsons, this.registries, RecipeTypeDefinitionStorage.current());\n        profile.copyNanos = System.nanoTime() - phaseStarted;\n        phaseStarted = System.nanoTime();'),
    ('        List<RecipeHolder<?>> newHolders = new ArrayList<>();',
     '        profile.recipeHooksNanos = System.nanoTime() - phaseStarted;\n        phaseStarted = System.nanoTime();\n        profile.finalJsonCount = eventJS.getFinalJsons().size();\n        List<RecipeHolder<?>> newHolders = new ArrayList<>();'),
    ('        this.recipes = RecipeMap.create(newHolders);',
     '        profile.decodeNanos = System.nanoTime() - phaseStarted;\n        profile.decodedCount = newHolders.size();\n        phaseStarted = System.nanoTime();\n        this.recipes = RecipeMap.create(newHolders);\n        profile.mapBuildNanos = System.nanoTime() - phaseStarted;\n        phaseStarted = System.nanoTime();'),
    ('        this.nekojs$rawJsons.clear();\n\n        com.tkisor.nekojs.script.ScriptTypeEnv.logger',
     '        profile.afterHooksNanos = System.nanoTime() - phaseStarted;\n        profile.end();\n        profile.commit();\n        this.nekojs$rawJsons.clear();\n\n        com.tkisor.nekojs.script.ScriptTypeEnv.logger'),
]
for before, after in edits:
    assert source.count(before) == 1, before
    source = source.replace(before, after)
target.write_text(source, encoding='utf-8', newline='\n')
helper = '''package com.tkisor.nekojs.core.error;

/** Temporary recipe-pass measurements for the owned diagnostic checkout only. */
@jdk.jfr.Name("neko.RecipePass6e")
@jdk.jfr.Label("Recipe pass diagnostic")
@jdk.jfr.StackTrace(false)
public final class RecipePassDiagnostic extends jdk.jfr.Event {
    public int beforeCount;
    public int afterFilterCount;
    public int finalJsonCount;
    public int decodedCount;
    public long filterNanos;
    public long copyNanos;
    public long recipeHooksNanos;
    public long decodeNanos;
    public long mapBuildNanos;
    public long afterHooksNanos;
}
'''
(tree / helper_relative).write_text(helper, encoding='utf-8', newline='\n')
(out / 'RecipePassDiagnostic.java').write_text(helper, encoding='utf-8', newline='\n')
binding = dict(revision=revision, diagnosticOnly=True,
    bindings=[dict(path=relative, originalSha256=hashlib.sha256(original).hexdigest(),
                   instrumentedSha256=hashlib.sha256(target.read_bytes()).hexdigest())],
    addedSource=helper_relative, addedSha256=hashlib.sha256((tree / helper_relative).read_bytes()).hexdigest())
(out / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
(out / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', relative], cwd=tree))
controller = (tools / '6e43b827-map-diagnostic/diagnostic.ps1').read_text(encoding='utf-8')
assert controller.count('6e43b827-map-diagnostic/session') == 1
controller = controller.replace('6e43b827-map-diagnostic/session', '6e43b827-recipe-diagnostic/session')
(out / 'diagnostic.ps1').write_text(controller, encoding='utf-8', newline='\n')
(out / 'run.py').write_bytes((tools / '6e43b827-map-diagnostic/run.py').read_bytes())
print(json.dumps(dict(prepared=True, revision=revision, modifiedSourceFiles=1, temporaryHelperFiles=1, diagnosticOnly=True)))
