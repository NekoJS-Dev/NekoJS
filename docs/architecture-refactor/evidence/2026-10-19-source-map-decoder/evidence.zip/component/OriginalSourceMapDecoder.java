package com.tkisor.nekojs.core.error;
import java.util.*;
public final class OriginalSourceMapDecoder {
    private static final String VLQ_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    private static List<List<MappingEntry>> parseMappings(String mappings, int sourceCount, int nameCount) {
        String[] generatedLines = mappings.split(";", -1);
        List<List<MappingEntry>> lineMappings = new ArrayList<>(generatedLines.length);

        int sourceIndex = 0;
        int originalLine = 0;
        int originalColumn = 0;
        int nameIndex = 0;

        for (String generatedLine : generatedLines) {
            List<MappingEntry> entries = new ArrayList<>();
            lineMappings.add(entries);
            if (generatedLine.isEmpty()) {
                continue;
            }

            int generatedColumn = 0;
            for (String segment : generatedLine.split(",")) {
                if (segment.isEmpty()) continue;
                List<Integer> values = decodeVlq(segment);
                if (values.isEmpty()) continue;

                generatedColumn += values.get(0);
                if (values.size() < 4) {
                    continue;
                }

                sourceIndex += values.get(1);
                originalLine += values.get(2);
                originalColumn += values.get(3);

                int entryNameIndex = -1;
                if (values.size() >= 5) {
                    nameIndex += values.get(4);
                    if (nameIndex >= 0 && nameIndex < nameCount) {
                        entryNameIndex = nameIndex;
                    }
                }

                if (sourceIndex >= 0 && sourceIndex < sourceCount && originalLine >= 0 && originalColumn >= 0) {
                    entries.add(new MappingEntry(generatedColumn, sourceIndex, originalLine, originalColumn, entryNameIndex));
                }
            }
        }
        return lineMappings;
    }

    private static List<Integer> decodeVlq(String str) {
        List<Integer> result = new ArrayList<>();
        int value = 0;
        int shift = 0;
        for (int i = 0; i < str.length(); i++) {
            int c = VLQ_CHARS.indexOf(str.charAt(i));
            if (c < 0) {
                result.clear();
                return result;
            }
            value |= (c & 31) << shift;
            if ((c & 32) == 0) {
                int decoded = value >> 1;
                result.add((value & 1) != 0 ? -decoded : decoded);
                value = 0;
                shift = 0;
            } else {
                shift += 5;
            }
        }
        return result;
    }

    private record MappingEntry(int generatedColumn, int sourceIndex, int originalLine, int originalColumn, int nameIndex) {}
}
