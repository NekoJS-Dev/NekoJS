package com.tkisor.nekojs.core.error;

import com.tkisor.nekojs.core.compiler.NekoSourceMapBuilder;
import com.google.gson.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;

public class SourceMapDecodeControl {
    static volatile Object sink;
    static final com.sun.management.ThreadMXBean CPU =
        (com.sun.management.ThreadMXBean) java.lang.management.ManagementFactory.getThreadMXBean();
    static Map<String, Long> measure(Method method, List<String> mappings) throws Exception {
        long thread = Thread.currentThread().threadId();
        long bytes = CPU.getThreadAllocatedBytes(thread), cpu = CPU.getCurrentThreadCpuTime(), wall = System.nanoTime();
        for (String map : mappings) sink = method.invoke(null, map, 1, 0);
        return Map.of("wallNs", System.nanoTime()-wall, "cpuNs", CPU.getCurrentThreadCpuTime()-cpu,
            "allocatedBytes", CPU.getThreadAllocatedBytes(thread)-bytes);
    }
    public static void main(String[] args) throws Exception {
        Method before = OriginalSourceMapDecoder.class.getDeclaredMethod("parseMappings", String.class, int.class, int.class);
        Method after = SourceMapRegistry.class.getDeclaredMethod("parseMappings", String.class, int.class, int.class);
        before.setAccessible(true); after.setAccessible(true);
        var maps = new ArrayList<String>();
        try (var files = Files.walk(Path.of(args[0]))) {
            for (var file : files.filter(p -> p.toString().endsWith(".js")).sorted().toList()) {
                String source = Files.readString(file);
                maps.add(JsonParser.parseString(NekoSourceMapBuilder.identity(file, source, source)).getAsJsonObject().get("mappings").getAsString());
            }
        }
        if (maps.size()!=6) throw new AssertionError(maps.size());
        var random = new Random(19062026L);
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/,;?\u00e9";
        var cases = new ArrayList<String>(maps);
        Collections.addAll(cases, "", ";", ";;", ",", ",,", "AAAA;", "AAAA,,CAAC", "AAAA?", "AAAAg", "AAAAAA", "AAAAAA?", "AAAA;CAAC", "gggggggggggggggggggA");
        for (int i=0; i<10000; i++) {
            var value = new StringBuilder();
            int length=random.nextInt(160);
            for (int j=0; j<length; j++) value.append(alphabet.charAt(random.nextInt(alphabet.length())));
            cases.add(value.toString());
        }
        for (String map : cases) {
            String expected = before.invoke(null, map, 2, 2).toString();
            String actual = after.invoke(null, map, 2, 2).toString();
            if (!expected.equals(actual)) throw new AssertionError("Mapping mismatch: "+map);
        }
        for (int i=0;i<100;i++) { measure(before,maps); measure(after,maps); }
        var rows = new ArrayList<Map<String,Object>>();
        for (int i=0;i<30;i++) {
            var row = new LinkedHashMap<String,Object>(); row.put("pair",i+1);
            if (i%2==0) { row.put("before",measure(before,maps)); row.put("after",measure(after,maps)); }
            else { row.put("after",measure(after,maps)); row.put("before",measure(before,maps)); }
            rows.add(row);
        }
        var result = new LinkedHashMap<String,Object>();
        result.put("diagnosticOnly",true); result.put("sources",maps.size()); result.put("equivalentCases",cases.size());
        result.put("warmups",100); result.put("pairs",rows);
        Files.writeString(Path.of(args[1]),new GsonBuilder().setPrettyPrinting().create().toJson(result));
        System.out.println("SOURCE_MAP_CONTROL_COMPLETE equivalentCases="+cases.size());
    }
}
