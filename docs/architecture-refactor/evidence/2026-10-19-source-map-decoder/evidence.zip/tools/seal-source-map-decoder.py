"""Freeze the decoder component control and every original formal sample."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project / 'build/priority-closeout'
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
control = tools / 'source-map-decoder'
cohort = tools / 'source-map-606d1fff-formal'
prep = json.loads((cohort / 'preparation.json').read_text())
target = project / 'docs/architecture-refactor/evidence/2026-10-19-source-map-decoder'
target.mkdir(parents=True, exist_ok=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == prep['revision']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
classes = {}
for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    base = tree / relative
    for file in base.rglob('*.class'):
        key = file.relative_to(base).as_posix()
        assert key not in classes
        assert b'DEBUG-CLOSEOUT' not in file.read_bytes() and b'neko.ReloadStage' not in file.read_bytes()
        classes[key] = hashlib.sha256(file.read_bytes()).hexdigest()
assert classes == prep['classBindings']
artifact = Path(prep['artifact'])
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == prep['artifactSha256']
secrets = []
for file in [tree / 'versions/26.1.2/run/server.properties', tools / 'client-world-acceptance/server/server.properties']:
    secrets.extend(line.split('=', 1)[1] for line in file.read_text().splitlines() if line.startswith('rcon.password='))
assert len(secrets) == 2 and all(secrets)
entries, redactions = {}, {}

def add_bytes(data, name, binary=False):
    assert name not in entries
    assert not name.endswith(('server.properties', '.pk8', 'classpath.txt'))
    if not binary:
        encoding = 'utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
        try:
            text = data.decode(encoding)
        except UnicodeDecodeError:
            encoding = 'gb18030'
            text = data.decode(encoding)
        if any(secret in text for secret in secrets):
            redactions[name] = dict(originalSha256=hashlib.sha256(data).hexdigest())
            for secret in secrets:
                text = text.replace(secret, '<REDACTED-RCON-CREDENTIAL>')
            data = text.encode(encoding)
    for secret in secrets:
        assert all(secret.encode(encoding) not in data for encoding in ['utf-8', 'utf-16-le', 'utf-16-be'])
    entries[name] = data

def add(file, name, binary=False):
    add_bytes(file.read_bytes(), name, binary)

for file in cohort.iterdir():
    if file.is_file(): add(file, 'formal/metadata/' + file.name)
for group in json.loads((cohort / 'groups.json').read_text()):
    folder = Path(group['outputDirectories'][0])
    for file in folder.rglob('*'):
        if file.is_file() and file.suffix in {'.json', '.jsonl', '.log', '.txt', '.csv'}:
            add(file, 'formal/' + group['group'] + '/' + file.relative_to(folder).as_posix())
for file in control.rglob('*'):
    if file.is_file() and 'classes' not in file.parts and file.name not in {'OriginalSourceMapRegistry.java', 'common-progress-thread.txt'}:
        if file.suffix in {'.json', '.xml', '.java', '.log'}:
            add(file, 'component/' + file.relative_to(control).as_posix())
add(artifact, 'binaries/neoforge-26.1.2.jar', True)
for name in ['bench/perf/sample.ps1', 'bench/perf/rcon.py', *prep['fixtureHashes']]:
    add(tree / name, 'harness/' + name)
for name in json.loads((control / 'validation/binding.json').read_text())['sourceHashes']:
    add(tree / name, 'source/' + name)
add_bytes(subprocess.check_output(['git', 'diff', '4550a385', prep['revision']], cwd=tree), 'source/change.patch')
for name in ['formal-performance.py', 'judge-performance.py', 'SourceMapDecodeControl.java',
             'run-source-map-control.py', 'seal-source-map-decoder.py']:
    add(tools / name, 'tools/' + name)
add_bytes((json.dumps(dict(classBindings=classes, trackedSourcesClean=True), indent=2) + '\n').encode(), 'post-run-bindings.json')
add_bytes((json.dumps(redactions, indent=2) + '\n').encode(), 'redactions.json')
packed = target / 'evidence.zip'
with zipfile.ZipFile(packed, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in sorted(entries.items()): archive.writestr(name, data)
manifest = dict(candidateCommit=prep['revision'], baseCommit='4550a385',
                samplerChanged=False, externalQosController=False,
                archiveBytes=packed.stat().st_size, archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
                entries={name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())})
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k != 'entries'}))
print('entries=' + str(len(entries)))
