import hashlib
import json
import statistics
import subprocess
import sys
from pathlib import Path

tools = Path(__file__).resolve().parent
out = tools / 'source-map-decoder'
label = sys.argv[1]
target = out / label
target.mkdir()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
cp = (tools / 'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
cp = ';'.join(str(Path(part)) for part in cp.split(';'))
cp = cp.replace('D:\\mcmodDemo\\NekoJS-mult\\common\\build', str(tree / 'common/build'))
assert str(tree / 'common/build/classes/java/main').replace('/', '\\').lower() in cp.replace('/', '\\').lower()
classes = target / 'classes'
classes.mkdir()
commands = [
    [str(java / 'javac.exe'), '-cp', cp, '-d', str(classes), str(out / 'OriginalSourceMapDecoder.java'), str(tools / 'SourceMapDecodeControl.java')],
    [str(java / 'java.exe'), '-cp', str(classes)+';'+cp, 'com.tkisor.nekojs.core.error.SourceMapDecodeControl',
        str(tree / 'bench/perf/fixtures/nekojs/server_scripts'), str(target / 'observations.json')],
]
for i, command in enumerate(commands):
    with (target / f'{i}-stdout.log').open('xb') as stdout, (target / f'{i}-stderr.log').open('xb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, i
observed = json.loads((target / 'observations.json').read_text(encoding='utf-8'))
summary = dict(diagnosticOnly=True, formalVerdictUnchanged='FAIL', equivalentCases=observed['equivalentCases'], means={})
for arm in ['before','after']:
    summary['means'][arm] = {key: statistics.mean(row[arm][key] for row in observed['pairs']) for key in ['wallNs','cpuNs','allocatedBytes']}
summary['allocationRatio'] = summary['means']['after']['allocatedBytes'] / summary['means']['before']['allocatedBytes']
summary['allocationGate'] = 'PASS' if summary['allocationRatio'] <= 0.8 else 'FAIL'
summary['currentDecoderClassSha256'] = hashlib.sha256((tree / 'common/build/classes/java/main/com/tkisor/nekojs/core/error/SourceMapRegistry.class').read_bytes()).hexdigest()
(target / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
raise SystemExit(0 if summary['allocationGate']=='PASS' else 2)
