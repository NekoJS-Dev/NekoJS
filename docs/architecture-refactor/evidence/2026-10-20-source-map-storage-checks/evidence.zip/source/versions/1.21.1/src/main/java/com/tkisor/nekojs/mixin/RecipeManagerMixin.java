// 1.21.1 实现，与版本树 src/ 下的同名 26.x 文件成对。内容等于那份文件在本节点求值后的形态
//（可用 tools/extract_evaluated.py 重新提取核对）；26.x 侧行为变更时须同步本文件。
// guard-exempt(20): 配方 mixin 的注入点两个时代差别很大，逐处守卫比再拆文件更清楚（ADR-0008）
package com.tkisor.nekojs.mixin;

import com.tkisor.nekojs.script.ScriptTypeEnv;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.mojang.serialization.JsonOps;
import com.tkisor.nekojs.NekoJS;
import com.tkisor.nekojs.api.event.ScriptErrorReporter;
import com.tkisor.nekojs.api.recipe.definition.RecipeTypeDefinitionStorage;
import com.tkisor.nekojs.bindings.event.ServerEvents;
import com.tkisor.nekojs.core.error.NekoErrorUIHelper;
import com.tkisor.nekojs.api.plugin.NekoRuntimeAccess;
import com.tkisor.nekojs.api.recipe.IRecipeManagerExtension;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.wrapper.event.server.RecipeEventJS;
import graal.graalvm.polyglot.PolyglotException;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;
import net.neoforged.neoforge.server.ServerLifecycleHooks;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import java.util.*;
import com.google.common.collect.Multimap;
import net.minecraft.resources.RegistryOps;
import net.minecraft.world.item.crafting.*;
import net.neoforged.neoforge.common.conditions.WithConditions;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RecipeManager.class)
public abstract class RecipeManagerMixin implements IRecipeManagerExtension {

    @Final @Shadow private HolderLookup.Provider registries;
    @Shadow private Map<ResourceLocation, RecipeHolder<?>> byName;
    @Shadow private Multimap<RecipeType<?>, RecipeHolder<?>> byType;

    @Shadow public abstract void replaceRecipes(Iterable<RecipeHolder<?>> p_44025_);

    @Unique
    private final Map<ResourceLocation, JsonElement> nekojs$rawJsons = new HashMap<>();

    // 永久缓存 prepare() 读到的原始配方 JSON，让 nekojs$applyScripts() 可被 /nekojs reload server 反复调用（热重载）。
    // rawJsons 是每次 applyScripts 的工作集（会被条件过滤 mutate、末尾 clear），baseJsons 只在 prepare 时整体重建。
    @Unique
    private final Map<ResourceLocation, JsonElement> nekojs$baseJsons = new HashMap<>();

    @Inject(method = "apply(Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)V", at = @At("HEAD"))
    private void nekojs$cacheRawJsons(Map<ResourceLocation, JsonElement> p_44037_, ResourceManager p_44038_, ProfilerFiller p_44039_, CallbackInfo ci) {
        this.nekojs$rawJsons.clear();
        this.nekojs$rawJsons.putAll(p_44037_);
        // 同步永久缓存：热重载时 nekojs$applyScripts() 从 baseJsons 重建工作集
        this.nekojs$baseJsons.clear();
        this.nekojs$baseJsons.putAll(p_44037_);
    }

    @Unique
    @Override
    public void nekojs$applyScripts() {
        // 从永久缓存重建工作集，使本方法可被 /nekojs reload server 反复调用。
        // rawJsons 在下方会被条件过滤 mutate、末尾 clear，故每次入口都从 baseJsons 重新拷贝。
        this.nekojs$rawJsons.clear();
        this.nekojs$rawJsons.putAll(this.nekojs$baseJsons);
        int beforeCount = this.nekojs$rawJsons.size();

        // 相当于: ! ICondition.conditionsMatched(JsonOps.INSTANCE, entry.getValue())
        // 这么写只是为了避免重复创建 ConditionalOps
        RegistryOps<JsonElement> registryOps = this.registries.createSerializationContext(JsonOps.INSTANCE);

        this.nekojs$rawJsons.entrySet().removeIf(entry -> {
            ResourceLocation id = entry.getKey();
            if (id.getPath().startsWith("_")) return true;

            try {
                Optional<WithConditions<Recipe<?>>> decoded = Recipe.CONDITIONAL_CODEC.parse(registryOps, entry.getValue())
                        .getOrThrow(JsonParseException::new);
                return decoded.isEmpty();
            } catch (Exception e) {
                return true;
            }
        });

        int afterCount = this.nekojs$rawJsons.size();
        NekoJS.LOGGER.debug("Filtered out {} recipes that did not meet conditions", beforeCount - afterCount);

        RecipeEventJS eventJS = new RecipeEventJS(this.nekojs$rawJsons, this.registries, RecipeTypeDefinitionStorage.current());
        try {
            // 原料动作（damage/keep/replaceIngredient）是纯脚本状态：脚本重跑前整表清空，
            // 由本次脚本执行期间 RecipeJsonBuilder 的动作调用重建——删掉的脚本动作随之消失
            NekoRuntimeAccess.get().beforeRecipeLoading(eventJS);
            ServerEvents.RECIPES.post(eventJS);
        } catch (PolyglotException e) {
            // 错误上报经 ScriptErrorReporter 门面（root-owned ErrorTracker 的静态报告面，
            // 由共享装配函数安装）——mixin 静态上下文无法注入 root，不再直读 static root
            ScriptErrorReporter.recordEventError(ScriptType.SERVER, e);
        } catch (Exception e) {
            com.tkisor.nekojs.script.ScriptTypeEnv.logger(ScriptType.SERVER).error("Recipe script execution crashed", e);
        }

        List<RecipeHolder<?>> newHolders = new ArrayList<>();
        // Keep registry lookup reuse within this decode pass and after the modification hooks.
        RegistryOps<JsonElement> recipeOps = null;
        for (Map.Entry<ResourceLocation, JsonElement> entry : eventJS.getFinalJsons().entrySet()) {
            try {
                if (recipeOps == null) {
                    recipeOps = this.registries.createSerializationContext(JsonOps.INSTANCE);
                }
                Recipe<?> recipe = Recipe.CODEC.parse(recipeOps, entry.getValue())
                        .getOrThrow(JsonParseException::new);
                newHolders.add(new RecipeHolder<>(entry.getKey(), recipe));
            } catch (Exception e) {
                if (entry.getValue().isJsonObject()) {
                    NekoJS.LOGGER.error("{}", eventJS.formatRecipeError("Invalid recipe after script processing", entry.getKey(), entry.getValue().getAsJsonObject(), e));
                } else {
                    NekoJS.LOGGER.error("Invalid recipe after script processing (id={}): {}", entry.getKey(), e.getMessage());
                }
            }
        }

        // ticket 23（AC3）：整批解析完成后一次性替换配方表（单引用提交，无半更新）；
        // afterRecipes（脚本事件与插件 hook）只在提交之后触发——此前它先于 codec 解析，
        // 消费者会观察到未提交的旧配方表。afterRecipes 阶段的修改不再进入本次提交。
        this.replaceRecipes(newHolders);
        try {
            ServerEvents.AFTER_RECIPES.post(eventJS);
            NekoRuntimeAccess.get().afterRecipes(eventJS);
        } catch (PolyglotException e) {
            ScriptErrorReporter.recordEventError(ScriptType.SERVER, e);
        } catch (Exception e) {
            com.tkisor.nekojs.script.ScriptTypeEnv.logger(ScriptType.SERVER).error("afterRecipes lifecycle phase crashed", e);
        }
        this.nekojs$rawJsons.clear();

        com.tkisor.nekojs.script.ScriptTypeEnv.logger(ScriptType.SERVER).debug("Script execution completed, total recipes: {}", this.byName.size());
        if (ServerLifecycleHooks.getCurrentServer() != null) {
            List<ServerPlayer> players = ServerLifecycleHooks.getCurrentServer().getPlayerList().getPlayers();
            players.forEach(player -> {
                if (player.hasPermissions(2)) {
                    if (!ScriptErrorReporter.hasErrors()) {
                        player.sendSystemMessage(NekoErrorUIHelper.getSuccessComponent());
                    } else {
                        player.sendSystemMessage(NekoErrorUIHelper.getErrorComponent(ScriptErrorReporter.errorCount()));
                    }
                }
            });
        }
    }
}
