import hashlib
import json
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
run = repo / 'build/priority-closeout/2026-10-20-24d35a5d-verification'
assert not run.exists(), 'Preserve existing verification attempts'
run.mkdir()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert revision.startswith('24d35a5d')
preserved = []
for name in ['common/src/test/probe-ts/generated/index.d.ts',
             'common/src/test/resources/nekojs/dynamic/dynamic-registry-events.expected.d.ts']:
    data = (repo / name).read_bytes()
    backup = run / (Path(name).name + '.before')
    backup.write_bytes(data)
    preserved.append(dict(path=name, backup=backup.relative_to(repo).as_posix(),
                          sha256=hashlib.sha256(data).hexdigest().upper()))
baseline = dict(commit=revision, preserved=preserved,
                status=subprocess.check_output(['git', 'status', '--short'], cwd=repo, text=True).splitlines())
(run / 'baseline.json').write_text(json.dumps(baseline, indent=2)+'\n', encoding='utf-8')
gradle = [str(repo / 'gradlew.bat'), '-g', 'D:/mcmodDemo/NekoJS/.gradle-perf02',
          '-Dorg.gradle.java.home=C:/Program Files/Java/jdk-25.0.2', '--offline', '--no-parallel', '--console=plain']
nodes = ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']

def guard():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == revision
    for item in preserved:
        assert hashlib.sha256((repo / item['path']).read_bytes()).hexdigest().upper() == item['sha256']

def execute(label, args):
    guard()
    print('CHECK_START', label, flush=True)
    start = time.monotonic()
    with (run / (label+'.log')).open('xb') as out:
        process = subprocess.Popen(args, cwd=repo, stdout=out, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        code = process.wait()
    result = dict(commit=revision, exitCode=code, seconds=round(time.monotonic()-start, 3), arguments=args)
    (run / (label+'-result.json')).write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print('CHECK_EXIT', label, code, result['seconds'], flush=True)
    guard()
    assert code == 0, label

def snapshot(label, projects):
    counts = {}
    for name, directory in projects.items():
        for task in ['test', 'platformGateTest']:
            source = repo / directory / 'build/test-results' / task
            if not source.exists() or (label == 'focused' and task != 'test'):
                continue
            target = run / (label+'-xml') / name / task
            target.mkdir(parents=True)
            stats = dict(tests=0, failures=0, errors=0, skipped=0)
            for path in sorted(source.glob('TEST-*.xml')):
                shutil.copy2(path, target / path.name)
                root = ET.parse(path).getroot()
                for key in stats:
                    stats[key] += int(root.attrib.get(key, 0))
            counts[name+':'+task] = stats
    (run / (label+'-counts.json')).write_text(json.dumps(counts, indent=2)+'\n', encoding='utf-8')
    assert all(s['failures'] == s['errors'] == 0 for s in counts.values()), counts

focused = [':common:test']
for test in ['SourceMapRegistryTest', 'NekoSourceMapBuilderTest',
             'NekoModulePipelineCacheSessionTest', 'NekoModulePipelineCacheStampTest',
             'NekoModuleIdentityLifecycleTest', 'ModulePipelineIsolationTest',
             'NekoModulePipelinePrepareTest', 'BuiltinModuleReuseTest',
             'ScriptReloadGenerationTest', 'NekoPythonPrepareTest']:
    focused += ['--tests', '*.'+test]
execute('focused', gradle+focused)
snapshot('focused', {'common':'common'})
print('FOCUSED_COMPLETE', revision, flush=True)
