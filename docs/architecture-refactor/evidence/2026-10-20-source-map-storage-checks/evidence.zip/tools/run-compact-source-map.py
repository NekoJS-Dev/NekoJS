import hashlib
import json
import statistics
import subprocess
import time
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
tools = repo/'build/priority-closeout'
out = tools/'compact-source-map-24d35a5d-v2'
assert not out.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip().startswith('24d35a5d')
out.mkdir()
before = subprocess.check_output(['git','show','46505ad2:common/src/main/java/com/tkisor/nekojs/core/error/SourceMapRegistry.java'],cwd=repo)
(out/'baseline-SourceMapRegistry.java').write_bytes(before)
# The reference class has its own nested position type, so it cannot implement the current
# interface whose return type names SourceMapRegistry. Keep its method bodies unchanged.
reference = before.replace(b'SourceMapRegistry',b'OriginalSourceMapRegistry')
reference = reference.replace(b' implements NekoSourceMapView', b'').replace(b'@Override', b'')
(out/'OriginalSourceMapRegistry.java').write_bytes(reference)
(out/'CompactSourceMapControl.java').write_bytes((tools/'CompactSourceMapControl.java').read_bytes())
original_cp = (tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text().strip().split(';')
jars = [part for part in original_cp if part.endswith('.jar') and Path(part).is_file()]
classpath = ';'.join([str(repo/'common/build/classes/java/main'), str(repo/'common/build/resources/main'), *jars])
classes = out/'classes'
classes.mkdir()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
commands = [
    [str(java/'javac.exe'),'-J-Duser.language=en','-J-Duser.country=US','-encoding','UTF-8','-cp',classpath,'-d',str(classes),str(out/'OriginalSourceMapRegistry.java'),str(out/'CompactSourceMapControl.java')],
    [str(java/'java.exe'),'-cp',str(classes)+';'+classpath,'com.tkisor.nekojs.core.error.CompactSourceMapControl',
        str(repo/'bench/perf/fixtures/nekojs/server_scripts'),str(out/'observations.json')]
]
for index,command in enumerate(commands):
    started=time.monotonic()
    with (out/f'{index}-output.log').open('xb') as log:
        result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/f'{index}-result.json').write_text(json.dumps(dict(exitCode=result.returncode,seconds=time.monotonic()-started),indent=2)+'\n')
    assert result.returncode==0,index
observed=json.loads((out/'observations.json').read_text())
summary=dict(diagnosticOnly=True,formalVerdictUnchanged='NOT_PASS',equivalentCases=observed['equivalentCases'],
    observablePositions=observed['observablePositions'],means={})
for arm in ('before','after'):
    summary['means'][arm]={key:statistics.mean(row[arm][key] for row in observed['pairs']) for key in ('wallNs','cpuNs','allocatedBytes')}
summary['allocationRatio']=summary['means']['after']['allocatedBytes']/summary['means']['before']['allocatedBytes']
summary['currentClassSha256']=hashlib.sha256((repo/'common/build/classes/java/main/com/tkisor/nekojs/core/error/SourceMapRegistry.class').read_bytes()).hexdigest()
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
