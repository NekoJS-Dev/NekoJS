package com.tkisor.nekojs.core.error;

import com.google.gson.*;
import com.tkisor.nekojs.core.compiler.NekoSourceMapBuilder;
import java.lang.reflect.Method;
import java.nio.file.*;
import java.util.*;

public final class CompactSourceMapControl {
    private static volatile Object sink;
    private static final com.sun.management.ThreadMXBean CPU =
        (com.sun.management.ThreadMXBean) java.lang.management.ManagementFactory.getThreadMXBean();

    private static List<int[]> fields(Object parsed) throws Exception {
        var result = new ArrayList<int[]>();
        for (Object line : (List<?>) parsed) {
            if (line instanceof int[] packed) {
                result.add(packed);
            } else {
                List<?> entries = (List<?>) line;
                int[] values = new int[entries.size() * 5];
                int at = 0;
                for (Object entry : entries) {
                    for (String field : List.of("generatedColumn", "sourceIndex", "originalLine", "originalColumn", "nameIndex")) {
                        Method method = entry.getClass().getDeclaredMethod(field);
                        method.setAccessible(true);
                        values[at++] = (int) method.invoke(entry);
                    }
                }
                result.add(values);
            }
        }
        return result;
    }

    private static Map<String, Long> measure(Method method, List<String> maps) throws Exception {
        long thread = Thread.currentThread().threadId();
        long allocated = CPU.getThreadAllocatedBytes(thread);
        long cpu = CPU.getCurrentThreadCpuTime();
        long wall = System.nanoTime();
        for (String map : maps) sink = method.invoke(null, map, 1, 0);
        return Map.of("wallNs", System.nanoTime()-wall, "cpuNs", CPU.getCurrentThreadCpuTime()-cpu,
            "allocatedBytes", CPU.getThreadAllocatedBytes(thread)-allocated);
    }

    private static String position(String path, int line, int column, String name, String content) {
        return new Gson().toJson(Arrays.asList(path, line, column, name, content));
    }

    public static void main(String[] arguments) throws Exception {
        Method before = OriginalSourceMapRegistry.class.getDeclaredMethod("parseMappings", String.class, int.class, int.class);
        Method after = SourceMapRegistry.class.getDeclaredMethod("parseMappings", String.class, int.class, int.class);
        before.setAccessible(true);
        after.setAccessible(true);
        var maps = new ArrayList<String>();
        try (var files = Files.walk(Path.of(arguments[0]))) {
            for (Path file : files.filter(p -> p.toString().endsWith(".js")).sorted().toList()) {
                String source = Files.readString(file);
                maps.add(JsonParser.parseString(NekoSourceMapBuilder.identity(file, source, source))
                    .getAsJsonObject().get("mappings").getAsString());
            }
        }
        if (maps.size() != 6) throw new AssertionError("Expected all six recursive fixture sources");
        var cases = new ArrayList<String>(maps);
        Collections.addAll(cases, "", ";", ";;", ",", ",,", "AAAA;", "AAAA,,CAAC", "AAAA?", "AAAAg",
            "AAAAAA", "AAAAAA?", "AAAA;CAAC", "gggggggggggggggggggA", "EAAI,DAAC,AAAC",
            "AAAACE,AAAAC", "AAAA,ggggggDAAC,igggggBAAA");
        Random random = new Random(19062026L);
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/,;?\u00e9";
        for (int i=0; i<10000; i++) {
            StringBuilder value = new StringBuilder();
            int length = random.nextInt(160);
            for (int j=0; j<length; j++) value.append(alphabet.charAt(random.nextInt(alphabet.length())));
            cases.add(value.toString());
        }
        var oldRegistry = new OriginalSourceMapRegistry(Path.of(arguments[0]));
        var newRegistry = new SourceMapRegistry(Path.of(arguments[0]));
        long positions = 0;
        for (int index=0; index<cases.size(); index++) {
            String map = cases.get(index);
            List<int[]> expected = fields(before.invoke(null, map, 2, 3));
            List<int[]> actual = fields(after.invoke(null, map, 2, 3));
            if (expected.size() != actual.size()) throw new AssertionError("Line count at case " + index);
            for (int line=0; line<expected.size(); line++) {
                if (!Arrays.equals(expected.get(line), actual.get(line))) throw new AssertionError("Fields at case " + index);
            }
            JsonObject json = new JsonObject();
            json.addProperty("version", 3);
            json.add("sources", JsonParser.parseString("[\"one.ts\",\"two.ts\"]"));
            json.add("sourcesContent", JsonParser.parseString("[\"one\",\"two\"]"));
            json.add("names", JsonParser.parseString("[\"zero\",\"one\",\"two\"]"));
            json.addProperty("mappings", map);
            String path = "server_scripts/contrast.js";
            String revision = "case-" + index;
            int prefix = index % 3;
            oldRegistry.register(path, json.toString(), prefix, revision);
            newRegistry.register(path, json.toString(), prefix, revision);
            if (!Objects.equals(oldRegistry.mappedCacheRevision(path), newRegistry.mappedCacheRevision(path))) {
                throw new AssertionError("Revision at case " + index);
            }
            for (int line : new int[]{-1, 0, 1, 2, 3, 5, expected.size()+prefix+1}) {
                for (int column : new int[]{-1, 0, 1, 2, 3, 20, Integer.MAX_VALUE}) {
                    var oldPosition = oldRegistry.getMappedPosition(path, line, column);
                    var newPosition = newRegistry.getMappedPosition(path, line, column);
                    String left = position(oldPosition.path, oldPosition.line, oldPosition.column, oldPosition.name, oldPosition.sourceContent);
                    String right = position(newPosition.path, newPosition.line, newPosition.column, newPosition.name, newPosition.sourceContent);
                    if (!left.equals(right)) throw new AssertionError("Observable mapping at case " + index);
                    positions++;
                }
            }
        }
        for (int i=0; i<100; i++) { measure(before, maps); measure(after, maps); }
        List<Map<String,Object>> pairs = new ArrayList<>();
        for (int i=0; i<30; i++) {
            var row = new LinkedHashMap<String,Object>();
            row.put("pair", i+1);
            if (i%2==0) { row.put("before", measure(before, maps)); row.put("after", measure(after, maps)); }
            else { row.put("after", measure(after, maps)); row.put("before", measure(before, maps)); }
            pairs.add(row);
        }
        var result = new LinkedHashMap<String,Object>();
        result.put("diagnosticOnly", true);
        result.put("sources", maps.size());
        result.put("equivalentCases", cases.size());
        result.put("observablePositions", positions);
        result.put("warmups", 100);
        result.put("pairs", pairs);
        Files.writeString(Path.of(arguments[1]), new GsonBuilder().setPrettyPrinting().create().toJson(result));
        System.out.println("COMPACT_MAPPING_CONTROL_COMPLETE cases="+cases.size()+" positions="+positions);
    }
}
