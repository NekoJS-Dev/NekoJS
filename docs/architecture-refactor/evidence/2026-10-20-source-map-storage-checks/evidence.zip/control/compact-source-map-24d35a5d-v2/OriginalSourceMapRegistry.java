package com.tkisor.nekojs.core.error;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.core.fs.ScriptPathProvider;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class OriginalSourceMapRegistry {
    private static final String VLQ_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    private final Map<String, NormalizedSourceMap> mappings = new ConcurrentHashMap<>();
    /** Cache key of the prepared module that registered each source map (ticket 30). */
    private final Map<String, String> revisions = new ConcurrentHashMap<>();
    private final Path root;
    private final boolean caseInsensitive;
    private static final java.util.logging.Logger LOGGER =
            java.util.logging.Logger.getLogger(OriginalSourceMapRegistry.class.getName());
    // Backstop cap on cached source maps. Each entry holds decoded VLQ mappings + sourcesContent,
    // so unbounded growth under script churn could exhaust memory. Reload clears the map (CONC-2).
    private static final int CACHE_HARD_CAP = 4096;

    public OriginalSourceMapRegistry(Path root) {
        Path canonicalRoot = root.normalize().toAbsolutePath();
        try {
            canonicalRoot = canonicalRoot.toRealPath();
        } catch (IOException ignored) {
            // A not-yet-created root still has a stable lexical identity.
        }
        this.root = canonicalRoot;
        this.caseInsensitive = this.root.getFileSystem().getPath("A")
                .equals(this.root.getFileSystem().getPath("a"));
    }

    public Path root() {
        return root;
    }

    public void register(String scriptPath, String sourceMapJson) {
        register(scriptPath, sourceMapJson, 0);
    }

    public void register(String scriptPath, String sourceMapJson, int prependedLineCount) {
        register(scriptPath, sourceMapJson, prependedLineCount, null);
    }

    /**
     * Register a source map together with the cache key of the prepared module that produced
     * it (ticket 30): mapped diagnostics can then retain which prepared revision the position
     * was mapped through. A null/blank revision registers the map without revision info.
     */
    public void register(String scriptPath, String sourceMapJson, int prependedLineCount, String cacheKey) {
        if (scriptPath == null) return;
        String generatedPath = normalizeLookupPath(scriptPath);
        NormalizedSourceMap sourceMap = parse(generatedPath, sourceMapJson, prependedLineCount);
        // Hard cap to guard against unbounded growth in long-running sessions with heavy
        // script churn. Reload clears the map (CONC-2), so this is a backstop for edge cases
        // where many distinct scripts are compiled without a full reload.
        if (mappings.size() > CACHE_HARD_CAP) {
            LOGGER.warning("OriginalSourceMapRegistry exceeded " + CACHE_HARD_CAP + " entries; clearing to bound memory");
            mappings.clear();
            revisions.clear();
        }
        mappings.put(generatedPath, sourceMap);
        if (cacheKey != null && !cacheKey.isBlank()) {
            revisions.put(generatedPath, cacheKey);
        } else {
            revisions.remove(generatedPath);
        }
        if (sourceMap.file != null && !sourceMap.file.isBlank()) {
            mappings.put(sourceMap.file, sourceMap);
            if (cacheKey != null && !cacheKey.isBlank()) {
                revisions.put(sourceMap.file, cacheKey);
            } else {
                revisions.remove(sourceMap.file);
            }
        }
    }

    public OriginalPosition getMappedPosition(String scriptPath, int jsLine, int jsColumn) {
        OriginalPosition fallback = new OriginalPosition(jsLine, jsColumn, null);
        if (scriptPath == null || mappings.isEmpty()) return fallback;

        // Exact normalized-path match only. The previous `endsWith` fallback let two scripts
        // sharing a path suffix collide (RISK-C3); an unmatched query is now unmapped (null source).
        String query = normalizeLookupPath(scriptPath);
        NormalizedSourceMap mapping = mappings.get(query);

        return mapping == null ? fallback : mapping.map(jsLine, jsColumn);
    }

    public void clear() {
        mappings.clear();
        revisions.clear();
    }

    public void clear(String scriptPath) {
        if (scriptPath == null) return;
        String query = normalizeLookupPath(scriptPath);
        removeMappingsWithRevisions(
                entry -> entry.getKey().equals(query) || entry.getValue().matchesGeneratedPath(query));
    }

    public void clearByPathPrefix(String pathPrefix) {
        if (pathPrefix == null) return;
        // Prefix match only (DEFECT-D3): `contains` let clearing `foo/bar` also drop `baz/foo/bar`.
        // normalizeLookupPath already converts `\` to `/`, so a single separator convention is in place.
        String prefix = normalizeLookupPath(pathPrefix);
        removeMappingsWithRevisions(
                entry -> entry.getKey().startsWith(prefix) || entry.getValue().generatedPath.startsWith(prefix));
    }

    /**
     * 仅清空指定 {@link ScriptType} 的 source map：脚本根目录遵循 {@code <name>_scripts}
     * 命名约定，keys 均为 root-relative 路径（如 {@code server_scripts/foo.ts}），
     * 按该前缀过滤即可。与 runtime-owned prepared 缓存的分区清理
     * （见 {@code NekoModulePipelineCache#clear(ScriptType)}）配套，
     * 避免单机单类型 reload 误清其它类型的 Python/TS 映射。
     */
    public void clearByScriptType(ScriptType type) {
        if (type == null) return;
        removeMappingsWithRevisions(entry -> type == scriptTypeOf(entry.getKey())
                || type == scriptTypeOf(entry.getValue().generatedPath));
    }

    /**
     * Removes matching mappings together with their revision side-entries: a revision key
     * always shadows a mapping key of the same path (registration writes both), so dropping
     * a mapping by its generated/alias path must drop that revision too — otherwise a later
     * record creation could attach a stale cache revision to a path whose map is gone.
     */
    private void removeMappingsWithRevisions(
            java.util.function.Predicate<Map.Entry<String, NormalizedSourceMap>> removal) {
        mappings.entrySet().removeIf(entry -> {
            if (removal.test(entry)) {
                revisions.remove(entry.getKey());
                return true;
            }
            return false;
        });
    }

    /** Cache key of the prepared module that registered the map for this generated path (ticket 30). */
    
    public String mappedCacheRevision(String scriptPath) {
        if (scriptPath == null || revisions.isEmpty()) return null;
        return revisions.get(normalizeLookupPath(scriptPath));
    }

    private NormalizedSourceMap parse(String generatedPath, String sourceMapJson, int prependedLineCount) {
        if (sourceMapJson == null || sourceMapJson.isBlank()) {
            return NormalizedSourceMap.empty(generatedPath, prependedLineCount);
        }
        try {
            JsonElement rootElement = JsonParser.parseString(sourceMapJson);
            if (!rootElement.isJsonObject()) {
                return NormalizedSourceMap.empty(generatedPath, prependedLineCount);
            }
            JsonObject root = rootElement.getAsJsonObject();
            if (root.has("sections")) {
                LOGGER.warning("Source map for " + generatedPath + " uses indexed 'sections' format, which is not supported; stack traces will point at generated code");
                return NormalizedSourceMap.empty(generatedPath, prependedLineCount);
            }

            String file = normalizeSourcePath(generatedPath, null, stringMember(root, "file"));
            String sourceRoot = stringMember(root, "sourceRoot");
            List<String> sources = stringArray(root, "sources").stream()
                    .map(source -> normalizeSourcePath(generatedPath, sourceRoot, source))
                    .toList();
            List<String> sourcesContent = nullableStringArray(root, "sourcesContent");
            List<String> names = stringArray(root, "names");
            String mappings = stringMember(root, "mappings");

            if (mappings == null || mappings.isEmpty()) {
                return new NormalizedSourceMap(generatedPath, file, prependedLineCount, List.of(), sources, sourcesContent, names);
            }
            return new NormalizedSourceMap(generatedPath, file, prependedLineCount, parseMappings(mappings, sources.size(), names.size()), sources, sourcesContent, names);
        } catch (Exception e) {
            LOGGER.warning("Failed to parse source map for " + generatedPath + ": " + e.getMessage() + "; stack traces will point at generated code");
            return NormalizedSourceMap.empty(generatedPath, prependedLineCount);
        }
    }

    private static List<List<MappingEntry>> parseMappings(String mappings, int sourceCount, int nameCount) {
        List<List<MappingEntry>> lineMappings = new ArrayList<>();
        List<MappingEntry> entries = new ArrayList<>();
        lineMappings.add(entries);
        // Reuse five field slots across segments; extra fields are still fully validated.
        int[] values = new int[5];

        int sourceIndex = 0;
        int originalLine = 0;
        int originalColumn = 0;
        int nameIndex = 0;
        int generatedColumn = 0;
        int start = 0;
        while (start <= mappings.length()) {
            int end = start;
            while (end < mappings.length() && mappings.charAt(end) != ',' && mappings.charAt(end) != ';') {
                end++;
            }
            int count = decodeVlq(mappings, start, end, values);
            if (count > 0) {
                generatedColumn += values[0];
                if (count >= 4) {
                    sourceIndex += values[1];
                    originalLine += values[2];
                    originalColumn += values[3];
                    int entryNameIndex = -1;
                    if (count >= 5) {
                        nameIndex += values[4];
                        if (nameIndex >= 0 && nameIndex < nameCount) entryNameIndex = nameIndex;
                    }
                    if (sourceIndex >= 0 && sourceIndex < sourceCount && originalLine >= 0 && originalColumn >= 0) {
                        entries.add(new MappingEntry(generatedColumn, sourceIndex, originalLine, originalColumn, entryNameIndex));
                    }
                }
            }
            if (end == mappings.length()) break;
            if (mappings.charAt(end) == ';') {
                entries = new ArrayList<>();
                lineMappings.add(entries);
                generatedColumn = 0;
            }
            start = end + 1;
        }
        return lineMappings;
    }

    /** Retains complete fields, but rejects the whole segment if any character is invalid. */
    private static int decodeVlq(String text, int start, int end, int[] values) {
        int count = 0;
        int value = 0;
        int shift = 0;
        for (int i = start; i < end; i++) {
            int c = VLQ_CHARS.indexOf(text.charAt(i));
            if (c < 0) return 0;
            value |= (c & 31) << shift;
            if ((c & 32) == 0) {
                int decoded = value >> 1;
                if (count < values.length) values[count] = (value & 1) != 0 ? -decoded : decoded;
                count++;
                value = 0;
                shift = 0;
            } else {
                shift += 5;
            }
        }
        return count;
    }

    private static String stringMember(JsonObject object, String member) {
        JsonElement value = object.get(member);
        return value == null || value.isJsonNull() || !value.isJsonPrimitive() ? null : value.getAsString();
    }

    private static List<String> stringArray(JsonObject object, String member) {
        JsonElement value = object.get(member);
        if (value == null || !value.isJsonArray()) return List.of();
        List<String> result = new ArrayList<>();
        JsonArray array = value.getAsJsonArray();
        for (JsonElement element : array) {
            if (element != null && !element.isJsonNull() && element.isJsonPrimitive()) {
                result.add(element.getAsString());
            }
        }
        return result;
    }

    private static List<String> nullableStringArray(JsonObject object, String member) {
        JsonElement value = object.get(member);
        if (value == null || !value.isJsonArray()) return List.of();
        List<String> result = new ArrayList<>();
        JsonArray array = value.getAsJsonArray();
        for (JsonElement element : array) {
            result.add(element == null || element.isJsonNull() || !element.isJsonPrimitive() ? null : element.getAsString());
        }
        return result;
    }

    private String normalizeLookupPath(String path) {
        String normalized = path.replace('\\', '/');
        try {
            Path parsed = normalized.startsWith("file:")
                    ? Path.of(URI.create(normalized)) : Path.of(normalized);
            if (parsed.isAbsolute()) {
                Path absolute = parsed.normalize().toAbsolutePath();
                if (absolute.startsWith(root)) {
                    normalized = root.relativize(absolute).toString().replace('\\', '/');
                }
            }
        } catch (Exception ignored) {
            // Keep non-file source names (including virtual module display names) textual.
        }
        normalized = trimLeadingSlash(normalized);
        return caseInsensitive ? normalized.toLowerCase(Locale.ROOT) : normalized;
    }

    private String normalizeSourcePath(String generatedPath, String sourceRoot, String source) {
        if (source == null || source.isBlank()) {
            return null;
        }
        String sourceText = source.replace('\\', '/');
        if (sourceRoot != null && !sourceRoot.isBlank() && !isAbsoluteOrUri(sourceText)) {
            sourceText = trimTrailingSlash(sourceRoot.replace('\\', '/')) + "/" + sourceText;
        }

        String pathFromUri = normalizeFileUri(sourceText);
        if (pathFromUri != null) {
            return pathFromUri;
        }

        if (isAbsolutePath(sourceText)) {
            return normalizeAbsolutePath(sourceText);
        }

        String normalized = sourceText;
        try {
            Path sourcePath = Path.of(sourceText).normalize();
            normalized = sourcePath.toString().replace('\\', '/');
        } catch (Exception ignored) { // Path.of parse may fail for non-path source text; keep raw
        }

        if (isRootRelative(normalized)) {
            return normalized;
        }

        String generatedDir = generatedDirectory(generatedPath);
        if (!generatedDir.isBlank()) {
            try {
                String resolved = Path.of(generatedDir).resolve(normalized).normalize().toString().replace('\\', '/');
                if (!resolved.startsWith("../") && !resolved.equals("..")) {
                    return trimLeadingSlash(resolved);
                }
            } catch (Exception ignored) { // resolve may fail for unresolvable relative paths; skip
            }
        }
        return normalized.startsWith("../") || normalized.equals("..") ? null : trimLeadingSlash(normalized);
    }

    private String normalizeFileUri(String sourceText) {
        if (!sourceText.startsWith("file:")) {
            return null;
        }
        try {
            return normalizeAbsolutePath(Path.of(URI.create(sourceText)).toString().replace('\\', '/'));
        } catch (Exception ignored) { // URI.create fails for non-file-URI source texts
            return null;
        }
    }

    private String normalizeAbsolutePath(String sourceText) {
        try {
            Path path = Path.of(sourceText).normalize().toAbsolutePath();
            if (path.startsWith(root)) {
                return root.relativize(path).toString().replace('\\', '/');
            }
            return path.toString().replace('\\', '/');
        } catch (Exception ignored) { // Path.of may fail for non-path strings; fallback to simple replace
            return sourceText.replace('\\', '/');
        }
    }

    private static boolean isAbsoluteOrUri(String path) {
        return path.contains("://") || path.startsWith("file:") || isAbsolutePath(path);
    }

    private static boolean isAbsolutePath(String path) {
        return path.startsWith("/") || path.matches("^[A-Za-z]:/.*");
    }

    private boolean isRootRelative(String path) {
        return ScriptPathProvider.typeOf(root.getFileSystem().getPath(path)) != null;
    }

    private ScriptType scriptTypeOf(String path) {
        if (path == null || path.isBlank()) return null;
        try {
            Path parsed = root.getFileSystem().getPath(path);
            if (!parsed.isAbsolute()) {
                parsed = root.resolve(parsed);
            }
            return ScriptPathProvider.typeOf(parsed);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String generatedDirectory(String generatedPath) {
        if (generatedPath == null) return "";
        int slash = generatedPath.lastIndexOf('/');
        return slash < 0 ? "" : generatedPath.substring(0, slash);
    }

    private static String trimLeadingSlash(String value) {
        while (value.startsWith("/")) {
            value = value.substring(1);
        }
        return value;
    }

    private static String trimTrailingSlash(String value) {
        while (value.endsWith("/")) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }

    private record NormalizedSourceMap(
            String generatedPath,
            String file,
            int prependedLineCount,
            List<List<MappingEntry>> lineMappings,
            List<String> sources,
            List<String> sourcesContent,
            List<String> names
    ) {
        static NormalizedSourceMap empty(String generatedPath, int prependedLineCount) {
            return new NormalizedSourceMap(generatedPath, null, prependedLineCount, List.of(), List.of(), List.of(), List.of());
        }

        boolean matchesGeneratedPath(String path) {
            return generatedPath.equals(path) || (file != null && file.equals(path));
        }

        OriginalPosition map(int jsLine, int jsColumn) {
            int adjustedLine = jsLine - Math.max(0, prependedLineCount);
            int lineIndex = adjustedLine - 1;
            if (lineIndex < 0 || lineIndex >= lineMappings.size()) {
                // Miss: allocate the fallback only when we actually need it (not on every call).
                return new OriginalPosition(adjustedLine > 0 ? adjustedLine : jsLine, jsColumn, null);
            }

            List<MappingEntry> entries = lineMappings.get(lineIndex);
            if (entries == null || entries.isEmpty()) {
                return new OriginalPosition(adjustedLine > 0 ? adjustedLine : jsLine, jsColumn, null);
            }

            int targetColumn = Math.max(0, jsColumn - 1);
            MappingEntry bestMatch = entries.get(0);
            for (MappingEntry entry : entries) {
                if (entry.generatedColumn <= targetColumn) {
                    bestMatch = entry;
                } else {
                    break;
                }
            }

            String path = bestMatch.sourceIndex >= 0 && bestMatch.sourceIndex < sources.size() ? sources.get(bestMatch.sourceIndex) : null;
            String sourceContent = bestMatch.sourceIndex >= 0 && bestMatch.sourceIndex < sourcesContent.size() ? sourcesContent.get(bestMatch.sourceIndex) : null;
            String name = bestMatch.nameIndex >= 0 && bestMatch.nameIndex < names.size() ? names.get(bestMatch.nameIndex) : null;
            return new OriginalPosition(path, bestMatch.originalLine + 1, bestMatch.originalColumn + 1, name, sourceContent);
        }
    }

    private record MappingEntry(int generatedColumn, int sourceIndex, int originalLine, int originalColumn, int nameIndex) {}

    public static class OriginalPosition {
        public final String path;
        public final int line;
        public final int column;
        public final String name;
        public final String sourceContent;

        public OriginalPosition(int line, int column, String name) {
            this(null, line, column, name, null);
        }

        public OriginalPosition(String path, int line, int column, String name, String sourceContent) {
            this.path = path;
            this.line = line;
            this.column = column;
            this.name = name;
            this.sourceContent = sourceContent;
        }

        
        public String toString() {
            String position = (path == null || path.isBlank() ? "" : path + ":") + line + ":" + column;
            if (name != null) return name + " (" + position + ")";
            return position;
        }
    }
}
