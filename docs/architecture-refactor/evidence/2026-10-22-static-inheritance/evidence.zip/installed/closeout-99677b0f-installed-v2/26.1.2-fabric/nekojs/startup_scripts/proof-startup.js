RegistryEvents.register(event => {
    event.soundEvent('installed_ec7:nullable', build => { build.fixedRange = null; });
    event.soundEvent('installed_ec7:named', 'basic', build => { build.setFixedRange(null); });
    event.item('installed_ec7:token', build => { build.maxStackSize = 16; });
    event.block('installed_ec7:stone', build => { build.item.maxStackSize = 16; });
    event.block('installed_ec7:no_item', build => { build.noItem(); });
    console.info('EC7-INSTALLED-STARTUP-CALLBACKS-PASS');
});
