// Installed-artifact fixture. The runner substitutes the phase, declaration and node reader.
ServerEvents.tradeDeclaration(event => event.add('minecraft:farmer/level_1', { cost: '1x minecraft:emerald', result: '5x minecraft:apple', maxUses: 12, xp: 2 }));
let ticks = 0;
ServerEvents.tickPost(() => {
    if (++ticks % 20 !== 0) return;
    const query = VillagerTrades.query();
    const classic = Java.type('net.minecraft.world.entity.npc.VillagerTrades');
    const builtin = Java.type('net.minecraft.core.registries.BuiltInRegistries');
    const Location = Java.type('net.minecraft.resources.ResourceLocation');
    const physicalCount = classic.TRADES.get(builtin.VILLAGER_PROFESSION.get(Location.parse('minecraft:farmer'))).get(1).length;
    console.info('DOMAIN-CLOSEOUT-TRADE ' + JSON.stringify({
        phase: 'declared', status: String(query.status), generation: query.generation,
        total: query.total, unrestored: query.unrestoredListingKeys.size(),
        retired: query.retiredListingKeys.size(), physicalCount
    }));
});
