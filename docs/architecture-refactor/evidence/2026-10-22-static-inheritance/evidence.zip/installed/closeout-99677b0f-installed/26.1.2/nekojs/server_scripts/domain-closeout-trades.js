// Installed-artifact fixture. The runner substitutes the phase, declaration and node reader.
ServerEvents.tradeDeclaration(event => event.add('minecraft:farmer/level_1', { cost: '1x minecraft:emerald', result: '5x minecraft:apple', maxUses: 12, xp: 2 }));
let ticks = 0;
ServerEvents.tickPost(() => {
    if (++ticks % 20 !== 0) return;
    const query = VillagerTrades.query();
    const server = Java.type('net.neoforged.neoforge.server.ServerLifecycleHooks').getCurrentServer();
    const registries = Java.type('net.minecraft.core.registries.Registries');
    const Location = Java.type('net.minecraft.resources.Identifier');
    const registry = server.reloadableRegistries().lookup().lookup(registries.TRADE_SET).orElseThrow();
    const physicalCount = registry.getValue(Location.parse('minecraft:farmer/level_1')).getTrades().size();
    console.info('DOMAIN-CLOSEOUT-TRADE ' + JSON.stringify({
        phase: 'declared', status: String(query.status), generation: query.generation,
        total: query.total, unrestored: query.unrestoredListingKeys.size(),
        retired: query.retiredListingKeys.size(), physicalCount
    }));
});
