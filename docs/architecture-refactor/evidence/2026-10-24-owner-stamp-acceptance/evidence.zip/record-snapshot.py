"""Record a later acceptance snapshot without rewriting the initial six-artifact inventory."""
from datetime import datetime, UTC
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

repo = Path.cwd()
proof_root = repo / 'docs/architecture-refactor/evidence'
out = proof_root / '2026-10-24-owner-stamp-acceptance'
candidate = repo / 'build/release-candidate-6e43b827'
revision = '6e43b82789a7dbf7b9659dc1c21fefecac662649'
target = candidate / 'manifest-acceptance.json'
assert not target.exists() and not (out / 'evidence.zip').exists()
initial = json.loads((candidate / 'manifest.json').read_text(encoding='utf-8'))
bindings = json.loads((candidate / 'class-bindings.json').read_text(encoding='utf-8'))
assert initial['productionRevision'] == revision and not initial['releaseReady']
assert len(initial['artifacts']) == 6
for row in initial['artifacts']:
    path = (candidate / row['path']).resolve()
    assert path.is_relative_to(candidate.resolve()) and path.stat().st_size == row['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    with zipfile.ZipFile(path) as jar:
        names = {name for name in jar.namelist() if name.startswith('com/tkisor/nekojs/') and name.endswith('.class')}
        assert names == set(bindings[row['node']]) and len(names) == row['productionClasses']
        assert all(hashlib.sha256(jar.read(name)).hexdigest() == digest for name, digest in bindings[row['node']].items())
archives = {}
for name in ['2026-10-24-owner-stamp', '2026-10-24-owner-stamp-performance',
             '2026-10-24-owner-stamp-handoff', '2026-10-24-owner-stamp-tcp',
             '2026-10-24-owner-stamp-render', '2026-10-24-owner-stamp-rollback']:
    archives[name] = hashlib.sha256((proof_root / name / 'evidence.zip').read_bytes()).hexdigest()
with zipfile.ZipFile(proof_root / '2026-10-24-owner-stamp/evidence.zip') as archive:
    matrix = json.loads(archive.read('matrix/summary.json'))
    installed = json.loads(archive.read('installed/preparation-manifest.json'))
    ide = json.loads(archive.read('installed/ide/summary.json'))
    assert matrix['sourceRevision'] == installed['sourceRevision'] == ide['sourceRevision'] == revision
    assert matrix['total'] == dict(tests=5158, failures=0, errors=0, skipped=271)
    assert json.loads(archive.read('installed/runner-exit.json'))['exitCode'] == 0
    for node in installed['nodes']:
        assert json.loads(archive.read('installed/' + node['node'] + '/runtime-verdict.json'))['verdict'] == 'PASS'
        assert json.loads(archive.read('installed/' + node['node'] + '/server-exit.json'))['exitCode'] == 0
    python_rows = [node['pyright'] for node in ide['nodes']]
    ts_rows = [side for node in ide['nodes'] for side in node['typescript']]
    assert len(python_rows) == 5 and sum(row['stubCount'] for row in python_rows) == 1609
    assert all(row['exitCode'] == 0 and row['summary']['errorCount'] == row['summary']['warningCount'] == 0 for row in python_rows)
    assert len(ts_rows) == 10 and sum(row['diagnosticCount'] for row in ts_rows) == 5537
    assert all(row['exitCode'] == 2 and row['defaultEditorIncludes'] and not row['skipLibCheck']
        and row['diagnosticsComplete'] and not row['compilerCrashed'] for row in ts_rows)
with zipfile.ZipFile(proof_root / '2026-10-24-owner-stamp-performance/evidence.zip') as archive:
    performance = json.loads(archive.read('run/judgment.json'))
    assert performance['collectionComplete'] and performance['valid'] and performance['verdict'] == 'NOT_PASS'
    assert all(row['revision'] == revision for row in performance['groups'])
    reloads = [row for row in performance['groups'] if row['group'].startswith('reload-')]
    startup = next(row for row in performance['groups'] if row['group'] == 'startup')
    assert [row['mean'] for row in reloads] == [288.2, 299.4]
    assert all(row['limit'] == 285.3 and row['verdict'] == 'FAIL' for row in reloads)
    assert startup['mean'] == 26174.8 and startup['limit'] == 41173 and startup['verdict'] == 'PASS'
with zipfile.ZipFile(proof_root / '2026-10-24-owner-stamp-tcp/evidence.zip') as archive:
    tcp_rows = [json.loads(archive.read(kind + '-' + short + '/run-result.json'))
                for kind in ['basic', 'commit'] for short in ['261', '262']]
    assert all(row['verdict'] == 'PASS' and not row['errors'] and not row['forced'] for row in tcp_rows)
    assert sum(len(row['stages']) for row in tcp_rows) == 30
    assert sum(len(row['exits']) for row in tcp_rows) == 14 and all(value == 0 for row in tcp_rows for value in row['exits'].values())
with zipfile.ZipFile(proof_root / '2026-10-24-owner-stamp-render/evidence.zip') as archive:
    render_rows = [json.loads(archive.read(short + '/run-result.json')) for short in ['121', '261', '262']]
    render_reviews = [json.loads(archive.read(short + '/pixel-review.json')) for short in ['121', '261', '262']]
    assert sum(len(row['stages']) for row in render_rows) == 30
    assert all(row['mechanicalVerdict'] == 'PASS' and not row['errors'] and not row['forced']
        and row['clientExit'] == row['serverExit'] == 0 for row in render_rows)
    assert all(row['verdict'] == 'PASS' and row['screenshotsReviewed'] for row in render_reviews)
with zipfile.ZipFile(proof_root / '2026-10-24-owner-stamp-rollback/evidence.zip') as archive:
    rollback = json.loads(archive.read('final-verdict.json'))
    rollback_rows = json.loads(archive.read('summary.json'))['records']
    assert rollback['verdict'] == 'PASS' and rollback['currentSourceRevision'] == revision
    assert rollback['separateArtifactAndDataRollback'] and len(rollback_rows) == 4
    assert all(row['verdict'] == 'PASS' and row['exitCode'] == 0 for row in rollback_rows)
snapshot = dict(productionRevision=revision, recordedAtUtc=datetime.now(UTC).isoformat(),
    checkoutRevisionAtRecording=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    artifactVersion=initial['artifactVersion'], releaseReady=False, remoteUploadPerformed=False,
    sourceVersionRepackaged=False, initialManifestSha256=hashlib.sha256((candidate / 'manifest.json').read_bytes()).hexdigest(),
    artifacts=initial['artifacts'], evidenceArchives=archives,
    gates=dict(fullMatrix=dict(verdict='PASS', **matrix['total']), installedServers=dict(verdict='PASS', nodes=5, normalStops=5),
        defaultPython=dict(verdict='PASS', stubs=1609, errors=0, warnings=0),
        fullStrictTypeScript=dict(verdict='FAIL', diagnostics=5537, skipLibCheck=False),
        reloadPerformance=dict(verdict='FAIL', meansMs=[row['mean'] for row in reloads], limitMs=285.3),
        startupPerformance=dict(verdict='PASS', meanMs=startup['mean'], limitMs=41173),
        tcp=dict(verdict='PASS', nodes=2, stages=30, normalStops=14),
        nativeRender=dict(verdict='PASS', nodes=3, originalFrames=30, syntheticNativeF3T=13, normalStops=6),
        separatedRollback=dict(verdict='PASS', phases=4, normalStops=4, scope=rollback['scope']),
        maintainerAcceptance=dict(verdict='NOT RECORDED'), finalVersionCutover=dict(verdict='NOT DONE')),
    limits=['Engineering acceptance snapshot, not release authorization.',
        'Native helper dispatch and framebuffer capture are not physical presentation or an official installer.',
        'Known d91ca974/current pair and 26.1.2 whole-world fixture only; no world-external rollback guarantee.',
        'Initial inventory is preserved byte-for-byte; this separate manifest records later bounded evidence.'])
target.write_text(json.dumps(snapshot, indent=2) + '\n', encoding='utf-8', newline='\n')
files = {name: (candidate / name).read_bytes() for name in ['manifest-acceptance.json', 'manifest.json', 'class-bindings.json', 'SHA256SUMS']}
for name in ['privacy-audit.json', 'audit-local-credentials.py']:
    files[name] = (out / name).read_bytes()
files['record-snapshot.py'] = Path(__file__).read_bytes()
files['entries.json'] = (json.dumps({name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())}, indent=2) + '\n').encode()
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
result = dict(revision=revision, entries=len(files), bytes=(out / 'evidence.zip').stat().st_size,
    sha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(), artifacts=6, releaseReady=False)
(out / 'verification.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(result))
