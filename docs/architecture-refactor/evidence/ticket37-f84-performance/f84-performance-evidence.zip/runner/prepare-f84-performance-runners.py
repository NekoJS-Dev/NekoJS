import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
runner = root/'build/ticket37-config-sync-repair'
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision.startswith('f84e2adb')
for name in ['prepare-2a421-performance.ps1', 'guard-2a421-performance.ps1', 'run-2a421-performance.py']:
    text = (runner/name).read_text(encoding='utf-8')
    text = text.replace('2a421c18bd36dc59d0006db8e68d515f0122ce8e', revision)
    text = text.replace('ticket37-perf-2a421c18', 'ticket37-perf-f84e2adb')
    text = text.replace('2a421-performance', 'f84-performance')
    target = runner/name.replace('2a421-performance', 'f84-performance')
    assert not target.exists()
    target.write_text(text, encoding='utf-8')
print(json.dumps(dict(sourceRevision=revision, groups=['reload-confirmed-1', 'reload-confirmed-2', 'startup-confirmed'],
    unchangedSampler=True, samplesPerGroup=5, startupThreshold=41173, reloadThreshold=285.3,
    noDiscardedValues=True, startAfterOwnedServersAndCompilersSettle=True)))
