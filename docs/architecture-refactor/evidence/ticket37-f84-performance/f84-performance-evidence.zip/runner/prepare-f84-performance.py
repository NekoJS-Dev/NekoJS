import json
import os
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
runner = root/'build/ticket37-config-sync-repair'
trial = root/'build/ticket37-node-ambient-installed'
assert json.loads((trial/'runtime-ports-freed.json').read_text())['normalDirectServerExits']
assert json.loads((runner/'node-ambient-ide-exit.json').read_text())['exitCode'] == 0
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision.startswith('f84e2adb')
environment = dict(os.environ)
environment['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(runner/'prepare-f84-performance.ps1')], env=environment, creationflags=subprocess.CREATE_NO_WINDOW)
(runner/'f84-performance-preparation-exit.json').write_text(json.dumps(dict(exitCode=result.returncode, sourceRevision=revision), indent=2)+'\n', encoding='utf-8')
raise SystemExit(result.returncode)
