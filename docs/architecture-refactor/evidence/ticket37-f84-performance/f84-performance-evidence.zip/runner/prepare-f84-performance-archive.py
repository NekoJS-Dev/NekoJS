from pathlib import Path

root = Path.cwd().resolve()
runner = root/'build/ticket37-config-sync-repair'
contents = (runner/'archive-2a421-performance.py').read_text(encoding='utf-8')
contents = contents.replace('2a421c18bd36dc59d0006db8e68d515f0122ce8e', 'f84e2adbc36cac31ec8b2da8a448fbc0b8bbebae')
contents = contents.replace('ticket37-perf-2a421c18', 'ticket37-perf-f84e2adb').replace('ticket37-2a421-performance', 'ticket37-f84-performance').replace('2a421-performance', 'f84-performance')
contents = contents.replace("for name in ['ApiTypeRefPyRenderer', 'PythonClassRenderer', 'PythonProbeBackend']:\n    relative = 'common/build/classes/java/main/com/tkisor/nekojs/probe/backend/python/'+name+'.class'", "for name in ['NodeModuleTypeDocs', 'NodeModuleTypeDocs$TSExtractor']:\n    relative = 'common/build/classes/java/main/com/tkisor/nekojs/core/compiler/'+name+'.class'")
contents = contents.replace('No causal claim about Python change', 'No causal claim about Node declaration change')
target = runner/'archive-f84-performance.py'
assert not target.exists()
target.write_text(contents, encoding='utf-8')
destination = root/'docs/architecture-refactor/evidence/ticket37-f84-performance'
assert not destination.exists()
destination.mkdir()
print('Prepared exclusive current-source performance archive; no sampler or threshold changed')
