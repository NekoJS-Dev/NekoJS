import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $EndCrystal, $EnderDragon } from "java:net/minecraft/world/entity/boss/enderdragon";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/boss/enderdragon/phases" {
    export class $AbstractDragonPhaseInstance implements $DragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonPhaseInstance>;
        getPhase(): $EnderDragonPhase<$DragonPhaseInstance>;
        get turnSpeed(): number;
        getTurnSpeed(): number;
        get sitting(): boolean;
        isSitting(): boolean;
        begin(): void;
        doClientTick(): void;
        doServerTick(): void;
        end(): void;
        onCrystalDestroyed(arg0: $EndCrystal, arg1: $BlockPos_, arg2: $DamageSource, arg3: $Player): void;
        onHurt(arg0: $DamageSource, arg1: number): number;
    }

    export class $AbstractDragonSittingPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get phase(): $EnderDragonPhase<$DragonPhaseInstance>;
        getPhase(): $EnderDragonPhase<$DragonPhaseInstance>;
        get sitting(): boolean;
        isSitting(): boolean;
        onHurt(arg0: $DamageSource, arg1: number): number;
    }

    export class $DragonChargePlayerPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonChargePlayerPhase>;
        getPhase(): $EnderDragonPhase<$DragonChargePlayerPhase>;
        begin(): void;
        doServerTick(): void;
        setTarget(arg0: $Vec3_): void;
    }

    export class $DragonDeathPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonDeathPhase>;
        getPhase(): $EnderDragonPhase<$DragonDeathPhase>;
        begin(): void;
        doClientTick(): void;
        doServerTick(): void;
    }

    export class $DragonHoldingPatternPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonHoldingPatternPhase>;
        getPhase(): $EnderDragonPhase<$DragonHoldingPatternPhase>;
        begin(): void;
        doServerTick(): void;
        onCrystalDestroyed(arg0: $EndCrystal, arg1: $BlockPos_, arg2: $DamageSource, arg3: $Player): void;
    }

    export class $DragonHoverPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonHoverPhase>;
        getPhase(): $EnderDragonPhase<$DragonHoverPhase>;
        get sitting(): boolean;
        isSitting(): boolean;
        begin(): void;
        doServerTick(): void;
    }

    export class $DragonLandingApproachPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonLandingApproachPhase>;
        getPhase(): $EnderDragonPhase<$DragonLandingApproachPhase>;
        begin(): void;
        doServerTick(): void;
    }

    export class $DragonLandingPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonLandingPhase>;
        getPhase(): $EnderDragonPhase<$DragonLandingPhase>;
        get turnSpeed(): number;
        getTurnSpeed(): number;
        begin(): void;
        doClientTick(): void;
        doServerTick(): void;
    }

    export interface $DragonPhaseInstance {
        begin(): void;
        doClientTick(): void;
        doServerTick(): void;
        end(): void;
        getFlySpeed(): number;
        getFlyTargetLocation(): $Vec3;
        getPhase(): $EnderDragonPhase<$DragonPhaseInstance>;
        getTurnSpeed(): number;
        isSitting(): boolean;
        onCrystalDestroyed(arg0: $EndCrystal, arg1: $BlockPos_, arg2: $DamageSource, arg3: $Player): void;
        onHurt(arg0: $DamageSource, arg1: number): number;
    }

    export class $DragonSittingAttackingPhase extends $AbstractDragonSittingPhase {
        constructor(arg0: $EnderDragon);
        get phase(): $EnderDragonPhase<$DragonSittingAttackingPhase>;
        getPhase(): $EnderDragonPhase<$DragonSittingAttackingPhase>;
        begin(): void;
        doClientTick(): void;
        doServerTick(): void;
    }

    export class $DragonSittingFlamingPhase extends $AbstractDragonSittingPhase {
        constructor(arg0: $EnderDragon);
        get phase(): $EnderDragonPhase<$DragonSittingFlamingPhase>;
        getPhase(): $EnderDragonPhase<$DragonSittingFlamingPhase>;
        begin(): void;
        doClientTick(): void;
        doServerTick(): void;
        end(): void;
        resetFlameCount(): void;
    }

    export class $DragonSittingScanningPhase extends $AbstractDragonSittingPhase {
        constructor(arg0: $EnderDragon);
        get phase(): $EnderDragonPhase<$DragonSittingScanningPhase>;
        getPhase(): $EnderDragonPhase<$DragonSittingScanningPhase>;
        begin(): void;
        doServerTick(): void;
    }

    export class $DragonStrafePlayerPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonStrafePlayerPhase>;
        getPhase(): $EnderDragonPhase<$DragonStrafePlayerPhase>;
        begin(): void;
        doServerTick(): void;
        setTarget(arg0: $LivingEntity): void;
    }

    export class $DragonTakeoffPhase extends $AbstractDragonPhaseInstance {
        constructor(arg0: $EnderDragon);
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonTakeoffPhase>;
        getPhase(): $EnderDragonPhase<$DragonTakeoffPhase>;
        begin(): void;
        doServerTick(): void;
    }

    export class $EnderDragonPhase<T extends $DragonPhaseInstance> {
        static CHARGING_PLAYER: $EnderDragonPhase<$DragonChargePlayerPhase>;
        static DYING: $EnderDragonPhase<$DragonDeathPhase>;
        static HOLDING_PATTERN: $EnderDragonPhase<$DragonHoldingPatternPhase>;
        static HOVERING: $EnderDragonPhase<$DragonHoverPhase>;
        static LANDING: $EnderDragonPhase<$DragonLandingPhase>;
        static LANDING_APPROACH: $EnderDragonPhase<$DragonLandingApproachPhase>;
        static SITTING_ATTACKING: $EnderDragonPhase<$DragonSittingAttackingPhase>;
        static SITTING_FLAMING: $EnderDragonPhase<$DragonSittingFlamingPhase>;
        static SITTING_SCANNING: $EnderDragonPhase<$DragonSittingScanningPhase>;
        static STRAFE_PLAYER: $EnderDragonPhase<$DragonStrafePlayerPhase>;
        static TAKEOFF: $EnderDragonPhase<$DragonTakeoffPhase>;
        get id(): number;
        getId(): number;
        static getById(arg0: number): $EnderDragonPhase<any>;
        static getCount(): number;
        createInstance(arg0: $EnderDragon): $DragonPhaseInstance;
        toString(): string;
    }

    export class $EnderDragonPhaseManager {
        constructor(arg0: $EnderDragon);
        get currentPhase(): $DragonPhaseInstance;
        getCurrentPhase(): $DragonPhaseInstance;
        getPhase<T extends $DragonPhaseInstance>(arg0: $EnderDragonPhase<T>): T;
        setPhase(arg0: $EnderDragonPhase<any>): void;
    }

}
