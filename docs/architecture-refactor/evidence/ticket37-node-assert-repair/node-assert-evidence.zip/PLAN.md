# Actual callable Node module declaration repair

Source base 6d10f0ece24a67ed6684577acc181bb54794d395. Preserve unrelated
working files and existing manual producers, runtime trust, permissions,
platform contracts and acceptance gates. Actual builtin assert extraction
reproduces duplicate aliases and missing assigned constructor exports.
Freeze each one-variable RED step before continuing. Remove the duplicate
source alias, resolve literal Object.assign members on the exported function,
and remove default parameter initializers from ambient class signatures.

Verify actual extracted declarations with strict caller and rejected negatives,
runtime Node regressions, common isolation, full node builds/NBT/API/guard/npm/
platform gates. Install fresh exact JARs in dedicated servers, regenerate Probe
without editing output, run default editor includes strictly and all Python
stubs, preserve all remaining/added diagnostics and actual process exit codes.
Named assert members are the scope of this repair; default callable export and
other module surface mismatches remain separate until actually verified.

No performance or old client certification inheritance. Archive raw failures,
source/patch/artifact identities and results before explicit commits/push.
Human acceptance and overall completion remain unrecorded/incomplete.
