export * as function from "java:java/util/function";

