declare module "java:java/util/function" {
    export interface $Function<T, R> {
        andThen<V>(arg0: $Function_<R, V, R, V>): $Function<T, V>;
        apply(arg0: T): R;
        compose<V>(arg0: $Function_<V, T, V, T>): $Function<V, R>;
    }
    export const $Function: {
        identity<T>(): $Function<T, T>;
    };

    export type $Function_<Host0 = any, Host1 = any, CallbackArg0 = Host0, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($Function<Host0, Host1> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
