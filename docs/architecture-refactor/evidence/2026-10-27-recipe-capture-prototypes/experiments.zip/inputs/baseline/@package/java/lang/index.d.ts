declare module "java:java/lang" {
    export class $Record {
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

}
