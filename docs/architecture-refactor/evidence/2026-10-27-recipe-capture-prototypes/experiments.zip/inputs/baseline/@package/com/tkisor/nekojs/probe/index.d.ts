import { $Record } from "java:java/lang";
import { $Function, $Function_ } from "java:java/util/function";

declare module "java:com/tkisor/nekojs/probe" {
    export class $ProbeRecipeCapturePrototypeTest$Input {
        constructor();
    }

    export interface $ProbeRecipeCapturePrototypeTest$Recipe<I extends $ProbeRecipeCapturePrototypeTest$Input> {
        getSerializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$Recipe<I>>;
        name(): string;
    }

    export interface $ProbeRecipeCapturePrototypeTest$FlatRecipe extends $ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input> {
        getSerializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$FlatRecipe>;
    }

    export class $ProbeRecipeCapturePrototypeTest$LeafRecipe implements $ProbeRecipeCapturePrototypeTest$FlatRecipe {
        constructor();
        get code(): number;
        getCode(): number;
        get serializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$LeafRecipe>;
        getSerializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$LeafRecipe>;
        name(): string;
    }

    export class $ProbeRecipeCapturePrototypeTest$OtherRecipe implements $ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input> {
        constructor();
        get serializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$OtherRecipe>;
        getSerializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$OtherRecipe>;
        get other(): boolean;
        isOther(): boolean;
        name(): string;
    }

    export class $ProbeRecipeCapturePrototypeTest$Serializer<R extends $ProbeRecipeCapturePrototypeTest$Recipe<any>> extends $Record {
        constructor(codec: $ProbeRecipeCapturePrototypeTest$MapCodec<R>);
        codec(): $ProbeRecipeCapturePrototypeTest$MapCodec<R>;
        equals(o: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $ProbeRecipeCapturePrototypeTest$MapCodec<A> {
        constructor();
        codec(): $ProbeRecipeCapturePrototypeTest$Codec<A>;
    }

    export class $ProbeRecipeCapturePrototypeTest$Codec<A> {
        constructor();
        comapFlatMap<S>(to: $Function_<A, $ProbeRecipeCapturePrototypeTest$Result<S>, A, $ProbeRecipeCapturePrototypeTest$Result<S>>, from: $Function_<S, A, S, A>): $ProbeRecipeCapturePrototypeTest$Codec<S>;
        decode(): A;
        encode(value: A): void;
    }

    export class $ProbeRecipeCapturePrototypeTest$Result<T> {
        constructor();
        get(): T;
    }

}
