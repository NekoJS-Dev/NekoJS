import type {
  $ProbeRecipeCapturePrototypeTest$Input as Input,
  $ProbeRecipeCapturePrototypeTest$Recipe as Recipe,
  $ProbeRecipeCapturePrototypeTest$FlatRecipe as FlatRecipe,
  $ProbeRecipeCapturePrototypeTest$LeafRecipe as LeafRecipe,
  $ProbeRecipeCapturePrototypeTest$OtherRecipe as OtherRecipe,
  $ProbeRecipeCapturePrototypeTest$Serializer as Serializer
} from 'java:com/tkisor/nekojs/probe';
declare const leaf: LeafRecipe;
const parent: Recipe<Input> = leaf;
const middle: FlatRecipe = leaf;
const narrowCode: number = leaf.getSerializer().codec().codec().decode().code;
const broad: Recipe<Input> = parent.getSerializer().codec().codec().decode();
const name: string = broad.name();
function roundTrip<R extends Recipe<Input>>(serializer: Serializer<R>): void {
  const codec = serializer.codec().codec();
  codec.encode(codec.decode());
}
roundTrip(parent.getSerializer());
roundTrip(leaf.getSerializer());
// @ts-expect-error The captured encoder cannot accept an arbitrary upper-bound recipe.
parent.getSerializer().codec().codec().encode(parent);
// @ts-expect-error A parent read does not acquire the concrete leaf member.
parent.getSerializer().codec().codec().decode().code;
// @ts-expect-error An unrelated serializer cannot replace this concrete serializer.
const unrelated: Serializer<OtherRecipe> = leaf.getSerializer();
// @ts-expect-error An unrelated value does not belong to the concrete codec domain.
leaf.getSerializer().codec().codec().encode('wrong');
