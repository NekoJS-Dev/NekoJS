import type {
  $ProbeRecipeCapturePrototypeTest$Input as Input,
  $ProbeRecipeCapturePrototypeTest$Recipe as Recipe,
  $ProbeRecipeCapturePrototypeTest$FlatRecipe as FlatRecipe,
  $ProbeRecipeCapturePrototypeTest$LeafRecipe as LeafRecipe,
  $ProbeRecipeCapturePrototypeTest$OtherRecipe as OtherRecipe,
  $ProbeRecipeCapturePrototypeTest$Serializer as Serializer
} from 'java:com/tkisor/nekojs/probe';
declare const leaf: LeafRecipe;
declare const ops: import('java:com/mojang/serialization').$DynamicOps<unknown>;
declare const data: unknown;
const parent: Recipe<Input> = leaf;
const middle: FlatRecipe = leaf;
const narrowCode: number = leaf.getSerializer().codec().codec().parse(ops, data).getOrThrow().code;
const broad: Recipe<Input> = parent.getSerializer().codec().codec().parse(ops, data).getOrThrow();
const name: string = broad.name();
function roundTrip<R extends Recipe<Input>>(serializer: Serializer<R>): void {
  const codec = serializer.codec().codec();
  codec.encodeStart(ops, codec.parse(ops, data).getOrThrow());
}
roundTrip(parent.getSerializer());
roundTrip(leaf.getSerializer());
// @ts-expect-error The captured encoder cannot accept an arbitrary upper-bound recipe.
parent.getSerializer().codec().codec().encodeStart(ops, parent);
// @ts-expect-error A parent read does not acquire the concrete leaf member.
parent.getSerializer().codec().codec().parse(ops, data).getOrThrow().code;
// @ts-expect-error An unrelated serializer cannot replace this concrete serializer.
const unrelated: Serializer<OtherRecipe> = leaf.getSerializer();
// @ts-expect-error An unrelated value does not belong to the concrete codec domain.
leaf.getSerializer().codec().codec().encodeStart(ops, 'wrong');

declare const secondParent: Recipe<Input>;
const firstCodec = parent.getSerializer().codec().codec();
const secondCodec = secondParent.getSerializer().codec().codec();
const foreignPayload = secondCodec.parse(ops, data).getOrThrow();
// @ts-expect-error A different existential capture must not feed the first codec.
firstCodec.encodeStart(ops, foreignPayload);
function readCaptured<R extends Recipe<Input>>(serializer: Serializer<R>): R {
  return serializer.codec().codec().parse(ops, data).getOrThrow();
}
const decodedAtBound: Recipe<Input> = readCaptured(parent.getSerializer());
// @ts-expect-error A capture must not become bottom and fabricate an arbitrary leaf value.
const fabricatedLeaf: LeafRecipe = readCaptured(parent.getSerializer());
const directlyReadable: string = parent.getSerializer().codec().codec().parse(ops, data).getOrThrow().name();
