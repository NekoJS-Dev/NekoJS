export * as serialization from "java:com/mojang/serialization";
export * as datafixers from "java:com/mojang/datafixers";

