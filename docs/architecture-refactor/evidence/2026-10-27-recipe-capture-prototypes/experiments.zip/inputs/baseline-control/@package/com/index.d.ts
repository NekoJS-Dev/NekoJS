export * as tkisor from "java:com/tkisor";
export * as mojang from "java:com/mojang";

