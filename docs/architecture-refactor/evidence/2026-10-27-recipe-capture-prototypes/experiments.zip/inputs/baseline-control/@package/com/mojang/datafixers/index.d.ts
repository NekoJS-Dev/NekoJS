import { $App, $Applicative, $K1 } from "java:com/mojang/datafixers/kinds";
import { $Function10, $Function10_, $Function11, $Function11_, $Function12, $Function12_, $Function13, $Function13_, $Function14, $Function14_, $Function15, $Function15_, $Function16, $Function16_, $Function3, $Function3_, $Function4, $Function4_, $Function5, $Function5_, $Function6, $Function6_, $Function7, $Function7_, $Function8, $Function8_, $Function9, $Function9_ } from "java:com/mojang/datafixers/util";
import { $Record } from "java:java/lang";
import { $BiFunction, $BiFunction_, $Function, $Function_ } from "java:java/util/function";

export * as util from "java:com/mojang/datafixers/util";
export * as kinds from "java:com/mojang/datafixers/kinds";

declare module "java:com/mojang/datafixers" {
    export class $Products$P1<F extends $K1, T1> extends $Record {
        constructor(t1: $App<F, T1>);
        and<T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>(arg0: $Products$P10<F, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>(arg0: $Products$P11<F, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>(arg0: $Products$P12<F, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>(arg0: $Products$P13<F, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>(arg0: $Products$P14<F, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P15<F, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T2, T3>(arg0: $Products$P2<F, T2, T3>): $Products$P3<F, T1, T2, T3>;
        and<T2, T3, T4>(arg0: $Products$P3<F, T2, T3, T4>): $Products$P4<F, T1, T2, T3, T4>;
        and<T2, T3, T4, T5>(arg0: $Products$P4<F, T2, T3, T4, T5>): $Products$P5<F, T1, T2, T3, T4, T5>;
        and<T2, T3, T4, T5, T6>(arg0: $Products$P5<F, T2, T3, T4, T5, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        and<T2, T3, T4, T5, T6, T7>(arg0: $Products$P6<F, T2, T3, T4, T5, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T2, T3, T4, T5, T6, T7, T8>(arg0: $Products$P7<F, T2, T3, T4, T5, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T2, T3, T4, T5, T6, T7, T8, T9>(arg0: $Products$P8<F, T2, T3, T4, T5, T6, T7, T8, T9>): $Products$P9<F, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        and<T2, T3, T4, T5, T6, T7, T8, T9, T10>(arg0: $Products$P9<F, T2, T3, T4, T5, T6, T7, T8, T9, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        and<T2>(arg0: $App<F, T2>): $Products$P2<F, T1, T2>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function<T1, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function_<T1, R, T1, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        toString(): string;
    }

    export class $Products$P10<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>, t9: $App<F, T9>, t10: $App<F, T10>);
        and<T11, T12>(arg0: $Products$P2<F, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T11, T12, T13>(arg0: $Products$P3<F, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T11, T12, T13, T14>(arg0: $Products$P4<F, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T11, T12, T13, T14, T15>(arg0: $Products$P5<F, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T11, T12, T13, T14, T15, T16>(arg0: $Products$P6<F, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T11>(arg0: $App<F, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function10_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t10(): $App<F, T10>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        t9(): $App<F, T9>;
        toString(): string;
    }

    export class $Products$P11<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>, t9: $App<F, T9>, t10: $App<F, T10>, t11: $App<F, T11>);
        and<T12, T13>(arg0: $Products$P2<F, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T12, T13, T14>(arg0: $Products$P3<F, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T12, T13, T14, T15>(arg0: $Products$P4<F, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T12, T13, T14, T15, T16>(arg0: $Products$P5<F, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T12>(arg0: $App<F, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function11_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t10(): $App<F, T10>;
        t11(): $App<F, T11>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        t9(): $App<F, T9>;
        toString(): string;
    }

    export class $Products$P12<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>, t9: $App<F, T9>, t10: $App<F, T10>, t11: $App<F, T11>, t12: $App<F, T12>);
        and<T13, T14>(arg0: $Products$P2<F, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T13, T14, T15>(arg0: $Products$P3<F, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T13, T14, T15, T16>(arg0: $Products$P4<F, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T13>(arg0: $App<F, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function12_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t10(): $App<F, T10>;
        t11(): $App<F, T11>;
        t12(): $App<F, T12>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        t9(): $App<F, T9>;
        toString(): string;
    }

    export class $Products$P13<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>, t9: $App<F, T9>, t10: $App<F, T10>, t11: $App<F, T11>, t12: $App<F, T12>, t13: $App<F, T13>);
        and<T14, T15>(arg0: $Products$P2<F, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T14, T15, T16>(arg0: $Products$P3<F, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T14>(arg0: $App<F, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function13_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t10(): $App<F, T10>;
        t11(): $App<F, T11>;
        t12(): $App<F, T12>;
        t13(): $App<F, T13>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        t9(): $App<F, T9>;
        toString(): string;
    }

    export class $Products$P14<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>, t9: $App<F, T9>, t10: $App<F, T10>, t11: $App<F, T11>, t12: $App<F, T12>, t13: $App<F, T13>, t14: $App<F, T14>);
        and<T15, T16>(arg0: $Products$P2<F, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T15>(arg0: $App<F, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function14_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t10(): $App<F, T10>;
        t11(): $App<F, T11>;
        t12(): $App<F, T12>;
        t13(): $App<F, T13>;
        t14(): $App<F, T14>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        t9(): $App<F, T9>;
        toString(): string;
    }

    export class $Products$P15<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>, t9: $App<F, T9>, t10: $App<F, T10>, t11: $App<F, T11>, t12: $App<F, T12>, t13: $App<F, T13>, t14: $App<F, T14>, t15: $App<F, T15>);
        and<T16>(arg0: $App<F, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function15_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t10(): $App<F, T10>;
        t11(): $App<F, T11>;
        t12(): $App<F, T12>;
        t13(): $App<F, T13>;
        t14(): $App<F, T14>;
        t15(): $App<F, T15>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        t9(): $App<F, T9>;
        toString(): string;
    }

    export class $Products$P16<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>, t9: $App<F, T9>, t10: $App<F, T10>, t11: $App<F, T11>, t12: $App<F, T12>, t13: $App<F, T13>, t14: $App<F, T14>, t15: $App<F, T15>, t16: $App<F, T16>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function16_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t10(): $App<F, T10>;
        t11(): $App<F, T11>;
        t12(): $App<F, T12>;
        t13(): $App<F, T13>;
        t14(): $App<F, T14>;
        t15(): $App<F, T15>;
        t16(): $App<F, T16>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        t9(): $App<F, T9>;
        toString(): string;
    }

    export class $Products$P2<F extends $K1, T1, T2> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>);
        and<T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>(arg0: $Products$P10<F, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>(arg0: $Products$P11<F, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>(arg0: $Products$P12<F, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>(arg0: $Products$P13<F, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P14<F, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T3, T4>(arg0: $Products$P2<F, T3, T4>): $Products$P4<F, T1, T2, T3, T4>;
        and<T3, T4, T5>(arg0: $Products$P3<F, T3, T4, T5>): $Products$P5<F, T1, T2, T3, T4, T5>;
        and<T3, T4, T5, T6>(arg0: $Products$P4<F, T3, T4, T5, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        and<T3, T4, T5, T6, T7>(arg0: $Products$P5<F, T3, T4, T5, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T3, T4, T5, T6, T7, T8>(arg0: $Products$P6<F, T3, T4, T5, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T3, T4, T5, T6, T7, T8, T9>(arg0: $Products$P7<F, T3, T4, T5, T6, T7, T8, T9>): $Products$P9<F, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        and<T3, T4, T5, T6, T7, T8, T9, T10>(arg0: $Products$P8<F, T3, T4, T5, T6, T7, T8, T9, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        and<T3, T4, T5, T6, T7, T8, T9, T10, T11>(arg0: $Products$P9<F, T3, T4, T5, T6, T7, T8, T9, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T3>(arg0: $App<F, T3>): $Products$P3<F, T1, T2, T3>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $BiFunction<T1, T2, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $BiFunction_<T1, T2, R, T1, T2, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        toString(): string;
    }

    export class $Products$P3<F extends $K1, T1, T2, T3> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>);
        and<T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>(arg0: $Products$P10<F, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>(arg0: $Products$P11<F, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>(arg0: $Products$P12<F, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P13<F, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T4, T5>(arg0: $Products$P2<F, T4, T5>): $Products$P5<F, T1, T2, T3, T4, T5>;
        and<T4, T5, T6>(arg0: $Products$P3<F, T4, T5, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        and<T4, T5, T6, T7>(arg0: $Products$P4<F, T4, T5, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T4, T5, T6, T7, T8>(arg0: $Products$P5<F, T4, T5, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T4, T5, T6, T7, T8, T9>(arg0: $Products$P6<F, T4, T5, T6, T7, T8, T9>): $Products$P9<F, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        and<T4, T5, T6, T7, T8, T9, T10>(arg0: $Products$P7<F, T4, T5, T6, T7, T8, T9, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        and<T4, T5, T6, T7, T8, T9, T10, T11>(arg0: $Products$P8<F, T4, T5, T6, T7, T8, T9, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T4, T5, T6, T7, T8, T9, T10, T11, T12>(arg0: $Products$P9<F, T4, T5, T6, T7, T8, T9, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T4>(arg0: $App<F, T4>): $Products$P4<F, T1, T2, T3, T4>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function3<T1, T2, T3, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function3_<T1, T2, T3, R, T1, T2, T3, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        toString(): string;
    }

    export class $Products$P4<F extends $K1, T1, T2, T3, T4> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>);
        and<T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>(arg0: $Products$P10<F, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>(arg0: $Products$P11<F, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P12<F, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T5, T6>(arg0: $Products$P2<F, T5, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        and<T5, T6, T7>(arg0: $Products$P3<F, T5, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T5, T6, T7, T8>(arg0: $Products$P4<F, T5, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T5, T6, T7, T8, T9>(arg0: $Products$P5<F, T5, T6, T7, T8, T9>): $Products$P9<F, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        and<T5, T6, T7, T8, T9, T10>(arg0: $Products$P6<F, T5, T6, T7, T8, T9, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        and<T5, T6, T7, T8, T9, T10, T11>(arg0: $Products$P7<F, T5, T6, T7, T8, T9, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T5, T6, T7, T8, T9, T10, T11, T12>(arg0: $Products$P8<F, T5, T6, T7, T8, T9, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T5, T6, T7, T8, T9, T10, T11, T12, T13>(arg0: $Products$P9<F, T5, T6, T7, T8, T9, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T5>(arg0: $App<F, T5>): $Products$P5<F, T1, T2, T3, T4, T5>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function4<T1, T2, T3, T4, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function4_<T1, T2, T3, T4, R, T1, T2, T3, T4, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        toString(): string;
    }

    export class $Products$P5<F extends $K1, T1, T2, T3, T4, T5> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>);
        and<T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>(arg0: $Products$P10<F, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P11<F, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T6, T7>(arg0: $Products$P2<F, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T6, T7, T8>(arg0: $Products$P3<F, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T6, T7, T8, T9>(arg0: $Products$P4<F, T6, T7, T8, T9>): $Products$P9<F, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        and<T6, T7, T8, T9, T10>(arg0: $Products$P5<F, T6, T7, T8, T9, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        and<T6, T7, T8, T9, T10, T11>(arg0: $Products$P6<F, T6, T7, T8, T9, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T6, T7, T8, T9, T10, T11, T12>(arg0: $Products$P7<F, T6, T7, T8, T9, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T6, T7, T8, T9, T10, T11, T12, T13>(arg0: $Products$P8<F, T6, T7, T8, T9, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T6, T7, T8, T9, T10, T11, T12, T13, T14>(arg0: $Products$P9<F, T6, T7, T8, T9, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T6>(arg0: $App<F, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function5<T1, T2, T3, T4, T5, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function5_<T1, T2, T3, T4, T5, R, T1, T2, T3, T4, T5, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        toString(): string;
    }

    export class $Products$P6<F extends $K1, T1, T2, T3, T4, T5, T6> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>);
        and<T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P10<F, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T7, T8>(arg0: $Products$P2<F, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T7, T8, T9>(arg0: $Products$P3<F, T7, T8, T9>): $Products$P9<F, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        and<T7, T8, T9, T10>(arg0: $Products$P4<F, T7, T8, T9, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        and<T7, T8, T9, T10, T11>(arg0: $Products$P5<F, T7, T8, T9, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T7, T8, T9, T10, T11, T12>(arg0: $Products$P6<F, T7, T8, T9, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T7, T8, T9, T10, T11, T12, T13>(arg0: $Products$P7<F, T7, T8, T9, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T7, T8, T9, T10, T11, T12, T13, T14>(arg0: $Products$P8<F, T7, T8, T9, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T7, T8, T9, T10, T11, T12, T13, T14, T15>(arg0: $Products$P9<F, T7, T8, T9, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T7>(arg0: $App<F, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function6<T1, T2, T3, T4, T5, T6, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function6_<T1, T2, T3, T4, T5, T6, R, T1, T2, T3, T4, T5, T6, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        toString(): string;
    }

    export class $Products$P7<F extends $K1, T1, T2, T3, T4, T5, T6, T7> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>);
        and<T8, T9>(arg0: $Products$P2<F, T8, T9>): $Products$P9<F, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        and<T8, T9, T10>(arg0: $Products$P3<F, T8, T9, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        and<T8, T9, T10, T11>(arg0: $Products$P4<F, T8, T9, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T8, T9, T10, T11, T12>(arg0: $Products$P5<F, T8, T9, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T8, T9, T10, T11, T12, T13>(arg0: $Products$P6<F, T8, T9, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T8, T9, T10, T11, T12, T13, T14>(arg0: $Products$P7<F, T8, T9, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T8, T9, T10, T11, T12, T13, T14, T15>(arg0: $Products$P8<F, T8, T9, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T8, T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P9<F, T8, T9, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T8>(arg0: $App<F, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function7<T1, T2, T3, T4, T5, T6, T7, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function7_<T1, T2, T3, T4, T5, T6, T7, R, T1, T2, T3, T4, T5, T6, T7, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        toString(): string;
    }

    export class $Products$P8<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>);
        and<T9, T10>(arg0: $Products$P2<F, T9, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        and<T9, T10, T11>(arg0: $Products$P3<F, T9, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T9, T10, T11, T12>(arg0: $Products$P4<F, T9, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T9, T10, T11, T12, T13>(arg0: $Products$P5<F, T9, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T9, T10, T11, T12, T13, T14>(arg0: $Products$P6<F, T9, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T9, T10, T11, T12, T13, T14, T15>(arg0: $Products$P7<F, T9, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P8<F, T9, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T9>(arg0: $App<F, T9>): $Products$P9<F, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function8<T1, T2, T3, T4, T5, T6, T7, T8, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function8_<T1, T2, T3, T4, T5, T6, T7, T8, R, T1, T2, T3, T4, T5, T6, T7, T8, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        toString(): string;
    }

    export class $Products$P9<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9> extends $Record {
        constructor(t1: $App<F, T1>, t2: $App<F, T2>, t3: $App<F, T3>, t4: $App<F, T4>, t5: $App<F, T5>, t6: $App<F, T6>, t7: $App<F, T7>, t8: $App<F, T8>, t9: $App<F, T9>);
        and<T10, T11>(arg0: $Products$P2<F, T10, T11>): $Products$P11<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        and<T10, T11, T12>(arg0: $Products$P3<F, T10, T11, T12>): $Products$P12<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        and<T10, T11, T12, T13>(arg0: $Products$P4<F, T10, T11, T12, T13>): $Products$P13<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        and<T10, T11, T12, T13, T14>(arg0: $Products$P5<F, T10, T11, T12, T13, T14>): $Products$P14<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        and<T10, T11, T12, T13, T14, T15>(arg0: $Products$P6<F, T10, T11, T12, T13, T14, T15>): $Products$P15<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        and<T10, T11, T12, T13, T14, T15, T16>(arg0: $Products$P7<F, T10, T11, T12, T13, T14, T15, T16>): $Products$P16<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        and<T10>(arg0: $App<F, T10>): $Products$P10<F, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function9<T1, T2, T3, T4, T5, T6, T7, T8, T9, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function9_<T1, T2, T3, T4, T5, T6, T7, T8, T9, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, R>): $App<F, R>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
        t9(): $App<F, T9>;
        toString(): string;
    }

}
