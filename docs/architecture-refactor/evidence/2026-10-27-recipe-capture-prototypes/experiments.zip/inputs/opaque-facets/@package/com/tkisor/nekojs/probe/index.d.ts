import { $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";

declare module "java:com/tkisor/nekojs/probe" {
    const $CaptureToken: unique symbol;
    type $Captured<T> = T & { readonly [$CaptureToken]: never };
    export class $ProbeRecipeCapturePrototypeTest$Input {
        constructor();
    }

    export interface $ProbeRecipeCapturePrototypeTest$Recipe<I extends $ProbeRecipeCapturePrototypeTest$Input> {
        getSerializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$Recipe<I>>>;
        name(): string;
    }

    export interface $ProbeRecipeCapturePrototypeTest$FlatRecipe extends $ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input> {
        getSerializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$FlatRecipe>> & $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input>>>;
        priority(): number;
    }

    export class $ProbeRecipeCapturePrototypeTest$LeafRecipe implements $ProbeRecipeCapturePrototypeTest$FlatRecipe {
        constructor();
        get code(): number;
        getCode(): number;
        get serializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$LeafRecipe> & $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$FlatRecipe>> & $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input>>>;
        getSerializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$LeafRecipe> & $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$FlatRecipe>> & $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input>>>;
        name(): string;
        priority(): number;
    }

    export class $ProbeRecipeCapturePrototypeTest$OtherRecipe implements $ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input> {
        constructor();
        get serializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$OtherRecipe> & $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input>>>;
        getSerializer(): $ProbeRecipeCapturePrototypeTest$Serializer<$ProbeRecipeCapturePrototypeTest$OtherRecipe> & $ProbeRecipeCapturePrototypeTest$Serializer<$Captured<$ProbeRecipeCapturePrototypeTest$Recipe<$ProbeRecipeCapturePrototypeTest$Input>>>;
        get other(): boolean;
        isOther(): boolean;
        name(): string;
    }

    export class $ProbeRecipeCapturePrototypeTest$Serializer<R extends $ProbeRecipeCapturePrototypeTest$Recipe<any>> extends $Record {
        constructor(codec: $MapCodec<R>);
        codec(): $MapCodec<R>;
        equals(o: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

}
