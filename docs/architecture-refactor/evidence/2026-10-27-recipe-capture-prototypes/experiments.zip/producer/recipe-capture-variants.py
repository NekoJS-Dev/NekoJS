from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess

repo = Path.cwd()
root = repo / 'common/build/probe-ts-recipe-capture-prototype'
baseline = root / 'baseline-dfu-complete'
relative = Path('@package/com/tkisor/nekojs/probe/index.d.ts')
original = (baseline / relative).read_bytes()
prefix = '$ProbeRecipeCapturePrototypeTest$'
recipe = prefix + 'Recipe<' + prefix + 'Input>'
serializer = lambda value: prefix + 'Serializer<' + value + '>'
control = """
declare const secondParent: Recipe<Input>;
const firstCodec = parent.getSerializer().codec().codec();
const secondCodec = secondParent.getSerializer().codec().codec();
const foreignPayload = secondCodec.parse(ops, data).getOrThrow();
// @ts-expect-error A different existential capture must not feed the first codec.
firstCodec.encodeStart(ops, foreignPayload);
function readCaptured<R extends Recipe<Input>>(serializer: Serializer<R>): R {
  return serializer.codec().codec().parse(ops, data).getOrThrow();
}
const decodedAtBound: Recipe<Input> = readCaptured(parent.getSerializer());
// @ts-expect-error A capture must not become bottom and fabricate an arbitrary leaf value.
const fabricatedLeaf: LeafRecipe = readCaptured(parent.getSerializer());
const directlyReadable: string = parent.getSerializer().codec().codec().parse(ops, data).getOrThrow().name();
"""
results = []
for variant in ['baseline-control', 'opaque-facets', 'bottom-facets']:
    output = root / variant
    if output.exists():
        raise RuntimeError(f'Prototype variant already exists: {output}')
    shutil.copytree(baseline, output)
    exercise = output / 'exercise.ts'
    exercise.write_text(exercise.read_text() + control)
    if variant != 'baseline-control':
        captured = (lambda value: '$Captured<' + value + '>') if variant == 'opaque-facets' else (lambda value: 'never')
        text = original.decode('utf-8')
        text = text.replace('declare module "java:com/tkisor/nekojs/probe" {',
                            'declare module "java:com/tkisor/nekojs/probe" {\n'
                            '    const $CaptureToken: unique symbol;\n'
                            '    type $Captured<T> = T & { readonly [$CaptureToken]: never };')
        owner = ''
        lines = []
        for line in text.splitlines():
            match = re.match(r'    export (?:class|interface) (\S+?)(?:[ <]|$)', line)
            if match:
                owner = match[1]
            if 'getSerializer():' in line or 'get serializer():' in line:
                if owner == prefix + 'Recipe':
                    bound = prefix + 'Recipe<I>'
                    line = line.replace(serializer(bound), serializer(captured(bound)))
                elif owner == prefix + 'FlatRecipe':
                    own = serializer(prefix + 'FlatRecipe')
                    line = line.replace(own, serializer(captured(prefix + 'FlatRecipe')) + ' & ' + serializer(captured(recipe)))
                elif owner in [prefix + 'LeafRecipe', prefix + 'OtherRecipe']:
                    own = serializer(owner)
                    facets = [serializer(captured(recipe))]
                    if owner == prefix + 'LeafRecipe':
                        facets.insert(0, serializer(captured(prefix + 'FlatRecipe')))
                    line = line.replace(own, own + ' & ' + ' & '.join(facets))
            lines.append(line)
        (output / relative).write_text('\n'.join(lines) + '\n')
    result = subprocess.run(['node', 'node_modules/typescript/bin/tsc', '-p', str(output / 'tsconfig.json')],
                            capture_output=True, timeout=120)
    (repo / 'build' / ('recipe-capture-' + variant + '-tsc.txt')).write_bytes(result.stdout)
    (repo / 'build' / ('recipe-capture-' + variant + '-stderr.txt')).write_bytes(result.stderr)
    codes = Counter(re.findall(r': error (TS\d+):', result.stdout.decode()))
    results.append(dict(variant=variant, exitCode=result.returncode, codes=dict(codes)))
    print(results[-1])
assert sha256((baseline / relative).read_bytes()).digest() == sha256(original).digest()
(repo / 'build/recipe-capture-variant-results.json').write_text(json.dumps(results, indent=2) + '\n')
