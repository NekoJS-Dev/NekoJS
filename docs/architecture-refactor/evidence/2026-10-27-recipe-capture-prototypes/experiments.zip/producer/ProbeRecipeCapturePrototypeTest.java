package com.tkisor.nekojs.probe;

import com.tkisor.nekojs.api.catalog.NekoScriptCatalogSnapshot;
import com.tkisor.nekojs.core.fs.NekoJSPaths;
import com.tkisor.nekojs.probe.backend.typescript.TypeScriptProbeBackend;
import com.tkisor.nekojs.testfixture.TestPlatformInit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/** Reproduces serializer captures through the public declaration backend. */
class ProbeRecipeCapturePrototypeTest {
    public static class Input {}
    public interface Recipe<I extends Input> {
        String name();
        Serializer<? extends Recipe<I>> getSerializer();
    }
    public interface FlatRecipe extends Recipe<Input> {
        @Override Serializer<? extends FlatRecipe> getSerializer();
        int priority();
    }
    public static class LeafRecipe implements FlatRecipe {
        public String name() { return "leaf"; }
        public int priority() { return 1; }
        public int getCode() { return 7; }
        public Serializer<LeafRecipe> getSerializer() { return null; }
    }
    public static class OtherRecipe implements Recipe<Input> {
        public String name() { return "other"; }
        public boolean isOther() { return true; }
        public Serializer<OtherRecipe> getSerializer() { return null; }
    }
    public record Serializer<R extends Recipe<?>>(com.mojang.serialization.MapCodec<R> codec) {}

    @Test
    void generate(@TempDir Path temp) throws Exception {
        TestPlatformInit.ensureInitialized();
        var snapshot = new NekoScriptCatalogSnapshot(List.of(), List.of(), List.of(), List.of(),
                List.of(), List.of(), List.of(), List.of(), List.of(), List.of(), List.of(), List.of(), List.of(),
                null, Map.of(), List.of(), List.of());
        var config = new ProbeConfig(true, ".neko_probe", new ProbeConfig.ScanConfig(
                List.of(getClass().getPackageName()), List.of(), List.of("java.time"), List.of(), 1, "SMART"));
        var context = new ProbeContext.Of(snapshot,
                List.of(Input.class, Recipe.class, FlatRecipe.class, LeafRecipe.class, OtherRecipe.class,
                        Serializer.class),
                config, NekoJSPaths.fromGameDir(temp), "typescript", temp.resolve("typescript"));
        var files = new TypeScriptProbeBackend().render(context);
        Path output = Path.of("build/probe-ts-recipe-capture-prototype/baseline-dfu-complete");
        for (var entry : files.entrySet()) {
            Path path = output.resolve(entry.getKey());
            Files.createDirectories(path.getParent());
            Files.writeString(path, entry.getValue());
        }
        Files.writeString(output.resolve("tsconfig.json"), """
                {"compilerOptions":{"strict":true,"noEmit":true,"skipLibCheck":false,"target":"ES2022","module":"ESNext","moduleResolution":"Bundler","types":[],"baseUrl":".","paths":{"java:*": ["@package/*"],"java:java/time": ["java-time-ambient.d.ts"]}},"include":["@package/**/*.d.ts","java-time-ambient.d.ts","exercise.ts"]}
                """);
        Files.writeString(output.resolve("java-time-ambient.d.ts"), """
                declare class $Duration { static toString(): string; }
                declare class $Instant { static toString(): string; }
                export { $Duration, $Instant };
                """);
        Files.writeString(output.resolve("exercise.ts"), """
                import type {
                  $ProbeRecipeCapturePrototypeTest$Input as Input,
                  $ProbeRecipeCapturePrototypeTest$Recipe as Recipe,
                  $ProbeRecipeCapturePrototypeTest$FlatRecipe as FlatRecipe,
                  $ProbeRecipeCapturePrototypeTest$LeafRecipe as LeafRecipe,
                  $ProbeRecipeCapturePrototypeTest$OtherRecipe as OtherRecipe,
                  $ProbeRecipeCapturePrototypeTest$Serializer as Serializer
                } from 'java:com/tkisor/nekojs/probe';
                declare const leaf: LeafRecipe;
                declare const ops: import('java:com/mojang/serialization').$DynamicOps<unknown>;
                declare const data: unknown;
                const parent: Recipe<Input> = leaf;
                const middle: FlatRecipe = leaf;
                const narrowCode: number = leaf.getSerializer().codec().codec().parse(ops, data).getOrThrow().code;
                const broad: Recipe<Input> = parent.getSerializer().codec().codec().parse(ops, data).getOrThrow();
                const name: string = broad.name();
                function roundTrip<R extends Recipe<Input>>(serializer: Serializer<R>): void {
                  const codec = serializer.codec().codec();
                  codec.encodeStart(ops, codec.parse(ops, data).getOrThrow());
                }
                roundTrip(parent.getSerializer());
                roundTrip(leaf.getSerializer());
                // @ts-expect-error The captured encoder cannot accept an arbitrary upper-bound recipe.
                parent.getSerializer().codec().codec().encodeStart(ops, parent);
                // @ts-expect-error A parent read does not acquire the concrete leaf member.
                parent.getSerializer().codec().codec().parse(ops, data).getOrThrow().code;
                // @ts-expect-error An unrelated serializer cannot replace this concrete serializer.
                const unrelated: Serializer<OtherRecipe> = leaf.getSerializer();
                // @ts-expect-error An unrelated value does not belong to the concrete codec domain.
                leaf.getSerializer().codec().codec().encodeStart(ops, 'wrong');
                """);
    }
}
