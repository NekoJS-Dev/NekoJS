package com.tkisor.nekojs.probe;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.tkisor.nekojs.probe.ProbeRecipeCapturePrototypeTest.*;

class CapturePositive {
    static <R extends Recipe<Input>, T> DataResult<T> roundTrip(Serializer<R> serializer, DynamicOps<T> ops, T input) {
        var codec = serializer.codec().codec();
        R value = codec.parse(ops, input).getOrThrow();
        return codec.encodeStart(ops, value);
    }

    static <T> DataResult<T> legal(Recipe<Input> recipe, DynamicOps<T> ops, T input) {
        return roundTrip(recipe.getSerializer(), ops, input);
    }
}
