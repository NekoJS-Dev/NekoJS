package com.tkisor.nekojs.probe;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.tkisor.nekojs.probe.ProbeRecipeCapturePrototypeTest.*;

class CaptureNegative {
    static <T> DataResult<T> cross(Recipe<Input> first, Recipe<Input> second, DynamicOps<T> ops, T input) {
        return first.getSerializer().codec().codec().encodeStart(ops,
                second.getSerializer().codec().codec().parse(ops, input).getOrThrow());
    }
}
