package com.tkisor.nekojs.script;

import com.google.gson.GsonBuilder;
import com.tkisor.nekojs.api.JSTypeAdapter;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.api.catalog.ManualDeclarationCatalogEntry;
import com.tkisor.nekojs.api.catalog.TypeDocCatalogEntry;
import com.tkisor.nekojs.api.data.Binding;
import com.tkisor.nekojs.api.event.EventGroup;
import com.tkisor.nekojs.api.event.ScriptBindingSchema;
import com.tkisor.nekojs.api.recipe.RecipeLifecycleContext;
import com.tkisor.nekojs.api.recipe.RecipeNamespaceEntry;
import com.tkisor.nekojs.api.plugin.IPluginRuntime;
import com.tkisor.nekojs.api.surface.ApiRuntimeView;
import com.tkisor.nekojs.api.surface.ApiSymbolId;
import com.tkisor.nekojs.api.surface.EnvironmentKey;
import com.tkisor.nekojs.core.ScriptEventBridge;
import com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator;
import com.tkisor.nekojs.core.compiler.OriginalGlobalBindingMemberValidator;
import com.tkisor.nekojs.core.compiler.ScriptCompilerRegistry;
import com.tkisor.nekojs.core.config.SandboxConfig;
import com.tkisor.nekojs.core.fs.NekoJSPaths;
import com.tkisor.nekojs.core.module.NekoModulePipelineCache;
import com.tkisor.nekojs.core.state.GlobalStateStores;
import com.tkisor.nekojs.testfixture.NekoModuleTestFixtures;
import com.tkisor.nekojs.testfixture.TestPlatformInit;
import graal.graalvm.polyglot.Context;
import graal.graalvm.polyglot.Engine;

import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** A diagnostic component contrast, excluded from production output. */
public final class BindingPreflightControl {
    private static final com.sun.management.ThreadMXBean CPU =
            (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    private record Fixture(Path path, String source) {}
    private record Sample(long wallNs, long cpuNs, long allocatedBytes) {}
    private record Pair(int pair, List<String> order, Sample before, Sample after) {}
    private static volatile Object sink;

    private static Sample measured(Runnable action) {
        long thread = Thread.currentThread().threadId();
        long allocation = CPU.getThreadAllocatedBytes(thread);
        long cpu = CPU.getCurrentThreadCpuTime();
        long wall = System.nanoTime();
        action.run();
        return new Sample(System.nanoTime()-wall, CPU.getCurrentThreadCpuTime()-cpu,
                CPU.getThreadAllocatedBytes(thread)-allocation);
    }

    private static void validate(boolean before, Fixture fixture, ScriptBindingSchema.View view) {
        if (before) OriginalGlobalBindingMemberValidator.validate(fixture.path(), fixture.source(), view);
        else GlobalBindingMemberValidator.validate(fixture.path(), fixture.source(), view);
    }

    private static List<Pair> regexPairs(List<Fixture> fixtures, ScriptBindingSchema.View view,
                                         List<String> observed, List<String> expected, int pairs, int rounds) {
        var samples = new ArrayList<Pair>();
        for (int pair=0; pair<pairs; pair++) {
            Sample before=null, after=null;
            var order = pair%2 == 0 ? List.of("before", "after") : List.of("after", "before");
            for (String arm : order) {
                Sample sample = measured(() -> {
                    for (int round=0; round<rounds; round++) {
                        observed.clear();
                        for (Fixture fixture : fixtures) validate(arm.equals("before"), fixture, view);
                    }
                });
                if (!observed.equals(expected)) throw new AssertionError("Fixture diagnostics changed");
                if (arm.equals("before")) before=sample; else after=sample;
            }
            samples.add(new Pair(pair+1, order, before, after));
        }
        return samples;
    }

    private static Map<String,Object> regex(Path root) throws Exception {
        var fixtures = new ArrayList<Fixture>();
        try (var paths = Files.walk(root)) {
            for (Path path : paths.filter(p -> p.toString().endsWith(".js")).sorted().toList()) {
                fixtures.add(new Fixture(path, Files.readString(path)));
            }
        }
        if (fixtures.size()!=6) throw new AssertionError("Expected all six recursive fixture sources");
        var observed = new ArrayList<String>();
        var schema = Map.of("Fixture", new ScriptBindingSchema.BindingMembers(Set.of("valid")),
                "ServerEvents", new ScriptBindingSchema.BindingMembers(Set.of("started", "stopped", "tickPre", "tagsUpdated")),
                "PlayerEvents", new ScriptBindingSchema.BindingMembers(Set.of("loggedIn")),
                "LevelEvents", new ScriptBindingSchema.BindingMembers(Set.of("loaded")));
        var view = new ScriptBindingSchema.View(schema,
                Set.of("console", "Math", "JSON", "Java", "global", "shared", "globalThis", "this", "arguments", "super"),
                diagnostic -> observed.add(diagnostic.type()+":"+diagnostic.callbackKind()+":"+diagnostic.throwable().getMessage()));
        var cases = new ArrayList<>(fixtures);
        Path path = root.resolve("contrast.js");
        for (String source : List.of("", "Fixture.valid(); Fixture.typo(); missing();",
                "import { One as Two, Three } from 'library'; Two.call(); Three.call();",
                "class Named {} Named.call(); function work(arg) { arg.call(); } work();",
                "try { Fixture.valid(); } catch (failure) { failure.call(); }",
                "const {left: right, ...rest} = value; right.call(); rest.call();",
                "const [first, second] = value; first.call(); second.call();",
                "for (const item of items) { item.call(); } for (key in object) { key.call(); }",
                "import { $A as $B } from 'one';\r\nimport Value from 'two';\r\n$B.call(); Value.call();")) {
            cases.add(new Fixture(path, source));
        }
        int comparisons=0;
        for (var currentSchema : List.of(schema, Map.of("Fixture", new ScriptBindingSchema.BindingMembers(Set.of("valid", "typo"))), schema)) {
            var current = new ScriptBindingSchema.View(currentSchema, view.globals(), view.reporter());
            for (Fixture fixture : cases) {
                observed.clear(); validate(true, fixture, current);
                var expected = List.copyOf(observed);
                observed.clear(); validate(false, fixture, current);
                if (!observed.equals(expected)) throw new AssertionError("Current-schema diagnostics changed");
                comparisons++;
            }
        }
        observed.clear();
        for (Fixture fixture : fixtures) validate(true, fixture, view);
        var expected = List.copyOf(observed);
        var warmups = regexPairs(fixtures, view, observed, expected, 20, 5);
        var pairs = regexPairs(fixtures, view, observed, expected, 30, 20);
        return Map.of("fixtures", fixtures.size(), "diagnosticsPerSix", expected.size(), "equivalenceCases", comparisons,
                "roundsPerArm", 20, "warmupRoundsPerArm", 5, "warmups", warmups, "pairs", pairs);
    }

    private record StubRuntime(Map<String,Binding> values) implements IPluginRuntime {
        @Override public Map<String,Binding> bindings(ScriptType type) { return values; }
        @Override public Map<String,EventGroup> eventGroups() { return Map.of(); }
        @Override public List<JSTypeAdapter<?>> adapters() { return List.of(); }
        @Override public List<TypeDocCatalogEntry> typeDocs() { return List.of(); }
        @Override public List<ManualDeclarationCatalogEntry> manualDeclarations() { return List.of(); }
        @Override public Map<String,String> nodeModules() { return Map.of(); }
        @Override public Map<String,RecipeNamespaceEntry> recipeNamespaces() { return Map.of(); }
        @Override public void beforeRecipeLoading(RecipeLifecycleContext context) {}
        @Override public void afterRecipes(RecipeLifecycleContext context) {}
        @Override public void fireInit() {}
        @Override public void fireInitStartup() {}
        @Override public void fireAfterInit() {}
        @Override public void fireBeforeScriptsLoaded(ScriptType type) {}
        @Override public void fireAfterScriptsLoaded(ScriptType type) {}
        @Override public ApiRuntimeView apiRuntime(EnvironmentKey key) { return null; }
        @Override public Object managedApiImplementation(ApiSymbolId id) { return null; }
    }

    private static Map<String,Object> binding() throws Exception {
        var bindings = new LinkedHashMap<String,Binding>();
        for (int i=0; i<72; i++) {
            String name="ControlBinding"+i;
            bindings.put(name, Binding.of(name, i%2==0 ? String.class : "value"));
        }
        var runtime = new StubRuntime(Collections.unmodifiableMap(bindings));
        var stores = new GlobalStateStores();
        var before = new OriginalScriptEnvironmentFactory(ScriptEventBridge.EMPTY, runtime, null, stores);
        var after = new ScriptEnvironmentFactory(ScriptEventBridge.EMPTY, runtime, null, stores);
        try (Engine engine = Engine.newBuilder().build();
             NekoModulePipelineCache owner = NekoModuleTestFixtures.newCache(NekoJSPaths.get(),
                     ScriptCompilerRegistry.createRuntimeRegistry(), SandboxConfig.defaultConfig())) {
            var all = new ArrayList<Pair>();
            ScriptBindingSchema.View expected = null;
            int globalsCount=0;
            for (int pair=0; pair<50; pair++) {
                Sample oldSample=null, newSample=null;
                var order=pair%2==0 ? List.of("before", "after") : List.of("after", "before");
                for (String arm : order) {
                    try (Context context = Context.newBuilder("js").engine(engine).allowAllAccess(true).build();
                         var session = owner.openSession();
                         var globals = stores.newGeneration(ScriptType.SERVER, true)) {
                        context.eval("js", "Object.defineProperty(globalThis, 'HiddenControl', { value: 1, enumerable: false })");
                        Sample sample = measured(() -> {
                            if (arm.equals("before")) before.installEnvironmentBindings(context, ScriptType.SERVER, globals, session);
                            else after.installEnvironmentBindings(context, ScriptType.SERVER, globals, session);
                        });
                        var actual = session.bindingSchemaView();
                        if (expected == null) expected = actual;
                        if (!actual.schemas().equals(expected.schemas()) || !actual.globals().equals(expected.globals())) {
                            throw new AssertionError("Installed binding schema or global names changed");
                        }
                        if (!actual.globals().contains("HiddenControl")) throw new AssertionError("Nonenumerable global missing");
                        globalsCount=actual.globals().size();
                        if (arm.equals("before")) before.discardEnvironmentBindings(context, session);
                        else after.discardEnvironmentBindings(context, session);
                        if (arm.equals("before")) oldSample=sample; else newSample=sample;
                    }
                }
                all.add(new Pair(pair+1, order, oldSample, newSample));
            }
            sink=expected;
            return Map.of("syntheticBindings", bindings.size(), "knownGlobals", globalsCount,
                    "contexts", 100, "equivalentInstalls", 100, "warmups", List.copyOf(all.subList(0,20)),
                    "pairs", List.copyOf(all.subList(20,50)));
        } finally {
            stores.closeAll();
            sink=null;
        }
    }

    public static void main(String[] args) throws Exception {
        TestPlatformInit.ensureInitialized();
        var result = new LinkedHashMap<String,Object>();
        result.put("diagnosticOnly", true);
        result.put("formalPerformanceMeasured", false);
        result.put("regex", regex(Path.of(args[0])));
        result.put("binding", binding());
        Files.writeString(Path.of(args[1]), new GsonBuilder().setPrettyPrinting().create().toJson(result));
        System.out.println("BINDING_PREFLIGHT_CONTROL_COMPLETE");
    }
}
