import hashlib
import json
import statistics
import subprocess
import time
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
tools = repo/'build/priority-closeout'
out = tools/'binding-preflight-26844b7e-v1'
assert not out.exists(), 'Preserve all attempts'
revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert revision.startswith('26844b7e')
out.mkdir()
references = [
    ('common/src/main/java/com/tkisor/nekojs/core/compiler/GlobalBindingMemberValidator.java', 'GlobalBindingMemberValidator'),
    ('common/src/main/java/com/tkisor/nekojs/script/ScriptEnvironmentFactory.java', 'ScriptEnvironmentFactory')
]
sources=[]
for path,name in references:
    source=subprocess.check_output(['git','show','24d35a5d:'+path],cwd=repo)
    (out/('baseline-'+name+'.java')).write_bytes(source)
    original=out/('Original'+name+'.java')
    original.write_bytes(source.replace(name.encode(),('Original'+name).encode()))
    sources.append(original)
control=out/'BindingPreflightControl.java'
control.write_bytes((tools/control.name).read_bytes())
sources.append(control)
original_cp=(tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text().strip().split(';')
jars=[part for part in original_cp if part.endswith('.jar') and Path(part).is_file()]
classpath=';'.join([str(repo/'common/build/classes/java/main'),str(repo/'common/build/classes/java/test'),
                    str(repo/'common/build/resources/main'),*jars])
classes=out/'classes'
classes.mkdir()
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
commands=[
    [str(java/'javac.exe'),'-J-Duser.language=en','-J-Duser.country=US','-encoding','UTF-8','-cp',classpath,'-d',str(classes),*map(str,sources)],
    [str(java/'java.exe'),'-cp',str(classes)+';'+classpath,'com.tkisor.nekojs.script.BindingPreflightControl',
     str(repo/'bench/perf/fixtures/nekojs/server_scripts'),str(out/'observations.json')]
]
for index,command in enumerate(commands):
    start=time.monotonic()
    print('CONTROL_START',index,flush=True)
    with (out/f'{index}-output.log').open('xb') as log:
        result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/f'{index}-result.json').write_text(json.dumps(dict(exitCode=result.returncode,seconds=time.monotonic()-start),indent=2)+'\n')
    print('CONTROL_EXIT',index,result.returncode,flush=True)
    assert result.returncode==0,index
observed=json.loads((out/'observations.json').read_text())
summary=dict(commit=revision,baseline='24d35a5d',diagnosticOnly=True,formalVerdictUnchanged='NOT_PASS',components={})
for component in ('regex','binding'):
    value=observed[component]
    divisor=value.get('roundsPerArm',1)
    means={arm:{key:statistics.mean(row[arm][key]/divisor for row in value['pairs'])
                for key in ('wallNs','cpuNs','allocatedBytes')} for arm in ('before','after')}
    summary['components'][component]=dict(means=means,pairedWallWins=sum(row['after']['wallNs']<row['before']['wallNs'] for row in value['pairs']),
        pairs=len(value['pairs']),wallSavedNs=means['before']['wallNs']-means['after']['wallNs'])
summary['classes']={name:hashlib.sha256((repo/'common/build/classes/java/main'/Path(path).relative_to('common/src/main/java').with_suffix('.class')).read_bytes()).hexdigest()
                    for path,name in references}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
