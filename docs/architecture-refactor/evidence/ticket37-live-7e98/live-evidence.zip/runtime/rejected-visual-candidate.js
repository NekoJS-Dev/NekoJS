ClientEvents.postEffects(() => {
    throw new Error('Owned visual candidate rejection');
});
