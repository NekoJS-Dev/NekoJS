const visualFs = require('node:fs');
const visualSignal = 'D:/mcmodDemo/NekoJS-mult/build/ticket37-live-7e98/clientA/nekojs/data/visual-step.txt';
let lastVisualStep = '';
let hudRecorded = false;
ClientEvents.postEffects(event => {
    event.register('minecraft:invert', { blurRadius: 16, blurRounds: 1 });
    event.register('ticket37:declared', { blurRadius: 2, blurRounds: 1 });
});
ClientEvents.tickPost(() => {
    if (!visualFs.existsSync(visualSignal)) return;
    const step = String(visualFs.readFileSync(visualSignal, 'utf8')).trim();
    if (step === lastVisualStep) return;
    lastVisualStep = step;
    const accepted = step === 'blur' ? PostEffects.set('minecraft:invert') : PostEffects.clear();
    console.info('LIVE-VISUAL-STEP ' + JSON.stringify({ step, accepted, generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('minecraft:invert'), current: PostEffects.current(), active: PostEffects.isActive() }));
});
ClientEvents.hud(() => {
    if (hudRecorded) return;
    hudRecorded = true;
    console.info('LIVE-RELOAD-FIRST-HUD ' + JSON.stringify({ generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('minecraft:invert'), current: PostEffects.current(), active: PostEffects.isActive() }));
});
