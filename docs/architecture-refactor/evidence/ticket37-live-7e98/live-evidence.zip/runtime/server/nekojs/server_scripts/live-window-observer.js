const liveFacade = Java.type('com.tkisor.nekojs.dynamic.DynamicRegistryFacade');
let previousWindow = '';
ServerEvents.tickPost(() => {
    const engine = liveFacade.runtime().activationEngine();
    if (engine === null) return;
    const outcomes = engine.syncOutcomes();
    const phases = engine.phaseLog();
    const state = String(engine.status()) + ':' + engine.activatedGeneration() + ':' + String(engine.transport().participants()) + ':' + outcomes.size() + ':' + phases.size();
    if (state === previousWindow) return;
    previousWindow = state;
    const rows = [];
    for (let i = 0; i < outcomes.size(); i++) {
        const row = outcomes.get(i);
        rows.push({ participant: row.participantId(), generation: Number(row.generation()), outcome: row.outcome(), reason: row.reason() });
    }
    const phaseRows = [];
    for (let i = 0; i < phases.size(); i++) {
        const row = phases.get(i);
        phaseRows.push({ phase: String(row.phase()), generation: Number(row.generation()), passed: row.passed(), errorSource: row.errorSource(), detail: row.detail() });
    }
    console.info('LIVE-WINDOW ' + JSON.stringify({ status: String(engine.status()), activatedGeneration: Number(engine.activatedGeneration()), participants: String(engine.transport().participants()), outcomes: rows, phases: phaseRows }));
});
