let firstHudSeen = false;
ClientEvents.postEffects(event => {
    event.register('minecraft:invert', { blurRadius: 16, blurRounds: 1 });
    event.register('ticket37:declared', { blurRadius: 2, blurRounds: 1 });
});
ClientEvents.loggedIn(() => {
    console.info('LIVE-VISUAL-LOGIN ' + JSON.stringify({ generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('minecraft:invert'), set: PostEffects.set('minecraft:invert') }));
});
ClientEvents.hud(() => {
    if (firstHudSeen) return;
    firstHudSeen = true;
    console.info('LIVE-VISUAL-FIRST-HUD ' + JSON.stringify({ generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('minecraft:invert'), current: PostEffects.current(), active: PostEffects.isActive() }));
});
