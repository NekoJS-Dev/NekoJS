import hashlib
import json
import shutil
import socket
import subprocess
import zipfile
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/ticket37-live-7e98'
destination = project / 'docs/architecture-refactor/evidence/ticket37-live-7e98'
destination.mkdir(exist_ok=True)
assert not (destination / 'live-evidence.zip').exists()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision == '7e98fd15175d15c8dad062bf40e2a284e04eaf51'
properties = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines() if '=' in line)
secret = properties['rcon.password'].encode()
for port in (25971, 25972, 25973, 25974):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
exit_codes = {node: json.loads((root / node / 'exit.json').read_text())['exitCode'] for node in ('server', 'clientA', 'clientB', 'clientC', 'clientD', 'clientE')}
assert exit_codes == dict(server=0, clientA=0, clientB=0, clientC=0, clientD=1, clientE=1), exit_codes
window = json.loads((root / 'window-verdict.json').read_text())
configuration = json.loads((root / 'configuration-commit-verdict.json').read_text())
assert window['abort']['status'] == 'ABORTED' and configuration['result'] == 'PASS'
client = (root / 'clientA/logs/latest.log').read_text(encoding='utf-8')

def readings(marker):
    return [json.loads(line.split(marker + ' ', 1)[1]) for line in client.splitlines() if marker + ' ' in line]

hud = readings('LIVE-RELOAD-FIRST-HUD')
steps = readings('LIVE-VISUAL-STEP')
assert [row['generation'] for row in hud] == [2, 3]
assert all(row['declared'] and row['active'] and row['current'] == 'minecraft:invert' for row in hud)
assert any(row['step'] == 'clear' and row['current'] is None and not row['active'] for row in steps)
assert len([row for row in steps if row['step'] == 'blur' and row['generation'] == 2 and row['active']]) == 2
assert 'phase=RELOAD_CANCEL' in client and 'Owned visual candidate rejection' in client
verdict = dict(sourceRevision=revision, artifactSha256=json.loads((root / 'preparation.json').read_text())['artifactSha256'],
    multiplayerWindows='PASS', visualResourceOverrideClearAndCandidateRecovery='PASS', firstHudAfterResourceReload='PASS',
    firstPixelFrame='NOT_VERIFIED', allNodeClientVisual='NOT_RUN', nativeClientOverall='FAIL', exits=exit_codes,
    nativeCrashes=['clientD: glfw.dll+0x10fa1', 'clientE: glfw.dll+0x10fa1'], crashCause='NOT_ESTABLISHED',
    loginSetFirstHud=dict(setAccepted=True, current=None, active=False), reloadFirstHud=hud, steps=steps, ownedPortsFree=True,
    productionSourceChanged=False, fakeReplies=False, packetBytesModified=False)
(destination / 'runtime-summary.json').write_text(json.dumps(verdict, indent=2)+'\n', encoding='utf-8')
files = {}
def add(path, name):
    data = path.read_bytes()
    assert secret not in data, 'Credential found in selected artifact: ' + name
    files[name] = data
for path in root.iterdir():
    if path.is_file() and (path.suffix in ('.json', '.jsonl', '.txt', '.js') or 'prepare-held' in path.name or 'handshake' in path.name or 'release-' in path.name or path.name.startswith('hold-') or path.name.startswith('disconnect-')):
        add(path, 'runtime/' + path.name)
for node in exit_codes:
    directory = root / node
    for name in ('stdout.log', 'stderr.log', 'owned-process.json', 'exit.json', 'options.txt'):
        path = directory / name
        if path.exists():
            add(path, 'runtime/' + node + '/' + name)
    for path in (directory / 'logs').glob('*.log'):
        add(path, 'runtime/' + node + '/logs/' + path.name)
    for folder in ('config', 'startup_scripts', 'server_scripts', 'client_scripts'):
        for path in (directory / 'nekojs' / folder).rglob('*'):
            if path.is_file() and path.suffix in ('.js', '.toml'):
                add(path, 'runtime/' + node + '/' + path.relative_to(directory).as_posix())
for path in (root / 'clientA/screenshots').glob('*.png'):
    add(path, 'runtime/clientA/screenshots/' + path.name)
for name in ('prepare-live-7e98.py', 'run-live-7e98.py', 'live-rcon-7e98.py', 'live-proxy-7e98.py', 'prove-live-window-7e98.py', 'prove-live-config-commit-7e98.py', 'archive-live-7e98.py'):
    add(project / 'build/ticket37-config-sync-repair' / name, 'scripts/' + name)
entries = {name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(files.items())}
archive = destination / 'live-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(files.items()):
        output.writestr(name, data)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for name, metadata in entries.items():
        assert hashlib.sha256(output.read(name)).hexdigest() == metadata['sha256']
manifest = dict(sourceRevision=revision, archive=dict(file=archive.name, bytes=archive.stat().st_size, entries=len(entries), sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
    entries=entries, exclusions=['server.properties/RCON credentials', 'world', 'account/launcher arguments', 'binaries/libraries/assets', 'raw hs_err native crash reports'],
    rawCrashReports={str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in root.glob('client*/hs_err_pid*.log')})
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
for source, target in [('2026-10-10_00.51.39.png', 'world.png'), ('2026-10-10_01.00.07.png', 'blur.png'), ('2026-10-10_01.00.23.png', 'cleared.png'), ('2026-10-10_01.01.08.png', 'retained-after-rejection.png')]:
    shutil.copyfile(root / 'clientA/screenshots' / source, destination / target)
print(json.dumps(dict(archive=manifest['archive'], exits=exit_codes, ownedPortsFree=True, hashReadbackAndCredentialScan='PASS')))
