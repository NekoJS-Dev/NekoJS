import hashlib
import json
import re
import subprocess
import sys
import uuid
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/ticket37-live-7e98'
java = Path('C:/Program Files/Java/jdk-25.0.2/bin/java.exe')
mode = sys.argv[1]
directory = root / ('server' if mode == 'server' else 'client' + mode)
assert directory.parent == root and directory.exists()
assert not (directory / 'owned-process.json').exists()
if mode == 'server':
    args = [str(java), '-Xms512M', '-Xmx2G', '@libraries/net/neoforged/neoforge/26.2.0.75/win_args.txt', 'nogui']
else:
    assert mode in ('A', 'B', 'C', 'D', 'E')
    mc = project / 'build/ticket37-config-sync-installed-attempt1/launcherA/.minecraft'
    base = json.loads((mc / 'versions/26.2/26.2.json').read_text(encoding='utf-8'))
    neo = json.loads((mc / 'versions/neoforge-26.2.0.75/neoforge-26.2.0.75.json').read_text(encoding='utf-8'))
    features = dict(has_custom_resolution=True, is_quick_play_multiplayer=True)

    def allowed(entry):
        if 'rules' not in entry:
            return True
        result = False
        for rule in entry['rules']:
            os = rule.get('os', {})
            matches = os.get('name', 'windows') == 'windows' and os.get('arch', 'amd64') in ('amd64', 'x86_64')
            matches = matches and all(features.get(k, False) == v for k, v in rule.get('features', {}).items())
            if matches:
                result = rule['action'] == 'allow'
        return result

    libraries = {}
    for lib in base['libraries'] + neo['libraries']:
        if not allowed(lib):
            continue
        artifact = lib.get('downloads', {}).get('artifact')
        if not artifact:
            continue
        path = mc / 'libraries' / artifact['path']
        assert path.is_file(), artifact['path']
        assert hashlib.sha1(path.read_bytes()).hexdigest() == artifact['sha1'], artifact['path']
        coordinates = lib['name'].split(':')
        key = ':'.join(coordinates[:2] + coordinates[3:])
        libraries[key] = str(path.resolve())
    clientjar = mc / 'versions/26.2/26.2.jar'
    assert hashlib.sha1(clientjar.read_bytes()).hexdigest() == base['downloads']['client']['sha1']
    substitutions = dict(auth_player_name='NekoLive' + mode, auth_uuid=uuid.uuid3(uuid.NAMESPACE_DNS, 'owned.neko.live.' + mode).hex,
        auth_access_token='0', auth_xuid='0', clientid='0', version_name=neo['id'], version_type='release',
        game_directory=str(directory), assets_root=str((mc / 'assets').resolve()), assets_index_name=base['assetIndex']['id'],
        natives_directory=str(directory / 'owned-natives'), library_directory=str((mc / 'libraries').resolve()),
        launcher_name='owned-acceptance', launcher_version='1', classpath=';'.join(list(libraries.values()) + [str(clientjar)]),
        resolution_width='854', resolution_height='480', quickPlayMultiplayer='127.0.0.1:' + str(dict(C=25973, D=25974, E=25974).get(mode, 25971)))

    def expand(entries):
        output = []
        for entry in entries:
            if isinstance(entry, dict):
                if not allowed(entry):
                    continue
                entry = entry['value']
            for value in ([entry] if isinstance(entry, str) else entry):
                value = re.sub(r'\$\{([^}]+)\}', lambda m: substitutions[m.group(1)], value)
                output.append(value)
        return output

    args = [str(java), '-Xms512M', '-Xmx2G'] + expand(base['arguments']['jvm'] + neo['arguments']['jvm'])
    args += [neo['mainClass']] + expand(base['arguments']['game'] + neo['arguments']['game'])
    # Java argument files avoid the Windows command-line limit; these are synthetic offline arguments.
    argument_file = directory / 'owned-java-args.txt'
    argument_file.write_text('\n'.join('"' + arg.replace('\\', '\\\\').replace('"', '\\"') + '"' for arg in args[1:]) + '\n', encoding='utf-8')
    args = [str(java), '@' + str(argument_file)]
with (directory / 'stdout.log').open('xb') as out, (directory / 'stderr.log').open('xb') as err:
    process = subprocess.Popen(args, cwd=directory, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
(directory / 'owned-process.json').write_text(json.dumps(dict(pid=process.pid, executable=str(java), directory=str(directory), mode=mode), indent=2))
print('OWNED_PROCESS_STARTED', mode, process.pid, flush=True)
code = process.wait()
(directory / 'exit.json').write_text(json.dumps(dict(mode=mode, exitCode=code)))
print('OWNED_PROCESS_EXIT', mode, code, flush=True)
