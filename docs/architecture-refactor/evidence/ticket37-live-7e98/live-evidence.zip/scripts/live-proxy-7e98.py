import json
import re
import socket
import sys
import threading
import time
import zlib
from pathlib import Path

root = Path.cwd() / 'build/ticket37-live-7e98'
letter = sys.argv[1]
port = int(sys.argv[2])
assert letter in ('C', 'D', 'E') and port in (25973, 25974)
lock = threading.Lock()
ended = threading.Event()
log = root / ('proxy' + letter + '.jsonl')
assert not log.exists()

def note(event, **fields):
    with lock, log.open('a', encoding='utf-8') as output:
        output.write(json.dumps(dict(time=time.time(), event=event, client=letter, **fields)) + '\n')

def varint(data, offset=0):
    result = 0
    for i in range(5):
        if offset + i >= len(data):
            return None
        value = data[offset + i]
        result |= (value & 127) << (7 * i)
        if value < 128:
            return result, offset + i + 1
    raise ValueError('Invalid framed VarInt')

listener = socket.socket()
listener.bind(('127.0.0.1', port))
listener.listen(1)
note('listening', port=port)
print('OWNED_PROXY_LISTENING', letter, port, flush=True)
client, _ = listener.accept()
listener.close()
server = socket.create_connection(('127.0.0.1', 25971))
note('connected')
if letter in ('D', 'E'):
    (root / (letter + '-handshake-held')).touch()
    note('handshake-held')
    deadline = time.monotonic() + 240
    while not (root / ('release-' + letter + '-handshake')).exists():
        assert time.monotonic() < deadline, 'Owned handshake hold expired'
        time.sleep(0.01)
    note('handshake-released')

def close():
    ended.set()
    for connection in (client, server):
        try:
            connection.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        connection.close()

def upstream():
    try:
        while not ended.is_set():
            data = client.recv(65536)
            if not data:
                break
            server.sendall(data)
    except OSError as error:
        note('upstream-ended', error=type(error).__name__)
    finally:
        close()

thread = threading.Thread(target=upstream)
thread.start()
buffer = b''
try:
    while not ended.is_set():
        data = server.recv(65536)
        if not data:
            break
        buffer += data
        while True:
            head = varint(buffer)
            if head is None or len(buffer) < head[1] + head[0]:
                break
            end = head[1] + head[0]
            frame, body = buffer[:end], buffer[head[1]:end]
            buffer = buffer[end:]
            candidates = [body]
            compressed = varint(body)
            if compressed:
                try:
                    candidates.append(zlib.decompress(body[compressed[1]:]) if compressed[0] else body[compressed[1]:])
                except zlib.error:
                    pass
            message = None
            for decoded in candidates:
                if b'nekojs:dynamic_registry_sync' not in decoded:
                    continue
                start = decoded.find(b'{"v":1,')
                if start >= 0:
                    # Only inspect the existing JSON payload; forward the original frame unchanged.
                    message, _ = json.JSONDecoder().raw_decode(decoded[start:].decode('utf-8'))
                    break
            if message:
                note('dynamic-frame', kind=message['kind'], generation=message['generation'])
                if message['kind'] == 'PREPARE' and (root / ('hold-' + letter + '-prepare')).exists():
                    (root / (letter + '-prepare-held')).write_text(json.dumps(message))
                    note('prepare-held', generation=message['generation'])
                    deadline = time.monotonic() + 8
                    while not (root / ('release-' + letter + '-prepare')).exists():
                        if (root / ('disconnect-' + letter)).exists():
                            note('disconnect-before-delivery', generation=message['generation'])
                            close()
                            break
                        if time.monotonic() >= deadline:
                            note('hold-expired', generation=message['generation'])
                            close()
                            break
                        time.sleep(0.005)
                    if ended.is_set():
                        break
                    note('prepare-released', generation=message['generation'])
            if not ended.is_set():
                client.sendall(frame)
except (OSError, ValueError) as error:
    note('downstream-ended', error=type(error).__name__, detail=str(error))
finally:
    close()
    thread.join(timeout=5)
    note('proxy-closed')
    print('OWNED_PROXY_EXIT', letter, flush=True)
