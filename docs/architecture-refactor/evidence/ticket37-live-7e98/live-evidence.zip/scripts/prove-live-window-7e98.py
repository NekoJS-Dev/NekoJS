import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd() / 'build/ticket37-live-7e98'
helper = Path('build/ticket37-config-sync-repair/live-rcon-7e98.py')
assert not (root / 'window-verdict.json').exists()

def wait(path, seconds):
    deadline = time.monotonic() + seconds
    while not path.exists():
        assert time.monotonic() < deadline, 'Owned window not reached: ' + path.name
        time.sleep(0.005)

def command(value):
    result = subprocess.run([sys.executable, str(helper), value], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)

def snapshots():
    text = (root / 'server/logs/latest.log').read_text(encoding='utf-8')
    return [json.loads(line.split('LIVE-WINDOW ', 1)[1]) for line in text.splitlines() if 'LIVE-WINDOW ' in line]

wait(root / 'D-handshake-held', 55)
baseline = snapshots()[-1]['activatedGeneration']
for letter in ('C', 'D'):
    (root / ('hold-' + letter + '-prepare')).touch()
fixture = root / 'server/nekojs/server_scripts/proof-dynamic.js'
old = fixture.read_bytes()
(root / 'dynamic-before-window.js').write_bytes(old)
fixture.write_text(old.decode('utf-8').replace("    console.info('B7-INSTALLED", "    event.item('ticket37_live:window_item', build => { build.maxStackSize = 9; });\n    console.info('B7-INSTALLED"), encoding='utf-8')
reload = command('nekojs reload server')
wait(root / 'C-prepare-held', 4)
(root / 'release-D-handshake').touch()
wait(root / 'D-prepare-held', 6)
held = json.loads((root / 'D-prepare-held').read_text())
assert held['kind'] == 'PREPARE', held
(root / 'disconnect-D').touch()
(root / 'release-C-prepare').touch()
deadline = time.monotonic() + 6
aborted = None
while time.monotonic() < deadline:
    candidates = [row for row in snapshots() if row['status'] == 'ABORTED']
    if candidates:
        aborted = candidates[-1]
        break
    time.sleep(0.02)
assert aborted, 'No actual abort snapshot'
assert aborted['activatedGeneration'] == baseline
assert any(row['generation'] == held['generation'] and row['outcome'] == 'joined-mid-transaction' for row in aborted['outcomes'])
assert any(row['generation'] == held['generation'] and row['detail'] == 'participant disconnected before acking the prepare' for row in aborted['phases'])
assert not any(row['generation'] == held['generation'] and row['phase'] == 'COMMIT' for row in aborted['phases'])
missing = command('give NekoLiveA ticket37_live:window_item')
assert 'Unknown item' in missing['response'], missing
recovery = command('nekojs reload server')
time.sleep(1)
recovered = snapshots()[-1]
assert recovered['status'] == 'COMMITTED' and recovered['activatedGeneration'] > held['generation'], recovered
generation = recovered['activatedGeneration']
acks = [row for row in recovered['outcomes'] if row['generation'] == generation and row['outcome'] == 'ack']
reports = [row for row in recovered['outcomes'] if row['generation'] == generation and row['outcome'] == 'activation-report']
assert len(acks) == 3 and len(reports) == 3, (acks, reports)
give = command('give NekoLiveA ticket37_live:window_item')
assert 'Gave' in give['response'], give
verdict = dict(source='7e98fd15175d15c8dad062bf40e2a284e04eaf51', baselineGeneration=baseline, abortedGeneration=held['generation'],
    configurationJoinedWhileAwaitingAck=True, disconnectedBeforePrepareDelivery=True, fakeReplies=False, wireBytesModified=False,
    abort=aborted, missingAfterAbort=missing, recovery=recovered, recoveryGive=give)
(root / 'window-verdict.json').write_text(json.dumps(verdict, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(result='PASS', baseline=baseline, abortedGeneration=held['generation'], recoveredGeneration=generation, realAcks=len(acks), realReports=len(reports))))
