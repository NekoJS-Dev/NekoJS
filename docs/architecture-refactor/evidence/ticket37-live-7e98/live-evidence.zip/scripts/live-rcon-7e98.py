import importlib.util
import json
import socket
import sys
from pathlib import Path

root = Path.cwd() / 'build/ticket37-live-7e98'
spec = importlib.util.spec_from_file_location('owned_rcon', Path('bench/perf/rcon.py').resolve())
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
properties = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines() if '=' in line)
command = sys.argv[1]
with socket.create_connection(('127.0.0.1', int(properties['rcon.port'])), timeout=10) as connection:
    connection.settimeout(60)
    rcon.send_packet(connection, 1, 3, properties['rcon.password'])
    auth = rcon.recv_packet(connection)
    assert auth and auth[0] != -1
    rcon.send_packet(connection, 2, 2, command)
    result = rcon.recv_packet(connection)
    assert result and result[0] == 2
    row = dict(command=command, response=result[2])
    with (root / 'rcon.jsonl').open('a', encoding='utf-8') as output:
        output.write(json.dumps(row) + '\n')
    print(json.dumps(row))
