import hashlib
import json
import shutil
import socket
import subprocess
import uuid
from pathlib import Path

project = Path.cwd().resolve()
revision = '7e98fd15175d15c8dad062bf40e2a284e04eaf51'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == revision
root = project / 'build/ticket37-live-7e98'
assert not root.exists()
for port in (25971, 25972):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
old = project / 'build/ticket37-config-sync-installed-attempt1'
installed = project / 'build/ticket37-interface-static-installed/26.2.0'
artifact = installed / 'mods/nekojs-neoforge-26.2.0-1.1.0-preview3.jar'
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == '9acfb41ec223240054d852f04fc6f892c1be62f64dea1af71008c417fa70bd93'
server = root / 'server'
(server / 'mods').mkdir(parents=True)
(server / 'libraries').symlink_to((installed / 'libraries').resolve(), target_is_directory=True)
shutil.copyfile(artifact, server / 'mods' / artifact.name)
graal = old / 'server/mods/graal-1504336-8762962.jar'
shutil.copyfile(graal, server / 'mods' / graal.name)
for folder in ('config', 'startup_scripts'):
    shutil.copytree(old / 'server/nekojs' / folder, server / 'nekojs' / folder)
(server / 'nekojs/server_scripts').mkdir()
shutil.copyfile(old / 'proof-dynamic-before-live-add.js', server / 'nekojs/server_scripts/proof-dynamic.js')
shutil.copyfile(old / 'server/nekojs/server_scripts/proof-sync-observer.js', server / 'nekojs/server_scripts/proof-sync-observer.js')
(server / 'eula.txt').write_text('eula=true\n')
(server / 'server.properties').write_text('\n'.join(['server-ip=127.0.0.1', 'server-port=25971', 'enable-rcon=true', 'rcon.port=25972', 'rcon.password=' + uuid.uuid4().hex, 'online-mode=false', 'level-name=owned-live-7e98-world', 'view-distance=3', 'simulation-distance=3', 'max-players=4', 'spawn-protection=0']) + '\n')
for letter in ('A', 'B', 'C'):
    client = root / ('client' + letter)
    (client / 'mods').mkdir(parents=True)
    for jar in (artifact, graal):
        shutil.copyfile(jar, client / 'mods' / jar.name)
    for folder in ('config', 'startup_scripts'):
        shutil.copytree(old / 'server/nekojs' / folder, client / 'nekojs' / folder)
    (client / 'options.txt').write_text('enableVsync:false\nmaxFps:30\nrenderDistance:3\nsimulationDistance:3\nentityDistanceScaling:0.5\nfullscreen:false\nskipMultiplayerWarning:true\n')
(root / 'preparation.json').write_text(json.dumps(dict(sourceRevision=revision, artifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(), profile=str(root), freshWorld=True, dynamicPreseeded=False, accountType='synthetic-offline'), indent=2) + '\n')
print('OWNED_LIVE_PROFILES_PREPARED')
