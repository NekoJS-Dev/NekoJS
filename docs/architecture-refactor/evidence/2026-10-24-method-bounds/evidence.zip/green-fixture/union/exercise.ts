import type { $TypeScriptMethodBoundsTest$Host as Host } from 'java:com/tkisor/nekojs/probe';
declare const host: Host;
host.select({base: 1, alternate() { return 'owned'; }});
host.select({base: 1, alternateNumber() { return 1; }});
// @ts-expect-error The alternate branch cannot bypass the first bound.
host.select({alternate() { return 'owned'; }});
// @ts-expect-error The intersection also rejects a missing union branch.
host.select({base: 1});
