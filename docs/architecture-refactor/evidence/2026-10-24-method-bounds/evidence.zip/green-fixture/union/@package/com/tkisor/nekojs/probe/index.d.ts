declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptMethodBoundsTest$Host {
        constructor();
        select<T extends ($TypeScriptMethodBoundsTest$Primary) & ($TypeScriptMethodBoundsTest$Alternate | $TypeScriptMethodBoundsTest$Replacement)>(value: T): T;
    }

    export interface $TypeScriptMethodBoundsTest$Alternate {
        alternateNumber(): number;
    }

    export class $TypeScriptMethodBoundsTest$Primary {
        constructor();
        base: number;
    }

    export interface $TypeScriptMethodBoundsTest$Replacement {
        alternate(): string;
    }

    export type $TypeScriptMethodBoundsTest$Alternate_<CallbackResult = number> = (() => CallbackResult) | ($TypeScriptMethodBoundsTest$Alternate & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptMethodBoundsTest$Replacement_<CallbackResult = string> = (() => CallbackResult) | ($TypeScriptMethodBoundsTest$Replacement & { readonly [Symbol.hasInstance]?: never });
}
