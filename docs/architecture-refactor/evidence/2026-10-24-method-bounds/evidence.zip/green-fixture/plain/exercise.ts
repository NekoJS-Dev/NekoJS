import type { $TypeScriptMethodBoundsTest$Host as Host } from 'java:com/tkisor/nekojs/probe';
declare const host: Host;
declare const valid: {base: number; marker(): string};
const result = host.select(valid);
const marker: string = result.marker();
// @ts-expect-error The second method bound remains required.
host.select({base: 1});
// @ts-expect-error The first method bound remains required.
host.select({marker() { return 'owned'; }});
