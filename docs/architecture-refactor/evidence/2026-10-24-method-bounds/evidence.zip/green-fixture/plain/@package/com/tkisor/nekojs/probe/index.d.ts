import { $SecondaryBound, $SecondaryBound_ } from "java:com/tkisor/nekojs/testfixture/probe";

declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptMethodBoundsTest$Host {
        constructor();
        select<T extends ($TypeScriptMethodBoundsTest$Primary) & ($SecondaryBound)>(value: T): T;
    }

    export class $TypeScriptMethodBoundsTest$Primary {
        constructor();
        base: number;
    }

}
