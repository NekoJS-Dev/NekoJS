declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptMethodBoundsTest$Host {
        constructor();
        select<T extends ($TypeScriptMethodBoundsTest$Primary) & ($TypeScriptMethodBoundsTest$Replacement)>(value: T): T;
    }

    export class $TypeScriptMethodBoundsTest$Primary {
        constructor();
        base: number;
    }

    export interface $TypeScriptMethodBoundsTest$Replacement {
        alternate(): string;
    }

    export type $TypeScriptMethodBoundsTest$Replacement_<CallbackResult = string> = (() => CallbackResult) | ($TypeScriptMethodBoundsTest$Replacement & { readonly [Symbol.hasInstance]?: never });
}
