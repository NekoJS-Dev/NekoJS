interface Original { value(input: string): string; }
interface Indexed { value: Original['value']; }
declare const original: Original;
declare const indexed: Indexed;
original.value = (input: string) => input;
indexed.value = (input: string) => input;
