declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$RemappedField {
        constructor();
        value: number;
        "operation()"(): number;
    }

}
