import type { $TypeScriptFieldMethodSelectorTest$RemappedField as Field } from 'java:com/tkisor/nekojs/probe/ir';
declare const field: Field;
const value: number = field.value;
const called: number = field["operation()"]();
// @ts-expect-error A remapped ordinary name is not the Java selector identity.
field["value()"]();
