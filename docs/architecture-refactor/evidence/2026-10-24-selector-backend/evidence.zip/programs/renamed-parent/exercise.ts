import type { $TypeScriptFieldMethodSelectorTest$RenameChild as Child } from 'java:com/tkisor/nekojs/probe/ir';
declare const child: Child;
const data: number = child.y;
const parent: string = child["x()"]();
const own: string = child.x(0.5);
// @ts-expect-error The unedited inherited copy follows the ancestor's explicit rename.
child.x();
