declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$RenameChild extends $TypeScriptFieldMethodSelectorTest$RenameParent {
        constructor();
        y: number;
        x(input: number): string;
        "x(int)"(input: number): string;
        "x()"(): string;
    }

    export class $TypeScriptFieldMethodSelectorTest$RenameParent {
        constructor();
        "x(int)"(input: number): string;
        "x()"(): string;
    }

}
