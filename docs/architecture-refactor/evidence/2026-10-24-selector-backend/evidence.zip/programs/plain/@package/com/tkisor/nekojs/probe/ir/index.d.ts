declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$Coordinate implements $TypeScriptFieldMethodSelectorTest$Position {
        constructor();
        x: number;
        "x(double)"(value: number): $TypeScriptFieldMethodSelectorTest$Coordinate;
        "x()"(): number;
    }

    export interface $TypeScriptFieldMethodSelectorTest$Position {
        "x()"(): number;
    }

    export class $TypeScriptFieldMethodSelectorTest$OrdinaryPosition implements $TypeScriptFieldMethodSelectorTest$Position {
        constructor();
        x(): number;
        "x()"(): number;
    }

    export interface $TypeScriptFieldMethodSelectorTest$InheritedPosition extends $TypeScriptFieldMethodSelectorTest$Position {
        x(): number;
    }

    export type $TypeScriptFieldMethodSelectorTest$Position_<CallbackResult = number> = (() => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$Position & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptFieldMethodSelectorTest$InheritedPosition_<CallbackResult = number> = (() => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$InheritedPosition & { readonly [Symbol.hasInstance]?: never });
}
