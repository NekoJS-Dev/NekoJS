import type { $TypeScriptFieldMethodSelectorTest$Coordinate as Coordinate,
    $TypeScriptFieldMethodSelectorTest$Position as Position,
    $TypeScriptFieldMethodSelectorTest$OrdinaryPosition as Ordinary,
    $TypeScriptFieldMethodSelectorTest$InheritedPosition as Inherited } from 'java:com/tkisor/nekojs/probe/ir';
declare const coordinate: Coordinate;
declare const ordinary: Ordinary;
declare const inherited: Inherited;
const parent: Position = coordinate;
const read: number = coordinate.x;
coordinate.x = 7;
const called: number = coordinate["x()"]();
const updated: Coordinate = coordinate["x(double)"](8);
const extracted = coordinate["x()"];
const extractedValue: number = extracted();
const parentValue: number = parent["x()"]();
const ordinaryValue: number = ordinary.x();
const ordinarySelector: number = ordinary["x()"]();
const inheritedValue: number = inherited.x();
const inheritedSelector: number = inherited["x()"]();
// @ts-expect-error The actual field is not a callable property value.
coordinate.x();
// @ts-expect-error The parent uses the selector to admit its field-bearing implementation.
parent.x();
// @ts-expect-error The selected Java setter retains its numeric input.
coordinate["x(double)"]('bad');
// @ts-expect-error Field writes keep their original numeric type.
coordinate.x = 'bad';
