import type { $TypeScriptFieldMethodSelectorTest$OrdinaryGrandchild as Child } from 'java:com/tkisor/nekojs/probe/ir';
declare const child: Child;
const ordinary: number = child.x();
const selector: number = child["x()"]();
