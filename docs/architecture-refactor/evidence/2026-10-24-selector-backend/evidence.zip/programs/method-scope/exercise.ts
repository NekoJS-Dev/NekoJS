import type { $TypeScriptFieldMethodSelectorTest$Payload as Payload,
    $TypeScriptFieldMethodSelectorTest$InheritedBounded as Inherited,
    $TypeScriptFieldMethodSelectorTest$BoundedField as Field } from 'java:com/tkisor/nekojs/probe/ir';
declare const inherited: Inherited<number>;
declare const field: Field<number>;
declare const input: Payload<number>;
const ordinary: Payload<number> = inherited.value(input);
const selector: Payload<number> = field["value(com.tkisor.nekojs.probe.ir.TypeScriptFieldMethodSelectorTest$Payload)"](input);
// @ts-expect-error The substituted method bound still requires the class's actual argument.
inherited.value({item: 'wrong'});
