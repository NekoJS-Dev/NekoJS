declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$Payload<T> {
        constructor();
        item: T;
    }

    export interface $TypeScriptFieldMethodSelectorTest$BoundedPosition<P> {
        "value(com.tkisor.nekojs.probe.ir.TypeScriptFieldMethodSelectorTest$Payload)"<C extends $TypeScriptFieldMethodSelectorTest$Payload<P>>(input: C): C;
    }

    export class $TypeScriptFieldMethodSelectorTest$BoundedField<P> implements $TypeScriptFieldMethodSelectorTest$BoundedPosition<P> {
        constructor();
        value: P;
        "value(com.tkisor.nekojs.probe.ir.TypeScriptFieldMethodSelectorTest$Payload)"<C extends $TypeScriptFieldMethodSelectorTest$Payload<P>>(input: C): C;
    }

    export interface $TypeScriptFieldMethodSelectorTest$InheritedBounded<C> extends $TypeScriptFieldMethodSelectorTest$BoundedPosition<C> {
        value<C1 extends $TypeScriptFieldMethodSelectorTest$Payload<C>>(input: C1): C1;
    }

    export type $TypeScriptFieldMethodSelectorTest$BoundedPosition_<Host0 = any, CallbackArg0 = any, CallbackResult = any> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$BoundedPosition<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptFieldMethodSelectorTest$InheritedBounded_<Host0 = any, CallbackArg0 = any, CallbackResult = any> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$InheritedBounded<Host0> & { readonly [Symbol.hasInstance]?: never });
}
