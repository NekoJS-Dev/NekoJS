import type { $TypeScriptFieldMethodSelectorTest$GenericOperation as Operation,
    $TypeScriptFieldMethodSelectorTest$StringField as Field } from 'java:com/tkisor/nekojs/probe/ir';
declare const field: Field;
const parent: Operation<string> = field;
const value: number = field.value;
const direct: string = field["value(java.lang.String)"]('input');
const inherited: string = field["value(java.lang.Object)"]('input');
const selected: string = parent["value(java.lang.Object)"]('input');
// @ts-expect-error Erasure does not remove the actual generic argument constraint.
field["value(java.lang.Object)"](false);
