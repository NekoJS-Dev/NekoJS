declare module "java:com/tkisor/nekojs/probe/ir" {
    export interface $TypeScriptFieldMethodSelectorTest$GenericOperation<T> {
        "value(java.lang.Object)"(input: T): T;
    }

    export class $TypeScriptFieldMethodSelectorTest$StringField implements $TypeScriptFieldMethodSelectorTest$GenericOperation<string> {
        constructor();
        value: number;
        "value(java.lang.String)"(input: string): string;
        "value(java.lang.Object)"(input: string): string;
    }

    export type $TypeScriptFieldMethodSelectorTest$GenericOperation_<Host0 = any, CallbackArg0 = Host0, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$GenericOperation<Host0> & { readonly [Symbol.hasInstance]?: never });
}
