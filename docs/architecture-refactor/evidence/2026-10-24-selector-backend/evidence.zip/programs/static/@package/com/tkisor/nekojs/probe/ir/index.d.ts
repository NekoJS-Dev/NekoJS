declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$StaticField {
        constructor();
        static x: number;
        x(): number;
    }

}
