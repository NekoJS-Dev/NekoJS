import { $TypeScriptFieldMethodSelectorTest$StaticField as Field } from 'java:com/tkisor/nekojs/probe/ir';
declare const field: Field;
const value: number = Field.x;
const called: number = field.x();
