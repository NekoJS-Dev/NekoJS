declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$DefaultField implements $TypeScriptFieldMethodSelectorTest$DefaultPosition {
        constructor();
        x: number;
    }

    export interface $TypeScriptFieldMethodSelectorTest$DefaultPosition {
    }

}
