import type { $TypeScriptFieldMethodSelectorTest$Payload as Payload,
    $TypeScriptFieldMethodSelectorTest$InheritedAuthored as Inherited,
    $TypeScriptFieldMethodSelectorTest$OverloadedInheritedAuthored as Overloaded } from 'java:com/tkisor/nekojs/probe/ir';
declare const inherited: Inherited<number>;
declare const overloaded: Overloaded<number>;
declare const input: Payload<number>;
const value: Payload<number> = inherited.value(input);
const inheritedOverload: Payload<number> = overloaded.value(input);
const ownOverload: Payload<number> = overloaded.value(input, 1);
// @ts-expect-error An authored overload retains the substituted class argument.
inherited.value({item: 'wrong'});
