declare module "java:com/tkisor/nekojs/probe/ir" {
    export interface $TypeScriptFieldMethodSelectorTest$AuthoredPosition<P> {
        "value(java.lang.Object)"(input: P): P;
        "value(java.lang.Object)"(input: P): P;
    }

    export class $TypeScriptFieldMethodSelectorTest$AuthoredField<P> implements $TypeScriptFieldMethodSelectorTest$AuthoredPosition<P> {
        constructor();
        value: P;
        "value(java.lang.Object)"(input: P): P;
    }

    export interface $TypeScriptFieldMethodSelectorTest$InheritedAuthored<C> extends $TypeScriptFieldMethodSelectorTest$AuthoredPosition<$TypeScriptFieldMethodSelectorTest$Payload<C>> {
        value: $TypeScriptFieldMethodSelectorTest$AuthoredPosition<$TypeScriptFieldMethodSelectorTest$Payload<C>>["value(java.lang.Object)"];
    }

    export interface $TypeScriptFieldMethodSelectorTest$OverloadedInheritedAuthored<C> extends $TypeScriptFieldMethodSelectorTest$AuthoredPosition<$TypeScriptFieldMethodSelectorTest$Payload<C>> {
        value: {
        (input: $TypeScriptFieldMethodSelectorTest$Payload<C>, marker: number): $TypeScriptFieldMethodSelectorTest$Payload<C>;
        } & $TypeScriptFieldMethodSelectorTest$AuthoredPosition<$TypeScriptFieldMethodSelectorTest$Payload<C>>["value(java.lang.Object)"];
        "value(com.tkisor.nekojs.probe.ir.TypeScriptFieldMethodSelectorTest$Payload,int)"(input: $TypeScriptFieldMethodSelectorTest$Payload<C>, marker: number): $TypeScriptFieldMethodSelectorTest$Payload<C>;
        "value(java.lang.Object)": $TypeScriptFieldMethodSelectorTest$AuthoredPosition<$TypeScriptFieldMethodSelectorTest$Payload<C>>["value(java.lang.Object)"];
    }

    export class $TypeScriptFieldMethodSelectorTest$Payload<T> {
        constructor();
        item: T;
    }

    export type $TypeScriptFieldMethodSelectorTest$AuthoredPosition_<Host0 = any, CallbackArg0 = Host0, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$AuthoredPosition<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptFieldMethodSelectorTest$InheritedAuthored_<Host0 = any, CallbackArg0 = $TypeScriptFieldMethodSelectorTest$Payload<Host0>, CallbackResult = $TypeScriptFieldMethodSelectorTest$Payload<Host0>> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$InheritedAuthored<Host0> & { readonly [Symbol.hasInstance]?: never });
}
