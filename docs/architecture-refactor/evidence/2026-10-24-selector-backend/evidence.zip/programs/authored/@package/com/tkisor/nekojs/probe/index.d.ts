export * as ir from "java:com/tkisor/nekojs/probe/ir";

