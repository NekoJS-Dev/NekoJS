declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$InheritedField extends $TypeScriptFieldMethodSelectorTest$Coordinate implements $TypeScriptFieldMethodSelectorTest$AdditionalPosition {
        constructor();
        "x(double)"(value: number): $TypeScriptFieldMethodSelectorTest$Coordinate;
        "x()"(): number;
    }

    export class $TypeScriptFieldMethodSelectorTest$AdditionalOrdinary implements $TypeScriptFieldMethodSelectorTest$AdditionalPosition {
        constructor();
        x(): number;
        "x()"(): number;
    }

    export interface $TypeScriptFieldMethodSelectorTest$AdditionalPosition {
        "x()"(): number;
    }

    export class $TypeScriptFieldMethodSelectorTest$Coordinate implements $TypeScriptFieldMethodSelectorTest$Position {
        constructor();
        x: number;
        "x(double)"(value: number): $TypeScriptFieldMethodSelectorTest$Coordinate;
        "x()"(): number;
    }

    export interface $TypeScriptFieldMethodSelectorTest$Position {
        "x()"(): number;
    }

    export type $TypeScriptFieldMethodSelectorTest$AdditionalPosition_<CallbackResult = number> = (() => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$AdditionalPosition & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptFieldMethodSelectorTest$Position_<CallbackResult = number> = (() => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$Position & { readonly [Symbol.hasInstance]?: never });
}
