import type { $TypeScriptFieldMethodSelectorTest$InheritedField as Field,
    $TypeScriptFieldMethodSelectorTest$AdditionalPosition as Position,
    $TypeScriptFieldMethodSelectorTest$AdditionalOrdinary as Ordinary } from 'java:com/tkisor/nekojs/probe/ir';
declare const field: Field;
declare const ordinary: Ordinary;
const parent: Position = field;
const value: number = field.x;
const called: number = parent["x()"]();
const safe: number = ordinary.x();
const safeSelector: number = ordinary["x()"]();
// @ts-expect-error The newly implemented interface admits a field-bearing instance.
parent.x();
