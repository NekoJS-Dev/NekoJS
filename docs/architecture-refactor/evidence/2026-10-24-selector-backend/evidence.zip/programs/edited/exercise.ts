import type { $TypeScriptFieldMethodSelectorTest$InheritedGeneric as Inherited,
    $TypeScriptFieldMethodSelectorTest$FieldPosition as Field } from 'java:com/tkisor/nekojs/probe/ir';
declare const inherited: Inherited<number>;
declare const field: Field<number>;
const ordinary: boolean = inherited.value();
const selected: boolean = field["value()"]();
const data: number = field.value;
// @ts-expect-error An explicit ancestor return edit remains authoritative.
const wrong: number = inherited.value();
