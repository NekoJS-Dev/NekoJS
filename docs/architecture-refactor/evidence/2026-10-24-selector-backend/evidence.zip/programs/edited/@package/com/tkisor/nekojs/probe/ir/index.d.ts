declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$FieldPosition<P> implements $TypeScriptFieldMethodSelectorTest$GenericPosition<P> {
        constructor();
        value: P;
        "value()"(): boolean;
    }

    export interface $TypeScriptFieldMethodSelectorTest$InheritedGeneric<C> extends $TypeScriptFieldMethodSelectorTest$GenericPosition<$TypeScriptFieldMethodSelectorTest$Payload<C>> {
        value(): boolean;
    }

    export class $TypeScriptFieldMethodSelectorTest$Payload<T> {
        constructor();
        item: T;
    }

    export interface $TypeScriptFieldMethodSelectorTest$GenericPosition<P> {
        "value()"(): boolean;
    }

    export type $TypeScriptFieldMethodSelectorTest$InheritedGeneric_<Host0 = any, CallbackResult = $TypeScriptFieldMethodSelectorTest$Payload<Host0>> = (() => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$InheritedGeneric<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptFieldMethodSelectorTest$GenericPosition_<Host0 = any, CallbackResult = Host0> = (() => CallbackResult) | ($TypeScriptFieldMethodSelectorTest$GenericPosition<Host0> & { readonly [Symbol.hasInstance]?: never });
}
