import type { $TypeScriptFieldMethodSelectorTest$Payload as Payload,
    $TypeScriptFieldMethodSelectorTest$GenericPosition as Generic,
    $TypeScriptFieldMethodSelectorTest$FieldPosition as Field,
    $TypeScriptFieldMethodSelectorTest$InheritedGeneric as Inherited } from 'java:com/tkisor/nekojs/probe/ir';
declare const field: Field<Payload<string>>;
declare const inherited: Inherited<number>;
const parent: Generic<Payload<string>> = field;
const fieldValue: Payload<string> = field.value;
const called: Payload<string> = field["value()"]();
const ordinary: Payload<number> = inherited.value();
const selector: Payload<number> = inherited["value()"]();
// @ts-expect-error Materialization substitutes the actual parent argument.
const wrong: Payload<string> = inherited.value();
// @ts-expect-error The generic field keeps its own argument.
field.value = ordinary;
