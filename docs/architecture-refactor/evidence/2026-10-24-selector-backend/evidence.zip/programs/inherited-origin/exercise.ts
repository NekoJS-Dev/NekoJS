import type { $TypeScriptFieldMethodSelectorTest$FieldOnlyParent as Parent,
    $TypeScriptFieldMethodSelectorTest$MethodOnlyChild as Child } from 'java:com/tkisor/nekojs/probe/ir';
declare const child: Child;
const parent: Parent = child;
const value: number = child.x;
const selected: number = child["x()"]();
// @ts-expect-error The inherited field remains a number.
child.x();
