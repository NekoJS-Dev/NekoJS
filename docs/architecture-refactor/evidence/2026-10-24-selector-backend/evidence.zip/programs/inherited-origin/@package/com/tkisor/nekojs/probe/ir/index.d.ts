declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $TypeScriptFieldMethodSelectorTest$MethodOnlyChild extends $TypeScriptFieldMethodSelectorTest$FieldOnlyParent {
        constructor();
        "x()"(): number;
    }

    export class $TypeScriptFieldMethodSelectorTest$FieldOnlyParent {
        constructor();
        x: number;
    }

}
