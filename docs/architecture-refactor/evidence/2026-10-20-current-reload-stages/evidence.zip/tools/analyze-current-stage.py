import json
import statistics
import subprocess
from pathlib import Path

tools = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout')
out = tools / 'stage-current-46505ad2'
session = out / 'session'
assert (out / 'restoration.json').exists()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
classpath = (tools / 'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
gson, = [part for part in classpath.split(';') if Path(part).name.startswith('gson-') and Path(part).is_file()]
classes = out / 'analysis-classes'
classes.mkdir()
(out / 'ReloadStageAnalysis.java').write_bytes((tools / 'ReloadStageAnalysis.java').read_bytes())
commands = [[str(java / 'javac.exe'), '-cp', gson, '-d', str(classes), str(out / 'ReloadStageAnalysis.java')]]
for stage in ('root', 'recipe', 'command'):
    commands.append([str(java / 'java.exe'), '-cp', str(classes)+';'+gson, 'ReloadStageAnalysis',
        str(session / 'reload.jfr'), str(out / (stage+'-analysis.json')), stage])
for index, command in enumerate(commands):
    with (out / f'analysis-{index}.log').open('xb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, index
analysis = json.loads((out / 'root-analysis.json').read_text(encoding='utf-8'))
rows = json.loads((session / 'observations.json').read_text(encoding='utf-8-sig'))
state = json.loads((session / 'session.json').read_text(encoding='utf-8-sig'))
assert len(rows) == 40 and not state['forcedKill'] and not state['extra']['killed'] and state['extra']['stopChannel'] == 'rcon'
summary = dict(diagnosticOnly=True, formalVerdictUnchanged='NOT_PASS', pairs=20,
    reloadRconMs=statistics.mean(r['rconMs'] for r in rows if r['command'] == 'nekojs reload'),
    queryRconMs=statistics.mean(r['rconMs'] for r in rows if r['command'] == 'list'),
    markerMs=statistics.mean(r['markerMs'] for r in rows if r['command'] == 'nekojs reload'),
    stages={}, rootSamples=analysis['rootSamples'])
for stage in ('root', 'recipe', 'command'):
    selected = [r for r in analysis['stages'] if r['stage'] == stage]
    assert len(selected) == 20 and all(r['thread'] == 'Server thread' for r in selected)
    summary['stages'][stage] = dict(wallMs=statistics.mean(r['wallNs']/1e6 for r in selected),
        cpuMs=statistics.mean(r['cpuNs']/1e6 for r in selected))
summary['outsideCommandMs'] = summary['reloadRconMs'] - summary['stages']['command']['wallMs']
(out / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
for stage in ('root', 'recipe'):
    analysis = json.loads((out / (stage+'-analysis.json')).read_text())
    print(stage.upper()+'_LEAVES', json.dumps(dict(list(analysis['rootLeafCounts'].items())[:15])))
    print(stage.upper()+'_INCLUSIVE', json.dumps(dict(list(analysis['rootNekoInclusiveCounts'].items())[:30])))
