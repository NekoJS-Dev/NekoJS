import hashlib
import json
import os
import socket
import subprocess
import time
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
tools = repo / 'build/priority-closeout'
out = tools / 'stage-current-46505ad2'
revision = '46505ad2c7652cc90fd723766e3c40340d0c7dcb'
assert not out.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
for port in (25871, 25872):
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', port))
out.mkdir()
path = tree / 'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java'
original = path.read_bytes()
(out / 'original-command.java').write_bytes(original)
source = original.decode('utf-8')
replacements = {
    '        NekoRuntimeRoot.ReloadResult reloadResult;\n        try {':
        '        NekoRuntimeRoot.ReloadResult reloadResult;\n        try (var diagnostic = ReloadStage.begin("command")) {',
    '            reloadResult = root.reload(type);':
        '            try (var diagnosticRoot = ReloadStage.begin("root")) {\n                reloadResult = root.reload(type);\n            }',
    '                    recipeBroadcast = applyRecipeScripts(source);':
        '                    try (var diagnosticRecipe = ReloadStage.begin("recipe")) {\n                        recipeBroadcast = applyRecipeScripts(source);\n                    }',
}
for before, after in replacements.items():
    assert source.count(before) == 1, before
    source = source.replace(before, after)
helper = '''
    @jdk.jfr.Name("neko.ReloadStage")
    @jdk.jfr.StackTrace(false)
    private static final class ReloadStage extends jdk.jfr.Event implements AutoCloseable {
        String stage;
        long wallNs;
        long cpuNs;
        private long startWall;
        private long startCpu;
        static ReloadStage begin(String name) {
            var event = new ReloadStage();
            event.stage = name;
            event.startCpu = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            event.startWall = System.nanoTime();
            event.begin();
            return event;
        }
        @Override public void close() {
            end();
            wallNs = System.nanoTime() - startWall;
            cpuNs = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime() - startCpu;
            commit();
            System.err.println("[DEBUG-STAGE-CURRENT-20] stage=" + stage + " wallNs=" + wallNs + " cpuNs=" + cpuNs);
        }
    }
'''
index = source.rfind('\n}')
assert index > 0
source = source[:index] + helper + source[index:]
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME'] + '/bin;' + environment['PATH']
environment['PSModulePath'] = 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules;C:/Program Files/WindowsPowerShell/Modules'
properties = dict(line.split('=', 1) for line in
    (tree / 'versions/26.1.2/run/server.properties').read_text().splitlines()
    if line and not line.startswith('#') and '=' in line)
environment['NEKO_PERF_RCON_PASS'] = properties['rcon.password']
gradle = [str(tree / 'gradlew.bat'), '-g', 'D:/mcmodDemo/NekoJS/.gradle-<REDACTED>',
    '-Dorg.gradle.java.home=C:/Program Files/Java/jdk-25.0.2', '--offline', '--no-parallel', '--console=plain',
    ':26.1.2:classes', ':26.1.2:jar', ':26.1.2:prepareServerRun']

def execute(label, arguments):
    print('CURRENT_STAGE_START', label, flush=True)
    started = time.monotonic()
    with (out / (label + '.log')).open('xb') as log:
        code = subprocess.run(arguments, cwd=tree, env=environment, stdout=log, stderr=subprocess.STDOUT,
                              creationflags=subprocess.CREATE_NO_WINDOW).returncode
    (out / (label + '-result.json')).write_text(json.dumps(dict(exitCode=code,
        seconds=time.monotonic()-started, arguments=arguments), indent=2)+'\n', encoding='utf-8')
    print('CURRENT_STAGE_EXIT', label, code, flush=True)
    assert code == 0, label

try:
    path.write_bytes(source.encode('utf-8'))
    (out / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=tree))
    (out / 'binding.json').write_text(json.dumps(dict(revision=revision, diagnosticOnly=True,
        originalSha256=hashlib.sha256(original).hexdigest(),
        instrumentedSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        plannedPairs=20, executionSamplePeriod='2ms'), indent=2)+'\n', encoding='utf-8')
    controller = (tools / 'stage-jfr-v2-diagnostic.ps1').read_text(encoding='utf-8')
    controller = controller.replace('C:\\Users\\11515\\.codex\\worktrees\\domain-perf-0965\\NekoJS-mult', str(tree).replace('/', '\\'))
    controller = controller.replace('stage-jfr-4550a385/session-v2', 'stage-current-46505ad2/session')
    controller = controller.replace('4550a3859b40f215084016082f97fa28eb1ac250', revision)
    controller = controller.replace("$GitRev = '4550a385'", "$GitRev = '46505ad2'")
    (out / 'diagnostic.ps1').write_text(controller, encoding='utf-8')
    execute('build-diagnostic', gradle)
    execute('run-diagnostic', ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(out / 'diagnostic.ps1')])
finally:
    path.write_bytes(original)
    execute('build-restored', gradle)
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
    expected = json.loads((tools / '2026-10-19-46505ad2-verification/performance-source-binding.json').read_text())
    actual = {}
    for directory in ('common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main'):
        root = tree / directory
        for file in root.rglob('*.class'):
            name = file.relative_to(root).as_posix()
            assert name not in actual
            actual[name] = hashlib.sha256(file.read_bytes()).hexdigest()
    assert actual == expected['classBindings']
    artifact, = (tree / 'versions/26.1.2/build/libs').glob('*.jar')
    assert hashlib.sha256(artifact.read_bytes()).hexdigest() == expected['jarSha256']
    (out / 'restoration.json').write_text(json.dumps(dict(sourceRestored=True, worktreeClean=True,
        classesMatchFormal=True, classCount=len(actual), jarMatchesFormal=True,
        jarSha256=expected['jarSha256']), indent=2)+'\n', encoding='utf-8')
    print('CURRENT_STAGE_RESTORED', len(actual), flush=True)
