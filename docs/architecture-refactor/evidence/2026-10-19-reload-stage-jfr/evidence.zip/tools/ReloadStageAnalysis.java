import jdk.jfr.consumer.*;
import java.nio.file.*;
import java.util.*;
import com.google.gson.*;

public class ReloadStageAnalysis {
    record Window(String stage, java.time.Instant start, java.time.Instant end, long thread) {}
    static Map<String, Long> sorted(Map<String, Long> map, int limit) {
        var result = new LinkedHashMap<String, Long>();
        map.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed())
            .limit(limit).forEach(e -> result.put(e.getKey(), e.getValue()));
        return result;
    }
    public static void main(String[] args) throws Exception {
        var windows = new ArrayList<Window>();
        var stages = new ArrayList<Map<String, Object>>();
        try (var file = new RecordingFile(Path.of(args[0]))) {
            while (file.hasMoreEvents()) {
                var e = file.readEvent();
                if (!e.getEventType().getName().equals("neko.ReloadStage")) continue;
                String stage = e.getString("stage");
                windows.add(new Window(stage, e.getStartTime(), e.getEndTime(), e.getThread().getJavaThreadId()));
                var row = new LinkedHashMap<String, Object>();
                row.put("stage", stage); row.put("startUtc", e.getStartTime().toString());
                row.put("endUtc", e.getEndTime().toString()); row.put("thread", e.getThread().getJavaName());
                row.put("wallNs", e.getLong("wallNs")); row.put("cpuNs", e.getLong("cpuNs"));
                stages.add(row);
            }
        }
        var leaves = new HashMap<String, Long>();
        var inclusive = new HashMap<String, Long>();
        var stacks = new HashMap<String, Long>();
        var types = new HashMap<String, Long>();
        var allocations = new HashMap<String, Long>();
        long samples = 0;
        try (var file = new RecordingFile(Path.of(args[0]))) {
            while (file.hasMoreEvents()) {
                var e = file.readEvent();
                String type = e.getEventType().getName();
                boolean sample = type.equals("jdk.ExecutionSample") || type.equals("jdk.NativeMethodSample");
                var thread = sample ? e.getThread("sampledThread") : e.getThread();
                if (thread == null || windows.stream().noneMatch(w -> w.stage.equals(args.length > 2 ? args[2] : "root") && w.thread == thread.getJavaThreadId()
                    && !e.getStartTime().isBefore(w.start) && !e.getStartTime().isAfter(w.end))) continue;
                types.merge(type, 1L, Long::sum);
                if (type.equals("jdk.ObjectAllocationSample")) {
                    allocations.merge(e.getClass("objectClass").getName(), e.getLong("weight"), Long::sum);
                }
                if (!sample || e.getStackTrace() == null || e.getStackTrace().getFrames().isEmpty()) continue;
                samples++;
                var frames = e.getStackTrace().getFrames();
                var leaf = frames.getFirst().getMethod();
                leaves.merge(leaf.getType().getName()+"."+leaf.getName(), 1L, Long::sum);
                var unique = new HashSet<String>();
                var stack = new ArrayList<String>();
                for (var frame : frames) {
                    var method = frame.getMethod();
                    String label = method.getType().getName()+"."+method.getName()+":"+frame.getLineNumber();
                    if (method.getType().getName().startsWith("com.tkisor.nekojs.")) unique.add(label);
                    stack.add(label);
                }
                for (var label : unique) inclusive.merge(label, 1L, Long::sum);
                stacks.merge(String.join("\n", stack), 1L, Long::sum);
            }
        }
        var result = new LinkedHashMap<String, Object>();
        result.put("diagnosticOnly", true); result.put("countsAreNotMilliseconds", true);
        result.put("stages", stages); result.put("rootSamples", samples);
        result.put("rootEventCounts", sorted(types, 50)); result.put("rootLeafCounts", sorted(leaves, 80));
        result.put("rootNekoInclusiveCounts", sorted(inclusive, 100));
        result.put("rootAllocationSampleWeight", sorted(allocations, 40));
        result.put("rootStacks", sorted(stacks, 100));
        Files.writeString(Path.of(args[1]), new GsonBuilder().setPrettyPrinting().create().toJson(result));
        System.out.println("STAGE_JFR_PARSED stages="+stages.size()+" rootSamples="+samples);
    }
}
