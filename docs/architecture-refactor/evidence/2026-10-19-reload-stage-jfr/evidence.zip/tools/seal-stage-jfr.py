import hashlib
import io
import json
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project / 'build/priority-closeout'
root = tools / 'stage-jfr-4550a385'
target = project / 'docs/architecture-refactor/evidence/2026-10-19-reload-stage-jfr'
target.mkdir()
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
properties = dict(line.split('=',1) for line in (tree / 'versions/26.1.2/run/server.properties').read_text().splitlines()
    if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password']
files = {p.relative_to(root).as_posix(): p for p in root.rglob('*') if p.is_file()
    and p.suffix not in ['.jfr', '.class'] and 'analysis-classes' not in p.parts}
for name in ['prepare-stage-jfr.py','stage-jfr-diagnostic.ps1','stage-jfr-v2-diagnostic.ps1','run-stage-jfr.py','run-stage-jfr-v2.py',
    'analyze-stage-jfr.py','ReloadStageAnalysis.java','restore-stage-jfr.py','stage-jfr-build.log',
    'stage-jfr-restored-build.log','stage-jfr-controller.log','stage-jfr-controller-stderr.log','stage-jfr-exit.json',
    'stage-jfr-v2-controller.log','stage-jfr-v2-controller-stderr.log','stage-jfr-v2-exit.json','seal-stage-jfr.py']:
    files['tools/'+name] = tools/name
entries = {}
redactions = {}
with zipfile.ZipFile(target / 'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,path in sorted(files.items()):
        original = data = path.read_bytes()
        try:
            text = data.decode('utf-16') if data.startswith((b'\xff\xfe',b'\xfe\xff')) else data.decode('utf-8-sig')
        except UnicodeDecodeError:
            text = data.decode('gb18030')
        if secret in text:
            data = text.replace(secret,'<REDACTED>').encode('utf-8')
            redactions[name] = dict(originalSha256=hashlib.sha256(original).hexdigest())
        assert secret.encode() not in data and secret.encode('utf-16-le') not in data
        entries[name] = hashlib.sha256(data).hexdigest()
        archive.writestr(name,data)
data = (target/'evidence.zip').read_bytes()
manifest = dict(baseCommit=json.loads((root/'binding.json').read_text())['revision'], diagnosticOnly=True,
    formalVerdictUnchanged='FAIL', archiveSha256=hashlib.sha256(data).hexdigest(), archiveBytes=len(data),
    rawJfrExcluded='Raw JFR may contain environment and program properties; only stack/event analysis is exported.',
    rawJfrSha256=hashlib.sha256((root/'session-v2/reload.jfr').read_bytes()).hexdigest(),
    entries=entries,redactions=redactions)
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(entries=len(entries),bytes=len(data),sha256=manifest['archiveSha256'])))
