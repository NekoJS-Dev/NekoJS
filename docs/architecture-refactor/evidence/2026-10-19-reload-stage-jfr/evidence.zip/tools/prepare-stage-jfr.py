import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip()
assert revision.startswith('4550a385')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
out = tools / 'stage-jfr-4550a385'
out.mkdir()
relative = 'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java'
path = tree / relative
original = path.read_bytes()
(out / 'original-command.java').write_bytes(original)
source = original.decode('utf-8')
before = '        NekoRuntimeRoot.ReloadResult reloadResult;\n        try {'
assert source.count(before) == 1
source = source.replace(before, '        NekoRuntimeRoot.ReloadResult reloadResult;\n        try (var profile = ReloadStage.begin("command")) {')
before = '            reloadResult = root.reload(type);'
assert source.count(before) == 1
source = source.replace(before, '            try (var profileRoot = ReloadStage.begin("root")) {\n' + before + '\n            }')
before = '                    recipeBroadcast = applyRecipeScripts(source);'
assert source.count(before) == 1
source = source.replace(before, '                    try (var profileRecipe = ReloadStage.begin("recipe")) {\n' + before + '\n                    }')
before = '    private static boolean applyRecipeScripts(CommandSourceStack source) {'
assert source.count(before) == 1
source = source.replace(before, '''    @jdk.jfr.Name("neko.ReloadStage")
    @jdk.jfr.StackTrace(false)
    private static final class ReloadStage extends jdk.jfr.Event implements AutoCloseable {
        String stage;
        long wallNs;
        long cpuNs;
        private long startWall;
        private long startCpu;
        static ReloadStage begin(String name) {
            var event = new ReloadStage();
            event.stage = name;
            event.startCpu = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            event.startWall = System.nanoTime();
            event.begin();
            return event;
        }
        @Override public void close() {
            end();
            wallNs = System.nanoTime() - startWall;
            cpuNs = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime() - startCpu;
            commit();
            System.err.println("[DEBUG-STAGE-JFR-19] stage=" + stage + " wallNs=" + wallNs + " cpuNs=" + cpuNs);
        }
    }

''' + before)
path.write_text(source, encoding='utf-8', newline='\n')
(out / 'binding.json').write_text(json.dumps(dict(revision=revision, path=relative,
    originalSha256=hashlib.sha256(original).hexdigest(), instrumentedSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    diagnosticOnly=True, plannedPairs=20, executionSamplePeriod='2ms'), indent=2)+'\n', encoding='utf-8')
(out / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', relative], cwd=tree))

controller = (tools / 'cpu-diagnostic.ps1').read_text(encoding='utf-8').split('New-Item -ItemType Directory -Path $OutDir | Out-Null')[0]
controller = controller.replace('diagnostic-cpu-6e5bb8f0', 'stage-jfr-4550a385/session')
controller = controller.replace('6e5bb8f00c3747b828056589853cb0471477b18a', revision).replace("$GitRev = '6e5bb8f0'", "$GitRev = '4550a385'")
controller += r'''
New-Item -ItemType Directory -Path $OutDir | Out-Null
Write-EnvSnapshot
Deploy-Fixtures -Bench:$false
$session = Invoke-ServerSession -Tag 'stages' -OnDone {
    param($proc, $outLog, $sw)
    $recording = $false
    $rows = @()
    try {
        $listeners = @(Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 25871)
        if ($listeners.Count -ne 1) { throw 'Expected one owned game listener' }
        $gameId = $listeners[0].OwningProcess
        $game = Get-CimInstance Win32_Process -Filter "ProcessId=$gameId"
        if ($game.ExecutablePath -ne "$javaRoot\bin\java.exe" -or -not $game.CommandLine.Contains($ProjectDir)) { throw 'Unexpected game owner' }
        @{pid=$gameId;launcher=$proc.Id} | ConvertTo-Json | Set-Content (Join-Path $OutDir 'owner.json') -Encoding UTF8
        & "$javaRoot\bin\jcmd.exe" $gameId JFR.start name=reloadStages settings=profile 'jdk.ExecutionSample#period=2ms' 'jdk.NativeMethodSample#period=2ms' | Set-Content (Join-Path $OutDir 'jfr-start.txt')
        if ($LASTEXITCODE -ne 0) { throw 'JFR start failed' }
        $recording = $true
        $offset = (Get-Item -LiteralPath $outLog).Length
        for ($pair = 1; $pair -le 20; $pair++) {
            $commands = if ($pair % 2) { @('time query gametime', 'nekojs reload') } else { @('nekojs reload', 'time query gametime') }
            foreach ($command in $commands) {
                Start-Sleep -Seconds 3
                [void](Read-LogTailUtf8 $outLog ([ref]$offset))
                $started = [DateTime]::UtcNow.ToString('o')
                $timer = [Diagnostics.Stopwatch]::StartNew()
                $response = Invoke-Rcon -Command $command
                $rconMs = $timer.Elapsed.TotalMilliseconds
                $returned = [DateTime]::UtcNow.ToString('o')
                $markerMs = $null
                if ($command -eq 'nekojs reload') {
                    if ($response -notmatch 'phase=COMMIT - no errors\.') { throw 'Reload diagnostic did not commit' }
                    $deadline = [DateTime]::UtcNow.AddSeconds(10)
                    while ([DateTime]::UtcNow -lt $deadline) {
                        $chunk = Read-LogTailUtf8 $outLog ([ref]$offset)
                        if ($chunk.Contains($script:ReloadMarker)) { $markerMs = $timer.Elapsed.TotalMilliseconds; break }
                        Start-Sleep -Milliseconds 100
                    }
                    if ($null -eq $markerMs) { throw 'Reload diagnostic marker missing' }
                } elseif ($response -notmatch 'The time is \d+') { throw 'Query control response invalid' }
                $rows += @{pair=$pair;command=$command;startedUtc=$started;returnedUtc=$returned;rconMs=$rconMs;markerMs=$markerMs;response=$response}
                $rows | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $OutDir 'observations.json') -Encoding UTF8
            }
        }
    } finally {
        if ($recording) {
            & "$javaRoot\bin\jcmd.exe" $gameId JFR.stop name=reloadStages ("filename=" + (Join-Path $OutDir 'reload.jfr')) | Set-Content (Join-Path $OutDir 'jfr-stop.txt')
            $recording = $false
        }
        $stop = Stop-Server $proc
    }
    @{stopSent=$true;stopChannel=$stop.channel;killed=$stop.killed}
}
$session | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $OutDir 'session.json') -Encoding UTF8
if ($session.forcedKill -or $session.extra.killed -or $session.extra.stopChannel -ne 'rcon') { throw 'Diagnostic shutdown was not normal' }
Write-Output 'STAGE_JFR_COMPLETE'
'''
(tools / 'stage-jfr-diagnostic.ps1').write_text(controller, encoding='utf-8')
runner = (tools / 'run-cpu-diagnostic.py').read_text(encoding='utf-8').replace('cpu-diagnostic.ps1', 'stage-jfr-diagnostic.ps1').replace('cpu-controller', 'stage-jfr-controller').replace('cpu-exit', 'stage-jfr-exit')
(tools / 'run-stage-jfr.py').write_text(runner, encoding='utf-8')
print('STAGE_JFR_PREPARED')
