import json
import statistics
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
out = tools / 'stage-jfr-4550a385'
session = out / 'session-v2'
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
cp = (tools / 'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
gson = [part for part in cp.split(';') if Path(part).name.startswith('gson-') and Path(part).is_file()]
assert len(gson) == 1
classes = out / 'analysis-classes'
classes.mkdir()
commands = [
    [str(java / 'javac.exe'), '-cp', gson[0], '-d', str(classes), str(tools / 'ReloadStageAnalysis.java')],
    [str(java / 'java.exe'), '-cp', str(classes)+';'+gson[0], 'ReloadStageAnalysis', str(session / 'reload.jfr'), str(out / 'analysis.json')],
]
for i, command in enumerate(commands):
    with (out / f'analysis-{i}.log').open('xb') as stdout, (out / f'analysis-{i}-stderr.log').open('xb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, i
analysis = json.loads((out / 'analysis.json').read_text(encoding='utf-8'))
rows = json.loads((session / 'observations.json').read_text(encoding='utf-8-sig'))
state = json.loads((session / 'session.json').read_text(encoding='utf-8-sig'))
assert len(rows) == 40 and not state['forcedKill'] and not state['extra']['killed'] and state['extra']['stopChannel'] == 'rcon'
summary = dict(diagnosticOnly=True, formalVerdictUnchanged='FAIL', pairs=20,
    reloadRconMs=statistics.mean(r['rconMs'] for r in rows if r['command'] == 'nekojs reload'),
    queryRconMs=statistics.mean(r['rconMs'] for r in rows if r['command'] == 'list'),
    markerMs=statistics.mean(r['markerMs'] for r in rows if r['command'] == 'nekojs reload'),
    stages={}, rootSamples=analysis['rootSamples'])
for stage in ['root', 'recipe', 'command']:
    selected = [row for row in analysis['stages'] if row['stage'] == stage]
    assert len(selected) == 20 and all(r['thread'] == 'Server thread' for r in selected)
    summary['stages'][stage] = dict(wallMs=statistics.mean(r['wallNs']/1e6 for r in selected),
        cpuMs=statistics.mean(r['cpuNs']/1e6 for r in selected))
summary['outsideCommandMs'] = summary['reloadRconMs'] - summary['stages']['command']['wallMs']
(out / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
print('ROOT_LEAVES', json.dumps(dict(list(analysis['rootLeafCounts'].items())[:15])))
print('ROOT_INCLUSIVE', json.dumps(dict(list(analysis['rootNekoInclusiveCounts'].items())[:35])))
