import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

tools = Path(__file__).resolve().parent
out = tools / 'stage-jfr-4550a385'
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
binding = json.loads((out / 'binding.json').read_text(encoding='utf-8'))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == binding['revision']
state = json.loads((out / 'session-v2/session.json').read_text(encoding='utf-8-sig'))
assert not state['forcedKill'] and state['extra']['stopChannel'] == 'rcon' and not state['extra']['killed']
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=tree, text=True).splitlines()
assert changed == [binding['path']]
path = tree / binding['path']
assert hashlib.sha256(path.read_bytes()).hexdigest() == binding['instrumentedSha256']
classes = {}
for root in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    for file in (tree / root).rglob('*.class'):
        name = file.relative_to(tree / root).as_posix()
        assert name not in classes
        classes[name] = hashlib.sha256(file.read_bytes()).hexdigest()
artifact, = (tree / 'versions/26.1.2/build/libs').glob('nekojs-neoforge-26.1.2-*.jar')
with zipfile.ZipFile(artifact) as jar:
    assert all(hashlib.sha256(jar.read(name)).hexdigest() == sha for name, sha in classes.items())
binding['classes'] = classes
binding['artifactSha256'] = hashlib.sha256(artifact.read_bytes()).hexdigest()
binding['jfrSha256'] = hashlib.sha256((out / 'session-v2/reload.jfr').read_bytes()).hexdigest()
original = (out / 'original-command.java').read_bytes()
assert hashlib.sha256(original).hexdigest() == binding['originalSha256']
path.write_bytes(original)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
binding['sourceRestored'] = True
(out / 'binding.json').write_text(json.dumps(binding, indent=2)+'\n', encoding='utf-8')
print('STAGE_JFR_SOURCE_RESTORED classes='+str(len(classes)))
