// Preserve ordinary method spellings wherever the field/interface constraints permit them.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require(path.resolve('node_modules/typescript'));
const root = process.cwd();
const base = path.join(root, 'build/priority-closeout');
const out = path.join(base, 'selector-preservation-policy-v1');
fs.mkdirSync(out);
const records = JSON.parse(fs.readFileSync(path.join(base, 'selector-migration-join-v1/records.json')));
const materializations = [];
const policies = [];
for (const node of ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']) {
    const graph = JSON.parse(fs.readFileSync(path.join(base, 'selector-heritage-closure-v1', node + '.json')));
    const rows = new Map(graph.selected.map(row => [row.owner + '\0' + row.member, row]));
    const children = new Map([...rows.keys()].map(key => [key, new Set()]));
    for (const [key, row] of rows) {
        for (const parent of row.parents) {
            const parentKey = parent + '\0' + row.member;
            if (rows.has(parentKey)) children.get(parentKey).add(key);
        }
    }
    const fieldActive = new Set([...rows].filter(([key, row]) => row.fieldDeclarations.length).map(([key]) => key));
    let queue = [...fieldActive];
    while (queue.length) {
        for (const child of children.get(queue.pop())) {
            if (!fieldActive.has(child)) { fieldActive.add(child); queue.push(child); }
        }
    }
    const unsafe = new Set(fieldActive);
    // An inherited field also conflicts with interfaces newly implemented by its subclass.
    queue = [...fieldActive];
    while (queue.length) {
        const key = queue.pop();
        const row = rows.get(key);
        for (const parent of row.parents) {
            const parentKey = parent + '\0' + row.member;
            if (rows.has(parentKey) && !unsafe.has(parentKey)) { unsafe.add(parentKey); queue.push(parentKey); }
        }
    }
    const safeInherited = [...rows].filter(([key, row]) => !unsafe.has(key) && !row.methodDeclarations.length);
    for (const [key, row] of safeInherited) {
        const visited = new Set();
        const parents = row.parents.map(owner => owner + '\0' + row.member);
        const candidates = [];
        while (parents.length) {
            const current = parents.shift();
            if (visited.has(current)) continue;
            visited.add(current);
            const parent = rows.get(current);
            if (!parent) continue;
            if (parent.methodDeclarations.length) candidates.push(...parent.methodDeclarations.map(method => ({ ...method, owner: parent.owner })));
            else parents.push(...parent.parents.map(owner => owner + '\0' + row.member));
        }
        const signatures = [...new Set(candidates.map(method => method.text))];
        // Current outputs contain one non-generic inherited boolean method here; do not guess a generic substitution.
        if (signatures.length !== 1 || signatures[0] !== 'showNotification(): boolean;') throw new Error('Unproven inherited materialization: ' + key);
        const [module, owner] = row.owner.split('#');
        const relative = '.neko_probe/typescript/@package/' + module.slice('java:'.length) + '/index.d.ts';
        const filename = path.join(root, 'build/closeout-owner-stamp-installed', node, relative);
        const source = ts.createSourceFile(filename, fs.readFileSync(filename, 'utf8'), ts.ScriptTarget.Latest, true);
        const matches = [];
        function visit(current, name) {
            if (ts.isModuleDeclaration(current) && ts.isStringLiteral(current.name)) name = current.name.text;
            if ((ts.isInterfaceDeclaration(current) || ts.isClassDeclaration(current)) && current.name?.text === owner && name === module) matches.push(current);
            ts.forEachChild(current, child => visit(child, name));
        }
        visit(source, null);
        if (matches.length !== 1 || source.text[matches[0].members.pos - 1] !== '{') throw new Error('Ambiguous declaration insertion');
        const offset = matches[0].members.pos;
        const lc = source.getLineAndCharacterOfPosition(offset);
        materializations.push({ node, owner: row.owner, member: row.member, file: relative,
            line: lc.line + 1, column: lc.character + 1, oldDeclaration: '', newDeclaration: ' ' + signatures[0],
            inheritedFrom: candidates[0].owner, reason: 'Preserve an ordinary inherited operation on a branch without the field' });
    }
    let kept = 0;
    for (const record of records.filter(record => record.node === node)) {
        if (unsafe.has(record.owner + '\0' + record.member)) record.mode = 'replace-ordinary-with-selector';
        else {
            record.mode = 'retain-ordinary-and-add-selector';
            record.newDeclaration = record.oldDeclaration + ' ' + record.newDeclaration;
            kept++;
        }
    }
    policies.push({ node, fieldActivePairs: fieldActive.size, unsafeOrdinaryPairs: unsafe.size,
        retainedOwnDeclarations: kept, inheritedMaterializations: safeInherited.length,
        unsafe: [...unsafe].sort(), fieldActive: [...fieldActive].sort() });
}
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const summary = { sourceRevision: '6e43b82789a7dbf7b9659dc1c21fefecac662649', methodRecords: records.length,
    ordinarySpellingReplacements: records.filter(record => record.mode === 'replace-ordinary-with-selector').length,
    retainedOwnDeclarations: records.filter(record => record.mode === 'retain-ordinary-and-add-selector').length,
    inheritedMaterializations: materializations.length, productionChanged: false, migrationApproved: false,
    toolSha256: digest(fs.readFileSync(__filename)) };
if (summary.ordinarySpellingReplacements !== 979 || summary.retainedOwnDeclarations !== 25 || summary.inheritedMaterializations !== 1) throw new Error('Unexpected current preservation scope');
fs.writeFileSync(path.join(out, 'records.json'), JSON.stringify(records, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'materializations.json'), JSON.stringify(materializations, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'policy.json'), JSON.stringify(policies, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'summary.json'), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary));
