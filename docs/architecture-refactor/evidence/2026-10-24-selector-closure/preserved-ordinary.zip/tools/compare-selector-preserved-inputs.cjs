// Verify the complete TypeScript program inputs behind the scratch spelling prototype.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require(path.resolve('node_modules/typescript'));
const root = process.cwd();
const [node, side] = process.argv.slice(2);
if (!['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric'].includes(node) || !['server', 'startup'].includes(side)) throw new Error('Unexpected scope');
const baseline = path.join(root, 'build/closeout-owner-stamp-installed', node).replaceAll('\\', '/');
const prototype = path.join(root, 'build/priority-closeout/selector-preserved-declaration-prototype-v1', node).replaceAll('\\', '/');
const changes = JSON.parse(fs.readFileSync(path.join(path.dirname(prototype), 'summary.json'))).changedFiles.filter(row => row.node === node);
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function read(config, base) {
    const loaded = ts.readConfigFile(config, ts.sys.readFile);
    if (loaded.error) throw new Error('Configuration read failed');
    const parsed = ts.parseJsonConfigFileContent(loaded.config, ts.sys, path.dirname(config), {}, config);
    if (parsed.errors.length) throw new Error('Configuration parse failed');
    if (!parsed.options.strict || parsed.options.skipLibCheck !== false || !parsed.options.noEmit) throw new Error('Strict settings changed');
    const program = ts.createProgram(parsed.fileNames, parsed.options);
    const normalize = filename => {
        const value = filename.replaceAll('\\', '/');
        return value.startsWith(base + '/') ? 'node/' + value.slice(base.length + 1) : value;
    };
    const sources = Object.fromEntries(program.getSourceFiles().map(source => [normalize(source.fileName), digest(fs.readFileSync(source.fileName))]));
    const options = JSON.parse(JSON.stringify(parsed.options, (key, value) => key === 'configFile' ? undefined : typeof value === 'string' ? normalize(value) : value));
    delete options.configFilePath;
    return { sources, options };
}
const originalConfig = path.join(root, 'build/closeout-owner-stamp-installed/ide', node + '-' + side + '-tsconfig.json');
const prototypeConfig = path.join(prototype, side + '-tsconfig.json');
const before = read(originalConfig, baseline);
const after = read(prototypeConfig, prototype);
if (JSON.stringify(before.options) !== JSON.stringify(after.options)) throw new Error('Effective compiler options differ');
if (JSON.stringify(Object.keys(before.sources).sort()) !== JSON.stringify(Object.keys(after.sources).sort())) throw new Error('Program source identities differ');
const edited = [];
for (const [identity, hash] of Object.entries(before.sources)) {
    const change = changes.find(row => 'node/' + row.file === identity);
    if (change) {
        if (hash !== change.originalSha256 || after.sources[identity] !== change.prototypeSha256) throw new Error('Wrong proposed edit: ' + identity);
        edited.push(identity);
    } else if (hash !== after.sources[identity]) throw new Error('Unrelated program input changed: ' + identity);
}
const result = { node, side, verdict: 'PASS', sourceFiles: Object.keys(before.sources).length,
    proposedEditedInputs: edited.length, identicalEffectiveOptions: true, missingInputs: 0, unrelatedChanges: 0,
    originalSources: before.sources, prototypeSources: after.sources, options: before.options };
fs.writeFileSync(path.join(prototype, side + '-program-inputs.json'), JSON.stringify(result, null, 2) + '\n');
const { originalSources: ignored, prototypeSources: ignoredAfter, options: ignoredOptions, ...summary } = result;
console.log(JSON.stringify(summary));
