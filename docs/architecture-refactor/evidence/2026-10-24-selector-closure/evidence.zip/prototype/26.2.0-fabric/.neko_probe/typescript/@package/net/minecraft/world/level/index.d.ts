import type { RegistryTypes } from "@special/types";
import { $Codec, $Dynamic, $MapCodec } from "java:com/mojang/serialization";
import { $AttachedData, $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $LevelExtension, $LevelExtension_ } from "java:com/tkisor/nekojs/api/inject";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Long2ObjectOpenHashMap, $LongSet } from "java:it/unimi/dsi/fastutil/longs";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $AutoCloseable, $AutoCloseable_, $Class, $Enum, $Iterable, $Record } from "java:java/lang";
import { $Collection, $List, $Map, $Optional, $Set, $UUID } from "java:java/util";
import { $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function, $Function_, $Predicate, $Predicate_, $Supplier, $Supplier_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $AttachmentTarget, $AttachmentType, $GlobalAttachments, $GlobalAttachmentsProvider } from "java:net/fabricmc/fabric/api/attachment/v1";
import { $FabricBlockGetter } from "java:net/fabricmc/fabric/api/blockgetter/v2";
import { $Event } from "java:net/fabricmc/fabric/api/event";
import { $AttachmentTargetImpl, $AttachmentTargetImpl_ } from "java:net/fabricmc/fabric/impl/attachment";
import { $AttachmentChange, $AttachmentTargetInfo } from "java:net/fabricmc/fabric/impl/attachment/sync";
import { $LoadedChunksCache } from "java:net/fabricmc/fabric/impl/event/lifecycle";
import { $BlockGetterMixin } from "java:net/fabricmc/fabric/mixin/blockgetter";
import { $CrashReport, $CrashReportCategory } from "java:net/minecraft";
import { $CommandSource, $CommandSourceStack } from "java:net/minecraft/commands";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $HolderLookup, $HolderSet, $Holder_, $Registry, $RegistryAccess, $SectionPos } from "java:net/minecraft/core";
import { $ExplosionParticleInfo, $ParticleOptions, $ParticleOptions_, $ParticleType, $ParticleType_ } from "java:net/minecraft/core/particles";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $ChunkMap, $ServerLevel, $ServerPlayer, $Ticket, $TicketType, $TicketType_, $WorldGenRegion } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_, $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $RandomSource } from "java:net/minecraft/util";
import { $WeightedList } from "java:net/minecraft/util/random";
import { $Difficulty, $DifficultyInstance, $Difficulty_, $TickRateManager } from "java:net/minecraft/world";
import { $EnvironmentAttributeReader, $EnvironmentAttributeSystem } from "java:net/minecraft/world/attribute";
import { $ClockManager, $ClockManager_ } from "java:net/minecraft/world/clock";
import { $DamageSource, $DamageSources } from "java:net/minecraft/world/damagesource";
import { $Entity, $EntityType, $EntityType_, $LivingEntity, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $EnderDragonPart } from "java:net/minecraft/world/entity/boss/enderdragon";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $PotionBrewing } from "java:net/minecraft/world/item/alchemy";
import { $FireworkExplosion } from "java:net/minecraft/world/item/component";
import { $RecipeAccess } from "java:net/minecraft/world/item/crafting";
import { $Biome, $Biome$Precipitation, $Biome$Precipitation_, $BiomeManager, $BiomeManager$NoiseBiomeSource, $BiomeManager$NoiseBiomeSource_ } from "java:net/minecraft/world/level/biome";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_, $FuelValues, $TickingBlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $WorldBorder } from "java:net/minecraft/world/level/border";
import { $BlockColumn, $ChunkAccess, $ChunkSource, $LevelChunk, $PalettedContainerFactory, $StructureAccess } from "java:net/minecraft/world/level/chunk";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";
import { $DimensionType } from "java:net/minecraft/world/level/dimension";
import { $EntityTypeTest } from "java:net/minecraft/world/level/entity";
import { $GameEvent, $GameEvent$Context, $GameEvent_ } from "java:net/minecraft/world/level/gameevent";
import { $Heightmap$Types, $Heightmap$Types_, $WorldOptions } from "java:net/minecraft/world/level/levelgen";
import { $Structure, $StructureCheck, $StructureCheckResult, $StructureCheckResult_, $StructureStart } from "java:net/minecraft/world/level/levelgen/structure";
import { $StructurePlacement } from "java:net/minecraft/world/level/levelgen/structure/placement";
import { $LevelLightEngine } from "java:net/minecraft/world/level/lighting";
import { $Fluid, $FluidState, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $Orientation } from "java:net/minecraft/world/level/redstone";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";
import { $MapId, $MapItemSavedData } from "java:net/minecraft/world/level/saveddata/maps";
import { $LevelData, $LevelData$RespawnData, $ValueInput, $ValueOutput } from "java:net/minecraft/world/level/storage";
import { $AABB, $BlockHitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $CollisionContext, $VoxelShape } from "java:net/minecraft/world/phys/shapes";
import { $Scoreboard } from "java:net/minecraft/world/scores";
import { $LevelTickAccess, $ScheduledTick, $TickPriority, $TickPriority_ } from "java:net/minecraft/world/ticks";

export * as biome from "java:net/minecraft/world/level/biome";
export * as block from "java:net/minecraft/world/level/block";
export * as border from "java:net/minecraft/world/level/border";
export * as chunk from "java:net/minecraft/world/level/chunk";
export * as dimension from "java:net/minecraft/world/level/dimension";
export * as entity from "java:net/minecraft/world/level/entity";
export * as gameevent from "java:net/minecraft/world/level/gameevent";
export * as gamerules from "java:net/minecraft/world/level/gamerules";
export * as levelgen from "java:net/minecraft/world/level/levelgen";
export * as lighting from "java:net/minecraft/world/level/lighting";
export * as material from "java:net/minecraft/world/level/material";
export * as pathfinder from "java:net/minecraft/world/level/pathfinder";
export * as portal from "java:net/minecraft/world/level/portal";
export * as redstone from "java:net/minecraft/world/level/redstone";
export * as saveddata from "java:net/minecraft/world/level/saveddata";
export * as storage from "java:net/minecraft/world/level/storage";
export * as timers from "java:net/minecraft/world/level/timers";
export * as validation from "java:net/minecraft/world/level/validation";

declare module "java:net/minecraft/world/level" {
    export class $BaseCommandBlock {
        constructor();
        get command(): string;
        getCommand(): string;
        set command(value: string);
        get customName(): $Component;
        getCustomName(): $Component;
        set customName(value: $Component_);
        get lastOutput(): $Component;
        getLastOutput(): $Component;
        set lastOutput(value: $Component_);
        get name(): $Component;
        getName(): $Component;
        get successCount(): number;
        getSuccessCount(): number;
        set successCount(value: number);
        get trackOutput(): boolean;
        isTrackOutput(): boolean;
        set trackOutput(value: boolean);
        get valid(): boolean;
        isValid(): boolean;
        createCommandSourceStack(level: $ServerLevel, source: $CommandSource): $CommandSourceStack;
        load(input: $ValueInput): void;
        onUpdated(level: $ServerLevel): void;
        performCommand(level: $ServerLevel): boolean;
        save(output: $ValueOutput): void;
        setCommand(command: string): void;
        setCustomName(name: $Component_): void;
        setLastOutput(lastOutput: $Component_): void;
        setSuccessCount(successCount: number): void;
        setTrackOutput(trackOutput: boolean): void;
    }

    export interface $BlockAndLightGetter extends $BlockGetter {
        canSeeSky(pos: $BlockPos_): boolean;
        getBrightness(layer: $LightLayer_, pos: $BlockPos_): number;
        getLightEngine(): $LevelLightEngine;
        getRawBrightness(pos: $BlockPos_, darkening: number): number;
    }

    export interface $BlockGetter extends $LevelHeightAccessor, $FabricBlockGetter, $BlockGetterMixin {
        clipWithInteractionOverride(from: $Vec3_, to: $Vec3_, pos: $BlockPos_, blockShape: $VoxelShape, blockState: $BlockState_): $BlockHitResult;
        clip(c: $ClipContext): $BlockHitResult;
        getBiomeFabric(arg0: $BlockPos_): $Holder<$Biome>;
        getBlockEntityRenderData(arg0: $BlockPos_): unknown;
        getBlockEntity<T extends $BlockEntity>(pos: $BlockPos_, type: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(pos: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(pos: $BlockPos_): number;
        getBlockFloorHeight(blockShape: $VoxelShape, belowBlockShape: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStates(box: $AABB): $Stream<$BlockState>;
        getBlockState(pos: $BlockPos_): $BlockState;
        getFluidState(pos: $BlockPos_): $FluidState;
        getLightEmission(pos: $BlockPos_): number;
        hasBiomes(): boolean;
        isBlockInLine(c: $ClipBlockStateContext): $BlockHitResult;
    }
    export const $BlockGetter: {
        forEachBlockIntersectedBetween(from: $Vec3_, to: $Vec3_, aabbAtTarget: $AABB, visitor: $BlockGetter$BlockStepVisitor_<$BlockPos, number, boolean>): boolean;
        traverseBlocks<T, C>(from: $Vec3_, to: $Vec3_, context: C, consumer: $BiFunction_<C, $BlockPos, T, C, $BlockPos, T>, missFactory: $Function_<C, T, C, T>): T;
    };

    export interface $BlockGetter$BlockStepVisitor {
        visit(pos: $BlockPos_, iteration: number): boolean;
    }

    export class $CardinalLighting extends $Record {
        constructor(down: number, up: number, north: number, south: number, west: number, east: number);
        static DEFAULT: $CardinalLighting;
        static NETHER: $CardinalLighting;
        byFace(direction: $Direction_): number;
        down(): number;
        east(): number;
        equals(o: unknown): boolean;
        hashCode(): number;
        north(): number;
        south(): number;
        toString(): string;
        up(): number;
        west(): number;
    }

    export class $CardinalLighting$Type {
        static DEFAULT: $CardinalLighting$Type;
        static NETHER: $CardinalLighting$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CardinalLighting$Type[];
        static valueOf(name: string): $CardinalLighting$Type;
    }
    export interface $CardinalLighting$Type extends $Enum<$CardinalLighting$Type> {}

    export class $ChunkPos extends $Record {
        constructor(x: number, z: number);
        static CODEC: $Codec<$ChunkPos>;
        static INVALID_CHUNK_POS: number;
        static REGION_MAX_INDEX: number;
        static REGION_SIZE: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ChunkPos>;
        static ZERO: $ChunkPos;
        get maxBlockX(): number;
        getMaxBlockX(): number;
        get maxBlockZ(): number;
        getMaxBlockZ(): number;
        get middleBlockX(): number;
        getMiddleBlockX(): number;
        get middleBlockZ(): number;
        getMiddleBlockZ(): number;
        get minBlockX(): number;
        getMinBlockX(): number;
        get minBlockZ(): number;
        getMinBlockZ(): number;
        get regionLocalX(): number;
        getRegionLocalX(): number;
        get regionLocalZ(): number;
        getRegionLocalZ(): number;
        get regionX(): number;
        getRegionX(): number;
        get regionZ(): number;
        getRegionZ(): number;
        get worldPosition(): $BlockPos;
        getWorldPosition(): $BlockPos;
        get valid(): boolean;
        isValid(): boolean;
        static containing(pos: $BlockPos_): $ChunkPos;
        static fromSectionNode(sectionNode: number): number;
        static getRegionX(pos: number): number;
        static getRegionZ(pos: number): number;
        static getX(pos: number): number;
        static getZ(pos: number): number;
        static hash(x: number, z: number): number;
        static isValid(x: number, z: number): boolean;
        static maxFromRegion(regionX: number, regionZ: number): $ChunkPos;
        static minFromRegion(regionX: number, regionZ: number): $ChunkPos;
        static pack(x: number, z: number): number;
        static pack(pos: $BlockPos_): number;
        static rangeClosed(center: $ChunkPos, radius: number): $Stream<$ChunkPos>;
        static rangeClosed(from: $ChunkPos, to: $ChunkPos): $Stream<$ChunkPos>;
        static unpack(key: number): $ChunkPos;
        contains(pos: $BlockPos_): boolean;
        distanceSquared(pos: number): number;
        distanceSquared(pos: $ChunkPos): number;
        equals(o: unknown): boolean;
        getBlockAt(x: number, y: number, z: number): $BlockPos;
        getBlockX(offset: number): number;
        getBlockZ(offset: number): number;
        getChessboardDistance(x: number, z: number): number;
        getChessboardDistance(pos: $ChunkPos): number;
        getMiddleBlockPosition(y: number): $BlockPos;
        hashCode(): number;
        pack(): number;
        toString(): string;
        x(): number;
        z(): number;
    }

    export class $ClipBlockStateContext {
        constructor(from: $Vec3_, to: $Vec3_, block: $Predicate_<$BlockState, $BlockState, boolean>);
        get from(): $Vec3;
        getFrom(): $Vec3;
        get to(): $Vec3;
        getTo(): $Vec3;
        get targetBlock(): $Predicate<$BlockState>;
        isTargetBlock(): $Predicate<$BlockState>;
    }

    export class $ClipContext {
        constructor(from: $Vec3_, to: $Vec3_, block: $ClipContext$Block_, fluid: $ClipContext$Fluid_, entity: $Entity);
        constructor(from: $Vec3_, to: $Vec3_, block: $ClipContext$Block_, fluid: $ClipContext$Fluid_, collisionContext: $CollisionContext);
        get from(): $Vec3;
        getFrom(): $Vec3;
        get to(): $Vec3;
        getTo(): $Vec3;
        getBlockShape(blockState: $BlockState_, level: $BlockGetter, pos: $BlockPos_): $VoxelShape;
        getFluidShape(fluidState: $FluidState, level: $BlockGetter, pos: $BlockPos_): $VoxelShape;
    }

    export class $ClipContext$Block {
        static COLLIDER: $ClipContext$Block;
        static FALLDAMAGE_RESETTING: $ClipContext$Block;
        static OUTLINE: $ClipContext$Block;
        static VISUAL: $ClipContext$Block;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClipContext$Block[];
        static valueOf(name: string): $ClipContext$Block;
    }
    export interface $ClipContext$Block extends $Enum<$ClipContext$Block> {}

    export class $ClipContext$Fluid {
        static ANY: $ClipContext$Fluid;
        static NONE: $ClipContext$Fluid;
        static SOURCE_ONLY: $ClipContext$Fluid;
        static WATER: $ClipContext$Fluid;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClipContext$Fluid[];
        static valueOf(name: string): $ClipContext$Fluid;
    }
    export interface $ClipContext$Fluid extends $Enum<$ClipContext$Fluid> {}

    export interface $ClipContext$ShapeGetter {
        get(state: $BlockState_, level: $BlockGetter, pos: $BlockPos_, context: $CollisionContext): $VoxelShape;
    }

    export interface $CollisionGetter extends $BlockGetter {
        clipIncludingBorder(c: $ClipContext): $BlockHitResult;
        collidesWithSuffocatingBlock(source: $Entity, box: $AABB): boolean;
        findFreePosition(source: $Entity, allowedCenters: $VoxelShape, preferredCenter: $Vec3_, sizeX: number, sizeY: number, sizeZ: number): $Optional<$Vec3>;
        findSupportingBlock(source: $Entity, box: $AABB): $Optional<$BlockPos>;
        getBlockAndLiquidCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getBlockCollisionsFromContext(source: $CollisionContext, box: $AABB): $Iterable<$VoxelShape>;
        getBlockCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getChunkForCollisions(chunkX: number, chunkZ: number): $BlockGetter;
        getCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getEntityCollisions(source: $Entity, testArea: $AABB): $List<$VoxelShape>;
        getPreMoveCollisions(source: $Entity, box: $AABB, oldPos: $Vec3_): $Iterable<$VoxelShape>;
        getWorldBorder(): $WorldBorder;
        isUnobstructed(source: $Entity, shape: $VoxelShape): boolean;
        isUnobstructed(ignore: $Entity): boolean;
        isUnobstructed(state: $BlockState_, pos: $BlockPos_, context: $CollisionContext): boolean;
        noBlockCollision(entity: $Entity, aabb: $AABB, alwaysCollideWithFluids: boolean): boolean;
        noBlockCollision(entity: $Entity, aabb: $AABB): boolean;
        noBorderCollision(entity: $Entity, aabb: $AABB): boolean;
        noCollision(entity: $Entity, aabb: $AABB, alwaysCollideWithFluids: boolean): boolean;
        noCollision(entity: $Entity, aabb: $AABB): boolean;
        noCollision(source: $Entity): boolean;
        noCollision(aabb: $AABB): boolean;
        noEntityCollision(entity: $Entity, aabb: $AABB): boolean;
    }

    export interface $CommonLevelAccessor extends $LevelReader, $LevelSimulatedRW, $EntityGetter {
        getBlockEntity<T extends $BlockEntity>(pos: $BlockPos_, type: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(pos: $BlockPos_): $BlockEntity;
        getEntityCollisions(source: $Entity, testArea: $AABB): $List<$VoxelShape>;
        getHeightmapPos(type: $Heightmap$Types_, pos: $BlockPos_): $BlockPos;
        isUnobstructed(source: $Entity, shape: $VoxelShape): boolean;
        isUnobstructed(ignore: $Entity): boolean;
        isUnobstructed(state: $BlockState_, pos: $BlockPos_, context: $CollisionContext): boolean;
    }

    export interface $CustomSpawner {
        tick(level: $ServerLevel, spawnEnemies: boolean): void;
    }

    export class $DataPackConfig {
        constructor(enabled: ($List<string> | (string)[]), disabled: ($List<string> | (string)[]));
        static CODEC: $Codec<$DataPackConfig>;
        static DEFAULT: $DataPackConfig;
        get disabled(): $List<string>;
        getDisabled(): $List<string>;
        get enabled(): $List<string>;
        getEnabled(): $List<string>;
    }

    export interface $EntityGetter {
        getEntitiesOfClass<T extends $Entity>(baseClass: $Class<T>, bb: $AABB, selector: $Predicate_<T, T, boolean>): $List<T>;
        getEntitiesOfClass<T extends $Entity>(baseClass: $Class<T>, bb: $AABB): $List<T>;
        getEntities(except: $Entity, bb: $AABB, selector: $Predicate_<$Entity, $Entity, boolean>): $List<$Entity>;
        getEntities(except: $Entity, bb: $AABB): $List<$Entity>;
        getEntities<T extends $Entity>(type: $EntityTypeTest<$Entity, T>, bb: $AABB, selector: $Predicate_<T, T, boolean>): $List<T>;
        getEntityCollisions(source: $Entity, testArea: $AABB): $List<$VoxelShape>;
        getNearestPlayer(x: number, y: number, z: number, maxDist: number, filterOutCreative: boolean): $Player;
        getNearestPlayer(x: number, y: number, z: number, range: number, predicate: $Predicate_<$Entity, $Entity, boolean>): $Player;
        getNearestPlayer(source: $Entity, maxDist: number): $Player;
        getPlayerByUUID(uuid: $UUID): $Player;
        hasNearbyAlivePlayer(x: number, y: number, z: number, range: number): boolean;
        isUnobstructed(source: $Entity, shape: $VoxelShape): boolean;
        players(): $List<$Player>;
    }

    export interface $Explosion {
        canTriggerBlocks(): boolean;
        center(): $Vec3;
        getBlockInteraction(): $Explosion$BlockInteraction;
        getDirectSourceEntity(): $Entity;
        getIndirectSourceEntity(): $LivingEntity;
        level(): $ServerLevel;
        radius(): number;
        shouldAffectBlocklikeEntities(): boolean;
    }
    export const $Explosion: {
        getDefaultDamageSource(level: $Level, source: $Entity): $DamageSource;
        getIndirectSourceEntity(source: $Entity): $LivingEntity;
    };

    export class $Explosion$BlockInteraction {
        static DESTROY: $Explosion$BlockInteraction;
        static DESTROY_WITH_DECAY: $Explosion$BlockInteraction;
        static KEEP: $Explosion$BlockInteraction;
        static TRIGGER_BLOCK: $Explosion$BlockInteraction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Explosion$BlockInteraction[];
        static valueOf(name: string): $Explosion$BlockInteraction;
    }
    export interface $Explosion$BlockInteraction extends $Enum<$Explosion$BlockInteraction> {}

    export class $ExplosionDamageCalculator {
        constructor();
        getBlockExplosionResistance(explosion: $Explosion, level: $BlockGetter, pos: $BlockPos_, block: $BlockState_, fluid: $FluidState): $Optional<number>;
        getEntityDamageAmount(explosion: $Explosion, entity: $Entity, exposure: number): number;
        getKnockbackMultiplier(entity: $Entity): number;
        shouldBlockExplode(explosion: $Explosion, level: $BlockGetter, pos: $BlockPos_, state: $BlockState_, power: number): boolean;
        shouldDamageEntity(explosion: $Explosion, entity: $Entity): boolean;
    }

    export class $GameType {
        static ADVENTURE: $GameType;
        static CREATIVE: $GameType;
        static SPECTATOR: $GameType;
        static SURVIVAL: $GameType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GameType[];
        static valueOf(name: string): $GameType;
    }
    export interface $GameType extends $Enum<$GameType> {}

    export interface $ItemLike {
        asItem(): $Item;
    }

    export class $Level implements $LevelAccessor, $AutoCloseable, $AttachmentTarget, $GlobalAttachmentsProvider, $AttachmentTargetImpl, $LoadedChunksCache, $LevelExtension {
        static ACROSS_THE_WHOLE_WORLD: number;
        static END: $ResourceKey<$Level>;
        static LONG_PARTICLE_CLIP_RANGE: number;
        static MAX_BRIGHTNESS: number;
        static MAX_ENTITY_SPAWN_Y: number;
        static MAX_LEVEL_SIZE: number;
        static MIN_ENTITY_SPAWN_Y: number;
        static NETHER: $ResourceKey<$Level>;
        static OVERWORLD: $ResourceKey<$Level>;
        static RESOURCE_KEY_CODEC: $Codec<$ResourceKey<$Level>>;
        static SHORT_PARTICLE_CLIP_RANGE: number;
        get biomeManager(): $BiomeManager;
        getBiomeManager(): $BiomeManager;
        get blockTicks(): $LevelTickAccess<$Block>;
        getBlockTicks(): $LevelTickAccess<$Block>;
        get chunkSource(): $ChunkSource;
        getChunkSource(): $ChunkSource;
        get defaultClockTime(): number;
        getDefaultClockTime(): number;
        get difficulty(): $Difficulty;
        getDifficulty(): $Difficulty;
        get fluidTicks(): $LevelTickAccess<$Fluid>;
        getFluidTicks(): $LevelTickAccess<$Fluid>;
        get gameTime(): number;
        getGameTime(): number;
        get height(): number;
        getHeight(): number;
        get levelData(): $LevelData;
        getLevelData(): $LevelData;
        get lightEngine(): $LevelLightEngine;
        getLightEngine(): $LevelLightEngine;
        get maxSectionY(): number;
        getMaxSectionY(): number;
        get maxY(): number;
        getMaxY(): number;
        get minSectionY(): number;
        getMinSectionY(): number;
        get minY(): number;
        getMinY(): number;
        get nextEntityId(): number;
        getNextEntityId(): number;
        get overworldClockTime(): number;
        getOverworldClockTime(): number;
        get random(): $RandomSource;
        getRandom(): $RandomSource;
        get respawnData(): $LevelData$RespawnData;
        getRespawnData(): $LevelData$RespawnData;
        set respawnData(value: $LevelData$RespawnData);
        get scoreboard(): $Scoreboard;
        getScoreboard(): $Scoreboard;
        get seaLevel(): number;
        getSeaLevel(): number;
        get sectionsCount(): number;
        getSectionsCount(): number;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get skyDarken(): number;
        getSkyDarken(): number;
        get worldBorder(): $WorldBorder;
        getWorldBorder(): $WorldBorder;
        get brightOutside(): boolean;
        isBrightOutside(): boolean;
        get clientSide(): boolean;
        isClientSide(): boolean;
        get darkOutside(): boolean;
        isDarkOutside(): boolean;
        get debug(): boolean;
        isDebug(): boolean;
        get raining(): boolean;
        isRaining(): boolean;
        set raining(value: boolean);
        get thundering(): boolean;
        isThundering(): boolean;
        get id(): string;
        getId(): string;
        getPlayers(): $List<$Player>;
        get time(): number;
        getTime(): number;
        set time(value: number);
        get day(): boolean;
        isDay(): boolean;
        static isInSpawnableBounds(pos: $BlockPos_): boolean;
        addAlwaysVisibleParticle(particle: $ParticleOptions_<$ParticleType_<any>>, overrideLimiter: boolean, x: number, y: number, z: number, xd: number, yd: number, zd: number): void;
        addAlwaysVisibleParticle(particle: $ParticleOptions_<$ParticleType_<any>>, x: number, y: number, z: number, xd: number, yd: number, zd: number): void;
        addBlockEntityTicker(ticker: $TickingBlockEntity): void;
        addDestroyBlockEffect(pos: $BlockPos_, blockState: $BlockState_): void;
        addFreshEntity(entity: $Entity): boolean;
        addParticle(particle: $ParticleOptions_<$ParticleType_<any>>, overrideLimiter: boolean, alwaysShow: boolean, x: number, y: number, z: number, xd: number, yd: number, zd: number): void;
        addParticle(particle: $ParticleOptions_<$ParticleType_<any>>, x: number, y: number, z: number, xd: number, yd: number, zd: number): void;
        blockEntityChanged(pos: $BlockPos_): void;
        blockEvent(pos: $BlockPos_, block: $Block_, b0: number, b1: number): void;
        broadcastDamageEvent(entity: $Entity, source: $DamageSource): void;
        broadcastEntityEvent(entity: $Entity, event: number): void;
        canHaveWeather(): boolean;
        canSeeSkyFromBelowWater(pos: $BlockPos_): boolean;
        canSeeSky(pos: $BlockPos_): boolean;
        clipIncludingBorder(c: $ClipContext): $BlockHitResult;
        clipWithInteractionOverride(from: $Vec3_, to: $Vec3_, pos: $BlockPos_, blockShape: $VoxelShape, blockState: $BlockState_): $BlockHitResult;
        clip(c: $ClipContext): $BlockHitResult;
        clockManager(): $ClockManager;
        close(): void;
        collidesWithSuffocatingBlock(source: $Entity, box: $AABB): boolean;
        containsAnyLiquid(box: $AABB): boolean;
        createFireworks(x: number, y: number, z: number, xd: number, yd: number, zd: number, explosions: ($List<$FireworkExplosion> | ($FireworkExplosion)[])): void;
        createTick<T>(pos: $BlockPos_, type: T, tickDelay: number, priority: $TickPriority_): $ScheduledTick<T>;
        createTick<T>(pos: $BlockPos_, type: T, tickDelay: number): $ScheduledTick<T>;
        damageSources(): $DamageSources;
        destroyBlockProgress(id: number, blockPos: $BlockPos_, progress: number): void;
        destroyBlock(pos: $BlockPos_, dropResources: boolean, breaker: $Entity, updateLimit: number): boolean;
        destroyBlock(pos: $BlockPos_, dropResources: boolean, breaker: $Entity): boolean;
        destroyBlock(pos: $BlockPos_, dropResources: boolean): boolean;
        dimensionTypeRegistration(): $Holder<$DimensionType>;
        dimensionType(): $DimensionType;
        dimension(): $ResourceKey<$Level>;
        dragonParts(): $Collection<$EnderDragonPart>;
        enabledFeatures(): $FeatureFlagSet;
        environmentAttributes(): $EnvironmentAttributeSystem;
        explode(source: $Entity, x: number, y: number, z: number, r: number, fire: boolean, blockInteraction: $Level$ExplosionInteraction_): void;
        explode(source: $Entity, x: number, y: number, z: number, r: number, blockInteraction: $Level$ExplosionInteraction_): void;
        explode(source: $Entity, damageSource: $DamageSource, damageCalculator: $ExplosionDamageCalculator, x: number, y: number, z: number, r: number, fire: boolean, interactionType: $Level$ExplosionInteraction_, smallExplosionParticles: $ParticleOptions_<$ParticleType_<any>>, largeExplosionParticles: $ParticleOptions_<$ParticleType_<any>>, blockParticles: $WeightedList<$ExplosionParticleInfo>, explosionSound: $Holder_<$SoundEvent>): void;
        explode(source: $Entity, damageSource: $DamageSource, damageCalculator: $ExplosionDamageCalculator, x: number, y: number, z: number, r: number, fire: boolean, interactionType: $Level$ExplosionInteraction_): void;
        explode(source: $Entity, damageSource: $DamageSource, damageCalculator: $ExplosionDamageCalculator, boomPos: $Vec3_, r: number, fire: boolean, blockInteraction: $Level$ExplosionInteraction_): void;
        fabric_clearDeferredSyncChanges(): void;
        fabric_computeInitialSyncChanges(arg0: $ServerPlayer, arg1: $Consumer_<any, any>): void;
        fabric_getAttachments(): $Map<$AttachmentType<any>, any>;
        fabric_getLoadedChunks(): $Set<$LevelChunk>;
        fabric_getRegistryAccess(): $RegistryAccess;
        fabric_getSyncTargetInfo(): $AttachmentTargetInfo<any>;
        fabric_hasPersistentAttachments(): boolean;
        fabric_markChanged(arg0: $AttachmentType<any>): void;
        fabric_markLoaded(arg0: $LevelChunk): void;
        fabric_markUnloaded(arg0: $LevelChunk): void;
        fabric_readAttachmentsFromNbt(arg0: $ValueInput): void;
        fabric_sendAndClearDeferredSyncChanges(arg0: ($List<any> | (any)[])): void;
        fabric_shouldDeferSync(): boolean;
        fabric_shouldTryToSync(): boolean;
        fabric_syncChange(arg0: $AttachmentType<any>, arg1: $AttachmentChange): void;
        fabric_updateSyncTarget(arg0: $AttachmentTargetInfo<any>, arg1: $AttachmentTargetInfo<any>): void;
        fabric_writeAttachmentsToNbt(arg0: $ValueOutput): void;
        fillReportDetails(report: $CrashReport): $CrashReportCategory;
        findFreePosition(source: $Entity, allowedCenters: $VoxelShape, preferredCenter: $Vec3_, sizeX: number, sizeY: number, sizeZ: number): $Optional<$Vec3>;
        findSupportingBlock(source: $Entity, box: $AABB): $Optional<$BlockPos>;
        fuelValues(): $FuelValues;
        gameEvent(gameEvent: $Holder_<$GameEvent>, pos: $BlockPos_, context: $GameEvent$Context): void;
        gameEvent(gameEvent: $Holder_<$GameEvent>, position: $Vec3_, context: $GameEvent$Context): void;
        gameEvent(gameEvent: $ResourceKey<$GameEvent>, pos: $BlockPos_, context: $GameEvent$Context): void;
        gameEvent(sourceEntity: $Entity, gameEvent: $Holder_<$GameEvent>, pos: $BlockPos_): void;
        gameEvent(sourceEntity: $Entity, gameEvent: $Holder_<$GameEvent>, pos: $Vec3_): void;
        gatherChunkSourceStats(): string;
        getAttachedOrCreate<A>(arg0: $AttachmentType<A>, arg1: $Supplier_<A, A>): A;
        getAttachedOrCreate<A>(arg0: $AttachmentType<A>): A;
        getAttachedOrElse<A>(arg0: $AttachmentType<A>, arg1: A): A;
        getAttachedOrGet<A>(arg0: $AttachmentType<A>, arg1: $Supplier_<A, A>): A;
        getAttachedOrSet<A>(arg0: $AttachmentType<A>, arg1: A): A;
        getAttachedOrThrow<A>(arg0: $AttachmentType<A>): A;
        getAttached(arg0: $AttachmentType<any>): unknown;
        getBestNeighborSignal(pos: $BlockPos_): number;
        getBestOwnOrNeighbourSignal(pos: $BlockPos_): number;
        getBiomeFabric(arg0: $BlockPos_): $Holder<any>;
        getBiome(pos: $BlockPos_): $Holder<$Biome>;
        getBlockAndLiquidCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getBlockCollisionsFromContext(source: $CollisionContext, box: $AABB): $Iterable<$VoxelShape>;
        getBlockCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getBlockEntityRenderData(arg0: $BlockPos_): unknown;
        getBlockEntity<T extends $BlockEntity>(pos: $BlockPos_, type: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(pos: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(pos: $BlockPos_): number;
        getBlockFloorHeight(blockShape: $VoxelShape, belowBlockShape: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockRandomPos(xo: number, yo: number, zo: number, yMask: number): $BlockPos;
        getBlockStatesIfLoaded(box: $AABB): $Stream<$BlockState>;
        getBlockStates(box: $AABB): $Stream<$BlockState>;
        getBlockState(pos: $BlockPos_): $BlockState;
        getBrightness(layer: $LightLayer_, pos: $BlockPos_): number;
        getChunkAt(pos: $BlockPos_): $LevelChunk;
        getChunkForCollisions(chunkX: number, chunkZ: number): $BlockGetter;
        getChunk(chunkX: number, chunkZ: number, status: $ChunkStatus_, loadOrGenerate: boolean): $ChunkAccess;
        getChunk(chunkX: number, chunkZ: number, status: $ChunkStatus_): $ChunkAccess;
        getChunk(chunkX: number, chunkZ: number): $LevelChunk;
        getChunk(pos: $BlockPos_): $ChunkAccess;
        getClientLeafTintColor(pos: $BlockPos_): number;
        getCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getControlInputSignal(pos: $BlockPos_, direction: $Direction_, onlyDiodes: boolean): number;
        getDirectSignalTo(pos: $BlockPos_): number;
        getDirectSignal(pos: $BlockPos_, direction: $Direction_): number;
        getEffectiveSkyBrightness(pos: $BlockPos_): number;
        getEntitiesOfClass<T extends $Entity>(baseClass: $Class<T>, bb: $AABB, selector: $Predicate_<T, T, boolean>): $List<T>;
        getEntitiesOfClass<T extends $Entity>(baseClass: $Class<T>, bb: $AABB): $List<T>;
        getEntities(except: $Entity, bb: $AABB, selector: $Predicate_<$Entity, $Entity, boolean>): $List<$Entity>;
        getEntities(except: $Entity, bb: $AABB): $List<$Entity>;
        getEntities<T extends $Entity>(type: $EntityTypeTest<$Entity, T>, bb: $AABB, selector: $Predicate_<T, T, boolean>, output: ($List<any> | (any)[]), maxResults: number): void;
        getEntities<T extends $Entity>(type: $EntityTypeTest<$Entity, T>, bb: $AABB, selector: $Predicate_<T, T, boolean>, output: ($List<any> | (any)[])): void;
        getEntities<T extends $Entity>(type: $EntityTypeTest<$Entity, T>, bb: $AABB, selector: $Predicate_<T, T, boolean>): $List<T>;
        getEntityCollisions(source: $Entity, testArea: $AABB): $List<$VoxelShape>;
        getEntityInAnyDimension(uuid: $UUID): $Entity;
        getEntity(id: number): $Entity;
        getEntity(uuid: $UUID): $Entity;
        getFluidState(pos: $BlockPos_): $FluidState;
        getHeightmapPos(type: $Heightmap$Types_, pos: $BlockPos_): $BlockPos;
        getHeight(type: $Heightmap$Types_, x: number, z: number): number;
        getHeight(type: $Heightmap$Types_, pos: $BlockPos_): number;
        getLightEmission(pos: $BlockPos_): number;
        getLightLevelDependentMagicValue(pos: $BlockPos_): number;
        getMapData(id: $MapId): $MapItemSavedData;
        getMaxLocalRawBrightness(pos: $BlockPos_, skyDarkening: number): number;
        getMaxLocalRawBrightness(pos: $BlockPos_): number;
        getNearestPlayer(x: number, y: number, z: number, maxDist: number, filterOutCreative: boolean): $Player;
        getNearestPlayer(x: number, y: number, z: number, range: number, predicate: $Predicate_<$Entity, $Entity, boolean>): $Player;
        getNearestPlayer(source: $Entity, maxDist: number): $Player;
        getNoiseBiome(quartX: number, quartY: number, quartZ: number): $Holder<$Biome>;
        getPathfindingCostFromLightLevels(pos: $BlockPos_): number;
        getPlayerByUUID(uuid: $UUID): $Player;
        getPlayerInAnyDimension(uuid: $UUID): $Player;
        getPreMoveCollisions(source: $Entity, box: $AABB, oldPos: $Vec3_): $Iterable<$VoxelShape>;
        getPushableEntities(pusher: $Entity, boundingBox: $AABB): $List<$Entity>;
        getRainLevel(a: number): number;
        getRawBrightness(pos: $BlockPos_, darkening: number): number;
        getSectionIndexFromSectionY(sectionY: number): number;
        getSectionIndex(blockY: number): number;
        getSectionYFromSectionIndex(sectionIndex: number): number;
        getSignal(pos: $BlockPos_, direction: $Direction_): number;
        getThunderLevel(a: number): number;
        getUncachedNoiseBiome(quartX: number, quartY: number, quartZ: number): $Holder<$Biome>;
        getWorldBorderAdjustedRespawnData(respawnData: $LevelData$RespawnData): $LevelData$RespawnData;
        globalAttachments(): $GlobalAttachments;
        globalLevelEvent(type: number, pos: $BlockPos_, data: number): void;
        guardEntityTick<T extends $Entity>(tick: $Consumer_<T, T>, entity: T): void;
        hasAttached(arg0: $AttachmentType<any>): boolean;
        hasBiomes(): boolean;
        hasChunkAt(blockX: number, blockZ: number): boolean;
        hasChunkAt(pos: $BlockPos_): boolean;
        hasChunksAt(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number): boolean;
        hasChunksAt(x0: number, z0: number, x1: number, z1: number): boolean;
        hasChunksAt(pos0: $BlockPos_, pos1: $BlockPos_): boolean;
        hasChunk(chunkX: number, chunkZ: number): boolean;
        hasEntities<T extends $Entity>(type: $EntityTypeTest<$Entity, T>, bb: $AABB, selector: $Predicate_<T, T, boolean>): boolean;
        hasNearbyAlivePlayer(x: number, y: number, z: number, range: number): boolean;
        hasNeighborSignal(blockPos: $BlockPos_): boolean;
        hasSignal(pos: $BlockPos_, direction: $Direction_): boolean;
        holderLookup<T>(key: $ResourceKey<$Registry<T>>): $HolderLookup<T>;
        isBlockInLine(c: $ClipBlockStateContext): $BlockHitResult;
        isEmptyBlock(pos: $BlockPos_): boolean;
        isFluidAtPosition(pos: $BlockPos_, predicate: $Predicate_<$FluidState, $FluidState, boolean>): boolean;
        isInValidBounds(pos: $BlockPos_): boolean;
        isInWorldBounds(pos: $BlockPos_): boolean;
        isInsideBuildHeight(blockY: number): boolean;
        isInsideBuildHeight(pos: $BlockPos_): boolean;
        isLoaded(pos: $BlockPos_): boolean;
        isOutsideBuildHeight(blockY: number): boolean;
        isOutsideBuildHeight(pos: $BlockPos_): boolean;
        isRainingAt(pos: $BlockPos_): boolean;
        isStateAtPosition(pos: $BlockPos_, predicate: $Predicate_<$BlockState, $BlockState, boolean>): boolean;
        isUnobstructed(source: $Entity, shape: $VoxelShape): boolean;
        isUnobstructed(ignore: $Entity): boolean;
        isUnobstructed(state: $BlockState_, pos: $BlockPos_, context: $CollisionContext): boolean;
        isWaterAt(pos: $BlockPos_): boolean;
        levelEvent(type: number, pos: $BlockPos_, data: number): void;
        levelEvent(source: $Entity, type: number, pos: $BlockPos_, data: number): void;
        loadedAndEntityCanStandOnFace(pos: $BlockPos_, entity: $Entity, faceDirection: $Direction_): boolean;
        loadedAndEntityCanStandOn(pos: $BlockPos_, entity: $Entity): boolean;
        mayInteract(entity: $Entity, pos: $BlockPos_): boolean;
        modifyAttached<A>(arg0: $AttachmentType<A>, arg1: $UnaryOperator_<A, A, A>): A;
        neighborChanged(pos: $BlockPos_, changedBlock: $Block_, orientation: $Orientation): void;
        neighborChanged(state: $BlockState_, pos: $BlockPos_, changedBlock: $Block_, orientation: $Orientation, movedByPiston: boolean): void;
        neighborShapeChanged(direction: $Direction_, pos: $BlockPos_, neighborPos: $BlockPos_, neighborState: $BlockState_, updateFlags: number, updateLimit: number): void;
        data(): $AttachedData<$Level>;
        getBlockState(x: number, y: number, z: number): $BlockState;
        isRaining(): boolean;
        setBlock(x: number, y: number, z: number, block: unknown): boolean;
        setRaining(raining: boolean): void;
        setTime(time: number): void;
        spawnEntity(type: $EntityType_<any>, x: number, y: number, z: number): $Entity;
        spawnLightning(x: number, y: number, z: number): $Entity;
        nextSubTickCount(): number;
        noBlockCollision(entity: $Entity, aabb: $AABB, alwaysCollideWithFluids: boolean): boolean;
        noBlockCollision(entity: $Entity, aabb: $AABB): boolean;
        noBorderCollision(entity: $Entity, aabb: $AABB): boolean;
        noCollision(entity: $Entity, aabb: $AABB, alwaysCollideWithFluids: boolean): boolean;
        noCollision(entity: $Entity, aabb: $AABB): boolean;
        noCollision(source: $Entity): boolean;
        noCollision(aabb: $AABB): boolean;
        noEntityCollision(entity: $Entity, aabb: $AABB): boolean;
        "noSave()"(): boolean;
        onAttachedSet(arg0: $AttachmentType<any>): $Event<any>;
        onBlockEntityAdded(blockEntity: $BlockEntity): void;
        palettedContainerFactory(): $PalettedContainerFactory;
        playLocalSound(x: number, y: number, z: number, sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number, distanceDelay: boolean): void;
        playLocalSound(pos: $BlockPos_, sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number, distanceDelay: boolean): void;
        playLocalSound(sourceEntity: $Entity, sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number): void;
        playPlayerSound(sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number): void;
        playSeededSound(except: $Entity, x: number, y: number, z: number, sound: $Holder_<$SoundEvent>, source: $SoundSource_, volume: number, pitch: number, seed: number): void;
        playSeededSound(except: $Entity, x: number, y: number, z: number, sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number, seed: number): void;
        playSeededSound(except: $Entity, sourceEntity: $Entity, sound: $Holder_<$SoundEvent>, source: $SoundSource_, volume: number, pitch: number, seed: number): void;
        playSound(except: $Entity, x: number, y: number, z: number, sound: $Holder_<$SoundEvent>, source: $SoundSource_, volume: number, pitch: number): void;
        playSound(except: $Entity, x: number, y: number, z: number, sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number): void;
        playSound(except: $Entity, x: number, y: number, z: number, sound: $SoundEvent_, source: $SoundSource_): void;
        playSound(except: $Entity, pos: $BlockPos_, sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number): void;
        playSound(except: $Entity, pos: $BlockPos_, soundEvent: $SoundEvent_, source: $SoundSource_): void;
        playSound(except: $Entity, sourceEntity: $Entity, sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number): void;
        players(): $List<$Player>;
        potionBrewing(): $PotionBrewing;
        precipitationAt(pos: $BlockPos_): $Biome$Precipitation;
        recipeAccess(): $RecipeAccess;
        registryAccess(): $RegistryAccess;
        removeAttached<A>(arg0: $AttachmentType<A>): A;
        removeBlockEntity(pos: $BlockPos_): void;
        removeBlock(pos: $BlockPos_, movedByPiston: boolean): boolean;
        scheduleTick(pos: $BlockPos_, type: $Block_, tickDelay: number, priority: $TickPriority_): void;
        scheduleTick(pos: $BlockPos_, type: $Block_, tickDelay: number): void;
        scheduleTick(pos: $BlockPos_, type: $Fluid_, tickDelay: number, priority: $TickPriority_): void;
        scheduleTick(pos: $BlockPos_, type: $Fluid_, tickDelay: number): void;
        sendBlockUpdated(pos: $BlockPos_, old: $BlockState_, current: $BlockState_, updateFlags: number): void;
        sendPacketToServer(packet: $Packet<any>): void;
        setAttached(arg0: $AttachmentType<any>, arg1: unknown): unknown;
        setBlockAndUpdate(pos: $BlockPos_, blockState: $BlockState_): boolean;
        setBlockEntity(blockEntity: $BlockEntity): void;
        setBlocksDirty(pos: $BlockPos_, oldState: $BlockState_, newState: $BlockState_): void;
        setBlock(pos: $BlockPos_, blockState: $BlockState_, updateFlags: number, updateLimit: number): boolean;
        setBlock(pos: $BlockPos_, blockState: $BlockState_, updateFlags: number): boolean;
        setRainLevel(rainLevel: number): void;
        setRespawnData(respawnData: $LevelData$RespawnData): void;
        setSkyFlashTime(skyFlashTime: number): void;
        setSpawnSettings(spawnEnemies: boolean): void;
        setThunderLevel(thunderLevel: number): void;
        shouldTickBlocksAt(chunkPos: number): boolean;
        shouldTickBlocksAt(pos: $BlockPos_): boolean;
        shouldTickDeath(entity: $Entity): boolean;
        tickBlockEntities(): void;
        tickRateManager(): $TickRateManager;
        updateNeighborsAtExceptFromFacing(pos: $BlockPos_, blockObject: $Block_, skipDirection: $Direction_, orientation: $Orientation): void;
        updateNeighborsAt(pos: $BlockPos_, sourceBlock: $Block_, orientation: $Orientation): void;
        updateNeighborsAt(pos: $BlockPos_, sourceBlock: $Block_): void;
        updateNeighbourForOutputSignal(pos: $BlockPos_, changedBlock: $Block_): void;
        updatePOIOnBlockStateChange(pos: $BlockPos_, oldState: $BlockState_, newState: $BlockState_): void;
        updateSkyBrightness(): void;
    }

    export class $Level$ExplosionInteraction {
        static BLOCK: $Level$ExplosionInteraction;
        static MOB: $Level$ExplosionInteraction;
        static NONE: $Level$ExplosionInteraction;
        static TNT: $Level$ExplosionInteraction;
        static TRIGGER: $Level$ExplosionInteraction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Level$ExplosionInteraction[];
        static valueOf(name: string): $Level$ExplosionInteraction;
    }
    export interface $Level$ExplosionInteraction extends $Enum<$Level$ExplosionInteraction> {}

    export interface $LevelAccessor extends $CommonLevelAccessor, $ScheduledTickAccess {
        addParticle(particle: $ParticleOptions_<$ParticleType_<any>>, x: number, y: number, z: number, xd: number, yd: number, zd: number): void;
        createTick<T>(pos: $BlockPos_, type: T, tickDelay: number, priority: $TickPriority_): $ScheduledTick<T>;
        createTick<T>(pos: $BlockPos_, type: T, tickDelay: number): $ScheduledTick<T>;
        gameEvent(gameEvent: $Holder_<$GameEvent>, pos: $BlockPos_, context: $GameEvent$Context): void;
        gameEvent(gameEvent: $Holder_<$GameEvent>, position: $Vec3_, context: $GameEvent$Context): void;
        gameEvent(gameEvent: $ResourceKey<$GameEvent>, pos: $BlockPos_, context: $GameEvent$Context): void;
        gameEvent(sourceEntity: $Entity, gameEvent: $Holder_<$GameEvent>, pos: $BlockPos_): void;
        gameEvent(sourceEntity: $Entity, gameEvent: $Holder_<$GameEvent>, pos: $Vec3_): void;
        getChunkSource(): $ChunkSource;
        getDifficulty(): $Difficulty;
        getGameTime(): number;
        getLevelData(): $LevelData;
        getRandom(): $RandomSource;
        getServer(): $MinecraftServer;
        hasChunk(chunkX: number, chunkZ: number): boolean;
        levelEvent(type: number, pos: $BlockPos_, data: number): void;
        levelEvent(source: $Entity, type: number, pos: $BlockPos_, data: number): void;
        neighborShapeChanged(direction: $Direction_, pos: $BlockPos_, neighborPos: $BlockPos_, neighborState: $BlockState_, updateFlags: number, updateLimit: number): void;
        nextSubTickCount(): number;
        playSound(except: $Entity, pos: $BlockPos_, sound: $SoundEvent_, source: $SoundSource_, volume: number, pitch: number): void;
        playSound(except: $Entity, pos: $BlockPos_, soundEvent: $SoundEvent_, source: $SoundSource_): void;
        updateNeighborsAt(pos: $BlockPos_, sourceBlock: $Block_): void;
    }

    export interface $LevelHeightAccessor {
        getHeight(): number;
        getMaxSectionY(): number;
        getMaxY(): number;
        getMinSectionY(): number;
        getMinY(): number;
        getSectionIndexFromSectionY(sectionY: number): number;
        getSectionIndex(blockY: number): number;
        getSectionYFromSectionIndex(sectionIndex: number): number;
        getSectionsCount(): number;
        isInsideBuildHeight(blockY: number): boolean;
        isInsideBuildHeight(pos: $BlockPos_): boolean;
        isOutsideBuildHeight(blockY: number): boolean;
        isOutsideBuildHeight(pos: $BlockPos_): boolean;
    }
    export const $LevelHeightAccessor: {
        create(minY: number, height: number): $LevelHeightAccessor;
    };

    export interface $LevelReader extends $BlockAndLightGetter, $CollisionGetter, $SignalGetter, $BiomeManager$NoiseBiomeSource {
        canSeeSkyFromBelowWater(pos: $BlockPos_): boolean;
        clipWithInteractionOverride(from: $Vec3_, to: $Vec3_, pos: $BlockPos_, blockShape: $VoxelShape, blockState: $BlockState_): $BlockHitResult;
        clip(c: $ClipContext): $BlockHitResult;
        containsAnyLiquid(box: $AABB): boolean;
        dimensionType(): $DimensionType;
        enabledFeatures(): $FeatureFlagSet;
        environmentAttributes(): $EnvironmentAttributeReader;
        getBiomeFabric(arg0: $BlockPos_): $Holder<any>;
        getBiomeManager(): $BiomeManager;
        getBiome(pos: $BlockPos_): $Holder<$Biome>;
        getBlockEntityRenderData(arg0: $BlockPos_): unknown;
        getBlockEntity<T extends $BlockEntity>(pos: $BlockPos_, type: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(pos: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(pos: $BlockPos_): number;
        getBlockFloorHeight(blockShape: $VoxelShape, belowBlockShape: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStatesIfLoaded(box: $AABB): $Stream<$BlockState>;
        getBlockStates(box: $AABB): $Stream<$BlockState>;
        getBlockState(pos: $BlockPos_): $BlockState;
        getChunkForCollisions(chunkX: number, chunkZ: number): $BlockGetter;
        getChunk(chunkX: number, chunkZ: number, targetStatus: $ChunkStatus_, loadOrGenerate: boolean): $ChunkAccess;
        getChunk(chunkX: number, chunkZ: number, status: $ChunkStatus_): $ChunkAccess;
        getChunk(chunkX: number, chunkZ: number): $ChunkAccess;
        getChunk(pos: $BlockPos_): $ChunkAccess;
        getEffectiveSkyBrightness(pos: $BlockPos_): number;
        getFluidState(pos: $BlockPos_): $FluidState;
        getHeightmapPos(type: $Heightmap$Types_, pos: $BlockPos_): $BlockPos;
        getHeight(type: $Heightmap$Types_, x: number, z: number): number;
        getHeight(type: $Heightmap$Types_, pos: $BlockPos_): number;
        getHeight(): number;
        getLightEmission(pos: $BlockPos_): number;
        getLightLevelDependentMagicValue(pos: $BlockPos_): number;
        getMaxLocalRawBrightness(pos: $BlockPos_, skyDarkening: number): number;
        getMaxLocalRawBrightness(pos: $BlockPos_): number;
        getMaxSectionY(): number;
        getMaxY(): number;
        getMinSectionY(): number;
        getMinY(): number;
        getNoiseBiome(quartX: number, quartY: number, quartZ: number): $Holder<$Biome>;
        getPathfindingCostFromLightLevels(pos: $BlockPos_): number;
        getSeaLevel(): number;
        getSectionIndexFromSectionY(sectionY: number): number;
        getSectionIndex(blockY: number): number;
        getSectionYFromSectionIndex(sectionIndex: number): number;
        getSectionsCount(): number;
        getSkyDarken(): number;
        getUncachedNoiseBiome(quartX: number, quartY: number, quartZ: number): $Holder<$Biome>;
        hasBiomes(): boolean;
        hasChunkAt(blockX: number, blockZ: number): boolean;
        hasChunkAt(pos: $BlockPos_): boolean;
        hasChunksAt(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number): boolean;
        hasChunksAt(x0: number, z0: number, x1: number, z1: number): boolean;
        hasChunksAt(pos0: $BlockPos_, pos1: $BlockPos_): boolean;
        hasChunk(chunkX: number, chunkZ: number): boolean;
        holderLookup<T>(key: $ResourceKey<$Registry<T>>): $HolderLookup<T>;
        isBlockInLine(c: $ClipBlockStateContext): $BlockHitResult;
        isClientSide(): boolean;
        isEmptyBlock(pos: $BlockPos_): boolean;
        isInsideBuildHeight(blockY: number): boolean;
        isInsideBuildHeight(pos: $BlockPos_): boolean;
        isOutsideBuildHeight(blockY: number): boolean;
        isOutsideBuildHeight(pos: $BlockPos_): boolean;
        isWaterAt(pos: $BlockPos_): boolean;
        registryAccess(): $RegistryAccess;
    }

    export class $LevelSettings extends $Record {
        constructor(levelName: string, gameType: $GameType_, difficultySettings: $LevelSettings$DifficultySettings, allowCommands: boolean, dataConfiguration: $WorldDataConfiguration);
        static parse(input: $Dynamic<any>, loadConfig: $WorldDataConfiguration): $LevelSettings;
        allowCommands(): boolean;
        copy(): $LevelSettings;
        dataConfiguration(): $WorldDataConfiguration;
        difficultySettings(): $LevelSettings$DifficultySettings;
        equals(o: unknown): boolean;
        gameType(): $GameType;
        hashCode(): number;
        levelName(): string;
        toString(): string;
        withAllowCommands(allowCommands: boolean): $LevelSettings;
        withDataConfiguration(dataConfiguration: $WorldDataConfiguration): $LevelSettings;
        withDifficultyLock(locked: boolean): $LevelSettings;
        withDifficulty(difficulty: $Difficulty_): $LevelSettings;
        withGameType(gameType: $GameType_): $LevelSettings;
    }

    export class $LevelSettings$DifficultySettings extends $Record {
        constructor(difficulty: $Difficulty_, hardcore: boolean, locked: boolean);
        static CODEC: $Codec<$LevelSettings$DifficultySettings>;
        static DEFAULT: $LevelSettings$DifficultySettings;
        difficulty(): $Difficulty;
        equals(o: unknown): boolean;
        hardcore(): boolean;
        hashCode(): number;
        locked(): boolean;
        toString(): string;
    }

    export interface $LevelSimulatedRW extends $LevelSimulatedReader, $LevelWriter {
    }

    export interface $LevelSimulatedReader {
        getBlockEntity<T extends $BlockEntity>(pos: $BlockPos_, type: $BlockEntityType_<T>): $Optional<T>;
        getHeightmapPos(type: $Heightmap$Types_, pos: $BlockPos_): $BlockPos;
        isFluidAtPosition(pos: $BlockPos_, predicate: $Predicate_<$FluidState, $FluidState, boolean>): boolean;
        isStateAtPosition(pos: $BlockPos_, predicate: $Predicate_<$BlockState, $BlockState, boolean>): boolean;
    }

    export interface $LevelWriter {
        addFreshEntity(entity: $Entity): boolean;
        destroyBlock(pos: $BlockPos_, dropResources: boolean, breaker: $Entity, updateLimit: number): boolean;
        destroyBlock(pos: $BlockPos_, dropResources: boolean, breaker: $Entity): boolean;
        destroyBlock(pos: $BlockPos_, dropResources: boolean): boolean;
        removeBlock(pos: $BlockPos_, movedByPiston: boolean): boolean;
        setBlock(pos: $BlockPos_, blockState: $BlockState_, updateFlags: number, updateLimit: number): boolean;
        setBlock(pos: $BlockPos_, blockState: $BlockState_, updateFlags: number): boolean;
    }

    export class $LightLayer {
        static BLOCK: $LightLayer;
        static SKY: $LightLayer;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LightLayer[];
        static valueOf(name: string): $LightLayer;
    }
    export interface $LightLayer extends $Enum<$LightLayer> {}

    export class $NaturalSpawner$SpawnState {
        get mobCategoryCounts(): $Object2IntMap<$MobCategory>;
        getMobCategoryCounts(): $Object2IntMap<$MobCategory>;
        get spawnableChunkCount(): number;
        getSpawnableChunkCount(): number;
    }

    export class $NoiseColumn implements $BlockColumn {
        constructor(minY: number, column: $BlockState_[]);
        getBlock(blockY: number): $BlockState;
        setBlock(blockY: number, state: $BlockState_): void;
    }

    export class $PathNavigationRegion implements $CollisionGetter {
        constructor(level: $Level, start: $BlockPos_, end: $BlockPos_);
        get height(): number;
        getHeight(): number;
        get maxSectionY(): number;
        getMaxSectionY(): number;
        get maxY(): number;
        getMaxY(): number;
        get minSectionY(): number;
        getMinSectionY(): number;
        get minY(): number;
        getMinY(): number;
        get sectionsCount(): number;
        getSectionsCount(): number;
        get worldBorder(): $WorldBorder;
        getWorldBorder(): $WorldBorder;
        clipIncludingBorder(c: $ClipContext): $BlockHitResult;
        clipWithInteractionOverride(from: $Vec3_, to: $Vec3_, pos: $BlockPos_, blockShape: $VoxelShape, blockState: $BlockState_): $BlockHitResult;
        clip(c: $ClipContext): $BlockHitResult;
        collidesWithSuffocatingBlock(source: $Entity, box: $AABB): boolean;
        findFreePosition(source: $Entity, allowedCenters: $VoxelShape, preferredCenter: $Vec3_, sizeX: number, sizeY: number, sizeZ: number): $Optional<$Vec3>;
        findSupportingBlock(source: $Entity, box: $AABB): $Optional<$BlockPos>;
        getBiomeFabric(arg0: $BlockPos_): $Holder<$Biome>;
        getBlockAndLiquidCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getBlockCollisionsFromContext(source: $CollisionContext, box: $AABB): $Iterable<$VoxelShape>;
        getBlockCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getBlockEntityRenderData(arg0: $BlockPos_): unknown;
        getBlockEntity<T extends $BlockEntity>(pos: $BlockPos_, type: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(pos: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(pos: $BlockPos_): number;
        getBlockFloorHeight(blockShape: $VoxelShape, belowBlockShape: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStates(box: $AABB): $Stream<$BlockState>;
        getBlockState(pos: $BlockPos_): $BlockState;
        getChunkForCollisions(chunkX: number, chunkZ: number): $BlockGetter;
        getCollisions(source: $Entity, box: $AABB): $Iterable<$VoxelShape>;
        getEntityCollisions(source: $Entity, testArea: $AABB): $List<$VoxelShape>;
        getFluidState(pos: $BlockPos_): $FluidState;
        getLightEmission(pos: $BlockPos_): number;
        getPreMoveCollisions(source: $Entity, box: $AABB, oldPos: $Vec3_): $Iterable<$VoxelShape>;
        getSectionIndexFromSectionY(sectionY: number): number;
        getSectionIndex(blockY: number): number;
        getSectionYFromSectionIndex(sectionIndex: number): number;
        hasBiomes(): boolean;
        isBlockInLine(c: $ClipBlockStateContext): $BlockHitResult;
        isInsideBuildHeight(blockY: number): boolean;
        isInsideBuildHeight(pos: $BlockPos_): boolean;
        isOutsideBuildHeight(blockY: number): boolean;
        isOutsideBuildHeight(pos: $BlockPos_): boolean;
        isUnobstructed(source: $Entity, shape: $VoxelShape): boolean;
        isUnobstructed(ignore: $Entity): boolean;
        isUnobstructed(state: $BlockState_, pos: $BlockPos_, context: $CollisionContext): boolean;
        noBlockCollision(entity: $Entity, aabb: $AABB, alwaysCollideWithFluids: boolean): boolean;
        noBlockCollision(entity: $Entity, aabb: $AABB): boolean;
        noBorderCollision(entity: $Entity, aabb: $AABB): boolean;
        noCollision(entity: $Entity, aabb: $AABB, alwaysCollideWithFluids: boolean): boolean;
        noCollision(entity: $Entity, aabb: $AABB): boolean;
        noCollision(source: $Entity): boolean;
        noCollision(aabb: $AABB): boolean;
        noEntityCollision(entity: $Entity, aabb: $AABB): boolean;
    }

    export interface $ScheduledTickAccess {
        createTick<T>(pos: $BlockPos_, type: T, tickDelay: number, priority: $TickPriority_): $ScheduledTick<T>;
        createTick<T>(pos: $BlockPos_, type: T, tickDelay: number): $ScheduledTick<T>;
        getBlockTicks(): $LevelTickAccess<$Block>;
        getFluidTicks(): $LevelTickAccess<$Fluid>;
        scheduleTick(pos: $BlockPos_, type: $Block_, tickDelay: number, priority: $TickPriority_): void;
        scheduleTick(pos: $BlockPos_, type: $Block_, tickDelay: number): void;
        scheduleTick(pos: $BlockPos_, type: $Fluid_, tickDelay: number, priority: $TickPriority_): void;
        scheduleTick(pos: $BlockPos_, type: $Fluid_, tickDelay: number): void;
    }

    export interface $ServerLevelAccessor extends $LevelAccessor {
        addFreshEntityWithPassengers(entity: $Entity): void;
        getCurrentDifficultyAt(pos: $BlockPos_): $DifficultyInstance;
        getLevel(): $ServerLevel;
    }

    export interface $SignalGetter extends $BlockGetter {
        getBestNeighborSignal(pos: $BlockPos_): number;
        getBestOwnOrNeighbourSignal(pos: $BlockPos_): number;
        getControlInputSignal(pos: $BlockPos_, direction: $Direction_, onlyDiodes: boolean): number;
        getDirectSignalTo(pos: $BlockPos_): number;
        getDirectSignal(pos: $BlockPos_, direction: $Direction_): number;
        getSignal(pos: $BlockPos_, direction: $Direction_): number;
        hasNeighborSignal(blockPos: $BlockPos_): boolean;
        hasSignal(pos: $BlockPos_, direction: $Direction_): boolean;
    }
    export const $SignalGetter: {
        readonly DIRECTIONS: $Direction[];
    };

    export class $StructureManager {
        constructor(level: $LevelAccessor, worldOptions: $WorldOptions, structureCheck: $StructureCheck);
        addReferenceForStructure(pos: $SectionPos, structure: $Structure, reference: number, chunk: $StructureAccess): void;
        addReference(start: $StructureStart): void;
        checkStructurePresence(pos: $ChunkPos, structure: $Structure, placement: $StructurePlacement, createReference: boolean): $StructureCheckResult;
        fillStartsForStructure(structure: $Structure, referencesForStructure: $LongSet, consumer: $Consumer_<$StructureStart, $StructureStart>): void;
        forWorldGenRegion(region: $WorldGenRegion): $StructureManager;
        getAllStructuresAt(pos: $BlockPos_): $Map<$Structure, $LongSet>;
        getStartForStructure(pos: $SectionPos, structure: $Structure, chunk: $StructureAccess): $StructureStart;
        getStructureAt(blockPos: $BlockPos_, structure: $Structure): $StructureStart;
        getStructureWithPieceAt(blockPos: $BlockPos_, predicate: $Predicate_<$Holder<$Structure>, $Holder<$Structure>, boolean>): $StructureStart;
        getStructureWithPieceAt(blockPos: $BlockPos_, structures: $HolderSet<$Structure>): $StructureStart;
        getStructureWithPieceAt(blockPos: $BlockPos_, structureTag: $TagKey_<$Structure>): $StructureStart;
        getStructureWithPieceAt(blockPos: $BlockPos_, structure: $Structure): $StructureStart;
        hasAnyStructureAt(pos: $BlockPos_): boolean;
        registryAccess(): $RegistryAccess;
        setStartForStructure(pos: $SectionPos, structure: $Structure, start: $StructureStart, chunk: $StructureAccess): void;
        shouldGenerateStructures(): boolean;
        startsForStructure(pos: $SectionPos, structure: $Structure): $List<$StructureStart>;
        startsForStructure(pos: $ChunkPos, matcher: $Predicate_<$Structure, $Structure, boolean>): $List<$StructureStart>;
        structureHasPieceAt(blockPos: $BlockPos_, structureStart: $StructureStart): boolean;
    }

    export class $TicketStorage extends $SavedData {
        constructor();
        static CODEC: $Codec<$TicketStorage>;
        static TYPE: $SavedDataType<$TicketStorage>;
        get forceLoadedChunks(): $LongSet;
        getForceLoadedChunks(): $LongSet;
        activateAllDeactivatedTickets(): void;
        addTicketWithRadius(type: $TicketType_, chunkPos: $ChunkPos, radius: number): void;
        addTicket(key: number, ticket: $Ticket): boolean;
        addTicket(ticket: $Ticket, chunkPos: $ChunkPos): void;
        deactivateTicketsOnClosing(): void;
        getTicketDebugString(key: number, simulation: boolean): string;
        getTicketLevelAt(key: number, simulation: boolean): number;
        getTickets(key: number): $List<$Ticket>;
        hasTickets(): boolean;
        purgeStaleTickets(chunkMap: $ChunkMap): void;
        removeTicketIf(predicate: $TicketStorage$TicketPredicate_<$Ticket, number, boolean>, removedTickets: $Long2ObjectOpenHashMap<$List<$Ticket>>): void;
        removeTicketWithRadius(type: $TicketType_, chunkPos: $ChunkPos, radius: number): void;
        removeTicket(key: number, ticket: $Ticket): boolean;
        removeTicket(ticket: $Ticket, chunkPos: $ChunkPos): void;
        replaceTicketLevelOfType(newLevel: number, ticketType: $TicketType_): void;
        setLoadingChunkUpdatedListener(loadingChunkUpdatedListener: $TicketStorage$ChunkUpdated_<number, number, boolean>): void;
        setSimulationChunkUpdatedListener(simulationChunkUpdatedListener: $TicketStorage$ChunkUpdated_<number, number, boolean>): void;
        shouldKeepDimensionActive(): boolean;
        updateChunkForced(chunkPos: $ChunkPos, forced: boolean): boolean;
    }

    export interface $TicketStorage$ChunkUpdated {
        update(node: number, newLevelFrom: number, onlyDecreased: boolean): void;
    }

    export interface $TicketStorage$TicketPredicate {
        test(ticket: $Ticket, chunkPos: number): boolean;
    }

    export class $WorldDataConfiguration extends $Record {
        constructor(dataPacks: $DataPackConfig, enabledFeatures: $FeatureFlagSet);
        static CODEC: $Codec<$WorldDataConfiguration>;
        static DEFAULT: $WorldDataConfiguration;
        static ENABLED_FEATURES_ID: string;
        static MAP_CODEC: $MapCodec<$WorldDataConfiguration>;
        dataPacks(): $DataPackConfig;
        enabledFeatures(): $FeatureFlagSet;
        equals(o: unknown): boolean;
        expandFeatures(newEnabledFeatures: $FeatureFlagSet): $WorldDataConfiguration;
        hashCode(): number;
        toString(): string;
    }

    export interface $WorldGenLevel extends $ServerLevelAccessor {
        ensureCanWrite(pos: $BlockPos_): boolean;
        getSeed(): number;
        setCurrentlyGenerating(currentlyGenerating: $Supplier_<string, string>): void;
    }

    export type $BlockGetter$BlockStepVisitor_<CallbackArg0 = $BlockPos, CallbackArg1 = number, CallbackResult = boolean> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($BlockGetter$BlockStepVisitor & { readonly [Symbol.hasInstance]?: never });
    export type $CardinalLighting$Type_ = $CardinalLighting$Type | "DEFAULT" | "NETHER";
    export type $ClipContext$Block_ = $ClipContext$Block | "COLLIDER" | "FALLDAMAGE_RESETTING" | "OUTLINE" | "VISUAL";
    export type $ClipContext$Fluid_ = $ClipContext$Fluid | "ANY" | "NONE" | "SOURCE_ONLY" | "WATER";
    export type $ClipContext$ShapeGetter_<CallbackArg0 = $BlockState, CallbackArg1 = $BlockGetter, CallbackArg2 = $BlockPos, CallbackArg3 = $CollisionContext, CallbackResult = $VoxelShape> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => CallbackResult) | ($ClipContext$ShapeGetter & { readonly [Symbol.hasInstance]?: never });
    export type $CustomSpawner_<CallbackArg0 = $ServerLevel, CallbackArg1 = boolean> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($CustomSpawner & { readonly [Symbol.hasInstance]?: never });
    export type $Explosion$BlockInteraction_ = $Explosion$BlockInteraction | "DESTROY" | "DESTROY_WITH_DECAY" | "KEEP" | "TRIGGER_BLOCK";
    export type $GameType_ = $GameType | "ADVENTURE" | "CREATIVE" | "SPECTATOR" | "SURVIVAL";
    export type $ItemLike_ = $ItemLike | RegistryTypes.Item | $ItemStack | $Block | $NekoId;
    export type $Level$ExplosionInteraction_ = $Level$ExplosionInteraction | "BLOCK" | "MOB" | "NONE" | "TNT" | "TRIGGER";
    export type $LightLayer_ = $LightLayer | "BLOCK" | "SKY";
    export type $TicketStorage$ChunkUpdated_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = boolean> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void) | ($TicketStorage$ChunkUpdated & { readonly [Symbol.hasInstance]?: never });
    export type $TicketStorage$TicketPredicate_<CallbackArg0 = $Ticket, CallbackArg1 = number, CallbackResult = boolean> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($TicketStorage$TicketPredicate & { readonly [Symbol.hasInstance]?: never });
}
