import type { RegistryTypes } from "@special/types";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Iterable, $Record } from "java:java/lang";
import { $Collection, $List, $Optional } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentGetter, $DataComponentGetter_, $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ItemFrame } from "java:net/minecraft/world/entity/decoration";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $DyeColor, $DyeColor_, $Item$TooltipContext, $ItemStack, $ItemStack_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $TooltipProvider, $TooltipProvider_ } from "java:net/minecraft/world/item/component";
import { $BlockGetter, $Level, $LevelAccessor } from "java:net/minecraft/world/level";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";

declare module "java:net/minecraft/world/level/saveddata/maps" {
    export class $MapBanner extends $Record {
        constructor(pos: $BlockPos_, color: $DyeColor_, name: $Optional<$Component>);
        static CODEC: $Codec<$MapBanner>;
        get decoration(): $Holder<$MapDecorationType>;
        getDecoration(): $Holder<$MapDecorationType>;
        get id(): string;
        getId(): string;
        static fromWorld(arg0: $BlockGetter, arg1: $BlockPos_): $MapBanner;
        color(): $DyeColor;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        pos(): $BlockPos;
        toString(): string;
    }

    export class $MapDecoration extends $Record {
        constructor(type: $Holder_<$MapDecorationType>, x: number, y: number, rot: number, name: $Optional<$Component>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $MapDecoration>;
        get spriteLocation(): $Identifier;
        getSpriteLocation(): $Identifier;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        renderOnFrame(): boolean;
        rot(): number;
        toString(): string;
        type(): $Holder<$MapDecorationType>;
        x(): number;
        y(): number;
    }

    export class $MapDecorationType extends $Record {
        constructor(assetId: $Identifier_, showOnItemFrame: boolean, mapColor: number, explorationMapElement: boolean, trackCount: boolean);
        static CODEC: $Codec<$Holder<$MapDecorationType>>;
        static NO_MAP_COLOR: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$MapDecorationType>>;
        assetId(): $Identifier;
        equals(arg0: unknown): boolean;
        explorationMapElement(): boolean;
        hasMapColor(): boolean;
        hashCode(): number;
        mapColor(): number;
        showOnItemFrame(): boolean;
        toString(): string;
        trackCount(): boolean;
    }

    export class $MapId extends $Record implements $TooltipProvider {
        constructor(id: number);
        static CODEC: $Codec<$MapId>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $MapId>;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer_<$Component, $Component>, arg2: $TooltipFlag, arg3: $DataComponentGetter_<$DataComponentType<any>, any>): void;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        id(): number;
        key(): string;
        toString(): string;
    }

    export class $MapItemSavedData extends $SavedData {
        static CODEC: $Codec<$MapItemSavedData>;
        static MAX_SCALE: number;
        static TRACKED_DECORATION_LIMIT: number;
        centerX: number;
        centerZ: number;
        colors: number[];
        dimension: $ResourceKey<$Level>;
        locked: boolean;
        scale: number;
        get banners(): $Collection<$MapBanner>;
        getBanners(): $Collection<$MapBanner>;
        get decorations(): $Iterable<$MapDecoration>;
        getDecorations(): $Iterable<$MapDecoration>;
        get explorationMap(): boolean;
        isExplorationMap(): boolean;
        static addTargetDecoration(arg0: $ItemStack_, arg1: $BlockPos_, arg2: string, arg3: $Holder_<$MapDecorationType>): void;
        static createForClient(arg0: number, arg1: boolean, arg2: $ResourceKey<$Level>): $MapItemSavedData;
        static createFresh(arg0: number, arg1: number, arg2: number, arg3: boolean, arg4: boolean, arg5: $ResourceKey<$Level>): $MapItemSavedData;
        static type(arg0: $MapId): $SavedDataType<$MapItemSavedData>;
        addClientSideDecorations(arg0: ($List<$MapDecoration> | ($MapDecoration)[])): void;
        addDecoration(arg0: $Holder_<$MapDecorationType>, arg1: $LevelAccessor, arg2: string, arg3: number, arg4: number, arg5: number, arg6: $Component_): void;
        checkBanners(arg0: $BlockGetter, arg1: number, arg2: number): void;
        getHoldingPlayer(arg0: $Player): $MapItemSavedData$HoldingPlayer;
        getUpdatePacket(arg0: $MapId, arg1: $Player): $Packet<any>;
        isTrackedCountOverLimit(arg0: number): boolean;
        "locked()"(): $MapItemSavedData;
        removeDecoration(arg0: string): void;
        removedFromFrame(arg0: $BlockPos_, arg1: number): void;
        scaled(): $MapItemSavedData;
        setColor(arg0: number, arg1: number, arg2: number): void;
        tickCarriedBy(arg0: $Player, arg1: $ItemStack_, arg2: $ItemFrame): void;
        toggleBanner(arg0: $LevelAccessor, arg1: $BlockPos_): boolean;
        updateColor(arg0: number, arg1: number, arg2: number): boolean;
    }

    export class $MapItemSavedData$HoldingPlayer {
        player: $Player;
        step: number;
    }

    export class $MapItemSavedData$MapPatch extends $Record {
        constructor(startX: number, startY: number, width: number, height: number, mapColors: number[]);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Optional<$MapItemSavedData$MapPatch>>;
        applyToMap(arg0: $MapItemSavedData): void;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        height(): number;
        mapColors(): number[];
        startX(): number;
        startY(): number;
        toString(): string;
        width(): number;
    }

    export type $MapDecorationType_ = $MapDecorationType | RegistryTypes.MapDecorationType | $NekoId | string;
}
