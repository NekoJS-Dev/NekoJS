import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $IRecipeManagerExtension, $IRecipeManagerExtension_ } from "java:com/tkisor/nekojs/api/recipe";
import { $IntList } from "java:it/unimi/dsi/fastutil/ints";
import { $Enum, $Iterable, $Record, $Runnable, $Runnable_ } from "java:java/lang";
import { $Collection, $List, $Map, $Optional } from "java:java/util";
import { $CompletableFuture, $Executor, $Executor_ } from "java:java/util/concurrent";
import { $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $FabricRecipeAccess, $FabricRecipeManager } from "java:net/fabricmc/fabric/api/recipe/v1";
import { $CustomIngredient, $FabricIngredient } from "java:net/fabricmc/fabric/api/recipe/v1/ingredient";
import { $SynchronizedRecipes } from "java:net/fabricmc/fabric/api/recipe/v1/sync";
import { $SyncedSerializerAwarePreparedRecipe, $SyncedSerializerAwarePreparedRecipe_ } from "java:net/fabricmc/fabric/impl/recipe/sync";
import { $FabricResourceReloader } from "java:net/fabricmc/fabric/impl/resource";
import { $RecipeAccessMixin } from "java:net/fabricmc/fabric/mixin/recipe";
import { $RecipeManagerAccessor, $RecipeManagerAccessor_ } from "java:net/fabricmc/fabric/mixin/recipe/sync";
import { $Holder, $HolderLookup$Provider, $HolderSet, $Holder_, $NonNullList, $Registry } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $PreparableReloadListener$PreparationBarrier, $PreparableReloadListener$PreparationBarrier_, $PreparableReloadListener$SharedState, $SimplePreparableReloadListener } from "java:net/minecraft/server/packs/resources";
import { $StackedContents$IngredientInfo, $StackedContents$IngredientInfo_, $StackedItemContents } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemStack, $ItemStackTemplate, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $RecipeDisplay, $RecipeDisplayEntry, $RecipeDisplayId, $SlotDisplay } from "java:net/minecraft/world/item/crafting/display";
import { $ItemLike, $ItemLike_, $Level } from "java:net/minecraft/world/level";

export * as display from "java:net/minecraft/world/item/crafting/display";

declare module "java:net/minecraft/world/item/crafting" {
    export class $AbstractCookingRecipe extends $SingleItemRecipe {
        constructor(commonInfo: $Recipe$CommonInfo, bookInfo: $AbstractCookingRecipe$CookingBookInfo, ingredient: $Ingredient_, result: $ItemStackTemplate, experience: number, cookingTime: number);
        get serializer(): $RecipeSerializer<$AbstractCookingRecipe>;
        getSerializer(): $RecipeSerializer<$AbstractCookingRecipe>;
        get type(): $RecipeType<$AbstractCookingRecipe>;
        getType(): $RecipeType<$AbstractCookingRecipe>;
        get special(): boolean;
        isSpecial(): boolean;
        static cookingMapCodec<T extends $AbstractCookingRecipe>(factory: $AbstractCookingRecipe$Factory_<T, $Recipe$CommonInfo, $AbstractCookingRecipe$CookingBookInfo, $Ingredient, $ItemStackTemplate, number, number, T>, defaultCookingTime: number): $MapCodec<T>;
        static cookingStreamCodec<T extends $AbstractCookingRecipe>(factory: $AbstractCookingRecipe$Factory_<T, $Recipe$CommonInfo, $AbstractCookingRecipe$CookingBookInfo, $Ingredient, $ItemStackTemplate, number, number, T>): $StreamCodec<$RegistryFriendlyByteBuf, T>;
        category(): $CookingBookCategory;
        cookingTime(): number;
        display(): $List<$RecipeDisplay>;
        experience(): number;
        group(): string;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export class $AbstractCookingRecipe$CookingBookInfo extends $Record implements $Recipe$BookInfo<$CookingBookCategory> {
        constructor(category: $CookingBookCategory_, group: string);
        static MAP_CODEC: $MapCodec<$AbstractCookingRecipe$CookingBookInfo>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $AbstractCookingRecipe$CookingBookInfo>;
        category(): $CookingBookCategory;
        equals(o: unknown): boolean;
        group(): string;
        hashCode(): number;
        toString(): string;
    }

    export interface $AbstractCookingRecipe$Factory<T extends $AbstractCookingRecipe> {
        create(commonInfo: $Recipe$CommonInfo, cbookInfotegory: $AbstractCookingRecipe$CookingBookInfo, ingredient: $Ingredient_, result: $ItemStackTemplate, experience: number, cookingTime: number): T;
    }

    export class $BlastingRecipe extends $AbstractCookingRecipe {
        constructor(commonInfo: $Recipe$CommonInfo, bookInfo: $AbstractCookingRecipe$CookingBookInfo, ingredient: $Ingredient_, result: $ItemStackTemplate, experience: number, cookingTime: number);
        static MAP_CODEC: $MapCodec<$BlastingRecipe>;
        static SERIALIZER: $RecipeSerializer<$BlastingRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $BlastingRecipe>;
        get serializer(): $RecipeSerializer<$BlastingRecipe>;
        getSerializer(): $RecipeSerializer<$BlastingRecipe>;
        get type(): $RecipeType<$BlastingRecipe>;
        getType(): $RecipeType<$BlastingRecipe>;
        get special(): boolean;
        isSpecial(): boolean;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export class $CampfireCookingRecipe extends $AbstractCookingRecipe {
        constructor(commonInfo: $Recipe$CommonInfo, bookInfo: $AbstractCookingRecipe$CookingBookInfo, ingredient: $Ingredient_, result: $ItemStackTemplate, experience: number, cookingTime: number);
        static MAP_CODEC: $MapCodec<$CampfireCookingRecipe>;
        static SERIALIZER: $RecipeSerializer<$CampfireCookingRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $CampfireCookingRecipe>;
        get serializer(): $RecipeSerializer<$CampfireCookingRecipe>;
        getSerializer(): $RecipeSerializer<$CampfireCookingRecipe>;
        get type(): $RecipeType<$CampfireCookingRecipe>;
        getType(): $RecipeType<$CampfireCookingRecipe>;
        get special(): boolean;
        isSpecial(): boolean;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export class $CookingBookCategory {
        static BLOCKS: $CookingBookCategory;
        static FOOD: $CookingBookCategory;
        static MISC: $CookingBookCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CookingBookCategory[];
        static valueOf(name: string): $CookingBookCategory;
    }
    export interface $CookingBookCategory extends $Enum<$CookingBookCategory> {}

    export class $CraftingBookCategory {
        static BUILDING: $CraftingBookCategory;
        static EQUIPMENT: $CraftingBookCategory;
        static MISC: $CraftingBookCategory;
        static REDSTONE: $CraftingBookCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CraftingBookCategory[];
        static valueOf(name: string): $CraftingBookCategory;
    }
    export interface $CraftingBookCategory extends $Enum<$CraftingBookCategory> {}

    export class $CraftingInput implements $RecipeInput {
        static EMPTY: $CraftingInput;
        get empty(): boolean;
        isEmpty(): boolean;
        static ofPositioned(width: number, height: number, items: ($List<$ItemStack> | ($ItemStack_)[])): $CraftingInput$Positioned;
        static of(width: number, height: number, items: ($List<$ItemStack> | ($ItemStack_)[])): $CraftingInput;
        equals(obj: unknown): boolean;
        getItem(x: number, y: number): $ItemStack;
        getItem(index: number): $ItemStack;
        hashCode(): number;
        height(): number;
        ingredientCount(): number;
        items(): $List<$ItemStack>;
        size(): number;
        stackedContents(): $StackedItemContents;
        width(): number;
    }

    export class $CraftingInput$Positioned extends $Record {
        constructor(input: $CraftingInput, left: number, top: number);
        static EMPTY: $CraftingInput$Positioned;
        equals(o: unknown): boolean;
        hashCode(): number;
        input(): $CraftingInput;
        left(): number;
        toString(): string;
        top(): number;
    }

    export interface $CraftingRecipe extends $Recipe<$CraftingInput> {
        category(): $CraftingBookCategory;
        getRemainingItems(input: $CraftingInput): $NonNullList<$ItemStack>;
        getSerializer(): $RecipeSerializer<$CraftingRecipe>;
        getType(): $RecipeType<$CraftingRecipe>;
        recipeBookCategory(): $RecipeBookCategory;
    }
    export const $CraftingRecipe: {
        defaultCraftingReminder(input: $CraftingInput): $NonNullList<$ItemStack>;
    };

    export interface $ExtendedRecipeBookCategory {
    }

    export class $Ingredient implements $Predicate<$ItemStack>, $StackedContents$IngredientInfo<$Holder<$Item>>, $FabricIngredient {
        constructor(values: $HolderSet<$Item>);
        static CODEC: $Codec<$Ingredient>;
        static CONTENTS_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Ingredient>;
        static NON_AIR_HOLDER_SET_CODEC: $Codec<$HolderSet<$Item>>;
        static OPTIONAL_CONTENTS_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Optional<$Ingredient>>;
        values: $HolderSet<$Item>;
        get customIngredient(): $CustomIngredient;
        getCustomIngredient(): $CustomIngredient;
        get empty(): boolean;
        isEmpty(): boolean;
        static displayForSingleItem(item: $Holder_<$Item>): $SlotDisplay;
        static of(stream: $Stream<$ItemLike>): $Ingredient;
        static of(tag: $HolderSet<$Item>): $Ingredient;
        static of(items?: $ItemLike_[]): $Ingredient;
        static of(itemLike: $ItemLike_): $Ingredient;
        static optionalIngredientToDisplay(ingredient: $Optional<$Ingredient>): $SlotDisplay;
        static testOptionalIngredient(ingredient: $Optional<$Ingredient>, stack: $ItemStack_): boolean;
        acceptsItem(item: $Holder_<$Item>): boolean;
        and(arg0: $Predicate_<$ItemStack, $ItemStack, boolean>): $Predicate<$ItemStack>;
        display(): $SlotDisplay;
        equals(o: unknown): boolean;
        hashCode(): number;
        items(): $Stream<$Holder<$Item>>;
        negate(): $Predicate<$ItemStack>;
        or(arg0: $Predicate_<$ItemStack, $ItemStack, boolean>): $Predicate<$ItemStack>;
        requiresTesting(): boolean;
        test(input: $ItemStack_): boolean;
    }

    export class $PlacementInfo {
        static EMPTY_SLOT: number;
        static NOT_PLACEABLE: $PlacementInfo;
        get impossibleToPlace(): boolean;
        isImpossibleToPlace(): boolean;
        static createFromOptionals(ingredients: ($List<$Optional<$Ingredient>> | ($Optional<$Ingredient>)[])): $PlacementInfo;
        static create(ingredients: ($List<$Ingredient> | ($Ingredient_)[])): $PlacementInfo;
        static create(ingredient: $Ingredient_): $PlacementInfo;
        ingredients(): $List<$Ingredient>;
        slotsToIngredientIndex(): $IntList;
    }

    export interface $Recipe<T extends $RecipeInput> {
        assemble(input: T): $ItemStack;
        display(): $List<$RecipeDisplay>;
        getSerializer(): $RecipeSerializer<$Recipe<T>>;
        getType(): $RecipeType<$Recipe<T>>;
        group(): string;
        isSpecial(): boolean;
        matches(input: T, level: $Level): boolean;
        placementInfo(): $PlacementInfo;
        recipeBookCategory(): $RecipeBookCategory;
        showNotification(): boolean;
    }
    export const $Recipe: {
        readonly CODEC: $Codec<$Recipe<any>>;
        readonly KEY_CODEC: $Codec<$ResourceKey<$Recipe<any>>>;
        readonly STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Recipe<any>>;
    };

    export interface $Recipe$BookInfo<CategoryType> {
        category(): CategoryType;
        group(): string;
    }
    export const $Recipe$BookInfo: {
        mapCodec<CategoryType, SelfType extends $Recipe$BookInfo<CategoryType>>(categoryCodec: $Codec<CategoryType>, defaultCategory: CategoryType, constructor: $Recipe$BookInfo$Constructor_<CategoryType, SelfType, CategoryType, string, SelfType>): $MapCodec<SelfType>;
        streamCodec<CategoryType, SelfType extends $Recipe$BookInfo<CategoryType>>(categoryCodec: $StreamCodec<any, CategoryType>, constructor: $Recipe$BookInfo$Constructor_<CategoryType, SelfType, CategoryType, string, SelfType>): $StreamCodec<$RegistryFriendlyByteBuf, SelfType>;
    };

    export class $Recipe$CommonInfo extends $Record {
        constructor(showNotification: boolean);
        static MAP_CODEC: $MapCodec<$Recipe$CommonInfo>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Recipe$CommonInfo>;
        equals(o: unknown): boolean;
        hashCode(): number;
        showNotification(): boolean;
        toString(): string;
    }

    export interface $RecipeAccess extends $FabricRecipeAccess, $RecipeAccessMixin {
        getSynchronizedRecipes(): $SynchronizedRecipes;
        propertySet(id: $ResourceKey<$RecipePropertySet>): $RecipePropertySet;
        stonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
    }

    export class $RecipeBookCategory implements $ExtendedRecipeBookCategory {
        constructor();
    }

    export class $RecipeHolder<T extends $Recipe<any>> extends $Record {
        constructor(id: $ResourceKey<$Recipe<any>>, value: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $RecipeHolder<any>>;
        equals(obj: unknown): boolean;
        hashCode(): number;
        id(): $ResourceKey<$Recipe<any>>;
        toString(): string;
        value(): T;
    }

    export interface $RecipeInput {
        getItem(index: number): $ItemStack;
        isEmpty(): boolean;
        size(): number;
    }

    export class $RecipeManager extends $SimplePreparableReloadListener<$RecipeMap> implements $RecipeAccess, $FabricRecipeManager, $RecipeManagerAccessor, $FabricResourceReloader, $IRecipeManagerExtension {
        constructor(registries: $HolderLookup$Provider);
        get name(): string;
        getName(): string;
        get recipes(): $Collection<$RecipeHolder<any>>;
        getRecipes(): $Collection<$RecipeHolder<any>>;
        get synchronizedItemProperties(): $Map<$ResourceKey<$RecipePropertySet>, $RecipePropertySet>;
        getSynchronizedItemProperties(): $Map<$ResourceKey<$RecipePropertySet>, $RecipePropertySet>;
        get synchronizedRecipes(): $SynchronizedRecipes;
        getSynchronizedRecipes(): $SynchronizedRecipes;
        get synchronizedStonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
        getSynchronizedStonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
        static createCheck<I extends $RecipeInput, T extends $Recipe<I>>(type: $RecipeType<T>): $RecipeManager$CachedCheck<I, T>;
        byKey(recipeId: $ResourceKey<$Recipe<any>>): $Optional<$RecipeHolder<any>>;
        fabric$getId(): $Identifier;
        finalizeRecipeLoading(enabledFlags: $FeatureFlagSet): void;
        getAllMatches(arg0: $RecipeType<any>, arg1: $RecipeInput, arg2: $Level): $Stream<any>;
        getAllOfType(arg0: $RecipeType<any>): $Collection<any>;
        getRecipeFor<I extends $RecipeInput, T extends $Recipe<I>>(type: $RecipeType<T>, input: I, level: $Level, recipeHint: $ResourceKey<$Recipe<any>>): $Optional<$RecipeHolder<T>>;
        getRecipeFor<I extends $RecipeInput, T extends $Recipe<I>>(type: $RecipeType<T>, input: I, level: $Level, recipeHint: $RecipeHolder<T>): $Optional<$RecipeHolder<T>>;
        getRecipeFor<I extends $RecipeInput, T extends $Recipe<I>>(type: $RecipeType<T>, input: I, level: $Level): $Optional<$RecipeHolder<T>>;
        getRecipeFromDisplay(id: $RecipeDisplayId): $RecipeManager$ServerDisplayInfo;
        getRecipes(): $RecipeMap;
        listDisplaysForRecipe(id: $ResourceKey<$Recipe<any>>, output: $Consumer_<$RecipeDisplayEntry, $RecipeDisplayEntry>): void;
        nekojs$applyScripts(): void;
        prepareSharedState(currentReload: $PreparableReloadListener$SharedState): void;
        propertySet(id: $ResourceKey<$RecipePropertySet>): $RecipePropertySet;
        reload(currentReload: $PreparableReloadListener$SharedState, taskExecutor: $Executor_<$Runnable>, preparationBarrier: $PreparableReloadListener$PreparationBarrier_<any, $CompletableFuture<any>>, reloadExecutor: $Executor_<$Runnable>): $CompletableFuture<void>;
        stonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
    }

    export interface $RecipeManager$CachedCheck<I extends $RecipeInput, T extends $Recipe<I>> {
        getRecipeFor(input: I, level: $ServerLevel): $Optional<$RecipeHolder<T>>;
    }

    export class $RecipeManager$ServerDisplayInfo extends $Record {
        constructor(display: $RecipeDisplayEntry, parent: $RecipeHolder<any>);
        display(): $RecipeDisplayEntry;
        equals(o: unknown): boolean;
        hashCode(): number;
        parent(): $RecipeHolder<any>;
        toString(): string;
    }

    export class $RecipeMap implements $SyncedSerializerAwarePreparedRecipe {
        static EMPTY: $RecipeMap;
        static create(recipes: ($Iterable<$RecipeHolder<any>> | ($RecipeHolder<any>)[])): $RecipeMap;
        byKey(recipeId: $ResourceKey<$Recipe<any>>): $RecipeHolder<any>;
        byType<I extends $RecipeInput, T extends $Recipe<I>>(type: $RecipeType<T>): $Collection<$RecipeHolder<T>>;
        fabric_getRecipesBySyncedSerializer(arg0: $RecipeSerializer<any>): $List<$RecipeHolder<any>>;
        getRecipesFor<I extends $RecipeInput, T extends $Recipe<I>>(type: $RecipeType<T>, container: I, level: $Level): $Stream<$RecipeHolder<T>>;
        values(): $Collection<$RecipeHolder<any>>;
    }

    export class $RecipePropertySet {
        static BLAST_FURNACE_INPUT: $ResourceKey<$RecipePropertySet>;
        static CAMPFIRE_INPUT: $ResourceKey<$RecipePropertySet>;
        static EMPTY: $RecipePropertySet;
        static FURNACE_INPUT: $ResourceKey<$RecipePropertySet>;
        static SMITHING_ADDITION: $ResourceKey<$RecipePropertySet>;
        static SMITHING_BASE: $ResourceKey<$RecipePropertySet>;
        static SMITHING_TEMPLATE: $ResourceKey<$RecipePropertySet>;
        static SMOKER_INPUT: $ResourceKey<$RecipePropertySet>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $RecipePropertySet>;
        static TYPE_KEY: $ResourceKey<$Registry<$RecipePropertySet>>;
        test(itemStack: $ItemStack_): boolean;
    }

    export class $RecipeSerializer<T extends $Recipe<any>> extends $Record {
        constructor(codec: $MapCodec<T>, streamCodec: $StreamCodec<$RegistryFriendlyByteBuf, T>);
        codec(): $MapCodec<T>;
        equals(o: unknown): boolean;
        hashCode(): number;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, T>;
        toString(): string;
    }

    export interface $RecipeType<T extends $Recipe<any>> {
    }
    export const $RecipeType: {
        register<T extends $Recipe<any>>(name: string): $RecipeType<T>;
        readonly BLASTING: $RecipeType<$BlastingRecipe>;
        readonly CAMPFIRE_COOKING: $RecipeType<$CampfireCookingRecipe>;
        readonly CRAFTING: $RecipeType<$CraftingRecipe>;
        readonly SMELTING: $RecipeType<$SmeltingRecipe>;
        readonly SMITHING: $RecipeType<$SmithingRecipe>;
        readonly SMOKING: $RecipeType<$SmokingRecipe>;
        readonly STONECUTTING: $RecipeType<$StonecutterRecipe>;
    };

    export class $SelectableRecipe<T extends $Recipe<any>> extends $Record {
        constructor(optionDisplay: $SlotDisplay, recipe: $Optional<$RecipeHolder<T>>);
        static noRecipeCodec<T extends $Recipe<any>>(): $StreamCodec<$RegistryFriendlyByteBuf, $SelectableRecipe<T>>;
        equals(o: unknown): boolean;
        hashCode(): number;
        optionDisplay(): $SlotDisplay;
        recipe(): $Optional<$RecipeHolder<T>>;
        toString(): string;
    }

    export class $SelectableRecipe$SingleInputEntry<T extends $Recipe<any>> extends $Record {
        constructor(input: $Ingredient_, recipe: $SelectableRecipe<T>);
        static noRecipeCodec<T extends $Recipe<any>>(): $StreamCodec<$RegistryFriendlyByteBuf, $SelectableRecipe$SingleInputEntry<T>>;
        equals(o: unknown): boolean;
        hashCode(): number;
        input(): $Ingredient;
        recipe(): $SelectableRecipe<T>;
        toString(): string;
    }

    export class $SelectableRecipe$SingleInputSet<T extends $Recipe<any>> extends $Record {
        constructor(entries: ($List<$SelectableRecipe$SingleInputEntry<T>> | ($SelectableRecipe$SingleInputEntry<T>)[]));
        get empty(): boolean;
        isEmpty(): boolean;
        static empty<T extends $Recipe<any>>(): $SelectableRecipe$SingleInputSet<T>;
        static noRecipeCodec<T extends $Recipe<any>>(): $StreamCodec<$RegistryFriendlyByteBuf, $SelectableRecipe$SingleInputSet<T>>;
        acceptsInput(input: $ItemStack_): boolean;
        entries(): $List<$SelectableRecipe$SingleInputEntry<T>>;
        equals(o: unknown): boolean;
        hashCode(): number;
        selectByInput(input: $ItemStack_): $SelectableRecipe$SingleInputSet<T>;
        size(): number;
        toString(): string;
    }

    export class $SingleItemRecipe implements $Recipe<$SingleRecipeInput> {
        constructor(commonInfo: $Recipe$CommonInfo, input: $Ingredient_, result: $ItemStackTemplate);
        result: $ItemStackTemplate;
        get serializer(): $RecipeSerializer<$SingleItemRecipe>;
        getSerializer(): $RecipeSerializer<$SingleItemRecipe>;
        get type(): $RecipeType<$SingleItemRecipe>;
        getType(): $RecipeType<$SingleItemRecipe>;
        get special(): boolean;
        isSpecial(): boolean;
        static simpleMapCodec<T extends $SingleItemRecipe>(factory: $SingleItemRecipe$Factory_<T, $Recipe$CommonInfo, $Ingredient, $ItemStackTemplate, T>): $MapCodec<T>;
        static simpleStreamCodec<T extends $SingleItemRecipe>(factory: $SingleItemRecipe$Factory_<T, $Recipe$CommonInfo, $Ingredient, $ItemStackTemplate, T>): $StreamCodec<$RegistryFriendlyByteBuf, T>;
        assemble(input: $SingleRecipeInput): $ItemStack;
        display(): $List<$RecipeDisplay>;
        group(): string;
        input(): $Ingredient;
        matches(input: $SingleRecipeInput, level: $Level): boolean;
        placementInfo(): $PlacementInfo;
        recipeBookCategory(): $RecipeBookCategory;
        "result()"(): $ItemStackTemplate;
        showNotification(): boolean;
    }

    export interface $SingleItemRecipe$Factory<T extends $SingleItemRecipe> {
        create(commonInfo: $Recipe$CommonInfo, ingredient: $Ingredient_, result: $ItemStackTemplate): T;
    }

    export class $SingleRecipeInput extends $Record implements $RecipeInput {
        constructor(item: $ItemStack_);
        get empty(): boolean;
        isEmpty(): boolean;
        equals(o: unknown): boolean;
        getItem(index: number): $ItemStack;
        hashCode(): number;
        item(): $ItemStack;
        size(): number;
        toString(): string;
    }

    export class $SmeltingRecipe extends $AbstractCookingRecipe {
        constructor(commonInfo: $Recipe$CommonInfo, bookInfo: $AbstractCookingRecipe$CookingBookInfo, ingredient: $Ingredient_, result: $ItemStackTemplate, experience: number, cookingTime: number);
        static MAP_CODEC: $MapCodec<$SmeltingRecipe>;
        static SERIALIZER: $RecipeSerializer<$SmeltingRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $SmeltingRecipe>;
        get serializer(): $RecipeSerializer<$SmeltingRecipe>;
        getSerializer(): $RecipeSerializer<$SmeltingRecipe>;
        get type(): $RecipeType<$SmeltingRecipe>;
        getType(): $RecipeType<$SmeltingRecipe>;
        get special(): boolean;
        isSpecial(): boolean;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export interface $SmithingRecipe extends $Recipe<$SmithingRecipeInput> {
        additionIngredient(): $Optional<$Ingredient>;
        baseIngredient(): $Ingredient;
        getSerializer(): $RecipeSerializer<$SmithingRecipe>;
        getType(): $RecipeType<$SmithingRecipe>;
        matches(input: $SmithingRecipeInput, level: $Level): boolean;
        recipeBookCategory(): $RecipeBookCategory;
        templateIngredient(): $Optional<$Ingredient>;
    }

    export class $SmithingRecipeInput extends $Record implements $RecipeInput {
        constructor(template: $ItemStack_, base: $ItemStack_, addition: $ItemStack_);
        get empty(): boolean;
        isEmpty(): boolean;
        addition(): $ItemStack;
        base(): $ItemStack;
        equals(o: unknown): boolean;
        getItem(index: number): $ItemStack;
        hashCode(): number;
        size(): number;
        template(): $ItemStack;
        toString(): string;
    }

    export class $SmokingRecipe extends $AbstractCookingRecipe {
        constructor(commonInfo: $Recipe$CommonInfo, bookInfo: $AbstractCookingRecipe$CookingBookInfo, ingredient: $Ingredient_, result: $ItemStackTemplate, experience: number, cookingTime: number);
        static MAP_CODEC: $MapCodec<$SmokingRecipe>;
        static SERIALIZER: $RecipeSerializer<$SmokingRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $SmokingRecipe>;
        get serializer(): $RecipeSerializer<$SmokingRecipe>;
        getSerializer(): $RecipeSerializer<$SmokingRecipe>;
        get type(): $RecipeType<$SmokingRecipe>;
        getType(): $RecipeType<$SmokingRecipe>;
        get special(): boolean;
        isSpecial(): boolean;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export class $StonecutterRecipe extends $SingleItemRecipe {
        constructor(commonInfo: $Recipe$CommonInfo, ingredient: $Ingredient_, result: $ItemStackTemplate);
        static MAP_CODEC: $MapCodec<$StonecutterRecipe>;
        static SERIALIZER: $RecipeSerializer<$StonecutterRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $StonecutterRecipe>;
        get serializer(): $RecipeSerializer<$StonecutterRecipe>;
        getSerializer(): $RecipeSerializer<$StonecutterRecipe>;
        get type(): $RecipeType<$StonecutterRecipe>;
        getType(): $RecipeType<$StonecutterRecipe>;
        get special(): boolean;
        isSpecial(): boolean;
        display(): $List<$RecipeDisplay>;
        group(): string;
        recipeBookCategory(): $RecipeBookCategory;
        resultDisplay(): $SlotDisplay;
    }

    export interface $Recipe$BookInfo$Constructor<CategoryType, SelfType extends $Recipe$BookInfo<CategoryType>> extends $BiFunction<CategoryType, string, SelfType> {
    }

    export type $AbstractCookingRecipe$Factory_<Host0 extends $AbstractCookingRecipe = any, CallbackArg0 = $Recipe$CommonInfo, CallbackArg1 = $AbstractCookingRecipe$CookingBookInfo, CallbackArg2 = $Ingredient, CallbackArg3 = $ItemStackTemplate, CallbackArg4 = number, CallbackArg5 = number, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4, arg5: CallbackArg5) => CallbackResult) | ($AbstractCookingRecipe$Factory<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $CookingBookCategory_ = $CookingBookCategory | "BLOCKS" | "FOOD" | "MISC";
    export type $CraftingBookCategory_ = $CraftingBookCategory | "BUILDING" | "EQUIPMENT" | "MISC" | "REDSTONE";
    /** item:id | #tag | @mod | * | /regex/ | { item?|tag?|mod?|regex?|wildcard?|filter?|any?|all?|not? } */
    export type $Ingredient_ = $Ingredient | RegistryTypes.Item | `#${RegistryTypes.ItemTag}` | `@${RegistryTypes.Namespace}` | "*" | `/${string}` | $Ingredient_[] | $ItemStack | $Item | $NekoId | { item?: RegistryTypes.Item, tag?: RegistryTypes.ItemTag, mod?: RegistryTypes.Namespace, regex?: string, wildcard?: boolean, filter?: ((item: $ItemStack) => boolean), any?: $Ingredient_[], all?: $Ingredient_[], not?: $Ingredient_ };
    export type $RecipeBookCategory_ = $RecipeBookCategory | RegistryTypes.RecipeBookCategory | $NekoId | string;
    export type $RecipeManager$CachedCheck_<Host0 extends $RecipeInput = any, Host1 extends $Recipe<Host0> = any, CallbackArg0 = Host0, CallbackArg1 = $ServerLevel, CallbackResult = $Optional<$RecipeHolder<Host1>>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($RecipeManager$CachedCheck<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
    export type $SingleItemRecipe$Factory_<Host0 extends $SingleItemRecipe = any, CallbackArg0 = $Recipe$CommonInfo, CallbackArg1 = $Ingredient, CallbackArg2 = $ItemStackTemplate, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($SingleItemRecipe$Factory<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Recipe$BookInfo$Constructor_<Host0 = any, Host1 extends $Recipe$BookInfo<Host0> = any, CallbackArg0 = Host0, CallbackArg1 = string, CallbackResult = Host1> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($Recipe$BookInfo$Constructor<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
}
