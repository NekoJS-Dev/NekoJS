import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Iterable } from "java:java/lang";
import { $EnumSet, $List, $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction$Axis, $Direction$Axis_, $Direction_, $Position, $Vec3i } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $RandomSource } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";
import { $Vector3f, $Vector3fc } from "java:org/joml";

export * as shapes from "java:net/minecraft/world/phys/shapes";

declare module "java:net/minecraft/world/phys" {
    export class $AABB {
        constructor(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number);
        constructor(pos: $BlockPos_);
        constructor(begin: $Vec3_, end: $Vec3_);
        maxX: number;
        maxY: number;
        maxZ: number;
        minX: number;
        minY: number;
        minZ: number;
        get bottomCenter(): $Vec3;
        getBottomCenter(): $Vec3;
        get center(): $Vec3;
        getCenter(): $Vec3;
        get maxPosition(): $Vec3;
        getMaxPosition(): $Vec3;
        get minPosition(): $Vec3;
        getMinPosition(): $Vec3;
        get size(): number;
        getSize(): number;
        get xsize(): number;
        getXsize(): number;
        get ysize(): number;
        getYsize(): number;
        get zsize(): number;
        getZsize(): number;
        static clip(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number, from: $Vec3_, to: $Vec3_): $Optional<$Vec3>;
        static clip(aabBs: ($Iterable<$AABB> | ($AABB)[]), from: $Vec3_, to: $Vec3_, pos: $BlockPos_): $BlockHitResult;
        static encapsulatingFullBlocks(pos0: $BlockPos_, pos1: $BlockPos_): $AABB;
        static ofSize(center: $Vec3_, sizeX: number, sizeY: number, sizeZ: number): $AABB;
        static of(box: $BoundingBox): $AABB;
        static unitCubeFromLowerCorner(pos: $Vec3_): $AABB;
        clip(from: $Vec3_, to: $Vec3_): $Optional<$Vec3>;
        collidedAlongVector(vector: $Vec3_, aabbs: ($List<$AABB> | ($AABB)[])): boolean;
        contains(x: number, y: number, z: number): boolean;
        contains(vec: $Vec3_): boolean;
        contract(xa: number, ya: number, za: number): $AABB;
        deflate(xSubstract: number, ySubtract: number, zSubtract: number): $AABB;
        deflate(amount: number): $AABB;
        distanceToSqr(boundingBox: $AABB): number;
        distanceToSqr(point: $Vec3_): number;
        equals(o: unknown): boolean;
        expandTowards(xa: number, ya: number, za: number): $AABB;
        expandTowards(delta: $Vec3_): $AABB;
        hasNaN(): boolean;
        hashCode(): number;
        inflate(xAdd: number, yAdd: number, zAdd: number): $AABB;
        inflate(amountToAddInAllDirections: number): $AABB;
        intersects(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): boolean;
        intersects(pos: $BlockPos_): boolean;
        intersects(aabb: $AABB): boolean;
        intersects(min: $Vec3_, max: $Vec3_): boolean;
        intersect(other: $AABB): $AABB;
        max(axis: $Direction$Axis_): number;
        minmax(other: $AABB): $AABB;
        min(axis: $Direction$Axis_): number;
        move(xa: number, ya: number, za: number): $AABB;
        move(pos: $BlockPos_): $AABB;
        move(pos: $Vec3_): $AABB;
        move(pos: $Vector3f): $AABB;
        setMaxX(maxX: number): $AABB;
        setMaxY(maxY: number): $AABB;
        setMaxZ(maxZ: number): $AABB;
        setMinX(minX: number): $AABB;
        setMinY(minY: number): $AABB;
        setMinZ(minZ: number): $AABB;
        toString(): string;
    }

    export class $BlockHitResult extends $HitResult {
        constructor(location: $Vec3_, direction: $Direction_, pos: $BlockPos_, inside: boolean);
        constructor(location: $Vec3_, direction: $Direction_, pos: $BlockPos_, inside: boolean, worldBorderHit: boolean);
        get blockPos(): $BlockPos;
        getBlockPos(): $BlockPos;
        get direction(): $Direction;
        getDirection(): $Direction;
        get type(): $HitResult$Type;
        getType(): $HitResult$Type;
        get inside(): boolean;
        isInside(): boolean;
        get worldBorderHit(): boolean;
        isWorldBorderHit(): boolean;
        static miss(location: $Vec3_, direction: $Direction_, pos: $BlockPos_): $BlockHitResult;
        hitBorder(): $BlockHitResult;
        withDirection(direction: $Direction_): $BlockHitResult;
        withPosition(blockPos: $BlockPos_): $BlockHitResult;
    }

    export class $HitResult {
        get location(): $Vec3;
        getLocation(): $Vec3;
        get type(): $HitResult$Type;
        getType(): $HitResult$Type;
        distanceTo(entity: $Entity): number;
    }

    export class $HitResult$Type {
        static BLOCK: $HitResult$Type;
        static ENTITY: $HitResult$Type;
        static MISS: $HitResult$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $HitResult$Type[];
        static valueOf(name: string): $HitResult$Type;
    }
    export interface $HitResult$Type extends $Enum<$HitResult$Type> {}

    export class $Vec2 {
        constructor(x: number, y: number);
        static CODEC: $Codec<$Vec2>;
        static MAX: $Vec2;
        static MIN: $Vec2;
        static NEG_UNIT_X: $Vec2;
        static NEG_UNIT_Y: $Vec2;
        static ONE: $Vec2;
        static UNIT_X: $Vec2;
        static UNIT_Y: $Vec2;
        static ZERO: $Vec2;
        x: number;
        y: number;
        add(v: number): $Vec2;
        add(rhs: $Vec2): $Vec2;
        distanceToSqr(p: $Vec2): number;
        dot(v: $Vec2): number;
        equals(rhs: $Vec2): boolean;
        lengthSquared(): number;
        length(): number;
        negated(): $Vec2;
        normalized(): $Vec2;
        scale(s: number): $Vec2;
    }

    export class $Vec3 implements $Position {
        constructor(x: number, y: number, z: number);
        constructor(vec: $Vec3i);
        constructor(vec: $Vector3fc);
        static CODEC: $Codec<$Vec3>;
        static LP_STREAM_CODEC: $StreamCodec<$ByteBuf, $Vec3>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Vec3>;
        static X_AXIS: $Vec3;
        static Y_AXIS: $Vec3;
        static ZERO: $Vec3;
        static Z_AXIS: $Vec3;
        x: number;
        y: number;
        z: number;
        get finite(): boolean;
        isFinite(): boolean;
        static applyLocalCoordinatesToRotation(rotation: $Vec2, direction: $Vec3_): $Vec3;
        static atBottomCenterOf(pos: $Vec3i): $Vec3;
        static atCenterOf(pos: $Vec3i): $Vec3;
        static atLowerCornerOf(pos: $Vec3i): $Vec3;
        static atLowerCornerWithOffset(pos: $Vec3i, x: number, y: number, z: number): $Vec3;
        static directionFromRotation(rotX: number, rotY: number): $Vec3;
        static directionFromRotation(rotation: $Vec2): $Vec3;
        static upFromBottomCenterOf(pos: $Vec3i, yOffset: number): $Vec3;
        addLocalCoordinates(direction: $Vec3_): $Vec3;
        add(x: number, y: number, z: number): $Vec3;
        add(value: number): $Vec3;
        add(vec: $Vec3_): $Vec3;
        align(axes: $EnumSet<$Direction$Axis>): $Vec3;
        closerThan(pos: $Position, distance: number): boolean;
        closerThan(vec: $Vec3_, distanceXZ: number, distanceY: number): boolean;
        cross(vec: $Vec3_): $Vec3;
        distanceToSqr(x: number, y: number, z: number): number;
        distanceToSqr(vec: $Vec3_): number;
        distanceTo(vec: $Vec3_): number;
        dot(vec: $Vec3_): number;
        equals(o: unknown): boolean;
        get(axis: $Direction$Axis_): number;
        hashCode(): number;
        horizontalDistanceSqr(): number;
        horizontalDistance(): number;
        horizontal(): $Vec3;
        lengthSqr(): number;
        length(): number;
        lerp(vec: $Vec3_, a: number): $Vec3;
        multiply(xScale: number, yScale: number, zScale: number): $Vec3;
        multiply(scale: $Vec3_): $Vec3;
        normalize(): $Vec3;
        offsetRandomXZ(random: $RandomSource, offset: number): $Vec3;
        offsetRandom(random: $RandomSource, offset: number): $Vec3;
        projectedOn(onto: $Vec3_): $Vec3;
        relative(direction: $Direction_, distance: number): $Vec3;
        reverse(): $Vec3;
        rotateClockwise90(): $Vec3;
        rotation(): $Vec2;
        scale(scale: number): $Vec3;
        subtract(x: number, y: number, z: number): $Vec3;
        subtract(value: number): $Vec3;
        subtract(vec: $Vec3_): $Vec3;
        toString(): string;
        toVector3f(): $Vector3f;
        vectorTo(vec: $Vec3_): $Vec3;
        with(axis: $Direction$Axis_, value: number): $Vec3;
        xRot(radians: number): $Vec3;
        "x()"(): number;
        yRot(radians: number): $Vec3;
        "y()"(): number;
        zRot(radians: number): $Vec3;
        "z()"(): number;
    }

    export type $HitResult$Type_ = $HitResult$Type | "BLOCK" | "ENTITY" | "MISS";
    export type $Vec3_ = $Vec3 | $BlockPos | { x: number, y: number, z: number } | number[];
}
