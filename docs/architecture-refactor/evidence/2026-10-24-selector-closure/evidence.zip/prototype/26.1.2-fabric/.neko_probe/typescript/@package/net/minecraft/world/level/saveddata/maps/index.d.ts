import type { RegistryTypes } from "@special/types";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Iterable, $Record } from "java:java/lang";
import { $Collection, $List, $Optional } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentGetter, $DataComponentGetter_, $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ItemFrame } from "java:net/minecraft/world/entity/decoration";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $DyeColor, $DyeColor_, $Item$TooltipContext, $ItemStack, $ItemStack_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $TooltipProvider, $TooltipProvider_ } from "java:net/minecraft/world/item/component";
import { $BlockGetter, $Level, $LevelAccessor } from "java:net/minecraft/world/level";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";

declare module "java:net/minecraft/world/level/saveddata/maps" {
    export class $MapBanner extends $Record {
        constructor(pos: $BlockPos_, color: $DyeColor_, name: $Optional<$Component>);
        static CODEC: $Codec<$MapBanner>;
        get decoration(): $Holder<$MapDecorationType>;
        getDecoration(): $Holder<$MapDecorationType>;
        get id(): string;
        getId(): string;
        static fromWorld(level: $BlockGetter, pos: $BlockPos_): $MapBanner;
        color(): $DyeColor;
        equals(o: unknown): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        pos(): $BlockPos;
        toString(): string;
    }

    export class $MapDecoration extends $Record {
        constructor(type: $Holder_<$MapDecorationType>, x: number, y: number, rot: number, name: $Optional<$Component>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $MapDecoration>;
        get spriteLocation(): $Identifier;
        getSpriteLocation(): $Identifier;
        equals(o: unknown): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        renderOnFrame(): boolean;
        rot(): number;
        toString(): string;
        type(): $Holder<$MapDecorationType>;
        x(): number;
        y(): number;
    }

    export class $MapDecorationType extends $Record {
        constructor(assetId: $Identifier_, showOnItemFrame: boolean, mapColor: number, explorationMapElement: boolean, trackCount: boolean);
        static CODEC: $Codec<$Holder<$MapDecorationType>>;
        static NO_MAP_COLOR: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$MapDecorationType>>;
        assetId(): $Identifier;
        equals(o: unknown): boolean;
        explorationMapElement(): boolean;
        hasMapColor(): boolean;
        hashCode(): number;
        mapColor(): number;
        showOnItemFrame(): boolean;
        toString(): string;
        trackCount(): boolean;
    }

    export class $MapId extends $Record implements $TooltipProvider {
        constructor(id: number);
        static CODEC: $Codec<$MapId>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $MapId>;
        addToTooltip(context: $Item$TooltipContext, consumer: $Consumer_<$Component, $Component>, flag: $TooltipFlag, components: $DataComponentGetter_<$DataComponentType<any>, any>): void;
        equals(o: unknown): boolean;
        hashCode(): number;
        id(): number;
        key(): string;
        toString(): string;
    }

    export class $MapItemSavedData extends $SavedData {
        static CODEC: $Codec<$MapItemSavedData>;
        static MAX_SCALE: number;
        static TRACKED_DECORATION_LIMIT: number;
        centerX: number;
        centerZ: number;
        colors: number[];
        dimension: $ResourceKey<$Level>;
        locked: boolean;
        scale: number;
        get banners(): $Collection<$MapBanner>;
        getBanners(): $Collection<$MapBanner>;
        get decorations(): $Iterable<$MapDecoration>;
        getDecorations(): $Iterable<$MapDecoration>;
        get explorationMap(): boolean;
        isExplorationMap(): boolean;
        static addTargetDecoration(itemStack: $ItemStack_, position: $BlockPos_, key: string, decorationType: $Holder_<$MapDecorationType>): void;
        static createForClient(scale: number, isLocked: boolean, dimension: $ResourceKey<$Level>): $MapItemSavedData;
        static createFresh(originX: number, originY: number, scale: number, trackingPosition: boolean, unlimitedTracking: boolean, dimension: $ResourceKey<$Level>): $MapItemSavedData;
        static type(id: $MapId): $SavedDataType<$MapItemSavedData>;
        addClientSideDecorations(decorations: ($List<$MapDecoration> | ($MapDecoration)[])): void;
        checkBanners(level: $BlockGetter, x: number, z: number): void;
        getHoldingPlayer(player: $Player): $MapItemSavedData$HoldingPlayer;
        getUpdatePacket(id: $MapId, player: $Player): $Packet<any>;
        isTrackedCountOverLimit(limit: number): boolean;
        "locked()"(): $MapItemSavedData;
        removedFromFrame(pos: $BlockPos_, entityID: number): void;
        scaled(): $MapItemSavedData;
        setColor(x: number, y: number, newColor: number): void;
        tickCarriedBy(tickingPlayer: $Player, itemStack: $ItemStack_, placedInFrame: $ItemFrame): void;
        toggleBanner(level: $LevelAccessor, pos: $BlockPos_): boolean;
        updateColor(x: number, y: number, newColor: number): boolean;
    }

    export class $MapItemSavedData$HoldingPlayer {
        player: $Player;
        step: number;
    }

    export class $MapItemSavedData$MapPatch extends $Record {
        constructor(startX: number, startY: number, width: number, height: number, mapColors: number[]);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Optional<$MapItemSavedData$MapPatch>>;
        applyToMap(map: $MapItemSavedData): void;
        equals(o: unknown): boolean;
        hashCode(): number;
        height(): number;
        mapColors(): number[];
        startX(): number;
        startY(): number;
        toString(): string;
        width(): number;
    }

    export type $MapDecorationType_ = $MapDecorationType | RegistryTypes.MapDecorationType | $NekoId | string;
}
