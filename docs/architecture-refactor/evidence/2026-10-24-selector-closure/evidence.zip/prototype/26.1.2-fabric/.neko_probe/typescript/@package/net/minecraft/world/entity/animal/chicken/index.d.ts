import { $Codec } from "java:com/mojang/serialization";
import { $PersistentDataJS } from "java:com/tkisor/nekojs/wrapper/pdata";
import { $IntList } from "java:it/unimi/dsi/fastutil/ints";
import { $Enum, $Record } from "java:java/lang";
import { $List, $Map } from "java:java/util";
import { $Supplier, $Supplier_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $AttachmentType } from "java:net/fabricmc/fabric/api/attachment/v1";
import { $PermissionNode } from "java:net/fabricmc/fabric/api/permission/v1";
import { $TriState, $TriState_ } from "java:net/fabricmc/fabric/api/util";
import { $ClientAsset$ResourceTexture, $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType, $TypedDataComponent } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $PermissionLevel, $PermissionLevel_ } from "java:net/minecraft/server/permissions";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $MobEffect, $MobEffectInstance, $MobEffect_ } from "java:net/minecraft/world/effect";
import { $AgeableMob, $Entity, $Entity$RemovalReason, $Entity$RemovalReason_, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $EquipmentSlot, $EquipmentSlot_, $EquipmentTable, $Leashable$LeashData, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $ModelAndTexture, $PriorityProvider, $PriorityProvider$Selector, $PriorityProvider_, $SpawnCondition, $SpawnContext, $SpawnPrioritySelectors } from "java:net/minecraft/world/entity/variant";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $SlotCollection, $SlotCollection_ } from "java:net/minecraft/world/item/slot";
import { $Level, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $TeleportTransition } from "java:net/minecraft/world/level/portal";
import { $ValueInput, $ValueOutput } from "java:net/minecraft/world/level/storage";
import { $LootParams, $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/chicken" {
    export class $Chicken extends $Animal {
        constructor(type: $EntityType_<$Chicken>, level: $Level);
        eggTime: number;
        flap: number;
        flapSpeed: number;
        flapping: number;
        isChickenJockey: boolean;
        oFlap: number;
        oFlapSpeed: number;
        get feedbackDisplayName(): $Component;
        getFeedbackDisplayName(): $Component;
        get leashHolder(): $Entity;
        getLeashHolder(): $Entity;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get plainTextName(): string;
        getPlainTextName(): string;
        get quadLeashOffsets(): $Vec3[];
        getQuadLeashOffsets(): $Vec3[];
        get variant(): $Holder<$ChickenVariant>;
        getVariant(): $Holder<$ChickenVariant>;
        set variant(value: $Holder_<$ChickenVariant>);
        get chickenJockey(): boolean;
        "isChickenJockey()"(): boolean;
        set chickenJockey(value: boolean);
        get leashed(): boolean;
        isLeashed(): boolean;
        get chestItem(): unknown;
        getChestItem(): unknown;
        get feetItem(): unknown;
        getFeetItem(): unknown;
        get headItem(): unknown;
        getHeadItem(): unknown;
        get registryId(): string;
        getRegistryId(): string;
        get legsItem(): unknown;
        getLegsItem(): unknown;
        getLevel(): unknown;
        get offHandItem(): unknown;
        getOffHandItem(): unknown;
        static createAttributes(): $AttributeSupplier$Builder;
        addEffect(newEffect: $MobEffectInstance, source: $Entity): boolean;
        addEffect(newEffect: $MobEffectInstance): boolean;
        aiStep(): void;
        canHaveALeashAttachedTo(entity: $Entity): boolean;
        checkElasticInteractions(leashHolder: $Entity, leashData: $Leashable$LeashData): boolean;
        checkPermission<T>(arg0: $PermissionNode<T>, arg1: T): T;
        checkPermission<T>(arg0: $PermissionNode<T>): T;
        checkPermission(arg0: $Identifier_, arg1: boolean): boolean;
        checkPermission(arg0: $Identifier_, arg1: $PermissionLevel_): boolean;
        checkPermission(arg0: $Identifier_): $TriState;
        dropLeash(): void;
        equip(lootTable: $ResourceKey<$LootTable>, dropChances: ($Map<$EquipmentSlot, number> | (([$EquipmentSlot_] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$EquipmentSlot_, PropertyKey>, number>>))): void;
        equip(lootTable: $ResourceKey<$LootTable>, lootParams: $LootParams, dropChances: ($Map<$EquipmentSlot, number> | (([$EquipmentSlot_] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$EquipmentSlot_, PropertyKey>, number>>))): void;
        equip(lootTable: $ResourceKey<$LootTable>, lootParams: $LootParams, optionalLootTableSeed: number, dropChances: ($Map<$EquipmentSlot, number> | (([$EquipmentSlot_] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$EquipmentSlot_, PropertyKey>, number>>))): void;
        equip(equipment: $EquipmentTable, lootParams: $LootParams): void;
        equip(equipment: $EquipmentTable): void;
        fabric_markChanged(arg0: $AttachmentType<any>): void;
        fabric_shouldDeferSync(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getAttachedOrCreate<A>(arg0: $AttachmentType<A>, arg1: $Supplier_<A, A>): A;
        getAttachedOrCreate<A>(arg0: $AttachmentType<A>): A;
        getAttachedOrElse<A>(arg0: $AttachmentType<A>, arg1: A): A;
        getAttachedOrGet<A>(arg0: $AttachmentType<A>, arg1: $Supplier_<A, A>): A;
        getAttachedOrSet<A>(arg0: $AttachmentType<A>, arg1: A): A;
        getAttachedOrThrow<A>(arg0: $AttachmentType<A>): A;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Chicken;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getLeashOffset(partialTicks: number): $Vec3;
        getOrDefault<T>(type: $DataComponentType<T>, defaultValue: T): T;
        getSlotsFromRange(slots: $IntList): $SlotCollection;
        getTyped<T>(type: $DataComponentType<T>): $TypedDataComponent<T>;
        get<T>(type: $DataComponentType<T>): T;
        isFood(itemStack: $ItemStack_): boolean;
        is(type: $Holder_<$EntityType<any>>): boolean;
        is(set: $HolderSet<$EntityType<any>>): boolean;
        is(type: $ResourceKey<$EntityType<any>>): boolean;
        is(tag: $TagKey_<$EntityType<any>>): boolean;
        is(rawType: $EntityType_<any>): boolean;
        is(other: $Entity): boolean;
        kill(level: $ServerLevel): void;
        leashDistanceTo(entity: $Entity): number;
        leashElasticDistance(): number;
        leashSnapDistance(): number;
        level(): $Level;
        mayBeLeashed(): boolean;
        modifyAttached<A>(arg0: $AttachmentType<A>, arg1: $UnaryOperator_<A, A, A>): A;
        addEffect(effectId: string, duration: number, amplifier: number): boolean;
        damage(amount: number): void;
        hasTag(tag: string): boolean;
        kill(): boolean;
        pdata(): $PersistentDataJS;
        removeEffect(effectId: string): boolean;
        remove(): void;
        teleport(x: number, y: number, z: number): void;
        onElasticLeashPull(): void;
        readLeashData(input: $ValueInput): void;
        removeAttached<A>(arg0: $AttachmentType<A>): A;
        removeEffect(effect: $Holder_<$MobEffect>): boolean;
        removeLeash(): void;
        removeWhenFarAway(distSqr: number): boolean;
        remove(reason: $Entity$RemovalReason_): void;
        resolveSlot(toEquip: $ItemStack_, alreadyInsertedIntoSlots: ($List<$EquipmentSlot> | ($EquipmentSlot_)[])): $EquipmentSlot;
        setChickenJockey(isChickenJockey: boolean): void;
        setDelayedLeashHolderId(entityId: number): void;
        setLeashedTo(holder: $Entity, synch: boolean): void;
        setVariant(variant: $Holder_<$ChickenVariant>): void;
        supportQuadLeash(): boolean;
        tags(): $Stream<$TagKey<$EntityType<any>>>;
        teleport(transition: $TeleportTransition): $Entity;
        writeLeashData(output: $ValueOutput, leashData: $Leashable$LeashData): void;
    }

    export class $ChickenSoundVariant extends $Record {
        constructor(adultSounds: $ChickenSoundVariant$ChickenSoundSet, babySounds: $ChickenSoundVariant$ChickenSoundSet);
        static CODEC: $Codec<$Holder<$ChickenSoundVariant>>;
        static DIRECT_CODEC: $Codec<$ChickenSoundVariant>;
        static NETWORK_CODEC: $Codec<$ChickenSoundVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$ChickenSoundVariant>>;
        adultSounds(): $ChickenSoundVariant$ChickenSoundSet;
        babySounds(): $ChickenSoundVariant$ChickenSoundSet;
        equals(o: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $ChickenSoundVariant$ChickenSoundSet extends $Record {
        constructor(ambientSound: $Holder_<$SoundEvent>, hurtSound: $Holder_<$SoundEvent>, deathSound: $Holder_<$SoundEvent>, stepSound: $Holder_<$SoundEvent>);
        ambientSound(): $Holder<$SoundEvent>;
        deathSound(): $Holder<$SoundEvent>;
        equals(o: unknown): boolean;
        hashCode(): number;
        hurtSound(): $Holder<$SoundEvent>;
        stepSound(): $Holder<$SoundEvent>;
        toString(): string;
    }

    export class $ChickenSoundVariants$SoundSet {
        static CLASSIC: $ChickenSoundVariants$SoundSet;
        static PICKY: $ChickenSoundVariants$SoundSet;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChickenSoundVariants$SoundSet[];
        static valueOf(name: string): $ChickenSoundVariants$SoundSet;
    }
    export interface $ChickenSoundVariants$SoundSet extends $Enum<$ChickenSoundVariants$SoundSet> {}

    export class $ChickenVariant extends $Record implements $PriorityProvider<$SpawnContext, $SpawnCondition> {
        constructor(modelAndTexture: $ModelAndTexture<$ChickenVariant$ModelType>, babyTexture: $ClientAsset$ResourceTexture, spawnConditions: $SpawnPrioritySelectors);
        static CODEC: $Codec<$Holder<$ChickenVariant>>;
        static DIRECT_CODEC: $Codec<$ChickenVariant>;
        static NETWORK_CODEC: $Codec<$ChickenVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$ChickenVariant>>;
        babyTexture(): $ClientAsset$ResourceTexture;
        equals(o: unknown): boolean;
        hashCode(): number;
        modelAndTexture(): $ModelAndTexture<$ChickenVariant$ModelType>;
        selectors(): $List<$PriorityProvider$Selector<$SpawnContext, $SpawnCondition>>;
        spawnConditions(): $SpawnPrioritySelectors;
        toString(): string;
    }

    export class $ChickenVariant$ModelType {
        static COLD: $ChickenVariant$ModelType;
        static NORMAL: $ChickenVariant$ModelType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChickenVariant$ModelType[];
        static valueOf(name: string): $ChickenVariant$ModelType;
    }
    export interface $ChickenVariant$ModelType extends $Enum<$ChickenVariant$ModelType> {}

    export type $ChickenSoundVariants$SoundSet_ = $ChickenSoundVariants$SoundSet | "CLASSIC" | "PICKY";
    export type $ChickenVariant$ModelType_ = $ChickenVariant$ModelType | "COLD" | "NORMAL";
}
