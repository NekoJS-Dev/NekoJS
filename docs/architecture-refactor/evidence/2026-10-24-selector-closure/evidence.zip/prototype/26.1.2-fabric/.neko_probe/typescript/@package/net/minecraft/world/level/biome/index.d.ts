import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Iterable, $Record } from "java:java/lang";
import { $List, $Map, $Optional, $Set } from "java:java/util";
import { $Predicate, $Predicate_, $Supplier, $Supplier_, $ToIntFunction, $ToIntFunction_ } from "java:java/util/function";
import { $MultiNoiseSamplerHooks } from "java:net/fabricmc/fabric/impl/biome";
import { $BlockPos, $BlockPos_, $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $WeightedList } from "java:net/minecraft/util/random";
import { $EnvironmentAttributeMap } from "java:net/minecraft/world/attribute";
import { $EntityType, $EntityType_, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $LevelReader } from "java:net/minecraft/world/level";
import { $DensityFunction } from "java:net/minecraft/world/level/levelgen";
import { $ConfiguredWorldCarver } from "java:net/minecraft/world/level/levelgen/carver";
import { $ConfiguredFeature } from "java:net/minecraft/world/level/levelgen/feature";
import { $PlacedFeature } from "java:net/minecraft/world/level/levelgen/placement";
import { $ImprovedNoise, $PerlinSimplexNoise } from "java:net/minecraft/world/level/levelgen/synth";

declare module "java:net/minecraft/world/level/biome" {
    export class $Biome {
        static BIOME_INFO_NOISE: $PerlinSimplexNoise;
        static CODEC: $Codec<$Holder<$Biome>>;
        static DIRECT_CODEC: $Codec<$Biome>;
        static LIST_CODEC: $Codec<$HolderSet<$Biome>>;
        static NETWORK_CODEC: $Codec<$Biome>;
        get attributes(): $EnvironmentAttributeMap;
        set attributes(value: $EnvironmentAttributeMap);
        climateSettings: $Biome$ClimateSettings;
        get generationSettings(): $BiomeGenerationSettings;
        get mobSettings(): $MobSpawnSettings;
        getAttributes(): $EnvironmentAttributeMap;
        get baseTemperature(): number;
        getBaseTemperature(): number;
        get dryFoliageColor(): number;
        getDryFoliageColor(): number;
        get foliageColor(): number;
        getFoliageColor(): number;
        getGenerationSettings(): $BiomeGenerationSettings;
        getMobSettings(): $MobSpawnSettings;
        get specialEffects(): $BiomeSpecialEffects;
        getSpecialEffects(): $BiomeSpecialEffects;
        get waterColor(): number;
        getWaterColor(): number;
        coldEnoughToSnow(pos: $BlockPos_, seaLevel: number): boolean;
        getGrassColor(x: number, z: number): number;
        getPrecipitationAt(pos: $BlockPos_, seaLevel: number): $Biome$Precipitation;
        hasPrecipitation(): boolean;
        shouldFreeze(level: $LevelReader, pos: $BlockPos_, checkNeighbors: boolean): boolean;
        shouldFreeze(level: $LevelReader, pos: $BlockPos_): boolean;
        shouldMeltFrozenOceanIcebergSlightly(pos: $BlockPos_, seaLevel: number): boolean;
        shouldSnow(level: $LevelReader, pos: $BlockPos_): boolean;
        warmEnoughToRain(pos: $BlockPos_, seaLevel: number): boolean;
    }

    export class $Biome$ClimateSettings extends $Record {
        constructor(hasPrecipitation: boolean, temperature: number, temperatureModifier: $Biome$TemperatureModifier_, downfall: number);
        static CODEC: $MapCodec<$Biome$ClimateSettings>;
        downfall(): number;
        equals(o: unknown): boolean;
        hasPrecipitation(): boolean;
        hashCode(): number;
        temperatureModifier(): $Biome$TemperatureModifier;
        temperature(): number;
        toString(): string;
    }

    export class $Biome$Precipitation {
        static NONE: $Biome$Precipitation;
        static RAIN: $Biome$Precipitation;
        static SNOW: $Biome$Precipitation;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Biome$Precipitation[];
        static valueOf(name: string): $Biome$Precipitation;
    }
    export interface $Biome$Precipitation extends $Enum<$Biome$Precipitation> {}

    export class $Biome$TemperatureModifier {
        static FROZEN: $Biome$TemperatureModifier;
        static NONE: $Biome$TemperatureModifier;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Biome$TemperatureModifier[];
        static valueOf(name: string): $Biome$TemperatureModifier;
    }
    export interface $Biome$TemperatureModifier extends $Enum<$Biome$TemperatureModifier> {}

    export class $BiomeGenerationSettings {
        static CODEC: $MapCodec<$BiomeGenerationSettings>;
        static EMPTY: $BiomeGenerationSettings;
        get boneMealFeatures(): $List<$ConfiguredFeature<any, any>>;
        set boneMealFeatures(value: $Supplier_<$List<$ConfiguredFeature<any, any>>, ($List<$ConfiguredFeature<any, any>> | ($ConfiguredFeature<any, any>)[])>);
        get carvers(): $Iterable<$Holder<$ConfiguredWorldCarver<any>>>;
        set carvers(value: $HolderSet<$ConfiguredWorldCarver<any>>);
        featureSet: $Supplier<$Set<$PlacedFeature>>;
        features: $List<$HolderSet<$PlacedFeature>>;
        getBoneMealFeatures(): $List<$ConfiguredFeature<any, any>>;
        getCarvers(): $Iterable<$Holder<$ConfiguredWorldCarver<any>>>;
        "features()"(): $List<$HolderSet<$PlacedFeature>>;
        hasFeature(feature: $PlacedFeature): boolean;
    }

    export class $BiomeManager {
        constructor(noiseBiomeSource: $BiomeManager$NoiseBiomeSource_<number, number, number, $Holder_<$Biome>>, seed: number);
        static CHUNK_CENTER_QUART: number;
        static obfuscateSeed(seed: number): number;
        getBiome(pos: $BlockPos_): $Holder<$Biome>;
        getNoiseBiomeAtPosition(x: number, y: number, z: number): $Holder<$Biome>;
        getNoiseBiomeAtPosition(blockPos: $BlockPos_): $Holder<$Biome>;
        getNoiseBiomeAtQuart(quartX: number, quartY: number, quartZ: number): $Holder<$Biome>;
        withDifferentSource(biomeSource: $BiomeManager$NoiseBiomeSource_<number, number, number, $Holder_<$Biome>>): $BiomeManager;
    }

    export interface $BiomeManager$NoiseBiomeSource {
        getNoiseBiome(quartX: number, quartY: number, quartZ: number): $Holder<$Biome>;
    }

    export interface $BiomeResolver {
        getNoiseBiome(quartX: number, quartY: number, quartZ: number, sampler: $Climate$Sampler): $Holder<$Biome>;
    }

    export class $BiomeSource implements $BiomeResolver {
        static CODEC: $Codec<$BiomeSource>;
        addDebugInfo(result: ($List<string> | (string)[]), feetPos: $BlockPos_, sampler: $Climate$Sampler): void;
        findBiomeHorizontal(originX: number, originY: number, originZ: number, searchRadius: number, skipSteps: number, allowed: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>, random: $RandomSource, findClosest: boolean, sampler: $Climate$Sampler): $Pair<$BlockPos, $Holder<$Biome>>;
        findBiomeHorizontal(x: number, y: number, z: number, searchRadius: number, allowed: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>, random: $RandomSource, sampler: $Climate$Sampler): $Pair<$BlockPos, $Holder<$Biome>>;
        findClosestBiome3d(origin: $BlockPos_, searchRadius: number, sampleResolutionHorizontal: number, sampleResolutionVertical: number, allowed: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>, sampler: $Climate$Sampler, level: $LevelReader): $Pair<$BlockPos, $Holder<$Biome>>;
        getBiomesWithin(x: number, y: number, z: number, r: number, sampler: $Climate$Sampler): $Set<$Holder<$Biome>>;
        getNoiseBiome(quartX: number, quartY: number, quartZ: number, sampler: $Climate$Sampler): $Holder<$Biome>;
        possibleBiomes(): $Set<$Holder<$Biome>>;
    }

    export class $BiomeSpecialEffects extends $Record {
        constructor(waterColor: number, foliageColorOverride: $Optional<number>, dryFoliageColorOverride: $Optional<number>, grassColorOverride: $Optional<number>, grassColorModifier: $BiomeSpecialEffects$GrassColorModifier_);
        static CODEC: $Codec<$BiomeSpecialEffects>;
        dryFoliageColorOverride: $Optional<number>;
        foliageColorOverride: $Optional<number>;
        grassColorModifier: $BiomeSpecialEffects$GrassColorModifier;
        grassColorOverride: $Optional<number>;
        waterColor: number;
        "dryFoliageColorOverride()"(): $Optional<number>;
        equals(o: unknown): boolean;
        "foliageColorOverride()"(): $Optional<number>;
        "grassColorModifier()"(): $BiomeSpecialEffects$GrassColorModifier;
        "grassColorOverride()"(): $Optional<number>;
        hashCode(): number;
        toString(): string;
        "waterColor()"(): number;
    }

    export class $BiomeSpecialEffects$GrassColorModifier {
        static DARK_FOREST: $BiomeSpecialEffects$GrassColorModifier;
        static NONE: $BiomeSpecialEffects$GrassColorModifier;
        static SWAMP: $BiomeSpecialEffects$GrassColorModifier;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BiomeSpecialEffects$GrassColorModifier[];
        static valueOf(name: string): $BiomeSpecialEffects$GrassColorModifier;
    }
    export interface $BiomeSpecialEffects$GrassColorModifier extends $Enum<$BiomeSpecialEffects$GrassColorModifier> {}

    export class $Climate$Parameter extends $Record {
        constructor(min: number, max: number);
        static CODEC: $Codec<$Climate$Parameter>;
        static point(min: number): $Climate$Parameter;
        static span(min: number, max: number): $Climate$Parameter;
        static span(min: $Climate$Parameter, max: $Climate$Parameter): $Climate$Parameter;
        distance(target: number): number;
        distance(target: $Climate$Parameter): number;
        equals(o: unknown): boolean;
        hashCode(): number;
        max(): number;
        min(): number;
        span(other: $Climate$Parameter): $Climate$Parameter;
        toString(): string;
    }

    export class $Climate$ParameterPoint extends $Record {
        constructor(temperature: $Climate$Parameter, humidity: $Climate$Parameter, continentalness: $Climate$Parameter, erosion: $Climate$Parameter, depth: $Climate$Parameter, weirdness: $Climate$Parameter, offset: number);
        static CODEC: $Codec<$Climate$ParameterPoint>;
        continentalness(): $Climate$Parameter;
        depth(): $Climate$Parameter;
        equals(o: unknown): boolean;
        erosion(): $Climate$Parameter;
        hashCode(): number;
        humidity(): $Climate$Parameter;
        offset(): number;
        temperature(): $Climate$Parameter;
        toString(): string;
        weirdness(): $Climate$Parameter;
    }

    export class $Climate$Sampler extends $Record implements $MultiNoiseSamplerHooks {
        constructor(temperature: $DensityFunction, humidity: $DensityFunction, continentalness: $DensityFunction, erosion: $DensityFunction, depth: $DensityFunction, weirdness: $DensityFunction, spawnTarget: ($List<$Climate$ParameterPoint> | ($Climate$ParameterPoint)[]));
        continentalness(): $DensityFunction;
        depth(): $DensityFunction;
        equals(o: unknown): boolean;
        erosion(): $DensityFunction;
        fabric_getEndBiomesSampler(): $ImprovedNoise;
        fabric_getSeed(): number;
        fabric_setSeed(arg0: number): void;
        findSpawnPosition(): $BlockPos;
        hashCode(): number;
        humidity(): $DensityFunction;
        sample(quartX: number, quartY: number, quartZ: number): $Climate$TargetPoint;
        spawnTarget(): $List<$Climate$ParameterPoint>;
        temperature(): $DensityFunction;
        toString(): string;
        weirdness(): $DensityFunction;
    }

    export class $Climate$TargetPoint extends $Record {
        constructor(temperature: number, humidity: number, continentalness: number, erosion: number, depth: number, weirdness: number);
        continentalness(): number;
        depth(): number;
        equals(o: unknown): boolean;
        erosion(): number;
        hashCode(): number;
        humidity(): number;
        temperature(): number;
        toString(): string;
        weirdness(): number;
    }

    export class $FeatureSorter$StepFeatureData extends $Record {
        constructor(features: ($List<$PlacedFeature> | ($PlacedFeature)[]), indexMapping: $ToIntFunction_<$PlacedFeature, $PlacedFeature, number>);
        equals(o: unknown): boolean;
        features(): $List<$PlacedFeature>;
        hashCode(): number;
        indexMapping(): $ToIntFunction<$PlacedFeature>;
        toString(): string;
    }

    export class $MobSpawnSettings {
        static CODEC: $MapCodec<$MobSpawnSettings>;
        static EMPTY: $MobSpawnSettings;
        static EMPTY_MOB_LIST: $WeightedList<$MobSpawnSettings$SpawnerData>;
        creatureGenerationProbability: number;
        mobSpawnCosts: $Map<$EntityType<any>, $MobSpawnSettings$MobSpawnCost>;
        spawners: $Map<$MobCategory, $WeightedList<$MobSpawnSettings$SpawnerData>>;
        get creatureProbability(): number;
        getCreatureProbability(): number;
        getMobSpawnCost(type: $EntityType_<any>): $MobSpawnSettings$MobSpawnCost;
        getMobs(category: $MobCategory_): $WeightedList<$MobSpawnSettings$SpawnerData>;
    }

    export class $MobSpawnSettings$MobSpawnCost extends $Record {
        constructor(energyBudget: number, charge: number);
        static CODEC: $Codec<$MobSpawnSettings$MobSpawnCost>;
        charge(): number;
        energyBudget(): number;
        equals(o: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $MobSpawnSettings$SpawnerData extends $Record {
        constructor(type: $EntityType_<any>, minCount: number, maxCount: number);
        static CODEC: $MapCodec<$MobSpawnSettings$SpawnerData>;
        equals(o: unknown): boolean;
        hashCode(): number;
        maxCount(): number;
        minCount(): number;
        toString(): string;
        type(): $EntityType<any>;
    }

    export type $Biome$Precipitation_ = $Biome$Precipitation | "NONE" | "RAIN" | "SNOW";
    export type $Biome$TemperatureModifier_ = $Biome$TemperatureModifier | "FROZEN" | "NONE";
    export type $BiomeManager$NoiseBiomeSource_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackResult = $Holder_<$Biome>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($BiomeManager$NoiseBiomeSource & { readonly [Symbol.hasInstance]?: never });
    export type $BiomeResolver_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackArg3 = $Climate$Sampler, CallbackResult = $Holder_<$Biome>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => CallbackResult) | ($BiomeResolver & { readonly [Symbol.hasInstance]?: never });
    export type $BiomeSpecialEffects$GrassColorModifier_ = $BiomeSpecialEffects$GrassColorModifier | "DARK_FOREST" | "NONE" | "SWAMP";
}
