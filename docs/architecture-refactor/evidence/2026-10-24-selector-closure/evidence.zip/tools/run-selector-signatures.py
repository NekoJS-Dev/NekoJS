"""Collect Java selector identities in five fresh installed server processes, serially."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import socket
import subprocess
import time
import zipfile

ROOT = Path.cwd().resolve()
TOOLS = ROOT / 'build/priority-closeout'
OUT = TOOLS / 'selector-signatures-installed-v4'
assert not OUT.exists()
OUT.mkdir()
installed = ROOT / 'build/closeout-owner-stamp-installed'
prep = json.loads((installed / 'preparation-manifest.json').read_text(encoding='utf-8'))
assert prep['sourceRevision'] == '6e43b82789a7dbf7b9659dc1c21fefecac662649'
classes = OUT / 'helper-classes'
classes.mkdir()
compile_source = installed / '26.1.2'
artifact = next((compile_source / 'mods').glob('nekojs-*.jar'))
gson_jars = list((compile_source / 'libraries/com/google/code/gson/gson').glob('*/*.jar'))
assert len(gson_jars) == 1
# The installer fat JAR contains a reduced Gson copy; compile against the game's actual library first.
cp = ';'.join([str(gson_jars[0]), str(artifact)] + [str(p) for p in (compile_source / 'libraries').rglob('*.jar')])
flags = subprocess.CREATE_NO_WINDOW
with (OUT / 'compile.log').open('wb') as log:
    code = subprocess.run([shutil.which('javac'), '--release', '21', '-proc:none', '-cp', cp, '-d', str(classes),
        str(TOOLS / 'SelectorSignatureCollector.java'), str(TOOLS / 'SelectorSignatureMod.java')], stdout=log, stderr=subprocess.STDOUT, creationflags=flags).returncode
assert code == 0, 'Owned helper compilation failed; inspect compile.log'
spec = importlib.util.spec_from_file_location('selector_rcon', ROOT / 'bench/perf/rcon.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
records = []
for index, node in enumerate(['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']):
    source = installed / node
    directory = OUT / node
    directory.mkdir()
    node_prep = next(row for row in prep['nodes'] if row['node'] == node)
    candidate = source / 'mods' / node_prep['artifact']
    assert hashlib.sha256(candidate.read_bytes()).hexdigest() == node_prep['sha256']
    with zipfile.ZipFile(candidate) as jar:
        expected_index = hashlib.sha256(jar.read('com/tkisor/nekojs/api/JavaMemberIndex.class')).hexdigest()
    port = 33521 + index * 10
    for number in [port, port + 1]:
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', number))
    shutil.copyfile(source / 'eula.txt', directory / 'eula.txt')
    properties = (source / 'server.properties').read_text(encoding='utf-8')
    properties = '\n'.join(f'server-port={port}' if line.startswith('server-port=') else
        f'rcon.port={port + 1}' if line.startswith('rcon.port=') else
        'level-name=owned-selector-signatures' if line.startswith('level-name=') else
        'server-ip=127.0.0.1' if line.startswith('server-ip=') else line for line in properties.splitlines()) + '\n'
    (directory / 'server.properties').write_text(properties, encoding='utf-8')
    password = dict(line.split('=', 1) for line in properties.splitlines() if '=' in line)['rcon.password']
    shutil.copytree(source / 'nekojs/config', directory / 'nekojs/config')
    (directory / 'nekojs/server_scripts').mkdir()
    closure = json.loads((TOOLS / 'selector-heritage-closure-v1' / (node + '.json')).read_text(encoding='utf-8'))
    targets = []
    for row in closure['selected']:
        if not row['methodDeclarations']:
            continue
        module, owner = row['owner'].split('#')
        class_name = module.removeprefix('java:').replace('/', '.') + '.' + owner.removeprefix('$')
        targets.append(dict(className=class_name, member=row['member']))
    (directory / 'request.json').write_text(json.dumps(targets, indent=2) + '\n', encoding='utf-8')
    script = "const Collector = Java.type('nekojs.acceptance.selector.SelectorSignatureCollector');\n" + \
        'const requests = ' + json.dumps(targets) + ';\n' + '''for (let offset = 0; offset < requests.length; offset += 20) {
    const payload = String(Collector.inspect(JSON.stringify(requests.slice(offset, offset + 20))));
    if (payload.length > 60000) throw new Error('Owned selector batch exceeds the diagnostic logger limit');
    console.info('OWNED-SELECTOR-SIGNATURES ' + offset + ' ' + payload);
}
'''
    (directory / 'nekojs/server_scripts/signatures.js').write_text(script, encoding='utf-8')
    shutil.copytree(source / 'mods', directory / 'mods')
    with zipfile.ZipFile(directory / 'mods/owned-selector-signatures.jar', 'w', zipfile.ZIP_DEFLATED) as jar:
        if node.endswith('-fabric'):
            jar.writestr('fabric.mod.json', json.dumps(dict(schemaVersion=1, id='owned_selector_signatures', version='1.0', name='Owned Selector Signatures', environment='*')))
        else:
            jar.writestr('META-INF/neoforge.mods.toml', 'modLoader="javafml"\nloaderVersion="[1,)"\nlicense="MIT"\n[[mods]]\nmodId="owned_selector_signatures"\nversion="1.0"\ndisplayName="Owned Selector Signatures"\n')
        for file in classes.rglob('*.class'):
            if node.endswith('-fabric') and file.name == 'SelectorSignatureMod.class':
                continue
            jar.write(file, file.relative_to(classes).as_posix())
    (directory / 'libraries').symlink_to((source / 'libraries').resolve(), target_is_directory=True)
    java = 'C:/Program Files/Java/jdk-25.0.2/bin/java.exe'
    if node.endswith('-fabric'):
        (directory / 'versions').symlink_to((source / 'versions').resolve(), target_is_directory=True)
        shutil.copyfile(source / 'fabric-server-launch.jar', directory / 'fabric-server-launch.jar')
        shutil.copytree(source / '.fabric/server', directory / '.fabric/server')
        args = [java, '-Xms512M', '-Xmx2G', '-jar', 'fabric-server-launch.jar', 'nogui']
    else:
        argfiles = list((source / 'libraries/net/neoforged/neoforge').glob('*/win_args.txt'))
        assert len(argfiles) == 1
        relative = argfiles[0].relative_to(source).as_posix()
        args = [java, '-Xms512M', '-Xmx2G', '@' + relative, 'nogui']
    def command(text):
        with socket.create_connection(('127.0.0.1', port + 1), timeout=15) as connection:
            connection.settimeout(30)
            rcon.send_packet(connection, 1, 3, password)
            assert rcon.recv_packet(connection)[0] != -1
            rcon.send_packet(connection, 2, 2, text)
            return rcon.recv_packet(connection)[2]
    with (directory / 'stdout.log').open('xb') as stdout, (directory / 'stderr.log').open('xb') as stderr:
        process = subprocess.Popen(args, cwd=directory, stdout=stdout, stderr=stderr, creationflags=flags)
    record = dict(node=node, pid=process.pid, sourceRevision=prep['sourceRevision'], candidateSha256=node_prep['sha256'],
                  expectedIndexClassSha256=expected_index, requestedPairs=len(targets), verdict='NOTGREEN')
    (directory / 'owned-process.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    try:
        deadline = time.monotonic() + 300
        while True:
            log = (directory / 'stdout.log').read_text(encoding='utf-8', errors='replace')
            assert process.poll() is None, 'Owned server exited before ready'
            if 'Done (' in log or 'Done(' in log:
                break
            assert time.monotonic() < deadline, 'Owned readiness timed out'
            time.sleep(1)
        marker = 'OWNED-SELECTOR-SIGNATURES '
        matches = []
        for line in log.splitlines():
            if marker not in line:
                continue
            match = re.fullmatch(r'(\d+) (.+)', line.split(marker, 1)[1].strip())
            assert match, 'Malformed signature batch'
            matches.append((int(match[1]), json.loads(match[2])))
        matches.sort(key=lambda pair: pair[0])
        assert [offset for offset, _ in matches] == list(range(0, len(targets), 20)), 'Missing or repeated signature batch'
        observed = dict(indexClassSha256=matches[0][1]['indexClassSha256'], indexSource=matches[0][1]['indexSource'],
                        rows=[row for _, batch in matches for row in batch['rows']], batches=len(matches))
        assert all(batch['indexClassSha256'] == observed['indexClassSha256'] and batch['indexSource'] == observed['indexSource'] for _, batch in matches)
        assert observed['indexClassSha256'] == expected_index
        assert '/mods/' in observed['indexSource'] and candidate.name in observed['indexSource']
        assert len(observed['rows']) == len(targets)
        assert all(row['status'] == 'MATCHED' for row in observed['rows']), 'Unavailable or unmatched methods retained in stdout'
        (directory / 'signatures.json').write_text(json.dumps(observed, indent=2) + '\n', encoding='utf-8')
        record['verdict'] = 'RECORDED'
    finally:
        stop = dict(attempted=False, responseReceived=False)
        record['stop'] = stop
        try:
            if process.poll() is None:
                stop['attempted'] = True
                stop['requestedUtc'] = datetime.now(timezone.utc).isoformat()
                stop['response'] = command('stop')
                stop['responseReceived'] = True
                stop['returnedUtc'] = datetime.now(timezone.utc).isoformat()
        finally:
            try:
                record['exitCode'] = process.wait(timeout=90)
                stopped = (directory / 'stdout.log').read_text(encoding='utf-8', errors='replace')
                stop['shutdownMarkersObserved'] = 'Stopping server' in stopped
                record['normalRconStop'] = stop['attempted'] and stop['responseReceived'] and stop['shutdownMarkersObserved'] and record['exitCode'] == 0
            finally:
                (directory / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
                records.append(record)
                (OUT / 'summary.json').write_text(json.dumps(dict(records=records), indent=2) + '\n', encoding='utf-8')
    assert record['verdict'] == 'RECORDED' and record['normalRconStop']
    print(json.dumps(dict(node=node, pairs=len(targets), verdict='RECORDED', exitCode=record['exitCode'])), flush=True)
