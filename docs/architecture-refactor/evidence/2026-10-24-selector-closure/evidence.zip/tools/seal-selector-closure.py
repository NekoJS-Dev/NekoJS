"""Seal the bounded inheritance/signature/prototype evidence before any production migration."""
import hashlib
import io
import json
from pathlib import Path
import zipfile

ROOT = Path.cwd().resolve()
TOOLS = ROOT / 'build/priority-closeout'
OUT = ROOT / 'docs/architecture-refactor/evidence/2026-10-24-selector-closure'
OUT.mkdir(exist_ok=True)
assert not (OUT / 'evidence.zip').exists()
files = {}
for filename in ['selector-heritage-closure.cjs', 'SelectorSignatureCollector.java', 'SelectorSignatureMod.java',
                 'run-selector-signatures.py', 'join-selector-signatures.cjs', 'run-selector-declaration-prototype.py',
                 'compare-selector-program-inputs.cjs', 'seal-selector-closure.py']:
    files['tools/' + filename] = (TOOLS / filename).read_bytes()
for folder, prefix in [('selector-heritage-closure-v1', 'closure'), ('selector-migration-join-v1', 'join')]:
    for path in sorted((TOOLS / folder).glob('*.json')):
        files[prefix + '/' + path.name] = path.read_bytes()
runtime = TOOLS / 'selector-signatures-installed-v4'
files['runtime/summary.json'] = (runtime / 'summary.json').read_bytes()
files['runtime/compile.log'] = (runtime / 'compile.log').read_bytes()
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    for name in ['request.json', 'owned-process.json', 'result.json', 'signatures.json', 'stdout.log', 'stderr.log',
                 'nekojs/server_scripts/signatures.js', 'mods/owned-selector-signatures.jar']:
        files[f'runtime/{node}/{name}'] = (runtime / node / name).read_bytes()
    prototype = TOOLS / 'selector-declaration-prototype-v1' / node
    for path in sorted(prototype.glob('*')):
        if path.is_file():
            files[f'prototype/{node}/{path.name}'] = path.read_bytes()
for name in ['summary.json']:
    files['prototype/' + name] = (TOOLS / 'selector-declaration-prototype-v1' / name).read_bytes()
prototype_summary = json.loads(files['prototype/summary.json'])
for row in prototype_summary['changedFiles']:
    files[f"prototype/{row['node']}/{row['file']}"] = (TOOLS / 'selector-declaration-prototype-v1' / row['node'] / row['file']).read_bytes()
for version in ['v1', 'v2']:
    files[f'preparation-failures/{version}/compile.log'] = (TOOLS / ('selector-signatures-installed-' + version) / 'compile.log').read_bytes()
for name in ['request.json', 'owned-process.json', 'result.json', 'stdout.log', 'stderr.log',
             'nekojs/server_scripts/signatures.js', 'mods/owned-selector-signatures.jar']:
    files['initial-truncated-run/' + name] = (TOOLS / 'selector-signatures-installed-v3/1.21.1' / name).read_bytes()
binding = dict(sourceRevision='6e43b82789a7dbf7b9659dc1c21fefecac662649', productionChanged=False,
    migrationApproved=False, maintainerAcceptance=False,
    sourceEvidenceSha256='1fc7538fc9adc05adaec76f1727a17d1e1bfbf4dd82d65514182749ec7d101a8',
    initialSelectorEvidenceSha256='57737df28bbcaf6643fa63c414d4656de4b54a43cf03ec25740c6727ab9a94d6')
files['binding.json'] = (json.dumps(binding, indent=2) + '\n').encode()
secrets = set()
properties_count = 0
for path in (ROOT / 'build/closeout-owner-stamp-installed').glob('*/server.properties'):
    properties_count += 1
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.startswith(('rcon.password=', 'management-server-secret=')):
            value = line.split('=', 1)[1]
            if value:
                secrets.add(value)
patterns = {(value.encode(encoding), encoding) for value in secrets for encoding in ['utf-8', 'utf-16-le', 'utf-16-be']}
original_hashes, ranges = {}, {}
for name, data in list(files.items()):
    found = []
    for pattern, encoding in patterns:
        offset = 0
        while True:
            index = data.find(pattern, offset)
            if index < 0:
                break
            found.append((index, index + len(pattern), encoding))
            offset = index + len(pattern)
    if found:
        found = sorted(set(found))
        assert all(found[i][1] <= found[i + 1][0] for i in range(len(found) - 1))
        assert not data.startswith(b'PK\x03\x04'), 'A nested helper artifact needs explicit redaction; stop before sealing'
        original_hashes[name] = hashlib.sha256(data).hexdigest()
        ranges[name] = [dict(offset=a, length=b - a, encoding=encoding) for a, b, encoding in found]
        chunks, offset = [], 0
        for start, end, encoding in found:
            chunks.extend([data[offset:start], '[REDACTED]'.encode(encoding)])
            offset = end
        chunks.append(data[offset:])
        files[name] = b''.join(chunks)
payloads = 0
def scan(data):
    global payloads
    payloads += 1
    assert not any(pattern in data for pattern, _ in patterns), 'Credential retained after redaction'
    if data.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(data)) as jar:
            for name in jar.namelist():
                if not name.endswith('/'):
                    scan(jar.read(name))
for data in files.values():
    scan(data)
files['redactions.json'] = (json.dumps(dict(originalSha256=original_hashes, ranges=ranges), indent=2) + '\n').encode()
files['privacy-audit.json'] = (json.dumps(dict(propertiesSources=properties_count, privateSecrets=len(secrets),
    patternCount=len(patterns), payloadsChecked=payloads, redactedFiles=len(ranges),
    replacements=sum(len(values) for values in ranges.values()), retainedMatches=0,
    limitation='Local private-pattern scan; public verification binds the receipt but cannot repeat without private inputs'), indent=2) + '\n').encode()
files['entries.json'] = (json.dumps({name: hashlib.sha256(data).hexdigest() for name, data in files.items()}, indent=2) + '\n').encode()
with zipfile.ZipFile(OUT / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED) as jar:
    for name, data in sorted(files.items()):
        jar.writestr(name, data)
manifest = dict(sourceRevision=binding['sourceRevision'], sha256=hashlib.sha256((OUT / 'evidence.zip').read_bytes()).hexdigest(),
    entries=len(files), bytes=(OUT / 'evidence.zip').stat().st_size, prototypeOnly=True, productionChanged=False,
    redactedFiles=len(ranges), replacements=sum(len(values) for values in ranges.values()), privacyPayloads=payloads)
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps(manifest))
