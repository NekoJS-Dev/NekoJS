package nekojs.acceptance.selector;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tkisor.nekojs.api.JavaMemberIndex;
import java.lang.reflect.Modifier;
import java.security.MessageDigest;
import java.util.*;

/** Records source-method identities from the installed loader's existing public member index. */
public final class SelectorSignatureCollector {
    public static String inspect(String requestJson) throws Exception {
        var rows = new JsonArray();
        for (var element : JsonParser.parseString(requestJson).getAsJsonArray()) {
            JsonObject request = element.getAsJsonObject();
            String name = request.get("className").getAsString();
            String member = request.get("member").getAsString();
            var row = new JsonObject();
            row.addProperty("className", name);
            row.addProperty("member", member);
            try {
                Class<?> type = Class.forName(name, false, JavaMemberIndex.class.getClassLoader());
                var methods = new ArrayList<JsonObject>();
                for (var method : JavaMemberIndex.exposedMembersOf(type).methods().getOrDefault(member, List.of())) {
                    if (Modifier.isStatic(method.getModifiers())) continue;
                    var params = Arrays.stream(method.getParameterTypes()).map(Class::getTypeName).toList();
                    var value = new JsonObject();
                    value.addProperty("declaringClass", method.getDeclaringClass().getName());
                    value.addProperty("javaName", method.getName());
                    var parameters = new JsonArray();
                    params.forEach(parameters::add);
                    value.add("parameters", parameters);
                    value.addProperty("selector", method.getName() + "(" + String.join(",", params) + ")");
                    value.addProperty("returnType", method.getReturnType().getTypeName());
                    value.addProperty("genericSignature", method.toGenericString());
                    value.addProperty("varargs", method.isVarArgs());
                    methods.add(value);
                }
                methods.sort(Comparator.comparing(value -> value.get("selector").getAsString()));
                var methodArray = new JsonArray();
                methods.forEach(methodArray::add);
                row.add("methods", methodArray);
                row.addProperty("status", methods.isEmpty() ? "NO-METHOD" : "MATCHED");
                var location = type.getProtectionDomain().getCodeSource();
                row.addProperty("codeSource", location == null ? null : location.getLocation().toString());
            } catch (Throwable failure) {
                row.addProperty("status", "UNAVAILABLE");
                row.addProperty("failure", failure.getClass().getName() + ": " + failure.getMessage());
            }
            rows.add(row);
        }
        var result = new JsonObject();
        result.add("rows", rows);
        result.addProperty("indexSource", JavaMemberIndex.class.getProtectionDomain().getCodeSource().getLocation().toString());
        try (var stream = JavaMemberIndex.class.getResourceAsStream("/com/tkisor/nekojs/api/JavaMemberIndex.class")) {
            result.addProperty("indexClassSha256", HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(stream.readAllBytes())));
        }
        return result.toString();
    }
}
