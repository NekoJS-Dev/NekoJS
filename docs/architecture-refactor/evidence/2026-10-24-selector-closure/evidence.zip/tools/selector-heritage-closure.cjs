// Analyze copies of current declarations without changing the production backend or its output.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require(path.resolve('node_modules/typescript'));

const root = process.cwd();
const out = path.join(root, 'build/priority-closeout/selector-heritage-closure-v1');
fs.mkdirSync(out);
const inventoryPath = path.join(root, 'build/priority-closeout/method-selector-evidence-v2/collision-inventory.json');
const inventoryBytes = fs.readFileSync(inventoryPath);
const inventory = JSON.parse(inventoryBytes);
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const results = [];
function filesUnder(directory) {
    return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
        const target = path.join(directory, entry.name);
        return entry.isDirectory() ? filesUnder(target) : target.endsWith('.d.ts') ? [target] : [];
    });
}
for (const node of [...new Set(inventory.entities.map(row => row.node))].sort()) {
    const base = path.join(root, 'build/closeout-owner-stamp-installed', node);
    const graph = new Map();
    const sourceHashes = {};
    const unresolved = [];
    const get = key => {
        if (!graph.has(key)) graph.set(key, { key, declarations: [], methods: new Map(), fields: new Map(), parents: new Set(), children: new Set() });
        return graph.get(key);
    };
    for (const filename of filesUnder(path.join(base, '.neko_probe/typescript/@package')).sort()) {
        const bytes = fs.readFileSync(filename);
        sourceHashes[path.relative(base, filename).replaceAll('\\', '/')] = digest(bytes);
        const source = ts.createSourceFile(filename, bytes.toString('utf8'), ts.ScriptTarget.Latest, true);
        const imports = new Map();
        for (const statement of source.statements) {
            if (!ts.isImportDeclaration(statement) || !statement.importClause?.namedBindings ||
                    !ts.isNamedImports(statement.importClause.namedBindings)) continue;
            for (const named of statement.importClause.namedBindings.elements) {
                imports.set(named.name.text, statement.moduleSpecifier.text + '#' + (named.propertyName ?? named.name).text);
            }
        }
        function visit(current, moduleName) {
            if (ts.isModuleDeclaration(current) && ts.isStringLiteral(current.name)) moduleName = current.name.text;
            if ((ts.isClassDeclaration(current) || ts.isInterfaceDeclaration(current)) && current.name && moduleName) {
                const item = get(moduleName + '#' + current.name.text);
                const location = position => {
                    const lc = source.getLineAndCharacterOfPosition(position);
                    return { file: path.relative(base, filename).replaceAll('\\', '/'), line: lc.line + 1, column: lc.character + 1 };
                };
                item.declarations.push({ kind: ts.isClassDeclaration(current) ? 'class' : 'interface', ...location(current.getStart(source)) });
                for (const clause of current.heritageClauses ?? []) {
                    for (const type of clause.types) {
                        const expression = type.expression;
                        if (ts.isIdentifier(expression)) item.parents.add(imports.get(expression.text) ?? moduleName + '#' + expression.text);
                        else unresolved.push({ owner: item.key, expression: expression.getText(source), ...location(expression.getStart(source)) });
                    }
                }
                for (const member of current.members) {
                    if (!member.name || member.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.StaticKeyword)) continue;
                    if (!ts.isIdentifier(member.name) && !ts.isStringLiteral(member.name)) continue;
                    const name = member.name.text;
                    let target;
                    if (ts.isMethodSignature(member) || ts.isMethodDeclaration(member)) target = item.methods;
                    else if (ts.isPropertySignature(member) || ts.isPropertyDeclaration(member)) target = item.fields;
                    else continue;
                    if (!target.has(name)) target.set(name, []);
                    target.get(name).push({ ...location(member.name.getStart(source)), text: member.getText(source) });
                }
            }
            ts.forEachChild(current, child => visit(child, moduleName));
        }
        visit(source, null);
    }
    for (const item of graph.values()) {
        for (const parent of item.parents) {
            if (graph.has(parent)) graph.get(parent).children.add(item.key);
            else unresolved.push({ owner: item.key, parent });
        }
    }
    const seeds = inventory.entities.filter(row => row.node === node);
    const selected = new Map();
    const missingSeeds = [];
    const inheritedMemo = new Map();
    function hasMethod(key, member, visiting = new Set()) {
        const memoKey = key + '\0' + member;
        if (inheritedMemo.has(memoKey)) return inheritedMemo.get(memoKey);
        const item = graph.get(key);
        if (!item || visiting.has(key)) return false;
        if (item.methods.has(member)) { inheritedMemo.set(memoKey, true); return true; }
        const next = new Set(visiting).add(key);
        const found = [...item.parents].some(parent => hasMethod(parent, member, next));
        inheritedMemo.set(memoKey, found);
        return found;
    }
    for (const seed of seeds) {
        const packagePath = seed.file.split('/@package/')[1].replace(/\/index\.d\.ts$/, '');
        const key = 'java:' + packagePath + '#' + seed.owner;
        const item = graph.get(key);
        if (!item || !item.methods.has(seed.member) || !item.fields.has(seed.member)) {
            missingSeeds.push({ key, member: seed.member });
            continue;
        }
        const queue = [{ key, reason: 'direct-field-method-collision', via: null }];
        const visited = new Set();
        while (queue.length) {
            const current = queue.shift();
            if (visited.has(current.key)) continue;
            visited.add(current.key);
            const value = graph.get(current.key);
            if (!value) continue;
            const selectedKey = current.key + '\0' + seed.member;
            if (!selected.has(selectedKey)) selected.set(selectedKey, {
                owner: current.key, member: seed.member, reason: current.reason, via: current.via,
                methodDeclarations: value.methods.get(seed.member) ?? [],
                fieldDeclarations: value.fields.get(seed.member) ?? [],
                parents: [...value.parents].sort(),
            });
            for (const parent of value.parents) {
                if (hasMethod(parent, seed.member)) queue.push({ key: parent, reason: 'ancestor-method-contract', via: current.key });
            }
            if (hasMethod(current.key, seed.member)) {
                for (const child of value.children) queue.push({ key: child, reason: 'inherited-or-overriding-contract', via: current.key });
            }
        }
    }
    if (missingSeeds.length) throw new Error('Current seeds not found: ' + JSON.stringify(missingSeeds));
    const selectedRows = [...selected.values()].sort((a, b) => (a.owner + '\0' + a.member).localeCompare(b.owner + '\0' + b.member));
    const declarationRows = selectedRows.filter(row => row.methodDeclarations.length);
    const seedKeys = new Set(seeds.map(row => 'java:' + row.file.split('/@package/')[1].replace(/\/index\.d\.ts$/, '') + '#' + row.owner + '\0' + row.member));
    const affectedUnknownParents = unresolved.filter(row => selectedRows.some(selected => selected.owner === row.owner));
    const result = { node, graphTypes: graph.size, sourceFiles: Object.keys(sourceHashes).length,
        collisionSeeds: seeds.length, structuralPairs: selectedRows.length, declarationPairs: declarationRows.length,
        additionalDeclarationPairs: declarationRows.filter(row => !seedKeys.has(row.owner + '\0' + row.member)).length,
        methodDeclarationCount: declarationRows.reduce((sum, row) => sum + row.methodDeclarations.length, 0),
        affectedUnknownParents, selected: selectedRows, sourceHashes,
        limitation: 'Structural candidate closure in existing generated outputs only; no Java reflection identity, source edits, runtime coverage or approved migration scope.' };
    fs.writeFileSync(path.join(out, node + '.json'), JSON.stringify(result, null, 2) + '\n');
    const { selected: ignored, sourceHashes: ignoredHashes, affectedUnknownParents: unknown, ...summary } = result;
    results.push({ ...summary, affectedUnknownParents: unknown.length });
    console.log(JSON.stringify(results.at(-1)));
}
fs.writeFileSync(path.join(out, 'summary.json'), JSON.stringify({ sourceRevision: inventory.sourceRevision,
    inventorySha256: digest(inventoryBytes), toolSha256: digest(fs.readFileSync(__filename)),
    typescriptSha256: digest(fs.readFileSync(path.join(root, 'node_modules/typescript/lib/typescript.js'))),
    nodes: results, productionEdits: false, migrationApproved: false }, null, 2) + '\n');
