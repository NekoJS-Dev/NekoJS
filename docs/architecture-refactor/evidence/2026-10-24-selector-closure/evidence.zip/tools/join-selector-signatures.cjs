// Join recorded Java identities to existing declaration signatures without editing generated output.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require(path.resolve('node_modules/typescript'));
const root = process.cwd();
const input = path.join(root, 'build/priority-closeout/selector-signatures-installed-v4');
const closure = path.join(root, 'build/priority-closeout/selector-heritage-closure-v1');
const out = path.join(root, 'build/priority-closeout/selector-migration-join-v1');
fs.mkdirSync(out);
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const records = [];
const ambiguous = [];
const sourceHashes = {};
for (const node of ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']) {
    const loadedPath = path.join(input, node, 'signatures.json');
    const graphPath = path.join(closure, node + '.json');
    const loaded = JSON.parse(fs.readFileSync(loadedPath));
    const graph = JSON.parse(fs.readFileSync(graphPath));
    sourceHashes[path.relative(root, loadedPath).replaceAll('\\', '/')] = digest(fs.readFileSync(loadedPath));
    sourceHashes[path.relative(root, graphPath).replaceAll('\\', '/')] = digest(fs.readFileSync(graphPath));
    const methods = new Map(loaded.rows.map(row => [row.className + '\0' + row.member, row]));
    for (const item of graph.selected.filter(row => row.methodDeclarations.length)) {
        const [module, owner] = item.owner.split('#');
        const className = module.slice('java:'.length).replaceAll('/', '.') + '.' + owner.slice(1);
        const row = methods.get(className + '\0' + item.member);
        if (!row || row.status !== 'MATCHED') throw new Error('Unmatched recorded owner: ' + item.owner);
        for (const declaration of item.methodDeclarations) {
            const prefix = 'interface Candidate {\n';
            const source = ts.createSourceFile('candidate.ts', prefix + declaration.text + '\n}', ts.ScriptTarget.Latest, true);
            const method = source.statements[0].members[0];
            if (!ts.isMethodSignature(method) || method.name.text !== item.member) throw new Error('Unexpected declaration shape');
            const candidates = row.methods.filter(candidate => candidate.parameters.length === method.parameters.length);
            const keys = [...new Set(candidates.map(candidate => candidate.selector))];
            if (keys.length !== 1) {
                ambiguous.push({ node, className, member: item.member, declaration, candidates });
                continue;
            }
            const start = method.name.getStart(source) - prefix.length;
            const end = method.name.end - prefix.length;
            const replacement = declaration.text.slice(0, start) + JSON.stringify(keys[0]) + declaration.text.slice(end);
            records.push({ node, owner: item.owner, className, member: item.member, reason: item.reason,
                file: declaration.file, line: declaration.line, column: declaration.column,
                oldDeclaration: declaration.text, newDeclaration: replacement,
                selector: keys[0], javaMethods: candidates });
        }
    }
}
const summary = { sourceRevision: '6e43b82789a7dbf7b9659dc1c21fefecac662649',
    declarationRecords: records.length, ambiguousDeclarations: ambiguous.length,
    crossNodePairs: new Set(records.map(row => row.owner + '\0' + row.member)).size,
    nodePairs: new Set(records.map(row => row.node + '\0' + row.owner + '\0' + row.member)).size,
    crossNodeClasses: new Set(records.map(row => row.owner)).size,
    sourceHashes, toolSha256: digest(fs.readFileSync(__filename)), productionEdits: false, migrationApproved: false };
fs.writeFileSync(path.join(out, 'records.json'), JSON.stringify(records, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'ambiguous.json'), JSON.stringify(ambiguous, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'summary.json'), JSON.stringify(summary, null, 2) + '\n');
const { sourceHashes: ignored, ...display } = summary;
console.log(JSON.stringify(display));
