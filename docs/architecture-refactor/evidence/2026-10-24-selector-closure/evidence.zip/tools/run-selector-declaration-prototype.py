"""Type-check complete scratch copies after only the proposed quoted-method spelling edits."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path.cwd().resolve()
TOOLS = ROOT / 'build/priority-closeout'
BASE = ROOT / 'build/closeout-owner-stamp-installed'
OUT = TOOLS / 'selector-declaration-prototype-v1'
assert not OUT.exists()
OUT.mkdir()
records = json.loads((TOOLS / 'selector-migration-join-v1/records.json').read_text(encoding='utf-8'))
assert len(records) == 1004
all_rows = []
changes = []
def diagnostics(text, prefix):
    result = []
    for line in text.splitlines():
        found = re.match(r'(.+)\((\d+),(\d+)\): error (TS\d+): (.+)', line)
        if not found:
            continue
        filename, row, column, code, message = found.groups()
        filename = filename.replace('\\', '/')
        marker = prefix.replace('\\', '/').rstrip('/') + '/'
        if filename.startswith(marker):
            filename = filename[len(marker):]
        elif marker in filename:
            filename = filename.split(marker, 1)[1]
        result.append((filename, int(row), int(column), code, message))
    return result
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    original = BASE / node
    candidate = OUT / node
    candidate.mkdir()
    shutil.copytree(original / '.neko_probe/typescript', candidate / '.neko_probe/typescript')
    for side in ['server', 'startup']:
        shutil.copytree(original / 'nekojs' / (side + '_scripts'), candidate / 'nekojs' / (side + '_scripts'))
    node_types = original / 'nekojs/node_modules/@types'
    if node_types.exists():
        shutil.copytree(node_types, candidate / 'nekojs/node_modules/@types')
    grouped = {}
    for record in records:
        if record['node'] == node:
            grouped.setdefault(record['file'], []).append(record)
    for filename, edits in sorted(grouped.items()):
        target = candidate / filename
        before = target.read_bytes()
        text = before.decode('utf-8')
        lines = text.splitlines(keepends=True)
        offsets = [0]
        for line in lines:
            offsets.append(offsets[-1] + len(line))
        spans = []
        for edit in edits:
            start = offsets[edit['line'] - 1] + edit['column'] - 1
            end = start + len(edit['oldDeclaration'])
            assert text[start:end] == edit['oldDeclaration'], (node, filename, edit['line'])
            assert edit['oldDeclaration'].count('\n') == edit['newDeclaration'].count('\n') == 0
            spans.append((start, end, edit['newDeclaration']))
        spans.sort()
        assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))
        for start, end, replacement in reversed(spans):
            text = text[:start] + replacement + text[end:]
        target.write_bytes(text.encode('utf-8'))
        changes.append(dict(node=node, file=filename, edits=len(edits),
            originalSha256=hashlib.sha256(before).hexdigest(), prototypeSha256=hashlib.sha256(target.read_bytes()).hexdigest()))
    for side in ['server', 'startup']:
        cfg_path = BASE / 'ide' / f'{node}-{side}-tsconfig.json'
        cfg_bytes = cfg_path.read_bytes()
        cfg = json.loads(cfg_bytes.decode('utf-8-sig'))
        assert cfg['compilerOptions']['skipLibCheck'] is False
        assert set(cfg) == {'extends', 'compilerOptions'}
        assert Path(cfg['extends']) == original / 'nekojs' / (side + '_scripts') / 'jsconfig.json'
        cfg['extends'] = str(candidate / 'nekojs' / (side + '_scripts') / 'jsconfig.json')
        actual_cfg = candidate / (side + '-tsconfig.json')
        actual_cfg.write_text(json.dumps(cfg, indent=2) + '\n', encoding='utf-8')
        (candidate / (side + '-original-tsconfig.json')).write_bytes(cfg_bytes)
        stdout_path = candidate / (side + '-tsc.txt')
        with stdout_path.open('wb') as stdout, (candidate / (side + '-tsc-stderr.txt')).open('wb') as stderr:
            code = subprocess.run(['node', 'node_modules/typescript/bin/tsc', '--pretty', 'false', '-p', str(actual_cfg)],
                                  stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW).returncode
        old = diagnostics((BASE / 'ide' / f'{node}-{side}-tsc.txt').read_text(encoding='utf-8-sig'), 'build/closeout-owner-stamp-installed')
        new = diagnostics(stdout_path.read_text(encoding='utf-8-sig'), 'build/priority-closeout/selector-declaration-prototype-v1')
        assert code in [0, 2] and old and new
        removed = list((Counter(old) - Counter(new)).elements())
        added = list((Counter(new) - Counter(old)).elements())
        row = dict(node=node, side=side, exitCode=code, baseline=len(old), prototype=len(new),
            removed=len(removed), added=len(added), baselineByCode=dict(Counter(x[3] for x in old)),
            prototypeByCode=dict(Counter(x[3] for x in new)), addedDiagnostics=added, removedDiagnostics=removed)
        (candidate / (side + '-comparison.json')).write_text(json.dumps(row, indent=2) + '\n', encoding='utf-8')
        all_rows.append(row)
        print(json.dumps({key: value for key, value in row.items() if key not in ['addedDiagnostics', 'removedDiagnostics', 'baselineByCode', 'prototypeByCode']}), flush=True)
summary = dict(sourceRevision='6e43b82789a7dbf7b9659dc1c21fefecac662649', prototypeOnly=True,
    sourceGeneratorChanged=False, declarationEdits=sum(row['edits'] for row in changes), filesChanged=len(changes),
    baseline=sum(row['baseline'] for row in all_rows), prototype=sum(row['prototype'] for row in all_rows),
    removed=sum(row['removed'] for row in all_rows), added=sum(row['added'] for row in all_rows),
    rows=[{key: value for key, value in row.items() if key not in ['addedDiagnostics', 'removedDiagnostics']} for row in all_rows],
    changedFiles=changes, migrationApproved=False)
assert summary['baseline'] == 5537 and summary['declarationEdits'] == 1004
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in summary.items() if key not in ['rows', 'changedFiles']}), flush=True)
