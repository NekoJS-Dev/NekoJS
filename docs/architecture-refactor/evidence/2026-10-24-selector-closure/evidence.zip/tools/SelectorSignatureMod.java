package nekojs.acceptance.selector;

import net.neoforged.fml.common.Mod;

/** Makes the isolated reflection collector visible to the NeoForge mod class loader. */
@Mod("owned_selector_signatures")
public final class SelectorSignatureMod {}
