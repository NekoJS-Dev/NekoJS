"""Check every derived node change against the saved pre-regeneration bytes."""
import json
import zipfile
from pathlib import Path

root = Path('src/test/resources/golden/events-declared')
tools = Path('build/priority-closeout')
added = b'import { $VillagerTradeDeclarationEventJS, $VillagerTradeReloadEventJS } from "java:com/tkisor/nekojs/core/villager";\n'
nodes = ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']
with zipfile.ZipFile(tools / 'event-dependency-node-goldens-before.zip') as original:
    changed = [name for name in original.namelist() if (root / name).read_bytes() != original.read(name)]
    expected = {node + '.' + side + '-events.d.ts' for node in nodes for side in ['server', 'startup']}
    assert set(changed) == expected
    for name in changed:
        current = (root / name).read_bytes()
        assert current.count(added) == 1 and current.replace(added, b'') == original.read(name), name
result = dict(changed=changed, addedImportOnly=True, publicSignaturesUnchanged=True,
              clientSideFilesUnchanged=True)
(tools / 'event-dependency-node-golden-review.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('NODE_GOLDEN_EXACT_IMPORT_ONLY', len(changed))
