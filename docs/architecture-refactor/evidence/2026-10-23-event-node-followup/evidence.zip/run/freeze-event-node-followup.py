"""Freeze ordinary node gates after the intentional event import regeneration."""
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
dest = repo / 'docs/architecture-refactor/evidence/2026-10-23-event-node-followup'
assert not dest.exists()
entries = {}
totals = {}
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    counts = dict(tests=0, skipped=0, failures=0, errors=0)
    for file in (repo / 'versions' / node / 'build/test-results/platformGateTest').glob('TEST-*.xml'):
        data = file.read_bytes()
        suite = ET.fromstring(data)
        for key in counts:
            counts[key] += int(suite.get(key, 0))
        entries['platform-xml/' + node + '/' + file.name] = data
    assert counts == dict(tests=3, skipped=0, failures=0, errors=0), (node, counts)
    totals[node] = counts
    for kind in ['server', 'startup']:
        name = f'src/test/resources/golden/events-declared/{node}.{kind}-events.d.ts'
        entries['goldens/' + Path(name).name] = (repo / name).read_bytes()
for name in ['event-dependency-node-first-failure.xml', 'event-dependency-modern-nf-build.log',
             'event-dependency-node-regenerate.log', 'event-dependency-node-normal-check.log',
             'event-dependency-node-golden-review.json', 'check-event-node-goldens.py',
             'freeze-event-node-followup.py']:
    entries['run/' + name] = (tools / name).read_bytes()
assert b'BUILD SUCCESSFUL in 3m 14s' in entries['run/event-dependency-node-normal-check.log']
artifacts = {}
for node in ['26.1.2', '26.2.0']:
    file = next((repo / 'versions' / node / 'build/libs').glob('*.jar'))
    artifacts[node] = dict(name=file.name, sha256=hashlib.sha256(file.read_bytes()).hexdigest())
summary = dict(productionRevision='1f877b0fa7435be6fea61a44ff2e9266ce2c3c2a',
               checkoutRevision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
               normalPlatformGates=totals, modernNeoForgeBuilds='PASS',
               goldenChange='One actual villager event import in each of ten server/startup files; client files unchanged.',
               artifacts=artifacts, installedAcceptance='NOT RUN for this candidate',
               maintainerAcceptance=False)
entries['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
dest.mkdir()
with zipfile.ZipFile(dest / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(dest / 'manifest.json').write_text(json.dumps(dict(
    archiveSha256=hashlib.sha256((dest / 'evidence.zip').read_bytes()).hexdigest(),
    entries={name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())}), indent=2) + '\n')
print(json.dumps(summary))
