import hashlib
import json
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[2]
input_root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root
output = root / 'build/ticket37-config-sync-repair'
projects = ['common', 'common-api-processor', 'versions/1.21.1', 'versions/26.1.2',
            'versions/26.2.0', 'versions/26.1.2-fabric', 'versions/26.2.0-fabric']
summary = []
with ZipFile(output / 'full-matrix-ordinary-xml.zip', 'w', ZIP_DEFLATED) as archive:
    for project in projects:
        counts = dict(xml=0, tests=0, skipped=0, failures=0, errors=0)
        for path in sorted((input_root / project / 'build/test-results/test').glob('TEST-*.xml')):
            suite = ET.parse(path).getroot()
            counts['xml'] += 1
            for key in ('tests', 'skipped', 'failures', 'errors'):
                counts[key] += int(suite.get(key, 0))
            archive.write(path, path.relative_to(input_root).as_posix())
        summary.append(dict(project=project, **counts))
totals = {key: sum(row[key] for row in summary) for key in ('xml', 'tests', 'skipped', 'failures', 'errors')}
assert totals['failures'] == totals['errors'] == 0, totals
document = dict(source='ec7fe6848afc1970661ee1f38a7c7c6d4575530c', projects=summary, total=totals,
                note='Ordinary report snapshot; tasks may include up-to-date outputs. PlatformGate reports are separate.')
(output / 'test-summary.json').write_bytes((json.dumps(document, indent=2) + '\n').encode('utf-8'))
print(json.dumps(totals))
