import json
from pathlib import Path

root = Path(__file__).resolve().parents[1] / 'ticket37-config-sync-installed-attempt1'
server = (root / 'server/logs/latest.log').read_text(encoding='utf-8')
records = []
abort_item_present = None
for line in server.splitlines():
    if 'ABORT-ITEM-READBACK present=' in line:
        abort_item_present = line.rsplit('=', 1)[1] == 'true'
    if 'CONFIG-SYNC-PROOF ' in line:
        row = json.loads(line.split('CONFIG-SYNC-PROOF ', 1)[1])
        row['abortItemPresent'] = abort_item_present
        records.append(row)
live = [row for row in records if row['activatedGeneration'] == 5 and row['status'] == 'COMMITTED']
assert live, 'No committed live-add snapshot'
live = live[-1]
assert sum(row['generation'] == 5 and row['outcome'] == 'ack' for row in live['outcomes']) == 2
assert sum(row['generation'] == 5 and row['outcome'] == 'activation-report' for row in live['outcomes']) == 2
aborted = [row for row in records if row['status'] == 'ABORTED' and row['activatedGeneration'] == 5]
assert aborted, 'No real rejection abort snapshot'
aborted = aborted[-1]
assert any(row['generation'] == 6 and row['outcome'] == 'ack-rejected' for row in aborted['outcomes'])
assert not any(row['generation'] == 6 and row['phase'] == 'COMMIT' for row in aborted['phases'])
assert aborted['abortItemPresent'] is False
client = (root / 'clientC/logs/latest.log').read_text(encoding='utf-8')
readback = [json.loads(line.split('LATE-CLIENT-READBACK ', 1)[1]) for line in client.splitlines()
            if 'LATE-CLIENT-READBACK ' in line]
assert readback and len(readback[-1]) == 6
assert 'REJECTOR-GATE-RELOADED' in client
summary = dict(source='ec7fe6848afc1970661ee1f38a7c7c6d4575530c',
               liveAdd=dict(generation=5, ack=2, successfulActivationReports=2),
               lateClient=dict(readback=readback[-1], preseeded=False),
               rejection=dict(generation=6, status=aborted['status'], activatedGeneration=5,
                              committed=False, newServerItemPresent=False,
                              outcomes=[row for row in aborted['outcomes'] if row['generation'] == 6]))
recovered = [row for row in records if row['status'] == 'COMMITTED' and row['activatedGeneration'] == 7]
assert recovered, 'No recovery commit snapshot'
recovered = recovered[-1]
assert sum(row['generation'] == 7 and row['outcome'] == 'activation-report' for row in recovered['outcomes']) == 2
assert recovered['abortItemPresent'] is True
summary['recovery'] = dict(generation=7, ack=2, successfulActivationReports=2,
                           serverItemPresent=True, rejectingParticipantRemoved=True)
(root / 'runtime-verdict.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode('utf-8'))
print(json.dumps({key: value for key, value in summary.items() if key != 'source'}))
