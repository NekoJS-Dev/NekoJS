import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[2]
repair = root / 'build/ticket37-config-sync-repair'
runtime = root / 'build/ticket37-config-sync-installed-attempt1'
destination = root / 'docs/architecture-refactor/evidence/ticket37-configuration-sync'
destination.mkdir(parents=True, exist_ok=True)
expected = 'ec3263cc5a4ab568d4ccd5e2d6f71544f3c766cac8af439378270f5b4931b7f7'
sha = lambda data: hashlib.sha256(data).hexdigest()
artifacts = []
for side in ('server', 'clientA', 'clientB', 'clientC'):
    jar = runtime / side / 'mods/nekojs-neoforge-26.2.0-1.1.0-preview3.jar'
    assert sha(jar.read_bytes()) == expected, side
    artifacts.append(dict(side=side, sha256=expected, bytes=jar.stat().st_size))
static_hashes = {sha((runtime / side / 'nekojs/startup_scripts/proof-startup.js').read_bytes())
                 for side in ('server', 'clientA', 'clientB', 'clientC')}
assert len(static_hashes) == 1
properties = dict(line.split('=', 1) for line in (runtime / 'server/server.properties')
                  .read_text(encoding='utf-8-sig').splitlines() if '=' in line)
secret = properties['rcon.password'].encode()
files = []
for pattern in ('*.txt', '*.json', '*.py', '*.ps1', '*.patch', '*.xml'):
    files += [(path, 'repair/' + path.name) for path in repair.glob(pattern)]
files += [(repair / 'full-matrix-ordinary-xml.zip', 'repair/full-matrix-ordinary-xml.zip')]
for pattern in ('*.txt', '*.json', '*.log', '*.js', '*.toml'):
    files += [(path, 'runtime/' + path.name) for path in runtime.glob(pattern)]
for side in ('server', 'clientA', 'clientB', 'clientC'):
    for path in (runtime / side / 'logs').glob('*'):
        if path.is_file():
            files.append((path, 'runtime/' + path.relative_to(runtime).as_posix()))
    for category in ('server_scripts', 'client_scripts', 'startup_scripts', 'test_scripts'):
        for path in (runtime / side / 'nekojs' / category).glob('*'):
            if path.suffix in ('.js', '.mjs'):
                files.append((path, 'runtime/' + path.relative_to(runtime).as_posix()))
seen = set()
entries = []
zip_path = destination / 'configuration-sync-evidence.zip'
with ZipFile(zip_path, 'w', ZIP_DEFLATED) as archive:
    for path, name in files:
        if name in seen or not path.is_file():
            continue
        seen.add(name)
        data = path.read_bytes()
        assert secret not in data, name
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
with ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    for entry in entries:
        assert sha(archive.read(entry['path'])) == entry['sha256']
summary = json.loads((repair / 'test-summary.json').read_text(encoding='utf-8'))
assert summary['total']['failures'] == summary['total']['errors'] == 0
assert summary['total']['tests'] > 4500, 'Do not archive the overwritten partial report as the full matrix'
manifest = dict(source='ec7fe6848afc1970661ee1f38a7c7c6d4575530c', artifacts=artifacts,
                staticStartupSha256=static_hashes.pop(), testSummary=summary,
                runtime=json.loads((runtime / 'runtime-verdict.json').read_text(encoding='utf-8')),
                archive=dict(file=zip_path.name, bytes=zip_path.stat().st_size, sha256=sha(zip_path.read_bytes())),
                entries=entries,
                exclusions=['server.properties/RCON credentials', 'launcher/account configs', 'worlds', 'raw JFR'])
(destination / 'manifest.json').write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
print(json.dumps(dict(entries=len(entries), tests=summary['total'], archiveSha256=manifest['archive']['sha256'])))
