import test from 'node:test';
import assert from 'node:assert/strict';

// This owned acceptance fixture inspects the existing host facade; no sandbox settings change.
const facade = Java.type('com.tkisor.nekojs.dynamic.DynamicRegistryFacade');
const builtins = Java.type('net.minecraft.core.registries.BuiltInRegistries');
const Identifier = Java.type('net.minecraft.resources.Identifier');

test('configuration sync engine and dynamic registry readbacks', () => {
    const engine = facade.runtime().activationEngine();
    assert.ok(engine !== null);
    assert.ok(Number(engine.activatedGeneration()) >= 0);
    for (const [registry, id] of [
        [builtins.ITEM, 'ticket37_b7:proof_item'],
        [builtins.SOUND_EVENT, 'ticket37_b7:proof_sound'],
        [builtins.MOB_EFFECT, 'ticket37_b7:proof_effect']
    ]) {
        assert.equal(registry.containsKey(Identifier.parse(id)), true, id);
    }
    const outcomes = engine.syncOutcomes();
    const records = [];
    for (let i = 0; i < outcomes.size(); i++) {
        const row = outcomes.get(i);
        records.push({ participant: row.participantId(), generation: Number(row.generation()),
            outcome: row.outcome(), reason: row.reason() });
    }
    const phases = engine.phaseLog();
    const phaseRecords = [];
    for (let i = 0; i < phases.size(); i++) {
        const row = phases.get(i);
        phaseRecords.push({ phase: String(row.phase()), generation: Number(row.generation()),
            passed: row.passed(), errorSource: row.errorSource(), detail: row.detail() });
    }
    console.info('CONFIG-SYNC-PROOF ' + JSON.stringify({ status: String(engine.status()),
        activatedGeneration: Number(engine.activatedGeneration()),
        participants: String(engine.transport().participants()), outcomes: records, phases: phaseRecords }));
});
