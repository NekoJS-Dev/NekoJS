
// This owned acceptance fixture inspects the existing host facade; no sandbox settings change.
const facade = Java.type('com.tkisor.nekojs.dynamic.DynamicRegistryFacade');
const builtins = Java.type('net.minecraft.core.registries.BuiltInRegistries');
const Identifier = Java.type('net.minecraft.resources.Identifier');

let proofTicks = 0;
ServerEvents.tickPost(event => {
    ++proofTicks; if (proofTicks !== 5 && proofTicks !== 100) return;
    const engine = facade.runtime().activationEngine();
    if (engine === null) throw new Error('Configuration proof has no activation engine');
    if (Number(engine.activatedGeneration()) < 0) throw new Error('Configuration proof has no activated generation');
    for (const [registry, id] of [
        [builtins.ITEM, 'ticket37_b7:proof_item'],
        [builtins.SOUND_EVENT, 'ticket37_b7:proof_sound'],
        [builtins.MOB_EFFECT, 'ticket37_b7:proof_effect']
    ]) {
        if (!registry.containsKey(Identifier.parse(id))) throw new Error('Configuration proof missing ' + id);
    }
    console.info('ABORT-ITEM-READBACK present=' + builtins.ITEM.containsKey(Identifier.parse('ticket37_b7:abort_item')));
    const outcomes = engine.syncOutcomes();
    const records = [];
    for (let i = 0; i < outcomes.size(); i++) {
        const row = outcomes.get(i);
        records.push({ participant: row.participantId(), generation: Number(row.generation()),
            outcome: row.outcome(), reason: row.reason() });
    }
    const phases = engine.phaseLog();
    const phaseRecords = [];
    for (let i = 0; i < phases.size(); i++) {
        const row = phases.get(i);
        phaseRecords.push({ phase: String(row.phase()), generation: Number(row.generation()),
            passed: row.passed(), errorSource: row.errorSource(), detail: row.detail() });
    }
    console.info('CONFIG-SYNC-PROOF ' + JSON.stringify({ status: String(engine.status()),
        activatedGeneration: Number(engine.activatedGeneration()),
        participants: String(engine.transport().participants()), outcomes: records, phases: phaseRecords }));
});




