RegistryEvents.register(event => {
    event.soundEvent('ticket15_startup:nullable', build => { build.fixedRange = null; });
    event.soundEvent('ticket15_startup:named', 'basic', build => { build.setFixedRange(null); });
    event.item('ticket15_startup:token', build => { build.maxStackSize = 16; });
    event.block('ticket15_startup:stone', build => { build.item.maxStackSize = 16; });
    event.block('ticket15_startup:no_item', build => { build.noItem(); });
    event.fluid('ticket15_startup:spring', build => { build.lightLevel = 5; });
    event.fluid('ticket15_startup:bare', build => { build.noBlock(); build.noBucket(); });
    console.info('STARTUP-INSTALLED-CALLBACKS-PASS');
});
