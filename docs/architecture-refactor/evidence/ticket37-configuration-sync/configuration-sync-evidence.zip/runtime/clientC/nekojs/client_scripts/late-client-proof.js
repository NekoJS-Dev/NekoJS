const fs = require('node:fs');
const registries = Java.type('net.minecraft.core.registries.BuiltInRegistries');
const Identifier = Java.type('net.minecraft.resources.Identifier');
const workspace = Java.type('com.tkisor.nekojs.script.WorkspaceGenerator');
let observedJoin = false;

ClientEvents.loggedIn(event => {
    if (observedJoin) return;
    observedJoin = true;
    const present = [];
    for (const [registry, id] of [
        [registries.ITEM, 'ticket37_b7:proof_item'],
        [registries.SOUND_EVENT, 'ticket37_b7:proof_sound'],
        [registries.MOB_EFFECT, 'ticket37_b7:proof_effect'],
        [registries.ITEM, 'ticket37_b7:live_item'],
        [registries.SOUND_EVENT, 'ticket37_b7:live_sound'],
        [registries.MOB_EFFECT, 'ticket37_b7:live_effect']
    ]) {
        if (!registry.containsKey(Identifier.parse(id))) throw new Error('Late client missing ' + id);
        present.push(id);
    }
    console.info('LATE-CLIENT-READBACK ' + JSON.stringify(present));
});

let reloadTicks = 0;
let reloaded = false;
ClientEvents.tickPost(event => {
    if (!observedJoin || reloaded || ++reloadTicks % 20 !== 0) return;
    const signal = 'D:/mcmodDemo/NekoJS-mult/build/ticket37-config-sync-installed-attempt1/clientC/nekojs/data/reload-owned-engine.txt';
    if (!fs.existsSync(signal)) return;
    // The host edits its owned config; scripts remain unable to write protected engine files.
    workspace.setupWorkspace();
    reloaded = true;
    console.info('REJECTOR-GATE-RELOADED from host-edited owned config after catch-up');
});
