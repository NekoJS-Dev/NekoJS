DynamicRegistryEvents.dynamicRegistry(event => {
    const item = event.item('ticket37_b7:proof_item', build => {
        build.maxStackSize = 16;
        build.rarity = 'epic';
    });
    const sound = event.soundEvent('ticket37_b7:proof_sound', build => {
        build.fixedRange = null;
    });
    const effect = event.mobEffect('ticket37_b7:proof_effect', build => {
        build.category = 'beneficial';
        build.color = 0x123456;
    });
    event.item('ticket37_b7:live_item', build => { build.maxStackSize = 8; });
    event.soundEvent('ticket37_b7:live_sound', build => { build.fixedRange = 12; });
    event.mobEffect('ticket37_b7:live_effect', build => { build.color = 0x654321; });
    console.info('B7-INSTALLED-DYNAMIC-COLLECT item=' + item + ' sound=' + sound + ' effect=' + effect);
});

