"""Prepare the unchanged seven-stage physical activation-failure proof for both current nodes."""
from pathlib import Path

root = Path(__file__).resolve().parent
names = ['prepare-method-bounds-tcp.py', 'run-method-bounds-tcp-all.py',
         'run-method-bounds-tcp-261.py', 'run-method-bounds-tcp-262.py', 'verify-method-bounds-tcp.py']
for name in names:
    source = (root / name).read_text(encoding='utf-8')
    source = source.replace('975496d3bddf6fc76b206921a1d09207120ca24d', '6e43b82789a7dbf7b9659dc1c21fefecac662649')
    source = source.replace('975496d3', '6e43b827').replace('method-bounds', 'owner-stamp')
    source = source.replace('30191', '33291').replace('30291', '33391')
    source = source.replace('.read_text()', ".read_text(encoding='utf-8')")
    target = root / name.replace('method-bounds', 'owner-stamp')
    assert not target.exists()
    target.write_text(source, encoding='utf-8', newline='\n')
print('Derived fresh exact-client-A fault helpers; all seven stage assertions retained.')
