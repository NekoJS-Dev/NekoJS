"""Keep the established stage verifier while rebinding exact sources, artifacts, and current tools."""
import ast
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
def current(source):
    source = source.replace('975496d3bddf6fc76b206921a1d09207120ca24d', '6e43b82789a7dbf7b9659dc1c21fefecac662649')
    source = source.replace('975496d3', '6e43b827').replace('method-bounds', 'owner-stamp')
    source = source.replace('2026-10-24-candidate-tcp', '2026-10-24-owner-stamp-tcp')
    source = source.replace('== 1100', '== 1101').replace('== 1641', '== 1642')
    source = source.replace('productionClassesPerNode=1641', 'productionClassesPerNode=1642')
    return source.replace('.read_text()', ".read_text(encoding='utf-8')")
source = current((tools / 'seal-method-bounds-tcp.py').read_text(encoding='utf-8'))
start = source.index('names = [')
end = source.index("for short in ['261', '262']:", start)
names = ['derive-owner-stamp-commit-tcp.py', 'prepare-owner-stamp-tcp.py', 'run-owner-stamp-tcp-all.py',
    'derive-owner-stamp-basic-tcp.py', 'prepare-owner-stamp-basic-tcp.py', 'run-owner-stamp-basic-tcp-all.py',
    'verify-owner-stamp-tcp.py', 'bind-owner-stamp-runtime.py', 'owner-stamp-runtime-binding.log',
    'owner-stamp-tcp-driver.log', 'owner-stamp-basic-tcp-driver.log', 'seal-owner-stamp-tcp.py',
    'derive-owner-stamp-tcp-evidence.py']
source = source[:start] + 'names = ' + repr(names) + '\n' + source[end:]
ast.parse(source)
target = tools / 'seal-owner-stamp-tcp.py'
assert not target.exists()
target.write_text(source, encoding='utf-8', newline='\n')
source = current((repo / 'docs/architecture-refactor/evidence/2026-10-24-candidate-tcp/verify.py').read_text(encoding='utf-8'))
ast.parse(source)
target = tools / 'owner-stamp-tcp-evidence-verify.py'
assert not target.exists()
target.write_text(source, encoding='utf-8', newline='\n')
print('Derived the same 30-stage/14-exit verifier; exact current binding is 1101 sources and 1642 classes.')
