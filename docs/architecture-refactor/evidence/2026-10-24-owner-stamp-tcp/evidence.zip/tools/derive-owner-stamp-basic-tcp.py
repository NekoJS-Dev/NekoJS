"""Bind the unchanged eight-stage protocol proof to the current exact local candidate."""
from pathlib import Path

root = Path(__file__).resolve().parent
names = ['prepare-method-bounds-basic-tcp.py', 'run-method-bounds-basic-tcp-all.py',
         'run-method-bounds-basic-tcp-261.py', 'run-method-bounds-basic-tcp-262.py',
         'verify-method-bounds-basic-tcp-261.py', 'verify-method-bounds-basic-tcp-262.py',
         'bind-method-bounds-runtime.py']
for name in names:
    source = (root / name).read_text(encoding='utf-8')
    source = source.replace('975496d3bddf6fc76b206921a1d09207120ca24d', '6e43b82789a7dbf7b9659dc1c21fefecac662649')
    source = source.replace('975496d3', '6e43b827').replace('method-bounds', 'owner-stamp')
    source = source.replace('30391', '32491').replace('30491', '32591')
    target = root / name.replace('method-bounds', 'owner-stamp')
    assert not target.exists()
    target.write_text(source, encoding='utf-8', newline='\n')
print('Derived separate fresh candidate fixtures; protocol stages and assertions unchanged.')
