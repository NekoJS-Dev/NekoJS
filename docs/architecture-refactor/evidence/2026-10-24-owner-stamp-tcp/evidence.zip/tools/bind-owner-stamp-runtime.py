"""Bind each current-candidate runtime proof to committed sources and all packaged production classes."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
revision = '6e43b82789a7dbf7b9659dc1c21fefecac662649'
installed = json.loads((repo / 'build/closeout-owner-stamp-installed/preparation-manifest.json').read_text())
assert installed['sourceRevision'] == revision
tracked = subprocess.check_output(['git', 'ls-files'], text=True).splitlines()
paths = [name for name in tracked if '/src/main/' in '/' + name or name.startswith('src/main/')
         or name.endswith(('.gradle', '.gradle.kts')) or name in ['gradle.properties', 'gradle/libs.versions.toml']]
batch = subprocess.check_output(['git', 'cat-file', '--batch'], input=''.join(revision + ':' + name + '\n' for name in paths).encode())
offset = 0
sources = {}
for name in paths:
    boundary = batch.index(b'\n', offset)
    header = batch[offset:boundary].decode().split()
    assert len(header) == 3 and header[1] == 'blob', (name, header)
    size = int(header[2])
    data = batch[boundary + 1:boundary + 1 + size]
    offset = boundary + size + 2
    current = (repo / name).read_bytes()
    assert current.replace(b'\r\n', b'\n') == data.replace(b'\r\n', b'\n'), name
    sources[name] = dict(committedBlob=header[0], workingSha256=hashlib.sha256(current).hexdigest())
roots = []
for kind in ['commit', 'basic']:
    for short, node in [('261', '26.1.2'), ('262', '26.2.0')]:
        root = tools / f'dynamic-{kind}-6e43b827-{short}-v1'
        if not (root / 'run-result.json').exists():
            continue
        result = json.loads((root / 'run-result.json').read_text())
        assert result['verdict'] == 'PASS' and not result['errors'] and not result['forced']
        assert all(value == 0 for value in result['exits'].values())
        roots.append((root, node, ['server', 'clientA', 'clientB']))
for short, node in [('121', '1.21.1'), ('261', '26.1.2'), ('262', '26.2.0')]:
    root = tools / f'posteffects-{short}-installed-6e43b827-v1'
    if not (root / 'run-result.json').exists():
        continue
    result = json.loads((root / 'run-result.json').read_text())
    assert result['mechanicalVerdict'] == 'PASS' and not result['errors'] and not result['forced']
    assert result['clientExit'] == result['serverExit'] == 0
    roots.append((root, node, ['server', 'client']))
results = []
for root, node, sides in roots:
    target = root / 'candidate-binding.json'
    if target.exists():
        continue
    row = next(value for value in installed['nodes'] if value['node'] == node)
    artifacts = {}
    for side in sides:
        name = row['artifact'].replace('-server.jar', '.jar') if side == 'client' and node == '1.21.1' else row['artifact']
        jar = root / side / 'mods' / name
        digest = hashlib.sha256(jar.read_bytes()).hexdigest()
        if side != 'client' or node != '1.21.1':
            assert digest == row['sha256']
        with zipfile.ZipFile(jar) as archive:
            for name, expected in row['classBindings'].items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == expected, (root.name, side, name)
        artifacts[side] = dict(name=jar.name, sha256=digest)
    binding = dict(sourceRevision=revision, sourceBindings=sources, classBindings=row['classBindings'],
        artifacts=artifacts, timing='Post-run independent byte verification against the frozen installed candidate.',
        matrixArchiveSha256=hashlib.sha256((repo / 'docs/architecture-refactor/evidence/2026-10-24-owner-stamp/evidence.zip').read_bytes()).hexdigest())
    target.write_text(json.dumps(binding, indent=2) + '\n')
    results.append(dict(root=root.name, sourceFiles=len(sources), compiledClasses=len(row['classBindings'])))
print(json.dumps(results))
