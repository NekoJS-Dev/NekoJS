"""Independently check the actual TCP observations and exact installed artifact bindings."""
import hashlib
import json
import zipfile
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
expected = ['01-empty-two-enabled-clients', '02-normal-dual-commit',
    '03-real-commit-activation-failure', '04-failed-catch-up-retains-prior-client-state',
    '05-reconnect-rejected-before-play', '06-same-client-recovery-after-fault-removed',
    '07-subsequent-dual-commit-after-recovery']
results = []
for short, attempt, node in [('261', 'v1', '26.1.2'), ('262', 'v1', '26.2.0')]:
    root = tools / f'dynamic-commit-6e43b827-{short}-{attempt}'
    result = json.loads((root / 'run-result.json').read_text(encoding='utf-8'))
    prep = json.loads((root / 'preparation.json').read_text(encoding='utf-8'))
    assert result['verdict'] == 'PASS' and result['stages'] == expected
    assert not result['errors'] and not result['forced']
    assert result['exits'] == dict(server=0, clientA=0, clientB=0)
    stages = [json.loads((root / (name + '.json')).read_text(encoding='utf-8')) for name in expected]
    for stage in stages:
        assert all(stage[side]['sameThread'] for side in ['server', 'clientA', 'clientB'])
    fault = stages[2]
    generation = fault['server']['activatedGeneration']
    players = {value['name']: value['id'] for value in fault['server']['players']}
    assert len(players) == 2
    def outcomes(stage, name):
        return [entry for entry in stage['server']['syncOutcomes']
                if entry['generation'] == generation and entry['outcome'] == name]
    assert {entry['participantId'] for entry in outcomes(fault, 'ack')} == set(players.values())
    failures = outcomes(fault, 'activation-failed-post-commit')
    assert len(failures) == 1 and failures[0]['participantId'] == players['OwnedTcpA']
    assert 'OWNED-TCP-COMMIT-FAULT' in failures[0]['reason']
    assert fault['server']['status'] == 'COMMITTED' and fault['server']['lastSummary']['committed']
    assert fault['server']['items']['tcp_commit_fail']['present']
    assert fault['clientB']['items']['tcp_commit_fail']['present']
    assert not fault['clientA']['items']['tcp_commit_fail']['present']
    assert fault['clientA']['items']['tcp_seed']['present']
    assert stages[3]['clientA']['connected'] and outcomes(stages[3], 'state-sync-rejected')
    assert stages[3]['clientA']['items']['tcp_seed']['present']
    assert not stages[3]['clientA']['items']['tcp_commit_fail']['present']
    assert len(outcomes(stages[4], 'state-sync-rejected')) > len(outcomes(stages[3], 'state-sync-rejected'))
    assert not stages[4]['clientA']['connected'] and len(stages[4]['server']['players']) == 1
    assert 'DisconnectedScreen' in stages[4]['clientA']['screen']
    assert stages[5]['clientA']['connected'] and not stages[5]['clientA']['faultEnabled']
    assert stages[5]['server']['activatedGeneration'] == generation
    assert outcomes(stages[5], 'state-sync-completed')
    for side in ['server', 'clientA', 'clientB']:
        for key in ['tcp_seed', 'tcp_commit_fail', 'tcp_followup']:
            assert stages[6][side]['items'][key] == dict(present=True, maxStackSize=16, rarity='RARE')
        jar = root / side / 'mods' / prep['jar']['name']
        assert hashlib.sha256(jar.read_bytes()).hexdigest() == prep['jar']['sha256']
        proof_files = list((root / side).glob('installed-source-*.json'))
        assert len(proof_files) == 1
        proof = json.loads(proof_files[0].read_text(encoding='utf-8'))
        assert proof['artifactSha256'] == prep['jar']['sha256']
        assert 'OWNED-TCP-INSTALLED-SOURCE-PASS' in (root / (side + '-stdout.log')).read_text(encoding='utf8', errors='replace')
        assert len(proof['classes']) == 5
        owned_pid = json.loads((root / (side + '-owned-process.json')).read_text(encoding='utf-8'))['pid']
        assert proof['pid'] == owned_pid
        with zipfile.ZipFile(jar) as archive:
            for name, digest in prep['classBindings'].items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
            for name, binding in proof['classes'].items():
                assert hashlib.sha256(archive.read(name.replace('.', '/') + '.class')).hexdigest() == binding['sha256']
                assert prep['jar']['name'] in binding['codeSource']
                assert prep['jar']['name'] in binding['resource']
    client_log = (root / 'clientA-stdout.log').read_text(encoding='utf8', errors='replace')
    assert client_log.count('OWNED-TCP-COMMIT-FAULT owner=') == 3
    assert client_log.count('thread=Render thread') == 3
    for side in ['server', 'clientB']:
        assert 'OWNED-TCP-COMMIT-FAULT owner=' not in (root / (side + '-stdout.log')).read_text(encoding='utf8', errors='replace')
    results.append(dict(node=node, root=root.name, verdict='PASS', stages=7, normalExits=3,
        jar=prep['jar'], nodeClassBindings=len(prep['classBindings']),
        helperSha256=result['helperSha256'], clientLoader=prep['clientLoader'], serverLoader=prep['serverLoader']))
(tools / 'owner-stamp-tcp-summary.json').write_text(json.dumps(dict(
    productionRevision='6e43b82789a7dbf7b9659dc1c21fefecac662649', nodes=results,
    fixtureMutatesProduction=False, productionFix='Existing intrusive holder cleanup retained; current declaration candidate', maintainerAcceptance=False,
    limits=['ModDev helper launcher; not an external release installer.',
            'COMMIT failure is observable; play participant remains connected until explicitly kicked.',
            'Performance and full strict IDE gates remain open.']), indent=2) + '\n')
print(json.dumps(results))
