"""Build only the owned helpers, then execute both installed-candidate TCP proofs serially."""
import json
import os
from pathlib import Path
import subprocess
import sys

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
env = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-25.0.2')
for short in ['261', '262']:
    root = tools / f'dynamic-commit-6e43b827-{short}-v1'
    with (tools / f'owner-stamp-tcp-{short}-helper-build.log').open('xb') as log:
        result = subprocess.run([str(repo / 'gradlew.bat'), '-p', str(root), '--no-daemon',
            'jar', 'writeOwnedLaunch'], env=env, stdout=log, stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, f'Owned helper {short} build failed'
    print('HELPER_BUILD_PASS', short, flush=True)
for short in ['261', '262']:
    with (tools / f'owner-stamp-tcp-{short}-run.log').open('xb') as log:
        result = subprocess.run([sys.executable, str(tools / f'run-owner-stamp-tcp-{short}.py')],
            stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, f'Owned proof {short} driver failed'
    observed = json.loads((tools / f'dynamic-commit-6e43b827-{short}-v1/run-result.json').read_text(encoding='utf-8'))
    assert observed['verdict'] == 'PASS', observed['errors']
    print('TCP_PROOF_PASS', short, len(observed['stages']), observed['exits'], flush=True)
subprocess.run([sys.executable, str(tools / 'verify-owner-stamp-tcp.py')], check=True)
