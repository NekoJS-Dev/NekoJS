"""Seal both real TCP suites and bind their installed artifacts without exporting launch arguments."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-24-owner-stamp-tcp'
assert not out.exists()
trials = [(kind, short, tools / f'dynamic-{kind}-6e43b827-{short}-v1')
          for kind in ['basic', 'commit'] for short in ['261', '262']]
secrets = set()
for kind, short, trial in trials:
    result = json.loads((trial / 'run-result.json').read_text(encoding='utf-8'))
    assert result['verdict'] == 'PASS' and not result['errors'] and not result['forced']
    assert len(result['stages']) == (8 if kind == 'basic' else 7)
    assert len(result['exits']) == (4 if kind == 'basic' else 3) and all(value == 0 for value in result['exits'].values())
    props = dict(line.split('=', 1) for line in (trial / 'server/server.properties').read_text(encoding='utf-8').splitlines()
                 if '=' in line and not line.startswith('#'))
    secrets.add(props['rcon.password'])
entries = {}
redactions = {}
def add(name, file):
    original = data = file.read_bytes()
    for secret in secrets:
        if secret:
            for encoding in ['utf8', 'utf-16-le', 'utf-16-be']:
                data = data.replace(secret.encode(encoding), '[REDACTED]'.encode(encoding))
    if data != original:
        redactions[name] = hashlib.sha256(original).hexdigest()
    assert name not in entries
    entries[name] = data
references = {'261': dict(path='../2026-10-24-owner-stamp-performance/evidence.zip',
    entry='artifact/nekojs-neoforge-26.1.2-1.1.0-preview3.jar')}
reference_file = repo / 'docs/architecture-refactor/evidence/2026-10-24-owner-stamp-performance/evidence.zip'
references['261']['archiveSha256'] = hashlib.sha256(reference_file.read_bytes()).hexdigest()
for kind, short, trial in trials:
    prefix = kind + '-' + short
    for file in trial.iterdir():
        if file.is_file() and file.suffix in ['.json', '.jsonl', '.log', '.gradle'] and file.name != 'launch-descriptor.json':
            add(prefix + '/' + file.name, file)
    for file in (trial / 'src').rglob('*'):
        if file.is_file():
            add(prefix + '/src/' + file.relative_to(trial / 'src').as_posix(), file)
    helper = next((trial / 'build/libs').glob('*.jar'))
    add(prefix + '/helper.jar', helper)
    assert entries[prefix + '/helper.jar'] == helper.read_bytes()
    binding = json.loads((trial / 'candidate-binding.json').read_text(encoding='utf-8'))
    assert len(binding['sourceBindings']) == 1101 and len(binding['classBindings']) == 1642
    for side in ['server', 'clientA', 'clientB']:
        directory = trial / side
        artifact = binding['artifacts'][side]
        jar = directory / 'mods' / artifact['name']
        assert hashlib.sha256(jar.read_bytes()).hexdigest() == artifact['sha256']
        with zipfile.ZipFile(jar) as archive:
            for name, digest in binding['classBindings'].items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == digest
        for file in directory.iterdir():
            if file.is_file() and file.suffix in ['.json', '.jsonl']:
                add(prefix + '/' + side + '/' + file.name, file)
        for file in (directory / 'nekojs').rglob('*.js'):
            add(prefix + '/' + side + '/' + file.relative_to(directory).as_posix(), file)
        if kind == 'basic' and short == '262' and side == 'server':
            add('artifact/' + artifact['name'], jar)
            assert entries['artifact/' + artifact['name']] == jar.read_bytes()
            references[short] = dict(entry='artifact/' + artifact['name'])
names = ['derive-owner-stamp-commit-tcp.py', 'prepare-owner-stamp-tcp.py', 'run-owner-stamp-tcp-all.py', 'derive-owner-stamp-basic-tcp.py', 'prepare-owner-stamp-basic-tcp.py', 'run-owner-stamp-basic-tcp-all.py', 'verify-owner-stamp-tcp.py', 'bind-owner-stamp-runtime.py', 'owner-stamp-runtime-binding.log', 'owner-stamp-tcp-driver.log', 'owner-stamp-basic-tcp-driver.log', 'seal-owner-stamp-tcp.py', 'derive-owner-stamp-tcp-evidence.py']
for short in ['261', '262']:
    names.extend([f'run-owner-stamp-tcp-{short}.py', f'run-owner-stamp-basic-tcp-{short}.py',
        f'verify-owner-stamp-basic-tcp-{short}.py', f'owner-stamp-tcp-{short}-run.log',
        f'owner-stamp-tcp-{short}-helper-build.log', f'owner-stamp-basic-tcp-{short}-run.log',
        f'owner-stamp-basic-tcp-{short}-helper-build.log'])
for name in names:
    add('tools/' + name, tools / name)
add('tools/rcon.py', repo / 'bench/perf/rcon.py')
out.mkdir()
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(out / 'manifest.json').write_text(json.dumps(dict(sourceRevision='6e43b82789a7dbf7b9659dc1c21fefecac662649',
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(), artifactReferences=references,
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())},
    redactedOriginalHashes=redactions,
    exclusions=['world binaries', 'server.properties', 'launch-descriptor.json', '*-arguments.txt', 'runtime libraries', 'human acceptance']), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size, stages=30, normalExits=14)))
