from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.typing import CallableChild
def invalid(value: CallableChild) -> None:
    value.apply(17)
