from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.typing import Callable, CallableChild
def valid(value: CallableChild) -> Callable:
    value.apply(lambda incoming: incoming)
    return value
