from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.typing import Callable, CallableChild
def callback(incoming: object) -> object:
    return incoming
def valid(value: CallableChild) -> Callable:
    value.apply(callback)
    return value
