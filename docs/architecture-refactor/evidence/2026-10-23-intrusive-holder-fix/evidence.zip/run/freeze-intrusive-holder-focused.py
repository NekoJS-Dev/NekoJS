"""Preserve all four actual node regression reports before broader checks overwrite them."""
import json
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = tools / 'intrusive-holder-focused'
assert not out.exists()
out.mkdir()
summary = {}
for node in ['26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    file = repo / 'versions' / node / 'build/test-results/test/TEST-com.tkisor.nekojs.dynamic.DynamicIntrusiveHolderRollbackTest.xml'
    root = ET.fromstring(file.read_bytes())
    counts = {key: int(root.get(key, 0)) for key in ['tests', 'failures', 'errors', 'skipped']}
    assert counts == dict(tests=4, failures=0, errors=0, skipped=0), (node, counts)
    shutil.copyfile(file, out / (node + '.xml'))
    summary[node] = counts
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
