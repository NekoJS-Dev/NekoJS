"""Freeze the committed shared holder fix and its red/green behavior checks."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-23-intrusive-holder-fix'
assert not out.exists()
revision = subprocess.check_output(['git', 'rev-parse', 'b47734c6'], text=True).strip()
sources = ['src/main/java/com/tkisor/nekojs/dynamic/RegistrySurgery.java',
           'src/test/java/com/tkisor/nekojs/dynamic/DynamicIntrusiveHolderRollbackTest.java']
entries = {}
for name in sources:
    data = (repo / name).read_bytes()
    expected = subprocess.check_output(['git', 'show', revision + ':' + name])
    assert data.replace(b'\r\n', b'\n') == expected.replace(b'\r\n', b'\n')
    entries['sources/' + name] = data
entries['code.patch'] = subprocess.check_output(['git', 'diff', '6612cf05', revision, '--', *sources])
for name in ['intrusive-holder-red.log', 'intrusive-holder-red.xml',
    'intrusive-holder-refreeze-red.log', 'intrusive-holder-refreeze-red.xml',
    'intrusive-holder-green.log', 'intrusive-holder-fabric-first-failure.xml',
    'intrusive-holder-261-first-green.xml', 'intrusive-holder-262-first-green.xml',
    'intrusive-holder-final-focused.log', 'freeze-intrusive-holder-focused.py', 'seal-intrusive-holder-fix.py']:
    entries['run/' + name] = (tools / name).read_bytes()
for file in (tools / 'intrusive-holder-focused').iterdir():
    entries['focused/' + file.name] = file.read_bytes()
summary = dict(productionRevision=revision, focusedTests=16, focusedFailures=0,
    guard=dict(files=562, blocks=381, warnings=0),
    historicalFailures=['Old code: initial 4 tests / 2 failures; first real refreeze absent in one test.',
        'Old code with real refreeze: 4 tests / 3 failures.',
        'Initial cross-node command: two NeoForge suites passed; Fabric repeated tags assumption failed twice; last Fabric not run.'],
    testCorrection='Use existing frozen guard without binding tags, then first real freeze; null-map negative check runs unfrozen.',
    reviews=dict(standards=0, spec=0, readOnly=True, maintainerAcceptance=False),
    normalModernBuilds='IN PROGRESS, not included here', tcpRecovery='NOT RUN for this revision',
    fullStrictTsc='Latest measured preceding 1f877b0f: 5857 FAIL', performance='FAIL at existing 285.3 ms threshold')
entries['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
out.mkdir()
with zipfile.ZipFile(out / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(out / 'manifest.json').write_text(json.dumps(dict(archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())}), indent=2) + '\n')
print(json.dumps(summary))
