import json
import os
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
runner = root/'build/ticket37-config-sync-repair'
records = json.loads((runner/'constructor-performance-groups-exits.json').read_text())
assert len(records) == 3 and all(row['samplerExit'] == 0 for row in records)
# Invoke only after the parent observes tool session 60112 complete with exit_code=0.
(runner/'constructor-performance-runner-exit.json').write_text(json.dumps(dict(exitCode=0,
    observation='Tool session 60112 directly completed with exit_code=0; three subprocess exit records retained'), indent=2)+'\n', encoding='utf-8')
environment = dict(os.environ)
environment['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
target = root/'build/ticket37-perf-7b724a50'
with (target/'final-owned-guard.txt').open('xb') as output:
    result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(runner/'guard-constructor-performance.ps1')], stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW, env=environment)
(target/'final-owned-guard-exit.json').write_text(json.dumps(dict(exitCode=result.returncode), indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(directOuterExit=0, directSamplerExits=[row['samplerExit'] for row in records], finalGuardExit=result.returncode)))
raise SystemExit(result.returncode)


