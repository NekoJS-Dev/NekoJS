import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
runner = root/'build/ticket37-config-sync-repair'
revision = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert revision == '7b724a50f51367ad43f5903b1e7240e8e69bad10'
for name in ['prepare-util-performance.ps1','guard-util-performance.ps1','run-util-performance.py','prepare-util-performance.py','archive-util-performance.py','verify-util-performance.py']:
    text = (runner/name).read_text(encoding='utf-8-sig')
    text = text.replace('60139fffffa6e54b2248797c2a32d4fd75025a54',revision).replace('60139fff','7b724a50')
    text = text.replace('util-performance','constructor-performance').replace('node-util-predicate','constructor-member')
    text = text.replace('common/build/resources/main/nekojs/node/modules/util.ts','common/build/classes/java/main/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.class')
    text = text.replace("jar.read('nekojs/node/modules/util.ts')", "jar.read('com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.class')")
    text = text.replace('actualFiveInstalledResourcesByteEqual','actualFiveInstalledClassesByteEqual').replace('compiledResources','compiledClasses')
    text = text.replace('No causal claim about the util annotation correction','No causal claim about the constructor declaration correction')
    target = runner/name.replace('util-performance','constructor-performance')
    assert not target.exists()
    target.write_text(text,encoding='utf-8')
out = root/'docs/architecture-refactor/evidence/ticket37-constructor-performance'
assert not out.exists()
out.mkdir()
plan = dict(sourceRevision=revision,groups=['reload-confirmed-1','reload-confirmed-2','startup-confirmed'],unchangedSampler=True,samplesPerGroup=5,
    startupThreshold=41173,reloadThreshold=285.3,noDiscardedValues=True,startAfterOwnedServersAndCompilersSettle=True)
(out/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps(plan))
