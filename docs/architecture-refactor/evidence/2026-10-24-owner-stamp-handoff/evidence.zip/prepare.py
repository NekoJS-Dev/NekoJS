"""Bind six unchanged local artifacts to the latest source and explicit open gates."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

repo = Path.cwd()
revision = '6e43b82789a7dbf7b9659dc1c21fefecac662649'
root = repo / 'build/release-candidate-6e43b827'
assert not root.exists()
installed_root = repo / 'build/closeout-owner-stamp-installed'
installed = json.loads((installed_root / 'preparation-manifest.json').read_text())
assert installed['sourceRevision'] == revision
evidence = repo / 'docs/architecture-refactor/evidence'
proofs = ['2026-10-24-owner-stamp', '2026-10-24-owner-stamp-performance']
references = {name: hashlib.sha256((evidence / name / 'evidence.zip').read_bytes()).hexdigest() for name in proofs}
artifacts = []
root.mkdir()
for row in installed['nodes']:
    sources = [('runtime', installed_root / row['node'] / 'mods' / row['artifact'], row['sha256'])]
    if row['node'] == '1.21.1':
        name = row['artifact'].replace('-server.jar', '.jar')
        client = repo / 'versions/1.21.1/build/libs' / name
        sources.append(('client', client, hashlib.sha256(client.read_bytes()).hexdigest()))
    for role, source, expected in sources:
        assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
        with zipfile.ZipFile(source) as jar:
            actual = {name: hashlib.sha256(jar.read(name)).hexdigest() for name in jar.namelist() if name.endswith('.class')}
            assert {name: actual[name] for name in row['classBindings']} == row['classBindings'], (row['node'], role)
            assert {name for name in actual if name.startswith('com/tkisor/nekojs/')} == {
                name for name in row['classBindings'] if name.startswith('com/tkisor/nekojs/')}, (row['node'], role)
        target = root / row['node'] / source.name
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(source, target)
        assert hashlib.sha256(target.read_bytes()).hexdigest() == expected
        artifacts.append(dict(node=row['node'], role=role, path=target.relative_to(root).as_posix(),
            sha256=expected, bytes=target.stat().st_size, productionClasses=len(row['classBindings'])))
manifest = dict(productionRevision=revision,
    checkoutRevisionAtPreparation=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    artifactVersion='1.1.0-preview3', releaseReady=False, remoteUploadPerformed=False,
    sourceVersionRepackaged=False, artifacts=artifacts, evidenceArchives=references,
    gates=dict(fullMatrix='PASS: 5158 declared tests / 271 skipped / zero failures and errors',
        installedServers='PASS: five nodes, five normal stops', defaultPython='PASS: 1609 stubs',
        strictTypeScript='FAIL: 5537 diagnostics, removed 12 and added zero against 87baad4b',
        reloadPerformance='FAIL: 288.2 / 299.4 ms against 285.3 ms',
        startupPerformance='PASS: 26174.8 ms against 41173 ms',
        nativeRender='NOT RE-RUN: previous proof binds 975496d3',
        realTcp='NOT RE-RUN: previous proof binds 975496d3',
        separatedRollback='NOT RE-RUN: previous proof binds d91ca974 and 975496d3; 26.1.2 whole-world fixture only',
        maintainerAcceptance='NOT RECORDED'),
    limits=['Exact local engineering candidate; release gates remain open.',
        'Artifact replacement does not restore data or world-external effects.',
        'Current display version retained; no final 1.2.0 version cutover or repackaging.'])
(root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(root / 'class-bindings.json').write_text(json.dumps({row['node']: row['classBindings'] for row in installed['nodes']}, indent=2) + '\n')
(root / 'SHA256SUMS').write_text(''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in artifacts))
assert len(artifacts) == 6
print(json.dumps(dict(localArtifacts=len(artifacts), nodes=len(installed['nodes']), releaseReady=False,
    directory=str(root), artifactBytes=sum(row['bytes'] for row in artifacts))))
