import hashlib
import json
import shutil
import socket
import subprocess
import uuid
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/ticket37-client93-visual'
assert not root.exists()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changes = subprocess.check_output(['git', 'diff', '--name-only', '93f4b259ffafb6466918582fcfa950c2c2480d77', revision], text=True).splitlines()
assert all(path.startswith('docs/') for path in changes)
for path in (project, project / 'build'):
    assert path.resolve() == path and not path.is_symlink()
for port in (25981, 25982):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
installed = project / 'build/ticket37-same-name-import-installed/26.2.0'
manifest = json.loads((installed.parent / 'preparation-manifest.json').read_text())
entry = next(row for row in manifest['nodes'] if row['node'] == '26.2.0')
artifact = installed / 'mods' / entry['artifact']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(artifact) == entry['sha256']
assert sha(project / 'versions/26.2.0/build/libs' / artifact.name) == entry['sha256']
old = project / 'build/ticket37-live-7e98'
graal = old / 'server/mods/graal-1504336-8762962.jar'
bridge = project / 'build/ticket37-native-neoforge/client/mods/minecraft-mcp-26.2-neoforge.jar'
assert bridge.is_file()
server = root / 'server'
(server / 'mods').mkdir(parents=True)
(server / 'libraries').symlink_to((old / 'server/libraries').resolve(), target_is_directory=True)
for jar in (artifact, graal):
    shutil.copyfile(jar, server / 'mods' / jar.name)
for folder in ('config', 'startup_scripts'):
    shutil.copytree(old / 'server/nekojs' / folder, server / 'nekojs' / folder)
(server / 'nekojs/server_scripts').mkdir()
for name in ('proof-dynamic.js', 'proof-sync-observer.js'):
    shutil.copyfile(old / 'server/nekojs/server_scripts' / name, server / 'nekojs/server_scripts' / name)
(server / 'eula.txt').write_text('eula=true\n')
(server / 'server.properties').write_text('\n'.join(['server-ip=127.0.0.1', 'server-port=25981', 'enable-rcon=true', 'rcon.port=25982', 'rcon.password=' + uuid.uuid4().hex, 'online-mode=false', 'level-name=owned-client93-world', 'gamemode=creative', 'difficulty=peaceful', 'view-distance=3', 'simulation-distance=3', 'max-players=3', 'spawn-protection=0']) + '\n')
for letter in ('A', 'B'):
    client = root / ('client' + letter)
    (client / 'mods').mkdir(parents=True)
    for jar in (artifact, graal, bridge):
        shutil.copyfile(jar, client / 'mods' / jar.name)
    for folder in ('config', 'startup_scripts'):
        shutil.copytree(old / 'server/nekojs' / folder, client / 'nekojs' / folder)
    (client / 'nekojs/client_scripts').mkdir()
    (client / 'nekojs/data').mkdir()
    signal = str(client / 'nekojs/data/visual-step.txt').replace('\\', '/')
    fixture = """const visualFs = require('node:fs');
const visualSignal = '__SIGNAL__';
let lastVisualStep = '';
let hudRecorded = false;
ClientEvents.postEffects(event => {
    event.register('minecraft:invert', { blurRadius: 16, blurRounds: 1 });
    event.register('ticket37_client93:inline_blur', { blurRadius: 16, blurRounds: 1 });
});
ClientEvents.loggedIn(() => {
    const accepted = PostEffects.set('ticket37_client93:inline_blur');
    console.info('CLIENT93-LOGIN-SET ' + JSON.stringify({ accepted, generation: PostEffects.activeGeneration(), current: PostEffects.current(), active: PostEffects.isActive() }));
});
ClientEvents.tickPost(() => {
    if (!visualFs.existsSync(visualSignal)) return;
    const step = String(visualFs.readFileSync(visualSignal, 'utf8')).trim();
    if (step === lastVisualStep) return;
    lastVisualStep = step;
    const accepted = step === 'inline' ? PostEffects.set('ticket37_client93:inline_blur') : step === 'vanilla' ? PostEffects.set('minecraft:invert') : PostEffects.clear();
    console.info('CLIENT93-VISUAL-STEP ' + JSON.stringify({ step, accepted, generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('ticket37_client93:inline_blur'), current: PostEffects.current(), active: PostEffects.isActive() }));
});
ClientEvents.hud(() => {
    if (hudRecorded) return;
    hudRecorded = true;
    console.info('CLIENT93-FIRST-HUD ' + JSON.stringify({ generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('ticket37_client93:inline_blur'), current: PostEffects.current(), active: PostEffects.isActive() }));
});
""".replace('__SIGNAL__', signal)
    (client / 'nekojs/client_scripts/visual-proof.js').write_text(fixture, encoding='utf-8')
    (client / 'options.txt').write_text('enableVsync:false\nmaxFps:30\nrenderDistance:3\nsimulationDistance:3\nentityDistanceScaling:0.5\nfullscreen:false\nskipMultiplayerWarning:true\n', encoding='utf-8')
plan = '''# Current client visual and two-player installed acceptance

Use exact current official NeoForge26.2 JAR from the completed five-node
source-bound build, fresh owned world/profiles, cached NeoForge26.2.0.75,
JDK25.0.2 and synthetic offline identities. Server port25981/RCON25982.
Launch A first, bind Minecraft bridge by actual client PID/game directory,
verify initial join/catch-up, declaration generation and first HUD state.
Capture clear/vanilla override/custom inline blur, candidate rejection
retaining the previous generation, and next successful recovery.
Then launch B to observe two real sessions/ACK/activation after ordinary
server reload. Preserve original failures, native crashes and raw logs.
No sandbox/HostAccess/ClassFilter/production source changes. Screenshot
after a HUD callback does not certify the first rendered pixel frame.
Do not operate user game profiles or unrelated processes. Normal server
RCON stop and client close; record direct exits. Raw launcher arguments,
credentials, worlds and hs_err stay local. User explicitly authorized
visible client testing in this turn. No release or human PASS inferred.
'''
(root / 'PLAN.md').write_text(plan, encoding='utf-8')
(root / 'preparation.json').write_text(json.dumps(dict(checkoutRevision=revision, productionRevision='93f4b259ffafb6466918582fcfa950c2c2480d77', artifact=artifact.name, artifactSha256=entry['sha256'], graalSha256=sha(graal), bridgeSha256=sha(bridge), freshWorld=True, syntheticOfflineAccounts=True, ports=[25981,25982]), indent=2) + '\n', encoding='utf-8')
print('CLIENT93_PROFILES_PREPARED')
