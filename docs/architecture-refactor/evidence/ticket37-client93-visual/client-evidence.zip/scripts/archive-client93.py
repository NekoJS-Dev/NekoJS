import hashlib
import json
import re
import shutil
import socket
import subprocess
import zipfile
from pathlib import Path

project = Path.cwd().resolve()
roots = {'initial': project / 'build/ticket37-client93-visual',
         'resumed': project / 'build/ticket37-client93-resumed'}
destination = project / 'docs/architecture-refactor/evidence/ticket37-client93-visual'
destination.mkdir(exist_ok=True)
assert not (destination / 'client-evidence.zip').exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
source = '93f4b259ffafb6466918582fcfa950c2c2480d77'
checkout = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changes = subprocess.check_output(['git', 'diff', '--name-only', source, checkout], text=True).splitlines()
assert all(path.startswith('docs/') for path in changes)
for port in (25981, 25982, 9876, 9875):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
secrets = []
artifact_bindings = []
prior = json.loads((project / 'docs/architecture-refactor/evidence/ticket37-ts-same-name-import-repair/manifest.json').read_text())
class_hashes = prior['artifactSourceBinding']['nodes'][0]['classHashes']
assert len(class_hashes) == 14
for name, expected in prior['source']['files'].items():
    assert sha((project / name).read_bytes()) == expected
for label, root in roots.items():
    preparation = json.loads((root / 'preparation.json').read_text())
    assert preparation['productionRevision'] == source
    assert preparation['artifactSha256'] == '59d97eb34b670639e278f9a0558cd03e813e5b556061c209346837d6d1c24447'
    properties = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines() if '=' in line)
    secrets.append(properties['rcon.password'].encode())
    for node in ('server', 'clientA', 'clientB'):
        path = root / node / 'mods' / preparation['artifact']
        assert sha(path.read_bytes()) == preparation['artifactSha256']
        with zipfile.ZipFile(path) as jar:
            assert all(sha(jar.read(entry)) == expected for entry, expected in class_hashes.items())
        artifact_bindings.append(dict(run=label, node=node, sha256=preparation['artifactSha256'], classEntriesMatched=14))

def records(path, marker):
    return [json.loads(line.split(marker + ' ', 1)[1]) for line in path.read_text(encoding='utf-8', errors='replace').splitlines() if marker + ' ' in line]

initial = roots['initial']
resumed = roots['resumed']
proofs = records(initial / 'server/stdout.log', 'CONFIG-SYNC-PROOF')
two = next(row for row in reversed(proofs) if row['status'] == 'COMMITTED' and row['activatedGeneration'] == 3)
acks = [row for row in two['outcomes'] if row['generation'] == 3 and row['outcome'] == 'ack']
reports = [row for row in two['outcomes'] if row['generation'] == 3 and row['outcome'] == 'activation-report']
assert len(acks) == len(reports) == 2
assert {row['participant'] for row in acks} == {row['participant'] for row in reports}
assert all(row['reason'] == 'activated' for row in reports)
hud = records(initial / 'clientA/stdout.log', 'CLIENT93-FIRST-HUD')
assert [row['generation'] for row in hud] == [1, 2, 3]
assert all(row['declared'] for row in hud)
assert all(row['active'] and row['current'] == 'minecraft:invert' for row in hud[1:])
steps = records(initial / 'clientA/stdout.log', 'CLIENT93-VISUAL-STEP')
assert any(row['step'] == 'inline' and not row['accepted'] and row['generation'] == 2 and row['active'] for row in steps)
assert any(row['step'] == '' for row in steps)
client_log = (initial / 'clientA/stdout.log').read_text(encoding='utf-8', errors='replace')
assert 'phase=RELOAD_CANCEL' in client_log and 'CLIENT93-REJECTED-CANDIDATE' in client_log
assert any(row['step'] == 'vanilla' and row['generation'] == 3 and row['active'] for row in steps)
resumed_hud = records(resumed / 'clientA/stdout.log', 'CLIENT93-FIRST-HUD')
assert [row['generation'] for row in resumed_hud] == [1, 2]
assert resumed_hud[-1]['active']
exit_codes = {}
for label, root in roots.items():
    exit_codes[label] = {node: json.loads((root / node / 'exit.json').read_text())['exitCode'] if (root / node / 'exit.json').exists() else None for node in ('server', 'clientA', 'clientB')}
assert exit_codes['initial'] == dict(server=None, clientA=None, clientB=0)
assert exit_codes['resumed'] == dict(server=0, clientA=4294967295, clientB=1)
cleanup = json.loads((resumed / 'clientA/forced-cleanup.json').read_text(encoding='utf-8-sig'))
assert not cleanup['normalExit'] and cleanup['argumentFileVerified'] and cleanup['parentRunnerVerified']
crash = resumed / 'clientB/hs_err_pid31516.log'
crash_text = crash.read_text(encoding='utf-8', errors='replace')
assert 'EXCEPTION_ACCESS_VIOLATION' in crash_text and 'glfw.dll+0x10fa1' in crash_text
dump = (resumed / 'clientA/shutdown-thread-dump.txt').read_text(encoding='utf-8', errors='replace')
non_daemon = re.findall(r'^"pool-13-thread-\d+"[^\n]+', dump, re.MULTILINE)
assert len(non_daemon) == 8 and all('daemon' not in line for line in non_daemon) and '"DestroyJavaVM"' in dump
captures = []
for label, root in roots.items():
    for path in sorted((root / 'captures').glob('*.png')):
        captures.append(dict(run=label, file=path.name, bytes=path.stat().st_size, sha256=sha(path.read_bytes())))
identical = []
for label in roots:
    hashes = {}
    for row in captures:
        if row['run'] == label:
            hashes.setdefault(row['sha256'], []).append(row['file'])
    identical += [dict(run=label, files=names) for names in hashes.values() if len(names) > 1]
assert len(identical) == 4
summary = dict(sourceRevision=source, checkoutRevision=checkout, artifactBindings=artifact_bindings,
    initialTwoActualAcksAndActivatedReports='PASS', twoPlayerTransaction=two,
    declarationFirstHudState='PASS', initialHud=hud, resumedAHud=resumed_hud,
    initialAEffectClearAndEnablePixels='PASS', candidateRejectionAndRecoveryState='PASS',
    postReloadAndBPixelTransitions='NOT_VERIFIED', identicalCaptureGroups=identical, captures=captures,
    inlineIdActivation='REJECTED_BY_RESOURCE_BACKED_SET_CONTRACT', firstPixelFrame='NOT_VERIFIED',
    allNodeVisual='NOT_RUN', nativeClientOverall='FAIL', exits=exit_codes,
    resumedBCrash=dict(frame='glfw.dll+0x10fa1', thread='Render thread', cause='NOT_ESTABLISHED'),
    resumedAShutdown=dict(nonDaemonPoolThreads=8, owner='NOT_ESTABLISHED', forced=True, normalExit=False),
    initialMissingDirectExits='NOT_RECORDED; no inferred shutdown cause', ownedPortsFree=True,
    productionSourceChanged=False, securityChanged=False, humanAcceptance='NOT_RECORDED', overall='NOT_COMPLETE')
(destination / 'runtime-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
files = {}
def add(path, name):
    data = path.read_bytes()
    assert all(secret not in data for secret in secrets), 'Credential found in selected artifact: ' + name
    assert name not in files
    files[name] = data
for label, root in roots.items():
    for path in root.iterdir():
        if path.is_file() and path.suffix in ('.md', '.json', '.jsonl', '.js', '.py'):
            add(path, label + '/' + path.name)
    for node in ('server', 'clientA', 'clientB'):
        directory = root / node
        for name in ('stdout.log', 'stderr.log', 'owned-process.json', 'exit.json', 'options.txt', 'forced-cleanup.json', 'shutdown-thread-dump.txt', 'bridge-binding.json'):
            path = directory / name
            if path.exists():
                add(path, label + '/' + node + '/' + name)
        for path in (directory / 'logs').glob('*.log'):
            add(path, label + '/' + node + '/logs/' + path.name)
        for folder in ('config', 'startup_scripts', 'server_scripts', 'client_scripts'):
            for path in (directory / 'nekojs' / folder).rglob('*'):
                if path.is_file() and path.suffix in ('.js', '.toml'):
                    add(path, label + '/' + node + '/' + path.relative_to(directory).as_posix())
    for path in (root / 'captures').glob('*.png'):
        add(path, label + '/captures/' + path.name)
repair = project / 'build/ticket37-config-sync-repair'
for pattern in ('*client93*.py',):
    for path in repair.glob(pattern):
        add(path, 'scripts/' + path.name)
add(destination / 'runtime-summary.json', 'runtime-summary.json')
archive = destination / 'client-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(files.items()):
        output.writestr(name, data)
entries = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(files.items())}
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    assert set(output.namelist()) == set(entries)
    assert all(sha(output.read(name)) == row['sha256'] for name, row in entries.items())
manifest = dict(sourceRevision=source, archive=dict(file=archive.name, entries=len(entries), bytes=archive.stat().st_size, sha256=sha(archive.read_bytes())),
    entries=entries, rawCrashReports={'resumed/clientB/hs_err_pid31516.log': sha(crash.read_bytes())},
    exclusions=['server.properties/credentials', 'world', 'account/launcher arguments', 'libraries/assets/binaries', 'raw hs_err', 'unrelated desktop images'],
    actualCredentialScan='PASS', hashReadback='PASS')
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for source_name, target in [('resumed_a_clear.png', 'a-clear.png'), ('resumed_a_blur.png', 'a-blur.png')]:
    shutil.copyfile(resumed / 'captures' / source_name, destination / target)
print(json.dumps(dict(archive=manifest['archive'], exits=exit_codes, nativeClientOverall='FAIL', hashesAndCredentialScan='PASS')))
