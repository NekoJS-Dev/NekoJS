from pathlib import Path

project = Path.cwd().resolve()
repair = project / 'build/ticket37-config-sync-repair'
names = ['prepare-client93-visual', 'run-client93', 'rcon-client93', 'api-client93', 'step-client93-visual', 'setup-client93-scene']
for name in names:
    source = (repair / (name + '.py')).read_text(encoding='utf-8')
    source = source.replace('ticket37-client93-visual', 'ticket37-client93-resumed')
    for helper in names:
        source = source.replace(helper + '.py', helper + '-resumed.py')
    if name == 'run-client93':
        source = source.replace("args = [str(java), '-Xms512M', '-Xmx2G'] +", "args = [str(java), '-Xms512M', '-Xmx2G', '-Dmcp.port=' + str({'A': 9876, 'B': 9875}[mode])] +")
    if name == 'step-client93-visual':
        source = source.replace("(client / 'nekojs/data/visual-step.txt').write_text(step + '\\n', encoding='ascii')", "signal = client / 'nekojs/data/visual-step.txt'\npending = signal.with_suffix('.pending')\npending.write_text(step + '\\n', encoding='ascii')\npending.replace(signal)")
    with (repair / (name + '-resumed.py')).open('x', encoding='utf-8') as output:
        output.write(source)
print('RESUMED_HELPERS_PREPARED')
