from pathlib import Path

project = Path.cwd().resolve()
repair = project / 'build/ticket37-config-sync-repair'
source = (repair / 'run-live-7e98.py').read_text(encoding='utf-8')
source = source.replace('ticket37-live-7e98', 'ticket37-client93-visual')
source = source.replace('NekoLive', 'NekoClient93')
source = source.replace("assert mode in ('A', 'B', 'C', 'D', 'E')", "assert mode in ('A', 'B')")
source = source.replace("str(dict(C=25973, D=25974, E=25974).get(mode, 25971))", 'str(25981)')
with (repair / 'run-client93.py').open('x', encoding='utf-8') as output:
    output.write(source)
source = (repair / 'live-rcon-7e98.py').read_text(encoding='utf-8').replace('ticket37-live-7e98', 'ticket37-client93-visual')
with (repair / 'rcon-client93.py').open('x', encoding='utf-8') as output:
    output.write(source)
print('CLIENT93_RUNNERS_PREPARED')
