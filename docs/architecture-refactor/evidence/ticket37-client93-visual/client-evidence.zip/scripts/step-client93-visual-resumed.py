import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd().resolve()
letter, step, name = sys.argv[1:]
assert letter in ('A', 'B') and step in ('clear', 'vanilla', 'inline') and name.isidentifier()
client = root / 'build/ticket37-client93-resumed' / ('client' + letter)
log = client / 'stdout.log'
before = log.stat().st_size
signal = client / 'nekojs/data/visual-step.txt'
pending = signal.with_suffix('.pending')
pending.write_text(step + '\n', encoding='ascii')
pending.replace(signal)
deadline = time.monotonic() + 15
observed = None
while time.monotonic() < deadline:
    with log.open('rb') as output:
        output.seek(before)
        text = output.read().decode('utf-8', errors='replace')
    for line in text.splitlines():
        if 'CLIENT93-VISUAL-STEP ' in line:
            row = json.loads(line.partition('CLIENT93-VISUAL-STEP ')[2])
            if row['step'] == step:
                observed = row
                break
    if observed is not None:
        break
    time.sleep(0.1)
assert observed is not None, 'No new owned visual step observation'
time.sleep(0.25)
capture = root / 'build/ticket37-client93-resumed/captures' / (name + '.png')
assert not capture.exists()
params = json.dumps(dict(path=str(capture).replace('\\', '/')))
result = subprocess.run([sys.executable, str(root / 'build/ticket37-config-sync-repair/api-client93-resumed.py'), letter, 'screenshot_to_file', params], stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
assert result.returncode == 0, result.stderr.decode(errors='replace')
image = json.loads(result.stdout)
assert capture.is_file() and capture.stat().st_size == image['size']
record = dict(client=letter, step=observed, capture=capture.name, delayedAfterObservationSeconds=0.25, firstPixelFrame=False)
with (root / 'build/ticket37-client93-resumed/visual-captures.jsonl').open('a', encoding='utf-8') as output:
    output.write(json.dumps(record) + '\n')
print(json.dumps(record))
