import json
import sys
import time
import urllib.request
from pathlib import Path

root = Path.cwd().resolve() / 'build/ticket37-client93-visual'
letter = sys.argv[1]
assert letter in ('A', 'B')
client = root / ('client' + letter)
owned = json.loads((client / 'owned-process.json').read_text())
binding_file = client / 'bridge-binding.json'
if binding_file.exists():
    binding = json.loads(binding_file.read_text())
else:
    binding = None
    for port in range(9876, 9859, -1):
        try:
            with urllib.request.urlopen('http://127.0.0.1:' + str(port) + '/api/status', timeout=0.3) as response:
                status = json.load(response)
            if status.get('type') == 'minecraft-mod' and status.get('pid') == owned['pid']:
                binding = dict(port=port, pid=owned['pid'], status=status)
                break
        except (OSError, ValueError):
            pass
    assert binding is not None, 'Owned Minecraft bridge not found'
    binding_file.write_text(json.dumps(binding, indent=2) + '\n', encoding='utf-8')
base = 'http://127.0.0.1:' + str(binding['port'])
with urllib.request.urlopen(base + '/api/status', timeout=3) as response:
    status = json.load(response)
assert status.get('type') == 'minecraft-mod' and status.get('pid') == owned['pid'] == binding['pid']
method = sys.argv[2]
params = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
payload = dict(cmd=method, **params)
request = urllib.request.Request(base + '/api/cmd', data=json.dumps(payload).encode(), headers={'Content-Type':'application/json'}, method='POST')
with urllib.request.urlopen(request, timeout=30) as response:
    result = json.load(response)
row = dict(ts=time.time(), client=letter, pid=owned['pid'], port=binding['port'], request=payload, response=result)
with (root / 'api-actions.jsonl').open('a', encoding='utf-8') as output:
    output.write(json.dumps(row) + '\n')
print(json.dumps(result))
