import collections
import concurrent.futures
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

root = Path.cwd()
repair = root / 'build/ticket37-config-sync-repair'
trial = root / 'build/ticket37-ts-member-candidate'
expected = {'1.21.1': 317, '26.1.2': 377, '26.2.0': 344, '26.1.2-fabric': 293, '26.2.0-fabric': 259}
def check(node):
    server = trial / node
    files = sorted((server / '.neko_probe/python').rglob('*.pyi'))
    assert len(files) == expected[node]
    prefix = 'ts-member-ide-' + node
    config = dict(extends=str(server / 'pyrightconfig.json'), include=[os.path.relpath(p, repair).replace('\\', '/') for p in files], exclude=[])
    config_path = repair / (prefix + '-pyrightconfig.json')
    assert not config_path.exists(), 'Preserve IDE trial'
    config_path.write_text(json.dumps(config, indent=2) + '\n')
    pyright_path = repair / (prefix + '-pyright.json')
    with pyright_path.open('xb') as output:
        result = subprocess.run(['node', 'C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js', '--project', str(config_path), '--outputjson'], stdout=output, stderr=subprocess.PIPE)
    (repair / (prefix + '-pyright-stderr.txt')).write_bytes(result.stderr)
    assert not result.stderr
    document = json.loads(pyright_path.read_text(encoding='utf-8-sig'))
    assert document['summary']['filesAnalyzed'] == len(files)
    ts_results = []
    for side in ['server', 'startup']:
        config = dict(extends=str(server / 'nekojs' / (side + '_scripts/jsconfig.json')), compilerOptions=dict(skipLibCheck=False, noEmit=True))
        config_path = repair / (prefix + '-' + side + '-tsconfig.json')
        config_path.write_text(json.dumps(config, indent=2) + '\n')
        with (repair / (prefix + '-' + side + '-tsc.txt')).open('xb') as output:
            ts = subprocess.run(['node', str(root / 'node_modules/typescript/bin/tsc'), '--project', str(config_path), '--pretty', 'false'], stdout=output, stderr=subprocess.PIPE)
        assert not ts.stderr
        text = (repair / (prefix + '-' + side + '-tsc.txt')).read_text(encoding='utf-8-sig')
        codes = collections.Counter(re.findall(r'error (TS\d+):', text))
        ts_results.append(dict(side=side, exitCode=ts.returncode, diagnosticCount=sum(codes.values()), codes=dict(codes), includesInheritedFromActualEditorConfig=True, skipLibCheck=False))
    answer = dict(node=node, pyright=dict(version=document['version'], summary=document['summary'], exitCode=result.returncode, explicitStubCount=len(files), rules=dict(collections.Counter(d.get('rule', 'none') for d in document['generalDiagnostics']))), typescript=ts_results)
    print(json.dumps(answer), flush=True)
    return answer

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    results = list(executor.map(check, expected))
before = json.loads((repair / 'python-member-ide-1.21.1-pyright.json').read_text(encoding='utf-8-sig'))
after = json.loads((repair / 'ts-member-ide-1.21.1-pyright.json').read_text(encoding='utf-8-sig'))
def normalized(diagnostic):
    file = diagnostic['file'].replace('\\', '/').partition('/python/')[2]
    return (file, diagnostic.get('rule', 'none'), diagnostic['message'])
old = collections.Counter(normalized(d) for d in before['generalDiagnostics'])
new = collections.Counter(normalized(d) for d in after['generalDiagnostics'])
comparison = dict(before=before['summary'], after=after['summary'], removed=[dict(file=f, rule=r, message=m, count=n) for (f,r,m),n in sorted((old-new).items())], added=[dict(file=f, rule=r, message=m, count=n) for (f,r,m),n in sorted((new-old).items())], lineNumbersIgnoredForIdentity=True, sameNodeSameFixtures=True)
(repair / 'ts-member-ide-summary.json').write_text(json.dumps(dict(nodes=results, legacyComparison=comparison), indent=2) + '\n')
print('LEGACY_DIAGNOSTIC_CHANGE', json.dumps(dict(removed=sum((old-new).values()), added=sum((new-old).values()))))
