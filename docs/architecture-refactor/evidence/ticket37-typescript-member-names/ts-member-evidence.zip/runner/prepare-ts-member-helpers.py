from pathlib import Path
import json,subprocess
root=Path.cwd(); repair=root/'build/ticket37-config-sync-repair'
trial=root/'build/ticket37-ts-member-name-fixture'
assert not trial.exists()
caller=(repair/'ts-member-name-caller.ts').read_text(encoding='utf-8-sig').replace('"../../common/build/probe-ts-member-names"','"./index"')
config=dict(compilerOptions=dict(strict=True,skipLibCheck=False,noEmit=True,types=[]),files=['index.d.ts','caller.ts'])
results=[]
for phase,path in [('red',repair/'ts-member-name-red.d.ts'),('green',root/'common/build/probe-ts-member-names/index.d.ts')]:
    dest=trial/phase;dest.mkdir(parents=True)
    (dest/'index.d.ts').write_bytes(path.read_bytes())
    (dest/'caller.ts').write_text(caller)
    (dest/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n')
    result=subprocess.run(['node',str(root/'node_modules/typescript/bin/tsc'),'--project',str(dest/'tsconfig.json'),'--pretty','false'],capture_output=True)
    (dest/'tsc.txt').write_bytes(result.stdout+result.stderr)
    results.append(dict(phase=phase,exitCode=result.returncode))
assert results==[dict(phase='red',exitCode=2),dict(phase='green',exitCode=0)],results
(trial/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(results)
for old,new in [('prepare-python-member-candidate.py','prepare-ts-member-candidate.py'),('prepare-python-member-other-candidates.py','prepare-ts-member-other-candidates.py'),('check-python-member-ide.py','check-ts-member-ide.py')]:
    text=(repair/old).read_text()
    text=text.replace('9b2c5d29','8a8aa2d7').replace('Python Bean/member collision candidate','TypeScript quoted member-name candidate').replace('No golden change in this Python repair','No golden change in this TS repair').replace('common/src/main/java/com/tkisor/nekojs/probe/backend/python/PythonClassRenderer.java','common/src/main/java/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.java')
    if old=='check-python-member-ide.py':
        text=text.replace('python-member','ts-member')
        text=text.replace("'legacy-probe-actual-explicit-pyright.json'","'python-member-ide-1.21.1-pyright.json'")
        text=text.replace('ticket37-ts-member-candidate','ticket37-ts-member-candidate')
    assert not (repair/new).exists()
    (repair/new).write_text(text)
