from pathlib import Path
root=Path.cwd();repair=root/'build/ticket37-config-sync-repair'
text=(repair/'archive-python-member-evidence.py').read_text()
text=text.replace('ticket37-python-member-candidate','ticket37-ts-member-candidate').replace('ticket37-python-member-collisions','ticket37-typescript-member-names').replace('python-member-evidence.zip','ts-member-evidence.zip').replace('9b2c5d29','8a8aa2d7')
text=text.replace("['python-member-*', '*python-member*.py', 'triage-python-ide.py', 'python-ide-triage.json', 'run-other-nodes.py', 'configure-other-node-proofs.py']","['ts-member-*', '*ts-member*.py', 'parse-ts-member-declarations.cjs', 'run-other-nodes.py', 'configure-other-node-proofs.py', 'prove-python-member-candidate.py']")
text=text.replace("['.txt', '.json', '.xml', '.py', '.patch', '.zip']","['.txt', '.json', '.xml', '.py', '.patch', '.zip', '.cjs', '.ts']")
text=text.replace("for name in ['common/src/main/java/com/tkisor/nekojs/probe/backend/python/PythonClassRenderer.java', 'common/src/test/java/com/tkisor/nekojs/probe/backend/python/PythonBeanMemberCollisionTest.java']:","for p in (root / 'build/ticket37-ts-member-name-fixture').rglob('*'):\n    if p.is_file(): files['fixture/' + p.relative_to(root / 'build/ticket37-ts-member-name-fixture').as_posix()] = p\nfor name in ['common/src/main/java/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.java', 'common/src/test/java/com/tkisor/nekojs/probe/ir/TypeScriptMemberNameTest.java']:")
text=text.replace("['python-member-final-test-summary.json', 'python-member-ide-summary.json', 'python-member-ts-byte-comparison.json', 'python-ide-triage.json']","['ts-member-final-test-summary.json', 'ts-member-ide-summary.json', 'ts-member-syntax-before.json', 'ts-member-syntax-after.json']")
text=text.replace("'python-member-final-test-summary.json'","'ts-member-final-test-summary.json'").replace("matrixVerdict=summary['matrixVerdict']","matrixVerdict='PASS: directly observed ordinary matrix exit0, prior filesystem failures retained separately'")
text=text.replace("both agent jobs hit service usage limit; manual review separate","prior agent jobs hit service usage limit; no new independent result; manual review separate")
assert not (repair/'archive-ts-member-evidence.py').exists()
(repair/'archive-ts-member-evidence.py').write_text(text)
