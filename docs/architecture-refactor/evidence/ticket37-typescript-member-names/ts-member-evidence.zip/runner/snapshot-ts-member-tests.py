import hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path.cwd();out=root/'build/ticket37-config-sync-repair'
sha=lambda data:hashlib.sha256(data).hexdigest()
rows=[];entries=[]
with ZipFile(out/'ts-member-final-xml.zip','x',ZIP_DEFLATED) as z:
    for project in ['common','common-api-processor']+['versions/'+n for n in ['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']]:
        row=dict(project=project,xml=0,tests=0,skipped=0,failures=0,errors=0)
        for p in sorted((root/project/'build/test-results/test').glob('TEST-*.xml')):
            s=ET.parse(p).getroot();row['xml']+=1
            for k in ['tests','skipped','failures','errors']:row[k]+=int(s.get(k,'0'))
            data=p.read_bytes();name=p.relative_to(root).as_posix();z.writestr(name,data);entries.append(dict(path=name,sha256=sha(data)))
        rows.append(row)
total={k:sum(r[k] for r in rows) for k in ['xml','tests','skipped','failures','errors']}
assert total==dict(xml=792,tests=4597,skipped=271,failures=0,errors=0),total
patch=subprocess.check_output(['git','diff','8a8aa2d7','--','common/src/main/java/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.java'])
(out/'ts-member-production.patch').write_bytes(patch)
(out/'ts-member-final-test-summary.json').write_text(json.dumps(dict(sourceBase='8a8aa2d7',productionPatchSha256=sha(patch),projects=rows,total=total,exitCode=0,xmlArchiveSha256=sha((out/'ts-member-final-xml.zip').read_bytes()),entries=entries),indent=2)+'\n')
print(total)
