import gzip
import hashlib
import io
import json
import re
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
repair = root / 'build/ticket37-config-sync-repair'
trial = root / 'build/ticket37-ts-member-candidate'
destination = root / 'docs/architecture-refactor/evidence/ticket37-typescript-member-names'
archive_path = destination / 'ts-member-evidence.zip'
assert not archive_path.exists(), 'Preserve completed evidence'
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
secrets = []
artifacts = []
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    server = trial / node
    exit_record = json.loads((server / 'server-exit.json').read_text())
    assert exit_record['exitCode'] == 0
    for line in (server / 'server.properties').read_text().splitlines():
        if line.startswith('rcon.password='):
            secrets.append(line.partition('=')[2].encode())
    jars = [p for p in (server / 'mods').glob('nekojs-*.jar')]
    assert len(jars) == 1
    jar = jars[0]
    assert jar.read_bytes() == (root / 'versions' / node / 'build/libs' / jar.name).read_bytes()
    artifacts.append(dict(node=node, file=jar.name, sha256=sha(jar.read_bytes()), exit=exit_record))
    for p in server.iterdir():
        if p.is_file() and (p.name.startswith(('owned-', 'server-', 'runtime-', 'command-')) or p.name == 'pyrightconfig.json'):
            files[p.relative_to(root / 'build').as_posix()] = p
    for directory in ['logs', 'nekojs', '.neko_probe', 'crash-reports']:
        for p in (server / directory).rglob('*'):
            if p.is_file() and p.suffix in ['.json', '.log', '.txt', '.gz', '.js', '.mjs', '.ts', '.pyi', '.md', '.toml', '.typed']:
                files[p.relative_to(root / 'build').as_posix()] = p
for p in trial.iterdir():
    if p.is_file() and p.suffix in ['.json', '.patch']:
        files[p.relative_to(root / 'build').as_posix()] = p
for pattern in ['ts-member-*', '*ts-member*.py', 'parse-ts-member-declarations.cjs', 'run-other-nodes.py', 'configure-other-node-proofs.py', 'prove-python-member-candidate.py']:
    for p in repair.glob(pattern):
        if p.is_file() and p.suffix in ['.txt', '.json', '.xml', '.py', '.patch', '.zip', '.cjs', '.ts']:
            files['runner/' + p.name] = p
for p in (root / 'build/ticket37-ts-member-name-fixture').rglob('*'):
    if p.is_file(): files['fixture/' + p.relative_to(root / 'build/ticket37-ts-member-name-fixture').as_posix()] = p
for name in ['common/src/main/java/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.java', 'common/src/test/java/com/tkisor/nekojs/probe/ir/TypeScriptMemberNameTest.java']:
    files['source/' + name] = root / name
def scan(data, suffix):
    if suffix == '.gz':
        scan(gzip.decompress(data), '')
        return
    if suffix == '.zip':
        with ZipFile(io.BytesIO(data)) as archive:
            for name in archive.namelist():
                scan(archive.read(name), Path(name).suffix)
        return
    assert not any(secret and secret in data for secret in secrets), 'Credential value in evidence'
    assert not re.search(rb'(?m)^rcon\.password=', data), 'Credential line in evidence'
entries = []
with ZipFile(archive_path, 'w', ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        scan(data, path.suffix)
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in entries:
        assert sha(archive.read(record['path'])) == record['sha256']
for name in ['ts-member-final-test-summary.json', 'ts-member-ide-summary.json', 'ts-member-syntax-before.json', 'ts-member-syntax-after.json']:
    (destination / name).write_bytes((repair / name).read_bytes())
summary = json.loads((repair / 'ts-member-final-test-summary.json').read_text())
manifest = dict(sourceBase='8a8aa2d7', sourceWipAtBuild=True, productionPatchSha256=summary['productionPatchSha256'], artifacts=artifacts, runtime=json.loads((trial / 'runtime-summary.json').read_text()), matrix=summary['total'], matrixVerdict='PASS: directly observed ordinary matrix exit0, prior filesystem failures retained separately', independentReview='NOT COMPLETED: prior agent jobs hit service usage limit; no new independent result; manual review separate', archive=dict(file=archive_path.name, sha256=sha(archive_path.read_bytes()), bytes=archive_path.stat().st_size, entries=len(entries)), entries=entries, exclusions=['server.properties/RCON credentials', 'worlds', 'account/launcher data', 'binaries/libraries', 'raw JFR'])
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(destination / '.gitattributes').write_bytes(b'*.txt -text whitespace=-blank-at-eol,-blank-at-eof,space-before-tab,cr-at-eol\n*.patch -text whitespace=-blank-at-eol\n')
print(json.dumps(dict(archive=manifest['archive'], artifacts=artifacts, matrix=manifest['matrix'], matrixVerdict=manifest['matrixVerdict'])))
