import hashlib
import json
import shutil
import socket
import subprocess
import sys
from pathlib import Path

project = Path.cwd()
source = project / 'build/ticket37-legacy-server-icu-installed/1.21.1'
root = (project / (sys.argv[1] if len(sys.argv) > 1 else 'build/ticket37-legacy-probe-candidate1')).resolve()
assert root.parent == (project / 'build').resolve()
assert not root.exists()
for port in [25921, 25922]:
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
node = root / '1.21.1'
(node / 'mods').mkdir(parents=True)
for name in ['server.properties', 'eula.txt']:
    shutil.copyfile(source / name, node / name)
for jar in (source / 'mods').glob('*.jar'):
    if not jar.name.startswith('nekojs-'):
        shutil.copyfile(jar, node / 'mods' / jar.name)
jar = project / 'versions/1.21.1/build/libs/nekojs-neoforge-1.21.1-1.1.0-preview3-server.jar'
shutil.copyfile(jar, node / 'mods' / jar.name)
(node / 'libraries').symlink_to((source / 'libraries').resolve(), target_is_directory=True)
for folder in ['config', 'startup_scripts', 'server_scripts']:
    shutil.copytree(source / 'nekojs' / folder, node / 'nekojs' / folder)
patch = subprocess.check_output(['git', 'diff', '8a8aa2d7', '--', 'common/src/main/java/com/tkisor/nekojs/probe'])
(root / 'production-source.patch').write_bytes(patch)
manifest = dict(purpose='TypeScript quoted member-name candidate, original fixtures, new world', sourceWip=True, sourceBase='8a8aa2d7', productionPatchSha256=hashlib.sha256(patch).hexdigest(), artifactSha256=hashlib.sha256(jar.read_bytes()).hexdigest(), customStartupScripts=True, goldenAcceptance='No golden change in this TS repair')
(root / 'preparation-manifest.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest))
