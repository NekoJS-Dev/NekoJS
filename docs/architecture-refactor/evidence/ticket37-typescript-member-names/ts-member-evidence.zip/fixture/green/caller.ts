import { $TypeScriptMemberNameTest$Fixture as Fixture } from "./index";
const fixture = new Fixture();
const a: string = fixture["handler$zek000$fabric-events-interaction-v0$fakePlayerGameMode"](1);
const b: string = fixture["handler$zek000$fabric-events-interaction-v0$fakePlayerGameMode"]("survival");
const c: number = Fixture["static-factory"]();
const d: number = fixture["getOdd-name"]();
fixture['quote"slash\\line\n']();
fixture.ordinary();
