    export class $TypeScriptMemberNameTest$Fixture {
        constructor();
        "getOdd-name"(): number;
        static "static-factory"(): number;
        "quote\"slash\\line\n"(): void;
        "handler$zek000$fabric-events-interaction-v0$fakePlayerGameMode"(mode: number): string;
        "handler$zek000$fabric-events-interaction-v0$fakePlayerGameMode"(mode: string): string;
        ordinary(): void;
    }
