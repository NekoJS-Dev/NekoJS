import json
import os
import subprocess
from pathlib import Path

root=Path.cwd().resolve()
helpers=root/'build/ticket37-config-sync-repair'
installed=root/'build/ticket37-manual-item-installed'
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert revision.startswith('63d538dc')
for name in ('runner','proof-runner','ide-runner'):
    assert json.loads((installed/(name+'-exit.json')).read_text())['exitCode']==0
for row in json.loads((installed/'preparation-manifest.json').read_text())['nodes']:
    assert json.loads((installed/row['node']/'server-exit.json').read_text())['exitCode']==0
for name in ('prepare-current-d109-performance.ps1','guard-current-d109-performance.ps1','run-current-d109-performance.py'):
    data=(helpers/name).read_text()
    data=data.replace('d10912ebbf24d9d5df75a908dc7a5529da09979a',revision)
    data=data.replace('ticket37-perf-d10912eb','ticket37-perf-'+revision[:8])
    data=data.replace('current-d109-performance','manual-item-performance')
    target=helpers/name.replace('current-d109-performance','manual-item-performance')
    assert not target.exists()
    target.write_text(data)
env=dict(os.environ)
env['PSModulePath']=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(helpers/'prepare-manual-item-performance.ps1')],env=env,creationflags=subprocess.CREATE_NO_WINDOW)
(helpers/'manual-item-performance-preparation-exit.json').write_text(json.dumps(dict(exitCode=result.returncode,sourceRevision=revision)))
raise SystemExit(result.returncode)
