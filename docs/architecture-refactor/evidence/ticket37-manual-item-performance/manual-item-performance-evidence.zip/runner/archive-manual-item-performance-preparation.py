import json
import os
import subprocess
from pathlib import Path

root=Path.cwd().resolve()
helpers=root/'build/ticket37-config-sync-repair'
revision='63d538dc14e7d7cdcf00f6217c5617fd285e7933'
work=root/('build/ticket37-perf-'+revision[:8])
assert json.loads((helpers/'manual-item-performance-runner-exit.json').read_text(encoding='utf-8-sig'))['exitCode']==0
env=dict(os.environ)
env['PSModulePath']=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
with (work/'final-owned-guard.txt').open('xb') as output:
    result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(helpers/'guard-manual-item-performance.ps1')],env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
(work/'final-owned-guard-exit.json').write_text(json.dumps(dict(exitCode=result.returncode)))
assert result.returncode==0
text=(helpers/'archive-current-d109-performance.py').read_text()
text=text.replace('d10912ebbf24d9d5df75a908dc7a5529da09979a',revision)
text=text.replace('ticket37-perf-d10912eb','ticket37-perf-'+revision[:8])
text=text.replace('current-d109-performance','manual-item-performance')
text=text.replace('ticket37-current-d109-installed','ticket37-manual-item-installed')
text=text.replace('ticket37-current-d109-ide','ticket37-manual-item-repair')
text=text.replace("read_text())['exitCode'] == 0", "read_text(encoding='utf-8-sig'))['exitCode'] == 0")
target=helpers/'archive-manual-item-performance.py'
assert not target.exists()
target.write_text(text)
