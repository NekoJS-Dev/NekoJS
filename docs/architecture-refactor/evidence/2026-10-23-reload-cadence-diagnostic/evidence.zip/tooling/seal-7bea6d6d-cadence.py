"""Freeze diagnosis separately from the failed formal acceptance result."""
import hashlib
import json
import zipfile
from pathlib import Path

repo = Path('D:/mcmodDemo/NekoJS-mult')
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-23-reload-cadence-diagnostic'
assert not (out / 'evidence.zip').exists()
out.mkdir(exist_ok=True)
properties = dict(line.split('=', 1) for line in
    Path('D:/mcmodDemo/NekoJS-perf-606d1fff/versions/26.1.2/run/server.properties').read_text().splitlines()
    if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password']
entries, redactions = {}, {}
roots = ['7bea6d6d-stage-formal-cadence', '7bea6d6d-stage-formal-cadence-v2',
         '7bea6d6d-stage-formal-cadence-v3', 'cjs-source-reuse-probe', 'cjs-source-reuse-probe-v2']
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    def add(path, name):
        original = path.read_bytes()
        data = original.decode('utf-16').encode('utf-8') if original.startswith((b'\xff\xfe', b'\xfe\xff')) else original
        if secret.encode() in data:
            redactions[name] = hashlib.sha256(original).hexdigest()
            data = data.replace(secret.encode(), b'<REDACTED>')
        assert secret.encode() not in data and secret.encode('utf-16-le') not in data
        entries[name] = hashlib.sha256(data).hexdigest()
        z.writestr(name, data)
    for name in roots:
        for path in sorted((tools / name).rglob('*')):
            if path.is_file() and path.suffix in {'.json', '.py', '.ps1', '.java', '.log', '.txt', '.patch', '.gradle'}:
                add(path, name + '/' + path.relative_to(tools / name).as_posix())
    for name in ['prepare-7bea6d6d-stage-cadence.py', 'ReloadStageAnalysis.java',
                 'CjsSourceReuseProbe.java', 'seal-7bea6d6d-cadence.py']:
        add(tools / name, 'tooling/' + name)
manifest = dict(revision='7bea6d6dcc9d0a70be6886f7ee1c79af9a9dae75', diagnosticOnly=True,
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    entries=entries, redactions=redactions,
    rawJfrExcluded='Raw JFR can contain JVM and environment properties; only derived stages and stacks are exported.',
    rawJfrSha256=hashlib.sha256((tools / roots[2] / 'session/reload.jfr').read_bytes()).hexdigest(),
    formalEvidenceSha256=hashlib.sha256((repo / 'docs/architecture-refactor/evidence/2026-10-22-source-facts-performance/evidence.zip').read_bytes()).hexdigest())
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size)))
