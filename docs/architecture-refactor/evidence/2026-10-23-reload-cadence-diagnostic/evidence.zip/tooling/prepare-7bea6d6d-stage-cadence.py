"""Install owned, temporary stage events in the isolated performance checkout."""
import hashlib
import json
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = tools / '7bea6d6d-stage-formal-cadence'
assert not out.exists()
assert subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True).strip() == ''
revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()
assert revision == '7bea6d6dcc9d0a70be6886f7ee1c79af9a9dae75'
out.mkdir()
event = '''
    @jdk.jfr.Name("neko.ReloadStage")
    @jdk.jfr.StackTrace(false)
    private static final class ReloadStage extends jdk.jfr.Event implements AutoCloseable {
        String stage;
        long wallNs;
        long cpuNs;
        private long startWall;
        private long startCpu;
        static ReloadStage begin(String name) {
            var event = new ReloadStage();
            event.stage = name;
            event.startCpu = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            event.startWall = System.nanoTime();
            event.begin();
            return event;
        }
        @Override public void close() {
            end();
            wallNs = System.nanoTime() - startWall;
            cpuNs = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime() - startCpu;
            commit();
        }
    }
'''
paths = ['src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java',
    'common/src/main/java/com/tkisor/nekojs/script/ScriptManager.java']
bindings = []
for relative in paths:
    path = tree / relative
    original = path.read_bytes()
    (out / path.name).write_bytes(original)
    source = original.decode('utf-8')
    if path.name == 'NekoJSCommands.java':
        edits = [('        NekoRuntimeRoot.ReloadResult reloadResult;\n        try {',
                  '        NekoRuntimeRoot.ReloadResult reloadResult;\n        try (var profile = ReloadStage.begin("command")) {')]
        for stage, line in [('root', '            reloadResult = root.reload(type);'),
                            ('recipe', '                    recipeBroadcast = applyRecipeScripts(source);')]:
            edits.append((line, f'            try (var stageProfile = ReloadStage.begin("{stage}")) {{\n'+line+'\n            }'))
    else:
        edits = [
            ('                    try {\n                        candidateEnvironment = createCandidateEnvironment(candidateGeneration);',
             '                    try (var stageProfile = ReloadStage.begin("preparation")) {\n                        candidateEnvironment = createCandidateEnvironment(candidateGeneration);'),
            ('                    try {\n                        environmentFactory.installEnvironmentBindings(',
             '                    try (var stageProfile = ReloadStage.begin("bindings")) {\n                        environmentFactory.installEnvironmentBindings('),
            ('                    try {\n                        candidateScripts = discoverWithPacks();',
             '                    try (var stageProfile = ReloadStage.begin("execution")) {\n                        candidateScripts = discoverWithPacks();'),
            ('                    commitGeneration(candidateGeneration, candidateEnvironment, candidateScripts, oldEnvironment);',
             '                    try (var stageProfile = ReloadStage.begin("commit")) {\n                    commitGeneration(candidateGeneration, candidateEnvironment, candidateScripts, oldEnvironment);\n                    }')]
    for before, after in edits:
        assert source.count(before) == 1, (relative, before)
        source = source.replace(before, after)
    end = source.rfind('\n}\n//?}')+1 if path.name == 'NekoJSCommands.java' else source.rfind('}')
    assert end > 0
    source = source[:end] + event + source[end:]
    path.write_text(source,encoding='utf-8',newline='\n')
    bindings.append(dict(path=relative,originalSha256=hashlib.sha256(original).hexdigest(),
        instrumentedSha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(out/'binding.json').write_text(json.dumps(dict(revision=revision,diagnosticOnly=True,bindings=bindings),indent=2)+'\n',encoding='utf-8')
(out/'instrumentation.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths],cwd=tree))

for relative in ['common/src/main/java/com/tkisor/nekojs/script/ScriptExecutor.java', 'src/main/java/com/tkisor/nekojs/mixin/RecipeManagerMixin.java']:
    path = tree/relative
    original = path.read_bytes()
    (out/path.name).write_bytes(original)
    source = original.decode('utf-8')
    if path.name == 'ScriptExecutor.java':
        edits=[]
        for stage,line in [('preflight','                validateGlobalBindings(ctx, script, moduleSession);'),('guest-entry','                    waitForEntryModule(ctx, script, requirePath, nodeRuntime);')]:
            edits.append((line,'                try (var profile = ReloadStage.begin("'+stage+'")) {\n'+line+'\n                }'))
    else:
        start='        var conditionalCodec = ConditionalOps.createConditionalCodec(Unit.CODEC);'
        finish='        int afterCount = this.nekojs$rawJsons.size();'
        edits=[(start,'        try (var profile = ReloadStage.begin("recipe-conditions")) {\n'+start), (finish,'        }\n'+finish),
            ('        List<RecipeHolder<?>> newHolders = new ArrayList<>();','        List<RecipeHolder<?>> newHolders = new ArrayList<>();\n        try (var profile = ReloadStage.begin("recipe-decode")) {'),
            ('        this.recipes = RecipeMap.create(newHolders);','        }\n        try (var profile = ReloadStage.begin("recipe-map")) {\n        this.recipes = RecipeMap.create(newHolders);\n        }')]
    for before,after in edits:
        assert source.count(before)==1,(relative,before)
        source=source.replace(before,after)
    end=source.rfind('\n}\n//?}')+1 if path.name=='RecipeManagerMixin.java' else source.rfind('}')
    assert end>0
    source=source[:end]+event+source[end:]
    path.write_text(source,encoding='utf-8',newline='\n')
    bindings.append(dict(path=relative,originalSha256=hashlib.sha256(original).hexdigest(),instrumentedSha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(out/'binding.json').write_text(json.dumps(dict(revision=revision,diagnosticOnly=True,bindings=bindings),indent=2)+'\n',encoding='utf-8')
(out/'instrumentation.patch').write_bytes(subprocess.check_output(['git','diff','--',*[r['path'] for r in bindings]],cwd=tree))
controller=(tools/'4405b0b0-stage-jfr-v2/diagnostic.ps1').read_text(encoding='utf-8')
controller=controller.replace('4405b0b0-stage-jfr-v2','7bea6d6d-stage-formal-cadence').replace('4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349',revision).replace("'4405b0b0'","'7bea6d6d'").replace(').Count -ne 2)',').Count -ne 4)')
anchor='    . ([ScriptBlock]::Create($definition.Extent.Text.Replace(\'$PSScriptRoot\', "\'$sampleDirectory\'")))'
assert anchor in controller
replacement='''    $source = $definition.Extent.Text.Replace('$PSScriptRoot', "'$sampleDirectory'")
    if ($definition.Name -eq 'Invoke-ServerSession') {
        $original = '/c gradlew.bat :$Node`:runServer --console=plain'
        if (-not $source.Contains($original)) { throw 'Launcher patch target missing' }
        $source = $source.Replace($original, $original + ' --offline --init-script D:/mcmodDemo/NekoJS-mult/build/priority-closeout/7bea6d6d-stage-formal-cadence/profile.init.gradle')
    }
    . ([ScriptBlock]::Create($source))'''
controller=controller.replace(anchor,replacement)
a=controller.index('        & "$javaRoot\\bin\\jcmd.exe" $gameId JFR.start')
b=controller.index('        $offset = ',a)
controller=controller[:a]+controller[b:]
controller=controller.replace('$pair -le 10','$pair -le 5').replace("$commands = if ($pair % 2) { @('list', 'nekojs reload') } else { @('nekojs reload', 'list') }","$commands = @('nekojs reload')")
a=controller.index('        if ($recording) {')
b=controller.index('        $stop = Stop-Server $proc',a)
controller=controller[:a]+controller[b:]
controller += "\nif (-not (Test-Path -LiteralPath (Join-Path $OutDir 'reload.jfr'))) { throw 'Recording missing' }\n"
(out/'diagnostic.ps1').write_text(controller,encoding='utf-8',newline='\n')
init='''gradle.projectsEvaluated {
    def node = gradle.rootProject.findProject(':26.1.2')
    def server = node.extensions.getByName('neoForge').runs.getByName('server')
    server.jvmArguments.add('-XX:StartFlightRecording=name=reloadStages,settings=profile,jdk.ExecutionSample#period=2ms,jdk.NativeMethodSample#period=2ms,filename=RECORDING,dumponexit=true')
}
'''.replace('RECORDING',(out/'session/reload.jfr').as_posix())
(out/'profile.init.gradle').write_text(init,encoding='utf-8',newline='\n')
(out/'run.py').write_bytes((tools/'4405b0b0-stage-jfr-v2/run.py').read_bytes())
(out/'analyze.py').write_bytes((tools/'4405b0b0-stage-jfr-v2/analyze.py').read_bytes())
print('EXACT_CADENCE_DIAGNOSTIC_PREPARED')
