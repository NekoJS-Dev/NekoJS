import graal.graalvm.polyglot.Context;
import graal.graalvm.polyglot.Engine;
import graal.graalvm.polyglot.Source;
import graal.graalvm.polyglot.Value;
import com.google.gson.GsonBuilder;
import java.nio.file.*;
import java.util.*;

/** Diagnostic only: compare compilation of the unchanged six CommonJS fixture bodies. */
public final class CjsSourceReuseProbe {
    public static void main(String[] args) throws Exception {
        Path fixtures = Path.of(args[0]);
        List<Path> files;
        try (var paths = Files.walk(fixtures)) {
            files = paths.filter(p -> p.toString().endsWith(".js")).sorted().toList();
        }
        var bodies = new ArrayList<String>();
        var sources = new ArrayList<Source>();
        for (Path file : files) {
            String body = Files.readString(file) + "\n//# sourceURL=" + fixtures.relativize(file).toString().replace('\\', '/');
            bodies.add(body);
            sources.add(Source.newBuilder("js", "(function anonymous(exports,require,module,__filename,__dirname\n) {\n" + body + "\n})", file.toString()).build());
        }
        var rows = new ArrayList<Map<String, Object>>();
        try (Engine engine = Engine.newBuilder().option("engine.WarnInterpreterOnly", "false").build()) {
            for (int round = 0; round < 24; round++) {
                for (boolean shared : round % 2 == 0 ? new boolean[]{false, true} : new boolean[]{true, false}) {
                    try (Context context = Context.newBuilder("js").engine(engine).allowExperimentalOptions(true)
                            .option("js.nashorn-compat", "true").option("js.ecmascript-version", "latest").option("js.strict", "true")
                            .option("js.v8-compat", "true").build()) {
                        Value factory = context.eval("js", "code => new Function('exports','require','module','__filename','__dirname',code)");
                        long start = System.nanoTime();
                        for (int i = 0; i < bodies.size(); i++) {
                            Value function = shared ? context.eval(sources.get(i)) : factory.execute(bodies.get(i));
                            if (!function.canExecute()) throw new AssertionError("Function not executable");
                        }
                        rows.add(Map.of("round", round, "warmup", round < 4, "sharedSource", shared,
                                "compileMs", (System.nanoTime() - start) / 1e6));
                    }
                }
            }
        }
        var result = new LinkedHashMap<String, Object>();
        result.put("diagnosticOnly", true);
        result.put("scope", "Compile-only, no module execution, filesystem authorization, Minecraft or formal performance gate");
        result.put("fixtures", files.stream().map(fixtures::relativize).map(Path::toString).toList());
        result.put("rows", rows);
        for (boolean shared : new boolean[]{false, true}) {
            var samples = rows.stream().filter(r -> r.get("sharedSource").equals(shared) && r.get("warmup").equals(false))
                    .mapToDouble(r -> (double) r.get("compileMs")).sorted().toArray();
            result.put(shared ? "sharedSourceMeanMs" : "functionConstructorMeanMs", Arrays.stream(samples).average().orElseThrow());
            result.put(shared ? "sharedSourceMedianMs" : "functionConstructorMedianMs", (samples[9] + samples[10]) / 2);
        }
        Files.writeString(Path.of(args[1]), new GsonBuilder().setPrettyPrinting().create().toJson(result));
        System.out.println("COMPILE_ONLY_PROBE_COMPLETE");
    }
}
