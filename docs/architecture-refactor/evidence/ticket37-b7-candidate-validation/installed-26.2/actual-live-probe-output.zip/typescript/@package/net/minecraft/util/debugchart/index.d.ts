import { $Enum, $String } from "java:java/lang";
import { $DebugSubscription } from "java:net/minecraft/util/debug";

declare module "java:net/minecraft/util/debugchart" {
    export class $AbstractSampleLogger implements $SampleLogger {
        logFullSample(arg0: number[]): void;
        logPartialSample(arg0: number, arg1: number): void;
        logSample(arg0: number): void;
    }

    export class $LocalSampleLogger extends $AbstractSampleLogger implements $SampleStorage {
        constructor(arg0: number);
        constructor(arg0: number, arg1: number[]);
        static CAPACITY: number;
        capacity(): number;
        get(arg0: number, arg1: number): number;
        get(arg0: number): number;
        reset(): void;
        size(): number;
    }

    export class $RemoteDebugSampleType {
        static TICK_TIME: $RemoteDebugSampleType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RemoteDebugSampleType[];
        static valueOf(name: string): $RemoteDebugSampleType;
    }

    export interface $SampleLogger {
        logFullSample(arg0: number[]): void;
        logPartialSample(arg0: number, arg1: number): void;
        logSample(arg0: number): void;
    }

    export interface $SampleStorage {
        capacity(): number;
        get(arg0: number, arg1: number): number;
        get(arg0: number): number;
        reset(): void;
        size(): number;
    }

    export type $RemoteDebugSampleType_ = $RemoteDebugSampleType | "TICK_TIME";
}
