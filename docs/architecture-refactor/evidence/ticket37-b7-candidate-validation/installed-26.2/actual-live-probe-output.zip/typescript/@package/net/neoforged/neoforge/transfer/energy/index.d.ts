import { $TransactionContext } from "java:net/neoforged/neoforge/transfer/transaction";

declare module "java:net/neoforged/neoforge/transfer/energy" {
    export interface $EnergyHandler {
        extract(arg0: number, arg1: $TransactionContext): number;
        getAmountAsInt(): number;
        getAmountAsLong(): number;
        getCapacityAsInt(): number;
        getCapacityAsLong(): number;
        insert(arg0: number, arg1: $TransactionContext): number;
    }

}
