import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener, $ClientboundAddEntityPacket } from "java:net/minecraft/network/protocol/game";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerEntity, $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $LightningBolt, $MoverType, $MoverType_, $SlotAccess } from "java:net/minecraft/world/entity";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Explosion } from "java:net/minecraft/world/level";
import { $Mirror, $Mirror_, $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $MapId } from "java:net/minecraft/world/level/saveddata/maps";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/decoration" {
    export class $BlockAttachedEntity extends $Entity {
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get pickable(): boolean;
        isPickable(): boolean;
        dropItem(arg0: $ServerLevel, arg1: $Entity): void;
        hurtClient(arg0: $DamageSource): boolean;
        hurtServer(arg0: $ServerLevel, arg1: $DamageSource, arg2: number): boolean;
        ignoreExplosion(arg0: $Explosion): boolean;
        move(arg0: $MoverType_, arg1: $Vec3_): void;
        push(arg0: number, arg1: number, arg2: number): void;
        refreshDimensions(): void;
        setPos(arg0: number, arg1: number, arg2: number): void;
        skipAttackInteraction(arg0: $Entity): boolean;
        survives(): boolean;
        thunderHit(arg0: $ServerLevel, arg1: $LightningBolt): void;
        tick(): void;
    }

    export class $HangingEntity extends $BlockAttachedEntity {
        get direction(): $Direction;
        getDirection(): $Direction;
        mirror(arg0: $Mirror_): number;
        onSyncedDataUpdated(arg0: $EntityDataAccessor<any>): void;
        playPlacementSound(): void;
        rotate(arg0: $Rotation_): number;
        spawnAtLocation(arg0: $ServerLevel, arg1: $ItemStack_, arg2: number): $ItemEntity;
        survives(): boolean;
    }

    export class $ItemFrame extends $HangingEntity {
        constructor(arg0: $EntityType<$ItemFrame>, arg1: $Level);
        constructor(arg0: $EntityType<$ItemFrame>, arg1: $Level, arg2: $BlockPos_, arg3: $Direction_);
        constructor(arg0: $Level, arg1: $BlockPos_, arg2: $Direction_);
        static NUM_ROTATIONS: number;
        get addItemSound(): $SoundEvent;
        getAddItemSound(): $SoundEvent;
        get analogOutput(): number;
        getAnalogOutput(): number;
        get breakSound(): $SoundEvent;
        getBreakSound(): $SoundEvent;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        set item(value: $ItemStack_);
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        get placeSound(): $SoundEvent;
        getPlaceSound(): $SoundEvent;
        get removeItemSound(): $SoundEvent;
        getRemoveItemSound(): $SoundEvent;
        get rotateItemSound(): $SoundEvent;
        getRotateItemSound(): $SoundEvent;
        get rotation(): number;
        getRotation(): number;
        set rotation(value: number);
        get visualRotationYInDegrees(): number;
        getVisualRotationYInDegrees(): number;
        dropItem(arg0: $ServerLevel, arg1: $Entity): void;
        getAddEntityPacket(arg0: $ServerEntity): $Packet<$ClientGamePacketListener>;
        getFramedMapId(arg0: $ItemStack_): $MapId;
        getSlot(arg0: number): $SlotAccess;
        hasFramedMap(): boolean;
        hurtClient(arg0: $DamageSource): boolean;
        hurtServer(arg0: $ServerLevel, arg1: $DamageSource, arg2: number): boolean;
        interact(arg0: $Player, arg1: $InteractionHand_, arg2: $Vec3_): $InteractionResult;
        kill(arg0: $ServerLevel): void;
        move(arg0: $MoverType_, arg1: $Vec3_): void;
        onSyncedDataUpdated(arg0: $EntityDataAccessor<any>): void;
        playPlacementSound(): void;
        push(arg0: number, arg1: number, arg2: number): void;
        recreateFromPacket(arg0: $ClientboundAddEntityPacket): void;
        setItem(arg0: $ItemStack_, arg1: boolean): void;
        shouldRenderAtSqrDistance(arg0: number): boolean;
        survives(): boolean;
    }

}
