import { $String } from "java:java/lang";
import { $Set } from "java:java/util";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/util/context" {
    export class $ContextKey<T> {
        constructor(arg0: $Identifier_);
        static vanilla<T>(arg0: string): $ContextKey<T>;
        name(): $Identifier;
        toString(): string;
    }

    export class $ContextKeySet {
        static EMPTY: $ContextKeySet;
        allowed(): $Set<$ContextKey<any>>;
        required(): $Set<$ContextKey<any>>;
        toString(): string;
    }

    export class $ContextMap {
        static EMPTY: $ContextMap;
        getOptional<T>(arg0: $ContextKey<T>): T;
        getOrDefault<T>(arg0: $ContextKey<T>, arg1: T): T;
        getOrThrow<T>(arg0: $ContextKey<T>): T;
        has(arg0: $ContextKey<any>): boolean;
    }

}
