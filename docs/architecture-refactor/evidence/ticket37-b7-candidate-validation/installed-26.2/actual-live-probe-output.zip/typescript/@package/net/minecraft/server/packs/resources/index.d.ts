import { $JsonElement } from "java:com/google/gson";
import { $Codec, $DynamicOps } from "java:com/mojang/serialization";
import { $BufferedReader, $InputStream } from "java:java/io";
import { $AutoCloseable, $String, $Void } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Collection, $List, $Map, $Optional, $Set } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $Consumer, $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $ZipEntry, $ZipFile } from "java:java/util/zip";
import { $FileToIdConverter, $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $PackResources } from "java:net/minecraft/server/packs";
import { $MetadataSectionType, $MetadataSectionType$WithValue } from "java:net/minecraft/server/packs/metadata";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $ContextAwareReloadListener } from "java:net/neoforged/neoforge/resource";

declare module "java:net/minecraft/server/packs/resources" {
    export interface $CloseableResourceManager extends $ResourceManager, $AutoCloseable {
        close(): void;
    }

    export interface $IoSupplier<T> {
        create(arg0: string): $IoSupplier<$InputStream>;
        create(arg0: $ZipFile, arg1: $ZipEntry): $IoSupplier<$InputStream>;
        get(): T;
    }

    export interface $PreparableReloadListener {
        getName(): string;
        prepareSharedState(arg0: $PreparableReloadListener$SharedState): void;
        reload(arg0: $PreparableReloadListener$SharedState, arg1: $Executor, arg2: $PreparableReloadListener$PreparationBarrier, arg3: $Executor): $CompletableFuture<void>;
    }

    export interface $PreparableReloadListener$PreparationBarrier {
        wait<T>(arg0: T): $CompletableFuture<T>;
    }

    export class $PreparableReloadListener$SharedState {
        constructor(arg0: $ResourceManager);
        get<T>(arg0: $PreparableReloadListener$StateKey<T>): T;
        resourceManager(): $ResourceManager;
        set<T>(arg0: $PreparableReloadListener$StateKey<T>, arg1: T): void;
    }

    export class $PreparableReloadListener$StateKey<T> {
        constructor();
    }

    export class $Resource {
        constructor(arg0: $PackResources, arg1: $IoSupplier<$InputStream>);
        constructor(arg0: $PackResources, arg1: $IoSupplier<$InputStream>, arg2: $IoSupplier<$ResourceMetadata>);
        knownPackInfo(): $Optional<$KnownPack>;
        metadata(): $ResourceMetadata;
        openAsReader(): $BufferedReader;
        open(): $InputStream;
        sourcePackId(): string;
        source(): $PackResources;
    }

    export interface $ResourceManager extends $ResourceProvider {
        getNamespaces(): $Set<string>;
        getResourceStack(arg0: $Identifier_): $List<$Resource>;
        listPacks(): $Stream<$PackResources>;
        listResourceStacks(arg0: string, arg1: $Predicate<$Identifier_>): $Map<$Identifier, $List<$Resource>>;
        listResources(arg0: string, arg1: $Predicate<$Identifier_>): $Map<$Identifier, $Resource>;
    }

    export interface $ResourceMetadata {
        fromJsonStream(arg0: $InputStream): $ResourceMetadata;
        getSection<T>(arg0: $MetadataSectionType<T>): $Optional<T>;
        getTypedSections(arg0: $MetadataSectionType<any>[]): $List<$MetadataSectionType$WithValue<any>>;
        getTypedSection<T>(arg0: $MetadataSectionType<T>): $Optional<$MetadataSectionType$WithValue<T>>;
        of<T1, T2>(arg0: $MetadataSectionType<T1>, arg1: T1, arg2: $MetadataSectionType<T2>, arg3: T2): $ResourceMetadata;
        of<T>(arg0: $MetadataSectionType<T>, arg1: T): $ResourceMetadata;
        static EMPTY: $ResourceMetadata;
        static EMPTY_SUPPLIER: $IoSupplier<$ResourceMetadata>;
    }

    export interface $ResourceProvider {
        fromMap(arg0: { [key: $Identifier_]: $Resource }): $ResourceProvider;
        getResourceOrThrow(arg0: $Identifier_): $Resource;
        getResource(arg0: $Identifier_): $Optional<$Resource>;
        openAsReader(arg0: $Identifier_): $BufferedReader;
        open(arg0: $Identifier_): $InputStream;
        static EMPTY: $ResourceProvider;
    }

    export class $SimpleJsonResourceReloadListener<T> extends $SimplePreparableReloadListener {
        static scanDirectoryWithModifier<T>(arg0: $ResourceManager, arg1: $FileToIdConverter, arg2: $DynamicOps<$JsonElement>, arg3: $Codec<T>, arg4: { [key: $Identifier_]: T }, arg5: $Consumer<{ [key: $Identifier_]: $JsonElement }>): void;
        static scanDirectoryWithOptionalValues<T>(arg0: $ResourceManager, arg1: $ResourceKey<$Registry<T>>, arg2: $DynamicOps<$JsonElement>, arg3: $Codec<$Optional<T>>, arg4: { [key: $Identifier_]: $Optional<T> }): void;
        static scanDirectory<T>(arg0: $ResourceManager, arg1: $FileToIdConverter, arg2: $DynamicOps<$JsonElement>, arg3: $Codec<T>, arg4: { [key: $Identifier_]: T }): void;
        static scanDirectory<T>(arg0: $ResourceManager, arg1: $ResourceKey<$Registry<T>>, arg2: $DynamicOps<$JsonElement>, arg3: $Codec<T>, arg4: { [key: $Identifier_]: T }): void;
    }

    export class $SimplePreparableReloadListener<T> extends $ContextAwareReloadListener implements $PreparableReloadListener {
        constructor();
        reload(arg0: $PreparableReloadListener$SharedState, arg1: $Executor, arg2: $PreparableReloadListener$PreparationBarrier, arg3: $Executor): $CompletableFuture<void>;
    }

}
