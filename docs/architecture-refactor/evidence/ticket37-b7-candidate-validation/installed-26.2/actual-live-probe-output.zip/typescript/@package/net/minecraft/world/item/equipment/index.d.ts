import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Integer, $Record, $String } from "java:java/lang";
import { $Map } from "java:java/util";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $EquipmentSlot, $EquipmentSlot_ } from "java:net/minecraft/world/entity";
import { $Item, $Item_ } from "java:net/minecraft/world/item";
import { $ItemAttributeModifiers } from "java:net/minecraft/world/item/component";

export * as trim from "java:net/minecraft/world/item/equipment/trim";

declare module "java:net/minecraft/world/item/equipment" {
    export class $ArmorMaterial extends $Record {
        constructor(durability: number, defense: { [key: $ArmorType_]: number }, enchantmentValue: number, equipSound: $Holder<$SoundEvent_>, toughness: number, knockbackResistance: number, repairIngredient: $TagKey<$Item_>, assetId: $ResourceKey<$EquipmentAsset>);
        assetId(): $ResourceKey<$EquipmentAsset>;
        createAttributes(arg0: $ArmorType_): $ItemAttributeModifiers;
        defense(): $Map<$ArmorType, number>;
        durability(): number;
        enchantmentValue(): number;
        equals(arg0: object): boolean;
        equipSound(): $Holder<$SoundEvent>;
        hashCode(): number;
        knockbackResistance(): number;
        repairIngredient(): $TagKey<$Item>;
        toString(): string;
        toughness(): number;
    }

    export class $ArmorType {
        static BODY: $ArmorType;
        static BOOTS: $ArmorType;
        static CHESTPLATE: $ArmorType;
        static HELMET: $ArmorType;
        static LEGGINGS: $ArmorType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ArmorType[];
        static valueOf(name: string): $ArmorType;
    }

    export class $EquipmentAsset {
        constructor();
    }

    export type $ArmorType_ = $ArmorType | "BODY" | "BOOTS" | "CHESTPLATE" | "HELMET" | "LEGGINGS";
}
