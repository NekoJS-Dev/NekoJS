import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Record, $String } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $SlotDisplay } from "java:net/minecraft/world/item/crafting/display";
import { $Fluid, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $FluidStack, $FluidStack_ } from "java:net/neoforged/neoforge/fluids";

declare module "java:net/neoforged/neoforge/fluids/crafting" {
    export class $FluidIngredient implements $Predicate {
        constructor();
        static CODEC: $Codec<$FluidIngredient>;
        static OPTIONAL_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Optional<$FluidIngredient>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FluidIngredient>;
        get type(): $FluidIngredientType<any>;
        getType(): $FluidIngredientType<any>;
        get simple(): boolean;
        isSimple(): boolean;
        static displayForSingleFluid(arg0: $Holder<$Fluid_>): $SlotDisplay;
        static of(arg0: $Stream<$Fluid_>): $FluidIngredient;
        static of(arg0: $HolderSet<$Fluid_>): $FluidIngredient;
        static of(arg0?: $Fluid_[]): $FluidIngredient;
        static of(arg0?: $FluidStack_[]): $FluidIngredient;
        display(): $SlotDisplay;
        equals(arg0: object): boolean;
        fluids(): $List<$Holder<$Fluid>>;
        hashCode(): number;
        test(arg0: $FluidStack_): boolean;
    }

    export class $FluidIngredientType<T extends $FluidIngredient> extends $Record {
        constructor(arg0: $MapCodec<T>);
        constructor(codec: $MapCodec<T>, streamCodec: $StreamCodec<any, T>);
        codec(): $MapCodec<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        streamCodec(): $StreamCodec<any, T>;
        toString(): string;
    }

    export class $SizedFluidIngredient {
        constructor(arg0: $FluidIngredient_, arg1: number);
        static CODEC: $Codec<$SizedFluidIngredient>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $SizedFluidIngredient>;
        static of(arg0: $Fluid_, arg1: number): $SizedFluidIngredient;
        amount(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        ingredient(): $FluidIngredient;
        test(arg0: $FluidStack_): boolean;
        toString(): string;
    }

    /** fluid:id | #tag | @mod | * | /regex/ | { fluid?|tag?|mod?|regex?|wildcard?|filter?|any?|all?|not?|ingredient? } */
    export type $FluidIngredient_ = $FluidIngredient | RegistryTypes.Fluid | `#${RegistryTypes.FluidTag}` | `@${RegistryTypes.Namespace}` | "*" | `/${string}` | $FluidIngredient_[] | $FluidStack | $Fluid | $NekoId | { fluid?: RegistryTypes.Fluid, tag?: RegistryTypes.FluidTag, mod?: RegistryTypes.Namespace, regex?: string, wildcard?: boolean, filter?: ((fluid: $FluidStack) => boolean), any?: $FluidIngredient_[], all?: $FluidIngredient_[], not?: $FluidIngredient_, ingredient?: $FluidIngredient_ };
    /** fluid:id | #tag | @mod | * | /regex/ | { ingredient|fluid|tag|mod|regex|wildcard|filter|any|all|not, amount } */
    export type $SizedFluidIngredient_ = $SizedFluidIngredient | RegistryTypes.Fluid | `#${RegistryTypes.FluidTag}` | `@${RegistryTypes.Namespace}` | "*" | `/${string}` | $FluidStack | $Fluid | $NekoId | { ingredient?: $SizedFluidIngredient_, fluid?: RegistryTypes.Fluid, tag?: RegistryTypes.FluidTag, mod?: RegistryTypes.Namespace, regex?: string, wildcard?: boolean, filter?: ((fluid: $FluidStack) => boolean), any?: $SizedFluidIngredient_[], all?: $SizedFluidIngredient_[], not?: $SizedFluidIngredient_, amount: number };
}
