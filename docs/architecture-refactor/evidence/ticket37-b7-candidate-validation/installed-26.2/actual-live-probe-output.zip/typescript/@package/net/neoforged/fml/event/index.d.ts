declare module "java:net/neoforged/fml/event" {
    export interface $IModBusEvent {
    }

}
