import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Integer, $String } from "java:java/lang";
import { $Optional, $UUID } from "java:java/util";
import { $Vec3i } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $Entity, $LivingEntity } from "java:net/minecraft/world/entity";
import { $AttributeModifier } from "java:net/minecraft/world/entity/ai/attributes";
import { $Item$Properties } from "java:net/minecraft/world/item";
import { $ChunkPos, $Level } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/waypoints" {
    export interface $PartialTickSupplier {
        apply(arg0: $Entity): number;
    }

    export class $TrackedWaypoint implements $Waypoint {
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $TrackedWaypoint>;
        static empty(arg0: string): $TrackedWaypoint;
        static setAzimuth(arg0: string, arg1: $Waypoint$Icon, arg2: number): $TrackedWaypoint;
        static setChunk(arg0: string, arg1: $Waypoint$Icon, arg2: $ChunkPos): $TrackedWaypoint;
        static setPosition(arg0: string, arg1: $Waypoint$Icon, arg2: $Vec3i): $TrackedWaypoint;
        distanceSquared(arg0: $Entity): number;
        icon(): $Waypoint$Icon;
        id(): $Either<$UUID, string>;
        pitchDirectionToCamera(arg0: $Level, arg1: $TrackedWaypoint$Projector, arg2: $PartialTickSupplier): $TrackedWaypoint$PitchDirection;
        update(arg0: $TrackedWaypoint): void;
        writeContents(arg0: $ByteBuf): void;
        write(arg0: $ByteBuf): void;
        yawAngleToCamera(arg0: $Level, arg1: $TrackedWaypoint$Camera, arg2: $PartialTickSupplier): number;
    }

    export interface $TrackedWaypoint$Camera {
        position(): $Vec3;
        yaw(): number;
    }

    export class $TrackedWaypoint$PitchDirection {
        static DOWN: $TrackedWaypoint$PitchDirection;
        static NONE: $TrackedWaypoint$PitchDirection;
        static UP: $TrackedWaypoint$PitchDirection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TrackedWaypoint$PitchDirection[];
        static valueOf(name: string): $TrackedWaypoint$PitchDirection;
    }

    export interface $TrackedWaypoint$Projector {
        projectHorizonToScreen(): number;
        projectPointToScreen(arg0: $Vec3_): $Vec3;
    }

    export interface $TrackedWaypointManager extends $WaypointManager {
    }

    export interface $Waypoint {
        addHideAttribute(arg0: $Item$Properties): $Item$Properties;
        static WAYPOINT_TRANSMIT_RANGE_HIDE_MODIFIER: $AttributeModifier;
    }

    export class $Waypoint$Icon {
        constructor();
        static CODEC: $Codec<$Waypoint$Icon>;
        static NULL: $Waypoint$Icon;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Waypoint$Icon>;
        color: $Optional<number>;
        style: $ResourceKey<$WaypointStyleAsset>;
        cloneAndAssignStyle(arg0: $LivingEntity): $Waypoint$Icon;
        copyFrom(arg0: $Waypoint$Icon): void;
        hasData(): boolean;
    }

    export interface $WaypointManager<T extends $Waypoint> {
        trackWaypoint(arg0: T): void;
        untrackWaypoint(arg0: T): void;
        updateWaypoint(arg0: T): void;
    }

    export class $WaypointStyleAsset {
        constructor();
    }

    export interface $WaypointTransmitter extends $Waypoint {
        doesSourceIgnoreReceiver(arg0: $LivingEntity, arg1: $ServerPlayer): boolean;
        isChunkVisible(arg0: $ChunkPos, arg1: $ServerPlayer): boolean;
        isReallyFar(arg0: $LivingEntity, arg1: $ServerPlayer): boolean;
        isTransmittingWaypoint(): boolean;
        makeWaypointConnectionWith(arg0: $ServerPlayer): $Optional<$WaypointTransmitter$Connection>;
        waypointIcon(): $Waypoint$Icon;
        static REALLY_FAR_DISTANCE: number;
    }

    export interface $WaypointTransmitter$Connection {
        connect(): void;
        disconnect(): void;
        isBroken(): boolean;
        update(): void;
    }

    export type $TrackedWaypoint$PitchDirection_ = $TrackedWaypoint$PitchDirection | "DOWN" | "NONE" | "UP";
}
