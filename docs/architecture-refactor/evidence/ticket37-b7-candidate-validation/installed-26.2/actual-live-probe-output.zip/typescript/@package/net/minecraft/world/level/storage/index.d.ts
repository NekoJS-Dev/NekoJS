import { $Codec, $DataResult, $Dynamic, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $File } from "java:java/io";
import { $AutoCloseable, $Comparable, $Enum, $Integer, $Iterable, $Long, $Record, $String } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Instant, $ZonedDateTime } from "java:java/time";
import { $Iterator, $List, $Optional, $Set, $UUID } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Stream } from "java:java/util/stream";
import { $CrashReportCategory } from "java:net/minecraft";
import { $BlockPos, $BlockPos_, $GlobalPos, $HolderLookup$Provider, $Registry, $RegistryAccess } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Component, $Component_, $MutableComponent } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $WorldLoader$PackConfig } from "java:net/minecraft/server";
import { $PackRepository } from "java:net/minecraft/server/packs/repository";
import { $NameAndId } from "java:net/minecraft/server/players";
import { $DataFixTypes, $DataFixTypes_ } from "java:net/minecraft/util/datafix";
import { $Difficulty, $Difficulty_ } from "java:net/minecraft/world";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $GameType, $GameType_, $Level, $LevelHeightAccessor, $LevelSettings, $WorldDataConfiguration } from "java:net/minecraft/world/level";
import { $LevelStem } from "java:net/minecraft/world/level/dimension";
import { $GameRules } from "java:net/minecraft/world/level/gamerules";
import { $WorldDimensions$Complete, $WorldGenSettings } from "java:net/minecraft/world/level/levelgen";
import { $SavedDataType } from "java:net/minecraft/world/level/saveddata";
import { $DirectoryValidator } from "java:net/minecraft/world/level/validation";
import { $ValueInputExtension, $ValueOutputExtension } from "java:net/neoforged/neoforge/common/extensions";
import { $IORunnable } from "java:org/apache/commons/io/function";

export * as loot from "java:net/minecraft/world/level/storage/loot";

declare module "java:net/minecraft/world/level/storage" {
    export class $CommandStorage {
        constructor(arg0: $SavedDataStorage);
        get(arg0: $Identifier_): $CompoundTag;
        keys(): $Stream<$Identifier>;
        set(arg0: $Identifier_, arg1: $CompoundTag_): void;
    }

    export class $DataVersion extends $Record {
        constructor(version: number, series: string);
        static MAIN_SERIES: string;
        get sideSeries(): boolean;
        isSideSeries(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        isCompatible(arg0: $DataVersion): boolean;
        series(): string;
        toString(): string;
        version(): number;
    }

    export interface $LevelData {
        fillCrashReportCategory(arg0: $CrashReportCategory, arg1: $LevelHeightAccessor): void;
        getDifficulty(): $Difficulty;
        getGameTime(): number;
        getRespawnData(): $LevelData$RespawnData;
        isDifficultyLocked(): boolean;
        isHardcore(): boolean;
    }

    export class $LevelData$RespawnData extends $Record {
        constructor(globalPos: $GlobalPos, yaw: number, pitch: number);
        static CODEC: $Codec<$LevelData$RespawnData>;
        static DEFAULT: $LevelData$RespawnData;
        static MAP_CODEC: $MapCodec<$LevelData$RespawnData>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $LevelData$RespawnData>;
        static of(arg0: $ResourceKey<$Level>, arg1: $BlockPos_, arg2: number, arg3: number): $LevelData$RespawnData;
        dimension(): $ResourceKey<$Level>;
        equals(arg0: object): boolean;
        globalPos(): $GlobalPos;
        hashCode(): number;
        pitch(): number;
        pos(): $BlockPos;
        toString(): string;
        yaw(): number;
    }

    export class $LevelDataAndDimensions extends $Record {
        constructor(worldDataAndGenSettings: $LevelDataAndDimensions$WorldDataAndGenSettings, dimensions: $WorldDimensions$Complete);
        static create(arg0: $WorldData, arg1: $WorldGenSettings, arg2: $WorldDimensions$Complete): $LevelDataAndDimensions;
        dimensions(): $WorldDimensions$Complete;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        worldDataAndGenSettings(): $LevelDataAndDimensions$WorldDataAndGenSettings;
    }

    export class $LevelDataAndDimensions$WorldDataAndGenSettings extends $Record {
        constructor(data: $WorldData, genSettings: $WorldGenSettings);
        data(): $WorldData;
        equals(arg0: object): boolean;
        genSettings(): $WorldGenSettings;
        hashCode(): number;
        toString(): string;
    }

    export class $LevelResource extends $Record {
        constructor(id: string);
        static DATA: $LevelResource;
        static DATAPACK_DIR: $LevelResource;
        static GENERATED_DIR: $LevelResource;
        static ICON_FILE: $LevelResource;
        static LEVEL_DATA_FILE: $LevelResource;
        static LOCK_FILE: $LevelResource;
        static MAP_RESOURCE_FILE: $LevelResource;
        static OLD_LEVEL_DATA_FILE: $LevelResource;
        static PLAYER_ADVANCEMENTS_DIR: $LevelResource;
        static PLAYER_DATA_DIR: $LevelResource;
        static PLAYER_OLD_DATA_DIR: $LevelResource;
        static PLAYER_STATS_DIR: $LevelResource;
        static ROOT: $LevelResource;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): string;
        toString(): string;
    }

    export class $LevelStorageSource {
        constructor(arg0: string, arg1: string, arg2: $DirectoryValidator, arg3: $DataFixer);
        static ALLOWED_SYMLINKS_CONFIG_NAME: string;
        static TAG_DATA: string;
        get backupPath(): $Path;
        getBackupPath(): $Path;
        get baseDir(): $Path;
        getBaseDir(): $Path;
        get name(): string;
        getName(): string;
        get worldDirValidator(): $DirectoryValidator;
        getWorldDirValidator(): $DirectoryValidator;
        static createDefault(arg0: string): $LevelStorageSource;
        static getLevelDataAndDimensions(arg0: $LevelStorageSource$LevelStorageAccess, arg1: $Dynamic<any>, arg2: $WorldDataConfiguration, arg3: $Registry<$LevelStem>, arg4: $HolderLookup$Provider): $LevelDataAndDimensions;
        static getPackConfig(arg0: $Dynamic<any>, arg1: $PackRepository, arg2: boolean): $WorldLoader$PackConfig;
        static parseValidator(arg0: string): $DirectoryValidator;
        static readDataConfig(arg0: $Dynamic<any>): $WorldDataConfiguration;
        static readExistingSavedData<T>(arg0: $LevelStorageSource$LevelStorageAccess, arg1: $HolderLookup$Provider, arg2: $SavedDataType<T>): $DataResult<T>;
        static writeGameRules(arg0: $WorldData, arg1: string, arg2: $GameRules): void;
        static writeWorldGenSettings(arg0: $RegistryAccess, arg1: string, arg2: $WorldGenSettings): void;
        createAccess(arg0: string): $LevelStorageSource$LevelStorageAccess;
        findLevelCandidates(): $LevelStorageSource$LevelCandidates;
        getLevelPath(arg0: string): $Path;
        isNewLevelIdAcceptable(arg0: string): boolean;
        levelExists(arg0: string): boolean;
        loadLevelSummaries(arg0: $LevelStorageSource$LevelCandidates): $CompletableFuture<$List<$LevelSummary>>;
        validateAndCreateAccess(arg0: string): $LevelStorageSource$LevelStorageAccess;
    }

    export class $LevelStorageSource$LevelCandidates extends $Record implements $Iterable {
        constructor(levels: $LevelStorageSource$LevelDirectory[]);
        get empty(): boolean;
        isEmpty(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        iterator(): $Iterator<$LevelStorageSource$LevelDirectory>;
        levels(): $List<$LevelStorageSource$LevelDirectory>;
        toString(): string;
    }

    export class $LevelStorageSource$LevelDirectory extends $Record {
        constructor(path: string);
        corruptedDataFile(arg0: $ZonedDateTime): $Path;
        dataFile(): $Path;
        directoryName(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        iconFile(): $Path;
        lockFile(): $Path;
        oldDataFile(): $Path;
        path(): $Path;
        rawDataFile(arg0: $ZonedDateTime): $Path;
        resourcePath(arg0: $LevelResource): $Path;
        toString(): string;
    }

    export class $LevelStorageSource$LevelStorageAccess implements $AutoCloseable {
        get iconFile(): $Optional<$Path>;
        getIconFile(): $Optional<$Path>;
        get levelDirectory(): $LevelStorageSource$LevelDirectory;
        getLevelDirectory(): $LevelStorageSource$LevelDirectory;
        get levelId(): string;
        getLevelId(): string;
        get unfixedDataTagWithFallback(): $Dynamic<any>;
        getUnfixedDataTagWithFallback(): $Dynamic<any>;
        get worldDir(): $Path;
        getWorldDir(): $Path;
        checkForLowDiskSpace(): boolean;
        close(): void;
        collectIssues(arg0: boolean): void;
        createPlayerStorage(): $PlayerDataStorage;
        deleteLevel(): void;
        estimateDiskSpace(): number;
        fixAndGetSummaryFromTag(arg0: $Dynamic<any>): $LevelSummary;
        fixAndGetSummary(): $LevelSummary;
        getDimensionPath(arg0: $ResourceKey<$Level>): $Path;
        getFileModificationTime(arg0: boolean): $Instant;
        getLevelPath(arg0: $LevelResource): $Path;
        getUnfixedDataTag(arg0: boolean): $Dynamic<any>;
        hasWorldData(): boolean;
        makeWorldBackup(): number;
        parent(): $LevelStorageSource;
        readAdditionalLevelSaveData(arg0: boolean): void;
        releaseTemporarilyAndRun(arg0: $IORunnable): void;
        renameAndDropPlayer(arg0: string): void;
        renameLevel(arg0: string): void;
        restoreLevelDataFromOld(): boolean;
        safeClose(): void;
        saveDataTag(arg0: $WorldData, arg1: string): void;
        saveDataTag(arg0: $WorldData): void;
        saveLevelData(arg0: $Dynamic<any>): void;
    }

    export class $LevelSummary implements $Comparable {
        constructor(arg0: $LevelSettings, arg1: $LevelVersion, arg2: string, arg3: boolean, arg4: boolean, arg5: boolean, arg6: boolean, arg7: string);
        static PLAY_WORLD: $Component;
        static UPGRADE_AND_PLAY_WORLD: $Component;
        get gameMode(): $GameType;
        getGameMode(): $GameType;
        get icon(): $Path;
        getIcon(): $Path;
        get info(): $Component;
        getInfo(): $Component;
        get lastPlayed(): number;
        getLastPlayed(): number;
        get levelId(): string;
        getLevelId(): string;
        get levelName(): string;
        getLevelName(): string;
        get settings(): $LevelSettings;
        getSettings(): $LevelSettings;
        get worldVersionName(): $MutableComponent;
        getWorldVersionName(): $MutableComponent;
        get compatible(): boolean;
        isCompatible(): boolean;
        get disabled(): boolean;
        isDisabled(): boolean;
        get downgrade(): boolean;
        isDowngrade(): boolean;
        get experimental(): boolean;
        isExperimental(): boolean;
        get hardcore(): boolean;
        isHardcore(): boolean;
        get locked(): boolean;
        isLocked(): boolean;
        backupStatus(): $LevelSummary$BackupStatus;
        canDelete(): boolean;
        canEdit(): boolean;
        canRecreate(): boolean;
        canUpload(): boolean;
        compareTo(arg0: $LevelSummary): number;
        hasCommands(): boolean;
        levelVersion(): $LevelVersion;
        primaryActionActive(): boolean;
        primaryActionMessage(): $Component;
        requiresFileFixing(): boolean;
        requiresManualConversion(): boolean;
        shouldBackup(): boolean;
    }

    export class $LevelSummary$BackupStatus {
        static DOWNGRADE: $LevelSummary$BackupStatus;
        static FILE_FIXING_REQUIRED: $LevelSummary$BackupStatus;
        static NONE: $LevelSummary$BackupStatus;
        static UPGRADE_TO_SNAPSHOT: $LevelSummary$BackupStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LevelSummary$BackupStatus[];
        static valueOf(name: string): $LevelSummary$BackupStatus;
    }

    export class $LevelVersion {
        static parse(arg0: $Dynamic<any>): $LevelVersion;
        lastPlayed(): number;
        levelDataVersion(): number;
        minecraftVersionName(): string;
        minecraftVersion(): $DataVersion;
        snapshot(): boolean;
    }

    export class $PlayerDataStorage {
        constructor(arg0: $LevelStorageSource$LevelStorageAccess, arg1: $DataFixer);
        get playerDir(): $File;
        getPlayerDir(): $File;
        load(arg0: $NameAndId): $Optional<$CompoundTag>;
        save(arg0: $Player): void;
    }

    export class $PrimaryLevelData$SpecialWorldProperty {
        static DEBUG: $PrimaryLevelData$SpecialWorldProperty;
        static FLAT: $PrimaryLevelData$SpecialWorldProperty;
        static NONE: $PrimaryLevelData$SpecialWorldProperty;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PrimaryLevelData$SpecialWorldProperty[];
        static valueOf(name: string): $PrimaryLevelData$SpecialWorldProperty;
    }

    export class $SavedDataStorage implements $AutoCloseable {
        constructor(arg0: string, arg1: $DataFixer, arg2: $HolderLookup$Provider);
        constructor(arg0: $ServerLevel, arg1: string, arg2: $DataFixer, arg3: $HolderLookup$Provider);
        close(): void;
        computeIfAbsent<T>(arg0: $SavedDataType<T>): T;
        get<T>(arg0: $SavedDataType<T>): T;
        readTagFromDisk(arg0: string, arg1: $DataFixTypes_, arg2: number): $CompoundTag;
        saveAndJoin(): void;
        scheduleSave(): $CompletableFuture<any>;
        set<T>(arg0: $SavedDataType<T>, arg1: T): void;
    }

    export interface $ServerLevelData extends $WritableLevelData {
        fillCrashReportCategory(arg0: $CrashReportCategory, arg1: $LevelHeightAccessor): void;
        getDayTimeFraction(): number;
        getDayTimePerTick(): number;
        getGameType(): $GameType;
        getLevelName(): string;
        isAllowCommands(): boolean;
        isInitialized(): boolean;
        setAllowCommands(arg0: boolean): void;
        setDayTimeFraction(arg0: number): void;
        setDayTimePerTick(arg0: number): void;
        setGameTime(arg0: number): void;
        setGameType(arg0: $GameType_): void;
        setInitialized(arg0: boolean): void;
    }

    export interface $ValueInput extends $ValueInputExtension {
        childOrEmpty(arg0: string): $ValueInput;
        childrenListOrEmpty(arg0: string): $ValueInput$ValueInputList;
        childrenList(arg0: string): $Optional<$ValueInput$ValueInputList>;
        child(arg0: string): $Optional<$ValueInput>;
        getBooleanOr(arg0: string, arg1: boolean): boolean;
        getByteOr(arg0: string, arg1: number): number;
        getDoubleOr(arg0: string, arg1: number): number;
        getFloatOr(arg0: string, arg1: number): number;
        getIntArray(arg0: string): $Optional<number[]>;
        getIntOr(arg0: string, arg1: number): number;
        getInt(arg0: string): $Optional<number>;
        getLongOr(arg0: string, arg1: number): number;
        getLong(arg0: string): $Optional<number>;
        getShortOr(arg0: string, arg1: number): number;
        getStringOr(arg0: string, arg1: string): string;
        getString(arg0: string): $Optional<string>;
        listOrEmpty<T>(arg0: string, arg1: $Codec<T>): $ValueInput$TypedInputList<T>;
        list<T>(arg0: string, arg1: $Codec<T>): $Optional<$ValueInput$TypedInputList<T>>;
        lookup(): $HolderLookup$Provider;
        read<T>(arg0: $MapCodec<T>): $Optional<T>;
        read<T>(arg0: string, arg1: $Codec<T>): $Optional<T>;
    }

    export interface $ValueInput$TypedInputList<T> extends $Iterable {
        isEmpty(): boolean;
        stream(): $Stream<T>;
    }

    export interface $ValueInput$ValueInputList extends $Iterable {
        isEmpty(): boolean;
        stream(): $Stream<$ValueInput>;
    }

    export interface $ValueOutput extends $ValueOutputExtension {
        childrenList(arg0: string): $ValueOutput$ValueOutputList;
        child(arg0: string): $ValueOutput;
        discard(arg0: string): void;
        isEmpty(): boolean;
        list<T>(arg0: string, arg1: $Codec<T>): $ValueOutput$TypedOutputList<T>;
        putBoolean(arg0: string, arg1: boolean): void;
        putByte(arg0: string, arg1: number): void;
        putDouble(arg0: string, arg1: number): void;
        putFloat(arg0: string, arg1: number): void;
        putIntArray(arg0: string, arg1: number[]): void;
        putInt(arg0: string, arg1: number): void;
        putLong(arg0: string, arg1: number): void;
        putShort(arg0: string, arg1: number): void;
        putString(arg0: string, arg1: string): void;
        storeNullable<T>(arg0: string, arg1: $Codec<T>, arg2: T): void;
        store<T>(arg0: $MapCodec<T>, arg1: T): void;
        store<T>(arg0: string, arg1: $Codec<T>, arg2: T): void;
    }

    export interface $ValueOutput$TypedOutputList<T> {
        add(arg0: T): void;
        isEmpty(): boolean;
    }

    export interface $ValueOutput$ValueOutputList {
        addChild(): $ValueOutput;
        discardLast(): void;
        isEmpty(): boolean;
    }

    export interface $WorldData {
        createTag(arg0: string): $CompoundTag;
        enabledFeatures(): $FeatureFlagSet;
        fillCrashReportCategory(arg0: $CrashReportCategory): void;
        getDataConfiguration(): $WorldDataConfiguration;
        getDifficulty(): $Difficulty;
        getGameType(): $GameType;
        getKnownServerBrands(): $Set<string>;
        getLevelName(): string;
        getLevelSettings(): $LevelSettings;
        getRemovedFeatureFlags(): $Set<string>;
        getSinglePlayerUUID(): $UUID;
        getStorageVersionName(arg0: number): string;
        getVersion(): number;
        isAllowCommands(): boolean;
        isDebugWorld(): boolean;
        isDifficultyLocked(): boolean;
        isFlatWorld(): boolean;
        isHardcore(): boolean;
        overworldData(): $ServerLevelData;
        setAllowCommands(arg0: boolean): void;
        setDataConfiguration(arg0: $WorldDataConfiguration): void;
        setDifficultyLocked(arg0: boolean): void;
        setDifficulty(arg0: $Difficulty_): void;
        setGameType(arg0: $GameType_): void;
        setModdedInfo(arg0: string, arg1: boolean): void;
        wasModded(): boolean;
        worldGenSettingsLifecycle(): $Lifecycle;
        static ANVIL_VERSION_ID: number;
        static MCREGION_VERSION_ID: number;
    }

    export interface $WritableLevelData extends $LevelData {
        setSpawn(arg0: $LevelData$RespawnData): void;
    }

    export type $LevelSummary$BackupStatus_ = $LevelSummary$BackupStatus | "DOWNGRADE" | "FILE_FIXING_REQUIRED" | "NONE" | "UPGRADE_TO_SNAPSHOT";
    export type $PrimaryLevelData$SpecialWorldProperty_ = $PrimaryLevelData$SpecialWorldProperty | "DEBUG" | "FLAT" | "NONE";
}
