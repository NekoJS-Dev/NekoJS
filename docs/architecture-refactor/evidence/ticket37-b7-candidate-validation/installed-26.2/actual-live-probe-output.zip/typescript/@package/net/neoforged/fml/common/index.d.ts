export * as asm from "java:net/neoforged/fml/common/asm";

