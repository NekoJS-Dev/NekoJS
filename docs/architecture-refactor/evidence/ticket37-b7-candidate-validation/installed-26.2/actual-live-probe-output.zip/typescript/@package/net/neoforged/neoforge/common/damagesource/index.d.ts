import { $Enum, $String } from "java:java/lang";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Difficulty, $Difficulty_ } from "java:net/minecraft/world";
import { $CombatEntry, $DamageSource } from "java:net/minecraft/world/damagesource";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $LivingShieldBlockEvent } from "java:net/neoforged/neoforge/event/entity/living";

declare module "java:net/neoforged/neoforge/common/damagesource" {
    export class $DamageContainer {
        constructor(arg0: $DamageSource, arg1: number);
        get blockedDamage(): number;
        getBlockedDamage(): number;
        set blockedDamage(value: $LivingShieldBlockEvent);
        get inflictedDamage(): number;
        getInflictedDamage(): number;
        get newDamage(): number;
        getNewDamage(): number;
        set newDamage(value: number);
        get originalDamage(): number;
        getOriginalDamage(): number;
        get postAttackInvulnerabilityTicks(): number;
        getPostAttackInvulnerabilityTicks(): number;
        set postAttackInvulnerabilityTicks(value: number);
        get shieldDamage(): number;
        getShieldDamage(): number;
        get source(): $DamageSource;
        getSource(): $DamageSource;
        addModifier(arg0: $DamageContainer$Reduction_, arg1: $IReductionFunction): void;
        captureInflictedDamage(): void;
        getReduction(arg0: $DamageContainer$Reduction_): number;
        setReduction(arg0: $DamageContainer$Reduction_, arg1: number): void;
        shouldCauseSideEffects(): boolean;
    }

    export class $DamageContainer$Reduction {
        static ABSORPTION: $DamageContainer$Reduction;
        static ARMOR: $DamageContainer$Reduction;
        static ENCHANTMENTS: $DamageContainer$Reduction;
        static INNATE_RESISTANCE: $DamageContainer$Reduction;
        static INVULNERABILITY: $DamageContainer$Reduction;
        static MOB_EFFECTS: $DamageContainer$Reduction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DamageContainer$Reduction[];
        static valueOf(name: string): $DamageContainer$Reduction;
    }

    export interface $IDeathMessageProvider {
        getDeathMessage(arg0: $LivingEntity, arg1: $CombatEntry, arg2: $CombatEntry): $Component;
        static DEFAULT: $IDeathMessageProvider;
    }

    export interface $IReductionFunction {
        modify(arg0: $DamageContainer, arg1: number): number;
    }

    export interface $IScalingFunction {
        scaleDamage(arg0: $DamageSource, arg1: $Player, arg2: number, arg3: $Difficulty_): number;
        static DEFAULT: $IScalingFunction;
    }

    export type $DamageContainer$Reduction_ = $DamageContainer$Reduction | "ABSORPTION" | "ARMOR" | "ENCHANTMENTS" | "INNATE_RESISTANCE" | "INVULNERABILITY" | "MOB_EFFECTS";
}
