export * as enderdragon from "java:net/minecraft/world/entity/boss/enderdragon";

