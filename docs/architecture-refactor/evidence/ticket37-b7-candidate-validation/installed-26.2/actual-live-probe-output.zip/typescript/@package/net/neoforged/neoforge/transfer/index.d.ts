import { $Class } from "java:java/lang";
import { $TransactionContext } from "java:net/neoforged/neoforge/transfer/transaction";

export * as energy from "java:net/neoforged/neoforge/transfer/energy";
export * as fluid from "java:net/neoforged/neoforge/transfer/fluid";
export * as item from "java:net/neoforged/neoforge/transfer/item";
export * as resource from "java:net/neoforged/neoforge/transfer/resource";
export * as transaction from "java:net/neoforged/neoforge/transfer/transaction";

declare module "java:net/neoforged/neoforge/transfer" {
    export interface $ResourceHandler<T extends $Resource> {
        asClass<T>(): $Class<$ResourceHandler<T>>;
        extract(arg0: T, arg1: number, arg2: $TransactionContext): number;
        extract(arg0: number, arg1: T, arg2: number, arg3: $TransactionContext): number;
        getAmountAsInt(arg0: number): number;
        getAmountAsLong(arg0: number): number;
        getCapacityAsInt(arg0: number, arg1: T): number;
        getCapacityAsLong(arg0: number, arg1: T): number;
        getResource(arg0: number): T;
        insert(arg0: T, arg1: number, arg2: $TransactionContext): number;
        insert(arg0: number, arg1: T, arg2: number, arg3: $TransactionContext): number;
        isValid(arg0: number, arg1: T): boolean;
        size(): number;
    }

}
