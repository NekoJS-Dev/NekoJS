import { $ArgumentType } from "java:com/mojang/brigadier/arguments";
import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $Boolean, $Class, $Enum, $Integer, $Record, $String } from "java:java/lang";
import { $Set } from "java:java/util";
import { $Predicate, $ToIntFunction } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $Registry } from "java:net/minecraft/core";
import { $MutableComponent } from "java:net/minecraft/network/chat";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $FeatureElement, $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";
import { $ExtensionInfo, $IExtensibleEnum } from "java:net/neoforged/fml/common/asm/enumextension";

declare module "java:net/minecraft/world/level/gamerules" {
    export class $GameRule<T> implements $FeatureElement {
        constructor(arg0: $GameRuleCategory, arg1: $GameRuleType_, arg2: $ArgumentType<T>, arg3: $GameRules$VisitorCaller<T>, arg4: $Codec<T>, arg5: $ToIntFunction<T>, arg6: T, arg7: $FeatureFlagSet);
        get descriptionId(): string;
        getDescriptionId(): string;
        get identifierWithFallback(): $Identifier;
        getIdentifierWithFallback(): $Identifier;
        get identifier(): $Identifier;
        getIdentifier(): $Identifier;
        argument(): $ArgumentType<T>;
        callVisitor(arg0: $GameRuleTypeVisitor): void;
        category(): $GameRuleCategory;
        defaultValue(): T;
        deserialize(arg0: string): $DataResult<T>;
        gameRuleType(): $GameRuleType;
        getCommandResult(arg0: T): number;
        id(): string;
        requiredFeatures(): $FeatureFlagSet;
        serialize(arg0: T): string;
        toString(): string;
        valueClass(): $Class<T>;
        valueCodec(): $Codec<T>;
    }

    export class $GameRuleCategory extends $Record {
        constructor(id: $Identifier_);
        static CHAT: $GameRuleCategory;
        static DROPS: $GameRuleCategory;
        static MISC: $GameRuleCategory;
        static MOBS: $GameRuleCategory;
        static PLAYER: $GameRuleCategory;
        static SPAWNING: $GameRuleCategory;
        static UPDATES: $GameRuleCategory;
        get descriptionId(): $Identifier;
        getDescriptionId(): $Identifier;
        static registerModdedCategories(): void;
        static register(arg0: $Identifier_): $GameRuleCategory;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        label(): $MutableComponent;
        toString(): string;
    }

    export class $GameRuleMap extends $SavedData {
        static CODEC: $Codec<$GameRuleMap>;
        static TYPE: $SavedDataType<$GameRuleMap>;
        static copyOf(arg0: $GameRuleMap): $GameRuleMap;
        static of(arg0: $Stream<$GameRule<any>>): $GameRuleMap;
        static of(): $GameRuleMap;
        equals(arg0: object): boolean;
        get<T>(arg0: $GameRule<T>): T;
        hashCode(): number;
        has(arg0: $GameRule<any>): boolean;
        keySet(): $Set<$GameRule<any>>;
        remove<T>(arg0: $GameRule<T>): T;
        reset<T>(arg0: $GameRule<T>): void;
        setFromIf(arg0: $GameRuleMap, arg1: $Predicate<$GameRule<any>>): void;
        set<T>(arg0: $GameRule<T>, arg1: T): void;
        size(): number;
        toString(): string;
        withOther(arg0: $GameRuleMap): $GameRuleMap;
    }

    export class $GameRuleType {
        static BOOL: $GameRuleType;
        static INT: $GameRuleType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GameRuleType[];
        static valueOf(name: string): $GameRuleType;
    }

    export interface $GameRuleTypeVisitor {
        visitBoolean(arg0: $GameRule<boolean>): void;
        visitInteger(arg0: $GameRule<number>): void;
        visit<T>(arg0: $GameRule<T>): void;
    }

    export class $GameRules {
        constructor(arg0: $GameRule<any>[]);
        constructor(arg0: $FeatureFlagSet);
        constructor(arg0: $FeatureFlagSet, arg1: $GameRuleMap);
        static ADVANCE_TIME: $GameRule<boolean>;
        static ADVANCE_WEATHER: $GameRule<boolean>;
        static ALLOW_ENTERING_NETHER_USING_PORTALS: $GameRule<boolean>;
        static BLOCK_DROPS: $GameRule<boolean>;
        static BLOCK_EXPLOSION_DROP_DECAY: $GameRule<boolean>;
        static COMMAND_BLOCKS_WORK: $GameRule<boolean>;
        static COMMAND_BLOCK_OUTPUT: $GameRule<boolean>;
        static DROWNING_DAMAGE: $GameRule<boolean>;
        static ELYTRA_MOVEMENT_CHECK: $GameRule<boolean>;
        static ENDER_PEARLS_VANISH_ON_DEATH: $GameRule<boolean>;
        static ENTITY_DROPS: $GameRule<boolean>;
        static FALL_DAMAGE: $GameRule<boolean>;
        static FIRE_DAMAGE: $GameRule<boolean>;
        static FIRE_SPREAD_RADIUS_AROUND_PLAYER: $GameRule<number>;
        static FORGIVE_DEAD_PLAYERS: $GameRule<boolean>;
        static FREEZE_DAMAGE: $GameRule<boolean>;
        static GLOBAL_SOUND_EVENTS: $GameRule<boolean>;
        static IMMEDIATE_RESPAWN: $GameRule<boolean>;
        static KEEP_INVENTORY: $GameRule<boolean>;
        static LAVA_SOURCE_CONVERSION: $GameRule<boolean>;
        static LIMITED_CRAFTING: $GameRule<boolean>;
        static LOCATOR_BAR: $GameRule<boolean>;
        static LOG_ADMIN_COMMANDS: $GameRule<boolean>;
        static MAX_BLOCK_MODIFICATIONS: $GameRule<number>;
        static MAX_COMMAND_FORKS: $GameRule<number>;
        static MAX_COMMAND_SEQUENCE_LENGTH: $GameRule<number>;
        static MAX_ENTITY_CRAMMING: $GameRule<number>;
        static MAX_MINECART_SPEED: $GameRule<number>;
        static MAX_SNOW_ACCUMULATION_HEIGHT: $GameRule<number>;
        static MOB_DROPS: $GameRule<boolean>;
        static MOB_EXPLOSION_DROP_DECAY: $GameRule<boolean>;
        static MOB_GRIEFING: $GameRule<boolean>;
        static NATURAL_HEALTH_REGENERATION: $GameRule<boolean>;
        static PLAYERS_NETHER_PORTAL_CREATIVE_DELAY: $GameRule<number>;
        static PLAYERS_NETHER_PORTAL_DEFAULT_DELAY: $GameRule<number>;
        static PLAYERS_SLEEPING_PERCENTAGE: $GameRule<number>;
        static PLAYER_MOVEMENT_CHECK: $GameRule<boolean>;
        static PROJECTILES_CAN_BREAK_BLOCKS: $GameRule<boolean>;
        static PVP: $GameRule<boolean>;
        static RAIDS: $GameRule<boolean>;
        static RANDOM_TICK_SPEED: $GameRule<number>;
        static REDUCED_DEBUG_INFO: $GameRule<boolean>;
        static RESPAWN_RADIUS: $GameRule<number>;
        static SEND_COMMAND_FEEDBACK: $GameRule<boolean>;
        static SHOW_ADVANCEMENT_MESSAGES: $GameRule<boolean>;
        static SHOW_DEATH_MESSAGES: $GameRule<boolean>;
        static SPAWNER_BLOCKS_WORK: $GameRule<boolean>;
        static SPAWN_MOBS: $GameRule<boolean>;
        static SPAWN_MONSTERS: $GameRule<boolean>;
        static SPAWN_PATROLS: $GameRule<boolean>;
        static SPAWN_PHANTOMS: $GameRule<boolean>;
        static SPAWN_WANDERING_TRADERS: $GameRule<boolean>;
        static SPAWN_WARDENS: $GameRule<boolean>;
        static SPECTATORS_GENERATE_CHUNKS: $GameRule<boolean>;
        static SPREAD_VINES: $GameRule<boolean>;
        static TNT_EXPLODES: $GameRule<boolean>;
        static TNT_EXPLOSION_DROP_DECAY: $GameRule<boolean>;
        static UNIVERSAL_ANGER: $GameRule<boolean>;
        static WATER_SOURCE_CONVERSION: $GameRule<boolean>;
        static bootstrap(arg0: $Registry<$GameRule<any>>): $GameRule<any>;
        static codec(arg0: $FeatureFlagSet): $Codec<$GameRules>;
        static registerBoolean(arg0: string, arg1: $GameRuleCategory, arg2: boolean): $GameRule<boolean>;
        static registerInteger(arg0: string, arg1: $GameRuleCategory, arg2: number, arg3: number, arg4: number, arg5: $FeatureFlagSet): $GameRule<number>;
        static registerInteger(arg0: string, arg1: $GameRuleCategory, arg2: number, arg3: number, arg4: number): $GameRule<number>;
        static registerInteger(arg0: string, arg1: $GameRuleCategory, arg2: number, arg3: number): $GameRule<number>;
        static register<T>(arg0: string, arg1: $GameRuleCategory, arg2: $GameRuleType_, arg3: $ArgumentType<T>, arg4: $Codec<T>, arg5: T, arg6: $FeatureFlagSet, arg7: $GameRules$VisitorCaller<T>, arg8: $ToIntFunction<T>): $GameRule<T>;
        availableRules(): $Stream<$GameRule<any>>;
        copy(arg0: $FeatureFlagSet): $GameRules;
        getAsString<T>(arg0: $GameRule<T>): string;
        get<T>(arg0: $GameRule<T>): T;
        setAll(arg0: $GameRuleMap, arg1: $MinecraftServer): void;
        setAll(arg0: $GameRules, arg1: $MinecraftServer): void;
        set<T>(arg0: $GameRule<T>, arg1: T, arg2: $MinecraftServer): void;
        visitGameRuleTypes(arg0: $GameRuleTypeVisitor): void;
    }

    export interface $GameRules$VisitorCaller<T> {
        call(arg0: $GameRuleTypeVisitor, arg1: $GameRule<T>): void;
    }

    export type $GameRuleType_ = $GameRuleType | "BOOL" | "INT";
}
