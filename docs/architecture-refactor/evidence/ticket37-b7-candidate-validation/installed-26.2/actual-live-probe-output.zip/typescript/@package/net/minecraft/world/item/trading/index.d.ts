import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $ArrayList, $Optional } from "java:java/util";
import { $UnaryOperator } from "java:java/util/function";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentExactPredicate, $DataComponentExactPredicate$Builder } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";

declare module "java:net/minecraft/world/item/trading" {
    export class $ItemCost extends $Record {
        constructor(arg0: $Holder<$Item_>, arg1: number, arg2: $DataComponentExactPredicate);
        constructor(item: $Holder<$Item_>, count: number, components: $DataComponentExactPredicate, itemStack: $ItemStack_);
        constructor(arg0: $ItemLike_);
        constructor(arg0: $ItemLike_, arg1: number);
        static CODEC: $Codec<$ItemCost>;
        static OPTIONAL_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Optional<$ItemCost>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemCost>;
        components(): $DataComponentExactPredicate;
        count(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        itemStack(): $ItemStack;
        item(): $Holder<$Item>;
        test(arg0: $ItemStack_): boolean;
        toString(): string;
        withComponents(arg0: $UnaryOperator<$DataComponentExactPredicate$Builder>): $ItemCost;
    }

    export interface $Merchant {
        canRestock(): boolean;
        getNotifyTradeSound(): $SoundEvent;
        getOffers(): $MerchantOffers;
        getTradingPlayer(): $Player;
        getVillagerXp(): number;
        isClientSide(): boolean;
        notifyTradeUpdated(arg0: $ItemStack_): void;
        notifyTrade(arg0: $MerchantOffer): void;
        openTradingScreen(arg0: $Player, arg1: $Component_, arg2: number): void;
        overrideOffers(arg0: $MerchantOffers): void;
        overrideXp(arg0: number): void;
        setTradingPlayer(arg0: $Player): void;
        showProgressBar(): boolean;
        stillValid(arg0: $Player): boolean;
    }

    export class $MerchantOffer {
        constructor(arg0: $ItemCost, arg1: $Optional<$ItemCost>, arg2: $ItemStack_, arg3: number, arg4: number, arg5: number);
        constructor(arg0: $ItemCost, arg1: $Optional<$ItemCost>, arg2: $ItemStack_, arg3: number, arg4: number, arg5: number, arg6: number);
        constructor(arg0: $ItemCost, arg1: $Optional<$ItemCost>, arg2: $ItemStack_, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number);
        constructor(arg0: $ItemCost, arg1: $ItemStack_, arg2: number, arg3: number, arg4: number);
        static CODEC: $Codec<$MerchantOffer>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $MerchantOffer>;
        get baseCostA(): $ItemStack;
        getBaseCostA(): $ItemStack;
        get costA(): $ItemStack;
        getCostA(): $ItemStack;
        get costB(): $ItemStack;
        getCostB(): $ItemStack;
        get demand(): number;
        getDemand(): number;
        get itemCostA(): $ItemCost;
        getItemCostA(): $ItemCost;
        get itemCostB(): $Optional<$ItemCost>;
        getItemCostB(): $Optional<$ItemCost>;
        get maxUses(): number;
        getMaxUses(): number;
        get priceMultiplier(): number;
        getPriceMultiplier(): number;
        get result(): $ItemStack;
        getResult(): $ItemStack;
        get specialPriceDiff(): number;
        getSpecialPriceDiff(): number;
        set specialPriceDiff(value: number);
        get uses(): number;
        getUses(): number;
        get xp(): number;
        getXp(): number;
        get outOfStock(): boolean;
        isOutOfStock(): boolean;
        static createFromStream(arg0: $RegistryFriendlyByteBuf): $MerchantOffer;
        addToSpecialPriceDiff(arg0: number): void;
        assemble(): $ItemStack;
        copy(): $MerchantOffer;
        increaseUses(): void;
        needsRestock(): boolean;
        resetSpecialPriceDiff(): void;
        resetUses(): void;
        satisfiedBy(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        setToOutOfStock(): void;
        shouldRewardExp(): boolean;
        take(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        updateDemand(): void;
    }

    export class $MerchantOffers extends $ArrayList {
        constructor();
        static CODEC: $Codec<$MerchantOffers>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $MerchantOffers>;
        copy(): $MerchantOffers;
        getRecipeFor(arg0: $ItemStack_, arg1: $ItemStack_, arg2: number): $MerchantOffer;
    }

}
