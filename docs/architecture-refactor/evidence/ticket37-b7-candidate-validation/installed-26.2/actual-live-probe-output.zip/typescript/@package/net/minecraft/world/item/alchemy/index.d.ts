import type { RegistryTypes } from "@special/types";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Holder, $Holder_, $RegistryAccess } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $MobEffectInstance } from "java:net/minecraft/world/effect";
import { $FeatureElement, $FeatureFlag, $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_ } from "java:net/minecraft/world/item/crafting";
import { $IBrewingRecipe } from "java:net/neoforged/neoforge/common/brewing";

declare module "java:net/minecraft/world/item/alchemy" {
    export class $Potion implements $FeatureElement {
        constructor(arg0: string, arg1?: $MobEffectInstance[]);
        static CODEC: $Codec<$Holder<$Potion>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$Potion>>;
        get effects(): $List<$MobEffectInstance>;
        getEffects(): $List<$MobEffectInstance>;
        hasInstantEffects(): boolean;
        name(): string;
        requiredFeatures(arg0?: $FeatureFlag[]): $Potion;
        requiredFeatures(): $FeatureFlagSet;
    }

    export class $PotionBrewing {
        static BREWING_TIME_SECONDS: number;
        static EMPTY: $PotionBrewing;
        get recipes(): $List<$IBrewingRecipe>;
        getRecipes(): $List<$IBrewingRecipe>;
        static addVanillaMixes(arg0: $PotionBrewing$Builder): void;
        static bootstrap(arg0: $FeatureFlagSet, arg1: $RegistryAccess): $PotionBrewing;
        static bootstrap(arg0: $FeatureFlagSet): $PotionBrewing;
        hasContainerMix(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        hasMix(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        hasPotionMix(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        isBrewablePotion(arg0: $Holder<$Potion_>): boolean;
        isContainerIngredient(arg0: $ItemStack_): boolean;
        isIngredient(arg0: $ItemStack_): boolean;
        isInput(arg0: $ItemStack_): boolean;
        isPotionIngredient(arg0: $ItemStack_): boolean;
        mix(arg0: $ItemStack_, arg1: $ItemStack_): $ItemStack;
    }

    export class $PotionBrewing$Builder {
        constructor(arg0: $FeatureFlagSet);
        addContainerRecipe(arg0: $Item_, arg1: $Item_, arg2: $Item_): void;
        addContainer(arg0: $Item_): void;
        addMix(arg0: $Holder<$Potion_>, arg1: $Item_, arg2: $Holder<$Potion_>): void;
        addRecipe(arg0: $Ingredient_, arg1: $Ingredient_, arg2: $ItemStack_): void;
        addRecipe(arg0: $IBrewingRecipe): void;
        addStartMix(arg0: $Item_, arg1: $Holder<$Potion_>): void;
        build(): $PotionBrewing;
    }

    export type $Potion_ = $Potion | RegistryTypes.Potion | $NekoId | string;
}
