import { $Runnable, $Void } from "java:java/lang";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Supplier } from "java:java/util/function";
import { $NotificationManager } from "java:net/minecraft/server/notifications";

declare module "java:net/minecraft/server/jsonrpc/internalapi" {
    export class $MinecraftApi {
        constructor(arg0: $NotificationManager, arg1: $MinecraftAllowListService, arg2: $MinecraftBanListService, arg3: $MinecraftPlayerListService, arg4: $MinecraftGameRuleService, arg5: $MinecraftOperatorListService, arg6: $MinecraftServerSettingsService, arg7: $MinecraftServerStateService, arg8: $MinecraftExecutorService);
        static of(arg0: $NotificationManager): $MinecraftApi;
        allowListService(): $MinecraftAllowListService;
        banListService(): $MinecraftBanListService;
        gameRuleService(): $MinecraftGameRuleService;
        notificationManager(): $NotificationManager;
        operatorListService(): $MinecraftOperatorListService;
        playerListService(): $MinecraftPlayerListService;
        serverSettingsService(): $MinecraftServerSettingsService;
        serverStateService(): $MinecraftServerStateService;
        submit(arg0: $Runnable): $CompletableFuture<void>;
        submit<V>(arg0: $Supplier<V>): $CompletableFuture<V>;
    }

}
