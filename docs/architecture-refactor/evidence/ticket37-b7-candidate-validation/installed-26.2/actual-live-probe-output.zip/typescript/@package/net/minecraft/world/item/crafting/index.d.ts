import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $IRecipeManagerExtension } from "java:com/tkisor/nekojs/api/recipe";
import { $ByteBuf } from "java:io/netty/buffer";
import { $IntList } from "java:it/unimi/dsi/fastutil/ints";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $Enum, $Iterable, $Record, $String } from "java:java/lang";
import { $Collection, $List, $Map, $Optional } from "java:java/util";
import { $BiFunction, $Consumer, $IntFunction, $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $Holder, $HolderSet, $Holder_, $NonNullList } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SimplePreparableReloadListener } from "java:net/minecraft/server/packs/resources";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $StackedContents$IngredientInfo, $StackedItemContents } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemStack, $ItemStackTemplate, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $RecipeDisplay, $RecipeDisplayEntry, $RecipeDisplayId, $SlotDisplay } from "java:net/minecraft/world/item/crafting/display";
import { $ItemLike, $ItemLike_, $Level } from "java:net/minecraft/world/level";
import { $WithConditions } from "java:net/neoforged/neoforge/common/conditions";
import { $ICustomIngredient } from "java:net/neoforged/neoforge/common/crafting";
import { $Logger } from "java:org/slf4j";

export * as display from "java:net/minecraft/world/item/crafting/display";

declare module "java:net/minecraft/world/item/crafting" {
    export class $AbstractCookingRecipe extends $SingleItemRecipe {
        constructor(arg0: $Recipe$CommonInfo, arg1: $AbstractCookingRecipe$CookingBookInfo, arg2: $Ingredient_, arg3: $ItemStackTemplate, arg4: number, arg5: number);
        get serializer(): $RecipeSerializer<$AbstractCookingRecipe>;
        getSerializer(): $RecipeSerializer<$AbstractCookingRecipe>;
        get type(): $RecipeType<$AbstractCookingRecipe>;
        getType(): $RecipeType<$AbstractCookingRecipe>;
        static cookingMapCodec<T>(arg0: $AbstractCookingRecipe$Factory<T>, arg1: number): $MapCodec<T>;
        static cookingStreamCodec<T>(arg0: $AbstractCookingRecipe$Factory<T>): $StreamCodec<$RegistryFriendlyByteBuf, T>;
        category(): $CookingBookCategory;
        cookingTime(): number;
        display(): $List<$RecipeDisplay>;
        experience(): number;
        group(): string;
    }

    export class $AbstractCookingRecipe$CookingBookInfo extends $Record implements $Recipe$BookInfo {
        constructor(category: $CookingBookCategory_, group: string);
        static MAP_CODEC: $MapCodec<$AbstractCookingRecipe$CookingBookInfo>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $AbstractCookingRecipe$CookingBookInfo>;
        category(): $CookingBookCategory;
        equals(arg0: object): boolean;
        group(): string;
        hashCode(): number;
        toString(): string;
    }

    export interface $AbstractCookingRecipe$Factory<T extends $AbstractCookingRecipe> {
        create(arg0: $Recipe$CommonInfo, arg1: $AbstractCookingRecipe$CookingBookInfo, arg2: $Ingredient_, arg3: $ItemStackTemplate, arg4: number, arg5: number): T;
    }

    export class $BlastingRecipe extends $AbstractCookingRecipe {
        constructor(arg0: $Recipe$CommonInfo, arg1: $AbstractCookingRecipe$CookingBookInfo, arg2: $Ingredient_, arg3: $ItemStackTemplate, arg4: number, arg5: number);
        static MAP_CODEC: $MapCodec<$BlastingRecipe>;
        static SERIALIZER: $RecipeSerializer<$BlastingRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $BlastingRecipe>;
        get serializer(): $RecipeSerializer<$BlastingRecipe>;
        getSerializer(): $RecipeSerializer<$BlastingRecipe>;
        get type(): $RecipeType<$BlastingRecipe>;
        getType(): $RecipeType<$BlastingRecipe>;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export class $CampfireCookingRecipe extends $AbstractCookingRecipe {
        constructor(arg0: $Recipe$CommonInfo, arg1: $AbstractCookingRecipe$CookingBookInfo, arg2: $Ingredient_, arg3: $ItemStackTemplate, arg4: number, arg5: number);
        static MAP_CODEC: $MapCodec<$CampfireCookingRecipe>;
        static SERIALIZER: $RecipeSerializer<$CampfireCookingRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $CampfireCookingRecipe>;
        get serializer(): $RecipeSerializer<$CampfireCookingRecipe>;
        getSerializer(): $RecipeSerializer<$CampfireCookingRecipe>;
        get type(): $RecipeType<$CampfireCookingRecipe>;
        getType(): $RecipeType<$CampfireCookingRecipe>;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export class $CookingBookCategory {
        static BLOCKS: $CookingBookCategory;
        static FOOD: $CookingBookCategory;
        static MISC: $CookingBookCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CookingBookCategory[];
        static valueOf(name: string): $CookingBookCategory;
    }

    export class $CraftingBookCategory {
        static BUILDING: $CraftingBookCategory;
        static EQUIPMENT: $CraftingBookCategory;
        static MISC: $CraftingBookCategory;
        static REDSTONE: $CraftingBookCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CraftingBookCategory[];
        static valueOf(name: string): $CraftingBookCategory;
    }

    export class $CraftingInput implements $RecipeInput {
        static EMPTY: $CraftingInput;
        get empty(): boolean;
        isEmpty(): boolean;
        static ofPositioned(arg0: number, arg1: number, arg2: $ItemStack_[]): $CraftingInput$Positioned;
        static of(arg0: number, arg1: number, arg2: $ItemStack_[]): $CraftingInput;
        equals(arg0: object): boolean;
        getItem(arg0: number, arg1: number): $ItemStack;
        getItem(arg0: number): $ItemStack;
        hashCode(): number;
        height(): number;
        ingredientCount(): number;
        items(): $List<$ItemStack>;
        size(): number;
        stackedContents(): $StackedItemContents;
        width(): number;
    }

    export class $CraftingInput$Positioned extends $Record {
        constructor(input: $CraftingInput, left: number, top: number);
        static EMPTY: $CraftingInput$Positioned;
        equals(arg0: object): boolean;
        hashCode(): number;
        input(): $CraftingInput;
        left(): number;
        toString(): string;
        top(): number;
    }

    export interface $CraftingRecipe extends $Recipe {
        category(): $CraftingBookCategory;
        defaultCraftingReminder(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        getSerializer(): $RecipeSerializer<$CraftingRecipe>;
        getType(): $RecipeType<$CraftingRecipe>;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export interface $ExtendedRecipeBookCategory {
    }

    export class $Ingredient implements $Predicate, $StackedContents$IngredientInfo {
        constructor(arg0: $ICustomIngredient);
        static CODEC: $Codec<$Ingredient>;
        static CONTENTS_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Ingredient>;
        static NON_AIR_HOLDER_SET_CODEC: $Codec<$HolderSet<$Item>>;
        static OPTIONAL_CONTENTS_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Optional<$Ingredient>>;
        values: $HolderSet<$Item>;
        get customIngredient(): $ICustomIngredient;
        getCustomIngredient(): $ICustomIngredient;
        get values(): $HolderSet<$Item>;
        getValues(): $HolderSet<$Item>;
        get custom(): boolean;
        isCustom(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        get simple(): boolean;
        isSimple(): boolean;
        static displayForSingleItem(arg0: $Holder<$Item_>): $SlotDisplay;
        static of(arg0: $Stream<$ItemLike_>): $Ingredient;
        static of(arg0: $HolderSet<$Item_>): $Ingredient;
        static of(arg0?: $ItemLike_[]): $Ingredient;
        static of(arg0: $ItemLike_): $Ingredient;
        static optionalIngredientToDisplay(arg0: $Optional<$Ingredient_>): $SlotDisplay;
        static testOptionalIngredient(arg0: $Optional<$Ingredient_>, arg1: $ItemStack_): boolean;
        acceptsItem(arg0: $Holder<$Item_>): boolean;
        display(): $SlotDisplay;
        equals(arg0: object): boolean;
        hashCode(): number;
        items(): $Stream<$Holder<$Item>>;
        test(arg0: $ItemStack_): boolean;
    }

    export class $PlacementInfo {
        static EMPTY_SLOT: number;
        static NOT_PLACEABLE: $PlacementInfo;
        get impossibleToPlace(): boolean;
        isImpossibleToPlace(): boolean;
        static createFromOptionals(arg0: $Optional<$Ingredient_>[]): $PlacementInfo;
        static create(arg0: $Ingredient_[]): $PlacementInfo;
        static create(arg0: $Ingredient_): $PlacementInfo;
        ingredients(): $List<$Ingredient>;
        slotsToIngredientIndex(): $IntList;
    }

    export interface $Recipe<T extends $RecipeInput> {
        assemble(arg0: T): $ItemStack;
        display(): $List<$RecipeDisplay>;
        getSerializer(): $RecipeSerializer<$Recipe<T>>;
        getType(): $RecipeType<$Recipe<T>>;
        group(): string;
        isSpecial(): boolean;
        matches(arg0: T, arg1: $Level): boolean;
        placementInfo(): $PlacementInfo;
        recipeBookCategory(): $RecipeBookCategory;
        showNotification(): boolean;
        static CODEC: $Codec<$Recipe<any>>;
        static CONDITIONAL_CODEC: $Codec<$Optional<$WithConditions<$Recipe<any>>>>;
        static KEY_CODEC: $Codec<$ResourceKey<$Recipe<any>>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Recipe<any>>;
    }

    export interface $Recipe$BookInfo<CategoryType> {
        category(): CategoryType;
        group(): string;
        mapCodec<CategoryType, SelfType>(arg0: $Codec<CategoryType>, arg1: CategoryType, arg2: $Recipe$BookInfo$Constructor<CategoryType, SelfType>): $MapCodec<SelfType>;
        streamCodec<CategoryType, SelfType>(arg0: $StreamCodec<any, CategoryType>, arg1: $Recipe$BookInfo$Constructor<CategoryType, SelfType>): $StreamCodec<$RegistryFriendlyByteBuf, SelfType>;
    }

    export interface $Recipe$BookInfo$Constructor<CategoryType, SelfType extends $Recipe$BookInfo<CategoryType>> extends $BiFunction {
    }

    export class $Recipe$CommonInfo extends $Record {
        constructor(showNotification: boolean);
        static MAP_CODEC: $MapCodec<$Recipe$CommonInfo>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Recipe$CommonInfo>;
        equals(arg0: object): boolean;
        hashCode(): number;
        showNotification(): boolean;
        toString(): string;
    }

    export interface $RecipeAccess {
        propertySet(arg0: $ResourceKey<$RecipePropertySet>): $RecipePropertySet;
        stonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
    }

    export class $RecipeBookCategory implements $ExtendedRecipeBookCategory {
        constructor();
    }

    export class $RecipeHolder<T extends $Recipe<any>> extends $Record {
        constructor(id: $ResourceKey<$Recipe<any>>, value: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $RecipeHolder<any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $ResourceKey<$Recipe<any>>;
        toString(): string;
        value(): T;
    }

    export interface $RecipeInput {
        getItem(arg0: number): $ItemStack;
        isEmpty(): boolean;
        size(): number;
    }

    export class $RecipeManager extends $SimplePreparableReloadListener implements $RecipeAccess, $IRecipeManagerExtension {
        constructor(arg0: $HolderLookup$Provider);
        static LOGGER: $Logger;
        get recipes(): $Collection<$RecipeHolder<any>>;
        getRecipes(): $Collection<$RecipeHolder<any>>;
        get synchronizedItemProperties(): $Map<$ResourceKey<$RecipePropertySet>, $RecipePropertySet>;
        getSynchronizedItemProperties(): $Map<$ResourceKey<$RecipePropertySet>, $RecipePropertySet>;
        get synchronizedStonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
        getSynchronizedStonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
        static createCheck<I, T>(arg0: $RecipeType<T>): $RecipeManager$CachedCheck<I, T>;
        byKey(arg0: $ResourceKey<$Recipe<any>>): $Optional<$RecipeHolder<any>>;
        finalizeRecipeLoading(arg0: $FeatureFlagSet): void;
        getRecipeFor<I, T>(arg0: $RecipeType<T>, arg1: I, arg2: $Level, arg3: $ResourceKey<$Recipe<any>>): $Optional<$RecipeHolder<T>>;
        getRecipeFor<I, T>(arg0: $RecipeType<T>, arg1: I, arg2: $Level, arg3: $RecipeHolder<T>): $Optional<$RecipeHolder<T>>;
        getRecipeFor<I, T>(arg0: $RecipeType<T>, arg1: I, arg2: $Level): $Optional<$RecipeHolder<T>>;
        getRecipeFromDisplay(arg0: $RecipeDisplayId): $RecipeManager$ServerDisplayInfo;
        listDisplaysForRecipe(arg0: $ResourceKey<$Recipe<any>>, arg1: $Consumer<$RecipeDisplayEntry>): void;
        nekojs$applyScripts(): void;
        propertySet(arg0: $ResourceKey<$RecipePropertySet>): $RecipePropertySet;
        recipeMap(): $RecipeMap;
        stonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
    }

    export interface $RecipeManager$CachedCheck<I extends $RecipeInput, T extends $Recipe<I>> {
        getRecipeFor(arg0: I, arg1: $ServerLevel): $Optional<$RecipeHolder<T>>;
    }

    export class $RecipeManager$ServerDisplayInfo extends $Record {
        constructor(display: $RecipeDisplayEntry, parent: $RecipeHolder<any>);
        display(): $RecipeDisplayEntry;
        equals(arg0: object): boolean;
        hashCode(): number;
        parent(): $RecipeHolder<any>;
        toString(): string;
    }

    export class $RecipeMap {
        static EMPTY: $RecipeMap;
        static create(arg0: $Iterable<$RecipeHolder<any>>): $RecipeMap;
        byKey(arg0: $ResourceKey<$Recipe<any>>): $RecipeHolder<any>;
        byType<I, T>(arg0: $RecipeType<T>): $Collection<$RecipeHolder<T>>;
        getRecipesFor<I, T>(arg0: $RecipeType<T>, arg1: I, arg2: $Level): $Stream<$RecipeHolder<T>>;
        order(arg0: $Object2IntMap<$ResourceKey<$Recipe<any>>>): void;
        values(): $Collection<$RecipeHolder<any>>;
    }

    export class $RecipePropertySet {
        static BLAST_FURNACE_INPUT: $ResourceKey<$RecipePropertySet>;
        static CAMPFIRE_INPUT: $ResourceKey<$RecipePropertySet>;
        static EMPTY: $RecipePropertySet;
        static FURNACE_INPUT: $ResourceKey<$RecipePropertySet>;
        static SMITHING_ADDITION: $ResourceKey<$RecipePropertySet>;
        static SMITHING_BASE: $ResourceKey<$RecipePropertySet>;
        static SMITHING_TEMPLATE: $ResourceKey<$RecipePropertySet>;
        static SMOKER_INPUT: $ResourceKey<$RecipePropertySet>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $RecipePropertySet>;
        static TYPE_KEY: $ResourceKey<$Registry<$RecipePropertySet>>;
        static create(arg0: $Ingredient_[]): $RecipePropertySet;
        test(arg0: $ItemStack_): boolean;
    }

    export class $RecipeSerializer<T extends $Recipe<any>> extends $Record {
        constructor(codec: $MapCodec<T>, streamCodec: $StreamCodec<$RegistryFriendlyByteBuf, T>);
        codec(): $MapCodec<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, T>;
        toString(): string;
    }

    export interface $RecipeType<T extends $Recipe<any>> {
        register<T>(arg0: string): $RecipeType<T>;
        simple<T>(arg0: $Identifier_): $RecipeType<T>;
        static BLASTING: $RecipeType<$BlastingRecipe>;
        static CAMPFIRE_COOKING: $RecipeType<$CampfireCookingRecipe>;
        static CRAFTING: $RecipeType<$CraftingRecipe>;
        static SMELTING: $RecipeType<$SmeltingRecipe>;
        static SMITHING: $RecipeType<$SmithingRecipe>;
        static SMOKING: $RecipeType<$SmokingRecipe>;
        static STONECUTTING: $RecipeType<$StonecutterRecipe>;
    }

    export class $SelectableRecipe<T extends $Recipe<any>> extends $Record {
        constructor(optionDisplay: $SlotDisplay, recipe: $Optional<$RecipeHolder<T>>);
        static noRecipeCodec<T>(): $StreamCodec<$RegistryFriendlyByteBuf, $SelectableRecipe<T>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        optionDisplay(): $SlotDisplay;
        recipe(): $Optional<$RecipeHolder<T>>;
        toString(): string;
    }

    export class $SelectableRecipe$SingleInputEntry<T extends $Recipe<any>> extends $Record {
        constructor(input: $Ingredient_, recipe: $SelectableRecipe<T>);
        static noRecipeCodec<T>(): $StreamCodec<$RegistryFriendlyByteBuf, $SelectableRecipe$SingleInputEntry<T>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        input(): $Ingredient;
        recipe(): $SelectableRecipe<T>;
        toString(): string;
    }

    export class $SelectableRecipe$SingleInputSet<T extends $Recipe<any>> extends $Record {
        constructor(entries: $SelectableRecipe$SingleInputEntry<T>[]);
        get empty(): boolean;
        isEmpty(): boolean;
        static empty<T>(): $SelectableRecipe$SingleInputSet<T>;
        static noRecipeCodec<T>(): $StreamCodec<$RegistryFriendlyByteBuf, $SelectableRecipe$SingleInputSet<T>>;
        acceptsInput(arg0: $ItemStack_): boolean;
        entries(): $List<$SelectableRecipe$SingleInputEntry<T>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        selectByInput(arg0: $ItemStack_): $SelectableRecipe$SingleInputSet<T>;
        size(): number;
        toString(): string;
    }

    export class $SingleItemRecipe implements $Recipe {
        constructor(arg0: $Recipe$CommonInfo, arg1: $Ingredient_, arg2: $ItemStackTemplate);
        result: $ItemStackTemplate;
        get serializer(): $RecipeSerializer<$SingleItemRecipe>;
        getSerializer(): $RecipeSerializer<$SingleItemRecipe>;
        get type(): $RecipeType<$SingleItemRecipe>;
        getType(): $RecipeType<$SingleItemRecipe>;
        static simpleMapCodec<T>(arg0: $SingleItemRecipe$Factory<T>): $MapCodec<T>;
        static simpleStreamCodec<T>(arg0: $SingleItemRecipe$Factory<T>): $StreamCodec<$RegistryFriendlyByteBuf, T>;
        assemble(arg0: $SingleRecipeInput): $ItemStack;
        input(): $Ingredient;
        matches(arg0: $SingleRecipeInput, arg1: $Level): boolean;
        placementInfo(): $PlacementInfo;
        result(): $ItemStackTemplate;
        showNotification(): boolean;
    }

    export interface $SingleItemRecipe$Factory<T extends $SingleItemRecipe> {
        create(arg0: $Recipe$CommonInfo, arg1: $Ingredient_, arg2: $ItemStackTemplate): T;
    }

    export class $SingleRecipeInput extends $Record implements $RecipeInput {
        constructor(item: $ItemStack_);
        equals(arg0: object): boolean;
        getItem(arg0: number): $ItemStack;
        hashCode(): number;
        item(): $ItemStack;
        size(): number;
        toString(): string;
    }

    export class $SmeltingRecipe extends $AbstractCookingRecipe {
        constructor(arg0: $Recipe$CommonInfo, arg1: $AbstractCookingRecipe$CookingBookInfo, arg2: $Ingredient_, arg3: $ItemStackTemplate, arg4: number, arg5: number);
        static MAP_CODEC: $MapCodec<$SmeltingRecipe>;
        static SERIALIZER: $RecipeSerializer<$SmeltingRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $SmeltingRecipe>;
        get serializer(): $RecipeSerializer<$SmeltingRecipe>;
        getSerializer(): $RecipeSerializer<$SmeltingRecipe>;
        get type(): $RecipeType<$SmeltingRecipe>;
        getType(): $RecipeType<$SmeltingRecipe>;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export interface $SmithingRecipe extends $Recipe {
        additionIngredient(): $Optional<$Ingredient>;
        baseIngredient(): $Ingredient;
        getSerializer(): $RecipeSerializer<$SmithingRecipe>;
        getType(): $RecipeType<$SmithingRecipe>;
        matches(arg0: $SmithingRecipeInput, arg1: $Level): boolean;
        recipeBookCategory(): $RecipeBookCategory;
        templateIngredient(): $Optional<$Ingredient>;
    }

    export class $SmithingRecipeInput extends $Record implements $RecipeInput {
        constructor(template: $ItemStack_, base: $ItemStack_, addition: $ItemStack_);
        get empty(): boolean;
        isEmpty(): boolean;
        addition(): $ItemStack;
        base(): $ItemStack;
        equals(arg0: object): boolean;
        getItem(arg0: number): $ItemStack;
        hashCode(): number;
        size(): number;
        template(): $ItemStack;
        toString(): string;
    }

    export class $SmokingRecipe extends $AbstractCookingRecipe {
        constructor(arg0: $Recipe$CommonInfo, arg1: $AbstractCookingRecipe$CookingBookInfo, arg2: $Ingredient_, arg3: $ItemStackTemplate, arg4: number, arg5: number);
        static MAP_CODEC: $MapCodec<$SmokingRecipe>;
        static SERIALIZER: $RecipeSerializer<$SmokingRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $SmokingRecipe>;
        get serializer(): $RecipeSerializer<$SmokingRecipe>;
        getSerializer(): $RecipeSerializer<$SmokingRecipe>;
        get type(): $RecipeType<$SmokingRecipe>;
        getType(): $RecipeType<$SmokingRecipe>;
        recipeBookCategory(): $RecipeBookCategory;
    }

    export class $StonecutterRecipe extends $SingleItemRecipe {
        constructor(arg0: $Recipe$CommonInfo, arg1: $Ingredient_, arg2: $ItemStackTemplate);
        static MAP_CODEC: $MapCodec<$StonecutterRecipe>;
        static SERIALIZER: $RecipeSerializer<$StonecutterRecipe>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $StonecutterRecipe>;
        get serializer(): $RecipeSerializer<$StonecutterRecipe>;
        getSerializer(): $RecipeSerializer<$StonecutterRecipe>;
        get type(): $RecipeType<$StonecutterRecipe>;
        getType(): $RecipeType<$StonecutterRecipe>;
        display(): $List<$RecipeDisplay>;
        group(): string;
        recipeBookCategory(): $RecipeBookCategory;
        resultDisplay(): $SlotDisplay;
    }

    export type $CookingBookCategory_ = $CookingBookCategory | "BLOCKS" | "FOOD" | "MISC";
    export type $CraftingBookCategory_ = $CraftingBookCategory | "BUILDING" | "EQUIPMENT" | "MISC" | "REDSTONE";
    /** item:id | #tag | @mod | * | /regex/ | { item?|tag?|mod?|regex?|wildcard?|filter?|any?|all?|not? } */
    export type $Ingredient_ = $Ingredient | RegistryTypes.Item | `#${RegistryTypes.ItemTag}` | `@${RegistryTypes.Namespace}` | "*" | `/${string}` | $Ingredient_[] | $ItemStack | $Item | $NekoId | { item?: RegistryTypes.Item, tag?: RegistryTypes.ItemTag, mod?: RegistryTypes.Namespace, regex?: string, wildcard?: boolean, filter?: ((item: $ItemStack) => boolean), any?: $Ingredient_[], all?: $Ingredient_[], not?: $Ingredient_ };
    export type $RecipeBookCategory_ = $RecipeBookCategory | RegistryTypes.RecipeBookCategory | $NekoId | string;
}
