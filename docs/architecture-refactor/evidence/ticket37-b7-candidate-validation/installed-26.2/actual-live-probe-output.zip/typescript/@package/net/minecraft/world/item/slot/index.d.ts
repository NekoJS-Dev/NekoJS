import { $Collection, $List } from "java:java/util";
import { $Function, $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $SlotAccess } from "java:net/minecraft/world/entity";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";

declare module "java:net/minecraft/world/item/slot" {
    export interface $SlotCollection {
        concat(arg0: $SlotCollection[]): $SlotCollection;
        concat(arg0: $SlotCollection, arg1: $SlotCollection): $SlotCollection;
        filter(arg0: $Predicate<any>): $SlotCollection;
        flatMap(arg0: $Function<$ItemStack_, $SlotCollection>): $SlotCollection;
        itemCopies(): $Stream<$ItemStack>;
        limit(arg0: number): $SlotCollection;
        of(arg0: $SlotAccess[]): $SlotCollection;
        of(arg0: $SlotAccess): $SlotCollection;
        static EMPTY: $SlotCollection;
    }

}
