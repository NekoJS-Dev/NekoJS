import { $ServerLevel } from "java:net/minecraft/server/level";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Item, $Item_ } from "java:net/minecraft/world/item";
import { $Explosion } from "java:net/minecraft/world/level";

export * as boat from "java:net/minecraft/world/entity/vehicle/boat";
export * as minecart from "java:net/minecraft/world/entity/vehicle/minecart";

declare module "java:net/minecraft/world/entity/vehicle" {
    export class $VehicleEntity extends $Entity {
        constructor(arg0: $EntityType<any>, arg1: $Level);
        get damage(): number;
        getDamage(): number;
        set damage(value: number);
        get dimensionChangingDelay(): number;
        getDimensionChangingDelay(): number;
        get hurtDir(): number;
        getHurtDir(): number;
        set hurtDir(value: number);
        get hurtTime(): number;
        getHurtTime(): number;
        set hurtTime(value: number);
        destroy(arg0: $ServerLevel, arg1: $Item_): void;
        hurtClient(arg0: $DamageSource): boolean;
        hurtServer(arg0: $ServerLevel, arg1: $DamageSource, arg2: number): boolean;
        ignoreExplosion(arg0: $Explosion): boolean;
    }

}
