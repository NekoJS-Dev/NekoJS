import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $Float, $Integer, $Record, $String } from "java:java/lang";
import { $Map, $Set } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $ToFloatFunction } from "java:net/minecraft/util";
import { $AttributeModifier, $AttributeModifier$OperationId, $AttributeModifier$OperationId_ } from "java:net/minecraft/world/attribute/modifier";
import { $ClockManager } from "java:net/minecraft/world/clock";
import { $Level } from "java:net/minecraft/world/level";
import { $LootContext } from "java:net/minecraft/world/level/storage/loot";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $Timeline } from "java:net/minecraft/world/timeline";

export * as modifier from "java:net/minecraft/world/attribute/modifier";

declare module "java:net/minecraft/world/attribute" {
    export interface $AttributeRange<Value> {
        any<Value>(): $AttributeRange<Value>;
        ofFloat(arg0: number, arg1: number): $AttributeRange<number>;
        sanitize(arg0: Value): Value;
        validate(arg0: Value): $DataResult<Value>;
        static NON_NEGATIVE_FLOAT: $AttributeRange<number>;
        static UNIT_FLOAT: $AttributeRange<number>;
    }

    export class $AttributeType<Value> extends $Record {
        constructor(valueCodec: $Codec<Value>, modifierLibrary: { [key: $AttributeModifier$OperationId_]: $AttributeModifier<Value, any> }, modifierCodec: $Codec<$AttributeModifier<Value, any>>, keyframeLerp: $LerpFunction<Value>, stateChangeLerp: $LerpFunction<Value>, spatialLerp: $LerpFunction<Value>, partialTickLerp: $LerpFunction<Value>, toFloat: $ToFloatFunction<Value>);
        static ofInterpolated<Value>(arg0: $Codec<Value>, arg1: { [key: $AttributeModifier$OperationId_]: $AttributeModifier<Value, any> }, arg2: $LerpFunction<Value>, arg3: $LerpFunction<Value>, arg4: $ToFloatFunction<Value>): $AttributeType<Value>;
        static ofInterpolated<Value>(arg0: $Codec<Value>, arg1: { [key: $AttributeModifier$OperationId_]: $AttributeModifier<Value, any> }, arg2: $LerpFunction<Value>): $AttributeType<Value>;
        static ofNotInterpolated<Value>(arg0: $Codec<Value>, arg1: { [key: $AttributeModifier$OperationId_]: $AttributeModifier<Value, any> }): $AttributeType<Value>;
        static ofNotInterpolated<Value>(arg0: $Codec<Value>): $AttributeType<Value>;
        checkAllowedModifier(arg0: $AttributeModifier<Value, any>): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        keyframeLerp(): $LerpFunction<Value>;
        modifierCodec(): $Codec<$AttributeModifier<Value, any>>;
        modifierLibrary(): $Map<$AttributeModifier$OperationId, $AttributeModifier<Value, any>>;
        partialTickLerp(): $LerpFunction<Value>;
        spatialLerp(): $LerpFunction<Value>;
        stateChangeLerp(): $LerpFunction<Value>;
        toFloat(arg0: Value): number;
        toFloat(): $ToFloatFunction<Value>;
        toString(): string;
        valueCodec(): $Codec<Value>;
    }

    export class $EnvironmentAttribute<Value> {
        get positional(): boolean;
        isPositional(): boolean;
        get spatiallyInterpolated(): boolean;
        isSpatiallyInterpolated(): boolean;
        get syncable(): boolean;
        isSyncable(): boolean;
        static builder<Value>(arg0: $AttributeType<Value>): $EnvironmentAttribute$Builder<Value>;
        defaultValue(): Value;
        sanitizeValue(arg0: Value): Value;
        toString(): string;
        type(): $AttributeType<Value>;
        valueCodec(): $Codec<Value>;
    }

    export class $EnvironmentAttribute$Builder<Value> {
        constructor(arg0: $AttributeType<Value>);
        build(): $EnvironmentAttribute<Value>;
        defaultValue(arg0: Value): $EnvironmentAttribute$Builder<Value>;
        notPositional(): $EnvironmentAttribute$Builder<Value>;
        spatiallyInterpolated(): $EnvironmentAttribute$Builder<Value>;
        syncable(): $EnvironmentAttribute$Builder<Value>;
        valueRange(arg0: $AttributeRange<Value>): $EnvironmentAttribute$Builder<Value>;
    }

    export interface $EnvironmentAttributeLayer<Value> {
    }

    export interface $EnvironmentAttributeLayer$Constant<Value> extends $EnvironmentAttributeLayer {
        applyConstant(arg0: Value): Value;
    }

    export interface $EnvironmentAttributeLayer$Positional<Value> extends $EnvironmentAttributeLayer {
        applyPositional(arg0: Value, arg1: $Vec3_, arg2: $SpatialAttributeInterpolator): Value;
    }

    export interface $EnvironmentAttributeLayer$TimeBased<Value> extends $EnvironmentAttributeLayer {
        applyTimeBased(arg0: Value, arg1: number): Value;
    }

    export class $EnvironmentAttributeMap {
        static CODEC: $Codec<$EnvironmentAttributeMap>;
        static CODEC_ONLY_POSITIONAL: $Codec<$EnvironmentAttributeMap>;
        static EMPTY: $EnvironmentAttributeMap;
        static NETWORK_CODEC: $Codec<$EnvironmentAttributeMap>;
        static builder(): $EnvironmentAttributeMap$Builder;
        applyModifier<Value>(arg0: $EnvironmentAttribute<Value>, arg1: Value): Value;
        contains(arg0: $EnvironmentAttribute<any>): boolean;
        equals(arg0: object): boolean;
        get<Value>(arg0: $EnvironmentAttribute<Value>): $EnvironmentAttributeMap$Entry<Value, any>;
        hashCode(): number;
        keySet(): $Set<$EnvironmentAttribute<any>>;
        toString(): string;
    }

    export class $EnvironmentAttributeMap$Builder {
        build(): $EnvironmentAttributeMap;
        modify<Value, Parameter>(arg0: $EnvironmentAttribute<Value>, arg1: $AttributeModifier<Value, Parameter>, arg2: Parameter): $EnvironmentAttributeMap$Builder;
        putAll(arg0: $EnvironmentAttributeMap): $EnvironmentAttributeMap$Builder;
        set<Value>(arg0: $EnvironmentAttribute<Value>, arg1: Value): $EnvironmentAttributeMap$Builder;
    }

    export class $EnvironmentAttributeMap$Entry<Value, Argument> extends $Record {
        constructor(argument: Argument, modifier: $AttributeModifier<Value, Argument>);
        applyModifier(arg0: Value): Value;
        argument(): Argument;
        equals(arg0: object): boolean;
        hashCode(): number;
        modifier(): $AttributeModifier<Value, Argument>;
        toString(): string;
    }

    export interface $EnvironmentAttributeReader {
        getDimensionValue<Value>(arg0: $EnvironmentAttribute<Value>): Value;
        getValue<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $BlockPos_): Value;
        getValue<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $Vec3_, arg2: $SpatialAttributeInterpolator): Value;
        getValue<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $Vec3_): Value;
        getValue<Value>(arg0: $LootContext, arg1: $EnvironmentAttribute<Value>): Value;
        static EMPTY: $EnvironmentAttributeReader;
    }

    export class $EnvironmentAttributeSystem implements $EnvironmentAttributeReader {
        static builder(): $EnvironmentAttributeSystem$Builder;
        getDimensionValue<Value>(arg0: $EnvironmentAttribute<Value>): Value;
        getValue<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $Vec3_, arg2: $SpatialAttributeInterpolator): Value;
        invalidateTickCache(): void;
    }

    export class $EnvironmentAttributeSystem$Builder {
        addConstantLayer<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $EnvironmentAttributeLayer$Constant<Value>): $EnvironmentAttributeSystem$Builder;
        addConstantLayer(arg0: $EnvironmentAttributeMap): $EnvironmentAttributeSystem$Builder;
        addDefaultLayers(arg0: $Level): $EnvironmentAttributeSystem$Builder;
        addPositionalLayer<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $EnvironmentAttributeLayer$Positional<Value>): $EnvironmentAttributeSystem$Builder;
        addTimeBasedLayer<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $EnvironmentAttributeLayer$TimeBased<Value>): $EnvironmentAttributeSystem$Builder;
        addTimelineLayer(arg0: $Holder<$Timeline>, arg1: $ClockManager): $EnvironmentAttributeSystem$Builder;
        build(): $EnvironmentAttributeSystem;
    }

    export interface $LerpFunction<T> {
        apply(arg0: number, arg1: T, arg2: T): T;
        ofColor(): $LerpFunction<number>;
        ofConstant<T>(): $LerpFunction<T>;
        ofDegrees(arg0: number): $LerpFunction<number>;
        ofFloat(): $LerpFunction<number>;
        ofInteger(): $LerpFunction<number>;
        ofStep<T>(arg0: number): $LerpFunction<T>;
        static CONSTANT: $LerpFunction<any>;
    }

    export class $SpatialAttributeInterpolator {
        constructor();
        accumulate(arg0: number, arg1: $EnvironmentAttributeMap): $SpatialAttributeInterpolator;
        applyAttributeLayer<Value>(arg0: $EnvironmentAttribute<Value>, arg1: Value): Value;
        clear(): void;
    }

}
