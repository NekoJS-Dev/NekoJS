declare module "java:net/neoforged/neoforge/registries/callback" {
    export interface $RegistryCallback<T> {
    }

}
