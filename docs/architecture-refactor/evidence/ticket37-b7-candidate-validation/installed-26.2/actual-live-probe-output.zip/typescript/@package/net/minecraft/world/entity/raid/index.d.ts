import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $List, $OptionalInt, $Set } from "java:java/util";
import { $BlockPos, $BlockPos_, $HolderGetter } from "java:net/minecraft/core";
import { $DataComponentPatch } from "java:net/minecraft/core/component";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $Difficulty, $DifficultyInstance, $Difficulty_ } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $EntitySpawnReason, $EntitySpawnReason_, $SpawnGroupData, $SpawnPlacementType } from "java:net/minecraft/world/entity";
import { $PatrollingMonster } from "java:net/minecraft/world/entity/monster";
import { $ItemStack, $ItemStackTemplate, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ChunkPos, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $BannerPattern } from "java:net/minecraft/world/level/block/entity";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";

declare module "java:net/minecraft/world/entity/raid" {
    export class $Raid {
        constructor(arg0: $BlockPos_, arg1: $Difficulty_);
        static DEFAULT_MAX_RAID_OMEN_LEVEL: number;
        static MAP_CODEC: $MapCodec<$Raid>;
        static MAX_CELEBRATION_TICKS: number;
        static MAX_NO_ACTION_TIME: number;
        static RAID_REMOVAL_THRESHOLD_SQR: number;
        static RAVAGER_SPAWN_PLACEMENT_TYPE: $SpawnPlacementType;
        static VALID_RAID_RADIUS_SQR: number;
        static VILLAGE_RADIUS_BUFFER: number;
        get allRaiders(): $Set<$Raider>;
        getAllRaiders(): $Set<$Raider>;
        get center(): $BlockPos;
        getCenter(): $BlockPos;
        get enchantOdds(): number;
        getEnchantOdds(): number;
        get groupsSpawned(): number;
        getGroupsSpawned(): number;
        get healthOfLivingRaiders(): number;
        getHealthOfLivingRaiders(): number;
        get maxRaidOmenLevel(): number;
        getMaxRaidOmenLevel(): number;
        get raidOmenLevel(): number;
        getRaidOmenLevel(): number;
        set raidOmenLevel(value: number);
        get totalHealth(): number;
        getTotalHealth(): number;
        get totalRaidersAlive(): number;
        getTotalRaidersAlive(): number;
        get active(): boolean;
        isActive(): boolean;
        get betweenWaves(): boolean;
        isBetweenWaves(): boolean;
        get loss(): boolean;
        isLoss(): boolean;
        get over(): boolean;
        isOver(): boolean;
        get started(): boolean;
        isStarted(): boolean;
        get stopped(): boolean;
        isStopped(): boolean;
        get victory(): boolean;
        isVictory(): boolean;
        static getBannerComponentPatch(arg0: $HolderGetter<$BannerPattern>): $DataComponentPatch;
        static getOminousBannerInstance(arg0: $HolderGetter<$BannerPattern>): $ItemStack;
        static getOminousBannerTemplate(arg0: $HolderGetter<$BannerPattern>): $ItemStackTemplate;
        absorbRaidOmen(arg0: $ServerPlayer): boolean;
        addHeroOfTheVillage(arg0: $Entity): void;
        addWaveMob(arg0: $ServerLevel, arg1: number, arg2: $Raider, arg3: boolean): boolean;
        getLeader(arg0: number): $Raider;
        getNumGroups(arg0: $Difficulty_): number;
        hasFirstWaveSpawned(): boolean;
        joinRaid(arg0: $ServerLevel, arg1: number, arg2: $Raider, arg3: $BlockPos_, arg4: boolean): void;
        removeFromRaid(arg0: $ServerLevel, arg1: $Raider, arg2: boolean): void;
        removeLeader(arg0: number): void;
        setLeader(arg0: number, arg1: $Raider): void;
        stop(): void;
        tick(arg0: $ServerLevel): void;
        updateBossbar(): void;
    }

    export class $Raider extends $PatrollingMonster {
        get celebrateSound(): $SoundEvent;
        getCelebrateSound(): $SoundEvent;
        get currentRaid(): $Raid;
        getCurrentRaid(): $Raid;
        set currentRaid(value: $Raid);
        get ticksOutsideRaid(): number;
        getTicksOutsideRaid(): number;
        set ticksOutsideRaid(value: number);
        get wave(): number;
        getWave(): number;
        set wave(value: number);
        get captain(): boolean;
        isCaptain(): boolean;
        get celebrating(): boolean;
        isCelebrating(): boolean;
        set celebrating(value: boolean);
        aiStep(): void;
        applyRaidBuffs(arg0: $ServerLevel, arg1: number, arg2: boolean): void;
        canJoinPatrol(): boolean;
        canJoinRaid(): boolean;
        die(arg0: $DamageSource): void;
        finalizeSpawn(arg0: $ServerLevelAccessor, arg1: $DifficultyInstance, arg2: $EntitySpawnReason_, arg3: $SpawnGroupData): $SpawnGroupData;
        hasActiveRaid(): boolean;
        hasRaid(): boolean;
        hurtServer(arg0: $ServerLevel, arg1: $DamageSource, arg2: number): boolean;
        removeWhenFarAway(arg0: number): boolean;
        requiresCustomPersistence(): boolean;
    }

    export class $Raids extends $SavedData {
        constructor();
        static CODEC: $Codec<$Raids>;
        static TYPE: $SavedDataType<$Raids>;
        static canJoinRaid(arg0: $Raider): boolean;
        static load(arg0: $CompoundTag_): $Raids;
        createOrExtendRaid(arg0: $ServerPlayer, arg1: $BlockPos_): $Raid;
        getId(arg0: $Raid): $OptionalInt;
        getNearbyRaid(arg0: $BlockPos_, arg1: number): $Raid;
        getRaidCentersInChunk(arg0: $ChunkPos): $List<$BlockPos>;
        get(arg0: number): $Raid;
        tick(arg0: $ServerLevel): void;
    }

}
