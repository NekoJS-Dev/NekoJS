import { $Class, $Iterable } from "java:java/lang";
import { $UUID } from "java:java/util";
import { $Consumer } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $FullChunkStatus, $FullChunkStatus_ } from "java:net/minecraft/server/level";
import { $AbortableIterationConsumer } from "java:net/minecraft/util";
import { $Entity$RemovalReason, $Entity$RemovalReason_ } from "java:net/minecraft/world/entity";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $AABB } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/level/entity" {
    export interface $ChunkStatusUpdateListener {
        onChunkStatusChange(arg0: $ChunkPos, arg1: $FullChunkStatus_): void;
    }

    export interface $EntityAccess extends $UniquelyIdentifyable {
        blockPosition(): $BlockPos;
        getBoundingBox(): $AABB;
        getId(): number;
        getPassengersAndSelf(): $Stream<$EntityAccess>;
        getSelfAndPassengers(): $Stream<$EntityAccess>;
        isAlwaysTicking(): boolean;
        setLevelCallback(arg0: $EntityInLevelCallback): void;
        setRemoved(arg0: $Entity$RemovalReason_): void;
        shouldBeSaved(): boolean;
    }

    export interface $EntityInLevelCallback {
        onMove(): void;
        onRemove(arg0: $Entity$RemovalReason_): void;
        static NULL: $EntityInLevelCallback;
    }

    export interface $EntityTypeTest<B, T extends B> {
        forClass<B, T>(arg0: $Class<T>): $EntityTypeTest<B, T>;
        forExactClass<B, T>(arg0: $Class<T>): $EntityTypeTest<B, T>;
        getBaseClass(): $Class<B>;
        tryCast(arg0: B): T;
    }

    export interface $LevelEntityGetter<T extends $EntityAccess> {
        getAll(): $Iterable<T>;
        get(arg0: number): T;
        get(arg0: string): T;
        get<U>(arg0: $EntityTypeTest<T, U>, arg1: $AbortableIterationConsumer<U>): void;
        get<U>(arg0: $EntityTypeTest<T, U>, arg1: $AABB, arg2: $AbortableIterationConsumer<U>): void;
        get(arg0: $AABB, arg1: $Consumer<T>): void;
    }

    export interface $UUIDLookup<IdentifiedType extends $UniquelyIdentifyable> {
        lookup(arg0: string): IdentifiedType;
    }

    export interface $UniquelyIdentifyable {
        getUUID(): $UUID;
        isRemoved(): boolean;
    }

}
