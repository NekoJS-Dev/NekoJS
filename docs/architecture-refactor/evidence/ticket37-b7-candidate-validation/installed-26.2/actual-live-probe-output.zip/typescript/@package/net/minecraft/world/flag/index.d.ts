import { $Set } from "java:java/util";
import { $ResourceKey } from "java:net/minecraft/resources";

declare module "java:net/minecraft/world/flag" {
    export interface $FeatureElement {
        isEnabled(arg0: $FeatureFlagSet): boolean;
        requiredFeatures(): $FeatureFlagSet;
        static FILTERED_REGISTRIES: $Set<$ResourceKey<$Registry<$FeatureElement>>>;
    }

    export class $FeatureFlag {
        get modded(): boolean;
        isModded(): boolean;
    }

    export class $FeatureFlagSet {
        static MAX_CONTAINER_SIZE: number;
        get empty(): boolean;
        isEmpty(): boolean;
        static of(arg0: $FeatureFlag, arg1?: $FeatureFlag[]): $FeatureFlagSet;
        static of(arg0: $FeatureFlag): $FeatureFlagSet;
        static of(): $FeatureFlagSet;
        contains(arg0: $FeatureFlag): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        intersects(arg0: $FeatureFlagSet): boolean;
        isSubsetOf(arg0: $FeatureFlagSet): boolean;
        join(arg0: $FeatureFlagSet): $FeatureFlagSet;
        subtract(arg0: $FeatureFlagSet): $FeatureFlagSet;
    }

}
