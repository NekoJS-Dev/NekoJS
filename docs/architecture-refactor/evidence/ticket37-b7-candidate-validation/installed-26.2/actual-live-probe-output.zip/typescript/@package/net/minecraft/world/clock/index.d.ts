import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Integer, $Record, $String } from "java:java/lang";
import { $Map, $Optional } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ClientboundSetTimePacket } from "java:net/minecraft/network/protocol/game";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";

declare module "java:net/minecraft/world/clock" {
    export interface $ClockManager {
        getPartialTick(arg0: $Holder<$WorldClock>): number;
        getTotalTicks(arg0: $Holder<$WorldClock>): number;
        setRate(arg0: $Holder<$WorldClock>, arg1: number): void;
    }

    export class $ClockNetworkState extends $Record {
        constructor(totalTicks: number, partialTick: number, rate: number);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClockNetworkState>;
        equals(arg0: object): boolean;
        hashCode(): number;
        partialTick(): number;
        rate(): number;
        toString(): string;
        totalTicks(): number;
    }

    export class $ClockState extends $Record {
        constructor(totalTicks: number, partialTick: number, rate: number, paused: boolean);
        static CODEC: $Codec<$ClockState>;
        equals(arg0: object): boolean;
        hashCode(): number;
        partialTick(): number;
        paused(): boolean;
        rate(): number;
        toString(): string;
        totalTicks(): number;
    }

    export class $ClockTimeMarker extends $Record {
        constructor(clock: $Holder<$WorldClock>, ticks: number, periodTicks: $Optional<number>, showInCommands: boolean);
        static KEY_CODEC: $Codec<$ResourceKey<$ClockTimeMarker>>;
        clock(): $Holder<$WorldClock>;
        equals(arg0: object): boolean;
        getRepetitionCount(arg0: number): number;
        hashCode(): number;
        occursAt(arg0: number): boolean;
        periodTicks(): $Optional<number>;
        resolveTimeToMoveTo(arg0: number): number;
        showInCommands(): boolean;
        ticks(): number;
        toString(): string;
    }

    export class $PackedClockStates extends $Record {
        constructor(clocks: { [key: $Holder<$WorldClock>]: $ClockState });
        static CODEC: $Codec<$PackedClockStates>;
        static EMPTY: $PackedClockStates;
        clocks(): $Map<$Holder<$WorldClock>, $ClockState>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $ServerClockManager extends $SavedData implements $ClockManager {
        static TYPE: $SavedDataType<$ServerClockManager>;
        addTicks(arg0: $Holder<$WorldClock>, arg1: number): void;
        commandTimeMarkersForClock(arg0: $Holder<$WorldClock>): $Stream<$ResourceKey<$ClockTimeMarker>>;
        createFullSyncPacket(): $ClientboundSetTimePacket;
        getPartialTick(arg0: $Holder<$WorldClock>): number;
        getRate(arg0: $Holder<$WorldClock>): number;
        getTotalTicks(arg0: $Holder<$WorldClock>): number;
        init(arg0: $MinecraftServer): void;
        isAtTimeMarker(arg0: $Holder<$WorldClock>, arg1: $ResourceKey<$ClockTimeMarker>): boolean;
        moveToTimeMarker(arg0: $Holder<$WorldClock>, arg1: $ResourceKey<$ClockTimeMarker>): boolean;
        packState(): $PackedClockStates;
        setPaused(arg0: $Holder<$WorldClock>, arg1: boolean): void;
        setRate(arg0: $Holder<$WorldClock>, arg1: number): void;
        setTotalTicks(arg0: $Holder<$WorldClock>, arg1: number): void;
        tick(): void;
    }

    export class $WorldClock extends $Record {
        constructor();
        static CODEC: $Codec<$Holder<$WorldClock>>;
        static DIRECT_CODEC: $Codec<$WorldClock>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$WorldClock>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

}
