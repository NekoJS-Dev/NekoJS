import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Integer, $Iterable, $Record, $String } from "java:java/lang";
import { $List, $Optional, $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $WeightedList } from "java:net/minecraft/util/random";
import { $EnvironmentAttributeMap } from "java:net/minecraft/world/attribute";
import { $EntityType, $EntityType_, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $LevelReader } from "java:net/minecraft/world/level";
import { $DensityFunction } from "java:net/minecraft/world/level/levelgen";
import { $ConfiguredWorldCarver } from "java:net/minecraft/world/level/levelgen/carver";
import { $ConfiguredFeature } from "java:net/minecraft/world/level/levelgen/feature";
import { $PlacedFeature } from "java:net/minecraft/world/level/levelgen/placement";
import { $PerlinSimplexNoise } from "java:net/minecraft/world/level/levelgen/synth";
import { $ExtensionInfo, $IExtensibleEnum } from "java:net/neoforged/fml/common/asm/enumextension";
import { $ModifiableBiomeInfo } from "java:net/neoforged/neoforge/common/world";

declare module "java:net/minecraft/world/level/biome" {
    export class $Biome {
        static BIOME_INFO_NOISE: $PerlinSimplexNoise;
        static CODEC: $Codec<$Holder<$Biome>>;
        static DIRECT_CODEC: $Codec<$Biome>;
        static LIST_CODEC: $Codec<$HolderSet<$Biome>>;
        static NETWORK_CODEC: $Codec<$Biome>;
        get attributes(): $EnvironmentAttributeMap;
        getAttributes(): $EnvironmentAttributeMap;
        get baseTemperature(): number;
        getBaseTemperature(): number;
        get dryFoliageColor(): number;
        getDryFoliageColor(): number;
        get foliageColor(): number;
        getFoliageColor(): number;
        get generationSettings(): $BiomeGenerationSettings;
        getGenerationSettings(): $BiomeGenerationSettings;
        get mobSettings(): $MobSpawnSettings;
        getMobSettings(): $MobSpawnSettings;
        get modifiedClimateSettings(): $Biome$ClimateSettings;
        getModifiedClimateSettings(): $Biome$ClimateSettings;
        get modifiedSpecialEffects(): $BiomeSpecialEffects;
        getModifiedSpecialEffects(): $BiomeSpecialEffects;
        get specialEffects(): $BiomeSpecialEffects;
        getSpecialEffects(): $BiomeSpecialEffects;
        get waterColor(): number;
        getWaterColor(): number;
        coldEnoughToSnow(arg0: $BlockPos_, arg1: number): boolean;
        getGrassColor(arg0: number, arg1: number): number;
        getPrecipitationAt(arg0: $BlockPos_, arg1: number): $Biome$Precipitation;
        hasPrecipitation(): boolean;
        modifiableBiomeInfo(): $ModifiableBiomeInfo;
        shouldFreeze(arg0: $LevelReader, arg1: $BlockPos_, arg2: boolean): boolean;
        shouldFreeze(arg0: $LevelReader, arg1: $BlockPos_): boolean;
        shouldMeltFrozenOceanIcebergSlightly(arg0: $BlockPos_, arg1: number): boolean;
        shouldSnow(arg0: $LevelReader, arg1: $BlockPos_): boolean;
        warmEnoughToRain(arg0: $BlockPos_, arg1: number): boolean;
    }

    export class $Biome$ClimateSettings extends $Record {
        constructor(hasPrecipitation: boolean, temperature: number, temperatureModifier: $Biome$TemperatureModifier_, downfall: number);
        static CODEC: $MapCodec<$Biome$ClimateSettings>;
        downfall(): number;
        equals(arg0: object): boolean;
        hasPrecipitation(): boolean;
        hashCode(): number;
        temperatureModifier(): $Biome$TemperatureModifier;
        temperature(): number;
        toString(): string;
    }

    export class $Biome$Precipitation {
        static NONE: $Biome$Precipitation;
        static RAIN: $Biome$Precipitation;
        static SNOW: $Biome$Precipitation;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Biome$Precipitation[];
        static valueOf(name: string): $Biome$Precipitation;
    }

    export class $Biome$TemperatureModifier {
        static FROZEN: $Biome$TemperatureModifier;
        static NONE: $Biome$TemperatureModifier;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Biome$TemperatureModifier[];
        static valueOf(name: string): $Biome$TemperatureModifier;
    }

    export class $BiomeGenerationSettings {
        constructor(arg0: $HolderSet<$ConfiguredWorldCarver<any>>, arg1: $HolderSet<$PlacedFeature>[]);
        static CODEC: $MapCodec<$BiomeGenerationSettings>;
        static EMPTY: $BiomeGenerationSettings;
        get boneMealFeatures(): $List<$ConfiguredFeature<any, any>>;
        getBoneMealFeatures(): $List<$ConfiguredFeature<any, any>>;
        get carvers(): $Iterable<$Holder<$ConfiguredWorldCarver<any>>>;
        getCarvers(): $Iterable<$Holder<$ConfiguredWorldCarver<any>>>;
        features(): $List<$HolderSet<$PlacedFeature>>;
        hasFeature(arg0: $PlacedFeature): boolean;
    }

    export class $BiomeManager {
        constructor(arg0: $BiomeManager$NoiseBiomeSource, arg1: number);
        static CHUNK_CENTER_QUART: number;
        static obfuscateSeed(arg0: number): number;
        getBiome(arg0: $BlockPos_): $Holder<$Biome>;
        getNoiseBiomeAtPosition(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getNoiseBiomeAtPosition(arg0: $BlockPos_): $Holder<$Biome>;
        getNoiseBiomeAtQuart(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        withDifferentSource(arg0: $BiomeManager$NoiseBiomeSource): $BiomeManager;
    }

    export interface $BiomeManager$NoiseBiomeSource {
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
    }

    export interface $BiomeResolver {
        getNoiseBiome(arg0: number, arg1: number, arg2: number, arg3: $Climate$Sampler): $Holder<$Biome>;
    }

    export class $BiomeSource implements $BiomeResolver {
        static CODEC: $Codec<$BiomeSource>;
        addDebugInfo(arg0: string[], arg1: $BlockPos_, arg2: $Climate$Sampler): void;
        findBiomeHorizontal(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $Predicate<$Holder<$Biome>>, arg6: $RandomSource, arg7: boolean, arg8: $Climate$Sampler): $Pair<$BlockPos, $Holder<$Biome>>;
        findBiomeHorizontal(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $Predicate<$Holder<$Biome>>, arg5: $RandomSource, arg6: $Climate$Sampler): $Pair<$BlockPos, $Holder<$Biome>>;
        findClosestBiome3d(arg0: $BlockPos_, arg1: number, arg2: number, arg3: number, arg4: $Predicate<$Holder<$Biome>>, arg5: $Climate$Sampler, arg6: $LevelReader): $Pair<$BlockPos, $Holder<$Biome>>;
        getBiomesWithin(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $Climate$Sampler): $Set<$Holder<$Biome>>;
        getNoiseBiome(arg0: number, arg1: number, arg2: number, arg3: $Climate$Sampler): $Holder<$Biome>;
        possibleBiomes(): $Set<$Holder<$Biome>>;
    }

    export class $BiomeSpecialEffects extends $Record {
        constructor(waterColor: number, foliageColorOverride: $Optional<number>, dryFoliageColorOverride: $Optional<number>, grassColorOverride: $Optional<number>, grassColorModifier: $BiomeSpecialEffects$GrassColorModifier_);
        static CODEC: $Codec<$BiomeSpecialEffects>;
        dryFoliageColorOverride(): $Optional<number>;
        equals(arg0: object): boolean;
        foliageColorOverride(): $Optional<number>;
        grassColorModifier(): $BiomeSpecialEffects$GrassColorModifier;
        grassColorOverride(): $Optional<number>;
        hashCode(): number;
        toString(): string;
        waterColor(): number;
    }

    export class $BiomeSpecialEffects$GrassColorModifier {
        static DARK_FOREST: $BiomeSpecialEffects$GrassColorModifier;
        static NONE: $BiomeSpecialEffects$GrassColorModifier;
        static SWAMP: $BiomeSpecialEffects$GrassColorModifier;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BiomeSpecialEffects$GrassColorModifier[];
        static valueOf(name: string): $BiomeSpecialEffects$GrassColorModifier;
    }

    export class $Climate$Parameter extends $Record {
        constructor(min: number, max: number);
        static CODEC: $Codec<$Climate$Parameter>;
        static point(arg0: number): $Climate$Parameter;
        static span(arg0: number, arg1: number): $Climate$Parameter;
        static span(arg0: $Climate$Parameter, arg1: $Climate$Parameter): $Climate$Parameter;
        distance(arg0: number): number;
        distance(arg0: $Climate$Parameter): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        max(): number;
        min(): number;
        span(arg0: $Climate$Parameter): $Climate$Parameter;
        toString(): string;
    }

    export class $Climate$ParameterPoint extends $Record {
        constructor(temperature: $Climate$Parameter, humidity: $Climate$Parameter, continentalness: $Climate$Parameter, erosion: $Climate$Parameter, depth: $Climate$Parameter, weirdness: $Climate$Parameter, offset: number);
        static CODEC: $Codec<$Climate$ParameterPoint>;
        continentalness(): $Climate$Parameter;
        depth(): $Climate$Parameter;
        equals(arg0: object): boolean;
        erosion(): $Climate$Parameter;
        hashCode(): number;
        humidity(): $Climate$Parameter;
        offset(): number;
        temperature(): $Climate$Parameter;
        toString(): string;
        weirdness(): $Climate$Parameter;
    }

    export class $Climate$Sampler extends $Record {
        constructor(temperature: $DensityFunction, humidity: $DensityFunction, continentalness: $DensityFunction, erosion: $DensityFunction, depth: $DensityFunction, weirdness: $DensityFunction, spawnTarget: $Climate$ParameterPoint[]);
        continentalness(): $DensityFunction;
        depth(): $DensityFunction;
        equals(arg0: object): boolean;
        erosion(): $DensityFunction;
        findSpawnPosition(): $BlockPos;
        hashCode(): number;
        humidity(): $DensityFunction;
        sample(arg0: number, arg1: number, arg2: number): $Climate$TargetPoint;
        spawnTarget(): $List<$Climate$ParameterPoint>;
        temperature(): $DensityFunction;
        toString(): string;
        weirdness(): $DensityFunction;
    }

    export class $Climate$TargetPoint extends $Record {
        constructor(temperature: number, humidity: number, continentalness: number, erosion: number, depth: number, weirdness: number);
        continentalness(): number;
        depth(): number;
        equals(arg0: object): boolean;
        erosion(): number;
        hashCode(): number;
        humidity(): number;
        temperature(): number;
        toString(): string;
        weirdness(): number;
    }

    export class $MobSpawnSettings {
        static CODEC: $MapCodec<$MobSpawnSettings>;
        static EMPTY: $MobSpawnSettings;
        static EMPTY_MOB_LIST: $WeightedList<$MobSpawnSettings$SpawnerData>;
        get creatureProbability(): number;
        getCreatureProbability(): number;
        get entityTypes(): $Set<$EntityType<any>>;
        getEntityTypes(): $Set<$EntityType<any>>;
        get spawnerTypes(): $Set<$MobCategory>;
        getSpawnerTypes(): $Set<$MobCategory>;
        getMobSpawnCost(arg0: $EntityType<any>): $MobSpawnSettings$MobSpawnCost;
        getMobs(arg0: $MobCategory_): $WeightedList<$MobSpawnSettings$SpawnerData>;
    }

    export class $MobSpawnSettings$MobSpawnCost extends $Record {
        constructor(energyBudget: number, charge: number);
        static CODEC: $Codec<$MobSpawnSettings$MobSpawnCost>;
        charge(): number;
        energyBudget(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $MobSpawnSettings$SpawnerData extends $Record {
        constructor(type: $EntityType<any>, minCount: number, maxCount: number);
        static CODEC: $MapCodec<$MobSpawnSettings$SpawnerData>;
        equals(arg0: object): boolean;
        hashCode(): number;
        maxCount(): number;
        minCount(): number;
        toString(): string;
        type(): $EntityType<any>;
    }

    export type $Biome$Precipitation_ = $Biome$Precipitation | "NONE" | "RAIN" | "SNOW";
    export type $Biome$TemperatureModifier_ = $Biome$TemperatureModifier | "FROZEN" | "NONE";
    export type $BiomeSpecialEffects$GrassColorModifier_ = $BiomeSpecialEffects$GrassColorModifier | "DARK_FOREST" | "NONE" | "SWAMP";
}
