import { $Enum, $String } from "java:java/lang";

export * as common from "java:net/neoforged/fml/common";
export * as event from "java:net/neoforged/fml/event";

declare module "java:net/neoforged/fml" {
    export class $LogicalSide {
        static CLIENT: $LogicalSide;
        static SERVER: $LogicalSide;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LogicalSide[];
        static valueOf(name: string): $LogicalSide;
    }

    export type $LogicalSide_ = $LogicalSide | "CLIENT" | "SERVER";
}
