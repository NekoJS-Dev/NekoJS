import { $EnumSet, $List } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $UseOnContext } from "java:net/minecraft/world/item/context";
import { $Level, $LevelAccessor, $ServerExplosion } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $PortalShape } from "java:net/minecraft/world/level/portal";
import { $Event, $ICancellableEvent } from "java:net/neoforged/bus/api";
import { $ItemAbility } from "java:net/neoforged/neoforge/common";
import { $BlockSnapshot } from "java:net/neoforged/neoforge/common/util";

declare module "java:net/neoforged/neoforge/event/level" {
    export class $BlockEvent extends $Event {
        constructor(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $BlockState_);
        get level(): $LevelAccessor;
        getLevel(): $LevelAccessor;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
    }

    export class $BlockEvent$BlockToolModificationEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $BlockState_, arg1: $UseOnContext, arg2: $ItemAbility, arg3: boolean);
        get context(): $UseOnContext;
        getContext(): $UseOnContext;
        get finalState(): $BlockState;
        getFinalState(): $BlockState;
        set finalState(value: $BlockState_);
        get heldItemStack(): $ItemStack;
        getHeldItemStack(): $ItemStack;
        get itemAbility(): $ItemAbility;
        getItemAbility(): $ItemAbility;
        get player(): $Player;
        getPlayer(): $Player;
        get simulated(): boolean;
        isSimulated(): boolean;
    }

    export class $BlockEvent$EntityMultiPlaceEvent extends $BlockEvent$EntityPlaceEvent implements $ICancellableEvent {
        constructor(arg0: $BlockSnapshot[], arg1: $BlockState_, arg2: $Entity);
        get replacedBlockSnapshots(): $List<$BlockSnapshot>;
        getReplacedBlockSnapshots(): $List<$BlockSnapshot>;
    }

    export class $BlockEvent$EntityPlaceEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $BlockSnapshot, arg1: $BlockState_, arg2: $Entity);
        get blockSnapshot(): $BlockSnapshot;
        getBlockSnapshot(): $BlockSnapshot;
        get entity(): $Entity;
        getEntity(): $Entity;
        get placedAgainst(): $BlockState;
        getPlacedAgainst(): $BlockState;
        get placedBlock(): $BlockState;
        getPlacedBlock(): $BlockState;
    }

    export class $BlockEvent$FarmlandTrampleEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: number, arg4: $Entity);
        get entity(): $Entity;
        getEntity(): $Entity;
        get fallDistance(): number;
        getFallDistance(): number;
    }

    export class $BlockEvent$FluidPlaceBlockEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $BlockState_);
        get liquidPos(): $BlockPos;
        getLiquidPos(): $BlockPos;
        get newState(): $BlockState;
        getNewState(): $BlockState;
        set newState(value: $BlockState_);
        get originalState(): $BlockState;
        getOriginalState(): $BlockState;
    }

    export class $BlockEvent$NeighborNotifyEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: $EnumSet<$Direction_>, arg4: boolean);
        get forceRedstoneUpdate(): boolean;
        getForceRedstoneUpdate(): boolean;
        get notifiedSides(): $EnumSet<$Direction>;
        getNotifiedSides(): $EnumSet<$Direction>;
    }

    export class $BlockEvent$PortalSpawnEvent extends $BlockEvent implements $ICancellableEvent {
        constructor(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $BlockState_, arg3: $PortalShape);
        get portalSize(): $PortalShape;
        getPortalSize(): $PortalShape;
    }

    export class $ChunkEvent<T extends $ChunkAccess> extends $LevelEvent {
        constructor(arg0: T);
        constructor(arg0: T, arg1: $LevelAccessor);
        get chunk(): T;
        getChunk(): T;
    }

    export class $ChunkEvent$Unload extends $ChunkEvent {
        constructor(arg0: $LevelChunk);
    }

    export class $ExplosionEvent extends $Event {
        constructor(arg0: $Level, arg1: $ServerExplosion);
        get explosion(): $ServerExplosion;
        getExplosion(): $ServerExplosion;
        get level(): $Level;
        getLevel(): $Level;
    }

    export class $ExplosionEvent$Detonate extends $ExplosionEvent {
        constructor(arg0: $Level, arg1: $ServerExplosion, arg2: $Entity[], arg3: $BlockPos_[]);
        get affectedBlocks(): $List<$BlockPos>;
        getAffectedBlocks(): $List<$BlockPos>;
        get affectedEntities(): $List<$Entity>;
        getAffectedEntities(): $List<$Entity>;
    }

    export class $ExplosionEvent$Start extends $ExplosionEvent implements $ICancellableEvent {
        constructor(arg0: $Level, arg1: $ServerExplosion);
    }

    export class $LevelEvent extends $Event {
        constructor(arg0: $LevelAccessor);
        get level(): $LevelAccessor;
        getLevel(): $LevelAccessor;
    }

    export class $LevelEvent$Load extends $LevelEvent {
        constructor(arg0: $LevelAccessor);
    }

    export class $LevelEvent$Save extends $LevelEvent {
        constructor(arg0: $LevelAccessor);
    }

    export class $LevelEvent$Unload extends $LevelEvent {
        constructor(arg0: $LevelAccessor);
    }

}
