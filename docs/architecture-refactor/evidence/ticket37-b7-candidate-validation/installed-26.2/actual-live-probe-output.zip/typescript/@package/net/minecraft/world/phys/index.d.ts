import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Iterable, $String } from "java:java/lang";
import { $EnumSet, $List, $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction$Axis, $Direction$Axis_, $Direction_, $Position, $Vec3i } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $RandomSource } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";
import { $Vector3f } from "java:org/joml";

export * as shapes from "java:net/minecraft/world/phys/shapes";

declare module "java:net/minecraft/world/phys" {
    export class $AABB {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number);
        constructor(arg0: $BlockPos_);
        constructor(arg0: $Vec3_, arg1: $Vec3_);
        static INFINITE: $AABB;
        maxX: number;
        maxY: number;
        maxZ: number;
        minX: number;
        minY: number;
        minZ: number;
        get bottomCenter(): $Vec3;
        getBottomCenter(): $Vec3;
        get center(): $Vec3;
        getCenter(): $Vec3;
        get maxPosition(): $Vec3;
        getMaxPosition(): $Vec3;
        get minPosition(): $Vec3;
        getMinPosition(): $Vec3;
        get size(): number;
        getSize(): number;
        get xsize(): number;
        getXsize(): number;
        get ysize(): number;
        getYsize(): number;
        get zsize(): number;
        getZsize(): number;
        get infinite(): boolean;
        isInfinite(): boolean;
        static clip(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: $Vec3_, arg7: $Vec3_): $Optional<$Vec3>;
        static clip(arg0: $Iterable<$AABB>, arg1: $Vec3_, arg2: $Vec3_, arg3: $BlockPos_): $BlockHitResult;
        static encapsulatingFullBlocks(arg0: $BlockPos_, arg1: $BlockPos_): $AABB;
        static ofSize(arg0: $Vec3_, arg1: number, arg2: number, arg3: number): $AABB;
        static of(arg0: $BoundingBox): $AABB;
        static unitCubeFromLowerCorner(arg0: $Vec3_): $AABB;
        clip(arg0: $Vec3_, arg1: $Vec3_): $Optional<$Vec3>;
        collidedAlongVector(arg0: $Vec3_, arg1: $AABB[]): boolean;
        contains(arg0: number, arg1: number, arg2: number): boolean;
        contains(arg0: $Vec3_): boolean;
        contract(arg0: number, arg1: number, arg2: number): $AABB;
        deflate(arg0: number, arg1: number, arg2: number): $AABB;
        deflate(arg0: number): $AABB;
        distanceToSqr(arg0: $AABB): number;
        distanceToSqr(arg0: $Vec3_): number;
        equals(arg0: object): boolean;
        expandTowards(arg0: number, arg1: number, arg2: number): $AABB;
        expandTowards(arg0: $Vec3_): $AABB;
        hasNaN(): boolean;
        hashCode(): number;
        inflate(arg0: number, arg1: number, arg2: number): $AABB;
        inflate(arg0: number): $AABB;
        intersects(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): boolean;
        intersects(arg0: $BlockPos_): boolean;
        intersects(arg0: $AABB): boolean;
        intersects(arg0: $Vec3_, arg1: $Vec3_): boolean;
        intersect(arg0: $AABB): $AABB;
        max(arg0: $Direction$Axis_): number;
        minmax(arg0: $AABB): $AABB;
        min(arg0: $Direction$Axis_): number;
        move(arg0: number, arg1: number, arg2: number): $AABB;
        move(arg0: $BlockPos_): $AABB;
        move(arg0: $Vec3_): $AABB;
        move(arg0: $Vector3f): $AABB;
        toString(): string;
    }

    export class $BlockHitResult extends $HitResult {
        constructor(arg0: $Vec3_, arg1: $Direction_, arg2: $BlockPos_, arg3: boolean);
        constructor(arg0: $Vec3_, arg1: $Direction_, arg2: $BlockPos_, arg3: boolean, arg4: boolean);
        get blockPos(): $BlockPos;
        getBlockPos(): $BlockPos;
        get direction(): $Direction;
        getDirection(): $Direction;
        get type(): $HitResult$Type;
        getType(): $HitResult$Type;
        get inside(): boolean;
        isInside(): boolean;
        get worldBorderHit(): boolean;
        isWorldBorderHit(): boolean;
        static miss(arg0: $Vec3_, arg1: $Direction_, arg2: $BlockPos_): $BlockHitResult;
        hitBorder(): $BlockHitResult;
        withDirection(arg0: $Direction_): $BlockHitResult;
        withPosition(arg0: $BlockPos_): $BlockHitResult;
    }

    export class $HitResult {
        get location(): $Vec3;
        getLocation(): $Vec3;
        get type(): $HitResult$Type;
        getType(): $HitResult$Type;
        distanceTo(arg0: $Entity): number;
    }

    export class $HitResult$Type {
        static BLOCK: $HitResult$Type;
        static ENTITY: $HitResult$Type;
        static MISS: $HitResult$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $HitResult$Type[];
        static valueOf(name: string): $HitResult$Type;
    }

    export class $Vec2 {
        constructor(arg0: number, arg1: number);
        static CODEC: $Codec<$Vec2>;
        static MAX: $Vec2;
        static MIN: $Vec2;
        static NEG_UNIT_X: $Vec2;
        static NEG_UNIT_Y: $Vec2;
        static ONE: $Vec2;
        static UNIT_X: $Vec2;
        static UNIT_Y: $Vec2;
        static ZERO: $Vec2;
        x: number;
        y: number;
        add(arg0: number): $Vec2;
        add(arg0: $Vec2): $Vec2;
        distanceToSqr(arg0: $Vec2): number;
        dot(arg0: $Vec2): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        lengthSquared(): number;
        length(): number;
        negated(): $Vec2;
        normalized(): $Vec2;
        rotate(arg0: number): $Vec2;
        scale(arg0: number): $Vec2;
    }

    export class $Vec3 implements $Position {
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: $Vec3i);
        constructor(arg0: $Vector3fc);
        static CODEC: $Codec<$Vec3>;
        static LP_STREAM_CODEC: $StreamCodec<$ByteBuf, $Vec3>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Vec3>;
        static X_AXIS: $Vec3;
        static Y_AXIS: $Vec3;
        static ZERO: $Vec3;
        static Z_AXIS: $Vec3;
        x: number;
        y: number;
        z: number;
        get finite(): boolean;
        isFinite(): boolean;
        static applyLocalCoordinatesToRotation(arg0: $Vec2, arg1: $Vec3_): $Vec3;
        static atBottomCenterOf(arg0: $Vec3i): $Vec3;
        static atCenterOf(arg0: $Vec3i): $Vec3;
        static atLowerCornerOf(arg0: $Vec3i): $Vec3;
        static atLowerCornerWithOffset(arg0: $Vec3i, arg1: number, arg2: number, arg3: number): $Vec3;
        static directionFromRotation(arg0: number, arg1: number): $Vec3;
        static directionFromRotation(arg0: $Vec2): $Vec3;
        static upFromBottomCenterOf(arg0: $Vec3i, arg1: number): $Vec3;
        addLocalCoordinates(arg0: $Vec3_): $Vec3;
        add(arg0: number, arg1: number, arg2: number): $Vec3;
        add(arg0: number): $Vec3;
        add(arg0: $Vec3_): $Vec3;
        align(arg0: $EnumSet<$Direction$Axis_>): $Vec3;
        closerThan(arg0: $Position, arg1: number): boolean;
        closerThan(arg0: $Vec3_, arg1: number, arg2: number): boolean;
        cross(arg0: $Vec3_): $Vec3;
        distanceToSqr(arg0: number, arg1: number, arg2: number): number;
        distanceToSqr(arg0: $Vec3_): number;
        distanceTo(arg0: $Vec3_): number;
        dot(arg0: $Vec3_): number;
        equals(arg0: object): boolean;
        get(arg0: $Direction$Axis_): number;
        hashCode(): number;
        horizontalDistanceSqr(): number;
        horizontalDistance(): number;
        horizontal(): $Vec3;
        lengthSqr(): number;
        length(): number;
        lerp(arg0: $Vec3_, arg1: number): $Vec3;
        multiply(arg0: number, arg1: number, arg2: number): $Vec3;
        multiply(arg0: $Vec3_): $Vec3;
        normalize(): $Vec3;
        offsetRandomXZ(arg0: $RandomSource, arg1: number): $Vec3;
        offsetRandom(arg0: $RandomSource, arg1: number): $Vec3;
        projectedOn(arg0: $Vec3_): $Vec3;
        relative(arg0: $Direction_, arg1: number): $Vec3;
        reverse(): $Vec3;
        rotateClockwise90(): $Vec3;
        rotation(): $Vec2;
        scale(arg0: number): $Vec3;
        subtract(arg0: number, arg1: number, arg2: number): $Vec3;
        subtract(arg0: number): $Vec3;
        subtract(arg0: $Vec3_): $Vec3;
        toString(): string;
        toVector3f(): $Vector3f;
        vectorTo(arg0: $Vec3_): $Vec3;
        with(arg0: $Direction$Axis_, arg1: number): $Vec3;
        xRot(arg0: number): $Vec3;
        x(): number;
        yRot(arg0: number): $Vec3;
        y(): number;
        zRot(arg0: number): $Vec3;
        z(): number;
    }

    export type $HitResult$Type_ = $HitResult$Type | "BLOCK" | "ENTITY" | "MISS";
    export type $Vec3_ = $Vec3 | $BlockPos | { x: number, y: number, z: number } | number[];
}
