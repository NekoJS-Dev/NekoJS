import { $AutoCloseable, $Runnable, $String, $Throwable, $Void } from "java:java/lang";
import { $List } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $BooleanSupplier, $Consumer, $Supplier } from "java:java/util/function";
import { $CrashReport } from "java:net/minecraft";
import { $MetricSampler, $ProfilerMeasured } from "java:net/minecraft/util/profiling/metrics";

declare module "java:net/minecraft/util/thread" {
    export class $AbstractConsecutiveExecutor<T extends $Runnable> implements $Runnable, $TaskScheduler, $ProfilerMeasured {
        constructor(arg0: $StrictQueue<T>, arg1: $Executor, arg2: string);
        close(): void;
        hasWork(): boolean;
        name(): string;
        profiledMetrics(): $List<$MetricSampler>;
        runAll(): void;
        run(): void;
        schedule(arg0: T): void;
        size(): number;
        toString(): string;
    }

    export class $BlockableEventLoop<R extends $Runnable> implements $Executor, $TaskScheduler, $ProfilerMeasured {
        static BLOCK_TIME_NANOS: number;
        get pendingTasksCount(): number;
        getPendingTasksCount(): number;
        get sameThread(): boolean;
        isSameThread(): boolean;
        static isNonRecoverable(arg0: $Throwable): boolean;
        static relayDelayCrash(arg0: $CrashReport): void;
        delayCrash(arg0: $CrashReport): void;
        executeBlocking(arg0: $Runnable): void;
        executeIfPossible(arg0: $Runnable): void;
        execute(arg0: $Runnable): void;
        managedBlock(arg0: $BooleanSupplier): void;
        name(): string;
        profiledMetrics(): $List<$MetricSampler>;
        schedule(arg0: R): void;
        submitAsync(arg0: $Runnable): $CompletableFuture<void>;
        submit(arg0: $Runnable): $CompletableFuture<void>;
        submit<V>(arg0: $Supplier<V>): $CompletableFuture<V>;
    }

    export class $ConsecutiveExecutor extends $AbstractConsecutiveExecutor {
        constructor(arg0: $Executor, arg1: string);
        wrapRunnable(arg0: $Runnable): $Runnable;
    }

    export class $ReentrantBlockableEventLoop<R extends $Runnable> extends $BlockableEventLoop {
        constructor(arg0: string, arg1: boolean);
    }

    export interface $TaskScheduler<R extends $Runnable> extends $AutoCloseable {
        close(): void;
        name(): string;
        scheduleWithResult<Source>(arg0: $Consumer<$CompletableFuture<Source>>): $CompletableFuture<Source>;
        schedule(arg0: R): void;
        wrapExecutor(arg0: string, arg1: $Executor): $TaskScheduler<$Runnable>;
        wrapRunnable(arg0: $Runnable): R;
    }

}
