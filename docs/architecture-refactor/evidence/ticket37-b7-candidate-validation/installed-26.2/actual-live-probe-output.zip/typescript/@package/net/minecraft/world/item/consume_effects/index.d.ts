import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $MobEffect, $MobEffectInstance, $MobEffect_ } from "java:net/minecraft/world/effect";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Level } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/item/consume_effects" {
    export class $ApplyStatusEffectsConsumeEffect extends $Record implements $ConsumeEffect {
        constructor(arg0: $MobEffectInstance[]);
        constructor(effects: $MobEffectInstance[], probability: number);
        constructor(arg0: $MobEffectInstance);
        constructor(arg0: $MobEffectInstance, arg1: number);
        static CODEC: $MapCodec<$ApplyStatusEffectsConsumeEffect>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ApplyStatusEffectsConsumeEffect>;
        get type(): $ConsumeEffect$Type<$ApplyStatusEffectsConsumeEffect>;
        getType(): $ConsumeEffect$Type<$ApplyStatusEffectsConsumeEffect>;
        apply(arg0: $Level, arg1: $ItemStack_, arg2: $LivingEntity): boolean;
        effects(): $List<$MobEffectInstance>;
        equals(arg0: object): boolean;
        hashCode(): number;
        probability(): number;
        toString(): string;
    }

    export class $ClearAllStatusEffectsConsumeEffect extends $Record implements $ConsumeEffect {
        constructor();
        static CODEC: $MapCodec<$ClearAllStatusEffectsConsumeEffect>;
        static INSTANCE: $ClearAllStatusEffectsConsumeEffect;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClearAllStatusEffectsConsumeEffect>;
        get type(): $ConsumeEffect$Type<$ClearAllStatusEffectsConsumeEffect>;
        getType(): $ConsumeEffect$Type<$ClearAllStatusEffectsConsumeEffect>;
        apply(arg0: $Level, arg1: $ItemStack_, arg2: $LivingEntity): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $ConsumeEffect {
        apply(arg0: $Level, arg1: $ItemStack_, arg2: $LivingEntity): boolean;
        getType(): $ConsumeEffect$Type<$ConsumeEffect>;
        static CODEC: $Codec<$ConsumeEffect>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ConsumeEffect>;
    }

    export class $ConsumeEffect$Type<T extends $ConsumeEffect> extends $Record {
        constructor(codec: $MapCodec<T>, streamCodec: $StreamCodec<$RegistryFriendlyByteBuf, T>);
        static APPLY_EFFECTS: $ConsumeEffect$Type<$ApplyStatusEffectsConsumeEffect>;
        static CLEAR_ALL_EFFECTS: $ConsumeEffect$Type<$ClearAllStatusEffectsConsumeEffect>;
        static PLAY_SOUND: $ConsumeEffect$Type<$PlaySoundConsumeEffect>;
        static REMOVE_EFFECTS: $ConsumeEffect$Type<$RemoveStatusEffectsConsumeEffect>;
        static TELEPORT_RANDOMLY: $ConsumeEffect$Type<$TeleportRandomlyConsumeEffect>;
        codec(): $MapCodec<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, T>;
        toString(): string;
    }

    export class $PlaySoundConsumeEffect extends $Record implements $ConsumeEffect {
        constructor(sound: $Holder<$SoundEvent_>);
        static CODEC: $MapCodec<$PlaySoundConsumeEffect>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $PlaySoundConsumeEffect>;
        get type(): $ConsumeEffect$Type<$PlaySoundConsumeEffect>;
        getType(): $ConsumeEffect$Type<$PlaySoundConsumeEffect>;
        apply(arg0: $Level, arg1: $ItemStack_, arg2: $LivingEntity): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        sound(): $Holder<$SoundEvent>;
        toString(): string;
    }

    export class $RemoveStatusEffectsConsumeEffect extends $Record implements $ConsumeEffect {
        constructor(arg0: $Holder<$MobEffect_>);
        constructor(effects: $HolderSet<$MobEffect_>);
        static CODEC: $MapCodec<$RemoveStatusEffectsConsumeEffect>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $RemoveStatusEffectsConsumeEffect>;
        get type(): $ConsumeEffect$Type<$RemoveStatusEffectsConsumeEffect>;
        getType(): $ConsumeEffect$Type<$RemoveStatusEffectsConsumeEffect>;
        apply(arg0: $Level, arg1: $ItemStack_, arg2: $LivingEntity): boolean;
        effects(): $HolderSet<$MobEffect>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $TeleportRandomlyConsumeEffect extends $Record implements $ConsumeEffect {
        constructor();
        constructor(diameter: number);
        static CODEC: $MapCodec<$TeleportRandomlyConsumeEffect>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $TeleportRandomlyConsumeEffect>;
        get type(): $ConsumeEffect$Type<$TeleportRandomlyConsumeEffect>;
        getType(): $ConsumeEffect$Type<$TeleportRandomlyConsumeEffect>;
        apply(arg0: $Level, arg1: $ItemStack_, arg2: $LivingEntity): boolean;
        diameter(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

}
