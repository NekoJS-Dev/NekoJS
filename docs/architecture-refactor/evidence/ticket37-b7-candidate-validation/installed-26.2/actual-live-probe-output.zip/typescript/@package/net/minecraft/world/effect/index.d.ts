import type { RegistryTypes } from "@special/types";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Int2DoubleFunction, $Int2IntFunction } from "java:it/unimi/dsi/fastutil/ints";
import { $Comparable, $Enum, $Record, $Runnable, $String } from "java:java/lang";
import { $Map } from "java:java/util";
import { $BiConsumer } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $Holder, $Holder_, $Registry } from "java:net/minecraft/core";
import { $ParticleOptions } from "java:net/minecraft/core/particles";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $Entity$RemovalReason, $Entity$RemovalReason_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Attribute, $AttributeMap, $AttributeModifier, $AttributeModifier$Operation, $AttributeModifier$Operation_, $Attribute_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $FeatureElement, $FeatureFlag, $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $IMobEffectExtension } from "java:net/neoforged/neoforge/common/extensions";

declare module "java:net/minecraft/world/effect" {
    export class $MobEffect implements $FeatureElement, $IMobEffectExtension {
        static CODEC: $Codec<$Holder<$MobEffect>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$MobEffect>>;
        attributeModifiers: $Map<$Holder<$Attribute>, $MobEffect$AttributeTemplate>;
        get blendInDurationTicks(): number;
        getBlendInDurationTicks(): number;
        get blendOutAdvanceTicks(): number;
        getBlendOutAdvanceTicks(): number;
        get blendOutDurationTicks(): number;
        getBlendOutDurationTicks(): number;
        get category(): $MobEffectCategory;
        getCategory(): $MobEffectCategory;
        get color(): number;
        getColor(): number;
        get descriptionId(): string;
        getDescriptionId(): string;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get beneficial(): boolean;
        isBeneficial(): boolean;
        get instantaneous(): boolean;
        isInstantaneous(): boolean;
        addAttributeModifiers(arg0: $AttributeMap, arg1: number): void;
        addAttributeModifier(arg0: $Holder<$Attribute_>, arg1: $Identifier_, arg2: number, arg3: $AttributeModifier$Operation_): $MobEffect;
        addAttributeModifier(arg0: $Holder<$Attribute_>, arg1: $Identifier_, arg2: $AttributeModifier$Operation_, arg3: $Int2DoubleFunction): $MobEffect;
        applyEffectTick(arg0: $ServerLevel, arg1: $LivingEntity, arg2: number): boolean;
        applyInstantaneousEffect(arg0: $ServerLevel, arg1: $Entity, arg2: $Entity, arg3: $LivingEntity, arg4: number, arg5: number): void;
        createModifiers(arg0: number, arg1: $BiConsumer<$Holder<$Attribute_>, $AttributeModifier>): void;
        createParticleOptions(arg0: $MobEffectInstance): $ParticleOptions;
        onEffectAdded(arg0: $LivingEntity, arg1: number): void;
        onEffectStarted(arg0: $LivingEntity, arg1: number): void;
        onMobHurt(arg0: $ServerLevel, arg1: $LivingEntity, arg2: number, arg3: $DamageSource, arg4: number): void;
        onMobRemoved(arg0: $ServerLevel, arg1: $LivingEntity, arg2: number, arg3: $Entity$RemovalReason_): void;
        removeAttributeModifiers(arg0: $AttributeMap): void;
        requiredFeatures(arg0?: $FeatureFlag[]): $MobEffect;
        requiredFeatures(): $FeatureFlagSet;
        setBlendDuration(arg0: number, arg1: number, arg2: number): $MobEffect;
        shouldApplyEffectTickThisTick(arg0: number, arg1: number): boolean;
        withSoundOnAdded(arg0: $SoundEvent_): $MobEffect;
    }

    export class $MobEffect$AttributeTemplate extends $Record {
        constructor(arg0: $Identifier_, arg1: number, arg2: $AttributeModifier$Operation_);
        constructor(id: $Identifier_, amount: number, operation: $AttributeModifier$Operation_, curve: $Int2DoubleFunction);
        amount(): number;
        create(arg0: number): $AttributeModifier;
        curve(): $Int2DoubleFunction;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        operation(): $AttributeModifier$Operation;
        toString(): string;
    }

    export class $MobEffectCategory {
        static BENEFICIAL: $MobEffectCategory;
        static HARMFUL: $MobEffectCategory;
        static NEUTRAL: $MobEffectCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MobEffectCategory[];
        static valueOf(name: string): $MobEffectCategory;
    }

    export class $MobEffectInstance implements $Comparable {
        constructor(arg0: $Holder<$MobEffect_>);
        constructor(arg0: $Holder<$MobEffect_>, arg1: number);
        constructor(arg0: $Holder<$MobEffect_>, arg1: number, arg2: number);
        constructor(arg0: $Holder<$MobEffect_>, arg1: number, arg2: number, arg3: boolean, arg4: boolean);
        constructor(arg0: $Holder<$MobEffect_>, arg1: number, arg2: number, arg3: boolean, arg4: boolean, arg5: boolean);
        constructor(arg0: $Holder<$MobEffect_>, arg1: number, arg2: number, arg3: boolean, arg4: boolean, arg5: boolean, arg6: $MobEffectInstance);
        constructor(arg0: $MobEffectInstance);
        static CODEC: $Codec<$MobEffectInstance>;
        static INFINITE_DURATION: number;
        static MAX_AMPLIFIER: number;
        static MIN_AMPLIFIER: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $MobEffectInstance>;
        get amplifier(): number;
        getAmplifier(): number;
        get descriptionId(): string;
        getDescriptionId(): string;
        get duration(): number;
        getDuration(): number;
        get effect(): $Holder<$MobEffect>;
        getEffect(): $Holder<$MobEffect>;
        get particleOptions(): $ParticleOptions;
        getParticleOptions(): $ParticleOptions;
        get ambient(): boolean;
        isAmbient(): boolean;
        get infiniteDuration(): boolean;
        isInfiniteDuration(): boolean;
        get visible(): boolean;
        isVisible(): boolean;
        compareTo(arg0: $MobEffectInstance): number;
        copyBlendState(arg0: $MobEffectInstance): void;
        endsWithin(arg0: number): boolean;
        equals(arg0: object): boolean;
        getBlendFactor(arg0: $LivingEntity, arg1: number): number;
        hashCode(): number;
        is(arg0: $Holder<$MobEffect_>): boolean;
        mapDuration(arg0: $Int2IntFunction): number;
        onEffectAdded(arg0: $LivingEntity): void;
        onEffectStarted(arg0: $LivingEntity): void;
        onMobHurt(arg0: $ServerLevel, arg1: $LivingEntity, arg2: $DamageSource, arg3: number): void;
        onMobRemoved(arg0: $ServerLevel, arg1: $LivingEntity, arg2: $Entity$RemovalReason_): void;
        showIcon(): boolean;
        skipBlending(): void;
        tickClient(): void;
        tickServer(arg0: $ServerLevel, arg1: $LivingEntity, arg2: $Runnable): boolean;
        toString(): string;
        update(arg0: $MobEffectInstance): boolean;
        withScaledDuration(arg0: number): $MobEffectInstance;
    }

    export class $MobEffects {
        constructor();
        static ABSORPTION: $Holder<$MobEffect>;
        static BAD_OMEN: $Holder<$MobEffect>;
        static BLINDNESS: $Holder<$MobEffect>;
        static BREATH_OF_THE_NAUTILUS: $Holder<$MobEffect>;
        static CONDUIT_POWER: $Holder<$MobEffect>;
        static DARKNESS: $Holder<$MobEffect>;
        static DOLPHINS_GRACE: $Holder<$MobEffect>;
        static FIRE_RESISTANCE: $Holder<$MobEffect>;
        static GLOWING: $Holder<$MobEffect>;
        static HASTE: $Holder<$MobEffect>;
        static HEALTH_BOOST: $Holder<$MobEffect>;
        static HERO_OF_THE_VILLAGE: $Holder<$MobEffect>;
        static HUNGER: $Holder<$MobEffect>;
        static INFESTED: $Holder<$MobEffect>;
        static INSTANT_DAMAGE: $Holder<$MobEffect>;
        static INSTANT_HEALTH: $Holder<$MobEffect>;
        static INVISIBILITY: $Holder<$MobEffect>;
        static JUMP_BOOST: $Holder<$MobEffect>;
        static LEVITATION: $Holder<$MobEffect>;
        static LUCK: $Holder<$MobEffect>;
        static MINING_FATIGUE: $Holder<$MobEffect>;
        static NAUSEA: $Holder<$MobEffect>;
        static NIGHT_VISION: $Holder<$MobEffect>;
        static OOZING: $Holder<$MobEffect>;
        static POISON: $Holder<$MobEffect>;
        static RAID_OMEN: $Holder<$MobEffect>;
        static REGENERATION: $Holder<$MobEffect>;
        static RESISTANCE: $Holder<$MobEffect>;
        static SATURATION: $Holder<$MobEffect>;
        static SLOWNESS: $Holder<$MobEffect>;
        static SLOW_FALLING: $Holder<$MobEffect>;
        static SPEED: $Holder<$MobEffect>;
        static STRENGTH: $Holder<$MobEffect>;
        static TRIAL_OMEN: $Holder<$MobEffect>;
        static UNLUCK: $Holder<$MobEffect>;
        static WATER_BREATHING: $Holder<$MobEffect>;
        static WEAKNESS: $Holder<$MobEffect>;
        static WEAVING: $Holder<$MobEffect>;
        static WIND_CHARGED: $Holder<$MobEffect>;
        static WITHER: $Holder<$MobEffect>;
        static bootstrap(arg0: $Registry<$MobEffect_>): $Holder<$MobEffect>;
    }

    export type $MobEffect_ = $MobEffect | RegistryTypes.MobEffect | $NekoId | string;
    export type $MobEffectCategory_ = $MobEffectCategory | "BENEFICIAL" | "HARMFUL" | "NEUTRAL";
}
