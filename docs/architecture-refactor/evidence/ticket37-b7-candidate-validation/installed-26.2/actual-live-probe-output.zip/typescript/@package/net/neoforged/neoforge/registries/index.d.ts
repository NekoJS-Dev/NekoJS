import { $Class } from "java:java/lang";
import { $Map } from "java:java/util";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $RegistryCallback } from "java:net/neoforged/neoforge/registries/callback";
import { $DataMapType } from "java:net/neoforged/neoforge/registries/datamaps";

export * as callback from "java:net/neoforged/neoforge/registries/callback";
export * as datamaps from "java:net/neoforged/neoforge/registries/datamaps";

declare module "java:net/neoforged/neoforge/registries" {
    export interface $IRegistryExtension<T> {
        addAlias(arg0: $Identifier_, arg1: $Identifier_): void;
        addCallback<C>(arg0: $Class<C>, arg1: C): void;
        addCallback(arg0: $RegistryCallback<T>): void;
        containsValue(arg0: T): boolean;
        doesSync(): boolean;
        getDataMap<A>(arg0: $DataMapType<T, A>): $Map<$ResourceKey<T>, A>;
        getId(arg0: $Identifier_): number;
        getId(arg0: $ResourceKey<T>): number;
        getKeyOrNull(arg0: T): $Identifier;
        getMaxId(): number;
        resolve(arg0: $Identifier_): $Identifier;
        resolve(arg0: $ResourceKey<T>): $ResourceKey<T>;
    }

}
