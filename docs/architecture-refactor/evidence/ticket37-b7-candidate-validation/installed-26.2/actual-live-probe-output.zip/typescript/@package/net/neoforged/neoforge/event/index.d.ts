import { $CommandDispatcher, $ParseResults } from "java:com/mojang/brigadier";
import { $Enum, $Iterable, $String, $Throwable } from "java:java/lang";
import { $Set } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $CommandBuildContext, $CommandSourceStack, $Commands$CommandSelection, $Commands$CommandSelection_ } from "java:net/minecraft/commands";
import { $HolderLookup$Provider, $RegistryAccess } from "java:net/minecraft/core";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $PlayerList } from "java:net/minecraft/server/players";
import { $RecipeType } from "java:net/minecraft/world/item/crafting";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $Event, $ICancellableEvent } from "java:net/neoforged/bus/api";

export * as entity from "java:net/neoforged/neoforge/event/entity";
export * as level from "java:net/neoforged/neoforge/event/level";
export * as server from "java:net/neoforged/neoforge/event/server";
export * as tick from "java:net/neoforged/neoforge/event/tick";

declare module "java:net/neoforged/neoforge/event" {
    export class $CommandEvent extends $Event implements $ICancellableEvent {
        constructor(arg0: $ParseResults<$CommandSourceStack>);
        get exception(): $Throwable;
        getException(): $Throwable;
        set exception(value: $Throwable);
        get parseResults(): $ParseResults<$CommandSourceStack>;
        getParseResults(): $ParseResults<$CommandSourceStack>;
        set parseResults(value: $ParseResults<$CommandSourceStack>);
    }

    export class $LootTableLoadEvent extends $Event implements $ICancellableEvent {
        constructor(arg0: $HolderLookup$Provider, arg1: $Identifier_, arg2: $LootTable);
        get key(): $ResourceKey<$LootTable>;
        getKey(): $ResourceKey<$LootTable>;
        get name(): $Identifier;
        getName(): $Identifier;
        get registries(): $HolderLookup$Provider;
        getRegistries(): $HolderLookup$Provider;
        get table(): $LootTable;
        getTable(): $LootTable;
        set table(value: $LootTable);
    }

    export class $OnDatapackSyncEvent extends $Event {
        constructor(arg0: $PlayerList, arg1: $ServerPlayer);
        get playerList(): $PlayerList;
        getPlayerList(): $PlayerList;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get recipeTypesToSend(): $Set<$RecipeType<any>>;
        getRecipeTypesToSend(): $Set<$RecipeType<any>>;
        get relevantPlayers(): $Stream<$ServerPlayer>;
        getRelevantPlayers(): $Stream<$ServerPlayer>;
        sendRecipes(arg0: $Iterable<$RecipeType<any>>): void;
        sendRecipes(arg0?: $RecipeType<any>[]): void;
    }

    export class $RegisterCommandsEvent extends $Event {
        constructor(arg0: $CommandDispatcher<$CommandSourceStack>, arg1: $Commands$CommandSelection_, arg2: $CommandBuildContext);
        get buildContext(): $CommandBuildContext;
        getBuildContext(): $CommandBuildContext;
        get commandSelection(): $Commands$CommandSelection;
        getCommandSelection(): $Commands$CommandSelection;
        get dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        getDispatcher(): $CommandDispatcher<$CommandSourceStack>;
    }

    export class $ServerChatEvent extends $Event implements $ICancellableEvent {
        constructor(arg0: $ServerPlayer, arg1: string, arg2: $Component_);
        get message(): $Component;
        getMessage(): $Component;
        set message(value: $Component_);
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get rawText(): string;
        getRawText(): string;
        get username(): string;
        getUsername(): string;
    }

    export class $TagsUpdatedEvent extends $Event {
        get lookupProvider(): $HolderLookup$Provider;
        getLookupProvider(): $HolderLookup$Provider;
        get registries(): $RegistryAccess;
        getRegistries(): $RegistryAccess;
        get updateCause(): $TagsUpdatedEvent$UpdateCause;
        getUpdateCause(): $TagsUpdatedEvent$UpdateCause;
        shouldUpdateStaticData(): boolean;
    }

    export class $TagsUpdatedEvent$UpdateCause {
        static CLIENT_PACKET_RECEIVED: $TagsUpdatedEvent$UpdateCause;
        static SERVER_DATA_LOAD: $TagsUpdatedEvent$UpdateCause;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TagsUpdatedEvent$UpdateCause[];
        static valueOf(name: string): $TagsUpdatedEvent$UpdateCause;
    }

    export type $TagsUpdatedEvent$UpdateCause_ = $TagsUpdatedEvent$UpdateCause | "CLIENT_PACKET_RECEIVED" | "SERVER_DATA_LOAD";
}
