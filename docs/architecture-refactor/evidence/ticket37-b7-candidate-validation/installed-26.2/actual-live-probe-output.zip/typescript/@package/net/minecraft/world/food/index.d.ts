import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Consumable, $ConsumableListener } from "java:net/minecraft/world/item/component";
import { $Level } from "java:net/minecraft/world/level";
import { $ValueInput, $ValueOutput } from "java:net/minecraft/world/level/storage";

declare module "java:net/minecraft/world/food" {
    export class $FoodData {
        constructor();
        get foodLevel(): number;
        getFoodLevel(): number;
        set foodLevel(value: number);
        get saturationLevel(): number;
        getSaturationLevel(): number;
        addAdditionalSaveData(arg0: $ValueOutput): void;
        addExhaustion(arg0: number): void;
        eat(arg0: number, arg1: number): void;
        eat(arg0: $FoodProperties): void;
        hasEnoughFood(): boolean;
        needsFood(): boolean;
        readAdditionalSaveData(arg0: $ValueInput): void;
        tick(arg0: $ServerPlayer): void;
    }

    export class $FoodProperties extends $Record implements $ConsumableListener {
        constructor(nutrition: number, saturation: number, canAlwaysEat: boolean);
        static DIRECT_CODEC: $Codec<$FoodProperties>;
        static DIRECT_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FoodProperties>;
        canAlwaysEat(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        nutrition(): number;
        onConsume(arg0: $Level, arg1: $LivingEntity, arg2: $ItemStack_, arg3: $Consumable): void;
        saturation(): number;
        toString(): string;
    }

}
