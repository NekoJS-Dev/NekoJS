import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Stream } from "java:java/util/stream";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_ } from "java:net/minecraft/world/item/crafting";
import { $SlotDisplay } from "java:net/minecraft/world/item/crafting/display";
import { $ItemLike, $ItemLike_ } from "java:net/minecraft/world/level";

declare module "java:net/neoforged/neoforge/common/crafting" {
    export interface $ICustomIngredient {
        display(): $SlotDisplay;
        getType(): $IngredientType<any>;
        isSimple(): boolean;
        items(): $Stream<$Holder<$Item>>;
        test(arg0: $ItemStack_): boolean;
        toVanilla(): $Ingredient;
    }

    export class $IngredientType<T extends $ICustomIngredient> extends $Record {
        constructor(arg0: $MapCodec<T>);
        constructor(codec: $MapCodec<T>, streamCodec: $StreamCodec<any, T>);
        codec(): $MapCodec<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        streamCodec(): $StreamCodec<any, T>;
        toString(): string;
    }

    export class $SizedIngredient {
        constructor(arg0: $Ingredient_, arg1: number);
        static NESTED_CODEC: $Codec<$SizedIngredient>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $SizedIngredient>;
        static of(arg0: $ItemLike_, arg1: number): $SizedIngredient;
        count(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        ingredient(): $Ingredient;
        test(arg0: $ItemStack_): boolean;
        toString(): string;
    }

    /** item:id | #tag | @mod | * | /regex/ | { ingredient|item|tag|mod|regex|wildcard|filter|any|all|not, count? } */
    export type $SizedIngredient_ = $SizedIngredient | RegistryTypes.Item | `#${RegistryTypes.ItemTag}` | `@${RegistryTypes.Namespace}` | "*" | `/${string}` | $SizedIngredient_[] | $Ingredient | { ingredient?: $Ingredient_, item?: RegistryTypes.Item, tag?: RegistryTypes.ItemTag, mod?: RegistryTypes.Namespace, regex?: string, wildcard?: boolean, filter?: ((item: $ItemStack) => boolean), any?: $SizedIngredient_[], all?: $SizedIngredient_[], not?: $SizedIngredient_, count: number };
}
