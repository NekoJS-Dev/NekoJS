import { $JsonElement, $JsonObject } from "java:com/google/gson";
import { $Codec, $DynamicOps, $MapCodec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Collection, $List, $Optional } from "java:java/util";
import { $Holder, $HolderLookup$Provider, $Holder_, $RegistryAccess } from "java:net/minecraft/core";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";

declare module "java:net/neoforged/neoforge/common/conditions" {
    export interface $ICondition {
        codec(): $MapCodec<$ICondition>;
        conditionsMatched<V>(arg0: $DynamicOps<V>, arg1: V): boolean;
        getConditionally<V, T>(arg0: $Codec<T>, arg1: $DynamicOps<V>, arg2: V): $Optional<T>;
        getWithConditionalCodec<V, T>(arg0: $Codec<$Optional<T>>, arg1: $DynamicOps<V>, arg2: V): $Optional<T>;
        getWithWithConditionsCodec<V, T>(arg0: $Codec<$Optional<$WithConditions<T>>>, arg1: $DynamicOps<V>, arg2: V): $Optional<T>;
        test(arg0: $ICondition$IContext): boolean;
        writeConditions(arg0: $DynamicOps<$JsonElement>, arg1: $JsonObject, arg2: $ICondition[]): void;
        writeConditions(arg0: $HolderLookup$Provider, arg1: $JsonObject, arg2: $ICondition[]): void;
        writeConditions(arg0: $HolderLookup$Provider, arg1: $JsonObject, arg2?: $ICondition[]): void;
        static CODEC: $Codec<$ICondition>;
        static LIST_CODEC: $Codec<$List<$ICondition>>;
    }

    export interface $ICondition$IContext {
        enabledFeatures(): $FeatureFlagSet;
        getTag<T>(arg0: $TagKey<T>): $Collection<$Holder<T>>;
        isTagLoaded<T>(arg0: $TagKey<T>): boolean;
        registryAccess(): $RegistryAccess;
        static EMPTY: $ICondition$IContext;
        static TAGS_INVALID: $ICondition$IContext;
    }

    export class $WithConditions<A> extends $Record {
        constructor(arg0: A);
        constructor(arg0: A, arg1?: $ICondition[]);
        constructor(conditions: $ICondition[], carrier: A);
        static builder<A>(arg0: A): $WithConditions$Builder<A>;
        carrier(): A;
        conditions(): $List<$ICondition>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $WithConditions$Builder<T> {
        constructor();
        addCondition(arg0: $ICondition[]): $WithConditions$Builder<T>;
        addCondition(arg0?: $ICondition[]): $WithConditions$Builder<T>;
        build(): $WithConditions<T>;
        withCarrier(arg0: T): $WithConditions$Builder<T>;
    }

}
