import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $VoxelShape } from "java:net/minecraft/world/phys/shapes";

declare module "java:net/minecraft/world/level/border" {
    export interface $BorderChangeListener {
        onLerpSize(arg0: $WorldBorder, arg1: number, arg2: number, arg3: number, arg4: number): void;
        onSetCenter(arg0: $WorldBorder, arg1: number, arg2: number): void;
        onSetDamagePerBlock(arg0: $WorldBorder, arg1: number): void;
        onSetSafeZone(arg0: $WorldBorder, arg1: number): void;
        onSetSize(arg0: $WorldBorder, arg1: number): void;
        onSetWarningBlocks(arg0: $WorldBorder, arg1: number): void;
        onSetWarningTime(arg0: $WorldBorder, arg1: number): void;
    }

    export class $BorderStatus {
        static GROWING: $BorderStatus;
        static SHRINKING: $BorderStatus;
        static STATIONARY: $BorderStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BorderStatus[];
        static valueOf(name: string): $BorderStatus;
    }

    export class $WorldBorder extends $SavedData {
        constructor();
        constructor(arg0: $WorldBorder$Settings);
        static CODEC: $Codec<$WorldBorder>;
        static MAX_CENTER_COORDINATE: number;
        static MAX_SIZE: number;
        static TYPE: $SavedDataType<$WorldBorder>;
        get absoluteMaxSize(): number;
        getAbsoluteMaxSize(): number;
        set absoluteMaxSize(value: number);
        get centerX(): number;
        getCenterX(): number;
        get centerZ(): number;
        getCenterZ(): number;
        get collisionShape(): $VoxelShape;
        getCollisionShape(): $VoxelShape;
        get damagePerBlock(): number;
        getDamagePerBlock(): number;
        set damagePerBlock(value: number);
        get lerpSpeed(): number;
        getLerpSpeed(): number;
        get lerpTarget(): number;
        getLerpTarget(): number;
        get lerpTime(): number;
        getLerpTime(): number;
        get maxX(): number;
        getMaxX(): number;
        get maxZ(): number;
        getMaxZ(): number;
        get minX(): number;
        getMinX(): number;
        get minZ(): number;
        getMinZ(): number;
        get safeZone(): number;
        getSafeZone(): number;
        set safeZone(value: number);
        get size(): number;
        getSize(): number;
        set size(value: number);
        get status(): $BorderStatus;
        getStatus(): $BorderStatus;
        get warningBlocks(): number;
        getWarningBlocks(): number;
        set warningBlocks(value: number);
        get warningTime(): number;
        getWarningTime(): number;
        set warningTime(value: number);
        addListener(arg0: $BorderChangeListener): void;
        applyInitialSettings(arg0: number): void;
        clampToBounds(arg0: number, arg1: number, arg2: number): $BlockPos;
        clampToBounds(arg0: $BlockPos_): $BlockPos;
        clampToBounds(arg0: $Vec3_): $BlockPos;
        clampVec3ToBound(arg0: number, arg1: number, arg2: number): $Vec3;
        clampVec3ToBound(arg0: $Vec3_): $Vec3;
        getDistanceToBorder(arg0: number, arg1: number): number;
        getDistanceToBorder(arg0: $Entity): number;
        getMaxX(arg0: number): number;
        getMaxZ(arg0: number): number;
        getMinX(arg0: number): number;
        getMinZ(arg0: number): number;
        isInsideCloseToBorder(arg0: $Entity, arg1: $AABB): boolean;
        isWithinBounds(arg0: number, arg1: number, arg2: number): boolean;
        isWithinBounds(arg0: number, arg1: number): boolean;
        isWithinBounds(arg0: $BlockPos_): boolean;
        isWithinBounds(arg0: $ChunkPos): boolean;
        isWithinBounds(arg0: $AABB): boolean;
        isWithinBounds(arg0: $Vec3_): boolean;
        lerpSizeBetween(arg0: number, arg1: number, arg2: number, arg3: number): void;
        removeListener(arg0: $BorderChangeListener): void;
        setCenter(arg0: number, arg1: number): void;
        tick(): void;
    }

    export class $WorldBorder$Settings extends $Record {
        constructor(centerX: number, centerZ: number, damagePerBlock: number, safeZone: number, warningBlocks: number, warningTime: number, size: number, lerpTime: number, lerpTarget: number);
        constructor(arg0: $WorldBorder);
        static CODEC: $Codec<$WorldBorder$Settings>;
        static DEFAULT: $WorldBorder$Settings;
        centerX(): number;
        centerZ(): number;
        damagePerBlock(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        lerpTarget(): number;
        lerpTime(): number;
        safeZone(): number;
        size(): number;
        toString(): string;
        warningBlocks(): number;
        warningTime(): number;
    }

    export type $BorderStatus_ = $BorderStatus | "GROWING" | "SHRINKING" | "STATIONARY";
}
