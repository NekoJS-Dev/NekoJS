import { $AutoCloseable, $Comparable, $String } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $List } from "java:java/util";
import { $Supplier } from "java:java/util/function";
import { $MetricCategory, $MetricCategory_ } from "java:net/minecraft/util/profiling/metrics";

export * as metrics from "java:net/minecraft/util/profiling/metrics";

declare module "java:net/minecraft/util/profiling" {
    export interface $ProfileResults {
        demanglePath(arg0: string): string;
        getEndTimeNano(): number;
        getEndTimeTicks(): number;
        getNanoDuration(): number;
        getProfilerResults(): string;
        getStartTimeNano(): number;
        getStartTimeTicks(): number;
        getTickDuration(): number;
        getTimes(arg0: string): $List<$ResultField>;
        saveResults(arg0: string): boolean;
        static PATH_SEPARATOR: string;
    }

    export interface $ProfilerFiller {
        addZoneText(arg0: string): void;
        addZoneValue(arg0: number): void;
        combine(arg0: $ProfilerFiller, arg1: $ProfilerFiller): $ProfilerFiller;
        endTick(): void;
        incrementCounter(arg0: string, arg1: number): void;
        incrementCounter(arg0: string): void;
        incrementCounter(arg0: $Supplier<string>, arg1: number): void;
        incrementCounter(arg0: $Supplier<string>): void;
        markForCharting(arg0: $MetricCategory_): void;
        popPush(arg0: string): void;
        popPush(arg0: $Supplier<string>): void;
        pop(): void;
        push(arg0: string): void;
        push(arg0: $Supplier<string>): void;
        setZoneColor(arg0: number): void;
        startTick(): void;
        zone(arg0: string): $Zone;
        zone(arg0: $Supplier<string>): $Zone;
        static ROOT: string;
    }

    export class $ResultField implements $Comparable {
        constructor(arg0: string, arg1: number, arg2: number, arg3: number);
        count: number;
        globalPercentage: number;
        name: string;
        percentage: number;
        get color(): number;
        getColor(): number;
        compareTo(arg0: $ResultField): number;
    }

    export class $Zone implements $AutoCloseable {
        static INACTIVE: $Zone;
        addText(arg0: string): $Zone;
        addText(arg0: $Supplier<string>): $Zone;
        addValue(arg0: number): $Zone;
        close(): void;
    }

}
