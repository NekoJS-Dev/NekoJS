import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Object2IntMap$Entry } from "java:it/unimi/dsi/fastutil/objects";
import { $Enum, $Float, $Record, $String } from "java:java/lang";
import { $List, $Map, $Optional, $Set } from "java:java/util";
import { $Consumer, $UnaryOperator } from "java:java/util/function";
import { $Holder, $HolderSet, $Holder_, $Registry } from "java:net/minecraft/core";
import { $DataComponentGetter, $DataComponentMap, $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $MutableComponent } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource, $StringRepresentable, $Unit, $Unit_ } from "java:net/minecraft/util";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $EquipmentSlot, $EquipmentSlotGroup, $EquipmentSlotGroup_, $EquipmentSlot_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Item, $Item$TooltipContext, $ItemInstance, $ItemStack, $ItemStack_, $Item_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $TooltipProvider } from "java:net/minecraft/world/item/component";
import { $EnchantmentAttributeEffect, $EnchantmentEntityEffect, $EnchantmentValueEffect } from "java:net/minecraft/world/item/enchantment/effects";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $LootContext, $Validatable, $ValidationContext } from "java:net/minecraft/world/level/storage/loot";
import { $LootItemCondition, $LootItemCondition$Builder } from "java:net/minecraft/world/level/storage/loot/predicates";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $MutableFloat } from "java:org/apache/commons/lang3/mutable";

export * as effects from "java:net/minecraft/world/item/enchantment/effects";

declare module "java:net/minecraft/world/item/enchantment" {
    export class $ConditionalEffect<T> extends $Record implements $Validatable {
        constructor(effect: T, requirements: $Optional<$LootItemCondition>);
        static codec<T>(arg0: $Codec<T>): $Codec<$ConditionalEffect<T>>;
        effect(): T;
        equals(arg0: object): boolean;
        hashCode(): number;
        matches(arg0: $LootContext): boolean;
        requirements(): $Optional<$LootItemCondition>;
        toString(): string;
        validate(arg0: $ValidationContext): void;
    }

    export class $EnchantedItemInUse extends $Record {
        constructor(arg0: $ItemStack_, arg1: $EquipmentSlot_, arg2: $LivingEntity);
        constructor(itemStack: $ItemStack_, inSlot: $EquipmentSlot_, owner: $LivingEntity, onBreak: $Consumer<$Item_>);
        equals(arg0: object): boolean;
        hashCode(): number;
        inSlot(): $EquipmentSlot;
        itemStack(): $ItemStack;
        onBreak(): $Consumer<$Item>;
        owner(): $LivingEntity;
        toString(): string;
    }

    export class $Enchantment extends $Record {
        constructor(description: $Component_, definition: $Enchantment$EnchantmentDefinition, exclusiveSet: $HolderSet<$Enchantment>, effects: $DataComponentMap);
        static CODEC: $Codec<$Holder<$Enchantment>>;
        static DIRECT_CODEC: $Codec<$Enchantment>;
        static MAX_LEVEL: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$Enchantment>>;
        get anvilCost(): number;
        getAnvilCost(): number;
        get maxLevel(): number;
        getMaxLevel(): number;
        get minLevel(): number;
        getMinLevel(): number;
        get supportedItems(): $HolderSet<$Item>;
        getSupportedItems(): $HolderSet<$Item>;
        get weight(): number;
        getWeight(): number;
        static applyEffects<T>(arg0: $ConditionalEffect<T>[], arg1: $LootContext, arg2: $Enchantment$GenericAction<T>): void;
        static areCompatible(arg0: $Holder<$Enchantment>, arg1: $Holder<$Enchantment>): boolean;
        static blockHitContext(arg0: $ServerLevel, arg1: number, arg2: $Entity, arg3: $Vec3_, arg4: $BlockState_): $LootContext;
        static constantCost(arg0: number): $Enchantment$Cost;
        static damageContext(arg0: $ServerLevel, arg1: number, arg2: $Entity, arg3: $DamageSource): $LootContext;
        static definition(arg0: $HolderSet<$Item_>, arg1: number, arg2: number, arg3: $Enchantment$Cost, arg4: $Enchantment$Cost, arg5: number, arg6?: $EquipmentSlotGroup_[]): $Enchantment$EnchantmentDefinition;
        static definition(arg0: $HolderSet<$Item_>, arg1: $HolderSet<$Item_>, arg2: number, arg3: number, arg4: $Enchantment$Cost, arg5: $Enchantment$Cost, arg6: number, arg7?: $EquipmentSlotGroup_[]): $Enchantment$EnchantmentDefinition;
        static doPostAttack(arg0: $TargetedConditionalEffect<$EnchantmentEntityEffect>, arg1: $ServerLevel, arg2: number, arg3: $EnchantedItemInUse, arg4: $Entity, arg5: $DamageSource): void;
        static dynamicCost(arg0: number, arg1: number): $Enchantment$Cost;
        static enchantment(arg0: $Enchantment$EnchantmentDefinition): $Enchantment$Builder;
        static entityContext(arg0: $ServerLevel, arg1: number, arg2: $Entity, arg3: $Vec3_): $LootContext;
        static getFullname(arg0: $Holder<$Enchantment>, arg1: number): $Component;
        static itemContext(arg0: $ServerLevel, arg1: number, arg2: $ItemInstance): $LootContext;
        static locationContext(arg0: $ServerLevel, arg1: number, arg2: $Entity, arg3: boolean): $LootContext;
        canEnchant(arg0: $ItemStack_): boolean;
        definition(): $Enchantment$EnchantmentDefinition;
        description(): $Component;
        doPostAttack(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $EnchantmentTarget_, arg4: $Entity, arg5: $DamageSource): void;
        doPostPiercingAttack(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $Entity): void;
        effects(): $DataComponentMap;
        equals(arg0: object): boolean;
        exclusiveSet(): $HolderSet<$Enchantment>;
        getEffects<T>(arg0: $DataComponentType<T[]>): $List<T>;
        getMaxCost(arg0: number): number;
        getMinCost(arg0: number): number;
        getSlotItems(arg0: $LivingEntity): $Map<$EquipmentSlot, $ItemStack>;
        hashCode(): number;
        isImmuneToDamage(arg0: $ServerLevel, arg1: number, arg2: $Entity, arg3: $DamageSource): boolean;
        isPrimaryItem(arg0: $ItemStack_): boolean;
        isSupportedItem(arg0: $ItemStack_): boolean;
        matchingSlot(arg0: $EquipmentSlot_): boolean;
        modifyAmmoCount(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: number): void;
        modifyArmorEffectivness(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: $DamageSource, arg5: number): void;
        modifyBlockExperience(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: number): void;
        modifyCrossbowChargeTime(arg0: $RandomSource, arg1: number, arg2: number): void;
        modifyDamageFilteredValue(arg0: $DataComponentType<$ConditionalEffect<$EnchantmentValueEffect>[]>, arg1: $ServerLevel, arg2: number, arg3: $ItemStack_, arg4: $Entity, arg5: $DamageSource, arg6: number): void;
        modifyDamageProtection(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: $DamageSource, arg5: number): void;
        modifyDamage(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: $DamageSource, arg5: number): void;
        modifyDurabilityChange(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: number): void;
        modifyDurabilityToRepairFromXp(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: number): void;
        modifyEntityFilteredValue(arg0: $DataComponentType<$ConditionalEffect<$EnchantmentValueEffect>[]>, arg1: $ServerLevel, arg2: number, arg3: $ItemStack_, arg4: $Entity, arg5: number): void;
        modifyFallBasedDamage(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: $DamageSource, arg5: number): void;
        modifyFishingLuckBonus(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: number): void;
        modifyFishingTimeReduction(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: number): void;
        modifyItemFilteredCount(arg0: $DataComponentType<$ConditionalEffect<$EnchantmentValueEffect>[]>, arg1: $ServerLevel, arg2: number, arg3: $ItemInstance, arg4: number): void;
        modifyKnockback(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: $DamageSource, arg5: number): void;
        modifyMobExperience(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: number): void;
        modifyPiercingCount(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: number): void;
        modifyProjectileCount(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: number): void;
        modifyProjectileSpread(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: number): void;
        modifyTridentReturnToOwnerAcceleration(arg0: $ServerLevel, arg1: number, arg2: $ItemStack_, arg3: $Entity, arg4: number): void;
        modifyTridentSpinAttackStrength(arg0: $RandomSource, arg1: number, arg2: number): void;
        modifyUnfilteredValue(arg0: $DataComponentType<$EnchantmentValueEffect>, arg1: $RandomSource, arg2: number, arg3: number): void;
        onHitBlock(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $Entity, arg4: $Vec3_, arg5: $BlockState_): void;
        onProjectileSpawned(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $Entity): void;
        runLocationChangedEffects(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $LivingEntity): void;
        stopLocationBasedEffects(arg0: number, arg1: $EnchantedItemInUse, arg2: $LivingEntity): void;
        tick(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $Entity): void;
        toString(): string;
    }

    export class $Enchantment$Builder {
        constructor(arg0: $Enchantment$EnchantmentDefinition);
        build(arg0: $Identifier_): $Enchantment;
        exclusiveWith(arg0: $HolderSet<$Enchantment>): $Enchantment$Builder;
        withCustomName(arg0: $UnaryOperator<$MutableComponent>): $Enchantment$Builder;
        withEffect<E>(arg0: $DataComponentType<$ConditionalEffect<E>[]>, arg1: E, arg2: $LootItemCondition$Builder): $Enchantment$Builder;
        withEffect<E>(arg0: $DataComponentType<$ConditionalEffect<E>[]>, arg1: E): $Enchantment$Builder;
        withEffect<E>(arg0: $DataComponentType<$TargetedConditionalEffect<E>[]>, arg1: $EnchantmentTarget_, arg2: $EnchantmentTarget_, arg3: E, arg4: $LootItemCondition$Builder): $Enchantment$Builder;
        withEffect<E>(arg0: $DataComponentType<$TargetedConditionalEffect<E>[]>, arg1: $EnchantmentTarget_, arg2: $EnchantmentTarget_, arg3: E): $Enchantment$Builder;
        withEffect(arg0: $DataComponentType<$EnchantmentAttributeEffect[]>, arg1: $EnchantmentAttributeEffect): $Enchantment$Builder;
        withEffect(arg0: $DataComponentType<$Unit_>): $Enchantment$Builder;
        withSpecialEffect<E>(arg0: $DataComponentType<E>, arg1: E): $Enchantment$Builder;
    }

    export class $Enchantment$Cost extends $Record {
        constructor(base: number, perLevelAboveFirst: number);
        static CODEC: $Codec<$Enchantment$Cost>;
        base(): number;
        calculate(arg0: number): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        perLevelAboveFirst(): number;
        toString(): string;
    }

    export class $Enchantment$EnchantmentDefinition extends $Record {
        constructor(supportedItems: $HolderSet<$Item_>, primaryItems: $Optional<$HolderSet<$Item_>>, weight: number, maxLevel: number, minCost: $Enchantment$Cost, maxCost: $Enchantment$Cost, anvilCost: number, slots: $EquipmentSlotGroup_[]);
        static CODEC: $MapCodec<$Enchantment$EnchantmentDefinition>;
        anvilCost(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        maxCost(): $Enchantment$Cost;
        maxLevel(): number;
        minCost(): $Enchantment$Cost;
        primaryItems(): $Optional<$HolderSet<$Item>>;
        slots(): $List<$EquipmentSlotGroup>;
        supportedItems(): $HolderSet<$Item>;
        toString(): string;
        weight(): number;
    }

    export interface $Enchantment$GenericAction<T> {
        apply(arg0: T): void;
    }

    export class $EnchantmentInstance extends $Record {
        constructor(enchantment: $Holder<$Enchantment>, level: number);
        enchantment(): $Holder<$Enchantment>;
        equals(arg0: object): boolean;
        hashCode(): number;
        level(): number;
        toString(): string;
        weight(): number;
    }

    export class $EnchantmentTarget {
        static ATTACKER: $EnchantmentTarget;
        static DAMAGING_ENTITY: $EnchantmentTarget;
        static VICTIM: $EnchantmentTarget;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EnchantmentTarget[];
        static valueOf(name: string): $EnchantmentTarget;
    }

    export class $ItemEnchantments implements $TooltipProvider {
        static CODEC: $Codec<$ItemEnchantments>;
        static EMPTY: $ItemEnchantments;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemEnchantments>;
        get empty(): boolean;
        isEmpty(): boolean;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer<$Component_>, arg2: $TooltipFlag, arg3: $DataComponentGetter): void;
        entrySet(): $Set<$Object2IntMap$Entry<$Holder<$Enchantment>>>;
        equals(arg0: object): boolean;
        getLevel(arg0: $Holder<$Enchantment>): number;
        hashCode(): number;
        keySet(): $Set<$Holder<$Enchantment>>;
        size(): number;
        toString(): string;
    }

    export interface $LevelBasedValue {
        bootstrap(arg0: $Registry<$MapCodec<$LevelBasedValue>>): $MapCodec<$LevelBasedValue>;
        calculate(arg0: number): number;
        codec(): $MapCodec<$LevelBasedValue>;
        constant(arg0: number): $LevelBasedValue$Constant;
        lookup(arg0: number[], arg1: $LevelBasedValue): $LevelBasedValue$Lookup;
        perLevel(arg0: number, arg1: number): $LevelBasedValue$Linear;
        perLevel(arg0: number): $LevelBasedValue$Linear;
        static CODEC: $Codec<$LevelBasedValue>;
        static DISPATCH_CODEC: $Codec<$LevelBasedValue>;
    }

    export class $LevelBasedValue$Constant extends $Record implements $LevelBasedValue {
        constructor(value: number);
        static CODEC: $Codec<$LevelBasedValue$Constant>;
        static TYPED_CODEC: $MapCodec<$LevelBasedValue$Constant>;
        calculate(arg0: number): number;
        codec(): $MapCodec<$LevelBasedValue$Constant>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        value(): number;
    }

    export class $LevelBasedValue$Linear extends $Record implements $LevelBasedValue {
        constructor(base: number, perLevelAboveFirst: number);
        static CODEC: $MapCodec<$LevelBasedValue$Linear>;
        base(): number;
        calculate(arg0: number): number;
        codec(): $MapCodec<$LevelBasedValue$Linear>;
        equals(arg0: object): boolean;
        hashCode(): number;
        perLevelAboveFirst(): number;
        toString(): string;
    }

    export class $LevelBasedValue$Lookup extends $Record implements $LevelBasedValue {
        constructor(values: number[], fallback: $LevelBasedValue);
        static CODEC: $MapCodec<$LevelBasedValue$Lookup>;
        calculate(arg0: number): number;
        codec(): $MapCodec<$LevelBasedValue$Lookup>;
        equals(arg0: object): boolean;
        fallback(): $LevelBasedValue;
        hashCode(): number;
        toString(): string;
        values(): $List<number>;
    }

    export class $TargetedConditionalEffect<T> extends $Record implements $Validatable {
        constructor(enchanted: $EnchantmentTarget_, affected: $EnchantmentTarget_, effect: T, requirements: $Optional<$LootItemCondition>);
        static codec<S>(arg0: $Codec<S>): $Codec<$TargetedConditionalEffect<S>>;
        static equipmentDropsCodec<S>(arg0: $Codec<S>): $Codec<$TargetedConditionalEffect<S>>;
        affected(): $EnchantmentTarget;
        effect(): T;
        enchanted(): $EnchantmentTarget;
        equals(arg0: object): boolean;
        hashCode(): number;
        matches(arg0: $LootContext): boolean;
        requirements(): $Optional<$LootItemCondition>;
        toString(): string;
        validate(arg0: $ValidationContext): void;
    }

    export type $EnchantmentTarget_ = $EnchantmentTarget | "ATTACKER" | "DAMAGING_ENTITY" | "VICTIM";
}
