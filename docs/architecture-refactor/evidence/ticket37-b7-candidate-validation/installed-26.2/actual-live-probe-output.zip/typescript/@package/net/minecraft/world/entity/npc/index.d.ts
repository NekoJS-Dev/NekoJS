export * as villager from "java:net/minecraft/world/entity/npc/villager";

