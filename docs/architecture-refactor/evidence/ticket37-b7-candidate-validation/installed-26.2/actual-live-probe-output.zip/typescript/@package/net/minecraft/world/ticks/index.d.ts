import { $Codec } from "java:com/mojang/serialization";
import { $Hash$Strategy } from "java:it/unimi/dsi/fastutil";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Comparator, $List } from "java:java/util";
import { $BiConsumer, $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Vec3i } from "java:net/minecraft/core";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";

declare module "java:net/minecraft/world/ticks" {
    export class $LevelChunkTicks<T> implements $TickContainerAccess, $SerializableTickContainer {
        constructor();
        constructor(arg0: $SavedTick<T>[]);
        get all(): $Stream<$ScheduledTick<T>>;
        getAll(): $Stream<$ScheduledTick<T>>;
        count(): number;
        hasScheduledTick(arg0: $BlockPos_, arg1: T): boolean;
        pack(arg0: number): $List<$SavedTick<T>>;
        peek(): $ScheduledTick<T>;
        poll(): $ScheduledTick<T>;
        removeIf(arg0: $Predicate<$ScheduledTick<T>>): void;
        schedule(arg0: $ScheduledTick<T>): void;
        unpack(arg0: number): void;
    }

    export interface $LevelTickAccess<T> extends $TickAccess {
        willTickThisTick(arg0: $BlockPos_, arg1: T): boolean;
    }

    export class $LevelTicks<T> implements $LevelTickAccess {
        constructor(arg0: $LongPredicate);
        addContainer(arg0: $ChunkPos, arg1: $LevelChunkTicks<T>): void;
        clearArea(arg0: $BoundingBox): void;
        copyAreaFrom(arg0: $LevelTicks<T>, arg1: $BoundingBox, arg2: $Vec3i): void;
        copyArea(arg0: $BoundingBox, arg1: $Vec3i): void;
        count(): number;
        hasScheduledTick(arg0: $BlockPos_, arg1: T): boolean;
        removeContainer(arg0: $ChunkPos): void;
        schedule(arg0: $ScheduledTick<T>): void;
        tick(arg0: number, arg1: number, arg2: $BiConsumer<$BlockPos_, T>): void;
        willTickThisTick(arg0: $BlockPos_, arg1: T): boolean;
    }

    export class $ProtoChunkTicks<T> implements $TickContainerAccess, $SerializableTickContainer {
        constructor();
        static load<T>(arg0: $SavedTick<T>[]): $ProtoChunkTicks<T>;
        count(): number;
        hasScheduledTick(arg0: $BlockPos_, arg1: T): boolean;
        pack(arg0: number): $List<$SavedTick<T>>;
        scheduledTicks(): $List<$SavedTick<T>>;
        schedule(arg0: $ScheduledTick<T>): void;
    }

    export class $SavedTick<T> extends $Record {
        constructor(type: T, pos: $BlockPos_, delay: number, priority: $TickPriority_);
        static UNIQUE_TICK_HASH: $Hash$Strategy<$SavedTick<any>>;
        static codec<T>(arg0: $Codec<T>): $Codec<$SavedTick<T>>;
        static filterTickListForChunk<T>(arg0: $SavedTick<T>[], arg1: $ChunkPos): $List<$SavedTick<T>>;
        static probe<T>(arg0: T, arg1: $BlockPos_): $SavedTick<T>;
        delay(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        pos(): $BlockPos;
        priority(): $TickPriority;
        toString(): string;
        type(): T;
        unpack(arg0: number, arg1: number): $ScheduledTick<T>;
    }

    export class $ScheduledTick<T> extends $Record {
        constructor(arg0: T, arg1: $BlockPos_, arg2: number, arg3: number);
        constructor(type: T, pos: $BlockPos_, triggerTick: number, priority: $TickPriority_, subTickOrder: number);
        static DRAIN_ORDER: $Comparator<$ScheduledTick<any>>;
        static INTRA_TICK_DRAIN_ORDER: $Comparator<$ScheduledTick<any>>;
        static UNIQUE_TICK_HASH: $Hash$Strategy<$ScheduledTick<any>>;
        static probe<T>(arg0: T, arg1: $BlockPos_): $ScheduledTick<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        pos(): $BlockPos;
        priority(): $TickPriority;
        subTickOrder(): number;
        toSavedTick(arg0: number): $SavedTick<T>;
        toString(): string;
        triggerTick(): number;
        type(): T;
    }

    export interface $SerializableTickContainer<T> {
        pack(arg0: number): $List<$SavedTick<T>>;
    }

    export interface $TickAccess<T> {
        count(): number;
        hasScheduledTick(arg0: $BlockPos_, arg1: T): boolean;
        schedule(arg0: $ScheduledTick<T>): void;
    }

    export interface $TickContainerAccess<T> extends $TickAccess {
    }

    export class $TickPriority {
        static EXTREMELY_HIGH: $TickPriority;
        static EXTREMELY_LOW: $TickPriority;
        static HIGH: $TickPriority;
        static LOW: $TickPriority;
        static NORMAL: $TickPriority;
        static VERY_HIGH: $TickPriority;
        static VERY_LOW: $TickPriority;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TickPriority[];
        static valueOf(name: string): $TickPriority;
    }

    export type $TickPriority_ = $TickPriority | "EXTREMELY_HIGH" | "EXTREMELY_LOW" | "HIGH" | "LOW" | "NORMAL" | "VERY_HIGH" | "VERY_LOW";
}
