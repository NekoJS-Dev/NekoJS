import { $MinecraftServer } from "java:net/minecraft/server";
import { $Level } from "java:net/minecraft/world/level";
import { $Event, $ICancellableEvent } from "java:net/neoforged/bus/api";
import { $EntityEvent } from "java:net/neoforged/neoforge/event/entity";
import { $PlayerEvent } from "java:net/neoforged/neoforge/event/entity/player";

declare module "java:net/neoforged/neoforge/event/tick" {
    export class $EntityTickEvent extends $EntityEvent {
    }

    export class $EntityTickEvent$Post extends $EntityTickEvent {
        constructor(arg0: $Entity);
    }

    export class $EntityTickEvent$Pre extends $EntityTickEvent implements $ICancellableEvent {
        constructor(arg0: $Entity);
    }

    export class $LevelTickEvent extends $Event {
        get level(): $Level;
        getLevel(): $Level;
        hasTime(): boolean;
    }

    export class $LevelTickEvent$Post extends $LevelTickEvent {
        constructor(arg0: $BooleanSupplier, arg1: $Level);
    }

    export class $LevelTickEvent$Pre extends $LevelTickEvent {
        constructor(arg0: $BooleanSupplier, arg1: $Level);
    }

    export class $PlayerTickEvent extends $PlayerEvent {
    }

    export class $PlayerTickEvent$Post extends $PlayerTickEvent {
        constructor(arg0: $Player);
    }

    export class $PlayerTickEvent$Pre extends $PlayerTickEvent {
        constructor(arg0: $Player);
    }

    export class $ServerTickEvent extends $Event {
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        hasTime(): boolean;
    }

    export class $ServerTickEvent$Post extends $ServerTickEvent {
        constructor(arg0: $BooleanSupplier, arg1: $MinecraftServer);
    }

    export class $ServerTickEvent$Pre extends $ServerTickEvent {
        constructor(arg0: $BooleanSupplier, arg1: $MinecraftServer);
    }

}
