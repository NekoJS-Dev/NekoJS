import { $Long2ObjectFunction, $Long2ObjectMap } from "java:it/unimi/dsi/fastutil/longs";
import { $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $SectionPos } from "java:net/minecraft/core";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $ChunkEvent$Unload } from "java:net/neoforged/neoforge/event/level";

declare module "java:net/neoforged/neoforge/model/data" {
    export class $ModelData {
        static EMPTY: $ModelData;
        get properties(): $Set<$ModelProperty<any>>;
        getProperties(): $Set<$ModelProperty<any>>;
        static builder(): $ModelData$Builder;
        static of<T>(arg0: $ModelProperty<T>, arg1: T): $ModelData;
        derive(): $ModelData$Builder;
        get<T>(arg0: $ModelProperty<T>): T;
        has(arg0: $ModelProperty<any>): boolean;
    }

    export class $ModelData$Builder {
        build(): $ModelData;
        with<T>(arg0: $ModelProperty<T>, arg1: T): $ModelData$Builder;
    }

    export class $ModelDataManager {
        constructor(arg0: $Level);
        static EMPTY_SNAPSHOT: $Long2ObjectFunction<$ModelData>;
        static onChunkUnload(arg0: $ChunkEvent$Unload): void;
        getAt(arg0: $BlockPos_): $ModelData;
        getAt(arg0: $SectionPos): $Long2ObjectMap<$ModelData>;
        requestRefresh(arg0: $BlockEntity): void;
        snapshotSectionRegion(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): $Long2ObjectFunction<$ModelData>;
    }

    export class $ModelProperty<T> implements $Predicate {
        constructor();
        constructor(arg0: $Predicate<T>);
        test(arg0: T): boolean;
    }

}
