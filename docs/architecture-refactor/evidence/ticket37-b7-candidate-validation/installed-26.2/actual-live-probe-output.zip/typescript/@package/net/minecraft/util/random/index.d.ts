import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Collection, $List, $Optional } from "java:java/util";
import { $Function, $Predicate } from "java:java/util/function";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/util/random" {
    export class $Weighted<T> extends $Record {
        constructor(value: T, weight: number);
        static codec<E>(arg0: $Codec<E>): $Codec<$Weighted<E>>;
        static codec<E>(arg0: $MapCodec<E>): $Codec<$Weighted<E>>;
        static streamCodec<B, T>(arg0: $StreamCodec<B, T>): $StreamCodec<B, $Weighted<T>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        map<U>(arg0: $Function<T, U>): $Weighted<U>;
        toString(): string;
        value(): T;
        weight(): number;
    }

    export class $WeightedList<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        static builder<E>(): $WeightedList$Builder<E>;
        static codec<E>(arg0: $Codec<E>): $Codec<$WeightedList<E>>;
        static codec<E>(arg0: $MapCodec<E>): $Codec<$WeightedList<E>>;
        static nonEmptyCodec<E>(arg0: $Codec<E>): $Codec<$WeightedList<E>>;
        static nonEmptyCodec<E>(arg0: $MapCodec<E>): $Codec<$WeightedList<E>>;
        static of<E>(arg0?: E[]): $WeightedList<E>;
        static of<E>(arg0: E): $WeightedList<E>;
        static of<E>(arg0: $Weighted<E>[]): $WeightedList<E>;
        static of<E>(arg0?: $Weighted<E>[]): $WeightedList<E>;
        static of<E>(): $WeightedList<E>;
        static streamCodec<E, B>(arg0: $StreamCodec<B, E>): $StreamCodec<B, $WeightedList<E>>;
        contains(arg0: E): boolean;
        equals(arg0: object): boolean;
        getRandomOrThrow(arg0: $RandomSource): E;
        getRandom(arg0: $RandomSource): $Optional<E>;
        hashCode(): number;
        map<T>(arg0: $Function<E, T>): $WeightedList<T>;
        unwrap(): $List<$Weighted<E>>;
    }

    export class $WeightedList$Builder<E> {
        constructor();
        get list(): $List<$Weighted<E>>;
        getList(): $List<$Weighted<E>>;
        addAll(arg0: $Weighted<E>[]): $WeightedList$Builder<E>;
        addAll(arg0: $WeightedList<E>): $WeightedList$Builder<E>;
        add(arg0: E, arg1: number): $WeightedList$Builder<E>;
        add(arg0: E): $WeightedList$Builder<E>;
        add(arg0: $Weighted<E>): $WeightedList$Builder<E>;
        build(): $WeightedList<E>;
        removeIf(arg0: $Predicate<$Weighted<E>>): $WeightedList$Builder<E>;
        remove(arg0: E): $WeightedList$Builder<E>;
        remove(arg0: $Weighted<E>): $WeightedList$Builder<E>;
    }

}
