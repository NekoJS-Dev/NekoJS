declare module "java:net/neoforged/bus/api" {
    export class $Event {
    }

    export interface $ICancellableEvent {
        isCanceled(): boolean;
        setCanceled(arg0: boolean): void;
    }

}
