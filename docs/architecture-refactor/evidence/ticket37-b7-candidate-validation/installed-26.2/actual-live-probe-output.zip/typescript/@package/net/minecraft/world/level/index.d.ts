import type { RegistryTypes } from "@special/types";
import { $Codec, $Dynamic, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $AttachedData, $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $LevelExtension } from "java:com/tkisor/nekojs/api/inject";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Long2ObjectOpenHashMap, $LongSet } from "java:it/unimi/dsi/fastutil/longs";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $AutoCloseable, $Class, $Enum, $Float, $Iterable, $Record, $String } from "java:java/lang";
import { $ArrayList, $Collection, $List, $Map, $Optional, $UUID } from "java:java/util";
import { $BiFunction, $Consumer, $Function, $Predicate, $Supplier } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $CrashReport, $CrashReportCategory } from "java:net/minecraft";
import { $CommandSource, $CommandSourceStack } from "java:net/minecraft/commands";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $HolderLookup, $HolderSet, $Holder_, $RegistryAccess, $SectionPos } from "java:net/minecraft/core";
import { $ExplosionParticleInfo, $ParticleOptions } from "java:net/minecraft/core/particles";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $ChunkMap, $ServerLevel, $Ticket, $TicketType, $TicketType_, $WorldGenRegion } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_, $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $RandomSource, $StringRepresentable, $StringRepresentable$EnumCodec } from "java:net/minecraft/util";
import { $WeightedList } from "java:net/minecraft/util/random";
import { $Difficulty, $DifficultyInstance, $Difficulty_, $TickRateManager } from "java:net/minecraft/world";
import { $EnvironmentAttributeReader, $EnvironmentAttributeSystem } from "java:net/minecraft/world/attribute";
import { $ClockManager } from "java:net/minecraft/world/clock";
import { $DamageSource, $DamageSources } from "java:net/minecraft/world/damagesource";
import { $Entity, $LivingEntity, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $Abilities, $Player } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $PotionBrewing } from "java:net/minecraft/world/item/alchemy";
import { $FireworkExplosion } from "java:net/minecraft/world/item/component";
import { $RecipeAccess } from "java:net/minecraft/world/item/crafting";
import { $Biome, $Biome$Precipitation, $Biome$Precipitation_, $BiomeManager, $BiomeManager$NoiseBiomeSource } from "java:net/minecraft/world/level/biome";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_, $FuelValues, $TickingBlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $WorldBorder } from "java:net/minecraft/world/level/border";
import { $BlockColumn, $ChunkAccess, $ChunkSource, $LevelChunk, $PalettedContainerFactory, $StructureAccess } from "java:net/minecraft/world/level/chunk";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";
import { $DimensionType } from "java:net/minecraft/world/level/dimension";
import { $EntityTypeTest } from "java:net/minecraft/world/level/entity";
import { $GameEvent, $GameEvent$Context, $GameEvent_ } from "java:net/minecraft/world/level/gameevent";
import { $Heightmap$Types, $Heightmap$Types_ } from "java:net/minecraft/world/level/levelgen";
import { $Structure, $StructureCheckResult, $StructureCheckResult_, $StructureStart } from "java:net/minecraft/world/level/levelgen/structure";
import { $StructurePlacement } from "java:net/minecraft/world/level/levelgen/structure/placement";
import { $LevelLightEngine } from "java:net/minecraft/world/level/lighting";
import { $Fluid, $FluidState, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $Orientation } from "java:net/minecraft/world/level/redstone";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";
import { $MapId, $MapItemSavedData } from "java:net/minecraft/world/level/saveddata/maps";
import { $LevelData, $LevelData$RespawnData, $ValueInput, $ValueOutput } from "java:net/minecraft/world/level/storage";
import { $AABB, $BlockHitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $CollisionContext, $VoxelShape } from "java:net/minecraft/world/phys/shapes";
import { $Scoreboard } from "java:net/minecraft/world/scores";
import { $LevelTickAccess, $ScheduledTick, $TickPriority, $TickPriority_ } from "java:net/minecraft/world/ticks";
import { $AttachmentHolder } from "java:net/neoforged/neoforge/attachment";
import { $IBlockGetterExtension, $ILevelExtension, $ILevelReaderExtension } from "java:net/neoforged/neoforge/common/extensions";
import { $BlockSnapshot } from "java:net/neoforged/neoforge/common/util";
import { $ForcedChunkManager$TicketTracker } from "java:net/neoforged/neoforge/common/world/chunk";

export * as biome from "java:net/minecraft/world/level/biome";
export * as block from "java:net/minecraft/world/level/block";
export * as border from "java:net/minecraft/world/level/border";
export * as chunk from "java:net/minecraft/world/level/chunk";
export * as dimension from "java:net/minecraft/world/level/dimension";
export * as entity from "java:net/minecraft/world/level/entity";
export * as gameevent from "java:net/minecraft/world/level/gameevent";
export * as gamerules from "java:net/minecraft/world/level/gamerules";
export * as levelgen from "java:net/minecraft/world/level/levelgen";
export * as lighting from "java:net/minecraft/world/level/lighting";
export * as material from "java:net/minecraft/world/level/material";
export * as pathfinder from "java:net/minecraft/world/level/pathfinder";
export * as portal from "java:net/minecraft/world/level/portal";
export * as redstone from "java:net/minecraft/world/level/redstone";
export * as saveddata from "java:net/minecraft/world/level/saveddata";
export * as storage from "java:net/minecraft/world/level/storage";
export * as timers from "java:net/minecraft/world/level/timers";
export * as validation from "java:net/minecraft/world/level/validation";

declare module "java:net/minecraft/world/level" {
    export class $BaseCommandBlock {
        constructor();
        get command(): string;
        getCommand(): string;
        set command(value: string);
        get customName(): $Component;
        getCustomName(): $Component;
        set customName(value: $Component_);
        get lastOutput(): $Component;
        getLastOutput(): $Component;
        set lastOutput(value: $Component_);
        get name(): $Component;
        getName(): $Component;
        get successCount(): number;
        getSuccessCount(): number;
        set successCount(value: number);
        get trackOutput(): boolean;
        isTrackOutput(): boolean;
        set trackOutput(value: boolean);
        get valid(): boolean;
        isValid(): boolean;
        createCommandSourceStack(arg0: $ServerLevel, arg1: $CommandSource): $CommandSourceStack;
        load(arg0: $ValueInput): void;
        onUpdated(arg0: $ServerLevel): void;
        performCommand(arg0: $ServerLevel): boolean;
        save(arg0: $ValueOutput): void;
    }

    export interface $BlockAndLightGetter extends $BlockGetter {
        canSeeSky(arg0: $BlockPos_): boolean;
        getBrightness(arg0: $LightLayer_, arg1: $BlockPos_): number;
        getLightEngine(): $LevelLightEngine;
        getRawBrightness(arg0: $BlockPos_, arg1: number): number;
    }

    export interface $BlockGetter extends $LevelHeightAccessor, $IBlockGetterExtension {
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        forEachBlockIntersectedBetween(arg0: $Vec3_, arg1: $Vec3_, arg2: $AABB, arg3: $BlockGetter$BlockStepVisitor): boolean;
        getBlockEntity<T>(arg0: $BlockPos_, arg1: $BlockEntityType<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier<$VoxelShape>): number;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getLightEmission(arg0: $BlockPos_): number;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        traverseBlocks<T, C>(arg0: $Vec3_, arg1: $Vec3_, arg2: C, arg3: $BiFunction<C, $BlockPos_, T>, arg4: $Function<C, T>): T;
    }

    export interface $BlockGetter$BlockStepVisitor {
        visit(arg0: $BlockPos_, arg1: number): boolean;
    }

    export class $CardinalLighting extends $Record {
        constructor(down: number, up: number, north: number, south: number, west: number, east: number);
        static DEFAULT: $CardinalLighting;
        static NETHER: $CardinalLighting;
        byFace(arg0: $Direction_): number;
        down(): number;
        east(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        north(): number;
        south(): number;
        toString(): string;
        up(): number;
        west(): number;
    }

    export class $CardinalLighting$Type {
        static DEFAULT: $CardinalLighting$Type;
        static NETHER: $CardinalLighting$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CardinalLighting$Type[];
        static valueOf(name: string): $CardinalLighting$Type;
    }

    export class $ChunkPos extends $Record {
        constructor(x: number, z: number);
        static CODEC: $Codec<$ChunkPos>;
        static INVALID_CHUNK_POS: number;
        static REGION_MAX_INDEX: number;
        static REGION_SIZE: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ChunkPos>;
        static ZERO: $ChunkPos;
        get maxBlockX(): number;
        getMaxBlockX(): number;
        get maxBlockZ(): number;
        getMaxBlockZ(): number;
        get middleBlockX(): number;
        getMiddleBlockX(): number;
        get middleBlockZ(): number;
        getMiddleBlockZ(): number;
        get minBlockX(): number;
        getMinBlockX(): number;
        get minBlockZ(): number;
        getMinBlockZ(): number;
        get regionLocalX(): number;
        getRegionLocalX(): number;
        get regionLocalZ(): number;
        getRegionLocalZ(): number;
        get regionX(): number;
        getRegionX(): number;
        get regionZ(): number;
        getRegionZ(): number;
        get worldPosition(): $BlockPos;
        getWorldPosition(): $BlockPos;
        get valid(): boolean;
        isValid(): boolean;
        static containing(arg0: $BlockPos_): $ChunkPos;
        static fromSectionNode(arg0: number): number;
        static getRegionX(arg0: number): number;
        static getRegionZ(arg0: number): number;
        static getX(arg0: number): number;
        static getZ(arg0: number): number;
        static hash(arg0: number, arg1: number): number;
        static isValid(arg0: number, arg1: number): boolean;
        static maxFromRegion(arg0: number, arg1: number): $ChunkPos;
        static minFromRegion(arg0: number, arg1: number): $ChunkPos;
        static pack(arg0: number, arg1: number): number;
        static pack(arg0: $BlockPos_): number;
        static rangeClosed(arg0: $ChunkPos, arg1: number): $Stream<$ChunkPos>;
        static rangeClosed(arg0: $ChunkPos, arg1: $ChunkPos): $Stream<$ChunkPos>;
        static unpack(arg0: number): $ChunkPos;
        contains(arg0: $BlockPos_): boolean;
        distanceSquared(arg0: number): number;
        distanceSquared(arg0: $ChunkPos): number;
        equals(arg0: object): boolean;
        getBlockAt(arg0: number, arg1: number, arg2: number): $BlockPos;
        getBlockX(arg0: number): number;
        getBlockZ(arg0: number): number;
        getChessboardDistance(arg0: number, arg1: number): number;
        getChessboardDistance(arg0: $ChunkPos): number;
        getMiddleBlockPosition(arg0: number): $BlockPos;
        hashCode(): number;
        pack(): number;
        toString(): string;
        x(): number;
        z(): number;
    }

    export class $ClipBlockStateContext {
        constructor(arg0: $Vec3_, arg1: $Vec3_, arg2: $Predicate<$BlockState_>);
        get from(): $Vec3;
        getFrom(): $Vec3;
        get to(): $Vec3;
        getTo(): $Vec3;
        get targetBlock(): $Predicate<$BlockState>;
        isTargetBlock(): $Predicate<$BlockState>;
    }

    export class $ClipContext {
        constructor(arg0: $Vec3_, arg1: $Vec3_, arg2: $ClipContext$Block_, arg3: $ClipContext$Fluid_, arg4: $Entity);
        constructor(arg0: $Vec3_, arg1: $Vec3_, arg2: $ClipContext$Block_, arg3: $ClipContext$Fluid_, arg4: $CollisionContext);
        get from(): $Vec3;
        getFrom(): $Vec3;
        get to(): $Vec3;
        getTo(): $Vec3;
        getBlockShape(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): $VoxelShape;
        getFluidShape(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): $VoxelShape;
    }

    export class $ClipContext$Block {
        static COLLIDER: $ClipContext$Block;
        static FALLDAMAGE_RESETTING: $ClipContext$Block;
        static OUTLINE: $ClipContext$Block;
        static VISUAL: $ClipContext$Block;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClipContext$Block[];
        static valueOf(name: string): $ClipContext$Block;
    }

    export class $ClipContext$Fluid {
        static ANY: $ClipContext$Fluid;
        static NONE: $ClipContext$Fluid;
        static SOURCE_ONLY: $ClipContext$Fluid;
        static WATER: $ClipContext$Fluid;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClipContext$Fluid[];
        static valueOf(name: string): $ClipContext$Fluid;
    }

    export interface $ClipContext$ShapeGetter {
        get(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $CollisionContext): $VoxelShape;
    }

    export interface $CollisionGetter extends $BlockGetter {
        clipIncludingBorder(arg0: $ClipContext): $BlockHitResult;
        collidesWithSuffocatingBlock(arg0: $Entity, arg1: $AABB): boolean;
        findFreePosition(arg0: $Entity, arg1: $VoxelShape, arg2: $Vec3_, arg3: number, arg4: number, arg5: number): $Optional<$Vec3>;
        findSupportingBlock(arg0: $Entity, arg1: $AABB): $Optional<$BlockPos>;
        getBlockAndLiquidCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getBlockCollisionsFromContext(arg0: $CollisionContext, arg1: $AABB): $Iterable<$VoxelShape>;
        getBlockCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getPreMoveCollisions(arg0: $Entity, arg1: $AABB, arg2: $Vec3_): $Iterable<$VoxelShape>;
        getWorldBorder(): $WorldBorder;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
        isUnobstructed(arg0: $Entity): boolean;
        isUnobstructed(arg0: $BlockState_, arg1: $BlockPos_, arg2: $CollisionContext): boolean;
        noBlockCollision(arg0: $Entity, arg1: $AABB, arg2: boolean): boolean;
        noBlockCollision(arg0: $Entity, arg1: $AABB): boolean;
        noBorderCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity, arg1: $AABB, arg2: boolean): boolean;
        noCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity): boolean;
        noCollision(arg0: $AABB): boolean;
        noEntityCollision(arg0: $Entity, arg1: $AABB): boolean;
    }

    export interface $CommonLevelAccessor extends $LevelReader, $LevelSimulatedRW, $EntityGetter {
        getBlockEntity<T>(arg0: $BlockPos_, arg1: $BlockEntityType<T>): $Optional<T>;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getHeightmapPos(arg0: $Heightmap$Types_, arg1: $BlockPos_): $BlockPos;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
    }

    export interface $CustomSpawner {
        tick(arg0: $ServerLevel, arg1: boolean): void;
    }

    export class $DataPackConfig {
        constructor(arg0: string[], arg1: string[]);
        static CODEC: $Codec<$DataPackConfig>;
        static DEFAULT: $DataPackConfig;
        get disabled(): $List<string>;
        getDisabled(): $List<string>;
        get enabled(): $List<string>;
        getEnabled(): $List<string>;
        addModPacks(arg0: string[]): void;
    }

    export interface $EntityGetter {
        getEntitiesOfClass<T>(arg0: $Class<T>, arg1: $AABB, arg2: $Predicate<any>): $List<T>;
        getEntitiesOfClass<T>(arg0: $Class<T>, arg1: $AABB): $List<T>;
        getEntities(arg0: $Entity, arg1: $AABB, arg2: $Predicate<any>): $List<$Entity>;
        getEntities(arg0: $Entity, arg1: $AABB): $List<$Entity>;
        getEntities<T>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate<any>): $List<T>;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getNearestPlayer(arg0: number, arg1: number, arg2: number, arg3: number, arg4: boolean): $Player;
        getNearestPlayer(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $Predicate<$Entity>): $Player;
        getNearestPlayer(arg0: $Entity, arg1: number): $Player;
        getPlayerByUUID(arg0: string): $Player;
        hasNearbyAlivePlayer(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
        players(): $List<$Player>;
    }

    export interface $Explosion {
        canTriggerBlocks(): boolean;
        center(): $Vec3;
        getBlockInteraction(): $Explosion$BlockInteraction;
        getDefaultDamageSource(arg0: $Level, arg1: $Entity): $DamageSource;
        getDirectSourceEntity(): $Entity;
        getIndirectSourceEntity(arg0: $Entity): $LivingEntity;
        getIndirectSourceEntity(): $LivingEntity;
        level(): $ServerLevel;
        radius(): number;
        shouldAffectBlocklikeEntities(): boolean;
    }

    export class $Explosion$BlockInteraction {
        static DESTROY: $Explosion$BlockInteraction;
        static DESTROY_WITH_DECAY: $Explosion$BlockInteraction;
        static KEEP: $Explosion$BlockInteraction;
        static TRIGGER_BLOCK: $Explosion$BlockInteraction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Explosion$BlockInteraction[];
        static valueOf(name: string): $Explosion$BlockInteraction;
    }

    export class $ExplosionDamageCalculator {
        constructor();
        getBlockExplosionResistance(arg0: $Explosion, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $BlockState_, arg4: $FluidState): $Optional<number>;
        getEntityDamageAmount(arg0: $Explosion, arg1: $Entity, arg2: number): number;
        getKnockbackMultiplier(arg0: $Entity): number;
        shouldBlockExplode(arg0: $Explosion, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $BlockState_, arg4: number): boolean;
        shouldDamageEntity(arg0: $Explosion, arg1: $Entity): boolean;
    }

    export class $GameType {
        static ADVENTURE: $GameType;
        static CREATIVE: $GameType;
        static SPECTATOR: $GameType;
        static SURVIVAL: $GameType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GameType[];
        static valueOf(name: string): $GameType;
    }

    export interface $ItemLike {
        asItem(): $Item;
    }

    export class $Level extends $AttachmentHolder implements $LevelAccessor, $AutoCloseable, $ILevelExtension, $LevelExtension {
        static ACROSS_THE_WHOLE_WORLD: number;
        static END: $ResourceKey<$Level>;
        static LONG_PARTICLE_CLIP_RANGE: number;
        static MAX_BRIGHTNESS: number;
        static MAX_ENTITY_SPAWN_Y: number;
        static MAX_LEVEL_SIZE: number;
        static MIN_ENTITY_SPAWN_Y: number;
        static NETHER: $ResourceKey<$Level>;
        static OVERWORLD: $ResourceKey<$Level>;
        static RESOURCE_KEY_CODEC: $Codec<$ResourceKey<$Level>>;
        static SHORT_PARTICLE_CLIP_RANGE: number;
        captureBlockSnapshots: boolean;
        capturedBlockSnapshots: $ArrayList<$BlockSnapshot>;
        oRainLevel: number;
        oThunderLevel: number;
        rainLevel: number;
        restoringBlockSnapshots: boolean;
        thunderLevel: number;
        get biomeManager(): $BiomeManager;
        getBiomeManager(): $BiomeManager;
        get defaultClockTime(): number;
        getDefaultClockTime(): number;
        get levelData(): $LevelData;
        getLevelData(): $LevelData;
        get lightEngine(): $LevelLightEngine;
        getLightEngine(): $LevelLightEngine;
        get maxEntityRadius(): number;
        getMaxEntityRadius(): number;
        get nextEntityId(): number;
        getNextEntityId(): number;
        get overworldClockTime(): number;
        getOverworldClockTime(): number;
        get random(): $RandomSource;
        getRandom(): $RandomSource;
        get respawnData(): $LevelData$RespawnData;
        getRespawnData(): $LevelData$RespawnData;
        set respawnData(value: $LevelData$RespawnData);
        get scoreboard(): $Scoreboard;
        getScoreboard(): $Scoreboard;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get skyDarken(): number;
        getSkyDarken(): number;
        get brightOutside(): boolean;
        isBrightOutside(): boolean;
        get clientSide(): boolean;
        isClientSide(): boolean;
        get darkOutside(): boolean;
        isDarkOutside(): boolean;
        get debug(): boolean;
        isDebug(): boolean;
        get raining(): boolean;
        isRaining(): boolean;
        get thundering(): boolean;
        isThundering(): boolean;
        static isInSpawnableBounds(arg0: $BlockPos_): boolean;
        addAlwaysVisibleParticle(arg0: $ParticleOptions, arg1: boolean, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): void;
        addAlwaysVisibleParticle(arg0: $ParticleOptions, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): void;
        addBlockEntityTicker(arg0: $TickingBlockEntity): void;
        addDestroyBlockEffect(arg0: $BlockPos_, arg1: $BlockState_): void;
        addFreshBlockEntities(arg0: $BlockEntity[]): void;
        addParticle(arg0: $ParticleOptions, arg1: boolean, arg2: boolean, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number, arg8: number): void;
        addParticle(arg0: $ParticleOptions, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): void;
        blockEntityChanged(arg0: $BlockPos_): void;
        blockEvent(arg0: $BlockPos_, arg1: $Block_, arg2: number, arg3: number): void;
        broadcastDamageEvent(arg0: $Entity, arg1: $DamageSource): void;
        broadcastEntityEvent(arg0: $Entity, arg1: number): void;
        canHaveWeather(): boolean;
        clockManager(): $ClockManager;
        close(): void;
        createFireworks(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: $FireworkExplosion[]): void;
        damageSources(): $DamageSources;
        destroyBlockProgress(arg0: number, arg1: $BlockPos_, arg2: number): void;
        destroyBlock(arg0: $BlockPos_, arg1: boolean, arg2: $Entity, arg3: number): boolean;
        dimensionTypeRegistration(): $Holder<$DimensionType>;
        dimensionType(): $DimensionType;
        dimension(): $ResourceKey<$Level>;
        dragonParts(): $Collection<$PartEntity<any>>;
        environmentAttributes(): $EnvironmentAttributeSystem;
        explode(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: number, arg5: boolean, arg6: $Level$ExplosionInteraction_): void;
        explode(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $Level$ExplosionInteraction_): void;
        explode(arg0: $Entity, arg1: $DamageSource, arg2: $ExplosionDamageCalculator, arg3: number, arg4: number, arg5: number, arg6: number, arg7: boolean, arg8: $Level$ExplosionInteraction_, arg9: $ParticleOptions, arg10: $ParticleOptions, arg11: $WeightedList<$ExplosionParticleInfo>, arg12: $Holder<$SoundEvent_>): void;
        explode(arg0: $Entity, arg1: $DamageSource, arg2: $ExplosionDamageCalculator, arg3: number, arg4: number, arg5: number, arg6: number, arg7: boolean, arg8: $Level$ExplosionInteraction_): void;
        explode(arg0: $Entity, arg1: $DamageSource, arg2: $ExplosionDamageCalculator, arg3: $Vec3_, arg4: number, arg5: boolean, arg6: $Level$ExplosionInteraction_): void;
        fillReportDetails(arg0: $CrashReport): $CrashReportCategory;
        fuelValues(): $FuelValues;
        gatherChunkSourceStats(): string;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockRandomPos(arg0: number, arg1: number, arg2: number, arg3: number): $BlockPos;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getChunkAt(arg0: $BlockPos_): $LevelChunk;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_, arg3: boolean): $ChunkAccess;
        getChunk(arg0: number, arg1: number): $LevelChunk;
        getClientLeafTintColor(arg0: $BlockPos_): number;
        getEntities(arg0: $Entity, arg1: $AABB, arg2: $Predicate<any>): $List<$Entity>;
        getEntities<T>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate<any>, arg3: any[], arg4: number): void;
        getEntities<T>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate<any>, arg3: any[]): void;
        getEntities<T>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate<any>): $List<T>;
        getEntityInAnyDimension(arg0: string): $Entity;
        getEntity(arg0: number): $Entity;
        getEntity(arg0: string): $Entity;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getMapData(arg0: $MapId): $MapItemSavedData;
        getPlayerInAnyDimension(arg0: string): $Player;
        getPushableEntities(arg0: $Entity, arg1: $AABB): $List<$Entity>;
        getRainLevel(arg0: number): number;
        getThunderLevel(arg0: number): number;
        getWorldBorderAdjustedRespawnData(arg0: $LevelData$RespawnData): $LevelData$RespawnData;
        globalLevelEvent(arg0: number, arg1: $BlockPos_, arg2: number): void;
        guardEntityTick<T>(arg0: $Consumer<T>, arg1: T): void;
        hasEntities<T>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate<any>): boolean;
        increaseMaxEntityRadius(arg0: number): number;
        isFluidAtPosition(arg0: $BlockPos_, arg1: $Predicate<$FluidState>): boolean;
        isInValidBounds(arg0: $BlockPos_): boolean;
        isInWorldBounds(arg0: $BlockPos_): boolean;
        isLoaded(arg0: $BlockPos_): boolean;
        isRainingAt(arg0: $BlockPos_): boolean;
        isStateAtPosition(arg0: $BlockPos_, arg1: $Predicate<$BlockState_>): boolean;
        loadedAndEntityCanStandOnFace(arg0: $BlockPos_, arg1: $Entity, arg2: $Direction_): boolean;
        loadedAndEntityCanStandOn(arg0: $BlockPos_, arg1: $Entity): boolean;
        markAndNotifyBlock(arg0: $BlockPos_, arg1: $LevelChunk, arg2: $BlockState_, arg3: $BlockState_, arg4: number, arg5: number): void;
        mayInteract(arg0: $Entity, arg1: $BlockPos_): boolean;
        neighborChanged(arg0: $BlockPos_, arg1: $Block_, arg2: $Orientation): void;
        neighborChanged(arg0: $BlockState_, arg1: $BlockPos_, arg2: $Block_, arg3: $Orientation, arg4: boolean): void;
        neighborShapeChanged(arg0: $Direction_, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $BlockState_, arg4: number, arg5: number): void;
        data(): $AttachedData;
        nextSubTickCount(): number;
        noSave(): boolean;
        onBlockEntityAdded(arg0: $BlockEntity): void;
        palettedContainerFactory(): $PalettedContainerFactory;
        playLocalSound(arg0: number, arg1: number, arg2: number, arg3: $SoundEvent_, arg4: $SoundSource_, arg5: number, arg6: number, arg7: boolean): void;
        playLocalSound(arg0: $BlockPos_, arg1: $SoundEvent_, arg2: $SoundSource_, arg3: number, arg4: number, arg5: boolean): void;
        playLocalSound(arg0: $Entity, arg1: $SoundEvent_, arg2: $SoundSource_, arg3: number, arg4: number): void;
        playPlayerSound(arg0: $SoundEvent_, arg1: $SoundSource_, arg2: number, arg3: number): void;
        playSeededSound(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: $Holder<$SoundEvent_>, arg5: $SoundSource_, arg6: number, arg7: number, arg8: number): void;
        playSeededSound(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: $SoundEvent_, arg5: $SoundSource_, arg6: number, arg7: number, arg8: number): void;
        playSeededSound(arg0: $Entity, arg1: $Entity, arg2: $Holder<$SoundEvent_>, arg3: $SoundSource_, arg4: number, arg5: number, arg6: number): void;
        playSound(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: $Holder<$SoundEvent_>, arg5: $SoundSource_, arg6: number, arg7: number): void;
        playSound(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: $SoundEvent_, arg5: $SoundSource_, arg6: number, arg7: number): void;
        playSound(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: $SoundEvent_, arg5: $SoundSource_): void;
        playSound(arg0: $Entity, arg1: $BlockPos_, arg2: $SoundEvent_, arg3: $SoundSource_, arg4: number, arg5: number): void;
        playSound(arg0: $Entity, arg1: $Entity, arg2: $SoundEvent_, arg3: $SoundSource_, arg4: number, arg5: number): void;
        potionBrewing(): $PotionBrewing;
        precipitationAt(arg0: $BlockPos_): $Biome$Precipitation;
        recipeAccess(): $RecipeAccess;
        registryAccess(): $RegistryAccess;
        removeBlockEntity(arg0: $BlockPos_): void;
        removeBlock(arg0: $BlockPos_, arg1: boolean): boolean;
        sendBlockUpdated(arg0: $BlockPos_, arg1: $BlockState_, arg2: $BlockState_, arg3: number): void;
        sendPacketToServer(arg0: $Packet<any>): void;
        setBlockAndUpdate(arg0: $BlockPos_, arg1: $BlockState_): boolean;
        setBlocksDirty(arg0: $BlockPos_, arg1: $BlockState_, arg2: $BlockState_): void;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_, arg2: number, arg3: number): boolean;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_, arg2: number): boolean;
        shouldTickBlocksAt(arg0: number): boolean;
        shouldTickBlocksAt(arg0: $BlockPos_): boolean;
        shouldTickDeath(arg0: $Entity): boolean;
        tickBlockEntities(): void;
        tickRateManager(): $TickRateManager;
        updateNeighborsAtExceptFromFacing(arg0: $BlockPos_, arg1: $Block_, arg2: $Direction_, arg3: $Orientation): void;
        updateNeighborsAt(arg0: $BlockPos_, arg1: $Block_, arg2: $Orientation): void;
        updateNeighbourForOutputSignal(arg0: $BlockPos_, arg1: $Block_): void;
        updatePOIOnBlockStateChange(arg0: $BlockPos_, arg1: $BlockState_, arg2: $BlockState_): void;
        updateSkyBrightness(): void;
    }

    export class $Level$ExplosionInteraction {
        static BLOCK: $Level$ExplosionInteraction;
        static MOB: $Level$ExplosionInteraction;
        static NONE: $Level$ExplosionInteraction;
        static TNT: $Level$ExplosionInteraction;
        static TRIGGER: $Level$ExplosionInteraction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Level$ExplosionInteraction[];
        static valueOf(name: string): $Level$ExplosionInteraction;
    }

    export interface $LevelAccessor extends $CommonLevelAccessor, $ScheduledTickAccess {
        addParticle(arg0: $ParticleOptions, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): void;
        createTick<T>(arg0: $BlockPos_, arg1: T, arg2: number, arg3: $TickPriority_): $ScheduledTick<T>;
        createTick<T>(arg0: $BlockPos_, arg1: T, arg2: number): $ScheduledTick<T>;
        gameEvent(arg0: $Holder<$GameEvent_>, arg1: $BlockPos_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $Holder<$GameEvent_>, arg1: $Vec3_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $ResourceKey<$GameEvent_>, arg1: $BlockPos_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $Entity, arg1: $Holder<$GameEvent_>, arg2: $BlockPos_): void;
        gameEvent(arg0: $Entity, arg1: $Holder<$GameEvent_>, arg2: $Vec3_): void;
        getChunkSource(): $ChunkSource;
        getDifficulty(): $Difficulty;
        getGameTime(): number;
        getLevelData(): $LevelData;
        getRandom(): $RandomSource;
        getServer(): $MinecraftServer;
        hasChunk(arg0: number, arg1: number): boolean;
        levelEvent(arg0: number, arg1: $BlockPos_, arg2: number): void;
        levelEvent(arg0: $Entity, arg1: number, arg2: $BlockPos_, arg3: number): void;
        neighborShapeChanged(arg0: $Direction_, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $BlockState_, arg4: number, arg5: number): void;
        nextSubTickCount(): number;
        playSound(arg0: $Entity, arg1: $BlockPos_, arg2: $SoundEvent_, arg3: $SoundSource_, arg4: number, arg5: number): void;
        playSound(arg0: $Entity, arg1: $BlockPos_, arg2: $SoundEvent_, arg3: $SoundSource_): void;
        updateNeighborsAt(arg0: $BlockPos_, arg1: $Block_): void;
    }

    export interface $LevelHeightAccessor {
        create(arg0: number, arg1: number): $LevelHeightAccessor;
        getHeight(): number;
        getMaxSectionY(): number;
        getMaxY(): number;
        getMinSectionY(): number;
        getMinY(): number;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        getSectionsCount(): number;
        isInsideBuildHeight(arg0: number): boolean;
        isInsideBuildHeight(arg0: $BlockPos_): boolean;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
    }

    export interface $LevelReader extends $BlockAndLightGetter, $CollisionGetter, $SignalGetter, $BiomeManager$NoiseBiomeSource, $ILevelReaderExtension {
        canSeeSkyFromBelowWater(arg0: $BlockPos_): boolean;
        containsAnyLiquid(arg0: $AABB): boolean;
        dimensionType(): $DimensionType;
        enabledFeatures(): $FeatureFlagSet;
        environmentAttributes(): $EnvironmentAttributeReader;
        getBiomeManager(): $BiomeManager;
        getBiome(arg0: $BlockPos_): $Holder<$Biome>;
        getBlockStatesIfLoaded(arg0: $AABB): $Stream<$BlockState>;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_, arg3: boolean): $ChunkAccess;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_): $ChunkAccess;
        getChunk(arg0: number, arg1: number): $ChunkAccess;
        getChunk(arg0: $BlockPos_): $ChunkAccess;
        getEffectiveSkyBrightness(arg0: $BlockPos_): number;
        getHeightmapPos(arg0: $Heightmap$Types_, arg1: $BlockPos_): $BlockPos;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getHeight(arg0: $Heightmap$Types_, arg1: $BlockPos_): number;
        getHeight(): number;
        getLightLevelDependentMagicValue(arg0: $BlockPos_): number;
        getMaxLocalRawBrightness(arg0: $BlockPos_, arg1: number): number;
        getMaxLocalRawBrightness(arg0: $BlockPos_): number;
        getMinY(): number;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getPathfindingCostFromLightLevels(arg0: $BlockPos_): number;
        getSeaLevel(): number;
        getSkyDarken(): number;
        getUncachedNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        hasChunkAt(arg0: number, arg1: number): boolean;
        hasChunkAt(arg0: $BlockPos_): boolean;
        hasChunksAt(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): boolean;
        hasChunksAt(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        hasChunksAt(arg0: $BlockPos_, arg1: $BlockPos_): boolean;
        hasChunk(arg0: number, arg1: number): boolean;
        holderLookup<T>(arg0: $ResourceKey<$Registry<T>>): $HolderLookup<T>;
        isClientSide(): boolean;
        isEmptyBlock(arg0: $BlockPos_): boolean;
        isWaterAt(arg0: $BlockPos_): boolean;
        registryAccess(): $RegistryAccess;
    }

    export class $LevelSettings extends $Record {
        constructor(arg0: string, arg1: $GameType_, arg2: $LevelSettings$DifficultySettings, arg3: boolean, arg4: $WorldDataConfiguration);
        constructor(levelName: string, gameType: $GameType_, difficultySettings: $LevelSettings$DifficultySettings, allowCommands: boolean, dataConfiguration: $WorldDataConfiguration, lifecycle: $Lifecycle);
        get lifecycle(): $Lifecycle;
        getLifecycle(): $Lifecycle;
        static parse(arg0: $Dynamic<any>, arg1: $WorldDataConfiguration): $LevelSettings;
        allowCommands(): boolean;
        copy(): $LevelSettings;
        dataConfiguration(): $WorldDataConfiguration;
        difficultySettings(): $LevelSettings$DifficultySettings;
        equals(arg0: object): boolean;
        gameType(): $GameType;
        hashCode(): number;
        levelName(): string;
        lifecycle(): $Lifecycle;
        toString(): string;
        withAllowCommands(arg0: boolean): $LevelSettings;
        withDataConfiguration(arg0: $WorldDataConfiguration): $LevelSettings;
        withDifficultyLock(arg0: boolean): $LevelSettings;
        withDifficulty(arg0: $Difficulty_): $LevelSettings;
        withGameType(arg0: $GameType_): $LevelSettings;
        withLifecycle(arg0: $Lifecycle): $LevelSettings;
    }

    export class $LevelSettings$DifficultySettings extends $Record {
        constructor(difficulty: $Difficulty_, hardcore: boolean, locked: boolean);
        static CODEC: $Codec<$LevelSettings$DifficultySettings>;
        static DEFAULT: $LevelSettings$DifficultySettings;
        difficulty(): $Difficulty;
        equals(arg0: object): boolean;
        hardcore(): boolean;
        hashCode(): number;
        locked(): boolean;
        toString(): string;
    }

    export interface $LevelSimulatedRW extends $LevelSimulatedReader, $LevelWriter {
    }

    export interface $LevelSimulatedReader {
        getBlockEntity<T>(arg0: $BlockPos_, arg1: $BlockEntityType<T>): $Optional<T>;
        getHeightmapPos(arg0: $Heightmap$Types_, arg1: $BlockPos_): $BlockPos;
        isFluidAtPosition(arg0: $BlockPos_, arg1: $Predicate<$FluidState>): boolean;
        isStateAtPosition(arg0: $BlockPos_, arg1: $Predicate<$BlockState_>): boolean;
    }

    export interface $LevelWriter {
        addFreshEntity(arg0: $Entity): boolean;
        destroyBlock(arg0: $BlockPos_, arg1: boolean, arg2: $Entity, arg3: number): boolean;
        destroyBlock(arg0: $BlockPos_, arg1: boolean, arg2: $Entity): boolean;
        destroyBlock(arg0: $BlockPos_, arg1: boolean): boolean;
        removeBlock(arg0: $BlockPos_, arg1: boolean): boolean;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_, arg2: number, arg3: number): boolean;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_, arg2: number): boolean;
    }

    export class $LightLayer {
        static BLOCK: $LightLayer;
        static SKY: $LightLayer;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LightLayer[];
        static valueOf(name: string): $LightLayer;
    }

    export class $NaturalSpawner$SpawnState {
        get mobCategoryCounts(): $Object2IntMap<$MobCategory>;
        getMobCategoryCounts(): $Object2IntMap<$MobCategory>;
        get spawnableChunkCount(): number;
        getSpawnableChunkCount(): number;
    }

    export class $NoiseColumn implements $BlockColumn {
        constructor(arg0: number, arg1: $BlockState_[]);
        getBlock(arg0: number): $BlockState;
        setBlock(arg0: number, arg1: $BlockState_): void;
    }

    export class $PathNavigationRegion implements $CollisionGetter {
        constructor(arg0: $Level, arg1: $BlockPos_, arg2: $BlockPos_);
        get height(): number;
        getHeight(): number;
        get minY(): number;
        getMinY(): number;
        get worldBorder(): $WorldBorder;
        getWorldBorder(): $WorldBorder;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getFluidState(arg0: $BlockPos_): $FluidState;
    }

    export interface $ScheduledTickAccess {
        createTick<T>(arg0: $BlockPos_, arg1: T, arg2: number, arg3: $TickPriority_): $ScheduledTick<T>;
        createTick<T>(arg0: $BlockPos_, arg1: T, arg2: number): $ScheduledTick<T>;
        getBlockTicks(): $LevelTickAccess<$Block>;
        getFluidTicks(): $LevelTickAccess<$Fluid>;
        scheduleTick(arg0: $BlockPos_, arg1: $Block_, arg2: number, arg3: $TickPriority_): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Block_, arg2: number): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Fluid_, arg2: number, arg3: $TickPriority_): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Fluid_, arg2: number): void;
    }

    export class $ServerExplosion implements $Explosion {
        constructor(arg0: $ServerLevel, arg1: $Entity, arg2: $DamageSource, arg3: $ExplosionDamageCalculator, arg4: $Vec3_, arg5: number, arg6: boolean, arg7: $Explosion$BlockInteraction_);
        get blockInteraction(): $Explosion$BlockInteraction;
        getBlockInteraction(): $Explosion$BlockInteraction;
        get damageSource(): $DamageSource;
        getDamageSource(): $DamageSource;
        get directSourceEntity(): $Entity;
        getDirectSourceEntity(): $Entity;
        get hitPlayers(): $Map<$Player, $Vec3>;
        getHitPlayers(): $Map<$Player, $Vec3>;
        get indirectSourceEntity(): $LivingEntity;
        getIndirectSourceEntity(): $LivingEntity;
        get small(): boolean;
        isSmall(): boolean;
        static getSeenPercent(arg0: $Vec3_, arg1: $Entity): number;
        canTriggerBlocks(): boolean;
        center(): $Vec3;
        explode(): number;
        level(): $ServerLevel;
        radius(): number;
        shouldAffectBlocklikeEntities(): boolean;
    }

    export interface $ServerLevelAccessor extends $LevelAccessor {
        addFreshEntityWithPassengers(arg0: $Entity): void;
        getCurrentDifficultyAt(arg0: $BlockPos_): $DifficultyInstance;
        getLevel(): $ServerLevel;
    }

    export interface $SignalGetter extends $BlockGetter {
        getBestNeighborSignal(arg0: $BlockPos_): number;
        getBestOwnOrNeighbourSignal(arg0: $BlockPos_): number;
        getControlInputSignal(arg0: $BlockPos_, arg1: $Direction_, arg2: boolean): number;
        getDirectSignalTo(arg0: $BlockPos_): number;
        getDirectSignal(arg0: $BlockPos_, arg1: $Direction_): number;
        getSignal(arg0: $BlockPos_, arg1: $Direction_): number;
        hasNeighborSignal(arg0: $BlockPos_): boolean;
        hasSignal(arg0: $BlockPos_, arg1: $Direction_): boolean;
        static DIRECTIONS: $Direction[];
    }

    export class $StructureManager {
        constructor(arg0: $LevelAccessor, arg1: $WorldOptions, arg2: $StructureCheck);
        addReferenceForStructure(arg0: $SectionPos, arg1: $Structure, arg2: number, arg3: $StructureAccess): void;
        addReference(arg0: $StructureStart): void;
        checkStructurePresence(arg0: $ChunkPos, arg1: $Structure, arg2: $StructurePlacement, arg3: boolean): $StructureCheckResult;
        fillStartsForStructure(arg0: $Structure, arg1: $LongSet, arg2: $Consumer<$StructureStart>): void;
        forWorldGenRegion(arg0: $WorldGenRegion): $StructureManager;
        getAllStructuresAt(arg0: $BlockPos_): $Map<$Structure, $LongSet>;
        getStartForStructure(arg0: $SectionPos, arg1: $Structure, arg2: $StructureAccess): $StructureStart;
        getStructureAt(arg0: $BlockPos_, arg1: $Structure): $StructureStart;
        getStructureWithPieceAt(arg0: $BlockPos_, arg1: $Predicate<$Holder<$Structure>>): $StructureStart;
        getStructureWithPieceAt(arg0: $BlockPos_, arg1: $HolderSet<$Structure>): $StructureStart;
        getStructureWithPieceAt(arg0: $BlockPos_, arg1: $TagKey<$Structure>): $StructureStart;
        getStructureWithPieceAt(arg0: $BlockPos_, arg1: $Structure): $StructureStart;
        hasAnyStructureAt(arg0: $BlockPos_): boolean;
        registryAccess(): $RegistryAccess;
        setStartForStructure(arg0: $SectionPos, arg1: $Structure, arg2: $StructureStart, arg3: $StructureAccess): void;
        shouldGenerateStructures(): boolean;
        startsForStructure(arg0: $SectionPos, arg1: $Structure): $List<$StructureStart>;
        startsForStructure(arg0: $ChunkPos, arg1: $Predicate<$Structure>): $List<$StructureStart>;
        structureHasPieceAt(arg0: $BlockPos_, arg1: $StructureStart): boolean;
    }

    export class $TicketStorage extends $SavedData {
        constructor();
        static CODEC: $Codec<$TicketStorage>;
        static TYPE: $SavedDataType<$TicketStorage>;
        get blockForcedChunks(): $ForcedChunkManager$TicketTracker<$BlockPos>;
        getBlockForcedChunks(): $ForcedChunkManager$TicketTracker<$BlockPos>;
        get entityForcedChunks(): $ForcedChunkManager$TicketTracker<$UUID>;
        getEntityForcedChunks(): $ForcedChunkManager$TicketTracker<$UUID>;
        get forceLoadedChunks(): $LongSet;
        getForceLoadedChunks(): $LongSet;
        activateAllDeactivatedTickets(): void;
        addTicketWithRadius(arg0: $TicketType_, arg1: $ChunkPos, arg2: number): void;
        addTicket(arg0: number, arg1: $Ticket): boolean;
        addTicket(arg0: $Ticket, arg1: $ChunkPos): void;
        deactivateTicketsOnClosing(): void;
        getTicketDebugString(arg0: number, arg1: boolean): string;
        getTicketLevelAt(arg0: number, arg1: boolean): number;
        getTickets(arg0: number): $List<$Ticket>;
        hasTickets(): boolean;
        purgeStaleTickets(arg0: $ChunkMap): void;
        removeTicketIf(arg0: $TicketStorage$TicketPredicate, arg1: $Long2ObjectOpenHashMap<$Ticket[]>): void;
        removeTicketWithRadius(arg0: $TicketType_, arg1: $ChunkPos, arg2: number): void;
        removeTicket(arg0: number, arg1: $Ticket): boolean;
        removeTicket(arg0: $Ticket, arg1: $ChunkPos): void;
        replaceTicketLevelOfType(arg0: number, arg1: $TicketType_): void;
        shouldForceNaturalSpawning(arg0: $ChunkPos): boolean;
        shouldKeepDimensionActive(): boolean;
        updateChunkForced(arg0: $ChunkPos, arg1: boolean): boolean;
    }

    export interface $TicketStorage$ChunkUpdated {
        update(arg0: number, arg1: number, arg2: boolean): void;
    }

    export interface $TicketStorage$TicketPredicate {
        test(arg0: $Ticket, arg1: number): boolean;
    }

    export class $WorldDataConfiguration extends $Record {
        constructor(dataPacks: $DataPackConfig, enabledFeatures: $FeatureFlagSet);
        static CODEC: $Codec<$WorldDataConfiguration>;
        static DEFAULT: $WorldDataConfiguration;
        static ENABLED_FEATURES_ID: string;
        static MAP_CODEC: $MapCodec<$WorldDataConfiguration>;
        dataPacks(): $DataPackConfig;
        enabledFeatures(): $FeatureFlagSet;
        equals(arg0: object): boolean;
        expandFeatures(arg0: $FeatureFlagSet): $WorldDataConfiguration;
        hashCode(): number;
        toString(): string;
    }

    export interface $WorldGenLevel extends $ServerLevelAccessor {
        ensureCanWrite(arg0: $BlockPos_): boolean;
        getSeed(): number;
        setCurrentlyGenerating(arg0: $Supplier<string>): void;
    }

    export type $CardinalLighting$Type_ = $CardinalLighting$Type | "DEFAULT" | "NETHER";
    export type $ClipContext$Block_ = $ClipContext$Block | "COLLIDER" | "FALLDAMAGE_RESETTING" | "OUTLINE" | "VISUAL";
    export type $ClipContext$Fluid_ = $ClipContext$Fluid | "ANY" | "NONE" | "SOURCE_ONLY" | "WATER";
    export type $Explosion$BlockInteraction_ = $Explosion$BlockInteraction | "DESTROY" | "DESTROY_WITH_DECAY" | "KEEP" | "TRIGGER_BLOCK";
    export type $GameType_ = $GameType | "ADVENTURE" | "CREATIVE" | "SPECTATOR" | "SURVIVAL";
    export type $ItemLike_ = $ItemLike | RegistryTypes.Item | $ItemStack | $Block | $NekoId;
    export type $Level$ExplosionInteraction_ = $Level$ExplosionInteraction | "BLOCK" | "MOB" | "NONE" | "TNT" | "TRIGGER";
    export type $LightLayer_ = $LightLayer | "BLOCK" | "SKY";
}
