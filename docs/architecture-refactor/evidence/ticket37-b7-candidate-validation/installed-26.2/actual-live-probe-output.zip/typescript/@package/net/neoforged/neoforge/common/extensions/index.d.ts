import { $GameProfile } from "java:com/mojang/authlib";
import { $ChannelFutureListener } from "java:io/netty/channel";
import { $Enum, $Integer, $Iterable, $Runnable, $String, $Void } from "java:java/lang";
import { $DecimalFormat } from "java:java/text";
import { $Collection, $List, $Map, $Optional, $OptionalInt, $Set } from "java:java/util";
import { $BiConsumer, $BiFunction, $Consumer, $IntFunction, $Supplier } from "java:java/util/function";
import { $AdvancementHolder } from "java:net/minecraft/advancements";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $Holder$Reference, $HolderLookup$Provider, $HolderLookup$RegistryLookup, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentGetter, $DataComponentMap$Builder, $DataComponentType } from "java:net/minecraft/core/component";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Connection, $FriendlyByteBuf, $PacketListener, $PacketProcessor, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $MutableComponent, $TextColor } from "java:net/minecraft/network/chat";
import { $StreamDecoder, $StreamEncoder } from "java:net/minecraft/network/codec";
import { $Packet, $PacketFlow, $PacketFlow_ } from "java:net/minecraft/network/protocol";
import { $CustomPacketPayload, $CustomPacketPayload$Type } from "java:net/minecraft/network/protocol/common/custom";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerChunkCache, $ServerLevel, $ServerPlayer, $ServerPlayer$RespawnPosAngle } from "java:net/minecraft/server/level";
import { $PlayerList } from "java:net/minecraft/server/players";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $RandomSource, $TriState, $TriState_ } from "java:net/minecraft/util";
import { $InteractionHand, $InteractionHand_, $InteractionResult, $MenuProvider } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance } from "java:net/minecraft/world/effect";
import { $Entity, $EntityType, $EntityType_, $EquipmentSlot, $EquipmentSlot_, $LivingEntity, $Mob, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $AttributeModifier, $AttributeModifier$Operation, $AttributeModifier$Operation_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Inventory, $Player } from "java:net/minecraft/world/entity/player";
import { $AbstractBoat } from "java:net/minecraft/world/entity/vehicle/boat";
import { $AbstractContainerMenu, $MenuType } from "java:net/minecraft/world/inventory";
import { $Item, $Item$Properties, $Item$TooltipContext, $ItemInstance, $ItemStack, $ItemStackTemplate, $ItemStack_, $Item_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $ItemAttributeModifiers, $TooltipDisplay } from "java:net/minecraft/world/item/component";
import { $UseOnContext } from "java:net/minecraft/world/item/context";
import { $RecipeType } from "java:net/minecraft/world/item/crafting";
import { $Enchantment, $EnchantmentInstance, $ItemEnchantments } from "java:net/minecraft/world/item/enchantment";
import { $BlockAndLightGetter, $BlockGetter, $ChunkPos, $Explosion, $Level, $LevelAccessor, $LevelReader, $SignalGetter, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Mirror, $Mirror_, $Rotation, $Rotation_, $SoundType } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $FuelValues } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $TreeConfiguration } from "java:net/minecraft/world/level/levelgen/feature/configurations";
import { $FluidState, $MapColor, $PushReaction, $PushReaction_ } from "java:net/minecraft/world/level/material";
import { $PathType, $PathType_ } from "java:net/minecraft/world/level/pathfinder";
import { $ValueInput } from "java:net/minecraft/world/level/storage";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $Scoreboard } from "java:net/minecraft/world/scores";
import { $LogicalSide, $LogicalSide_ } from "java:net/neoforged/fml";
import { $BlockCapability, $ItemCapability } from "java:net/neoforged/neoforge/capabilities";
import { $ItemAbility, $SoundAction } from "java:net/neoforged/neoforge/common";
import { $DamageContainer } from "java:net/neoforged/neoforge/common/damagesource";
import { $BubbleColumnDirection, $BubbleColumnDirection_ } from "java:net/neoforged/neoforge/common/enums";
import { $BlockRelocability, $ValueIOSerializable } from "java:net/neoforged/neoforge/common/util";
import { $AuxiliaryLightManager } from "java:net/neoforged/neoforge/common/world";
import { $PartEntity } from "java:net/neoforged/neoforge/entity";
import { $FluidStack, $FluidStack_, $FluidType, $InFluidPredicate } from "java:net/neoforged/neoforge/fluids";
import { $ModelData, $ModelDataManager } from "java:net/neoforged/neoforge/model/data";
import { $IContainerFactory } from "java:net/neoforged/neoforge/network";
import { $ConnectionType, $ConnectionType_ } from "java:net/neoforged/neoforge/network/connection";
import { $DataMapType, $IWithData } from "java:net/neoforged/neoforge/registries/datamaps";
import { $TransactionContext } from "java:net/neoforged/neoforge/transfer/transaction";
import { $TriConsumer } from "java:org/apache/commons/lang3/function";

declare module "java:net/neoforged/neoforge/common/extensions" {
    export interface $ContainerExtension {
        onTransfer(arg0: number, arg1: number, arg2: $TransactionContext): void;
        setItem(arg0: number, arg1: $ItemStack_, arg2: boolean): void;
    }

    export interface $GameTestHelperExtension {
        fail(arg0: string, arg1: $BlockPos_): void;
        fail(arg0: string, arg1: $Entity): void;
        getCapability<T, C>(arg0: $BlockCapability<T, C>, arg1: $BlockPos_, arg2: C): T;
        requireCapability<T, C>(arg0: $BlockCapability<T, C>, arg1: $BlockPos_, arg2: C): T;
    }

    export interface $IAbstractBoatExtension {
        canBoatInFluid(arg0: $FluidState): boolean;
        canBoatInFluid(arg0: $FluidType): boolean;
    }

    export interface $IAttributeExtension {
        getBaseId(): $Identifier;
        getDebugInfo(arg0: $AttributeModifier, arg1: $TooltipFlag): $Component;
        getMergedStyle(arg0: boolean): $TextColor;
        isNullOrAddition(arg0: $AttributeModifier$Operation_): boolean;
        toBaseComponent(arg0: number, arg1: number, arg2: boolean, arg3: $TooltipFlag): $MutableComponent;
        toComponent(arg0: $AttributeModifier, arg1: $TooltipFlag): $MutableComponent;
        toValueComponent(arg0: $AttributeModifier$Operation_, arg1: number, arg2: $TooltipFlag): $MutableComponent;
        static FORMAT: $DecimalFormat;
    }

    export interface $IBlockEntityExtension {
        applyStructureRotation(arg0: $Mirror_, arg1: $Rotation_): void;
        getModelData(): $ModelData;
        getPersistentData(): $CompoundTag;
        handleUpdateTag(arg0: $ValueInput): void;
        invalidateCapabilities(): void;
        onChunkUnloaded(): void;
        onDataPacket(arg0: $Connection, arg1: $ValueInput): void;
        onLoad(): void;
        requestModelDataUpdate(): void;
    }

    export interface $IBlockExtension {
        addLandingEffects(arg0: $BlockState_, arg1: $ServerLevel, arg2: $BlockPos_, arg3: $BlockState_, arg4: $LivingEntity, arg5: number): boolean;
        addRunningEffects(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Entity): boolean;
        canBeHydrated(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $FluidState, arg4: $BlockPos_): boolean;
        canConnectRedstone(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): boolean;
        canDropFromExplosion(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Explosion): boolean;
        canEntityDestroy(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Entity): boolean;
        canHarvestBlock(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Player): boolean;
        canStickTo(arg0: $BlockState_, arg1: $BlockState_): boolean;
        canSustainPlant(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_, arg4: $BlockState_): $TriState;
        collisionExtendsVertically(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Entity): boolean;
        getAdjacentBlockPathType(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob, arg4: $PathType_): $PathType;
        getAppearance(arg0: $BlockState_, arg1: $BlockAndLightGetter, arg2: $BlockPos_, arg3: $Direction_, arg4: $BlockState_, arg5: $BlockPos_): $BlockState;
        getBeaconColorMultiplier(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $BlockPos_): number;
        getBedDirection(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_): $Direction;
        getBlockPathType(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob): $PathType;
        getBounceRestitution(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: $Entity): number;
        getBubbleColumnDirection(arg0: $BlockState_): $BubbleColumnDirection;
        getCloneItemStack(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockState_, arg3: boolean, arg4: $Player): $ItemStack;
        getEnchantPowerBonus(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): number;
        getExpDrop(arg0: $BlockState_, arg1: $LevelAccessor, arg2: $BlockPos_, arg3: $BlockEntity, arg4: $Entity, arg5: $ItemStack_): number;
        getExplosionResistance(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Explosion): number;
        getFireSpreadSpeed(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): number;
        getFlammability(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): number;
        getFriction(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Entity): number;
        getLightEmission(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): number;
        getMapColor(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $MapColor): $MapColor;
        getPistonPushReaction(arg0: $BlockState_): $PushReaction;
        getRelocability(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockState_): $BlockRelocability;
        getRespawnPosition(arg0: $BlockState_, arg1: $EntityType<any>, arg2: $LevelReader, arg3: $BlockPos_, arg4: number): $Optional<$ServerPlayer$RespawnPosAngle>;
        getSoundType(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Entity): $SoundType;
        getStateAtViewpoint(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Vec3_): $BlockState;
        getToolModifiedState(arg0: $BlockState_, arg1: $UseOnContext, arg2: $ItemAbility, arg3: boolean): $BlockState;
        getWeakChanges(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_): boolean;
        hasDynamicLightEmission(arg0: $BlockState_): boolean;
        hidesNeighborFace(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockState_, arg4: $Direction_): boolean;
        ignitedByLava(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): boolean;
        isBed(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $LivingEntity): boolean;
        isBurning(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        isConduitFrame(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $BlockPos_): boolean;
        isEmpty(arg0: $BlockState_): boolean;
        isFertile(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        isFireSource(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Direction_): boolean;
        isFlammable(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): boolean;
        isLadder(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $LivingEntity): boolean;
        isPortalFrame(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        isScaffolding(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $LivingEntity): boolean;
        isSlimeBlock(arg0: $BlockState_): boolean;
        isStickyBlock(arg0: $BlockState_): boolean;
        makesOpenTrapdoorAboveClimbable(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $BlockState_): boolean;
        onBlockExploded(arg0: $BlockState_, arg1: $ServerLevel, arg2: $BlockPos_, arg3: $Explosion): void;
        onBlockStateChange(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockState_): void;
        onCaughtFire(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Direction_, arg4: $LivingEntity): boolean;
        onDestroyedByPlayer(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Player, arg4: $ItemStack_, arg5: boolean, arg6: $FluidState): boolean;
        onDestroyedByPushReaction(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Direction_, arg4: $FluidState): void;
        onNeighborChange(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $BlockPos_): void;
        onTreeGrow(arg0: $BlockState_, arg1: $WorldGenLevel, arg2: $BiConsumer<$BlockPos_, $BlockState_>, arg3: $RandomSource, arg4: $BlockPos_, arg5: $TreeConfiguration): boolean;
        playFallSound(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $LivingEntity): void;
        playStepSound(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Entity, arg4: number, arg5: number): void;
        rotate(arg0: $BlockState_, arg1: $LevelAccessor, arg2: $BlockPos_, arg3: $Rotation_): $BlockState;
        setBedOccupied(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $LivingEntity, arg4: boolean): void;
        shouldCheckWeakPower(arg0: $BlockState_, arg1: $SignalGetter, arg2: $BlockPos_, arg3: $Direction_): boolean;
        shouldDisplayFluidOverlay(arg0: $BlockState_, arg1: $BlockAndLightGetter, arg2: $BlockPos_, arg3: $FluidState): boolean;
        shouldHideAdjacentFluidFace(arg0: $BlockState_, arg1: $Direction_, arg2: $FluidState): boolean;
        supportsExternalFaceHiding(arg0: $BlockState_): boolean;
    }

    export interface $IBlockGetterExtension {
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getModelData(arg0: $BlockPos_): $ModelData;
    }

    export interface $IBlockStateExtension {
        addLandingEffects(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $BlockState_, arg3: $LivingEntity, arg4: number): boolean;
        addRunningEffects(arg0: $Level, arg1: $BlockPos_, arg2: $Entity): boolean;
        canBeHydrated(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $FluidState, arg3: $BlockPos_): boolean;
        canDropFromExplosion(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Explosion): boolean;
        canEntityDestroy(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Entity): boolean;
        canHarvestBlock(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Player): boolean;
        canRedstoneConnectTo(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): boolean;
        canStickTo(arg0: $BlockState_): boolean;
        canSustainPlant(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_, arg3: $BlockState_): $TriState;
        collisionExtendsVertically(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Entity): boolean;
        getAdjacentBlockPathType(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Mob, arg3: $PathType_): $PathType;
        getAppearance(arg0: $BlockAndLightGetter, arg1: $BlockPos_, arg2: $Direction_, arg3: $BlockState_, arg4: $BlockPos_): $BlockState;
        getBeaconColorMultiplier(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockPos_): number;
        getBedDirection(arg0: $LevelReader, arg1: $BlockPos_): $Direction;
        getBlockPathType(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Mob): $PathType;
        getBounceRestitution(arg0: $Level, arg1: $BlockPos_, arg2: $Entity): number;
        getBubbleColumnDirection(): $BubbleColumnDirection;
        getCloneItemStack(arg0: $BlockPos_, arg1: $LevelReader, arg2: boolean, arg3: $Player): $ItemStack;
        getEnchantPowerBonus(arg0: $LevelReader, arg1: $BlockPos_): number;
        getExpDrop(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $BlockEntity, arg3: $Entity, arg4: $ItemStack_): number;
        getExplosionResistance(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Explosion): number;
        getFireSpreadSpeed(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): number;
        getFlammability(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): number;
        getFriction(arg0: $LevelReader, arg1: $BlockPos_, arg2: $Entity): number;
        getLightEmission(arg0: $BlockGetter, arg1: $BlockPos_): number;
        getRelocability(arg0: $LevelReader, arg1: $BlockPos_): $BlockRelocability;
        getRespawnPosition(arg0: $EntityType<any>, arg1: $LevelReader, arg2: $BlockPos_, arg3: number): $Optional<$ServerPlayer$RespawnPosAngle>;
        getSoundType(arg0: $LevelReader, arg1: $BlockPos_, arg2: $Entity): $SoundType;
        getStateAtViewpoint(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Vec3_): $BlockState;
        getToolModifiedState(arg0: $UseOnContext, arg1: $ItemAbility, arg2: boolean): $BlockState;
        getWeakChanges(arg0: $LevelReader, arg1: $BlockPos_): boolean;
        hasDynamicLightEmission(): boolean;
        hidesNeighborFace(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $BlockState_, arg3: $Direction_): boolean;
        ignitedByLava(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): boolean;
        isBed(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $LivingEntity): boolean;
        isBurning(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        isConduitFrame(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockPos_): boolean;
        isEmpty(): boolean;
        isFertile(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        isFireSource(arg0: $LevelReader, arg1: $BlockPos_, arg2: $Direction_): boolean;
        isFlammable(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): boolean;
        isLadder(arg0: $LevelReader, arg1: $BlockPos_, arg2: $LivingEntity): boolean;
        isPortalFrame(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        isScaffolding(arg0: $LivingEntity): boolean;
        isSlimeBlock(): boolean;
        isStickyBlock(): boolean;
        onBlockExploded(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $Explosion): void;
        onBlockStateChange(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockState_): void;
        onCaughtFire(arg0: $Level, arg1: $BlockPos_, arg2: $Direction_, arg3: $LivingEntity): boolean;
        onDestroyedByPlayer(arg0: $Level, arg1: $BlockPos_, arg2: $Player, arg3: $ItemStack_, arg4: boolean, arg5: $FluidState): boolean;
        onDestroyedByPushReaction(arg0: $Level, arg1: $BlockPos_, arg2: $Direction_, arg3: $FluidState): void;
        onNeighborChange(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockPos_): void;
        onTreeGrow(arg0: $WorldGenLevel, arg1: $BiConsumer<$BlockPos_, $BlockState_>, arg2: $RandomSource, arg3: $BlockPos_, arg4: $TreeConfiguration): boolean;
        playFallSound(arg0: $Level, arg1: $BlockPos_, arg2: $LivingEntity): void;
        playStepSound(arg0: $Level, arg1: $BlockPos_, arg2: $Entity, arg3: number, arg4: number): void;
        rotate(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $Rotation_): $BlockState;
        setBedOccupied(arg0: $Level, arg1: $BlockPos_, arg2: $LivingEntity, arg3: boolean): void;
        shouldCheckWeakPower(arg0: $SignalGetter, arg1: $BlockPos_, arg2: $Direction_): boolean;
        shouldDisplayFluidOverlay(arg0: $BlockAndLightGetter, arg1: $BlockPos_, arg2: $FluidState): boolean;
        shouldHideAdjacentFluidFace(arg0: $Direction_, arg1: $FluidState): boolean;
        supportsExternalFaceHiding(): boolean;
    }

    export interface $IClientCommonPacketListenerExtension extends $ICommonPacketListener {
        disconnect(arg0: $Component_): void;
        send(arg0: $CustomPacketPayload): void;
    }

    export interface $ICommandSourceExtension {
        getGameProfile(): $Optional<$GameProfile>;
    }

    export interface $ICommandSourceStackExtension {
        getAdvancement(arg0: $Identifier_): $AdvancementHolder;
        getScoreboard(): $Scoreboard;
        getSourceProfile(): $Optional<$GameProfile>;
        getUnsidedLevel(): $Level;
    }

    export interface $ICommonPacketListener extends $PacketListener {
        disconnect(arg0: $Component_): void;
        getConnectionType(): $ConnectionType;
        getConnection(): $Connection;
        getPacketProcessor(): $PacketProcessor;
        hasChannel(arg0: $CustomPacketPayload$Type<any>): boolean;
        hasChannel(arg0: $CustomPacketPayload): boolean;
        hasChannel(arg0: $Identifier_): boolean;
        send(arg0: $Packet<any>): void;
        send(arg0: $CustomPacketPayload): void;
    }

    export interface $IDataComponentHolderExtension {
        addToTooltip<T>(arg0: $Supplier<$DataComponentType<T>>, arg1: $Item$TooltipContext, arg2: $TooltipDisplay, arg3: $Consumer<$Component_>, arg4: $TooltipFlag): void;
        addToTooltip<T>(arg0: $DataComponentType<T>, arg1: $Item$TooltipContext, arg2: $TooltipDisplay, arg3: $Consumer<$Component_>, arg4: $TooltipFlag): void;
    }

    export interface $IDataComponentMapBuilderExtensions extends $DataComponentGetter {
        set<T>(arg0: $Supplier<$DataComponentType<T>>, arg1: T): $DataComponentMap$Builder;
    }

    export interface $IEntityExtension {
        canBeRiddenUnderFluidType(arg0: $FluidType, arg1: $Entity): boolean;
        canFluidExtinguish(arg0: $FluidType): boolean;
        canHydrateInFluidType(arg0: $FluidType): boolean;
        canRiderInteract(): boolean;
        canStartSwimming(): boolean;
        canSwimInFluidType(arg0: $FluidType): boolean;
        canTrample(arg0: $ServerLevel, arg1: $BlockState_, arg2: $BlockPos_, arg3: number): boolean;
        captureDrops(arg0: $ItemEntity[]): $Collection<$ItemEntity>;
        captureDrops(): $Collection<$ItemEntity>;
        copyAttachmentsFrom(arg0: $Entity, arg1: boolean): void;
        getBlockBounciness(arg0: $BlockPos_, arg1: $BlockState_): number;
        getClassification(arg0: boolean): $MobCategory;
        getFirstEyeInFluidType(): $FluidType;
        getFluidFallDistanceModifier(arg0: $FluidType): number;
        getFluidMotionScale(arg0: $FluidType): number;
        getFluidTypeHeight(arg0: $FluidType): number;
        getMaxHeightFluidType(): $FluidType;
        getParts(): $PartEntity<any>[];
        getPersistentData(): $CompoundTag;
        getSoundFromFluidType(arg0: $FluidType, arg1: $SoundAction): $SoundEvent;
        isAddedToLevel(): boolean;
        isEyeInFluidType(arg0: $FluidType): boolean;
        isInFluidType(arg0: $FluidState): boolean;
        isInFluidType(arg0: $FluidType): boolean;
        isInFluidType(arg0: $InFluidPredicate<$Entity>): boolean;
        isInFluidType(): boolean;
        isMultipartEntity(): boolean;
        isPushedByFluid(arg0: $FluidType): boolean;
        onAddedToLevel(): void;
        onRemovedFromLevel(): void;
        revive(): void;
        sendPairingData(arg0: $ServerPlayer, arg1: $Consumer<$CustomPacketPayload>): void;
        shouldRiderSit(): boolean;
    }

    export interface $IFluidExtension {
        appendHoverText(arg0: $FluidStack_, arg1: $Item$TooltipContext, arg2: $TooltipDisplay, arg3: $Consumer<$Component_>, arg4: $TooltipFlag): void;
        canConvertToSource(arg0: $FluidState, arg1: $ServerLevel, arg2: $BlockPos_): boolean;
        canExtinguish(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        canHydrate(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $BlockState_, arg4: $BlockPos_): boolean;
        getAdjacentBlockPathType(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob, arg4: $PathType_): $PathType;
        getBlockPathType(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob, arg4: boolean): $PathType;
        getExplosionResistance(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Explosion): number;
        getFluidType(): $FluidType;
        move(arg0: $FluidState, arg1: $LivingEntity, arg2: $Vec3_, arg3: number): boolean;
        supportsBoating(arg0: $FluidState, arg1: $AbstractBoat): boolean;
    }

    export interface $IFluidStateExtension {
        canConvertToSource(arg0: $ServerLevel, arg1: $BlockPos_): boolean;
        canExtinguish(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        canHydrate(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockPos_): boolean;
        getAdjacentBlockPathType(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Mob, arg3: $PathType_): $PathType;
        getBlockPathType(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Mob, arg3: boolean): $PathType;
        getExplosionResistance(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Explosion): number;
        getFluidType(): $FluidType;
        move(arg0: $LivingEntity, arg1: $Vec3_, arg2: number): boolean;
        supportsBoating(arg0: $AbstractBoat): boolean;
    }

    export interface $IFriendlyByteBufExtension {
        readArray<T>(arg0: $IntFunction<T[]>, arg1: $StreamDecoder<any, T>): T[];
        readMap<K, V>(arg0: $StreamDecoder<any, K>, arg1: $BiFunction<$FriendlyByteBuf, K, V>): $Map<K, V>;
        writeArray<T>(arg0: T[], arg1: $StreamEncoder<any, T>): $FriendlyByteBuf;
        writeByte(arg0: number): $FriendlyByteBuf;
        writeMap<K, V>(arg0: { [key: K]: V }, arg1: $StreamEncoder<any, K>, arg2: $TriConsumer<$FriendlyByteBuf, K, V>): void;
        writeObjectCollection<T>(arg0: T[], arg1: $BiConsumer<T, $FriendlyByteBuf>): void;
    }

    export interface $IHolderExtension<T> extends $IWithData {
        getDelegate(): $Holder<T>;
        getKey(): $ResourceKey<T>;
        unwrapLookup(): $HolderLookup$RegistryLookup<T>;
    }

    export interface $IHolderLookupProviderExtension {
        holderOrThrow<T>(arg0: $ResourceKey<T>): $Holder<T>;
        holder<T>(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
    }

    export interface $IHolderSetExtension<T> {
        addInvalidationListener(arg0: $Runnable): void;
        isImmediatelyResolvable(): boolean;
        serializationType(): $IHolderSetExtension$SerializationType;
    }

    export class $IHolderSetExtension$SerializationType {
        static LIST: $IHolderSetExtension$SerializationType;
        static OBJECT: $IHolderSetExtension$SerializationType;
        static STRING: $IHolderSetExtension$SerializationType;
        static UNKNOWN: $IHolderSetExtension$SerializationType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $IHolderSetExtension$SerializationType[];
        static valueOf(name: string): $IHolderSetExtension$SerializationType;
    }

    export interface $IItemExtension {
        applyEnchantments(arg0: $ItemStack_, arg1: $EnchantmentInstance[]): $ItemStack;
        canBeHurtBy(arg0: $ItemStack_, arg1: $DamageSource): boolean;
        canContinueUsing(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        canEquip(arg0: $ItemStack_, arg1: $EquipmentSlot_, arg2: $LivingEntity): boolean;
        canFitInsideContainerItems(arg0: $ItemStack_): boolean;
        canGrindstoneRepair(arg0: $ItemStack_): boolean;
        canPerformAction(arg0: $ItemInstance, arg1: $ItemAbility): boolean;
        canWalkOnPowderedSnow(arg0: $ItemStack_, arg1: $LivingEntity): boolean;
        createEntity(arg0: $Level, arg1: $Entity, arg2: $ItemStack_): $Entity;
        damageItem<T>(arg0: $ItemStack_, arg1: number, arg2: T, arg3: $Consumer<$Item_>): number;
        doesSneakBypassUse(arg0: $ItemStack_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Player): boolean;
        getAllEnchantments(arg0: $ItemStack_, arg1: $HolderLookup$RegistryLookup<$Enchantment>): $ItemEnchantments;
        getBurnTime(arg0: $ItemStack_, arg1: $RecipeType<any>, arg2: $FuelValues): number;
        getCraftingRemainder(arg0: $ItemInstance): $ItemStackTemplate;
        getCreatorModId(arg0: $HolderLookup$Provider, arg1: $ItemStack_): string;
        getDamage(arg0: $ItemStack_): number;
        getDefaultAttributeModifiers(arg0: $ItemStack_): $ItemAttributeModifiers;
        getEnchantmentLevel(arg0: $ItemInstance, arg1: $Holder<$Enchantment>): number;
        getEntityLifespan(arg0: $ItemStack_, arg1: $Level): number;
        getEquipmentSlot(arg0: $ItemStack_): $EquipmentSlot;
        getHighlightTip(arg0: $ItemStack_, arg1: $Component_): $Component;
        getMaxDamage(arg0: $ItemStack_): number;
        getMaxStackSize(arg0: $ItemStack_): number;
        getSweepHitBox(arg0: $ItemStack_, arg1: $Player, arg2: $Entity): $AABB;
        getXpRepairRatio(arg0: $ItemStack_): number;
        hasCustomEntity(arg0: $ItemStack_): boolean;
        isCombineRepairable(arg0: $ItemStack_): boolean;
        isDamageable(arg0: $ItemStack_): boolean;
        isDamaged(arg0: $ItemStack_): boolean;
        isGazeDisguise(arg0: $ItemStack_, arg1: $Player, arg2: $LivingEntity): boolean;
        isNotReplaceableByPickAction(arg0: $ItemStack_, arg1: $Player, arg2: number): boolean;
        isPiglinCurrency(arg0: $ItemStack_): boolean;
        isPrimaryItemFor(arg0: $ItemStack_, arg1: $Holder<$Enchantment>): boolean;
        makesPiglinsNeutral(arg0: $ItemStack_, arg1: $LivingEntity): boolean;
        onAnimalArmorTick(arg0: $ItemStack_, arg1: $Level, arg2: $Mob): void;
        onDestroyed(arg0: $ItemEntity, arg1: $DamageSource): void;
        onDroppedByPlayer(arg0: $ItemStack_, arg1: $Player): boolean;
        onEntityItemUpdate(arg0: $ItemStack_, arg1: $ItemEntity): boolean;
        onEntitySwing(arg0: $ItemStack_, arg1: $LivingEntity, arg2: $InteractionHand_): boolean;
        onGlideDamage(arg0: $ItemStack_, arg1: $LivingEntity, arg2: $EquipmentSlot_): void;
        onItemUseFirst(arg0: $ItemStack_, arg1: $UseOnContext): $InteractionResult;
        onLeftClickEntity(arg0: $ItemStack_, arg1: $Player, arg2: $Entity): boolean;
        onStopUsing(arg0: $ItemStack_, arg1: $LivingEntity, arg2: number): void;
        setDamage(arg0: $ItemStack_, arg1: number): void;
        shouldCauseBlockBreakReset(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        shouldCauseReequipAnimation(arg0: $ItemStack_, arg1: $ItemStack_, arg2: boolean): boolean;
        supportsEnchantment(arg0: $ItemStack_, arg1: $Holder<$Enchantment>): boolean;
    }

    export interface $IItemPropertiesExtensions {
        component<T>(arg0: $Supplier<$DataComponentType<T>>, arg1: T): $Item$Properties;
    }

    export interface $IItemStackExtension extends $ItemInstanceExtension {
        canEquip(arg0: $EquipmentSlot_, arg1: $LivingEntity): boolean;
        canFitInsideContainerItems(): boolean;
        canGrindstoneRepair(): boolean;
        canWalkOnPowderedSnow(arg0: $LivingEntity): boolean;
        doesSneakBypassUse(arg0: $LevelReader, arg1: $BlockPos_, arg2: $Player): boolean;
        getAllEnchantments(arg0: $HolderLookup$RegistryLookup<$Enchantment>): $ItemEnchantments;
        getAttributeModifiers(): $ItemAttributeModifiers;
        getBurnTime(arg0: $RecipeType<any>, arg1: $FuelValues): number;
        getCapability<T, C>(arg0: $ItemCapability<T, C>, arg1: C): T;
        getCapability<T>(arg0: $ItemCapability<T, void>): T;
        getEntityLifespan(arg0: $Level): number;
        getEquipmentSlot(): $EquipmentSlot;
        getHighlightTip(arg0: $Component_): $Component;
        getSweepHitBox(arg0: $Player, arg1: $Entity): $AABB;
        getXpRepairRatio(): number;
        isCombineRepairable(): boolean;
        isGazeDisguise(arg0: $Player, arg1: $LivingEntity): boolean;
        isNotReplaceableByPickAction(arg0: $Player, arg1: number): boolean;
        isPiglinCurrency(): boolean;
        isPrimaryItemFor(arg0: $Holder<$Enchantment>): boolean;
        makesPiglinsNeutral(arg0: $LivingEntity): boolean;
        onAnimalArmorTick(arg0: $Level, arg1: $Mob): void;
        onDestroyed(arg0: $ItemEntity, arg1: $DamageSource): void;
        onDroppedByPlayer(arg0: $Player): boolean;
        onEntityItemUpdate(arg0: $ItemEntity): boolean;
        onEntitySwing(arg0: $LivingEntity, arg1: $InteractionHand_): boolean;
        onGlideDamage(arg0: $LivingEntity, arg1: $EquipmentSlot_): void;
        onItemUseFirst(arg0: $UseOnContext): $InteractionResult;
        onStopUsing(arg0: $LivingEntity, arg1: number): void;
        shouldCauseBlockBreakReset(arg0: $ItemStack_): boolean;
        supportsEnchantment(arg0: $Holder<$Enchantment>): boolean;
    }

    export interface $ILevelExtension {
        getCapability<T, C>(arg0: $BlockCapability<T, C>, arg1: $BlockPos_, arg2: C): T;
        getCapability<T, C>(arg0: $BlockCapability<T, C>, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity, arg4: C): T;
        getCapability<T>(arg0: $BlockCapability<T, void>, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity): T;
        getCapability<T>(arg0: $BlockCapability<T, void>, arg1: $BlockPos_): T;
        getDescriptionKey(): string;
        getDescription(): $Component;
        getMaxEntityRadius(): number;
        getModelDataManager(): $ModelDataManager;
        increaseMaxEntityRadius(arg0: number): number;
        invalidateCapabilities(arg0: $BlockPos_): void;
        invalidateCapabilities(arg0: $ChunkPos): void;
        static TRANSLATION_PREFIX: string;
    }

    export interface $ILevelReaderExtension {
        holderOrThrow<T>(arg0: $ResourceKey<T>): $Holder<T>;
        holder<T>(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        isAreaLoaded(arg0: $BlockPos_, arg1: number): boolean;
    }

    export interface $ILivingEntityExtension extends $IEntityExtension {
        canDrownInFluidType(arg0: $FluidType): boolean;
        canSwimInFluidType(arg0: $FluidType): boolean;
        jumpInFluid(arg0: $FluidType): void;
        moveInFluid(arg0: $FluidState, arg1: $Vec3_, arg2: number): boolean;
        moveInFluid(arg0: $FluidType, arg1: $Vec3_, arg2: number): boolean;
        onDamageTaken(arg0: $DamageContainer): void;
        self(): $LivingEntity;
        sinkInFluid(arg0: $FluidType): void;
    }

    export interface $IMenuProviderExtension {
        shouldTriggerClientSideContainerClosingOnOpen(): boolean;
        writeClientSideData(arg0: $AbstractContainerMenu, arg1: $RegistryFriendlyByteBuf): void;
    }

    export interface $IMenuTypeExtension<T> {
        create(arg0: number, arg1: $Inventory, arg2: $RegistryFriendlyByteBuf): T;
        create<T>(arg0: $IContainerFactory<T>): $MenuType<T>;
    }

    export interface $IMobEffectExtension {
        getSortOrder(arg0: $MobEffectInstance): number;
    }

    export interface $IPackResourcesExtension {
        isHidden(): boolean;
    }

    export interface $IPacketFlowExtension {
        getReceptionSide(): $LogicalSide;
        isClientbound(): boolean;
        isServerbound(): boolean;
        self(): $PacketFlow;
    }

    export interface $IPlayerExtension {
        isCloseEnough(arg0: $Entity, arg1: number): boolean;
        isFakePlayer(): boolean;
        mayFly(): boolean;
        openMenu(arg0: $MenuProvider, arg1: $Consumer<$RegistryFriendlyByteBuf>): $OptionalInt;
        openMenu(arg0: $MenuProvider, arg1: $BlockPos_): $OptionalInt;
    }

    export interface $IPlayerListExtension {
        broadcastAll(arg0: $CustomPacketPayload, arg1: $ResourceKey<$Level>): void;
        broadcastAll(arg0: $CustomPacketPayload): void;
        broadcast(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $ResourceKey<$Level>, arg5: $CustomPacketPayload): void;
        broadcast(arg0: $Player, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $ResourceKey<$Level>, arg6: $CustomPacketPayload): void;
        self(): $PlayerList;
    }

    export interface $IServerChunkCacheExtension {
        self(): $ServerChunkCache;
        sendToTrackingPlayersAndSelf(arg0: $Entity, arg1: $CustomPacketPayload): void;
        sendToTrackingPlayers(arg0: $Entity, arg1: $CustomPacketPayload): void;
    }

    export interface $IServerCommonPacketListenerExtension extends $ICommonPacketListener {
        send(arg0: $Packet<any>, arg1: $ChannelFutureListener): void;
        send(arg0: $CustomPacketPayload, arg1: $ChannelFutureListener): void;
        send(arg0: $CustomPacketPayload): void;
    }

    export interface $IServerGamePacketListenerExtension extends $IServerCommonPacketListenerExtension {
        sendBundled(arg0: $Iterable<$CustomPacketPayload>): void;
        sendBundled(arg0?: $CustomPacketPayload[]): void;
    }

    export interface $ItemInstanceExtension {
        canPerformAction(arg0: $ItemAbility): boolean;
        getCraftingRemainder(): $ItemStackTemplate;
        getEnchantmentLevel(arg0: $Holder<$Enchantment>): number;
        getTagEnchantments(): $ItemEnchantments;
    }

    export interface $PendingTagsExtension<T> {
        contents(): $Map<$TagKey<T>, $List<$Holder<T>>>;
    }

    export interface $TooltipFlagExtension {
        hasAltDown(): boolean;
        hasControlDown(): boolean;
        hasShiftDown(): boolean;
        shouldDisplayAllInformation(): boolean;
    }

    export interface $TypedInstanceExtension<T> extends $IWithData {
        getData<D>(arg0: $DataMapType<T, D>): D;
    }

    export interface $ValueInputExtension {
        keySet(): $Set<string>;
        rawChildOrEmpty(arg0: string): $ValueInput;
        readChild(arg0: string, arg1: $ValueIOSerializable): void;
    }

    export interface $ValueOutputExtension {
        putChild(arg0: string, arg1: $ValueIOSerializable): void;
        store(arg0: $CompoundTag_): void;
    }

    export type $IHolderSetExtension$SerializationType_ = $IHolderSetExtension$SerializationType | "LIST" | "OBJECT" | "STRING" | "UNKNOWN";
}
