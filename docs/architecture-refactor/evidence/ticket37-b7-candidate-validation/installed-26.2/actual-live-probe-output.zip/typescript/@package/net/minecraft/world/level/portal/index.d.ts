import { $Record, $String } from "java:java/lang";
import { $Optional, $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Direction$Axis, $Direction$Axis_ } from "java:net/minecraft/core";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $BlockUtil$FoundRectangle } from "java:net/minecraft/util";
import { $Entity, $EntityDimensions, $Relative, $Relative_ } from "java:net/minecraft/world/entity";
import { $BlockGetter, $LevelAccessor } from "java:net/minecraft/world/level";
import { $WorldBorder } from "java:net/minecraft/world/level/border";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/level/portal" {
    export class $PortalForcer {
        constructor(arg0: $ServerLevel);
        static TICKET_RADIUS: number;
        createPortal(arg0: $BlockPos_, arg1: $Direction$Axis_): $Optional<$BlockUtil$FoundRectangle>;
        findClosestPortalPosition(arg0: $BlockPos_, arg1: boolean, arg2: $WorldBorder): $Optional<$BlockPos>;
    }

    export class $PortalShape {
        static MAX_HEIGHT: number;
        static MAX_WIDTH: number;
        get complete(): boolean;
        isComplete(): boolean;
        get valid(): boolean;
        isValid(): boolean;
        static findAnyShape(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction$Axis_): $PortalShape;
        static findCollisionFreePosition(arg0: $Vec3_, arg1: $ServerLevel, arg2: $Entity, arg3: $EntityDimensions): $Vec3;
        static findEmptyPortalShape(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $Direction$Axis_): $Optional<$PortalShape>;
        static findPortalShape(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $Predicate<$PortalShape>, arg3: $Direction$Axis_): $Optional<$PortalShape>;
        static getRelativePosition(arg0: $BlockUtil$FoundRectangle, arg1: $Direction$Axis_, arg2: $Vec3_, arg3: $EntityDimensions): $Vec3;
        createPortalBlocks(arg0: $LevelAccessor): void;
    }

    export class $TeleportTransition extends $Record {
        constructor(newLevel: $ServerLevel, position: $Vec3_, deltaMovement: $Vec3_, yRot: number, xRot: number, missingRespawnBlock: boolean, asPassenger: boolean, relatives: $Relative_[], postTeleportTransition: $TeleportTransition$PostTeleportTransition);
        constructor(arg0: $ServerLevel, arg1: $Vec3_, arg2: $Vec3_, arg3: number, arg4: number, arg5: $Relative_[], arg6: $TeleportTransition$PostTeleportTransition);
        constructor(arg0: $ServerLevel, arg1: $Vec3_, arg2: $Vec3_, arg3: number, arg4: number, arg5: $TeleportTransition$PostTeleportTransition);
        static DO_NOTHING: $TeleportTransition$PostTeleportTransition;
        static PLACE_PORTAL_TICKET: $TeleportTransition$PostTeleportTransition;
        static PLAY_PORTAL_SOUND: $TeleportTransition$PostTeleportTransition;
        static createDefault(arg0: $ServerPlayer, arg1: $TeleportTransition$PostTeleportTransition): $TeleportTransition;
        static missingRespawnBlock(arg0: $ServerPlayer, arg1: $TeleportTransition$PostTeleportTransition): $TeleportTransition;
        asPassenger(): boolean;
        deltaMovement(): $Vec3;
        equals(arg0: object): boolean;
        hashCode(): number;
        missingRespawnBlock(): boolean;
        newLevel(): $ServerLevel;
        position(): $Vec3;
        postTeleportTransition(): $TeleportTransition$PostTeleportTransition;
        relatives(): $Set<$Relative>;
        toString(): string;
        transitionAsPassenger(): $TeleportTransition;
        withPosition(arg0: $Vec3_): $TeleportTransition;
        withRotation(arg0: number, arg1: number): $TeleportTransition;
        xRot(): number;
        yRot(): number;
    }

    export interface $TeleportTransition$PostTeleportTransition {
        onTransition(arg0: $Entity): void;
        then(arg0: $TeleportTransition$PostTeleportTransition): $TeleportTransition$PostTeleportTransition;
    }

}
