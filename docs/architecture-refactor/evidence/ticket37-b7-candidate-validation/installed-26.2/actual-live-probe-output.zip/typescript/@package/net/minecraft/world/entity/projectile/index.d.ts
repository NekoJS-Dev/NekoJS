import { $DoubleDoubleImmutablePair } from "java:it/unimi/dsi/fastutil/doubles";
import { $Consumer } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener, $ClientboundAddEntityPacket } from "java:net/minecraft/network/protocol/game";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerEntity, $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $Entity$RemovalReason, $Entity$RemovalReason_, $EntityReference, $InterpolationHandler, $LivingEntity, $TraceableEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as arrow from "java:net/minecraft/world/entity/projectile/arrow";
export * as hurtingprojectile from "java:net/minecraft/world/entity/projectile/hurtingprojectile";
export * as throwableitemprojectile from "java:net/minecraft/world/entity/projectile/throwableitemprojectile";

declare module "java:net/minecraft/world/entity/projectile" {
    export class $FireworkRocketEntity extends $Projectile implements $ItemSupplier {
        constructor(arg0: $EntityType<$FireworkRocketEntity>, arg1: $Level);
        constructor(arg0: $Level, arg1: number, arg2: number, arg3: number, arg4: $ItemStack_);
        constructor(arg0: $Level, arg1: $Entity, arg2: number, arg3: number, arg4: number, arg5: $ItemStack_);
        constructor(arg0: $Level, arg1: $ItemStack_, arg2: number, arg3: number, arg4: number, arg5: boolean);
        constructor(arg0: $Level, arg1: $ItemStack_, arg2: $Entity, arg3: number, arg4: number, arg5: number, arg6: boolean);
        constructor(arg0: $Level, arg1: $ItemStack_, arg2: $LivingEntity);
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get attackable(): boolean;
        isAttackable(): boolean;
        get shotAtAngle(): boolean;
        isShotAtAngle(): boolean;
        calculateHorizontalHurtKnockbackDirection(arg0: $LivingEntity, arg1: $DamageSource): $DoubleDoubleImmutablePair;
        handleEntityEvent(arg0: number): void;
        shouldRenderAtSqrDistance(arg0: number): boolean;
        shouldRender(arg0: number, arg1: number, arg2: number): boolean;
        tick(): void;
    }

    export class $FishingHook extends $Projectile {
        constructor(arg0: $EntityType<$FishingHook>, arg1: $Level);
        constructor(arg0: $Player, arg1: $Level, arg2: number, arg3: number);
        get hookedIn(): $Entity;
        getHookedIn(): $Entity;
        get interpolation(): $InterpolationHandler;
        getInterpolation(): $InterpolationHandler;
        get playerOwner(): $Player;
        getPlayerOwner(): $Player;
        get openWaterFishing(): boolean;
        isOpenWaterFishing(): boolean;
        canUsePortal(arg0: boolean): boolean;
        getAddEntityPacket(arg0: $ServerEntity): $Packet<$ClientGamePacketListener>;
        handleEntityEvent(arg0: number): void;
        onClientRemoval(): void;
        onSyncedDataUpdated(arg0: $EntityDataAccessor<any>): void;
        recreateFromPacket(arg0: $ClientboundAddEntityPacket): void;
        remove(arg0: $Entity$RemovalReason_): void;
        retrieve(arg0: $ItemStack_): number;
        shouldRenderAtSqrDistance(arg0: number): boolean;
        tick(): void;
    }

    export interface $ItemSupplier {
        getItem(): $ItemStack;
    }

    export class $Projectile extends $Entity implements $TraceableEntity {
        get dimensionChangingDelay(): number;
        getDimensionChangingDelay(): number;
        get effectSource(): $Entity;
        getEffectSource(): $Entity;
        get owner(): $Entity;
        getOwner(): $Entity;
        set owner(value: $Entity);
        get pickRadius(): number;
        getPickRadius(): number;
        get pickable(): boolean;
        isPickable(): boolean;
        static spawnProjectileFromRotation<T>(arg0: $Projectile$ProjectileFactory<T>, arg1: $ServerLevel, arg2: $ItemStack_, arg3: $LivingEntity, arg4: number, arg5: number, arg6: number): T;
        static spawnProjectileUsingShoot<T>(arg0: T, arg1: $ServerLevel, arg2: $ItemStack_, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): T;
        static spawnProjectileUsingShoot<T>(arg0: $Projectile$ProjectileFactory<T>, arg1: $ServerLevel, arg2: $ItemStack_, arg3: $LivingEntity, arg4: number, arg5: number, arg6: number, arg7: number, arg8: number): T;
        static spawnProjectile<T>(arg0: T, arg1: $ServerLevel, arg2: $ItemStack_, arg3: $Consumer<T>): T;
        static spawnProjectile<T>(arg0: T, arg1: $ServerLevel, arg2: $ItemStack_): T;
        applyOnProjectileSpawned(arg0: $ServerLevel, arg1: $ItemStack_): void;
        calculateHorizontalHurtKnockbackDirection(arg0: $LivingEntity, arg1: $DamageSource): $DoubleDoubleImmutablePair;
        deflect(arg0: $ProjectileDeflection, arg1: $Entity, arg2: $EntityReference<$Entity>, arg3: boolean): boolean;
        getAddEntityPacket(arg0: $ServerEntity): $Packet<$ClientGamePacketListener>;
        getMovementToShoot(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): $Vec3;
        hurtServer(arg0: $ServerLevel, arg1: $DamageSource, arg2: number): boolean;
        mayBreak(arg0: $ServerLevel): boolean;
        mayInteract(arg0: $ServerLevel, arg1: $BlockPos_): boolean;
        onAboveBubbleColumn(arg0: boolean, arg1: $BlockPos_): void;
        onInsideBubbleColumn(arg0: boolean): void;
        recreateFromPacket(arg0: $ClientboundAddEntityPacket): void;
        restoreFrom(arg0: $Entity): void;
        shootFromRotation(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): void;
        shoot(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): void;
        tick(): void;
    }

    export interface $Projectile$ProjectileFactory<T extends $Projectile> {
        create(arg0: $ServerLevel, arg1: $LivingEntity, arg2: $ItemStack_): T;
    }

    export interface $ProjectileDeflection {
        deflect(arg0: $Projectile, arg1: $Entity, arg2: $RandomSource): void;
        static AIM_DEFLECT: $ProjectileDeflection;
        static MOMENTUM_DEFLECT: $ProjectileDeflection;
        static NONE: $ProjectileDeflection;
        static REVERSE: $ProjectileDeflection;
    }

    export class $ThrowableProjectile extends $Projectile {
        canUsePortal(arg0: boolean): boolean;
        shouldRenderAtSqrDistance(arg0: number): boolean;
        tick(): void;
    }

}
