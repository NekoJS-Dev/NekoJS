import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Integer, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $Holder_, $TypedInstance } from "java:net/minecraft/core";
import { $DataComponentGetter, $DataComponentMap, $DataComponentPatch, $DataComponentType, $TypedDataComponent } from "java:net/minecraft/core/component";
import { $ParticleOptions } from "java:net/minecraft/core/particles";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $Entity, $LivingEntity, $Mob } from "java:net/minecraft/world/entity";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $AbstractBoat } from "java:net/minecraft/world/entity/vehicle/boat";
import { $Item$TooltipContext, $ItemStack, $ItemStack_, $Rarity, $Rarity_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $BlockAndLightGetter, $BlockGetter, $Level, $LevelReader } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Fluid, $FluidState, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $PathType, $PathType_ } from "java:net/minecraft/world/level/pathfinder";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $MutableDataComponentHolder, $SoundAction } from "java:net/neoforged/neoforge/common";
import { $Lazy } from "java:net/neoforged/neoforge/common/util";

export * as crafting from "java:net/neoforged/neoforge/fluids/crafting";

declare module "java:net/neoforged/neoforge/fluids" {
    export interface $FluidInstance extends $TypedInstance, $DataComponentGetter {
        amount(): number;
        getFluidType(): $FluidType;
        is(arg0: $FluidType): boolean;
        static FIELD_AMOUNT: string;
        static FIELD_COMPONENTS: string;
        static FIELD_ID: string;
        static FLUID_HOLDER_CODEC: $Codec<$Holder<$Fluid>>;
        static FLUID_HOLDER_CODEC_WITH_BOUND_COMPONENTS: $Codec<$Holder<$Fluid>>;
        static FLUID_HOLDER_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$Fluid>>;
    }

    export class $FluidStack implements $MutableDataComponentHolder, $FluidInstance {
        constructor(arg0: $Holder<$Fluid_>, arg1: number);
        constructor(arg0: $Holder<$Fluid_>, arg1: number, arg2: $DataComponentPatch);
        constructor(arg0: $Fluid_, arg1: number);
        constructor(arg0: $Fluid_, arg1: number, arg2: $DataComponentPatch);
        static CODEC: $Codec<$FluidStack>;
        static EMPTY: $FluidStack;
        static MAP_CODEC: $MapCodec<$FluidStack>;
        static OPTIONAL_CODEC: $Codec<$FluidStack>;
        static OPTIONAL_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FluidStack>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FluidStack>;
        get amount(): number;
        getAmount(): number;
        set amount(value: number);
        get componentsPatch(): $DataComponentPatch;
        getComponentsPatch(): $DataComponentPatch;
        get components(): $DataComponentMap;
        getComponents(): $DataComponentMap;
        get descriptionId(): string;
        getDescriptionId(): string;
        get fluid(): $Fluid;
        getFluid(): $Fluid;
        get hoverName(): $Component;
        getHoverName(): $Component;
        get prototype(): $DataComponentMap;
        getPrototype(): $DataComponentMap;
        get componentsPatchEmpty(): boolean;
        isComponentsPatchEmpty(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        static fixedAmountCodec(arg0: number): $Codec<$FluidStack>;
        static hashFluidAndComponents(arg0: $FluidStack_): number;
        static isSameFluidSameComponents(arg0: $FluidStack_, arg1: $FluidStackTemplate): boolean;
        static isSameFluidSameComponents(arg0: $FluidStack_, arg1: $FluidStack_): boolean;
        static isSameFluid(arg0: $FluidStack_, arg1: $FluidStackTemplate): boolean;
        static isSameFluid(arg0: $FluidStack_, arg1: $FluidStack_): boolean;
        static lenientOptionalFieldOf(arg0: string): $MapCodec<$FluidStack>;
        static matches(arg0: $FluidStack_, arg1: $FluidStackTemplate): boolean;
        static matches(arg0: $FluidStack_, arg1: $FluidStack_): boolean;
        amount(): number;
        applyComponents(arg0: $DataComponentMap): void;
        applyComponents(arg0: $DataComponentPatch): void;
        copyAndClear(): $FluidStack;
        copyWithAmount(arg0: number): $FluidStack;
        copy(): $FluidStack;
        getTooltipLines(arg0: $Item$TooltipContext, arg1: $Player, arg2: $TooltipFlag): $List<$Component>;
        grow(arg0: number): void;
        hasNonDefault(arg0: $DataComponentType<any>): boolean;
        immutableComponents(): $DataComponentMap;
        is(arg0: $Predicate<$Holder<$Fluid_>>): boolean;
        limitSize(arg0: number): void;
        remove<T>(arg0: $DataComponentType<T>): T;
        set<T>(arg0: $DataComponentType<T>, arg1: T): T;
        set<T>(arg0: $TypedDataComponent<T>): T;
        shrink(arg0: number): void;
        split(arg0: number): $FluidStack;
        toString(): string;
        transmuteCopy(arg0: $Fluid_, arg1: number): $FluidStack;
        transmuteCopy(arg0: $Fluid_): $FluidStack;
        typeHolder(): $Holder<$Fluid>;
    }

    export class $FluidStackTemplate extends $Record implements $FluidInstance {
        constructor(arg0: $Holder<$Fluid_>, arg1: number);
        constructor(fluid: $Holder<$Fluid_>, amount: number, components: $DataComponentPatch);
        constructor(arg0: $Fluid_, arg1: number);
        constructor(arg0: $Fluid_, arg1: number, arg2: $DataComponentPatch);
        static CODEC: $Codec<$FluidStackTemplate>;
        static MAP_CODEC: $MapCodec<$FluidStackTemplate>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FluidStackTemplate>;
        static fixedAmountCodec(arg0: number): $Codec<$FluidStackTemplate>;
        static fixedAmountStreamCodec(arg0: number): $StreamCodec<$RegistryFriendlyByteBuf, $FluidStackTemplate>;
        static fromNonEmptyStack(arg0: $FluidStack_): $FluidStackTemplate;
        amount(): number;
        apply(arg0: number, arg1: $DataComponentPatch): $FluidStack;
        apply(arg0: $DataComponentPatch): $FluidStack;
        components(): $DataComponentPatch;
        create(): $FluidStack;
        equals(arg0: object): boolean;
        fluid(): $Holder<$Fluid>;
        get<T>(arg0: $DataComponentType<T>): T;
        hashCode(): number;
        toString(): string;
        typeHolder(): $Holder<$Fluid>;
        withAmount(arg0: number): $FluidStackTemplate;
    }

    export class $FluidType {
        constructor(arg0: $FluidType$Properties);
        static BUCKET_VOLUME: number;
        static SIZE: $Lazy<number>;
        get density(): number;
        getDensity(): number;
        get descriptionId(): string;
        getDescriptionId(): string;
        get description(): $Component;
        getDescription(): $Component;
        get dripInfo(): $FluidType$DripstoneDripInfo;
        getDripInfo(): $FluidType$DripstoneDripInfo;
        get isWaterLike(): boolean;
        getIsWaterLike(): boolean;
        get lightLevel(): number;
        getLightLevel(): number;
        get rarity(): $Rarity;
        getRarity(): $Rarity;
        get temperature(): number;
        getTemperature(): number;
        get viscosity(): number;
        getViscosity(): number;
        get air(): boolean;
        isAir(): boolean;
        get lighterThanAir(): boolean;
        isLighterThanAir(): boolean;
        get vanilla(): boolean;
        isVanilla(): boolean;
        canBePlacedInLevel(arg0: $BlockAndLightGetter, arg1: $BlockPos_, arg2: $FluidState): boolean;
        canBePlacedInLevel(arg0: $BlockAndLightGetter, arg1: $BlockPos_, arg2: $FluidStack_): boolean;
        canConvertToSource(arg0: $FluidState, arg1: $LevelReader, arg2: $BlockPos_): boolean;
        canConvertToSource(arg0: $FluidStack_): boolean;
        canDrownIn(arg0: $LivingEntity): boolean;
        canExtinguish(arg0: $Entity): boolean;
        canExtinguish(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        canHydrate(arg0: $Entity): boolean;
        canHydrate(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $BlockState_, arg4: $BlockPos_): boolean;
        canHydrate(arg0: $FluidStack_): boolean;
        canPushEntity(arg0: $Entity): boolean;
        canRideVehicleUnder(arg0: $Entity, arg1: $Entity): boolean;
        canSwim(arg0: $Entity): boolean;
        getAdjacentBlockPathType(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob, arg4: $PathType_): $PathType;
        getBlockForFluidState(arg0: $BlockAndLightGetter, arg1: $BlockPos_, arg2: $FluidState): $BlockState;
        getBlockPathType(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob, arg4: boolean): $PathType;
        getBucket(arg0: $FluidStack_): $ItemStack;
        getDensity(arg0: $FluidState, arg1: $BlockAndLightGetter, arg2: $BlockPos_): number;
        getDensity(arg0: $FluidStack_): number;
        getDescriptionId(arg0: $FluidStack_): string;
        getDescription(arg0: $FluidStack_): $Component;
        getFallDistanceModifier(arg0: $Entity): number;
        getLightLevel(arg0: $FluidState, arg1: $BlockAndLightGetter, arg2: $BlockPos_): number;
        getLightLevel(arg0: $FluidStack_): number;
        getRarity(arg0: $FluidStack_): $Rarity;
        getSound(arg0: $Entity, arg1: $SoundAction): $SoundEvent;
        getSound(arg0: $LivingEntity, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $SoundAction): $SoundEvent;
        getSound(arg0: $SoundAction): $SoundEvent;
        getSound(arg0: $FluidStack_, arg1: $SoundAction): $SoundEvent;
        getStateForPlacement(arg0: $BlockAndLightGetter, arg1: $BlockPos_, arg2: $FluidStack_): $FluidState;
        getTemperature(arg0: $FluidState, arg1: $BlockAndLightGetter, arg2: $BlockPos_): number;
        getTemperature(arg0: $FluidStack_): number;
        getViscosity(arg0: $FluidState, arg1: $BlockAndLightGetter, arg2: $BlockPos_): number;
        getViscosity(arg0: $FluidStack_): number;
        handleCauldronDrip(arg0: $Fluid_, arg1: $Level, arg2: $BlockPos_): boolean;
        isVaporizedOnPlacement(arg0: $Level, arg1: $BlockPos_, arg2: $FluidStack_): boolean;
        motionScale(arg0: $Entity): number;
        move(arg0: $LivingEntity, arg1: $Vec3_, arg2: number): boolean;
        move(arg0: $FluidState, arg1: $LivingEntity, arg2: $Vec3_, arg3: number): boolean;
        onVaporize(arg0: $LivingEntity, arg1: $Level, arg2: $BlockPos_, arg3: $FluidStack_): void;
        supportsBoating(arg0: $AbstractBoat): boolean;
        supportsBoating(arg0: $FluidState, arg1: $AbstractBoat): boolean;
        toString(): string;
    }

    export class $FluidType$DripstoneDripInfo extends $Record {
        constructor(chance: number, dripParticle: $ParticleOptions, filledCauldron: $Block_);
        chance(): number;
        dripParticle(): $ParticleOptions;
        equals(arg0: object): boolean;
        filledCauldron(): $Block;
        hashCode(): number;
        toString(): string;
    }

    export class $FluidType$Properties {
        static create(): $FluidType$Properties;
        addDripstoneDripping(arg0: number, arg1: $ParticleOptions, arg2: $Block_, arg3: $SoundEvent_): $FluidType$Properties;
        adjacentPathType(arg0: $PathType_): $FluidType$Properties;
        canConvertToSource(arg0: boolean): $FluidType$Properties;
        canDrown(arg0: boolean): $FluidType$Properties;
        canExtinguish(arg0: boolean): $FluidType$Properties;
        canHydrate(arg0: boolean): $FluidType$Properties;
        canPushEntity(arg0: boolean): $FluidType$Properties;
        canSwim(arg0: boolean): $FluidType$Properties;
        density(arg0: number): $FluidType$Properties;
        descriptionId(arg0: string): $FluidType$Properties;
        fallDistanceModifier(arg0: number): $FluidType$Properties;
        isWaterLike(arg0: boolean): $FluidType$Properties;
        lightLevel(arg0: number): $FluidType$Properties;
        motionScale(arg0: number): $FluidType$Properties;
        pathType(arg0: $PathType_): $FluidType$Properties;
        rarity(arg0: $Rarity_): $FluidType$Properties;
        sound(arg0: $SoundAction, arg1: $SoundEvent_): $FluidType$Properties;
        supportsBoating(arg0: boolean): $FluidType$Properties;
        temperature(arg0: number): $FluidType$Properties;
        viscosity(arg0: number): $FluidType$Properties;
    }

    export interface $InFluidPredicate<E extends $Entity> {
        test(arg0: E, arg1: $FluidType, arg2: number): boolean;
    }

    /** fluid:id | RegistryTypes.Fluid | $Fluid | $NekoId | { fluid?|id?, amount? } */
    export type $FluidStack_ = $FluidStack | RegistryTypes.Fluid | $Fluid | $NekoId | { fluid?: RegistryTypes.Fluid, id?: RegistryTypes.Fluid, amount?: number };
}
