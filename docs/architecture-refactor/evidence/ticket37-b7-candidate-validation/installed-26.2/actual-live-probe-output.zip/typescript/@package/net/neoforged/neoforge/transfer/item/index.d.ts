import { $Codec } from "java:com/mojang/serialization";
import { $String } from "java:java/lang";
import { $Predicate, $Supplier } from "java:java/util/function";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentMap, $DataComponentPatch, $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Item, $ItemStack, $ItemStackTemplate, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $ItemLike, $ItemLike_ } from "java:net/minecraft/world/level";
import { $DataComponentHolderResource } from "java:net/neoforged/neoforge/transfer/resource";

declare module "java:net/neoforged/neoforge/transfer/item" {
    export class $ItemResource implements $DataComponentHolderResource {
        static CODEC: $Codec<$ItemResource>;
        static EMPTY: $ItemResource;
        static OPTIONAL_CODEC: $Codec<$ItemResource>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemResource>;
        get componentsPatch(): $DataComponentPatch;
        getComponentsPatch(): $DataComponentPatch;
        get components(): $DataComponentMap;
        getComponents(): $DataComponentMap;
        get hoverName(): $Component;
        getHoverName(): $Component;
        get item(): $Item;
        getItem(): $Item;
        get maxStackSize(): number;
        getMaxStackSize(): number;
        get componentsPatchEmpty(): boolean;
        isComponentsPatchEmpty(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        static of(arg0: $Holder<$Item_>, arg1: $DataComponentPatch): $ItemResource;
        static of(arg0: $Holder<$Item_>): $ItemResource;
        static of(arg0: $ItemStackTemplate): $ItemResource;
        static of(arg0: $ItemStack_): $ItemResource;
        static of(arg0: $ItemLike_, arg1: $DataComponentPatch): $ItemResource;
        static of(arg0: $ItemLike_): $ItemResource;
        equals(arg0: object): boolean;
        hashCode(): number;
        is(arg0: $ItemLike_): boolean;
        matches(arg0: $ItemStackTemplate): boolean;
        matches(arg0: $ItemStack_): boolean;
        test(arg0: $Predicate<$ItemStack_>): boolean;
        toStack(arg0: number): $ItemStack;
        toStack(): $ItemStack;
        toString(): string;
        typeHolder(): $Holder<$Item>;
        value(): $Item;
        withMergedPatch(arg0: $DataComponentPatch): $ItemResource;
        without(arg0: $Supplier<$DataComponentType<any>>): $ItemResource;
        without(arg0: $DataComponentType<any>): $ItemResource;
        with<D>(arg0: $Supplier<$DataComponentType<D>>, arg1: D): $ItemResource;
        with<D>(arg0: $DataComponentType<D>, arg1: D): $ItemResource;
    }

}
