import { $MapCodec } from "java:com/mojang/serialization";
import { $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $BiPredicate, $Function, $Predicate, $Supplier } from "java:java/util/function";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $ValueInput, $ValueOutput } from "java:net/minecraft/world/level/storage";

declare module "java:net/neoforged/neoforge/attachment" {
    export class $AttachmentHolder implements $IAttachmentHolder {
        constructor();
        static ATTACHMENTS_NBT_KEY: string;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        hasAttachments(): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        removeData<T>(arg0: $AttachmentType<T>): T;
        serializeAttachments(arg0: $ValueOutput): void;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
    }

    export class $AttachmentHolder$AsField extends $AttachmentHolder {
        constructor(arg0: $IAttachmentHolder);
        deserializeInternal(arg0: $HolderLookup$Provider, arg1: $ValueInput): void;
        syncData(arg0: $AttachmentType<any>): void;
    }

    export interface $AttachmentSyncHandler<T> {
        read(arg0: $IAttachmentHolder, arg1: $RegistryFriendlyByteBuf, arg2: T): T;
        sendToPlayer(arg0: $IAttachmentHolder, arg1: $ServerPlayer): boolean;
        write(arg0: $RegistryFriendlyByteBuf, arg1: T, arg2: boolean): void;
    }

    export class $AttachmentType<T> {
        static builder<T>(arg0: $Function<$IAttachmentHolder, T>): $AttachmentType$Builder<T>;
        static builder<T>(arg0: $Supplier<T>): $AttachmentType$Builder<T>;
        static serializable<T>(arg0: $Function<$IAttachmentHolder, T>): $AttachmentType$Builder<T>;
        static serializable<T>(arg0: $Supplier<T>): $AttachmentType$Builder<T>;
    }

    export class $AttachmentType$Builder<T> {
        build(): $AttachmentType<T>;
        copyHandler(arg0: $IAttachmentCopyHandler<T>): $AttachmentType$Builder<T>;
        copyOnDeath(): $AttachmentType$Builder<T>;
        serialize(arg0: $MapCodec<T>, arg1: $Predicate<any>): $AttachmentType$Builder<T>;
        serialize(arg0: $MapCodec<T>): $AttachmentType$Builder<T>;
        serialize(arg0: $IAttachmentSerializer<T>): $AttachmentType$Builder<T>;
        sync(arg0: $BiPredicate<$IAttachmentHolder, $ServerPlayer>, arg1: $StreamCodec<any, T>): $AttachmentType$Builder<T>;
        sync(arg0: $StreamCodec<any, T>): $AttachmentType$Builder<T>;
        sync(arg0: $AttachmentSyncHandler<T>): $AttachmentType$Builder<T>;
    }

    export interface $IAttachmentCopyHandler<T> {
        copy(arg0: T, arg1: $IAttachmentHolder, arg2: $HolderLookup$Provider): T;
    }

    export interface $IAttachmentHolder {
        getData<T>(arg0: $Supplier<$AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier<$AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier<$AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        hasAttachments(): boolean;
        hasData<T>(arg0: $Supplier<$AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        removeData<T>(arg0: $Supplier<$AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        setData<T>(arg0: $Supplier<$AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        syncData(arg0: $Supplier<$AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
    }

    export interface $IAttachmentSerializer<T> {
        read(arg0: $IAttachmentHolder, arg1: $ValueInput): T;
        write(arg0: T, arg1: $ValueOutput): boolean;
    }

}
