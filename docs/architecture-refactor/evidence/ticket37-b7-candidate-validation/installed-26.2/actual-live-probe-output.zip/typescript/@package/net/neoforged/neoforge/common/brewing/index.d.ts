import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";

declare module "java:net/neoforged/neoforge/common/brewing" {
    export interface $IBrewingRecipe {
        getOutput(arg0: $ItemStack_, arg1: $ItemStack_): $ItemStack;
        isIngredient(arg0: $ItemStack_): boolean;
        isInput(arg0: $ItemStack_): boolean;
    }

}
