import { $Record, $String } from "java:java/lang";
import { $Optional, $Set } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $Entity } from "java:net/minecraft/world/entity";
import { $PoiRecord, $PoiType, $PoiType_ } from "java:net/minecraft/world/entity/ai/village/poi";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $LevelChunk } from "java:net/minecraft/world/level/chunk";

declare module "java:net/minecraft/util/debug" {
    export class $DebugPoiInfo extends $Record {
        constructor(pos: $BlockPos_, poiType: $Holder<$PoiType_>, freeTicketCount: number);
        constructor(arg0: $PoiRecord);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DebugPoiInfo>;
        equals(arg0: object): boolean;
        freeTicketCount(): number;
        hashCode(): number;
        poiType(): $Holder<$PoiType>;
        pos(): $BlockPos;
        toString(): string;
    }

    export class $DebugSubscription<T> {
        constructor(arg0: $StreamCodec<any, T>);
        constructor(arg0: $StreamCodec<any, T>, arg1: number);
        static DOES_NOT_EXPIRE: number;
        emptyUpdate(): $DebugSubscription$Update<T>;
        expireAfterTicks(): number;
        packEvent(arg0: T): $DebugSubscription$Event<T>;
        packUpdate(arg0: T): $DebugSubscription$Update<T>;
        toString(): string;
        valueStreamCodec(): $StreamCodec<any, T>;
    }

    export class $DebugSubscription$Event<T> extends $Record {
        constructor(subscription: $DebugSubscription<T>, value: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DebugSubscription$Event<any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        subscription(): $DebugSubscription<T>;
        toString(): string;
        value(): T;
    }

    export class $DebugSubscription$Update<T> extends $Record {
        constructor(subscription: $DebugSubscription<T>, value: $Optional<T>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DebugSubscription$Update<any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        subscription(): $DebugSubscription<T>;
        toString(): string;
        value(): $Optional<T>;
    }

    export interface $DebugValueSource {
        registerDebugValues(arg0: $ServerLevel, arg1: $DebugValueSource$Registration): void;
    }

    export interface $DebugValueSource$Registration {
        register<T>(arg0: $DebugSubscription<T>, arg1: $DebugValueSource$ValueGetter<T>): void;
    }

    export interface $DebugValueSource$ValueGetter<T> {
        get(): T;
    }

    export class $LevelDebugSynchronizers {
        constructor(arg0: $ServerLevel);
        broadcastEventToTracking<T>(arg0: $BlockPos_, arg1: $DebugSubscription<T>, arg2: T): void;
        clearBlockValue<T>(arg0: $BlockPos_, arg1: $DebugSubscription<T>): void;
        clearEntityValue<T>(arg0: $Entity, arg1: $DebugSubscription<T>): void;
        dropBlockEntity(arg0: $BlockPos_): void;
        dropChunk(arg0: $ChunkPos): void;
        dropEntity(arg0: $Entity): void;
        dropPoi(arg0: $BlockPos_): void;
        hasAnySubscriberFor(arg0: $DebugSubscription<any>): boolean;
        registerBlockEntity(arg0: $BlockEntity): void;
        registerChunk(arg0: $LevelChunk): void;
        registerEntity(arg0: $Entity): void;
        registerPoi(arg0: $PoiRecord): void;
        sendBlockValue<T>(arg0: $BlockPos_, arg1: $DebugSubscription<T>, arg2: T): void;
        sendEntityValue<T>(arg0: $Entity, arg1: $DebugSubscription<T>, arg2: T): void;
        startTrackingChunk(arg0: $ServerPlayer, arg1: $ChunkPos): void;
        startTrackingEntity(arg0: $ServerPlayer, arg1: $Entity): void;
        tick(arg0: $ServerDebugSubscribers): void;
        updatePoi(arg0: $BlockPos_): void;
    }

    export class $ServerDebugSubscribers {
        constructor(arg0: $MinecraftServer);
        broadcastToAll(arg0: $DebugSubscription<any>, arg1: $Packet<any>): void;
        enabledSubscriptions(): $Set<$DebugSubscription<any>>;
        hasAnySubscriberFor(arg0: $DebugSubscription<any>): boolean;
        hasRequiredPermissions(arg0: $ServerPlayer): boolean;
        tick(): void;
    }

}
