import { $Enum, $Record, $String } from "java:java/lang";
import { $Set } from "java:java/util";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Entity, $Mob } from "java:net/minecraft/world/entity";
import { $BlockGetter, $CollisionGetter, $PathNavigationRegion } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/level/pathfinder" {
    export class $Node {
        constructor(arg0: number, arg1: number, arg2: number);
        cameFrom: $Node;
        closed: boolean;
        costMalus: number;
        f: number;
        g: number;
        h: number;
        heapIdx: number;
        type: $PathType;
        walkedDistance: number;
        x: number;
        y: number;
        z: number;
        static createFromStream(arg0: $FriendlyByteBuf): $Node;
        static createHash(arg0: number, arg1: number, arg2: number): number;
        asBlockPos(): $BlockPos;
        asVec3(): $Vec3;
        cloneAndMove(arg0: number, arg1: number, arg2: number): $Node;
        distanceManhattan(arg0: $BlockPos_): number;
        distanceManhattan(arg0: $Node): number;
        distanceToSqr(arg0: $BlockPos_): number;
        distanceToSqr(arg0: $Node): number;
        distanceToXZ(arg0: $Node): number;
        distanceTo(arg0: $BlockPos_): number;
        distanceTo(arg0: $Node): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        inOpenSet(): boolean;
        toString(): string;
        writeToStream(arg0: $FriendlyByteBuf): void;
    }

    export class $NodeEvaluator {
        constructor();
        get start(): $Node;
        getStart(): $Node;
        static isBurningBlock(arg0: $BlockState_): boolean;
        canFloat(): boolean;
        canOpenDoors(): boolean;
        canPassDoors(): boolean;
        canWalkOverFences(): boolean;
        done(): void;
        getNeighbors(arg0: $Node[], arg1: $Node): number;
        getPathTypeOfMob(arg0: $PathfindingContext, arg1: number, arg2: number, arg3: number, arg4: $Mob): $PathType;
        getPathType(arg0: $Mob, arg1: $BlockPos_): $PathType;
        getPathType(arg0: $PathfindingContext, arg1: number, arg2: number, arg3: number): $PathType;
        getTarget(arg0: number, arg1: number, arg2: number): $Target;
        prepare(arg0: $PathNavigationRegion, arg1: $Mob): void;
    }

    export class $Path {
        constructor(arg0: $Node[], arg1: $BlockPos_, arg2: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $Path>;
        get distToTarget(): number;
        getDistToTarget(): number;
        get endNode(): $Node;
        getEndNode(): $Node;
        get nextNodeIndex(): number;
        getNextNodeIndex(): number;
        set nextNodeIndex(value: number);
        get nextNodePos(): $BlockPos;
        getNextNodePos(): $BlockPos;
        get nextNode(): $Node;
        getNextNode(): $Node;
        get nodeCount(): number;
        getNodeCount(): number;
        get previousNode(): $Node;
        getPreviousNode(): $Node;
        get target(): $BlockPos;
        getTarget(): $BlockPos;
        get done(): boolean;
        isDone(): boolean;
        static createFromStream(arg0: $FriendlyByteBuf): $Path;
        advance(): void;
        canReach(): boolean;
        copy(): $Path;
        debugData(): $Path$DebugData;
        equals(arg0: object): boolean;
        getEntityPosAtNode(arg0: $Entity, arg1: number): $Vec3;
        getNextEntityPos(arg0: $Entity): $Vec3;
        getNodePos(arg0: number): $BlockPos;
        getNode(arg0: number): $Node;
        hashCode(): number;
        notStarted(): boolean;
        replaceNode(arg0: number, arg1: $Node): void;
        sameAs(arg0: $Path): boolean;
        toString(): string;
        truncateNodes(arg0: number): void;
        writeToStream(arg0: $FriendlyByteBuf): void;
    }

    export class $Path$DebugData extends $Record {
        constructor(openSet: $Node[], closedSet: $Node[], targetNodes: $Target[]);
        static read(arg0: $FriendlyByteBuf): $Path$DebugData;
        closedSet(): $Node[];
        equals(arg0: object): boolean;
        hashCode(): number;
        openSet(): $Node[];
        targetNodes(): $Set<$Target>;
        toString(): string;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $PathComputationType {
        static AIR: $PathComputationType;
        static LAND: $PathComputationType;
        static WATER: $PathComputationType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PathComputationType[];
        static valueOf(name: string): $PathComputationType;
    }

    export class $PathType {
        static BIG_MOBS_CLOSE_TO_DANGER: $PathType;
        static BLOCKED: $PathType;
        static BREACH: $PathType;
        static COCOA: $PathType;
        static DAMAGE_CAUTIOUS: $PathType;
        static DAMAGING: $PathType;
        static DAMAGING_IN_NEIGHBOR: $PathType;
        static DOOR_IRON_CLOSED: $PathType;
        static DOOR_OPEN: $PathType;
        static DOOR_WOOD_CLOSED: $PathType;
        static FENCE: $PathType;
        static FIRE: $PathType;
        static FIRE_IN_NEIGHBOR: $PathType;
        static LAVA: $PathType;
        static LEAVES: $PathType;
        static ON_TOP_OF_POWDER_SNOW: $PathType;
        static ON_TOP_OF_TRAPDOOR: $PathType;
        static OPEN: $PathType;
        static POWDER_SNOW: $PathType;
        static RAIL: $PathType;
        static STICKY_HONEY: $PathType;
        static TRAPDOOR: $PathType;
        static UNPASSABLE_RAIL: $PathType;
        static WALKABLE: $PathType;
        static WALKABLE_DOOR: $PathType;
        static WATER: $PathType;
        static WATER_BORDER: $PathType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PathType[];
        static valueOf(name: string): $PathType;
    }

    export class $PathTypeCache {
        constructor();
        getOrCompute(arg0: $BlockGetter, arg1: $BlockPos_): $PathType;
        invalidate(arg0: $BlockPos_): void;
    }

    export class $PathfindingContext {
        constructor(arg0: $CollisionGetter, arg1: $Mob);
        getBlockState(arg0: $BlockPos_): $BlockState;
        getPathTypeFromState(arg0: number, arg1: number, arg2: number): $PathType;
        level(): $CollisionGetter;
        mobPosition(): $BlockPos;
    }

    export class $Target extends $Node {
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: $Node);
        get bestNode(): $Node;
        getBestNode(): $Node;
        get reached(): boolean;
        isReached(): boolean;
        static createFromStream(arg0: $FriendlyByteBuf): $Target;
        setReached(): void;
        updateBest(arg0: number, arg1: $Node): void;
    }

    export type $PathComputationType_ = $PathComputationType | "AIR" | "LAND" | "WATER";
    export type $PathType_ = $PathType | "BIG_MOBS_CLOSE_TO_DANGER" | "BLOCKED" | "BREACH" | "COCOA" | "DAMAGE_CAUTIOUS" | "DAMAGING" | "DAMAGING_IN_NEIGHBOR" | "DOOR_IRON_CLOSED" | "DOOR_OPEN" | "DOOR_WOOD_CLOSED" | "FENCE" | "FIRE" | "FIRE_IN_NEIGHBOR" | "LAVA" | "LEAVES" | "ON_TOP_OF_POWDER_SNOW" | "ON_TOP_OF_TRAPDOOR" | "OPEN" | "POWDER_SNOW" | "RAIL" | "STICKY_HONEY" | "TRAPDOOR" | "UNPASSABLE_RAIL" | "WALKABLE" | "WALKABLE_DOOR" | "WATER" | "WATER_BORDER";
}
