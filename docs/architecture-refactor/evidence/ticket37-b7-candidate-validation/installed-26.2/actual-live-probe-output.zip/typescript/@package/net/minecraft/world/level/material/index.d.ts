import type { RegistryTypes } from "@special/types";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Enum, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Function } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $Holder$Reference, $Holder_, $IdMapper, $TypedInstance } from "java:net/minecraft/core";
import { $ParticleOptions } from "java:net/minecraft/core/particles";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $RandomSource } from "java:net/minecraft/util";
import { $Entity, $InsideBlockEffectApplier } from "java:net/minecraft/world/entity";
import { $Item, $Item_ } from "java:net/minecraft/world/item";
import { $BlockGetter, $Level, $LevelReader } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_, $StateDefinition, $StateHolder } from "java:net/minecraft/world/level/block/state";
import { $BooleanProperty, $IntegerProperty } from "java:net/minecraft/world/level/block/state/properties";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $VoxelShape } from "java:net/minecraft/world/phys/shapes";
import { $IFluidExtension, $IFluidStateExtension } from "java:net/neoforged/neoforge/common/extensions";
import { $FluidType } from "java:net/neoforged/neoforge/fluids";
import { $FluidResource } from "java:net/neoforged/neoforge/transfer/fluid";

declare module "java:net/minecraft/world/level/material" {
    export class $FlowingFluid extends $Fluid {
        constructor();
        static FALLING: $BooleanProperty;
        static LEVEL: $IntegerProperty;
        get flowing(): $Fluid;
        getFlowing(): $Fluid;
        get source(): $Fluid;
        getSource(): $Fluid;
        canConvertToSource(arg0: $FluidState, arg1: $ServerLevel, arg2: $BlockPos_): boolean;
        getAmount(arg0: $FluidState): number;
        getFlowing(arg0: number, arg1: boolean): $FluidState;
        getFlow(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $FluidState): $Vec3;
        getHeight(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): number;
        getOwnHeight(arg0: $FluidState): number;
        getShape(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): $VoxelShape;
        getSource(arg0: boolean): $FluidState;
        tick(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $BlockState_, arg3: $FluidState): void;
    }

    export class $Fluid implements $IFluidExtension {
        static FLUID_STATE_REGISTRY: $IdMapper<$FluidState>;
        get bucket(): $Item;
        getBucket(): $Item;
        get fluidType(): $FluidType;
        getFluidType(): $FluidType;
        get pickupSound(): $Optional<$SoundEvent>;
        getPickupSound(): $Optional<$SoundEvent>;
        get stateDefinition(): $StateDefinition<$Fluid, $FluidState>;
        getStateDefinition(): $StateDefinition<$Fluid, $FluidState>;
        builtInRegistryHolder(): $Holder$Reference<$Fluid>;
        computeDefaultResource(arg0: $Function<$Fluid_, $FluidResource>): $FluidResource;
        defaultFluidState(): $FluidState;
        getAABB(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): $AABB;
        getAmount(arg0: $FluidState): number;
        getHeight(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): number;
        getOwnHeight(arg0: $FluidState): number;
        getShape(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): $VoxelShape;
        getTickDelay(arg0: $LevelReader): number;
        isSame(arg0: $Fluid_): boolean;
        isSource(arg0: $FluidState): boolean;
        is(arg0: $TagKey<$Fluid_>): boolean;
        toString(): string;
    }

    export class $FluidState extends $StateHolder implements $TypedInstance, $IFluidStateExtension {
        constructor(arg0: $Fluid_, arg1: $Property<any>[], arg2: $Comparable<any>[]);
        static AMOUNT_FULL: number;
        static AMOUNT_MAX: number;
        static CODEC: $Codec<$FluidState>;
        get amount(): number;
        getAmount(): number;
        get dripParticle(): $ParticleOptions;
        getDripParticle(): $ParticleOptions;
        get explosionResistance(): number;
        getExplosionResistance(): number;
        get ownHeight(): number;
        getOwnHeight(): number;
        get type(): $Fluid;
        getType(): $Fluid;
        get empty(): boolean;
        isEmpty(): boolean;
        get full(): boolean;
        isFull(): boolean;
        get randomlyTicking(): boolean;
        isRandomlyTicking(): boolean;
        get source(): boolean;
        isSource(): boolean;
        animateTick(arg0: $Level, arg1: $BlockPos_, arg2: $RandomSource): void;
        canBeReplacedWith(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Fluid_, arg3: $Direction_): boolean;
        createLegacyBlock(): $BlockState;
        entityInside(arg0: $Level, arg1: $BlockPos_, arg2: $Entity, arg3: $InsideBlockEffectApplier): void;
        getAABB(arg0: $BlockGetter, arg1: $BlockPos_): $AABB;
        getFlow(arg0: $BlockGetter, arg1: $BlockPos_): $Vec3;
        getHeight(arg0: $BlockGetter, arg1: $BlockPos_): number;
        getShape(arg0: $BlockGetter, arg1: $BlockPos_): $VoxelShape;
        isSourceOfType(arg0: $Fluid_): boolean;
        randomTick(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $RandomSource): void;
        shouldRenderBackwardUpFace(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        tick(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $BlockState_): void;
        typeHolder(): $Holder<$Fluid>;
    }

    export class $Fluids {
        constructor();
        static EMPTY: $Fluid;
        static FLOWING_LAVA: $FlowingFluid;
        static FLOWING_WATER: $FlowingFluid;
        static LAVA: $FlowingFluid;
        static WATER: $FlowingFluid;
    }

    export class $MapColor {
        static CLAY: $MapColor;
        static COLOR_BLACK: $MapColor;
        static COLOR_BLUE: $MapColor;
        static COLOR_BROWN: $MapColor;
        static COLOR_CYAN: $MapColor;
        static COLOR_GRAY: $MapColor;
        static COLOR_GREEN: $MapColor;
        static COLOR_LIGHT_BLUE: $MapColor;
        static COLOR_LIGHT_GRAY: $MapColor;
        static COLOR_LIGHT_GREEN: $MapColor;
        static COLOR_MAGENTA: $MapColor;
        static COLOR_ORANGE: $MapColor;
        static COLOR_PINK: $MapColor;
        static COLOR_PURPLE: $MapColor;
        static COLOR_RED: $MapColor;
        static COLOR_YELLOW: $MapColor;
        static CRIMSON_HYPHAE: $MapColor;
        static CRIMSON_NYLIUM: $MapColor;
        static CRIMSON_STEM: $MapColor;
        static DEEPSLATE: $MapColor;
        static DIAMOND: $MapColor;
        static DIRT: $MapColor;
        static EMERALD: $MapColor;
        static FIRE: $MapColor;
        static GLOW_LICHEN: $MapColor;
        static GOLD: $MapColor;
        static GRASS: $MapColor;
        static ICE: $MapColor;
        static LAPIS: $MapColor;
        static METAL: $MapColor;
        static NETHER: $MapColor;
        static NONE: $MapColor;
        static PLANT: $MapColor;
        static PODZOL: $MapColor;
        static QUARTZ: $MapColor;
        static RAW_IRON: $MapColor;
        static SAND: $MapColor;
        static SNOW: $MapColor;
        static STONE: $MapColor;
        static TERRACOTTA_BLACK: $MapColor;
        static TERRACOTTA_BLUE: $MapColor;
        static TERRACOTTA_BROWN: $MapColor;
        static TERRACOTTA_CYAN: $MapColor;
        static TERRACOTTA_GRAY: $MapColor;
        static TERRACOTTA_GREEN: $MapColor;
        static TERRACOTTA_LIGHT_BLUE: $MapColor;
        static TERRACOTTA_LIGHT_GRAY: $MapColor;
        static TERRACOTTA_LIGHT_GREEN: $MapColor;
        static TERRACOTTA_MAGENTA: $MapColor;
        static TERRACOTTA_ORANGE: $MapColor;
        static TERRACOTTA_PINK: $MapColor;
        static TERRACOTTA_PURPLE: $MapColor;
        static TERRACOTTA_RED: $MapColor;
        static TERRACOTTA_WHITE: $MapColor;
        static TERRACOTTA_YELLOW: $MapColor;
        static WARPED_HYPHAE: $MapColor;
        static WARPED_NYLIUM: $MapColor;
        static WARPED_STEM: $MapColor;
        static WARPED_WART_BLOCK: $MapColor;
        static WATER: $MapColor;
        static WOOD: $MapColor;
        static WOOL: $MapColor;
        col: number;
        id: number;
        static byId(arg0: number): $MapColor;
        static getColorFromPackedId(arg0: number): number;
        calculateARGBColor(arg0: $MapColor$Brightness_): number;
        getPackedId(arg0: $MapColor$Brightness_): number;
    }

    export class $MapColor$Brightness {
        static HIGH: $MapColor$Brightness;
        static LOW: $MapColor$Brightness;
        static LOWEST: $MapColor$Brightness;
        static NORMAL: $MapColor$Brightness;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MapColor$Brightness[];
        static valueOf(name: string): $MapColor$Brightness;
    }

    export class $PushReaction {
        static BLOCK: $PushReaction;
        static DESTROY: $PushReaction;
        static IGNORE: $PushReaction;
        static NORMAL: $PushReaction;
        static PUSH_ONLY: $PushReaction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PushReaction[];
        static valueOf(name: string): $PushReaction;
    }

    export type $Fluid_ = $Fluid | RegistryTypes.Fluid | $NekoId | string;
    export type $MapColor$Brightness_ = $MapColor$Brightness | "HIGH" | "LOW" | "LOWEST" | "NORMAL";
    export type $PushReaction_ = $PushReaction | "BLOCK" | "DESTROY" | "IGNORE" | "NORMAL" | "PUSH_ONLY";
}
