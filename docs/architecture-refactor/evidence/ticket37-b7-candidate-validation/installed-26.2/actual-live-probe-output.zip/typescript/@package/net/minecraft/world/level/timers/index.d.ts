import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $List, $Set } from "java:java/util";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";

declare module "java:net/minecraft/world/level/timers" {
    export interface $TimerCallback<T> {
        codec(): $MapCodec<$TimerCallback<T>>;
        handle(arg0: T, arg1: $TimerQueue<T>, arg2: number): void;
    }

    export class $TimerQueue<T> extends $SavedData {
        constructor();
        constructor(arg0: $TimerQueue$Packed<T>);
        static CODEC: $Codec<$TimerQueue<$MinecraftServer>>;
        static TYPE: $SavedDataType<$TimerQueue<$MinecraftServer>>;
        get eventsIds(): $Set<string>;
        getEventsIds(): $Set<string>;
        remove(arg0: string): number;
        schedule(arg0: string, arg1: number, arg2: $TimerCallback<T>): void;
        tick(arg0: T, arg1: number): void;
    }

    export class $TimerQueue$Event$Packed<T> extends $Record {
        constructor(triggerTime: number, id: string, callback: $TimerCallback<T>);
        static codec<T>(arg0: $Codec<$TimerCallback<T>>): $Codec<$TimerQueue$Event$Packed<T>>;
        callback(): $TimerCallback<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): string;
        toString(): string;
        triggerTime(): number;
    }

    export class $TimerQueue$Packed<T> extends $Record {
        constructor(events: $TimerQueue$Event$Packed<T>[]);
        static codec<T>(arg0: $Codec<$TimerCallback<T>>): $Codec<$TimerQueue$Packed<T>>;
        equals(arg0: object): boolean;
        events(): $List<$TimerQueue$Event$Packed<T>>;
        hashCode(): number;
        toString(): string;
    }

}
