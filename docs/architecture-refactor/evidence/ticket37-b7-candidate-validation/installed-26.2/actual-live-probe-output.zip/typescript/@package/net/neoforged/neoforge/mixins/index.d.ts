import { $Set } from "java:java/util";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";

declare module "java:net/neoforged/neoforge/mixins" {
    export interface $BlockEntityTypeAccessor {
        neoforge$setValidBlocks(arg0: $Block_[]): void;
    }

}
