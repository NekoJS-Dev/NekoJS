import { $ImmutableSet } from "java:com/google/common/collect";
import { $Codec, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Record, $String, $StringBuilder } from "java:java/lang";
import { $List, $Map, $Optional, $OptionalLong, $Set } from "java:java/util";
import { $Function, $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Holder, $HolderGetter, $HolderGetter$Provider, $HolderLookup, $HolderLookup$Provider, $Holder_, $Registry, $RegistryAccess, $RegistryAccess$Frozen } from "java:net/minecraft/core";
import { $BootstrapContext } from "java:net/minecraft/data/worldgen";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $KeyDispatchDataCodec, $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $ChunkPos, $Level, $LevelHeightAccessor } from "java:net/minecraft/world/level";
import { $Biome, $BiomeManager, $BiomeResolver, $Climate$ParameterPoint, $Climate$Sampler } from "java:net/minecraft/world/level/biome";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $ChunkAccess, $ChunkGenerator, $ProtoChunk } from "java:net/minecraft/world/level/chunk";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";
import { $DimensionType, $LevelStem } from "java:net/minecraft/world/level/dimension";
import { $Blender } from "java:net/minecraft/world/level/levelgen/blending";
import { $CarvingContext } from "java:net/minecraft/world/level/levelgen/carver";
import { $NormalNoise, $NormalNoise$NoiseParameters } from "java:net/minecraft/world/level/levelgen/synth";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";
import { $PrimaryLevelData$SpecialWorldProperty, $PrimaryLevelData$SpecialWorldProperty_ } from "java:net/minecraft/world/level/storage";

export * as blending from "java:net/minecraft/world/level/levelgen/blending";
export * as blockpredicates from "java:net/minecraft/world/level/levelgen/blockpredicates";
export * as carver from "java:net/minecraft/world/level/levelgen/carver";
export * as feature from "java:net/minecraft/world/level/levelgen/feature";
export * as heightproviders from "java:net/minecraft/world/level/levelgen/heightproviders";
export * as placement from "java:net/minecraft/world/level/levelgen/placement";
export * as structure from "java:net/minecraft/world/level/levelgen/structure";
export * as synth from "java:net/minecraft/world/level/levelgen/synth";

declare module "java:net/minecraft/world/level/levelgen" {
    export interface $Aquifer {
        computeSubstance(arg0: $DensityFunction$FunctionContext, arg1: number): $BlockState;
        createDisabled(arg0: $Aquifer$FluidPicker): $Aquifer;
        create(arg0: $NoiseChunk, arg1: $ChunkPos, arg2: $NoiseRouter, arg3: $PositionalRandomFactory, arg4: number, arg5: number, arg6: $Aquifer$FluidPicker): $Aquifer;
        shouldScheduleFluidUpdate(): boolean;
    }

    export interface $Aquifer$FluidPicker {
        computeFluid(arg0: number, arg1: number, arg2: number): $Aquifer$FluidStatus;
    }

    export class $Aquifer$FluidStatus extends $Record {
        constructor(fluidLevel: number, fluidType: $BlockState_);
        at(arg0: number): $BlockState;
        equals(arg0: object): boolean;
        fluidLevel(): number;
        fluidType(): $BlockState;
        hashCode(): number;
        toString(): string;
    }

    export class $BelowZeroRetrogen {
        static CODEC: $Codec<$BelowZeroRetrogen>;
        static UPGRADE_HEIGHT_ACCESSOR: $LevelHeightAccessor;
        static getBiomeResolver(arg0: $BiomeResolver, arg1: $ChunkAccess): $BiomeResolver;
        static replaceOldBedrock(arg0: $ProtoChunk): void;
        applyBedrockMask(arg0: $ProtoChunk): void;
        hasBedrockHoles(): boolean;
        hasBedrockHole(arg0: number, arg1: number): boolean;
        targetStatus(): $ChunkStatus;
    }

    export interface $DensityFunction {
        abs(): $DensityFunction;
        clamp(arg0: number, arg1: number): $DensityFunction;
        codec(): $KeyDispatchDataCodec<$DensityFunction>;
        compute(arg0: $DensityFunction$FunctionContext): number;
        cube(): $DensityFunction;
        fillArray(arg0: number[], arg1: $DensityFunction$ContextProvider): void;
        halfNegative(): $DensityFunction;
        invert(): $DensityFunction;
        mapAll(arg0: $DensityFunction$Visitor): $DensityFunction;
        mapChildren(arg0: $DensityFunction$Visitor): $DensityFunction;
        maxValue(): number;
        minValue(): number;
        quarterNegative(): $DensityFunction;
        square(): $DensityFunction;
        squeeze(): $DensityFunction;
        static CODEC: $Codec<$DensityFunction>;
    }

    export interface $DensityFunction$ContextProvider {
        fillAllDirectly(arg0: number[], arg1: $DensityFunction): void;
        forIndex(arg0: number): $DensityFunction$FunctionContext;
    }

    export interface $DensityFunction$FunctionContext {
        blockX(): number;
        blockY(): number;
        blockZ(): number;
    }

    export interface $DensityFunction$SimpleFunction extends $DensityFunction {
        fillArray(arg0: number[], arg1: $DensityFunction$ContextProvider): void;
        mapChildren(arg0: $DensityFunction$Visitor): $DensityFunction;
    }

    export interface $DensityFunction$Visitor {
        apply(arg0: $DensityFunction): $DensityFunction;
        visitNoise(arg0: $DensityFunction$NoiseHolder): $DensityFunction$NoiseHolder;
    }

    export interface $DensityFunctions$BeardifierOrMarker extends $DensityFunction$SimpleFunction {
        codec(): $KeyDispatchDataCodec<$DensityFunction>;
        static CODEC: $KeyDispatchDataCodec<$DensityFunction>;
    }

    export class $GenerationStep$Decoration {
        static FLUID_SPRINGS: $GenerationStep$Decoration;
        static LAKES: $GenerationStep$Decoration;
        static LOCAL_MODIFICATIONS: $GenerationStep$Decoration;
        static RAW_GENERATION: $GenerationStep$Decoration;
        static STRONGHOLDS: $GenerationStep$Decoration;
        static SURFACE_STRUCTURES: $GenerationStep$Decoration;
        static TOP_LAYER_MODIFICATION: $GenerationStep$Decoration;
        static UNDERGROUND_DECORATION: $GenerationStep$Decoration;
        static UNDERGROUND_ORES: $GenerationStep$Decoration;
        static UNDERGROUND_STRUCTURES: $GenerationStep$Decoration;
        static VEGETAL_DECORATION: $GenerationStep$Decoration;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GenerationStep$Decoration[];
        static valueOf(name: string): $GenerationStep$Decoration;
    }

    export class $Heightmap {
        constructor(arg0: $ChunkAccess, arg1: $Heightmap$Types_);
        get rawData(): number[];
        getRawData(): number[];
        static primeHeightmaps(arg0: $ChunkAccess, arg1: $Heightmap$Types_[]): void;
        getFirstAvailable(arg0: number, arg1: number): number;
        getHighestTaken(arg0: number, arg1: number): number;
        setRawData(arg0: $ChunkAccess, arg1: $Heightmap$Types_, arg2: number[]): void;
        update(arg0: number, arg1: number, arg2: number, arg3: $BlockState_): boolean;
    }

    export class $Heightmap$Types {
        static MOTION_BLOCKING: $Heightmap$Types;
        static MOTION_BLOCKING_NO_LEAVES: $Heightmap$Types;
        static OCEAN_FLOOR: $Heightmap$Types;
        static OCEAN_FLOOR_WG: $Heightmap$Types;
        static WORLD_SURFACE: $Heightmap$Types;
        static WORLD_SURFACE_WG: $Heightmap$Types;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Heightmap$Types[];
        static valueOf(name: string): $Heightmap$Types;
    }

    export class $LegacyRandomSource implements $BitRandomSource {
        constructor(arg0: number);
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextGaussian(): number;
        next(arg0: number): number;
    }

    export class $NoiseChunk implements $DensityFunction$FunctionContext, $DensityFunction$ContextProvider {
        constructor(arg0: number, arg1: $RandomState, arg2: number, arg3: number, arg4: $NoiseSettings, arg5: $DensityFunctions$BeardifierOrMarker, arg6: $NoiseGeneratorSettings, arg7: $Aquifer$FluidPicker, arg8: $Blender);
        static forChunk(arg0: $ChunkAccess, arg1: $RandomState, arg2: $DensityFunctions$BeardifierOrMarker, arg3: $NoiseGeneratorSettings, arg4: $Aquifer$FluidPicker, arg5: $Blender): $NoiseChunk;
        advanceCellX(arg0: number): void;
        aquifer(): $Aquifer;
        blockX(): number;
        blockY(): number;
        blockZ(): number;
        fillAllDirectly(arg0: number[], arg1: $DensityFunction): void;
        forIndex(arg0: number): $NoiseChunk;
        initializeForFirstCellX(): void;
        maxPreliminarySurfaceLevel(arg0: number, arg1: number, arg2: number, arg3: number): number;
        preliminarySurfaceLevel(arg0: number, arg1: number): number;
        selectCellYZ(arg0: number, arg1: number): void;
        stopInterpolation(): void;
        swapSlices(): void;
        updateForX(arg0: number, arg1: number): void;
        updateForY(arg0: number, arg1: number): void;
        updateForZ(arg0: number, arg1: number): void;
    }

    export class $NoiseGeneratorSettings extends $Record {
        constructor(noiseSettings: $NoiseSettings, defaultBlock: $BlockState_, defaultFluid: $BlockState_, noiseRouter: $NoiseRouter, surfaceRule: $SurfaceRules$RuleSource, spawnTarget: $Climate$ParameterPoint[], seaLevel: number, disableMobGeneration: boolean, aquifersEnabled: boolean, oreVeinsEnabled: boolean, useLegacyRandomSource: boolean);
        static AMPLIFIED: $ResourceKey<$NoiseGeneratorSettings>;
        static CAVES: $ResourceKey<$NoiseGeneratorSettings>;
        static CODEC: $Codec<$Holder<$NoiseGeneratorSettings>>;
        static DIRECT_CODEC: $Codec<$NoiseGeneratorSettings>;
        static END: $ResourceKey<$NoiseGeneratorSettings>;
        static FLOATING_ISLANDS: $ResourceKey<$NoiseGeneratorSettings>;
        static LARGE_BIOMES: $ResourceKey<$NoiseGeneratorSettings>;
        static NETHER: $ResourceKey<$NoiseGeneratorSettings>;
        static OVERWORLD: $ResourceKey<$NoiseGeneratorSettings>;
        get randomSource(): $WorldgenRandom$Algorithm;
        getRandomSource(): $WorldgenRandom$Algorithm;
        get aquifersEnabled(): boolean;
        isAquifersEnabled(): boolean;
        static bootstrap(arg0: $BootstrapContext<$NoiseGeneratorSettings>): void;
        static caves(arg0: $BootstrapContext<any>): $NoiseGeneratorSettings;
        static dummy(): $NoiseGeneratorSettings;
        static end(arg0: $BootstrapContext<any>): $NoiseGeneratorSettings;
        static floatingIslands(arg0: $BootstrapContext<any>): $NoiseGeneratorSettings;
        static nether(arg0: $BootstrapContext<any>): $NoiseGeneratorSettings;
        static overworld(arg0: $BootstrapContext<any>, arg1: boolean, arg2: boolean): $NoiseGeneratorSettings;
        aquifersEnabled(): boolean;
        defaultBlock(): $BlockState;
        defaultFluid(): $BlockState;
        disableMobGeneration(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        noiseRouter(): $NoiseRouter;
        noiseSettings(): $NoiseSettings;
        oreVeinsEnabled(): boolean;
        seaLevel(): number;
        spawnTarget(): $List<$Climate$ParameterPoint>;
        surfaceRule(): $SurfaceRules$RuleSource;
        toString(): string;
        useLegacyRandomSource(): boolean;
    }

    export class $NoiseRouter extends $Record {
        constructor(barrierNoise: $DensityFunction, fluidLevelFloodednessNoise: $DensityFunction, fluidLevelSpreadNoise: $DensityFunction, lavaNoise: $DensityFunction, temperature: $DensityFunction, vegetation: $DensityFunction, continents: $DensityFunction, erosion: $DensityFunction, depth: $DensityFunction, ridges: $DensityFunction, preliminarySurfaceLevel: $DensityFunction, finalDensity: $DensityFunction, veinToggle: $DensityFunction, veinRidged: $DensityFunction, veinGap: $DensityFunction);
        static CODEC: $Codec<$NoiseRouter>;
        barrierNoise(): $DensityFunction;
        continents(): $DensityFunction;
        depth(): $DensityFunction;
        equals(arg0: object): boolean;
        erosion(): $DensityFunction;
        finalDensity(): $DensityFunction;
        fluidLevelFloodednessNoise(): $DensityFunction;
        fluidLevelSpreadNoise(): $DensityFunction;
        hashCode(): number;
        lavaNoise(): $DensityFunction;
        mapAll(arg0: $DensityFunction$Visitor): $NoiseRouter;
        preliminarySurfaceLevel(): $DensityFunction;
        ridges(): $DensityFunction;
        temperature(): $DensityFunction;
        toString(): string;
        vegetation(): $DensityFunction;
        veinGap(): $DensityFunction;
        veinRidged(): $DensityFunction;
        veinToggle(): $DensityFunction;
    }

    export class $NoiseSettings extends $Record {
        constructor(minY: number, height: number, noiseSizeHorizontal: number, noiseSizeVertical: number);
        static CODEC: $Codec<$NoiseSettings>;
        get cellHeight(): number;
        getCellHeight(): number;
        get cellWidth(): number;
        getCellWidth(): number;
        static create(arg0: number, arg1: number, arg2: number, arg3: number): $NoiseSettings;
        clampToHeightAccessor(arg0: $LevelHeightAccessor): $NoiseSettings;
        equals(arg0: object): boolean;
        hashCode(): number;
        height(): number;
        minY(): number;
        noiseSizeHorizontal(): number;
        noiseSizeVertical(): number;
        toString(): string;
    }

    export interface $PositionalRandomFactory {
        at(arg0: number, arg1: number, arg2: number): $RandomSource;
        at(arg0: $BlockPos_): $RandomSource;
        fromHashOf(arg0: string): $RandomSource;
        fromHashOf(arg0: $Identifier_): $RandomSource;
        fromSeed(arg0: number): $RandomSource;
        parityConfigString(arg0: $StringBuilder): void;
    }

    export class $RandomState {
        static create(arg0: $HolderGetter$Provider, arg1: $ResourceKey<$NoiseGeneratorSettings>, arg2: number): $RandomState;
        static create(arg0: $NoiseGeneratorSettings, arg1: $HolderGetter<$NormalNoise$NoiseParameters>, arg2: number): $RandomState;
        aquiferRandom(): $PositionalRandomFactory;
        getOrCreateNoise(arg0: $ResourceKey<$NormalNoise$NoiseParameters>): $NormalNoise;
        getOrCreateRandomFactory(arg0: $Identifier_): $PositionalRandomFactory;
        oreRandom(): $PositionalRandomFactory;
        router(): $NoiseRouter;
        sampler(): $Climate$Sampler;
        surfaceSystem(): $SurfaceSystem;
    }

    export class $RandomSupport$Seed128bit extends $Record {
        constructor(seedLo: number, seedHi: number);
        equals(arg0: object): boolean;
        hashCode(): number;
        mixed(): $RandomSupport$Seed128bit;
        seedHi(): number;
        seedLo(): number;
        toString(): string;
        xor(arg0: number, arg1: number): $RandomSupport$Seed128bit;
        xor(arg0: $RandomSupport$Seed128bit): $RandomSupport$Seed128bit;
    }

    export interface $SurfaceRules$RuleSource extends $Function {
        bootstrap(arg0: $Registry<$MapCodec<$SurfaceRules$RuleSource>>): $MapCodec<$SurfaceRules$RuleSource>;
        codec(): $MapCodec<$SurfaceRules$RuleSource>;
        static CODEC: $Codec<$SurfaceRules$RuleSource>;
    }

    export class $SurfaceSystem {
        constructor(arg0: $RandomState, arg1: $BlockState_, arg2: number, arg3: $PositionalRandomFactory);
        get seaLevel(): number;
        getSeaLevel(): number;
        buildSurface(arg0: $RandomState, arg1: $BiomeManager, arg2: boolean, arg3: $WorldGenerationContext, arg4: $ChunkAccess, arg5: $NoiseChunk, arg6: $SurfaceRules$RuleSource, arg7: $Holder<$Biome>[]): void;
        topMaterial(arg0: $SurfaceRules$RuleSource, arg1: $CarvingContext, arg2: $Function<$BlockPos_, $Holder<$Biome>>, arg3: $ChunkAccess, arg4: $NoiseChunk, arg5: $BlockPos_, arg6: boolean): $Optional<$BlockState>;
    }

    export class $WorldDimensions extends $Record {
        constructor(dimensions: { [key: $ResourceKey<$LevelStem>]: $LevelStem });
        constructor(arg0: $Registry<$LevelStem>);
        static CODEC: $MapCodec<$WorldDimensions>;
        get debug(): boolean;
        isDebug(): boolean;
        static keysInOrder(arg0: $ResourceKey<$LevelStem>[]): $Stream<$ResourceKey<$LevelStem>>;
        static withOverworld(arg0: { [key: $ResourceKey<$LevelStem>]: $LevelStem }, arg1: $Holder<$DimensionType>, arg2: $ChunkGenerator): $Map<$ResourceKey<$LevelStem>, $LevelStem>;
        static withOverworld(arg0: $HolderLookup<$DimensionType>, arg1: { [key: $ResourceKey<$LevelStem>]: $LevelStem }, arg2: $ChunkGenerator): $Map<$ResourceKey<$LevelStem>, $LevelStem>;
        bake(arg0: $Registry<$LevelStem>): $WorldDimensions$Complete;
        dimensions(): $Map<$ResourceKey<$LevelStem>, $LevelStem>;
        equals(arg0: object): boolean;
        get(arg0: $ResourceKey<$LevelStem>): $Optional<$LevelStem>;
        hashCode(): number;
        levels(): $ImmutableSet<$ResourceKey<$Level>>;
        overworld(): $ChunkGenerator;
        replaceOverworldGenerator(arg0: $HolderLookup$Provider, arg1: $ChunkGenerator): $WorldDimensions;
        toString(): string;
    }

    export class $WorldDimensions$Complete extends $Record {
        constructor(dimensions: $Registry<$LevelStem>, specialWorldProperty: $PrimaryLevelData$SpecialWorldProperty_);
        dimensionsRegistryAccess(): $RegistryAccess$Frozen;
        dimensions(): $Registry<$LevelStem>;
        equals(arg0: object): boolean;
        hashCode(): number;
        lifecycle(): $Lifecycle;
        specialWorldProperty(): $PrimaryLevelData$SpecialWorldProperty;
        toString(): string;
    }

    export class $WorldGenSettings extends $SavedData {
        constructor(arg0: $WorldOptions, arg1: $WorldDimensions);
        static CODEC: $Codec<$WorldGenSettings>;
        static TYPE: $SavedDataType<$WorldGenSettings>;
        static of(arg0: $WorldOptions, arg1: $RegistryAccess): $WorldGenSettings;
        dimensions(): $WorldDimensions;
        hashCode(): number;
        options(): $WorldOptions;
        toString(): string;
    }

    export class $WorldGenerationContext {
        constructor(arg0: $ChunkGenerator, arg1: $LevelHeightAccessor);
        get genDepth(): number;
        getGenDepth(): number;
        get minGenY(): number;
        getMinGenY(): number;
    }

    export class $WorldOptions {
        constructor(arg0: number, arg1: boolean, arg2: boolean);
        static CODEC: $MapCodec<$WorldOptions>;
        static DEMO_OPTIONS: $WorldOptions;
        get oldCustomizedWorld(): boolean;
        isOldCustomizedWorld(): boolean;
        static defaultWithRandomSeed(): $WorldOptions;
        static parseSeed(arg0: string): $OptionalLong;
        static randomSeed(): number;
        static testWorldWithRandomSeed(): $WorldOptions;
        generateBonusChest(): boolean;
        generateStructures(): boolean;
        seed(): number;
        withBonusChest(arg0: boolean): $WorldOptions;
        withSeed(arg0: $OptionalLong): $WorldOptions;
        withStructures(arg0: boolean): $WorldOptions;
    }

    export class $WorldgenRandom extends $LegacyRandomSource {
        constructor(arg0: $RandomSource);
        get count(): number;
        getCount(): number;
        static seedSlimeChunk(arg0: number, arg1: number, arg2: number, arg3: number): $RandomSource;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        next(arg0: number): number;
        setDecorationSeed(arg0: number, arg1: number, arg2: number): number;
        setFeatureSeed(arg0: number, arg1: number, arg2: number): void;
        setLargeFeatureSeed(arg0: number, arg1: number, arg2: number): void;
        setLargeFeatureWithSalt(arg0: number, arg1: number, arg2: number, arg3: number): void;
    }

    export class $WorldgenRandom$Algorithm {
        static LEGACY: $WorldgenRandom$Algorithm;
        static XOROSHIRO: $WorldgenRandom$Algorithm;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $WorldgenRandom$Algorithm[];
        static valueOf(name: string): $WorldgenRandom$Algorithm;
    }

    export class $XoroshiroRandomSource implements $RandomSource {
        constructor(arg0: number);
        constructor(arg0: number, arg1: number);
        constructor(arg0: $RandomSupport$Seed128bit);
        static CODEC: $Codec<$XoroshiroRandomSource>;
        consumeCount(arg0: number): void;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextGaussian(): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(): number;
    }

    export type $GenerationStep$Decoration_ = $GenerationStep$Decoration | "FLUID_SPRINGS" | "LAKES" | "LOCAL_MODIFICATIONS" | "RAW_GENERATION" | "STRONGHOLDS" | "SURFACE_STRUCTURES" | "TOP_LAYER_MODIFICATION" | "UNDERGROUND_DECORATION" | "UNDERGROUND_ORES" | "UNDERGROUND_STRUCTURES" | "VEGETAL_DECORATION";
    export type $Heightmap$Types_ = $Heightmap$Types | "MOTION_BLOCKING" | "MOTION_BLOCKING_NO_LEAVES" | "OCEAN_FLOOR" | "OCEAN_FLOOR_WG" | "WORLD_SURFACE" | "WORLD_SURFACE_WG";
    export type $WorldgenRandom$Algorithm_ = $WorldgenRandom$Algorithm | "LEGACY" | "XOROSHIRO";
}
