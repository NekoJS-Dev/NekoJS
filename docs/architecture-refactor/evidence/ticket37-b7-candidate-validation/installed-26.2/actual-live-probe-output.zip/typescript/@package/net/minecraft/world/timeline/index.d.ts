import { $Codec } from "java:com/mojang/serialization";
import { $Exception, $Integer } from "java:java/lang";
import { $Map, $Optional, $Set } from "java:java/util";
import { $BiConsumer, $Consumer } from "java:java/util/function";
import { $Holder, $Holder_, $Registry } from "java:net/minecraft/core";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $KeyframeTrack$Builder } from "java:net/minecraft/util";
import { $EnvironmentAttribute, $EnvironmentAttributeLayer$TimeBased } from "java:net/minecraft/world/attribute";
import { $AttributeModifier } from "java:net/minecraft/world/attribute/modifier";
import { $ClockManager, $ClockTimeMarker, $WorldClock } from "java:net/minecraft/world/clock";

declare module "java:net/minecraft/world/timeline" {
    export class $AttributeTrackSampler<Value, Argument> implements $EnvironmentAttributeLayer$TimeBased {
        constructor(arg0: $Holder<$WorldClock>, arg1: $Optional<number>, arg2: $AttributeModifier<Value, Argument>, arg3: $KeyframeTrack<Argument>, arg4: $LerpFunction<Argument>, arg5: $ClockManager);
        applyTimeBased(arg0: Value, arg1: number): Value;
    }

    export class $Timeline {
        static CODEC: $Codec<$Holder<$Timeline>>;
        static DIRECT_CODEC: $Codec<$Timeline>;
        static NETWORK_CODEC: $Codec<$Timeline>;
        static builder(arg0: $Holder<$WorldClock>): $Timeline$Builder;
        static validateRegistry(arg0: $Registry<$Timeline>, arg1: { [key: $ResourceKey<any>]: $Exception }): void;
        attributes(): $Set<$EnvironmentAttribute<any>>;
        clock(): $Holder<$WorldClock>;
        createTrackSampler<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $ClockManager): $AttributeTrackSampler<Value, any>;
        getCurrentTicks(arg0: $ClockManager): number;
        getPeriodCount(arg0: $ClockManager): number;
        getTotalTicks(arg0: $ClockManager): number;
        periodTicks(): $Optional<number>;
        registerTimeMarkers(arg0: $BiConsumer<$ResourceKey<$ClockTimeMarker>, $ClockTimeMarker>): void;
    }

    export class $Timeline$Builder {
        addModifierTrack<Value, Argument>(arg0: $EnvironmentAttribute<Value>, arg1: $AttributeModifier<Value, Argument>, arg2: $Consumer<$KeyframeTrack$Builder<Argument>>): $Timeline$Builder;
        addTimeMarker(arg0: $ResourceKey<$ClockTimeMarker>, arg1: number, arg2: boolean): $Timeline$Builder;
        addTimeMarker(arg0: $ResourceKey<$ClockTimeMarker>, arg1: number): $Timeline$Builder;
        addTrack<Value>(arg0: $EnvironmentAttribute<Value>, arg1: $Consumer<$KeyframeTrack$Builder<Value>>): $Timeline$Builder;
        build(): $Timeline;
    }

}
