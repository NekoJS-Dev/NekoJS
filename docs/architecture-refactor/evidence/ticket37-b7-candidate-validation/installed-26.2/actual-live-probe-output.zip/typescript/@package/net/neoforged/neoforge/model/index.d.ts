export * as data from "java:net/neoforged/neoforge/model/data";

