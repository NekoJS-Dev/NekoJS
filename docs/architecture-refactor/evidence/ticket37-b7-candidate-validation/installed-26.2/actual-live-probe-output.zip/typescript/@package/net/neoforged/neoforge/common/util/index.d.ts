import { $String } from "java:java/lang";
import { $Set } from "java:java/util";
import { $Supplier } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $Level, $LevelAccessor } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $ValueInput, $ValueOutput } from "java:net/minecraft/world/level/storage";

declare module "java:net/neoforged/neoforge/common/util" {
    export interface $BlockRelocability {
        isRelocatable(arg0: $BlockPos_[]): boolean;
    }

    export class $BlockSnapshot {
        get currentState(): $BlockState;
        getCurrentState(): $BlockState;
        get dimension(): $ResourceKey<$Level>;
        getDimension(): $ResourceKey<$Level>;
        get flags(): number;
        getFlags(): number;
        get level(): $LevelAccessor;
        getLevel(): $LevelAccessor;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
        get tag(): $CompoundTag;
        getTag(): $CompoundTag;
        static create(arg0: $ResourceKey<$Level>, arg1: $LevelAccessor, arg2: $BlockPos_, arg3: number): $BlockSnapshot;
        static create(arg0: $ResourceKey<$Level>, arg1: $LevelAccessor, arg2: $BlockPos_): $BlockSnapshot;
        equals(arg0: object): boolean;
        hashCode(): number;
        recreateBlockEntity(arg0: $HolderLookup$Provider): $BlockEntity;
        restoreBlockEntity(arg0: $LevelAccessor, arg1: $BlockPos_): boolean;
        restoreToLocation(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: number): boolean;
        restore(arg0: number): boolean;
        restore(): boolean;
        toString(): string;
    }

    export class $Lazy<T> implements $Supplier {
        static of<T>(arg0: $Supplier<T>): $Lazy<T>;
        get(): T;
        invalidate(): void;
    }

    export interface $ValueIOSerializable {
        deserialize(arg0: $ValueInput): void;
        serialize(arg0: $ValueOutput): void;
    }

}
