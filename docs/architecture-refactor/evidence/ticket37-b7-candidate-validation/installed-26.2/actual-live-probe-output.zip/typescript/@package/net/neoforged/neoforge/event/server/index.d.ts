import { $MinecraftServer } from "java:net/minecraft/server";
import { $Event } from "java:net/neoforged/bus/api";

declare module "java:net/neoforged/neoforge/event/server" {
    export class $ServerAboutToStartEvent extends $ServerLifecycleEvent {
        constructor(arg0: $MinecraftServer);
    }

    export class $ServerLifecycleEvent extends $Event {
        constructor(arg0: $MinecraftServer);
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
    }

    export class $ServerStartedEvent extends $ServerLifecycleEvent {
        constructor(arg0: $MinecraftServer);
    }

    export class $ServerStartingEvent extends $ServerLifecycleEvent {
        constructor(arg0: $MinecraftServer);
    }

    export class $ServerStoppedEvent extends $ServerLifecycleEvent {
        constructor(arg0: $MinecraftServer);
    }

    export class $ServerStoppingEvent extends $ServerLifecycleEvent {
        constructor(arg0: $MinecraftServer);
    }

}
