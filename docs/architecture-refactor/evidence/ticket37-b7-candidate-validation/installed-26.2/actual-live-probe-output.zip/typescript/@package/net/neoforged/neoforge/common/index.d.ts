import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $String } from "java:java/lang";
import { $Collection } from "java:java/util";
import { $BiFunction, $Supplier, $UnaryOperator } from "java:java/util/function";
import { $DataComponentGetter, $DataComponentHolder, $DataComponentMap, $DataComponentPatch, $DataComponentType } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";

export * as brewing from "java:net/neoforged/neoforge/common/brewing";
export * as conditions from "java:net/neoforged/neoforge/common/conditions";
export * as crafting from "java:net/neoforged/neoforge/common/crafting";
export * as damagesource from "java:net/neoforged/neoforge/common/damagesource";
export * as enums from "java:net/neoforged/neoforge/common/enums";
export * as extensions from "java:net/neoforged/neoforge/common/extensions";
export * as util from "java:net/neoforged/neoforge/common/util";
export * as world from "java:net/neoforged/neoforge/common/world";

declare module "java:net/neoforged/neoforge/common" {
    export class $ItemAbility {
        static CODEC: $Codec<$ItemAbility>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ItemAbility>;
        static getActions(): $Collection<$ItemAbility>;
        static get(arg0: string): $ItemAbility;
        name(): string;
        toString(): string;
    }

    export interface $MutableDataComponentHolder extends $DataComponentHolder {
        applyComponents(arg0: $DataComponentMap): void;
        applyComponents(arg0: $DataComponentPatch): void;
        copyFrom<T>(arg0: $Supplier<$DataComponentType<T>>, arg1: $DataComponentGetter): void;
        copyFrom(arg0: $DataComponentHolder, arg1?: $Supplier<$DataComponentType<any>>[]): void;
        copyFrom(arg0: $DataComponentHolder, arg1?: $DataComponentType<any>[]): void;
        copyFrom<T>(arg0: $DataComponentType<T>, arg1: $DataComponentGetter): void;
        remove<T>(arg0: $Supplier<$DataComponentType<T>>): T;
        remove<T>(arg0: $DataComponentType<T>): T;
        set<T>(arg0: $Supplier<$DataComponentType<T>>, arg1: T): T;
        set<T>(arg0: $DataComponentType<T>, arg1: T): T;
        update<T, U>(arg0: $Supplier<$DataComponentType<T>>, arg1: T, arg2: U, arg3: $BiFunction<T, U, T>): T;
        update<T>(arg0: $Supplier<$DataComponentType<T>>, arg1: T, arg2: $UnaryOperator<T>): T;
        update<T, U>(arg0: $DataComponentType<T>, arg1: T, arg2: U, arg3: $BiFunction<T, U, T>): T;
        update<T>(arg0: $DataComponentType<T>, arg1: T, arg2: $UnaryOperator<T>): T;
    }

    export class $SoundAction {
        static get(arg0: string): $SoundAction;
        name(): string;
        toString(): string;
    }

}
