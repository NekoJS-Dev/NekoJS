declare module "java:net/minecraft/world/inventory/tooltip" {
    export interface $TooltipComponent {
    }

}
