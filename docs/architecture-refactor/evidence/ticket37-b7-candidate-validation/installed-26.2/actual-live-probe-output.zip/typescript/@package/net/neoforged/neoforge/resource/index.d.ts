import { $String } from "java:java/lang";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $PreparableReloadListener } from "java:net/minecraft/server/packs/resources";
import { $ICondition$IContext } from "java:net/neoforged/neoforge/common/conditions";

declare module "java:net/neoforged/neoforge/resource" {
    export class $ContextAwareReloadListener implements $PreparableReloadListener {
        constructor();
        injectContext(arg0: $ICondition$IContext, arg1: $HolderLookup$Provider): void;
    }

    export class $ListenerKey<T extends $PreparableReloadListener> {
        get listenerId(): $Identifier;
        getListenerId(): $Identifier;
        static create<T>(arg0: $Identifier_): $ListenerKey<T>;
        toString(): string;
    }

}
