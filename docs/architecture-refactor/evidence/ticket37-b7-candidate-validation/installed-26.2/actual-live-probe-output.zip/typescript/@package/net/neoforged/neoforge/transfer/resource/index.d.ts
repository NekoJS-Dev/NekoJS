import { $Predicate, $Supplier } from "java:java/util/function";
import { $Holder, $Holder_, $TypedInstance } from "java:net/minecraft/core";
import { $DataComponentHolder, $DataComponentPatch, $DataComponentType } from "java:net/minecraft/core/component";

declare module "java:net/neoforged/neoforge/transfer/resource" {
    export interface $DataComponentHolderResource<T> extends $RegisteredResource, $DataComponentHolder {
        getComponentsPatch(): $DataComponentPatch;
        isComponentsPatchEmpty(): boolean;
        withMergedPatch(arg0: $DataComponentPatch): $DataComponentHolderResource<T>;
        without(arg0: $Supplier<$DataComponentType<any>>): $DataComponentHolderResource<T>;
        without(arg0: $DataComponentType<any>): $DataComponentHolderResource<T>;
        with<D>(arg0: $Supplier<$DataComponentType<D>>, arg1: D): $DataComponentHolderResource<T>;
        with<D>(arg0: $DataComponentType<D>, arg1: D): $DataComponentHolderResource<T>;
    }

    export interface $RegisteredResource<T> extends $Resource, $TypedInstance {
        is(arg0: $Predicate<$Holder<T>>): boolean;
        value(): T;
    }

    export interface $Resource {
        isEmpty(): boolean;
    }

}
