import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Byte, $Enum, $Record, $String } from "java:java/lang";
import { $List, $Map } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $HolderSet, $Holder_, $RegistryAccess } from "java:net/minecraft/core";
import { $ListTag } from "java:net/minecraft/nbt";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientboundLevelChunkWithLightPacket } from "java:net/minecraft/network/protocol/game";
import { $Biome, $Biome$ClimateSettings, $BiomeGenerationSettings, $BiomeSpecialEffects, $MobSpawnSettings } from "java:net/minecraft/world/level/biome";
import { $Structure, $Structure$StructureSettings } from "java:net/minecraft/world/level/levelgen/structure";

export * as chunk from "java:net/neoforged/neoforge/common/world/chunk";

declare module "java:net/neoforged/neoforge/common/world" {
    export interface $AuxiliaryLightManager {
        getLightAt(arg0: $BlockPos_): number;
        removeLightAt(arg0: $BlockPos_): void;
        setLightAt(arg0: $BlockPos_, arg1: number): void;
    }

    export interface $BiomeModifier {
        codec(): $MapCodec<$BiomeModifier>;
        modify(arg0: $Holder<$Biome>, arg1: $BiomeModifier$Phase_, arg2: $ModifiableBiomeInfo$BiomeInfo$Builder): void;
        static DIRECT_CODEC: $Codec<$BiomeModifier>;
        static LIST_CODEC: $Codec<$HolderSet<$BiomeModifier>>;
        static REFERENCE_CODEC: $Codec<$Holder<$BiomeModifier>>;
    }

    export class $BiomeModifier$Phase {
        static ADD: $BiomeModifier$Phase;
        static AFTER_EVERYTHING: $BiomeModifier$Phase;
        static BEFORE_EVERYTHING: $BiomeModifier$Phase;
        static MODIFY: $BiomeModifier$Phase;
        static REMOVE: $BiomeModifier$Phase;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BiomeModifier$Phase[];
        static valueOf(name: string): $BiomeModifier$Phase;
    }

    export class $LevelChunkAuxiliaryLightManager implements $AuxiliaryLightManager {
        constructor(arg0: $LevelChunk);
        static LIGHT_NBT_KEY: string;
        deserializeNBT(arg0: $ListTag): void;
        getLightAt(arg0: $BlockPos_): number;
        handleLightDataSync(arg0: { [key: $BlockPos_]: number }): void;
        sendLightDataTo(arg0: $ClientboundLevelChunkWithLightPacket): $Packet<any>;
        serializeNBT(): $ListTag;
        setLightAt(arg0: $BlockPos_, arg1: number): void;
    }

    export class $ModifiableBiomeInfo {
        constructor(arg0: $ModifiableBiomeInfo$BiomeInfo);
        get modifiedBiomeInfo(): $ModifiableBiomeInfo$BiomeInfo;
        getModifiedBiomeInfo(): $ModifiableBiomeInfo$BiomeInfo;
        get originalBiomeInfo(): $ModifiableBiomeInfo$BiomeInfo;
        getOriginalBiomeInfo(): $ModifiableBiomeInfo$BiomeInfo;
        applyBiomeModifiers(arg0: $Holder<$Biome>, arg1: $BiomeModifier[], arg2: $RegistryAccess): boolean;
        get(): $ModifiableBiomeInfo$BiomeInfo;
    }

    export class $ModifiableBiomeInfo$BiomeInfo extends $Record {
        constructor(climateSettings: $Biome$ClimateSettings, effects: $BiomeSpecialEffects, generationSettings: $BiomeGenerationSettings, mobSpawnSettings: $MobSpawnSettings);
        climateSettings(): $Biome$ClimateSettings;
        effects(): $BiomeSpecialEffects;
        equals(arg0: object): boolean;
        generationSettings(): $BiomeGenerationSettings;
        hashCode(): number;
        mobSpawnSettings(): $MobSpawnSettings;
        toString(): string;
    }

    export class $ModifiableBiomeInfo$BiomeInfo$Builder {
        get climateSettings(): $ClimateSettingsBuilder;
        getClimateSettings(): $ClimateSettingsBuilder;
        get generationSettings(): $BiomeGenerationSettingsBuilder;
        getGenerationSettings(): $BiomeGenerationSettingsBuilder;
        get mobSpawnSettings(): $MobSpawnSettingsBuilder;
        getMobSpawnSettings(): $MobSpawnSettingsBuilder;
        get specialEffects(): $BiomeSpecialEffectsBuilder;
        getSpecialEffects(): $BiomeSpecialEffectsBuilder;
        static copyOf(arg0: $ModifiableBiomeInfo$BiomeInfo): $ModifiableBiomeInfo$BiomeInfo$Builder;
        build(): $ModifiableBiomeInfo$BiomeInfo;
    }

    export class $ModifiableStructureInfo {
        constructor(arg0: $ModifiableStructureInfo$StructureInfo);
        get modifiedStructureInfo(): $ModifiableStructureInfo$StructureInfo;
        getModifiedStructureInfo(): $ModifiableStructureInfo$StructureInfo;
        get originalStructureInfo(): $ModifiableStructureInfo$StructureInfo;
        getOriginalStructureInfo(): $ModifiableStructureInfo$StructureInfo;
        applyStructureModifiers(arg0: $Holder<$Structure>, arg1: $StructureModifier[]): void;
        get(): $ModifiableStructureInfo$StructureInfo;
    }

    export class $ModifiableStructureInfo$StructureInfo extends $Record {
        constructor(structureSettings: $Structure$StructureSettings);
        equals(arg0: object): boolean;
        hashCode(): number;
        structureSettings(): $Structure$StructureSettings;
        toString(): string;
    }

    export class $ModifiableStructureInfo$StructureInfo$Builder {
        get structureSettings(): $StructureSettingsBuilder;
        getStructureSettings(): $StructureSettingsBuilder;
        static copyOf(arg0: $ModifiableStructureInfo$StructureInfo): $ModifiableStructureInfo$StructureInfo$Builder;
        build(): $ModifiableStructureInfo$StructureInfo;
    }

    export interface $StructureModifier {
        codec(): $MapCodec<$StructureModifier>;
        modify(arg0: $Holder<$Structure>, arg1: $StructureModifier$Phase_, arg2: $ModifiableStructureInfo$StructureInfo$Builder): void;
        static DIRECT_CODEC: $Codec<$StructureModifier>;
        static LIST_CODEC: $Codec<$HolderSet<$StructureModifier>>;
        static REFERENCE_CODEC: $Codec<$Holder<$StructureModifier>>;
    }

    export class $StructureModifier$Phase {
        static ADD: $StructureModifier$Phase;
        static AFTER_EVERYTHING: $StructureModifier$Phase;
        static BEFORE_EVERYTHING: $StructureModifier$Phase;
        static MODIFY: $StructureModifier$Phase;
        static REMOVE: $StructureModifier$Phase;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StructureModifier$Phase[];
        static valueOf(name: string): $StructureModifier$Phase;
    }

    export type $BiomeModifier$Phase_ = $BiomeModifier$Phase | "ADD" | "AFTER_EVERYTHING" | "BEFORE_EVERYTHING" | "MODIFY" | "REMOVE";
    export type $StructureModifier$Phase_ = $StructureModifier$Phase | "ADD" | "AFTER_EVERYTHING" | "BEFORE_EVERYTHING" | "MODIFY" | "REMOVE";
}
