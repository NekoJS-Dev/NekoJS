export * as enumextension from "java:net/neoforged/fml/common/asm/enumextension";

