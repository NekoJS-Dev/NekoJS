import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Inventory } from "java:net/minecraft/world/entity/player";
import { $MenuType$MenuSupplier } from "java:net/minecraft/world/inventory";

export * as connection from "java:net/neoforged/neoforge/network/connection";

declare module "java:net/neoforged/neoforge/network" {
    export interface $IContainerFactory<T extends $AbstractContainerMenu> extends $MenuType$MenuSupplier {
        create(arg0: number, arg1: $Inventory, arg2: $RegistryFriendlyByteBuf): T;
        create(arg0: number, arg1: $Inventory): T;
    }

}
