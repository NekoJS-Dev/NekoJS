import { $OctahedralGroup, $OctahedralGroup_ } from "java:com/mojang/math";
import { $DoubleList } from "java:it/unimi/dsi/fastutil/doubles";
import { $String } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $AxisCycle, $AxisCycle_, $BlockPos, $BlockPos_, $Direction, $Direction$Axis, $Direction$Axis_, $Direction_, $Vec3i } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Item, $Item_ } from "java:net/minecraft/world/item";
import { $CollisionGetter } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $FluidState } from "java:net/minecraft/world/level/material";
import { $AABB, $BlockHitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/phys/shapes" {
    export interface $CollisionContext {
        alwaysCollideWithFluid(): boolean;
        canStandOnFluid(arg0: $FluidState, arg1: $FluidState): boolean;
        emptyWithFluidCollisions(): $CollisionContext;
        empty(): $CollisionContext;
        getCollisionShape(arg0: $BlockState_, arg1: $CollisionGetter, arg2: $BlockPos_): $VoxelShape;
        isAbove(arg0: $VoxelShape, arg1: $BlockPos_, arg2: boolean): boolean;
        isDescending(): boolean;
        isHoldingItem(arg0: $Item_): boolean;
        isPlacement(): boolean;
        of(arg0: $Entity, arg1: boolean): $CollisionContext;
        of(arg0: $Entity): $CollisionContext;
        placementContext(arg0: $Player): $CollisionContext;
        positionContext(arg0: number): $CollisionContext;
        withPosition(arg0: $Entity, arg1: number): $CollisionContext;
    }

    export class $DiscreteVoxelShape {
        get xSize(): number;
        getXSize(): number;
        get ySize(): number;
        getYSize(): number;
        get zSize(): number;
        getZSize(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        fill(arg0: number, arg1: number, arg2: number): void;
        firstFull(arg0: $Direction$Axis_, arg1: number, arg2: number): number;
        firstFull(arg0: $Direction$Axis_): number;
        forAllBoxes(arg0: $DiscreteVoxelShape$IntLineConsumer, arg1: boolean): void;
        forAllEdges(arg0: $DiscreteVoxelShape$IntLineConsumer, arg1: boolean): void;
        forAllFaces(arg0: $DiscreteVoxelShape$IntFaceConsumer): void;
        getSize(arg0: $Direction$Axis_): number;
        isFullWide(arg0: number, arg1: number, arg2: number): boolean;
        isFullWide(arg0: $AxisCycle_, arg1: number, arg2: number, arg3: number): boolean;
        isFull(arg0: number, arg1: number, arg2: number): boolean;
        isFull(arg0: $AxisCycle_, arg1: number, arg2: number, arg3: number): boolean;
        lastFull(arg0: $Direction$Axis_, arg1: number, arg2: number): number;
        lastFull(arg0: $Direction$Axis_): number;
        rotate(arg0: $OctahedralGroup_): $DiscreteVoxelShape;
    }

    export interface $DiscreteVoxelShape$IntFaceConsumer {
        consume(arg0: $Direction_, arg1: number, arg2: number, arg3: number): void;
    }

    export interface $DiscreteVoxelShape$IntLineConsumer {
        consume(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): void;
    }

    export interface $Shapes$DoubleLineConsumer {
        consume(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): void;
    }

    export class $VoxelShape {
        get empty(): boolean;
        isEmpty(): boolean;
        bounds(): $AABB;
        clip(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_): $BlockHitResult;
        closestPointTo(arg0: $Vec3_): $Optional<$Vec3>;
        collide(arg0: $Direction$Axis_, arg1: $AABB, arg2: number): number;
        equals(arg0: object): boolean;
        forAllBoxes(arg0: $Shapes$DoubleLineConsumer): void;
        forAllEdges(arg0: $Shapes$DoubleLineConsumer): void;
        getCoords(arg0: $Direction$Axis_): $DoubleList;
        getFaceShape(arg0: $Direction_): $VoxelShape;
        max(arg0: $Direction$Axis_, arg1: number, arg2: number): number;
        max(arg0: $Direction$Axis_): number;
        min(arg0: $Direction$Axis_, arg1: number, arg2: number): number;
        min(arg0: $Direction$Axis_): number;
        move(arg0: number, arg1: number, arg2: number): $VoxelShape;
        move(arg0: $Vec3i): $VoxelShape;
        move(arg0: $Vec3_): $VoxelShape;
        optimize(): $VoxelShape;
        singleEncompassing(): $VoxelShape;
        toAabbs(): $List<$AABB>;
        toString(): string;
    }

}
