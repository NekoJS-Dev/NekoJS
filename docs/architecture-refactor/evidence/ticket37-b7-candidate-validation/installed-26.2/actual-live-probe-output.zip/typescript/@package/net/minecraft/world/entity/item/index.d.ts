import { $UUID } from "java:java/util";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $SlotAccess, $TraceableEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Explosion } from "java:net/minecraft/world/level";
import { $TeleportTransition } from "java:net/minecraft/world/level/portal";

declare module "java:net/minecraft/world/entity/item" {
    export class $ItemEntity extends $Entity implements $TraceableEntity {
        constructor(arg0: $EntityType<$ItemEntity>, arg1: $Level);
        constructor(arg0: $Level, arg1: number, arg2: number, arg3: number, arg4: $ItemStack_);
        constructor(arg0: $Level, arg1: number, arg2: number, arg3: number, arg4: $ItemStack_, arg5: number, arg6: number, arg7: number);
        static DEFAULT_HEALTH: number;
        static EYE_HEIGHT: number;
        static LIFETIME: number;
        age: number;
        bobOffs: number;
        lifespan: number;
        get age(): number;
        getAge(): number;
        get blockPosBelowThatAffectsMyMovement(): $BlockPos;
        getBlockPosBelowThatAffectsMyMovement(): $BlockPos;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        set item(value: $ItemStack_);
        get name(): $Component;
        getName(): $Component;
        get owner(): $Entity;
        getOwner(): $Entity;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get target(): $UUID;
        getTarget(): $UUID;
        set target(value: string);
        get visualRotationYInDegrees(): number;
        getVisualRotationYInDegrees(): number;
        get attackable(): boolean;
        isAttackable(): boolean;
        static areMergable(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        static getSpin(arg0: number, arg1: number): number;
        static merge(arg0: $ItemStack_, arg1: $ItemStack_, arg2: number): $ItemStack;
        dampensVibrations(): boolean;
        fireImmune(): boolean;
        getSlot(arg0: number): $SlotAccess;
        hasPickUpDelay(): boolean;
        hurtClient(arg0: $DamageSource): boolean;
        hurtServer(arg0: $ServerLevel, arg1: $DamageSource, arg2: number): boolean;
        ignoreExplosion(arg0: $Explosion): boolean;
        makeFakeItem(): void;
        playerTouch(arg0: $Player): void;
        restoreFrom(arg0: $Entity): void;
        setDefaultPickUpDelay(): void;
        setExtendedLifetime(): void;
        setNeverPickUp(): void;
        setNoPickUpDelay(): void;
        setUnlimitedLifetime(): void;
        teleport(arg0: $TeleportTransition): $Entity;
        tick(): void;
    }

}
