import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $InteractionHand, $InteractionHand_ } from "java:net/minecraft/world";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Level } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/item/context" {
    export class $BlockPlaceContext extends $UseOnContext {
        constructor(arg0: $Player, arg1: $InteractionHand_, arg2: $ItemStack_, arg3: $BlockHitResult);
        constructor(arg0: $UseOnContext);
        constructor(arg0: $Level, arg1: $Player, arg2: $InteractionHand_, arg3: $ItemStack_, arg4: $BlockHitResult);
        get clickedPos(): $BlockPos;
        getClickedPos(): $BlockPos;
        get nearestLookingDirections(): $Direction[];
        getNearestLookingDirections(): $Direction[];
        get nearestLookingDirection(): $Direction;
        getNearestLookingDirection(): $Direction;
        get nearestLookingVerticalDirection(): $Direction;
        getNearestLookingVerticalDirection(): $Direction;
        static at(arg0: $BlockPlaceContext, arg1: $BlockPos_, arg2: $Direction_): $BlockPlaceContext;
        canPlace(): boolean;
        replacingClickedOnBlock(): boolean;
    }

    export class $UseOnContext {
        constructor(arg0: $Player, arg1: $InteractionHand_, arg2: $BlockHitResult);
        constructor(arg0: $Level, arg1: $Player, arg2: $InteractionHand_, arg3: $ItemStack_, arg4: $BlockHitResult);
        get clickLocation(): $Vec3;
        getClickLocation(): $Vec3;
        get clickedFace(): $Direction;
        getClickedFace(): $Direction;
        get clickedPos(): $BlockPos;
        getClickedPos(): $BlockPos;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get horizontalDirection(): $Direction;
        getHorizontalDirection(): $Direction;
        get itemInHand(): $ItemStack;
        getItemInHand(): $ItemStack;
        get level(): $Level;
        getLevel(): $Level;
        get player(): $Player;
        getPlayer(): $Player;
        get rotation(): number;
        getRotation(): number;
        get inside(): boolean;
        isInside(): boolean;
        get secondaryUseActive(): boolean;
        isSecondaryUseActive(): boolean;
    }

}
