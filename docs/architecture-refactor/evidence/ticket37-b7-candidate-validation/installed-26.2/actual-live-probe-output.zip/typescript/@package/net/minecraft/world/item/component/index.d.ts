import { $GameProfile } from "java:com/mojang/authlib";
import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $IntList } from "java:it/unimi/dsi/fastutil/ints";
import { $Enum, $Record, $String } from "java:java/lang";
import { $DecimalFormat } from "java:java/text";
import { $List, $Optional, $SequencedSet, $UUID } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $BiConsumer, $Consumer, $Predicate } from "java:java/util/function";
import { $Holder, $HolderLookup$Provider, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentGetter, $DataComponentType } from "java:net/minecraft/core/component";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $MutableComponent } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ProfileResolver } from "java:net/minecraft/server/players";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $Entity, $EquipmentSlot, $EquipmentSlotGroup, $EquipmentSlotGroup_, $EquipmentSlot_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Attribute, $AttributeModifier, $Attribute_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $Player, $PlayerSkin$Patch } from "java:net/minecraft/world/entity/player";
import { $Item$TooltipContext, $ItemStack, $ItemStack_, $ItemUseAnimation, $ItemUseAnimation_, $SwingAnimationType, $SwingAnimationType_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $ConsumeEffect } from "java:net/minecraft/world/item/consume_effects";
import { $Level } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $AABB, $HitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $ExtensionInfo, $IExtensibleEnum } from "java:net/neoforged/fml/common/asm/enumextension";
import { $TriConsumer } from "java:org/apache/commons/lang3/function";

declare module "java:net/minecraft/world/item/component" {
    export class $AttackRange extends $Record {
        constructor(minReach: number, maxReach: number, minCreativeReach: number, maxCreativeReach: number, hitboxMargin: number, mobFactor: number);
        static CODEC: $Codec<$AttackRange>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $AttackRange>;
        static defaultFor(arg0: $LivingEntity): $AttackRange;
        effectiveMaxRange(arg0: $Entity): number;
        effectiveMinRange(arg0: $Entity): number;
        equals(arg0: object): boolean;
        getClosesetHit(arg0: $Entity, arg1: number, arg2: $Predicate<$Entity>): $HitResult;
        hashCode(): number;
        hitboxMargin(): number;
        isInRange(arg0: $LivingEntity, arg1: $AABB, arg2: number): boolean;
        isInRange(arg0: $LivingEntity, arg1: $Vec3_): boolean;
        maxCreativeReach(): number;
        maxReach(): number;
        minCreativeReach(): number;
        minReach(): number;
        mobFactor(): number;
        toString(): string;
    }

    export class $Consumable extends $Record {
        constructor(consumeSeconds: number, animation: $ItemUseAnimation_, sound: $Holder<$SoundEvent_>, hasConsumeParticles: boolean, onConsumeEffects: $ConsumeEffect[]);
        static CODEC: $Codec<$Consumable>;
        static DEFAULT_CONSUME_SECONDS: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Consumable>;
        static builder(): $Consumable$Builder;
        animation(): $ItemUseAnimation;
        canConsume(arg0: $LivingEntity, arg1: $ItemStack_): boolean;
        consumeSeconds(): number;
        consumeTicks(): number;
        emitParticlesAndSounds(arg0: $RandomSource, arg1: $LivingEntity, arg2: $ItemStack_, arg3: number): void;
        equals(arg0: object): boolean;
        hasConsumeParticles(): boolean;
        hashCode(): number;
        onConsumeEffects(): $List<$ConsumeEffect>;
        onConsume(arg0: $Level, arg1: $LivingEntity, arg2: $ItemStack_): $ItemStack;
        shouldEmitParticlesAndSounds(arg0: number): boolean;
        sound(): $Holder<$SoundEvent>;
        startConsuming(arg0: $LivingEntity, arg1: $ItemStack_, arg2: $InteractionHand_): $InteractionResult;
        toString(): string;
    }

    export class $Consumable$Builder {
        animation(arg0: $ItemUseAnimation_): $Consumable$Builder;
        build(): $Consumable;
        consumeSeconds(arg0: number): $Consumable$Builder;
        hasConsumeParticles(arg0: boolean): $Consumable$Builder;
        onConsume(arg0: $ConsumeEffect): $Consumable$Builder;
        soundAfterConsume(arg0: $Holder<$SoundEvent_>): $Consumable$Builder;
        sound(arg0: $Holder<$SoundEvent_>): $Consumable$Builder;
    }

    export interface $ConsumableListener {
        onConsume(arg0: $Level, arg1: $LivingEntity, arg2: $ItemStack_, arg3: $Consumable): void;
    }

    export class $FireworkExplosion extends $Record implements $TooltipProvider {
        constructor(shape: $FireworkExplosion$Shape_, colors: $IntList, fadeColors: $IntList, hasTrail: boolean, hasTwinkle: boolean);
        static CODEC: $Codec<$FireworkExplosion>;
        static COLOR_LIST_CODEC: $Codec<$IntList>;
        static DEFAULT: $FireworkExplosion;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $FireworkExplosion>;
        addAdditionalTooltip(arg0: $Consumer<$Component_>): void;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer<$Component_>, arg2: $TooltipFlag, arg3: $DataComponentGetter): void;
        colors(): $IntList;
        equals(arg0: object): boolean;
        fadeColors(): $IntList;
        hasTrail(): boolean;
        hasTwinkle(): boolean;
        hashCode(): number;
        shape(): $FireworkExplosion$Shape;
        toString(): string;
        withFadeColors(arg0: $IntList): $FireworkExplosion;
    }

    export class $FireworkExplosion$Shape {
        static BURST: $FireworkExplosion$Shape;
        static CREEPER: $FireworkExplosion$Shape;
        static LARGE_BALL: $FireworkExplosion$Shape;
        static SMALL_BALL: $FireworkExplosion$Shape;
        static STAR: $FireworkExplosion$Shape;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $FireworkExplosion$Shape[];
        static valueOf(name: string): $FireworkExplosion$Shape;
    }

    export class $ItemAttributeModifiers extends $Record {
        constructor(modifiers: $ItemAttributeModifiers$Entry[]);
        static ATTRIBUTE_MODIFIER_FORMAT: $DecimalFormat;
        static CODEC: $Codec<$ItemAttributeModifiers>;
        static EMPTY: $ItemAttributeModifiers;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemAttributeModifiers>;
        static builder(): $ItemAttributeModifiers$Builder;
        compute(arg0: $Holder<$Attribute_>, arg1: number, arg2: $EquipmentSlot_): number;
        equals(arg0: object): boolean;
        forEach(arg0: $EquipmentSlotGroup_, arg1: $BiConsumer<$Holder<$Attribute_>, $AttributeModifier>): void;
        forEach(arg0: $EquipmentSlotGroup_, arg1: $TriConsumer<$Holder<$Attribute_>, $AttributeModifier, $ItemAttributeModifiers$Display>): void;
        forEach(arg0: $EquipmentSlot_, arg1: $BiConsumer<$Holder<$Attribute_>, $AttributeModifier>): void;
        hashCode(): number;
        modifiers(): $List<$ItemAttributeModifiers$Entry>;
        toString(): string;
        withModifierAdded(arg0: $Holder<$Attribute_>, arg1: $AttributeModifier, arg2: $EquipmentSlotGroup_): $ItemAttributeModifiers;
    }

    export class $ItemAttributeModifiers$Builder {
        add(arg0: $Holder<$Attribute_>, arg1: $AttributeModifier, arg2: $EquipmentSlotGroup_, arg3: $ItemAttributeModifiers$Display): $ItemAttributeModifiers$Builder;
        add(arg0: $Holder<$Attribute_>, arg1: $AttributeModifier, arg2: $EquipmentSlotGroup_): $ItemAttributeModifiers$Builder;
        build(): $ItemAttributeModifiers;
    }

    export interface $ItemAttributeModifiers$Display {
        apply(arg0: $Consumer<$Component_>, arg1: $Player, arg2: $Holder<$Attribute_>, arg3: $AttributeModifier): void;
        attributeModifiers(): $ItemAttributeModifiers$Display;
        hidden(): $ItemAttributeModifiers$Display;
        override(arg0: $Component_): $ItemAttributeModifiers$Display;
        type(): $ItemAttributeModifiers$Display$Type;
        static CODEC: $Codec<$ItemAttributeModifiers$Display>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemAttributeModifiers$Display>;
    }

    export class $ItemAttributeModifiers$Display$Type {
        static DEFAULT: $ItemAttributeModifiers$Display$Type;
        static HIDDEN: $ItemAttributeModifiers$Display$Type;
        static OVERRIDE: $ItemAttributeModifiers$Display$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ItemAttributeModifiers$Display$Type[];
        static valueOf(name: string): $ItemAttributeModifiers$Display$Type;
    }

    export class $ItemAttributeModifiers$Entry extends $Record {
        constructor(arg0: $Holder<$Attribute_>, arg1: $AttributeModifier, arg2: $EquipmentSlotGroup_);
        constructor(attribute: $Holder<$Attribute_>, modifier: $AttributeModifier, slot: $EquipmentSlotGroup_, display: $ItemAttributeModifiers$Display);
        static CODEC: $Codec<$ItemAttributeModifiers$Entry>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemAttributeModifiers$Entry>;
        attribute(): $Holder<$Attribute>;
        display(): $ItemAttributeModifiers$Display;
        equals(arg0: object): boolean;
        hashCode(): number;
        matches(arg0: $Holder<$Attribute_>, arg1: $Identifier_): boolean;
        modifier(): $AttributeModifier;
        slot(): $EquipmentSlotGroup;
        toString(): string;
    }

    export class $ItemLore extends $Record implements $TooltipProvider {
        constructor(arg0: $Component_[]);
        constructor(lines: $Component_[], styledLines: $Component_[]);
        static CODEC: $Codec<$ItemLore>;
        static EMPTY: $ItemLore;
        static MAX_LINES: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemLore>;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer<$Component_>, arg2: $TooltipFlag, arg3: $DataComponentGetter): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        lines(): $List<$Component>;
        styledLines(): $List<$Component>;
        toString(): string;
        withLineAdded(arg0: $Component_): $ItemLore;
    }

    export class $ResolvableProfile implements $TooltipProvider {
        static CODEC: $Codec<$ResolvableProfile>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ResolvableProfile>;
        static createResolved(arg0: $GameProfile): $ResolvableProfile;
        static createUnresolved(arg0: string): $ResolvableProfile;
        static createUnresolved(arg0: string): $ResolvableProfile;
        name(): $Optional<string>;
        partialProfile(): $GameProfile;
        resolveProfile(arg0: $ProfileResolver): $CompletableFuture<$GameProfile>;
        skinPatch(): $PlayerSkin$Patch;
    }

    export class $SwingAnimation extends $Record {
        constructor(type: $SwingAnimationType_, duration: number);
        static CODEC: $Codec<$SwingAnimation>;
        static DEFAULT: $SwingAnimation;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $SwingAnimation>;
        duration(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $SwingAnimationType;
    }

    export class $TooltipDisplay extends $Record {
        constructor(hideTooltip: boolean, hiddenComponents: $SequencedSet<$DataComponentType<any>>);
        static CODEC: $Codec<$TooltipDisplay>;
        static DEFAULT: $TooltipDisplay;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $TooltipDisplay>;
        equals(arg0: object): boolean;
        hashCode(): number;
        hiddenComponents(): $SequencedSet<$DataComponentType<any>>;
        hideTooltip(): boolean;
        shows(arg0: $DataComponentType<any>): boolean;
        toString(): string;
        withHidden(arg0: $DataComponentType<any>, arg1: boolean): $TooltipDisplay;
    }

    export interface $TooltipProvider {
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer<$Component_>, arg2: $TooltipFlag, arg3: $DataComponentGetter): void;
    }

    export class $TypedEntityData<IdType> implements $TooltipProvider {
        get unsafe(): $CompoundTag;
        getUnsafe(): $CompoundTag;
        static codec<T>(arg0: $Codec<T>): $Codec<$TypedEntityData<T>>;
        static of<T>(arg0: T, arg1: $CompoundTag_): $TypedEntityData<T>;
        static streamCodec<B, T>(arg0: $StreamCodec<B, T>): $StreamCodec<B, $TypedEntityData<T>>;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer<$Component_>, arg2: $TooltipFlag, arg3: $DataComponentGetter): void;
        contains(arg0: string): boolean;
        copyTagWithoutId(): $CompoundTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        loadInto(arg0: $Entity): void;
        loadInto(arg0: $BlockEntity, arg1: $HolderLookup$Provider): boolean;
        toString(): string;
        type(): IdType;
    }

    export class $Fireworks extends $Record implements $TooltipProvider {
        constructor(flightDuration: number, explosions: $FireworkExplosion[]);
        static CODEC: $Codec<$Fireworks>;
        static MAX_EXPLOSIONS: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Fireworks>;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer<$Component_>, arg2: $TooltipFlag, arg3: $DataComponentGetter): void;
        equals(arg0: object): boolean;
        explosions(): $List<$FireworkExplosion>;
        flightDuration(): number;
        hashCode(): number;
        toString(): string;
    }

    export type $FireworkExplosion$Shape_ = $FireworkExplosion$Shape | "BURST" | "CREEPER" | "LARGE_BALL" | "SMALL_BALL" | "STAR";
    export type $ItemAttributeModifiers$Display$Type_ = $ItemAttributeModifiers$Display$Type | "DEFAULT" | "HIDDEN" | "OVERRIDE";
    export type $Fireworks_ = $Fireworks | { [key: string]: any } | $Fireworks_[] | string;
}
