import { $Record, $String } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $List } from "java:java/util";

declare module "java:net/minecraft/world/level/validation" {
    export class $DirectoryValidator {
        constructor(arg0: $PathMatcher);
        validateDirectory(arg0: string, arg1: boolean): $List<$ForbiddenSymlinkInfo>;
        validateKnownDirectory(arg0: string, arg1: $ForbiddenSymlinkInfo[]): void;
        validateSymlink(arg0: string, arg1: $ForbiddenSymlinkInfo[]): void;
        validateSymlink(arg0: string): $List<$ForbiddenSymlinkInfo>;
    }

    export class $ForbiddenSymlinkInfo extends $Record {
        constructor(link: string, target: string);
        equals(arg0: object): boolean;
        hashCode(): number;
        link(): $Path;
        target(): $Path;
        toString(): string;
    }

}
