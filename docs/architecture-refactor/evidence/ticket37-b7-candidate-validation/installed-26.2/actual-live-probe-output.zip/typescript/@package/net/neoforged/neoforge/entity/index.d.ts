import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener } from "java:net/minecraft/network/protocol/game";
import { $ServerEntity } from "java:net/minecraft/server/level";
import { $Entity } from "java:net/minecraft/world/entity";

declare module "java:net/neoforged/neoforge/entity" {
    export class $PartEntity<T extends $Entity> extends $Entity {
        constructor(arg0: T);
        get parent(): T;
        getParent(): T;
        getAddEntityPacket(arg0: $ServerEntity): $Packet<$ClientGamePacketListener>;
    }

}
