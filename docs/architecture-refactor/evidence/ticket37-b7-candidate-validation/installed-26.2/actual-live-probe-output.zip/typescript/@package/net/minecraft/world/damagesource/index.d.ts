import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Holder, $Holder_, $Registry } from "java:net/minecraft/core";
import { $BootstrapContext } from "java:net/minecraft/data/worldgen";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $Style } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $Entity, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FireworkRocketEntity } from "java:net/minecraft/world/entity/projectile";
import { $AbstractArrow } from "java:net/minecraft/world/entity/projectile/arrow";
import { $Fireball, $WitherSkull } from "java:net/minecraft/world/entity/projectile/hurtingprojectile";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Explosion } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $ExtensionInfo, $IExtensibleEnum } from "java:net/neoforged/fml/common/asm/enumextension";
import { $IDeathMessageProvider, $IScalingFunction } from "java:net/neoforged/neoforge/common/damagesource";

declare module "java:net/minecraft/world/damagesource" {
    export class $CombatEntry extends $Record {
        constructor(source: $DamageSource, damage: number, fallLocation: $FallLocation, fallDistance: number);
        damage(): number;
        equals(arg0: object): boolean;
        fallDistance(): number;
        fallLocation(): $FallLocation;
        hashCode(): number;
        source(): $DamageSource;
        toString(): string;
    }

    export class $CombatTracker {
        constructor(arg0: $LivingEntity);
        static INTENTIONAL_GAME_DESIGN_STYLE: $Style;
        static RESET_COMBAT_STATUS_TIME: number;
        static RESET_DAMAGE_STATUS_TIME: number;
        get combatDuration(): number;
        getCombatDuration(): number;
        get deathMessage(): $Component;
        getDeathMessage(): $Component;
        get mostSignificantFall(): $CombatEntry;
        getMostSignificantFall(): $CombatEntry;
        getFallMessage(arg0: $CombatEntry, arg1: $Entity): $Component;
        recheckStatus(): void;
        recordDamage(arg0: $DamageSource, arg1: number): void;
    }

    export class $DamageEffects {
        static BURNING: $DamageEffects;
        static DROWNING: $DamageEffects;
        static FREEZING: $DamageEffects;
        static HURT: $DamageEffects;
        static POKING: $DamageEffects;
        static THORNS: $DamageEffects;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DamageEffects[];
        static valueOf(name: string): $DamageEffects;
    }

    export class $DamageScaling {
        static ALWAYS: $DamageScaling;
        static NEVER: $DamageScaling;
        static WHEN_CAUSED_BY_LIVING_NON_PLAYER: $DamageScaling;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DamageScaling[];
        static valueOf(name: string): $DamageScaling;
    }

    export class $DamageSource {
        constructor(arg0: $Holder<$DamageType>);
        constructor(arg0: $Holder<$DamageType>, arg1: $Entity);
        constructor(arg0: $Holder<$DamageType>, arg1: $Entity, arg2: $Entity);
        constructor(arg0: $Holder<$DamageType>, arg1: $Entity, arg2: $Entity, arg3: $Vec3_);
        constructor(arg0: $Holder<$DamageType>, arg1: $Vec3_);
        get directEntity(): $Entity;
        getDirectEntity(): $Entity;
        get entity(): $Entity;
        getEntity(): $Entity;
        get foodExhaustion(): number;
        getFoodExhaustion(): number;
        get msgId(): string;
        getMsgId(): string;
        get sourcePosition(): $Vec3;
        getSourcePosition(): $Vec3;
        get weaponItem(): $ItemStack;
        getWeaponItem(): $ItemStack;
        get creativePlayer(): boolean;
        isCreativePlayer(): boolean;
        get direct(): boolean;
        isDirect(): boolean;
        getLocalizedDeathMessage(arg0: $LivingEntity): $Component;
        is(arg0: $ResourceKey<$DamageType>): boolean;
        is(arg0: $TagKey<$DamageType>): boolean;
        scalesWithDifficulty(): boolean;
        sourcePositionRaw(): $Vec3;
        toString(): string;
        typeHolder(): $Holder<$DamageType>;
        type(): $DamageType;
    }

    export class $DamageSources {
        constructor(arg0: $RegistryAccess);
        damageTypes: $Registry<$DamageType>;
        anvil(arg0: $Entity): $DamageSource;
        arrow(arg0: $AbstractArrow, arg1: $Entity): $DamageSource;
        badRespawnPointExplosion(arg0: $Vec3_): $DamageSource;
        cactus(): $DamageSource;
        campfire(): $DamageSource;
        cramming(): $DamageSource;
        dragonBreath(): $DamageSource;
        drown(): $DamageSource;
        dryOut(): $DamageSource;
        enderPearl(): $DamageSource;
        explosion(arg0: $Entity, arg1: $Entity): $DamageSource;
        explosion(arg0: $Explosion): $DamageSource;
        fallingBlock(arg0: $Entity): $DamageSource;
        fallingStalactite(arg0: $Entity): $DamageSource;
        fall(): $DamageSource;
        fellOutOfWorld(): $DamageSource;
        fireball(arg0: $Fireball, arg1: $Entity): $DamageSource;
        fireworks(arg0: $FireworkRocketEntity, arg1: $Entity): $DamageSource;
        flyIntoWall(): $DamageSource;
        freeze(): $DamageSource;
        genericKill(): $DamageSource;
        generic(): $DamageSource;
        hotFloor(): $DamageSource;
        inFire(): $DamageSource;
        inWall(): $DamageSource;
        indirectMagic(arg0: $Entity, arg1: $Entity): $DamageSource;
        lava(): $DamageSource;
        lightningBolt(): $DamageSource;
        mace(arg0: $Entity): $DamageSource;
        magic(): $DamageSource;
        mobAttack(arg0: $LivingEntity): $DamageSource;
        mobProjectile(arg0: $Entity, arg1: $LivingEntity): $DamageSource;
        noAggroMobAttack(arg0: $LivingEntity): $DamageSource;
        onFire(): $DamageSource;
        outOfBorder(): $DamageSource;
        playerAttack(arg0: $Player): $DamageSource;
        sonicBoom(arg0: $Entity): $DamageSource;
        source(arg0: $ResourceKey<$DamageType>, arg1: $Entity, arg2: $Entity): $DamageSource;
        source(arg0: $ResourceKey<$DamageType>, arg1: $Entity): $DamageSource;
        source(arg0: $ResourceKey<$DamageType>): $DamageSource;
        spit(arg0: $Entity, arg1: $LivingEntity): $DamageSource;
        stalagmite(): $DamageSource;
        starve(): $DamageSource;
        sting(arg0: $LivingEntity): $DamageSource;
        sweetBerryBush(): $DamageSource;
        thorns(arg0: $Entity): $DamageSource;
        thrown(arg0: $Entity, arg1: $Entity): $DamageSource;
        trident(arg0: $Entity, arg1: $Entity): $DamageSource;
        windCharge(arg0: $Entity, arg1: $LivingEntity): $DamageSource;
        witherSkull(arg0: $WitherSkull, arg1: $Entity): $DamageSource;
        wither(): $DamageSource;
    }

    export class $DamageType extends $Record {
        constructor(arg0: string, arg1: number);
        constructor(arg0: string, arg1: number, arg2: $DamageEffects_);
        constructor(arg0: string, arg1: $DamageScaling_, arg2: number);
        constructor(arg0: string, arg1: $DamageScaling_, arg2: number, arg3: $DamageEffects_);
        constructor(msgId: string, scaling: $DamageScaling_, exhaustion: number, effects: $DamageEffects_, deathMessageType: $DeathMessageType_);
        static CODEC: $Codec<$Holder<$DamageType>>;
        static DIRECT_CODEC: $Codec<$DamageType>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$DamageType>>;
        deathMessageType(): $DeathMessageType;
        effects(): $DamageEffects;
        equals(arg0: object): boolean;
        exhaustion(): number;
        hashCode(): number;
        msgId(): string;
        scaling(): $DamageScaling;
        toString(): string;
    }

    export interface $DamageTypes {
        bootstrap(arg0: $BootstrapContext<$DamageType>): void;
        static ARROW: $ResourceKey<$DamageType>;
        static BAD_RESPAWN_POINT: $ResourceKey<$DamageType>;
        static CACTUS: $ResourceKey<$DamageType>;
        static CAMPFIRE: $ResourceKey<$DamageType>;
        static CRAMMING: $ResourceKey<$DamageType>;
        static DRAGON_BREATH: $ResourceKey<$DamageType>;
        static DROWN: $ResourceKey<$DamageType>;
        static DRY_OUT: $ResourceKey<$DamageType>;
        static ENDER_PEARL: $ResourceKey<$DamageType>;
        static EXPLOSION: $ResourceKey<$DamageType>;
        static FALL: $ResourceKey<$DamageType>;
        static FALLING_ANVIL: $ResourceKey<$DamageType>;
        static FALLING_BLOCK: $ResourceKey<$DamageType>;
        static FALLING_STALACTITE: $ResourceKey<$DamageType>;
        static FELL_OUT_OF_WORLD: $ResourceKey<$DamageType>;
        static FIREBALL: $ResourceKey<$DamageType>;
        static FIREWORKS: $ResourceKey<$DamageType>;
        static FLY_INTO_WALL: $ResourceKey<$DamageType>;
        static FREEZE: $ResourceKey<$DamageType>;
        static GENERIC: $ResourceKey<$DamageType>;
        static GENERIC_KILL: $ResourceKey<$DamageType>;
        static HOT_FLOOR: $ResourceKey<$DamageType>;
        static INDIRECT_MAGIC: $ResourceKey<$DamageType>;
        static IN_FIRE: $ResourceKey<$DamageType>;
        static IN_WALL: $ResourceKey<$DamageType>;
        static LAVA: $ResourceKey<$DamageType>;
        static LIGHTNING_BOLT: $ResourceKey<$DamageType>;
        static MACE_SMASH: $ResourceKey<$DamageType>;
        static MAGIC: $ResourceKey<$DamageType>;
        static MOB_ATTACK: $ResourceKey<$DamageType>;
        static MOB_ATTACK_NO_AGGRO: $ResourceKey<$DamageType>;
        static MOB_PROJECTILE: $ResourceKey<$DamageType>;
        static ON_FIRE: $ResourceKey<$DamageType>;
        static OUTSIDE_BORDER: $ResourceKey<$DamageType>;
        static PLAYER_ATTACK: $ResourceKey<$DamageType>;
        static PLAYER_EXPLOSION: $ResourceKey<$DamageType>;
        static SONIC_BOOM: $ResourceKey<$DamageType>;
        static SPEAR: $ResourceKey<$DamageType>;
        static SPIT: $ResourceKey<$DamageType>;
        static STALAGMITE: $ResourceKey<$DamageType>;
        static STARVE: $ResourceKey<$DamageType>;
        static STING: $ResourceKey<$DamageType>;
        static SULFUR_CUBE_HOT: $ResourceKey<$DamageType>;
        static SWEET_BERRY_BUSH: $ResourceKey<$DamageType>;
        static THORNS: $ResourceKey<$DamageType>;
        static THROWN: $ResourceKey<$DamageType>;
        static TRIDENT: $ResourceKey<$DamageType>;
        static UNATTRIBUTED_FIREBALL: $ResourceKey<$DamageType>;
        static WIND_CHARGE: $ResourceKey<$DamageType>;
        static WITHER: $ResourceKey<$DamageType>;
        static WITHER_SKULL: $ResourceKey<$DamageType>;
    }

    export class $DeathMessageType {
        static DEFAULT: $DeathMessageType;
        static FALL_VARIANTS: $DeathMessageType;
        static INTENTIONAL_GAME_DESIGN: $DeathMessageType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DeathMessageType[];
        static valueOf(name: string): $DeathMessageType;
    }

    export class $FallLocation extends $Record {
        constructor(id: string);
        static GENERIC: $FallLocation;
        static LADDER: $FallLocation;
        static OTHER_CLIMBABLE: $FallLocation;
        static SCAFFOLDING: $FallLocation;
        static TWISTING_VINES: $FallLocation;
        static VINES: $FallLocation;
        static WATER: $FallLocation;
        static WEEPING_VINES: $FallLocation;
        static blockToFallLocation(arg0: $BlockState_): $FallLocation;
        static getCurrentFallLocation(arg0: $LivingEntity): $FallLocation;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): string;
        languageKey(): string;
        toString(): string;
    }

    export type $DamageEffects_ = $DamageEffects | "BURNING" | "DROWNING" | "FREEZING" | "HURT" | "POKING" | "THORNS";
    export type $DamageScaling_ = $DamageScaling | "ALWAYS" | "NEVER" | "WHEN_CAUSED_BY_LIVING_NON_PLAYER";
    export type $DeathMessageType_ = $DeathMessageType | "DEFAULT" | "FALL_VARIANTS" | "INTENTIONAL_GAME_DESIGN";
}
