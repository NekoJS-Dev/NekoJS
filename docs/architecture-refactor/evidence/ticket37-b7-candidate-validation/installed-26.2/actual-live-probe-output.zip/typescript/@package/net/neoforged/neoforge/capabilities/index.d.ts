import { $Class, $Void } from "java:java/lang";
import { $List } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $Entity, $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $ItemLike, $ItemLike_, $Level } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_ } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Event } from "java:net/neoforged/bus/api";
import { $IModBusEvent } from "java:net/neoforged/fml/event";

declare module "java:net/neoforged/neoforge/capabilities" {
    export class $BaseCapability<T, C> {
        contextClass(): $Class<C>;
        name(): $Identifier;
        typeClass(): $Class<T>;
    }

    export class $BlockCapability<T, C> extends $BaseCapability {
        get proxyable(): boolean;
        isProxyable(): boolean;
        static createSided<T>(arg0: $Identifier_, arg1: $Class<T>): $BlockCapability<T, $Direction>;
        static createVoid<T>(arg0: $Identifier_, arg1: $Class<T>): $BlockCapability<T, void>;
        static create<T, C>(arg0: $Identifier_, arg1: $Class<T>, arg2: $Class<C>): $BlockCapability<T, C>;
        static getAllProxyable(): $List<$BlockCapability<any, any>>;
        static getAll(): $List<$BlockCapability<any, any>>;
        getCapability(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity, arg4: C): T;
    }

    export class $Capabilities {
    }

    export class $EntityCapability<T, C> extends $BaseCapability {
        static createSided<T>(arg0: $Identifier_, arg1: $Class<T>): $EntityCapability<T, $Direction>;
        static createVoid<T>(arg0: $Identifier_, arg1: $Class<T>): $EntityCapability<T, void>;
        static create<T, C>(arg0: $Identifier_, arg1: $Class<T>, arg2: $Class<C>): $EntityCapability<T, C>;
        static getAll(): $List<$EntityCapability<any, any>>;
        getCapability(arg0: $Entity, arg1: C): T;
    }

    export interface $IBlockCapabilityProvider<T, C> {
        getCapability(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity, arg4: C): T;
    }

    export interface $ICapabilityInvalidationListener {
        onInvalidate(): boolean;
    }

    export interface $ICapabilityProvider<O, C, T> {
        getCapability(arg0: O, arg1: C): T;
    }

    export class $ItemCapability<T, C> extends $BaseCapability {
        static createVoid<T>(arg0: $Identifier_, arg1: $Class<T>): $ItemCapability<T, void>;
        static create<T, C>(arg0: $Identifier_, arg1: $Class<T>, arg2: $Class<C>): $ItemCapability<T, C>;
        static getAll(): $List<$ItemCapability<any, any>>;
        getCapability(arg0: $ItemStack_, arg1: C): T;
    }

    export class $RegisterCapabilitiesEvent extends $Event implements $IModBusEvent {
        isBlockRegistered(arg0: $BlockCapability<any, any>, arg1: $Block_): boolean;
        isEntityRegistered(arg0: $EntityCapability<any, any>, arg1: $EntityType<any>): boolean;
        isItemRegistered(arg0: $ItemCapability<any, any>, arg1: $Item_): boolean;
        registerBlockEntity<T, C, BE>(arg0: $BlockCapability<T, C>, arg1: $BlockEntityType<BE>, arg2: $ICapabilityProvider<any, C, T>): void;
        registerBlock<T, C>(arg0: $BlockCapability<T, C>, arg1: $IBlockCapabilityProvider<T, C>, arg2?: $Block_[]): void;
        registerEntity<T, C, E>(arg0: $EntityCapability<T, C>, arg1: $EntityType<E>, arg2: $ICapabilityProvider<any, C, T>): void;
        registerItem<T, C>(arg0: $ItemCapability<T, C>, arg1: $ICapabilityProvider<$ItemStack_, C, T>, arg2?: $ItemLike_[]): void;
    }

}
