import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity$Fallsounds, $PathfinderMob, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";

export * as hoglin from "java:net/minecraft/world/entity/monster/hoglin";
export * as piglin from "java:net/minecraft/world/entity/monster/piglin";
export * as warden from "java:net/minecraft/world/entity/monster/warden";

declare module "java:net/minecraft/world/entity/monster" {
    export interface $Enemy {
        static XP_REWARD_BOSS: number;
        static XP_REWARD_HUGE: number;
        static XP_REWARD_LARGE: number;
        static XP_REWARD_MEDIUM: number;
        static XP_REWARD_NONE: number;
        static XP_REWARD_SMALL: number;
    }

    export class $Monster extends $PathfinderMob implements $Enemy {
        get fallSounds(): $LivingEntity$Fallsounds;
        getFallSounds(): $LivingEntity$Fallsounds;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        static checkAnyLightMonsterSpawnRules(arg0: $EntityType<$Monster>, arg1: $LevelAccessor, arg2: $EntitySpawnReason_, arg3: $BlockPos_, arg4: $RandomSource): boolean;
        static checkMonsterSpawnRules(arg0: $EntityType<$Mob>, arg1: $ServerLevelAccessor, arg2: $EntitySpawnReason_, arg3: $BlockPos_, arg4: $RandomSource): boolean;
        static checkSurfaceMonstersSpawnRules(arg0: $EntityType<$Mob>, arg1: $ServerLevelAccessor, arg2: $EntitySpawnReason_, arg3: $BlockPos_, arg4: $RandomSource): boolean;
        static createMonsterAttributes(): $AttributeSupplier$Builder;
        static isDarkEnoughToSpawn(arg0: $ServerLevelAccessor, arg1: $BlockPos_, arg2: $RandomSource): boolean;
        aiStep(): void;
        getProjectile(arg0: $ItemStack_): $ItemStack;
        getWalkTargetValue(arg0: $BlockPos_, arg1: $LevelReader): number;
        isPreventingPlayerRest(arg0: $ServerLevel, arg1: $Player): boolean;
        shouldDropExperience(): boolean;
    }

    export class $PatrollingMonster extends $Monster {
        get patrolTarget(): $BlockPos;
        getPatrolTarget(): $BlockPos;
        set patrolTarget(value: $BlockPos_);
        get patrolLeader(): boolean;
        isPatrolLeader(): boolean;
        set patrolLeader(value: boolean);
        static checkPatrollingMonsterSpawnRules(arg0: $EntityType<$PatrollingMonster>, arg1: $LevelAccessor, arg2: $EntitySpawnReason_, arg3: $BlockPos_, arg4: $RandomSource): boolean;
        canBeLeader(): boolean;
        canJoinPatrol(): boolean;
        finalizeSpawn(arg0: $ServerLevelAccessor, arg1: $DifficultyInstance, arg2: $EntitySpawnReason_, arg3: $SpawnGroupData): $SpawnGroupData;
        findPatrolTarget(): void;
        hasPatrolTarget(): boolean;
        removeWhenFarAway(arg0: number): boolean;
    }

}
