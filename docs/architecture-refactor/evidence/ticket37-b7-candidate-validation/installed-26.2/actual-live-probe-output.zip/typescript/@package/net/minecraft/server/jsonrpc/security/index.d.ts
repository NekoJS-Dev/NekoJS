import { $ChannelDuplexHandler, $ChannelHandlerContext, $ChannelPromise } from "java:io/netty/channel";
import { $String } from "java:java/lang";

declare module "java:net/minecraft/server/jsonrpc/security" {
    export class $AuthenticationHandler extends $ChannelDuplexHandler {
        constructor(arg0: $SecurityConfig, arg1: string);
        static BEARER_PREFIX: string;
        channelRead(arg0: $ChannelHandlerContext, arg1: object): void;
        isValidApiKey(arg0: string): boolean;
        write(arg0: $ChannelHandlerContext, arg1: object, arg2: $ChannelPromise): void;
    }

}
