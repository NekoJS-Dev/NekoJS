import { $ImmutableList } from "java:com/google/common/collect";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Collection, $List, $Optional, $Set } from "java:java/util";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $EnvironmentAttribute, $EnvironmentAttributeSystem } from "java:net/minecraft/world/attribute";
import { $BehaviorControl } from "java:net/minecraft/world/entity/ai/behavior";
import { $MemoryMap, $MemoryModuleType, $MemoryStatus, $MemoryStatus_ } from "java:net/minecraft/world/entity/ai/memory";
import { $Activity, $Activity_ } from "java:net/minecraft/world/entity/schedule";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as attributes from "java:net/minecraft/world/entity/ai/attributes";
export * as behavior from "java:net/minecraft/world/entity/ai/behavior";
export * as control from "java:net/minecraft/world/entity/ai/control";
export * as goal from "java:net/minecraft/world/entity/ai/goal";
export * as memory from "java:net/minecraft/world/entity/ai/memory";
export * as navigation from "java:net/minecraft/world/entity/ai/navigation";
export * as sensing from "java:net/minecraft/world/entity/ai/sensing";
export * as targeting from "java:net/minecraft/world/entity/ai/targeting";
export * as village from "java:net/minecraft/world/entity/ai/village";

declare module "java:net/minecraft/world/entity/ai" {
    export class $ActivityData<E extends $LivingEntity> extends $Record {
        constructor(activityType: $Activity_, behaviorPriorityPairs: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, conditions: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[], memoriesToEraseWhenStopped: $MemoryModuleType<any>[]);
        static createPriorityPairs<E>(arg0: number, arg1: $ImmutableList<$BehaviorControl<any>>): $ImmutableList<$Pair<number, $BehaviorControl<any>>>;
        static create<E>(arg0: $Activity_, arg1: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, arg2: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[], arg3: $MemoryModuleType<any>[]): $ActivityData<E>;
        static create<E>(arg0: $Activity_, arg1: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, arg2: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[]): $ActivityData<E>;
        static create<E>(arg0: $Activity_, arg1: $ImmutableList<$Pair<number, $BehaviorControl<any>>>): $ActivityData<E>;
        static create<E>(arg0: $Activity_, arg1: number, arg2: $ImmutableList<$BehaviorControl<any>>, arg3: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[]): $ActivityData<E>;
        static create<E>(arg0: $Activity_, arg1: number, arg2: $ImmutableList<$BehaviorControl<any>>, arg3: $MemoryModuleType<any>): $ActivityData<E>;
        static create<E>(arg0: $Activity_, arg1: number, arg2: $ImmutableList<$BehaviorControl<any>>): $ActivityData<E>;
        activityType(): $Activity;
        behaviorPriorityPairs(): $ImmutableList<$Pair<number, $BehaviorControl<any>>>;
        conditions(): $Set<$Pair<$MemoryModuleType<any>, $MemoryStatus>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        memoriesToEraseWhenStopped(): $Set<$MemoryModuleType<any>>;
        toString(): string;
    }

    export class $Brain<E extends $LivingEntity> {
        constructor();
        get activeActivities(): $Set<$Activity>;
        getActiveActivities(): $Set<$Activity>;
        get activeNonCoreActivity(): $Optional<$Activity>;
        getActiveNonCoreActivity(): $Optional<$Activity>;
        get runningBehaviors(): $List<$BehaviorControl<any>>;
        getRunningBehaviors(): $List<$BehaviorControl<any>>;
        get brainDead(): boolean;
        isBrainDead(): boolean;
        static provider<E>(arg0: $MemoryModuleType<any>[], arg1: $SensorType<$Sensor<any>>[], arg2: $Brain$ActivitySupplier<E>): $Brain$Provider<E>;
        static provider<E>(arg0: $SensorType<$Sensor<any>>[], arg1: $Brain$ActivitySupplier<E>): $Brain$Provider<E>;
        static provider<E>(arg0: $SensorType<$Sensor<any>>[]): $Brain$Provider<E>;
        addActivity(arg0: $Activity_, arg1: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, arg2: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[], arg3: $MemoryModuleType<any>[]): void;
        checkMemory(arg0: $MemoryModuleType<any>, arg1: $MemoryStatus_): boolean;
        clearMemories(): void;
        eraseMemory<U>(arg0: $MemoryModuleType<U>): void;
        forEach(arg0: $Brain$Visitor): void;
        getMemoryInternal<U>(arg0: $MemoryModuleType<U>): $Optional<U>;
        getMemory<U>(arg0: $MemoryModuleType<U>): $Optional<U>;
        getTimeUntilExpiry<U>(arg0: $MemoryModuleType<U>): number;
        hasMemoryValue(arg0: $MemoryModuleType<any>): boolean;
        isActive(arg0: $Activity_): boolean;
        isMemoryValue<U>(arg0: $MemoryModuleType<U>, arg1: U): boolean;
        pack(): $Brain$Packed;
        removeAllBehaviors(): void;
        setMemoryWithExpiry<U>(arg0: $MemoryModuleType<U>, arg1: U, arg2: number): void;
        setMemory<U>(arg0: $MemoryModuleType<U>, arg1: U): void;
        setMemory<U>(arg0: $MemoryModuleType<U>, arg1: $Optional<U>): void;
        stopAll(arg0: $ServerLevel, arg1: E): void;
        tick(arg0: $ServerLevel, arg1: E): void;
        updateActivityFromSchedule(arg0: $EnvironmentAttributeSystem, arg1: number, arg2: $Vec3_): void;
        useDefaultActivity(): void;
    }

    export interface $Brain$ActivitySupplier<E extends $LivingEntity> {
        createActivities(arg0: E): $List<$ActivityData<E>>;
    }

    export class $Brain$Packed extends $Record {
        constructor(memories: $MemoryMap);
        static CODEC: $Codec<$Brain$Packed>;
        static EMPTY: $Brain$Packed;
        equals(arg0: object): boolean;
        hashCode(): number;
        memories(): $MemoryMap;
        toString(): string;
    }

    export class $Brain$Provider<E extends $LivingEntity> {
        makeBrain(arg0: E, arg1: $Brain$Packed): $Brain<E>;
    }

    export interface $Brain$Visitor {
        acceptEmpty<U>(arg0: $MemoryModuleType<U>): void;
        accept<U>(arg0: $MemoryModuleType<U>, arg1: U, arg2: number): void;
        accept<U>(arg0: $MemoryModuleType<U>, arg1: U): void;
    }

}
