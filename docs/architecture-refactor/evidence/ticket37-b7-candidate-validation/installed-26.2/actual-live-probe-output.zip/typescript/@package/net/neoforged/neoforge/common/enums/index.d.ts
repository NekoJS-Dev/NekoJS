import { $Enum, $String } from "java:java/lang";

declare module "java:net/neoforged/neoforge/common/enums" {
    export class $BubbleColumnDirection {
        static DOWNWARD: $BubbleColumnDirection;
        static NONE: $BubbleColumnDirection;
        static UPWARD: $BubbleColumnDirection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BubbleColumnDirection[];
        static valueOf(name: string): $BubbleColumnDirection;
    }

    export type $BubbleColumnDirection_ = $BubbleColumnDirection | "DOWNWARD" | "NONE" | "UPWARD";
}
