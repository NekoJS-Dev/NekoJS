import { $GameProfile } from "java:com/mojang/authlib";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Collection, $List, $Map, $Optional } from "java:java/util";
import { $Consumer, $IntFunction } from "java:java/util/function";
import { $Component, $Component_, $MutableComponent, $TextColor } from "java:net/minecraft/network/chat";
import { $NumberFormat } from "java:net/minecraft/network/chat/numbers";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $StringRepresentable, $StringRepresentable$EnumCodec } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";
import { $ObjectiveCriteria, $ObjectiveCriteria$RenderType, $ObjectiveCriteria$RenderType_ } from "java:net/minecraft/world/scores/criteria";

export * as criteria from "java:net/minecraft/world/scores/criteria";

declare module "java:net/minecraft/world/scores" {
    export class $DisplaySlot {
        static BELOW_NAME: $DisplaySlot;
        static LIST: $DisplaySlot;
        static SIDEBAR: $DisplaySlot;
        static TEAM_AQUA: $DisplaySlot;
        static TEAM_BLACK: $DisplaySlot;
        static TEAM_BLUE: $DisplaySlot;
        static TEAM_DARK_AQUA: $DisplaySlot;
        static TEAM_DARK_BLUE: $DisplaySlot;
        static TEAM_DARK_GRAY: $DisplaySlot;
        static TEAM_DARK_GREEN: $DisplaySlot;
        static TEAM_DARK_PURPLE: $DisplaySlot;
        static TEAM_DARK_RED: $DisplaySlot;
        static TEAM_GOLD: $DisplaySlot;
        static TEAM_GRAY: $DisplaySlot;
        static TEAM_GREEN: $DisplaySlot;
        static TEAM_LIGHT_PURPLE: $DisplaySlot;
        static TEAM_RED: $DisplaySlot;
        static TEAM_WHITE: $DisplaySlot;
        static TEAM_YELLOW: $DisplaySlot;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DisplaySlot[];
        static valueOf(name: string): $DisplaySlot;
    }

    export class $Objective {
        constructor(arg0: $Scoreboard, arg1: string, arg2: $ObjectiveCriteria, arg3: $Component_, arg4: $ObjectiveCriteria$RenderType_, arg5: boolean, arg6: $NumberFormat);
        get criteria(): $ObjectiveCriteria;
        getCriteria(): $ObjectiveCriteria;
        get displayName(): $Component;
        getDisplayName(): $Component;
        set displayName(value: $Component_);
        get formattedDisplayName(): $Component;
        getFormattedDisplayName(): $Component;
        get name(): string;
        getName(): string;
        get renderType(): $ObjectiveCriteria$RenderType;
        getRenderType(): $ObjectiveCriteria$RenderType;
        set renderType(value: $ObjectiveCriteria$RenderType_);
        get scoreboard(): $Scoreboard;
        getScoreboard(): $Scoreboard;
        displayAutoUpdate(): boolean;
        numberFormatOrDefault(arg0: $NumberFormat): $NumberFormat;
        numberFormat(): $NumberFormat;
        pack(): $Objective$Packed;
    }

    export class $Objective$Packed extends $Record {
        constructor(name: string, criteria: $ObjectiveCriteria, displayName: $Component_, renderType: $ObjectiveCriteria$RenderType_, displayAutoUpdate: boolean, numberFormat: $Optional<$NumberFormat>);
        static CODEC: $Codec<$Objective$Packed>;
        criteria(): $ObjectiveCriteria;
        displayAutoUpdate(): boolean;
        displayName(): $Component;
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): string;
        numberFormat(): $Optional<$NumberFormat>;
        renderType(): $ObjectiveCriteria$RenderType;
        toString(): string;
    }

    export class $PlayerScoreEntry extends $Record {
        constructor(owner: string, value: number, display: $Component_, numberFormatOverride: $NumberFormat);
        get hidden(): boolean;
        isHidden(): boolean;
        display(): $Component;
        equals(arg0: object): boolean;
        formatValue(arg0: $NumberFormat): $MutableComponent;
        hashCode(): number;
        numberFormatOverride(): $NumberFormat;
        ownerName(): $Component;
        owner(): string;
        toString(): string;
        value(): number;
    }

    export class $PlayerTeam extends $Team {
        constructor(arg0: $Scoreboard, arg1: string);
        get collisionRule(): $Team$CollisionRule;
        getCollisionRule(): $Team$CollisionRule;
        set collisionRule(value: $Team$CollisionRule_);
        get color(): $Optional<$TeamColor>;
        getColor(): $Optional<$TeamColor>;
        set color(value: $Optional<$TeamColor_>);
        get deathMessageVisibility(): $Team$Visibility;
        getDeathMessageVisibility(): $Team$Visibility;
        set deathMessageVisibility(value: $Team$Visibility_);
        get displayName(): $Component;
        getDisplayName(): $Component;
        set displayName(value: $Component_);
        get formattedDisplayName(): $MutableComponent;
        getFormattedDisplayName(): $MutableComponent;
        get nameTagVisibility(): $Team$Visibility;
        getNameTagVisibility(): $Team$Visibility;
        set nameTagVisibility(value: $Team$Visibility_);
        get name(): string;
        getName(): string;
        get playerPrefix(): $Component;
        getPlayerPrefix(): $Component;
        set playerPrefix(value: $Component_);
        get playerSuffix(): $Component;
        getPlayerSuffix(): $Component;
        set playerSuffix(value: $Component_);
        get players(): $Collection<string>;
        getPlayers(): $Collection<string>;
        get scoreboard(): $Scoreboard;
        getScoreboard(): $Scoreboard;
        get allowFriendlyFire(): boolean;
        isAllowFriendlyFire(): boolean;
        set allowFriendlyFire(value: boolean);
        static formatNameForTeam(arg0: $Team, arg1: $Component_): $MutableComponent;
        canSeeFriendlyInvisibles(): boolean;
        getFormattedName(arg0: $Component_): $MutableComponent;
        packOptions(): number;
        pack(): $PlayerTeam$Packed;
        unpackOptions(arg0: number): void;
    }

    export class $PlayerTeam$Packed extends $Record {
        constructor(name: string, displayName: $Optional<$Component_>, color: $Optional<$TeamColor_>, allowFriendlyFire: boolean, seeFriendlyInvisibles: boolean, memberNamePrefix: $Component_, memberNameSuffix: $Component_, nameTagVisibility: $Team$Visibility_, deathMessageVisibility: $Team$Visibility_, collisionRule: $Team$CollisionRule_, players: string[]);
        static CODEC: $Codec<$PlayerTeam$Packed>;
        allowFriendlyFire(): boolean;
        collisionRule(): $Team$CollisionRule;
        color(): $Optional<$TeamColor>;
        deathMessageVisibility(): $Team$Visibility;
        displayName(): $Optional<$Component>;
        equals(arg0: object): boolean;
        hashCode(): number;
        memberNamePrefix(): $Component;
        memberNameSuffix(): $Component;
        nameTagVisibility(): $Team$Visibility;
        name(): string;
        players(): $List<string>;
        seeFriendlyInvisibles(): boolean;
        toString(): string;
    }

    export interface $ReadOnlyScoreInfo {
        formatValue(arg0: $NumberFormat): $MutableComponent;
        isLocked(): boolean;
        numberFormat(): $NumberFormat;
        value(): number;
    }

    export class $Score$Packed extends $Record {
        constructor(value: number, locked: boolean, display: $Optional<$Component_>, numberFormat: $Optional<$NumberFormat>);
        static MAP_CODEC: $MapCodec<$Score$Packed>;
        display(): $Optional<$Component>;
        equals(arg0: object): boolean;
        hashCode(): number;
        locked(): boolean;
        numberFormat(): $Optional<$NumberFormat>;
        toString(): string;
        value(): number;
    }

    export interface $ScoreAccess {
        add(arg0: number): number;
        display(arg0: $Component_): void;
        display(): $Component;
        get(): number;
        increment(): number;
        locked(): boolean;
        lock(): void;
        numberFormatOverride(arg0: $NumberFormat): void;
        reset(): void;
        set(arg0: number): void;
        unlock(): void;
    }

    export interface $ScoreHolder {
        forNameOnly(arg0: string): $ScoreHolder;
        fromGameProfile(arg0: $GameProfile): $ScoreHolder;
        getDisplayName(): $Component;
        getFeedbackDisplayName(): $Component;
        getScoreboardName(): string;
        static WILDCARD: $ScoreHolder;
        static WILDCARD_NAME: string;
    }

    export class $Scoreboard {
        constructor();
        static HIDDEN_SCORE_PREFIX: string;
        get objectiveNames(): $Collection<string>;
        getObjectiveNames(): $Collection<string>;
        get objectives(): $Collection<$Objective>;
        getObjectives(): $Collection<$Objective>;
        get playerTeams(): $Collection<$PlayerTeam>;
        getPlayerTeams(): $Collection<$PlayerTeam>;
        get teamNames(): $Collection<string>;
        getTeamNames(): $Collection<string>;
        get trackedPlayers(): $Collection<$ScoreHolder>;
        getTrackedPlayers(): $Collection<$ScoreHolder>;
        addObjective(arg0: string, arg1: $ObjectiveCriteria, arg2: $Component_, arg3: $ObjectiveCriteria$RenderType_, arg4: boolean, arg5: $NumberFormat): $Objective;
        addPlayerTeam(arg0: string): $PlayerTeam;
        addPlayerToTeam(arg0: string, arg1: $PlayerTeam): boolean;
        entityRemoved(arg0: $Entity): void;
        forAllObjectives(arg0: $ObjectiveCriteria, arg1: $ScoreHolder, arg2: $Consumer<$ScoreAccess>): void;
        getDisplayObjective(arg0: $DisplaySlot_): $Objective;
        getObjective(arg0: string): $Objective;
        getOrCreatePlayerScore(arg0: $ScoreHolder, arg1: $Objective, arg2: boolean): $ScoreAccess;
        getOrCreatePlayerScore(arg0: $ScoreHolder, arg1: $Objective): $ScoreAccess;
        getPlayerScoreInfo(arg0: $ScoreHolder, arg1: $Objective): $ReadOnlyScoreInfo;
        getPlayerTeam(arg0: string): $PlayerTeam;
        getPlayersTeam(arg0: string): $PlayerTeam;
        listPlayerScores(arg0: $Objective): $Collection<$PlayerScoreEntry>;
        listPlayerScores(arg0: $ScoreHolder): $Object2IntMap<$Objective>;
        onObjectiveAdded(arg0: $Objective): void;
        onObjectiveChanged(arg0: $Objective): void;
        onObjectiveRemoved(arg0: $Objective): void;
        onPlayerRemoved(arg0: $ScoreHolder): void;
        onPlayerScoreRemoved(arg0: $ScoreHolder, arg1: $Objective): void;
        onTeamAdded(arg0: $PlayerTeam): void;
        onTeamChanged(arg0: $PlayerTeam): void;
        onTeamRemoved(arg0: $PlayerTeam): void;
        removeObjective(arg0: $Objective): void;
        removePlayerFromTeam(arg0: string, arg1: $PlayerTeam): void;
        removePlayerFromTeam(arg0: string): boolean;
        removePlayerTeam(arg0: $PlayerTeam): void;
        resetAllPlayerScores(arg0: $ScoreHolder): void;
        resetSinglePlayerScore(arg0: $ScoreHolder, arg1: $Objective): void;
        setDisplayObjective(arg0: $DisplaySlot_, arg1: $Objective): void;
    }

    export class $Scoreboard$PackedScore extends $Record {
        constructor(owner: string, objective: string, score: $Score$Packed);
        static CODEC: $Codec<$Scoreboard$PackedScore>;
        equals(arg0: object): boolean;
        hashCode(): number;
        objective(): string;
        owner(): string;
        score(): $Score$Packed;
        toString(): string;
    }

    export class $ScoreboardSaveData extends $SavedData {
        constructor(arg0: $ScoreboardSaveData$Packed);
        static TYPE: $SavedDataType<$ScoreboardSaveData>;
        get data(): $ScoreboardSaveData$Packed;
        getData(): $ScoreboardSaveData$Packed;
        set data(value: $ScoreboardSaveData$Packed);
    }

    export class $ScoreboardSaveData$Packed extends $Record {
        constructor(objectives: $Objective$Packed[], scores: $Scoreboard$PackedScore[], displaySlots: { [key: $DisplaySlot_]: string }, teams: $PlayerTeam$Packed[]);
        static CODEC: $Codec<$ScoreboardSaveData$Packed>;
        static EMPTY: $ScoreboardSaveData$Packed;
        displaySlots(): $Map<$DisplaySlot, string>;
        equals(arg0: object): boolean;
        hashCode(): number;
        objectives(): $List<$Objective$Packed>;
        scores(): $List<$Scoreboard$PackedScore>;
        teams(): $List<$PlayerTeam$Packed>;
        toString(): string;
    }

    export class $Team {
        constructor();
        get collisionRule(): $Team$CollisionRule;
        getCollisionRule(): $Team$CollisionRule;
        get color(): $Optional<$TeamColor>;
        getColor(): $Optional<$TeamColor>;
        get deathMessageVisibility(): $Team$Visibility;
        getDeathMessageVisibility(): $Team$Visibility;
        get nameTagVisibility(): $Team$Visibility;
        getNameTagVisibility(): $Team$Visibility;
        get name(): string;
        getName(): string;
        get players(): $Collection<string>;
        getPlayers(): $Collection<string>;
        get allowFriendlyFire(): boolean;
        isAllowFriendlyFire(): boolean;
        canSeeFriendlyInvisibles(): boolean;
        getFormattedName(arg0: $Component_): $MutableComponent;
        isAlliedTo(arg0: $Team): boolean;
    }

    export class $Team$CollisionRule {
        static ALWAYS: $Team$CollisionRule;
        static NEVER: $Team$CollisionRule;
        static PUSH_OTHER_TEAMS: $Team$CollisionRule;
        static PUSH_OWN_TEAM: $Team$CollisionRule;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Team$CollisionRule[];
        static valueOf(name: string): $Team$CollisionRule;
    }

    export class $Team$Visibility {
        static ALWAYS: $Team$Visibility;
        static HIDE_FOR_OTHER_TEAMS: $Team$Visibility;
        static HIDE_FOR_OWN_TEAM: $Team$Visibility;
        static NEVER: $Team$Visibility;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Team$Visibility[];
        static valueOf(name: string): $Team$Visibility;
    }

    export class $TeamColor {
        static AQUA: $TeamColor;
        static BLACK: $TeamColor;
        static BLUE: $TeamColor;
        static DARK_AQUA: $TeamColor;
        static DARK_BLUE: $TeamColor;
        static DARK_GRAY: $TeamColor;
        static DARK_GREEN: $TeamColor;
        static DARK_PURPLE: $TeamColor;
        static DARK_RED: $TeamColor;
        static GOLD: $TeamColor;
        static GRAY: $TeamColor;
        static GREEN: $TeamColor;
        static LIGHT_PURPLE: $TeamColor;
        static RED: $TeamColor;
        static WHITE: $TeamColor;
        static YELLOW: $TeamColor;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TeamColor[];
        static valueOf(name: string): $TeamColor;
    }

    export type $DisplaySlot_ = $DisplaySlot | "BELOW_NAME" | "LIST" | "SIDEBAR" | "TEAM_AQUA" | "TEAM_BLACK" | "TEAM_BLUE" | "TEAM_DARK_AQUA" | "TEAM_DARK_BLUE" | "TEAM_DARK_GRAY" | "TEAM_DARK_GREEN" | "TEAM_DARK_PURPLE" | "TEAM_DARK_RED" | "TEAM_GOLD" | "TEAM_GRAY" | "TEAM_GREEN" | "TEAM_LIGHT_PURPLE" | "TEAM_RED" | "TEAM_WHITE" | "TEAM_YELLOW";
    export type $Team$CollisionRule_ = $Team$CollisionRule | "ALWAYS" | "NEVER" | "PUSH_OTHER_TEAMS" | "PUSH_OWN_TEAM";
    export type $Team$Visibility_ = $Team$Visibility | "ALWAYS" | "HIDE_FOR_OTHER_TEAMS" | "HIDE_FOR_OWN_TEAM" | "NEVER";
    export type $TeamColor_ = $TeamColor | "AQUA" | "BLACK" | "BLUE" | "DARK_AQUA" | "DARK_BLUE" | "DARK_GRAY" | "DARK_GREEN" | "DARK_PURPLE" | "DARK_RED" | "GOLD" | "GRAY" | "GREEN" | "LIGHT_PURPLE" | "RED" | "WHITE" | "YELLOW";
}
