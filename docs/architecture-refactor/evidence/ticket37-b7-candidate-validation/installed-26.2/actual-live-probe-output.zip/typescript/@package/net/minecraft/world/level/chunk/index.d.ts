import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $LongSet } from "java:it/unimi/dsi/fastutil/longs";
import { $ShortList } from "java:it/unimi/dsi/fastutil/shorts";
import { $AutoCloseable, $Enum, $Record, $String } from "java:java/lang";
import { $Collection, $List, $Map, $Map$Entry, $Optional, $Set } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $BiConsumer, $BiPredicate, $BooleanSupplier, $Consumer, $Function, $Predicate, $Supplier } from "java:java/util/function";
import { $LongStream, $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Holder, $HolderLookup, $HolderLookup$Provider, $HolderSet, $Holder_, $IdMap, $RegistryAccess, $SectionPos } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $ClientboundLevelChunkPacketData$BlockEntityTagOutput } from "java:net/minecraft/network/protocol/game";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $FullChunkStatus, $FullChunkStatus_, $ServerLevel, $WorldGenRegion } from "java:net/minecraft/server/level";
import { $ProblemReporter$PathElement } from "java:net/minecraft/util";
import { $DebugValueSource, $DebugValueSource$Registration } from "java:net/minecraft/util/debug";
import { $WeightedList } from "java:net/minecraft/util/random";
import { $Entity, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $BlockGetter, $ChunkPos, $Level, $LevelHeightAccessor, $LightLayer, $LightLayer_, $NoiseColumn, $StructureManager, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Biome, $BiomeGenerationSettings, $BiomeManager, $BiomeManager$NoiseBiomeSource, $BiomeResolver, $BiomeSource, $Climate$Sampler, $MobSpawnSettings$SpawnerData } from "java:net/minecraft/world/level/biome";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";
import { $GameEventListenerRegistry } from "java:net/minecraft/world/level/gameevent";
import { $BelowZeroRetrogen, $Heightmap, $Heightmap$Types, $Heightmap$Types_, $NoiseChunk, $RandomState } from "java:net/minecraft/world/level/levelgen";
import { $Blender, $BlendingData } from "java:net/minecraft/world/level/levelgen/blending";
import { $Structure, $StructureSet, $StructureStart } from "java:net/minecraft/world/level/levelgen/structure";
import { $ConcentricRingsStructurePlacement, $StructurePlacement } from "java:net/minecraft/world/level/levelgen/structure/placement";
import { $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";
import { $ChunkSkyLightSources, $LevelLightEngine } from "java:net/minecraft/world/level/lighting";
import { $Fluid, $FluidState, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $LevelChunkTicks, $SavedTick, $TickContainerAccess } from "java:net/minecraft/world/ticks";
import { $AttachmentHolder$AsField, $AttachmentType, $IAttachmentHolder } from "java:net/neoforged/neoforge/attachment";
import { $LevelChunkAuxiliaryLightManager } from "java:net/neoforged/neoforge/common/world";

export * as status from "java:net/minecraft/world/level/chunk/status";
export * as storage from "java:net/minecraft/world/level/chunk/storage";

declare module "java:net/minecraft/world/level/chunk" {
    export interface $BlockColumn {
        getBlock(arg0: number): $BlockState;
        setBlock(arg0: number, arg1: $BlockState_): void;
    }

    export class $CarvingMask {
        constructor(arg0: number, arg1: number);
        constructor(arg0: number[], arg1: number);
        get(arg0: number, arg1: number, arg2: number): boolean;
        set(arg0: number, arg1: number, arg2: number): void;
        stream(arg0: $ChunkPos): $Stream<$BlockPos>;
        toArray(): number[];
    }

    export interface $CarvingMask$Mask {
        test(arg0: number, arg1: number, arg2: number): boolean;
    }

    export class $ChunkAccess implements $LightChunk, $StructureAccess, $BiomeManager$NoiseBiomeSource, $IAttachmentHolder {
        constructor(arg0: $ChunkPos, arg1: $UpgradeData, arg2: $LevelHeightAccessor, arg3: $PalettedContainerFactory, arg4: number, arg5: $LevelChunkSection[], arg6: $BlendingData);
        static NO_FILLED_SECTION: number;
        get allReferences(): $Map<$Structure, $LongSet>;
        getAllReferences(): $Map<$Structure, $LongSet>;
        set allReferences(value: { [key: $Structure]: $LongSet });
        get allStarts(): $Map<$Structure, $StructureStart>;
        getAllStarts(): $Map<$Structure, $StructureStart>;
        set allStarts(value: { [key: $Structure]: $StructureStart });
        get attachmentHolder(): $AttachmentHolder$AsField;
        getAttachmentHolder(): $AttachmentHolder$AsField;
        get belowZeroRetrogen(): $BelowZeroRetrogen;
        getBelowZeroRetrogen(): $BelowZeroRetrogen;
        get blendingData(): $BlendingData;
        getBlendingData(): $BlendingData;
        get blockEntitiesPos(): $Set<$BlockPos>;
        getBlockEntitiesPos(): $Set<$BlockPos>;
        get blockTicks(): $TickContainerAccess<$Block>;
        getBlockTicks(): $TickContainerAccess<$Block>;
        get fluidTicks(): $TickContainerAccess<$Fluid>;
        getFluidTicks(): $TickContainerAccess<$Fluid>;
        get heightAccessorForGeneration(): $LevelHeightAccessor;
        getHeightAccessorForGeneration(): $LevelHeightAccessor;
        get heightmaps(): $Collection<$Map$Entry<$Heightmap$Types, $Heightmap>>;
        getHeightmaps(): $Collection<$Map$Entry<$Heightmap$Types, $Heightmap>>;
        get height(): number;
        getHeight(): number;
        get highestFilledSectionIndex(): number;
        getHighestFilledSectionIndex(): number;
        get highestGeneratedStatus(): $ChunkStatus;
        getHighestGeneratedStatus(): $ChunkStatus;
        get highestSectionPosition(): number;
        getHighestSectionPosition(): number;
        get inhabitedTime(): number;
        getInhabitedTime(): number;
        set inhabitedTime(value: number);
        get level(): $Level;
        getLevel(): $Level;
        get minY(): number;
        getMinY(): number;
        get persistedStatus(): $ChunkStatus;
        getPersistedStatus(): $ChunkStatus;
        get postProcessing(): $ShortList[];
        getPostProcessing(): $ShortList[];
        get pos(): $ChunkPos;
        getPos(): $ChunkPos;
        get sections(): $LevelChunkSection[];
        getSections(): $LevelChunkSection[];
        get skyLightSources(): $ChunkSkyLightSources;
        getSkyLightSources(): $ChunkSkyLightSources;
        get upgradeData(): $UpgradeData;
        getUpgradeData(): $UpgradeData;
        get lightCorrect(): boolean;
        isLightCorrect(): boolean;
        set lightCorrect(value: boolean);
        get oldNoiseGeneration(): boolean;
        isOldNoiseGeneration(): boolean;
        get unsaved(): boolean;
        isUnsaved(): boolean;
        get upgrading(): boolean;
        isUpgrading(): boolean;
        static getOrCreateOffsetList(arg0: $ShortList[], arg1: number): $ShortList;
        static problemPath(arg0: $ChunkPos): $ProblemReporter$PathElement;
        addEntity(arg0: $Entity): void;
        addPackedPostProcess(arg0: $ShortList, arg1: number): void;
        addReferenceForStructure(arg0: $Structure, arg1: number): void;
        canBeSerialized(): boolean;
        carverBiome(arg0: $Supplier<$BiomeGenerationSettings>): $BiomeGenerationSettings;
        collectBiomesInPalette(arg0: $Holder<$Biome>[]): void;
        fillBiomesFromNoise(arg0: $BiomeResolver, arg1: $Climate$Sampler): void;
        findBlockLightSources(arg0: $BiConsumer<$BlockPos_, $BlockState_>): void;
        findBlocks(arg0: $Predicate<$BlockState_>, arg1: $BiConsumer<$BlockPos_, $BlockState_>): void;
        findBlocks(arg0: $Predicate<$BlockState_>, arg1: $BiPredicate<$BlockState_, $BlockPos_>, arg2: $BiConsumer<$BlockPos_, $BlockState_>): void;
        getBlockEntityNbtForSaving(arg0: $BlockPos_, arg1: $HolderLookup$Provider): $CompoundTag;
        getBlockEntityNbt(arg0: $BlockPos_): $CompoundTag;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getListenerRegistry(arg0: number): $GameEventListenerRegistry;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getOrCreateHeightmapUnprimed(arg0: $Heightmap$Types_): $Heightmap;
        getOrCreateNoiseChunk(arg0: $Function<$ChunkAccess, $NoiseChunk>): $NoiseChunk;
        getReferencesForStructure(arg0: $Structure): $LongSet;
        getSection(arg0: number): $LevelChunkSection;
        getStartForStructure(arg0: $Structure): $StructureStart;
        getTicksForSerialization(arg0: number): $ChunkAccess$PackedTicks;
        hasAnyStructureReferences(): boolean;
        hasAttachments(): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        hasPrimedHeightmap(arg0: $Heightmap$Types_): boolean;
        incrementInhabitedTime(arg0: number): void;
        initializeLightSources(): void;
        isYSpaceEmpty(arg0: number, arg1: number): boolean;
        markPosForPostProcessing(arg0: $BlockPos_): void;
        markUnsaved(): void;
        problemPath(): $ProblemReporter$PathElement;
        readAttachmentsFromNBT(arg0: $HolderLookup$Provider, arg1: $CompoundTag_): void;
        removeBlockEntity(arg0: $BlockPos_): void;
        removeData<T>(arg0: $AttachmentType<T>): T;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_, arg2: number): $BlockState;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_): $BlockState;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        setHeightmap(arg0: $Heightmap$Types_, arg1: number[]): void;
        setStartForStructure(arg0: $Structure, arg1: $StructureStart): void;
        tryMarkSaved(): boolean;
        writeAttachmentsToNBT(arg0: $HolderLookup$Provider): $CompoundTag;
    }

    export class $ChunkAccess$PackedTicks extends $Record {
        constructor(blocks: $SavedTick<$Block_>[], fluids: $SavedTick<$Fluid_>[]);
        blocks(): $List<$SavedTick<$Block>>;
        equals(arg0: object): boolean;
        fluids(): $List<$SavedTick<$Fluid>>;
        hashCode(): number;
        toString(): string;
    }

    export class $ChunkGenerator {
        constructor(arg0: $BiomeSource);
        constructor(arg0: $BiomeSource, arg1: $Function<$Holder<$Biome>, $BiomeGenerationSettings>);
        static CODEC: $Codec<$ChunkGenerator>;
        get biomeSource(): $BiomeSource;
        getBiomeSource(): $BiomeSource;
        get genDepth(): number;
        getGenDepth(): number;
        get minY(): number;
        getMinY(): number;
        get seaLevel(): number;
        getSeaLevel(): number;
        get typeNameForDataFixer(): $Optional<$Identifier>;
        getTypeNameForDataFixer(): $Optional<$Identifier>;
        addDebugScreenInfo(arg0: string[], arg1: $RandomState, arg2: $BlockPos_): void;
        applyBiomeDecoration(arg0: $WorldGenLevel, arg1: $ChunkAccess, arg2: $StructureManager): void;
        applyCarvers(arg0: $WorldGenRegion, arg1: number, arg2: $RandomState, arg3: $BiomeManager, arg4: $StructureManager, arg5: $ChunkAccess): void;
        buildSurface(arg0: $WorldGenRegion, arg1: $StructureManager, arg2: $RandomState, arg3: $ChunkAccess): void;
        createBiomes(arg0: $RandomState, arg1: $Blender, arg2: $StructureManager, arg3: $ChunkAccess): $CompletableFuture<$ChunkAccess>;
        createReferences(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkAccess): void;
        createState(arg0: $HolderLookup<$StructureSet>, arg1: $RandomState, arg2: number): $ChunkGeneratorStructureState;
        createStructures(arg0: $RegistryAccess, arg1: $ChunkGeneratorStructureState, arg2: $StructureManager, arg3: $ChunkAccess, arg4: $StructureTemplateManager, arg5: $ResourceKey<$Level>): void;
        fillFromNoise(arg0: $Blender, arg1: $RandomState, arg2: $StructureManager, arg3: $ChunkAccess): $CompletableFuture<$ChunkAccess>;
        findNearestMapStructure(arg0: $ServerLevel, arg1: $HolderSet<$Structure>, arg2: $BlockPos_, arg3: number, arg4: boolean): $Pair<$BlockPos, $Holder<$Structure>>;
        getBaseColumn(arg0: number, arg1: number, arg2: $LevelHeightAccessor, arg3: $RandomState): $NoiseColumn;
        getBaseHeight(arg0: number, arg1: number, arg2: $Heightmap$Types_, arg3: $LevelHeightAccessor, arg4: $RandomState): number;
        getBiomeGenerationSettings(arg0: $Holder<$Biome>): $BiomeGenerationSettings;
        getFirstFreeHeight(arg0: number, arg1: number, arg2: $Heightmap$Types_, arg3: $LevelHeightAccessor, arg4: $RandomState): number;
        getFirstOccupiedHeight(arg0: number, arg1: number, arg2: $Heightmap$Types_, arg3: $LevelHeightAccessor, arg4: $RandomState): number;
        getMobsAt(arg0: $Holder<$Biome>, arg1: $StructureManager, arg2: $MobCategory_, arg3: $BlockPos_): $WeightedList<$MobSpawnSettings$SpawnerData>;
        getSpawnHeight(arg0: $LevelHeightAccessor): number;
        refreshFeaturesPerStep(): void;
        spawnOriginalMobs(arg0: $WorldGenRegion): void;
        validate(): void;
    }

    export class $ChunkGeneratorStructureState {
        get levelSeed(): number;
        getLevelSeed(): number;
        static createForFlat(arg0: $RandomState, arg1: number, arg2: $BiomeSource, arg3: $Stream<$Holder<$StructureSet>>): $ChunkGeneratorStructureState;
        static createForNormal(arg0: $RandomState, arg1: number, arg2: $BiomeSource, arg3: $HolderLookup<$StructureSet>): $ChunkGeneratorStructureState;
        ensureStructuresGenerated(): void;
        getPlacementsForStructure(arg0: $Holder<$Structure>): $List<$StructurePlacement>;
        getRingPositionsFor(arg0: $ConcentricRingsStructurePlacement): $List<$ChunkPos>;
        hasStructureChunkInRange(arg0: $Holder<$StructureSet>, arg1: number, arg2: number, arg3: number): boolean;
        possibleStructureSets(): $List<$Holder<$StructureSet>>;
        randomState(): $RandomState;
    }

    export class $ChunkSource implements $AutoCloseable, $LightChunkGetter {
        constructor();
        get forceLoadedChunks(): $LongSet;
        getForceLoadedChunks(): $LongSet;
        get lightEngine(): $LevelLightEngine;
        getLightEngine(): $LevelLightEngine;
        get loadedChunksCount(): number;
        getLoadedChunksCount(): number;
        close(): void;
        gatherStats(): string;
        getChunkForLighting(arg0: number, arg1: number): $LightChunk;
        getChunkNow(arg0: number, arg1: number): $LevelChunk;
        getChunk(arg0: number, arg1: number, arg2: boolean): $LevelChunk;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_, arg3: boolean): $ChunkAccess;
        hasChunk(arg0: number, arg1: number): boolean;
        onSectionEmptinessChanged(arg0: number, arg1: number, arg2: number, arg3: boolean): void;
        tick(arg0: $BooleanSupplier, arg1: boolean): void;
        updateChunkForced(arg0: $ChunkPos, arg1: boolean): boolean;
    }

    export class $DataLayer {
        constructor();
        constructor(arg0: number[]);
        constructor(arg0: number);
        static LAYER_COUNT: number;
        static LAYER_SIZE: number;
        static SIZE: number;
        get data(): number[];
        getData(): number[];
        get definitelyHomogenous(): boolean;
        isDefinitelyHomogenous(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        copy(): $DataLayer;
        fill(arg0: number): void;
        get(arg0: number, arg1: number, arg2: number): number;
        isDefinitelyFilledWith(arg0: number): boolean;
        layerToString(arg0: number): string;
        set(arg0: number, arg1: number, arg2: number, arg3: number): void;
        toString(): string;
    }

    export class $GlobalPalette<T> implements $Palette {
        constructor(arg0: $IdMap<T>);
        get size(): number;
        getSize(): number;
        copy(): $Palette<T>;
        getSerializedSize(arg0: $IdMap<T>): number;
        idFor(arg0: T, arg1: $PaletteResize<T>): number;
        maybeHas(arg0: $Predicate<T>): boolean;
        read(arg0: $FriendlyByteBuf, arg1: $IdMap<T>): void;
        valueFor(arg0: number): T;
        write(arg0: $FriendlyByteBuf, arg1: $IdMap<T>): void;
    }

    export class $ImposterProtoChunk extends $ProtoChunk {
        constructor(arg0: $LevelChunk, arg1: boolean);
        get allReferences(): $Map<$Structure, $LongSet>;
        getAllReferences(): $Map<$Structure, $LongSet>;
        set allReferences(value: { [key: $Structure]: $LongSet });
        get allStarts(): $Map<$Structure, $StructureStart>;
        getAllStarts(): $Map<$Structure, $StructureStart>;
        set allStarts(value: { [key: $Structure]: $StructureStart });
        get attachmentHolder(): $AttachmentHolder$AsField;
        getAttachmentHolder(): $AttachmentHolder$AsField;
        get blendingData(): $BlendingData;
        getBlendingData(): $BlendingData;
        get blockTicks(): $TickContainerAccess<$Block>;
        getBlockTicks(): $TickContainerAccess<$Block>;
        get carvingMask(): $CarvingMask;
        getCarvingMask(): $CarvingMask;
        get fluidTicks(): $TickContainerAccess<$Fluid>;
        getFluidTicks(): $TickContainerAccess<$Fluid>;
        get orCreateCarvingMask(): $CarvingMask;
        getOrCreateCarvingMask(): $CarvingMask;
        get persistedStatus(): $ChunkStatus;
        getPersistedStatus(): $ChunkStatus;
        set persistedStatus(value: $ChunkStatus_);
        get pos(): $ChunkPos;
        getPos(): $ChunkPos;
        get sections(): $LevelChunkSection[];
        getSections(): $LevelChunkSection[];
        get skyLightSources(): $ChunkSkyLightSources;
        getSkyLightSources(): $ChunkSkyLightSources;
        get wrapped(): $LevelChunk;
        getWrapped(): $LevelChunk;
        get lightCorrect(): boolean;
        isLightCorrect(): boolean;
        set lightCorrect(value: boolean);
        get unsaved(): boolean;
        isUnsaved(): boolean;
        addEntity(arg0: $Entity): void;
        addReferenceForStructure(arg0: $Structure, arg1: number): void;
        canBeSerialized(): boolean;
        fillBiomesFromNoise(arg0: $BiomeResolver, arg1: $Climate$Sampler): void;
        findBlocks(arg0: $Predicate<$BlockState_>, arg1: $BiConsumer<$BlockPos_, $BlockState_>): void;
        findBlocks(arg0: $Predicate<$BlockState_>, arg1: $BiPredicate<$BlockState_, $BlockPos_>, arg2: $BiConsumer<$BlockPos_, $BlockState_>): void;
        getBlockEntityNbtForSaving(arg0: $BlockPos_, arg1: $HolderLookup$Provider): $CompoundTag;
        getBlockEntityNbt(arg0: $BlockPos_): $CompoundTag;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getOrCreateHeightmapUnprimed(arg0: $Heightmap$Types_): $Heightmap;
        getReferencesForStructure(arg0: $Structure): $LongSet;
        getSection(arg0: number): $LevelChunkSection;
        getStartForStructure(arg0: $Structure): $StructureStart;
        getTicksForSerialization(arg0: number): $ChunkAccess$PackedTicks;
        initializeLightSources(): void;
        markPosForPostProcessing(arg0: $BlockPos_): void;
        markUnsaved(): void;
        removeBlockEntity(arg0: $BlockPos_): void;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_, arg2: number): $BlockState;
        setHeightmap(arg0: $Heightmap$Types_, arg1: number[]): void;
        setStartForStructure(arg0: $Structure, arg1: $StructureStart): void;
        tryMarkSaved(): boolean;
    }

    export class $LevelChunk extends $ChunkAccess implements $DebugValueSource, $IAttachmentHolder {
        constructor(arg0: $ServerLevel, arg1: $ProtoChunk, arg2: $LevelChunk$PostLoadProcessor);
        constructor(arg0: $Level, arg1: $ChunkPos);
        constructor(arg0: $Level, arg1: $ChunkPos, arg2: $UpgradeData, arg3: $LevelChunkTicks<$Block_>, arg4: $LevelChunkTicks<$Fluid_>, arg5: number, arg6: $LevelChunkSection[], arg7: $LevelChunk$PostLoadProcessor, arg8: $BlendingData);
        get blockEntities(): $Map<$BlockPos, $BlockEntity>;
        getBlockEntities(): $Map<$BlockPos, $BlockEntity>;
        get blockTicks(): $TickContainerAccess<$Block>;
        getBlockTicks(): $TickContainerAccess<$Block>;
        get fluidTicks(): $TickContainerAccess<$Fluid>;
        getFluidTicks(): $TickContainerAccess<$Fluid>;
        get fullStatus(): $FullChunkStatus;
        getFullStatus(): $FullChunkStatus;
        set fullStatus(value: $Supplier<$FullChunkStatus_>);
        get level(): $Level;
        getLevel(): $Level;
        get persistedStatus(): $ChunkStatus;
        getPersistedStatus(): $ChunkStatus;
        get empty(): boolean;
        isEmpty(): boolean;
        addAndRegisterBlockEntity(arg0: $BlockEntity): void;
        addEntity(arg0: $Entity): void;
        clearAllBlockEntities(): void;
        getAuxLightManager(arg0: $ChunkPos): $LevelChunkAuxiliaryLightManager;
        getBlockEntityNbtForSaving(arg0: $BlockPos_, arg1: $HolderLookup$Provider): $CompoundTag;
        getBlockEntity(arg0: $BlockPos_, arg1: $LevelChunk$EntityCreationType_): $BlockEntity;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getFluidState(arg0: number, arg1: number, arg2: number): $FluidState;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getListenerRegistry(arg0: number): $GameEventListenerRegistry;
        getTicksForSerialization(arg0: number): $ChunkAccess$PackedTicks;
        markUnsaved(): void;
        postProcessGeneration(arg0: $ServerLevel): void;
        registerAllBlockEntitiesAfterLevelLoad(): void;
        registerDebugValues(arg0: $ServerLevel, arg1: $DebugValueSource$Registration): void;
        registerTickContainerInLevel(arg0: $ServerLevel): void;
        removeBlockEntity(arg0: $BlockPos_): void;
        replaceBiomes(arg0: $FriendlyByteBuf): void;
        replaceWithPacketData(arg0: $FriendlyByteBuf, arg1: { [key: $Heightmap$Types_]: number[] }, arg2: $Consumer<$ClientboundLevelChunkPacketData$BlockEntityTagOutput>): void;
        runPostLoad(): void;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_, arg2: number): $BlockState;
        syncData(arg0: $AttachmentType<any>): void;
        unpackTicks(arg0: number): void;
        unregisterTickContainerFromLevel(arg0: $ServerLevel): void;
    }

    export class $LevelChunk$EntityCreationType {
        static CHECK: $LevelChunk$EntityCreationType;
        static IMMEDIATE: $LevelChunk$EntityCreationType;
        static QUEUED: $LevelChunk$EntityCreationType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LevelChunk$EntityCreationType[];
        static valueOf(name: string): $LevelChunk$EntityCreationType;
    }

    export interface $LevelChunk$PostLoadProcessor {
        run(arg0: $LevelChunk): void;
    }

    export interface $LevelChunk$UnsavedListener {
        setUnsaved(arg0: $ChunkPos): void;
    }

    export class $LevelChunkSection {
        constructor(arg0: $PalettedContainer<$BlockState_>, arg1: $PalettedContainerRO<$Holder<$Biome>>);
        constructor(arg0: $PalettedContainerFactory);
        static BIOME_CONTAINER_BITS: number;
        get biomes(): $PalettedContainerRO<$Holder<$Biome>>;
        getBiomes(): $PalettedContainerRO<$Holder<$Biome>>;
        get serializedSize(): number;
        getSerializedSize(): number;
        get states(): $PalettedContainer<$BlockState>;
        getStates(): $PalettedContainer<$BlockState>;
        get randomlyTickingBlocks(): boolean;
        isRandomlyTickingBlocks(): boolean;
        get randomlyTickingFluids(): boolean;
        isRandomlyTickingFluids(): boolean;
        get randomlyTicking(): boolean;
        isRandomlyTicking(): boolean;
        acquire(): void;
        copy(): $LevelChunkSection;
        fillBiomesFromNoise(arg0: $BiomeResolver, arg1: $Climate$Sampler, arg2: number, arg3: number, arg4: number): void;
        getBlockState(arg0: number, arg1: number, arg2: number): $BlockState;
        getFluidState(arg0: number, arg1: number, arg2: number): $FluidState;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        hasFluid(): boolean;
        hasOnlyAir(): boolean;
        maybeHas(arg0: $Predicate<$BlockState_>): boolean;
        readBiomes(arg0: $FriendlyByteBuf): void;
        read(arg0: $FriendlyByteBuf): void;
        recalcBlockCounts(): void;
        release(): void;
        setBlockState(arg0: number, arg1: number, arg2: number, arg3: $BlockState_, arg4: boolean): $BlockState;
        setBlockState(arg0: number, arg1: number, arg2: number, arg3: $BlockState_): $BlockState;
        write(arg0: $FriendlyByteBuf): void;
    }

    export interface $LightChunk extends $BlockGetter {
        findBlockLightSources(arg0: $BiConsumer<$BlockPos_, $BlockState_>): void;
        getSkyLightSources(): $ChunkSkyLightSources;
    }

    export interface $LightChunkGetter {
        getChunkForLighting(arg0: number, arg1: number): $LightChunk;
        getLevel(): $BlockGetter;
        onLightUpdate(arg0: $LightLayer_, arg1: $SectionPos): void;
    }

    export interface $Palette<T> {
        copy(): $Palette<T>;
        getSerializedSize(arg0: $IdMap<T>): number;
        getSize(): number;
        idFor(arg0: T, arg1: $PaletteResize<T>): number;
        maybeHas(arg0: $Predicate<T>): boolean;
        read(arg0: $FriendlyByteBuf, arg1: $IdMap<T>): void;
        valueFor(arg0: number): T;
        write(arg0: $FriendlyByteBuf, arg1: $IdMap<T>): void;
    }

    export interface $PaletteResize<T> {
        noResizeExpected<T>(): $PaletteResize<T>;
        onResize(arg0: number, arg1: T): number;
    }

    export class $PalettedContainer<T> implements $PaletteResize, $PalettedContainerRO {
        constructor(arg0: T, arg1: $Strategy<T>);
        get serializedSize(): number;
        getSerializedSize(): number;
        static codecRO<T>(arg0: $Codec<T>, arg1: $Strategy<T>, arg2: T): $Codec<$PalettedContainerRO<T>>;
        static codecRW<T>(arg0: $Codec<T>, arg1: $Strategy<T>, arg2: T): $Codec<$PalettedContainer<T>>;
        static unpack<T>(arg0: $Strategy<T>, arg1: $PalettedContainerRO$PackedData<T>): $DataResult<$PalettedContainer<T>>;
        acquire(): void;
        bitsPerEntry(): number;
        copy(): $PalettedContainer<T>;
        count(arg0: $PalettedContainer$CountConsumer<T>): void;
        forEachInPalette(arg0: $Consumer<T>): void;
        getAll(arg0: $Consumer<T>): void;
        getAndSetUnchecked(arg0: number, arg1: number, arg2: number, arg3: T): T;
        getAndSet(arg0: number, arg1: number, arg2: number, arg3: T): T;
        get(arg0: number, arg1: number, arg2: number): T;
        maybeHas(arg0: $Predicate<T>): boolean;
        onResize(arg0: number, arg1: T): number;
        pack(arg0: $Strategy<T>): $PalettedContainerRO$PackedData<T>;
        read(arg0: $FriendlyByteBuf): void;
        recreate(): $PalettedContainer<T>;
        release(): void;
        set(arg0: number, arg1: number, arg2: number, arg3: T): void;
        write(arg0: $FriendlyByteBuf): void;
    }

    export interface $PalettedContainer$CountConsumer<T> {
        accept(arg0: T, arg1: number): void;
    }

    export class $PalettedContainerFactory extends $Record {
        constructor(blockStatesStrategy: $Strategy<$BlockState_>, defaultBlockState: $BlockState_, blockStatesContainerCodec: $Codec<$PalettedContainer<$BlockState_>>, biomeStrategy: $Strategy<$Holder<$Biome>>, defaultBiome: $Holder<$Biome>, biomeContainerCodec: $Codec<$PalettedContainerRO<$Holder<$Biome>>>);
        static create(arg0: $RegistryAccess): $PalettedContainerFactory;
        biomeContainerCodec(): $Codec<$PalettedContainerRO<$Holder<$Biome>>>;
        biomeStrategy(): $Strategy<$Holder<$Biome>>;
        blockStatesContainerCodec(): $Codec<$PalettedContainer<$BlockState>>;
        blockStatesStrategy(): $Strategy<$BlockState>;
        createForBiomes(): $PalettedContainer<$Holder<$Biome>>;
        createForBlockStates(): $PalettedContainer<$BlockState>;
        defaultBiome(): $Holder<$Biome>;
        defaultBlockState(): $BlockState;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $PalettedContainerRO<T> {
        bitsPerEntry(): number;
        copy(): $PalettedContainer<T>;
        count(arg0: $PalettedContainer$CountConsumer<T>): void;
        forEachInPalette(arg0: $Consumer<T>): void;
        getAll(arg0: $Consumer<T>): void;
        getSerializedSize(): number;
        get(arg0: number, arg1: number, arg2: number): T;
        maybeHas(arg0: $Predicate<T>): boolean;
        pack(arg0: $Strategy<T>): $PalettedContainerRO$PackedData<T>;
        recreate(): $PalettedContainer<T>;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $PalettedContainerRO$PackedData<T> extends $Record {
        constructor(arg0: T[], arg1: $Optional<$LongStream>);
        constructor(paletteEntries: T[], storage: $Optional<$LongStream>, bitsPerEntry: number);
        static UNKNOWN_BITS_PER_ENTRY: number;
        bitsPerEntry(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        paletteEntries(): $List<T>;
        storage(): $Optional<$LongStream>;
        toString(): string;
    }

    export class $ProtoChunk extends $ChunkAccess {
        constructor(arg0: $ChunkPos, arg1: $UpgradeData, arg2: $LevelHeightAccessor, arg3: $PalettedContainerFactory, arg4: $BlendingData);
        constructor(arg0: $ChunkPos, arg1: $UpgradeData, arg2: $LevelChunkSection[], arg3: $ProtoChunkTicks<$Block_>, arg4: $ProtoChunkTicks<$Fluid_>, arg5: $LevelHeightAccessor, arg6: $PalettedContainerFactory, arg7: $BlendingData);
        get belowZeroRetrogen(): $BelowZeroRetrogen;
        getBelowZeroRetrogen(): $BelowZeroRetrogen;
        set belowZeroRetrogen(value: $BelowZeroRetrogen);
        get blockEntities(): $Map<$BlockPos, $BlockEntity>;
        getBlockEntities(): $Map<$BlockPos, $BlockEntity>;
        get blockEntityNbts(): $Map<$BlockPos, $CompoundTag>;
        getBlockEntityNbts(): $Map<$BlockPos, $CompoundTag>;
        get blockTicks(): $TickContainerAccess<$Block>;
        getBlockTicks(): $TickContainerAccess<$Block>;
        get carvingMask(): $CarvingMask;
        getCarvingMask(): $CarvingMask;
        set carvingMask(value: $CarvingMask);
        get entities(): $List<$CompoundTag>;
        getEntities(): $List<$CompoundTag>;
        get fluidTicks(): $TickContainerAccess<$Fluid>;
        getFluidTicks(): $TickContainerAccess<$Fluid>;
        get heightAccessorForGeneration(): $LevelHeightAccessor;
        getHeightAccessorForGeneration(): $LevelHeightAccessor;
        get orCreateCarvingMask(): $CarvingMask;
        getOrCreateCarvingMask(): $CarvingMask;
        get persistedStatus(): $ChunkStatus;
        getPersistedStatus(): $ChunkStatus;
        set persistedStatus(value: $ChunkStatus_);
        static packOffsetCoordinates(arg0: $BlockPos_): number;
        static unpackOffsetCoordinates(arg0: number, arg1: number, arg2: $ChunkPos): $BlockPos;
        addEntity(arg0: $CompoundTag_): void;
        addEntity(arg0: $Entity): void;
        addPackedPostProcess(arg0: $ShortList, arg1: number): void;
        getBlockEntityNbtForSaving(arg0: $BlockPos_, arg1: $HolderLookup$Provider): $CompoundTag;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getTicksForSerialization(arg0: number): $ChunkAccess$PackedTicks;
        markPosForPostProcessing(arg0: $BlockPos_): void;
        removeBlockEntity(arg0: $BlockPos_): void;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_, arg2: number): $BlockState;
        setStartForStructure(arg0: $Structure, arg1: $StructureStart): void;
        unpackBlockTicks(): $LevelChunkTicks<$Block>;
        unpackFluidTicks(): $LevelChunkTicks<$Fluid>;
    }

    export class $Strategy<T> {
        static createForBiomes<T>(arg0: $IdMap<T>): $Strategy<T>;
        static createForBlockStates<T>(arg0: $IdMap<T>): $Strategy<T>;
        entryCount(): number;
        getIndex(arg0: number, arg1: number, arg2: number): number;
        globalMap(): $IdMap<T>;
        globalPalette(): $GlobalPalette<T>;
    }

    export interface $StructureAccess {
        addReferenceForStructure(arg0: $Structure, arg1: number): void;
        getAllReferences(): $Map<$Structure, $LongSet>;
        getReferencesForStructure(arg0: $Structure): $LongSet;
        getStartForStructure(arg0: $Structure): $StructureStart;
        setAllReferences(arg0: { [key: $Structure]: $LongSet }): void;
        setStartForStructure(arg0: $Structure, arg1: $StructureStart): void;
    }

    export class $UpgradeData {
        constructor(arg0: $CompoundTag_, arg1: $LevelHeightAccessor);
        static EMPTY: $UpgradeData;
        get empty(): boolean;
        isEmpty(): boolean;
        copy(): $UpgradeData;
        upgrade(arg0: $LevelChunk): void;
        write(): $CompoundTag;
    }

    export type $LevelChunk$EntityCreationType_ = $LevelChunk$EntityCreationType | "CHECK" | "IMMEDIATE" | "QUEUED";
}
