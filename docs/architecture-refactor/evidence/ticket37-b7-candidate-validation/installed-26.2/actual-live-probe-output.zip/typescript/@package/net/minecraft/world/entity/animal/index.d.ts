import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as chicken from "java:net/minecraft/world/entity/animal/chicken";
export * as cow from "java:net/minecraft/world/entity/animal/cow";
export * as equine from "java:net/minecraft/world/entity/animal/equine";
export * as feline from "java:net/minecraft/world/entity/animal/feline";
export * as nautilus from "java:net/minecraft/world/entity/animal/nautilus";
export * as parrot from "java:net/minecraft/world/entity/animal/parrot";
export * as pig from "java:net/minecraft/world/entity/animal/pig";
export * as wolf from "java:net/minecraft/world/entity/animal/wolf";

declare module "java:net/minecraft/world/entity/animal" {
    export class $Animal extends $AgeableMob {
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get inLoveTime(): number;
        getInLoveTime(): number;
        set inLoveTime(value: number);
        get loveCause(): $ServerPlayer;
        getLoveCause(): $ServerPlayer;
        get inLove(): boolean;
        isInLove(): boolean;
        set inLove(value: $Player);
        static checkAnimalSpawnRules(arg0: $EntityType<$Animal>, arg1: $LevelAccessor, arg2: $EntitySpawnReason_, arg3: $BlockPos_, arg4: $RandomSource): boolean;
        static createAnimalAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canFallInLove(): boolean;
        canMate(arg0: $Animal): boolean;
        finalizeSpawnChildFromBreeding(arg0: $ServerLevel, arg1: $Animal, arg2: $AgeableMob): void;
        getDismountLocationForPassenger(arg0: $LivingEntity): $Vec3;
        getWalkTargetValue(arg0: $BlockPos_, arg1: $LevelReader): number;
        handleEntityEvent(arg0: number): void;
        isFood(arg0: $ItemStack_): boolean;
        mobInteract(arg0: $Player, arg1: $InteractionHand_): $InteractionResult;
        removeWhenFarAway(arg0: number): boolean;
        resetLove(): void;
        spawnChildFromBreeding(arg0: $ServerLevel, arg1: $Animal): void;
    }

}
