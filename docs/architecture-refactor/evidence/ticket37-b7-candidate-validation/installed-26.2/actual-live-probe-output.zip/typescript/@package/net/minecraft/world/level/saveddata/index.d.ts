import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Supplier } from "java:java/util/function";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $DataFixTypes, $DataFixTypes_ } from "java:net/minecraft/util/datafix";

export * as maps from "java:net/minecraft/world/level/saveddata/maps";

declare module "java:net/minecraft/world/level/saveddata" {
    export class $SavedData {
        constructor();
        get dirty(): boolean;
        isDirty(): boolean;
        set dirty(value: boolean);
        setDirty(): void;
    }

    export class $SavedDataType<T extends $SavedData> extends $Record {
        constructor(arg0: $Identifier_, arg1: $Supplier<T>, arg2: $Codec<T>);
        constructor(arg0: $Identifier_, arg1: $Supplier<T>, arg2: $Codec<T>, arg3: $DataFixTypes_);
        constructor(arg0: $Identifier_, arg1: $SavedDataType$Factory<T>, arg2: $SavedDataType$Factory<$Codec<T>>);
        constructor(id: $Identifier_, factory: $SavedDataType$Factory<T>, codecFactory: $SavedDataType$Factory<$Codec<T>>, dataFixType: $DataFixTypes_);
        codecFactory(): $SavedDataType$Factory<$Codec<T>>;
        codec(): $Codec<T>;
        constructor(): $Supplier<T>;
        dataFixType(): $DataFixTypes;
        equals(arg0: object): boolean;
        factory(): $SavedDataType$Factory<T>;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
    }

    export interface $SavedDataType$Factory<T> {
        create(arg0: $ServerLevel): T;
    }

    export class $WeatherData extends $SavedData {
        constructor();
        constructor(arg0: number, arg1: number, arg2: number, arg3: boolean, arg4: boolean);
        static CODEC: $Codec<$WeatherData>;
        static TYPE: $SavedDataType<$WeatherData>;
        get clearWeatherTime(): number;
        getClearWeatherTime(): number;
        set clearWeatherTime(value: number);
        get rainTime(): number;
        getRainTime(): number;
        set rainTime(value: number);
        get thunderTime(): number;
        getThunderTime(): number;
        set thunderTime(value: number);
        get raining(): boolean;
        isRaining(): boolean;
        set raining(value: boolean);
        get thundering(): boolean;
        isThundering(): boolean;
        set thundering(value: boolean);
    }

}
