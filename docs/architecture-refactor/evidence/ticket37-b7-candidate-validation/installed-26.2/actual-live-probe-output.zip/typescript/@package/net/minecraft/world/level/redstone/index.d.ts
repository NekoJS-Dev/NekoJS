import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Direction, $Direction_ } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/world/level/redstone" {
    export class $Orientation {
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Orientation>;
        get directions(): $List<$Direction>;
        getDirections(): $List<$Direction>;
        get front(): $Direction;
        getFront(): $Direction;
        get horizontalDirections(): $List<$Direction>;
        getHorizontalDirections(): $List<$Direction>;
        get index(): number;
        getIndex(): number;
        get sideBias(): $Orientation$SideBias;
        getSideBias(): $Orientation$SideBias;
        get side(): $Direction;
        getSide(): $Direction;
        get up(): $Direction;
        getUp(): $Direction;
        get verticalDirections(): $List<$Direction>;
        getVerticalDirections(): $List<$Direction>;
        static fromIndex(arg0: number): $Orientation;
        static of(arg0: $Direction_, arg1: $Direction_, arg2: $Orientation$SideBias_): $Orientation;
        static random(arg0: $RandomSource): $Orientation;
        toString(): string;
        withFrontAdjustSideBias(arg0: $Direction_): $Orientation;
        withFrontPreserveUp(arg0: $Direction_): $Orientation;
        withFront(arg0: $Direction_): $Orientation;
        withMirror(): $Orientation;
        withSideBias(arg0: $Orientation$SideBias_): $Orientation;
        withUp(arg0: $Direction_): $Orientation;
    }

    export class $Orientation$SideBias {
        static LEFT: $Orientation$SideBias;
        static RIGHT: $Orientation$SideBias;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Orientation$SideBias[];
        static valueOf(name: string): $Orientation$SideBias;
    }

    export type $Orientation$SideBias_ = $Orientation$SideBias | "LEFT" | "RIGHT";
}
