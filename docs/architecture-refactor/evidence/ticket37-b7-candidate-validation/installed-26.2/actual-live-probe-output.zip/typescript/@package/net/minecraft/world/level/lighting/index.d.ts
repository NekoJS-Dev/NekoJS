import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_, $SectionPos } from "java:net/minecraft/core";
import { $BlockGetter, $ChunkPos, $LightLayer, $LightLayer_ } from "java:net/minecraft/world/level";
import { $ChunkAccess, $DataLayer } from "java:net/minecraft/world/level/chunk";

declare module "java:net/minecraft/world/level/lighting" {
    export class $ChunkSkyLightSources {
        constructor(arg0: $LevelHeightAccessor);
        static NEGATIVE_INFINITY: number;
        get highestLowestSourceY(): number;
        getHighestLowestSourceY(): number;
        fillFrom(arg0: $ChunkAccess): void;
        getLowestSourceY(arg0: number, arg1: number): number;
        update(arg0: $BlockGetter, arg1: number, arg2: number, arg3: number): boolean;
    }

    export interface $LayerLightEventListener extends $LightEventListener {
        getDataLayerData(arg0: $SectionPos): $DataLayer;
        getLightValue(arg0: $BlockPos_): number;
    }

    export class $LayerLightSectionStorage$SectionType {
        static EMPTY: $LayerLightSectionStorage$SectionType;
        static LIGHT_AND_DATA: $LayerLightSectionStorage$SectionType;
        static LIGHT_ONLY: $LayerLightSectionStorage$SectionType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LayerLightSectionStorage$SectionType[];
        static valueOf(name: string): $LayerLightSectionStorage$SectionType;
    }

    export class $LevelLightEngine implements $LightEventListener {
        constructor(arg0: $LightChunkGetter, arg1: boolean, arg2: boolean);
        static EMPTY: $LevelLightEngine;
        static LIGHT_SECTION_PADDING: number;
        get lightSectionCount(): number;
        getLightSectionCount(): number;
        get maxLightSection(): number;
        getMaxLightSection(): number;
        get minLightSection(): number;
        getMinLightSection(): number;
        checkBlock(arg0: $BlockPos_): void;
        getDebugData(arg0: $LightLayer_, arg1: $SectionPos): string;
        getDebugSectionType(arg0: $LightLayer_, arg1: $SectionPos): $LayerLightSectionStorage$SectionType;
        getLayerListener(arg0: $LightLayer_): $LayerLightEventListener;
        getRawBrightness(arg0: $BlockPos_, arg1: number): number;
        hasLightWork(): boolean;
        lightOnInColumn(arg0: number): boolean;
        propagateLightSources(arg0: $ChunkPos): void;
        queueSectionData(arg0: $LightLayer_, arg1: $SectionPos, arg2: $DataLayer): void;
        retainData(arg0: $ChunkPos, arg1: boolean): void;
        runLightUpdates(): number;
        setLightEnabled(arg0: $ChunkPos, arg1: boolean): void;
        updateSectionStatus(arg0: $SectionPos, arg1: boolean): void;
    }

    export interface $LightEventListener {
        checkBlock(arg0: $BlockPos_): void;
        hasLightWork(): boolean;
        propagateLightSources(arg0: $ChunkPos): void;
        runLightUpdates(): number;
        setLightEnabled(arg0: $ChunkPos, arg1: boolean): void;
        updateSectionStatus(arg0: $BlockPos_, arg1: boolean): void;
        updateSectionStatus(arg0: $SectionPos, arg1: boolean): void;
    }

    export type $LayerLightSectionStorage$SectionType_ = $LayerLightSectionStorage$SectionType | "EMPTY" | "LIGHT_AND_DATA" | "LIGHT_ONLY";
}
