import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Optional, $UUID } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $Holder$Reference, $Holder_, $Registry } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Level } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/level/gameevent" {
    export class $BlockPositionSource extends $Record implements $PositionSource {
        constructor(pos: $BlockPos_);
        static CODEC: $MapCodec<$BlockPositionSource>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $BlockPositionSource>;
        get type(): $PositionSourceType<$BlockPositionSource>;
        getType(): $PositionSourceType<$BlockPositionSource>;
        equals(arg0: object): boolean;
        getPosition(arg0: $Level): $Optional<$Vec3>;
        hashCode(): number;
        pos(): $BlockPos;
        toString(): string;
    }

    export class $DynamicGameEventListener<T extends $GameEventListener> {
        constructor(arg0: T);
        get listener(): T;
        getListener(): T;
        add(arg0: $ServerLevel): void;
        move(arg0: $ServerLevel): void;
        remove(arg0: $ServerLevel): void;
    }

    export class $EntityPositionSource implements $PositionSource {
        constructor(arg0: $Entity, arg1: number);
        static CODEC: $MapCodec<$EntityPositionSource>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $EntityPositionSource>;
        get type(): $PositionSourceType<$EntityPositionSource>;
        getType(): $PositionSourceType<$EntityPositionSource>;
        get uuid(): $UUID;
        getUuid(): $UUID;
        getPosition(arg0: $Level): $Optional<$Vec3>;
    }

    export class $GameEvent extends $Record {
        constructor(notificationRadius: number);
        static BLOCK_ACTIVATE: $Holder$Reference<$GameEvent>;
        static BLOCK_ATTACH: $Holder$Reference<$GameEvent>;
        static BLOCK_CHANGE: $Holder$Reference<$GameEvent>;
        static BLOCK_CLOSE: $Holder$Reference<$GameEvent>;
        static BLOCK_DEACTIVATE: $Holder$Reference<$GameEvent>;
        static BLOCK_DESTROY: $Holder$Reference<$GameEvent>;
        static BLOCK_DETACH: $Holder$Reference<$GameEvent>;
        static BLOCK_OPEN: $Holder$Reference<$GameEvent>;
        static BLOCK_PLACE: $Holder$Reference<$GameEvent>;
        static BOUNCE: $Holder$Reference<$GameEvent>;
        static CODEC: $Codec<$Holder<$GameEvent>>;
        static CONTAINER_CLOSE: $Holder$Reference<$GameEvent>;
        static CONTAINER_OPEN: $Holder$Reference<$GameEvent>;
        static DEFAULT_NOTIFICATION_RADIUS: number;
        static DRINK: $Holder$Reference<$GameEvent>;
        static EAT: $Holder$Reference<$GameEvent>;
        static ELYTRA_GLIDE: $Holder$Reference<$GameEvent>;
        static ENTITY_ACTION: $Holder$Reference<$GameEvent>;
        static ENTITY_DAMAGE: $Holder$Reference<$GameEvent>;
        static ENTITY_DIE: $Holder$Reference<$GameEvent>;
        static ENTITY_DISMOUNT: $Holder$Reference<$GameEvent>;
        static ENTITY_INTERACT: $Holder$Reference<$GameEvent>;
        static ENTITY_MOUNT: $Holder$Reference<$GameEvent>;
        static ENTITY_PLACE: $Holder$Reference<$GameEvent>;
        static EQUIP: $Holder$Reference<$GameEvent>;
        static EXPLODE: $Holder$Reference<$GameEvent>;
        static FLAP: $Holder$Reference<$GameEvent>;
        static FLUID_PICKUP: $Holder$Reference<$GameEvent>;
        static FLUID_PLACE: $Holder$Reference<$GameEvent>;
        static HIT_GROUND: $Holder$Reference<$GameEvent>;
        static INSTRUMENT_PLAY: $Holder$Reference<$GameEvent>;
        static ITEM_INTERACT_FINISH: $Holder$Reference<$GameEvent>;
        static ITEM_INTERACT_START: $Holder$Reference<$GameEvent>;
        static JUKEBOX_PLAY: $Holder$Reference<$GameEvent>;
        static JUKEBOX_STOP_PLAY: $Holder$Reference<$GameEvent>;
        static LIGHTNING_STRIKE: $Holder$Reference<$GameEvent>;
        static NOTE_BLOCK_PLAY: $Holder$Reference<$GameEvent>;
        static PRIME_FUSE: $Holder$Reference<$GameEvent>;
        static PROJECTILE_LAND: $Holder$Reference<$GameEvent>;
        static PROJECTILE_SHOOT: $Holder$Reference<$GameEvent>;
        static RESONATE_1: $Holder$Reference<$GameEvent>;
        static RESONATE_10: $Holder$Reference<$GameEvent>;
        static RESONATE_11: $Holder$Reference<$GameEvent>;
        static RESONATE_12: $Holder$Reference<$GameEvent>;
        static RESONATE_13: $Holder$Reference<$GameEvent>;
        static RESONATE_14: $Holder$Reference<$GameEvent>;
        static RESONATE_15: $Holder$Reference<$GameEvent>;
        static RESONATE_2: $Holder$Reference<$GameEvent>;
        static RESONATE_3: $Holder$Reference<$GameEvent>;
        static RESONATE_4: $Holder$Reference<$GameEvent>;
        static RESONATE_5: $Holder$Reference<$GameEvent>;
        static RESONATE_6: $Holder$Reference<$GameEvent>;
        static RESONATE_7: $Holder$Reference<$GameEvent>;
        static RESONATE_8: $Holder$Reference<$GameEvent>;
        static RESONATE_9: $Holder$Reference<$GameEvent>;
        static SCULK_SENSOR_TENDRILS_CLICKING: $Holder$Reference<$GameEvent>;
        static SHEAR: $Holder$Reference<$GameEvent>;
        static SHRIEK: $Holder$Reference<$GameEvent>;
        static SPLASH: $Holder$Reference<$GameEvent>;
        static STEP: $Holder$Reference<$GameEvent>;
        static SWIM: $Holder$Reference<$GameEvent>;
        static TELEPORT: $Holder$Reference<$GameEvent>;
        static UNEQUIP: $Holder$Reference<$GameEvent>;
        static bootstrap(arg0: $Registry<$GameEvent_>): $Holder<$GameEvent>;
        equals(arg0: object): boolean;
        hashCode(): number;
        notificationRadius(): number;
        toString(): string;
    }

    export class $GameEvent$Context extends $Record {
        constructor(sourceEntity: $Entity, affectedState: $BlockState_);
        static of(arg0: $Entity, arg1: $BlockState_): $GameEvent$Context;
        static of(arg0: $Entity): $GameEvent$Context;
        static of(arg0: $BlockState_): $GameEvent$Context;
        affectedState(): $BlockState;
        equals(arg0: object): boolean;
        hashCode(): number;
        sourceEntity(): $Entity;
        toString(): string;
    }

    export interface $GameEventListener {
        getDeliveryMode(): $GameEventListener$DeliveryMode;
        getListenerRadius(): number;
        getListenerSource(): $PositionSource;
        handleGameEvent(arg0: $ServerLevel, arg1: $Holder<$GameEvent_>, arg2: $GameEvent$Context, arg3: $Vec3_): boolean;
    }

    export class $GameEventListener$DeliveryMode {
        static BY_DISTANCE: $GameEventListener$DeliveryMode;
        static UNSPECIFIED: $GameEventListener$DeliveryMode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GameEventListener$DeliveryMode[];
        static valueOf(name: string): $GameEventListener$DeliveryMode;
    }

    export interface $GameEventListenerRegistry {
        isEmpty(): boolean;
        register(arg0: $GameEventListener): void;
        unregister(arg0: $GameEventListener): void;
        visitInRangeListeners(arg0: $Holder<$GameEvent_>, arg1: $Vec3_, arg2: $GameEvent$Context, arg3: $GameEventListenerRegistry$ListenerVisitor): boolean;
        static NOOP: $GameEventListenerRegistry;
    }

    export interface $GameEventListenerRegistry$ListenerVisitor {
        visit(arg0: $GameEventListener, arg1: $Vec3_): void;
    }

    export interface $PositionSource {
        getPosition(arg0: $Level): $Optional<$Vec3>;
        getType(): $PositionSourceType<$PositionSource>;
        static CODEC: $Codec<$PositionSource>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $PositionSource>;
    }

    export interface $PositionSourceType<T extends $PositionSource> {
        codec(): $MapCodec<T>;
        register<S, T>(arg0: string, arg1: S): S;
        streamCodec(): $StreamCodec<any, T>;
        static BLOCK: $PositionSourceType<$BlockPositionSource>;
        static ENTITY: $PositionSourceType<$EntityPositionSource>;
    }

    export type $GameEvent_ = $GameEvent | RegistryTypes.GameEvent | $NekoId | string;
    export type $GameEventListener$DeliveryMode_ = $GameEventListener$DeliveryMode | "BY_DISTANCE" | "UNSPECIFIED";
}
