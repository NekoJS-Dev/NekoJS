import { $Entity } from "java:net/minecraft/world/entity";
import { $Level } from "java:net/minecraft/world/level";
import { $Event, $ICancellableEvent } from "java:net/neoforged/bus/api";

export * as item from "java:net/neoforged/neoforge/event/entity/item";
export * as living from "java:net/neoforged/neoforge/event/entity/living";
export * as player from "java:net/neoforged/neoforge/event/entity/player";

declare module "java:net/neoforged/neoforge/event/entity" {
    export class $EntityEvent extends $Event {
        constructor(arg0: $Entity);
        get entity(): $Entity;
        getEntity(): $Entity;
    }

    export class $EntityJoinLevelEvent extends $EntityEvent implements $ICancellableEvent {
        constructor(arg0: $Entity, arg1: $Level);
        constructor(arg0: $Entity, arg1: $Level, arg2: boolean);
        get level(): $Level;
        getLevel(): $Level;
        loadedFromDisk(): boolean;
    }

    export class $EntityLeaveLevelEvent extends $EntityEvent {
        constructor(arg0: $Entity, arg1: $Level);
        get level(): $Level;
        getLevel(): $Level;
    }

}
