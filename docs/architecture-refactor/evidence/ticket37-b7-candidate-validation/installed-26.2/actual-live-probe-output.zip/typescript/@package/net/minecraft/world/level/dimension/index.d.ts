import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Optional, $OptionalLong } from "java:java/util";
import { $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $IntProvider } from "java:net/minecraft/util/valueproviders";
import { $EnvironmentAttributeMap } from "java:net/minecraft/world/attribute";
import { $WorldClock } from "java:net/minecraft/world/clock";
import { $CardinalLighting$Type, $CardinalLighting$Type_, $Level } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $Timeline } from "java:net/minecraft/world/timeline";

export * as end from "java:net/minecraft/world/level/dimension/end";

declare module "java:net/minecraft/world/level/dimension" {
    export class $DimensionType extends $Record {
        constructor(hasFixedTime: boolean, hasSkyLight: boolean, hasCeiling: boolean, hasEnderDragonFight: boolean, coordinateScale: number, minY: number, height: number, logicalHeight: number, infiniburn: $HolderSet<$Block_>, ambientLight: number, monsterSettings: $DimensionType$MonsterSettings, skybox: $DimensionType$Skybox_, cardinalLightType: $CardinalLighting$Type_, attributes: $EnvironmentAttributeMap, timelines: $HolderSet<$Timeline>, defaultClock: $Optional<$Holder<$WorldClock>>);
        static BITS_FOR_Y: number;
        static CODEC: $Codec<$Holder<$DimensionType>>;
        static DIRECT_CODEC: $Codec<$DimensionType>;
        static MAX_Y: number;
        static MIN_HEIGHT: number;
        static MIN_Y: number;
        static MOON_BRIGHTNESS_PER_PHASE: number[];
        static NETWORK_CODEC: $Codec<$DimensionType>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$DimensionType>>;
        static WAY_ABOVE_MAX_Y: number;
        static WAY_BELOW_MIN_Y: number;
        static Y_SIZE: number;
        static getStorageFolder(arg0: $ResourceKey<$Level>, arg1: string): $Path;
        static getTeleportationScale(arg0: $DimensionType, arg1: $DimensionType): number;
        ambientLight(): number;
        attributes(): $EnvironmentAttributeMap;
        cardinalLightType(): $CardinalLighting$Type;
        coordinateScale(): number;
        defaultClock(): $Optional<$Holder<$WorldClock>>;
        equals(arg0: object): boolean;
        hasCeiling(): boolean;
        hasEndFlashes(): boolean;
        hasEnderDragonFight(): boolean;
        hasFixedTime(): boolean;
        hasSkyLight(): boolean;
        hashCode(): number;
        height(): number;
        infiniburn(): $HolderSet<$Block>;
        logicalHeight(): number;
        minY(): number;
        monsterSettings(): $DimensionType$MonsterSettings;
        monsterSpawnBlockLightLimit(): number;
        monsterSpawnLightTest(): $IntProvider;
        skybox(): $DimensionType$Skybox;
        timelines(): $HolderSet<$Timeline>;
        toString(): string;
    }

    export class $DimensionType$MonsterSettings extends $Record {
        constructor(monsterSpawnLightTest: $IntProvider, monsterSpawnBlockLightLimit: number);
        static CODEC: $MapCodec<$DimensionType$MonsterSettings>;
        equals(arg0: object): boolean;
        hashCode(): number;
        monsterSpawnBlockLightLimit(): number;
        monsterSpawnLightTest(): $IntProvider;
        toString(): string;
    }

    export class $DimensionType$Skybox {
        static END: $DimensionType$Skybox;
        static NONE: $DimensionType$Skybox;
        static OVERWORLD: $DimensionType$Skybox;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DimensionType$Skybox[];
        static valueOf(name: string): $DimensionType$Skybox;
    }

    export class $LevelStem extends $Record {
        constructor(arg0: $Holder<$DimensionType>, arg1: $ChunkGenerator);
        constructor(type: $Holder<$DimensionType>, generator: $ChunkGenerator, seedOverride: $OptionalLong);
        static CODEC: $Codec<$LevelStem>;
        static END: $ResourceKey<$LevelStem>;
        static NETHER: $ResourceKey<$LevelStem>;
        static OVERWORLD: $ResourceKey<$LevelStem>;
        equals(arg0: object): boolean;
        generator(): $ChunkGenerator;
        hashCode(): number;
        seedOverride(): $OptionalLong;
        toString(): string;
        type(): $Holder<$DimensionType>;
    }

    export type $DimensionType$Skybox_ = $DimensionType$Skybox | "END" | "NONE" | "OVERWORLD";
}
