import { $Enum, $String } from "java:java/lang";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $ChunkPos, $Level } from "java:net/minecraft/world/level";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";

declare module "java:net/minecraft/server/level/progress" {
    export interface $ChunkLoadStatusView {
        get(arg0: number, arg1: number): $ChunkStatus;
        moveTo(arg0: $ResourceKey<$Level>, arg1: $ChunkPos): void;
        radius(): number;
    }

    export interface $LevelLoadListener {
        compose(arg0: $LevelLoadListener, arg1: $LevelLoadListener): $LevelLoadListener;
        finish(arg0: $LevelLoadListener$Stage_): void;
        start(arg0: $LevelLoadListener$Stage_, arg1: number): void;
        updateFocus(arg0: $ResourceKey<$Level>, arg1: $ChunkPos): void;
        update(arg0: $LevelLoadListener$Stage_, arg1: number, arg2: number): void;
    }

    export class $LevelLoadListener$Stage {
        static LOAD_INITIAL_CHUNKS: $LevelLoadListener$Stage;
        static LOAD_PLAYER_CHUNKS: $LevelLoadListener$Stage;
        static PREPARE_GLOBAL_SPAWN: $LevelLoadListener$Stage;
        static START_SERVER: $LevelLoadListener$Stage;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LevelLoadListener$Stage[];
        static valueOf(name: string): $LevelLoadListener$Stage;
    }

    export type $LevelLoadListener$Stage_ = $LevelLoadListener$Stage | "LOAD_INITIAL_CHUNKS" | "LOAD_PLAYER_CHUNKS" | "PREPARE_GLOBAL_SPAWN" | "START_SERVER";
}
