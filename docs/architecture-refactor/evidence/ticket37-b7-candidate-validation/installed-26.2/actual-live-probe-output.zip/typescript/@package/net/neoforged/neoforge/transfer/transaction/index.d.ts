declare module "java:net/neoforged/neoforge/transfer/transaction" {
    export interface $TransactionContext {
        depth(): number;
    }

}
