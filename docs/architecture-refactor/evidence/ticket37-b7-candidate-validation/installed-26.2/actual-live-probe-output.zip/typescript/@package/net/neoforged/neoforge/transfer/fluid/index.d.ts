import { $Codec } from "java:com/mojang/serialization";
import { $String } from "java:java/lang";
import { $Predicate, $Supplier } from "java:java/util/function";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentMap, $DataComponentPatch, $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Fluid, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $FluidStack, $FluidStackTemplate, $FluidStack_, $FluidType } from "java:net/neoforged/neoforge/fluids";
import { $DataComponentHolderResource } from "java:net/neoforged/neoforge/transfer/resource";

declare module "java:net/neoforged/neoforge/transfer/fluid" {
    export class $FluidResource implements $DataComponentHolderResource {
        static CODEC: $Codec<$FluidResource>;
        static EMPTY: $FluidResource;
        static OPTIONAL_CODEC: $Codec<$FluidResource>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FluidResource>;
        get componentsPatch(): $DataComponentPatch;
        getComponentsPatch(): $DataComponentPatch;
        get components(): $DataComponentMap;
        getComponents(): $DataComponentMap;
        get fluidType(): $FluidType;
        getFluidType(): $FluidType;
        get fluid(): $Fluid;
        getFluid(): $Fluid;
        get hoverName(): $Component;
        getHoverName(): $Component;
        get componentsPatchEmpty(): boolean;
        isComponentsPatchEmpty(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        static of(arg0: $Holder<$Fluid_>, arg1: $DataComponentPatch): $FluidResource;
        static of(arg0: $Holder<$Fluid_>): $FluidResource;
        static of(arg0: $Fluid_, arg1: $DataComponentPatch): $FluidResource;
        static of(arg0: $Fluid_): $FluidResource;
        static of(arg0: $FluidStackTemplate): $FluidResource;
        static of(arg0: $FluidStack_): $FluidResource;
        equals(arg0: object): boolean;
        hashCode(): number;
        is(arg0: $FluidType): boolean;
        matches(arg0: $FluidStackTemplate): boolean;
        matches(arg0: $FluidStack_): boolean;
        test(arg0: $Predicate<$FluidStack_>): boolean;
        toStack(arg0: number): $FluidStack;
        toString(): string;
        typeHolder(): $Holder<$Fluid>;
        value(): $Fluid;
        withMergedPatch(arg0: $DataComponentPatch): $FluidResource;
        without(arg0: $Supplier<$DataComponentType<any>>): $FluidResource;
        without(arg0: $DataComponentType<any>): $FluidResource;
        with<D>(arg0: $Supplier<$DataComponentType<D>>, arg1: D): $FluidResource;
        with<D>(arg0: $DataComponentType<D>, arg1: D): $FluidResource;
    }

}
