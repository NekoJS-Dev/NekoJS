import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $String } from "java:java/lang";
import { $Map, $Optional, $Set } from "java:java/util";
import { $StringRepresentable, $StringRepresentable$EnumCodec } from "java:net/minecraft/util";
import { $TeamColor, $TeamColor_ } from "java:net/minecraft/world/scores";

declare module "java:net/minecraft/world/scores/criteria" {
    export class $ObjectiveCriteria {
        static AIR: $ObjectiveCriteria;
        static ARMOR: $ObjectiveCriteria;
        static CODEC: $Codec<$ObjectiveCriteria>;
        static DEATH_COUNT: $ObjectiveCriteria;
        static DUMMY: $ObjectiveCriteria;
        static EXPERIENCE: $ObjectiveCriteria;
        static FOOD: $ObjectiveCriteria;
        static HEALTH: $ObjectiveCriteria;
        static KILLED_BY_TEAM: $Map<$TeamColor, $ObjectiveCriteria>;
        static KILL_COUNT_ALL: $ObjectiveCriteria;
        static KILL_COUNT_PLAYERS: $ObjectiveCriteria;
        static LEVEL: $ObjectiveCriteria;
        static TEAM_KILL: $Map<$TeamColor, $ObjectiveCriteria>;
        static TRIGGER: $ObjectiveCriteria;
        get defaultRenderType(): $ObjectiveCriteria$RenderType;
        getDefaultRenderType(): $ObjectiveCriteria$RenderType;
        get name(): string;
        getName(): string;
        get readOnly(): boolean;
        isReadOnly(): boolean;
        static byName(arg0: string): $Optional<$ObjectiveCriteria>;
        static getCustomCriteriaNames(): $Set<string>;
    }

    export class $ObjectiveCriteria$RenderType {
        static HEARTS: $ObjectiveCriteria$RenderType;
        static INTEGER: $ObjectiveCriteria$RenderType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ObjectiveCriteria$RenderType[];
        static valueOf(name: string): $ObjectiveCriteria$RenderType;
    }

    export type $ObjectiveCriteria$RenderType_ = $ObjectiveCriteria$RenderType | "HEARTS" | "INTEGER";
}
