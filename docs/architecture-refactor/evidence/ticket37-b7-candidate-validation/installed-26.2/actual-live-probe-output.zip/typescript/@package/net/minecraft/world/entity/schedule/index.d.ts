import type { RegistryTypes } from "@special/types";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $String } from "java:java/lang";

declare module "java:net/minecraft/world/entity/schedule" {
    export class $Activity {
        constructor(arg0: string);
        static ADMIRE_ITEM: $Activity;
        static AVOID: $Activity;
        static CELEBRATE: $Activity;
        static CORE: $Activity;
        static DIG: $Activity;
        static EMERGE: $Activity;
        static FIGHT: $Activity;
        static HIDE: $Activity;
        static IDLE: $Activity;
        static INVESTIGATE: $Activity;
        static LAY_SPAWN: $Activity;
        static LONG_JUMP: $Activity;
        static MEET: $Activity;
        static PANIC: $Activity;
        static PLAY: $Activity;
        static PLAY_DEAD: $Activity;
        static PRE_RAID: $Activity;
        static RAID: $Activity;
        static RAM: $Activity;
        static REST: $Activity;
        static RIDE: $Activity;
        static ROAR: $Activity;
        static SNIFF: $Activity;
        static SWIM: $Activity;
        static TONGUE: $Activity;
        static WORK: $Activity;
        get name(): string;
        getName(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export type $Activity_ = $Activity | RegistryTypes.Activity | $NekoId | string;
}
