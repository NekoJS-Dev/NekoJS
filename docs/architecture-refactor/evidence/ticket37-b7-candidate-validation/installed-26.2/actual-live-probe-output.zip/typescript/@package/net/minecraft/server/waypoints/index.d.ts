import { $Set } from "java:java/util";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $WaypointManager, $WaypointTransmitter } from "java:net/minecraft/world/waypoints";

declare module "java:net/minecraft/server/waypoints" {
    export class $ServerWaypointManager implements $WaypointManager {
        constructor();
        addPlayer(arg0: $ServerPlayer): void;
        breakAllConnections(): void;
        remakeConnections(arg0: $WaypointTransmitter): void;
        removePlayer(arg0: $ServerPlayer): void;
        trackWaypoint(arg0: $WaypointTransmitter): void;
        transmitters(): $Set<$WaypointTransmitter>;
        untrackWaypoint(arg0: $WaypointTransmitter): void;
        updatePlayer(arg0: $ServerPlayer): void;
        updateWaypoint(arg0: $WaypointTransmitter): void;
    }

}
