import { $RecipeJsonBuilder } from "java:com/tkisor/nekojs/api/recipe";
import { $List_, $Map_ } from "java:java/util";
import { $ItemStack_ } from "java:net/minecraft/world/item";
import { $Ingredient_ } from "java:net/minecraft/world/item/crafting";

    export class Minecraft$CraftingDye extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$CraftingSpecialMapextending extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$Blasting extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
        experience(experience: number): this;
        cookingtime(cookingtime: number): this;
    }
    export class Minecraft$CraftingShapeless extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredients(ingredients: object): this;
    }
    export class Minecraft$CraftingSpecialFireworkStarFade extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$Smelting extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
        experience(experience: number): this;
        cookingtime(cookingtime: number): this;
    }
    export class Minecraft$CampfireCooking extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
        experience(experience: number): this;
        cookingtime(cookingtime: number): this;
    }
    export class Minecraft$Stonecutting extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$CraftingSpecialBannerduplicate extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$CraftingSpecialFireworkRocket extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$SmithingTrim extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        template(template: $Ingredient_): this;
        base(base: $Ingredient_): this;
        addition(addition: $Ingredient_): this;
    }
    export class Minecraft$SmithingTransform extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        template(template: $Ingredient_): this;
        base(base: $Ingredient_): this;
        addition(addition: $Ingredient_): this;
    }
    export class Minecraft$CraftingShaped extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredients(ingredients: object): this;
    }
    export class Minecraft$CraftingTransmute extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$CraftingDecoratedPot extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$CraftingSpecialShielddecoration extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$CraftingImbue extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$CraftingSpecialBookcloning extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$CraftingSpecialRepairitem extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }
    export class Minecraft$Smoking extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
        experience(experience: number): this;
        cookingtime(cookingtime: number): this;
    }
    export class Minecraft$CraftingSpecialFireworkStar extends $RecipeJsonBuilder {
        result(result: $ItemStack_): this;
        ingredient(ingredient: $Ingredient_): this;
    }

    /**
     * Top-level recipe registry. Access via event.recipes.<namespace>.<type>(...)
     */
    export class DocumentedRecipes {
        minecraft: {
            crafting_shapeless(result: $ItemStack_, ingredients: $Ingredient_[]): $RecipeJsonBuilder;
            crafting_shaped(result: $ItemStack_, pattern: string[], keys: { [key: string]: $Ingredient_ }): $RecipeJsonBuilder;
            crafting_dye(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingDye;
            crafting_dye(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingDye;
            crafting_special_mapextending(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingSpecialMapextending;
            crafting_special_mapextending(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingSpecialMapextending;
            blasting(options: { result: $ItemStack_, ingredient: $Ingredient_, experience?: number, cookingtime?: number }): Minecraft$Blasting;
            blasting(result: $ItemStack_, ingredient: $Ingredient_, experience: number, cookingtime: number): Minecraft$Blasting;
            blasting(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$Blasting;
            crafting_special_firework_star_fade(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingSpecialFireworkStarFade;
            crafting_special_firework_star_fade(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingSpecialFireworkStarFade;
            smelting(options: { result: $ItemStack_, ingredient: $Ingredient_, experience?: number, cookingtime?: number }): Minecraft$Smelting;
            smelting(result: $ItemStack_, ingredient: $Ingredient_, experience: number, cookingtime: number): Minecraft$Smelting;
            smelting(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$Smelting;
            campfire_cooking(options: { result: $ItemStack_, ingredient: $Ingredient_, experience?: number, cookingtime?: number }): Minecraft$CampfireCooking;
            campfire_cooking(result: $ItemStack_, ingredient: $Ingredient_, experience: number, cookingtime: number): Minecraft$CampfireCooking;
            campfire_cooking(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CampfireCooking;
            stonecutting(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$Stonecutting;
            stonecutting(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$Stonecutting;
            crafting_special_bannerduplicate(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingSpecialBannerduplicate;
            crafting_special_bannerduplicate(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingSpecialBannerduplicate;
            crafting_special_firework_rocket(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingSpecialFireworkRocket;
            crafting_special_firework_rocket(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingSpecialFireworkRocket;
            smithing_trim(options: { result: $ItemStack_, template: $Ingredient_, base: $Ingredient_, addition: $Ingredient_ }): Minecraft$SmithingTrim;
            smithing_trim(result: $ItemStack_, template: $Ingredient_, base: $Ingredient_, addition: $Ingredient_): Minecraft$SmithingTrim;
            smithing_transform(options: { result: $ItemStack_, template: $Ingredient_, base: $Ingredient_, addition: $Ingredient_ }): Minecraft$SmithingTransform;
            smithing_transform(result: $ItemStack_, template: $Ingredient_, base: $Ingredient_, addition: $Ingredient_): Minecraft$SmithingTransform;
            crafting_transmute(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingTransmute;
            crafting_transmute(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingTransmute;
            crafting_decorated_pot(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingDecoratedPot;
            crafting_decorated_pot(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingDecoratedPot;
            crafting_special_shielddecoration(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingSpecialShielddecoration;
            crafting_special_shielddecoration(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingSpecialShielddecoration;
            crafting_imbue(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingImbue;
            crafting_imbue(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingImbue;
            crafting_special_bookcloning(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingSpecialBookcloning;
            crafting_special_bookcloning(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingSpecialBookcloning;
            crafting_special_repairitem(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingSpecialRepairitem;
            crafting_special_repairitem(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingSpecialRepairitem;
            smoking(options: { result: $ItemStack_, ingredient: $Ingredient_, experience?: number, cookingtime?: number }): Minecraft$Smoking;
            smoking(result: $ItemStack_, ingredient: $Ingredient_, experience: number, cookingtime: number): Minecraft$Smoking;
            smoking(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$Smoking;
            crafting_special_firework_star(options: { result: $ItemStack_, ingredient: $Ingredient_ }): Minecraft$CraftingSpecialFireworkStar;
            crafting_special_firework_star(result: $ItemStack_, ingredient: $Ingredient_): Minecraft$CraftingSpecialFireworkStar;
        };
}
