// Bindings for startup scripts
import { $RecipeSchemaBinding } from "java:com/tkisor/nekojs/bindings";
import { $BlockJS, $CapabilitiesJS, $ClientDataJS, $ColorJS, $DamageSourceJS, $DataMapJS, $FluidIngredientJS, $FluidJS, $IngredientFactory, $ItemJS, $KMathJS, $NativeEventsJS, $OnceJS, $OnceJS$ClearOnceJS, $ParticleOptionsJS, $StringUtilsJS, $TextIcons, $TimeJS, $UUIDJS, $UtilsJS } from "java:com/tkisor/nekojs/bindings/static_access";
import { $AssetGeneratorJS, $FluidAmounts } from "java:com/tkisor/nekojs/wrapper";
import { $ClientDataSyncJS } from "java:com/tkisor/nekojs/wrapper/clientdata";
import { $NetworkJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $Math } from "java:java/lang";
import { $BlockPos, $Direction } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleTypes } from "java:net/minecraft/core/particles";
import { $CompoundTag } from "java:net/minecraft/nbt";
import { $Component, $MutableComponent } from "java:net/minecraft/network/chat";
import { $Identifier } from "java:net/minecraft/resources";
import { $SoundEvents } from "java:net/minecraft/sounds";
import { $TriState } from "java:net/minecraft/util";
import { $DamageSource, $DamageTypes } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance, $MobEffects } from "java:net/minecraft/world/effect";
import { $EntityType } from "java:net/minecraft/world/entity";
import { $DyeColor, $Item, $ItemStack, $Items } from "java:net/minecraft/world/item";
import { $Ingredient } from "java:net/minecraft/world/item/crafting";
import { $Block, $Blocks } from "java:net/minecraft/world/level/block";
import { $Fluid, $Fluids } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3 } from "java:net/minecraft/world/phys";
import { $Capabilities } from "java:net/neoforged/neoforge/capabilities";
import { $FluidStack } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient } from "java:net/neoforged/neoforge/fluids/crafting";
type AssetGeneratorJS = $AssetGeneratorJS;
type NekoFluidHelper = $FluidJS;
type NekoItemHelper = $ItemJS;
type NekoFluidIngredientHelper = $FluidIngredientJS;
type NekoIngredientHelper = $IngredientFactory;

export {};

declare global {
    let Component: typeof $Component;
    let MutableComponent: typeof $MutableComponent;
    let FluidAmounts: typeof $FluidAmounts;
    let ParticleOptions: $ParticleOptionsJS & typeof $ParticleOptions;
    let CompoundTag: typeof $CompoundTag;
    let SoundEvents: typeof $SoundEvents;
    let DamageSource: $DamageSourceJS & typeof $DamageSource;
    let DamageTypes: typeof $DamageTypes;
    let Items: typeof $Items;
    let FluidStack: typeof $FluidStack;
    let UUID: $UUIDJS;
    let Utils: $UtilsJS;
    let DataMap: $DataMapJS;
    let clearOnce: $OnceJS$ClearOnceJS;
    let Vec3: typeof $Vec3;
    /** Typed asset generators writing into NekoJS's assets pack (blockState/blockModel/itemModel/texture); takes effect on the next resource reload. */
    let Assets: AssetGeneratorJS;
    let Capabilities: $CapabilitiesJS & typeof $Capabilities;
    let ItemStack: typeof $ItemStack;
    let TriState: typeof $TriState;
    let clientData: $ClientDataJS;
    let MobEffects: typeof $MobEffects;
    let Identifier: typeof $Identifier;
    let BlockPos: typeof $BlockPos;
    let Time: $TimeJS;
    /** Startup-side native NeoForge event bridge. */
    let NativeEvents: $NativeEventsJS;
    let Block: $BlockJS & typeof $Block;
    /** Script-friendly FluidStack helper. */
    let Fluid: NekoFluidHelper & typeof $Fluid;
    let RecipeSchema: $RecipeSchemaBinding;
    let KMath: typeof $KMathJS;
    let Fluids: typeof $Fluids;
    let AABB: typeof $AABB;
    let once: $OnceJS;
    let JavaMath: typeof $Math;
    let DyeColor: typeof $DyeColor;
    let Network: typeof $NetworkJS;
    let Color: $ColorJS;
    let StringUtils: $StringUtilsJS;
    let Direction: typeof $Direction;
    let EntityType: typeof $EntityType;
    /** Script-friendly ItemStack factory and helpers (KubeJS-style: Item.of(id)); delegates of/empty to the helper, rest to MC Item. */
    let Item: NekoItemHelper & typeof $Item;
    /** Script-friendly FluidIngredient and SizedFluidIngredient helper. */
    let FluidIngredient: NekoFluidIngredientHelper & typeof $FluidIngredient;
    let ParticleTypes: typeof $ParticleTypes;
    let MobEffectInstance: typeof $MobEffectInstance;
    let Blocks: typeof $Blocks;
    /** Script-friendly Ingredient and IngredientJS helper. */
    let Ingredient: NekoIngredientHelper & typeof $Ingredient;
    let ClientData: typeof $ClientDataSyncJS;
    let TextIcons: typeof $TextIcons;
}
