// Bindings for test scripts
import { $RecipeSchemaBinding } from "java:com/tkisor/nekojs/bindings";
import { $BlockJS, $CapabilitiesJS, $ClientDataJS, $ColorJS, $DamageSourceJS, $DataMapJS, $FluidIngredientJS, $FluidJS, $IngredientFactory, $ItemJS, $KMathJS, $OnceJS, $OnceJS$ClearOnceJS, $ParticleOptionsJS, $StringUtilsJS, $TestJS, $TextIcons, $TimeJS, $UUIDJS, $UtilsJS } from "java:com/tkisor/nekojs/bindings/static_access";
import { $EntitySelectorsJS } from "java:com/tkisor/nekojs/util/selector";
import { $AssetGeneratorJS, $FluidAmounts } from "java:com/tkisor/nekojs/wrapper";
import { $ClientDataSyncJS } from "java:com/tkisor/nekojs/wrapper/clientdata";
import { $NetworkJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $Math } from "java:java/lang";
import { $BlockPos, $Direction } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleTypes } from "java:net/minecraft/core/particles";
import { $CompoundTag } from "java:net/minecraft/nbt";
import { $Component, $MutableComponent } from "java:net/minecraft/network/chat";
import { $Identifier } from "java:net/minecraft/resources";
import { $SoundEvents } from "java:net/minecraft/sounds";
import { $TriState } from "java:net/minecraft/util";
import { $DamageSource, $DamageTypes } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance, $MobEffects } from "java:net/minecraft/world/effect";
import { $EntityType } from "java:net/minecraft/world/entity";
import { $DyeColor, $Item, $ItemStack, $Items } from "java:net/minecraft/world/item";
import { $Ingredient } from "java:net/minecraft/world/item/crafting";
import { $Block, $Blocks } from "java:net/minecraft/world/level/block";
import { $Fluid, $Fluids } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3 } from "java:net/minecraft/world/phys";
import { $Capabilities } from "java:net/neoforged/neoforge/capabilities";
import { $FluidStack } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient } from "java:net/neoforged/neoforge/fluids/crafting";
type NekoItemHelper = $ItemJS;
type NekoTestHelper = $TestJS;
type NekoIngredientHelper = $IngredientFactory;
type NekoFluidIngredientHelper = $FluidIngredientJS;
type AssetGeneratorJS = $AssetGeneratorJS;
type NekoFluidHelper = $FluidJS;

export {};

declare global {
    let Color: $ColorJS;
    let AABB: typeof $AABB;
    let Items: typeof $Items;
    let EntityType: typeof $EntityType;
    let UUID: $UUIDJS;
    /** Script-friendly ItemStack factory and helpers (KubeJS-style: Item.of(id)); delegates of/empty to the helper, rest to MC Item. */
    let Item: NekoItemHelper & typeof $Item;
    /** Test-script assertion and smoke test helper. */
    let Test: NekoTestHelper;
    let Utils: $UtilsJS;
    /** Script-friendly Ingredient and IngredientJS helper. */
    let Ingredient: NekoIngredientHelper & typeof $Ingredient;
    let Time: $TimeJS;
    let JavaMath: typeof $Math;
    let Identifier: typeof $Identifier;
    let BlockPos: typeof $BlockPos;
    let TriState: typeof $TriState;
    let Vec3: typeof $Vec3;
    let StringUtils: $StringUtilsJS;
    let Direction: typeof $Direction;
    let FluidStack: typeof $FluidStack;
    /** Script-friendly FluidIngredient and SizedFluidIngredient helper. */
    let FluidIngredient: NekoFluidIngredientHelper & typeof $FluidIngredient;
    let MutableComponent: typeof $MutableComponent;
    let ClientData: typeof $ClientDataSyncJS;
    let DyeColor: typeof $DyeColor;
    let KMath: typeof $KMathJS;
    let FluidAmounts: typeof $FluidAmounts;
    let CompoundTag: typeof $CompoundTag;
    let clearOnce: $OnceJS$ClearOnceJS;
    let TextIcons: typeof $TextIcons;
    let DamageTypes: typeof $DamageTypes;
    let DamageSource: $DamageSourceJS & typeof $DamageSource;
    let Fluids: typeof $Fluids;
    let SoundEvents: typeof $SoundEvents;
    let MobEffectInstance: typeof $MobEffectInstance;
    let Blocks: typeof $Blocks;
    /** Typed asset generators writing into NekoJS's assets pack (blockState/blockModel/itemModel/texture); takes effect on the next resource reload. */
    let Assets: AssetGeneratorJS;
    let MobEffects: typeof $MobEffects;
    let once: $OnceJS;
    let Component: typeof $Component;
    let ParticleOptions: $ParticleOptionsJS & typeof $ParticleOptions;
    let clientData: $ClientDataJS;
    let Capabilities: $CapabilitiesJS & typeof $Capabilities;
    let ItemStack: typeof $ItemStack;
    let ParticleTypes: typeof $ParticleTypes;
    let DataMap: $DataMapJS;
    let EntitySelectors: $EntitySelectorsJS;
    let RecipeSchema: $RecipeSchemaBinding;
    let Network: typeof $NetworkJS;
    let Block: $BlockJS & typeof $Block;
    /** Script-friendly FluidStack helper. */
    let Fluid: NekoFluidHelper & typeof $Fluid;
}
