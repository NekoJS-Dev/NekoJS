// Bindings for server scripts
import { $RecipeSchemaBinding } from "java:com/tkisor/nekojs/bindings";
import { $BlockJS, $CapabilitiesJS, $ClientDataJS, $ColorJS, $DamageSourceJS, $DataMapJS, $FluidIngredientJS, $FluidJS, $IngredientFactory, $ItemJS, $KMathJS, $OnceJS, $OnceJS$ClearOnceJS, $ParticleOptionsJS, $StringUtilsJS, $TextIcons, $TimeJS, $UUIDJS, $UtilsJS, $VillagerTradesJS } from "java:com/tkisor/nekojs/bindings/static_access";
import { $DynamicRegistryJS } from "java:com/tkisor/nekojs/dynamic";
import { $EntitySelectorsJS } from "java:com/tkisor/nekojs/util/selector";
import { $AssetGeneratorJS, $FluidAmounts } from "java:com/tkisor/nekojs/wrapper";
import { $ClientDataSyncJS } from "java:com/tkisor/nekojs/wrapper/clientdata";
import { $NetworkJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $Math } from "java:java/lang";
import { $BlockPos, $Direction } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleTypes } from "java:net/minecraft/core/particles";
import { $CompoundTag } from "java:net/minecraft/nbt";
import { $Component, $MutableComponent } from "java:net/minecraft/network/chat";
import { $Identifier } from "java:net/minecraft/resources";
import { $SoundEvents } from "java:net/minecraft/sounds";
import { $TriState } from "java:net/minecraft/util";
import { $DamageSource, $DamageTypes } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance, $MobEffects } from "java:net/minecraft/world/effect";
import { $EntityType } from "java:net/minecraft/world/entity";
import { $DyeColor, $Item, $ItemStack, $Items } from "java:net/minecraft/world/item";
import { $Ingredient } from "java:net/minecraft/world/item/crafting";
import { $Block, $Blocks } from "java:net/minecraft/world/level/block";
import { $Fluid, $Fluids } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3 } from "java:net/minecraft/world/phys";
import { $Capabilities } from "java:net/neoforged/neoforge/capabilities";
import { $FluidStack } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient } from "java:net/neoforged/neoforge/fluids/crafting";
type AssetGeneratorJS = $AssetGeneratorJS;
type NekoFluidHelper = $FluidJS;
type NekoIngredientHelper = $IngredientFactory;
type NekoItemHelper = $ItemJS;
type NekoFluidIngredientHelper = $FluidIngredientJS;

export {};

declare global {
    let Component: typeof $Component;
    let Fluids: typeof $Fluids;
    let RecipeSchema: $RecipeSchemaBinding;
    /** Read-only, generation-bound villager trade queries. Declare trades through ServerEvents.tradeDeclaration; the platform adapter applies the candidate batch only after successful preflight and commit. */
    let VillagerTrades: $VillagerTradesJS;
    let MobEffectInstance: typeof $MobEffectInstance;
    let MobEffects: typeof $MobEffects;
    let EntitySelectors: $EntitySelectorsJS;
    let TextIcons: typeof $TextIcons;
    let KMath: typeof $KMathJS;
    let UUID: $UUIDJS;
    let DamageSource: $DamageSourceJS & typeof $DamageSource;
    let DynamicRegistry: $DynamicRegistryJS;
    let DyeColor: typeof $DyeColor;
    let Vec3: typeof $Vec3;
    let BlockPos: typeof $BlockPos;
    let DamageTypes: typeof $DamageTypes;
    let ClientData: typeof $ClientDataSyncJS;
    /** Typed asset generators writing into NekoJS's assets pack (blockState/blockModel/itemModel/texture); takes effect on the next resource reload. */
    let Assets: AssetGeneratorJS;
    let Blocks: typeof $Blocks;
    let Identifier: typeof $Identifier;
    /** Script-friendly FluidStack helper. */
    let Fluid: NekoFluidHelper & typeof $Fluid;
    let Time: $TimeJS;
    let AABB: typeof $AABB;
    let FluidAmounts: typeof $FluidAmounts;
    let JavaMath: typeof $Math;
    let DataMap: $DataMapJS;
    let FluidStack: typeof $FluidStack;
    /** Script-friendly Ingredient and IngredientJS helper. */
    let Ingredient: NekoIngredientHelper & typeof $Ingredient;
    let StringUtils: $StringUtilsJS;
    let MutableComponent: typeof $MutableComponent;
    let Direction: typeof $Direction;
    let ItemStack: typeof $ItemStack;
    let EntityType: typeof $EntityType;
    let clientData: $ClientDataJS;
    let Color: $ColorJS;
    let ParticleOptions: $ParticleOptionsJS & typeof $ParticleOptions;
    let Block: $BlockJS & typeof $Block;
    let TriState: typeof $TriState;
    let Utils: $UtilsJS;
    let once: $OnceJS;
    let ParticleTypes: typeof $ParticleTypes;
    let SoundEvents: typeof $SoundEvents;
    let Capabilities: $CapabilitiesJS & typeof $Capabilities;
    let clearOnce: $OnceJS$ClearOnceJS;
    let Network: typeof $NetworkJS;
    /** Script-friendly ItemStack factory and helpers (KubeJS-style: Item.of(id)); delegates of/empty to the helper, rest to MC Item. */
    let Item: NekoItemHelper & typeof $Item;
    let Items: typeof $Items;
    let CompoundTag: typeof $CompoundTag;
    /** Script-friendly FluidIngredient and SizedFluidIngredient helper. */
    let FluidIngredient: NekoFluidIngredientHelper & typeof $FluidIngredient;
}
