package nekojs.acceptance.frame;
import net.minecraft.client.Minecraft;



import org.lwjgl.glfw.GLFW;
/** Exercises native debug-key dispatch with a temporary synthetic F3 state. */
public final class InputDriver {
    private static boolean f3Held;
    private InputDriver() {}
    public static boolean f3Held() { return f3Held; }
    public static void reloadResourcesWithF3T() {
        Minecraft minecraft = Minecraft.getInstance();
        if (!minecraft.isSameThread()) throw new IllegalStateException("Owned input requires the client thread");
        var keyboard = minecraft.keyboardHandler;
        long window = minecraft.getWindow().getWindow();
        f3Held = true;
        try {
            
            System.out.println("OWNED-F3T-NATIVE-PRESS-BEGIN");
            keyboard.keyPress(window, GLFW.GLFW_KEY_T, 0, GLFW.GLFW_PRESS, 0);
        } finally {
            f3Held = false;
            
            keyboard.keyPress(window, GLFW.GLFW_KEY_T, 0, GLFW.GLFW_RELEASE, 0);
            System.out.println("OWNED-F3T-NATIVE-PRESS-END held=" + f3Held);
        }
    }
}
