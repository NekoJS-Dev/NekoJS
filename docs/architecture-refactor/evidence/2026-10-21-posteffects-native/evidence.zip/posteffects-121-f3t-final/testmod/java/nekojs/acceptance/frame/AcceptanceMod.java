package nekojs.acceptance.frame;
import net.neoforged.fml.common.Mod;
/** Registers only this isolated acceptance fixture. */
@Mod("neko_frame_acceptance")
public final class AcceptanceMod {
    public AcceptanceMod() {}
}
