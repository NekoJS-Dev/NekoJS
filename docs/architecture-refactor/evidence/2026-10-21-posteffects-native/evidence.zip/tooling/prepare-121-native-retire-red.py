from pathlib import Path
import shutil,os,json,hashlib
b=Path('build/priority-closeout');old=b/'posteffects-121-f3t-v2';r=b/'posteffects-121-native-retire-red';r.mkdir()
for n in ['server','client']:
 d=r/n;d.mkdir();shutil.copytree(old/n/'config',d/'config')
 if n=='server':
  shutil.copytree(old/n/'mods',d/'mods');os.symlink((old/n/'libraries').resolve(),d/'libraries',target_is_directory=True);shutil.copy2(old/n/'eula.txt',d/'eula.txt');(d/'server.properties').write_text((old/n/'server.properties').read_text().replace('28311','28331').replace('28312','28332'))
 else:
  shutil.copy2(old/n/'options.txt',d/'options.txt')
  for sub in ['startup_scripts','client_scripts','data']:(d/'nekojs'/sub).mkdir(parents=True)
  shutil.copy2(old/n/'nekojs/startup_scripts/frame.js',d/'nekojs/startup_scripts/frame.js')
  s=(old/n/'nekojs/client_scripts/frame.js').read_text().replace('const arm = {step,accepted,',"if (step === 'retained-native-retired') InputDriver.retireDefinitions();\n    const arm = {step,accepted,retiredThroughAdapter:step === 'retained-native-retired',hasDefinition:PostEffects.hasDefinition('minecraft:invert'),")
  (d/'nekojs/client_scripts/frame.js').write_text(s);(d/'nekojs/data/step.txt').write_text('idle')
shutil.copytree(old/'testmod',r/'testmod');p=r/'testmod/java/nekojs/acceptance/frame/InputDriver.java';s=p.read_text().replace('    public static void reloadResourcesWithF3T()',"""    public static void retireDefinitions() {
        var installed = com.tkisor.nekojs.client.posteffect.PostEffectManager.installedDefinitions();
        com.tkisor.nekojs.client.posteffect.PostEffectManager.installGeneration(
            com.tkisor.nekojs.client.posteffect.PostEffectManager.activeGeneration() + 1L,
            java.util.Map.of(), java.util.Set.copyOf(installed.keySet()));
        System.out.println("OWNED-ADAPTER-RETIRED " + installed.size());
    }
    public static void reloadResourcesWithF3T()""");p.write_text(s)
(r/'client.init.gradle').write_text((old/'client.init.gradle').read_text().replace(old.name,r.name).replace('28311','28331'))
s=(b/('run-'+old.name+'.py')).read_text().replace(old.name,r.name)
start=s.index("    before = capture('clear-before')");end=s.index('\nexcept Exception as error:',start)
s=s[:start]+"""    capture('clear-before')
    capture('effect-before')
    (client / 'nekojs/data/native.flag').write_text('replace')
    offset = len(log(client))
    signal('reload-native')
    wait_for(lambda: 'OWNED-NATIVE-EFFECT-REPLACED' in log(client)[offset:], 120, 'native effect replacement')
    native = capture('retained-native')
    assert native['current'] is None and native['active'] is True and native['hasDefinition'], native
    retired = capture('retained-native-retired')
    assert retired['current'] is None and retired['active'] is True and not retired['hasDefinition'], retired
"""+s[end:];s=s.replace("len(result['stages']) == 15", "len(result['stages']) == 4");(b/('run-'+r.name+'.py')).write_text(s)
v=json.loads((old/'manifest.json').read_text());v['port']=28331;v['rconPort']=28332;v['expected']='RED: retiring stale NekoJS selection must preserve currently native-owned chain';v['originalFixtureHashes']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'client.init.gradle',*r.glob('testmod/**/*.java'),*r.glob('testmod/**/*.json'),*r.glob('testmod/**/*.toml'),r/'client/nekojs/client_scripts/frame.js',r/'client/nekojs/startup_scripts/frame.js']}
v['productionSourceHashes']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('versions/1.21.1/src/main/java/com/tkisor/nekojs/client/posteffect/PostEffectManager.java'),Path('versions/1.21.1/src/main/java/com/tkisor/nekojs/mixin/PostEffectResourceReloadMixin.java'),Path('src/main/resources-legacy/nekojs.mixins.json')]};(r/'manifest.json').write_text(json.dumps(v,indent=2))
