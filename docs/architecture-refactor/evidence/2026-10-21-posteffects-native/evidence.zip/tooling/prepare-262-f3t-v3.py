from pathlib import Path
import shutil,os,json,hashlib,subprocess
b=Path('build/priority-closeout');old=b/'posteffects-261-f3t-v1';r=b/'posteffects-262-f3t-v3';r.mkdir();template=Path('build/closeout-dd15186c-installed/26.2.0')
srv=r/'server';srv.mkdir()
for n in ['config','mods']:shutil.copytree(template/n,srv/n)
os.symlink((template/'libraries').resolve(),srv/'libraries',target_is_directory=True)
shutil.copy2(template/'eula.txt',srv/'eula.txt')
props=(old/'server/server.properties').read_text().replace('28291','28361').replace('28292','28362');(srv/'server.properties').write_text(props)
c=r/'client';c.mkdir();shutil.copytree(old/'client/config',c/'config');shutil.copy2(old/'client/options.txt',c/'options.txt')
for sub in ['startup_scripts','client_scripts','data']:(c/'nekojs'/sub).mkdir(parents=True)
for sub in ['startup_scripts','client_scripts']:
 s=(old/'client/nekojs'/sub/'frame.js').read_text().replace('mc.getOverlay()','mc.gui.overlay()').replace('mc.getMainRenderTarget()','mc.gameRenderer.mainRenderTarget()');(c/'nekojs'/sub/'frame.js').write_text(s)
(c/'nekojs/data/step.txt').write_text('idle')
shutil.copytree(old/'testmod',r/'testmod')
(r/'client.init.gradle').write_text((old/'client.init.gradle').read_text().replace(old.name,r.name).replace(':26.1.2',':26.2.0').replace('28291','28361').replace("jvmArguments.add('-Dnekojs.acceptance.owner=", "jvmArguments.add('-Dneoforge.warnings.logofile.hide=true')\n        jvmArguments.add('-Dnekojs.acceptance.owner="))
s=(b/('run-'+old.name+'.py')).read_text().replace(old.name,r.name).replace(':26.1.2',':26.2.0').replace('26.1.2.71','26.2.0.75')
s+='\nraise SystemExit(0 if result[\'mechanicalVerdict\'] == \'PASS\' else 1)\n'; (b/('run-'+r.name+'.py')).write_text(s)
v=dict(node='26.2.0',productionSourceRevision='dd15186c',freshWorld=True,port=28361,rconPort=28362,serverLoader='26.2.0.75',developmentClientLoader='26.2.0.57',method='Synthetic native T dispatch with scoped F3 and cached mapping refresh; first RenderFrameEvent.Post before present, not physical input/display pixels',fixtureHashes={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'client.init.gradle',*r.glob('testmod/**/*.java'),*r.glob('testmod/**/*.json'),*r.glob('testmod/**/*.toml'),c/'nekojs/client_scripts/frame.js',c/'nekojs/startup_scripts/frame.js']});v['previousAttempt']='posteffects-262-f3t-v2'; v['developmentWarningPolicy']='neoforge.warnings.logofile.hide=true: vendor developer-only deprecation warning; production skips it by default. No runtime/security/capability change.'; (r/'manifest.json').write_text(json.dumps(v,indent=2))
