from pathlib import Path
import shutil,os,json,hashlib,subprocess
base=Path('build/priority-closeout'); old=base/'posteffects-121-v2'; r=base/'posteffects-121-f3t-v1'; r.mkdir()
for n in ['server','client']:
 d=r/n;d.mkdir();shutil.copytree(old/n/'config',d/'config')
 if n=='server':
  shutil.copytree(old/n/'mods',d/'mods');os.symlink((old/n/'libraries').resolve(),d/'libraries',target_is_directory=True)
  shutil.copy2(old/n/'eula.txt',d/'eula.txt')
  props=(old/n/'server.properties').read_text().replace('28281','28301').replace('28282','28302');(d/'server.properties').write_text(props)
 else:
  shutil.copy2(old/n/'options.txt',d/'options.txt')
  for sub in ['startup_scripts','client_scripts','data']:(d/'nekojs'/sub).mkdir(parents=True)
  shutil.copy2(old/n/'nekojs/startup_scripts/frame.js',d/'nekojs/startup_scripts/frame.js')
  s=(old/n/'nekojs/client_scripts/frame.js').read_text().replace("const Compat =", "const InputDriver = Java.type('nekojs.acceptance.frame.InputDriver');\nconst Compat =")
  s=s.replace("ClientEvents.postEffects(event => {", "ClientEvents.postEffects(event => {\n    if (fs.existsSync('nekojs/data/retire.flag')) return;")
  s=s.replace('mc.reloadResourcePacks();',"InputDriver.reloadResourcesWithF3T();\n        if (step === 'reload-cleared') PostEffects.clear();")
  (d/'nekojs/client_scripts/frame.js').write_text(s)
  (d/'nekojs/data/step.txt').write_text('idle')
# Source set and metadata copied only from the owned test fixture.
t=base/'posteffects-261-f3t-v1';shutil.copytree(t/'testmod',r/'testmod')
p=r/'testmod/java/nekojs/acceptance/frame/InputDriver.java'
s=p.read_text().replace('import net.minecraft.client.input.KeyEvent;','').replace('import net.minecraft.client.KeyMapping;','').replace('import nekojs.acceptance.frame.mixin.KeyboardInvoker;','').replace('KeyboardInvoker keyboard = (KeyboardInvoker) minecraft.keyboardHandler;','var keyboard = minecraft.keyboardHandler;').replace('minecraft.getWindow().handle()','minecraft.getWindow().getWindow()').replace('KeyMapping.setAll();','').replace('keyboard.nekoFramePress(window, GLFW.GLFW_PRESS, new KeyEvent(GLFW.GLFW_KEY_T, 0, 0));','keyboard.keyPress(window, GLFW.GLFW_KEY_T, 0, GLFW.GLFW_PRESS, 0);').replace('keyboard.nekoFramePress(window, GLFW.GLFW_RELEASE, new KeyEvent(GLFW.GLFW_KEY_T, 0, 0));','keyboard.keyPress(window, GLFW.GLFW_KEY_T, 0, GLFW.GLFW_RELEASE, 0);');p.write_text(s)
(r/'testmod/java/nekojs/acceptance/frame/mixin/KeyboardInvoker.java').unlink()
p=r/'testmod/java/nekojs/acceptance/frame/mixin/InputStateMixin.java';s=p.read_text().replace('import com.mojang.blaze3d.platform.Window;','').replace('heldF3(Window window,','heldF3(long window,');p.write_text(s)
p=r/'testmod/resources/neko-frame-acceptance.mixins.json';v=json.loads(p.read_text());v['compatibilityLevel']='JAVA_21';v['client']=['InputStateMixin'];p.write_text(json.dumps(v,indent=2))
s=(t/'client.init.gradle').read_text().replace('posteffects-261-f3t-v1',r.name).replace(':26.1.2',':1.21.1').replace('28291','28301');(r/'client.init.gradle').write_text(s)
s=(base/'run-posteffects-121-v2.py').read_text().replace('posteffects-121-v2',r.name)
s=s.replace("after = capture('clear-after')", "resource = capture('retained-resource')\n    assert resource['current'] == 'minecraft:invert' and resource['active'], resource\n    after = capture('clear-after')")
s=s.replace("capture('effect-recovered')", """capture('effect-recovered')
    offset = len(log(client))
    signal('reload-cleared')
    wait_for(lambda: 'POST-FRAME-CLIENT-READY' in log(client)[offset:], 120, 'reload after explicit clear')
    cleared = capture('retained-cleared')
    assert cleared['current'] is None and cleared['active'] is False, cleared
    capture('effect-retiring')
    (client / 'nekojs/data/retire.flag').write_text('retire')
    offset = len(log(client))
    signal('reload-retired')
    wait_for(lambda: 'POST-FRAME-CLIENT-READY' in log(client)[offset:], 120, 'retired effect reload')
    retired = capture('retained-retired')
    assert retired['current'] is None and retired['active'] is False, retired
""")
s=s.replace("len(result['stages']) == 7", "len(result['stages']) == 11")
runner=base/('run-'+r.name+'.py');runner.write_text(s)
manifest=dict(node='1.21.1',baseRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),productionPatch='legacy-resource-restoration.patch',freshWorld=True,port=28301,rconPort=28302,method='Synthetic T dispatched through native KeyboardHandler with scoped F3 state; not physical keyboard/GLFW callback',originalFixtureHashes={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in r.rglob('*') if p.is_file() and p.suffix in ['.java','.js','.gradle','.json','.toml'] and 'config' not in p.parts})
(r/'manifest.json').write_text(json.dumps(manifest,indent=2))
patch=subprocess.check_output(['git','diff','--','versions/1.21.1/src/main/java/com/tkisor/nekojs/client/posteffect/PostEffectManager.java','src/main/resources-legacy/nekojs.mixins.json'])
(r/'legacy-resource-restoration.patch').write_bytes(patch)
