from pathlib import Path
import json,numpy as np
from PIL import Image
r=Path('build/priority-closeout/posteffects-121-f3t-v1');v=json.loads((r/'run-result.json').read_text());roi=(230,200,380,260)
a={x['step']:np.asarray(Image.open(r/x['image']).crop(roi)).astype(float) for x in v['stages']};clear=a['clear-after'];effect=a['effect-after'];rows=[]
for x in v['stages']:
 n=x['step'];dc=float(np.mean(np.abs(a[n]-clear)));de=float(np.mean(np.abs(a[n]-effect)));expected='clear' if n.startswith('clear-') or n in ['retained-cleared','retained-retired'] else 'invert';ok=dc<de if expected=='clear' else de<dc
 rows.append(dict(step=n,expected=expected,meanAbsoluteDistanceToClear=dc,meanAbsoluteDistanceToEffect=de,passed=ok));assert ok,n
log=(r/'client/stdout.log').read_text(errors='replace');assert log.count('OWNED-F3T-NATIVE-PRESS-BEGIN')==5 and log.count('OWNED-F3T-NATIVE-PRESS-END held=false')==5
out=dict(roi=roi,roiSelection='Same visually reviewed wall region as pre-fix regression; excludes HUD/crosshair',referenceScope='Visual clear/invert classification, not a shader-color formula or pre-registered tolerance',rows=rows,nativeKeyboardDispatches=5,screenshotsReviewed=True,reviewer='Primary agent; all eleven original PNGs inspected. Not physical keyboard/display present/maintainer sign-off.')
(r/'pixel-review.json').write_text(json.dumps(out,indent=2));print(out)
