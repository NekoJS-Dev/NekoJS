from pathlib import Path
import json,numpy as np
from PIL import Image
r=Path("build/priority-closeout/posteffects-262-f3t-v3")
rows=[]
for x in json.loads((r/'run-result.json').read_text())['stages']:
 a=np.asarray(Image.open(r/x['image']).crop((230,200,380,260)).convert('L')).astype(float);score=float(np.mean(np.diff(a,axis=1)**2));clear=x['step'].startswith('clear');ok=score>100 if clear else .5<score<50
 rows.append(dict(step=x['step'],gradientSquaredMean=score,expected='clear' if clear else 'blur',passed=ok));assert ok,x['step']
log=(r/'client/stdout.log').read_text(errors='replace');assert log.count('OWNED-F3T-NATIVE-PRESS-BEGIN')==3 and log.count('OWNED-F3T-NATIVE-PRESS-END held=false')==3
review=dict(roi=[230,200,380,260],roiSelection='Same wall region as API run, visually checked for HUD exclusion',rows=rows,nativeKeyboardDispatches=3,screenshotsReviewed=True,reviewer='Primary agent; seven original PNGs inspected. Not maintainer sign-off or physical keyboard proof.')
(r/'pixel-review.json').write_text(json.dumps(review,indent=2));print(dict(rows=rows))
