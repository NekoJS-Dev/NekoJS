"""Seal bounded native evidence without copying worlds, credentials or dependencies."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path.cwd()
raw = root / 'build/priority-closeout'
out = root / 'docs/architecture-refactor/evidence/2026-10-21-posteffects-native'
out.mkdir(parents=True, exist_ok=True)
entries = {}
archive = out / 'evidence.zip'

with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    def add(name, data):
        assert name not in entries, name
        assert not name.endswith(('server.properties', '.jar', 'owned-java-args.txt'))
        entries[name] = dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
        z.writestr(name, data)

    def file(path, name=None):
        add(name or path.relative_to(raw).as_posix(), path.read_bytes())

    for attempt in sorted(raw.glob('posteffects-*')):
        if not attempt.is_dir():
            continue
        for p in sorted(attempt.iterdir()):
            if p.is_file() and p.suffix in {'.json', '.jsonl', '.png', '.log', '.patch', '.gradle'}:
                file(p)
        for side in ('client', 'server'):
            folder = attempt / side
            for name in ('stdout.log', 'stderr.log', 'owned-process.json'):
                p = folder / name
                if p.is_file():
                    file(p)
            for scripts in ('client_scripts', 'startup_scripts', 'server_scripts'):
                for p in sorted((folder / 'nekojs' / scripts).rglob('*')):
                    if p.is_file() and p.name.endswith(('.js', '.js.rejected')):
                        file(p)
        for p in sorted((attempt / 'testmod').rglob('*')):
            if p.is_file() and p.suffix in {'.java', '.json', '.toml'}:
                file(p)
    for p in sorted(raw.iterdir()):
        if p.is_file() and (p.name.startswith(('run-posteffects-', 'prepare-121-', 'prepare-262-',
                                              'review-121-', 'review-261-', 'review-262-',
                                              'check-121-retention', 'capture-native-posteffect',
                                              'seal-posteffects')) or p.name.startswith('legacy-posteffect-')):
            file(p, 'tooling/' + p.name)
    for p in sorted((raw / 'native-posteffect-bytecode').rglob('*.txt')):
        file(p)
    for p in sorted((root / 'versions/1.21.1/build/test-results').rglob('TEST-*.xml')):
        if p.parent.name in {'test', 'platformGateTest'}:
            file(p, 'checks/xml/' + p.parent.name + '/' + p.name)
    sources = ['versions/1.21.1/src/main/java/com/tkisor/nekojs/client/posteffect/PostEffectManager.java',
               'versions/1.21.1/src/main/java/com/tkisor/nekojs/mixin/PostEffectResourceReloadMixin.java',
               'src/main/resources-legacy/nekojs.mixins.json']
    for name in sources:
        file(root / name, 'source/' + name)
    patch = subprocess.check_output(['git', 'diff', '671a75e1', '8798257f', '--', *sources])
    add('source/671a75e1-to-8798257f.patch', patch)

manifest = dict(archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(), entries=entries,
                legacyRevision='8798257f', modernRevision='dd15186c',
                exclusions=['worlds', 'JARs and cached libraries', 'server.properties and launch argument files',
                            'configuration and user profiles', 'generated Probe outputs'])
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf8')
accepted = [('1.21.1', 'posteffects-121-f3t-final', '8798257f', 16, 7, '21.1.227', '21.1.227'),
            ('26.1.2', 'posteffects-261-f3t-v1', 'dd15186c', 7, 3, '26.1.2.71', '26.1.2.71'),
            ('26.2.0', 'posteffects-262-f3t-v3', 'dd15186c', 7, 3, '26.2.0.57', '26.2.0.75')]
summary = dict(accepted=[dict(node=n, attempt=a, sourceRevision=s, images=i,
                              nativeKeyboardDispatches=k, clientLoader=c, serverLoader=v)
                        for n,a,s,i,k,c,v in accepted],
               tests=dict(tests=447, skipped=31, failures=0, errors=0),
               sourceReview=dict(base='671a75e1', head='8798257f',
                                 standards=dict(initialFindings=2, remainingFindings=0),
                                 spec=dict(initialFindings=1, remainingFindings=0),
                                 scope='Independent Luna xhigh read-only source reviews; primary implemented and verified fixes.'),
               nativeVerdict='PASS within documented scope',
               installedClientJarLaunch=False, physicalKeyboardInput=False,
               monitorPresentValidation=False, maintainerAcceptance=False,
               effectReloadDuringWorldSwitch=False,
               negativeEvidence=['posteffects-121-v2/retention-review.json',
                                 'posteffects-121-native-retire-red/run-result.json',
                                 'posteffects-262-f3t-v2/run-result.json'])
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf8')
print(dict(entries=len(entries), archiveBytes=archive.stat().st_size))
