from pathlib import Path
import json,hashlib,zipfile
import numpy as np
from PIL import Image
b=Path('build/priority-closeout');r=b/'posteffects-261-f3t-v1'
v=json.loads((b/'posteffects-261-v3/source-binding.json').read_text());v['fixtureHashes']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'client.init.gradle',*r.glob('testmod/**/*.java'),*r.glob('testmod/**/*.json'),*r.glob('testmod/**/*.toml'),r/'client/nekojs/client_scripts/frame.js',r/'client/nekojs/startup_scripts/frame.js']};v.pop('originalFixtureHashes',None)
v['fixturePreparationNote']='Original manifest preceded the KeyMapping.setAll and mixin-package corrections. This post-run binding records the compiled/loaded fixture sources; compile.log and native key markers retained. No production source changed for this 26.1.2 run.'
v['acceptanceClassHashes']={str(p.relative_to(Path('versions/26.1.2/build/classes/java/postFrameAcceptance'))):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('versions/26.1.2/build/classes/java/postFrameAcceptance').rglob('*.class')}
jar=next((b.parent/'closeout-dd15186c-installed/26.1.2/mods').glob('nekojs-*.jar'))
with zipfile.ZipFile(jar) as z:
 for root in [Path('common/build/classes/java/main'),Path('versions/26.1.2/build/classes/java/main')]:
  for p in root.rglob('*.class'):
   name=p.relative_to(root).as_posix();assert hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256(z.read(name)).hexdigest(),name
(r/'source-binding.json').write_text(json.dumps(v,indent=2))
rows=[]
for x in json.loads((r/'run-result.json').read_text())['stages']:
 a=np.asarray(Image.open(r/x['image']).crop((230,200,380,260)).convert('L')).astype(float);score=float(np.mean(np.diff(a,axis=1)**2));clear=x['step'].startswith('clear');ok=score>100 if clear else .5<score<50
 rows.append(dict(step=x['step'],gradientSquaredMean=score,expected='clear' if clear else 'blur',passed=ok));assert ok,x['step']
log=(r/'client/stdout.log').read_text(errors='replace');assert log.count('OWNED-F3T-NATIVE-PRESS-BEGIN')==3 and log.count('OWNED-F3T-NATIVE-PRESS-END held=false')==3
review=dict(roi=[230,200,380,260],roiSelection='Same wall region as API run, visually checked for HUD exclusion',rows=rows,nativeKeyboardDispatches=3,screenshotsReviewed=True,reviewer='Primary agent; seven original PNGs inspected. Not maintainer sign-off or physical keyboard proof.')
(r/'pixel-review.json').write_text(json.dumps(review,indent=2));print(dict(classesMatched=True,rows=rows))
