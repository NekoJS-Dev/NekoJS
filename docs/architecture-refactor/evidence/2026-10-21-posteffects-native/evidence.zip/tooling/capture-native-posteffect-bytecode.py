from pathlib import Path
import subprocess
b=Path('build/priority-closeout/native-posteffect-bytecode');b.mkdir(exist_ok=True)
for node,jar,java in [('1.21.1','neoforge-21.1.227-merged.jar','jdk-21.0.10'),('26.1.2','minecraft-patched-26.1.2.71-merged.jar','jdk-25.0.2'),('26.2.0','minecraft-patched-26.2.0.57-merged.jar','jdk-25.0.2')]:
 d=b/node;d.mkdir(exist_ok=True);j=Path('versions',node,'build/moddev/artifacts',jar);assert j.exists(),j
 for cls in ['net.minecraft.client.Minecraft','net.minecraft.client.Screenshot','net.minecraft.client.KeyboardHandler','net.minecraft.client.KeyMapping','com.mojang.blaze3d.platform.InputConstants']:
  v=subprocess.run([f'C:/Program Files/Java/{java}/bin/javap.exe','-p','-c','-classpath',str(j),cls],capture_output=True);assert v.returncode==0,(cls,v.stderr)
  (d/(cls.rsplit('.',1)[-1]+'.txt')).write_bytes(v.stdout)
(d.parent/'1.21.1/ShaderReload.txt').write_bytes(Path('build/priority-closeout/legacy-shader-reload-javap.txt').read_bytes())
print('Three-node native bytecode snapshots saved')
