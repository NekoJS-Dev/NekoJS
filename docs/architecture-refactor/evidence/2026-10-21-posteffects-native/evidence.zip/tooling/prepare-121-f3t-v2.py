from pathlib import Path
import shutil,os,json,hashlib
b=Path('build/priority-closeout');old=b/'posteffects-121-f3t-v1';r=b/'posteffects-121-f3t-v2';r.mkdir()
for n in ['server','client']:
 d=r/n;d.mkdir();shutil.copytree(old/n/'config',d/'config')
 if n=='server':
  shutil.copytree(old/n/'mods',d/'mods');os.symlink((old/n/'libraries').resolve(),d/'libraries',target_is_directory=True);shutil.copy2(old/n/'eula.txt',d/'eula.txt');(d/'server.properties').write_text((old/n/'server.properties').read_text().replace('28301','28311').replace('28302','28312'))
 else:
  shutil.copy2(old/n/'options.txt',d/'options.txt')
  for sub in ['startup_scripts','client_scripts','data']:(d/'nekojs'/sub).mkdir(parents=True)
  shutil.copy2(old/n/'nekojs/startup_scripts/frame.js',d/'nekojs/startup_scripts/frame.js')
  s=(old/n/'nekojs/client_scripts/frame.js').read_text()
  s=s.replace("ClientEvents.tickPost(() => {", """ClientEvents.generateAssets('after_mods', () => {
    if (fs.existsSync('nekojs/data/native.flag')) {
        Minecraft.getInstance().gameRenderer.loadEffect(Java.type('net.minecraft.resources.ResourceLocation').parse('minecraft:shaders/post/creeper.json'));
        console.info('OWNED-NATIVE-EFFECT-REPLACED');
    }
});
ClientEvents.tickPost(() => {""")
  s=s.replace('const arm = {step,accepted,', "if (step === 'effect-inactive') mc.gameRenderer.togglePostEffect();\n    const arm = {step,accepted,")
  (d/'nekojs/client_scripts/frame.js').write_text(s);(d/'nekojs/data/step.txt').write_text('idle')
shutil.copytree(old/'testmod',r/'testmod')
(r/'client.init.gradle').write_text((old/'client.init.gradle').read_text().replace(old.name,r.name).replace('28301','28311'))
s=(b/('run-'+old.name+'.py')).read_text().replace(old.name,r.name)
s=s.replace("assert retired['current'] is None and retired['active'] is False, retired", """assert retired['current'] is None and retired['active'] is False, retired
    inactive = capture('effect-inactive')
    assert inactive['current'] == 'minecraft:invert' and inactive['active'] is False, inactive
    offset = len(log(client))
    signal('reload-inactive')
    wait_for(lambda: 'POST-FRAME-CLIENT-READY' in log(client)[offset:], 120, 'inactive effect reload')
    inactive_after = capture('retained-inactive')
    assert inactive_after['current'] == 'minecraft:invert' and inactive_after['active'] is False, inactive_after
    capture('effect-native-target')
    (client / 'nekojs/data/native.flag').write_text('replace')
    offset = len(log(client))
    signal('reload-native')
    wait_for(lambda: 'OWNED-NATIVE-EFFECT-REPLACED' in log(client)[offset:], 120, 'native effect replacement')
    native = capture('retained-native')
    assert native['current'] is None and native['active'] is True, native
""")
s=s.replace("len(result['stages']) == 11", "len(result['stages']) == 15");(b/('run-'+r.name+'.py')).write_text(s)
v=json.loads((old/'manifest.json').read_text());v['port']=28311;v['rconPort']=28312;v['previousAttempt']=old.name;v['originalFixtureHashes']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'client.init.gradle',*r.glob('testmod/**/*.java'),*r.glob('testmod/**/*.json'),*r.glob('testmod/**/*.toml'),r/'client/nekojs/client_scripts/frame.js',r/'client/nekojs/startup_scripts/frame.js']};(r/'manifest.json').write_text(json.dumps(v,indent=2))
