from pathlib import Path
import shutil,os,json,hashlib
b=Path('build/priority-closeout');old=b/'posteffects-121-f3t-v2';red=b/'posteffects-121-native-retire-red';r=b/'posteffects-121-f3t-final';r.mkdir()
for n in ['server','client']:
 d=r/n;d.mkdir();shutil.copytree(old/n/'config',d/'config')
 if n=='server':
  shutil.copytree(old/n/'mods',d/'mods');os.symlink((old/n/'libraries').resolve(),d/'libraries',target_is_directory=True);shutil.copy2(old/n/'eula.txt',d/'eula.txt');(d/'server.properties').write_text((old/n/'server.properties').read_text().replace('28311','28341').replace('28312','28342'))
 else:
  shutil.copy2(old/n/'options.txt',d/'options.txt')
  for sub in ['startup_scripts','client_scripts','data']:(d/'nekojs'/sub).mkdir(parents=True)
  shutil.copy2(old/n/'nekojs/startup_scripts/frame.js',d/'nekojs/startup_scripts/frame.js')
  shutil.copy2(red/n/'nekojs/client_scripts/frame.js',d/'nekojs/client_scripts/frame.js');(d/'nekojs/data/step.txt').write_text('idle')
shutil.copytree(red/'testmod',r/'testmod')
(r/'client.init.gradle').write_text((old/'client.init.gradle').read_text().replace(old.name,r.name).replace('28311','28341'))
s=(b/('run-'+old.name+'.py')).read_text().replace(old.name,r.name)
s=s.replace("(client / 'nekojs/data/native.flag').write_text('replace')", "(client / 'nekojs/data/retire.flag').unlink()\n    (client / 'nekojs/data/native.flag').write_text('replace')")
s=s.replace("assert native['current'] is None and native['active'] is True, native", """assert native['current'] is None and native['active'] is True and native['hasDefinition'], native
    retired_native = capture('retained-native-retired')
    assert retired_native['current'] is None and retired_native['active'] is True and not retired_native['hasDefinition'], retired_native
""")
s=s.replace("len(result['stages']) == 15", "len(result['stages']) == 16");s+="\nraise SystemExit(0 if result['mechanicalVerdict'] == 'PASS' else 1)\n";(b/('run-'+r.name+'.py')).write_text(s)
v=json.loads((old/'manifest.json').read_text());v['port']=28341;v['rconPort']=28342;v['originalFixtureHashes']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'client.init.gradle',*r.glob('testmod/**/*.java'),*r.glob('testmod/**/*.json'),*r.glob('testmod/**/*.toml'),r/'client/nekojs/client_scripts/frame.js',r/'client/nekojs/startup_scripts/frame.js']};v['productionSourceHashes']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('versions/1.21.1/src/main/java/com/tkisor/nekojs/client/posteffect/PostEffectManager.java'),Path('versions/1.21.1/src/main/java/com/tkisor/nekojs/mixin/PostEffectResourceReloadMixin.java'),Path('src/main/resources-legacy/nekojs.mixins.json')]};(r/'manifest.json').write_text(json.dumps(v,indent=2))
