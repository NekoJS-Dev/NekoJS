import json
from pathlib import Path
import numpy as np
from PIL import Image
r=Path('build/priority-closeout/posteffects-121-v2')
names=['clear-after','effect-after','retained-rejected']
roi=(230,200,380,260)
a={n:np.asarray(Image.open(r/(n+'.png')).crop(roi)).astype(float) for n in names}
d_clear=float(np.mean(np.abs(a['retained-rejected']-a['clear-after'])))
d_effect=float(np.mean(np.abs(a['retained-rejected']-a['effect-after'])))
v=dict(roi=roi,retainedToClear=d_clear,retainedToEffect=d_effect,verdict='PASS' if d_effect<d_clear else 'FAIL',screenshotsReviewed=True)
(r/'retention-review.json').write_text(json.dumps(v,indent=2))
print(json.dumps(v))
assert d_effect<d_clear,'Rejected candidate lost the active native effect'
