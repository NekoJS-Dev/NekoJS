"""Seal controlled diagnostic records; never export raw JFR properties or credentials."""
import datetime
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

tools = Path(__file__).resolve().parent
repo = tools.parent.parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
dest = repo / 'docs/architecture-refactor/evidence/2026-10-23-loader-preparation-diagnostic'
assert not dest.exists()
formal = json.loads((tools / 'final-7bea6d6d-formal/preparation.json').read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree).strip()
artifact = Path(formal['artifact'])
assert sha(artifact.read_bytes()) == formal['artifactSha256']
with zipfile.ZipFile(artifact) as jar:
    found = {}
    for directory in [tree / 'common/build/classes/java/main', tree / 'versions/26.1.2/build/classes/java/main']:
        for file in directory.rglob('*.class'):
            key = file.relative_to(directory).as_posix()
            if key.startswith('com/tkisor/nekojs/'):
                found[key] = sha(file.read_bytes())
    assert found == formal['classBindings'] and len(found) == 1640
    assert all(sha(jar.read(name)) == digest for name, digest in found.items())
restoration = dict(classCount=len(found), allClassesRestored=True,
                   jarSha256=formal['artifactSha256'], jarByteIdentical=True, checkoutClean=True)
(tools / '7bea6d6d-preparation-spans/restored-candidate.json').write_text(json.dumps(restoration, indent=2) + '\n')
properties = dict(line.split('=', 1) for line in
    (tree / 'versions/26.1.2/run/server.properties').read_text(encoding='utf-8').splitlines()
    if line and not line.startswith('#') and '=' in line)
credential = properties['rcon.password'].encode()
assert credential
entries = {}
redactions = {}
def add(name, path):
    data = path.read_bytes()
    original = data
    utf16 = properties['rcon.password'].encode('utf-16-le')
    data = data.replace(credential, b'<REDACTED>').replace(utf16, '<REDACTED>'.encode('utf-16-le'))
    if data != original:
        redactions[name] = sha(original)
    assert credential not in data and utf16 not in data
    entries[name] = data

parse = datetime.datetime.fromisoformat
for name in ['7bea6d6d-loader-spans', '7bea6d6d-preparation-spans']:
    root = tools / name
    data = json.loads((root / 'analysis.json').read_text(encoding='utf-8'))
    windows = [r for r in data['stages'] if r['stage'] == 'command']
    assert len(windows) == 5
    groups = {}
    for row in data['stages']:
        if any(parse(w['startUtc']) <= parse(row['startUtc']) <= parse(w['endUtc']) for w in windows):
            groups.setdefault(row['stage'], []).append(row)
    summary = {key: dict(count=len(rows), totalMs=round(sum(r['wallNs'] for r in rows) / 1e6, 3),
                        perReloadMs=round(sum(r['wallNs'] for r in rows) / 5e6, 3)) for key, rows in groups.items()}
    assert summary['root']['count'] == summary['recipe']['count'] == 5
    (root / 'reload-only-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    assert json.loads((root / 'exit.json').read_text())['exitCode'] == 0
    session = json.loads((root / 'session/session.json').read_text(encoding='utf-8-sig'))
    assert session['forcedKill'] is False and session['extra']['killed'] is False
    assert session['extra']['stopChannel'] == 'rcon'
    observations = json.loads((root / 'session/observations.json').read_text(encoding='utf-8-sig'))
    assert len(observations) == 5 and all('phase=COMMIT - no errors.' in r['response'] for r in observations)
    for file in root.rglob('*'):
        if file.is_file() and file.suffix != '.jfr' and 'analysis-classes' not in file.parts:
            add(name + '/' + file.relative_to(root).as_posix(), file)
    raw = root / 'session/reload.jfr'
    entries[name + '/jfr-sha256.json'] = json.dumps(dict(sha256=sha(raw.read_bytes()), bytes=raw.stat().st_size)).encode()
for name in ['prepare-7bea6d6d-loader-spans.py', 'seal-7bea6d6d-loader-diagnostic.py', 'ReloadStageAnalysis.java']:
    add('tools/' + name, tools / name)
dest.mkdir()
with zipfile.ZipFile(dest / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
manifest = dict(sourceRevision=formal['revision'], diagnosticOnly=True,
    archiveSha256=sha((dest / 'evidence.zip').read_bytes()),
    entries={n: dict(size=len(d), sha256=sha(d)) for n, d in sorted(entries.items())},
    excluded=['Raw JFR', 'server.properties', 'world', 'JARs and compiled helpers', 'credentials'],
    formalPerformanceStillFailed=True, restoration=restoration, redactedOriginalSha256=redactions)
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(dest / 'evidence.zip').stat().st_size, restoration=restoration)))
