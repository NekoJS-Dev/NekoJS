"""Prepare reversible loader spans in the isolated, owned performance checkout."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
detail = '--detail' in sys.argv
root = tools / ('7bea6d6d-preparation-spans' if detail else '7bea6d6d-loader-spans')
previous = tools / '7bea6d6d-stage-formal-cadence-v3'
helper = 'common/src/main/java/com/tkisor/nekojs/core/diagnostic/ReloadStage.java'
def sha(data):
    return hashlib.sha256(data).hexdigest()

if len(sys.argv) > 1 and sys.argv[1] == 'restore':
    binding = json.loads((root / 'binding.json').read_text())
    for row in binding['paths']:
        path = tree / row['path']
        assert sha(path.read_bytes()) == row['instrumentedSha256'], row['path']
    for row in binding['paths']:
        path = tree / row['path']
        if row['originalSha256'] is None:
            assert path.resolve().is_relative_to(tree.resolve()) and row['path'] == helper
            path.unlink()
        else:
            original = (root / 'originals' / row['path']).read_bytes()
            assert sha(original) == row['originalSha256']
            path.write_bytes(original)
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree).strip()
    (root / 'restoration.json').write_text(json.dumps({'ownedSourcesRestored': True}) + '\n')
    print('OWNED_SOURCES_RESTORED')
    raise SystemExit()

resume = len(sys.argv) > 1 and sys.argv[1] == 'resume'
assert root.exists() if resume else not root.exists()
if not resume:
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree).strip()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip()
assert revision == '7bea6d6dcc9d0a70be6886f7ee1c79af9a9dae75'
paths = [
    'common/src/main/java/com/tkisor/nekojs/script/ScriptExecutor.java',
    'common/src/main/java/com/tkisor/nekojs/script/ScriptManager.java',
    'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java',
    'src/main/java/com/tkisor/nekojs/mixin/RecipeManagerMixin.java',
    'common/src/main/java/com/tkisor/nekojs/core/node/NekoNodeModuleInstaller.java',
    'common/src/main/java/com/tkisor/nekojs/core/module/NekoScriptModuleLoaderHost.java',
]
if detail:
    paths.append('common/src/main/java/com/tkisor/nekojs/core/module/NekoModulePipelineCache.java')
root.mkdir(exist_ok=resume)
originals = {}
for relative in paths:
    backup = root / 'originals' / relative
    if resume:
        original = backup.read_bytes()
    else:
        original = (tree / relative).read_bytes()
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_bytes(original)
    originals[relative] = sha(original)
patch = previous / 'instrumentation.patch'
target = tree / helper
if resume:
    assert subprocess.check_output(['git', 'diff', '--', *paths], cwd=tree) == patch.read_bytes()
    assert target.read_bytes() == (previous / 'ReloadStage.java').read_bytes()
else:
    subprocess.run(['git', 'apply', '--check', str(patch)], cwd=tree, check=True)
    subprocess.run(['git', 'apply', str(patch)], cwd=tree, check=True)
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((previous / 'ReloadStage.java').read_bytes())
if detail:
    source = target.read_text(encoding='utf-8')
    source = source.replace('        String stage;', '        private static final java.lang.management.ThreadMXBean CPU = java.lang.management.ManagementFactory.getThreadMXBean();\n        String stage;')
    source = source.replace('java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime()', 'CPU.getCurrentThreadCpuTime()')
    target.write_text(source, encoding='utf-8', newline='\n')
profile = 'com.tkisor.nekojs.core.diagnostic.ReloadStage.begin'
installer = tree / 'common/src/main/java/com/tkisor/nekojs/core/node/NekoNodeModuleInstaller.java'
source = installer.read_text(encoding='utf-8')
before = '            context.eval(prepared);'
assert source.count(before) == 1
source = source.replace(before, f'            try (var profile = {profile}("builtin:" + entry)) {{\n{before}\n            }}')
installer.write_text(source, encoding='utf-8', newline='\n')
host = tree / 'common/src/main/java/com/tkisor/nekojs/core/module/NekoScriptModuleLoaderHost.java'
source = host.read_text(encoding='utf-8')
edits = [
    ('        try {\n            return resolution.resolve();',
     f'        try (var profile = {profile}("module-resolve")) {{\n            return resolution.resolve();'),
    ('        try {\n            executor.execute(module.value(), require, resolve, resolved.id(), resolved.dirname(), prepared.code());',
     f'        try (var profile = {profile}("module-execute:" + resolved.id())) {{\n            executor.execute(module.value(), require, resolve, resolved.id(), resolved.dirname(), prepared.code());'),
    ('        NekoPreparedModule prepared = preparationCache.prepare(resolved.path());\n        observePrepared(resolved.id(), resolved.path(), prepared);\n        return prepared;',
     f'        try (var profile = {profile}("module-prepare")) {{\n        NekoPreparedModule prepared = preparationCache.prepare(resolved.path());\n        observePrepared(resolved.id(), resolved.path(), prepared);\n        return prepared;\n        }}'),
]
for before, after in edits:
    assert source.count(before) == 1, before
    source = source.replace(before, after)
host.write_text(source, encoding='utf-8', newline='\n')
if detail:
    cache = tree / paths[-1]
    source = cache.read_text(encoding='utf-8')
    edits = [
        ('        Path key = key(path);\n        NekoTrustApprovedSource approval = approvedSource(key);\n        try {\n            SourceSnapshot source = readSource(key);',
         f'''        Path key;
        NekoTrustApprovedSource approval;
        try (var profile = {profile}("prepare-path-trust")) {{
            key = key(path);
            approval = approvedSource(key);
        }}
        try {{
            SourceSnapshot source;
            try (var profile = {profile}("prepare-read-stamp")) {{
                source = readSource(key);
            }}'''),
        ('                    NekoPreparedModule prepared = prepareSource(k, source, approval, bindingSchemaViewFor(k));',
         f'''                    NekoPreparedModule prepared;
                    try (var profile = {profile}("prepare-frontend")) {{
                        prepared = prepareSource(k, source, approval, bindingSchemaViewFor(k));
                    }}'''),
        ('            publishSourceMap(key, entry.prepared());',
         f'''            try (var profile = {profile}("prepare-source-map")) {{
                publishSourceMap(key, entry.prepared());
            }}'''),
    ]
    for before, after in edits:
        assert source.count(before) == 1, before
        source = source.replace(before, after)
    cache.write_text(source, encoding='utf-8', newline='\n')
rows = [dict(path=p, originalSha256=originals.get(p), instrumentedSha256=sha((tree / p).read_bytes()))
        for p in paths + [helper]]
(root / 'binding.json').write_text(json.dumps(dict(revision=revision, diagnosticOnly=True, paths=rows), indent=2) + '\n')
(root / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *paths], cwd=tree))
(root / 'ReloadStage.java').write_bytes(target.read_bytes())
for name in ['diagnostic.ps1', 'profile.init.gradle', 'run.py', 'analyze.py']:
    source = (previous / name).read_text(encoding='utf-8')
    source = source.replace(previous.name, root.name)
    if name == 'diagnostic.ps1':
        source = source.replace(').Count -ne 4)', f').Count -ne {len(paths)})')
    if name == 'profile.init.gradle':
        source = source.replace('#period=2ms', '#period=1ms')
    (root / name).write_text(source, encoding='utf-8', newline='\n')
print('OWNED_LOADER_SPANS_PREPARED')
