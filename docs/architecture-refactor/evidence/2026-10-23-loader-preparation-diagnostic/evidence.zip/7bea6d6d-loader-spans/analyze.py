import json
import statistics
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
classpath = (root.parent/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text().strip()
classes = root/'analysis-classes'
classes.mkdir(exist_ok=True)
source = root.parent/'ReloadStageAnalysis.java'
commands = [[str(java/'javac.exe'),'-cp',classpath,'-d',str(classes),str(source)],
    [str(java/'java.exe'),'-cp',str(classes)+';'+classpath,'ReloadStageAnalysis',
        str(root/'session/reload.jfr'),str(root/'analysis.json')]]
for index,command in enumerate(commands):
    with (root/f'analysis-{index}.log').open('xb') as out,(root/f'analysis-{index}-stderr.log').open('xb') as err:
        result = subprocess.run(command,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0,index
d=json.loads((root/'analysis.json').read_text())
groups={}
for row in d['stages']: groups.setdefault(row['stage'],[]).append(row)
summary={name:dict(count=len(rows),wallMs=[round(r['wallNs']/1e6,2) for r in rows],
    meanWallMs=round(statistics.mean(r['wallNs']/1e6 for r in rows),2),
    meanCpuMs=round(statistics.mean(r['cpuNs']/1e6 for r in rows),2)) for name,rows in groups.items()}
(root/'stage-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
print(json.dumps(dict(rootSamples=d['rootSamples'],rootNekoInclusiveCounts=d['rootNekoInclusiveCounts']),indent=2))
