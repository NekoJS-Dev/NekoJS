package com.tkisor.nekojs.core.diagnostic;

    @jdk.jfr.Name("neko.ReloadStage")
    @jdk.jfr.StackTrace(false)
    public final class ReloadStage extends jdk.jfr.Event implements AutoCloseable {
        String stage;
        long wallNs;
        long cpuNs;
        private long startWall;
        private long startCpu;
        public static ReloadStage begin(String name) {
            var event = new ReloadStage();
            event.stage = name;
            event.startCpu = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
            event.startWall = System.nanoTime();
            event.begin();
            return event;
        }
        @Override public void close() {
            end();
            wallNs = System.nanoTime() - startWall;
            cpuNs = java.lang.management.ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime() - startCpu;
            commit();
        }
    }
