from pathlib import Path
import subprocess,os
repair=Path.cwd()/'build/ticket37-config-sync-repair'
text=(repair/'run-cb5-remaining-performance.py').read_text()
text=text.replace('import subprocess,json','import subprocess,json,os')
text=text.replace('records=[]',"child_env=dict(os.environ)\nchild_env['PSModulePath']=r'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\Modules'\nchild_env['JAVA_HOME']=r'C:\\Program Files\\Java\\jdk-25.0.2'\nchild_env['PATH']=child_env['JAVA_HOME']+r'\\bin;'+child_env['PATH']\nrecords=[]")
text=text.replace("group+'-guard.txt'","group+'-guard-v2.txt'")
text=text.replace('creationflags=subprocess.CREATE_NO_WINDOW)', 'creationflags=subprocess.CREATE_NO_WINDOW,env=child_env)')
assert not (repair/'run-cb5-remaining-performance-v2.py').exists()
(repair/'run-cb5-remaining-performance-v2.py').write_text(text)
