import hashlib,json,re,subprocess,gzip,io
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path.cwd();owned=root/'build/ticket37-perf-owned-ac810fa7';repair=root/'build/ticket37-config-sync-repair';work=root/'build/ticket37-perf-cb5f7fe6';out=root/'docs/architecture-refactor/evidence/ticket37-cb5-performance'
revision='cb5f7fe6a81d1415acff69c5e91ac430457385d5'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','-C',str(owned),'rev-parse','HEAD'],text=True).strip()==revision
assert not subprocess.check_output(['git','-C',str(owned),'status','--porcelain'],text=True).strip()
assert sha((owned/'bench/perf/sample.ps1').read_bytes())=='1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
assert json.loads((repair/'cb5-remaining-performance-runner-exit-v2.json').read_text(encoding='utf-8-sig'))['exitCode']==0
secrets=[line.partition('=')[2].encode() for line in (owned/'versions/26.1.2/run/server.properties').read_text().splitlines() if line.startswith('rcon.password=')]
def scan(data,suffix):
    if suffix=='.gz': return scan(gzip.decompress(data),'')
    if suffix=='.zip':
        with ZipFile(io.BytesIO(data)) as z:
            for name in z.namelist():scan(z.read(name),Path(name).suffix)
        return
    checked=data.replace(b'.gradle-perf02',b'[owned-gradle-cache]')
    assert not any(s and s in checked for s in secrets),'Credential value'
    assert not re.search(rb'(?m)^rcon\.password=',data),'Credential line'
folders=[]
for folder in sorted((owned/'bench/perf/out').iterdir()):
    p=folder/'samples.jsonl'
    if not p.is_file():continue
    samples=[json.loads(line) for line in p.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    if samples and samples[0]['rev']==revision[:8]:folders.append((folder,samples))
assert len(folders)==3
assert [s[0]['mode'] for _,s in folders]==['reload','reload','startup']
files={};groups=[]
for index,(folder,samples) in enumerate(folders):
    mode=samples[0]['mode'];formal=[s for s in samples if s['kind']=='formal'];warmup=[s for s in samples if s['kind']=='warmup']
    assert len(formal)==5 and len(samples)==(7 if mode=='startup' else 5)
    assert [s['index'] for s in formal]==([3,4,5,6,7] if mode=='startup' else [1,2,3,4,5])
    assert all(s['rev']==revision[:8] and s['node']=='26.1.2' and s['stop_channel']=='rcon' and not s['forced_kill'] and not s['killed'] for s in samples)
    if mode=='reload': assert all('phase=COMMIT - no errors.' in s['rcon_response'] for s in formal)
    key='wall_done_ms' if mode=='startup' else 'marker_ms';values=[s[key] for s in formal];mean=sum(values)/5;threshold=41173 if mode=='startup' else 285.3
    label=['reload-confirmed-1','reload-confirmed-2','startup-confirmed'][index]
    exit_status='NOT OBSERVED' if index==0 else json.loads((work/(label+'-exit.json')).read_text())['samplerExit']
    if index>0:assert exit_status==0
    groups.append(dict(group=label,folder=folder.name,mode=mode,formalValuesMs=values,meanMs=mean,thresholdMs=threshold,metricVerdict='PASS' if mean<=threshold else 'FAIL',samplerExit=exit_status,acceptanceVerdict='NOT GREEN: sampler exit not directly observed' if index==0 else ('PASS' if mean<=threshold else 'FAIL'),warmupValuesMs=[s[key] for s in warmup],samples=samples))
    for p in folder.iterdir():
        if p.is_file() and p.suffix in ['.log','.jsonl','.txt','.json','.csv']:files['samples/'+folder.name+'/'+p.name]=p
for p in work.iterdir():
    if p.is_file() and p.suffix in ['.txt','.json']:files['wrapper/'+p.name]=p
for pattern in ['*cb5*performance*','cb5-first-capture-stall.json','cb5-outer-capture-termination.json','prepare-cb5-remaining-v2.py']:
    for p in repair.glob(pattern):
        if p.is_file() and p.suffix in ['.txt','.json','.ps1','.py']:files['runner/'+p.name]=p
archive=out/'cb5-performance-evidence.zip';assert not archive.exists()
entries=[]
with ZipFile(archive,'x',ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()):
        data=p.read_bytes();scan(data,p.suffix);z.writestr(name,data);entries.append(dict(path=name,bytes=len(data),sha256=sha(data)))
with ZipFile(archive) as z:
    assert z.testzip() is None
    for e in entries:assert sha(z.read(e['path']))==e['sha256']
class_path='common/build/classes/java/main/com/tkisor/nekojs/probe/ir/TypeScriptClassRenderer.class'
assert (owned/class_path).read_bytes()==(root/class_path).read_bytes()
unique_pids=sorted({s['pid'] for _,samples in folders for s in samples});assert len(unique_pids)==9
summary=dict(sourceRevision=revision,samplerSha256=sha((owned/'bench/perf/sample.ps1').read_bytes()),compiledRendererSha256=sha((owned/class_path).read_bytes()),compiledRendererMatchesInstalledTrialBuild=True,groups=groups,overall='NOT GREEN: second reload mean exceeds fixed threshold; first sampler exit unobserved',normalRconGamePids=unique_pids,outerCaptureTermination='First owned wrapper and outer capture terminated after absent sampler/game and free ports; tool observed outer termination exit -1, not sampler completion',remainingRunnerExit=0,failedGuardRunnerExit=1,archive=dict(file=archive.name,entries=len(entries),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),entries=entries,exclusions=['server.properties/RCON credentials','worlds','binary artifacts','raw JFR','unrelated processes/data'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'.gitattributes').write_bytes(b'*.txt -text whitespace=-blank-at-eol,-blank-at-eof,space-before-tab,cr-at-eol\n*.patch -text whitespace=-blank-at-eol\n')
print(json.dumps(dict(groups=[{k:v for k,v in g.items() if k not in ['samples']} for g in groups],archive=summary['archive'],normalGameCount=len(unique_pids))))
