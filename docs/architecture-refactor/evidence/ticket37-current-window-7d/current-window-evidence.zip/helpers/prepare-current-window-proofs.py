from pathlib import Path

project = Path.cwd()
helpers = project / 'build/ticket37-config-sync-repair'
source = (helpers / 'prove-live-window-7e98.py').read_text(encoding='utf-8')
source = source.replace('ticket37-live-7e98', 'ticket37-current-window-7d').replace('live-rcon-7e98.py', 'rcon-current-window-7d.py')
source = source.replace('NekoLiveA', 'NekoWindow7dC').replace('ticket37_live:window_item', 'ticket37_b7:abort_item')
source = source.replace("7e98fd15175d15c8dad062bf40e2a284e04eaf51", "7d77308bfa400721304b20940ada91092180a1ed")
source = source.replace("(root / 'release-C-prepare').touch()", "(root / ('release-C-prepare-' + str(held['generation']))).touch()")
source = source.replace("recovery = command('nekojs reload server')", "assert (root / 'hold-C-prepare').read_bytes() == b''\n(root / 'hold-C-prepare').unlink()\nrecovery = command('nekojs reload server')")
source = source.replace('len(acks) == 3 and len(reports) == 3', 'len(acks) == 1 and len(reports) == 1')
source = source.replace("wait(root / 'D-handshake-held', 55)", "wait(root / 'D-handshake-held', 55)\nassert 'NekoWindow7dC joined the game' in (root / 'server/stdout.log').read_text(encoding='utf-8', errors='replace')")
path = helpers / 'prove-current-abort-window-7d.py'
assert not path.exists()
path.write_text(source, encoding='utf-8')
source = (helpers / 'prove-live-config-commit-7e98.py').read_text(encoding='utf-8')
source = source.replace('ticket37-live-7e98', 'ticket37-current-window-7d').replace('live-rcon-7e98.py', 'rcon-current-window-7d.py')
source = source.replace('NekoLiveE', 'NekoWindow7dE').replace('ticket37_live:window_item', 'ticket37_b7:abort_item')
source = source.replace("(root / 'release-C-prepare').touch()", "(root / ('release-C-prepare-' + str(generation))).touch()")
source = source.replace("command('nekojs reload server')", "(root / 'hold-C-prepare').touch()\nprevious_hold = (root / 'C-prepare-held').read_bytes()\ncommand('nekojs reload server')", 1)
source = source.replace("(root / 'C-prepare-held').exists()", "(root / 'C-prepare-held').exists() and (root / 'C-prepare-held').read_bytes() != previous_hold")
source = source.replace('len(acks) == 4 and len(reports) == 4', 'len(acks) == 2 and len(reports) == 2')
path = helpers / 'prove-current-commit-window-7d.py'
assert not path.exists()
path.write_text(source, encoding='utf-8')
