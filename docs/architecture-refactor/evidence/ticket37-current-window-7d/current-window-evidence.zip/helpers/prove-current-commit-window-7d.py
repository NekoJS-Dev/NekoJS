import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd() / 'build/ticket37-current-window-7d'
helper = Path('build/ticket37-config-sync-repair/rcon-current-window-7d.py')

def wait(test, seconds, label):
    deadline = time.monotonic() + seconds
    while not test():
        assert time.monotonic() < deadline, label
        time.sleep(0.005)

def command(value):
    result = subprocess.run([sys.executable, str(helper), value], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)

wait(lambda: (root / 'E-handshake-held').exists(), 55, 'E handshake not held')
(root / 'hold-C-prepare').touch()
previous_hold = (root / 'C-prepare-held').read_bytes()
command('nekojs reload server')
wait(lambda: (root / 'C-prepare-held').exists() and (root / 'C-prepare-held').read_bytes() != previous_hold, 3, 'C prepare not held')
generation = json.loads((root / 'C-prepare-held').read_text())['generation']
(root / 'release-E-handshake').touch()
wait(lambda: '"kind": "PREPARE"' in (root / 'proxyE.jsonl').read_text(), 5, 'E configuration did not receive PREPARE')
(root / ('release-C-prepare-' + str(generation))).touch()
wait(lambda: 'NekoWindow7dE joined the game' in (root / 'server/logs/latest.log').read_text(encoding='utf-8'), 8, 'E did not complete task and log in')
rows = [json.loads(line.split('LIVE-WINDOW ', 1)[1]) for line in (root / 'server/logs/latest.log').read_text(encoding='utf-8').splitlines() if 'LIVE-WINDOW ' in line]
state = rows[-1]
assert state['status'] == 'COMMITTED' and state['activatedGeneration'] == generation
assert any(row['generation'] == generation and row['outcome'] == 'joined-mid-transaction' for row in state['outcomes'])
acks = [row for row in state['outcomes'] if row['generation'] == generation and row['outcome'] == 'ack']
reports = [row for row in state['outcomes'] if row['generation'] == generation and row['outcome'] == 'activation-report']
assert len(acks) == 2 and len(reports) == 2, (acks, reports)
give = command('give NekoWindow7dE ticket37_b7:abort_item')
assert 'Gave' in give['response']
(root / 'configuration-commit-verdict.json').write_text(json.dumps(dict(result='PASS', generation=generation, actualConfigurationJoin=True, realAcks=len(acks), realReports=len(reports), state=state, give=give), indent=2)+'\n')
print(json.dumps(dict(result='PASS', generation=generation, realAcks=len(acks), realReports=len(reports), loggedIn=True)))
