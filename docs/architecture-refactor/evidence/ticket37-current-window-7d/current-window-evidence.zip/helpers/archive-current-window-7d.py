import hashlib
import json
import socket
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

project = Path.cwd().resolve()
roots = [project / 'build/ticket37-current-window-7d', project / 'build/ticket37-current-window-7d-attempt2']
destination = project / 'docs/architecture-refactor/evidence/ticket37-current-window-7d'
assert destination.is_dir() and {path.name for path in destination.iterdir()} == {'verify.py'}
sha = lambda value: hashlib.sha256(value).hexdigest()
entries = {}
exits = {}
secrets = []
for port in (25995, 25996, 25997, 25998):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
for index, root in enumerate(roots, 1):
    prefix = 'attempt' + str(index)
    preparation = json.loads((root / 'preparation.json').read_text())
    props = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines() if '=' in line)
    secrets.append(props['rcon.password'].encode())
    exits[prefix] = {}
    for path in root.iterdir():
        if path.is_file() and path.suffix in ('.json', '.jsonl', '.txt', '.md', '.js'):
            entries[prefix + '/' + path.name] = path.read_bytes()
    for node in ('server', 'clientC', 'clientD', 'clientE'):
        directory = root / node
        jar = directory / 'mods' / preparation['artifact']
        assert sha(jar.read_bytes()) == preparation['artifactSha256']
        with ZipFile(jar) as contents:
            for name, digest in preparation['classBindings'].items():
                assert sha(contents.read(name)) == digest
                candidates = [project / 'versions/26.2.0/build/classes/java/main' / name, project / 'common/build/classes/java/main' / name]
                compiled = next(path for path in candidates if path.is_file())
                assert sha(compiled.read_bytes()) == digest
        launched = (directory / 'owned-process.json').exists()
        if launched:
            code = json.loads((directory / 'exit.json').read_text())['exitCode']
            assert code == 0
            exits[prefix][node] = code
            for name in ('stdout.log', 'stderr.log', 'exit.json', 'owned-process.json', 'logs/latest.log'):
                path = directory / name
                if path.exists():
                    entries[prefix + '/' + node + '/' + name] = path.read_bytes()
            assert not list(directory.glob('hs_err*'))
        for folder in ('startup_scripts', 'server_scripts', 'client_scripts'):
            for path in (directory / 'nekojs' / folder).rglob('*.js'):
                entries[prefix + '/' + node + '/' + str(path.relative_to(directory / 'nekojs')).replace('\\', '/')] = path.read_bytes()
        if (directory / 'options.txt').exists():
            entries[prefix + '/' + node + '/options.txt'] = (directory / 'options.txt').read_bytes()
assert json.loads((roots[0] / 'abort-proof-exit.json').read_text())['exitCode'] == 1
assert json.loads((roots[1] / 'orchestrator-exit.json').read_text())['exitCode'] == 0
helpers = project / 'build/ticket37-config-sync-repair'
for path in helpers.glob('*current*window*.py'):
    entries['helpers/' + path.name] = path.read_bytes()
for name, data in entries.items():
    assert not any(secret in data for secret in secrets), name
archive = destination / 'current-window-evidence.zip'
with ZipFile(archive, 'x', compression=ZIP_DEFLATED) as output:
    for name, data in sorted(entries.items()):
        output.writestr(name, data)
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
    entries=[dict(name=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(entries.items())],
    exclusions=['server.properties and RCON credentials', 'worlds', 'launcher argument files', 'JARs and native binaries', 'raw JFR and hs_err', 'unrelated user files'])
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
summary = dict(checkoutRevision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    productionRevision=preparation['productionRevision'], artifactSha256=preparation['artifactSha256'],
    classBindings=preparation['classBindings'], copiesPerAttempt=4, directExits=exits,
    failedAttempt='FAIL: D handshake held about 38 seconds; no D PREPARE; C proxy hold expired; preserved original failure',
    onlyRetryChange='Proof started before D/E client launch; unchanged proxy forwarding and deadlines',
    abort=json.loads((roots[1] / 'window-verdict.json').read_text()),
    commit=json.loads((roots[1] / 'configuration-commit-verdict.json').read_text()),
    noBridge=True, noNativeActivationOrInput=True, forcedKills=0, portsFree=[25995, 25996, 25997, 25998],
    handshakeTimeoutCause='Consistent with excessive hold; timeout mechanism not established',
    packDownloadWindow='NOT_RUN', firstPixel='NOT_VERIFIED', crossNodeClients='NOT_RUN',
    wholeIDE='FAIL', pyright='FAIL', formalReload='FAIL', maintainerAcceptance='NOT_RECORDED', overall='NOT_COMPLETE')
(destination / 'runtime-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(result='ARCHIVED', entries=len(entries), bytes=manifest['bytes'], sha256=manifest['sha256'])))
