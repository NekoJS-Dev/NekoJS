import json
import subprocess
import sys
import time
import traceback
from pathlib import Path

root = Path.cwd() / 'build/ticket37-current-window-7d-attempt2'
helpers = Path.cwd() / 'build/ticket37-config-sync-repair'
assert not (root / 'orchestrator-exit.json').exists()
jobs = []
streams = []

def start(name, *args):
    stream = (root / (name + '.txt')).open('xb')
    streams.append(stream)
    process = subprocess.Popen([sys.executable, str(helpers / args[0]), *args[1:]], stdout=stream, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    jobs.append((name, process))
    print('OWNED_STAGE_STARTED', name, process.pid, flush=True)
    return process

def wait(test, seconds, label):
    deadline = time.monotonic() + seconds
    while not test():
        assert time.monotonic() < deadline, label
        time.sleep(.02)

def stop_client(letter):
    directory = root / ('client' + letter)
    if not (directory / 'owned-process.json').exists() or (directory / 'exit.json').exists():
        return
    (directory / 'nekojs/data/close-owned.txt').write_bytes(b'')
    wait(lambda: (directory / 'exit.json').exists(), 15, 'Owner stop did not exit: ' + letter)
    assert json.loads((directory / 'exit.json').read_text())['exitCode'] == 0

code = 1
try:
    wait(lambda: 'NekoWindow7dC joined the game' in (root / 'server/stdout.log').read_text(encoding='utf-8', errors='replace'), 90, 'C did not join')
    start('proxyD-runner', 'proxy-current-window-7d-attempt2.py', 'D', '25998')
    wait(lambda: (root / 'proxyD.jsonl').exists(), 5, 'D proxy did not listen')
    proof = start('abort-proof-runner', 'prove-current-abort-window-7d-attempt2.py')
    start('clientD-runner', 'run-current-window-7d-attempt2.py', 'D')
    result = proof.wait(timeout=85)
    (root / 'abort-proof-exit.json').write_text(json.dumps(dict(exitCode=result)))
    assert result == 0, 'Abort proof failed; original output retained'
    stop_client('D')
    wait(lambda: next(p for n, p in jobs if n == 'proxyD-runner').poll() is not None, 8, 'D proxy did not close')
    start('proxyE-runner', 'proxy-current-window-7d-attempt2.py', 'E', '25998')
    wait(lambda: (root / 'proxyE.jsonl').exists(), 5, 'E proxy did not listen')
    proof = start('commit-proof-runner', 'prove-current-commit-window-7d-attempt2.py')
    start('clientE-runner', 'run-current-window-7d-attempt2.py', 'E')
    result = proof.wait(timeout=85)
    (root / 'commit-proof-exit.json').write_text(json.dumps(dict(exitCode=result)))
    assert result == 0, 'Commit proof failed; original output retained'
    code = 0
except Exception:
    traceback.print_exc()
finally:
    for letter in ('C', 'D', 'E'):
        try:
            stop_client(letter)
        except Exception:
            traceback.print_exc()
            code = 1
    response = subprocess.run([sys.executable, str(helpers / 'rcon-current-window-7d-attempt2.py'), 'stop'], capture_output=True, text=True)
    print('OWNED_RCON_STOP', response.returncode, response.stdout, response.stderr, flush=True)
    wait(lambda: (root / 'server/exit.json').exists(), 15, 'Server did not stop')
    assert json.loads((root / 'server/exit.json').read_text())['exitCode'] == 0
    results = {name: process.wait(timeout=8) for name, process in jobs}
    for stream in streams:
        stream.close()
    (root / 'orchestrator-exit.json').write_text(json.dumps(dict(exitCode=code, jobs=results), indent=2))
    print('OWNED_ORCHESTRATOR_EXIT', code, flush=True)
sys.exit(code)
