// [REDACTED] fixture entry (module scaffold placeholder).
