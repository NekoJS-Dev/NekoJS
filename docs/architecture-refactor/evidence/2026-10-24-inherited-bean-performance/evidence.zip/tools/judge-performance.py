import json
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
preparation = json.loads((root / 'preparation.json').read_text(encoding='utf-8'))
groups = json.loads((root / 'groups.json').read_text(encoding='utf-8'))
results = []
for group in groups:
    assert group['exitCode'] == 0 and len(group['outputDirectories']) == 1
    output = Path(group['outputDirectories'][0])
    rows = [json.loads(line) for line in (output / 'samples.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    startup = group['group'] == 'startup'
    formal = [row for row in rows if row['kind'] == 'formal']
    key, limit = ('wall_done_ms', 41173) if startup else ('marker_ms', 285.3)
    invalid = []
    for row in rows:
        if (row.get(key) is None or row.get('wall_done_ms') is None or row.get('done_s') is None
                or row.get('killed') is not False or row.get('forced_kill') is not False
                or row.get('timeout') or row.get('stop_channel') != 'rcon'):
            invalid.append(row['index'])
    if not startup:
        invalid.extend(row['index'] for row in rows if 'phase=COMMIT - no errors.' not in row.get('rcon_response', ''))
    valid = (not invalid and len(formal) == 5 and
             (not startup or len([row for row in rows if row['kind'] == 'warmup']) == 2))
    values = [row[key] for row in formal]
    mean = statistics.mean(values) if valid else None
    result = dict(group=group['group'], revision=preparation['revision'], measure=key,
        values=values, mean=mean, limit=limit, valid=valid, invalidIndices=sorted(set(invalid)),
        verdict=('PASS' if mean <= limit else 'FAIL') if valid else 'INVALID',
        samplesFile=str(output / 'samples.jsonl'), environmentFile=str(output / 'env-snapshot.txt'))
    results.append(result)
    print(json.dumps(result), flush=True)
summary = dict(collectionComplete=[row['group'] for row in groups] == preparation['plannedGroups'],
    valid=all(row['valid'] for row in results),
    verdict='PASS' if all(row['verdict'] == 'PASS' for row in results) else 'NOT_PASS', groups=results)
(root / 'judgment.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
raise SystemExit(0 if summary['collectionComplete'] and summary['verdict'] == 'PASS' else 2)
