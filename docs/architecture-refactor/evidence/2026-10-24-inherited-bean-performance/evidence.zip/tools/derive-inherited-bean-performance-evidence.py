"""Bind the completed formal run to the unchanged Windows sampler and Git source."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

tools = Path(__file__).resolve().parent
root = tools / '2026-10-24-inherited-bean-performance-preparation'
revision = json.loads((root / 'performance-source-binding.json').read_text())['revision']
for name in ['formal-performance.py', 'judge-performance.py']:
    destination = root / name
    assert not destination.exists()
    shutil.copyfile(tools / ('inherited-bean-' + name), destination)
blob = subprocess.check_output(['git', 'show', revision + ':bench/perf/sample.ps1'])
working = Path('D:/mcmodDemo/NekoJS-perf-606d1fff/bench/perf/sample.ps1').read_bytes()
assert blob.replace(b'\r\n', b'\n') == working.replace(b'\r\n', b'\n')
assert hashlib.sha256(working).hexdigest() == '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
(root / 'provenance.json').write_text(json.dumps(dict(revision=revision,
    originalSamplerSha256=hashlib.sha256(working).hexdigest(), samplerGitBlobSha256=hashlib.sha256(blob).hexdigest(),
    sameSamplerAfterLineEndNormalization=True,
    preliminaryProvenanceCheck='Windows raw bytes independently guarded before every group; Git LF contents match after normalization. No preliminary hash failure in this candidate.',
    wrapperSha256=hashlib.sha256((root / 'formal-performance.py').read_bytes()).hexdigest(),
    policy='Original runServer sampler and fixtures; startup warmup2/samples5, two reload groups of five; thresholds285.3ms/41173ms; no other owned game or compiler test jobs during collection.'), indent=2) + '\n')
source = (tools / 'seal-method-bounds-performance.py').read_text(encoding='utf8')
source = source.replace('final-975496d3-formal', 'final-87baad4b-formal').replace('method-bounds', 'inherited-bean')
source = source.replace("'prepare-inherited-bean-formal-provenance.py'", "'derive-inherited-bean-performance-evidence.py'")
target = tools / 'seal-inherited-bean-performance.py'
assert not target.exists()
target.write_text(source, encoding='utf8', newline='\n')
print('UNCHANGED_FORMAL_POLICY_PROVENANCE_BOUND')
