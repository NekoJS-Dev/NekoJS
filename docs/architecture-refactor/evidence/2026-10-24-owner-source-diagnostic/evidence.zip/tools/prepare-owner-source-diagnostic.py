"""Instrument successful module preparation phases in the owned performance checkout only."""
import hashlib
import json
from pathlib import Path
import subprocess

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = tools / '6e43b827-source-diagnostic'
revision = '6e43b82789a7dbf7b9659dc1c21fefecac662649'
relative = 'common/src/main/java/com/tkisor/nekojs/core/module/NekoModulePipelineCache.java'
assert not out.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
out.mkdir()
target = tree / relative
original = target.read_bytes()
(out / 'NekoModulePipelineCache.java.original').write_bytes(original)
source = original.decode('utf-8').replace('\r\n', '\n')
edits = [
    ('''    public NekoPreparedModule prepare(Path path) throws IOException {
        ensureOpen();
        Path key = key(path);
        NekoTrustApprovedSource approval = approvedSource(key);
        try {
            SourceSnapshot source = readSource(key);''',
     '''    public NekoPreparedModule prepare(Path path) throws IOException {
        ensureOpen();
        var profile = new SourcePreparationDiagnostic();
        profile.begin();
        long phaseStarted = System.nanoTime();
        Path key = key(path);
        profile.keyNanos = System.nanoTime() - phaseStarted;
        phaseStarted = System.nanoTime();
        NekoTrustApprovedSource approval = approvedSource(key);
        profile.approvalNanos = System.nanoTime() - phaseStarted;
        try {
            SourceSnapshot source = readSource(key, profile);'''),
    ('''            PreparedEntry entry = preparedCache.compute(key, (k, existing) -> {
                if (existing != null && existing.stamp().equals(source.stamp())) {
                    return existing;
                }
                try {
                    NekoPreparedModule prepared = prepareSource(k, source, approval, bindingSchemaViewFor(k));''',
     '''            long computeStarted = System.nanoTime();
            PreparedEntry entry = preparedCache.compute(key, (k, existing) -> {
                if (existing != null && existing.stamp().equals(source.stamp())) {
                    profile.cacheHit = true;
                    return existing;
                }
                try {
                    long prepareStarted = System.nanoTime();
                    NekoPreparedModule prepared = prepareSource(k, source, approval, bindingSchemaViewFor(k));
                    profile.pipelineNanos = System.nanoTime() - prepareStarted;'''),
    ('''            publishSourceMap(key, entry.prepared());
            for (BiConsumer<Path, String> observer : preparationObservers) {
                observer.accept(key, entry.prepared().cacheKey());
            }
            return entry.prepared();''',
     '''            profile.computeNanos = System.nanoTime() - computeStarted;
            phaseStarted = System.nanoTime();
            publishSourceMap(key, entry.prepared());
            for (BiConsumer<Path, String> observer : preparationObservers) {
                observer.accept(key, entry.prepared().cacheKey());
            }
            profile.publishNanos = System.nanoTime() - phaseStarted;
            profile.end();
            profile.modulePathSha256 = NekoModuleHash.sha256(key.toString());
            profile.sourceChars = source.source().length();
            profile.commit();
            return entry.prepared();'''),
    ('private SourceSnapshot readSource(Path path) throws IOException {',
     'private SourceSnapshot readSource(Path path, SourcePreparationDiagnostic profile) throws IOException {'),
    ('''            source = Files.readString(path);
        } catch (IOException failure) {
            throw NekoModuleError.cache''',
     '''            long phaseStarted = System.nanoTime();
            source = Files.readString(path);
            profile.readNanos = System.nanoTime() - phaseStarted;
        } catch (IOException failure) {
            throw NekoModuleError.cache'''),
    ('''            binding = pipeline.captureBinding(path);
        } catch (Exception failure) {''',
     '''            long phaseStarted = System.nanoTime();
            binding = pipeline.captureBinding(path);
            profile.bindingNanos = System.nanoTime() - phaseStarted;
        } catch (Exception failure) {'''),
    ('stamp = FileStamp.read(path, source, binding.identity(), binding.registryRevision());',
     'stamp = FileStamp.read(path, source, binding.identity(), binding.registryRevision(), profile);'),
    ('''                                     long registryRevision) throws IOException {
            BasicFileAttributes attributes = Files.readAttributes(path, BasicFileAttributes.class);
            return new FileStamp(attributes.lastModifiedTime().toMillis(), attributes.size(),
                    contentHash(source), identity, registryRevision);''',
     '''                                     long registryRevision, SourcePreparationDiagnostic profile) throws IOException {
            long phaseStarted = System.nanoTime();
            BasicFileAttributes attributes = Files.readAttributes(path, BasicFileAttributes.class);
            long modifiedMillis = attributes.lastModifiedTime().toMillis();
            long size = attributes.size();
            profile.attributesNanos = System.nanoTime() - phaseStarted;
            phaseStarted = System.nanoTime();
            String hash = contentHash(source);
            profile.hashNanos = System.nanoTime() - phaseStarted;
            return new FileStamp(modifiedMillis, size, hash, identity, registryRevision);'''),
]
for before, after in edits:
    assert source.count(before) == 1, before
    source = source.replace(before, after)
event = '''
    /** Temporary successful-preparation phase measurements; no source contents or paths. */
    @jdk.jfr.Name("neko.SourcePreparation6e")
    @jdk.jfr.Label("Module source preparation diagnostic")
    @jdk.jfr.StackTrace(false)
    static final class SourcePreparationDiagnostic extends jdk.jfr.Event {
        public String modulePathSha256;
        public int sourceChars;
        public boolean cacheHit;
        public long keyNanos;
        public long approvalNanos;
        public long readNanos;
        public long bindingNanos;
        public long attributesNanos;
        public long hashNanos;
        public long computeNanos;
        public long pipelineNanos;
        public long publishNanos;
    }
'''
source = source[:source.rfind('}')] + event + source[source.rfind('}'):]
target.write_text(source, encoding='utf-8', newline='\n')
(out / 'binding.json').write_text(json.dumps(dict(revision=revision, diagnosticOnly=True,
    successfulPreparationsOnly=True, bindings=[dict(path=relative, originalSha256=hashlib.sha256(original).hexdigest(),
        instrumentedSha256=hashlib.sha256(target.read_bytes()).hexdigest())]), indent=2) + '\n', encoding='utf-8')
(out / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', relative], cwd=tree))
controller = (tools / '6e43b827-map-diagnostic/diagnostic.ps1').read_text(encoding='utf-8')
assert controller.count('6e43b827-map-diagnostic/session') == 1
controller = controller.replace('6e43b827-map-diagnostic/session', '6e43b827-source-diagnostic/session')
(out / 'diagnostic.ps1').write_text(controller, encoding='utf-8', newline='\n')
(out / 'run.py').write_bytes((tools / '6e43b827-map-diagnostic/run.py').read_bytes())
print(json.dumps(dict(prepared=True, revision=revision, temporarySourceFiles=1, successfulPreparationsOnly=True)))
