"""Preserve instrumented bindings, then restore the exact original owned source bytes."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

tools = Path(__file__).resolve().parent
root = tools / '6e43b827-source-diagnostic'
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
binding = json.loads((root / 'binding.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == binding['revision']
assert json.loads((root / 'exit.json').read_text())['exitCode'] == 0
classes = {}
for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    base = tree / relative
    for path in base.rglob('*.class'):
        name = path.relative_to(base).as_posix()
        assert name not in classes
        classes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
jars = list((tree / 'versions/26.1.2/build/libs').glob('*.jar'))
assert len(jars) == 1
artifact = jars[0]
shutil.copyfile(artifact, root / ('instrumented-' + artifact.name))
(root / 'instrumented-artifact.json').write_text(json.dumps(dict(sourceRevision=binding['revision'],
    diagnosticOnly=True, classBindings=classes, classCount=len(classes), artifact=artifact.name,
    sha256=hashlib.sha256(artifact.read_bytes()).hexdigest()), indent=2) + '\n')
assert subprocess.check_output(['git', 'diff', '--name-only'], cwd=tree, text=True).strip().replace('\\', '/') == binding['bindings'][0]['path']
row = binding['bindings'][0]
target = tree / row['path']
original = (root / 'NekoModulePipelineCache.java.original').read_bytes()
assert hashlib.sha256(original).hexdigest() == row['originalSha256']
assert hashlib.sha256(target.read_bytes()).hexdigest() == row['instrumentedSha256']
target.write_bytes(original)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
print(json.dumps(dict(sourceRestored=True, instrumentedClasses=len(classes), buildRestoreRequired=True)))
