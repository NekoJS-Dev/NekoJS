"""Associate source preparation events with real successful reload commands."""
from collections import Counter, defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent / '6e43b827-source-diagnostic'
events = json.loads((root / 'events.json').read_text(encoding='utf-8-sig'))['recording']['events']
observations = json.loads((root / 'session/observations.json').read_text(encoding='utf-8-sig'))
session = json.loads((root / 'session/session.json').read_text(encoding='utf-8-sig'))
assert not session['forcedKill'] and not session['extra']['killed'] and session['extra']['stopChannel'] == 'rcon'
assert len(observations) == 20
reloads = [row for row in observations if row['command'] == 'nekojs reload']
assert len(reloads) == 10
phases = ['keyNanos', 'approvalNanos', 'readNanos', 'bindingNanos', 'attributesNanos', 'hashNanos',
          'computeNanos', 'pipelineNanos', 'publishNanos']
used = set()
rows = []
modules = defaultdict(list)
for row in reloads:
    assert 'phase=COMMIT - no errors.' in row['response'] and row['markerMs'] is not None
    start, end = datetime.fromisoformat(row['startedUtc']), datetime.fromisoformat(row['returnedUtc'])
    current = []
    for index, event in enumerate(events):
        values = event['values']
        if start <= datetime.fromisoformat(values['startTime']) <= end:
            assert index not in used and event['type'] == 'neko.SourcePreparation6e'
            assert values['eventThread']['javaName'] == 'Server thread'
            assert all(values[name] >= 0 for name in phases)
            assert values['pipelineNanos'] <= values['computeNanos']
            if values['cacheHit']:
                assert values['pipelineNanos'] == 0
            used.add(index)
            current.append(values)
            modules[values['modulePathSha256']].append(dict(pair=row['pair'], **values))
    assert current, row['pair']
    rows.append(dict(pair=row['pair'], preparationEvents=len(current), cacheHits=sum(value['cacheHit'] for value in current),
        markerMs=row['markerMs'], phaseMs={name.removesuffix('Nanos'): sum(value[name] for value in current) / 1e6 for name in phases}))
assert len(used) == len(events)
result = dict(sourceRevision=json.loads((root / 'binding.json').read_text())['revision'], diagnosticOnly=True,
    successfulPreparationsOnly=True, successfulReloads=10, controlQueries=10, normalStops=1,
    preparationEvents=len(events), distinctModulePaths=len(modules),
    eventsPerReload=dict(Counter(row['preparationEvents'] for row in rows)),
    cacheHits=sum(row['cacheHits'] for row in rows), rows=rows,
    phaseMeanMs={name.removesuffix('Nanos'): statistics.mean(row['phaseMs'][name.removesuffix('Nanos')] for row in rows) for name in phases},
    moduleCalls={key: len(values) for key, values in sorted(modules.items())},
    rawEventsSha256=hashlib.sha256((root / 'events.json').read_bytes()).hexdigest(),
    limits=['Successful prepare(Path) calls only; JSON reads, failed paths and other canonical/trust callers are not measured.',
        'compute includes pipeline; do not add pipeline again when summing phase times.',
        'Instrumentation, JFR and different cadence are not formal policy measurements or causal savings.',
        'No source contents or raw paths in diagnostic event fields; module hashes are not credential hashes.'])
(root / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result.items() if key not in ['rows', 'moduleCalls', 'limits']}))
