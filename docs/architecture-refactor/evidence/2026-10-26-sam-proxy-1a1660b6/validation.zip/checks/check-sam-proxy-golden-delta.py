from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

root = Path('common/src/test/resources/nekojs/probe/legacy-tree')
changes = []
flags = json.loads(Path('build/sam-proxy-jdk-sealed-flags.json').read_text(encoding='utf-8'))
with ZipFile('build/sam-proxy-goldens-before.zip') as before:
    assert set(before.namelist()) == {p.as_posix() for p in root.rglob('*') if p.is_file()}
    for name in before.namelist():
        old_bytes = before.read(name)
        new_bytes = Path(name).read_bytes()
        if old_bytes == new_bytes:
            continue
        assert b'\r' not in old_bytes + new_bytes, name
        old_lines, new_lines = old_bytes.decode('utf-8').splitlines(), new_bytes.decode('utf-8').splitlines()
        assert len(old_lines) == len(new_lines), name
        lines = []
        package = name.split('/@package/', 1)[1].removesuffix('/index.d.ts').replace('/', '.')
        for index, (old, new) in enumerate(zip(old_lines, new_lines), 1):
            if old == new:
                continue
            assert old.strip().startswith('export type $') and old.endswith(';'), (name, index)
            host_expression = old.rsplit(' | (', 1)[1].removesuffix(');')
            host_name = host_expression.split(' & ', 1)[0].removeprefix('$').split('<', 1)[0]
            fqn = package + '.' + host_name
            if flags[fqn]:
                assert new == old.rsplit(' = (', 1)[0] + ' = (' + host_expression + ');', (name, index)
                lines.append({'line': index, 'interface': fqn, 'sealedHostOnly': True})
                continue
            assert new.startswith(old[:-1]), (name, index)
            added = new[len(old[:-1]):]
            start = ' | (globalThis.NoInfer<{ readonly '
            assert added.startswith(start), (name, index)
            java_name, end = json.JSONDecoder().raw_decode(added[len(start):])
            callback = old.rsplit(' = (', 1)[1].split(') | (', 1)[0]
            assert added[len(start) + end:] == ': ' + callback + ' } & { readonly [Symbol.hasInstance]?: never }>);', (name, index)
            lines.append({'line': index, 'interface': fqn, 'javaMethodName': java_name, 'sealedHostOnly': False})
        changes.append({'file': name, 'oldSha256': sha256(old_bytes).hexdigest(),
                        'newSha256': sha256(new_bytes).hexdigest(), 'addedProxyBranches': lines})
report = {'changedFiles': len(changes),
          'addedProxyBranches': sum(not line['sealedHostOnly'] for c in changes for line in c['addedProxyBranches']),
          'sealedHostOnlyAliases': sum(line['sealedHostOnly'] for c in changes for line in c['addedProxyBranches']),
          'nonsealedOldBranchesRetained': True, 'sealedAliasNameArityHostAndAllMembersRetained': True, 'changes': changes}
Path('build/sam-proxy-golden-delta.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print('PASS:', report['changedFiles'], 'files;', report['addedProxyBranches'], 'proxy branches;',
      report['sealedHostOnlyAliases'], 'sealed host-only aliases; members, names, arities and order retained')
