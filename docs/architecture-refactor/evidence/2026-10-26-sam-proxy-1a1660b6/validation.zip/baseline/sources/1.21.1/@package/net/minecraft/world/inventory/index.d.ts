import { $Pair } from "java:com/mojang/datafixers/util";
import { $Enum, $Runnable, $Runnable_ } from "java:java/lang";
import { $List, $Optional, $OptionalInt, $Set } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $HolderLookup$Provider, $Holder_, $NonNullList } from "java:net/minecraft/core";
import { $ListTag } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $Container, $SimpleContainer } from "java:net/minecraft/world";
import { $MobEffect, $MobEffect_ } from "java:net/minecraft/world/effect";
import { $Inventory, $Player, $StackedContents } from "java:net/minecraft/world/entity/player";
import { $FeatureElement, $FeatureElement_, $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $AbstractCookingRecipe, $CraftingInput, $CraftingInput$Positioned, $CraftingRecipe, $RecipeHolder, $SingleRecipeInput, $StonecutterRecipe } from "java:net/minecraft/world/item/crafting";
import { $Merchant, $MerchantOffers } from "java:net/minecraft/world/item/trading";
import { $Level } from "java:net/minecraft/world/level";
import { $BannerPattern, $BlockEntity, $EnderChestBlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $IExtensibleEnum } from "java:net/neoforged/fml/common/asm/enumextension";
import { $IMenuTypeExtension, $IMenuTypeExtension_ } from "java:net/neoforged/neoforge/common/extensions";

export * as tooltip from "java:net/minecraft/world/inventory/tooltip";

declare module "java:net/minecraft/world/inventory" {
    export class $AbstractContainerMenu {
        static CARRIED_SLOT_SIZE: number;
        static QUICKCRAFT_HEADER_CONTINUE: number;
        static QUICKCRAFT_HEADER_END: number;
        static QUICKCRAFT_HEADER_START: number;
        static QUICKCRAFT_TYPE_CHARITABLE: number;
        static QUICKCRAFT_TYPE_CLONE: number;
        static QUICKCRAFT_TYPE_GREEDY: number;
        static SLOT_CLICKED_OUTSIDE: number;
        containerId: number;
        slots: $NonNullList<$Slot>;
        get carried(): $ItemStack;
        getCarried(): $ItemStack;
        set carried(value: $ItemStack_);
        get items(): $NonNullList<$ItemStack>;
        getItems(): $NonNullList<$ItemStack>;
        get stateId(): number;
        getStateId(): number;
        get type(): $MenuType<any>;
        getType(): $MenuType<any>;
        static canItemQuickReplace(arg0: $Slot, arg1: $ItemStack_, arg2: boolean): boolean;
        static getQuickCraftPlaceCount(arg0: $Set<$Slot>, arg1: number, arg2: $ItemStack_): number;
        static getQuickcraftHeader(arg0: number): number;
        static getQuickcraftMask(arg0: number, arg1: number): number;
        static getQuickcraftType(arg0: number): number;
        static getRedstoneSignalFromBlockEntity(arg0: $BlockEntity): number;
        static getRedstoneSignalFromContainer(arg0: $Container): number;
        static isValidQuickcraftType(arg0: number, arg1: $Player): boolean;
        addSlotListener(arg0: $ContainerListener): void;
        broadcastChanges(): void;
        broadcastFullState(): void;
        canDragTo(arg0: $Slot): boolean;
        canTakeItemForPickAll(arg0: $ItemStack_, arg1: $Slot): boolean;
        clickMenuButton(arg0: $Player, arg1: number): boolean;
        clicked(arg0: number, arg1: number, arg2: $ClickType_, arg3: $Player): void;
        findSlot(arg0: $Container, arg1: number): $OptionalInt;
        getSlot(arg0: number): $Slot;
        incrementStateId(): number;
        initializeContents(arg0: number, arg1: ($List<$ItemStack> | ($ItemStack_)[]), arg2: $ItemStack_): void;
        isValidSlotIndex(arg0: number): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removeSlotListener(arg0: $ContainerListener): void;
        removed(arg0: $Player): void;
        resumeRemoteUpdates(): void;
        sendAllDataToRemote(): void;
        setCarried(arg0: $ItemStack_): void;
        setData(arg0: number, arg1: number): void;
        setItem(arg0: number, arg1: number, arg2: $ItemStack_): void;
        setRemoteCarried(arg0: $ItemStack_): void;
        setRemoteSlotNoCopy(arg0: number, arg1: $ItemStack_): void;
        setRemoteSlot(arg0: number, arg1: $ItemStack_): void;
        setSynchronizer(arg0: $ContainerSynchronizer): void;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
        suppressRemoteUpdates(): void;
        transferState(arg0: $AbstractContainerMenu): void;
    }

    export class $AbstractFurnaceMenu extends $RecipeBookMenu<$SingleRecipeInput, $AbstractCookingRecipe> {
        static DATA_COUNT: number;
        static FUEL_SLOT: number;
        static INGREDIENT_SLOT: number;
        static RESULT_SLOT: number;
        static SLOT_COUNT: number;
        get burnProgress(): number;
        getBurnProgress(): number;
        get gridHeight(): number;
        getGridHeight(): number;
        get gridWidth(): number;
        getGridWidth(): number;
        get litProgress(): number;
        getLitProgress(): number;
        get recipeBookType(): $RecipeBookType;
        getRecipeBookType(): $RecipeBookType;
        get resultSlotIndex(): number;
        getResultSlotIndex(): number;
        get size(): number;
        getSize(): number;
        get lit(): boolean;
        isLit(): boolean;
        clearCraftingContent(): void;
        fillCraftSlotsStackedContents(arg0: $StackedContents): void;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        recipeMatches(arg0: $RecipeHolder<$AbstractCookingRecipe>): boolean;
        shouldMoveToInventory(arg0: number): boolean;
        stillValid(arg0: $Player): boolean;
    }

    export class $AnvilMenu extends $ItemCombinerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        static ADDITIONAL_SLOT: number;
        static INPUT_SLOT: number;
        static MAX_NAME_LENGTH: number;
        static RESULT_SLOT: number;
        repairItemCountCost: number;
        get cost(): number;
        getCost(): number;
        static calculateIncreasedRepairCost(arg0: number): number;
        createResult(): void;
        setItemName(arg0: string): boolean;
        setMaximumCost(arg0: number): void;
    }

    export class $BeaconMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Container);
        constructor(arg0: number, arg1: $Container, arg2: $ContainerData, arg3: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        get levels(): number;
        getLevels(): number;
        get primaryEffect(): $Holder<$MobEffect>;
        getPrimaryEffect(): $Holder<$MobEffect>;
        get secondaryEffect(): $Holder<$MobEffect>;
        getSecondaryEffect(): $Holder<$MobEffect>;
        static decodeEffect(arg0: number): $Holder<$MobEffect>;
        static encodeEffect(arg0: $Holder_<$MobEffect>): number;
        hasPayment(): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        setData(arg0: number, arg1: number): void;
        stillValid(arg0: $Player): boolean;
        updateEffects(arg0: $Optional<$Holder<$MobEffect>>, arg1: $Optional<$Holder<$MobEffect>>): void;
    }

    export class $BlastFurnaceMenu extends $AbstractFurnaceMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $Container, arg3: $ContainerData);
    }

    export class $BrewingStandMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $Container, arg3: $ContainerData);
        get brewingTicks(): number;
        getBrewingTicks(): number;
        get fuel(): number;
        getFuel(): number;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        stillValid(arg0: $Player): boolean;
    }

    export class $CartographyTableMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        static ADDITIONAL_SLOT: number;
        static MAP_SLOT: number;
        static RESULT_SLOT: number;
        container: $Container;
        canTakeItemForPickAll(arg0: $ItemStack_, arg1: $Slot): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $ChestMenu extends $AbstractContainerMenu {
        constructor(arg0: $MenuType<any>, arg1: number, arg2: $Inventory, arg3: $Container, arg4: number);
        get container(): $Container;
        getContainer(): $Container;
        get rowCount(): number;
        getRowCount(): number;
        static fiveRows(arg0: number, arg1: $Inventory): $ChestMenu;
        static fourRows(arg0: number, arg1: $Inventory): $ChestMenu;
        static oneRow(arg0: number, arg1: $Inventory): $ChestMenu;
        static sixRows(arg0: number, arg1: $Inventory, arg2: $Container): $ChestMenu;
        static sixRows(arg0: number, arg1: $Inventory): $ChestMenu;
        static threeRows(arg0: number, arg1: $Inventory, arg2: $Container): $ChestMenu;
        static threeRows(arg0: number, arg1: $Inventory): $ChestMenu;
        static twoRows(arg0: number, arg1: $Inventory): $ChestMenu;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $ClickAction {
        static PRIMARY: $ClickAction;
        static SECONDARY: $ClickAction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClickAction[];
        static valueOf(name: string): $ClickAction;
    }
    export interface $ClickAction extends $Enum<$ClickAction> {}

    export class $ClickType {
        static CLONE: $ClickType;
        static PICKUP: $ClickType;
        static PICKUP_ALL: $ClickType;
        static QUICK_CRAFT: $ClickType;
        static QUICK_MOVE: $ClickType;
        static SWAP: $ClickType;
        static THROW: $ClickType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClickType[];
        static valueOf(name: string): $ClickType;
    }
    export interface $ClickType extends $Enum<$ClickType> {}

    export interface $ContainerData {
        getCount(): number;
        get(arg0: number): number;
        set(arg0: number, arg1: number): void;
    }

    export interface $ContainerLevelAccess {
        evaluate<T>(arg0: $BiFunction_<$Level, $BlockPos, T, $Level, $BlockPos, T>, arg1: T): T;
        evaluate<T>(arg0: $BiFunction_<$Level, $BlockPos, T, $Level, $BlockPos, T>): $Optional<T>;
        execute(arg0: $BiConsumer_<$Level, $BlockPos, $Level, $BlockPos>): void;
    }
    export const $ContainerLevelAccess: {
        create(arg0: $Level, arg1: $BlockPos_): $ContainerLevelAccess;
        readonly NULL: $ContainerLevelAccess;
    };

    export interface $ContainerListener {
        dataChanged(arg0: $AbstractContainerMenu, arg1: number, arg2: number): void;
        slotChanged(arg0: $AbstractContainerMenu, arg1: number, arg2: $ItemStack_): void;
    }

    export interface $ContainerSynchronizer {
        sendCarriedChange(arg0: $AbstractContainerMenu, arg1: $ItemStack_): void;
        sendDataChange(arg0: $AbstractContainerMenu, arg1: number, arg2: number): void;
        sendInitialData(arg0: $AbstractContainerMenu, arg1: $NonNullList<$ItemStack>, arg2: $ItemStack_, arg3: number[]): void;
        sendSlotChange(arg0: $AbstractContainerMenu, arg1: number, arg2: $ItemStack_): void;
    }

    export class $CrafterMenu extends $AbstractContainerMenu implements $ContainerListener {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $CraftingContainer, arg3: $ContainerData);
        get container(): $Container;
        getContainer(): $Container;
        get powered(): boolean;
        isPowered(): boolean;
        dataChanged(arg0: $AbstractContainerMenu, arg1: number, arg2: number): void;
        isSlotDisabled(arg0: number): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        setSlotState(arg0: number, arg1: boolean): void;
        slotChanged(arg0: $AbstractContainerMenu, arg1: number, arg2: $ItemStack_): void;
        stillValid(arg0: $Player): boolean;
    }

    export interface $CraftingContainer extends $Container, $StackedContentsCompatible {
        asCraftInput(): $CraftingInput;
        asPositionedCraftInput(): $CraftingInput$Positioned;
        getHeight(): number;
        getItems(): $List<$ItemStack>;
        getWidth(): number;
    }

    export class $CraftingMenu extends $RecipeBookMenu<$CraftingInput, $CraftingRecipe> {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        static RESULT_SLOT: number;
        player: $Player;
        get gridHeight(): number;
        getGridHeight(): number;
        get gridWidth(): number;
        getGridWidth(): number;
        get recipeBookType(): $RecipeBookType;
        getRecipeBookType(): $RecipeBookType;
        get resultSlotIndex(): number;
        getResultSlotIndex(): number;
        get size(): number;
        getSize(): number;
        beginPlacingRecipe(): void;
        canTakeItemForPickAll(arg0: $ItemStack_, arg1: $Slot): boolean;
        clearCraftingContent(): void;
        fillCraftSlotsStackedContents(arg0: $StackedContents): void;
        finishPlacingRecipe(arg0: $RecipeHolder<$CraftingRecipe>): void;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        recipeMatches(arg0: $RecipeHolder<$CraftingRecipe>): boolean;
        removed(arg0: $Player): void;
        shouldMoveToInventory(arg0: number): boolean;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $DispenserMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $Container);
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $EnchantmentMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        costs: number[];
        enchantClue: number[];
        levelClue: number[];
        get enchantmentSeed(): number;
        getEnchantmentSeed(): number;
        get goldCount(): number;
        getGoldCount(): number;
        clickMenuButton(arg0: $Player, arg1: number): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $FurnaceMenu extends $AbstractFurnaceMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $Container, arg3: $ContainerData);
    }

    export class $GrindstoneMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        static ADDITIONAL_SLOT: number;
        static INPUT_SLOT: number;
        static MAX_NAME_LENGTH: number;
        static RESULT_SLOT: number;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $HopperMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $Container);
        static CONTAINER_SIZE: number;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $InventoryMenu extends $RecipeBookMenu<$CraftingInput, $CraftingRecipe> {
        constructor(arg0: $Inventory, arg1: boolean, arg2: $Player);
        static ARMOR_SLOT_COUNT: number;
        static ARMOR_SLOT_END: number;
        static ARMOR_SLOT_START: number;
        static BLOCK_ATLAS: $ResourceLocation;
        static CONTAINER_ID: number;
        static CRAFT_SLOT_COUNT: number;
        static CRAFT_SLOT_END: number;
        static CRAFT_SLOT_START: number;
        static EMPTY_ARMOR_SLOT_BOOTS: $ResourceLocation;
        static EMPTY_ARMOR_SLOT_CHESTPLATE: $ResourceLocation;
        static EMPTY_ARMOR_SLOT_HELMET: $ResourceLocation;
        static EMPTY_ARMOR_SLOT_LEGGINGS: $ResourceLocation;
        static EMPTY_ARMOR_SLOT_SHIELD: $ResourceLocation;
        static INV_SLOT_END: number;
        static INV_SLOT_START: number;
        static RESULT_SLOT: number;
        static SHIELD_SLOT: number;
        static USE_ROW_SLOT_END: number;
        static USE_ROW_SLOT_START: number;
        active: boolean;
        owner: $Player;
        get craftSlots(): $CraftingContainer;
        getCraftSlots(): $CraftingContainer;
        get gridHeight(): number;
        getGridHeight(): number;
        get gridWidth(): number;
        getGridWidth(): number;
        get recipeBookType(): $RecipeBookType;
        getRecipeBookType(): $RecipeBookType;
        get resultSlotIndex(): number;
        getResultSlotIndex(): number;
        get size(): number;
        getSize(): number;
        static isHotbarSlot(arg0: number): boolean;
        canTakeItemForPickAll(arg0: $ItemStack_, arg1: $Slot): boolean;
        clearCraftingContent(): void;
        fillCraftSlotsStackedContents(arg0: $StackedContents): void;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        recipeMatches(arg0: $RecipeHolder<$CraftingRecipe>): boolean;
        removed(arg0: $Player): void;
        shouldMoveToInventory(arg0: number): boolean;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $ItemCombinerMenu extends $AbstractContainerMenu {
        constructor(arg0: $MenuType<any>, arg1: number, arg2: $Inventory, arg3: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        get resultSlot(): number;
        getResultSlot(): number;
        createResult(): void;
        getSlotToQuickMoveTo(arg0: $ItemStack_): number;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $LecternMenu extends $AbstractContainerMenu {
        constructor(arg0: number);
        constructor(arg0: number, arg1: $Container, arg2: $ContainerData);
        static BUTTON_NEXT_PAGE: number;
        static BUTTON_PAGE_JUMP_RANGE_START: number;
        static BUTTON_PREV_PAGE: number;
        static BUTTON_TAKE_BOOK: number;
        get book(): $ItemStack;
        getBook(): $ItemStack;
        get page(): number;
        getPage(): number;
        clickMenuButton(arg0: $Player, arg1: number): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        setData(arg0: number, arg1: number): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $LoomMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        get bannerSlot(): $Slot;
        getBannerSlot(): $Slot;
        get dyeSlot(): $Slot;
        getDyeSlot(): $Slot;
        get patternSlot(): $Slot;
        getPatternSlot(): $Slot;
        get resultSlot(): $Slot;
        getResultSlot(): $Slot;
        get selectablePatterns(): $List<$Holder<$BannerPattern>>;
        getSelectablePatterns(): $List<$Holder<$BannerPattern>>;
        get selectedBannerPatternIndex(): number;
        getSelectedBannerPatternIndex(): number;
        clickMenuButton(arg0: $Player, arg1: number): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        registerUpdateListener(arg0: $Runnable_): void;
        removed(arg0: $Player): void;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
    }

    export interface $MenuConstructor {
        createMenu(arg0: number, arg1: $Inventory, arg2: $Player): $AbstractContainerMenu;
    }

    export class $MenuType<T extends $AbstractContainerMenu> implements $FeatureElement, $IMenuTypeExtension<T> {
        constructor(arg0: $MenuType$MenuSupplier_<T, number, $Inventory, T>, arg1: $FeatureFlagSet);
        static ANVIL: $MenuType<$AnvilMenu>;
        static BEACON: $MenuType<$BeaconMenu>;
        static BLAST_FURNACE: $MenuType<$BlastFurnaceMenu>;
        static BREWING_STAND: $MenuType<$BrewingStandMenu>;
        static CARTOGRAPHY_TABLE: $MenuType<$CartographyTableMenu>;
        static CRAFTER_3x3: $MenuType<$CrafterMenu>;
        static CRAFTING: $MenuType<$CraftingMenu>;
        static ENCHANTMENT: $MenuType<$EnchantmentMenu>;
        static FURNACE: $MenuType<$FurnaceMenu>;
        static GENERIC_3x3: $MenuType<$DispenserMenu>;
        static GENERIC_9x1: $MenuType<$ChestMenu>;
        static GENERIC_9x2: $MenuType<$ChestMenu>;
        static GENERIC_9x3: $MenuType<$ChestMenu>;
        static GENERIC_9x4: $MenuType<$ChestMenu>;
        static GENERIC_9x5: $MenuType<$ChestMenu>;
        static GENERIC_9x6: $MenuType<$ChestMenu>;
        static GRINDSTONE: $MenuType<$GrindstoneMenu>;
        static HOPPER: $MenuType<$HopperMenu>;
        static LECTERN: $MenuType<$LecternMenu>;
        static LOOM: $MenuType<$LoomMenu>;
        static MERCHANT: $MenuType<$MerchantMenu>;
        static SHULKER_BOX: $MenuType<$ShulkerBoxMenu>;
        static SMITHING: $MenuType<$SmithingMenu>;
        static SMOKER: $MenuType<$SmokerMenu>;
        static STONECUTTER: $MenuType<$StonecutterMenu>;
        create(arg0: number, arg1: $Inventory, arg2: $RegistryFriendlyByteBuf): T;
        create(arg0: number, arg1: $Inventory): T;
        isEnabled(arg0: $FeatureFlagSet): boolean;
        requiredFeatures(): $FeatureFlagSet;
    }

    export interface $MenuType$MenuSupplier<T extends $AbstractContainerMenu> {
        create(arg0: number, arg1: $Inventory): T;
    }

    export class $MerchantMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $Merchant);
        get futureTraderXp(): number;
        getFutureTraderXp(): number;
        get offers(): $MerchantOffers;
        getOffers(): $MerchantOffers;
        set offers(value: $MerchantOffers);
        get traderLevel(): number;
        getTraderLevel(): number;
        get traderXp(): number;
        getTraderXp(): number;
        canRestock(): boolean;
        canTakeItemForPickAll(arg0: $ItemStack_, arg1: $Slot): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        setCanRestock(arg0: boolean): void;
        setMerchantLevel(arg0: number): void;
        setOffers(arg0: $MerchantOffers): void;
        setSelectionHint(arg0: number): void;
        setShowProgressBar(arg0: boolean): void;
        setXp(arg0: number): void;
        showProgressBar(): boolean;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
        tryMoveItems(arg0: number): void;
    }

    export class $PlayerEnderChestContainer extends $SimpleContainer {
        constructor();
        get maxStackSize(): number;
        getMaxStackSize(): number;
        canPlaceItem(arg0: number, arg1: $ItemStack_): boolean;
        canTakeItem(arg0: $Container, arg1: number, arg2: $ItemStack_): boolean;
        countItem(arg0: $Item_): number;
        createTag(arg0: $HolderLookup$Provider): $ListTag;
        fromTag(arg0: $ListTag, arg1: $HolderLookup$Provider): void;
        getMaxStackSize(arg0: $ItemStack_): number;
        hasAnyMatching(arg0: $Predicate_<$ItemStack, $ItemStack, boolean>): boolean;
        hasAnyOf(arg0: $Set<$Item>): boolean;
        isActiveChest(arg0: $EnderChestBlockEntity): boolean;
        setActiveChest(arg0: $EnderChestBlockEntity): void;
        startOpen(arg0: $Player): void;
        stillValid(arg0: $Player): boolean;
        stopOpen(arg0: $Player): void;
    }

    export class $RecipeBookType {
        static BLAST_FURNACE: $RecipeBookType;
        static CRAFTING: $RecipeBookType;
        static FURNACE: $RecipeBookType;
        static SMOKER: $RecipeBookType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RecipeBookType[];
        static valueOf(name: string): $RecipeBookType;
    }
    export interface $RecipeBookType extends $Enum<$RecipeBookType>, $IExtensibleEnum {}

    export interface $RecipeCraftingHolder {
        awardUsedRecipes(arg0: $Player, arg1: ($List<$ItemStack> | ($ItemStack_)[])): void;
        getRecipeUsed(): $RecipeHolder<any>;
        setRecipeUsed(arg0: $RecipeHolder<any>): void;
        setRecipeUsed(arg0: $Level, arg1: $ServerPlayer, arg2: $RecipeHolder<any>): boolean;
    }

    export class $ShulkerBoxMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $Container);
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        removed(arg0: $Player): void;
        stillValid(arg0: $Player): boolean;
    }

    export class $Slot {
        constructor(arg0: $Container, arg1: number, arg2: number, arg3: number);
        container: $Container;
        index: number;
        x: number;
        y: number;
        get containerSlot(): number;
        getContainerSlot(): number;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get maxStackSize(): number;
        getMaxStackSize(): number;
        get noItemIcon(): $Pair<$ResourceLocation, $ResourceLocation>;
        getNoItemIcon(): $Pair<$ResourceLocation, $ResourceLocation>;
        get slotIndex(): number;
        getSlotIndex(): number;
        get active(): boolean;
        isActive(): boolean;
        get fake(): boolean;
        isFake(): boolean;
        get highlightable(): boolean;
        isHighlightable(): boolean;
        allowModification(arg0: $Player): boolean;
        getMaxStackSize(arg0: $ItemStack_): number;
        hasItem(): boolean;
        isSameInventory(arg0: $Slot): boolean;
        mayPickup(arg0: $Player): boolean;
        mayPlace(arg0: $ItemStack_): boolean;
        onQuickCraft(arg0: $ItemStack_, arg1: $ItemStack_): void;
        onTake(arg0: $Player, arg1: $ItemStack_): void;
        remove(arg0: number): $ItemStack;
        safeInsert(arg0: $ItemStack_, arg1: number): $ItemStack;
        safeInsert(arg0: $ItemStack_): $ItemStack;
        safeTake(arg0: number, arg1: number, arg2: $Player): $ItemStack;
        setBackground(arg0: $ResourceLocation_, arg1: $ResourceLocation_): $Slot;
        setByPlayer(arg0: $ItemStack_, arg1: $ItemStack_): void;
        setByPlayer(arg0: $ItemStack_): void;
        setChanged(): void;
        set(arg0: $ItemStack_): void;
        tryRemove(arg0: number, arg1: number, arg2: $Player): $Optional<$ItemStack>;
    }

    export class $SmithingMenu extends $ItemCombinerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        static ADDITIONAL_SLOT: number;
        static ADDITIONAL_SLOT_X_PLACEMENT: number;
        static BASE_SLOT: number;
        static BASE_SLOT_X_PLACEMENT: number;
        static RESULT_SLOT: number;
        static SLOT_Y_PLACEMENT: number;
        static TEMPLATE_SLOT: number;
        static TEMPLATE_SLOT_X_PLACEMENT: number;
        canMoveIntoInputSlots(arg0: $ItemStack_): boolean;
        canTakeItemForPickAll(arg0: $ItemStack_, arg1: $Slot): boolean;
        createResult(): void;
        getSlotToQuickMoveTo(arg0: $ItemStack_): number;
    }

    export class $SmokerMenu extends $AbstractFurnaceMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $Container, arg3: $ContainerData);
    }

    export interface $StackedContentsCompatible {
        fillStackedContents(arg0: $StackedContents): void;
    }

    export class $StonecutterMenu extends $AbstractContainerMenu {
        constructor(arg0: number, arg1: $Inventory);
        constructor(arg0: number, arg1: $Inventory, arg2: $ContainerLevelAccess_<$BiFunction<$Level, $BlockPos, any>, $Optional<any>>);
        static INPUT_SLOT: number;
        static RESULT_SLOT: number;
        container: $Container;
        get numRecipes(): number;
        getNumRecipes(): number;
        get recipes(): $List<$RecipeHolder<$StonecutterRecipe>>;
        getRecipes(): $List<$RecipeHolder<$StonecutterRecipe>>;
        get selectedRecipeIndex(): number;
        getSelectedRecipeIndex(): number;
        get type(): $MenuType<any>;
        getType(): $MenuType<any>;
        canTakeItemForPickAll(arg0: $ItemStack_, arg1: $Slot): boolean;
        clickMenuButton(arg0: $Player, arg1: number): boolean;
        hasInputItem(): boolean;
        quickMoveStack(arg0: $Player, arg1: number): $ItemStack;
        registerUpdateListener(arg0: $Runnable_): void;
        removed(arg0: $Player): void;
        slotsChanged(arg0: $Container): void;
        stillValid(arg0: $Player): boolean;
    }

    export type $ClickAction_ = $ClickAction | "PRIMARY" | "SECONDARY";
    export type $ClickType_ = $ClickType | "CLONE" | "PICKUP" | "PICKUP_ALL" | "QUICK_CRAFT" | "QUICK_MOVE" | "SWAP" | "THROW";
    export type $ContainerLevelAccess_<CallbackArg0 = $BiFunction<$Level, $BlockPos, any>, CallbackResult = $Optional<any>> = ((arg0: CallbackArg0) => CallbackResult) | ($ContainerLevelAccess & { readonly [Symbol.hasInstance]?: never });
    export type $MenuConstructor_<CallbackArg0 = number, CallbackArg1 = $Inventory, CallbackArg2 = $Player, CallbackResult = $AbstractContainerMenu> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($MenuConstructor & { readonly [Symbol.hasInstance]?: never });
    export type $MenuType$MenuSupplier_<Host0 extends $AbstractContainerMenu = any, CallbackArg0 = number, CallbackArg1 = $Inventory, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($MenuType$MenuSupplier<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $RecipeBookType_ = $RecipeBookType | "BLAST_FURNACE" | "CRAFTING" | "FURNACE" | "SMOKER";
    export type $StackedContentsCompatible_<CallbackArg0 = $StackedContents> = ((arg0: CallbackArg0) => void) | ($StackedContentsCompatible & { readonly [Symbol.hasInstance]?: never });
}
