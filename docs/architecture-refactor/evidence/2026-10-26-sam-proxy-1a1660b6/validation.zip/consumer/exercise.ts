import { $TypeScriptSamProxyInputTest$Calls as Calls }
    from 'java:com/tkisor/nekojs/probe';
import { $UnaryOperator } from 'java:java/util/function';
const unary: string = Calls.unary({apply: (value: string) => value + '!'});
const defaults: string = Calls.unaryDefault({apply: (value: string) => value});
const binary: string = Calls.binary({apply: (left: string, right: string) => left});
const remapped: string = Calls.remapped({original: (value: string) => value});
const callback: string = Calls.unary((value: string) => value);
const host: string = Calls.unary(Calls.hostUnary());
const closedHost: string = Calls.closed(Calls.hostClosed());
// @ts-expect-error A sealed interface cannot gain a proxy implementation.
Calls.closed({apply: (value: string) => value});
// @ts-expect-error Sealed interfaces cannot be implemented by executable callbacks either.
Calls.closed((value: string) => value);
// @ts-expect-error A proxy member must accept the actual operand kind.
Calls.unary({apply: (value: number) => value});
// @ts-expect-error A proxy member must produce the actual result kind.
Calls.unary({apply: (value: string) => 123});
// @ts-expect-error Function.apply must not bypass callback result checking.
Calls.unary((value: string) => 123);
// @ts-expect-error A class value is not a SAM instance or proxy implementation.
Calls.unary($UnaryOperator);
// @ts-expect-error A remapped operation's proxy still checks its Java operand kind.
Calls.remapped({original: (value: number) => value});
