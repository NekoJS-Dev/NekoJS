import { $Comparable, $Comparable_ } from "java:java/lang";
import { $Function, $Function_, $ToDoubleFunction, $ToDoubleFunction_, $ToIntFunction, $ToIntFunction_, $ToLongFunction, $ToLongFunction_ } from "java:java/util/function";

export * as function from "java:java/util/function";

declare module "java:java/util" {
    export interface $Comparator<T> {
        compare(arg0: T, arg1: T): number;
        equals(arg0: unknown): boolean;
        reversed(): $Comparator<T>;
        thenComparingDouble(arg0: $ToDoubleFunction_<T, T, number>): $Comparator<T>;
        thenComparingInt(arg0: $ToIntFunction_<T, T, number>): $Comparator<T>;
        thenComparingLong(arg0: $ToLongFunction_<T, T, number>): $Comparator<T>;
        thenComparing(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        thenComparing<U>(arg0: $Function_<T, U, T, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<T>;
        thenComparing<U extends $Comparable<any>>(arg0: $Function_<T, U, T, U>): $Comparator<T>;
    }
    export const $Comparator: {
        comparingDouble<T>(arg0: $ToDoubleFunction_<T, T, number>): $Comparator<T>;
        comparingInt<T>(arg0: $ToIntFunction_<T, T, number>): $Comparator<T>;
        comparingLong<T>(arg0: $ToLongFunction_<T, T, number>): $Comparator<T>;
        comparing<T, U>(arg0: $Function_<T, U, T, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<T>;
        comparing<T, U extends $Comparable<any>>(arg0: $Function_<T, U, T, U>): $Comparator<T>;
        naturalOrder<T extends $Comparable<any>>(): $Comparator<T>;
        nullsFirst<T>(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        nullsLast<T>(arg0: $Comparator_<T, T, T, number>): $Comparator<T>;
        reverseOrder<T extends $Comparable<any>>(): $Comparator<T>;
    };

    export type $Comparator_<Host0 = any, CallbackArg0 = Host0, CallbackArg1 = Host0, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($Comparator<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "compare": (arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
