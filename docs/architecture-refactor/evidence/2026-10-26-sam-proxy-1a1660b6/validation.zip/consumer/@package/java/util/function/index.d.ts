import { $Comparator, $Comparator_ } from "java:java/util";

declare module "java:java/util/function" {
    export interface $BinaryOperator<T> extends $BiFunction<T, T, T> {
    }
    export const $BinaryOperator: {
        maxBy<T>(arg0: $Comparator_<T, T, T, number>): $BinaryOperator<T>;
        minBy<T>(arg0: $Comparator_<T, T, T, number>): $BinaryOperator<T>;
    };

    export interface $UnaryOperator<T> extends $Function<T, T> {
    }
    export const $UnaryOperator: {
        identity<T>(): $UnaryOperator<T>;
    };

    export interface $BiFunction<T, U, R> {
        andThen<V>(arg0: $Function_<R, V, R, V>): $BiFunction<T, U, V>;
        apply(arg0: T, arg1: U): R;
    }

    export interface $Function<T, R> {
        andThen<V>(arg0: $Function_<R, V, R, V>): $Function<T, V>;
        apply(arg0: T): R;
        compose<V>(arg0: $Function_<V, T, V, T>): $Function<V, R>;
    }
    export const $Function: {
        identity<T>(): $Function<T, T>;
    };

    export interface $ToDoubleFunction<T> {
        applyAsDouble(arg0: T): number;
    }

    export interface $ToIntFunction<T> {
        applyAsInt(arg0: T): number;
    }

    export interface $ToLongFunction<T> {
        applyAsLong(arg0: T): number;
    }

    export type $BinaryOperator_<Host0 = any, CallbackArg0 = Host0, CallbackArg1 = Host0, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($BinaryOperator<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $UnaryOperator_<Host0 = any, CallbackArg0 = Host0, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($UnaryOperator<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $BiFunction_<Host0 = any, Host1 = any, Host2 = any, CallbackArg0 = Host0, CallbackArg1 = Host1, CallbackResult = Host2> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($BiFunction<Host0, Host1, Host2> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Function_<Host0 = any, Host1 = any, CallbackArg0 = Host0, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($Function<Host0, Host1> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $ToDoubleFunction_<Host0 = any, CallbackArg0 = Host0, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($ToDoubleFunction<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "applyAsDouble": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $ToIntFunction_<Host0 = any, CallbackArg0 = Host0, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($ToIntFunction<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "applyAsInt": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $ToLongFunction_<Host0 = any, CallbackArg0 = Host0, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($ToLongFunction<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "applyAsLong": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
