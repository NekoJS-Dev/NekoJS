import { $BinaryOperator, $BinaryOperator_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";

declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptSamProxyInputTest$Calls {
        constructor();
        static binary(operator: $BinaryOperator_<string, string, string, string>): string;
        static closed(operation: $TypeScriptSamProxyInputTest$ClosedOperation_<string, string>): string;
        static hostClosed(): $TypeScriptSamProxyInputTest$ClosedOperation;
        static hostUnary(): $UnaryOperator<string>;
        static remapped(operation: $TypeScriptSamProxyInputTest$RemappedOperation_<string, string>): string;
        static unaryDefault(operator: $UnaryOperator_<string, string, string>): string;
        static unary(operator: $UnaryOperator_<string, string, string>): string;
    }

    export interface $TypeScriptSamProxyInputTest$ClosedOperation {
        apply(value: string): string;
        description(): string;
    }

    export interface $TypeScriptSamProxyInputTest$RemappedOperation {
        renamed(value: string): string;
    }

    export type $TypeScriptSamProxyInputTest$ClosedOperation_<CallbackArg0 = string, CallbackResult = string> = ($TypeScriptSamProxyInputTest$ClosedOperation & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptSamProxyInputTest$RemappedOperation_<CallbackArg0 = string, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptSamProxyInputTest$RemappedOperation & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "original": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
