# Current 7d real configuration transaction windows

Official source/JAR 7d, four bound copies, fresh owned world/profiles and synthetic
clients C/D/E. No bridge, native activation/input or production/security changes.
Server25995/RCON25996; original-frame TCP proxies25997/25998. The proxy inspects
actual framed JSON and only delays/forwards identical bytes; no synthetic replies.

Baseline C real join/catch-up. Hold C PREPARE, release D handshake while awaiting
ACK; hold D PREPARE and disconnect before delivery, releasing C. Observe real
joined-mid-transaction, whole-batch abort, unchanged activated generation and
new item absence. Recover with C real ACK/activation/item presence. Hold C next
PREPARE, release E handshake, allow E real PREPARE/ACK then release C; observe
commit/task release/login and both actual ACK/activated reports/item presence.
All samples/failures retained. Owner-tick client stop handles logged-out/menu
states too; normal RCON server stop. No downloads/first pixel/all-node/human claim.
