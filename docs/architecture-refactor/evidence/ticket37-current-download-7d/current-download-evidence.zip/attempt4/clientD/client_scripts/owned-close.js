const ownedFs = require('node:fs');
const OwnedMinecraft = Java.type('net.minecraft.client.Minecraft');
let stopRequested = false;
ClientEvents.tickPost(() => {
    if (stopRequested || !ownedFs.existsSync('D:/mcmodDemo/NekoJS-mult/build/ticket37-current-download-7d-attempt4/clientD/nekojs/data/close-owned.txt')) return;
    stopRequested = true;
    console.info('WINDOW-OWNED-STOP requested=true');
    OwnedMinecraft.getInstance().stop();
});
