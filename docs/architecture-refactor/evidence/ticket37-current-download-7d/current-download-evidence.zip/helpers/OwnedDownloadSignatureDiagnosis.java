package com.tkisor.nekojs.core.pack.sync;

import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;

/** Compares the actual boot-mutated file set with the original signed file set. */
public final class OwnedDownloadSignatureDiagnosis {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]).toRealPath();
        Path pack = root.resolve("server/nekojs/packs/owned-download");
        String manifest = Files.readString(pack.resolve("manifest.json"));
        var files = PackHasher.readContentFiles(pack);
        var originalFiles = files.stream().filter(file -> !file.relativePath().equals("client_scripts/jsconfig.json")).toList();
        if (files.size() != 2 || originalFiles.size() != 1) throw new IllegalStateException("Unexpected owned fixture file set");
        var store = new PackSyncTrustStore(root.resolve("diagnostic-trust.json"));
        var actual = PackSignatureVerifier.verify("packs:owned-download", "GLOBAL", manifest, files, false, store);
        var original = PackSignatureVerifier.verify("packs:owned-download", "GLOBAL", manifest, originalFiles, false, store);
        if (actual.valid() || !original.valid()) throw new IllegalStateException("Signature diagnosis did not isolate the generated config");
        JsonObject result = new JsonObject();
        result.addProperty("result", "REPRODUCED");
        result.addProperty("actualBootFilesValid", actual.valid());
        result.addProperty("originalSignedFilesValid", original.valid());
        result.addProperty("soleAddedFile", "client_scripts/jsconfig.json");
        result.addProperty("removedActualFiles", false);
        Files.writeString(root.resolve("signature-diagnosis.json"), result.toString());
        System.out.println(result);
    }
}
