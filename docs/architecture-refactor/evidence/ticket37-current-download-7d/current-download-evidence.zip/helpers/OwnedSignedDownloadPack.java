package com.tkisor.nekojs.core.pack.sync;

import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPairGenerator;
import java.security.Signature;
import java.util.Base64;

/** Creates a disposable signed pack with the production signature payload implementation. */
public final class OwnedSignedDownloadPack {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]).toRealPath();
        Path pack = root.resolve("server/nekojs/packs/owned-download");
        Files.createDirectories(pack.resolve("client_scripts"));
        Files.writeString(pack.resolve("client_scripts/download-proof.js"),
                "console.info('PACK-DOWNLOAD-PROOF executed=true');\n");
        JsonObject manifest = new JsonObject();
        manifest.addProperty("id", "owned-download");
        manifest.addProperty("version", "1.0.0");
        manifest.addProperty("clientSync", true);
        var files = PackHasher.readContentFiles(pack);
        var keys = KeyPairGenerator.getInstance("Ed25519").generateKeyPair();
        Signature signer = Signature.getInstance("Ed25519");
        signer.initSign(keys.getPrivate());
        signer.update(PackSignaturePayload.build("packs:owned-download", "GLOBAL", manifest.toString(), files));
        JsonObject signature = new JsonObject();
        signature.addProperty("algorithm", "Ed25519");
        signature.addProperty("keyId", "owned-download-window-7d");
        signature.addProperty("publicKey", Base64.getEncoder().encodeToString(keys.getPublic().getEncoded()));
        signature.addProperty("signature", Base64.getEncoder().encodeToString(signer.sign()));
        manifest.add("signature", signature);
        Files.writeString(pack.resolve("manifest.json"), manifest.toString());
        for (String letter : new String[]{"C", "D"}) {
            var store = new PackSyncTrustStore(root.resolve("client" + letter + "/nekojs/config/trusted-servers.json"));
            store.trustServer("127.0.0.1:" + (letter.equals("C") ? "25997" : "25998"));
            var result = PackSignatureVerifier.verify("packs:owned-download", "GLOBAL", manifest.toString(), files, false, store);
            if (!result.valid() || !result.signed()) throw new IllegalStateException("Owned signature verification failed");
        }
        JsonObject result = new JsonObject();
        result.addProperty("result", "SIGNED_AND_VERIFIED");
        result.addProperty("hash", PackHasher.hashPackDir(pack));
        result.addProperty("allowUnsigned", false);
        result.addProperty("privateKeyPersisted", false);
        Files.writeString(root.resolve("signed-pack-preparation.json"), result.toString());
        System.out.println(result);
    }
}
