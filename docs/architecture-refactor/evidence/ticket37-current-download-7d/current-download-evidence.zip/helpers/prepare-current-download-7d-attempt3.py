import hashlib
import json
import shutil
import socket
import uuid
from pathlib import Path
from zipfile import ZipFile

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
root = project / 'build/ticket37-current-download-7d-attempt3'
prior = project / 'build/ticket37-current-client-7d'
assert not root.exists()
assert all(json.loads((prior / node / 'exit.json').read_text())['exitCode'] == 0 for node in ('server', 'clientA', 'clientB'))
for port in (25995, 25996, 25997, 25998):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
for path in (project, project / 'build'):
    assert path.resolve() == path and not path.is_symlink()
preparation = json.loads((prior / 'preparation.json').read_text())
assert preparation['productionRevision'] == '7d77308bfa400721304b20940ada91092180a1ed'
artifact_sha = preparation['artifactSha256']
sha = lambda data: hashlib.sha256(data).hexdigest()
for node in ('server', 'clientC', 'clientD', 'clientE'):
    directory = root / node
    (directory / 'mods').mkdir(parents=True)
    for jar in (prior / 'server/mods').glob('*.jar'):
        assert 'mcp' not in jar.name
        shutil.copyfile(jar, directory / 'mods' / jar.name)
    for folder in ('config', 'startup_scripts'):
        shutil.copytree(prior / 'server/nekojs' / folder, directory / 'nekojs' / folder)
    jar = directory / 'mods' / preparation['artifact']
    assert sha(jar.read_bytes()) == artifact_sha
    with ZipFile(jar) as contents:
        for name, digest in preparation['classBindings'].items():
            assert sha(contents.read(name)) == digest
    if node == 'server':
        (directory / 'libraries').symlink_to((prior / 'server/libraries').resolve(), target_is_directory=True)
        (directory / 'nekojs/server_scripts').mkdir()
        for name in ('proof-dynamic.js', 'proof-sync-observer.js'):
            shutil.copyfile(prior / 'server/nekojs/server_scripts' / name, directory / 'nekojs/server_scripts' / name)
        shutil.copyfile(project / 'build/ticket37-live-7e98/server/nekojs/server_scripts/live-window-observer.js', directory / 'nekojs/server_scripts/live-window-observer.js')
        (directory / 'eula.txt').write_text('eula=true\n')
        properties = dict(server_port=25995, rcon_port=25996)
        (directory / 'server.properties').write_text('\n'.join(['server-ip=127.0.0.1', 'server-port=25995', 'enable-rcon=true', 'rcon.port=25996',
            'rcon.password=' + uuid.uuid4().hex, 'online-mode=false', 'level-name=owned-current-window', 'gamemode=creative',
            'difficulty=peaceful', 'view-distance=3', 'simulation-distance=3', 'max-players=3', 'spawn-protection=0'])+'\n')
    else:
        (directory / 'nekojs/client_scripts').mkdir()
        (directory / 'nekojs/data').mkdir()
        signal = str(directory / 'nekojs/data/close-owned.txt').replace('\\', '/')
        (directory / 'nekojs/client_scripts/owned-close.js').write_text('''const ownedFs = require('node:fs');
const OwnedMinecraft = Java.type('net.minecraft.client.Minecraft');
let stopRequested = false;
ClientEvents.tickPost(() => {
    if (stopRequested || !ownedFs.existsSync('__SIGNAL__')) return;
    stopRequested = true;
    console.info('WINDOW-OWNED-STOP requested=true');
    OwnedMinecraft.getInstance().stop();
});
'''.replace('__SIGNAL__', signal), encoding='utf-8')
        (directory / 'options.txt').write_text('enableVsync:false\nmaxFps:30\nrenderDistance:3\nsimulationDistance:3\nentityDistanceScaling:0.5\nfullscreen:false\nskipMultiplayerWarning:true\npauseOnLostFocus:false\n', encoding='utf-8')
run = (helpers / 'run-live-7e98.py').read_text(encoding='utf-8').replace('ticket37-live-7e98', 'ticket37-current-download-7d-attempt3')
run = run.replace("('A', 'B', 'C', 'D', 'E')", "('C', 'D', 'E')").replace('25971', '25995').replace('25973', '25997').replace('25974', '25998').replace('NekoLive', 'NekoWindow7d')
(helpers / 'run-current-window-7d.py').write_text(run, encoding='utf-8')
rcon = (helpers / 'rcon-current-client-7d.py').read_text(encoding='utf-8').replace('ticket37-current-client-7d', 'ticket37-current-download-7d-attempt3')
(helpers / 'rcon-current-window-7d-attempt2.py').write_text(rcon, encoding='utf-8')
proxy = (helpers / 'live-proxy-7e98.py').read_text(encoding='utf-8').replace('ticket37-live-7e98', 'ticket37-current-download-7d-attempt3')
proxy = proxy.replace('25971', '25995').replace('25973', '25997').replace('25974', '25998')
proxy = proxy.replace("(root / ('release-' + letter + '-prepare')).exists()", "(root / ('release-' + letter + '-prepare-' + str(message['generation']))).exists()")
before = "                    (root / (letter + '-prepare-held')).write_text(json.dumps(message))"
assert proxy.count(before) == 1
proxy = proxy.replace(before, before + "\n                    (root / (letter + '-prepare-held-' + str(message['generation']) + '.json')).write_text(json.dumps(message))")
proxy = proxy.replace('import json', 'import hashlib\nimport json', 1)
proxy = proxy.replace("                note('dynamic-frame', kind=message['kind'], generation=message['generation'])", "                note('dynamic-frame', kind=message['kind'], generation=message['generation'], frameSha256=hashlib.sha256(frame).hexdigest(), bytes=len(frame))")
proxy = proxy.replace('                client.sendall(frame)', "                client.sendall(frame)\n                if message:\n                    note('dynamic-frame-forwarded', kind=message['kind'], generation=message['generation'], frameSha256=hashlib.sha256(frame).hexdigest(), bytes=len(frame))")
(helpers / 'proxy-current-window-7d.py').write_text(proxy, encoding='utf-8')
preparation['installedCopies'] = 4
preparation['ports'] = [25995,25996,25997,25998]
(root / 'preparation.json').write_text(json.dumps(preparation, indent=2), encoding='utf-8')
(root / 'PLAN.md').write_text('''# Current 7d real configuration transaction windows

Official source/JAR 7d, four bound copies, fresh owned world/profiles and synthetic
clients C/D/E. No bridge, native activation/input or production/security changes.
Server25995/RCON25996; original-frame TCP proxies25997/25998. The proxy inspects
actual framed JSON and only delays/forwards identical bytes; no synthetic replies.

Baseline C real join/catch-up. Hold C PREPARE, release D handshake while awaiting
ACK; hold D PREPARE and disconnect before delivery, releasing C. Observe real
joined-mid-transaction, whole-batch abort, unchanged activated generation and
new item absence. Recover with C real ACK/activation/item presence. Hold C next
PREPARE, release E handshake, allow E real PREPARE/ACK then release C; observe
commit/task release/login and both actual ACK/activated reports/item presence.
All samples/failures retained. Owner-tick client stop handles logged-out/menu
states too; normal RCON server stop. No downloads/first pixel/all-node/human claim.
''', encoding='utf-8')
print(json.dumps(dict(result='PREPARED', copies=4, artifactSha256=artifact_sha, classBindings=len(preparation['classBindings']), ports=preparation['ports'])))

for node in ("server", "clientC", "clientD"):
    path = root / node / "nekojs/config/engine.toml"
    value = path.read_text(encoding="utf-8")
    assert value.count('mode = "off"') == 1 and 'allowUnsigned = false' in value
    path.write_text(value.replace('mode = "off"', 'mode = "all"'), encoding="utf-8")
