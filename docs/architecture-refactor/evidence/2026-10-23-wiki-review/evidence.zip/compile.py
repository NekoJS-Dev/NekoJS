import json,subprocess
from pathlib import Path
repo=Path.cwd(); root=repo/'build/priority-closeout/wiki-reviewed-examples'; root.mkdir(exist_ok=False)
source=root/'GreetExample.java'
source.write_text('''import com.tkisor.nekojs.api.event.EventGroup;
import com.tkisor.nekojs.api.event.EventBusJS;
import com.tkisor.nekojs.api.event.EventBusForgeBridge;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
public class GreetExample {
    public static class PlayerGreetEvent {
        private final ServerPlayer player;
        private final String greeting;
        public PlayerGreetEvent(ServerPlayer player, String greeting) { this.player = player; this.greeting = greeting; }
        public ServerPlayer getPlayer() { return player; }
        public String getGreeting() { return greeting; }
    }
    public interface MyEvents {
        EventGroup GROUP = EventGroup.of("MyEvents");
        EventBusJS<PlayerGreetEvent, Void> PLAYER_GREET = GROUP.server("playerGreet", PlayerGreetEvent.class);
    }
    public static void bind() {
        EventBusForgeBridge.create(NeoForge.EVENT_BUS)
            .bindTransformed(MyEvents.PLAYER_GREET,
                event -> new PlayerGreetEvent((ServerPlayer) event.getEntity(), "Hello"),
                PlayerEvent.PlayerLoggedInEvent.class);
    }
}
''',encoding='utf-8')
rows=[]
for node in ['1.21.1','26.1.2','26.2.0']:
 server=repo/'build/closeout-class-bounds-installed'/node
 jars=[*sorted((server/'mods').glob('nekojs-*.jar')),*sorted((server/'libraries').rglob('*.jar'))]
 assert jars
 target=root/node; target.mkdir()
 args=root/(node+'-javac-args.txt')
 args.write_text('-classpath\n"'+';'.join(str(j).replace('\\','/') for j in jars)+'"\n-d\n"'+str(target).replace('\\','/')+'"\n"'+str(source).replace('\\','/')+'"\n',encoding='utf-8')
 r=subprocess.run(['C:/Program Files/Java/jdk-25.0.2/bin/javac.exe','-encoding','UTF-8','@'+str(args)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 (root/(node+'-javac.log')).write_bytes(r.stdout)
 rows.append(dict(node=node,exitCode=r.returncode,compiledClasses=len(list(target.glob('*.class')))))
 print(rows[-1],flush=True)
(root/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
assert all(row['exitCode']==0 and row['compiledClasses']==3 for row in rows),rows
