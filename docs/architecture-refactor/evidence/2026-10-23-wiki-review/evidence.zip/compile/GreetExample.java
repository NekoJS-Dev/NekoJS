import com.tkisor.nekojs.api.event.EventGroup;
import com.tkisor.nekojs.api.event.EventBusJS;
import com.tkisor.nekojs.api.event.EventBusForgeBridge;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
public class GreetExample {
    public static class PlayerGreetEvent {
        private final ServerPlayer player;
        private final String greeting;
        public PlayerGreetEvent(ServerPlayer player, String greeting) { this.player = player; this.greeting = greeting; }
        public ServerPlayer getPlayer() { return player; }
        public String getGreeting() { return greeting; }
    }
    public interface MyEvents {
        EventGroup GROUP = EventGroup.of("MyEvents");
        EventBusJS<PlayerGreetEvent, Void> PLAYER_GREET = GROUP.server("playerGreet", PlayerGreetEvent.class);
    }
    public static void bind() {
        EventBusForgeBridge.create(NeoForge.EVENT_BUS)
            .bindTransformed(MyEvents.PLAYER_GREET,
                event -> new PlayerGreetEvent((ServerPlayer) event.getEntity(), "Hello"),
                PlayerEvent.PlayerLoggedInEvent.class);
    }
}
