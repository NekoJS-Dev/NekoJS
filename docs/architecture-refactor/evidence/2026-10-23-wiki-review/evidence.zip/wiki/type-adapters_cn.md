<!-- wiki-page: type-adapters; locale: cn -->

> **中文** · [English](type-adapters_us)

<a id="wiki-section-1"></a>
# 类型适配器

> 适配器让 Java 方法**自动接受多种 JS 输入形态**——比如一个 Java 方法声明参数是 `ItemStack`，脚本可以传字符串 `'minecraft:stone'`、传 `{id, count}` 对象、传 `ItemStack` 实例，适配器负责把它们都转成 `ItemStack`。适配器有两代 SPI：**新 SPI `JsTypeAdapter`（推荐）**与**旧 SPI `JSTypeAdapter`（Graal `Value`，兼容保留）**，见下文「两代 API」。

<a id="wiki-section-2"></a>
## 为什么需要适配器

GraalJS 的 `HostAccess` 提供了 `targetTypeMapping(C, T, predicate, function)` 机制：当 Java API 期望类型 `T` 时，GraalJS 会自动把传入的 JS 值（`Value`）通过 mapping 转成 `T`。NekoJS 的 `JSTypeAdapter` 就是这个 mapping 的载体。

NekoJS 在 bootstrap 时通过 `NekoSharedHostAccess` 将注册的适配器配置为 `HostAccess.targetTypeMapping(Value.class, T, adapter, adapter)`，由各 Context 使用这份共享 HostAccess 配置。

<a id="wiki-section-3"></a>
## 内置适配器

NekoJS 已注册了大量适配器（见 `src/main/java/com/tkisor/nekojs/js/type_adapter/`）：

| 适配器 | 目标类型 | 接受的 JS 输入 |
|---|---|---|
| `ItemAdapter` / `ItemStackAdapter` | `ItemStack` | 字符串 id（`"minecraft:stone"`）、`"1x minecraft:stone"`、`{id, count}`、`ItemStack` |
| `IngredientAdapter` | `Ingredient` | 字符串、tag（`"#minecraft:planks"`）、数组、`Ingredient` |
| `SizedIngredientAdapter` | `SizedIngredient` | 同上 + 数量 |
| `BlockAdapter` | `Block` | 字符串 id |
| `BlockPosAdapter` | `BlockPos` | `{x, y, z}`、`[x, y, z]`、字符串 |
| `Vec3Adapter` | `Vec3` | `{x, y, z}`、`[x, y, z]` |
| `CompoundTagAdapter` | `CompoundTag` | JS 对象（自动转 NBT） |
| `ComponentAdapter` | `Component` | 字符串、`MutableComponent` |
| `FluidStackAdapter` / `FluidIngredientAdapter` / `SizedFluidIngredientAdapter` | 流体类型 | 字符串、`{fluid, amount}` |
| `IdentifierAdapter` | `Identifier`/`ResourceLocation` | 字符串 |
| `TagKeyAdapter` | `TagKey` | `"#namespace:path"` |
| `EntityTypeAdapter` | `EntityType` | 字符串 id |
| `MobEffectAdapter` / `PotionAdapter` / `ParticleTypeAdapter` / `SoundEventAdapter` / `CreativeModeTabAdapter` / `BlockEntityTypeAdapter` | 各注册表类型 | 字符串 id |
| `CodecAdapter` | 任意 codec 类型 | 按 codec 解析 |
| `DataComponentsAdapter`（静态工具，非注册适配器） | `DataComponentPatch` | JS 对象 → data component patch（NeoForge / Fabric 26.x） |
| `RecipeFilterAdapter` | `RecipeFilter` | JS 对象（见 [配方系统 - 过滤器](recipe-system_cn#wiki-section-3)） |
| `RecipeJsonValueAdapter` | `RecipeJsonValue` | — |

<a id="wiki-section-4"></a>
## 两代 API

适配器现在有**两代 SPI**：

- **新 SPI（推荐）**：`JsTypeAdapter<T>`（`common/src/main/java/com/tkisor/nekojs/api/data/JsTypeAdapter.java`，对外契约包 `com.tkisor.nekojs.api.*`）——**无 MC/Graal 依赖**。签名：`targetType()` / `supports(JsValueView, ConversionContext)` / `convert(JsValueView, ConversionContext)` / `precedence()`。推荐基类是 `BaseJsTypeAdapter<T> implements JsTypeAdapter<T>`（模板方法：`fromString`/`fromHostObject`/`acceptOther`/`fromOther`）。已迁移示例：`src/main/java/com/tkisor/nekojs/js/type_adapter/ComponentAdapter.java`。
- **旧 SPI（兼容保留）**：`common` 的 `JSTypeAdapter<T>`/`AbstractJSTypeAdapter`——依赖 Graal `Value`（`test(Value)`/`apply(Value)`）。

两代适配器都经同一个注册表进场：`JSTypeAdapterRegistry`（`common/src/main/java/com/tkisor/nekojs/api/data/JSTypeAdapterRegistry.java`）同时提供 `register(JSTypeAdapter<T>)` 和 `register(JsTypeAdapter<T>)` 两个重载，插件拿到的就是它。

**新适配器请优先用新 SPI**；旧 SPI 继续可用（下文旧示例照常编译），两代的 `precedence()`/`getPrecedence()` 都返回 `ConversionPrecedence`。

<a id="wiki-section-5"></a>
### 必须实现什么

| SPI | 没有 default，必须实现 | 有 default，可以不管 |
|---|---|---|
| 新 `JsTypeAdapter<T>` | `targetType()`、`supports(JsValueView, ConversionContext)`、`convert(...)`、`precedence()` | `inputShapes()`（默认空表） |
| 旧 `JSTypeAdapter<T>` | `getTargetClass()`、`test(Value)`、`apply(Value)` | `getPrecedence()`（默认 `LOWEST`）、`inputShapes()`、`syntaxDoc()` |
| `BaseJsTypeAdapter<T>` | `fromHostObject(Object)`，以及构造器传 `targetType` | 其余全部（`precedence()` 默认 `LOWEST`，`fromString`/`fromOther` 默认抛 `ValueConversionException`，`acceptNull`/`acceptOther` 默认 `false`，`supportsString` 默认 `true`） |

基类只是省事的模板，**不是必经之路**：注册表接的是接口，直接 implements 接口完全等价。连类都不想写的话，`JSTypeAdapterRegistry` 还有个 default 重载 `register(Class<T> target, Predicate<Value> filter, Function<Value, T> converter)`，三个 lambda 就是一个旧 SPI 适配器。

<a id="wiki-section-6"></a>
## 写一个自定义适配器

<a id="wiki-section-7"></a>
### 步骤 1（旧 SPI）：实现 `JSTypeAdapter<T>`

```java
package com.example.myaddon;

import com.tkisor.nekojs.api.JSTypeAdapter;
import com.tkisor.nekojs.api.AdapterInputShape;
import com.tkisor.nekojs.api.data.ConversionPrecedence;
import graal.graalvm.polyglot.Value;
import java.util.List;

public class MyPosAdapter implements JSTypeAdapter<MyPos> {

    @Override
    public Class<MyPos> getTargetClass() {
        return MyPos.class;
    }

    @Override
    public ConversionPrecedence getPrecedence() {
        return ConversionPrecedence.LOW;   // 低于内置；多个适配器匹配同一类型时高优先级赢
    }

    @Override
    public boolean test(Value value) {
        // 判断这个 JS 值能否被本适配器处理
        return value.hasMembers() && value.hasMember("x") && value.hasMember("y");
    }

    @Override
    public MyPos apply(Value value) {
        int x = value.getMember("x").asInt();
        int y = value.getMember("y").asInt();
        return new MyPos(x, y);
    }

    @Override
    public List<AdapterInputShape> inputShapes() {
        // 给 probe 生成 $MyPos_ 输入别名用；object(Slot...) 声明接受的字段
        return List.of(
            AdapterInputShape.object(
                AdapterInputShape.Slot.req("x", AdapterInputShape.number()),
                AdapterInputShape.Slot.req("y", AdapterInputShape.number()))
        );
    }
}
```

<a id="wiki-section-8"></a>
### 步骤 2（旧 SPI）：或继承 `AbstractJSTypeAdapter`（模板方法，更省事）

```java
public class MyPosAdapter extends AbstractJSTypeAdapter<MyPos> {
    @Override public Class<MyPos> getTargetClass() { return MyPos.class; }

    @Override protected boolean acceptNull() { return false; }

    @Override
    protected MyPos fromString(String s) {
        // 将 "1,2" 转为 MyPos(1,2)
        String[] parts = s.split(",");
        return new MyPos(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
    }

    @Override
    protected MyPos fromHostObject(Object host) {
        // 已是 Java MyPos/Map/等
        if (host instanceof MyPos p) return p;
        if (host instanceof java.util.Map<?,?> m) {
            return new MyPos((int) m.get("x"), (int) m.get("y"));
        }
        throw new ValueConversionException("无法转成 MyPos: " + host);
    }

    @Override
    protected boolean acceptOther(Value value) {
        return value.isString() || (value.hasMembers() && value.hasMember("x"));
    }
}
```

`AbstractJSTypeAdapter` 的 `final test`/`apply` 自动分派到 `defaultValue`/`acceptNull`/`fromString`/`fromHostObject`/`acceptOther`/`fromOther`。设计为 MC 无关（`fromHostObject` 收到的是 `Object`，平台代码做 `instanceof`）。它在 `common/`，依赖 Graal `Value`。

<a id="wiki-section-9"></a>
### 步骤 2b（新 SPI，推荐）：继承 `BaseJsTypeAdapter<T>`

新 SPI 的基类 `BaseJsTypeAdapter<T>`（同在契约包 `api.data`，无 MC/Graal 依赖）提供同一套模板方法，`supports`/`convert` 已按 `JsValueView` + `ConversionContext` 实现好：

```java
public class MyPosAdapter extends BaseJsTypeAdapter<MyPos> {
    public MyPosAdapter() {
        super(MyPos.class);
    }

    @Override
    protected MyPos fromString(String s) {
        // 将 "1,2" 转为 MyPos(1,2)
        String[] parts = s.split(",");
        return new MyPos(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
    }

    @Override
    protected MyPos fromHostObject(Object host) {
        // 只有 supports() 判定过 host instanceof MyPos 时才会走到这里
        return (MyPos) host;
    }

    @Override
    protected boolean acceptOther(JsValueView value) {
        return value.hasMember("x") && value.hasMember("y");
    }

    @Override
    protected MyPos fromOther(JsValueView value) {
        return new MyPos(value.getMember("x").asInt(), value.getMember("y").asInt());
    }

    @Override
    public ConversionPrecedence precedence() {
        return ConversionPrecedence.LOW;
    }

    @Override
    public List<AdapterInputShape> inputShapes() {
        return List.of(
            AdapterInputShape.object(
                AdapterInputShape.Slot.req("x", AdapterInputShape.number()),
                AdapterInputShape.Slot.req("y", AdapterInputShape.number()))
        );
    }
}
```

写法与旧 SPI 几乎一一对应（`test`/`apply` → `supports`/`convert`，`getPrecedence()` → `precedence()`）。迁移实例见 `src/main/java/com/tkisor/nekojs/js/type_adapter/ComponentAdapter.java`。

> 基类的 host object 分支比旧基类**收窄**了：`supports` 对 host object 只在 `targetType.isAssignableFrom(host.getClass())` 时放行，所以 `fromHostObject` 收到的一定已经是目标类型，不需要（也不可能）在里面处理 `Map` 之类的其它形态。不匹配的 Java host object 会直接被拒绝；普通非 host 的 JS 对象才走 `acceptOther`/`fromOther`。而且 `fromHostObject` 返回 `null` **不是**「不识别」的合法表达：基类会把它当失败，抛 `ValueConversionException`（`BaseJsTypeAdapter.convert`）。要表达「不接受」就让 `supports` 返回 false。

<a id="wiki-section-10"></a>
### 步骤 3：注册

```java
@Override
public void registerAdapters(JSTypeAdapterRegistry registry) {
    registry.register(new MyPosAdapter());
}
```

> `registerAdapters` 的参数是 `JSTypeAdapterRegistry`，它同时有 `register(JSTypeAdapter<T>)` 和 `register(JsTypeAdapter<T>)` 两个重载——上面两代适配器都能直接传进去。

之后任何 Java 方法声明 `void foo(MyPos pos)` 都能从脚本接收 `{x: 1, y: 2}` 或 `"1,2"`。

<a id="wiki-section-11"></a>
## AdapterInputShape（probe 别名）

`inputShapes()` 告诉 probe 这个适配器接受什么形态的输入，probe 据此生成 `$MyPos_` 类型别名，让脚本的 `.d.ts` 准确反映「这个参数可以传字符串或对象」。

它是**纯编辑器面的**，两代 SPI 都有 default 空实现：不写照样能转换，代价只是 `.d.ts` 里该参数退化成目标类型本身，脚本传字符串会被编辑器标红（运行时仍然正常）。

`AdapterInputShape` 是 sealed 接口，14 个变体（见 `api/AdapterInputShape.java`）：

| 变体 | 含义 | 渲染成 |
|---|---|---|
| `String` | 接受任意字符串（自由文本字段） | `string` |
| `Literal(text)` | 单个字符串字面量 | `"*"` |
| `Number` | 接受数字 | `number` |
| `Boolean` | 接受布尔 | `boolean` |
| `Self` | 接受目标类型本身 | `$Foo` |
| `Host` | 接受某个 Java host 类型 | `$Bar` |
| `ArrayOf(shape)` | 接受数组 | `T[]` |
| `Object(field...)` | 接受对象（指定字段） | `{ a?: ..., b: ... }` |
| `Union(shape...)` | 单个字段接受多种写法 | `(A \| B)` |
| `Registry(typeName)` | 接受注册表 id 字符串 | `RegistryTypes.Item` |
| `RegistryTag(typeName)` | 接受该注册表的标签 id（不含 `#`） | `RegistryTypes.ItemTag` |
| `Namespace` | 接受 id 命名空间（mod 表 + 注册表命名空间） | `RegistryTypes.Namespace` |
| `Template(prefix, hole, suffix)` | 固定前后缀 + 可补全的洞 | <code>\`#${RegistryTypes.ItemTag}\`</code> |
| `Raw` | 其它原始形态 | 原样输出 |

`AdapterAliasGenerator` 会把这些渲染成 `$Foo_` union 类型。

> **别在联合里放裸 `string`。** TypeScript 一旦看到联合里有 `string`，就会把其它字符串字面量成员吞掉，编辑器不再给任何 id 补全——这正是早期 `$Ingredient_` 里原料位置没补全、而 `$ItemStack_` 里结果位置有补全的原因。想同时接纳 `@mod`、`*`、`/regex` 这类非 id 语法又保住补全，把它们写成字面量/模板字面量类型：
>
> ```java
> registry("Item"),                     // minecraft:stone（有补全）
> template("#", registryTag("Item")),   // #minecraft:planks（有补全）
> template("@", namespace()),           // @create（有补全）
> literal("*"),                          // *
> template("/", string())               // /wool$/（正则无穷，无法补全）
> ```
>
> 这条限制是**按联合**生效的，不是按对象：`{ output: RegistryTypes.Item, id: string }` 里的 `id` 用裸 `string` 不影响 `output` 的补全。
>
> `RegistryTypes.XTag` 由 probe 从注册表当前已绑定的标签生成；`RegistryTypes.Namespace` 是加载器 mod 列表（`NekoCatalogPlatformProvider.modIds()`）与全部注册表条目 id 的 `:` 前缀的并集——前者覆盖没往该注册表注册东西的 mod，后者覆盖脚本/数据包自造的命名空间。两者为空时都回退成 `string`，模板类型因此退化为「任意字符串」而不是 `never`。

<a id="wiki-section-12"></a>
## Precedence（优先级）

多个适配器匹配同一目标类型时，按 `precedence()`（旧 SPI `getPrecedence()`）决定。`ConversionPrecedence` 枚举只有 **4 个级别**（没有 `NORMAL`），顺序 `LOWEST < LOW < HIGH < HIGHEST`：

| 级别 | 用途 |
|---|---|
| `HIGHEST` | 平台/核心适配器 |
| `HIGH` | 内置通用适配器 |
| `LOW` | 兜底 |
| `LOWEST` | 最后手段 |

「用途」这一列是内置适配器的自我分层，**不是校验规则**：没有任何代码检查你是谁、用了哪一级。缺省值分两种情况——旧 SPI 的 `getPrecedence()` 与 `BaseJsTypeAdapter` 都默认 `LOWEST`；新 SPI 直接 implements `JsTypeAdapter` 时 `precedence()` 没有 default，必须自己写出来。

<a id="wiki-section-13"></a>
### 冲突策略

代码这边能确定的只有一条：`JSTypeAdapterRegistry.Impl` 就是一个 `ArrayList`，同一 `(目标类型, precedence)` 组合注册时**不做任何去重或冲突校验**，不报错、不打日志。注册表按顺序把全部适配器喂给 Graal 的 `HostAccess.targetTypeMapping`，注册顺序跟随插件加载顺序（priority 越高越先加载）。

同 precedence 层级内**最终哪个胜出由 Graal 决定，不由本仓决定**——这里没有相关代码，也没有测试钉住它。所以别依赖同层级的相对顺序，要确定性就用不同的 precedence。

下面几条是据此得出的建议，没有代码执行它们：

- 尽量别让多个 addon 在同一类型上声明相同 precedence（那等于把「谁生效」交给插件加载顺序）。
- addon 适配器用 `LOW`/`LOWEST` 比较安全——内置通用适配器在 `HIGH`，平台核心在 `HIGHEST`，你选低一级就是明确让内置优先；反过来想**盖掉**内置行为就得选比它高的级别，这是可行的、没人拦你。

<a id="wiki-section-14"></a>
## 测试适配器

下面针对步骤 2 的旧 SPI `AbstractJSTypeAdapter` 示例测试对象和字符串转换。

```java
@Test
void myPosAdapterConvertsObjectAndString() {
    MyPosAdapter adapter = new MyPosAdapter();
    Value obj = Value.asValue(Map.of("x", 1, "y", 2));
    assertTrue(adapter.test(obj));
    assertEquals(new MyPos(1, 2), adapter.apply(obj));

    Value str = Value.asValue("3,4");
    assertTrue(adapter.test(str));
    assertEquals(new MyPos(3, 4), adapter.apply(str));
}
```

<a id="wiki-section-15"></a>
## 平台无关性

适配器**能**做到跨平台，但没有机制要求它跨平台——一个只在某个加载器上编译的适配器照样能注册、能工作。下面是内置适配器为了跨平台而采用的分层，你想复用这套排布就照着放：
- 新 SPI `JsTypeAdapter`/`BaseJsTypeAdapter` 在契约包 `com.tkisor.nekojs.api.data`，无 MC/Graal 依赖；旧 SPI `JSTypeAdapter` 在 `com.tkisor.nekojs.api`，`AbstractJSTypeAdapter` 在 `com.tkisor.nekojs.api.data`（均依赖 Graal `Value`），无 MC 依赖。这两层的「无 XX 依赖」由 guardLint 的边界规则对**本仓**强制，你的 mod 不受它约束。
- MC 相关逻辑（`instanceof ItemStack` 等）在 `fromHostObject` 里，平台提供 host 对象。
- 平台专属适配器（如 `ItemAdapter`）放在平台 sourceSet。

<a id="wiki-section-16"></a>
## 下一步

- [插件开发](plugin-development_cn) —— `registerAdapters` 钩子。
- [Probe 类型生成](probe-type-generation_cn) —— `AdapterInputShape` 如何变成 `.d.ts` 别名。
- [注解体系](annotations_cn) —— `@Overload` 手写适配器表达不了的签名；适配器声明的 `inputShapes()` 会自动放宽参数类型，见上。
- 维护者完整 Java/JS 示例与目录边界：`docs/maintenance/adding-events-adapters.md`。

<!-- wiki-nav -->

---

[上一篇: 插件开发](plugin-development_cn) · [目录](Home) · [下一篇: 事件扩展](event-extensions_cn)
