"""Prepare, but do not run alongside performance sampling, native process memory observations."""
import hashlib
import json
import sys
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
output=tools/'pack-native-observation'
refresh='--refresh-prepared' in sys.argv
assert not output.exists() or refresh
assert not (output/'compile.log').exists() and not (output/'run.log').exists(), 'Preserve every executed probe'
output.mkdir(exist_ok=refresh)
original=project/'common/src/test/java/com/tkisor/nekojs/core/pack/PackResourceStabilityTest.java'
source=original.read_text(encoding='utf-8').replace('class PackResourceStabilityTest {','class PackNativeObservationTest {')
source=source.replace('            long legacyHeap = observedHeap();','            long legacyHeap = observedHeap();\n            NativePackMemory.snapshot("legacy", registeredContexts());')
source=source.replace('            long activeHeap = observedHeap();','            long activeHeap = observedHeap();\n            NativePackMemory.snapshot("active", registeredContexts());')
source=source.replace('                    long heap = observedHeap();','                    long heap = observedHeap();\n                    NativePackMemory.snapshot("reload-" + reload, registeredContexts());')
source=source.replace('            assertEquals(baselineContexts, registeredContexts());','            assertEquals(baselineContexts, registeredContexts());\n            NativePackMemory.snapshot("root-closed", registeredContexts());')
source=source.replace('                if (measureHeap) candidateHeap = observedHeap();','                if (measureHeap) {\n                    candidateHeap = observedHeap();\n                    NativePackMemory.snapshot("candidate", peakRegistered);\n                }')
(output/'PackNativeObservationTest.java').write_text(source,encoding='utf-8')
(output/'source-binding.json').write_text(json.dumps(dict(originalPath=str(original),originalSha256=hashlib.sha256(original.read_bytes()).hexdigest(),
    shadowSha256=hashlib.sha256((output/'PackNativeObservationTest.java').read_bytes()).hexdigest(),
    assertionsChanged=False,productionCodeChanged=False,observationsOnly=True),indent=2)+'\n',encoding='utf-8')
memory='''package com.tkisor.nekojs.core.pack;
import java.lang.foreign.*; import java.lang.invoke.*; import java.nio.file.*; import java.util.*;
public final class NativePackMemory {
    static final SymbolLookup LIB=SymbolLookup.libraryLookup("kernel32",Arena.global());
    static final Linker LINKER=Linker.nativeLinker();
    static final MethodHandle SELF=LINKER.downcallHandle(LIB.find("GetCurrentProcess").orElseThrow(),FunctionDescriptor.of(ValueLayout.ADDRESS));
    static final MethodHandle MEMORY=LINKER.downcallHandle(LIB.find("K32GetProcessMemoryInfo").orElseThrow(),FunctionDescriptor.of(ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.ADDRESS,ValueLayout.JAVA_INT));
    static final Path OUTPUT=Path.of(System.getProperty("neko.native.output"));
    static String currentCase="initialization";
    static int sequence;
    public static void snapshot(String stage,int contexts) {
        try(var arena=Arena.ofConfined()) {
            if(ValueLayout.ADDRESS.byteSize()!=8)throw new AssertionError("This diagnostic requires 64-bit Windows");
            var data=arena.allocate(80,8);data.set(ValueLayout.JAVA_INT,0,80);
            if((int)MEMORY.invokeExact((MemorySegment)SELF.invokeExact(),data,80)==0)throw new AssertionError("Process memory query failed");
            var row=new LinkedHashMap<String,Object>();
            row.put("case",currentCase);row.put("stage",stage);row.put("contexts",contexts);row.put("time",java.time.Instant.now().toString());
            row.put("privateCommitBytes",data.get(ValueLayout.JAVA_LONG,72));
            row.put("workingSetBytes",data.get(ValueLayout.JAVA_LONG,16));
            row.put("peakWorkingSetBytes",data.get(ValueLayout.JAVA_LONG,8));
            row.put("javaHeapUsedBytes",Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory());
            row.put("liveJavaThreads",java.lang.management.ManagementFactory.getThreadMXBean().getThreadCount());
            Path nmt=OUTPUT.getParent().resolve("nmt");Files.createDirectories(nmt);
            String name=String.format(java.util.Locale.ROOT,"%03d",sequence++);
            Path snapshot=nmt.resolve(name+".txt");
            var process=new ProcessBuilder(Path.of(System.getProperty("java.home"),"bin","jcmd.exe").toString(),
                Long.toString(ProcessHandle.current().pid()),"VM.native_memory","summary","scale=KB")
                .redirectOutput(snapshot.toFile()).redirectError(nmt.resolve(name+"-stderr.txt").toFile()).start();
            if(!process.waitFor(20,java.util.concurrent.TimeUnit.SECONDS)){process.destroyForcibly();throw new AssertionError("NMT query timed out");}
            if(process.exitValue()!=0)throw new AssertionError("NMT query failed");
            row.put("nmtSnapshot","nmt/"+name+".txt");
            Files.writeString(OUTPUT,new com.google.gson.Gson().toJson(row)+"\\n",StandardOpenOption.CREATE,StandardOpenOption.APPEND);
        }catch(Throwable failure){throw new AssertionError("Native process observation failed",failure);}
    }
}
'''
(output/'NativePackMemory.java').write_text(memory,encoding='utf-8')
launcher='''package com.tkisor.nekojs.core.pack;
import java.io.*; import java.nio.file.*;
import org.junit.platform.engine.TestExecutionResult;
import org.junit.platform.launcher.*;
import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class NativePackLauncher {
    public static void main(String[] args)throws Exception {
        Path output=Path.of(args[0]);
        var summary=new SummaryGeneratingListener();
        var events=output.resolve("test-events.jsonl");
        var listener=new TestExecutionListener(){
            void record(TestIdentifier id,String outcome,String detail) {
                if(!id.isTest())return;
                try {Files.writeString(events,new com.google.gson.Gson().toJson(java.util.Map.of("id",id.getUniqueId(),"name",id.getDisplayName(),"outcome",outcome,"detail",detail))+"\\n",StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
                catch(IOException e){throw new java.io.UncheckedIOException(e);}
            }
            @Override public void executionStarted(TestIdentifier id) {
                if(id.isTest()){NativePackMemory.currentCase=id.getDisplayName();NativePackMemory.snapshot("test-start",0);}
                record(id,"START","");
            }
            @Override public void executionFinished(TestIdentifier id,TestExecutionResult result) {
                if(id.isTest())NativePackMemory.snapshot("test-finished",0);
                record(id,result.getStatus().name(),result.getThrowable().map(Throwable::toString).orElse(""));
            }
        };
        var launcher=LauncherFactory.create();
        launcher.registerTestExecutionListeners(summary,listener);
        launcher.execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass(PackNativeObservationTest.class)).build());
        try(var writer=new PrintWriter(Files.newBufferedWriter(output.resolve("junit-summary.txt")))) {
            summary.getSummary().printTo(writer);summary.getSummary().printFailuresTo(writer);
        }
        var result=summary.getSummary();
        if(result.getTestsFoundCount()!=5||result.getTestsSucceededCount()!=5||result.getTotalFailureCount()!=0||result.getTestsSkippedCount()!=0)
            throw new AssertionError("Expected all five pack resource cases to execute and pass");
    }
}
'''
(output/'NativePackLauncher.java').write_text(launcher,encoding='utf-8')
print('PACK_NATIVE_OBSERVATION_PREPARED_NOT_RUN')
