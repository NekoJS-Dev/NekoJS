"""Run the five existing resource scenarios with observational shadow test code only."""
import hashlib
import json
import socket
import subprocess
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
output=tools/'pack-native-observation'
for label in ['candidate-6e5bb8f0-qos-controlled','historical-3400-qos-controlled']:
    groups=json.loads((tools/label/'groups.json').read_text(encoding='utf-8'))
    assert [r['group'] for r in groups]==['reload-1','reload-2','startup'] and all(r['exitCode']==0 for r in groups)
for port in [25871,25872]:
    with socket.socket() as probe:probe.bind(('127.0.0.1',port))
assert not (output/'compile.log').exists() and not (output/'run.log').exists()
binding=json.loads((output/'source-binding.json').read_text(encoding='utf-8'))
assert hashlib.sha256(Path(binding['originalPath']).read_bytes()).hexdigest()==binding['originalSha256']
classpath=(tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
classes=output/'classes';classes.mkdir()
production=project/'common/build/classes/java/main'
frozen={p.relative_to(production).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in production.rglob('*.class')}
assert len(frozen)==1152
(output/'production-class-bindings.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
commands=[('compile',[str(java/'javac.exe'),'-encoding','UTF-8','-cp',classpath,'-d',str(classes),
    *[str(output/name) for name in ['PackNativeObservationTest.java','NativePackMemory.java','NativePackLauncher.java']]]),
    ('run',[str(java/'java.exe'),'--enable-native-access=ALL-UNNAMED','-XX:NativeMemoryTracking=summary',
        '-Dneko.native.output='+str(output/'memory.jsonl'),'-cp',str(classes)+';'+classpath,
        'com.tkisor.nekojs.core.pack.NativePackLauncher',str(output)])]
results=[]
for label,command in commands:
    with (output/(label+'.log')).open('xb') as out,(output/(label+'-stderr.log')).open('xb') as err:
        result=subprocess.run(command,cwd=project,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    results.append(dict(stage=label,exitCode=result.returncode))
    (output/'execution.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    assert result.returncode==0,label
assert frozen=={p.relative_to(production).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in production.rglob('*.class')}
assert hashlib.sha256(Path(binding['originalPath']).read_bytes()).hexdigest()==binding['originalSha256']
print(json.dumps(dict(productionUnchanged=True,stages=results)))
