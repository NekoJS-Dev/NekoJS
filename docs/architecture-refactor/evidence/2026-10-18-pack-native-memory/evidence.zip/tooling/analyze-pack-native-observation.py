"""Summarize process and NMT observations without inventing a per-Context native allocation."""
import json
import re
from pathlib import Path

root=Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/pack-native-observation')
rows=[json.loads(line) for line in (root/'memory.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
events=[json.loads(line) for line in (root/'test-events.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
assert len(rows)==29
assert sum(r['outcome']=='START' for r in events)==5
assert sum(r['outcome']=='SUCCESSFUL' for r in events)==5
assert not any(r['outcome'] not in ['START','SUCCESSFUL'] for r in events)
for row in rows:
    text=(root/row['nmtSnapshot']).read_text(encoding='utf-8')
    total=re.search(r'Total: reserved=(\d+)KB, committed=(\d+)KB',text)
    assert total
    categories={name.strip():dict(reservedKiB=int(reserved),committedKiB=int(committed))
        for name,reserved,committed in re.findall(r'^\s*-\s+(.*?)\s+\(reserved=(\d+)KB, committed=(\d+)KB\)',text,re.M)}
    assert 'Java Heap' in categories and 'Thread' in categories and 'Code' in categories
    row['nmt']=dict(reservedKiB=int(total[1]),committedKiB=int(total[2]),categories=categories,
        vmNonHeapCommittedKiB=int(total[2])-categories['Java Heap']['committedKiB'])
result=dict(observationsOnly=True,wholeProcessCounters=True,perContextAllocationClaimed=False,
    nmtEnabled=True,untrackedThirdPartyNativeAllocationsPossible=True,testsPassed=5,skipped=0,snapshots=len(rows),cases={})
for case in dict.fromkeys(r['case'] for r in rows):
    chosen=[r for r in rows if r['case']==case]
    phases={r['stage']:r for r in chosen}
    if 'legacy' in phases:
        result['cases'][case]={phase:phases[phase] for phase in ['legacy','active','candidate','root-closed','test-finished']}
    elif any(r['stage'].startswith('reload-') for r in chosen):
        windows=[r for r in chosen if r['stage'].startswith('reload-')]
        assert [r['stage'] for r in windows]==['reload-10','reload-20','reload-30','reload-40','reload-50']
        assert all(r['contexts']==5 for r in windows)
        result['reloadWindows']=windows
        result['reload10To50']=dict(privateCommitDeltaBytes=windows[-1]['privateCommitBytes']-windows[0]['privateCommitBytes'],
            workingSetDeltaBytes=windows[-1]['workingSetBytes']-windows[0]['workingSetBytes'],
            vmNonHeapCommitDeltaKiB=windows[-1]['nmt']['vmNonHeapCommittedKiB']-windows[0]['nmt']['vmNonHeapCommittedKiB'],
            vmCodeCommitDeltaKiB=windows[-1]['nmt']['categories']['Code']['committedKiB']-windows[0]['nmt']['categories']['Code']['committedKiB'])
    else:
        result['failureCase']=chosen
assert len(result['cases'])==3
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(testsPassed=5,snapshots=len(rows),reload10To50=result['reload10To50'],
    packs=[dict(case=case,activeContexts=phases['active']['contexts'],candidateContexts=phases['candidate']['contexts'],
        privateCommitDeltaBytes=phases['active']['privateCommitBytes']-phases['legacy']['privateCommitBytes'],
        vmNonHeapCommitDeltaKiB=phases['active']['nmt']['vmNonHeapCommittedKiB']-phases['legacy']['nmt']['vmNonHeapCommittedKiB']) for case,phases in result['cases'].items()])))
