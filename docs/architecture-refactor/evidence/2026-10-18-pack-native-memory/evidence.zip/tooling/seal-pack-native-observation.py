"""Freeze the executed memory probe without modifying production or binary evidence."""
import hashlib
import io
import json
import zipfile
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
source=tools/'pack-native-observation'
target=project/'docs/architecture-refactor/evidence/2026-10-18-pack-native-memory'
target.mkdir(exist_ok=True)
secret=dict(line.split('=',1) for line in (Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')/'versions/26.1.2/run/server.properties').read_text().splitlines() if '=' in line and not line.startswith('#'))['rcon.password'].encode()
files={}
def add(path,name):
    assert name not in files
    data=path.read_bytes()
    assert secret not in data,'Omit sensitive input rather than altering executed binary evidence'
    files[name]=data

binding=json.loads((source/'source-binding.json').read_text())
original=Path(binding['originalPath'])
assert hashlib.sha256(original.read_bytes()).hexdigest()==binding['originalSha256']
add(original,'inputs/PackResourceStabilityTest.java')
for path in source.rglob('*'):
    if path.is_file():add(path,'observation/'+path.relative_to(source).as_posix())
for name in ['prepare-pack-native-observation.py','run-pack-native-observation.py','analyze-pack-native-observation.py','seal-pack-native-observation.py']:
    add(tools/name,'tooling/'+name)
expected=json.loads((source/'production-class-bindings.json').read_text())
actual={}
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    base=project/'common/build/classes/java/main'
    for path in sorted(base.rglob('*.class')):
        name=path.relative_to(base).as_posix()
        data=path.read_bytes()
        assert secret not in data
        actual[name]=hashlib.sha256(data).hexdigest()
        archive.writestr(name,data)
assert actual==expected and len(actual)==1152
files['binaries/common-main.jar']=buffer.getvalue()
classpath=(tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text().strip()
dependencies=[]
for entry in classpath.split(';'):
    path=Path(entry)
    if path.is_file():
        dependencies.append(dict(name=path.name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
files['dependency-bindings.json']=(json.dumps(dependencies,indent=2)+'\n').encode()
files['post-run-bindings.json']=(json.dumps(dict(originalTestUnchanged=True,productionClassesMatchBeforeRun=True,classCount=len(actual)),indent=2)+'\n').encode()
packed=target/'evidence.zip'
assert not packed.exists()
with zipfile.ZipFile(packed,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):archive.writestr(name,data)
manifest=dict(observationsOnly=True,wholeProcessCounters=True,perContextAllocationClaimed=False,
    archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),entries={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(entries=len(files),bytes=packed.stat().st_size,sha256=manifest['archiveSha256'])))
