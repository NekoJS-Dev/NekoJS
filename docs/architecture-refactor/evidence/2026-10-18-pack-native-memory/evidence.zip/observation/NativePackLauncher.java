package com.tkisor.nekojs.core.pack;
import java.io.*; import java.nio.file.*;
import org.junit.platform.engine.TestExecutionResult;
import org.junit.platform.launcher.*;
import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class NativePackLauncher {
    public static void main(String[] args)throws Exception {
        Path output=Path.of(args[0]);
        var summary=new SummaryGeneratingListener();
        var events=output.resolve("test-events.jsonl");
        var listener=new TestExecutionListener(){
            void record(TestIdentifier id,String outcome,String detail) {
                if(!id.isTest())return;
                try {Files.writeString(events,new com.google.gson.Gson().toJson(java.util.Map.of("id",id.getUniqueId(),"name",id.getDisplayName(),"outcome",outcome,"detail",detail))+"\n",StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
                catch(IOException e){throw new java.io.UncheckedIOException(e);}
            }
            @Override public void executionStarted(TestIdentifier id) {
                if(id.isTest()){NativePackMemory.currentCase=id.getDisplayName();NativePackMemory.snapshot("test-start",0);}
                record(id,"START","");
            }
            @Override public void executionFinished(TestIdentifier id,TestExecutionResult result) {
                if(id.isTest())NativePackMemory.snapshot("test-finished",0);
                record(id,result.getStatus().name(),result.getThrowable().map(Throwable::toString).orElse(""));
            }
        };
        var launcher=LauncherFactory.create();
        launcher.registerTestExecutionListeners(summary,listener);
        launcher.execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass(PackNativeObservationTest.class)).build());
        try(var writer=new PrintWriter(Files.newBufferedWriter(output.resolve("junit-summary.txt")))) {
            summary.getSummary().printTo(writer);summary.getSummary().printFailuresTo(writer);
        }
        var result=summary.getSummary();
        if(result.getTestsFoundCount()!=5||result.getTestsSucceededCount()!=5||result.getTotalFailureCount()!=0||result.getTestsSkippedCount()!=0)
            throw new AssertionError("Expected all five pack resource cases to execute and pass");
    }
}
