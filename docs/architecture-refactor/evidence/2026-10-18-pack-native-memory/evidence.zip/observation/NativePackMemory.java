package com.tkisor.nekojs.core.pack;
import java.lang.foreign.*; import java.lang.invoke.*; import java.nio.file.*; import java.util.*;
public final class NativePackMemory {
    static final SymbolLookup LIB=SymbolLookup.libraryLookup("kernel32",Arena.global());
    static final Linker LINKER=Linker.nativeLinker();
    static final MethodHandle SELF=LINKER.downcallHandle(LIB.find("GetCurrentProcess").orElseThrow(),FunctionDescriptor.of(ValueLayout.ADDRESS));
    static final MethodHandle MEMORY=LINKER.downcallHandle(LIB.find("K32GetProcessMemoryInfo").orElseThrow(),FunctionDescriptor.of(ValueLayout.JAVA_INT,ValueLayout.ADDRESS,ValueLayout.ADDRESS,ValueLayout.JAVA_INT));
    static final Path OUTPUT=Path.of(System.getProperty("neko.native.output"));
    static String currentCase="initialization";
    static int sequence;
    public static void snapshot(String stage,int contexts) {
        try(var arena=Arena.ofConfined()) {
            if(ValueLayout.ADDRESS.byteSize()!=8)throw new AssertionError("This diagnostic requires 64-bit Windows");
            var data=arena.allocate(80,8);data.set(ValueLayout.JAVA_INT,0,80);
            if((int)MEMORY.invokeExact((MemorySegment)SELF.invokeExact(),data,80)==0)throw new AssertionError("Process memory query failed");
            var row=new LinkedHashMap<String,Object>();
            row.put("case",currentCase);row.put("stage",stage);row.put("contexts",contexts);row.put("time",java.time.Instant.now().toString());
            row.put("privateCommitBytes",data.get(ValueLayout.JAVA_LONG,72));
            row.put("workingSetBytes",data.get(ValueLayout.JAVA_LONG,16));
            row.put("peakWorkingSetBytes",data.get(ValueLayout.JAVA_LONG,8));
            row.put("javaHeapUsedBytes",Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory());
            row.put("liveJavaThreads",java.lang.management.ManagementFactory.getThreadMXBean().getThreadCount());
            Path nmt=OUTPUT.getParent().resolve("nmt");Files.createDirectories(nmt);
            String name=String.format(java.util.Locale.ROOT,"%03d",sequence++);
            Path snapshot=nmt.resolve(name+".txt");
            var process=new ProcessBuilder(Path.of(System.getProperty("java.home"),"bin","jcmd.exe").toString(),
                Long.toString(ProcessHandle.current().pid()),"VM.native_memory","summary","scale=KB")
                .redirectOutput(snapshot.toFile()).redirectError(nmt.resolve(name+"-stderr.txt").toFile()).start();
            if(!process.waitFor(20,java.util.concurrent.TimeUnit.SECONDS)){process.destroyForcibly();throw new AssertionError("NMT query timed out");}
            if(process.exitValue()!=0)throw new AssertionError("NMT query failed");
            row.put("nmtSnapshot","nmt/"+name+".txt");
            Files.writeString(OUTPUT,new com.google.gson.Gson().toJson(row)+"\n",StandardOpenOption.CREATE,StandardOpenOption.APPEND);
        }catch(Throwable failure){throw new AssertionError("Native process observation failed",failure);}
    }
}
