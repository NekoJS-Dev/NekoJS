// <REDACTED-RCON-CREDENTIAL> startup fixture 6/10：fluid ×1 + creativeModeTab ×1（README「注册流体与创造模式标签页」）
console.info('PERF02-STARTUP s06 fluids-tabs load');
RegistryEvents.register(event => {
    event.fluid('nekojs:<REDACTED-RCON-CREDENTIAL>_molten_iron', b => {
        b.density = 3000;
        b.viscosity = 6000;
        b.temperature = 1500;
        b.lightLevel = 12;
    });
    event.creativeModeTab('nekojs:<REDACTED-RCON-CREDENTIAL>_tab', b => {
        b.title = 'Perf02 Tab';
        b.icon = 'nekojs:<REDACTED-RCON-CREDENTIAL>_item_01';
        b.add('nekojs:<REDACTED-RCON-CREDENTIAL>_item_01');
        b.add('nekojs:<REDACTED-RCON-CREDENTIAL>_item_02');
        b.add('nekojs:<REDACTED-RCON-CREDENTIAL>_block_01');
    });
});
