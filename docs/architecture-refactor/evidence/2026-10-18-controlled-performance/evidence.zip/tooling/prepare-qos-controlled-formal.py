"""Reuse the unchanged formal sampler with a separately recorded process policy."""
from pathlib import Path

tools=Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout')
source=(tools/'formal-performance.py').read_text(encoding='utf-8')
source=source.replace('import hashlib', 'import importlib.util\nimport hashlib',1)
source=source.replace("project = Path('D:/mcmodDemo/NekoJS-mult')", """project = Path('D:/mcmodDemo/NekoJS-mult')
spec = importlib.util.spec_from_file_location('owned_process_qos', project/'build/priority-closeout/owned-process-qos.py')
policy_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy_module)""")
source=source.replace("    scope='Existing source runServer startup/reload policy; not installed-JAR startup timing')", """    scope='Original sampler and workload under explicit owned-process HighQoS; not installed-JAR startup timing',
    originalUncontrolledVerdict='FAIL', samplerChanged=False, executionPolicyChanged=True,
    controlledPolicy=dict(scope='new game Java process under this owned project only', executionSpeed='HighQoS',
        systemPowerPlanChanged=False, affinityChanged=False, processPriorityChanged=False,
        timing='apply after owned-process identity query, keep through session, restore live processes on controller exit'))""")
source=source.replace('    with (destination / (group + \'.txt\')).open', "    sidecar = policy_module.OwnedProcessQos(worktree, destination/(group+'-policy.json'))\n    sidecar.start()\n    with (destination / (group + '.txt')).open")
source=source.replace('    code = process.wait()', '''    try:
        code = process.wait()
    finally:
        sidecar.stop()
    expected_processes = 7 if group == 'startup' else 1
    assert len(sidecar.records) == expected_processes, 'Owned game policy coverage incomplete'
    assert all(row['status'] == 'process-exited' and row['lifetimeEnded'] and row['readbacks'] > 1 for row in sidecar.records)
    assert all(row['originalPolicy'] == [1,0,0] and row['appliedPolicy'] == [1,1,0] for row in sidecar.records)''')
(tools/'qos-controlled-formal.py').write_text(source,encoding='utf-8')
print('QOS_CONTROLLED_FORMAL_PREPARED')
