import importlib.util
import hashlib
import json
import os
import socket
import subprocess
import time
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
output = tools/'historical-3400-qos-controlled'
spec=importlib.util.spec_from_file_location('owned_process_qos',tools/'owned-process-qos.py')
policy_module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy_module)
preparation = json.loads((output/'preparation.json').read_text())
assert json.loads((output/'build-result.json').read_text())['exitCode'] == 0
root, inner = Path(preparation['worktree']), Path(preparation['project'])
assert inner == root/'NekoJS-mult'
revision = preparation['revision']
assert not (output/'groups.json').exists()
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME']+'/bin;'+environment['PATH']
environment['PSModulePath'] = 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules;C:/Program Files/WindowsPowerShell/Modules'


def class_bindings():
    records = {}
    for relative in ['common/build/classes/java/main',
                     'versions/26.1.2/build/classes/java/main']:
        directory = inner/relative
        assert directory.is_dir(), relative
        files = list(directory.rglob('*.class'))
        assert files, relative
        for file in files:
            records[file.relative_to(inner).as_posix()] = hashlib.sha256(file.read_bytes()).hexdigest()
    assert records
    return records


def guard():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == revision
    assert subprocess.run(['git', 'diff', '--quiet'], cwd=root).returncode == 0
    for relative, expected in preparation['addedUntrackedHarness'].items():
        assert hashlib.sha256((inner/relative).read_bytes()).hexdigest() == expected
    run = inner/'versions/26.1.2/run'
    for path in [run, *run.parents]:
        assert not path.is_symlink() and not path.is_junction()
    for name in ['nekojs', '.neko_probe', 'world']:
        path = run/name
        assert path.resolve().is_relative_to(run.resolve())
        if path.exists():
            for member in [path, *path.rglob('*')]:
                assert not member.is_symlink() and not member.is_junction()
    for port in [25871, 25872]:
        with socket.socket() as listener: listener.bind(('127.0.0.1', port))


guard()
frozen = class_bindings()
(output/'class-bindings.json').write_text(json.dumps(frozen, indent=2)+'\n')
(output/'plan.json').write_text(json.dumps(dict(diagnosticOnly=True, groups=['reload-1', 'reload-2', 'startup'], executionPolicyChanged=True, samplerChanged=False, executionPolicy='Owned game process HighQoS',
    warmup=2, samples=5, reloads=5, initialWorld='new owned world; not historical world',
    interpretation='Current-environment old-source control; does not override current-source formal FAIL'), indent=2)+'\n')
groups = []
for label in ['reload-1', 'reload-2', 'startup']:
    guard()
    assert class_bindings() == frozen
    out_root = inner/'bench/perf/out'
    before = set(out_root.iterdir()) if out_root.exists() else set()
    arguments = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(inner/'bench/perf/sample.ps1'),
        '-Mode', 'startup' if label == 'startup' else 'reload', '-Node', '26.1.2', '-Warmup', '2', '-Samples', '5',
        '-Reloads', '5', '-GradleUserHome', 'D:/mcmodDemo/NekoJS/.gradle-<REDACTED-RCON-CREDENTIAL>', '-ServerPort', '25871', '-RconPort', '25872']
    print('OLD_REFERENCE_START '+label, flush=True)
    start = time.monotonic()
    sidecar=policy_module.OwnedProcessQos(inner,output/(label+'-policy.json'))
    sidecar.start()
    with (output/(label+'-stdout.log')).open('xb') as stdout, (output/(label+'-stderr.log')).open('xb') as stderr:
        process = subprocess.Popen(arguments, cwd=inner, env=environment, stdout=stdout, stderr=stderr,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        (output/(label+'-owner.json')).write_text(json.dumps(dict(pid=process.pid, project=str(inner), group=label))+'\n')
        try:
            code = process.wait()
        finally:
            sidecar.stop()
        assert len(sidecar.records)==(7 if label=='startup' else 1), 'Owned game policy coverage incomplete'
        assert all(r['status']=='process-exited' and r['lifetimeEnded'] and r['readbacks']>1 for r in sidecar.records)
        assert all(r['originalPolicy']==[1,0,0] and r['appliedPolicy']==[1,1,0] for r in sidecar.records)
    created = sorted(set(out_root.iterdir())-before)
    row = dict(group=label, exitCode=code, seconds=time.monotonic()-start, outputs=[str(path) for path in created])
    groups.append(row)
    (output/'groups.json').write_text(json.dumps(groups, indent=2)+'\n')
    print('OLD_REFERENCE_EXIT '+json.dumps(row), flush=True)
    assert code == 0 and len(created) == 1
    assert class_bindings() == frozen
guard()
print('OLD_REFERENCE_COMPLETE', flush=True)
