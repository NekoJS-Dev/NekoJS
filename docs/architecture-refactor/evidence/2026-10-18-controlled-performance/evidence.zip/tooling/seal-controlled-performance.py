"""Archive the original-sampler controlled runs, including failures and actual compiled artifacts."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
target=project/'docs/architecture-refactor/evidence/2026-10-18-controlled-performance'
worktree=Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
secret=dict(line.split('=',1) for line in (worktree/'versions/26.1.2/run/server.properties').read_text().splitlines() if line and not line.startswith('#') and '=' in line)['rcon.password'].encode()
files={};redactions={}
def add(path,name,binary=False):
    assert name not in files
    data=path.read_bytes()
    if secret in data:
        assert not binary,'Never redact binary evidence'
        redactions[name]=dict(originalSha256=hashlib.sha256(data).hexdigest(),occurrences=data.count(secret))
        data=data.replace(secret,b'<REDACTED-RCON-CREDENTIAL>')
    files[name]=data

post={}
for label,directory in [('current','candidate-6e5bb8f0-qos-controlled'),('historical','historical-3400-qos-controlled')]:
    root=tools/directory
    preparation=json.loads((root/'preparation.json').read_text(encoding='utf-8'))
    tree=Path(preparation['worktree'])
    inner=Path(preparation.get('project',tree))
    assert subprocess.run(['git','diff','--quiet'],cwd=tree).returncode==0
    bindings={}
    for relative in ['common/build/classes/java/main','versions/26.1.2/build/classes/java/main']:
        base=inner/relative
        for file in base.rglob('*.class'):
            key=file.relative_to(base).as_posix() if label=='current' else file.relative_to(inner).as_posix()
            assert key not in bindings
            bindings[key]=hashlib.sha256(file.read_bytes()).hexdigest()
    expected=preparation['classBindings'] if label=='current' else json.loads((root/'class-bindings.json').read_text(encoding='utf-8'))
    assert bindings==expected
    post[label]=dict(classBindings=bindings,matchBeforeRun=True,trackedSourcesClean=True)
    for file in root.iterdir():
        if file.is_file():add(file,label+'/metadata/'+file.name)
    for group in json.loads((root/'groups.json').read_text(encoding='utf-8')):
        folder=Path(group.get('outputDirectories',group.get('outputs'))[0])
        for file in folder.rglob('*'):
            if file.is_file():add(file,label+'/'+group['group']+'/'+file.relative_to(folder).as_posix())
    if label=='current':
        artifact=Path(preparation['artifact'])
        assert hashlib.sha256(artifact.read_bytes()).hexdigest()==preparation['artifactSha256']
        add(artifact,'binaries/current-neoforge.jar',True)
        harness={r:preparation['samplerSha256'] for r in ['bench/perf/sample.ps1']}
        harness.update(preparation['fixtureHashes'])
        harness['bench/perf/rcon.py']=hashlib.sha256((inner/'bench/perf/rcon.py').read_bytes()).hexdigest()
    else:
        for module,base in [('historical-common',inner/'common/build/libs'),('historical-neoforge',inner/'versions/26.1.2/build/libs')]:
            jars=[p for p in base.glob('*.jar') if not p.name.endswith(('-sources.jar','-javadoc.jar'))]
            assert len(jars)==1
            add(jars[0],'binaries/'+module+'.jar',True)
        harness=preparation['addedUntrackedHarness']
    for relative,sha in harness.items():
        file=inner/relative
        assert hashlib.sha256(file.read_bytes()).hexdigest()==sha
        add(file,label+'/harness/'+relative.removeprefix('bench/perf/'))
    files[label+'/harness-bindings.json']=(json.dumps(harness,indent=2)+'\n').encode()
files['post-run-bindings.json']=(json.dumps(post,indent=2)+'\n').encode()
for name in ['owned-process-qos.py','prepare-qos-controlled-formal.py','qos-controlled-formal.py','prepare-historical-qos.py',
             'run-historical-qos.py','analyze-qos-controlled.py','seal-controlled-performance.py']:
    add(tools/name,'tooling/'+name)
files['redactions.json']=(json.dumps(redactions,indent=2)+'\n').encode()
packed=target/'evidence.zip'
assert not packed.exists()
with zipfile.ZipFile(packed,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):archive.writestr(name,data)
manifest=dict(executionPolicyChanged=True,samplerChanged=False,originalUncontrolledVerdict='FAIL',
    archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),entries={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(entries=len(files),bytes=packed.stat().st_size,sha256=manifest['archiveSha256'])))
