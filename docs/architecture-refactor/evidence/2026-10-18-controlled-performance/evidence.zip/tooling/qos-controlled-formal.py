import importlib.util
import hashlib
import json
import os
import socket
import subprocess
import sys
import time
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
spec = importlib.util.spec_from_file_location('owned_process_qos', project/'build/priority-closeout/owned-process-qos.py')
policy_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy_module)
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
revision, label = sys.argv[1:3]
destination = project / 'build/priority-closeout' / label
assert not destination.exists(), 'Preserve existing formal results'
sampler = worktree / 'bench/perf/sample.ps1'
sampler_sha = '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME'] + '/bin;' + environment['PATH']
environment['PSModulePath'] = 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules;C:/Program Files/WindowsPowerShell/Modules'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def classes():
    result = {}
    for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
        directory = worktree / relative
        assert directory.is_dir()
        for path in directory.rglob('*.class'):
            key = path.relative_to(directory).as_posix()
            assert key not in result, key
            assert 'ReloadPerfProbe' not in key, 'Temporary diagnostic class remains'
            assert b'DEBUG-CLOSEOUT-16' not in path.read_bytes() and b'DEBUG-CLOSEOUT-17' not in path.read_bytes(), key
            result[key] = digest(path)
    assert len(result) > 1500
    return result

def fixtures():
    return {p.relative_to(worktree).as_posix(): digest(p)
            for p in (worktree / 'bench/perf/fixtures/nekojs').rglob('*') if p.is_file()}

def guard():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == revision
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
    assert digest(sampler) == sampler_sha
    for path in [worktree / 'versions/26.1.2/run', *list((worktree / 'versions/26.1.2/run').parents)]:
        assert not path.is_symlink() and not path.is_junction(), path
    run_root = worktree / 'versions/26.1.2/run'
    for name in ['nekojs', '.neko_probe', 'world']:
        target = run_root / name
        assert target.resolve().is_relative_to(run_root.resolve())
        if target.exists():
            for path in [target, *target.rglob('*')]:
                assert not path.is_symlink() and not path.is_junction(), path
    for port in [25871, 25872]:
        with socket.socket() as listener:
            listener.bind(('127.0.0.1', port))

guard()
destination.mkdir()
frozen_classes = classes()
frozen_fixtures = fixtures()
artifacts = list((worktree / 'versions/26.1.2/build/libs').glob('nekojs-neoforge-26.1.2-*.jar'))
assert len(artifacts) == 1, artifacts
artifact = artifacts[0]
with zipfile.ZipFile(artifact) as archive:
    for name, expected in frozen_classes.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected, name
preparation = dict(revision=revision, worktree=str(worktree), samplerSha256=sampler_sha,
    fixtureHashes=frozen_fixtures, plannedGroups=['reload-1', 'reload-2', 'startup'],
    warmup=2, samples=5, reloads=5, artifact=str(artifact), artifactSha256=digest(artifact),
    classBindings=frozen_classes, classesMatchBuiltArtifact=True,
    scope='Original sampler and workload under explicit owned-process HighQoS; not installed-JAR startup timing',
    originalUncontrolledVerdict='FAIL', samplerChanged=False, executionPolicyChanged=True,
    controlledPolicy=dict(scope='new game Java process under this owned project only', executionSpeed='HighQoS',
        systemPowerPlanChanged=False, affinityChanged=False, processPriorityChanged=False,
        timing='apply after owned-process identity query, keep through session, restore live processes on controller exit'))
(destination / 'preparation.json').write_text(json.dumps(preparation, indent=2) + '\n', encoding='utf-8')
groups = []
for group in preparation['plannedGroups']:
    guard()
    assert classes() == frozen_classes and fixtures() == frozen_fixtures
    outputs = worktree / 'bench/perf/out'
    before = set(outputs.iterdir()) if outputs.exists() else set()
    arguments = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(sampler),
        '-Mode', 'startup' if group == 'startup' else 'reload', '-Node', '26.1.2', '-Warmup', '2',
        '-Samples', '5', '-Reloads', '5', '-GradleUserHome', 'D:/mcmodDemo/NekoJS/.gradle-<REDACTED-RCON-CREDENTIAL>',
        '-ServerPort', '25871', '-RconPort', '25872']
    print('FORMAL_GROUP_START', group, flush=True)
    started = time.monotonic()
    sidecar = policy_module.OwnedProcessQos(worktree, destination/(group+'-policy.json'))
    sidecar.start()
    with (destination / (group + '.txt')).open('xb') as out, (destination / (group + '-stderr.txt')).open('xb') as err:
        process = subprocess.Popen(arguments, cwd=worktree, env=environment, stdout=out, stderr=err,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
    (destination / (group + '-owner.json')).write_text(json.dumps(dict(pid=process.pid,
        executable=arguments[0], worktree=str(worktree), arguments=arguments), indent=2) + '\n', encoding='utf-8')
    try:
        code = process.wait()
    finally:
        sidecar.stop()
    expected_processes = 7 if group == 'startup' else 1
    assert len(sidecar.records) == expected_processes, 'Owned game policy coverage incomplete'
    assert all(row['status'] == 'process-exited' and row['lifetimeEnded'] and row['readbacks'] > 1 for row in sidecar.records)
    assert all(row['originalPolicy'] == [1,0,0] and row['appliedPolicy'] == [1,1,0] for row in sidecar.records)
    created = sorted(set(outputs.iterdir()) - before)
    row = dict(group=group, exitCode=code, seconds=round(time.monotonic()-started, 3),
        outputDirectories=[str(p) for p in created])
    groups.append(row)
    (destination / 'groups.json').write_text(json.dumps(groups, indent=2) + '\n', encoding='utf-8')
    print('FORMAL_GROUP_EXIT', json.dumps(row), flush=True)
    assert code == 0 and len(created) == 1, row
    assert classes() == frozen_classes and fixtures() == frozen_fixtures
guard()
print('FORMAL_GROUPS_COMPLETE', flush=True)
