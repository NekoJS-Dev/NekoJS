"""Judge all prespecified groups at the original limits, retaining missing and failed samples."""
import datetime
import json
import re
import statistics
import sys
from pathlib import Path

tools=Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout')
output=tools/sys.argv[1]
preparation=json.loads((output/'preparation.json').read_text(encoding='utf-8'))
revision=preparation['revision']
assert revision in ['3400e97ee27e29b487ec100836cf04777262c84d','6e5bb8f00c3747b828056589853cb0471477b18a']
groups=json.loads((output/'groups.json').read_text(encoding='utf-8'))
assert [r['group'] for r in groups]==['reload-1','reload-2','startup']
result=dict(executionPolicyChanged=True,samplerChanged=False,productionImprovementClaimed=False,
    originalUncontrolledVerdict='FAIL',revision=revision,groups=[])
for group in groups:
    label=group['group']
    directories=group.get('outputDirectories',group.get('outputs'))
    assert group['exitCode']==0 and len(directories)==1
    folder=Path(directories[0])
    rows=[json.loads(line) for line in (folder/'samples.jsonl').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    startup=label=='startup'
    assert len(rows)==(7 if startup else 5)
    assert [r['index'] for r in rows]==list(range(1,len(rows)+1))
    formal=[r for r in rows if r['kind']=='formal']
    warmup=[r for r in rows if r['kind']=='warmup']
    assert len(formal)==5 and len(warmup)==(2 if startup else 0)
    field,limit=('wall_done_ms',41173) if startup else ('marker_ms',285.3)
    invalid=[]
    for r in rows:
        assert r['rev']==revision[:8] and r['node']=='26.1.2'
        valid=r.get(field) is not None and r.get('done_s') is not None and r.get('wall_done_ms') is not None
        valid=valid and r.get('forced_kill') is False and r.get('killed') is False and not r.get('timeout') and r.get('stop_channel')=='rcon'
        if not startup:
            response=r.get('rcon_response','').strip()
            successful=(response=='NekoJS server scripts reloaded. - no errors.') if revision.startswith('3400e97e') else ('phase=COMMIT - no errors.' in response)
            valid=valid and successful and 'PERF02-SERVER tick-bench load' in r.get('marker_line','')
        if not valid:invalid.append(r['index'])
    policy=json.loads((output/(label+'-policy.json')).read_text(encoding='utf-8'))
    assert policy['error'] is None and policy['globalSettingsChanged'] is False
    assert len(policy['processes'])==(7 if startup else 1)
    selected=rows if startup else rows[:1]
    for process,row in zip(policy['processes'],selected,strict=True):
        assert process['owned'] and process['originalPolicy']==[1,0,0] and process['appliedPolicy']==[1,1,0]
        assert process['status']=='process-exited' and process['lifetimeEnded'] and process['readbacks']>1
        text=(folder/(row['tag']+'-stdout.log')).read_text(encoding='utf-8-sig',errors='replace')
        match=re.search(r'\[(\d\d:\d\d:\d\d)\][^\r\n]*Done \(\d+\.\d+s\)!',text)
        assert match, 'Done log timestamp missing'
        created=process['createdAt100ns']/1e7-11644473600
        zone=datetime.timezone(datetime.timedelta(hours=8))
        date=datetime.datetime.fromtimestamp(created,zone).date()
        done=datetime.datetime.combine(date,datetime.time.fromisoformat(match[1]),zone).timestamp()
        if done<created:done+=86400
        assert process['appliedAtUnix']<done, 'Process control was not applied before Done'
    values=[r[field] for r in formal]
    mean=statistics.mean(values) if not invalid else None
    verdict='INVALID' if invalid else 'PASS' if mean<=limit else 'FAIL'
    record=dict(group=label,values=values,mean=mean,limit=limit,invalidIndices=invalid,verdict=verdict,
        maximumPolicyDiscoveryDelayMs=max(r['discoveryDelayMs'] for r in policy['processes']))
    if not startup:record['rconMean']=statistics.mean(r['rcon_rtt_ms'] for r in formal)
    result['groups'].append(record)
result['controlledVerdict']='PASS' if all(r['verdict']=='PASS' for r in result['groups']) else 'FAIL'
(output/'judgment.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
