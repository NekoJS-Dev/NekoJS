"""Prespecify the same controlled-environment sampling for the rebuilt historical source."""
import importlib.util
import json
from pathlib import Path

tools=Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout')
target=tools/'historical-3400-qos-controlled'
assert not target.exists()
target.mkdir()
for name in ['preparation.json','build-result.json']:
    (target/name).write_bytes((tools/'historical-reference-3400'/name).read_bytes())
source=(tools/'run-historical-reference.py').read_text(encoding='utf-8')
source=source.replace('import hashlib','import importlib.util\nimport hashlib',1)
source=source.replace("output = tools/'historical-reference-3400'", """output = tools/'historical-3400-qos-controlled'
spec=importlib.util.spec_from_file_location('owned_process_qos',tools/'owned-process-qos.py')
policy_module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy_module)""")
source=source.replace("groups=['startup', 'reload-1', 'reload-2']", "groups=['reload-1', 'reload-2', 'startup'], executionPolicyChanged=True, samplerChanged=False, executionPolicy='Owned game process HighQoS'")
source=source.replace("for label in ['startup', 'reload-1', 'reload-2']:", "for label in ['reload-1', 'reload-2', 'startup']:")
source=source.replace('    with (output/(label+\'-stdout.log\')).open', "    sidecar=policy_module.OwnedProcessQos(inner,output/(label+'-policy.json'))\n    sidecar.start()\n    with (output/(label+'-stdout.log')).open")
source=source.replace('        code = process.wait()', '''        try:
            code = process.wait()
        finally:
            sidecar.stop()
        assert len(sidecar.records)==(7 if label=='startup' else 1), 'Owned game policy coverage incomplete'
        assert all(r['status']=='process-exited' and r['lifetimeEnded'] and r['readbacks']>1 for r in sidecar.records)
        assert all(r['originalPolicy']==[1,0,0] and r['appliedPolicy']==[1,1,0] for r in sidecar.records)''')
(tools/'run-historical-qos.py').write_text(source,encoding='utf-8')
print(json.dumps(dict(prepared=True,productionSourcesChanged=False,groups=['reload-1','reload-2','startup'],warmup=2,samples=5,reloads=5)))
