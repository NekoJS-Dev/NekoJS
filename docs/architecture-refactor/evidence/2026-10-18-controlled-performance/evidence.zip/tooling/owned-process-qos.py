"""A scoped Windows process-policy sidecar for the unchanged performance sampler."""
import ctypes
from ctypes import wintypes
import json
import subprocess
import threading
import time
from pathlib import Path

KERNEL = ctypes.WinDLL('kernel32', use_last_error=True)


class ProcessEntry(ctypes.Structure):
    _fields_ = [('size', wintypes.DWORD), ('usage', wintypes.DWORD), ('pid', wintypes.DWORD),
                ('heap', ctypes.c_size_t), ('module', wintypes.DWORD), ('threads', wintypes.DWORD),
                ('parent', wintypes.DWORD), ('priority', wintypes.LONG), ('flags', wintypes.DWORD),
                ('name', wintypes.WCHAR * 260)]


class Policy(ctypes.Structure):
    _fields_ = [('version', wintypes.ULONG), ('control', wintypes.ULONG), ('state', wintypes.ULONG)]


KERNEL.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
KERNEL.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
for name in ['Process32FirstW', 'Process32NextW']:
    getattr(KERNEL, name).argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry)]
    getattr(KERNEL, name).restype = wintypes.BOOL
KERNEL.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
KERNEL.OpenProcess.restype = wintypes.HANDLE
KERNEL.GetProcessInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
KERNEL.SetProcessInformation.argtypes = KERNEL.GetProcessInformation.argtypes
KERNEL.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4)]
KERNEL.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
KERNEL.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
KERNEL.CloseHandle.argtypes = [wintypes.HANDLE]


def check(value, label):
    if not value:
        raise OSError(ctypes.get_last_error(), label)


def processes():
    handle = KERNEL.CreateToolhelp32Snapshot(2, 0)
    assert handle != ctypes.c_void_p(-1).value
    try:
        entry = ProcessEntry()
        entry.size = ctypes.sizeof(entry)
        more = KERNEL.Process32FirstW(handle, ctypes.byref(entry))
        result = []
        while more:
            if entry.name.lower() == 'java.exe':
                result.append(dict(pid=entry.pid, parent=entry.parent))
            more = KERNEL.Process32NextW(handle, ctypes.byref(entry))
        return result
    finally:
        check(KERNEL.CloseHandle(handle), 'Close snapshot')


def read(handle):
    state = Policy(1, 0, 0)
    check(KERNEL.GetProcessInformation(handle, 4, ctypes.byref(state), ctypes.sizeof(state)), 'Get process policy')
    return [state.version, state.control, state.state]


def write(handle, values):
    state = Policy(*values)
    check(KERNEL.SetProcessInformation(handle, 4, ctypes.byref(state), ctypes.sizeof(state)), 'Set process policy')
    assert read(handle) == values, 'Process policy readback mismatch'


def alive(handle):
    code = wintypes.DWORD()
    check(KERNEL.GetExitCodeProcess(handle, ctypes.byref(code)), 'Get exit status')
    return code.value == 259


class OwnedProcessQos:
    def __init__(self, project, output):
        self.project = str(Path(project).resolve())
        self.output = Path(output)
        self.seen = {row['pid'] for row in processes()}
        self.records, self.handles, self.error = [], {}, None
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self.run, name='owned-process-policy', daemon=False)
        self.scans = 0

    def save(self):
        self.output.write_text(json.dumps(dict(policy='HighQoS execution-speed opt-out',
            globalSettingsChanged=False, project=self.project, scans=self.scans,
            processes=self.records, error=self.error), indent=2) + '\n', encoding='utf-8')

    def identify(self, pid):
        # WMI sees the command line internally. Only the ownership result crosses stdout.
        escaped = self.project.replace("'", "''")
        script = "$p=Get-CimInstance Win32_Process -Filter 'ProcessId=" + str(pid) + "';"
        script += "$owned=$null -ne $p -and $p.CommandLine.IndexOf('" + escaped + "',[StringComparison]::OrdinalIgnoreCase) -ge 0"
        script += " -and $p.CommandLine.Contains('serverRunProgramArgs.txt') -and $p.CommandLine.Contains('serverRunVmArgs.txt');"
        script += "[pscustomobject]@{owned=$owned;pid=" + str(pid) + ";parent=$p.ParentProcessId}|ConvertTo-Json -Compress"
        query = subprocess.run(['powershell.exe', '-NoProfile', '-Command', script], capture_output=True,
                               creationflags=subprocess.CREATE_NO_WINDOW, timeout=20)
        assert query.returncode == 0, 'Owned process query failed'
        return json.loads(query.stdout.decode('utf-8-sig'))

    def apply(self, row):
        identity = self.identify(row['pid'])
        if not identity['owned']:
            return
        handle = KERNEL.OpenProcess(0x1200, False, row['pid'])
        check(handle, 'Open owned game process')
        try:
            image = ctypes.create_unicode_buffer(32768)
            length = wintypes.DWORD(len(image))
            check(KERNEL.QueryFullProcessImageNameW(handle, 0, image, ctypes.byref(length)), 'Query Java image')
            assert Path(image.value).resolve() == Path('C:/Program Files/Java/jdk-25.0.2/bin/java.exe').resolve()
            stamps = [wintypes.FILETIME() for _ in range(4)]
            check(KERNEL.GetProcessTimes(handle, *[ctypes.byref(v) for v in stamps]), 'Query creation time')
            created = stamps[0].dwLowDateTime + (stamps[0].dwHighDateTime << 32)
            original = read(handle)
            selected = [original[0], original[1] | 1, original[2] & ~1]
            record = dict(identity, createdAt100ns=created, originalPolicy=original,
                          appliedPolicy=selected, status='opening')
            self.records.append(record)
            self.handles[row['pid']] = (handle, record)
            handle = None
            write(self.handles[row['pid']][0], selected)
            record.update(status='applied', appliedAtUnix=time.time(),
                          discoveryDelayMs=(time.time() - (created / 1e7 - 11644473600)) * 1000,
                          readbacks=1)
            self.save()
        finally:
            if handle:
                check(KERNEL.CloseHandle(handle), 'Close rejected process')

    def run(self):
        try:
            while not self.stop_event.is_set():
                self.scans += 1
                for row in processes():
                    if row['pid'] not in self.seen:
                        self.seen.add(row['pid'])
                        self.apply(row)
                for pid, (handle, record) in list(self.handles.items()):
                    if alive(handle):
                        assert read(handle) == record['appliedPolicy'], 'Owned game policy changed during measurement'
                        record['readbacks'] += 1
                    else:
                        record.update(status='process-exited', lifetimeEnded=True)
                        check(KERNEL.CloseHandle(handle), 'Close exited process')
                        del self.handles[pid]
                        self.save()
                self.stop_event.wait(.1)
        except BaseException as failure:
            self.error = type(failure).__name__ + ': ' + str(failure)
        finally:
            for handle, record in self.handles.values():
                try:
                    if alive(handle):
                        write(handle, record['originalPolicy'])
                        record.update(status='restored-live', restoredPolicy=read(handle))
                    else:
                        record.update(status='process-exited', lifetimeEnded=True)
                except BaseException as failure:
                    self.error = type(failure).__name__ + ': ' + str(failure)
                finally:
                    KERNEL.CloseHandle(handle)
            self.handles.clear()
            self.save()

    def start(self):
        self.save()
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        self.thread.join(30)
        assert not self.thread.is_alive(), 'Policy sidecar failed to finish'
        assert self.error is None, self.error
