import { $Stream } from "java:java/util/stream";

declare module "java:com/tkisor/nekojs/probe" {
    export interface $ProbeStreamCaptureReturnTest$Parent<T> {
        getPassengersAndSelf(): $Stream<T>;
        getSelfAndPassengers(): $Stream<T>;
    }

    export class $ProbeStreamCaptureReturnTest$Implementation implements $ProbeStreamCaptureReturnTest$Parent<$ProbeCaptureReturnContractTest$Base> {
        constructor();
        get passengersAndSelf(): $Stream<$ProbeCaptureReturnContractTest$Child>;
        getPassengersAndSelf(): $Stream<$ProbeCaptureReturnContractTest$Child>;
        get selfAndPassengers(): $Stream<$ProbeCaptureReturnContractTest$Child>;
        getSelfAndPassengers(): $Stream<$ProbeCaptureReturnContractTest$Child>;
    }

    export class $ProbeCaptureReturnContractTest$Base {
        constructor(label: string);
        label: string;
    }

    export class $ProbeCaptureReturnContractTest$Child extends $ProbeCaptureReturnContractTest$Base {
        constructor();
        code: number;
    }

}
