import type {
  $ProbeStreamCaptureReturnTest$Parent as Parent,
  $ProbeStreamCaptureReturnTest$Implementation as Implementation,
  $ProbeCaptureReturnContractTest$Base as Base,
  $ProbeCaptureReturnContractTest$Child as Child
} from 'java:com/tkisor/nekojs/probe';
import type { $BinaryOperator } from 'java:java/util/function';
declare const implementation: Implementation;
const parent: Parent<Base> = implementation;
const narrow: Child = implementation.getSelfAndPassengers().findFirst().get();
const narrowBean: number = implementation.selfAndPassengers.findFirst().get().code;
const broad: Base = parent.getPassengersAndSelf().findFirst().get();
const name: string = parent.getSelfAndPassengers().map(value => value.label).toList().get(0);
declare const operator: $BinaryOperator<Base>;
const reduced: Base = implementation.getSelfAndPassengers().reduce(operator).get();
declare const narrowOperator: $BinaryOperator<Child>;
// @ts-expect-error A parent capture must admit the complete upper-bound operand domain.
parent.getSelfAndPassengers().reduce(narrowOperator);
// @ts-expect-error An upper-bound read does not acquire the narrow member.
broad.code;
// @ts-expect-error A captured reducer cannot return an unrelated value kind.
parent.getPassengersAndSelf().reduce((left, right) => 'wrong');
// @ts-expect-error The direct implementation still returns Child.
const wrong: string = implementation.getSelfAndPassengers().findFirst().get();
