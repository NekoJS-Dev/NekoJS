declare module "java:nekojs-test-orphan" { export const marker: string; }
