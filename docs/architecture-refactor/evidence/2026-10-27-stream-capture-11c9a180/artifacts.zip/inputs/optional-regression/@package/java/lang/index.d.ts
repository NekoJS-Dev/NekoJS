import { $InputStream, $PrintStream, $PrintWriter, $Serializable } from "java:java/io";
import { $Annotation, $Annotation_ } from "java:java/lang/annotation";
import { $ClassDesc, $Constable, $Constable_, $ConstantDesc, $ConstantDesc_, $DirectMethodHandleDesc, $DynamicConstantDesc } from "java:java/lang/constant";
import { $MethodHandles$Lookup, $TypeDescriptor$OfField } from "java:java/lang/invoke";
import { $Configuration, $ModuleDescriptor } from "java:java/lang/module";
import { $AccessFlag, $AccessFlag_, $AnnotatedElement, $AnnotatedType, $Constructor, $Field, $GenericDeclaration, $Method, $RecordComponent, $Type, $TypeVariable } from "java:java/lang/reflect";
import { $URL } from "java:java/net";
import { $CharBuffer } from "java:java/nio";
import { $ProtectionDomain } from "java:java/security";
import { $Duration } from "java:java/time";
import { $Enumeration, $Iterator, $List, $Map, $Optional, $OptionalView, $Set, $Spliterator } from "java:java/util";
import { $ThreadFactory, $ThreadFactory_ } from "java:java/util/concurrent";
import { $Consumer, $Consumer_, $Function, $Function_ } from "java:java/util/function";
import { $IntStream, $Stream } from "java:java/util/stream";

export * as annotation from "java:java/lang/annotation";
export * as constant from "java:java/lang/constant";
export * as invoke from "java:java/lang/invoke";
export * as reflect from "java:java/lang/reflect";
export * as module from "java:java/lang/module";
export * as foreign from "java:java/lang/foreign";

declare module "java:java/lang" {
    export interface $Runnable {
        run(): void;
    }

    export class $Throwable implements $Serializable {
        constructor();
        constructor(arg0: string);
        constructor(arg0: string, arg1: $Throwable);
        constructor(arg0: $Throwable);
        get cause(): $Throwable;
        getCause(): $Throwable;
        get localizedMessage(): string;
        getLocalizedMessage(): string;
        get message(): string;
        getMessage(): string;
        get stackTrace(): $StackTraceElement[];
        getStackTrace(): $StackTraceElement[];
        set stackTrace(value: $StackTraceElement[]);
        get suppressed(): $Throwable[];
        getSuppressed(): $Throwable[];
        addSuppressed(arg0: $Throwable): void;
        fillInStackTrace(): $Throwable;
        initCause(arg0: $Throwable): $Throwable;
        printStackTrace(arg0: $PrintStream): void;
        printStackTrace(arg0: $PrintWriter): void;
        printStackTrace(): void;
        setStackTrace(arg0: $StackTraceElement[]): void;
        toString(): string;
    }

    export class $StackTraceElement implements $Serializable {
        constructor(arg0: string, arg1: string, arg2: string, arg3: number);
        constructor(arg0: string, arg1: string, arg2: string, arg3: string, arg4: string, arg5: string, arg6: number);
        get classLoaderName(): string;
        getClassLoaderName(): string;
        get className(): string;
        getClassName(): string;
        get fileName(): string;
        getFileName(): string;
        get lineNumber(): number;
        getLineNumber(): number;
        get methodName(): string;
        getMethodName(): string;
        get moduleName(): string;
        getModuleName(): string;
        get moduleVersion(): string;
        getModuleVersion(): string;
        get nativeMethod(): boolean;
        isNativeMethod(): boolean;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $Appendable {
        append(arg0: string): $Appendable;
        append(arg0: $CharSequence, arg1: number, arg2: number): $Appendable;
        append(arg0: $CharSequence): $Appendable;
    }

    export interface $CharSequence {
        charAt(arg0: number): string;
        chars(): $IntStream;
        codePoints(): $IntStream;
        isEmpty(): boolean;
        length(): number;
        subSequence(arg0: number, arg1: number): $CharSequence;
        toString(): string;
    }
    export const $CharSequence: {
        compare(arg0: $CharSequence, arg1: $CharSequence): number;
    };

    export interface $AutoCloseable {
        close(): void;
    }

    export interface $Comparable<T> {
        compareTo(arg0: T): number;
    }

    export class $Class<T> implements $Serializable, $GenericDeclaration, $Type, $AnnotatedElement, $TypeDescriptor$OfField<$Class<any>>, $Constable {
        get annotatedInterfaces(): $AnnotatedType[];
        getAnnotatedInterfaces(): $AnnotatedType[];
        get annotatedSuperclass(): $AnnotatedType;
        getAnnotatedSuperclass(): $AnnotatedType;
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get canonicalName(): string;
        getCanonicalName(): string;
        get classLoader(): $ClassLoader;
        getClassLoader(): $ClassLoader;
        get classes(): $Class<any>[];
        getClasses(): $Class<any>[];
        getComponentType(): $Class<any>;
        get constructors(): $Constructor<any>[];
        getConstructors(): $Constructor<any>[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaredClasses(): $Class<any>[];
        getDeclaredClasses(): $Class<any>[];
        get declaredConstructors(): $Constructor<any>[];
        getDeclaredConstructors(): $Constructor<any>[];
        get declaredFields(): $Field[];
        getDeclaredFields(): $Field[];
        get declaredMethods(): $Method[];
        getDeclaredMethods(): $Method[];
        get declaringClass(): $Class<any>;
        getDeclaringClass(): $Class<any>;
        get enclosingClass(): $Class<any>;
        getEnclosingClass(): $Class<any>;
        get enclosingConstructor(): $Constructor<any>;
        getEnclosingConstructor(): $Constructor<any>;
        get enclosingMethod(): $Method;
        getEnclosingMethod(): $Method;
        get enumConstants(): T[];
        getEnumConstants(): T[];
        get fields(): $Field[];
        getFields(): $Field[];
        get genericInterfaces(): $Type[];
        getGenericInterfaces(): $Type[];
        get genericSuperclass(): $Type;
        getGenericSuperclass(): $Type;
        get interfaces(): $Class<any>[];
        getInterfaces(): $Class<any>[];
        get methods(): $Method[];
        getMethods(): $Method[];
        get modifiers(): number;
        getModifiers(): number;
        get module(): $Module;
        getModule(): $Module;
        get name(): string;
        getName(): string;
        get nestHost(): $Class<any>;
        getNestHost(): $Class<any>;
        get nestMembers(): $Class<any>[];
        getNestMembers(): $Class<any>[];
        get packageName(): string;
        getPackageName(): string;
        get package(): $Package;
        getPackage(): $Package;
        get permittedSubclasses(): $Class<any>[];
        getPermittedSubclasses(): $Class<any>[];
        get protectionDomain(): $ProtectionDomain;
        getProtectionDomain(): $ProtectionDomain;
        get recordComponents(): $RecordComponent[];
        getRecordComponents(): $RecordComponent[];
        get signers(): unknown[];
        getSigners(): unknown[];
        get simpleName(): string;
        getSimpleName(): string;
        get superclass(): $Class<any>;
        getSuperclass(): $Class<any>;
        get typeName(): string;
        getTypeName(): string;
        get typeParameters(): $TypeVariable<$Class<T>>[];
        getTypeParameters(): $TypeVariable<$Class<T>>[];
        get annotation(): boolean;
        isAnnotation(): boolean;
        get anonymousClass(): boolean;
        isAnonymousClass(): boolean;
        get array(): boolean;
        isArray(): boolean;
        get enum(): boolean;
        isEnum(): boolean;
        get hidden(): boolean;
        isHidden(): boolean;
        get interface(): boolean;
        isInterface(): boolean;
        get localClass(): boolean;
        isLocalClass(): boolean;
        get memberClass(): boolean;
        isMemberClass(): boolean;
        get primitive(): boolean;
        isPrimitive(): boolean;
        get record(): boolean;
        isRecord(): boolean;
        get sealed(): boolean;
        isSealed(): boolean;
        get synthetic(): boolean;
        isSynthetic(): boolean;
        get unnamedClass(): boolean;
        isUnnamedClass(): boolean;
        static forName(arg0: $Module, arg1: string): $Class<any>;
        static forName(arg0: string, arg1: boolean, arg2: $ClassLoader): $Class<any>;
        static forName(arg0: string): $Class<any>;
        accessFlags(): $Set<$AccessFlag>;
        arrayType(): $Class<any>;
        asSubclass<U>(arg0: $Class<U>): $Class<U>;
        cast(arg0: unknown): T;
        componentType(): $Class<any>;
        describeConstable(): $Optional<$ClassDesc> & $OptionalView<(number | string | $ConstantDesc)>;
        descriptorString(): string;
        desiredAssertionStatus(): boolean;
        getAnnotationsByType<A extends $Annotation>(arg0: $Class<A>): A[];
        getAnnotation<A extends $Annotation>(arg0: $Class<A>): A;
        getConstructor(arg0?: $Class<any>[]): $Constructor<T>;
        getDeclaredAnnotationsByType<A extends $Annotation>(arg0: $Class<A>): A[];
        getDeclaredAnnotation<A extends $Annotation>(arg0: $Class<A>): A;
        getDeclaredConstructor(arg0?: $Class<any>[]): $Constructor<T>;
        getDeclaredField(arg0: string): $Field;
        getDeclaredMethod(arg0: string, arg1?: $Class<any>[]): $Method;
        getField(arg0: string): $Field;
        getMethod(arg0: string, arg1?: $Class<any>[]): $Method;
        getResourceAsStream(arg0: string): $InputStream;
        getResource(arg0: string): $URL;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        isAssignableFrom(arg0: $Class<any>): boolean;
        isInstance(arg0: unknown): boolean;
        isNestmateOf(arg0: $Class<any>): boolean;
        newInstance(): T;
        toGenericString(): string;
        toString(): string;
    }

    export class $ClassLoader {
        get definedPackages(): $Package[];
        getDefinedPackages(): $Package[];
        get name(): string;
        getName(): string;
        get parent(): $ClassLoader;
        getParent(): $ClassLoader;
        get unnamedModule(): $Module;
        getUnnamedModule(): $Module;
        get registeredAsParallelCapable(): boolean;
        isRegisteredAsParallelCapable(): boolean;
        static getPlatformClassLoader(): $ClassLoader;
        static getSystemClassLoader(): $ClassLoader;
        static getSystemResourceAsStream(arg0: string): $InputStream;
        static getSystemResources(arg0: string): $Enumeration<$URL>;
        static getSystemResource(arg0: string): $URL;
        clearAssertionStatus(): void;
        getDefinedPackage(arg0: string): $Package;
        getResourceAsStream(arg0: string): $InputStream;
        getResources(arg0: string): $Enumeration<$URL>;
        getResource(arg0: string): $URL;
        loadClass(arg0: string): $Class<any>;
        resources(arg0: string): $Stream<$URL>;
        setClassAssertionStatus(arg0: string, arg1: boolean): void;
        setDefaultAssertionStatus(arg0: boolean): void;
        setPackageAssertionStatus(arg0: string, arg1: boolean): void;
    }

    export class $Module implements $AnnotatedElement {
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get classLoader(): $ClassLoader;
        getClassLoader(): $ClassLoader;
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get descriptor(): $ModuleDescriptor;
        getDescriptor(): $ModuleDescriptor;
        get layer(): $ModuleLayer;
        getLayer(): $ModuleLayer;
        get name(): string;
        getName(): string;
        get packages(): $Set<string>;
        getPackages(): $Set<string>;
        get named(): boolean;
        isNamed(): boolean;
        get nativeAccessEnabled(): boolean;
        isNativeAccessEnabled(): boolean;
        addExports(arg0: string, arg1: $Module): $Module;
        addOpens(arg0: string, arg1: $Module): $Module;
        addReads(arg0: $Module): $Module;
        addUses(arg0: $Class<any>): $Module;
        canRead(arg0: $Module): boolean;
        canUse(arg0: $Class<any>): boolean;
        getAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getDeclaredAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getDeclaredAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getResourceAsStream(arg0: string): $InputStream;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        isExported(arg0: string, arg1: $Module): boolean;
        isExported(arg0: string): boolean;
        isOpen(arg0: string, arg1: $Module): boolean;
        isOpen(arg0: string): boolean;
        toString(): string;
    }

    export class $Package extends $NamedPackage implements $AnnotatedElement {
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get implementationTitle(): string;
        getImplementationTitle(): string;
        get implementationVendor(): string;
        getImplementationVendor(): string;
        get implementationVersion(): string;
        getImplementationVersion(): string;
        get name(): string;
        getName(): string;
        get specificationTitle(): string;
        getSpecificationTitle(): string;
        get specificationVendor(): string;
        getSpecificationVendor(): string;
        get specificationVersion(): string;
        getSpecificationVersion(): string;
        get sealed(): boolean;
        isSealed(): boolean;
        static getPackages(): $Package[];
        static getPackage(arg0: string): $Package;
        getAnnotationsByType<A extends $Annotation>(arg0: $Class<A>): A[];
        getAnnotation<A extends $Annotation>(arg0: $Class<A>): A;
        getDeclaredAnnotationsByType<A extends $Annotation>(arg0: $Class<A>): A[];
        getDeclaredAnnotation<A extends $Annotation>(arg0: $Class<A>): A;
        hashCode(): number;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        isCompatibleWith(arg0: string): boolean;
        isSealed(arg0: $URL): boolean;
        toString(): string;
    }

    export class $ModuleLayer {
        static boot(): $ModuleLayer;
        static defineModulesWithManyLoaders(arg0: $Configuration, arg1: ($List<$ModuleLayer> | ($ModuleLayer)[]), arg2: $ClassLoader): $ModuleLayer$Controller;
        static defineModulesWithOneLoader(arg0: $Configuration, arg1: ($List<$ModuleLayer> | ($ModuleLayer)[]), arg2: $ClassLoader): $ModuleLayer$Controller;
        static defineModules(arg0: $Configuration, arg1: ($List<$ModuleLayer> | ($ModuleLayer)[]), arg2: $Function_<string, $ClassLoader, string, $ClassLoader>): $ModuleLayer$Controller;
        static empty(): $ModuleLayer;
        configuration(): $Configuration;
        defineModulesWithManyLoaders(arg0: $Configuration, arg1: $ClassLoader): $ModuleLayer;
        defineModulesWithOneLoader(arg0: $Configuration, arg1: $ClassLoader): $ModuleLayer;
        defineModules(arg0: $Configuration, arg1: $Function_<string, $ClassLoader, string, $ClassLoader>): $ModuleLayer;
        findLoader(arg0: string): $ClassLoader;
        findModule(arg0: string): $Optional<$Module>;
        modules(): $Set<$Module>;
        parents(): $List<$ModuleLayer>;
        toString(): string;
    }

    export class $ModuleLayer$Controller {
        addExports(arg0: $Module, arg1: string, arg2: $Module): $ModuleLayer$Controller;
        addOpens(arg0: $Module, arg1: string, arg2: $Module): $ModuleLayer$Controller;
        addReads(arg0: $Module, arg1: $Module): $ModuleLayer$Controller;
        enableNativeAccess(arg0: $Module): $ModuleLayer$Controller;
        layer(): $ModuleLayer;
    }

    export class $NamedPackage {
    }

    export class $Enum<E extends $Enum<E>> implements $Constable, $Comparable<E>, $Serializable {
        get declaringClass(): $Class<E>;
        getDeclaringClass(): $Class<E>;
        static valueOf<T extends $Enum<T>>(arg0: $Class<T>, arg1: string): T;
        compareTo(arg0: E): number;
        describeConstable(): $Optional<$Enum$EnumDesc<E>> & $OptionalView<(number | string | $ConstantDesc)>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        name(): string;
        ordinal(): number;
        toString(): string;
    }

    export class $Enum$EnumDesc<E extends $Enum<E>> extends $DynamicConstantDesc<E> {
        static of<E extends $Enum<E>>(arg0: $ClassDesc, arg1: string): $Enum$EnumDesc<E>;
        static of<T>(arg0: $DirectMethodHandleDesc, arg1?: (number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)[]): $DynamicConstantDesc<T>;
        static of<T>(arg0: $DirectMethodHandleDesc): $DynamicConstantDesc<T>;
        resolveConstantDesc(arg0: $MethodHandles$Lookup): E;
        toString(): string;
    }

    export interface $Readable {
        read(arg0: $CharBuffer): number;
    }

    export interface $Iterable<T> {
        forEach(arg0: $Consumer_<T, T>): void;
        iterator(): $Iterator<T>;
        spliterator(): $Spliterator<T>;
    }

    export class $Thread implements $Runnable {
        constructor();
        constructor(arg0: $Runnable_);
        constructor(arg0: $Runnable_, arg1: string);
        constructor(arg0: string);
        constructor(arg0: $ThreadGroup, arg1: $Runnable_);
        constructor(arg0: $ThreadGroup, arg1: $Runnable_, arg2: string);
        constructor(arg0: $ThreadGroup, arg1: $Runnable_, arg2: string, arg3: number);
        constructor(arg0: $ThreadGroup, arg1: $Runnable_, arg2: string, arg3: number, arg4: boolean);
        constructor(arg0: $ThreadGroup, arg1: string);
        static MAX_PRIORITY: number;
        static MIN_PRIORITY: number;
        static NORM_PRIORITY: number;
        get contextClassLoader(): $ClassLoader;
        getContextClassLoader(): $ClassLoader;
        set contextClassLoader(value: $ClassLoader);
        get id(): number;
        getId(): number;
        get name(): string;
        getName(): string;
        set name(value: string);
        get priority(): number;
        getPriority(): number;
        set priority(value: number);
        get stackTrace(): $StackTraceElement[];
        getStackTrace(): $StackTraceElement[];
        get state(): $Thread$State;
        getState(): $Thread$State;
        get threadGroup(): $ThreadGroup;
        getThreadGroup(): $ThreadGroup;
        get uncaughtExceptionHandler(): $Thread$UncaughtExceptionHandler;
        getUncaughtExceptionHandler(): $Thread$UncaughtExceptionHandler;
        set uncaughtExceptionHandler(value: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>);
        get alive(): boolean;
        isAlive(): boolean;
        get daemon(): boolean;
        isDaemon(): boolean;
        set daemon(value: boolean);
        get interrupted(): boolean;
        isInterrupted(): boolean;
        get virtual(): boolean;
        isVirtual(): boolean;
        static activeCount(): number;
        static currentThread(): $Thread;
        static dumpStack(): void;
        static enumerate(arg0: $Thread[]): number;
        static getAllStackTraces(): $Map<$Thread, $StackTraceElement[]>;
        static getDefaultUncaughtExceptionHandler(): $Thread$UncaughtExceptionHandler;
        static holdsLock(arg0: unknown): boolean;
        static interrupted(): boolean;
        static ofPlatform(): $Thread$Builder$OfPlatform;
        static ofVirtual(): $Thread$Builder$OfVirtual;
        static onSpinWait(): void;
        static setDefaultUncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): void;
        static sleep(arg0: $Duration): void;
        static sleep(arg0: number, arg1: number): void;
        static sleep(arg0: number): void;
        static startVirtualThread(arg0: $Runnable_): $Thread;
        static yield(): void;
        checkAccess(): void;
        countStackFrames(): number;
        interrupt(): void;
        join(arg0: $Duration): boolean;
        join(arg0: number, arg1: number): void;
        join(arg0: number): void;
        join(): void;
        resume(): void;
        run(): void;
        setContextClassLoader(arg0: $ClassLoader): void;
        setDaemon(arg0: boolean): void;
        setName(arg0: string): void;
        setPriority(arg0: number): void;
        setUncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): void;
        start(): void;
        stop(): void;
        suspend(): void;
        threadId(): number;
        toString(): string;
    }

    export interface $Thread$Builder$OfPlatform extends $Thread$Builder {
        daemon(arg0: boolean): $Thread$Builder$OfPlatform;
        daemon(): $Thread$Builder$OfPlatform;
        group(arg0: $ThreadGroup): $Thread$Builder$OfPlatform;
        inheritInheritableThreadLocals(arg0: boolean): $Thread$Builder$OfPlatform;
        name(arg0: string, arg1: number): $Thread$Builder$OfPlatform;
        name(arg0: string): $Thread$Builder$OfPlatform;
        priority(arg0: number): $Thread$Builder$OfPlatform;
        stackSize(arg0: number): $Thread$Builder$OfPlatform;
        uncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): $Thread$Builder$OfPlatform;
    }

    export interface $Thread$Builder$OfVirtual extends $Thread$Builder {
        inheritInheritableThreadLocals(arg0: boolean): $Thread$Builder$OfVirtual;
        name(arg0: string, arg1: number): $Thread$Builder$OfVirtual;
        name(arg0: string): $Thread$Builder$OfVirtual;
        uncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): $Thread$Builder$OfVirtual;
    }

    export class $Thread$State {
        static BLOCKED: $Thread$State;
        static NEW: $Thread$State;
        static RUNNABLE: $Thread$State;
        static TERMINATED: $Thread$State;
        static TIMED_WAITING: $Thread$State;
        static WAITING: $Thread$State;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Thread$State[];
        static valueOf(name: string): $Thread$State;
    }
    export interface $Thread$State extends $Enum<$Thread$State> {}

    export interface $Thread$UncaughtExceptionHandler {
        uncaughtException(arg0: $Thread, arg1: $Throwable): void;
    }

    export class $ThreadGroup implements $Thread$UncaughtExceptionHandler {
        constructor(arg0: string);
        constructor(arg0: $ThreadGroup, arg1: string);
        get maxPriority(): number;
        getMaxPriority(): number;
        set maxPriority(value: number);
        get name(): string;
        getName(): string;
        get parent(): $ThreadGroup;
        getParent(): $ThreadGroup;
        get daemon(): boolean;
        isDaemon(): boolean;
        set daemon(value: boolean);
        get destroyed(): boolean;
        isDestroyed(): boolean;
        activeCount(): number;
        activeGroupCount(): number;
        checkAccess(): void;
        destroy(): void;
        enumerate(arg0: $ThreadGroup[], arg1: boolean): number;
        enumerate(arg0: $ThreadGroup[]): number;
        enumerate(arg0: $Thread[], arg1: boolean): number;
        enumerate(arg0: $Thread[]): number;
        interrupt(): void;
        list(): void;
        parentOf(arg0: $ThreadGroup): boolean;
        resume(): void;
        setDaemon(arg0: boolean): void;
        setMaxPriority(arg0: number): void;
        stop(): void;
        suspend(): void;
        toString(): string;
        uncaughtException(arg0: $Thread, arg1: $Throwable): void;
    }

    export interface $Thread$Builder {
        factory(): $ThreadFactory;
        inheritInheritableThreadLocals(arg0: boolean): $Thread$Builder;
        name(arg0: string, arg1: number): $Thread$Builder;
        name(arg0: string): $Thread$Builder;
        start(arg0: $Runnable_): $Thread;
        uncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): $Thread$Builder;
        unstarted(arg0: $Runnable_): $Thread;
    }

    export interface $Cloneable {
    }

    export type $Runnable_ = (() => void) | ($Runnable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "run": () => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $AutoCloseable_ = (() => void) | ($AutoCloseable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "close": () => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Comparable_<Host0 = any, CallbackArg0 = Host0, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Comparable<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "compareTo": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Readable_<CallbackArg0 = $CharBuffer, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Readable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "read": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Iterable_<T> = ($Iterable<T> | (T)[]);
    export type $Thread$State_ = $Thread$State | "BLOCKED" | "NEW" | "RUNNABLE" | "TERMINATED" | "TIMED_WAITING" | "WAITING";
    export type $Thread$UncaughtExceptionHandler_<CallbackArg0 = $Thread, CallbackArg1 = $Throwable> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($Thread$UncaughtExceptionHandler & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "uncaughtException": (arg0: CallbackArg0, arg1: CallbackArg1) => void } & { readonly [Symbol.hasInstance]?: never }>);
}
