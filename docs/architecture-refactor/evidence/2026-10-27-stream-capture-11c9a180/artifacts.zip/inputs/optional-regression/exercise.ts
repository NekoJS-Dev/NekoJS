import type {
    $ProbeCaptureReturnContractTest$Base as Base,
    $ProbeCaptureReturnContractTest$Child as Child,
    $ProbeCaptureReturnContractTest$Parent as Parent,
    $ProbeCaptureReturnContractTest$Implementation as Implementation,
    $ProbeCaptureReturnContractTest$RepeatedOverride as RepeatedOverride,
    $ProbeCaptureReturnContractTest$WildcardOverride as WildcardOverride,
    $ProbeCaptureReturnContractTest$ParameterParent as ParameterParent,
    $ProbeCaptureReturnContractTest$ParameterImplementation as ParameterImplementation,
    $ProbeCaptureReturnContractTest$InheritedImplementation as InheritedImplementation,
    $ProbeCaptureReturnContractTest$WildcardMiddle as WildcardMiddle,
    $ProbeCaptureReturnContractTest$WildcardMiddleImplementation as WildcardMiddleImplementation
} from 'java:com/tkisor/nekojs/probe';
declare const implementation: Implementation;
declare const input: Base;
const direct: Child = implementation.values().get();
const code: number = implementation.values().get().code;
const inheritedFallback: Base = implementation.values().orElse(input);
declare const repeated: RepeatedOverride;
declare const wildcard: WildcardOverride;
const repeatedFallback: Base = repeated.values().orElse(input);
const repeatedCode: number = repeated.values().get().code;
const wildcardFallback: Base = wildcard.values().orElse(input);
const wildcardCode: number = wildcard.values().get().code;
// @ts-expect-error A broader inherited fallback does not promise the narrow member.
implementation.values().orElse(input).code;
const parent: Parent<Base> = implementation;
declare const layered: WildcardMiddleImplementation;
const layeredMiddle: WildcardMiddle = layered;
const layeredParent: Parent<Base> = layered;
const layeredChild: Child = layered.values().get();
const layeredFallback: Base = layeredParent.values().orElse(input);
// @ts-expect-error An inherited upper-bound fallback does not retain the narrow payload.
layered.values().orElse(input).code;
const broad: Base = parent.values().get();
declare const parameterImplementation: ParameterImplementation;
const parameterParent: ParameterParent<Base> = parameterImplementation;
const parameterNarrow: Child = parameterImplementation.values(input).get();
const parameterBroad: Base = parameterParent.values(input).get();
const parameterFallback: Base = parameterImplementation.values(input).orElse(input);
declare const inherited: InheritedImplementation;
const inheritedParameterFallback: Base = inherited.values(input).orElse(input);
const inheritedParameterNarrow: Child = inherited.values(input).get();
declare const hostInputs: Base[];
const arrayNarrow: Child = parameterImplementation.values(hostInputs).get();
const arrayBroad: Base = parameterParent.values(hostInputs).get();
const overloaded: string = parameterImplementation.values(1).get();
// @ts-expect-error A parent-typed result cannot promise the implementation's narrow members.
parent.values().get().code;
// @ts-expect-error The narrow return remains the direct-call contract.
const wrong: string = implementation.values().get();
