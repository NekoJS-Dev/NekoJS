import { $Stream, $StreamView } from "java:java/util/stream";

declare module "java:com/tkisor/nekojs/probe" {
    export interface $ProbeStreamCaptureReturnTest$Parent<T> {
        getPassengersAndSelf(): $StreamView<T>;
        getSelfAndPassengers(): $StreamView<T>;
    }

    export interface $ProbeStreamCaptureReturnTest$NarrowParent extends $ProbeStreamCaptureReturnTest$Parent<$ProbeCaptureReturnContractTest$Base> {
        getPassengersAndSelf(): $StreamView<$ProbeCaptureReturnContractTest$Child> & $StreamView<$ProbeCaptureReturnContractTest$Base>;
        getSelfAndPassengers(): $StreamView<$ProbeCaptureReturnContractTest$Child> & $StreamView<$ProbeCaptureReturnContractTest$Base>;
    }

    export class $ProbeStreamCaptureReturnTest$Implementation implements $ProbeStreamCaptureReturnTest$NarrowParent {
        constructor();
        get passengersAndSelf(): $Stream<$ProbeCaptureReturnContractTest$Child> & $StreamView<$ProbeCaptureReturnContractTest$Base>;
        getPassengersAndSelf(): $Stream<$ProbeCaptureReturnContractTest$Child> & $StreamView<$ProbeCaptureReturnContractTest$Base>;
        get selfAndPassengers(): $Stream<$ProbeCaptureReturnContractTest$Child> & $StreamView<$ProbeCaptureReturnContractTest$Base>;
        getSelfAndPassengers(): $Stream<$ProbeCaptureReturnContractTest$Child> & $StreamView<$ProbeCaptureReturnContractTest$Base>;
    }

    export class $ProbeCaptureReturnContractTest$Base {
        constructor(label: string);
        label: string;
    }

    export class $ProbeCaptureReturnContractTest$Child extends $ProbeCaptureReturnContractTest$Base {
        constructor();
        code: number;
    }

}
