import { marker } from 'java:nekojs-test-orphan';
const value: string = marker;
