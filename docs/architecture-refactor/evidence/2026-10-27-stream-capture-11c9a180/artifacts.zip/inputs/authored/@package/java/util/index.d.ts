export * as stream from "java:java/util/stream";

