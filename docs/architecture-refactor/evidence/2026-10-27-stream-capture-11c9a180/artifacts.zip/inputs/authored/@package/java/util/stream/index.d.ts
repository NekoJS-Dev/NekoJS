declare module "java:java/util/stream" {
    export interface $Stream<T> { authored(): string; }

    export type $Stream_<T> = T[];
}
