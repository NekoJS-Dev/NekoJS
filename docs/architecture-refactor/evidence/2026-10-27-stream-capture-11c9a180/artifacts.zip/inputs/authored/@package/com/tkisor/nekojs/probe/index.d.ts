import { $Stream } from "java:java/util/stream";

declare module "java:com/tkisor/nekojs/probe" {
    export interface $ProbeStreamCaptureReturnTest$Parent<T> {
        getPassengersAndSelf(): $Stream<T>;
        getSelfAndPassengers(): $Stream<T>;
    }

    export interface $ProbeStreamCaptureReturnTest$NarrowParent extends $ProbeStreamCaptureReturnTest$Parent<$ProbeCaptureReturnContractTest$Base> {
        getPassengersAndSelf(): $Stream<$ProbeCaptureReturnContractTest$Child>;
        getSelfAndPassengers(): $Stream<$ProbeCaptureReturnContractTest$Child>;
    }

    export class $ProbeStreamCaptureReturnTest$Implementation implements $ProbeStreamCaptureReturnTest$NarrowParent {
        constructor();
        get passengersAndSelf(): $Stream<$ProbeCaptureReturnContractTest$Child>;
        getPassengersAndSelf(): $Stream<$ProbeCaptureReturnContractTest$Child>;
        get selfAndPassengers(): $Stream<$ProbeCaptureReturnContractTest$Child>;
        getSelfAndPassengers(): $Stream<$ProbeCaptureReturnContractTest$Child>;
    }

    export class $ProbeCaptureReturnContractTest$Base {
        constructor(label: string);
        label: string;
    }

    export class $ProbeCaptureReturnContractTest$Child extends $ProbeCaptureReturnContractTest$Base {
        constructor();
        code: number;
    }

}
