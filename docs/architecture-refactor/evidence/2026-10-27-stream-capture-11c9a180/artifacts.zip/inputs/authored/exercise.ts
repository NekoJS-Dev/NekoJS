import type {
  $ProbeStreamCaptureReturnTest$Parent as Parent,
  $ProbeStreamCaptureReturnTest$Implementation as Implementation,
  $ProbeCaptureReturnContractTest$Base as Base
} from 'java:com/tkisor/nekojs/probe';
declare const implementation: Implementation;
const parent: Parent<Base> = implementation;
const marker: string = parent.getSelfAndPassengers().authored();
// @ts-expect-error A replacement must not regain native Stream methods.
parent.getSelfAndPassengers().findFirst();
