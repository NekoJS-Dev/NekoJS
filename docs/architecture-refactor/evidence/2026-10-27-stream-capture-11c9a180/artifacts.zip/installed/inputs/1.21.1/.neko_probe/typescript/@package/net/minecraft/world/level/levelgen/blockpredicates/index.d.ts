import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List } from "java:java/util";
import { $BiPredicate, $BiPredicate_, $Function, $Function_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $HolderSet, $Vec3i } from "java:net/minecraft/core";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Fluid, $Fluid_ } from "java:net/minecraft/world/level/material";

declare module "java:net/minecraft/world/level/levelgen/blockpredicates" {
    export interface $BlockPredicate extends $BiPredicate<$WorldGenLevel, $BlockPos> {
        type(): $BlockPredicateType<any>;
    }
    export const $BlockPredicate: {
        allOf(arg0: ($List<$BlockPredicate> | ($BlockPredicate)[])): $BlockPredicate;
        allOf(arg0?: $BlockPredicate[]): $BlockPredicate;
        allOf(arg0: $BlockPredicate, arg1: $BlockPredicate): $BlockPredicate;
        alwaysTrue(): $BlockPredicate;
        anyOf(arg0: ($List<$BlockPredicate> | ($BlockPredicate)[])): $BlockPredicate;
        anyOf(arg0?: $BlockPredicate[]): $BlockPredicate;
        anyOf(arg0: $BlockPredicate, arg1: $BlockPredicate): $BlockPredicate;
        hasSturdyFace(arg0: $Direction_): $BlockPredicate;
        hasSturdyFace(arg0: $Vec3i, arg1: $Direction_): $BlockPredicate;
        insideWorld(arg0: $Vec3i): $BlockPredicate;
        matchesBlocks(arg0: ($List<$Block> | ($Block_)[])): $BlockPredicate;
        matchesBlocks(arg0: $Vec3i, arg1: ($List<$Block> | ($Block_)[])): $BlockPredicate;
        matchesBlocks(arg0: $Vec3i, arg1?: $Block_[]): $BlockPredicate;
        matchesBlocks(arg0?: $Block_[]): $BlockPredicate;
        matchesFluids(arg0: $Vec3i, arg1: ($List<$Fluid> | ($Fluid_)[])): $BlockPredicate;
        matchesFluids(arg0: $Vec3i, arg1?: $Fluid_[]): $BlockPredicate;
        matchesFluids(arg0?: $Fluid_[]): $BlockPredicate;
        matchesTag(arg0: $Vec3i, arg1: $TagKey_<$Block>): $BlockPredicate;
        matchesTag(arg0: $TagKey_<$Block>): $BlockPredicate;
        noFluid(arg0: $Vec3i): $BlockPredicate;
        noFluid(): $BlockPredicate;
        not(arg0: $BlockPredicate): $BlockPredicate;
        replaceable(arg0: $Vec3i): $BlockPredicate;
        replaceable(): $BlockPredicate;
        solid(arg0: $Vec3i): $BlockPredicate;
        solid(): $BlockPredicate;
        unobstructed(arg0: $Vec3i): $BlockPredicate;
        unobstructed(): $BlockPredicate;
        wouldSurvive(arg0: $BlockState_, arg1: $Vec3i): $BlockPredicate;
        readonly CODEC: $Codec<$BlockPredicate>;
        readonly ONLY_IN_AIR_OR_WATER_PREDICATE: $BlockPredicate;
        readonly ONLY_IN_AIR_PREDICATE: $BlockPredicate;
    };

    export interface $BlockPredicateType<P extends $BlockPredicate> {
        codec(): $MapCodec<P>;
    }
    export const $BlockPredicateType: {
        readonly ALL_OF: $BlockPredicateType<$AllOfPredicate>;
        readonly ANY_OF: $BlockPredicateType<$AnyOfPredicate>;
        readonly HAS_STURDY_FACE: $BlockPredicateType<$HasSturdyFacePredicate>;
        readonly INSIDE_WORLD_BOUNDS: $BlockPredicateType<$InsideWorldBoundsPredicate>;
        readonly MATCHING_BLOCKS: $BlockPredicateType<$MatchingBlocksPredicate>;
        readonly MATCHING_BLOCK_TAG: $BlockPredicateType<$MatchingBlockTagPredicate>;
        readonly MATCHING_FLUIDS: $BlockPredicateType<$MatchingFluidsPredicate>;
        readonly NOT: $BlockPredicateType<$NotPredicate>;
        readonly REPLACEABLE: $BlockPredicateType<$ReplaceablePredicate>;
        readonly SOLID: $BlockPredicateType<$SolidPredicate>;
        readonly TRUE: $BlockPredicateType<$TrueBlockPredicate>;
        readonly UNOBSTRUCTED: $BlockPredicateType<$UnobstructedPredicate>;
        readonly WOULD_SURVIVE: $BlockPredicateType<$WouldSurvivePredicate>;
    };

    export class $AllOfPredicate extends $CombiningPredicate {
        constructor(arg0: ($List<$BlockPredicate> | ($BlockPredicate)[]));
        static CODEC: $MapCodec<$AllOfPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export class $AnyOfPredicate extends $CombiningPredicate {
        constructor(arg0: ($List<$BlockPredicate> | ($BlockPredicate)[]));
        static CODEC: $MapCodec<$AnyOfPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export class $HasSturdyFacePredicate implements $BlockPredicate {
        constructor(arg0: $Vec3i, arg1: $Direction_);
        static CODEC: $MapCodec<$HasSturdyFacePredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export class $InsideWorldBoundsPredicate implements $BlockPredicate {
        constructor(arg0: $Vec3i);
        static CODEC: $MapCodec<$InsideWorldBoundsPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export class $MatchingBlockTagPredicate extends $StateTestingPredicate {
        static CODEC: $MapCodec<$MatchingBlockTagPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        type(): $BlockPredicateType<any>;
    }

    export class $MatchingBlocksPredicate extends $StateTestingPredicate {
        constructor(arg0: $Vec3i, arg1: $HolderSet<$Block>);
        static CODEC: $MapCodec<$MatchingBlocksPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        type(): $BlockPredicateType<any>;
    }

    export class $MatchingFluidsPredicate extends $StateTestingPredicate {
        constructor(arg0: $Vec3i, arg1: $HolderSet<$Fluid>);
        static CODEC: $MapCodec<$MatchingFluidsPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        type(): $BlockPredicateType<any>;
    }

    export class $NotPredicate implements $BlockPredicate {
        constructor(arg0: $BlockPredicate);
        static CODEC: $MapCodec<$NotPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export class $ReplaceablePredicate extends $StateTestingPredicate {
        constructor(arg0: $Vec3i);
        static CODEC: $MapCodec<$ReplaceablePredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        type(): $BlockPredicateType<any>;
    }

    export class $SolidPredicate extends $StateTestingPredicate {
        constructor(arg0: $Vec3i);
        static CODEC: $MapCodec<$SolidPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        type(): $BlockPredicateType<any>;
    }

    export class $TrueBlockPredicate implements $BlockPredicate {
        static CODEC: $MapCodec<$TrueBlockPredicate>;
        static INSTANCE: $TrueBlockPredicate;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export class $UnobstructedPredicate extends $Record implements $BlockPredicate {
        static CODEC: $MapCodec<$UnobstructedPredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        offset(): $Vec3i;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        toString(): string;
        type(): $BlockPredicateType<any>;
    }

    export class $WouldSurvivePredicate implements $BlockPredicate {
        static CODEC: $MapCodec<$WouldSurvivePredicate>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export class $CombiningPredicate implements $BlockPredicate {
        static codec<T extends $CombiningPredicate>(arg0: $Function_<$List<$BlockPredicate>, T, $List<$BlockPredicate>, T>): $MapCodec<T>;
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export class $StateTestingPredicate implements $BlockPredicate {
        and(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        negate(): $BiPredicate<$WorldGenLevel, $BlockPos>;
        or(arg0: $BiPredicate_<$WorldGenLevel, $BlockPos, $WorldGenLevel, $BlockPos, boolean>): $BiPredicate<$WorldGenLevel, $BlockPos>;
        test(arg0: unknown, arg1: unknown): boolean;
        test(arg0: $WorldGenLevel, arg1: $BlockPos_): boolean;
        type(): $BlockPredicateType<any>;
    }

    export type $BlockPredicateType_<Host0 extends $BlockPredicate = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($BlockPredicateType<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "codec": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
