import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $RecordCodecBuilder, $RecordCodecBuilder$Instance } from "java:com/mojang/serialization/codecs";
import { $Enum, $Record } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $Function, $Function_ } from "java:java/util/function";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $WeightedRandomList } from "java:net/minecraft/util/random";
import { $ChunkPos, $StructureManager, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $MobSpawnSettings$SpawnerData } from "java:net/minecraft/world/level/biome";
import { $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $Heightmap$Types, $Heightmap$Types_ } from "java:net/minecraft/world/level/levelgen";
import { $HeightProvider } from "java:net/minecraft/world/level/levelgen/heightproviders";
import { $BoundingBox, $SinglePieceStructure, $Structure, $Structure$GenerationContext, $Structure$GenerationStub, $Structure$StructureSettings, $StructureType, $StructureType_ } from "java:net/minecraft/world/level/levelgen/structure";
import { $PiecesContainer } from "java:net/minecraft/world/level/levelgen/structure/pieces";
import { $DimensionPadding, $StructureTemplatePool } from "java:net/minecraft/world/level/levelgen/structure/pools";
import { $PoolAliasBinding } from "java:net/minecraft/world/level/levelgen/structure/pools/alias";
import { $LiquidSettings, $LiquidSettings_ } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";

declare module "java:net/minecraft/world/level/levelgen/structure/structures" {
    export class $BuriedTreasureStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$BuriedTreasureStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $BuriedTreasureStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $DesertPyramidStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$DesertPyramidStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $DesertPyramidStructure extends $SinglePieceStructure {
        afterPlace(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BoundingBox, arg5: $ChunkPos, arg6: $PiecesContainer): void;
        type(): $StructureType<any>;
    }

    export class $EndCityStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$EndCityStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $EndCityStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $IglooStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$IglooStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $IglooStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $JigsawStructure {
        constructor(arg0: $Structure$StructureSettings, arg1: $Holder_<$StructureTemplatePool>, arg2: number, arg3: $HeightProvider, arg4: boolean);
        constructor(arg0: $Structure$StructureSettings, arg1: $Holder_<$StructureTemplatePool>, arg2: number, arg3: $HeightProvider, arg4: boolean, arg5: $Heightmap$Types_);
        constructor(arg0: $Structure$StructureSettings, arg1: $Holder_<$StructureTemplatePool>, arg2: $Optional<$ResourceLocation>, arg3: number, arg4: $HeightProvider, arg5: boolean, arg6: $Optional<$Heightmap$Types>, arg7: number, arg8: ($List<$PoolAliasBinding> | ($PoolAliasBinding)[]), arg9: $DimensionPadding, arg10: $LiquidSettings_);
        static CODEC: $MapCodec<$JigsawStructure>;
        static DEFAULT_DIMENSION_PADDING: $DimensionPadding;
        static DEFAULT_LIQUID_SETTINGS: $LiquidSettings;
        static MAX_DEPTH: number;
        static MAX_TOTAL_STRUCTURE_RANGE: number;
        static MIN_DEPTH: number;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $JigsawStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $JungleTempleStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$JungleTempleStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $JungleTempleStructure extends $SinglePieceStructure {
        type(): $StructureType<any>;
    }

    export class $MineshaftStructure {
        constructor(arg0: $Structure$StructureSettings, arg1: $MineshaftStructure$Type_);
        static CODEC: $MapCodec<$MineshaftStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $MineshaftStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $MineshaftStructure$Type {
        static MESA: $MineshaftStructure$Type;
        static NORMAL: $MineshaftStructure$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MineshaftStructure$Type[];
        static valueOf(name: string): $MineshaftStructure$Type;
    }
    export interface $MineshaftStructure$Type extends $Enum<$MineshaftStructure$Type>, $StringRepresentable {}

    export class $NetherFortressStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$NetherFortressStructure>;
        static FORTRESS_ENEMIES: $WeightedRandomList<$MobSpawnSettings$SpawnerData>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $NetherFortressStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $NetherFossilStructure {
        constructor(arg0: $Structure$StructureSettings, arg1: $HeightProvider);
        static CODEC: $MapCodec<$NetherFossilStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $NetherFossilStructure extends $Structure {
        height: $HeightProvider;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $OceanMonumentStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$OceanMonumentStructure>;
        static regeneratePiecesAfterLoad(arg0: $ChunkPos, arg1: number, arg2: $PiecesContainer): $PiecesContainer;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $OceanMonumentStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $OceanRuinStructure {
        constructor(arg0: $Structure$StructureSettings, arg1: $OceanRuinStructure$Type_, arg2: number, arg3: number);
        static CODEC: $MapCodec<$OceanRuinStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $OceanRuinStructure extends $Structure {
        biomeTemp: $OceanRuinStructure$Type;
        clusterProbability: number;
        largeProbability: number;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $OceanRuinStructure$Type {
        static COLD: $OceanRuinStructure$Type;
        static WARM: $OceanRuinStructure$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $OceanRuinStructure$Type[];
        static valueOf(name: string): $OceanRuinStructure$Type;
    }
    export interface $OceanRuinStructure$Type extends $Enum<$OceanRuinStructure$Type>, $StringRepresentable {}

    export class $RuinedPortalStructure {
        constructor(arg0: $Structure$StructureSettings, arg1: ($List<$RuinedPortalStructure$Setup> | ($RuinedPortalStructure$Setup)[]));
        constructor(arg0: $Structure$StructureSettings, arg1: $RuinedPortalStructure$Setup);
        static CODEC: $MapCodec<$RuinedPortalStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $RuinedPortalStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $RuinedPortalStructure$Setup extends $Record {
        constructor(arg0: $RuinedPortalPiece$VerticalPlacement_, arg1: number, arg2: number, arg3: boolean, arg4: boolean, arg5: boolean, arg6: boolean, arg7: number);
        static CODEC: $Codec<$RuinedPortalStructure$Setup>;
        airPocketProbability(): number;
        canBeCold(): boolean;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        mossiness(): number;
        overgrown(): boolean;
        placement(): $RuinedPortalPiece$VerticalPlacement;
        replaceWithBlackstone(): boolean;
        toString(): string;
        vines(): boolean;
        weight(): number;
    }

    export class $ShipwreckStructure {
        constructor(arg0: $Structure$StructureSettings, arg1: boolean);
        static CODEC: $MapCodec<$ShipwreckStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $ShipwreckStructure extends $Structure {
        isBeached: boolean;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $StrongholdStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$StrongholdStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $StrongholdStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $SwampHutStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$SwampHutStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $SwampHutStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $WoodlandMansionStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$WoodlandMansionStructure>;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
    }
    export interface $WoodlandMansionStructure extends $Structure {
        afterPlace(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BoundingBox, arg5: $ChunkPos, arg6: $PiecesContainer): void;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $RuinedPortalPiece$VerticalPlacement {
        static IN_MOUNTAIN: $RuinedPortalPiece$VerticalPlacement;
        static IN_NETHER: $RuinedPortalPiece$VerticalPlacement;
        static ON_LAND_SURFACE: $RuinedPortalPiece$VerticalPlacement;
        static ON_OCEAN_FLOOR: $RuinedPortalPiece$VerticalPlacement;
        static PARTLY_BURIED: $RuinedPortalPiece$VerticalPlacement;
        static UNDERGROUND: $RuinedPortalPiece$VerticalPlacement;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RuinedPortalPiece$VerticalPlacement[];
        static valueOf(name: string): $RuinedPortalPiece$VerticalPlacement;
    }
    export interface $RuinedPortalPiece$VerticalPlacement extends $Enum<$RuinedPortalPiece$VerticalPlacement>, $StringRepresentable {}

    export type $MineshaftStructure$Type_ = $MineshaftStructure$Type | "MESA" | "NORMAL";
    export type $OceanRuinStructure$Type_ = $OceanRuinStructure$Type | "COLD" | "WARM";
    export type $RuinedPortalPiece$VerticalPlacement_ = $RuinedPortalPiece$VerticalPlacement | "IN_MOUNTAIN" | "IN_NETHER" | "ON_LAND_SURFACE" | "ON_OCEAN_FLOOR" | "PARTLY_BURIED" | "UNDERGROUND";
}
