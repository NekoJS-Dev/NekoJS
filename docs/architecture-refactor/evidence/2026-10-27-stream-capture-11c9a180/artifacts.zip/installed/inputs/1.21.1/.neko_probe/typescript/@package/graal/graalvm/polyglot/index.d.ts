import { $WordPointer } from "java:graal/graalvm/nativeimage/c/type";
import { $OptionDescriptors } from "java:graal/graalvm/options";
import { $ByteSequence, $FileSystem, $IOAccess, $IOAccess$Builder, $MessageEndpoint, $MessageTransport, $MessageTransport_, $ProcessHandler, $ProcessHandler$ProcessCommand, $ProcessHandler_ } from "java:graal/graalvm/polyglot/io";
import { $Proxy } from "java:graal/graalvm/polyglot/proxy";
import { $TypeMappingProvider, $TypeMappingProvider$MappingRegistry, $TypeMappingProvider$MappingRegistry_, $TypeMappingProviderRegistry, $TypeMappingProvider_ } from "java:graal/mod/api";
import { $File, $InputStream, $OutputStream, $Reader } from "java:java/io";
import { $AutoCloseable, $AutoCloseable_, $CharSequence, $Class, $ClassLoader, $Enum, $Process, $RuntimeException } from "java:java/lang";
import { $Annotation, $Annotation_ } from "java:java/lang/annotation";
import { $MethodHandles$Lookup } from "java:java/lang/invoke";
import { $Executable, $Field, $Type } from "java:java/lang/reflect";
import { $URI, $URL } from "java:java/net";
import { $ByteBuffer, $ByteOrder } from "java:java/nio";
import { $Charset } from "java:java/nio/charset";
import { $Path } from "java:java/nio/file";
import { $Duration, $Instant, $LocalDate, $LocalTime, $ZoneId } from "java:java/time";
import { $List, $Map, $Set } from "java:java/util";
import { $Consumer, $Consumer_, $Function, $Function_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $Handler } from "java:java/util/logging";

export * as proxy from "java:graal/graalvm/polyglot/proxy";
export * as io from "java:graal/graalvm/polyglot/io";

declare module "java:graal/graalvm/polyglot" {
    export class $Value extends $AbstractValue {
        get arraySize(): number;
        getArraySize(): number;
        get bufferSize(): number;
        getBufferSize(): number;
        get context(): $Context;
        getContext(): $Context;
        get hashEntriesIterator(): $Value;
        getHashEntriesIterator(): $Value;
        get hashKeysIterator(): $Value;
        getHashKeysIterator(): $Value;
        get hashSize(): number;
        getHashSize(): number;
        get hashValuesIterator(): $Value;
        getHashValuesIterator(): $Value;
        get iteratorNextElement(): $Value;
        getIteratorNextElement(): $Value;
        get iterator(): $Value;
        getIterator(): $Value;
        get memberKeys(): $Set<string>;
        getMemberKeys(): $Set<string>;
        get metaObject(): $Value;
        getMetaObject(): $Value;
        get metaParents(): $Value;
        getMetaParents(): $Value;
        get metaQualifiedName(): string;
        getMetaQualifiedName(): string;
        get metaSimpleName(): string;
        getMetaSimpleName(): string;
        get sourceLocation(): $SourceSection;
        getSourceLocation(): $SourceSection;
        get staticScope(): $Value;
        getStaticScope(): $Value;
        get boolean(): boolean;
        isBoolean(): boolean;
        get bufferWritable(): boolean;
        isBufferWritable(): boolean;
        get date(): boolean;
        isDate(): boolean;
        get duration(): boolean;
        isDuration(): boolean;
        get exception(): boolean;
        isException(): boolean;
        get hostObject(): boolean;
        isHostObject(): boolean;
        get instant(): boolean;
        isInstant(): boolean;
        get nativePointer(): boolean;
        isNativePointer(): boolean;
        get null(): boolean;
        isNull(): boolean;
        get number(): boolean;
        isNumber(): boolean;
        get proxyObject(): boolean;
        isProxyObject(): boolean;
        get string(): boolean;
        isString(): boolean;
        get timeZone(): boolean;
        isTimeZone(): boolean;
        get time(): boolean;
        isTime(): boolean;
        static asValue(o: unknown): $Value;
        static fromByteBasedString(bytes: number[], encoding: $Value$StringEncoding): $Value;
        static fromByteBasedString(bytes: number[], offset: number, length: number, encoding: $Value$StringEncoding, copy: boolean): $Value;
        static fromNativeString(basePointer: number, byteLength: number, encoding: $Value$StringEncoding): $Value;
        static fromNativeString(basePointer: number, byteOffset: number, byteLength: number, encoding: $Value$StringEncoding, copy: boolean): $Value;
        asBigInteger(): number;
        asBoolean(): boolean;
        asByte(): number;
        asDate(): $LocalDate;
        asDouble(): number;
        asDuration(): $Duration;
        asFloat(): number;
        asHostObject<T>(): T;
        asInstant(): $Instant;
        asInt(): number;
        asLong(): number;
        asNativePointer(): number;
        asProxyObject<T extends $Proxy>(): T;
        asShort(): number;
        asStringBytes(encoding: $Value$StringEncoding): number[];
        asString(): string;
        asTimeZone(): $ZoneId;
        asTime(): $LocalTime;
        as<T>(targetType: $TypeLiteral<T>): T;
        as<T>(targetType: $Class<T>): T;
        canExecute(): boolean;
        canInstantiate(): boolean;
        canInvokeMember(identifier: string): boolean;
        equals(obj: unknown): boolean;
        executeVoid(arguments_?: unknown[]): void;
        execute(arguments_?: unknown[]): $Value;
        fitsInBigInteger(): boolean;
        fitsInByte(): boolean;
        fitsInDouble(): boolean;
        fitsInFloat(): boolean;
        fitsInInt(): boolean;
        fitsInLong(): boolean;
        fitsInShort(): boolean;
        getArrayElement(index: number): $Value;
        getHashValueOrDefault(key: unknown, defaultValue: unknown): $Value;
        getHashValue(key: unknown): $Value;
        getMember(identifier: string): $Value;
        hasArrayElements(): boolean;
        hasBufferElements(): boolean;
        hasHashEntries(): boolean;
        hasHashEntry(key: unknown): boolean;
        hasIteratorNextElement(): boolean;
        hasIterator(): boolean;
        hasMembers(): boolean;
        hasMember(identifier: string): boolean;
        hasMetaParents(): boolean;
        hasStaticScope(): boolean;
        hashCode(): number;
        invokeMember(identifier: string, arguments_?: unknown[]): $Value;
        isIterator(): boolean;
        isMetaInstance(instance: unknown): boolean;
        isMetaObject(): boolean;
        newInstance(arguments_?: unknown[]): $Value;
        pin(): void;
        putHashEntry(key: unknown, value: unknown): void;
        putMember(identifier: string, value: unknown): void;
        readBufferByte(byteOffset: number): number;
        readBufferDouble(order: $ByteOrder, byteOffset: number): number;
        readBufferFloat(order: $ByteOrder, byteOffset: number): number;
        readBufferInt(order: $ByteOrder, byteOffset: number): number;
        readBufferLong(order: $ByteOrder, byteOffset: number): number;
        readBufferShort(order: $ByteOrder, byteOffset: number): number;
        readBuffer(byteOffset: number, destination: number[], destinationOffset: number, length: number): void;
        removeArrayElement(index: number): boolean;
        removeHashEntry(key: unknown): boolean;
        removeMember(identifier: string): boolean;
        setArrayElement(index: number, value: unknown): void;
        throwException(): $RuntimeException;
        toString(): string;
        writeBufferByte(byteOffset: number, value: number): void;
        writeBufferDouble(order: $ByteOrder, byteOffset: number, value: number): void;
        writeBufferFloat(order: $ByteOrder, byteOffset: number, value: number): void;
        writeBufferInt(order: $ByteOrder, byteOffset: number, value: number): void;
        writeBufferLong(order: $ByteOrder, byteOffset: number, value: number): void;
        writeBufferShort(order: $ByteOrder, byteOffset: number, value: number): void;
    }

    export class $AbstractValue {
        equals(obj: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $Context implements $AutoCloseable {
        get engine(): $Engine;
        getEngine(): $Engine;
        get polyglotBindings(): $Value;
        getPolyglotBindings(): $Value;
        static create(permittedLanguages?: string[]): $Context;
        static getCurrent(): $Context;
        static newBuilder(permittedLanguages?: string[]): $Context$Builder;
        asValue(hostValue: unknown): $Value;
        close(cancelIfExecuting: boolean): void;
        close(): void;
        enter(): void;
        equals(obj: unknown): boolean;
        eval(source: $Source): $Value;
        eval(languageId: string, source: $CharSequence): $Value;
        getBindings(languageId: string): $Value;
        hashCode(): number;
        initialize(languageId: string): boolean;
        interrupt(timeout: $Duration): void;
        leave(): void;
        parse(source: $Source): $Value;
        parse(languageId: string, source: $CharSequence): $Value;
        resetLimits(): void;
        safepoint(): void;
    }

    export class $SourceSection {
        get charEndIndex(): number;
        getCharEndIndex(): number;
        get charIndex(): number;
        getCharIndex(): number;
        get charLength(): number;
        getCharLength(): number;
        get characters(): $CharSequence;
        getCharacters(): $CharSequence;
        get code(): $CharSequence;
        getCode(): $CharSequence;
        get endColumn(): number;
        getEndColumn(): number;
        get endLine(): number;
        getEndLine(): number;
        get source(): $Source;
        getSource(): $Source;
        get startColumn(): number;
        getStartColumn(): number;
        get startLine(): number;
        getStartLine(): number;
        get available(): boolean;
        isAvailable(): boolean;
        equals(obj: unknown): boolean;
        hasCharIndex(): boolean;
        hasColumns(): boolean;
        hasLines(): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $TypeLiteral<T> {
        get rawType(): $Class<T>;
        getRawType(): $Class<T>;
        get type(): $Type;
        getType(): $Type;
        equals(obj: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $Value$StringEncoding {
        static UTF_16: $Value$StringEncoding;
        static UTF_16_BIG_ENDIAN: $Value$StringEncoding;
        static UTF_16_LITTLE_ENDIAN: $Value$StringEncoding;
        static UTF_32: $Value$StringEncoding;
        static UTF_32_BIG_ENDIAN: $Value$StringEncoding;
        static UTF_32_LITTLE_ENDIAN: $Value$StringEncoding;
        static UTF_8: $Value$StringEncoding;
    }

    export class $Context$Builder {
        allowAllAccess(enabled: boolean): $Context$Builder;
        allowCreateProcess(enabled: boolean): $Context$Builder;
        allowCreateThread(enabled: boolean): $Context$Builder;
        allowEnvironmentAccess(accessPolicy: $EnvironmentAccess): $Context$Builder;
        allowExperimentalOptions(enabled: boolean): $Context$Builder;
        allowHostAccess(enabled: boolean): $Context$Builder;
        allowHostAccess(config: $HostAccess): $Context$Builder;
        allowHostClassLoading(enabled: boolean): $Context$Builder;
        allowHostClassLookup(classFilter: $Predicate_<string, string, boolean>): $Context$Builder;
        allowIO(enabled: boolean): $Context$Builder;
        allowIO(ioAccess: $IOAccess): $Context$Builder;
        allowInnerContextOptions(enabled: boolean): $Context$Builder;
        allowNativeAccess(enabled: boolean): $Context$Builder;
        allowPolyglotAccess(accessPolicy: $PolyglotAccess): $Context$Builder;
        allowValueSharing(enabled: boolean): $Context$Builder;
        apply(action: $Consumer_<$Context$Builder, $Context$Builder>): $Context$Builder;
        arguments(language: string, args: string[]): $Context$Builder;
        build(): $Context;
        currentWorkingDirectory(workingDirectory: $Path): $Context$Builder;
        engine(engine: $Engine): $Context$Builder;
        environment(name: string, value: string): $Context$Builder;
        environment(env: ($Map<string, string> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, string>>))): $Context$Builder;
        err(err: $OutputStream): $Context$Builder;
        exceptionHandler(handler: $Consumer_<any, any>): $Context$Builder;
        extendHostAccess(defaultInitialValue: $HostAccess, setup: $Consumer_<$HostAccess$Builder, $HostAccess$Builder>): $Context$Builder;
        extendIO(defaultInitialValue: $IOAccess, setup: $Consumer_<$IOAccess$Builder, $IOAccess$Builder>): $Context$Builder;
        fileSystem(fileSystem: $FileSystem): $Context$Builder;
        hostClassFilter(classFilter: $Predicate_<string, string, boolean>): $Context$Builder;
        hostClassLoader(classLoader: $ClassLoader): $Context$Builder;
        in(in_: $InputStream): $Context$Builder;
        logHandler(logOut: $OutputStream): $Context$Builder;
        logHandler(logHandler: $Handler): $Context$Builder;
        options(options: ($Map<string, string> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, string>>))): $Context$Builder;
        option(key: string, value: string): $Context$Builder;
        out(out: $OutputStream): $Context$Builder;
        processHandler(handler: $ProcessHandler_<$ProcessHandler$ProcessCommand, $Process>): $Context$Builder;
        resourceLimits(limits: $ResourceLimits): $Context$Builder;
        sandbox(policy: $SandboxPolicy_): $Context$Builder;
        serverTransport(serverTransport: $MessageTransport_<$URI, $MessageEndpoint, $MessageEndpoint>): $Context$Builder;
        spawnIsolate(value: boolean): $Context$Builder;
        timeZone(zone: $ZoneId): $Context$Builder;
        useSystemExit(enabled: boolean): $Context$Builder;
    }

    export class $Engine implements $AutoCloseable {
        get cachedSources(): $Set<$Source>;
        getCachedSources(): $Set<$Source>;
        get implementationName(): string;
        getImplementationName(): string;
        get instruments(): $Map<string, $Instrument>;
        getInstruments(): $Map<string, $Instrument>;
        get languages(): $Map<string, $Language>;
        getLanguages(): $Map<string, $Language>;
        get options(): $OptionDescriptors;
        getOptions(): $OptionDescriptors;
        get version(): string;
        getVersion(): string;
        static copyResources(targetFolder: $Path, components?: string[]): boolean;
        static create(permittedLanguages?: string[]): $Engine;
        static create(): $Engine;
        static findHome(): $Path;
        static newBuilder(permittedLanguages?: string[]): $Engine$Builder;
        static newBuilder(): $Engine$Builder;
        static supportsCompilation(): boolean;
        close(cancelIfExecuting: boolean): void;
        close(): void;
        persistCache(callback: $Engine$CancellationCallback_<boolean>): $ByteBuffer;
        storeCache(targetFile: $Path, cancelledWord: $WordPointer): boolean;
        storeCache(targetFile: $Path): boolean;
    }

    export class $Source {
        get bytes(): $ByteSequence;
        getBytes(): $ByteSequence;
        get characters(): $CharSequence;
        getCharacters(): $CharSequence;
        get inputStream(): $InputStream;
        getInputStream(): $InputStream;
        get language(): string;
        getLanguage(): string;
        get length(): number;
        getLength(): number;
        get lineCount(): number;
        getLineCount(): number;
        get mimeType(): string;
        getMimeType(): string;
        get name(): string;
        getName(): string;
        get path(): string;
        getPath(): string;
        get reader(): $Reader;
        getReader(): $Reader;
        get uRI(): $URI;
        getURI(): $URI;
        get uRL(): $URL;
        getURL(): $URL;
        get interactive(): boolean;
        isInteractive(): boolean;
        get internal(): boolean;
        isInternal(): boolean;
        static create(language: string, source: $CharSequence): $Source;
        static findLanguage(file: $File): string;
        static findLanguage(mimeType: string): string;
        static findLanguage(url: $URL): string;
        static findMimeType(file: $File): string;
        static findMimeType(url: $URL): string;
        static newBuilder(language: string, bytes: $ByteSequence, name: string): $Source$Builder;
        static newBuilder(language: string, file: $File): $Source$Builder;
        static newBuilder(language: string, source: $Reader, name: string): $Source$Builder;
        static newBuilder(language: string, characters: $CharSequence, name: string): $Source$Builder;
        static newBuilder(language: string, url: $URL): $Source$Builder;
        equals(obj: unknown): boolean;
        getCharacters(lineNumber: number): $CharSequence;
        getColumnNumber(offset: number): number;
        getLineLength(lineNumber: number): number;
        getLineNumber(offset: number): number;
        getLineStartOffset(lineNumber: number): number;
        hasBytes(): boolean;
        hasCharacters(): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $EnvironmentAccess {
        static INHERIT: $EnvironmentAccess;
        static NONE: $EnvironmentAccess;
        toString(): string;
    }

    export class $HostAccess implements $TypeMappingProviderRegistry {
        static ALL: $HostAccess;
        static CONSTRAINED: $HostAccess;
        static EXPLICIT: $HostAccess;
        static ISOLATED: $HostAccess;
        static NONE: $HostAccess;
        static SCOPED: $HostAccess;
        static UNTRUSTED: $HostAccess;
        static newBuilder(conf: $HostAccess): $HostAccess$Builder;
        static newBuilder(): $HostAccess$Builder;
        equals(obj: unknown): boolean;
        graal$addProvider(provider: $TypeMappingProvider_<$Class<any>, $TypeMappingProvider$MappingRegistry<any>>): void;
        graal$viewProviders(): $List<$TypeMappingProvider>;
        hashCode(): number;
        toString(): string;
    }

    export class $PolyglotAccess {
        static ALL: $PolyglotAccess;
        static NONE: $PolyglotAccess;
        static newBuilder(): $PolyglotAccess$Builder;
    }

    export class $ResourceLimits {
        static newBuilder(): $ResourceLimits$Builder;
    }

    export class $SandboxPolicy {
        static CONSTRAINED: $SandboxPolicy;
        static ISOLATED: $SandboxPolicy;
        static TRUSTED: $SandboxPolicy;
        static UNTRUSTED: $SandboxPolicy;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SandboxPolicy[];
        static valueOf(name: string): $SandboxPolicy;
    }
    export interface $SandboxPolicy extends $Enum<$SandboxPolicy> {}

    export class $Engine$Builder {
        allowExperimentalOptions(enabled: boolean): $Engine$Builder;
        build(): $Engine;
        err(err: $OutputStream): $Engine$Builder;
        exceptionHandler(handler: $Consumer_<any, any>): $Engine$Builder;
        in(in_: $InputStream): $Engine$Builder;
        logHandler(logOut: $OutputStream): $Engine$Builder;
        logHandler(logHandler: $Handler): $Engine$Builder;
        options(options: ($Map<string, string> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, string>>))): $Engine$Builder;
        option(key: string, value: string): $Engine$Builder;
        out(out: $OutputStream): $Engine$Builder;
        sandbox(policy: $SandboxPolicy_): $Engine$Builder;
        serverTransport(serverTransport: $MessageTransport_<$URI, $MessageEndpoint, $MessageEndpoint>): $Engine$Builder;
        spawnIsolate(value: boolean): $Engine$Builder;
        useSystemProperties(enabled: boolean): $Engine$Builder;
    }

    export interface $Engine$CancellationCallback {
        shouldCancel(): boolean;
    }

    export class $Instrument {
        get id(): string;
        getId(): string;
        get name(): string;
        getName(): string;
        get options(): $OptionDescriptors;
        getOptions(): $OptionDescriptors;
        get sourceOptions(): $OptionDescriptors;
        getSourceOptions(): $OptionDescriptors;
        get version(): string;
        getVersion(): string;
        get website(): string;
        getWebsite(): string;
        equals(obj: unknown): boolean;
        hashCode(): number;
        lookup<T>(type: $Class<T>): T;
    }

    export class $Language {
        get defaultMimeType(): string;
        getDefaultMimeType(): string;
        get id(): string;
        getId(): string;
        get implementationName(): string;
        getImplementationName(): string;
        get mimeTypes(): $Set<string>;
        getMimeTypes(): $Set<string>;
        get name(): string;
        getName(): string;
        get options(): $OptionDescriptors;
        getOptions(): $OptionDescriptors;
        get sourceOptions(): $OptionDescriptors;
        getSourceOptions(): $OptionDescriptors;
        get version(): string;
        getVersion(): string;
        get website(): string;
        getWebsite(): string;
        get interactive(): boolean;
        isInteractive(): boolean;
        equals(obj: unknown): boolean;
        hashCode(): number;
    }

    export class $HostAccess$Builder implements $TypeMappingProviderRegistry {
        allowAccessAnnotatedBy(annotation: $Class<$Annotation>): $HostAccess$Builder;
        allowAccessInheritance(inheritAccess: boolean): $HostAccess$Builder;
        allowAccess(element: $Executable): $HostAccess$Builder;
        allowAccess(element: $Field): $HostAccess$Builder;
        allowAllClassImplementations(allow: boolean): $HostAccess$Builder;
        allowAllImplementations(allow: boolean): $HostAccess$Builder;
        allowArrayAccess(arrayAccess: boolean): $HostAccess$Builder;
        allowBigIntegerNumberAccess(bigIntegerNumberAccess: boolean): $HostAccess$Builder;
        allowBufferAccess(bufferAccess: boolean): $HostAccess$Builder;
        allowImplementationsAnnotatedBy(annotation: $Class<$Annotation>): $HostAccess$Builder;
        allowImplementations(type: $Class<any>): $HostAccess$Builder;
        allowIterableAccess(iterableAccess: boolean): $HostAccess$Builder;
        allowIteratorAccess(iteratorAccess: boolean): $HostAccess$Builder;
        allowListAccess(listAccess: boolean): $HostAccess$Builder;
        allowMapAccess(mapAccess: boolean): $HostAccess$Builder;
        allowMutableTargetMappings(mapping?: $HostAccess$MutableTargetMapping_[]): $HostAccess$Builder;
        allowPublicAccess(allow: boolean): $HostAccess$Builder;
        build(): $HostAccess;
        denyAccess(clazz: $Class<any>, includeSubclasses: boolean): $HostAccess$Builder;
        denyAccess(clazz: $Class<any>): $HostAccess$Builder;
        disableMethodScopingAnnotatedBy(annotation: $Class<$Annotation>): $HostAccess$Builder;
        disableMethodScoping(e: $Executable): $HostAccess$Builder;
        graal$addProvider(provider: $TypeMappingProvider_<$Class<any>, $TypeMappingProvider$MappingRegistry<any>>): void;
        graal$viewProviders(): $List<$TypeMappingProvider>;
        methodScoping(scopingDefault: boolean): $HostAccess$Builder;
        targetTypeMapping<S, T>(sourceType: $Class<S>, targetType: $Class<T>, accepts: $Predicate_<S, S, boolean>, converter: $Function_<S, T, S, T>, precedence: $HostAccess$TargetMappingPrecedence_): $HostAccess$Builder;
        targetTypeMapping<S, T>(sourceType: $Class<S>, targetType: $Class<T>, accepts: $Predicate_<S, S, boolean>, converter: $Function_<S, T, S, T>): $HostAccess$Builder;
        useModuleLookup(lookup: $MethodHandles$Lookup): $HostAccess$Builder;
    }

    export class $HostAccess$MutableTargetMapping {
        static ARRAY_TO_JAVA_LIST: $HostAccess$MutableTargetMapping;
        static EXECUTABLE_TO_JAVA_INTERFACE: $HostAccess$MutableTargetMapping;
        static HASH_TO_JAVA_MAP: $HostAccess$MutableTargetMapping;
        static ITERABLE_TO_JAVA_ITERABLE: $HostAccess$MutableTargetMapping;
        static ITERATOR_TO_JAVA_ITERATOR: $HostAccess$MutableTargetMapping;
        static MEMBERS_TO_JAVA_INTERFACE: $HostAccess$MutableTargetMapping;
        static MEMBERS_TO_JAVA_MAP: $HostAccess$MutableTargetMapping;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $HostAccess$MutableTargetMapping[];
        static valueOf(name: string): $HostAccess$MutableTargetMapping;
    }
    export interface $HostAccess$MutableTargetMapping extends $Enum<$HostAccess$MutableTargetMapping> {}

    export class $HostAccess$TargetMappingPrecedence {
        static HIGH: $HostAccess$TargetMappingPrecedence;
        static HIGHEST: $HostAccess$TargetMappingPrecedence;
        static LOW: $HostAccess$TargetMappingPrecedence;
        static LOWEST: $HostAccess$TargetMappingPrecedence;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $HostAccess$TargetMappingPrecedence[];
        static valueOf(name: string): $HostAccess$TargetMappingPrecedence;
    }
    export interface $HostAccess$TargetMappingPrecedence extends $Enum<$HostAccess$TargetMappingPrecedence> {}

    export class $PolyglotAccess$Builder {
        allowBindingsAccess(language: string): $PolyglotAccess$Builder;
        allowEvalBetween(languages?: string[]): $PolyglotAccess$Builder;
        allowEval(from: string, to: string): $PolyglotAccess$Builder;
        build(): $PolyglotAccess;
        denyBindingsAccess(language: string): $PolyglotAccess$Builder;
        denyEvalBetween(languages?: string[]): $PolyglotAccess$Builder;
        denyEval(from: string, to: string): $PolyglotAccess$Builder;
    }

    export class $ResourceLimits$Builder {
        build(): $ResourceLimits;
        onLimit(onLimit: $Consumer_<any, any>): $ResourceLimits$Builder;
        statementLimit(limit: number, sourceFilter: $Predicate_<$Source, $Source, boolean>): $ResourceLimits$Builder;
    }

    export class $Source$Builder {
        buildLiteral(): $Source;
        build(): $Source;
        cached(cached: boolean): $Source$Builder;
        content(bytes: $ByteSequence): $Source$Builder;
        content(characters: $CharSequence): $Source$Builder;
        content(code: string): $Source$Builder;
        encoding(encoding: $Charset): $Source$Builder;
        interactive(interactive: boolean): $Source$Builder;
        internal(internal: boolean): $Source$Builder;
        mimeType(mimeType: string): $Source$Builder;
        name(newName: string): $Source$Builder;
        options(options: ($Map<string, string> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, string>>))): $Source$Builder;
        option(key: string, value: string): $Source$Builder;
        uri(newUri: $URI): $Source$Builder;
    }

    export type $SandboxPolicy_ = $SandboxPolicy | "CONSTRAINED" | "ISOLATED" | "TRUSTED" | "UNTRUSTED";
    export type $Engine$CancellationCallback_<CallbackResult = boolean> = (() => CallbackResult) | ($Engine$CancellationCallback & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "shouldCancel": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $HostAccess$MutableTargetMapping_ = $HostAccess$MutableTargetMapping | "ARRAY_TO_JAVA_LIST" | "EXECUTABLE_TO_JAVA_INTERFACE" | "HASH_TO_JAVA_MAP" | "ITERABLE_TO_JAVA_ITERABLE" | "ITERATOR_TO_JAVA_ITERATOR" | "MEMBERS_TO_JAVA_INTERFACE" | "MEMBERS_TO_JAVA_MAP";
    export type $HostAccess$TargetMappingPrecedence_ = $HostAccess$TargetMappingPrecedence | "HIGH" | "HIGHEST" | "LOW" | "LOWEST";
}
