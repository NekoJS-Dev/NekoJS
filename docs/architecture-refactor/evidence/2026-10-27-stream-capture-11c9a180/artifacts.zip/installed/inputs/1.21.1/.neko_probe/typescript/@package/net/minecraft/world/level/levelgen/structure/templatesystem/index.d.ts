import { $DataFixer } from "java:com/mojang/datafixers";
import { $Codec } from "java:com/mojang/serialization";
import { $ObjectArrayList } from "java:it/unimi/dsi/fastutil/objects";
import { $Enum, $Record } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $List, $Optional } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $HolderGetter, $Vec3i } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ResourceManager } from "java:net/minecraft/server/packs/resources";
import { $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $Level, $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Block, $Block_, $Mirror, $Mirror_, $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";
import { $LevelStorageSource$LevelStorageAccess } from "java:net/minecraft/world/level/storage";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $DiscreteVoxelShape } from "java:net/minecraft/world/phys/shapes";

declare module "java:net/minecraft/world/level/levelgen/structure/templatesystem" {
    export class $LiquidSettings {
        static APPLY_WATERLOGGING: $LiquidSettings;
        static IGNORE_WATERLOGGING: $LiquidSettings;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LiquidSettings[];
        static valueOf(name: string): $LiquidSettings;
    }
    export interface $LiquidSettings extends $Enum<$LiquidSettings>, $StringRepresentable {}

    export class $RuleTest {
        constructor();
        static CODEC: $Codec<$RuleTest>;
        test(arg0: $BlockState_, arg1: $RandomSource): boolean;
    }

    export class $StructurePlaceSettings {
        constructor();
        get boundingBox(): $BoundingBox;
        getBoundingBox(): $BoundingBox;
        set boundingBox(value: $BoundingBox);
        get knownShape(): boolean;
        getKnownShape(): boolean;
        set knownShape(value: boolean);
        get mirror(): $Mirror;
        getMirror(): $Mirror;
        set mirror(value: $Mirror_);
        get processors(): $List<$StructureProcessor>;
        getProcessors(): $List<$StructureProcessor>;
        get rotationPivot(): $BlockPos;
        getRotationPivot(): $BlockPos;
        set rotationPivot(value: $BlockPos_);
        get rotation(): $Rotation;
        getRotation(): $Rotation;
        set rotation(value: $Rotation_);
        get ignoreEntities(): boolean;
        isIgnoreEntities(): boolean;
        set ignoreEntities(value: boolean);
        addProcessor(arg0: $StructureProcessor): $StructurePlaceSettings;
        clearProcessors(): $StructurePlaceSettings;
        copy(): $StructurePlaceSettings;
        getRandomPalette(arg0: ($List<$StructureTemplate$Palette> | ($StructureTemplate$Palette)[]), arg1: $BlockPos_): $StructureTemplate$Palette;
        getRandom(arg0: $BlockPos_): $RandomSource;
        popProcessor(arg0: $StructureProcessor): $StructurePlaceSettings;
        setBoundingBox(arg0: $BoundingBox): $StructurePlaceSettings;
        setFinalizeEntities(arg0: boolean): $StructurePlaceSettings;
        setIgnoreEntities(arg0: boolean): $StructurePlaceSettings;
        setKnownShape(arg0: boolean): $StructurePlaceSettings;
        setLiquidSettings(arg0: $LiquidSettings_): $StructurePlaceSettings;
        setMirror(arg0: $Mirror_): $StructurePlaceSettings;
        setRandom(arg0: $RandomSource): $StructurePlaceSettings;
        setRotationPivot(arg0: $BlockPos_): $StructurePlaceSettings;
        setRotation(arg0: $Rotation_): $StructurePlaceSettings;
        shouldApplyWaterlogging(): boolean;
        shouldFinalizeEntities(): boolean;
    }

    export class $StructureProcessor {
        constructor();
        finalizeProcessing(arg0: $ServerLevelAccessor, arg1: $BlockPos_, arg2: $BlockPos_, arg3: ($List<$StructureTemplate$StructureBlockInfo> | ($StructureTemplate$StructureBlockInfo)[]), arg4: ($List<$StructureTemplate$StructureBlockInfo> | ($StructureTemplate$StructureBlockInfo)[]), arg5: $StructurePlaceSettings): $List<$StructureTemplate$StructureBlockInfo>;
        processBlock(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $StructureTemplate$StructureBlockInfo, arg4: $StructureTemplate$StructureBlockInfo, arg5: $StructurePlaceSettings): $StructureTemplate$StructureBlockInfo;
        processEntity(arg0: $LevelReader, arg1: $BlockPos_, arg2: $StructureTemplate$StructureEntityInfo, arg3: $StructureTemplate$StructureEntityInfo, arg4: $StructurePlaceSettings, arg5: $StructureTemplate): $StructureTemplate$StructureEntityInfo;
        process(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $StructureTemplate$StructureBlockInfo, arg4: $StructureTemplate$StructureBlockInfo, arg5: $StructurePlaceSettings, arg6: $StructureTemplate): $StructureTemplate$StructureBlockInfo;
    }

    export class $StructureProcessorList {
        constructor(arg0: ($List<$StructureProcessor> | ($StructureProcessor)[]));
        list(): $List<$StructureProcessor>;
        toString(): string;
    }

    export class $StructureTemplate {
        constructor();
        static BLOCKS_TAG: string;
        static BLOCK_TAG_NBT: string;
        static BLOCK_TAG_POS: string;
        static BLOCK_TAG_STATE: string;
        static ENTITIES_TAG: string;
        static ENTITY_TAG_BLOCKPOS: string;
        static ENTITY_TAG_NBT: string;
        static ENTITY_TAG_POS: string;
        static PALETTE_LIST_TAG: string;
        static PALETTE_TAG: string;
        static SIZE_TAG: string;
        get author(): string;
        getAuthor(): string;
        set author(value: string);
        get size(): $Vec3i;
        getSize(): $Vec3i;
        static calculateRelativePosition(arg0: $StructurePlaceSettings, arg1: $BlockPos_): $BlockPos;
        static getZeroPositionWithTransform(arg0: $BlockPos_, arg1: $Mirror_, arg2: $Rotation_, arg3: number, arg4: number): $BlockPos;
        static processBlockInfos(arg0: $ServerLevelAccessor, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $StructurePlaceSettings, arg4: ($List<$StructureTemplate$StructureBlockInfo> | ($StructureTemplate$StructureBlockInfo)[]), arg5: $StructureTemplate): $List<$StructureTemplate$StructureBlockInfo>;
        static processBlockInfos(arg0: $ServerLevelAccessor, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $StructurePlaceSettings, arg4: ($List<$StructureTemplate$StructureBlockInfo> | ($StructureTemplate$StructureBlockInfo)[])): $List<$StructureTemplate$StructureBlockInfo>;
        static processEntityInfos(arg0: $StructureTemplate, arg1: $LevelAccessor, arg2: $BlockPos_, arg3: $StructurePlaceSettings, arg4: ($List<$StructureTemplate$StructureEntityInfo> | ($StructureTemplate$StructureEntityInfo)[])): $List<$StructureTemplate$StructureEntityInfo>;
        static transformedVec3d(arg0: $StructurePlaceSettings, arg1: $Vec3_): $Vec3;
        static transform(arg0: $BlockPos_, arg1: $Mirror_, arg2: $Rotation_, arg3: $BlockPos_): $BlockPos;
        static transform(arg0: $Vec3_, arg1: $Mirror_, arg2: $Rotation_, arg3: $BlockPos_): $Vec3;
        static updateShapeAtEdge(arg0: $LevelAccessor, arg1: number, arg2: $DiscreteVoxelShape, arg3: number, arg4: number, arg5: number): void;
        static updateShapeAtEdge(arg0: $LevelAccessor, arg1: number, arg2: $DiscreteVoxelShape, arg3: $BlockPos_): void;
        calculateConnectedPosition(arg0: $StructurePlaceSettings, arg1: $BlockPos_, arg2: $StructurePlaceSettings, arg3: $BlockPos_): $BlockPos;
        fillFromWorld(arg0: $Level, arg1: $BlockPos_, arg2: $Vec3i, arg3: boolean, arg4: $Block_): void;
        filterBlocks(arg0: $BlockPos_, arg1: $StructurePlaceSettings, arg2: $Block_, arg3: boolean): $ObjectArrayList<$StructureTemplate$StructureBlockInfo>;
        filterBlocks(arg0: $BlockPos_, arg1: $StructurePlaceSettings, arg2: $Block_): $List<$StructureTemplate$StructureBlockInfo>;
        getBoundingBox(arg0: $BlockPos_, arg1: $Rotation_, arg2: $BlockPos_, arg3: $Mirror_): $BoundingBox;
        getBoundingBox(arg0: $StructurePlaceSettings, arg1: $BlockPos_): $BoundingBox;
        getSize(arg0: $Rotation_): $Vec3i;
        getZeroPositionWithTransform(arg0: $BlockPos_, arg1: $Mirror_, arg2: $Rotation_): $BlockPos;
        load(arg0: $HolderGetter<$Block>, arg1: $CompoundTag_): void;
        placeInWorld(arg0: $ServerLevelAccessor, arg1: $BlockPos_, arg2: $BlockPos_, arg3: $StructurePlaceSettings, arg4: $RandomSource, arg5: number): boolean;
        save(arg0: $CompoundTag_): $CompoundTag;
        setAuthor(arg0: string): void;
    }

    export class $StructureTemplate$Palette {
        blocks(arg0: $Block_): $List<$StructureTemplate$StructureBlockInfo>;
        blocks(): $List<$StructureTemplate$StructureBlockInfo>;
    }

    export class $StructureTemplate$StructureBlockInfo extends $Record {
        constructor(pos: $BlockPos_, state: $BlockState_, nbt: $CompoundTag_);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        nbt(): $CompoundTag;
        pos(): $BlockPos;
        state(): $BlockState;
        toString(): string;
    }

    export class $StructureTemplate$StructureEntityInfo {
        constructor(arg0: $Vec3_, arg1: $BlockPos_, arg2: $CompoundTag_);
        blockPos: $BlockPos;
        nbt: $CompoundTag;
        pos: $Vec3;
    }

    export class $StructureTemplateManager {
        constructor(arg0: $ResourceManager, arg1: $LevelStorageSource$LevelStorageAccess, arg2: $DataFixer, arg3: $HolderGetter<$Block>);
        static STRUCTURE_RESOURCE_DIRECTORY_NAME: string;
        createAndValidatePathToGeneratedStructure(arg0: $ResourceLocation_, arg1: string): $Path;
        getOrCreate(arg0: $ResourceLocation_): $StructureTemplate;
        get(arg0: $ResourceLocation_): $Optional<$StructureTemplate>;
        listTemplates(): $Stream<$ResourceLocation>;
        onResourceManagerReload(arg0: $ResourceManager): void;
        readStructure(arg0: $CompoundTag_): $StructureTemplate;
        remove(arg0: $ResourceLocation_): void;
        save(arg0: $ResourceLocation_): boolean;
    }

    export type $LiquidSettings_ = $LiquidSettings | "APPLY_WATERLOGGING" | "IGNORE_WATERLOGGING";
}
