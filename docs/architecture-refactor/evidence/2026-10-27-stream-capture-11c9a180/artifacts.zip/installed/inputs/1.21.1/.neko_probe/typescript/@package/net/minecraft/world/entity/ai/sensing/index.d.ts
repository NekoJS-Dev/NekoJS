import { $Set } from "java:java/util";
import { $BiPredicate, $BiPredicate_, $Predicate, $Predicate_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $AgeableMob, $Entity, $LivingEntity, $Mob, $PathfinderMob } from "java:net/minecraft/world/entity";
import { $MemoryModuleType } from "java:net/minecraft/world/entity/ai/memory";
import { $Armadillo } from "java:net/minecraft/world/entity/animal/armadillo";
import { $Breeze } from "java:net/minecraft/world/entity/monster/breeze";
import { $Hoglin } from "java:net/minecraft/world/entity/monster/hoglin";
import { $Warden } from "java:net/minecraft/world/entity/monster/warden";
import { $Villager } from "java:net/minecraft/world/entity/npc";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";

declare module "java:net/minecraft/world/entity/ai/sensing" {
    export class $AdultSensor extends $Sensor<$AgeableMob> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $AxolotlAttackablesSensor extends $NearestVisibleLivingEntitySensor {
        constructor();
        static TARGET_DETECTION_DISTANCE: number;
    }

    export class $BreezeAttackEntitySensor extends $NearestLivingEntitySensor<$Breeze> {
        constructor();
        static BREEZE_SENSOR_RADIUS: number;
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $DummySensor extends $Sensor<$LivingEntity> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $FrogAttackablesSensor extends $NearestVisibleLivingEntitySensor {
        constructor();
        static TARGET_DETECTION_DISTANCE: number;
    }

    export class $GolemSensor extends $Sensor<$LivingEntity> {
        constructor();
        constructor(arg0: number);
        static checkForNearbyGolem(arg0: $LivingEntity): void;
        static golemDetected(arg0: $LivingEntity): void;
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $HoglinSpecificSensor extends $Sensor<$Hoglin> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $HurtBySensor extends $Sensor<$LivingEntity> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $IsInWaterSensor extends $Sensor<$LivingEntity> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $MobSensor<T extends $LivingEntity> extends $Sensor<T> {
        constructor(arg0: number, arg1: $BiPredicate_<T, $LivingEntity, T, $LivingEntity, boolean>, arg2: $Predicate_<T, T, boolean>, arg3: $MemoryModuleType<boolean>, arg4: number);
        checkForMobsNearby(arg0: T): void;
        clearMemory(arg0: T): void;
        mobDetected(arg0: T): void;
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $NearestBedSensor extends $Sensor<$Mob> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $NearestItemSensor extends $Sensor<$Mob> {
        constructor();
        static MAX_DISTANCE_TO_WANTED_ITEM: number;
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $NearestLivingEntitySensor<T extends $LivingEntity> extends $Sensor<T> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $NearestVisibleLivingEntitySensor extends $Sensor<$LivingEntity> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $PiglinBruteSpecificSensor extends $Sensor<$LivingEntity> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $PiglinSpecificSensor extends $Sensor<$LivingEntity> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $PlayerSensor extends $Sensor<$LivingEntity> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $SecondaryPoiSensor extends $Sensor<$Villager> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $Sensing {
        constructor(arg0: $Mob);
        hasLineOfSight(arg0: $Entity): boolean;
        tick(): void;
    }

    export class $Sensor<E extends $LivingEntity> {
        constructor();
        constructor(arg0: number);
        static isEntityAttackableIgnoringLineOfSight(arg0: $LivingEntity, arg1: $LivingEntity): boolean;
        static isEntityAttackable(arg0: $LivingEntity, arg1: $LivingEntity): boolean;
        static isEntityTargetable(arg0: $LivingEntity, arg1: $LivingEntity): boolean;
        requires(): $Set<$MemoryModuleType<any>>;
        tick(arg0: $ServerLevel, arg1: E): void;
    }

    export class $SensorType<U extends $Sensor<any>> {
        constructor(arg0: $Supplier_<U, U>);
        static ARMADILLO_SCARE_DETECTED: $SensorType<$MobSensor<$Armadillo>>;
        static ARMADILLO_TEMPTATIONS: $SensorType<$TemptingSensor>;
        static AXOLOTL_ATTACKABLES: $SensorType<$AxolotlAttackablesSensor>;
        static AXOLOTL_TEMPTATIONS: $SensorType<$TemptingSensor>;
        static BREEZE_ATTACK_ENTITY_SENSOR: $SensorType<$BreezeAttackEntitySensor>;
        static CAMEL_TEMPTATIONS: $SensorType<$TemptingSensor>;
        static DUMMY: $SensorType<$DummySensor>;
        static FROG_ATTACKABLES: $SensorType<$FrogAttackablesSensor>;
        static FROG_TEMPTATIONS: $SensorType<$TemptingSensor>;
        static GOAT_TEMPTATIONS: $SensorType<$TemptingSensor>;
        static GOLEM_DETECTED: $SensorType<$GolemSensor>;
        static HOGLIN_SPECIFIC_SENSOR: $SensorType<$HoglinSpecificSensor>;
        static HURT_BY: $SensorType<$HurtBySensor>;
        static IS_IN_WATER: $SensorType<$IsInWaterSensor>;
        static NEAREST_ADULT: $SensorType<$AdultSensor>;
        static NEAREST_BED: $SensorType<$NearestBedSensor>;
        static NEAREST_ITEMS: $SensorType<$NearestItemSensor>;
        static NEAREST_LIVING_ENTITIES: $SensorType<$NearestLivingEntitySensor<$LivingEntity>>;
        static NEAREST_PLAYERS: $SensorType<$PlayerSensor>;
        static PIGLIN_BRUTE_SPECIFIC_SENSOR: $SensorType<$PiglinBruteSpecificSensor>;
        static PIGLIN_SPECIFIC_SENSOR: $SensorType<$PiglinSpecificSensor>;
        static SECONDARY_POIS: $SensorType<$SecondaryPoiSensor>;
        static SNIFFER_TEMPTATIONS: $SensorType<$TemptingSensor>;
        static VILLAGER_BABIES: $SensorType<$VillagerBabiesSensor>;
        static VILLAGER_HOSTILES: $SensorType<$VillagerHostilesSensor>;
        static WARDEN_ENTITY_SENSOR: $SensorType<$WardenEntitySensor>;
        create(): U;
    }

    export class $TemptingSensor extends $Sensor<$PathfinderMob> {
        constructor(arg0: $Predicate_<$ItemStack, $ItemStack, boolean>);
        static TEMPTATION_RANGE: number;
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $VillagerBabiesSensor extends $Sensor<$LivingEntity> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

    export class $VillagerHostilesSensor extends $NearestVisibleLivingEntitySensor {
        constructor();
    }

    export class $WardenEntitySensor extends $NearestLivingEntitySensor<$Warden> {
        constructor();
        requires(): $Set<$MemoryModuleType<any>>;
    }

}
