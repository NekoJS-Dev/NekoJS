import { $Class } from "java:java/lang";
import { $Function, $Function_ } from "java:java/util/function";
import { $EntityType, $EntityType_, $Mob } from "java:net/minecraft/world/entity";
import { $Goal } from "java:net/minecraft/world/entity/ai/goal";

declare module "java:com/tkisor/nekojs/wrapper/entity" {
    export class $GoalRegistry$GoalBuilderJS {
        constructor();
        avoid(priority: number, target: unknown, radius: number, speed: number): $GoalRegistry$GoalBuilderJS;
        avoid(target: unknown, radius: number, speed: number): $GoalRegistry$GoalBuilderJS;
        customClass(priority: number, goalClass: $Class<$Goal>): $GoalRegistry$GoalBuilderJS;
        customTargetClass(priority: number, goalClass: $Class<$Goal>): $GoalRegistry$GoalBuilderJS;
        customTarget(priority: number, factory: $Function_<$Mob, $Goal, $Mob, $Goal>): $GoalRegistry$GoalBuilderJS;
        custom(priority: number, factory: $Function_<$Mob, $Goal, $Mob, $Goal>): $GoalRegistry$GoalBuilderJS;
        floatInWater(priority: number): $GoalRegistry$GoalBuilderJS;
        floatInWater(): $GoalRegistry$GoalBuilderJS;
        forType(id: string): $GoalRegistry$GoalBuilderJS;
        forType(type: $EntityType_<any>): $GoalRegistry$GoalBuilderJS;
        hurtByTarget(priority: number): $GoalRegistry$GoalBuilderJS;
        hurtByTarget(): $GoalRegistry$GoalBuilderJS;
        lookAt(priority: number, target: unknown, radius: number): $GoalRegistry$GoalBuilderJS;
        lookAt(target: unknown, radius: number): $GoalRegistry$GoalBuilderJS;
        meleeAttack(speed: number, longMemory: boolean): $GoalRegistry$GoalBuilderJS;
        meleeAttack(priority: number, speed: number, longMemory: boolean): $GoalRegistry$GoalBuilderJS;
        panic(speed: number): $GoalRegistry$GoalBuilderJS;
        panic(priority: number, speed: number): $GoalRegistry$GoalBuilderJS;
        randomStroll(speed: number): $GoalRegistry$GoalBuilderJS;
        randomStroll(priority: number, speed: number): $GoalRegistry$GoalBuilderJS;
        register(): void;
        target(priority: number, target: unknown, mustSee: boolean): $GoalRegistry$GoalBuilderJS;
        target(priority: number, target: unknown): $GoalRegistry$GoalBuilderJS;
        target(target: unknown): $GoalRegistry$GoalBuilderJS;
    }

}
