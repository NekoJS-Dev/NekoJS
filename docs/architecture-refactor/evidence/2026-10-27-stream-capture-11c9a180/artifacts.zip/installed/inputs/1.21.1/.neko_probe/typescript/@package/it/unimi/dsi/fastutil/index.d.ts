import { $Comparator, $Comparator_, $Iterator } from "java:java/util";
import { $Function as $NekoImport$Function, $Function_ as $NekoImport$Function_ } from "java:java/util/function";

export * as objects from "java:it/unimi/dsi/fastutil/objects";
export * as bytes from "java:it/unimi/dsi/fastutil/bytes";
export * as chars from "java:it/unimi/dsi/fastutil/chars";
export * as doubles from "java:it/unimi/dsi/fastutil/doubles";
export * as floats from "java:it/unimi/dsi/fastutil/floats";
export * as ints from "java:it/unimi/dsi/fastutil/ints";
export * as longs from "java:it/unimi/dsi/fastutil/longs";
export * as shorts from "java:it/unimi/dsi/fastutil/shorts";

declare module "java:it/unimi/dsi/fastutil" {
    export interface $Function<K, out V> extends $NekoImport$Function<K, V> {
        apply(arg0: K): V;
        clear(): void;
        containsKey(arg0: unknown): boolean;
        getOrDefault(arg0: unknown, arg1: V): V;
        get(arg0: unknown): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: unknown): V;
        size(): number;
    }

    export interface $BidirectionalIterator<K> extends $Iterator<K> {
        hasPrevious(): boolean;
        previous(): K;
    }

    export interface $Pair<L, R> {
        first(arg0: L): $Pair<L, R>;
        first(): L;
        key(arg0: L): $Pair<L, R>;
        key(): L;
        left(arg0: L): $Pair<L, R>;
        left(): L;
        right(arg0: R): $Pair<L, R>;
        right(): R;
        second(arg0: R): $Pair<L, R>;
        second(): R;
        value(arg0: R): $Pair<L, R>;
        value(): R;
    }
    export const $Pair: {
        lexComparator<L, R>(): $Comparator<$Pair<L, R>>;
        of<L, R>(arg0: L, arg1: R): $Pair<L, R>;
    };

    export interface $Stack<K> {
        isEmpty(): boolean;
        peek(arg0: number): K;
        pop(): K;
        push(arg0: K): void;
        top(): K;
    }

    export interface $Hash$Strategy<K> {
        equals(arg0: K, arg1: K): boolean;
        hashCode(arg0: K): number;
    }

    export type $Function_<Host0 = any, Host1 = any, CallbackArg0 = unknown, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($Function<Host0, Host1> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
