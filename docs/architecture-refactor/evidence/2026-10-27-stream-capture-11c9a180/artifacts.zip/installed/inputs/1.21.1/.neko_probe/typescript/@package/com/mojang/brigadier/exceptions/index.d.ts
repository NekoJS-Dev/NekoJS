import { $ImmutableStringReader, $Message, $Message_ } from "java:com/mojang/brigadier";
import { $Exception } from "java:java/lang";
import { $Function, $Function_ } from "java:java/util/function";

declare module "java:com/mojang/brigadier/exceptions" {
    export interface $BuiltInExceptionProvider {
        dispatcherExpectedArgumentSeparator(): $SimpleCommandExceptionType;
        dispatcherParseException(): $DynamicCommandExceptionType;
        dispatcherUnknownArgument(): $SimpleCommandExceptionType;
        dispatcherUnknownCommand(): $SimpleCommandExceptionType;
        doubleTooHigh(): $Dynamic2CommandExceptionType;
        doubleTooLow(): $Dynamic2CommandExceptionType;
        floatTooHigh(): $Dynamic2CommandExceptionType;
        floatTooLow(): $Dynamic2CommandExceptionType;
        integerTooHigh(): $Dynamic2CommandExceptionType;
        integerTooLow(): $Dynamic2CommandExceptionType;
        literalIncorrect(): $DynamicCommandExceptionType;
        longTooHigh(): $Dynamic2CommandExceptionType;
        longTooLow(): $Dynamic2CommandExceptionType;
        readerExpectedBool(): $SimpleCommandExceptionType;
        readerExpectedDouble(): $SimpleCommandExceptionType;
        readerExpectedEndOfQuote(): $SimpleCommandExceptionType;
        readerExpectedFloat(): $SimpleCommandExceptionType;
        readerExpectedInt(): $SimpleCommandExceptionType;
        readerExpectedLong(): $SimpleCommandExceptionType;
        readerExpectedStartOfQuote(): $SimpleCommandExceptionType;
        readerExpectedSymbol(): $DynamicCommandExceptionType;
        readerInvalidBool(): $DynamicCommandExceptionType;
        readerInvalidDouble(): $DynamicCommandExceptionType;
        readerInvalidEscape(): $DynamicCommandExceptionType;
        readerInvalidFloat(): $DynamicCommandExceptionType;
        readerInvalidInt(): $DynamicCommandExceptionType;
        readerInvalidLong(): $DynamicCommandExceptionType;
    }

    export interface $CommandExceptionType {
    }

    export class $CommandSyntaxException extends $Exception {
        constructor(arg0: $CommandExceptionType, arg1: $Message_<string>);
        constructor(arg0: $CommandExceptionType, arg1: $Message_<string>, arg2: string, arg3: number);
        static BUILT_IN_EXCEPTIONS: $BuiltInExceptionProvider;
        static CONTEXT_AMOUNT: number;
        static ENABLE_COMMAND_STACK_TRACES: boolean;
        get context(): string;
        getContext(): string;
        get cursor(): number;
        getCursor(): number;
        get input(): string;
        getInput(): string;
        get message(): string;
        getMessage(): string;
        get rawMessage(): $Message;
        getRawMessage(): $Message;
        get type(): $CommandExceptionType;
        getType(): $CommandExceptionType;
    }

    export class $Dynamic2CommandExceptionType implements $CommandExceptionType {
        constructor(arg0: $Dynamic2CommandExceptionType$Function_<unknown, unknown, $Message_<string>>);
        createWithContext(arg0: $ImmutableStringReader, arg1: unknown, arg2: unknown): $CommandSyntaxException;
        create(arg0: unknown, arg1: unknown): $CommandSyntaxException;
    }

    export interface $Dynamic2CommandExceptionType$Function {
        apply(arg0: unknown, arg1: unknown): $Message;
    }

    export class $DynamicCommandExceptionType implements $CommandExceptionType {
        constructor(arg0: $Function_<unknown, $Message, unknown, $Message_<string>>);
        createWithContext(arg0: $ImmutableStringReader, arg1: unknown): $CommandSyntaxException;
        create(arg0: unknown): $CommandSyntaxException;
    }

    export class $SimpleCommandExceptionType implements $CommandExceptionType {
        constructor(arg0: $Message_<string>);
        createWithContext(arg0: $ImmutableStringReader): $CommandSyntaxException;
        create(): $CommandSyntaxException;
        toString(): string;
    }

    export type $Dynamic2CommandExceptionType$Function_<CallbackArg0 = unknown, CallbackArg1 = unknown, CallbackResult = $Message_<string>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($Dynamic2CommandExceptionType$Function & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
