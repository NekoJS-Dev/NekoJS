import type { RegistryTypes } from "@special/types";
import { $RequiredArgumentBuilder } from "java:com/mojang/brigadier/builder";
import { $CommandContext } from "java:com/mojang/brigadier/context";
import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec, $Dynamic, $DynamicLike, $Lifecycle } from "java:com/mojang/serialization";
import { $AttachedData, $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $LevelExtension, $LevelExtension_ } from "java:com/tkisor/nekojs/api/inject";
import { $LongSet } from "java:it/unimi/dsi/fastutil/longs";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $AutoCloseable, $AutoCloseable_, $Class, $Enum, $Iterable, $Record } from "java:java/lang";
import { $ArrayList, $Collection, $List, $Map, $Optional, $UUID } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function, $Function_, $Predicate, $Predicate_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $CrashReport, $CrashReportCategory } from "java:net/minecraft";
import { $CommandSource, $CommandSourceStack } from "java:net/minecraft/commands";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $Holder$Reference, $HolderLookup, $HolderLookup$Provider, $HolderSet, $Holder_, $Registry, $RegistryAccess, $SectionPos } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleOptions_, $ParticleType, $ParticleType_ } from "java:net/minecraft/core/particles";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $ServerLevel, $WorldGenRegion } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_, $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $InclusiveRange, $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $ProfilerFiller } from "java:net/minecraft/util/profiling";
import { $SimpleWeightedRandomList } from "java:net/minecraft/util/random";
import { $Difficulty, $DifficultyInstance, $Difficulty_, $InteractionResult, $InteractionResult_, $TickRateManager } from "java:net/minecraft/world";
import { $DamageSource, $DamageSources } from "java:net/minecraft/world/damagesource";
import { $Entity, $EntityType, $EntityType_, $EquipmentTable, $LivingEntity, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $TargetingConditions } from "java:net/minecraft/world/entity/ai/targeting";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $PotionBrewing } from "java:net/minecraft/world/item/alchemy";
import { $FireworkExplosion } from "java:net/minecraft/world/item/component";
import { $RecipeManager } from "java:net/minecraft/world/item/crafting";
import { $Biome, $BiomeManager, $BiomeManager$NoiseBiomeSource, $BiomeManager$NoiseBiomeSource_ } from "java:net/minecraft/world/level/biome";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_, $TickingBlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $WorldBorder } from "java:net/minecraft/world/level/border";
import { $BlockColumn, $ChunkAccess, $ChunkSource, $LevelChunk, $StructureAccess } from "java:net/minecraft/world/level/chunk";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";
import { $DimensionType } from "java:net/minecraft/world/level/dimension";
import { $EntityTypeTest } from "java:net/minecraft/world/level/entity";
import { $GameEvent, $GameEvent$Context, $GameEvent_ } from "java:net/minecraft/world/level/gameevent";
import { $Heightmap$Types, $Heightmap$Types_, $WorldOptions } from "java:net/minecraft/world/level/levelgen";
import { $Structure, $StructureCheck, $StructureCheckResult, $StructureCheckResult_, $StructureStart } from "java:net/minecraft/world/level/levelgen/structure";
import { $StructurePlacement } from "java:net/minecraft/world/level/levelgen/structure/placement";
import { $LevelLightEngine } from "java:net/minecraft/world/level/lighting";
import { $Fluid, $FluidState, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $MapId, $MapItemSavedData } from "java:net/minecraft/world/level/saveddata/maps";
import { $LevelData } from "java:net/minecraft/world/level/storage";
import { $AABB, $BlockHitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $CollisionContext, $VoxelShape } from "java:net/minecraft/world/phys/shapes";
import { $Scoreboard } from "java:net/minecraft/world/scores";
import { $LevelTickAccess, $TickPriority, $TickPriority_ } from "java:net/minecraft/world/ticks";
import { $AttachmentHolder, $AttachmentType } from "java:net/neoforged/neoforge/attachment";
import { $BlockCapability } from "java:net/neoforged/neoforge/capabilities";
import { $ModelData, $ModelDataManager } from "java:net/neoforged/neoforge/client/model/data";
import { $IBlockAndTintGetterExtension, $IBlockGetterExtension, $ILevelExtension, $ILevelReaderExtension, $IOwnedSpawner, $IOwnedSpawner_ } from "java:net/neoforged/neoforge/common/extensions";
import { $BlockSnapshot } from "java:net/neoforged/neoforge/common/util";
import { $AuxiliaryLightManager } from "java:net/neoforged/neoforge/common/world";
import { $PartEntity } from "java:net/neoforged/neoforge/entity";

export * as biome from "java:net/minecraft/world/level/biome";
export * as block from "java:net/minecraft/world/level/block";
export * as border from "java:net/minecraft/world/level/border";
export * as chunk from "java:net/minecraft/world/level/chunk";
export * as dimension from "java:net/minecraft/world/level/dimension";
export * as entity from "java:net/minecraft/world/level/entity";
export * as gameevent from "java:net/minecraft/world/level/gameevent";
export * as levelgen from "java:net/minecraft/world/level/levelgen";
export * as lighting from "java:net/minecraft/world/level/lighting";
export * as material from "java:net/minecraft/world/level/material";
export * as pathfinder from "java:net/minecraft/world/level/pathfinder";
export * as portal from "java:net/minecraft/world/level/portal";
export * as saveddata from "java:net/minecraft/world/level/saveddata";
export * as storage from "java:net/minecraft/world/level/storage";
export * as timers from "java:net/minecraft/world/level/timers";
export * as validation from "java:net/minecraft/world/level/validation";

declare module "java:net/minecraft/world/level" {
    export class $BaseCommandBlock implements $CommandSource {
        constructor();
        get command(): string;
        getCommand(): string;
        set command(value: string);
        get customName(): $Component;
        getCustomName(): $Component;
        set customName(value: $Component_);
        get lastOutput(): $Component;
        getLastOutput(): $Component;
        set lastOutput(value: $Component_);
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
        get name(): $Component;
        getName(): $Component;
        get position(): $Vec3;
        getPosition(): $Vec3;
        get successCount(): number;
        getSuccessCount(): number;
        set successCount(value: number);
        get trackOutput(): boolean;
        isTrackOutput(): boolean;
        set trackOutput(value: boolean);
        get valid(): boolean;
        isValid(): boolean;
        acceptsFailure(): boolean;
        acceptsSuccess(): boolean;
        alwaysAccepts(): boolean;
        createCommandSourceStack(): $CommandSourceStack;
        load(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): void;
        onUpdated(): void;
        performCommand(arg0: $Level): boolean;
        save(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): $CompoundTag;
        sendSystemMessage(arg0: $Component_): void;
        setCommand(arg0: string): void;
        setCustomName(arg0: $Component_): void;
        setLastOutput(arg0: $Component_): void;
        setSuccessCount(arg0: number): void;
        setTrackOutput(arg0: boolean): void;
        shouldInformAdmins(): boolean;
        usedBy(arg0: $Player): $InteractionResult;
    }

    export class $BaseSpawner implements $IOwnedSpawner {
        constructor();
        static SPAWN_DATA_TAG: string;
        get owner(): $Either<$BlockEntity, $Entity>;
        getOwner(): $Either<$BlockEntity, $Entity>;
        get spin(): number;
        getSpin(): number;
        get oSpin(): number;
        getoSpin(): number;
        broadcastEvent(arg0: $Level, arg1: $BlockPos_, arg2: number): void;
        clientTick(arg0: $Level, arg1: $BlockPos_): void;
        getOrCreateDisplayEntity(arg0: $Level, arg1: $BlockPos_): $Entity;
        load(arg0: $Level, arg1: $BlockPos_, arg2: $CompoundTag_): void;
        onEventTriggered(arg0: $Level, arg1: number): boolean;
        save(arg0: $CompoundTag_): $CompoundTag;
        serverTick(arg0: $ServerLevel, arg1: $BlockPos_): void;
        setEntityId(arg0: $EntityType_<any>, arg1: $Level, arg2: $RandomSource, arg3: $BlockPos_): void;
    }

    export interface $BlockAndTintGetter extends $BlockGetter, $IBlockAndTintGetterExtension {
        canSeeSky(arg0: $BlockPos_): boolean;
        getBlockTint(arg0: $BlockPos_, arg1: $ColorResolver_<$Biome, number, number, number>): number;
        getBrightness(arg0: $LightLayer_, arg1: $BlockPos_): number;
        getLightEngine(): $LevelLightEngine;
        getRawBrightness(arg0: $BlockPos_, arg1: number): number;
        getShade(arg0: number, arg1: number, arg2: number, arg3: boolean): number;
        getShade(arg0: $Direction_, arg1: boolean): number;
    }

    export interface $BlockGetter extends $LevelHeightAccessor, $IBlockGetterExtension {
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getLightEmission(arg0: $BlockPos_): number;
        getMaxLightLevel(): number;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
    }
    export const $BlockGetter: {
        traverseBlocks<T, C>(arg0: $Vec3_, arg1: $Vec3_, arg2: C, arg3: $BiFunction_<C, $BlockPos, T, C, $BlockPos, T>, arg4: $Function_<C, T, C, T>): T;
    };

    export class $ChunkPos {
        constructor(arg0: number, arg1: number);
        constructor(arg0: number);
        constructor(arg0: $BlockPos_);
        static INVALID_CHUNK_POS: number;
        static REGION_MAX_INDEX: number;
        static REGION_SIZE: number;
        static ZERO: $ChunkPos;
        x: number;
        z: number;
        get maxBlockX(): number;
        getMaxBlockX(): number;
        get maxBlockZ(): number;
        getMaxBlockZ(): number;
        get middleBlockX(): number;
        getMiddleBlockX(): number;
        get middleBlockZ(): number;
        getMiddleBlockZ(): number;
        get minBlockX(): number;
        getMinBlockX(): number;
        get minBlockZ(): number;
        getMinBlockZ(): number;
        get regionLocalX(): number;
        getRegionLocalX(): number;
        get regionLocalZ(): number;
        getRegionLocalZ(): number;
        get regionX(): number;
        getRegionX(): number;
        get regionZ(): number;
        getRegionZ(): number;
        get worldPosition(): $BlockPos;
        getWorldPosition(): $BlockPos;
        static asLong(arg0: number, arg1: number): number;
        static asLong(arg0: $BlockPos_): number;
        static getX(arg0: number): number;
        static getZ(arg0: number): number;
        static hash(arg0: number, arg1: number): number;
        static maxFromRegion(arg0: number, arg1: number): $ChunkPos;
        static minFromRegion(arg0: number, arg1: number): $ChunkPos;
        static rangeClosed(arg0: $ChunkPos, arg1: number): $Stream<$ChunkPos>;
        static rangeClosed(arg0: $ChunkPos, arg1: $ChunkPos): $Stream<$ChunkPos>;
        distanceSquared(arg0: number): number;
        distanceSquared(arg0: $ChunkPos): number;
        equals(arg0: unknown): boolean;
        getBlockAt(arg0: number, arg1: number, arg2: number): $BlockPos;
        getBlockX(arg0: number): number;
        getBlockZ(arg0: number): number;
        getChessboardDistance(arg0: number, arg1: number): number;
        getChessboardDistance(arg0: $ChunkPos): number;
        getMiddleBlockPosition(arg0: number): $BlockPos;
        hashCode(): number;
        toLong(): number;
        toString(): string;
    }

    export class $ClipBlockStateContext {
        constructor(arg0: $Vec3_, arg1: $Vec3_, arg2: $Predicate_<$BlockState, $BlockState, boolean>);
        get from(): $Vec3;
        getFrom(): $Vec3;
        get to(): $Vec3;
        getTo(): $Vec3;
        get targetBlock(): $Predicate<$BlockState>;
        isTargetBlock(): $Predicate<$BlockState>;
    }

    export class $ClipContext {
        constructor(arg0: $Vec3_, arg1: $Vec3_, arg2: $ClipContext$Block_, arg3: $ClipContext$Fluid_, arg4: $Entity);
        constructor(arg0: $Vec3_, arg1: $Vec3_, arg2: $ClipContext$Block_, arg3: $ClipContext$Fluid_, arg4: $CollisionContext);
        get from(): $Vec3;
        getFrom(): $Vec3;
        get to(): $Vec3;
        getTo(): $Vec3;
        getBlockShape(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): $VoxelShape;
        getFluidShape(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): $VoxelShape;
    }

    export class $ClipContext$Block {
        static COLLIDER: $ClipContext$Block;
        static FALLDAMAGE_RESETTING: $ClipContext$Block;
        static OUTLINE: $ClipContext$Block;
        static VISUAL: $ClipContext$Block;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClipContext$Block[];
        static valueOf(name: string): $ClipContext$Block;
    }
    export interface $ClipContext$Block extends $Enum<$ClipContext$Block>, $ClipContext$ShapeGetter {}

    export class $ClipContext$Fluid {
        static ANY: $ClipContext$Fluid;
        static NONE: $ClipContext$Fluid;
        static SOURCE_ONLY: $ClipContext$Fluid;
        static WATER: $ClipContext$Fluid;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClipContext$Fluid[];
        static valueOf(name: string): $ClipContext$Fluid;
    }
    export interface $ClipContext$Fluid extends $Enum<$ClipContext$Fluid> {}

    export interface $ClipContext$ShapeGetter {
        get(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $CollisionContext): $VoxelShape;
    }

    export interface $CollisionGetter extends $BlockGetter {
        collidesWithSuffocatingBlock(arg0: $Entity, arg1: $AABB): boolean;
        findFreePosition(arg0: $Entity, arg1: $VoxelShape, arg2: $Vec3_, arg3: number, arg4: number, arg5: number): $Optional<$Vec3>;
        findSupportingBlock(arg0: $Entity, arg1: $AABB): $Optional<$BlockPos>;
        getBlockCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getWorldBorder(): $WorldBorder;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
        isUnobstructed(arg0: $Entity): boolean;
        isUnobstructed(arg0: $BlockState_, arg1: $BlockPos_, arg2: $CollisionContext): boolean;
        noBlockCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity): boolean;
        noCollision(arg0: $AABB): boolean;
    }

    export interface $ColorResolver {
        getColor(arg0: $Biome, arg1: number, arg2: number): number;
    }

    export interface $CommonLevelAccessor extends $EntityGetter, $LevelReader, $LevelSimulatedRW {
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getHeightmapPos(arg0: $Heightmap$Types_, arg1: $BlockPos_): $BlockPos;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
        isUnobstructed(arg0: $Entity): boolean;
        isUnobstructed(arg0: $BlockState_, arg1: $BlockPos_, arg2: $CollisionContext): boolean;
    }

    export interface $CustomSpawner {
        tick(arg0: $ServerLevel, arg1: boolean, arg2: boolean): number;
    }

    export class $DataPackConfig {
        constructor(arg0: ($List<string> | (string)[]), arg1: ($List<string> | (string)[]));
        static CODEC: $Codec<$DataPackConfig>;
        static DEFAULT: $DataPackConfig;
        get disabled(): $List<string>;
        getDisabled(): $List<string>;
        get enabled(): $List<string>;
        getEnabled(): $List<string>;
        addModPacks(arg0: ($List<string> | (string)[])): void;
    }

    export interface $EntityGetter {
        getEntitiesOfClass<T extends $Entity>(arg0: $Class<T>, arg1: $AABB, arg2: $Predicate_<T, T, boolean>): $List<T>;
        getEntitiesOfClass<T extends $Entity>(arg0: $Class<T>, arg1: $AABB): $List<T>;
        getEntities(arg0: $Entity, arg1: $AABB, arg2: $Predicate_<$Entity, $Entity, boolean>): $List<$Entity>;
        getEntities(arg0: $Entity, arg1: $AABB): $List<$Entity>;
        getEntities<T extends $Entity>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate_<T, T, boolean>): $List<T>;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getNearbyEntities<T extends $LivingEntity>(arg0: $Class<T>, arg1: $TargetingConditions, arg2: $LivingEntity, arg3: $AABB): $List<T>;
        getNearbyPlayers(arg0: $TargetingConditions, arg1: $LivingEntity, arg2: $AABB): $List<$Player>;
        getNearestEntity<T extends $LivingEntity>(arg0: $Class<T>, arg1: $TargetingConditions, arg2: $LivingEntity, arg3: number, arg4: number, arg5: number, arg6: $AABB): T;
        getNearestEntity<T extends $LivingEntity>(arg0: ($List<T> | (T)[]), arg1: $TargetingConditions, arg2: $LivingEntity, arg3: number, arg4: number, arg5: number): T;
        getNearestPlayer(arg0: number, arg1: number, arg2: number, arg3: number, arg4: boolean): $Player;
        getNearestPlayer(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $Predicate_<$Entity, $Entity, boolean>): $Player;
        getNearestPlayer(arg0: $Entity, arg1: number): $Player;
        getNearestPlayer(arg0: $TargetingConditions, arg1: number, arg2: number, arg3: number): $Player;
        getNearestPlayer(arg0: $TargetingConditions, arg1: $LivingEntity, arg2: number, arg3: number, arg4: number): $Player;
        getNearestPlayer(arg0: $TargetingConditions, arg1: $LivingEntity): $Player;
        getPlayerByUUID(arg0: $UUID): $Player;
        hasNearbyAlivePlayer(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
        players(): $List<$Player>;
    }

    export class $Explosion {
        constructor(arg0: $Level, arg1: $Entity, arg2: number, arg3: number, arg4: number, arg5: number, arg6: boolean, arg7: $Explosion$BlockInteraction_);
        constructor(arg0: $Level, arg1: $Entity, arg2: number, arg3: number, arg4: number, arg5: number, arg6: boolean, arg7: $Explosion$BlockInteraction_, arg8: ($List<$BlockPos> | ($BlockPos_)[]));
        constructor(arg0: $Level, arg1: $Entity, arg2: number, arg3: number, arg4: number, arg5: number, arg6: ($List<$BlockPos> | ($BlockPos_)[]), arg7: $Explosion$BlockInteraction_, arg8: $ParticleOptions_<$ParticleType_<any>>, arg9: $ParticleOptions_<$ParticleType_<any>>, arg10: $Holder_<$SoundEvent>);
        constructor(arg0: $Level, arg1: $Entity, arg2: $DamageSource, arg3: $ExplosionDamageCalculator, arg4: number, arg5: number, arg6: number, arg7: number, arg8: boolean, arg9: $Explosion$BlockInteraction_, arg10: $ParticleOptions_<$ParticleType_<any>>, arg11: $ParticleOptions_<$ParticleType_<any>>, arg12: $Holder_<$SoundEvent>);
        radius: number;
        get blockInteraction(): $Explosion$BlockInteraction;
        getBlockInteraction(): $Explosion$BlockInteraction;
        get directSourceEntity(): $Entity;
        getDirectSourceEntity(): $Entity;
        get explosionSound(): $Holder<$SoundEvent>;
        getExplosionSound(): $Holder<$SoundEvent>;
        get hitPlayers(): $Map<$Player, $Vec3>;
        getHitPlayers(): $Map<$Player, $Vec3>;
        get indirectSourceEntity(): $LivingEntity;
        getIndirectSourceEntity(): $LivingEntity;
        get largeExplosionParticles(): $ParticleOptions;
        getLargeExplosionParticles(): $ParticleOptions;
        get smallExplosionParticles(): $ParticleOptions;
        getSmallExplosionParticles(): $ParticleOptions;
        get toBlow(): $List<$BlockPos>;
        getToBlow(): $List<$BlockPos>;
        static getDefaultDamageSource(arg0: $Level, arg1: $Entity): $DamageSource;
        static getSeenPercent(arg0: $Vec3_, arg1: $Entity): number;
        canTriggerBlocks(): boolean;
        center(): $Vec3;
        clearToBlow(): void;
        explode(): void;
        finalizeExplosion(arg0: boolean): void;
        interactsWithBlocks(): boolean;
        "radius()"(): number;
    }

    export class $Explosion$BlockInteraction {
        static DESTROY: $Explosion$BlockInteraction;
        static DESTROY_WITH_DECAY: $Explosion$BlockInteraction;
        static KEEP: $Explosion$BlockInteraction;
        static TRIGGER_BLOCK: $Explosion$BlockInteraction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Explosion$BlockInteraction[];
        static valueOf(name: string): $Explosion$BlockInteraction;
    }
    export interface $Explosion$BlockInteraction extends $Enum<$Explosion$BlockInteraction> {}

    export class $ExplosionDamageCalculator {
        constructor();
        getBlockExplosionResistance(arg0: $Explosion, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $BlockState_, arg4: $FluidState): $Optional<number>;
        getEntityDamageAmount(arg0: $Explosion, arg1: $Entity): number;
        getKnockbackMultiplier(arg0: $Entity): number;
        shouldBlockExplode(arg0: $Explosion, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $BlockState_, arg4: number): boolean;
        shouldDamageEntity(arg0: $Explosion, arg1: $Entity): boolean;
    }

    export class $GameRules {
        constructor();
        constructor(arg0: $DynamicLike<any>);
        static DEFAULT_RANDOM_TICK_SPEED: number;
        static RULE_ANNOUNCE_ADVANCEMENTS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_BLOCK_EXPLOSION_DROP_DECAY: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_COMMANDBLOCKOUTPUT: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_COMMAND_MODIFICATION_BLOCK_LIMIT: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_DAYLIGHT: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DISABLE_ELYTRA_MOVEMENT_CHECK: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DISABLE_RAIDS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DOBLOCKDROPS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DOENTITYDROPS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DOFIRETICK: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DOINSOMNIA: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DOMOBLOOT: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DOMOBSPAWNING: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DO_IMMEDIATE_RESPAWN: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DO_PATROL_SPAWNING: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DO_TRADER_SPAWNING: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DO_VINES_SPREAD: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DO_WARDEN_SPAWNING: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_DROWNING_DAMAGE: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_ENDER_PEARLS_VANISH_ON_DEATH: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_FALL_DAMAGE: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_FIRE_DAMAGE: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_FORGIVE_DEAD_PLAYERS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_FREEZE_DAMAGE: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_GLOBAL_SOUND_EVENTS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_KEEPINVENTORY: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_LAVA_SOURCE_CONVERSION: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_LIMITED_CRAFTING: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_LOGADMINCOMMANDS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_MAX_COMMAND_CHAIN_LENGTH: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_MAX_COMMAND_FORK_COUNT: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_MAX_ENTITY_CRAMMING: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_MOBGRIEFING: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_MOB_EXPLOSION_DROP_DECAY: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_NATURAL_REGENERATION: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_PLAYERS_NETHER_PORTAL_CREATIVE_DELAY: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_PLAYERS_NETHER_PORTAL_DEFAULT_DELAY: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_PLAYERS_SLEEPING_PERCENTAGE: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_PROJECTILESCANBREAKBLOCKS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_RANDOMTICKING: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_REDUCEDDEBUGINFO: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_SENDCOMMANDFEEDBACK: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_SHOWDEATHMESSAGES: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_SNOW_ACCUMULATION_HEIGHT: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_SPAWN_CHUNK_RADIUS: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_SPAWN_RADIUS: $GameRules$Key<$GameRules$IntegerValue>;
        static RULE_SPECTATORSGENERATECHUNKS: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_TNT_EXPLOSION_DROP_DECAY: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_UNIVERSAL_ANGER: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_WATER_SOURCE_CONVERSION: $GameRules$Key<$GameRules$BooleanValue>;
        static RULE_WEATHER_CYCLE: $GameRules$Key<$GameRules$BooleanValue>;
        static register<T extends $GameRules$Value<T>>(arg0: string, arg1: $GameRules$Category_, arg2: $GameRules$Type<T>): $GameRules$Key<T>;
        static visitGameRuleTypes(arg0: $GameRules$GameRuleTypeVisitor): void;
        assignFrom(arg0: $GameRules, arg1: $MinecraftServer): void;
        copy(): $GameRules;
        createTag(): $CompoundTag;
        getBoolean(arg0: $GameRules$Key<$GameRules$BooleanValue>): boolean;
        getInt(arg0: $GameRules$Key<$GameRules$IntegerValue>): number;
        getRule<T extends $GameRules$Value<T>>(arg0: $GameRules$Key<T>): T;
    }

    export class $GameRules$BooleanValue extends $GameRules$Value<$GameRules$BooleanValue> {
        constructor(arg0: $GameRules$Type<$GameRules$BooleanValue>, arg1: boolean);
        get commandResult(): number;
        getCommandResult(): number;
        static create(arg0: boolean, arg1: $BiConsumer_<$MinecraftServer, $GameRules$BooleanValue, $MinecraftServer, $GameRules$BooleanValue>): $GameRules$Type<$GameRules$BooleanValue>;
        static create(arg0: boolean): $GameRules$Type<$GameRules$BooleanValue>;
        deserialize(arg0: string): void;
        get(): boolean;
        serialize(): string;
        setFrom(arg0: $GameRules$BooleanValue, arg1: $MinecraftServer): void;
        set(arg0: boolean, arg1: $MinecraftServer): void;
    }

    export class $GameRules$Category {
        static CHAT: $GameRules$Category;
        static DROPS: $GameRules$Category;
        static MISC: $GameRules$Category;
        static MOBS: $GameRules$Category;
        static PLAYER: $GameRules$Category;
        static SPAWNING: $GameRules$Category;
        static UPDATES: $GameRules$Category;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GameRules$Category[];
        static valueOf(name: string): $GameRules$Category;
    }
    export interface $GameRules$Category extends $Enum<$GameRules$Category> {}

    export interface $GameRules$GameRuleTypeVisitor {
        visitBoolean(arg0: $GameRules$Key<$GameRules$BooleanValue>, arg1: $GameRules$Type<$GameRules$BooleanValue>): void;
        visitInteger(arg0: $GameRules$Key<$GameRules$IntegerValue>, arg1: $GameRules$Type<$GameRules$IntegerValue>): void;
        visit<T extends $GameRules$Value<T>>(arg0: $GameRules$Key<T>, arg1: $GameRules$Type<T>): void;
    }

    export class $GameRules$IntegerValue extends $GameRules$Value<$GameRules$IntegerValue> {
        constructor(arg0: $GameRules$Type<$GameRules$IntegerValue>, arg1: number);
        get commandResult(): number;
        getCommandResult(): number;
        static create(arg0: number, arg1: $BiConsumer_<$MinecraftServer, $GameRules$IntegerValue, $MinecraftServer, $GameRules$IntegerValue>): $GameRules$Type<$GameRules$IntegerValue>;
        static create(arg0: number): $GameRules$Type<$GameRules$IntegerValue>;
        deserialize(arg0: string): void;
        get(): number;
        serialize(): string;
        setFrom(arg0: $GameRules$IntegerValue, arg1: $MinecraftServer): void;
        set(arg0: number, arg1: $MinecraftServer): void;
        tryDeserialize(arg0: string): boolean;
    }

    export class $GameRules$Key<T extends $GameRules$Value<T>> {
        constructor(arg0: string, arg1: $GameRules$Category_);
        get category(): $GameRules$Category;
        getCategory(): $GameRules$Category;
        get descriptionId(): string;
        getDescriptionId(): string;
        get id(): string;
        getId(): string;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $GameRules$Type<T extends $GameRules$Value<T>> {
        callVisitor(arg0: $GameRules$GameRuleTypeVisitor, arg1: $GameRules$Key<T>): void;
        createArgument(arg0: string): $RequiredArgumentBuilder<$CommandSourceStack, any>;
        createRule(): T;
    }

    export class $GameRules$Value<T extends $GameRules$Value<T>> {
        constructor(arg0: $GameRules$Type<T>);
        get commandResult(): number;
        getCommandResult(): number;
        deserialize(arg0: string): void;
        onChanged(arg0: $MinecraftServer): void;
        serialize(): string;
        setFromArgument(arg0: $CommandContext<$CommandSourceStack>, arg1: string): void;
        setFrom(arg0: T, arg1: $MinecraftServer): void;
        toString(): string;
    }

    export class $GameType {
        static ADVENTURE: $GameType;
        static CREATIVE: $GameType;
        static SPECTATOR: $GameType;
        static SURVIVAL: $GameType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GameType[];
        static valueOf(name: string): $GameType;
    }
    export interface $GameType extends $Enum<$GameType>, $StringRepresentable {}

    export interface $ItemLike {
        asItem(): $Item;
    }

    export class $Level extends $AttachmentHolder implements $LevelAccessor, $AutoCloseable, $ILevelExtension, $LevelExtension {
        static END: $ResourceKey<$Level>;
        static LONG_PARTICLE_CLIP_RANGE: number;
        static MAX_BRIGHTNESS: number;
        static MAX_ENTITY_SPAWN_Y: number;
        static MAX_LEVEL_SIZE: number;
        static MIN_ENTITY_SPAWN_Y: number;
        static NETHER: $ResourceKey<$Level>;
        static OVERWORLD: $ResourceKey<$Level>;
        static RESOURCE_KEY_CODEC: $Codec<$ResourceKey<$Level>>;
        static SHORT_PARTICLE_CLIP_RANGE: number;
        static TICKS_PER_DAY: number;
        captureBlockSnapshots: boolean;
        capturedBlockSnapshots: $ArrayList<$BlockSnapshot>;
        isClientSide: boolean;
        oRainLevel: number;
        oThunderLevel: number;
        rainLevel: number;
        get random(): $RandomSource;
        restoringBlockSnapshots: boolean;
        thunderLevel: number;
        get biomeManager(): $BiomeManager;
        getBiomeManager(): $BiomeManager;
        get blockTicks(): $LevelTickAccess<$Block>;
        getBlockTicks(): $LevelTickAccess<$Block>;
        get chunkSource(): $ChunkSource;
        getChunkSource(): $ChunkSource;
        get dayTimeFraction(): number;
        getDayTimeFraction(): number;
        set dayTimeFraction(value: number);
        get dayTimePerTick(): number;
        getDayTimePerTick(): number;
        set dayTimePerTick(value: number);
        getDayTime(): number;
        get descriptionKey(): string;
        getDescriptionKey(): string;
        get description(): $Component;
        getDescription(): $Component;
        get difficulty(): $Difficulty;
        getDifficulty(): $Difficulty;
        get fluidTicks(): $LevelTickAccess<$Fluid>;
        getFluidTicks(): $LevelTickAccess<$Fluid>;
        get freeMapId(): $MapId;
        getFreeMapId(): $MapId;
        get gameRules(): $GameRules;
        getGameRules(): $GameRules;
        get gameTime(): number;
        getGameTime(): number;
        get height(): number;
        getHeight(): number;
        get levelData(): $LevelData;
        getLevelData(): $LevelData;
        get lightEngine(): $LevelLightEngine;
        getLightEngine(): $LevelLightEngine;
        get maxBuildHeight(): number;
        getMaxBuildHeight(): number;
        get maxEntityRadius(): number;
        getMaxEntityRadius(): number;
        get maxLightLevel(): number;
        getMaxLightLevel(): number;
        get maxSection(): number;
        getMaxSection(): number;
        get minBuildHeight(): number;
        getMinBuildHeight(): number;
        get minSection(): number;
        getMinSection(): number;
        get modelDataManager(): $ModelDataManager;
        getModelDataManager(): $ModelDataManager;
        get moonBrightness(): number;
        getMoonBrightness(): number;
        get moonPhase(): number;
        getMoonPhase(): number;
        get partEntities(): $Collection<$PartEntity<any>>;
        getPartEntities(): $Collection<$PartEntity<any>>;
        get profilerSupplier(): $Supplier<$ProfilerFiller>;
        getProfilerSupplier(): $Supplier<$ProfilerFiller>;
        get profiler(): $ProfilerFiller;
        getProfiler(): $ProfilerFiller;
        getRandom(): $RandomSource;
        get recipeManager(): $RecipeManager;
        getRecipeManager(): $RecipeManager;
        get scoreboard(): $Scoreboard;
        getScoreboard(): $Scoreboard;
        get seaLevel(): number;
        getSeaLevel(): number;
        get sectionsCount(): number;
        getSectionsCount(): number;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get sharedSpawnAngle(): number;
        getSharedSpawnAngle(): number;
        get sharedSpawnPos(): $BlockPos;
        getSharedSpawnPos(): $BlockPos;
        get skyDarken(): number;
        getSkyDarken(): number;
        get worldBorder(): $WorldBorder;
        getWorldBorder(): $WorldBorder;
        get clientSide(): boolean;
        "isClientSide()"(): boolean;
        get day(): boolean;
        isDay(): boolean;
        get debug(): boolean;
        isDebug(): boolean;
        get night(): boolean;
        isNight(): boolean;
        get raining(): boolean;
        isRaining(): boolean;
        set raining(value: boolean);
        get thundering(): boolean;
        isThundering(): boolean;
        get id(): string;
        getId(): string;
        getPlayers(): $List<$Player>;
        get time(): number;
        getTime(): number;
        set time(value: number);
        static isInSpawnableBounds(arg0: $BlockPos_): boolean;
        addAlwaysVisibleParticle(arg0: $ParticleOptions_<$ParticleType_<any>>, arg1: boolean, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): void;
        addAlwaysVisibleParticle(arg0: $ParticleOptions_<$ParticleType_<any>>, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): void;
        addBlockEntityTicker(arg0: $TickingBlockEntity): void;
        addDestroyBlockEffect(arg0: $BlockPos_, arg1: $BlockState_): void;
        addFreshBlockEntities(arg0: ($Collection<$BlockEntity> | ($BlockEntity)[])): void;
        addFreshEntity(arg0: $Entity): boolean;
        addParticle(arg0: $ParticleOptions_<$ParticleType_<any>>, arg1: boolean, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): void;
        addParticle(arg0: $ParticleOptions_<$ParticleType_<any>>, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): void;
        blockEntityChanged(arg0: $BlockPos_): void;
        blockEvent(arg0: $BlockPos_, arg1: $Block_, arg2: number, arg3: number): void;
        blockUpdated(arg0: $BlockPos_, arg1: $Block_): void;
        broadcastDamageEvent(arg0: $Entity, arg1: $DamageSource): void;
        broadcastEntityEvent(arg0: $Entity, arg1: number): void;
        canSeeSkyFromBelowWater(arg0: $BlockPos_): boolean;
        canSeeSky(arg0: $BlockPos_): boolean;
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        close(): void;
        collidesWithSuffocatingBlock(arg0: $Entity, arg1: $AABB): boolean;
        containsAnyLiquid(arg0: $AABB): boolean;
        createFireworks(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: ($List<$FireworkExplosion> | ($FireworkExplosion)[])): void;
        damageSources(): $DamageSources;
        dayTime(): number;
        destroyBlockProgress(arg0: number, arg1: $BlockPos_, arg2: number): void;
        destroyBlock(arg0: $BlockPos_, arg1: boolean, arg2: $Entity, arg3: number): boolean;
        destroyBlock(arg0: $BlockPos_, arg1: boolean, arg2: $Entity): boolean;
        destroyBlock(arg0: $BlockPos_, arg1: boolean): boolean;
        dimensionTypeRegistration(): $Holder<$DimensionType>;
        dimensionType(): $DimensionType;
        dimension(): $ResourceKey<$Level>;
        disconnect(): void;
        enabledFeatures(): $FeatureFlagSet;
        explode(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: number, arg5: boolean, arg6: $Level$ExplosionInteraction_): $Explosion;
        explode(arg0: $Entity, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $Level$ExplosionInteraction_): $Explosion;
        explode(arg0: $Entity, arg1: $DamageSource, arg2: $ExplosionDamageCalculator, arg3: number, arg4: number, arg5: number, arg6: number, arg7: boolean, arg8: $Level$ExplosionInteraction_, arg9: boolean, arg10: $ParticleOptions_<$ParticleType_<any>>, arg11: $ParticleOptions_<$ParticleType_<any>>, arg12: $Holder_<$SoundEvent>): $Explosion;
        explode(arg0: $Entity, arg1: $DamageSource, arg2: $ExplosionDamageCalculator, arg3: number, arg4: number, arg5: number, arg6: number, arg7: boolean, arg8: $Level$ExplosionInteraction_, arg9: $ParticleOptions_<$ParticleType_<any>>, arg10: $ParticleOptions_<$ParticleType_<any>>, arg11: $Holder_<$SoundEvent>): $Explosion;
        explode(arg0: $Entity, arg1: $DamageSource, arg2: $ExplosionDamageCalculator, arg3: number, arg4: number, arg5: number, arg6: number, arg7: boolean, arg8: $Level$ExplosionInteraction_): $Explosion;
        explode(arg0: $Entity, arg1: $DamageSource, arg2: $ExplosionDamageCalculator, arg3: $Vec3_, arg4: number, arg5: boolean, arg6: $Level$ExplosionInteraction_): $Explosion;
        fillReportDetails(arg0: $CrashReport): $CrashReportCategory;
        findFreePosition(arg0: $Entity, arg1: $VoxelShape, arg2: $Vec3_, arg3: number, arg4: number, arg5: number): $Optional<$Vec3>;
        findSupportingBlock(arg0: $Entity, arg1: $AABB): $Optional<$BlockPos>;
        gameEvent(arg0: $Holder_<$GameEvent>, arg1: $BlockPos_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $Holder_<$GameEvent>, arg1: $Vec3_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $ResourceKey<$GameEvent>, arg1: $BlockPos_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $Entity, arg1: $Holder_<$GameEvent>, arg2: $BlockPos_): void;
        gameEvent(arg0: $Entity, arg1: $Holder_<$GameEvent>, arg2: $Vec3_): void;
        gatherChunkSourceStats(): string;
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getBestNeighborSignal(arg0: $BlockPos_): number;
        getBiome(arg0: $BlockPos_): $Holder<$Biome>;
        getBlockCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockRandomPos(arg0: number, arg1: number, arg2: number, arg3: number): $BlockPos;
        getBlockStatesIfLoaded(arg0: $AABB): $Stream<$BlockState>;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getBlockTint(arg0: $BlockPos_, arg1: $ColorResolver_<$Biome, number, number, number>): number;
        getBrightness(arg0: $LightLayer_, arg1: $BlockPos_): number;
        getCapability<T, C>(arg0: $BlockCapability<T, C>, arg1: $BlockPos_, arg2: C): T;
        getCapability<T, C>(arg0: $BlockCapability<T, C>, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity, arg4: C): T;
        getCapability<T>(arg0: $BlockCapability<T, void>, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity): T;
        getCapability<T>(arg0: $BlockCapability<T, void>, arg1: $BlockPos_): T;
        getChunkAt(arg0: $BlockPos_): $LevelChunk;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_, arg3: boolean): $ChunkAccess;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_): $ChunkAccess;
        getChunk(arg0: number, arg1: number): $LevelChunk;
        getChunk(arg0: $BlockPos_): $ChunkAccess;
        getCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getControlInputSignal(arg0: $BlockPos_, arg1: $Direction_, arg2: boolean): number;
        getCurrentDifficultyAt(arg0: $BlockPos_): $DifficultyInstance;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getDirectSignalTo(arg0: $BlockPos_): number;
        getDirectSignal(arg0: $BlockPos_, arg1: $Direction_): number;
        getEntitiesOfClass<T extends $Entity>(arg0: $Class<T>, arg1: $AABB, arg2: $Predicate_<T, T, boolean>): $List<T>;
        getEntitiesOfClass<T extends $Entity>(arg0: $Class<T>, arg1: $AABB): $List<T>;
        getEntities(arg0: $Entity, arg1: $AABB, arg2: $Predicate_<$Entity, $Entity, boolean>): $List<$Entity>;
        getEntities(arg0: $Entity, arg1: $AABB): $List<$Entity>;
        getEntities<T extends $Entity>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate_<T, T, boolean>, arg3: ($List<any> | (any)[]), arg4: number): void;
        getEntities<T extends $Entity>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate_<T, T, boolean>, arg3: ($List<any> | (any)[])): void;
        getEntities<T extends $Entity>(arg0: $EntityTypeTest<$Entity, T>, arg1: $AABB, arg2: $Predicate_<T, T, boolean>): $List<T>;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getEntity(arg0: number): $Entity;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getHeightmapPos(arg0: $Heightmap$Types_, arg1: $BlockPos_): $BlockPos;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getLightEmission(arg0: $BlockPos_): number;
        getLightLevelDependentMagicValue(arg0: $BlockPos_): number;
        getMapData(arg0: $MapId): $MapItemSavedData;
        getMaxLocalRawBrightness(arg0: $BlockPos_, arg1: number): number;
        getMaxLocalRawBrightness(arg0: $BlockPos_): number;
        getModelData(arg0: $BlockPos_): $ModelData;
        getNearbyEntities<T extends $LivingEntity>(arg0: $Class<T>, arg1: $TargetingConditions, arg2: $LivingEntity, arg3: $AABB): $List<T>;
        getNearbyPlayers(arg0: $TargetingConditions, arg1: $LivingEntity, arg2: $AABB): $List<$Player>;
        getNearestEntity<T extends $LivingEntity>(arg0: $Class<T>, arg1: $TargetingConditions, arg2: $LivingEntity, arg3: number, arg4: number, arg5: number, arg6: $AABB): T;
        getNearestEntity<T extends $LivingEntity>(arg0: ($List<T> | (T)[]), arg1: $TargetingConditions, arg2: $LivingEntity, arg3: number, arg4: number, arg5: number): T;
        getNearestPlayer(arg0: number, arg1: number, arg2: number, arg3: number, arg4: boolean): $Player;
        getNearestPlayer(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $Predicate_<$Entity, $Entity, boolean>): $Player;
        getNearestPlayer(arg0: $Entity, arg1: number): $Player;
        getNearestPlayer(arg0: $TargetingConditions, arg1: number, arg2: number, arg3: number): $Player;
        getNearestPlayer(arg0: $TargetingConditions, arg1: $LivingEntity, arg2: number, arg3: number, arg4: number): $Player;
        getNearestPlayer(arg0: $TargetingConditions, arg1: $LivingEntity): $Player;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getPathfindingCostFromLightLevels(arg0: $BlockPos_): number;
        getPlayerByUUID(arg0: $UUID): $Player;
        getRainLevel(arg0: number): number;
        getRawBrightness(arg0: $BlockPos_, arg1: number): number;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        getShade(arg0: number, arg1: number, arg2: number, arg3: boolean): number;
        getShade(arg0: $Direction_, arg1: boolean): number;
        getSignal(arg0: $BlockPos_, arg1: $Direction_): number;
        getSunAngle(arg0: number): number;
        getThunderLevel(arg0: number): number;
        getTimeOfDay(arg0: number): number;
        getUncachedNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        globalLevelEvent(arg0: number, arg1: $BlockPos_, arg2: number): void;
        guardEntityTick<T extends $Entity>(arg0: $Consumer_<T, T>, arg1: T): void;
        hasChunkAt(arg0: number, arg1: number): boolean;
        hasChunkAt(arg0: $BlockPos_): boolean;
        hasChunksAt(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): boolean;
        hasChunksAt(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        hasChunksAt(arg0: $BlockPos_, arg1: $BlockPos_): boolean;
        hasChunk(arg0: number, arg1: number): boolean;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        hasNearbyAlivePlayer(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        hasNeighborSignal(arg0: $BlockPos_): boolean;
        hasSignal(arg0: $BlockPos_, arg1: $Direction_): boolean;
        holderLookup<T>(arg0: $ResourceKey<$Registry<T>>): $HolderLookup<T>;
        holderOrThrow<T>(arg0: $ResourceKey<T>): $Holder<T>;
        holder<T>(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        increaseMaxEntityRadius(arg0: number): number;
        invalidateCapabilities(arg0: $BlockPos_): void;
        invalidateCapabilities(arg0: $ChunkPos): void;
        isAreaLoaded(arg0: $BlockPos_, arg1: number): boolean;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        isEmptyBlock(arg0: $BlockPos_): boolean;
        isFluidAtPosition(arg0: $BlockPos_, arg1: $Predicate_<$FluidState, $FluidState, boolean>): boolean;
        isInWorldBounds(arg0: $BlockPos_): boolean;
        isLoaded(arg0: $BlockPos_): boolean;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
        isRainingAt(arg0: $BlockPos_): boolean;
        isStateAtPosition(arg0: $BlockPos_, arg1: $Predicate_<$BlockState, $BlockState, boolean>): boolean;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
        isUnobstructed(arg0: $Entity): boolean;
        isUnobstructed(arg0: $BlockState_, arg1: $BlockPos_, arg2: $CollisionContext): boolean;
        isWaterAt(arg0: $BlockPos_): boolean;
        levelEvent(arg0: number, arg1: $BlockPos_, arg2: number): void;
        levelEvent(arg0: $Player, arg1: number, arg2: $BlockPos_, arg3: number): void;
        loadedAndEntityCanStandOnFace(arg0: $BlockPos_, arg1: $Entity, arg2: $Direction_): boolean;
        loadedAndEntityCanStandOn(arg0: $BlockPos_, arg1: $Entity): boolean;
        markAndNotifyBlock(arg0: $BlockPos_, arg1: $LevelChunk, arg2: $BlockState_, arg3: $BlockState_, arg4: number, arg5: number): void;
        mayInteract(arg0: $Player, arg1: $BlockPos_): boolean;
        neighborChanged(arg0: $BlockPos_, arg1: $Block_, arg2: $BlockPos_): void;
        neighborChanged(arg0: $BlockState_, arg1: $BlockPos_, arg2: $Block_, arg3: $BlockPos_, arg4: boolean): void;
        neighborShapeChanged(arg0: $Direction_, arg1: $BlockState_, arg2: $BlockPos_, arg3: $BlockPos_, arg4: number, arg5: number): void;
        data(): $AttachedData<$Level>;
        getBlockState(x: number, y: number, z: number): $BlockState;
        isDay(): boolean;
        isRaining(): boolean;
        setBlock(x: number, y: number, z: number, block: unknown): boolean;
        setRaining(raining: boolean): void;
        setTime(time: number): void;
        spawnEntity(type: $EntityType_<any>, x: number, y: number, z: number): $Entity;
        spawnLightning(x: number, y: number, z: number): $Entity;
        nextSubTickCount(): number;
        noBlockCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity): boolean;
        noCollision(arg0: $AABB): boolean;
        "noSave()"(): boolean;
        onBlockStateChange(arg0: $BlockPos_, arg1: $BlockState_, arg2: $BlockState_): void;
        playLocalSound(arg0: number, arg1: number, arg2: number, arg3: $SoundEvent_, arg4: $SoundSource_, arg5: number, arg6: number, arg7: boolean): void;
        playLocalSound(arg0: $BlockPos_, arg1: $SoundEvent_, arg2: $SoundSource_, arg3: number, arg4: number, arg5: boolean): void;
        playLocalSound(arg0: $Entity, arg1: $SoundEvent_, arg2: $SoundSource_, arg3: number, arg4: number): void;
        playSeededSound(arg0: $Player, arg1: number, arg2: number, arg3: number, arg4: $Holder_<$SoundEvent>, arg5: $SoundSource_, arg6: number, arg7: number, arg8: number): void;
        playSeededSound(arg0: $Player, arg1: number, arg2: number, arg3: number, arg4: $SoundEvent_, arg5: $SoundSource_, arg6: number, arg7: number, arg8: number): void;
        playSeededSound(arg0: $Player, arg1: $Entity, arg2: $Holder_<$SoundEvent>, arg3: $SoundSource_, arg4: number, arg5: number, arg6: number): void;
        playSound(arg0: $Entity, arg1: $BlockPos_, arg2: $SoundEvent_, arg3: $SoundSource_, arg4: number, arg5: number): void;
        playSound(arg0: $Player, arg1: number, arg2: number, arg3: number, arg4: $Holder_<$SoundEvent>, arg5: $SoundSource_, arg6: number, arg7: number): void;
        playSound(arg0: $Player, arg1: number, arg2: number, arg3: number, arg4: $SoundEvent_, arg5: $SoundSource_, arg6: number, arg7: number): void;
        playSound(arg0: $Player, arg1: number, arg2: number, arg3: number, arg4: $SoundEvent_, arg5: $SoundSource_): void;
        playSound(arg0: $Player, arg1: $BlockPos_, arg2: $SoundEvent_, arg3: $SoundSource_, arg4: number, arg5: number): void;
        playSound(arg0: $Player, arg1: $BlockPos_, arg2: $SoundEvent_, arg3: $SoundSource_): void;
        playSound(arg0: $Player, arg1: $Entity, arg2: $SoundEvent_, arg3: $SoundSource_, arg4: number, arg5: number): void;
        players(): $List<$Player>;
        potionBrewing(): $PotionBrewing;
        registryAccess(): $RegistryAccess;
        removeBlockEntity(arg0: $BlockPos_): void;
        removeBlock(arg0: $BlockPos_, arg1: boolean): boolean;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        scheduleTick(arg0: $BlockPos_, arg1: $Block_, arg2: number, arg3: $TickPriority_): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Block_, arg2: number): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Fluid_, arg2: number, arg3: $TickPriority_): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Fluid_, arg2: number): void;
        sendBlockUpdated(arg0: $BlockPos_, arg1: $BlockState_, arg2: $BlockState_, arg3: number): void;
        sendPacketToServer(arg0: $Packet<any>): void;
        setBlockAndUpdate(arg0: $BlockPos_, arg1: $BlockState_): boolean;
        setBlockEntity(arg0: $BlockEntity): void;
        setBlocksDirty(arg0: $BlockPos_, arg1: $BlockState_, arg2: $BlockState_): void;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_, arg2: number, arg3: number): boolean;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_, arg2: number): boolean;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        setDayTimeFraction(arg0: number): void;
        setDayTimePerTick(arg0: number): void;
        setMapData(arg0: $MapId, arg1: $MapItemSavedData): void;
        setRainLevel(arg0: number): void;
        setSkyFlashTime(arg0: number): void;
        setSpawnSettings(arg0: boolean, arg1: boolean): void;
        setThunderLevel(arg0: number): void;
        shouldTickBlocksAt(arg0: number): boolean;
        shouldTickBlocksAt(arg0: $BlockPos_): boolean;
        shouldTickDeath(arg0: $Entity): boolean;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
        tickRateManager(): $TickRateManager;
        updateNeighborsAtExceptFromFacing(arg0: $BlockPos_, arg1: $Block_, arg2: $Direction_): void;
        updateNeighborsAt(arg0: $BlockPos_, arg1: $Block_): void;
        updateNeighbourForOutputSignal(arg0: $BlockPos_, arg1: $Block_): void;
        updateSkyBrightness(): void;
    }

    export class $Level$ExplosionInteraction {
        static BLOCK: $Level$ExplosionInteraction;
        static MOB: $Level$ExplosionInteraction;
        static NONE: $Level$ExplosionInteraction;
        static TNT: $Level$ExplosionInteraction;
        static TRIGGER: $Level$ExplosionInteraction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Level$ExplosionInteraction[];
        static valueOf(name: string): $Level$ExplosionInteraction;
    }
    export interface $Level$ExplosionInteraction extends $Enum<$Level$ExplosionInteraction>, $StringRepresentable {}

    export interface $LevelAccessor extends $CommonLevelAccessor, $LevelTimeAccess {
        addParticle(arg0: $ParticleOptions_<$ParticleType_<any>>, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): void;
        blockUpdated(arg0: $BlockPos_, arg1: $Block_): void;
        canSeeSkyFromBelowWater(arg0: $BlockPos_): boolean;
        canSeeSky(arg0: $BlockPos_): boolean;
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        collidesWithSuffocatingBlock(arg0: $Entity, arg1: $AABB): boolean;
        containsAnyLiquid(arg0: $AABB): boolean;
        dayTime(): number;
        dimensionType(): $DimensionType;
        enabledFeatures(): $FeatureFlagSet;
        findFreePosition(arg0: $Entity, arg1: $VoxelShape, arg2: $Vec3_, arg3: number, arg4: number, arg5: number): $Optional<$Vec3>;
        findSupportingBlock(arg0: $Entity, arg1: $AABB): $Optional<$BlockPos>;
        gameEvent(arg0: $Holder_<$GameEvent>, arg1: $BlockPos_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $Holder_<$GameEvent>, arg1: $Vec3_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $ResourceKey<$GameEvent>, arg1: $BlockPos_, arg2: $GameEvent$Context): void;
        gameEvent(arg0: $Entity, arg1: $Holder_<$GameEvent>, arg2: $BlockPos_): void;
        gameEvent(arg0: $Entity, arg1: $Holder_<$GameEvent>, arg2: $Vec3_): void;
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getBestNeighborSignal(arg0: $BlockPos_): number;
        getBiomeManager(): $BiomeManager;
        getBiome(arg0: $BlockPos_): $Holder<$Biome>;
        getBlockCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStatesIfLoaded(arg0: $AABB): $Stream<$BlockState>;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getBlockTicks(): $LevelTickAccess<$Block>;
        getBlockTint(arg0: $BlockPos_, arg1: $ColorResolver_<$Biome, number, number, number>): number;
        getBrightness(arg0: $LightLayer_, arg1: $BlockPos_): number;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getChunkSource(): $ChunkSource;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_, arg3: boolean): $ChunkAccess;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_): $ChunkAccess;
        getChunk(arg0: number, arg1: number): $ChunkAccess;
        getChunk(arg0: $BlockPos_): $ChunkAccess;
        getCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getControlInputSignal(arg0: $BlockPos_, arg1: $Direction_, arg2: boolean): number;
        getCurrentDifficultyAt(arg0: $BlockPos_): $DifficultyInstance;
        getDifficulty(): $Difficulty;
        getDirectSignalTo(arg0: $BlockPos_): number;
        getDirectSignal(arg0: $BlockPos_, arg1: $Direction_): number;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getFluidTicks(): $LevelTickAccess<$Fluid>;
        getHeightmapPos(arg0: $Heightmap$Types_, arg1: $BlockPos_): $BlockPos;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getHeight(): number;
        getLevelData(): $LevelData;
        getLightEmission(arg0: $BlockPos_): number;
        getLightEngine(): $LevelLightEngine;
        getLightLevelDependentMagicValue(arg0: $BlockPos_): number;
        getMaxBuildHeight(): number;
        getMaxLightLevel(): number;
        getMaxLocalRawBrightness(arg0: $BlockPos_, arg1: number): number;
        getMaxLocalRawBrightness(arg0: $BlockPos_): number;
        getMaxSection(): number;
        getMinBuildHeight(): number;
        getMinSection(): number;
        getModelData(arg0: $BlockPos_): $ModelData;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getPathfindingCostFromLightLevels(arg0: $BlockPos_): number;
        getRandom(): $RandomSource;
        getRawBrightness(arg0: $BlockPos_, arg1: number): number;
        getSeaLevel(): number;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        getSectionsCount(): number;
        getServer(): $MinecraftServer;
        getShade(arg0: number, arg1: number, arg2: number, arg3: boolean): number;
        getShade(arg0: $Direction_, arg1: boolean): number;
        getSignal(arg0: $BlockPos_, arg1: $Direction_): number;
        getSkyDarken(): number;
        getUncachedNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getWorldBorder(): $WorldBorder;
        hasChunkAt(arg0: number, arg1: number): boolean;
        hasChunkAt(arg0: $BlockPos_): boolean;
        hasChunksAt(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): boolean;
        hasChunksAt(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        hasChunksAt(arg0: $BlockPos_, arg1: $BlockPos_): boolean;
        hasChunk(arg0: number, arg1: number): boolean;
        hasNeighborSignal(arg0: $BlockPos_): boolean;
        hasSignal(arg0: $BlockPos_, arg1: $Direction_): boolean;
        holderLookup<T>(arg0: $ResourceKey<$Registry<T>>): $HolderLookup<T>;
        holderOrThrow<T>(arg0: $ResourceKey<T>): $Holder<T>;
        holder<T>(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        isAreaLoaded(arg0: $BlockPos_, arg1: number): boolean;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        "isClientSide()"(): boolean;
        isEmptyBlock(arg0: $BlockPos_): boolean;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
        isUnobstructed(arg0: $Entity): boolean;
        isUnobstructed(arg0: $BlockState_, arg1: $BlockPos_, arg2: $CollisionContext): boolean;
        isWaterAt(arg0: $BlockPos_): boolean;
        levelEvent(arg0: number, arg1: $BlockPos_, arg2: number): void;
        levelEvent(arg0: $Player, arg1: number, arg2: $BlockPos_, arg3: number): void;
        neighborShapeChanged(arg0: $Direction_, arg1: $BlockState_, arg2: $BlockPos_, arg3: $BlockPos_, arg4: number, arg5: number): void;
        nextSubTickCount(): number;
        noBlockCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity): boolean;
        noCollision(arg0: $AABB): boolean;
        playSound(arg0: $Player, arg1: $BlockPos_, arg2: $SoundEvent_, arg3: $SoundSource_, arg4: number, arg5: number): void;
        playSound(arg0: $Player, arg1: $BlockPos_, arg2: $SoundEvent_, arg3: $SoundSource_): void;
        registryAccess(): $RegistryAccess;
        scheduleTick(arg0: $BlockPos_, arg1: $Block_, arg2: number, arg3: $TickPriority_): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Block_, arg2: number): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Fluid_, arg2: number, arg3: $TickPriority_): void;
        scheduleTick(arg0: $BlockPos_, arg1: $Fluid_, arg2: number): void;
    }

    export interface $LevelHeightAccessor {
        getHeight(): number;
        getMaxBuildHeight(): number;
        getMaxSection(): number;
        getMinBuildHeight(): number;
        getMinSection(): number;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        getSectionsCount(): number;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
    }
    export const $LevelHeightAccessor: {
        create(arg0: number, arg1: number): $LevelHeightAccessor;
    };

    export interface $LevelReader extends $BlockAndTintGetter, $CollisionGetter, $SignalGetter, $BiomeManager$NoiseBiomeSource, $ILevelReaderExtension {
        canSeeSkyFromBelowWater(arg0: $BlockPos_): boolean;
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        containsAnyLiquid(arg0: $AABB): boolean;
        dimensionType(): $DimensionType;
        enabledFeatures(): $FeatureFlagSet;
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getBiomeManager(): $BiomeManager;
        getBiome(arg0: $BlockPos_): $Holder<$Biome>;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStatesIfLoaded(arg0: $AABB): $Stream<$BlockState>;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getBlockTint(arg0: $BlockPos_, arg1: $ColorResolver_<$Biome, number, number, number>): number;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_, arg3: boolean): $ChunkAccess;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_): $ChunkAccess;
        getChunk(arg0: number, arg1: number): $ChunkAccess;
        getChunk(arg0: $BlockPos_): $ChunkAccess;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getHeightmapPos(arg0: $Heightmap$Types_, arg1: $BlockPos_): $BlockPos;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getHeight(): number;
        getLightEmission(arg0: $BlockPos_): number;
        getLightLevelDependentMagicValue(arg0: $BlockPos_): number;
        getMaxBuildHeight(): number;
        getMaxLightLevel(): number;
        getMaxLocalRawBrightness(arg0: $BlockPos_, arg1: number): number;
        getMaxLocalRawBrightness(arg0: $BlockPos_): number;
        getMaxSection(): number;
        getMinBuildHeight(): number;
        getMinSection(): number;
        getModelData(arg0: $BlockPos_): $ModelData;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getPathfindingCostFromLightLevels(arg0: $BlockPos_): number;
        getSeaLevel(): number;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        getSectionsCount(): number;
        getSkyDarken(): number;
        getUncachedNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        hasChunkAt(arg0: number, arg1: number): boolean;
        hasChunkAt(arg0: $BlockPos_): boolean;
        hasChunksAt(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): boolean;
        hasChunksAt(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        hasChunksAt(arg0: $BlockPos_, arg1: $BlockPos_): boolean;
        hasChunk(arg0: number, arg1: number): boolean;
        holderLookup<T>(arg0: $ResourceKey<$Registry<T>>): $HolderLookup<T>;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        "isClientSide()"(): boolean;
        isEmptyBlock(arg0: $BlockPos_): boolean;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
        isWaterAt(arg0: $BlockPos_): boolean;
        registryAccess(): $RegistryAccess;
    }

    export class $LevelSettings {
        constructor(arg0: string, arg1: $GameType_, arg2: boolean, arg3: $Difficulty_, arg4: boolean, arg5: $GameRules, arg6: $WorldDataConfiguration);
        constructor(arg0: string, arg1: $GameType_, arg2: boolean, arg3: $Difficulty_, arg4: boolean, arg5: $GameRules, arg6: $WorldDataConfiguration, arg7: $Lifecycle);
        get dataConfiguration(): $WorldDataConfiguration;
        getDataConfiguration(): $WorldDataConfiguration;
        get lifecycle(): $Lifecycle;
        getLifecycle(): $Lifecycle;
        static parse(arg0: $Dynamic<any>, arg1: $WorldDataConfiguration): $LevelSettings;
        allowCommands(): boolean;
        copy(): $LevelSettings;
        difficulty(): $Difficulty;
        gameRules(): $GameRules;
        gameType(): $GameType;
        hardcore(): boolean;
        levelName(): string;
        withDataConfiguration(arg0: $WorldDataConfiguration): $LevelSettings;
        withDifficulty(arg0: $Difficulty_): $LevelSettings;
        withGameType(arg0: $GameType_): $LevelSettings;
        withLifecycle(arg0: $Lifecycle): $LevelSettings;
    }

    export interface $LevelSimulatedRW extends $LevelSimulatedReader, $LevelWriter {
    }

    export interface $LevelSimulatedReader {
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getHeightmapPos(arg0: $Heightmap$Types_, arg1: $BlockPos_): $BlockPos;
        isFluidAtPosition(arg0: $BlockPos_, arg1: $Predicate_<$FluidState, $FluidState, boolean>): boolean;
        isStateAtPosition(arg0: $BlockPos_, arg1: $Predicate_<$BlockState, $BlockState, boolean>): boolean;
    }

    export interface $LevelTimeAccess extends $LevelReader {
        dayTime(): number;
        getMoonBrightness(): number;
        getMoonPhase(): number;
        getTimeOfDay(arg0: number): number;
    }

    export interface $LevelWriter {
        addFreshEntity(arg0: $Entity): boolean;
        destroyBlock(arg0: $BlockPos_, arg1: boolean, arg2: $Entity, arg3: number): boolean;
        destroyBlock(arg0: $BlockPos_, arg1: boolean, arg2: $Entity): boolean;
        destroyBlock(arg0: $BlockPos_, arg1: boolean): boolean;
        removeBlock(arg0: $BlockPos_, arg1: boolean): boolean;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_, arg2: number, arg3: number): boolean;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_, arg2: number): boolean;
    }

    export class $LightLayer {
        static BLOCK: $LightLayer;
        static SKY: $LightLayer;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LightLayer[];
        static valueOf(name: string): $LightLayer;
    }
    export interface $LightLayer extends $Enum<$LightLayer> {}

    export class $NaturalSpawner$SpawnState {
        get mobCategoryCounts(): $Object2IntMap<$MobCategory>;
        getMobCategoryCounts(): $Object2IntMap<$MobCategory>;
        get spawnableChunkCount(): number;
        getSpawnableChunkCount(): number;
    }

    export class $NoiseColumn implements $BlockColumn {
        constructor(arg0: number, arg1: $BlockState_[]);
        getBlock(arg0: number): $BlockState;
        setBlock(arg0: number, arg1: $BlockState_): void;
    }

    export class $PathNavigationRegion implements $BlockGetter, $CollisionGetter {
        constructor(arg0: $Level, arg1: $BlockPos_, arg2: $BlockPos_);
        get height(): number;
        getHeight(): number;
        get maxBuildHeight(): number;
        getMaxBuildHeight(): number;
        get maxLightLevel(): number;
        getMaxLightLevel(): number;
        get maxSection(): number;
        getMaxSection(): number;
        get minBuildHeight(): number;
        getMinBuildHeight(): number;
        get minSection(): number;
        getMinSection(): number;
        get profiler(): $ProfilerFiller;
        getProfiler(): $ProfilerFiller;
        get sectionsCount(): number;
        getSectionsCount(): number;
        get worldBorder(): $WorldBorder;
        getWorldBorder(): $WorldBorder;
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        collidesWithSuffocatingBlock(arg0: $Entity, arg1: $AABB): boolean;
        findFreePosition(arg0: $Entity, arg1: $VoxelShape, arg2: $Vec3_, arg3: number, arg4: number, arg5: number): $Optional<$Vec3>;
        findSupportingBlock(arg0: $Entity, arg1: $AABB): $Optional<$BlockPos>;
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getBlockCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getChunkForCollisions(arg0: number, arg1: number): $BlockGetter;
        getCollisions(arg0: $Entity, arg1: $AABB): $Iterable<$VoxelShape>;
        getEntityCollisions(arg0: $Entity, arg1: $AABB): $List<$VoxelShape>;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getLightEmission(arg0: $BlockPos_): number;
        getModelData(arg0: $BlockPos_): $ModelData;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
        isUnobstructed(arg0: $Entity, arg1: $VoxelShape): boolean;
        isUnobstructed(arg0: $Entity): boolean;
        isUnobstructed(arg0: $BlockState_, arg1: $BlockPos_, arg2: $CollisionContext): boolean;
        noBlockCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity, arg1: $AABB): boolean;
        noCollision(arg0: $Entity): boolean;
        noCollision(arg0: $AABB): boolean;
    }

    export interface $ServerLevelAccessor extends $LevelAccessor {
        addFreshEntityWithPassengers(arg0: $Entity): void;
        getLevel(): $ServerLevel;
    }

    export interface $SignalGetter extends $BlockGetter {
        getBestNeighborSignal(arg0: $BlockPos_): number;
        getControlInputSignal(arg0: $BlockPos_, arg1: $Direction_, arg2: boolean): number;
        getDirectSignalTo(arg0: $BlockPos_): number;
        getDirectSignal(arg0: $BlockPos_, arg1: $Direction_): number;
        getSignal(arg0: $BlockPos_, arg1: $Direction_): number;
        hasNeighborSignal(arg0: $BlockPos_): boolean;
        hasSignal(arg0: $BlockPos_, arg1: $Direction_): boolean;
    }
    export const $SignalGetter: {
        readonly DIRECTIONS: $Direction[];
    };

    export class $SpawnData extends $Record {
        constructor();
        constructor(arg0: $CompoundTag_, arg1: $Optional<$SpawnData$CustomSpawnRules>, arg2: $Optional<$EquipmentTable>);
        static CODEC: $Codec<$SpawnData>;
        static ENTITY_TAG: string;
        static LIST_CODEC: $Codec<$SimpleWeightedRandomList<$SpawnData>>;
        getCustomSpawnRules(): $Optional<$SpawnData$CustomSpawnRules>;
        getEntityToSpawn(): $CompoundTag;
        getEquipment(): $Optional<$EquipmentTable>;
        customSpawnRules(): $Optional<$SpawnData$CustomSpawnRules>;
        entityToSpawn(): $CompoundTag;
        equals(arg0: unknown): boolean;
        equipment(): $Optional<$EquipmentTable>;
        hashCode(): number;
        toString(): string;
    }

    export class $SpawnData$CustomSpawnRules extends $Record {
        constructor(arg0: $InclusiveRange<number>, arg1: $InclusiveRange<number>);
        static CODEC: $Codec<$SpawnData$CustomSpawnRules>;
        blockLightLimit(): $InclusiveRange<number>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        isValidPosition(arg0: $BlockPos_, arg1: $ServerLevel): boolean;
        skyLightLimit(): $InclusiveRange<number>;
        toString(): string;
    }

    export interface $Spawner {
        setEntityId(arg0: $EntityType_<any>, arg1: $RandomSource): void;
    }
    export const $Spawner: {
        appendHoverText(arg0: $ItemStack_, arg1: ($List<$Component> | ($Component_)[]), arg2: string): void;
        getSpawnEntityDisplayName(arg0: $ItemStack_, arg1: string): $Component;
    };

    export class $StructureManager {
        constructor(arg0: $LevelAccessor, arg1: $WorldOptions, arg2: $StructureCheck);
        addReferenceForStructure(arg0: $SectionPos, arg1: $Structure, arg2: number, arg3: $StructureAccess): void;
        addReference(arg0: $StructureStart): void;
        checkStructurePresence(arg0: $ChunkPos, arg1: $Structure, arg2: $StructurePlacement, arg3: boolean): $StructureCheckResult;
        fillStartsForStructure(arg0: $Structure, arg1: $LongSet, arg2: $Consumer_<$StructureStart, $StructureStart>): void;
        forWorldGenRegion(arg0: $WorldGenRegion): $StructureManager;
        getAllStructuresAt(arg0: $BlockPos_): $Map<$Structure, $LongSet>;
        getStartForStructure(arg0: $SectionPos, arg1: $Structure, arg2: $StructureAccess): $StructureStart;
        getStructureAt(arg0: $BlockPos_, arg1: $Structure): $StructureStart;
        getStructureWithPieceAt(arg0: $BlockPos_, arg1: $Predicate_<$Holder<$Structure>, $Holder<$Structure>, boolean>): $StructureStart;
        getStructureWithPieceAt(arg0: $BlockPos_, arg1: $HolderSet<$Structure>): $StructureStart;
        getStructureWithPieceAt(arg0: $BlockPos_, arg1: $TagKey_<$Structure>): $StructureStart;
        getStructureWithPieceAt(arg0: $BlockPos_, arg1: $Structure): $StructureStart;
        hasAnyStructureAt(arg0: $BlockPos_): boolean;
        registryAccess(): $RegistryAccess;
        setStartForStructure(arg0: $SectionPos, arg1: $Structure, arg2: $StructureStart, arg3: $StructureAccess): void;
        shouldGenerateStructures(): boolean;
        startsForStructure(arg0: $SectionPos, arg1: $Structure): $List<$StructureStart>;
        startsForStructure(arg0: $ChunkPos, arg1: $Predicate_<$Structure, $Structure, boolean>): $List<$StructureStart>;
        structureHasPieceAt(arg0: $BlockPos_, arg1: $StructureStart): boolean;
    }

    export class $WorldDataConfiguration extends $Record {
        constructor(arg0: $DataPackConfig, arg1: $FeatureFlagSet);
        static CODEC: $Codec<$WorldDataConfiguration>;
        static DEFAULT: $WorldDataConfiguration;
        static ENABLED_FEATURES_ID: string;
        dataPacks(): $DataPackConfig;
        enabledFeatures(): $FeatureFlagSet;
        equals(arg0: unknown): boolean;
        expandFeatures(arg0: $FeatureFlagSet): $WorldDataConfiguration;
        hashCode(): number;
        toString(): string;
    }

    export interface $WorldGenLevel extends $ServerLevelAccessor {
        ensureCanWrite(arg0: $BlockPos_): boolean;
        getSeed(): number;
        setCurrentlyGenerating(arg0: $Supplier_<string, string>): void;
    }

    export type $ClipContext$Block_ = $ClipContext$Block | "COLLIDER" | "FALLDAMAGE_RESETTING" | "OUTLINE" | "VISUAL";
    export type $ClipContext$Fluid_ = $ClipContext$Fluid | "ANY" | "NONE" | "SOURCE_ONLY" | "WATER";
    export type $ClipContext$ShapeGetter_<CallbackArg0 = $BlockState, CallbackArg1 = $BlockGetter, CallbackArg2 = $BlockPos, CallbackArg3 = $CollisionContext, CallbackResult = $VoxelShape> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => CallbackResult) | ($ClipContext$ShapeGetter & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $ColorResolver_<CallbackArg0 = $Biome, CallbackArg1 = number, CallbackArg2 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($ColorResolver & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "getColor": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $CustomSpawner_<CallbackArg0 = $ServerLevel, CallbackArg1 = boolean, CallbackArg2 = boolean, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($CustomSpawner & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "tick": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Explosion$BlockInteraction_ = $Explosion$BlockInteraction | "DESTROY" | "DESTROY_WITH_DECAY" | "KEEP" | "TRIGGER_BLOCK";
    export type $GameRules$Category_ = $GameRules$Category | "CHAT" | "DROPS" | "MISC" | "MOBS" | "PLAYER" | "SPAWNING" | "UPDATES";
    export type $GameType_ = $GameType | "ADVENTURE" | "CREATIVE" | "SPECTATOR" | "SURVIVAL";
    export type $ItemLike_ = $ItemLike | RegistryTypes.Item | $ItemStack | $Block | $NekoId;
    export type $Level$ExplosionInteraction_ = $Level$ExplosionInteraction | "BLOCK" | "MOB" | "NONE" | "TNT" | "TRIGGER";
    export type $LightLayer_ = $LightLayer | "BLOCK" | "SKY";
    export type $Spawner_<CallbackArg0 = $EntityType<any>, CallbackArg1 = $RandomSource> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($Spawner & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "setEntityId": (arg0: CallbackArg0, arg1: CallbackArg1) => void } & { readonly [Symbol.hasInstance]?: never }>);
}
