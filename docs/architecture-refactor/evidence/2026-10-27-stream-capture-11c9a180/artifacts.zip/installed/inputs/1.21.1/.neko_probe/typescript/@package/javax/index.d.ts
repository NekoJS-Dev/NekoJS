export * as security from "java:javax/security";
export * as crypto from "java:javax/crypto";

