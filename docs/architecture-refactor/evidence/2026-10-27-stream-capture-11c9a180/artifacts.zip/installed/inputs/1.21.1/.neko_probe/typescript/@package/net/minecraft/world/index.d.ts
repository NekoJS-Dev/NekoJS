import { $Codec } from "java:com/mojang/serialization";
import { $File } from "java:java/io";
import { $Enum, $Record } from "java:java/lang";
import { $List, $Optional, $Set, $UUID } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $HolderLookup$Provider, $NonNullList } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $ListTag } from "java:net/minecraft/nbt";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Player, $StackedContents } from "java:net/minecraft/world/entity/player";
import { $MenuConstructor, $MenuConstructor_, $StackedContentsCompatible, $StackedContentsCompatible_ } from "java:net/minecraft/world/inventory";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $BlockGetter, $Level } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $RandomSupport$Seed128bit, $XoroshiroRandomSource } from "java:net/minecraft/world/level/levelgen";
import { $SavedData, $SavedData$Factory } from "java:net/minecraft/world/level/saveddata";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $IMenuProviderExtension } from "java:net/neoforged/neoforge/client/extensions";

export * as damagesource from "java:net/minecraft/world/damagesource";
export * as effect from "java:net/minecraft/world/effect";
export * as entity from "java:net/minecraft/world/entity";
export * as flag from "java:net/minecraft/world/flag";
export * as food from "java:net/minecraft/world/food";
export * as inventory from "java:net/minecraft/world/inventory";
export * as item from "java:net/minecraft/world/item";
export * as level from "java:net/minecraft/world/level";
export * as phys from "java:net/minecraft/world/phys";
export * as scores from "java:net/minecraft/world/scores";
export * as ticks from "java:net/minecraft/world/ticks";

declare module "java:net/minecraft/world" {
    export class $BossEvent {
        constructor(arg0: $UUID, arg1: $Component_, arg2: $BossEvent$BossBarColor_, arg3: $BossEvent$BossBarOverlay_);
        get color(): $BossEvent$BossBarColor;
        getColor(): $BossEvent$BossBarColor;
        set color(value: $BossEvent$BossBarColor_);
        get id(): $UUID;
        getId(): $UUID;
        get name(): $Component;
        getName(): $Component;
        set name(value: $Component_);
        get overlay(): $BossEvent$BossBarOverlay;
        getOverlay(): $BossEvent$BossBarOverlay;
        set overlay(value: $BossEvent$BossBarOverlay_);
        get progress(): number;
        getProgress(): number;
        set progress(value: number);
        setColor(arg0: $BossEvent$BossBarColor_): void;
        setCreateWorldFog(arg0: boolean): $BossEvent;
        setDarkenScreen(arg0: boolean): $BossEvent;
        setName(arg0: $Component_): void;
        setOverlay(arg0: $BossEvent$BossBarOverlay_): void;
        setPlayBossMusic(arg0: boolean): $BossEvent;
        setProgress(arg0: number): void;
        shouldCreateWorldFog(): boolean;
        shouldDarkenScreen(): boolean;
        shouldPlayBossMusic(): boolean;
    }

    export class $BossEvent$BossBarColor {
        static BLUE: $BossEvent$BossBarColor;
        static GREEN: $BossEvent$BossBarColor;
        static PINK: $BossEvent$BossBarColor;
        static PURPLE: $BossEvent$BossBarColor;
        static RED: $BossEvent$BossBarColor;
        static WHITE: $BossEvent$BossBarColor;
        static YELLOW: $BossEvent$BossBarColor;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BossEvent$BossBarColor[];
        static valueOf(name: string): $BossEvent$BossBarColor;
    }
    export interface $BossEvent$BossBarColor extends $Enum<$BossEvent$BossBarColor> {}

    export class $BossEvent$BossBarOverlay {
        static NOTCHED_10: $BossEvent$BossBarOverlay;
        static NOTCHED_12: $BossEvent$BossBarOverlay;
        static NOTCHED_20: $BossEvent$BossBarOverlay;
        static NOTCHED_6: $BossEvent$BossBarOverlay;
        static PROGRESS: $BossEvent$BossBarOverlay;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BossEvent$BossBarOverlay[];
        static valueOf(name: string): $BossEvent$BossBarOverlay;
    }
    export interface $BossEvent$BossBarOverlay extends $Enum<$BossEvent$BossBarOverlay> {}

    export interface $Clearable {
        clearContent(): void;
    }
    export const $Clearable: {
        tryClear(arg0: unknown): void;
    };

    export interface $Container extends $Clearable {
        canPlaceItem(arg0: number, arg1: $ItemStack_): boolean;
        canTakeItem(arg0: $Container, arg1: number, arg2: $ItemStack_): boolean;
        countItem(arg0: $Item_): number;
        getContainerSize(): number;
        getItem(arg0: number): $ItemStack;
        getMaxStackSize(arg0: $ItemStack_): number;
        getMaxStackSize(): number;
        hasAnyMatching(arg0: $Predicate_<$ItemStack, $ItemStack, boolean>): boolean;
        hasAnyOf(arg0: $Set<$Item>): boolean;
        isEmpty(): boolean;
        removeItemNoUpdate(arg0: number): $ItemStack;
        removeItem(arg0: number, arg1: number): $ItemStack;
        setChanged(): void;
        setItem(arg0: number, arg1: $ItemStack_): void;
        startOpen(arg0: $Player): void;
        stillValid(arg0: $Player): boolean;
        stopOpen(arg0: $Player): void;
    }
    export const $Container: {
        stillValidBlockEntity(arg0: $BlockEntity, arg1: $Player, arg2: number): boolean;
        stillValidBlockEntity(arg0: $BlockEntity, arg1: $Player): boolean;
        readonly DEFAULT_DISTANCE_BUFFER: number;
    };

    export interface $ContainerListener {
        containerChanged(arg0: $Container): void;
    }

    export class $Difficulty {
        static EASY: $Difficulty;
        static HARD: $Difficulty;
        static NORMAL: $Difficulty;
        static PEACEFUL: $Difficulty;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Difficulty[];
        static valueOf(name: string): $Difficulty;
    }
    export interface $Difficulty extends $Enum<$Difficulty>, $StringRepresentable {}

    export class $DifficultyInstance {
        constructor(arg0: $Difficulty_, arg1: number, arg2: number, arg3: number);
        get difficulty(): $Difficulty;
        getDifficulty(): $Difficulty;
        get effectiveDifficulty(): number;
        getEffectiveDifficulty(): number;
        get specialMultiplier(): number;
        getSpecialMultiplier(): number;
        get hard(): boolean;
        isHard(): boolean;
        isHarderThan(arg0: number): boolean;
    }

    export class $InteractionHand {
        static MAIN_HAND: $InteractionHand;
        static OFF_HAND: $InteractionHand;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $InteractionHand[];
        static valueOf(name: string): $InteractionHand;
    }
    export interface $InteractionHand extends $Enum<$InteractionHand> {}

    export class $InteractionResult {
        static CONSUME: $InteractionResult;
        static CONSUME_PARTIAL: $InteractionResult;
        static FAIL: $InteractionResult;
        static PASS: $InteractionResult;
        static SUCCESS: $InteractionResult;
        static SUCCESS_NO_ITEM_USED: $InteractionResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $InteractionResult[];
        static valueOf(name: string): $InteractionResult;
    }
    export interface $InteractionResult extends $Enum<$InteractionResult> {}

    export class $InteractionResultHolder<T> {
        constructor(arg0: $InteractionResult_, arg1: T);
        get object(): T;
        getObject(): T;
        get result(): $InteractionResult;
        getResult(): $InteractionResult;
        static consume<T>(arg0: T): $InteractionResultHolder<T>;
        static fail<T>(arg0: T): $InteractionResultHolder<T>;
        static pass<T>(arg0: T): $InteractionResultHolder<T>;
        static sidedSuccess<T>(arg0: T, arg1: boolean): $InteractionResultHolder<T>;
        static success<T>(arg0: T): $InteractionResultHolder<T>;
    }

    export class $ItemInteractionResult {
        static CONSUME: $ItemInteractionResult;
        static CONSUME_PARTIAL: $ItemInteractionResult;
        static FAIL: $ItemInteractionResult;
        static PASS_TO_DEFAULT_BLOCK_INTERACTION: $ItemInteractionResult;
        static SKIP_DEFAULT_BLOCK_INTERACTION: $ItemInteractionResult;
        static SUCCESS: $ItemInteractionResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ItemInteractionResult[];
        static valueOf(name: string): $ItemInteractionResult;
    }
    export interface $ItemInteractionResult extends $Enum<$ItemInteractionResult> {}

    export class $LockCode extends $Record {
        constructor(arg0: string);
        static CODEC: $Codec<$LockCode>;
        static NO_LOCK: $LockCode;
        static TAG_LOCK: string;
        static fromTag(arg0: $CompoundTag_): $LockCode;
        addToTag(arg0: $CompoundTag_): void;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        key(): string;
        toString(): string;
        unlocksWith(arg0: $ItemStack_): boolean;
    }

    export interface $MenuProvider extends $MenuConstructor, $IMenuProviderExtension {
        getDisplayName(): $Component;
    }

    export interface $Nameable {
        getCustomName(): $Component;
        getDisplayName(): $Component;
        getName(): $Component;
        hasCustomName(): boolean;
    }

    export class $RandomSequence {
        constructor(arg0: number, arg1: $Optional<$ResourceLocation>);
        constructor(arg0: number, arg1: $ResourceLocation_);
        constructor(arg0: $XoroshiroRandomSource);
        static CODEC: $Codec<$RandomSequence>;
        static seedForKey(arg0: $ResourceLocation_): $RandomSupport$Seed128bit;
        random(): $RandomSource;
    }

    export class $RandomSequences extends $SavedData {
        constructor(arg0: number);
        static factory(arg0: number): $SavedData$Factory<$RandomSequences>;
        static load(arg0: number, arg1: $CompoundTag_): $RandomSequences;
        clear(): number;
        forAllSequences(arg0: $BiConsumer_<$ResourceLocation, $RandomSequence, $ResourceLocation, $RandomSequence>): void;
        get(arg0: $ResourceLocation_): $RandomSource;
        reset(arg0: $ResourceLocation_, arg1: number, arg2: boolean, arg3: boolean): void;
        reset(arg0: $ResourceLocation_): void;
        save(arg0: $File, arg1: $HolderLookup$Provider): void;
        save(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): $CompoundTag;
        setSeedDefaults(arg0: number, arg1: boolean, arg2: boolean): void;
    }

    export interface $RandomizableContainer extends $Container {
        getBlockPos(): $BlockPos;
        getLevel(): $Level;
        getLootTableSeed(): number;
        getLootTable(): $ResourceKey<$LootTable>;
        setLootTableSeed(arg0: number): void;
        setLootTable(arg0: $ResourceKey<$LootTable>, arg1: number): void;
        setLootTable(arg0: $ResourceKey<$LootTable>): void;
        tryLoadLootTable(arg0: $CompoundTag_): boolean;
        trySaveLootTable(arg0: $CompoundTag_): boolean;
        unpackLootTable(arg0: $Player): void;
    }
    export const $RandomizableContainer: {
        setBlockEntityLootTable(arg0: $BlockGetter, arg1: $RandomSource, arg2: $BlockPos_, arg3: $ResourceKey<$LootTable>): void;
        readonly LOOT_TABLE_SEED_TAG: string;
        readonly LOOT_TABLE_TAG: string;
    };

    export class $SimpleContainer implements $Container, $StackedContentsCompatible {
        constructor(arg0: number);
        constructor(arg0?: $ItemStack_[]);
        get containerSize(): number;
        getContainerSize(): number;
        get items(): $NonNullList<$ItemStack>;
        getItems(): $NonNullList<$ItemStack>;
        get maxStackSize(): number;
        getMaxStackSize(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        addItem(arg0: $ItemStack_): $ItemStack;
        addListener(arg0: $ContainerListener_<$Container>): void;
        canAddItem(arg0: $ItemStack_): boolean;
        canPlaceItem(arg0: number, arg1: $ItemStack_): boolean;
        canTakeItem(arg0: $Container, arg1: number, arg2: $ItemStack_): boolean;
        clearContent(): void;
        countItem(arg0: $Item_): number;
        createTag(arg0: $HolderLookup$Provider): $ListTag;
        fillStackedContents(arg0: $StackedContents): void;
        fromTag(arg0: $ListTag, arg1: $HolderLookup$Provider): void;
        getItem(arg0: number): $ItemStack;
        getMaxStackSize(arg0: $ItemStack_): number;
        hasAnyMatching(arg0: $Predicate_<$ItemStack, $ItemStack, boolean>): boolean;
        hasAnyOf(arg0: $Set<$Item>): boolean;
        removeAllItems(): $List<$ItemStack>;
        removeItemNoUpdate(arg0: number): $ItemStack;
        removeItemType(arg0: $Item_, arg1: number): $ItemStack;
        removeItem(arg0: number, arg1: number): $ItemStack;
        removeListener(arg0: $ContainerListener_<$Container>): void;
        setChanged(): void;
        setItem(arg0: number, arg1: $ItemStack_): void;
        startOpen(arg0: $Player): void;
        stillValid(arg0: $Player): boolean;
        stopOpen(arg0: $Player): void;
        toString(): string;
    }

    export class $TickRateManager {
        constructor();
        static MIN_TICKRATE: number;
        get frozen(): boolean;
        isFrozen(): boolean;
        set frozen(value: boolean);
        get steppingForward(): boolean;
        isSteppingForward(): boolean;
        frozenTicksToRun(): number;
        isEntityFrozen(arg0: $Entity): boolean;
        millisecondsPerTick(): number;
        nanosecondsPerTick(): number;
        runsNormally(): boolean;
        setFrozenTicksToRun(arg0: number): void;
        setFrozen(arg0: boolean): void;
        setTickRate(arg0: number): void;
        tickrate(): number;
        tick(): void;
    }

    export interface $WorldlyContainer extends $Container {
        canPlaceItemThroughFace(arg0: number, arg1: $ItemStack_, arg2: $Direction_): boolean;
        canTakeItemThroughFace(arg0: number, arg1: $ItemStack_, arg2: $Direction_): boolean;
        getSlotsForFace(arg0: $Direction_): number[];
    }

    export type $BossEvent$BossBarColor_ = $BossEvent$BossBarColor | "BLUE" | "GREEN" | "PINK" | "PURPLE" | "RED" | "WHITE" | "YELLOW";
    export type $BossEvent$BossBarOverlay_ = $BossEvent$BossBarOverlay | "NOTCHED_10" | "NOTCHED_12" | "NOTCHED_20" | "NOTCHED_6" | "PROGRESS";
    export type $Clearable_ = (() => void) | ($Clearable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "clearContent": () => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $ContainerListener_<CallbackArg0 = $Container> = ((arg0: CallbackArg0) => void) | ($ContainerListener & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "containerChanged": (arg0: CallbackArg0) => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Difficulty_ = $Difficulty | "EASY" | "HARD" | "NORMAL" | "PEACEFUL";
    export type $InteractionHand_ = $InteractionHand | "MAIN_HAND" | "OFF_HAND";
    export type $InteractionResult_ = $InteractionResult | "CONSUME" | "CONSUME_PARTIAL" | "FAIL" | "PASS" | "SUCCESS" | "SUCCESS_NO_ITEM_USED";
    export type $ItemInteractionResult_ = $ItemInteractionResult | "CONSUME" | "CONSUME_PARTIAL" | "FAIL" | "PASS_TO_DEFAULT_BLOCK_INTERACTION" | "SKIP_DEFAULT_BLOCK_INTERACTION" | "SUCCESS";
    export type $Nameable_<CallbackResult = $Component_> = (() => CallbackResult) | ($Nameable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "getName": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
