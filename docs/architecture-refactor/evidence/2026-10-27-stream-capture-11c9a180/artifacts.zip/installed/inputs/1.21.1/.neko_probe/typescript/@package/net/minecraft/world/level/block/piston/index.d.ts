import { $Optional } from "java:java/util";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Connection } from "java:net/minecraft/network";
import { $ClientboundBlockEntityDataPacket } from "java:net/minecraft/network/protocol/game";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $BlockGetter, $Level } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $VoxelShape } from "java:net/minecraft/world/phys/shapes";
import { $AttachmentType } from "java:net/neoforged/neoforge/attachment";
import { $ModelData } from "java:net/neoforged/neoforge/client/model/data";

declare module "java:net/minecraft/world/level/block/piston" {
    export class $PistonMovingBlockEntity extends $BlockEntity {
        constructor(arg0: $BlockPos_, arg1: $BlockState_);
        constructor(arg0: $BlockPos_, arg1: $BlockState_, arg2: $BlockState_, arg3: $Direction_, arg4: boolean, arg5: boolean);
        static TICK_MOVEMENT: number;
        get direction(): $Direction;
        getDirection(): $Direction;
        get lastTicked(): number;
        getLastTicked(): number;
        get modelData(): $ModelData;
        getModelData(): $ModelData;
        get movedState(): $BlockState;
        getMovedState(): $BlockState;
        get movementDirection(): $Direction;
        getMovementDirection(): $Direction;
        get extending(): boolean;
        isExtending(): boolean;
        get sourcePiston(): boolean;
        isSourcePiston(): boolean;
        static tick(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: $PistonMovingBlockEntity): void;
        finalTick(): void;
        getCollisionShape(arg0: $BlockGetter, arg1: $BlockPos_): $VoxelShape;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        getProgress(arg0: number): number;
        getUpdateTag(arg0: $HolderLookup$Provider): $CompoundTag;
        getXOff(arg0: number): number;
        getYOff(arg0: number): number;
        getZOff(arg0: number): number;
        handleUpdateTag(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): void;
        hasCustomOutlineRendering(arg0: $Player): boolean;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        invalidateCapabilities(): void;
        onChunkUnloaded(): void;
        onDataPacket(arg0: $Connection, arg1: $ClientboundBlockEntityDataPacket, arg2: $HolderLookup$Provider): void;
        onLoad(): void;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        requestModelDataUpdate(): void;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        setLevel(arg0: $Level): void;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
    }

}
