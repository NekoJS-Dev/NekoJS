export * as fastutil from "java:it/unimi/dsi/fastutil";

