import { $Closeable, $Closeable_ } from "java:java/io";
import { $AutoCloseable, $AutoCloseable_, $Throwable } from "java:java/lang";
import { $Arena, $MemorySegment } from "java:java/lang/foreign";
import { $DatagramSocket, $InetAddress, $NetworkInterface, $ProtocolFamily, $ProtocolFamily_, $ServerSocket, $Socket, $SocketAddress, $SocketOption } from "java:java/net";
import { $ByteBuffer, $MappedByteBuffer } from "java:java/nio";
import { $AbstractInterruptibleChannel, $AbstractSelectableChannel, $SelectorProvider } from "java:java/nio/channels/spi";
import { $OpenOption, $Path } from "java:java/nio/file";
import { $FileAttribute } from "java:java/nio/file/attribute";
import { $Set } from "java:java/util";
import { $ExecutorService, $Future } from "java:java/util/concurrent";
import { $Consumer, $Consumer_ } from "java:java/util/function";

export * as spi from "java:java/nio/channels/spi";

declare module "java:java/nio/channels" {
    export interface $AsynchronousChannel extends $Channel {
        close(): void;
    }

    export class $AsynchronousFileChannel implements $AsynchronousChannel {
        get open(): boolean;
        isOpen(): boolean;
        static open(arg0: $Path, arg1?: $OpenOption[]): $AsynchronousFileChannel;
        static open(arg0: $Path, arg1: $Set<$OpenOption>, arg2: $ExecutorService, arg3?: $FileAttribute<any>[]): $AsynchronousFileChannel;
        close(): void;
        force(arg0: boolean): void;
        lock<A>(arg0: A, arg1: $CompletionHandler<$FileLock, any>): void;
        lock<A>(arg0: number, arg1: number, arg2: boolean, arg3: A, arg4: $CompletionHandler<$FileLock, any>): void;
        lock(arg0: number, arg1: number, arg2: boolean): $Future<$FileLock>;
        lock(): $Future<$FileLock>;
        read<A>(arg0: $ByteBuffer, arg1: number, arg2: A, arg3: $CompletionHandler<number, any>): void;
        read(arg0: $ByteBuffer, arg1: number): $Future<number>;
        size(): number;
        truncate(arg0: number): $AsynchronousFileChannel;
        tryLock(arg0: number, arg1: number, arg2: boolean): $FileLock;
        tryLock(): $FileLock;
        write<A>(arg0: $ByteBuffer, arg1: number, arg2: A, arg3: $CompletionHandler<number, any>): void;
        write(arg0: $ByteBuffer, arg1: number): $Future<number>;
    }

    export interface $ByteChannel extends $ReadableByteChannel, $WritableByteChannel {
        close(): void;
        isOpen(): boolean;
    }

    export interface $Channel extends $Closeable {
        close(): void;
        isOpen(): boolean;
    }

    export interface $CompletionHandler<V, A> {
        completed(arg0: V, arg1: A): void;
        failed(arg0: $Throwable, arg1: A): void;
    }

    export class $FileChannel extends $AbstractInterruptibleChannel implements $SeekableByteChannel, $GatheringByteChannel, $ScatteringByteChannel {
        get open(): boolean;
        isOpen(): boolean;
        static open(arg0: $Path, arg1?: $OpenOption[]): $FileChannel;
        static open(arg0: $Path, arg1: $Set<$OpenOption>, arg2?: $FileAttribute<any>[]): $FileChannel;
        close(): void;
        force(arg0: boolean): void;
        lock(arg0: number, arg1: number, arg2: boolean): $FileLock;
        lock(): $FileLock;
        map(arg0: $FileChannel$MapMode, arg1: number, arg2: number, arg3: $Arena): $MemorySegment;
        map(arg0: $FileChannel$MapMode, arg1: number, arg2: number): $MappedByteBuffer;
        position(arg0: number): $FileChannel;
        position(): number;
        read(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        read(arg0: $ByteBuffer[]): number;
        read(arg0: $ByteBuffer, arg1: number): number;
        read(arg0: $ByteBuffer): number;
        size(): number;
        transferFrom(arg0: $ReadableByteChannel, arg1: number, arg2: number): number;
        transferTo(arg0: number, arg1: number, arg2: $WritableByteChannel): number;
        truncate(arg0: number): $FileChannel;
        tryLock(arg0: number, arg1: number, arg2: boolean): $FileLock;
        tryLock(): $FileLock;
        write(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        write(arg0: $ByteBuffer[]): number;
        write(arg0: $ByteBuffer, arg1: number): number;
        write(arg0: $ByteBuffer): number;
    }

    export class $FileChannel$MapMode {
        static PRIVATE: $FileChannel$MapMode;
        static READ_ONLY: $FileChannel$MapMode;
        static READ_WRITE: $FileChannel$MapMode;
        toString(): string;
    }

    export class $FileLock implements $AutoCloseable {
        get shared(): boolean;
        isShared(): boolean;
        get valid(): boolean;
        isValid(): boolean;
        acquiredBy(): $Channel;
        channel(): $FileChannel;
        close(): void;
        overlaps(arg0: number, arg1: number): boolean;
        position(): number;
        release(): void;
        size(): number;
        toString(): string;
    }

    export interface $GatheringByteChannel extends $WritableByteChannel {
        write(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        write(arg0: $ByteBuffer[]): number;
        write(arg0: $ByteBuffer): number;
    }

    export interface $InterruptibleChannel extends $Channel {
        close(): void;
    }

    export interface $ReadableByteChannel extends $Channel {
        read(arg0: $ByteBuffer): number;
    }

    export interface $ScatteringByteChannel extends $ReadableByteChannel {
        read(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        read(arg0: $ByteBuffer[]): number;
        read(arg0: $ByteBuffer): number;
    }

    export interface $SeekableByteChannel extends $ByteChannel {
        position(arg0: number): $SeekableByteChannel;
        position(): number;
        read(arg0: $ByteBuffer): number;
        size(): number;
        truncate(arg0: number): $SeekableByteChannel;
        write(arg0: $ByteBuffer): number;
    }

    export interface $WritableByteChannel extends $Channel {
        write(arg0: $ByteBuffer): number;
    }

    export class $DatagramChannel extends $AbstractSelectableChannel implements $ByteChannel, $ScatteringByteChannel, $GatheringByteChannel, $MulticastChannel {
        get localAddress(): $SocketAddress;
        getLocalAddress(): $SocketAddress;
        get remoteAddress(): $SocketAddress;
        getRemoteAddress(): $SocketAddress;
        get connected(): boolean;
        isConnected(): boolean;
        get open(): boolean;
        isOpen(): boolean;
        static open(arg0: $ProtocolFamily_<string>): $DatagramChannel;
        static open(): $DatagramChannel;
        bind(arg0: $SocketAddress): $DatagramChannel;
        close(): void;
        connect(arg0: $SocketAddress): $DatagramChannel;
        disconnect(): $DatagramChannel;
        getOption<T>(arg0: $SocketOption<T>): T;
        join(arg0: $InetAddress, arg1: $NetworkInterface, arg2: $InetAddress): $MembershipKey;
        join(arg0: $InetAddress, arg1: $NetworkInterface): $MembershipKey;
        read(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        read(arg0: $ByteBuffer[]): number;
        read(arg0: $ByteBuffer): number;
        receive(arg0: $ByteBuffer): $SocketAddress;
        send(arg0: $ByteBuffer, arg1: $SocketAddress): number;
        setOption<T>(arg0: $SocketOption<T>, arg1: T): $DatagramChannel;
        socket(): $DatagramSocket;
        supportedOptions(): $Set<$SocketOption<any>>;
        validOps(): number;
        write(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        write(arg0: $ByteBuffer[]): number;
        write(arg0: $ByteBuffer): number;
    }

    export class $Pipe {
        static open(): $Pipe;
        sink(): $Pipe$SinkChannel;
        source(): $Pipe$SourceChannel;
    }

    export class $ServerSocketChannel extends $AbstractSelectableChannel implements $NetworkChannel {
        get localAddress(): $SocketAddress;
        getLocalAddress(): $SocketAddress;
        get open(): boolean;
        isOpen(): boolean;
        static open(arg0: $ProtocolFamily_<string>): $ServerSocketChannel;
        static open(): $ServerSocketChannel;
        accept(): $SocketChannel;
        bind(arg0: $SocketAddress, arg1: number): $ServerSocketChannel;
        bind(arg0: $SocketAddress): $ServerSocketChannel;
        close(): void;
        getOption<T>(arg0: $SocketOption<T>): T;
        setOption<T>(arg0: $SocketOption<T>, arg1: T): $ServerSocketChannel;
        socket(): $ServerSocket;
        supportedOptions(): $Set<$SocketOption<any>>;
        validOps(): number;
    }

    export class $SocketChannel extends $AbstractSelectableChannel implements $ByteChannel, $ScatteringByteChannel, $GatheringByteChannel, $NetworkChannel {
        get localAddress(): $SocketAddress;
        getLocalAddress(): $SocketAddress;
        get remoteAddress(): $SocketAddress;
        getRemoteAddress(): $SocketAddress;
        get connected(): boolean;
        isConnected(): boolean;
        get connectionPending(): boolean;
        isConnectionPending(): boolean;
        get open(): boolean;
        isOpen(): boolean;
        static open(arg0: $ProtocolFamily_<string>): $SocketChannel;
        static open(arg0: $SocketAddress): $SocketChannel;
        static open(): $SocketChannel;
        bind(arg0: $SocketAddress): $SocketChannel;
        close(): void;
        connect(arg0: $SocketAddress): boolean;
        finishConnect(): boolean;
        getOption<T>(arg0: $SocketOption<T>): T;
        read(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        read(arg0: $ByteBuffer[]): number;
        read(arg0: $ByteBuffer): number;
        setOption<T>(arg0: $SocketOption<T>, arg1: T): $SocketChannel;
        shutdownInput(): $SocketChannel;
        shutdownOutput(): $SocketChannel;
        socket(): $Socket;
        supportedOptions(): $Set<$SocketOption<any>>;
        validOps(): number;
        write(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        write(arg0: $ByteBuffer[]): number;
        write(arg0: $ByteBuffer): number;
    }

    export class $MembershipKey {
        get valid(): boolean;
        isValid(): boolean;
        block(arg0: $InetAddress): $MembershipKey;
        channel(): $MulticastChannel;
        drop(): void;
        group(): $InetAddress;
        networkInterface(): $NetworkInterface;
        sourceAddress(): $InetAddress;
        unblock(arg0: $InetAddress): $MembershipKey;
    }

    export interface $MulticastChannel extends $NetworkChannel {
        close(): void;
        join(arg0: $InetAddress, arg1: $NetworkInterface, arg2: $InetAddress): $MembershipKey;
        join(arg0: $InetAddress, arg1: $NetworkInterface): $MembershipKey;
    }

    export interface $NetworkChannel extends $Channel {
        bind(arg0: $SocketAddress): $NetworkChannel;
        getLocalAddress(): $SocketAddress;
        getOption<T>(arg0: $SocketOption<T>): T;
        setOption<T>(arg0: $SocketOption<T>, arg1: T): $NetworkChannel;
        supportedOptions(): $Set<$SocketOption<any>>;
    }

    export class $Pipe$SinkChannel extends $AbstractSelectableChannel implements $WritableByteChannel, $GatheringByteChannel {
        get open(): boolean;
        isOpen(): boolean;
        close(): void;
        validOps(): number;
        write(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        write(arg0: $ByteBuffer[]): number;
        write(arg0: $ByteBuffer): number;
    }

    export class $Pipe$SourceChannel extends $AbstractSelectableChannel implements $ReadableByteChannel, $ScatteringByteChannel {
        get open(): boolean;
        isOpen(): boolean;
        close(): void;
        read(arg0: $ByteBuffer[], arg1: number, arg2: number): number;
        read(arg0: $ByteBuffer[]): number;
        read(arg0: $ByteBuffer): number;
        validOps(): number;
    }

    export class $SelectableChannel extends $AbstractInterruptibleChannel implements $Channel {
        get blocking(): boolean;
        isBlocking(): boolean;
        get open(): boolean;
        isOpen(): boolean;
        get registered(): boolean;
        isRegistered(): boolean;
        blockingLock(): unknown;
        close(): void;
        configureBlocking(arg0: boolean): $SelectableChannel;
        keyFor(arg0: $Selector): $SelectionKey;
        provider(): $SelectorProvider;
        register(arg0: $Selector, arg1: number, arg2: unknown): $SelectionKey;
        register(arg0: $Selector, arg1: number): $SelectionKey;
        validOps(): number;
    }

    export class $SelectionKey {
        static OP_ACCEPT: number;
        static OP_CONNECT: number;
        static OP_READ: number;
        static OP_WRITE: number;
        get acceptable(): boolean;
        isAcceptable(): boolean;
        get connectable(): boolean;
        isConnectable(): boolean;
        get readable(): boolean;
        isReadable(): boolean;
        get valid(): boolean;
        isValid(): boolean;
        get writable(): boolean;
        isWritable(): boolean;
        attachment(): unknown;
        attach(arg0: unknown): unknown;
        cancel(): void;
        channel(): $SelectableChannel;
        interestOpsAnd(arg0: number): number;
        interestOpsOr(arg0: number): number;
        interestOps(arg0: number): $SelectionKey;
        interestOps(): number;
        readyOps(): number;
        selector(): $Selector;
    }

    export class $Selector implements $Closeable {
        get open(): boolean;
        isOpen(): boolean;
        static open(): $Selector;
        close(): void;
        keys(): $Set<$SelectionKey>;
        provider(): $SelectorProvider;
        selectNow(arg0: $Consumer_<$SelectionKey, $SelectionKey>): number;
        selectNow(): number;
        selectedKeys(): $Set<$SelectionKey>;
        select(arg0: $Consumer_<$SelectionKey, $SelectionKey>, arg1: number): number;
        select(arg0: $Consumer_<$SelectionKey, $SelectionKey>): number;
        select(arg0: number): number;
        select(): number;
        wakeup(): $Selector;
    }

}
