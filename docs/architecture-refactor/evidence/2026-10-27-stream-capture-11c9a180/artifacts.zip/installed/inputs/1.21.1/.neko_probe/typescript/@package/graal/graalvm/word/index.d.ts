declare module "java:graal/graalvm/word" {
    export interface $PointerBase extends $ComparableWord {
        isNonNull(): boolean;
        isNull(): boolean;
    }

    export interface $SignedWord extends $ComparableWord {
        add(val: $SignedWord): $SignedWord;
        add(val: number): $SignedWord;
        and(val: $SignedWord): $SignedWord;
        and(val: number): $SignedWord;
        equal(val: $ComparableWord): boolean;
        equal(val: $SignedWord): boolean;
        equal(val: number): boolean;
        greaterOrEqual(val: $SignedWord): boolean;
        greaterOrEqual(val: number): boolean;
        greaterThan(val: $SignedWord): boolean;
        greaterThan(val: number): boolean;
        lessOrEqual(val: $SignedWord): boolean;
        lessOrEqual(val: number): boolean;
        lessThan(val: $SignedWord): boolean;
        lessThan(val: number): boolean;
        multiply(val: $SignedWord): $SignedWord;
        multiply(val: number): $SignedWord;
        notEqual(val: $ComparableWord): boolean;
        notEqual(val: $SignedWord): boolean;
        notEqual(val: number): boolean;
        not(): $SignedWord;
        or(val: $SignedWord): $SignedWord;
        or(val: number): $SignedWord;
        shiftLeft(n: $UnsignedWord): $SignedWord;
        shiftLeft(n: number): $SignedWord;
        signedDivide(val: $SignedWord): $SignedWord;
        signedDivide(val: number): $SignedWord;
        signedRemainder(val: $SignedWord): $SignedWord;
        signedRemainder(val: number): $SignedWord;
        signedShiftRight(n: $UnsignedWord): $SignedWord;
        signedShiftRight(n: number): $SignedWord;
        subtract(val: $SignedWord): $SignedWord;
        subtract(val: number): $SignedWord;
        xor(val: $SignedWord): $SignedWord;
        xor(val: number): $SignedWord;
    }

    export interface $WordBase {
        equals(o: unknown): boolean;
        rawValue(): number;
    }

    export interface $ComparableWord extends $WordBase {
        equal(val: $ComparableWord): boolean;
        notEqual(val: $ComparableWord): boolean;
    }

    export interface $UnsignedWord extends $ComparableWord {
        aboveOrEqual(val: $UnsignedWord): boolean;
        aboveOrEqual(val: number): boolean;
        aboveThan(val: $UnsignedWord): boolean;
        aboveThan(val: number): boolean;
        add(val: $UnsignedWord): $UnsignedWord;
        add(val: number): $UnsignedWord;
        and(val: $UnsignedWord): $UnsignedWord;
        and(val: number): $UnsignedWord;
        belowOrEqual(val: $UnsignedWord): boolean;
        belowOrEqual(val: number): boolean;
        belowThan(val: $UnsignedWord): boolean;
        belowThan(val: number): boolean;
        equal(val: $ComparableWord): boolean;
        equal(val: $UnsignedWord): boolean;
        equal(val: number): boolean;
        multiply(val: $UnsignedWord): $UnsignedWord;
        multiply(val: number): $UnsignedWord;
        notEqual(val: $ComparableWord): boolean;
        notEqual(val: $UnsignedWord): boolean;
        notEqual(val: number): boolean;
        not(): $UnsignedWord;
        or(val: $UnsignedWord): $UnsignedWord;
        or(val: number): $UnsignedWord;
        shiftLeft(n: $UnsignedWord): $UnsignedWord;
        shiftLeft(n: number): $UnsignedWord;
        subtract(val: $UnsignedWord): $UnsignedWord;
        subtract(val: number): $UnsignedWord;
        unsignedDivide(val: $UnsignedWord): $UnsignedWord;
        unsignedDivide(val: number): $UnsignedWord;
        unsignedRemainder(val: $UnsignedWord): $UnsignedWord;
        unsignedRemainder(val: number): $UnsignedWord;
        unsignedShiftRight(n: $UnsignedWord): $UnsignedWord;
        unsignedShiftRight(n: number): $UnsignedWord;
        xor(val: $UnsignedWord): $UnsignedWord;
        xor(val: number): $UnsignedWord;
    }

    export type $WordBase_<CallbackResult = number> = (() => CallbackResult) | ($WordBase & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "rawValue": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
