import { $DoubleStream, $IntStream, $LongStream } from "java:java/util/stream";

declare module "java:java/util/random" {
    export interface $RandomGenerator {
        doubles(arg0: number, arg1: number): $DoubleStream;
        doubles(arg0: number, arg1: number, arg2: number): $DoubleStream;
        doubles(arg0: number): $DoubleStream;
        doubles(): $DoubleStream;
        ints(arg0: number, arg1: number): $IntStream;
        ints(arg0: number, arg1: number, arg2: number): $IntStream;
        ints(arg0: number): $IntStream;
        ints(): $IntStream;
        isDeprecated(): boolean;
        longs(arg0: number, arg1: number, arg2: number): $LongStream;
        longs(arg0: number, arg1: number): $LongStream;
        longs(arg0: number): $LongStream;
        longs(): $LongStream;
        nextBoolean(): boolean;
        nextBytes(arg0: number[]): void;
        nextDouble(arg0: number, arg1: number): number;
        nextDouble(arg0: number): number;
        nextDouble(): number;
        nextExponential(): number;
        nextFloat(arg0: number, arg1: number): number;
        nextFloat(arg0: number): number;
        nextFloat(): number;
        nextGaussian(arg0: number, arg1: number): number;
        nextGaussian(): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(arg0: number, arg1: number): number;
        nextLong(arg0: number): number;
        nextLong(): number;
    }
    export const $RandomGenerator: {
        getDefault(): $RandomGenerator;
        of(arg0: string): $RandomGenerator;
    };

    export type $RandomGenerator_<CallbackResult = number> = (() => CallbackResult) | ($RandomGenerator & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "nextLong": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
