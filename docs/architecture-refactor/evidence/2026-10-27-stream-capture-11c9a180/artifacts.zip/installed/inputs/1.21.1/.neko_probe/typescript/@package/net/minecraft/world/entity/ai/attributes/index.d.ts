import type { RegistryTypes } from "@special/types";
import { $Multimap } from "java:com/google/common/collect";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Record } from "java:java/lang";
import { $Collection, $Set } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $ListTag } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $MutableComponent, $TextColor } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $TooltipFlag } from "java:net/minecraft/world/item";
import { $IAttributeExtension, $IAttributeExtension_ } from "java:net/neoforged/neoforge/common/extensions";

declare module "java:net/minecraft/world/entity/ai/attributes" {
    export class $Attribute implements $IAttributeExtension {
        static CODEC: $Codec<$Holder<$Attribute>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$Attribute>>;
        get baseId(): $ResourceLocation;
        getBaseId(): $ResourceLocation;
        get defaultValue(): number;
        getDefaultValue(): number;
        get descriptionId(): string;
        getDescriptionId(): string;
        get clientSyncable(): boolean;
        isClientSyncable(): boolean;
        getDebugInfo(arg0: $AttributeModifier, arg1: $TooltipFlag): $Component;
        getMergedStyle(arg0: boolean): $TextColor;
        getStyle(arg0: boolean): $ChatFormatting;
        sanitizeValue(arg0: number): number;
        setSentiment(arg0: $Attribute$Sentiment_): $Attribute;
        setSyncable(arg0: boolean): $Attribute;
        toBaseComponent(arg0: number, arg1: number, arg2: boolean, arg3: $TooltipFlag): $MutableComponent;
        toComponent(arg0: $AttributeModifier, arg1: $TooltipFlag): $MutableComponent;
        toValueComponent(arg0: $AttributeModifier$Operation_, arg1: number, arg2: $TooltipFlag): $MutableComponent;
    }

    export class $Attribute$Sentiment {
        static NEGATIVE: $Attribute$Sentiment;
        static NEUTRAL: $Attribute$Sentiment;
        static POSITIVE: $Attribute$Sentiment;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Attribute$Sentiment[];
        static valueOf(name: string): $Attribute$Sentiment;
    }
    export interface $Attribute$Sentiment extends $Enum<$Attribute$Sentiment> {}

    export class $AttributeInstance {
        constructor(arg0: $Holder_<$Attribute>, arg1: $Consumer_<$AttributeInstance, $AttributeInstance>);
        static ID_FIELD: string;
        get attribute(): $Holder<$Attribute>;
        getAttribute(): $Holder<$Attribute>;
        get baseValue(): number;
        getBaseValue(): number;
        set baseValue(value: number);
        get modifiers(): $Set<$AttributeModifier>;
        getModifiers(): $Set<$AttributeModifier>;
        get value(): number;
        getValue(): number;
        addOrReplacePermanentModifier(arg0: $AttributeModifier): void;
        addOrUpdateTransientModifier(arg0: $AttributeModifier): void;
        addPermanentModifier(arg0: $AttributeModifier): void;
        addTransientModifier(arg0: $AttributeModifier): void;
        getModifier(arg0: $ResourceLocation_): $AttributeModifier;
        hasModifier(arg0: $ResourceLocation_): boolean;
        load(arg0: $CompoundTag_): void;
        removeModifiers(): void;
        removeModifier(arg0: $ResourceLocation_): boolean;
        removeModifier(arg0: $AttributeModifier): void;
        replaceFrom(arg0: $AttributeInstance): void;
        save(): $CompoundTag;
        setBaseValue(arg0: number): void;
    }

    export class $AttributeMap {
        constructor(arg0: $AttributeSupplier);
        get attributesToSync(): $Set<$AttributeInstance>;
        getAttributesToSync(): $Set<$AttributeInstance>;
        get attributesToUpdate(): $Set<$AttributeInstance>;
        getAttributesToUpdate(): $Set<$AttributeInstance>;
        get syncableAttributes(): $Collection<$AttributeInstance>;
        getSyncableAttributes(): $Collection<$AttributeInstance>;
        addTransientAttributeModifiers(arg0: $Multimap<$Holder<$Attribute>, $AttributeModifier>): void;
        assignAllValues(arg0: $AttributeMap): void;
        assignBaseValues(arg0: $AttributeMap): void;
        getBaseValue(arg0: $Holder_<$Attribute>): number;
        getInstance(arg0: $Holder_<$Attribute>): $AttributeInstance;
        getModifierValue(arg0: $Holder_<$Attribute>, arg1: $ResourceLocation_): number;
        getValue(arg0: $Holder_<$Attribute>): number;
        hasAttribute(arg0: $Holder_<$Attribute>): boolean;
        hasModifier(arg0: $Holder_<$Attribute>, arg1: $ResourceLocation_): boolean;
        load(arg0: $ListTag): void;
        removeAttributeModifiers(arg0: $Multimap<$Holder<$Attribute>, $AttributeModifier>): void;
        save(): $ListTag;
    }

    export class $AttributeModifier extends $Record {
        constructor(arg0: $ResourceLocation_, arg1: number, arg2: $AttributeModifier$Operation_);
        static CODEC: $Codec<$AttributeModifier>;
        static MAP_CODEC: $MapCodec<$AttributeModifier>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $AttributeModifier>;
        static load(arg0: $CompoundTag_): $AttributeModifier;
        amount(): number;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        is(arg0: $ResourceLocation_): boolean;
        operation(): $AttributeModifier$Operation;
        save(): $CompoundTag;
        toString(): string;
    }

    export class $AttributeModifier$Operation {
        static ADD_MULTIPLIED_BASE: $AttributeModifier$Operation;
        static ADD_MULTIPLIED_TOTAL: $AttributeModifier$Operation;
        static ADD_VALUE: $AttributeModifier$Operation;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AttributeModifier$Operation[];
        static valueOf(name: string): $AttributeModifier$Operation;
    }
    export interface $AttributeModifier$Operation extends $Enum<$AttributeModifier$Operation>, $StringRepresentable {}

    export class $AttributeSupplier {
        static builder(): $AttributeSupplier$Builder;
        createInstance(arg0: $Consumer_<$AttributeInstance, $AttributeInstance>, arg1: $Holder_<$Attribute>): $AttributeInstance;
        getBaseValue(arg0: $Holder_<$Attribute>): number;
        getModifierValue(arg0: $Holder_<$Attribute>, arg1: $ResourceLocation_): number;
        getValue(arg0: $Holder_<$Attribute>): number;
        hasAttribute(arg0: $Holder_<$Attribute>): boolean;
        hasModifier(arg0: $Holder_<$Attribute>, arg1: $ResourceLocation_): boolean;
    }

    export class $AttributeSupplier$Builder {
        constructor();
        constructor(arg0: $AttributeSupplier);
        add(arg0: $Holder_<$Attribute>, arg1: number): $AttributeSupplier$Builder;
        add(arg0: $Holder_<$Attribute>): $AttributeSupplier$Builder;
        build(): $AttributeSupplier;
        combine(arg0: $AttributeSupplier$Builder): void;
        hasAttribute(arg0: $Holder_<$Attribute>): boolean;
    }

    export type $Attribute_ = $Attribute | RegistryTypes.Attribute | $NekoId | string;
    export type $Attribute$Sentiment_ = $Attribute$Sentiment | "NEGATIVE" | "NEUTRAL" | "POSITIVE";
    export type $AttributeModifier$Operation_ = $AttributeModifier$Operation | "ADD_MULTIPLIED_BASE" | "ADD_MULTIPLIED_TOTAL" | "ADD_VALUE";
}
