declare module "java:com/tkisor/nekojs/api/spec/inject" {
    export interface $BlockSpec {
        getId(): string;
    }

    export interface $BlockStateSpec {
        getId(): string;
        hasTag(tagLocation: string): boolean;
        is(idOrTag: string): boolean;
    }

    export interface $EntitySpec {
        getLevel(): unknown;
        kill(): boolean;
        remove(): void;
        teleport(x: number, y: number, z: number): void;
    }

    export interface $ItemSpec {
        getId(): string;
    }

    export interface $ItemStackSpec {
        getId(): string;
        hasEnchantment(enchId: string, level: number): boolean;
        isUnbreakable(): boolean;
        matches(other: unknown): boolean;
        pdata(): unknown;
        setUnbreakable(value: boolean): void;
        withCount(count: number): unknown;
    }

    export interface $LevelSpec {
        data(): unknown;
        getBlockState(x: number, y: number, z: number): unknown;
        getId(): string;
        getPlayers(): unknown;
        getTime(): number;
        isDay(): boolean;
        isRaining(): boolean;
        setBlock(x: number, y: number, z: number, block: unknown): boolean;
        setRaining(raining: boolean): void;
        setTime(time: number): void;
    }

    export interface $LivingEntitySpec {
        addEffect(effectId: string, duration: number, amplifier: number): boolean;
        damage(amount: number): void;
        getChestItem(): unknown;
        getFeetItem(): unknown;
        getHeadItem(): unknown;
        getLegsItem(): unknown;
        getOffHandItem(): unknown;
        removeEffect(effectId: string): boolean;
    }

    export interface $MutableComponentSpec {
        aqua(): unknown;
        black(): unknown;
        blue(): unknown;
        bold(value: boolean): unknown;
        bold(): unknown;
        darkAqua(): unknown;
        darkBlue(): unknown;
        darkGray(): unknown;
        darkGreen(): unknown;
        darkPurple(): unknown;
        darkRed(): unknown;
        font(font: string): unknown;
        gold(): unknown;
        gray(): unknown;
        green(): unknown;
        hasStyle(): boolean;
        insertion(insertion: string): unknown;
        italic(value: boolean): unknown;
        italic(): unknown;
        lightPurple(): unknown;
        noColor(): unknown;
        obfuscated(value: boolean): unknown;
        obfuscated(): unknown;
        red(): unknown;
        strikethrough(value: boolean): unknown;
        strikethrough(): unknown;
        underlined(value: boolean): unknown;
        underlined(): unknown;
        white(): unknown;
        yellow(): unknown;
    }

    export interface $PlayerSpec {
        addXpLevels(levels: number): void;
        addXpPoints(points: number): void;
        getGamemode(): string;
        getXpLevel(): number;
        give(stack: unknown): void;
        isOp(): boolean;
        kick(reason: unknown): void;
        setGamemode(gamemode: string): void;
        setXpLevel(level: number): void;
    }

    export interface $ServerSpec {
        data(): unknown;
    }

}
