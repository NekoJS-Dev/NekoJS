import { $ByteBuf } from "java:io/netty/buffer";
import { $Record } from "java:java/lang";
import { $List } from "java:java/util";
import { $ConnectionProtocol, $ConnectionProtocol_, $FriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec, $StreamDecoder, $StreamDecoder_, $StreamMemberEncoder, $StreamMemberEncoder_ } from "java:net/minecraft/network/codec";
import { $PacketFlow, $PacketFlow_ } from "java:net/minecraft/network/protocol";
import { $ClientboundCustomPayloadPacket, $ServerboundCustomPayloadPacket } from "java:net/minecraft/network/protocol/common";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/network/protocol/common/custom" {
    export interface $CustomPacketPayload {
        toVanillaClientbound(): $ClientboundCustomPayloadPacket;
        toVanillaServerbound(): $ServerboundCustomPayloadPacket;
        type(): $CustomPacketPayload$Type<$CustomPacketPayload>;
    }
    export const $CustomPacketPayload: {
        codec<B extends $ByteBuf, T extends $CustomPacketPayload>(arg0: $StreamMemberEncoder_<B, T, T, B>, arg1: $StreamDecoder_<B, T, B, T>): $StreamCodec<B, T>;
        codec<B extends $FriendlyByteBuf>(arg0: $CustomPacketPayload$FallbackProvider_<B, $ResourceLocation, $StreamCodec<B, $CustomPacketPayload>>, arg1: ($List<$CustomPacketPayload$TypeAndCodec<any, any>> | ($CustomPacketPayload$TypeAndCodec<any, any>)[]), arg2: $ConnectionProtocol_, arg3: $PacketFlow_): $StreamCodec<B, $CustomPacketPayload>;
        createType<T extends $CustomPacketPayload>(arg0: string): $CustomPacketPayload$Type<T>;
    };

    export interface $CustomPacketPayload$FallbackProvider<B extends $FriendlyByteBuf> {
        create(arg0: $ResourceLocation_): $StreamCodec<B, $CustomPacketPayload>;
    }

    export class $CustomPacketPayload$Type<T extends $CustomPacketPayload> extends $Record {
        constructor(id: $ResourceLocation_);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        toString(): string;
    }

    export class $CustomPacketPayload$TypeAndCodec<B extends $FriendlyByteBuf, T extends $CustomPacketPayload> extends $Record {
        constructor(type: $CustomPacketPayload$Type<T>, codec: $StreamCodec<B, T>);
        codec(): $StreamCodec<B, T>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
        type(): $CustomPacketPayload$Type<T>;
    }

    export type $CustomPacketPayload_<CallbackResult = $CustomPacketPayload$Type<$CustomPacketPayload>> = (() => CallbackResult) | ($CustomPacketPayload & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "type": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $CustomPacketPayload$FallbackProvider_<Host0 extends $FriendlyByteBuf = any, CallbackArg0 = $ResourceLocation, CallbackResult = $StreamCodec<Host0, $CustomPacketPayload>> = ((arg0: CallbackArg0) => CallbackResult) | ($CustomPacketPayload$FallbackProvider<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "create": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
