import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $RandomSource } from "java:net/minecraft/util";
import { $SimpleWeightedRandomList } from "java:net/minecraft/util/random";
import { $VerticalAnchor, $VerticalAnchor_, $WorldGenerationContext } from "java:net/minecraft/world/level/levelgen";

declare module "java:net/minecraft/world/level/levelgen/heightproviders" {
    export class $HeightProvider {
        constructor();
        static CODEC: $Codec<$HeightProvider>;
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
    }

    export interface $HeightProviderType<P extends $HeightProvider> {
        codec(): $MapCodec<P>;
    }
    export const $HeightProviderType: {
        readonly BIASED_TO_BOTTOM: $HeightProviderType<$BiasedToBottomHeight>;
        readonly CONSTANT: $HeightProviderType<$ConstantHeight>;
        readonly TRAPEZOID: $HeightProviderType<$TrapezoidHeight>;
        readonly UNIFORM: $HeightProviderType<$UniformHeight>;
        readonly VERY_BIASED_TO_BOTTOM: $HeightProviderType<$VeryBiasedToBottomHeight>;
        readonly WEIGHTED_LIST: $HeightProviderType<$WeightedListHeight>;
    };

    export class $BiasedToBottomHeight {
        private constructor();
        static CODEC: $MapCodec<$BiasedToBottomHeight>;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>, arg2: number): $BiasedToBottomHeight;
    }
    export interface $BiasedToBottomHeight extends $HeightProvider {
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $ConstantHeight {
        private constructor();
        static CODEC: $MapCodec<$ConstantHeight>;
        static ZERO: $ConstantHeight;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>): $ConstantHeight;
    }
    export interface $ConstantHeight extends $HeightProvider {
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        get value(): $VerticalAnchor;
        getValue(): $VerticalAnchor;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $TrapezoidHeight {
        private constructor();
        static CODEC: $MapCodec<$TrapezoidHeight>;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>, arg2: number): $TrapezoidHeight;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>): $TrapezoidHeight;
    }
    export interface $TrapezoidHeight extends $HeightProvider {
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $UniformHeight {
        private constructor();
        static CODEC: $MapCodec<$UniformHeight>;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>): $UniformHeight;
    }
    export interface $UniformHeight extends $HeightProvider {
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $VeryBiasedToBottomHeight {
        private constructor();
        static CODEC: $MapCodec<$VeryBiasedToBottomHeight>;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>, arg2: number): $VeryBiasedToBottomHeight;
    }
    export interface $VeryBiasedToBottomHeight extends $HeightProvider {
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $WeightedListHeight {
        constructor(arg0: $SimpleWeightedRandomList<$HeightProvider>);
        static CODEC: $MapCodec<$WeightedListHeight>;
    }
    export interface $WeightedListHeight extends $HeightProvider {
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
    }

    export type $HeightProviderType_<Host0 extends $HeightProvider = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($HeightProviderType<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "codec": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
