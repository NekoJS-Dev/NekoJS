import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List, $Optional, $UUID } from "java:java/util";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $EndCrystal, $EnderDragon } from "java:net/minecraft/world/entity/boss/enderdragon";

declare module "java:net/minecraft/world/level/dimension/end" {
    export class $EndDragonFight {
        constructor(arg0: $ServerLevel, arg1: number, arg2: $EndDragonFight$Data);
        constructor(arg0: $ServerLevel, arg1: number, arg2: $EndDragonFight$Data, arg3: $BlockPos_);
        static ARENA_TICKET_LEVEL: number;
        static DRAGON_SPAWN_Y: number;
        static TIME_BETWEEN_PLAYER_SCANS: number;
        get crystalsAlive(): number;
        getCrystalsAlive(): number;
        get dragonUUID(): $UUID;
        getDragonUUID(): $UUID;
        addPlayer(arg0: $ServerPlayer): void;
        hasPreviouslyKilledDragon(): boolean;
        onCrystalDestroyed(arg0: $EndCrystal, arg1: $DamageSource): void;
        removeAllGateways(): void;
        removePlayer(arg0: $ServerPlayer): void;
        resetSpikeCrystals(): void;
        saveData(): $EndDragonFight$Data;
        setDragonKilled(arg0: $EnderDragon): void;
        skipArenaLoadedCheck(): void;
        tick(): void;
        tryRespawn(): void;
        updateDragon(arg0: $EnderDragon): void;
    }

    export class $EndDragonFight$Data extends $Record {
        constructor(needsStateScanning: boolean, dragonKilled: boolean, previouslyKilled: boolean, isRespawning: boolean, dragonUUID: $Optional<$UUID>, exitPortalLocation: $Optional<$BlockPos>, gateways: $Optional<$List<number>>);
        static CODEC: $Codec<$EndDragonFight$Data>;
        static DEFAULT: $EndDragonFight$Data;
        get respawning(): boolean;
        isRespawning(): boolean;
        dragonKilled(): boolean;
        dragonUUID(): $Optional<$UUID>;
        equals(arg0: unknown): boolean;
        exitPortalLocation(): $Optional<$BlockPos>;
        gateways(): $Optional<$List<number>>;
        hashCode(): number;
        needsStateScanning(): boolean;
        previouslyKilled(): boolean;
        toString(): string;
    }

}
