import { $Codec } from "java:com/mojang/serialization";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $IntProvider } from "java:net/minecraft/util/valueproviders";
import { $LevelSimulatedReader } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $TreeConfiguration } from "java:net/minecraft/world/level/levelgen/feature/configurations";

declare module "java:net/minecraft/world/level/levelgen/feature/foliageplacers" {
    export class $FoliagePlacer {
        constructor(arg0: $IntProvider, arg1: $IntProvider);
        static CODEC: $Codec<$FoliagePlacer>;
        createFoliage(arg0: $LevelSimulatedReader, arg1: $FoliagePlacer$FoliageSetter, arg2: $RandomSource, arg3: $TreeConfiguration, arg4: number, arg5: $FoliagePlacer$FoliageAttachment, arg6: number, arg7: number): void;
        foliageHeight(arg0: $RandomSource, arg1: number, arg2: $TreeConfiguration): number;
        foliageRadius(arg0: $RandomSource, arg1: number): number;
    }

    export class $FoliagePlacer$FoliageAttachment {
        constructor(arg0: $BlockPos_, arg1: number, arg2: boolean);
        doubleTrunk(): boolean;
        pos(): $BlockPos;
        radiusOffset(): number;
    }

    export interface $FoliagePlacer$FoliageSetter {
        isSet(arg0: $BlockPos_): boolean;
        set(arg0: $BlockPos_, arg1: $BlockState_): void;
    }

}
