import { $Class } from "java:java/lang";
import { $Type } from "java:java/lang/reflect";

declare module "java:com/google/gson/reflect" {
    export class $TypeToken<T> {
        get rawType(): $Class<any>;
        getRawType(): $Class<any>;
        get type(): $Type;
        getType(): $Type;
        static getArray(arg0: $Type): $TypeToken<any>;
        static getParameterized(arg0: $Type, arg1?: $Type[]): $TypeToken<any>;
        static get<T>(arg0: $Class<T>): $TypeToken<T>;
        static get(arg0: $Type): $TypeToken<any>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        isAssignableFrom(arg0: $TypeToken<any>): boolean;
        isAssignableFrom(arg0: $Class<any>): boolean;
        isAssignableFrom(arg0: $Type): boolean;
        toString(): string;
    }

}
