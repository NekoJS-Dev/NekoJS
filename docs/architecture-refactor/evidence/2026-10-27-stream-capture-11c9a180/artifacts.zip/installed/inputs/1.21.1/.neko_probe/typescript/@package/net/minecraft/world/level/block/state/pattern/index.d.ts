import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $LevelReader } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";

declare module "java:net/minecraft/world/level/block/state/pattern" {
    export class $BlockInWorld {
        constructor(arg0: $LevelReader, arg1: $BlockPos_, arg2: boolean);
        get entity(): $BlockEntity;
        getEntity(): $BlockEntity;
        get level(): $LevelReader;
        getLevel(): $LevelReader;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
        static hasState(arg0: $Predicate_<$BlockState, $BlockState, boolean>): $Predicate<$BlockInWorld>;
    }

}
