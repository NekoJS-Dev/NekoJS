import { $ApiTypeRef } from "java:com/tkisor/nekojs/api/surface";
import { $TypeDecl } from "java:com/tkisor/nekojs/probe/ir";
import { $Record } from "java:java/lang";
import { $List, $Map, $Set } from "java:java/util";

declare module "java:com/tkisor/nekojs/probe/events" {
    export class $ClassEditor {
        addMethod(name: string, returnType: unknown, paramSpecs?: unknown[]): $ClassEditor;
        addParam(name: string, paramName: string, type: unknown): $ClassEditor;
        addStaticMethod(name: string, returnType: unknown, paramSpecs?: unknown[]): $ClassEditor;
        changeFieldType(name: string, type: unknown): $ClassEditor;
        changeParamType(name: string, index: number, type: unknown): $ClassEditor;
        changeParamType(name: string, paramName: string, type: unknown): $ClassEditor;
        changeReturnType(name: string, type: unknown): $ClassEditor;
        changeSuper(type: unknown): $ClassEditor;
        hasField(name: string): boolean;
        hasMethod(name: string): boolean;
        hideField(name: string): $ClassEditor;
        hideMethod(name: string): $ClassEditor;
        hide(): $ClassEditor;
        markOptional(name: string, paramName: string): $ClassEditor;
        removeParam(name: string, index: number): $ClassEditor;
        renameClass(newName: string): $ClassEditor;
        renameField(name: string, newName: string): $ClassEditor;
        renameMethod(name: string, newName: string): $ClassEditor;
        renameParam(name: string, paramName: string, newName: string): $ClassEditor;
        setDoc(doc: string): $ClassEditor;
        setFieldDoc(name: string, doc: string): $ClassEditor;
        setMethodDoc(name: string, doc: string): $ClassEditor;
    }

    export class $GlobalDecl extends $Record {
        constructor(name: string, type: $ApiTypeRef);
        equals(o: unknown): boolean;
        hashCode(): number;
        name(): string;
        toString(): string;
        type(): $ApiTypeRef;
    }

    export class $ProbeAddGlobalEventJS {
        constructor();
        add(name: string, typeDesc: unknown): void;
        globals(): $List<$GlobalDecl>;
    }

    export class $ProbeAssignTypeEventJS {
        constructor();
        static applyTo(d: $TypeDecl, map: ($Map<string, $ApiTypeRef> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, $ApiTypeRef>>))): number;
        assignments(): $Map<string, $ApiTypeRef>;
        assign(javaFqn: string, typeDesc: unknown): void;
        has(javaFqn: string): boolean;
    }

    export class $ProbeModifyTypeEventJS {
        constructor(decls: ($Map<string, $TypeDecl> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, $TypeDecl>>)));
        static collectEditedSymbolFqns(d: $TypeDecl, classPackage: string): $Set<string>;
        array(element: unknown): $ApiTypeRef;
        forClass(fqn: string): $ClassEditor;
        hasClass(fqn: string): boolean;
        type(desc: unknown): $ApiTypeRef;
        union(a: unknown, b: unknown, rest?: unknown[]): $ApiTypeRef;
    }

    export class $ProbeSnippetEventJS {
        constructor();
        add(name: string, prefix: string, body: string, description: string): void;
        add(name: string, prefix: string, body: string): void;
        snippets(): $List<$Snippet>;
    }

    export class $Snippet extends $Record {
        constructor(name: string, prefix: string, body: string, description: string);
        body(): string;
        description(): string;
        equals(o: unknown): boolean;
        hashCode(): number;
        name(): string;
        prefix(): string;
        toString(): string;
    }

}
