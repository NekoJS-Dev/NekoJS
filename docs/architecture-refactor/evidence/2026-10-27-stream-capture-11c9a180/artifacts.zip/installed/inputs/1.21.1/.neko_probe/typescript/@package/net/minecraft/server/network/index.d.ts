import { $GameProfile } from "java:com/mojang/authlib";
import { $EpollEventLoopGroup } from "java:io/netty/channel/epoll";
import { $NioEventLoopGroup } from "java:io/netty/channel/nio";
import { $Exception, $Iterable, $Record, $Throwable } from "java:java/lang";
import { $InetAddress, $SocketAddress } from "java:java/net";
import { $List, $Set } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $CrashReport, $CrashReportCategory } from "java:net/minecraft";
import { $Connection, $ConnectionProtocol, $ConnectionProtocol_, $DisconnectionDetails, $PacketSendListener, $TickablePacketListener } from "java:net/minecraft/network";
import { $ChatType$Bound, $Component, $Component_, $FilterMask, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $Packet, $PacketFlow, $PacketFlow_ } from "java:net/minecraft/network/protocol";
import { $ServerCommonPacketListener, $ServerboundClientInformationPacket, $ServerboundCustomPayloadPacket, $ServerboundKeepAlivePacket, $ServerboundPongPacket, $ServerboundResourcePackPacket } from "java:net/minecraft/network/protocol/common";
import { $CustomPacketPayload, $CustomPacketPayload$Type, $CustomPacketPayload_ } from "java:net/minecraft/network/protocol/common/custom";
import { $ServerboundCookieResponsePacket } from "java:net/minecraft/network/protocol/cookie";
import { $ServerGamePacketListener, $ServerboundAcceptTeleportationPacket, $ServerboundBlockEntityTagQueryPacket, $ServerboundChangeDifficultyPacket, $ServerboundChatAckPacket, $ServerboundChatCommandPacket, $ServerboundChatCommandSignedPacket, $ServerboundChatPacket, $ServerboundChatSessionUpdatePacket, $ServerboundChunkBatchReceivedPacket, $ServerboundClientCommandPacket, $ServerboundCommandSuggestionPacket, $ServerboundConfigurationAcknowledgedPacket, $ServerboundContainerButtonClickPacket, $ServerboundContainerClickPacket, $ServerboundContainerClosePacket, $ServerboundContainerSlotStateChangedPacket, $ServerboundDebugSampleSubscriptionPacket, $ServerboundEditBookPacket, $ServerboundEntityTagQueryPacket, $ServerboundInteractPacket, $ServerboundJigsawGeneratePacket, $ServerboundLockDifficultyPacket, $ServerboundMovePlayerPacket, $ServerboundMoveVehiclePacket, $ServerboundPaddleBoatPacket, $ServerboundPickItemPacket, $ServerboundPlaceRecipePacket, $ServerboundPlayerAbilitiesPacket, $ServerboundPlayerActionPacket, $ServerboundPlayerCommandPacket, $ServerboundPlayerInputPacket, $ServerboundRecipeBookChangeSettingsPacket, $ServerboundRecipeBookSeenRecipePacket, $ServerboundRenameItemPacket, $ServerboundSeenAdvancementsPacket, $ServerboundSelectTradePacket, $ServerboundSetBeaconPacket, $ServerboundSetCarriedItemPacket, $ServerboundSetCommandBlockPacket, $ServerboundSetCommandMinecartPacket, $ServerboundSetCreativeModeSlotPacket, $ServerboundSetJigsawBlockPacket, $ServerboundSetStructureBlockPacket, $ServerboundSignUpdatePacket, $ServerboundSwingPacket, $ServerboundTeleportToEntityPacket, $ServerboundUseItemOnPacket, $ServerboundUseItemPacket } from "java:net/minecraft/network/protocol/game";
import { $ServerboundPingRequestPacket } from "java:net/minecraft/network/protocol/ping";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $ClientInformation, $ServerPlayer } from "java:net/minecraft/server/level";
import { $ReentrantBlockableEventLoop } from "java:net/minecraft/util/thread";
import { $RelativeMovement, $RelativeMovement_ } from "java:net/minecraft/world/entity";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $LevelChunk } from "java:net/minecraft/world/level/chunk";
import { $ConnectionType, $ConnectionType_ } from "java:net/neoforged/neoforge/network/connection";

declare module "java:net/minecraft/server/network" {
    export class $CommonListenerCookie extends $Record {
        constructor(arg0: $GameProfile, arg1: number, arg2: $ClientInformation, arg3: boolean);
        constructor(gameProfile: $GameProfile, latency: number, clientInformation: $ClientInformation, transferred: boolean, connectionType: $ConnectionType_);
        static createInitial(arg0: $GameProfile, arg1: boolean): $CommonListenerCookie;
        clientInformation(): $ClientInformation;
        connectionType(): $ConnectionType;
        equals(arg0: unknown): boolean;
        gameProfile(): $GameProfile;
        hashCode(): number;
        latency(): number;
        toString(): string;
        transferred(): boolean;
    }

    export class $FilteredText extends $Record {
        constructor(arg0: string, arg1: $FilterMask);
        static EMPTY: $FilteredText;
        isFiltered(): boolean;
        static fullyFiltered(arg0: string): $FilteredText;
        static passThrough(arg0: string): $FilteredText;
        equals(arg0: unknown): boolean;
        filteredOrEmpty(): string;
        filtered(): string;
        hashCode(): number;
        mask(): $FilterMask;
        raw(): string;
        toString(): string;
    }

    export class $PlayerChunkSender {
        constructor(arg0: boolean);
        static MAX_CHUNKS_PER_TICK: number;
        static MIN_CHUNKS_PER_TICK: number;
        dropChunk(arg0: $ServerPlayer, arg1: $ChunkPos): void;
        isPending(arg0: number): boolean;
        markChunkPendingToSend(arg0: $LevelChunk): void;
        onChunkBatchReceivedByClient(arg0: number): void;
        sendNextChunks(arg0: $ServerPlayer): void;
    }

    export class $ServerCommonPacketListenerImpl implements $ServerCommonPacketListener {
        constructor(arg0: $MinecraftServer, arg1: $Connection, arg2: $CommonListenerCookie);
        static LATENCY_CHECK_INTERVAL: number;
        get connectionType(): $ConnectionType;
        getConnectionType(): $ConnectionType;
        get connection(): $Connection;
        getConnection(): $Connection;
        get mainThreadEventLoop(): $ReentrantBlockableEventLoop<any>;
        getMainThreadEventLoop(): $ReentrantBlockableEventLoop<any>;
        get owner(): $GameProfile;
        getOwner(): $GameProfile;
        get acceptingMessages(): boolean;
        isAcceptingMessages(): boolean;
        createDisconnectionInfo(arg0: $Component_, arg1: $Throwable): $DisconnectionDetails;
        disconnect(arg0: $DisconnectionDetails): void;
        disconnect(arg0: $Component_): void;
        fillCrashReport(arg0: $CrashReport): void;
        fillListenerSpecificCrashDetails(arg0: $CrashReport, arg1: $CrashReportCategory): void;
        flow(): $PacketFlow;
        handleClientInformation(arg0: $ServerboundClientInformationPacket): void;
        handleCookieResponse(arg0: $ServerboundCookieResponsePacket): void;
        handleCustomPayload(arg0: $ServerboundCustomPayloadPacket): void;
        handleKeepAlive(arg0: $ServerboundKeepAlivePacket): void;
        handlePong(arg0: $ServerboundPongPacket): void;
        handleResourcePackResponse(arg0: $ServerboundResourcePackPacket): void;
        hasChannel(arg0: $CustomPacketPayload$Type<any>): boolean;
        hasChannel(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): boolean;
        hasChannel(arg0: $ResourceLocation_): boolean;
        latency(): number;
        onDisconnect(arg0: $DisconnectionDetails): void;
        onPacketError(arg0: $Packet<any>, arg1: $Exception): void;
        protocol(): $ConnectionProtocol;
        resumeFlushing(): void;
        send(arg0: $Packet<any>, arg1: $PacketSendListener): void;
        send(arg0: $Packet<any>): void;
        send(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>, arg1: $PacketSendListener): void;
        send(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): void;
        shouldHandleMessage(arg0: $Packet<any>): boolean;
        suspendFlushing(): void;
    }

    export class $ServerConnectionListener {
        constructor(arg0: $MinecraftServer);
        static SERVER_EPOLL_EVENT_GROUP: $Supplier<$EpollEventLoopGroup>;
        static SERVER_EVENT_GROUP: $Supplier<$NioEventLoopGroup>;
        running: boolean;
        get connections(): $List<$Connection>;
        getConnections(): $List<$Connection>;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        startMemoryChannel(): $SocketAddress;
        startTcpServerListener(arg0: $InetAddress, arg1: number): void;
        stop(): void;
        tick(): void;
    }

    export class $ServerGamePacketListenerImpl extends $ServerCommonPacketListenerImpl implements $ServerGamePacketListener, $ServerPlayerConnection, $TickablePacketListener {
        constructor(arg0: $MinecraftServer, arg1: $Connection, arg2: $ServerPlayer, arg3: $CommonListenerCookie);
        chunkSender: $PlayerChunkSender;
        get player(): $ServerPlayer;
        set player(value: $ServerPlayer);
        get connectionType(): $ConnectionType;
        getConnectionType(): $ConnectionType;
        get connection(): $Connection;
        getConnection(): $Connection;
        get mainThreadEventLoop(): $ReentrantBlockableEventLoop<any>;
        getMainThreadEventLoop(): $ReentrantBlockableEventLoop<any>;
        getPlayer(): $ServerPlayer;
        get remoteAddress(): $SocketAddress;
        getRemoteAddress(): $SocketAddress;
        get acceptingMessages(): boolean;
        isAcceptingMessages(): boolean;
        ackBlockChangesUpTo(arg0: number): void;
        addPendingMessage(arg0: $PlayerChatMessage): void;
        createDisconnectionInfo(arg0: $Component_, arg1: $Throwable): $DisconnectionDetails;
        disconnect(arg0: $DisconnectionDetails): void;
        disconnect(arg0: $Component_): void;
        fillCrashReport(arg0: $CrashReport): void;
        fillListenerSpecificCrashDetails(arg0: $CrashReport, arg1: $CrashReportCategory): void;
        flow(): $PacketFlow;
        handleAcceptTeleportPacket(arg0: $ServerboundAcceptTeleportationPacket): void;
        handleAnimate(arg0: $ServerboundSwingPacket): void;
        handleBlockEntityTagQuery(arg0: $ServerboundBlockEntityTagQueryPacket): void;
        handleChangeDifficulty(arg0: $ServerboundChangeDifficultyPacket): void;
        handleChatAck(arg0: $ServerboundChatAckPacket): void;
        handleChatCommand(arg0: $ServerboundChatCommandPacket): void;
        handleChatSessionUpdate(arg0: $ServerboundChatSessionUpdatePacket): void;
        handleChat(arg0: $ServerboundChatPacket): void;
        handleChunkBatchReceived(arg0: $ServerboundChunkBatchReceivedPacket): void;
        handleClientCommand(arg0: $ServerboundClientCommandPacket): void;
        handleClientInformation(arg0: $ServerboundClientInformationPacket): void;
        handleConfigurationAcknowledged(arg0: $ServerboundConfigurationAcknowledgedPacket): void;
        handleContainerButtonClick(arg0: $ServerboundContainerButtonClickPacket): void;
        handleContainerClick(arg0: $ServerboundContainerClickPacket): void;
        handleContainerClose(arg0: $ServerboundContainerClosePacket): void;
        handleContainerSlotStateChanged(arg0: $ServerboundContainerSlotStateChangedPacket): void;
        handleCookieResponse(arg0: $ServerboundCookieResponsePacket): void;
        handleCustomCommandSuggestions(arg0: $ServerboundCommandSuggestionPacket): void;
        handleCustomPayload(arg0: $ServerboundCustomPayloadPacket): void;
        handleDebugSampleSubscription(arg0: $ServerboundDebugSampleSubscriptionPacket): void;
        handleEditBook(arg0: $ServerboundEditBookPacket): void;
        handleEntityTagQuery(arg0: $ServerboundEntityTagQueryPacket): void;
        handleInteract(arg0: $ServerboundInteractPacket): void;
        handleJigsawGenerate(arg0: $ServerboundJigsawGeneratePacket): void;
        handleKeepAlive(arg0: $ServerboundKeepAlivePacket): void;
        handleLockDifficulty(arg0: $ServerboundLockDifficultyPacket): void;
        handleMovePlayer(arg0: $ServerboundMovePlayerPacket): void;
        handleMoveVehicle(arg0: $ServerboundMoveVehiclePacket): void;
        handlePaddleBoat(arg0: $ServerboundPaddleBoatPacket): void;
        handlePickItem(arg0: $ServerboundPickItemPacket): void;
        handlePingRequest(arg0: $ServerboundPingRequestPacket): void;
        handlePlaceRecipe(arg0: $ServerboundPlaceRecipePacket): void;
        handlePlayerAbilities(arg0: $ServerboundPlayerAbilitiesPacket): void;
        handlePlayerAction(arg0: $ServerboundPlayerActionPacket): void;
        handlePlayerCommand(arg0: $ServerboundPlayerCommandPacket): void;
        handlePlayerInput(arg0: $ServerboundPlayerInputPacket): void;
        handlePong(arg0: $ServerboundPongPacket): void;
        handleRecipeBookChangeSettingsPacket(arg0: $ServerboundRecipeBookChangeSettingsPacket): void;
        handleRecipeBookSeenRecipePacket(arg0: $ServerboundRecipeBookSeenRecipePacket): void;
        handleRenameItem(arg0: $ServerboundRenameItemPacket): void;
        handleResourcePackResponse(arg0: $ServerboundResourcePackPacket): void;
        handleSeenAdvancements(arg0: $ServerboundSeenAdvancementsPacket): void;
        handleSelectTrade(arg0: $ServerboundSelectTradePacket): void;
        handleSetBeaconPacket(arg0: $ServerboundSetBeaconPacket): void;
        handleSetCarriedItem(arg0: $ServerboundSetCarriedItemPacket): void;
        handleSetCommandBlock(arg0: $ServerboundSetCommandBlockPacket): void;
        handleSetCommandMinecart(arg0: $ServerboundSetCommandMinecartPacket): void;
        handleSetCreativeModeSlot(arg0: $ServerboundSetCreativeModeSlotPacket): void;
        handleSetJigsawBlock(arg0: $ServerboundSetJigsawBlockPacket): void;
        handleSetStructureBlock(arg0: $ServerboundSetStructureBlockPacket): void;
        handleSignUpdate(arg0: $ServerboundSignUpdatePacket): void;
        handleSignedChatCommand(arg0: $ServerboundChatCommandSignedPacket): void;
        handleTeleportToEntityPacket(arg0: $ServerboundTeleportToEntityPacket): void;
        handleUseItemOn(arg0: $ServerboundUseItemOnPacket): void;
        handleUseItem(arg0: $ServerboundUseItemPacket): void;
        hasChannel(arg0: $CustomPacketPayload$Type<any>): boolean;
        hasChannel(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): boolean;
        hasChannel(arg0: $ResourceLocation_): boolean;
        onDisconnect(arg0: $DisconnectionDetails): void;
        onPacketError(arg0: $Packet<any>, arg1: $Exception): void;
        protocol(): $ConnectionProtocol;
        resetPosition(): void;
        sendBundled(arg0: ($Iterable<$CustomPacketPayload> | ($CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>)[])): void;
        sendBundled(arg0?: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>[]): void;
        sendDisguisedChatMessage(arg0: $Component_, arg1: $ChatType$Bound): void;
        sendPlayerChatMessage(arg0: $PlayerChatMessage, arg1: $ChatType$Bound): void;
        send(arg0: $Packet<any>, arg1: $PacketSendListener): void;
        send(arg0: $Packet<any>): void;
        send(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>, arg1: $PacketSendListener): void;
        send(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): void;
        shouldHandleMessage(arg0: $Packet<any>): boolean;
        switchToConfig(): void;
        teleport(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $Set<$RelativeMovement>): void;
        teleport(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): void;
        tick(): void;
    }

    export interface $ServerPlayerConnection {
        getPlayer(): $ServerPlayer;
        send(arg0: $Packet<any>): void;
    }

    export interface $TextFilter {
        join(): void;
        leave(): void;
        processMessageBundle(arg0: ($List<string> | (string)[])): $CompletableFuture<$List<$FilteredText>>;
        processStreamMessage(arg0: string): $CompletableFuture<$FilteredText>;
    }
    export const $TextFilter: {
        readonly DUMMY: $TextFilter;
    };

}
