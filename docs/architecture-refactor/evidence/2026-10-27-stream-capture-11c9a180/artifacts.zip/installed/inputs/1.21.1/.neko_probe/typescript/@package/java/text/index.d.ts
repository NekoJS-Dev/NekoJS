import { $Serializable } from "java:java/io";
import { $Cloneable, $Enum, $StringBuffer } from "java:java/lang";
import { $RoundingMode, $RoundingMode_ } from "java:java/math";
import { $Calendar, $Currency, $Date, $Locale, $Map, $Set, $TimeZone } from "java:java/util";

declare module "java:java/text" {
    export interface $AttributedCharacterIterator extends $CharacterIterator {
        getAllAttributeKeys(): $Set<$AttributedCharacterIterator$Attribute>;
        getAttributes(): $Map<$AttributedCharacterIterator$Attribute, unknown>;
        getAttribute(arg0: $AttributedCharacterIterator$Attribute): unknown;
        getRunLimit(arg0: $AttributedCharacterIterator$Attribute): number;
        getRunLimit(arg0: $Set<$AttributedCharacterIterator$Attribute>): number;
        getRunLimit(): number;
        getRunStart(arg0: $AttributedCharacterIterator$Attribute): number;
        getRunStart(arg0: $Set<$AttributedCharacterIterator$Attribute>): number;
        getRunStart(): number;
    }

    export class $AttributedCharacterIterator$Attribute implements $Serializable {
        static INPUT_METHOD_SEGMENT: $AttributedCharacterIterator$Attribute;
        static LANGUAGE: $AttributedCharacterIterator$Attribute;
        static READING: $AttributedCharacterIterator$Attribute;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $CharacterIterator extends $Cloneable {
        clone(): unknown;
        current(): string;
        first(): string;
        getBeginIndex(): number;
        getEndIndex(): number;
        getIndex(): number;
        last(): string;
        next(): string;
        previous(): string;
        setIndex(arg0: number): string;
    }
    export const $CharacterIterator: {
        readonly DONE: string;
    };

    export class $DecimalFormat extends $NumberFormat {
        constructor();
        constructor(arg0: string);
        constructor(arg0: string, arg1: $DecimalFormatSymbols);
        get currency(): $Currency;
        getCurrency(): $Currency;
        set currency(value: $Currency);
        get decimalFormatSymbols(): $DecimalFormatSymbols;
        getDecimalFormatSymbols(): $DecimalFormatSymbols;
        set decimalFormatSymbols(value: $DecimalFormatSymbols);
        get groupingSize(): number;
        getGroupingSize(): number;
        set groupingSize(value: number);
        get maximumFractionDigits(): number;
        getMaximumFractionDigits(): number;
        set maximumFractionDigits(value: number);
        get maximumIntegerDigits(): number;
        getMaximumIntegerDigits(): number;
        set maximumIntegerDigits(value: number);
        get minimumFractionDigits(): number;
        getMinimumFractionDigits(): number;
        set minimumFractionDigits(value: number);
        get minimumIntegerDigits(): number;
        getMinimumIntegerDigits(): number;
        set minimumIntegerDigits(value: number);
        get multiplier(): number;
        getMultiplier(): number;
        set multiplier(value: number);
        get negativePrefix(): string;
        getNegativePrefix(): string;
        set negativePrefix(value: string);
        get negativeSuffix(): string;
        getNegativeSuffix(): string;
        set negativeSuffix(value: string);
        get positivePrefix(): string;
        getPositivePrefix(): string;
        set positivePrefix(value: string);
        get positiveSuffix(): string;
        getPositiveSuffix(): string;
        set positiveSuffix(value: string);
        get roundingMode(): $RoundingMode;
        getRoundingMode(): $RoundingMode;
        set roundingMode(value: $RoundingMode_);
        get decimalSeparatorAlwaysShown(): boolean;
        isDecimalSeparatorAlwaysShown(): boolean;
        set decimalSeparatorAlwaysShown(value: boolean);
        get parseBigDecimal(): boolean;
        isParseBigDecimal(): boolean;
        set parseBigDecimal(value: boolean);
        applyLocalizedPattern(arg0: string): void;
        applyPattern(arg0: string): void;
        clone(): unknown;
        equals(arg0: unknown): boolean;
        formatToCharacterIterator(arg0: unknown): $AttributedCharacterIterator;
        format(arg0: number, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: number): string;
        format(arg0: unknown, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: unknown): string;
        format(arg0: number, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: number): string;
        hashCode(): number;
        parse(arg0: string, arg1: $ParsePosition): number;
        parse(arg0: string): number;
        setCurrency(arg0: $Currency): void;
        setDecimalFormatSymbols(arg0: $DecimalFormatSymbols): void;
        setDecimalSeparatorAlwaysShown(arg0: boolean): void;
        setGroupingSize(arg0: number): void;
        setGroupingUsed(arg0: boolean): void;
        setMaximumFractionDigits(arg0: number): void;
        setMaximumIntegerDigits(arg0: number): void;
        setMinimumFractionDigits(arg0: number): void;
        setMinimumIntegerDigits(arg0: number): void;
        setMultiplier(arg0: number): void;
        setNegativePrefix(arg0: string): void;
        setNegativeSuffix(arg0: string): void;
        setParseBigDecimal(arg0: boolean): void;
        setPositivePrefix(arg0: string): void;
        setPositiveSuffix(arg0: string): void;
        setRoundingMode(arg0: $RoundingMode_): void;
        toLocalizedPattern(): string;
        toPattern(): string;
    }

    export class $DecimalFormatSymbols implements $Cloneable, $Serializable {
        constructor();
        constructor(arg0: $Locale);
        get currencySymbol(): string;
        getCurrencySymbol(): string;
        set currencySymbol(value: string);
        get currency(): $Currency;
        getCurrency(): $Currency;
        set currency(value: $Currency);
        get decimalSeparator(): string;
        getDecimalSeparator(): string;
        set decimalSeparator(value: string);
        get digit(): string;
        getDigit(): string;
        set digit(value: string);
        get exponentSeparator(): string;
        getExponentSeparator(): string;
        set exponentSeparator(value: string);
        get groupingSeparator(): string;
        getGroupingSeparator(): string;
        set groupingSeparator(value: string);
        get infinity(): string;
        getInfinity(): string;
        set infinity(value: string);
        get internationalCurrencySymbol(): string;
        getInternationalCurrencySymbol(): string;
        set internationalCurrencySymbol(value: string);
        get locale(): $Locale;
        getLocale(): $Locale;
        get minusSign(): string;
        getMinusSign(): string;
        set minusSign(value: string);
        get monetaryDecimalSeparator(): string;
        getMonetaryDecimalSeparator(): string;
        set monetaryDecimalSeparator(value: string);
        get monetaryGroupingSeparator(): string;
        getMonetaryGroupingSeparator(): string;
        set monetaryGroupingSeparator(value: string);
        get naN(): string;
        getNaN(): string;
        set naN(value: string);
        get patternSeparator(): string;
        getPatternSeparator(): string;
        set patternSeparator(value: string);
        get perMill(): string;
        getPerMill(): string;
        set perMill(value: string);
        get percent(): string;
        getPercent(): string;
        set percent(value: string);
        get zeroDigit(): string;
        getZeroDigit(): string;
        set zeroDigit(value: string);
        static getAvailableLocales(): $Locale[];
        static getInstance(arg0: $Locale): $DecimalFormatSymbols;
        static getInstance(): $DecimalFormatSymbols;
        clone(): unknown;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        setCurrencySymbol(arg0: string): void;
        setCurrency(arg0: $Currency): void;
        setDecimalSeparator(arg0: string): void;
        setDigit(arg0: string): void;
        setExponentSeparator(arg0: string): void;
        setGroupingSeparator(arg0: string): void;
        setInfinity(arg0: string): void;
        setInternationalCurrencySymbol(arg0: string): void;
        setMinusSign(arg0: string): void;
        setMonetaryDecimalSeparator(arg0: string): void;
        setMonetaryGroupingSeparator(arg0: string): void;
        setNaN(arg0: string): void;
        setPatternSeparator(arg0: string): void;
        setPerMill(arg0: string): void;
        setPercent(arg0: string): void;
        setZeroDigit(arg0: string): void;
    }

    export class $FieldPosition {
        constructor(arg0: number);
        constructor(arg0: $Format$Field);
        constructor(arg0: $Format$Field, arg1: number);
        get beginIndex(): number;
        getBeginIndex(): number;
        set beginIndex(value: number);
        get endIndex(): number;
        getEndIndex(): number;
        set endIndex(value: number);
        get fieldAttribute(): $Format$Field;
        getFieldAttribute(): $Format$Field;
        get field(): number;
        getField(): number;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        setBeginIndex(arg0: number): void;
        setEndIndex(arg0: number): void;
        toString(): string;
    }

    export class $Format implements $Serializable, $Cloneable {
        clone(): unknown;
        formatToCharacterIterator(arg0: unknown): $AttributedCharacterIterator;
        format(arg0: unknown, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: unknown): string;
        parseObject(arg0: string, arg1: $ParsePosition): unknown;
        parseObject(arg0: string): unknown;
    }

    export class $Format$Field extends $AttributedCharacterIterator$Attribute {
    }

    export class $NumberFormat extends $Format {
        static FRACTION_FIELD: number;
        static INTEGER_FIELD: number;
        get currency(): $Currency;
        getCurrency(): $Currency;
        set currency(value: $Currency);
        get maximumFractionDigits(): number;
        getMaximumFractionDigits(): number;
        set maximumFractionDigits(value: number);
        get maximumIntegerDigits(): number;
        getMaximumIntegerDigits(): number;
        set maximumIntegerDigits(value: number);
        get minimumFractionDigits(): number;
        getMinimumFractionDigits(): number;
        set minimumFractionDigits(value: number);
        get minimumIntegerDigits(): number;
        getMinimumIntegerDigits(): number;
        set minimumIntegerDigits(value: number);
        get roundingMode(): $RoundingMode;
        getRoundingMode(): $RoundingMode;
        set roundingMode(value: $RoundingMode_);
        get groupingUsed(): boolean;
        isGroupingUsed(): boolean;
        set groupingUsed(value: boolean);
        get parseIntegerOnly(): boolean;
        isParseIntegerOnly(): boolean;
        set parseIntegerOnly(value: boolean);
        static getAvailableLocales(): $Locale[];
        static getCompactNumberInstance(arg0: $Locale, arg1: $NumberFormat$Style_): $NumberFormat;
        static getCompactNumberInstance(): $NumberFormat;
        static getCurrencyInstance(arg0: $Locale): $NumberFormat;
        static getCurrencyInstance(): $NumberFormat;
        static getInstance(arg0: $Locale): $NumberFormat;
        static getInstance(): $NumberFormat;
        static getIntegerInstance(arg0: $Locale): $NumberFormat;
        static getIntegerInstance(): $NumberFormat;
        static getNumberInstance(arg0: $Locale): $NumberFormat;
        static getNumberInstance(): $NumberFormat;
        static getPercentInstance(arg0: $Locale): $NumberFormat;
        static getPercentInstance(): $NumberFormat;
        clone(): unknown;
        equals(arg0: unknown): boolean;
        format(arg0: number, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: number): string;
        format(arg0: unknown, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: unknown): string;
        format(arg0: number, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: number): string;
        hashCode(): number;
        parseObject(arg0: string, arg1: $ParsePosition): unknown;
        parseObject(arg0: string): unknown;
        parse(arg0: string, arg1: $ParsePosition): number;
        parse(arg0: string): number;
        setCurrency(arg0: $Currency): void;
        setGroupingUsed(arg0: boolean): void;
        setMaximumFractionDigits(arg0: number): void;
        setMaximumIntegerDigits(arg0: number): void;
        setMinimumFractionDigits(arg0: number): void;
        setMinimumIntegerDigits(arg0: number): void;
        setParseIntegerOnly(arg0: boolean): void;
        setRoundingMode(arg0: $RoundingMode_): void;
    }

    export class $NumberFormat$Style {
        static LONG: $NumberFormat$Style;
        static SHORT: $NumberFormat$Style;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $NumberFormat$Style[];
        static valueOf(name: string): $NumberFormat$Style;
    }
    export interface $NumberFormat$Style extends $Enum<$NumberFormat$Style> {}

    export class $ParsePosition {
        constructor(arg0: number);
        get errorIndex(): number;
        getErrorIndex(): number;
        set errorIndex(value: number);
        get index(): number;
        getIndex(): number;
        set index(value: number);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        setErrorIndex(arg0: number): void;
        setIndex(arg0: number): void;
        toString(): string;
    }

    export class $SimpleDateFormat extends $DateFormat {
        constructor();
        constructor(arg0: string);
        constructor(arg0: string, arg1: $DateFormatSymbols);
        constructor(arg0: string, arg1: $Locale);
        get2DigitYearStart(): $Date;
        get dateFormatSymbols(): $DateFormatSymbols;
        getDateFormatSymbols(): $DateFormatSymbols;
        set dateFormatSymbols(value: $DateFormatSymbols);
        applyLocalizedPattern(arg0: string): void;
        applyPattern(arg0: string): void;
        clone(): unknown;
        equals(arg0: unknown): boolean;
        formatToCharacterIterator(arg0: unknown): $AttributedCharacterIterator;
        format(arg0: unknown, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: unknown): string;
        format(arg0: $Date, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: $Date): string;
        hashCode(): number;
        parse(arg0: string, arg1: $ParsePosition): $Date;
        parse(arg0: string): $Date;
        set2DigitYearStart(arg0: $Date): void;
        setDateFormatSymbols(arg0: $DateFormatSymbols): void;
        toLocalizedPattern(): string;
        toPattern(): string;
    }

    export class $DateFormat extends $Format {
        static AM_PM_FIELD: number;
        static DATE_FIELD: number;
        static DAY_OF_WEEK_FIELD: number;
        static DAY_OF_WEEK_IN_MONTH_FIELD: number;
        static DAY_OF_YEAR_FIELD: number;
        static DEFAULT: number;
        static ERA_FIELD: number;
        static FULL: number;
        static HOUR0_FIELD: number;
        static HOUR1_FIELD: number;
        static HOUR_OF_DAY0_FIELD: number;
        static HOUR_OF_DAY1_FIELD: number;
        static LONG: number;
        static MEDIUM: number;
        static MILLISECOND_FIELD: number;
        static MINUTE_FIELD: number;
        static MONTH_FIELD: number;
        static SECOND_FIELD: number;
        static SHORT: number;
        static TIMEZONE_FIELD: number;
        static WEEK_OF_MONTH_FIELD: number;
        static WEEK_OF_YEAR_FIELD: number;
        static YEAR_FIELD: number;
        get calendar(): $Calendar;
        getCalendar(): $Calendar;
        set calendar(value: $Calendar);
        get numberFormat(): $NumberFormat;
        getNumberFormat(): $NumberFormat;
        set numberFormat(value: $NumberFormat);
        get timeZone(): $TimeZone;
        getTimeZone(): $TimeZone;
        set timeZone(value: $TimeZone);
        get lenient(): boolean;
        isLenient(): boolean;
        set lenient(value: boolean);
        static getAvailableLocales(): $Locale[];
        static getDateInstance(arg0: number, arg1: $Locale): $DateFormat;
        static getDateInstance(arg0: number): $DateFormat;
        static getDateInstance(): $DateFormat;
        static getDateTimeInstance(arg0: number, arg1: number, arg2: $Locale): $DateFormat;
        static getDateTimeInstance(arg0: number, arg1: number): $DateFormat;
        static getDateTimeInstance(): $DateFormat;
        static getInstance(): $DateFormat;
        static getTimeInstance(arg0: number, arg1: $Locale): $DateFormat;
        static getTimeInstance(arg0: number): $DateFormat;
        static getTimeInstance(): $DateFormat;
        clone(): unknown;
        equals(arg0: unknown): boolean;
        format(arg0: unknown, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: unknown): string;
        format(arg0: $Date, arg1: $StringBuffer, arg2: $FieldPosition): $StringBuffer;
        format(arg0: $Date): string;
        hashCode(): number;
        parseObject(arg0: string, arg1: $ParsePosition): unknown;
        parseObject(arg0: string): unknown;
        parse(arg0: string, arg1: $ParsePosition): $Date;
        parse(arg0: string): $Date;
        setCalendar(arg0: $Calendar): void;
        setLenient(arg0: boolean): void;
        setNumberFormat(arg0: $NumberFormat): void;
        setTimeZone(arg0: $TimeZone): void;
    }

    export class $DateFormatSymbols implements $Serializable, $Cloneable {
        constructor();
        constructor(arg0: $Locale);
        get amPmStrings(): string[];
        getAmPmStrings(): string[];
        set amPmStrings(value: string[]);
        get eras(): string[];
        getEras(): string[];
        set eras(value: string[]);
        get localPatternChars(): string;
        getLocalPatternChars(): string;
        set localPatternChars(value: string);
        get months(): string[];
        getMonths(): string[];
        set months(value: string[]);
        get shortMonths(): string[];
        getShortMonths(): string[];
        set shortMonths(value: string[]);
        get shortWeekdays(): string[];
        getShortWeekdays(): string[];
        set shortWeekdays(value: string[]);
        get weekdays(): string[];
        getWeekdays(): string[];
        set weekdays(value: string[]);
        get zoneStrings(): string[][];
        getZoneStrings(): string[][];
        set zoneStrings(value: string[][]);
        static getAvailableLocales(): $Locale[];
        static getInstance(arg0: $Locale): $DateFormatSymbols;
        static getInstance(): $DateFormatSymbols;
        clone(): unknown;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        setAmPmStrings(arg0: string[]): void;
        setEras(arg0: string[]): void;
        setLocalPatternChars(arg0: string): void;
        setMonths(arg0: string[]): void;
        setShortMonths(arg0: string[]): void;
        setShortWeekdays(arg0: string[]): void;
        setWeekdays(arg0: string[]): void;
        setZoneStrings(arg0: string[][]): void;
    }

    export type $NumberFormat$Style_ = $NumberFormat$Style | "LONG" | "SHORT";
}
