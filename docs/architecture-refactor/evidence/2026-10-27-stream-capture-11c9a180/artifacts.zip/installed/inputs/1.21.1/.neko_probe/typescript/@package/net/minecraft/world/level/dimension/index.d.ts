import { $Codec, $DataResult, $Dynamic, $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $OptionalLong } from "java:java/util";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $IntProvider } from "java:net/minecraft/util/valueproviders";
import { $Level } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $ChunkGenerator } from "java:net/minecraft/world/level/chunk";

export * as end from "java:net/minecraft/world/level/dimension/end";

declare module "java:net/minecraft/world/level/dimension" {
    export class $DimensionType extends $Record {
        constructor(arg0: $OptionalLong, arg1: boolean, arg2: boolean, arg3: boolean, arg4: boolean, arg5: number, arg6: boolean, arg7: boolean, arg8: number, arg9: number, arg10: number, arg11: $TagKey_<$Block>, arg12: $ResourceLocation_, arg13: number, arg14: $DimensionType$MonsterSettings);
        static BITS_FOR_Y: number;
        static CODEC: $Codec<$Holder<$DimensionType>>;
        static DIRECT_CODEC: $Codec<$DimensionType>;
        static MAX_Y: number;
        static MIN_HEIGHT: number;
        static MIN_Y: number;
        static MOON_BRIGHTNESS_PER_PHASE: number[];
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$DimensionType>>;
        static WAY_ABOVE_MAX_Y: number;
        static WAY_BELOW_MIN_Y: number;
        static Y_SIZE: number;
        static getStorageFolder(arg0: $ResourceKey<$Level>, arg1: $Path): $Path;
        static getTeleportationScale(arg0: $DimensionType, arg1: $DimensionType): number;
        static parseLegacy(arg0: $Dynamic<any>): $DataResult<$ResourceKey<$Level>>;
        ambientLight(): number;
        bedWorks(): boolean;
        coordinateScale(): number;
        effectsLocation(): $ResourceLocation;
        equals(arg0: unknown): boolean;
        fixedTime(): $OptionalLong;
        hasCeiling(): boolean;
        hasFixedTime(): boolean;
        hasRaids(): boolean;
        hasSkyLight(): boolean;
        hashCode(): number;
        height(): number;
        infiniburn(): $TagKey<$Block>;
        logicalHeight(): number;
        minY(): number;
        monsterSettings(): $DimensionType$MonsterSettings;
        monsterSpawnBlockLightLimit(): number;
        monsterSpawnLightTest(): $IntProvider;
        moonPhase(arg0: number): number;
        natural(): boolean;
        piglinSafe(): boolean;
        respawnAnchorWorks(): boolean;
        timeOfDay(arg0: number): number;
        toString(): string;
        ultraWarm(): boolean;
    }

    export class $DimensionType$MonsterSettings extends $Record {
        constructor(arg0: boolean, arg1: boolean, arg2: $IntProvider, arg3: number);
        static CODEC: $MapCodec<$DimensionType$MonsterSettings>;
        equals(arg0: unknown): boolean;
        hasRaids(): boolean;
        hashCode(): number;
        monsterSpawnBlockLightLimit(): number;
        monsterSpawnLightTest(): $IntProvider;
        piglinSafe(): boolean;
        toString(): string;
    }

    export class $LevelStem extends $Record {
        constructor(arg0: $Holder_<$DimensionType>, arg1: $ChunkGenerator);
        static CODEC: $Codec<$LevelStem>;
        static END: $ResourceKey<$LevelStem>;
        static NETHER: $ResourceKey<$LevelStem>;
        static OVERWORLD: $ResourceKey<$LevelStem>;
        equals(arg0: unknown): boolean;
        generator(): $ChunkGenerator;
        hashCode(): number;
        toString(): string;
        type(): $Holder<$DimensionType>;
    }

}
