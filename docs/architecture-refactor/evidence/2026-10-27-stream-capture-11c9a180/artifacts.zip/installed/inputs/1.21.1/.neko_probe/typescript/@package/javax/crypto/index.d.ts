import { $ByteBuffer } from "java:java/nio";
import { $AlgorithmParameters, $Key, $Provider, $SecureRandom } from "java:java/security";
import { $Certificate } from "java:java/security/cert";
import { $AlgorithmParameterSpec } from "java:java/security/spec";

declare module "java:javax/crypto" {
    export class $Cipher {
        static DECRYPT_MODE: number;
        static ENCRYPT_MODE: number;
        static PRIVATE_KEY: number;
        static PUBLIC_KEY: number;
        static SECRET_KEY: number;
        static UNWRAP_MODE: number;
        static WRAP_MODE: number;
        get algorithm(): string;
        getAlgorithm(): string;
        get blockSize(): number;
        getBlockSize(): number;
        get exemptionMechanism(): $ExemptionMechanism;
        getExemptionMechanism(): $ExemptionMechanism;
        get iV(): number[];
        getIV(): number[];
        get parameters(): $AlgorithmParameters;
        getParameters(): $AlgorithmParameters;
        get provider(): $Provider;
        getProvider(): $Provider;
        static getInstance(arg0: string, arg1: string): $Cipher;
        static getInstance(arg0: string, arg1: $Provider): $Cipher;
        static getInstance(arg0: string): $Cipher;
        static getMaxAllowedKeyLength(arg0: string): number;
        static getMaxAllowedParameterSpec(arg0: string): $AlgorithmParameterSpec;
        doFinal(arg0: number[], arg1: number, arg2: number, arg3: number[], arg4: number): number;
        doFinal(arg0: number[], arg1: number, arg2: number, arg3: number[]): number;
        doFinal(arg0: number[], arg1: number, arg2: number): number[];
        doFinal(arg0: number[], arg1: number): number;
        doFinal(arg0: number[]): number[];
        doFinal(arg0: $ByteBuffer, arg1: $ByteBuffer): number;
        doFinal(): number[];
        getOutputSize(arg0: number): number;
        init(arg0: number, arg1: $Key, arg2: $AlgorithmParameters, arg3: $SecureRandom): void;
        init(arg0: number, arg1: $Key, arg2: $AlgorithmParameters): void;
        init(arg0: number, arg1: $Key, arg2: $SecureRandom): void;
        init(arg0: number, arg1: $Key, arg2: $AlgorithmParameterSpec, arg3: $SecureRandom): void;
        init(arg0: number, arg1: $Key, arg2: $AlgorithmParameterSpec): void;
        init(arg0: number, arg1: $Key): void;
        init(arg0: number, arg1: $Certificate, arg2: $SecureRandom): void;
        init(arg0: number, arg1: $Certificate): void;
        toString(): string;
        unwrap(arg0: number[], arg1: string, arg2: number): $Key;
        updateAAD(arg0: number[], arg1: number, arg2: number): void;
        updateAAD(arg0: number[]): void;
        updateAAD(arg0: $ByteBuffer): void;
        update(arg0: number[], arg1: number, arg2: number, arg3: number[], arg4: number): number;
        update(arg0: number[], arg1: number, arg2: number, arg3: number[]): number;
        update(arg0: number[], arg1: number, arg2: number): number[];
        update(arg0: number[]): number[];
        update(arg0: $ByteBuffer, arg1: $ByteBuffer): number;
        wrap(arg0: $Key): number[];
    }

    export class $ExemptionMechanism {
        get name(): string;
        getName(): string;
        get provider(): $Provider;
        getProvider(): $Provider;
        static getInstance(arg0: string, arg1: string): $ExemptionMechanism;
        static getInstance(arg0: string, arg1: $Provider): $ExemptionMechanism;
        static getInstance(arg0: string): $ExemptionMechanism;
        genExemptionBlob(arg0: number[], arg1: number): number;
        genExemptionBlob(arg0: number[]): number;
        genExemptionBlob(): number[];
        getOutputSize(arg0: number): number;
        init(arg0: $Key, arg1: $AlgorithmParameters): void;
        init(arg0: $Key, arg1: $AlgorithmParameterSpec): void;
        init(arg0: $Key): void;
        isCryptoAllowed(arg0: $Key): boolean;
    }

}
