import { $Function as $NekoImport$Function, $Function_ as $NekoImport$Function_ } from "java:it/unimi/dsi/fastutil";
import { $Byte2ByteFunction, $Byte2ByteFunction_, $Byte2CharFunction, $Byte2CharFunction_, $Byte2DoubleFunction, $Byte2DoubleFunction_, $Byte2FloatFunction, $Byte2FloatFunction_, $Byte2IntFunction, $Byte2IntFunction_, $Byte2LongFunction, $Byte2LongFunction_, $Byte2ObjectFunction, $Byte2ObjectFunction_, $Byte2ReferenceFunction, $Byte2ReferenceFunction_, $Byte2ShortFunction, $Byte2ShortFunction_ } from "java:it/unimi/dsi/fastutil/bytes";
import { $Char2ByteFunction, $Char2ByteFunction_, $Char2CharFunction, $Char2CharFunction_, $Char2DoubleFunction, $Char2DoubleFunction_, $Char2FloatFunction, $Char2FloatFunction_, $Char2IntFunction, $Char2IntFunction_, $Char2LongFunction, $Char2LongFunction_, $Char2ObjectFunction, $Char2ObjectFunction_, $Char2ReferenceFunction, $Char2ReferenceFunction_, $Char2ShortFunction, $Char2ShortFunction_ } from "java:it/unimi/dsi/fastutil/chars";
import { $Double2ByteFunction, $Double2ByteFunction_, $Double2CharFunction, $Double2CharFunction_, $Double2DoubleFunction, $Double2DoubleFunction_, $Double2FloatFunction, $Double2FloatFunction_, $Double2IntFunction, $Double2IntFunction_, $Double2LongFunction, $Double2LongFunction_, $Double2ObjectFunction, $Double2ObjectFunction_, $Double2ReferenceFunction, $Double2ReferenceFunction_, $Double2ShortFunction, $Double2ShortFunction_, $DoubleBinaryOperator as $NekoImport$DoubleBinaryOperator, $DoubleBinaryOperator_ as $NekoImport$DoubleBinaryOperator_, $DoubleCollection } from "java:it/unimi/dsi/fastutil/doubles";
import { $Float2ByteFunction, $Float2ByteFunction_, $Float2CharFunction, $Float2CharFunction_, $Float2DoubleFunction, $Float2DoubleFunction_, $Float2FloatFunction, $Float2FloatFunction_, $Float2IntFunction, $Float2IntFunction_, $Float2LongFunction, $Float2LongFunction_, $Float2ObjectFunction, $Float2ObjectFunction_, $Float2ReferenceFunction, $Float2ReferenceFunction_, $Float2ShortFunction, $Float2ShortFunction_ } from "java:it/unimi/dsi/fastutil/floats";
import { $Long2ByteFunction, $Long2ByteFunction_, $Long2CharFunction, $Long2CharFunction_, $Long2DoubleFunction, $Long2DoubleFunction_, $Long2FloatFunction, $Long2FloatFunction_, $Long2IntFunction, $Long2IntFunction_, $Long2LongFunction, $Long2LongFunction_, $Long2ObjectFunction, $Long2ObjectFunction_, $Long2ReferenceFunction, $Long2ReferenceFunction_, $Long2ShortFunction, $Long2ShortFunction_ } from "java:it/unimi/dsi/fastutil/longs";
import { $Object2ByteFunction, $Object2ByteFunction_, $Object2CharFunction, $Object2CharFunction_, $Object2DoubleFunction, $Object2DoubleFunction_, $Object2FloatFunction, $Object2FloatFunction_, $Object2IntFunction, $Object2IntFunction_, $Object2LongFunction, $Object2LongFunction_, $Object2ObjectFunction, $Object2ObjectFunction_, $Object2ReferenceFunction, $Object2ReferenceFunction_, $Object2ShortFunction, $Object2ShortFunction_, $ObjectBidirectionalIterator, $ObjectCollection, $ObjectSet, $Reference2ByteFunction, $Reference2ByteFunction_, $Reference2CharFunction, $Reference2CharFunction_, $Reference2DoubleFunction, $Reference2DoubleFunction_, $Reference2FloatFunction, $Reference2FloatFunction_, $Reference2IntFunction, $Reference2IntFunction_, $Reference2LongFunction, $Reference2LongFunction_, $Reference2ObjectFunction, $Reference2ObjectFunction_, $Reference2ReferenceFunction, $Reference2ReferenceFunction_, $Reference2ShortFunction, $Reference2ShortFunction_ } from "java:it/unimi/dsi/fastutil/objects";
import { $Short2ByteFunction, $Short2ByteFunction_, $Short2CharFunction, $Short2CharFunction_, $Short2DoubleFunction, $Short2DoubleFunction_, $Short2FloatFunction, $Short2FloatFunction_, $Short2IntFunction, $Short2IntFunction_, $Short2LongFunction, $Short2LongFunction_, $Short2ObjectFunction, $Short2ObjectFunction_, $Short2ReferenceFunction, $Short2ReferenceFunction_, $Short2ShortFunction, $Short2ShortFunction_ } from "java:it/unimi/dsi/fastutil/shorts";
import { $Comparable, $Comparable_, $Iterable } from "java:java/lang";
import { $Collection, $Comparator, $Comparator_, $List, $ListIterator, $Map, $Map$Entry, $PrimitiveIterator$OfInt, $Set, $Spliterator$OfInt } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $BinaryOperator, $BinaryOperator_, $Consumer, $Consumer_, $DoubleBinaryOperator as $NekoImport$DoubleBinaryOperator1, $DoubleBinaryOperator_ as $NekoImport$DoubleBinaryOperator_1, $Function as $NekoImport$Function1, $Function_ as $NekoImport$Function_1, $IntBinaryOperator as $NekoImport$IntBinaryOperator, $IntBinaryOperator_ as $NekoImport$IntBinaryOperator_, $IntConsumer as $NekoImport$IntConsumer, $IntConsumer_ as $NekoImport$IntConsumer_, $IntFunction, $IntFunction_, $IntPredicate as $NekoImport$IntPredicate, $IntPredicate_ as $NekoImport$IntPredicate_, $IntToDoubleFunction, $IntToDoubleFunction_, $IntToLongFunction, $IntToLongFunction_, $IntUnaryOperator as $NekoImport$IntUnaryOperator, $IntUnaryOperator_ as $NekoImport$IntUnaryOperator_, $Predicate, $Predicate_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $IntStream, $Stream } from "java:java/util/stream";

declare module "java:it/unimi/dsi/fastutil/ints" {
    export interface $Int2ObjectFunction<out V> extends $NekoImport$Function<number, V>, $IntFunction<V> {
        andThenByte(arg0: $Object2ByteFunction_<V, unknown, number>): $Int2ByteFunction;
        andThenChar(arg0: $Object2CharFunction_<V, unknown, string>): $Int2CharFunction;
        andThenDouble(arg0: $Object2DoubleFunction_<V, unknown, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Object2FloatFunction_<V, unknown, number>): $Int2FloatFunction;
        andThenInt(arg0: $Object2IntFunction_<V, unknown, number>): $Int2IntFunction;
        andThenLong(arg0: $Object2LongFunction_<V, unknown, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, unknown, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, unknown, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Object2ShortFunction_<V, unknown, number>): $Int2ShortFunction;
        apply(arg0: number): V;
        apply(arg0: number): V;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2ObjectFunction<V>;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, V>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: number, arg1: V): V;
        getOrDefault(arg0: unknown, arg1: V): V;
        get(arg0: number): V;
        get(arg0: unknown): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: number): V;
        remove(arg0: unknown): V;
    }

    export interface $Int2ByteFunction extends $NekoImport$Function<number, number>, $NekoImport$IntUnaryOperator {
        andThenByte(arg0: $Byte2ByteFunction_<number, number>): $Int2ByteFunction;
        andThenChar(arg0: $Byte2CharFunction_<number, string>): $Int2CharFunction;
        andThenDouble(arg0: $Byte2DoubleFunction_<number, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Byte2FloatFunction_<number, number>): $Int2FloatFunction;
        andThenInt(arg0: $Byte2IntFunction_<number, number>): $Int2IntFunction;
        andThenLong(arg0: $Byte2LongFunction_<number, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Byte2ObjectFunction_<T, number, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Byte2ReferenceFunction_<T, number, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Byte2ShortFunction_<number, number>): $Int2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2ByteFunction;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2ByteFunction;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2ByteFunction;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2ByteFunction;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2ByteFunction;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2ByteFunction;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2ByteFunction<T>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2ByteFunction<T>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2ByteFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        compose(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $Int2CharFunction extends $NekoImport$Function<number, string>, $NekoImport$IntUnaryOperator {
        andThenByte(arg0: $Char2ByteFunction_<string, number>): $Int2ByteFunction;
        andThenChar(arg0: $Char2CharFunction_<string, string>): $Int2CharFunction;
        andThenDouble(arg0: $Char2DoubleFunction_<string, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Char2FloatFunction_<string, number>): $Int2FloatFunction;
        andThenInt(arg0: $Char2IntFunction_<string, number>): $Int2IntFunction;
        andThenLong(arg0: $Char2LongFunction_<string, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Char2ObjectFunction_<T, string, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Char2ReferenceFunction_<T, string, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Char2ShortFunction_<string, number>): $Int2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<string, T, string, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2CharFunction;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2CharFunction;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2CharFunction;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2CharFunction;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2CharFunction;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2CharFunction;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2CharFunction<T>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2CharFunction<T>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2CharFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, string>;
        compose(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: string): void;
        defaultReturnValue(): string;
        getOrDefault(arg0: number, arg1: string): string;
        getOrDefault(arg0: unknown, arg1: string): string;
        get(arg0: number): string;
        get(arg0: unknown): string;
        put(arg0: number, arg1: string): string;
        put(arg0: number, arg1: string): string;
        remove(arg0: number): string;
        remove(arg0: unknown): string;
    }

    export interface $Int2DoubleFunction extends $NekoImport$Function<number, number>, $IntToDoubleFunction {
        andThenByte(arg0: $Double2ByteFunction_<number, number>): $Int2ByteFunction;
        andThenChar(arg0: $Double2CharFunction_<number, string>): $Int2CharFunction;
        andThenDouble(arg0: $Double2DoubleFunction_<number, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Double2FloatFunction_<number, number>): $Int2FloatFunction;
        andThenInt(arg0: $Double2IntFunction_<number, number>): $Int2IntFunction;
        andThenLong(arg0: $Double2LongFunction_<number, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Double2ObjectFunction_<T, number, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Double2ReferenceFunction_<T, number, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Double2ShortFunction_<number, number>): $Int2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsDouble(arg0: number): number;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2DoubleFunction;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2DoubleFunction;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2DoubleFunction;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2DoubleFunction;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2DoubleFunction;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2DoubleFunction;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2DoubleFunction<T>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2DoubleFunction<T>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2DoubleFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $Int2FloatFunction extends $NekoImport$Function<number, number>, $IntToDoubleFunction {
        andThenByte(arg0: $Float2ByteFunction_<number, number>): $Int2ByteFunction;
        andThenChar(arg0: $Float2CharFunction_<number, string>): $Int2CharFunction;
        andThenDouble(arg0: $Float2DoubleFunction_<number, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Float2FloatFunction_<number, number>): $Int2FloatFunction;
        andThenInt(arg0: $Float2IntFunction_<number, number>): $Int2IntFunction;
        andThenLong(arg0: $Float2LongFunction_<number, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Float2ObjectFunction_<T, number, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Float2ReferenceFunction_<T, number, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Float2ShortFunction_<number, number>): $Int2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsDouble(arg0: number): number;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2FloatFunction;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2FloatFunction;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2FloatFunction;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2FloatFunction;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2FloatFunction;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2FloatFunction;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2FloatFunction<T>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2FloatFunction<T>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2FloatFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $Int2IntFunction extends $NekoImport$Function<number, number>, $NekoImport$IntUnaryOperator {
        andThenByte(arg0: $Int2ByteFunction_<number, number>): $Int2ByteFunction;
        andThenChar(arg0: $Int2CharFunction_<number, string>): $Int2CharFunction;
        andThenDouble(arg0: $Int2DoubleFunction_<number, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Int2FloatFunction_<number, number>): $Int2FloatFunction;
        andThenInt(arg0: $Int2IntFunction_<number, number>): $Int2IntFunction;
        andThenLong(arg0: $Int2LongFunction_<number, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Int2ObjectFunction_<T, number, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Int2ReferenceFunction_<T, number, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Int2ShortFunction_<number, number>): $Int2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2IntFunction;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2IntFunction;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2IntFunction;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2IntFunction;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2IntFunction;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2IntFunction;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2IntFunction<T>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2IntFunction<T>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2IntFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        compose(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }
    export const $Int2IntFunction: {
        identity(): $Int2IntFunction;
    };

    export interface $Int2LongFunction extends $NekoImport$Function<number, number>, $IntToLongFunction {
        andThenByte(arg0: $Long2ByteFunction_<number, number>): $Int2ByteFunction;
        andThenChar(arg0: $Long2CharFunction_<number, string>): $Int2CharFunction;
        andThenDouble(arg0: $Long2DoubleFunction_<number, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Long2FloatFunction_<number, number>): $Int2FloatFunction;
        andThenInt(arg0: $Long2IntFunction_<number, number>): $Int2IntFunction;
        andThenLong(arg0: $Long2LongFunction_<number, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Long2ObjectFunction_<T, number, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Long2ReferenceFunction_<T, number, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Long2ShortFunction_<number, number>): $Int2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsLong(arg0: number): number;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2LongFunction;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2LongFunction;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2LongFunction;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2LongFunction;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2LongFunction;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2LongFunction;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2LongFunction<T>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2LongFunction<T>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2LongFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $Int2ReferenceFunction<out V> extends $NekoImport$Function<number, V>, $IntFunction<V> {
        andThenByte(arg0: $Reference2ByteFunction_<V, unknown, number>): $Int2ByteFunction;
        andThenChar(arg0: $Reference2CharFunction_<V, unknown, string>): $Int2CharFunction;
        andThenDouble(arg0: $Reference2DoubleFunction_<V, unknown, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Reference2FloatFunction_<V, unknown, number>): $Int2FloatFunction;
        andThenInt(arg0: $Reference2IntFunction_<V, unknown, number>): $Int2IntFunction;
        andThenLong(arg0: $Reference2LongFunction_<V, unknown, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Reference2ObjectFunction_<V, T, unknown, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Reference2ReferenceFunction_<V, T, unknown, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Reference2ShortFunction_<V, unknown, number>): $Int2ShortFunction;
        apply(arg0: number): V;
        apply(arg0: number): V;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2ReferenceFunction<V>;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2ReferenceFunction<V>;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2ReferenceFunction<V>;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2ReferenceFunction<V>;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2ReferenceFunction<V>;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2ReferenceFunction<V>;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2ReferenceFunction<T, V>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2ReferenceFunction<T, V>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2ReferenceFunction<V>;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, V>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: number, arg1: V): V;
        getOrDefault(arg0: unknown, arg1: V): V;
        get(arg0: number): V;
        get(arg0: unknown): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: number): V;
        remove(arg0: unknown): V;
    }

    export interface $Int2ShortFunction extends $NekoImport$Function<number, number>, $NekoImport$IntUnaryOperator {
        andThenByte(arg0: $Short2ByteFunction_<number, number>): $Int2ByteFunction;
        andThenChar(arg0: $Short2CharFunction_<number, string>): $Int2CharFunction;
        andThenDouble(arg0: $Short2DoubleFunction_<number, number>): $Int2DoubleFunction;
        andThenFloat(arg0: $Short2FloatFunction_<number, number>): $Int2FloatFunction;
        andThenInt(arg0: $Short2IntFunction_<number, number>): $Int2IntFunction;
        andThenLong(arg0: $Short2LongFunction_<number, number>): $Int2LongFunction;
        andThenObject<T>(arg0: $Short2ObjectFunction_<T, number, T>): $Int2ObjectFunction<T>;
        andThenReference<T>(arg0: $Short2ReferenceFunction_<T, number, T>): $Int2ReferenceFunction<T>;
        andThenShort(arg0: $Short2ShortFunction_<number, number>): $Int2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        andThen(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2IntFunction_<number, number>): $Byte2ShortFunction;
        composeChar(arg0: $Char2IntFunction_<string, number>): $Char2ShortFunction;
        composeDouble(arg0: $Double2IntFunction_<number, number>): $Double2ShortFunction;
        composeFloat(arg0: $Float2IntFunction_<number, number>): $Float2ShortFunction;
        composeInt(arg0: $Int2IntFunction_<number, number>): $Int2ShortFunction;
        composeLong(arg0: $Long2IntFunction_<number, number>): $Long2ShortFunction;
        composeObject<T>(arg0: $Object2IntFunction_<T, unknown, number>): $Object2ShortFunction<T>;
        composeReference<T>(arg0: $Reference2IntFunction_<T, unknown, number>): $Reference2ShortFunction<T>;
        composeShort(arg0: $Short2IntFunction_<number, number>): $Short2ShortFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        compose(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $IntList extends $List<number>, $Comparable<$List<number>>, $IntCollection {
        addAll(arg0: number, arg1: $IntCollection): boolean;
        addAll(arg0: number, arg1: $IntList): boolean;
        addAll(arg0: number, arg1: ($Collection<number> | (number)[])): boolean;
        addAll(arg0: $IntCollection): boolean;
        addAll(arg0: $IntList): boolean;
        addAll(arg0: ($Collection<number> | (number)[])): boolean;
        addElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        addElements(arg0: number, arg1: number[]): void;
        add(arg0: number, arg1: number): void;
        add(arg0: number, arg1: number): void;
        add(arg0: number): boolean;
        add(arg0: number): boolean;
        clear(): void;
        containsAll(arg0: $IntCollection): boolean;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: number): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        forEach(arg0: $IntConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$IntConsumer_<number>): void;
        getElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        getInt(arg0: number): number;
        get(arg0: number): number;
        hashCode(): number;
        indexOf(arg0: number): number;
        indexOf(arg0: unknown): number;
        isEmpty(): boolean;
        iterator(): $IntListIterator;
        lastIndexOf(arg0: number): number;
        lastIndexOf(arg0: unknown): number;
        listIterator(arg0: number): $IntListIterator;
        listIterator(): $IntListIterator;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $IntCollection): boolean;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeElements(arg0: number, arg1: number): void;
        removeIf(arg0: $IntPredicate_<number, boolean>): boolean;
        removeIf(arg0: $NekoImport$IntPredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        removeInt(arg0: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): boolean;
        replaceAll(arg0: $IntUnaryOperator_<number, number>): void;
        replaceAll(arg0: $NekoImport$IntUnaryOperator_<number, number>): void;
        replaceAll(arg0: $UnaryOperator_<number, number, number>): void;
        retainAll(arg0: $IntCollection): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        setElements(arg0: number[]): void;
        setElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        setElements(arg0: number, arg1: number[]): void;
        set(arg0: number, arg1: number): number;
        set(arg0: number, arg1: number): number;
        size(arg0: number): void;
        size(): number;
        sort(arg0: $IntComparator_<number, number, number>): void;
        sort(arg0: $Comparator_<number, number, number, number>): void;
        spliterator(): $IntSpliterator;
        stream(): $Stream<number>;
        subList(arg0: number, arg1: number): $IntList;
        toArray<T>(arg0: T[]): T[];
        toArray(arg0: number[]): number[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
        unstableSort(arg0: $IntComparator_<number, number, number>): void;
        unstableSort(arg0: $Comparator_<number, number, number, number>): void;
    }
    export const $IntList: {
        of(arg0?: number[]): $IntList;
        of(arg0: number, arg1: number, arg2: number): $IntList;
        of(arg0: number, arg1: number): $IntList;
        of(arg0: number): $IntList;
        of(): $IntList;
    };

    export interface $IntCollection extends $Collection<number>, $IntIterable {
        addAll(arg0: $IntCollection): boolean;
        addAll(arg0: ($Collection<number> | (number)[])): boolean;
        add(arg0: number): boolean;
        add(arg0: number): boolean;
        containsAll(arg0: $IntCollection): boolean;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: number): boolean;
        contains(arg0: unknown): boolean;
        forEach(arg0: $IntConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$IntConsumer_<number>): void;
        intIterator(): $IntIterator;
        intParallelStream(): $IntStream;
        intSpliterator(): $IntSpliterator;
        intStream(): $IntStream;
        iterator(): $IntIterator;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $IntCollection): boolean;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeIf(arg0: $IntPredicate_<number, boolean>): boolean;
        removeIf(arg0: $NekoImport$IntPredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        remove(arg0: unknown): boolean;
        rem(arg0: number): boolean;
        retainAll(arg0: $IntCollection): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        spliterator(): $IntSpliterator;
        stream(): $Stream<number>;
        toArray<T>(arg0: T[]): T[];
        toArray(arg0: number[]): number[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
        toIntArray(arg0: number[]): number[];
        toIntArray(): number[];
    }

    export interface $IntComparator extends $Comparator<number> {
        compare(arg0: number, arg1: number): number;
        compare(arg0: number, arg1: number): number;
        reversed(): $IntComparator;
        thenComparing(arg0: $IntComparator_<number, number, number>): $IntComparator;
        thenComparing(arg0: $Comparator_<number, number, number, number>): $Comparator<number>;
        thenComparing<U>(arg0: $NekoImport$Function_1<number, U, number, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<number>;
        thenComparing<U extends $Comparable<any>>(arg0: $NekoImport$Function_1<number, U, number, U>): $Comparator<number>;
    }

    export interface $IntConsumer extends $Consumer<number>, $NekoImport$IntConsumer {
        accept(arg0: number): void;
        accept(arg0: number): void;
        andThen(arg0: $IntConsumer_<number>): $IntConsumer;
        andThen(arg0: $Consumer_<number, number>): $Consumer<number>;
        andThen(arg0: $NekoImport$IntConsumer_<number>): $IntConsumer;
    }

    export interface $IntListIterator extends $IntBidirectionalIterator, $ListIterator<number> {
        add(arg0: number): void;
        add(arg0: number): void;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$IntConsumer_<number>): void;
        hasNext(): boolean;
        hasPrevious(): boolean;
        next(): number;
        previous(): number;
        remove(): void;
        set(arg0: number): void;
        set(arg0: number): void;
    }

    export interface $IntPredicate extends $Predicate<number>, $NekoImport$IntPredicate {
        and(arg0: $IntPredicate_<number, boolean>): $IntPredicate;
        and(arg0: $NekoImport$IntPredicate_<number, boolean>): $IntPredicate;
        and(arg0: $Predicate_<number, number, boolean>): $Predicate<number>;
        negate(): $IntPredicate;
        or(arg0: $IntPredicate_<number, boolean>): $IntPredicate;
        or(arg0: $NekoImport$IntPredicate_<number, boolean>): $IntPredicate;
        or(arg0: $Predicate_<number, number, boolean>): $Predicate<number>;
        test(arg0: number): boolean;
        test(arg0: number): boolean;
    }

    export interface $IntSpliterator extends $Spliterator$OfInt {
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$IntConsumer_<number>): void;
        getComparator(): $IntComparator;
        skip(arg0: number): number;
        tryAdvance(arg0: $IntConsumer_<number>): boolean;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $NekoImport$IntConsumer_<number>): boolean;
        trySplit(): $IntSpliterator;
    }

    export interface $IntUnaryOperator extends $UnaryOperator<number>, $NekoImport$IntUnaryOperator {
        andThen<V>(arg0: $NekoImport$Function_1<number, V, number, V>): $NekoImport$Function1<number, V>;
        andThen(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
        applyAsInt(arg0: number): number;
        apply(arg0: number): number;
        apply(arg0: number): number;
        compose<V>(arg0: $NekoImport$Function_1<V, number, V, number>): $NekoImport$Function1<V, number>;
        compose(arg0: $NekoImport$IntUnaryOperator_<number, number>): $NekoImport$IntUnaryOperator;
    }
    export const $IntUnaryOperator: {
        identity(): $IntUnaryOperator;
        negation(): $IntUnaryOperator;
    };

    export interface $IntIterable extends $Iterable<number> {
        forEach(arg0: $IntConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$IntConsumer_<number>): void;
        intIterator(): $IntIterator;
        intSpliterator(): $IntSpliterator;
        iterator(): $IntIterator;
        spliterator(): $IntSpliterator;
    }

    export interface $IntIterator extends $PrimitiveIterator$OfInt {
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$IntConsumer_<number>): void;
        nextInt(): number;
        next(): number;
        skip(arg0: number): number;
    }

    export interface $IntBidirectionalIterator extends $IntIterator, $ObjectBidirectionalIterator<number> {
        back(arg0: number): number;
        forEachRemaining(arg0: $IntConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$IntConsumer_<number>): void;
        hasNext(): boolean;
        next(): number;
        previousInt(): number;
        previous(): number;
        remove(): void;
        skip(arg0: number): number;
    }

    export interface $Int2ObjectMap<V> extends $Int2ObjectFunction<V>, $Map<number, V> {
        clear(): void;
        computeIfAbsentPartial(arg0: number, arg1: $Int2ObjectFunction_<V, number, V>): V;
        computeIfAbsent(arg0: number, arg1: $Int2ObjectFunction_<V, number, V>): V;
        computeIfAbsent(arg0: number, arg1: $IntFunction_<V, number, V>): V;
        computeIfAbsent(arg0: number, arg1: $NekoImport$Function_1<number, V, number, V>): V;
        computeIfPresent(arg0: number, arg1: $BiFunction_<number, V, V, number, V, V>): V;
        computeIfPresent(arg0: number, arg1: $BiFunction_<number, V, V, number, V, V>): V;
        compute(arg0: number, arg1: $BiFunction_<number, V, V, number, V, V>): V;
        compute(arg0: number, arg1: $BiFunction_<number, V, V, number, V, V>): V;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        entrySet(): $ObjectSet<$Map$Entry<number, V>>;
        forEach(arg0: $BiConsumer_<number, V, number, V>): void;
        getOrDefault(arg0: number, arg1: V): V;
        getOrDefault(arg0: unknown, arg1: V): V;
        get(arg0: number): V;
        get(arg0: unknown): V;
        int2ObjectEntrySet(): $ObjectSet<$Int2ObjectMap$Entry<V>>;
        keySet(): $IntSet;
        merge(arg0: number, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        merge(arg0: number, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putIfAbsent(arg0: number, arg1: V): V;
        putIfAbsent(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: number, arg1: unknown): boolean;
        remove(arg0: number): V;
        remove(arg0: unknown, arg1: unknown): boolean;
        remove(arg0: unknown): V;
        replace(arg0: number, arg1: V, arg2: V): boolean;
        replace(arg0: number, arg1: V): V;
        replace(arg0: number, arg1: V, arg2: V): boolean;
        replace(arg0: number, arg1: V): V;
        size(): number;
        values(): $ObjectCollection<V>;
    }

    export interface $Int2ObjectMap$Entry<V> extends $Map$Entry<number, V> {
        getIntKey(): number;
        getKey(): number;
    }

    export interface $IntSet extends $IntCollection, $Set<number> {
        addAll(arg0: $IntCollection): boolean;
        addAll(arg0: ($Collection<number> | (number)[])): boolean;
        add(arg0: number): boolean;
        add(arg0: number): boolean;
        clear(): void;
        containsAll(arg0: $IntCollection): boolean;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: number): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        forEach(arg0: $IntConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$IntConsumer_<number>): void;
        hashCode(): number;
        isEmpty(): boolean;
        iterator(): $IntIterator;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $IntCollection): boolean;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeIf(arg0: $IntPredicate_<number, boolean>): boolean;
        removeIf(arg0: $NekoImport$IntPredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        remove(arg0: number): boolean;
        remove(arg0: unknown): boolean;
        rem(arg0: number): boolean;
        retainAll(arg0: $IntCollection): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        size(): number;
        spliterator(): $IntSpliterator;
        stream(): $Stream<number>;
        toArray<T>(arg0: T[]): T[];
        toArray(arg0: number[]): number[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
    }
    export const $IntSet: {
        of(arg0?: number[]): $IntSet;
        of(arg0: number, arg1: number, arg2: number): $IntSet;
        of(arg0: number, arg1: number): $IntSet;
        of(arg0: number): $IntSet;
        of(): $IntSet;
    };

    export interface $Int2DoubleMap extends $Int2DoubleFunction, $Map<number, number> {
        clear(): void;
        computeIfAbsentNullable(arg0: number, arg1: $IntFunction_<number, number, number>): number;
        computeIfAbsentPartial(arg0: number, arg1: $Int2DoubleFunction_<number, number>): number;
        computeIfAbsent(arg0: number, arg1: $Int2DoubleFunction_<number, number>): number;
        computeIfAbsent(arg0: number, arg1: $IntToDoubleFunction_<number, number>): number;
        computeIfAbsent(arg0: number, arg1: $NekoImport$Function_1<number, number, number, number>): number;
        computeIfPresent(arg0: number, arg1: $BiFunction_<number, number, number, number, number, number>): number;
        computeIfPresent(arg0: number, arg1: $BiFunction_<number, number, number, number, number, number>): number;
        compute(arg0: number, arg1: $BiFunction_<number, number, number, number, number, number>): number;
        compute(arg0: number, arg1: $BiFunction_<number, number, number, number, number, number>): number;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        containsValue(arg0: number): boolean;
        containsValue(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        entrySet(): $ObjectSet<$Map$Entry<number, number>>;
        forEach(arg0: $BiConsumer_<number, number, number, number>): void;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        int2DoubleEntrySet(): $ObjectSet<$Int2DoubleMap$Entry>;
        keySet(): $IntSet;
        mergeDouble(arg0: number, arg1: number, arg2: $NekoImport$DoubleBinaryOperator_<number, number, number>): number;
        mergeDouble(arg0: number, arg1: number, arg2: $NekoImport$DoubleBinaryOperator_1<number, number, number>): number;
        merge(arg0: number, arg1: number, arg2: $BiFunction_<number, number, number, number, number, number>): number;
        merge(arg0: number, arg1: number, arg2: $BiFunction_<number, number, number, number, number, number>): number;
        putIfAbsent(arg0: number, arg1: number): number;
        putIfAbsent(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number, arg1: number): boolean;
        remove(arg0: number): number;
        remove(arg0: unknown, arg1: unknown): boolean;
        remove(arg0: unknown): number;
        replace(arg0: number, arg1: number, arg2: number): boolean;
        replace(arg0: number, arg1: number): number;
        replace(arg0: number, arg1: number, arg2: number): boolean;
        replace(arg0: number, arg1: number): number;
        size(): number;
        values(): $DoubleCollection;
    }

    export interface $Int2DoubleMap$Entry extends $Map$Entry<number, number> {
        getDoubleValue(): number;
        getIntKey(): number;
        getKey(): number;
        getValue(): number;
        setValue(arg0: number): number;
        setValue(arg0: number): number;
    }

    export interface $IntBinaryOperator extends $BinaryOperator<number>, $NekoImport$IntBinaryOperator {
        applyAsInt(arg0: number, arg1: number): number;
        apply(arg0: number, arg1: number): number;
        apply(arg0: number, arg1: number): number;
    }

    export interface $Int2IntMap extends $Int2IntFunction, $Map<number, number> {
        clear(): void;
        computeIfAbsentNullable(arg0: number, arg1: $IntFunction_<number, number, number>): number;
        computeIfAbsentPartial(arg0: number, arg1: $Int2IntFunction_<number, number>): number;
        computeIfAbsent(arg0: number, arg1: $Int2IntFunction_<number, number>): number;
        computeIfAbsent(arg0: number, arg1: $NekoImport$IntUnaryOperator_<number, number>): number;
        computeIfAbsent(arg0: number, arg1: $NekoImport$Function_1<number, number, number, number>): number;
        computeIfPresent(arg0: number, arg1: $BiFunction_<number, number, number, number, number, number>): number;
        computeIfPresent(arg0: number, arg1: $BiFunction_<number, number, number, number, number, number>): number;
        compute(arg0: number, arg1: $BiFunction_<number, number, number, number, number, number>): number;
        compute(arg0: number, arg1: $BiFunction_<number, number, number, number, number, number>): number;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        containsValue(arg0: number): boolean;
        containsValue(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        entrySet(): $ObjectSet<$Map$Entry<number, number>>;
        forEach(arg0: $BiConsumer_<number, number, number, number>): void;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        int2IntEntrySet(): $ObjectSet<$Int2IntMap$Entry>;
        keySet(): $IntSet;
        mergeInt(arg0: number, arg1: number, arg2: $IntBinaryOperator_<number, number, number>): number;
        mergeInt(arg0: number, arg1: number, arg2: $NekoImport$IntBinaryOperator_<number, number, number>): number;
        merge(arg0: number, arg1: number, arg2: $BiFunction_<number, number, number, number, number, number>): number;
        merge(arg0: number, arg1: number, arg2: $BiFunction_<number, number, number, number, number, number>): number;
        putIfAbsent(arg0: number, arg1: number): number;
        putIfAbsent(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number, arg1: number): boolean;
        remove(arg0: number): number;
        remove(arg0: unknown, arg1: unknown): boolean;
        remove(arg0: unknown): number;
        replace(arg0: number, arg1: number, arg2: number): boolean;
        replace(arg0: number, arg1: number): number;
        replace(arg0: number, arg1: number, arg2: number): boolean;
        replace(arg0: number, arg1: number): number;
        size(): number;
        values(): $IntCollection;
    }

    export interface $Int2IntMap$Entry extends $Map$Entry<number, number> {
        getIntKey(): number;
        getIntValue(): number;
        getKey(): number;
        getValue(): number;
        setValue(arg0: number): number;
        setValue(arg0: number): number;
    }

    export type $Int2ObjectFunction_<Host0 = any, CallbackArg0 = number, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2ObjectFunction<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Int2ByteFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2ByteFunction & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Int2CharFunction_<CallbackArg0 = number, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2CharFunction & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Int2DoubleFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2DoubleFunction & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Int2FloatFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2FloatFunction & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Int2IntFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2IntFunction & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Int2LongFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2LongFunction & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Int2ReferenceFunction_<Host0 = any, CallbackArg0 = number, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2ReferenceFunction<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Int2ShortFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Int2ShortFunction & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "get": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $IntComparator_<CallbackArg0 = number, CallbackArg1 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($IntComparator & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "compare": (arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $IntConsumer_<CallbackArg0 = number> = ((arg0: CallbackArg0) => void) | ($IntConsumer & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "accept": (arg0: CallbackArg0) => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $IntPredicate_<CallbackArg0 = number, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($IntPredicate & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "test": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $IntUnaryOperator_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($IntUnaryOperator & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $IntIterable_<CallbackResult = $IntIterator> = (() => CallbackResult) | ($IntIterable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "iterator": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $IntBinaryOperator_<CallbackArg0 = number, CallbackArg1 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($IntBinaryOperator & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "apply": (arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
