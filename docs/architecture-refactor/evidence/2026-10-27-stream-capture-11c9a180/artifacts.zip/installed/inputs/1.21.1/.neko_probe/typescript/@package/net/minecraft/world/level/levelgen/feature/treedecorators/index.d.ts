import { $Codec } from "java:com/mojang/serialization";
import { $ObjectArrayList } from "java:it/unimi/dsi/fastutil/objects";
import { $Set } from "java:java/util";
import { $BiConsumer, $BiConsumer_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $LevelSimulatedReader } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $BooleanProperty } from "java:net/minecraft/world/level/block/state/properties";

declare module "java:net/minecraft/world/level/levelgen/feature/treedecorators" {
    export class $TreeDecorator {
        constructor();
        static CODEC: $Codec<$TreeDecorator>;
        place(arg0: $TreeDecorator$Context): void;
    }

    export class $TreeDecorator$Context {
        constructor(arg0: $LevelSimulatedReader, arg1: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>, arg2: $RandomSource, arg3: $Set<$BlockPos>, arg4: $Set<$BlockPos>, arg5: $Set<$BlockPos>);
        isAir(arg0: $BlockPos_): boolean;
        leaves(): $ObjectArrayList<$BlockPos>;
        level(): $LevelSimulatedReader;
        logs(): $ObjectArrayList<$BlockPos>;
        placeVine(arg0: $BlockPos_, arg1: $BooleanProperty): void;
        random(): $RandomSource;
        roots(): $ObjectArrayList<$BlockPos>;
        setBlock(arg0: $BlockPos_, arg1: $BlockState_): void;
    }

}
