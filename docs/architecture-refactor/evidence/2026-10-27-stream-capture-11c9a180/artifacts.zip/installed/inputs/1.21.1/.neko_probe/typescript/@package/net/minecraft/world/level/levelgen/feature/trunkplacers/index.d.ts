import { $Codec } from "java:com/mojang/serialization";
import { $List } from "java:java/util";
import { $BiConsumer, $BiConsumer_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $LevelSimulatedReader } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $TreeConfiguration } from "java:net/minecraft/world/level/levelgen/feature/configurations";
import { $FoliagePlacer$FoliageAttachment } from "java:net/minecraft/world/level/levelgen/feature/foliageplacers";

declare module "java:net/minecraft/world/level/levelgen/feature/trunkplacers" {
    export class $TrunkPlacer {
        constructor(arg0: number, arg1: number, arg2: number);
        static CODEC: $Codec<$TrunkPlacer>;
        static MAX_HEIGHT: number;
        getTreeHeight(arg0: $RandomSource): number;
        isFree(arg0: $LevelSimulatedReader, arg1: $BlockPos_): boolean;
        placeTrunk(arg0: $LevelSimulatedReader, arg1: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>, arg2: $RandomSource, arg3: number, arg4: $BlockPos_, arg5: $TreeConfiguration): $List<$FoliagePlacer$FoliageAttachment>;
    }

}
