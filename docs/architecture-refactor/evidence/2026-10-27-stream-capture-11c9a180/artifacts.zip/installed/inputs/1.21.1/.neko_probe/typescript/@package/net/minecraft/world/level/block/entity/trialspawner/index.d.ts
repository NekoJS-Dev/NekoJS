import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record } from "java:java/lang";
import { $List, $Optional, $Set, $UUID } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleOptions_, $ParticleType, $ParticleType_, $SimpleParticleType } from "java:net/minecraft/core/particles";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $SimpleWeightedRandomList } from "java:net/minecraft/util/random";
import { $Entity, $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Level, $SpawnData } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $EntityTypeTest } from "java:net/minecraft/world/level/entity";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $AABB } from "java:net/minecraft/world/phys";
import { $IOwnedSpawner, $IOwnedSpawner_ } from "java:net/neoforged/neoforge/common/extensions";

declare module "java:net/minecraft/world/level/block/entity/trialspawner" {
    export interface $PlayerDetector {
        detect(arg0: $ServerLevel, arg1: $PlayerDetector$EntitySelector, arg2: $BlockPos_, arg3: number, arg4: boolean): $List<$UUID>;
    }
    export const $PlayerDetector: {
        readonly INCLUDING_CREATIVE_PLAYERS: $PlayerDetector;
        readonly NO_CREATIVE_PLAYERS: $PlayerDetector;
        readonly SHEEP: $PlayerDetector;
    };

    export interface $PlayerDetector$EntitySelector {
        getEntities<T extends $Entity>(arg0: $ServerLevel, arg1: $EntityTypeTest<$Entity, T>, arg2: $AABB, arg3: $Predicate_<T, T, boolean>): $List<T>;
        getPlayers(arg0: $ServerLevel, arg1: $Predicate_<$Player, $Player, boolean>): $List<$Player>;
    }
    export const $PlayerDetector$EntitySelector: {
        onlySelectPlayers(arg0: ($List<$Player> | ($Player)[])): $PlayerDetector$EntitySelector;
        onlySelectPlayer(arg0: $Player): $PlayerDetector$EntitySelector;
        readonly SELECT_FROM_LEVEL: $PlayerDetector$EntitySelector;
    };

    export class $TrialSpawner implements $IOwnedSpawner {
        constructor(arg0: $TrialSpawner$StateAccessor, arg1: $PlayerDetector_<$ServerLevel, $PlayerDetector$EntitySelector, $BlockPos, number, boolean, ($List<$UUID> | ($UUID)[])>, arg2: $PlayerDetector$EntitySelector);
        constructor(arg0: $TrialSpawnerConfig, arg1: $TrialSpawnerConfig, arg2: $TrialSpawnerData, arg3: number, arg4: number, arg5: $TrialSpawner$StateAccessor, arg6: $PlayerDetector_<$ServerLevel, $PlayerDetector$EntitySelector, $BlockPos, number, boolean, ($List<$UUID> | ($UUID)[])>, arg7: $PlayerDetector$EntitySelector);
        static DETECT_PLAYER_SPAWN_BUFFER: number;
        static NORMAL_CONFIG_TAG_NAME: string;
        static OMINOUS_CONFIG_TAG_NAME: string;
        get config(): $TrialSpawnerConfig;
        getConfig(): $TrialSpawnerConfig;
        get data(): $TrialSpawnerData;
        getData(): $TrialSpawnerData;
        get entitySelector(): $PlayerDetector$EntitySelector;
        getEntitySelector(): $PlayerDetector$EntitySelector;
        get normalConfig(): $TrialSpawnerConfig;
        getNormalConfig(): $TrialSpawnerConfig;
        get ominousConfig(): $TrialSpawnerConfig;
        getOminousConfig(): $TrialSpawnerConfig;
        get owner(): $Either<$BlockEntity, $Entity>;
        getOwner(): $Either<$BlockEntity, $Entity>;
        get playerDetector(): $PlayerDetector;
        getPlayerDetector(): $PlayerDetector;
        set playerDetector(value: $PlayerDetector_<$ServerLevel, $PlayerDetector$EntitySelector, $BlockPos, number, boolean, ($List<$UUID> | ($UUID)[])>);
        get requiredPlayerRange(): number;
        getRequiredPlayerRange(): number;
        get state(): $TrialSpawnerState;
        getState(): $TrialSpawnerState;
        get targetCooldownLength(): number;
        getTargetCooldownLength(): number;
        get ominous(): boolean;
        isOminous(): boolean;
        static addBecomeOminousParticles(arg0: $Level, arg1: $BlockPos_, arg2: $RandomSource): void;
        static addDetectPlayerParticles(arg0: $Level, arg1: $BlockPos_, arg2: $RandomSource, arg3: number, arg4: $ParticleOptions_<$ParticleType_<any>>): void;
        static addEjectItemParticles(arg0: $Level, arg1: $BlockPos_, arg2: $RandomSource): void;
        static addSpawnParticles(arg0: $Level, arg1: $BlockPos_, arg2: $RandomSource, arg3: $SimpleParticleType): void;
        applyOminous(arg0: $ServerLevel, arg1: $BlockPos_): void;
        canSpawnInLevel(arg0: $Level): boolean;
        codec(): $Codec<$TrialSpawner>;
        ejectReward(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $ResourceKey<$LootTable>): void;
        markUpdated(): void;
        overridePeacefulAndMobSpawnRule(): void;
        removeOminous(arg0: $ServerLevel, arg1: $BlockPos_): void;
        setPlayerDetector(arg0: $PlayerDetector_<$ServerLevel, $PlayerDetector$EntitySelector, $BlockPos, number, boolean, ($List<$UUID> | ($UUID)[])>): void;
        setState(arg0: $Level, arg1: $TrialSpawnerState_): void;
        spawnMob(arg0: $ServerLevel, arg1: $BlockPos_): $Optional<$UUID>;
        tickClient(arg0: $Level, arg1: $BlockPos_, arg2: boolean): void;
        tickServer(arg0: $ServerLevel, arg1: $BlockPos_, arg2: boolean): void;
    }

    export interface $TrialSpawner$StateAccessor {
        getState(): $TrialSpawnerState;
        markUpdated(): void;
        setState(arg0: $Level, arg1: $TrialSpawnerState_): void;
    }

    export class $TrialSpawnerConfig extends $Record {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: $SimpleWeightedRandomList<$SpawnData>, arg7: $SimpleWeightedRandomList<$ResourceKey<$LootTable>>, arg8: $ResourceKey<$LootTable>);
        static CODEC: $Codec<$TrialSpawnerConfig>;
        static DEFAULT: $TrialSpawnerConfig;
        calculateTargetSimultaneousMobs(arg0: number): number;
        calculateTargetTotalMobs(arg0: number): number;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        itemsToDropWhenOminous(): $ResourceKey<$LootTable>;
        lootTablesToEject(): $SimpleWeightedRandomList<$ResourceKey<$LootTable>>;
        simultaneousMobsAddedPerPlayer(): number;
        simultaneousMobs(): number;
        spawnPotentialsDefinition(): $SimpleWeightedRandomList<$SpawnData>;
        spawnRange(): number;
        ticksBetweenItemSpawners(): number;
        ticksBetweenSpawn(): number;
        toString(): string;
        totalMobsAddedPerPlayer(): number;
        totalMobs(): number;
    }

    export class $TrialSpawnerData {
        constructor();
        constructor(arg0: $Set<$UUID>, arg1: $Set<$UUID>, arg2: number, arg3: number, arg4: number, arg5: $Optional<$SpawnData>, arg6: $Optional<$ResourceKey<$LootTable>>);
        static MAP_CODEC: $MapCodec<$TrialSpawnerData>;
        static TAG_SPAWN_DATA: string;
        get oSpin(): number;
        getOSpin(): number;
        get spin(): number;
        getSpin(): number;
        countAdditionalPlayers(arg0: $BlockPos_): number;
        getOrCreateDisplayEntity(arg0: $TrialSpawner, arg1: $Level, arg2: $TrialSpawnerState_): $Entity;
        getUpdateTag(arg0: $TrialSpawnerState_): $CompoundTag;
        hasFinishedSpawningAllMobs(arg0: $TrialSpawnerConfig, arg1: number): boolean;
        hasMobToSpawn(arg0: $TrialSpawner, arg1: $RandomSource): boolean;
        haveAllCurrentMobsDied(): boolean;
        isCooldownFinished(arg0: $ServerLevel): boolean;
        isReadyToEjectItems(arg0: $ServerLevel, arg1: number, arg2: number): boolean;
        isReadyToOpenShutter(arg0: $ServerLevel, arg1: number, arg2: number): boolean;
        isReadyToSpawnNextMob(arg0: $ServerLevel, arg1: $TrialSpawnerConfig, arg2: number): boolean;
        resetAfterBecomingOminous(arg0: $TrialSpawner, arg1: $ServerLevel): void;
        reset(): void;
        setEntityId(arg0: $TrialSpawner, arg1: $RandomSource, arg2: $EntityType_<any>): void;
        tryDetectPlayers(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $TrialSpawner): void;
    }

    export class $TrialSpawnerState {
        static ACTIVE: $TrialSpawnerState;
        static COOLDOWN: $TrialSpawnerState;
        static EJECTING_REWARD: $TrialSpawnerState;
        static INACTIVE: $TrialSpawnerState;
        static WAITING_FOR_PLAYERS: $TrialSpawnerState;
        static WAITING_FOR_REWARD_EJECTION: $TrialSpawnerState;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TrialSpawnerState[];
        static valueOf(name: string): $TrialSpawnerState;
    }
    export interface $TrialSpawnerState extends $Enum<$TrialSpawnerState>, $StringRepresentable {}

    export type $PlayerDetector_<CallbackArg0 = $ServerLevel, CallbackArg1 = $PlayerDetector$EntitySelector, CallbackArg2 = $BlockPos, CallbackArg3 = number, CallbackArg4 = boolean, CallbackResult = ($List<$UUID> | ($UUID)[])> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4) => CallbackResult) | ($PlayerDetector & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "detect": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $TrialSpawnerState_ = $TrialSpawnerState | "ACTIVE" | "COOLDOWN" | "EJECTING_REWARD" | "INACTIVE" | "WAITING_FOR_PLAYERS" | "WAITING_FOR_REWARD_EJECTION";
}
