import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List, $Optional, $UUID } from "java:java/util";
import { $ToIntFunction, $ToIntFunction_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $Entity } from "java:net/minecraft/world/entity";
import { $GameEvent, $GameEvent$Context, $GameEventListener, $GameEventListener$DeliveryMode, $GameEventListener$DeliveryMode_, $GameEvent_, $PositionSource } from "java:net/minecraft/world/level/gameevent";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/level/gameevent/vibrations" {
    export class $VibrationInfo extends $Record {
        constructor(arg0: $Holder_<$GameEvent>, arg1: number, arg2: $Vec3_, arg3: $UUID, arg4: $UUID);
        constructor(arg0: $Holder_<$GameEvent>, arg1: number, arg2: $Vec3_, arg3: $UUID, arg4: $UUID, arg5: $Entity);
        constructor(arg0: $Holder_<$GameEvent>, arg1: number, arg2: $Vec3_, arg3: $Entity);
        static CODEC: $Codec<$VibrationInfo>;
        distance(): number;
        entity(): $Entity;
        equals(arg0: unknown): boolean;
        gameEvent(): $Holder<$GameEvent>;
        getEntity(arg0: $ServerLevel): $Optional<$Entity>;
        getProjectileOwner(arg0: $ServerLevel): $Optional<$Entity>;
        hashCode(): number;
        pos(): $Vec3;
        projectileOwnerUuid(): $UUID;
        toString(): string;
        uuid(): $UUID;
    }

    export class $VibrationSelector {
        constructor();
        constructor(arg0: $Optional<$VibrationInfo>, arg1: number);
        static CODEC: $Codec<$VibrationSelector>;
        addCandidate(arg0: $VibrationInfo, arg1: number): void;
        chosenCandidate(arg0: number): $Optional<$VibrationInfo>;
        startOver(): void;
    }

    export interface $VibrationSystem {
        getVibrationData(): $VibrationSystem$Data;
        getVibrationUser(): $VibrationSystem$User;
    }
    export const $VibrationSystem: {
        getGameEventFrequency(arg0: $Holder_<$GameEvent>): number;
        getGameEventFrequency(arg0: $ResourceKey<$GameEvent>): number;
        getRedstoneStrengthForDistance(arg0: number, arg1: number): number;
        getResonanceEventByFrequency(arg0: number): $ResourceKey<$GameEvent>;
        readonly DEFAULT_VIBRATION_FREQUENCY: number;
        readonly RESONANCE_EVENTS: $List<$ResourceKey<$GameEvent>>;
        readonly VIBRATION_FREQUENCY_FOR_EVENT: $ToIntFunction<$ResourceKey<$GameEvent>>;
    };

    export class $VibrationSystem$Data {
        constructor();
        static CODEC: $Codec<$VibrationSystem$Data>;
        static NBT_TAG_KEY: string;
        get currentVibration(): $VibrationInfo;
        getCurrentVibration(): $VibrationInfo;
        set currentVibration(value: $VibrationInfo);
        get selectionStrategy(): $VibrationSelector;
        getSelectionStrategy(): $VibrationSelector;
        get travelTimeInTicks(): number;
        getTravelTimeInTicks(): number;
        set travelTimeInTicks(value: number);
        decrementTravelTime(): void;
        setCurrentVibration(arg0: $VibrationInfo): void;
        setReloadVibrationParticle(arg0: boolean): void;
        setTravelTimeInTicks(arg0: number): void;
        shouldReloadVibrationParticle(): boolean;
    }

    export class $VibrationSystem$Listener implements $GameEventListener {
        constructor(arg0: $VibrationSystem);
        get deliveryMode(): $GameEventListener$DeliveryMode;
        getDeliveryMode(): $GameEventListener$DeliveryMode;
        get listenerRadius(): number;
        getListenerRadius(): number;
        get listenerSource(): $PositionSource;
        getListenerSource(): $PositionSource;
        static distanceBetweenInBlocks(arg0: $BlockPos_, arg1: $BlockPos_): number;
        forceScheduleVibration(arg0: $ServerLevel, arg1: $Holder_<$GameEvent>, arg2: $GameEvent$Context, arg3: $Vec3_): void;
        handleGameEvent(arg0: $ServerLevel, arg1: $Holder_<$GameEvent>, arg2: $GameEvent$Context, arg3: $Vec3_): boolean;
    }

    export interface $VibrationSystem$User {
        calculateTravelTimeInTicks(arg0: number): number;
        canReceiveVibration(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $Holder_<$GameEvent>, arg3: $GameEvent$Context): boolean;
        canTriggerAvoidVibration(): boolean;
        getListenableEvents(): $TagKey<$GameEvent>;
        getListenerRadius(): number;
        getPositionSource(): $PositionSource;
        isValidVibration(arg0: $Holder_<$GameEvent>, arg1: $GameEvent$Context): boolean;
        onDataChanged(): void;
        onReceiveVibration(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $Holder_<$GameEvent>, arg3: $Entity, arg4: $Entity, arg5: number): void;
        requiresAdjacentChunksToBeTicking(): boolean;
    }

}
