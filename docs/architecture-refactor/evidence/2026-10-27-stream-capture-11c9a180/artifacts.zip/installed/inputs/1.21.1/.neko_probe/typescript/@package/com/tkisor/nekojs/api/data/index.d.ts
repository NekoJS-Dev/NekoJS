import { $ScriptType, $ScriptType_ } from "java:com/tkisor/nekojs/api";
import { $Class, $Record } from "java:java/lang";
import { $HashMap } from "java:java/util";

declare module "java:com/tkisor/nekojs/api/data" {
    export class $AttachedData<T> extends $HashMap<string, unknown> {
        constructor(parent: T);
        get parent(): T;
        getParent(): T;
        add(key: string, data: unknown): void;
        equals(arg0: unknown): boolean;
        hashCode(): number;
    }

    export interface $Binding {
        close(scriptType: $ScriptType_): void;
        name(): string;
        valueType(): $Class<any>;
        value(): unknown;
    }
    export const $Binding: {
        of(name: string, value: unknown, valueType: $Class<any>): $Binding;
        of(name: string, value: unknown): $Binding;
    };

    export class $NekoId extends $Record {
        constructor(namespace: string, path: string);
        static DEFAULT_NAMESPACE: string;
        getNamespace(): string;
        getPath(): string;
        static of(namespace: string, path: string): $NekoId;
        static of(value: string): $NekoId;
        asString(): string;
        equals(o: unknown): boolean;
        hashCode(): number;
        namespace(): string;
        path(): string;
        toString(): string;
    }

}
