import { $DynamicLike } from "java:com/mojang/serialization";
import { $Enum } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Entity } from "java:net/minecraft/world/entity";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $VoxelShape } from "java:net/minecraft/world/phys/shapes";

declare module "java:net/minecraft/world/level/border" {
    export interface $BorderChangeListener {
        onBorderCenterSet(arg0: $WorldBorder, arg1: number, arg2: number): void;
        onBorderSetDamagePerBlock(arg0: $WorldBorder, arg1: number): void;
        onBorderSetDamageSafeZOne(arg0: $WorldBorder, arg1: number): void;
        onBorderSetWarningBlocks(arg0: $WorldBorder, arg1: number): void;
        onBorderSetWarningTime(arg0: $WorldBorder, arg1: number): void;
        onBorderSizeLerping(arg0: $WorldBorder, arg1: number, arg2: number, arg3: number): void;
        onBorderSizeSet(arg0: $WorldBorder, arg1: number): void;
    }

    export class $BorderStatus {
        static GROWING: $BorderStatus;
        static SHRINKING: $BorderStatus;
        static STATIONARY: $BorderStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BorderStatus[];
        static valueOf(name: string): $BorderStatus;
    }
    export interface $BorderStatus extends $Enum<$BorderStatus> {}

    export class $WorldBorder {
        constructor();
        static DEFAULT_SETTINGS: $WorldBorder$Settings;
        static MAX_CENTER_COORDINATE: number;
        static MAX_SIZE: number;
        get absoluteMaxSize(): number;
        getAbsoluteMaxSize(): number;
        set absoluteMaxSize(value: number);
        get centerX(): number;
        getCenterX(): number;
        get centerZ(): number;
        getCenterZ(): number;
        get collisionShape(): $VoxelShape;
        getCollisionShape(): $VoxelShape;
        get damagePerBlock(): number;
        getDamagePerBlock(): number;
        set damagePerBlock(value: number);
        get damageSafeZone(): number;
        getDamageSafeZone(): number;
        set damageSafeZone(value: number);
        get lerpRemainingTime(): number;
        getLerpRemainingTime(): number;
        get lerpSpeed(): number;
        getLerpSpeed(): number;
        get lerpTarget(): number;
        getLerpTarget(): number;
        get maxX(): number;
        getMaxX(): number;
        get maxZ(): number;
        getMaxZ(): number;
        get minX(): number;
        getMinX(): number;
        get minZ(): number;
        getMinZ(): number;
        get size(): number;
        getSize(): number;
        set size(value: number);
        get status(): $BorderStatus;
        getStatus(): $BorderStatus;
        get warningBlocks(): number;
        getWarningBlocks(): number;
        set warningBlocks(value: number);
        get warningTime(): number;
        getWarningTime(): number;
        set warningTime(value: number);
        addListener(arg0: $BorderChangeListener): void;
        applySettings(arg0: $WorldBorder$Settings): void;
        clampToBounds(arg0: number, arg1: number, arg2: number): $BlockPos;
        clampToBounds(arg0: $BlockPos_): $BlockPos;
        clampToBounds(arg0: $Vec3_): $BlockPos;
        createSettings(): $WorldBorder$Settings;
        getDistanceToBorder(arg0: number, arg1: number): number;
        getDistanceToBorder(arg0: $Entity): number;
        isInsideCloseToBorder(arg0: $Entity, arg1: $AABB): boolean;
        isWithinBounds(arg0: number, arg1: number, arg2: number): boolean;
        isWithinBounds(arg0: number, arg1: number): boolean;
        isWithinBounds(arg0: $BlockPos_): boolean;
        isWithinBounds(arg0: $ChunkPos): boolean;
        isWithinBounds(arg0: $AABB): boolean;
        isWithinBounds(arg0: $Vec3_): boolean;
        lerpSizeBetween(arg0: number, arg1: number, arg2: number): void;
        removeListener(arg0: $BorderChangeListener): void;
        setAbsoluteMaxSize(arg0: number): void;
        setCenter(arg0: number, arg1: number): void;
        setDamagePerBlock(arg0: number): void;
        setDamageSafeZone(arg0: number): void;
        setSize(arg0: number): void;
        setWarningBlocks(arg0: number): void;
        setWarningTime(arg0: number): void;
        tick(): void;
    }

    export class $WorldBorder$Settings {
        get centerX(): number;
        getCenterX(): number;
        get centerZ(): number;
        getCenterZ(): number;
        get damagePerBlock(): number;
        getDamagePerBlock(): number;
        get safeZone(): number;
        getSafeZone(): number;
        get sizeLerpTarget(): number;
        getSizeLerpTarget(): number;
        get sizeLerpTime(): number;
        getSizeLerpTime(): number;
        get size(): number;
        getSize(): number;
        get warningBlocks(): number;
        getWarningBlocks(): number;
        get warningTime(): number;
        getWarningTime(): number;
        static read(arg0: $DynamicLike<any>, arg1: $WorldBorder$Settings): $WorldBorder$Settings;
        write(arg0: $CompoundTag_): void;
    }

    export type $BorderStatus_ = $BorderStatus | "GROWING" | "SHRINKING" | "STATIONARY";
}
