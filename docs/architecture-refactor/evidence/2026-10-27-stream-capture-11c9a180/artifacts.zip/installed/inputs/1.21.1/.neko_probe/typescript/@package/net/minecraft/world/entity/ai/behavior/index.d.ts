import { $Enum } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/ai/behavior" {
    export class $Behavior$Status {
        static RUNNING: $Behavior$Status;
        static STOPPED: $Behavior$Status;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Behavior$Status[];
        static valueOf(name: string): $Behavior$Status;
    }
    export interface $Behavior$Status extends $Enum<$Behavior$Status> {}

    export interface $BehaviorControl<E extends $LivingEntity> {
        debugString(): string;
        doStop(arg0: $ServerLevel, arg1: E, arg2: number): void;
        getStatus(): $Behavior$Status;
        tickOrStop(arg0: $ServerLevel, arg1: E, arg2: number): void;
        tryStart(arg0: $ServerLevel, arg1: E, arg2: number): boolean;
    }

    export interface $PositionTracker {
        currentBlockPosition(): $BlockPos;
        currentPosition(): $Vec3;
        isVisibleBy(arg0: $LivingEntity): boolean;
    }

    export type $Behavior$Status_ = $Behavior$Status | "RUNNING" | "STOPPED";
}
