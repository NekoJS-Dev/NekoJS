import { $Class, $Enum, $Iterable } from "java:java/lang";
import { $Iterator, $List, $Map$Entry, $Set } from "java:java/util";
import { $Consumer, $Consumer_, $Function, $Function_ } from "java:java/util/function";

declare module "java:graal/graalvm/options" {
    export interface $OptionDescriptors extends $Iterable<$OptionDescriptor> {
        get(optionName: string): $OptionDescriptor;
        iterator(): $Iterator<$OptionDescriptor>;
    }
    export const $OptionDescriptors: {
        createUnion(descriptors?: $OptionDescriptors[]): $OptionDescriptors;
        create(descriptors: ($List<$OptionDescriptor> | ($OptionDescriptor)[])): $OptionDescriptors;
        readonly EMPTY: $OptionDescriptors;
    };

    export class $OptionDescriptor {
        get category(): $OptionCategory;
        getCategory(): $OptionCategory;
        get deprecationMessage(): string;
        getDeprecationMessage(): string;
        get help(): string;
        getHelp(): string;
        get key(): $OptionKey<any>;
        getKey(): $OptionKey<any>;
        get name(): string;
        getName(): string;
        get stability(): $OptionStability;
        getStability(): $OptionStability;
        get usageSyntax(): string;
        getUsageSyntax(): string;
        get constant(): boolean;
        isConstant(): boolean;
        get deprecated(): boolean;
        isDeprecated(): boolean;
        get optionMap(): boolean;
        isOptionMap(): boolean;
        static newBuilder<T>(key: $OptionKey<T>, name: string): $OptionDescriptor$Builder;
        equals(obj: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $OptionCategory {
        static EXPERT: $OptionCategory;
        static INTERNAL: $OptionCategory;
        static USER: $OptionCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $OptionCategory[];
        static valueOf(name: string): $OptionCategory;
    }
    export interface $OptionCategory extends $Enum<$OptionCategory> {}

    export class $OptionDescriptor$Builder {
        build(): $OptionDescriptor;
        category(category: $OptionCategory_): $OptionDescriptor$Builder;
        constant(value: boolean): $OptionDescriptor$Builder;
        deprecated(deprecated: boolean): $OptionDescriptor$Builder;
        deprecationMessage(deprecationMessage: string): $OptionDescriptor$Builder;
        help(help: string): $OptionDescriptor$Builder;
        stability(stability: $OptionStability_): $OptionDescriptor$Builder;
        usageSyntax(usageSyntax: string): $OptionDescriptor$Builder;
    }

    export class $OptionKey<T> {
        constructor(defaultValue: T);
        constructor(defaultValue: T, type: $OptionType<T>);
        get defaultValue(): T;
        getDefaultValue(): T;
        get type(): $OptionType<T>;
        getType(): $OptionType<T>;
        static mapOf<V>(valueClass: $Class<V>): $OptionKey<$OptionMap<V>>;
        getValue(values: $OptionValues): T;
        hasBeenSet(values: $OptionValues): boolean;
    }

    export class $OptionStability {
        static EXPERIMENTAL: $OptionStability;
        static STABLE: $OptionStability;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $OptionStability[];
        static valueOf(name: string): $OptionStability;
    }
    export interface $OptionStability extends $Enum<$OptionStability> {}

    export class $OptionMap<T> {
        static empty<T>(): $OptionMap<T>;
        entrySet(): $Set<$Map$Entry<string, T>>;
        equals(obj: unknown): boolean;
        get(key: string): T;
        hashCode(): number;
    }

    export class $OptionType<T> {
        constructor(name: string, defaultValue: T, stringConverter: $Function_<string, T, string, T>);
        constructor(name: string, defaultValue: T, stringConverter: $Function_<string, T, string, T>, validator: $Consumer_<T, T>);
        constructor(name: string, stringConverter: $Function_<string, T, string, T>);
        constructor(name: string, stringConverter: $Function_<string, T, string, T>, validator: $Consumer_<T, T>);
        get defaultValue(): T;
        getDefaultValue(): T;
        get name(): string;
        getName(): string;
        static defaultType<T>(value: T): $OptionType<T>;
        static defaultType<T>(clazz: $Class<T>): $OptionType<T>;
        convert(previousValue: unknown, nameSuffix: string, value: string): T;
        convert(value: string): T;
        toString(): string;
        validate(value: T): void;
    }

    export interface $OptionValues {
        getDescriptors(): $OptionDescriptors;
        get<T>(optionKey: $OptionKey<T>): T;
        hasBeenSet(optionKey: $OptionKey<any>): boolean;
        hasSetOptions(): boolean;
        set<T>(optionKey: $OptionKey<T>, value: T): void;
    }

    export type $OptionCategory_ = $OptionCategory | "EXPERT" | "INTERNAL" | "USER";
    export type $OptionStability_ = $OptionStability | "EXPERIMENTAL" | "STABLE";
}
