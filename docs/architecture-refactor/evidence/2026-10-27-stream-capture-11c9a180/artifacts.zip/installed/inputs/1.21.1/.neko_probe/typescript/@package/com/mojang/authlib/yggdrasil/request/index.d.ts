import { $AbuseReport } from "java:com/mojang/authlib/minecraft/report";
import { $Record } from "java:java/lang";
import { $UUID } from "java:java/util";

declare module "java:com/mojang/authlib/yggdrasil/request" {
    export class $AbuseReportRequest extends $Record {
        constructor(version: number, id: $UUID, report: $AbuseReport, clientInfo: $AbuseReportRequest$ClientInfo, thirdPartyServerInfo: $AbuseReportRequest$ThirdPartyServerInfo, realmInfo: $AbuseReportRequest$RealmInfo, reportType: string);
        clientInfo(): $AbuseReportRequest$ClientInfo;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        id(): $UUID;
        realmInfo(): $AbuseReportRequest$RealmInfo;
        reportType(): string;
        report(): $AbuseReport;
        thirdPartyServerInfo(): $AbuseReportRequest$ThirdPartyServerInfo;
        toString(): string;
        version(): number;
    }

    export class $AbuseReportRequest$ClientInfo extends $Record {
        constructor(clientVersion: string, locale: string);
        clientVersion(): string;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        locale(): string;
        toString(): string;
    }

    export class $AbuseReportRequest$RealmInfo extends $Record {
        constructor(realmId: string, slotId: number);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        realmId(): string;
        slotId(): number;
        toString(): string;
    }

    export class $AbuseReportRequest$ThirdPartyServerInfo extends $Record {
        constructor(address: string);
        address(): string;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

}
