import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Map, $Set } from "java:java/util";
import { $Direction8, $Direction8_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $WorldGenRegion } from "java:net/minecraft/server/level";
import { $LevelHeightAccessor, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Biome, $BiomeResolver, $BiomeResolver_, $Climate$Sampler } from "java:net/minecraft/world/level/biome";
import { $ChunkAccess, $ProtoChunk } from "java:net/minecraft/world/level/chunk";
import { $DensityFunction$FunctionContext } from "java:net/minecraft/world/level/levelgen";

declare module "java:net/minecraft/world/level/levelgen/blending" {
    export class $Blender {
        static addAroundOldChunksCarvingMaskFilter(arg0: $WorldGenLevel, arg1: $ProtoChunk): void;
        static empty(): $Blender;
        static generateBorderTicks(arg0: $WorldGenRegion, arg1: $ChunkAccess): void;
        static makeOldChunkDistanceGetter(arg0: $BlendingData, arg1: ($Map<$Direction8, $BlendingData> | (([$Direction8_] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$Direction8_, PropertyKey>, $BlendingData>>))): $Blender$DistanceGetter;
        static of(arg0: $WorldGenRegion): $Blender;
        blendDensity(arg0: $DensityFunction$FunctionContext, arg1: number): number;
        blendOffsetAndFactor(arg0: number, arg1: number): $Blender$BlendingOutput;
        getBiomeResolver(arg0: $BiomeResolver_<number, number, number, $Climate$Sampler, $Holder_<$Biome>>): $BiomeResolver;
    }

    export class $Blender$BlendingOutput extends $Record {
        constructor(arg0: number, arg1: number);
        alpha(): number;
        blendingOffset(): number;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $Blender$DistanceGetter {
        getDistance(arg0: number, arg1: number, arg2: number): number;
    }

    export class $BlendingData {
        static CODEC: $Codec<$BlendingData>;
        get areaWithOldGeneration(): $LevelHeightAccessor;
        getAreaWithOldGeneration(): $LevelHeightAccessor;
        static getOrUpdateBlendingData(arg0: $WorldGenRegion, arg1: number, arg2: number): $BlendingData;
        static sideByGenerationAge(arg0: $WorldGenLevel, arg1: number, arg2: number, arg3: boolean): $Set<$Direction8>;
    }

    export type $Blender$DistanceGetter_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($Blender$DistanceGetter & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "getDistance": (arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
