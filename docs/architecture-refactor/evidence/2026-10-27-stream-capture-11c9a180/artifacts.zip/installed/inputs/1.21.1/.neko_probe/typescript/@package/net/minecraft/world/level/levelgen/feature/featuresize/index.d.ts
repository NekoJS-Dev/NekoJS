import { $Codec } from "java:com/mojang/serialization";
import { $OptionalInt } from "java:java/util";

declare module "java:net/minecraft/world/level/levelgen/feature/featuresize" {
    export class $FeatureSize {
        constructor(arg0: $OptionalInt);
        static CODEC: $Codec<$FeatureSize>;
        getSizeAtHeight(arg0: number, arg1: number): number;
        minClippedHeight(): $OptionalInt;
    }

}
