import { $DataFixer } from "java:com/mojang/datafixers";
import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $RecordCodecBuilder, $RecordCodecBuilder$Instance } from "java:com/mojang/serialization/codecs";
import { $Enum, $Iterable, $Record } from "java:java/lang";
import { $List, $Map, $Optional } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Consumer, $Consumer_, $Function, $Function_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $HolderSet, $Holder_, $RegistryAccess, $Vec3i } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $StreamTagVisitor } from "java:net/minecraft/nbt";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $WeightedRandomList } from "java:net/minecraft/util/random";
import { $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $BlockGetter, $ChunkPos, $Level, $LevelHeightAccessor, $StructureManager, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Biome, $BiomeSource, $MobSpawnSettings$SpawnerData } from "java:net/minecraft/world/level/biome";
import { $Mirror, $Mirror_, $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $ChunkScanAccess, $ChunkScanAccess_ } from "java:net/minecraft/world/level/chunk/storage";
import { $GenerationStep$Decoration, $GenerationStep$Decoration_, $RandomState, $WorldgenRandom } from "java:net/minecraft/world/level/levelgen";
import { $PiecesContainer, $StructurePieceSerializationContext, $StructurePieceType, $StructurePieceType_, $StructurePiecesBuilder } from "java:net/minecraft/world/level/levelgen/structure/pieces";
import { $StructurePlacement } from "java:net/minecraft/world/level/levelgen/structure/placement";
import { $BuriedTreasureStructure, $DesertPyramidStructure, $EndCityStructure, $IglooStructure, $JigsawStructure, $JungleTempleStructure, $MineshaftStructure, $NetherFortressStructure, $NetherFossilStructure, $OceanMonumentStructure, $OceanRuinStructure, $RuinedPortalStructure, $ShipwreckStructure, $StrongholdStructure, $SwampHutStructure, $WoodlandMansionStructure } from "java:net/minecraft/world/level/levelgen/structure/structures";
import { $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";
import { $ModifiableStructureInfo } from "java:net/neoforged/neoforge/common/world";

export * as pieces from "java:net/minecraft/world/level/levelgen/structure/pieces";
export * as placement from "java:net/minecraft/world/level/levelgen/structure/placement";
export * as pools from "java:net/minecraft/world/level/levelgen/structure/pools";
export * as structures from "java:net/minecraft/world/level/levelgen/structure/structures";
export * as templatesystem from "java:net/minecraft/world/level/levelgen/structure/templatesystem";

declare module "java:net/minecraft/world/level/levelgen/structure" {
    export class $BoundingBox {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number);
        constructor(arg0: $BlockPos_);
        static CODEC: $Codec<$BoundingBox>;
        get center(): $BlockPos;
        getCenter(): $BlockPos;
        get length(): $Vec3i;
        getLength(): $Vec3i;
        get xSpan(): number;
        getXSpan(): number;
        get ySpan(): number;
        getYSpan(): number;
        get zSpan(): number;
        getZSpan(): number;
        static encapsulatingBoxes(arg0: ($Iterable<$BoundingBox> | ($BoundingBox)[])): $Optional<$BoundingBox>;
        static encapsulatingPositions(arg0: ($Iterable<$BlockPos> | ($BlockPos_)[])): $Optional<$BoundingBox>;
        static fromCorners(arg0: $Vec3i, arg1: $Vec3i): $BoundingBox;
        static infinite(): $BoundingBox;
        static orientBox(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number, arg8: number, arg9: $Direction_): $BoundingBox;
        encapsulate(arg0: $BlockPos_): $BoundingBox;
        encapsulate(arg0: $BoundingBox): $BoundingBox;
        equals(arg0: unknown): boolean;
        forAllCorners(arg0: $Consumer_<$BlockPos, $BlockPos>): void;
        hashCode(): number;
        inflatedBy(arg0: number, arg1: number, arg2: number): $BoundingBox;
        inflatedBy(arg0: number): $BoundingBox;
        intersectingChunks(): $Stream<$ChunkPos>;
        intersects(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        intersects(arg0: $BoundingBox): boolean;
        isInside(arg0: number, arg1: number, arg2: number): boolean;
        isInside(arg0: $Vec3i): boolean;
        maxX(): number;
        maxY(): number;
        maxZ(): number;
        minX(): number;
        minY(): number;
        minZ(): number;
        moved(arg0: number, arg1: number, arg2: number): $BoundingBox;
        move(arg0: number, arg1: number, arg2: number): $BoundingBox;
        move(arg0: $Vec3i): $BoundingBox;
        toString(): string;
    }

    export class $SinglePieceStructure extends $Structure {
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
    }

    export class $Structure {
        static CODEC: $Codec<$Holder<$Structure>>;
        static DIRECT_CODEC: $Codec<$Structure>;
        get modifiedStructureSettings(): $Structure$StructureSettings;
        getModifiedStructureSettings(): $Structure$StructureSettings;
        static getMeanFirstOccupiedHeight(arg0: $Structure$GenerationContext, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static settingsCodec<S extends $Structure>(arg0: $RecordCodecBuilder$Instance<S>): $RecordCodecBuilder<S, $Structure$StructureSettings>;
        static simpleCodec<S extends $Structure>(arg0: $Function_<$Structure$StructureSettings, S, $Structure$StructureSettings, S>): $MapCodec<S>;
        adjustBoundingBox(arg0: $BoundingBox): $BoundingBox;
        afterPlace(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BoundingBox, arg5: $ChunkPos, arg6: $PiecesContainer): void;
        biomes(): $HolderSet<$Biome>;
        findValidGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        generate(arg0: $RegistryAccess, arg1: $ChunkGenerator, arg2: $BiomeSource, arg3: $RandomState, arg4: $StructureTemplateManager, arg5: number, arg6: $ChunkPos, arg7: number, arg8: $LevelHeightAccessor, arg9: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>): $StructureStart;
        modifiableStructureInfo(): $ModifiableStructureInfo;
        spawnOverrides(): $Map<$MobCategory, $StructureSpawnOverride>;
        step(): $GenerationStep$Decoration;
        terrainAdaptation(): $TerrainAdjustment;
        type(): $StructureType<any>;
    }

    export class $Structure$GenerationContext extends $Record {
        constructor(arg0: $RegistryAccess, arg1: $ChunkGenerator, arg2: $BiomeSource, arg3: $RandomState, arg4: $StructureTemplateManager, arg5: number, arg6: $ChunkPos, arg7: $LevelHeightAccessor, arg8: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>);
        constructor(registryAccess: $RegistryAccess, chunkGenerator: $ChunkGenerator, biomeSource: $BiomeSource, randomState: $RandomState, structureTemplateManager: $StructureTemplateManager, random: $WorldgenRandom, seed: number, chunkPos: $ChunkPos, heightAccessor: $LevelHeightAccessor, validBiome: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>);
        biomeSource(): $BiomeSource;
        chunkGenerator(): $ChunkGenerator;
        chunkPos(): $ChunkPos;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        heightAccessor(): $LevelHeightAccessor;
        randomState(): $RandomState;
        random(): $WorldgenRandom;
        registryAccess(): $RegistryAccess;
        seed(): number;
        structureTemplateManager(): $StructureTemplateManager;
        toString(): string;
        validBiome(): $Predicate<$Holder<$Biome>>;
    }

    export class $Structure$GenerationStub extends $Record {
        constructor(position: $BlockPos_, generator: $Either<$Consumer<$StructurePiecesBuilder>, $StructurePiecesBuilder>);
        constructor(arg0: $BlockPos_, arg1: $Consumer_<$StructurePiecesBuilder, $StructurePiecesBuilder>);
        get piecesBuilder(): $StructurePiecesBuilder;
        getPiecesBuilder(): $StructurePiecesBuilder;
        equals(arg0: unknown): boolean;
        generator(): $Either<$Consumer<$StructurePiecesBuilder>, $StructurePiecesBuilder>;
        hashCode(): number;
        position(): $BlockPos;
        toString(): string;
    }

    export class $Structure$StructureSettings extends $Record {
        constructor(arg0: $HolderSet<$Biome>);
        constructor(biomes: $HolderSet<$Biome>, spawnOverrides: ($Map<$MobCategory, $StructureSpawnOverride> | (([$MobCategory_] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$MobCategory_, PropertyKey>, $StructureSpawnOverride>>)), step: $GenerationStep$Decoration_, terrainAdaptation: $TerrainAdjustment_);
        static CODEC: $MapCodec<$Structure$StructureSettings>;
        biomes(): $HolderSet<$Biome>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        spawnOverrides(): $Map<$MobCategory, $StructureSpawnOverride>;
        step(): $GenerationStep$Decoration;
        terrainAdaptation(): $TerrainAdjustment;
        toString(): string;
    }

    export class $StructureCheck {
        constructor(arg0: $ChunkScanAccess_<$ChunkPos, $StreamTagVisitor, $CompletableFuture<void>>, arg1: $RegistryAccess, arg2: $StructureTemplateManager, arg3: $ResourceKey<$Level>, arg4: $ChunkGenerator, arg5: $RandomState, arg6: $LevelHeightAccessor, arg7: $BiomeSource, arg8: number, arg9: $DataFixer);
        checkStart(arg0: $ChunkPos, arg1: $Structure, arg2: $StructurePlacement, arg3: boolean): $StructureCheckResult;
        incrementReference(arg0: $ChunkPos, arg1: $Structure): void;
        onStructureLoad(arg0: $ChunkPos, arg1: ($Map<$Structure, $StructureStart> | (([$Structure] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<$Structure, PropertyKey>, $StructureStart>>))): void;
    }

    export class $StructureCheckResult {
        static CHUNK_LOAD_NEEDED: $StructureCheckResult;
        static START_NOT_PRESENT: $StructureCheckResult;
        static START_PRESENT: $StructureCheckResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StructureCheckResult[];
        static valueOf(name: string): $StructureCheckResult;
    }
    export interface $StructureCheckResult extends $Enum<$StructureCheckResult> {}

    export class $StructurePiece {
        constructor(arg0: $StructurePieceType_, arg1: $CompoundTag_);
        get boundingBox(): $BoundingBox;
        getBoundingBox(): $BoundingBox;
        get genDepth(): number;
        getGenDepth(): number;
        set genDepth(value: number);
        get locatorPosition(): $BlockPos;
        getLocatorPosition(): $BlockPos;
        get mirror(): $Mirror;
        getMirror(): $Mirror;
        get orientation(): $Direction;
        getOrientation(): $Direction;
        set orientation(value: $Direction_);
        get rotation(): $Rotation;
        getRotation(): $Rotation;
        get type(): $StructurePieceType;
        getType(): $StructurePieceType;
        static createBoundingBox(arg0: $Stream<$StructurePiece>): $BoundingBox;
        static findCollisionPiece(arg0: ($List<$StructurePiece> | ($StructurePiece)[]), arg1: $BoundingBox): $StructurePiece;
        static reorient(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $BlockState_): $BlockState;
        addChildren(arg0: $StructurePiece, arg1: $StructurePieceAccessor, arg2: $RandomSource): void;
        createTag(arg0: $StructurePieceSerializationContext): $CompoundTag;
        isCloseToChunk(arg0: $ChunkPos, arg1: number): boolean;
        move(arg0: number, arg1: number, arg2: number): void;
        postProcess(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BoundingBox, arg5: $ChunkPos, arg6: $BlockPos_): void;
        setGenDepth(arg0: number): void;
        setOrientation(arg0: $Direction_): void;
    }

    export interface $StructurePieceAccessor {
        addPiece(arg0: $StructurePiece): void;
        findCollisionPiece(arg0: $BoundingBox): $StructurePiece;
    }

    export class $StructureSet extends $Record {
        constructor(arg0: ($List<$StructureSet$StructureSelectionEntry> | ($StructureSet$StructureSelectionEntry)[]), arg1: $StructurePlacement);
        constructor(arg0: $Holder_<$Structure>, arg1: $StructurePlacement);
        static CODEC: $Codec<$Holder<$StructureSet>>;
        static DIRECT_CODEC: $Codec<$StructureSet>;
        static entry(arg0: $Holder_<$Structure>, arg1: number): $StructureSet$StructureSelectionEntry;
        static entry(arg0: $Holder_<$Structure>): $StructureSet$StructureSelectionEntry;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        placement(): $StructurePlacement;
        structures(): $List<$StructureSet$StructureSelectionEntry>;
        toString(): string;
    }

    export class $StructureSet$StructureSelectionEntry extends $Record {
        constructor(arg0: $Holder_<$Structure>, arg1: number);
        static CODEC: $Codec<$StructureSet$StructureSelectionEntry>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        structure(): $Holder<$Structure>;
        toString(): string;
        weight(): number;
    }

    export class $StructureSpawnOverride extends $Record {
        constructor(arg0: $StructureSpawnOverride$BoundingBoxType_, arg1: $WeightedRandomList<$MobSpawnSettings$SpawnerData>);
        static CODEC: $Codec<$StructureSpawnOverride>;
        boundingBox(): $StructureSpawnOverride$BoundingBoxType;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        spawns(): $WeightedRandomList<$MobSpawnSettings$SpawnerData>;
        toString(): string;
    }

    export class $StructureSpawnOverride$BoundingBoxType {
        static PIECE: $StructureSpawnOverride$BoundingBoxType;
        static STRUCTURE: $StructureSpawnOverride$BoundingBoxType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StructureSpawnOverride$BoundingBoxType[];
        static valueOf(name: string): $StructureSpawnOverride$BoundingBoxType;
    }
    export interface $StructureSpawnOverride$BoundingBoxType extends $Enum<$StructureSpawnOverride$BoundingBoxType>, $StringRepresentable {}

    export class $StructureStart {
        constructor(arg0: $Structure, arg1: $ChunkPos, arg2: number, arg3: $PiecesContainer);
        static INVALID_START: $StructureStart;
        static INVALID_START_ID: string;
        get boundingBox(): $BoundingBox;
        getBoundingBox(): $BoundingBox;
        get chunkPos(): $ChunkPos;
        getChunkPos(): $ChunkPos;
        get pieces(): $List<$StructurePiece>;
        getPieces(): $List<$StructurePiece>;
        get references(): number;
        getReferences(): number;
        get structure(): $Structure;
        getStructure(): $Structure;
        get valid(): boolean;
        isValid(): boolean;
        static loadStaticStart(arg0: $StructurePieceSerializationContext, arg1: $CompoundTag_, arg2: number): $StructureStart;
        addReference(): void;
        canBeReferenced(): boolean;
        createTag(arg0: $StructurePieceSerializationContext, arg1: $ChunkPos): $CompoundTag;
        placeInChunk(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BoundingBox, arg5: $ChunkPos): void;
    }

    export interface $StructureType<S extends $Structure> {
        codec(): $MapCodec<S>;
    }
    export const $StructureType: {
        readonly BURIED_TREASURE: $StructureType<$BuriedTreasureStructure>;
        readonly DESERT_PYRAMID: $StructureType<$DesertPyramidStructure>;
        readonly END_CITY: $StructureType<$EndCityStructure>;
        readonly FORTRESS: $StructureType<$NetherFortressStructure>;
        readonly IGLOO: $StructureType<$IglooStructure>;
        readonly JIGSAW: $StructureType<$JigsawStructure>;
        readonly JUNGLE_TEMPLE: $StructureType<$JungleTempleStructure>;
        readonly MINESHAFT: $StructureType<$MineshaftStructure>;
        readonly NETHER_FOSSIL: $StructureType<$NetherFossilStructure>;
        readonly OCEAN_MONUMENT: $StructureType<$OceanMonumentStructure>;
        readonly OCEAN_RUIN: $StructureType<$OceanRuinStructure>;
        readonly RUINED_PORTAL: $StructureType<$RuinedPortalStructure>;
        readonly SHIPWRECK: $StructureType<$ShipwreckStructure>;
        readonly STRONGHOLD: $StructureType<$StrongholdStructure>;
        readonly SWAMP_HUT: $StructureType<$SwampHutStructure>;
        readonly WOODLAND_MANSION: $StructureType<$WoodlandMansionStructure>;
    };

    export class $TerrainAdjustment {
        static BEARD_BOX: $TerrainAdjustment;
        static BEARD_THIN: $TerrainAdjustment;
        static BURY: $TerrainAdjustment;
        static ENCAPSULATE: $TerrainAdjustment;
        static NONE: $TerrainAdjustment;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TerrainAdjustment[];
        static valueOf(name: string): $TerrainAdjustment;
    }
    export interface $TerrainAdjustment extends $Enum<$TerrainAdjustment>, $StringRepresentable {}

    export type $StructureCheckResult_ = $StructureCheckResult | "CHUNK_LOAD_NEEDED" | "START_NOT_PRESENT" | "START_PRESENT";
    export type $StructureSpawnOverride$BoundingBoxType_ = $StructureSpawnOverride$BoundingBoxType | "PIECE" | "STRUCTURE";
    export type $StructureType_<Host0 extends $Structure = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($StructureType<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "codec": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $TerrainAdjustment_ = $TerrainAdjustment | "BEARD_BOX" | "BEARD_THIN" | "BURY" | "ENCAPSULATE" | "NONE";
}
