import { $Codec, $DataResult, $DynamicOps } from "java:com/mojang/serialization";
import { $Class, $Comparable, $Comparable_, $Enum, $Record } from "java:java/lang";
import { $Collection, $Optional } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $StateHolder } from "java:net/minecraft/world/level/block/state";

declare module "java:net/minecraft/world/level/block/state/properties" {
    export class $BooleanProperty extends $Property<boolean> {
        get name(): string;
        getName(): string;
        get possibleValues(): $Collection<boolean>;
        getPossibleValues(): $Collection<boolean>;
        static create(arg0: string): $BooleanProperty;
        equals(arg0: unknown): boolean;
        generateHashCode(): number;
        getName(arg0: boolean): string;
        getValue(arg0: string): $Optional<boolean>;
    }

    export class $IntegerProperty extends $Property<number> {
        get name(): string;
        getName(): string;
        get possibleValues(): $Collection<number>;
        getPossibleValues(): $Collection<number>;
        static create(arg0: string, arg1: number, arg2: number): $IntegerProperty;
        equals(arg0: unknown): boolean;
        generateHashCode(): number;
        getName(arg0: number): string;
        getValue(arg0: string): $Optional<number>;
    }

    export class $NoteBlockInstrument {
        static BANJO: $NoteBlockInstrument;
        static BASEDRUM: $NoteBlockInstrument;
        static BASS: $NoteBlockInstrument;
        static BELL: $NoteBlockInstrument;
        static BIT: $NoteBlockInstrument;
        static CHIME: $NoteBlockInstrument;
        static COW_BELL: $NoteBlockInstrument;
        static CREEPER: $NoteBlockInstrument;
        static CUSTOM_HEAD: $NoteBlockInstrument;
        static DIDGERIDOO: $NoteBlockInstrument;
        static DRAGON: $NoteBlockInstrument;
        static FLUTE: $NoteBlockInstrument;
        static GUITAR: $NoteBlockInstrument;
        static HARP: $NoteBlockInstrument;
        static HAT: $NoteBlockInstrument;
        static IRON_XYLOPHONE: $NoteBlockInstrument;
        static PIGLIN: $NoteBlockInstrument;
        static PLING: $NoteBlockInstrument;
        static SKELETON: $NoteBlockInstrument;
        static SNARE: $NoteBlockInstrument;
        static WITHER_SKELETON: $NoteBlockInstrument;
        static XYLOPHONE: $NoteBlockInstrument;
        static ZOMBIE: $NoteBlockInstrument;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $NoteBlockInstrument[];
        static valueOf(name: string): $NoteBlockInstrument;
    }
    export interface $NoteBlockInstrument extends $Enum<$NoteBlockInstrument>, $StringRepresentable {}

    export class $Property<T extends ($Comparable<T> | string | number | boolean)> {
        get allValues(): $Stream<$Property$Value<T>>;
        getAllValues(): $Stream<$Property$Value<T>>;
        get name(): string;
        getName(): string;
        get possibleValues(): $Collection<T>;
        getPossibleValues(): $Collection<T>;
        get valueClass(): $Class<T>;
        getValueClass(): $Class<T>;
        codec(): $Codec<T>;
        equals(arg0: unknown): boolean;
        generateHashCode(): number;
        getName(arg0: T): string;
        getValue(arg0: string): $Optional<T>;
        hashCode(): number;
        parseValue<U, S extends $StateHolder<any, S>>(arg0: $DynamicOps<U>, arg1: S, arg2: U): $DataResult<S>;
        toString(): string;
        valueCodec(): $Codec<$Property$Value<T>>;
        value(arg0: T): $Property$Value<T>;
        value(arg0: $StateHolder<any, any>): $Property$Value<T>;
    }

    export class $Property$Value<T extends ($Comparable<T> | string | number | boolean)> extends $Record {
        constructor(arg0: $Property<T>, arg1: T);
        equals(arg0: unknown): boolean;
        hashCode(): number;
        property(): $Property<T>;
        toString(): string;
        value(): T;
    }

    export class $StructureMode {
        static CORNER: $StructureMode;
        static DATA: $StructureMode;
        static LOAD: $StructureMode;
        static SAVE: $StructureMode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StructureMode[];
        static valueOf(name: string): $StructureMode;
    }
    export interface $StructureMode extends $Enum<$StructureMode>, $StringRepresentable {}

    export type $NoteBlockInstrument_ = $NoteBlockInstrument | "BANJO" | "BASEDRUM" | "BASS" | "BELL" | "BIT" | "CHIME" | "COW_BELL" | "CREEPER" | "CUSTOM_HEAD" | "DIDGERIDOO" | "DRAGON" | "FLUTE" | "GUITAR" | "HARP" | "HAT" | "IRON_XYLOPHONE" | "PIGLIN" | "PLING" | "SKELETON" | "SNARE" | "WITHER_SKELETON" | "XYLOPHONE" | "ZOMBIE";
    export type $StructureMode_ = $StructureMode | "CORNER" | "DATA" | "LOAD" | "SAVE";
}
