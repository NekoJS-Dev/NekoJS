import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $IRecipeManagerExtension, $IRecipeManagerExtension_ } from "java:com/tkisor/nekojs/api/recipe";
import { $IntList } from "java:it/unimi/dsi/fastutil/ints";
import { $Enum, $Iterable, $Record } from "java:java/lang";
import { $Collection, $List, $Map, $Optional } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $HolderLookup$Provider, $NonNullList } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $SimpleJsonResourceReloadListener } from "java:net/minecraft/server/packs/resources";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $StackedContents } from "java:net/minecraft/world/entity/player";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $ItemLike, $ItemLike_, $Level } from "java:net/minecraft/world/level";
import { $WithConditions } from "java:net/neoforged/neoforge/common/conditions";
import { $ICustomIngredient } from "java:net/neoforged/neoforge/common/crafting";
import { $Logger } from "java:org/slf4j";

declare module "java:net/minecraft/world/item/crafting" {
    export class $AbstractCookingRecipe implements $Recipe<$SingleRecipeInput> {
        constructor(arg0: $RecipeType<any>, arg1: string, arg2: $CookingBookCategory_, arg3: $Ingredient_, arg4: $ItemStack_, arg5: number, arg6: number);
        get cookingTime(): number;
        getCookingTime(): number;
        get experience(): number;
        getExperience(): number;
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        assemble(arg0: $SingleRecipeInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        category(): $CookingBookCategory;
        getRemainingItems(arg0: $SingleRecipeInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        matches(arg0: $SingleRecipeInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $ArmorDyeRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $BannerDuplicateRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $BlastingRecipe extends $AbstractCookingRecipe {
        constructor(arg0: string, arg1: $CookingBookCategory_, arg2: $Ingredient_, arg3: $ItemStack_, arg4: number, arg5: number);
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        getRemainingItems(arg0: $SingleRecipeInput): $NonNullList<$ItemStack>;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $BookCloningRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $CampfireCookingRecipe extends $AbstractCookingRecipe {
        constructor(arg0: string, arg1: $CookingBookCategory_, arg2: $Ingredient_, arg3: $ItemStack_, arg4: number, arg5: number);
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        getRemainingItems(arg0: $SingleRecipeInput): $NonNullList<$ItemStack>;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $CookingBookCategory {
        static BLOCKS: $CookingBookCategory;
        static FOOD: $CookingBookCategory;
        static MISC: $CookingBookCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CookingBookCategory[];
        static valueOf(name: string): $CookingBookCategory;
    }
    export interface $CookingBookCategory extends $Enum<$CookingBookCategory>, $StringRepresentable {}

    export class $CraftingBookCategory {
        static BUILDING: $CraftingBookCategory;
        static EQUIPMENT: $CraftingBookCategory;
        static MISC: $CraftingBookCategory;
        static REDSTONE: $CraftingBookCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CraftingBookCategory[];
        static valueOf(name: string): $CraftingBookCategory;
    }
    export interface $CraftingBookCategory extends $Enum<$CraftingBookCategory>, $StringRepresentable {}

    export class $CraftingInput implements $RecipeInput {
        static EMPTY: $CraftingInput;
        get empty(): boolean;
        isEmpty(): boolean;
        static ofPositioned(arg0: number, arg1: number, arg2: ($List<$ItemStack> | ($ItemStack_)[])): $CraftingInput$Positioned;
        static of(arg0: number, arg1: number, arg2: ($List<$ItemStack> | ($ItemStack_)[])): $CraftingInput;
        equals(arg0: unknown): boolean;
        getItem(arg0: number, arg1: number): $ItemStack;
        getItem(arg0: number): $ItemStack;
        hashCode(): number;
        height(): number;
        ingredientCount(): number;
        items(): $List<$ItemStack>;
        size(): number;
        stackedContents(): $StackedContents;
        width(): number;
    }

    export class $CraftingInput$Positioned extends $Record {
        constructor(arg0: $CraftingInput, arg1: number, arg2: number);
        static EMPTY: $CraftingInput$Positioned;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        input(): $CraftingInput;
        left(): number;
        toString(): string;
        top(): number;
    }

    export interface $CraftingRecipe extends $Recipe<$CraftingInput> {
        category(): $CraftingBookCategory;
        getType(): $RecipeType<any>;
    }

    export class $CustomRecipe implements $CraftingRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        category(): $CraftingBookCategory;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $DecoratedPotRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $FireworkRocketRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $FireworkStarFadeRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $FireworkStarRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $Ingredient implements $Predicate<$ItemStack> {
        constructor(arg0: $Stream<$Ingredient$Value>);
        constructor(arg0: $ICustomIngredient);
        static CODEC: $Codec<$Ingredient>;
        static CODEC_NONEMPTY: $Codec<$Ingredient>;
        static CONTENTS_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Ingredient>;
        static EMPTY: $Ingredient;
        static LIST_CODEC: $Codec<$List<$Ingredient>>;
        static LIST_CODEC_NONEMPTY: $Codec<$List<$Ingredient>>;
        static MAP_CODEC_NONEMPTY: $MapCodec<$Ingredient>;
        itemStacks: $ItemStack[];
        get stackingIds(): $IntList;
        set stackingIds(value: $IntList);
        get values(): $Ingredient$Value[];
        set values(value: $Ingredient$Value_<($Collection<$ItemStack> | ($ItemStack_)[])>[]);
        get customIngredient(): $ICustomIngredient;
        getCustomIngredient(): $ICustomIngredient;
        get items(): $ItemStack[];
        getItems(): $ItemStack[];
        getStackingIds(): $IntList;
        getValues(): $Ingredient$Value[];
        get custom(): boolean;
        isCustom(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        get simple(): boolean;
        isSimple(): boolean;
        static fromValues(arg0: $Stream<$Ingredient$Value>): $Ingredient;
        static of(arg0: $Stream<$ItemStack>): $Ingredient;
        static of(arg0: $TagKey_<$Item>): $Ingredient;
        static of(arg0?: $ItemStack_[]): $Ingredient;
        static of(arg0?: $ItemLike_[]): $Ingredient;
        static of(): $Ingredient;
        and(arg0: $Predicate_<$ItemStack, $ItemStack, boolean>): $Predicate<$ItemStack>;
        equals(arg0: unknown): boolean;
        hasNoItems(): boolean;
        hashCode(): number;
        negate(): $Predicate<$ItemStack>;
        or(arg0: $Predicate_<$ItemStack, $ItemStack, boolean>): $Predicate<$ItemStack>;
        test(arg0: $ItemStack_): boolean;
    }

    export interface $Ingredient$Value {
        getItems(): $Collection<$ItemStack>;
    }
    export const $Ingredient$Value: {
        readonly CODEC: $Codec<$Ingredient$Value>;
        readonly MAP_CODEC: $MapCodec<$Ingredient$Value>;
    };

    export class $MapCloningRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $MapExtendingRecipe extends $ShapedRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get special(): boolean;
        isSpecial(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
    }

    export interface $Recipe<T extends $RecipeInput> {
        assemble(arg0: T, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getGroup(): string;
        getIngredients(): $NonNullList<$Ingredient>;
        getRemainingItems(arg0: T): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        getSerializer(): $RecipeSerializer<any>;
        getToastSymbol(): $ItemStack;
        getType(): $RecipeType<any>;
        isIncomplete(): boolean;
        isSpecial(): boolean;
        matches(arg0: T, arg1: $Level): boolean;
        "showNotification()"(): boolean;
    }
    export const $Recipe: {
        readonly CODEC: $Codec<$Recipe<any>>;
        readonly CONDITIONAL_CODEC: $Codec<$Optional<$WithConditions<$Recipe<any>>>>;
        readonly STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Recipe<any>>;
    };

    export class $RecipeHolder<T extends $Recipe<any>> extends $Record {
        constructor(arg0: $ResourceLocation_, arg1: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $RecipeHolder<any>>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        toString(): string;
        value(): T;
    }

    export interface $RecipeInput {
        getItem(arg0: number): $ItemStack;
        isEmpty(): boolean;
        size(): number;
    }

    export class $RecipeManager extends $SimpleJsonResourceReloadListener implements $IRecipeManagerExtension {
        constructor(arg0: $HolderLookup$Provider);
        static LOGGER: $Logger;
        get name(): string;
        getName(): string;
        get orderedRecipes(): $Collection<$RecipeHolder<any>>;
        getOrderedRecipes(): $Collection<$RecipeHolder<any>>;
        get recipeIds(): $Stream<$ResourceLocation>;
        getRecipeIds(): $Stream<$ResourceLocation>;
        get recipes(): $Collection<$RecipeHolder<any>>;
        getRecipes(): $Collection<$RecipeHolder<any>>;
        static createCheck<I extends $RecipeInput, T extends $Recipe<I>>(arg0: $RecipeType<T>): $RecipeManager$CachedCheck<I, T>;
        byKey(arg0: $ResourceLocation_): $Optional<$RecipeHolder<any>>;
        getAllRecipesFor<I extends $RecipeInput, T extends $Recipe<I>>(arg0: $RecipeType<T>): $List<$RecipeHolder<T>>;
        getRecipeFor<I extends $RecipeInput, T extends $Recipe<I>>(arg0: $RecipeType<T>, arg1: I, arg2: $Level, arg3: $ResourceLocation_): $Optional<$RecipeHolder<T>>;
        getRecipeFor<I extends $RecipeInput, T extends $Recipe<I>>(arg0: $RecipeType<T>, arg1: I, arg2: $Level, arg3: $RecipeHolder<T>): $Optional<$RecipeHolder<T>>;
        getRecipeFor<I extends $RecipeInput, T extends $Recipe<I>>(arg0: $RecipeType<T>, arg1: I, arg2: $Level): $Optional<$RecipeHolder<T>>;
        getRecipesFor<I extends $RecipeInput, T extends $Recipe<I>>(arg0: $RecipeType<T>, arg1: I, arg2: $Level): $List<$RecipeHolder<T>>;
        getRemainingItemsFor<I extends $RecipeInput, T extends $Recipe<I>>(arg0: $RecipeType<T>, arg1: I, arg2: $Level): $NonNullList<$ItemStack>;
        hadErrorsLoading(): boolean;
        nekojs$applyScripts(): void;
        replaceRecipes(arg0: ($Iterable<$RecipeHolder<any>> | ($RecipeHolder<any>)[])): void;
    }

    export interface $RecipeManager$CachedCheck<I extends $RecipeInput, T extends $Recipe<I>> {
        getRecipeFor(arg0: I, arg1: $Level): $Optional<$RecipeHolder<T>>;
    }

    export interface $RecipeSerializer<T extends $Recipe<any>> {
        codec(): $MapCodec<T>;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, T>;
    }
    export const $RecipeSerializer: {
        register<S extends $RecipeSerializer<T>, T extends $Recipe<any>>(arg0: string, arg1: S): S;
        readonly ARMOR_DYE: $RecipeSerializer<$ArmorDyeRecipe>;
        readonly BANNER_DUPLICATE: $RecipeSerializer<$BannerDuplicateRecipe>;
        readonly BLASTING_RECIPE: $RecipeSerializer<$BlastingRecipe>;
        readonly BOOK_CLONING: $RecipeSerializer<$BookCloningRecipe>;
        readonly CAMPFIRE_COOKING_RECIPE: $RecipeSerializer<$CampfireCookingRecipe>;
        readonly DECORATED_POT_RECIPE: $RecipeSerializer<$DecoratedPotRecipe>;
        readonly FIREWORK_ROCKET: $RecipeSerializer<$FireworkRocketRecipe>;
        readonly FIREWORK_STAR: $RecipeSerializer<$FireworkStarRecipe>;
        readonly FIREWORK_STAR_FADE: $RecipeSerializer<$FireworkStarFadeRecipe>;
        readonly MAP_CLONING: $RecipeSerializer<$MapCloningRecipe>;
        readonly MAP_EXTENDING: $RecipeSerializer<$MapExtendingRecipe>;
        readonly REPAIR_ITEM: $RecipeSerializer<$RepairItemRecipe>;
        readonly SHAPED_RECIPE: $RecipeSerializer<$ShapedRecipe>;
        readonly SHAPELESS_RECIPE: $RecipeSerializer<$ShapelessRecipe>;
        readonly SHIELD_DECORATION: $RecipeSerializer<$ShieldDecorationRecipe>;
        readonly SHULKER_BOX_COLORING: $RecipeSerializer<$ShulkerBoxColoring>;
        readonly SMELTING_RECIPE: $RecipeSerializer<$SmeltingRecipe>;
        readonly SMITHING_TRANSFORM: $RecipeSerializer<$SmithingTransformRecipe>;
        readonly SMITHING_TRIM: $RecipeSerializer<$SmithingTrimRecipe>;
        readonly SMOKING_RECIPE: $RecipeSerializer<$SmokingRecipe>;
        readonly STONECUTTER: $RecipeSerializer<$StonecutterRecipe>;
        readonly SUSPICIOUS_STEW: $RecipeSerializer<$SuspiciousStewRecipe>;
        readonly TIPPED_ARROW: $RecipeSerializer<$TippedArrowRecipe>;
    };

    export interface $RecipeType<T extends $Recipe<any>> {
    }
    export const $RecipeType: {
        register<T extends $Recipe<any>>(arg0: string): $RecipeType<T>;
        simple<T extends $Recipe<any>>(arg0: $ResourceLocation_): $RecipeType<T>;
        readonly BLASTING: $RecipeType<$BlastingRecipe>;
        readonly CAMPFIRE_COOKING: $RecipeType<$CampfireCookingRecipe>;
        readonly CRAFTING: $RecipeType<$CraftingRecipe>;
        readonly SMELTING: $RecipeType<$SmeltingRecipe>;
        readonly SMITHING: $RecipeType<$SmithingRecipe>;
        readonly SMOKING: $RecipeType<$SmokingRecipe>;
        readonly STONECUTTING: $RecipeType<$StonecutterRecipe>;
    };

    export class $RepairItemRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $ShapedRecipe implements $CraftingRecipe {
        constructor(arg0: string, arg1: $CraftingBookCategory_, arg2: $ShapedRecipePattern, arg3: $ItemStack_);
        constructor(arg0: string, arg1: $CraftingBookCategory_, arg2: $ShapedRecipePattern, arg3: $ItemStack_, arg4: boolean);
        pattern: $ShapedRecipePattern;
        result: $ItemStack;
        showNotification: boolean;
        get group(): string;
        getGroup(): string;
        get height(): number;
        getHeight(): number;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get width(): number;
        getWidth(): number;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        category(): $CraftingBookCategory;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        "showNotification()"(): boolean;
    }

    export class $ShapedRecipePattern {
        constructor(arg0: number, arg1: number, arg2: $NonNullList<$Ingredient>, arg3: $Optional<$ShapedRecipePattern$Data>);
        static MAP_CODEC: $MapCodec<$ShapedRecipePattern>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ShapedRecipePattern>;
        symmetrical: boolean;
        static getMaxHeight(): number;
        static getMaxWidth(): number;
        static of(arg0: ($Map<string, $Ingredient> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, $Ingredient_>>)), arg1?: string[]): $ShapedRecipePattern;
        static of(arg0: ($Map<string, $Ingredient> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, $Ingredient_>>)), arg1: ($List<string> | (string)[])): $ShapedRecipePattern;
        static setCraftingSize(arg0: number, arg1: number): void;
        height(): number;
        ingredients(): $NonNullList<$Ingredient>;
        matches(arg0: $CraftingInput): boolean;
        width(): number;
    }

    export class $ShapedRecipePattern$Data extends $Record {
        constructor(key: ($Map<string, $Ingredient> | (([string] extends [PropertyKey] ? unknown : never) & Partial<Record<Extract<string, PropertyKey>, $Ingredient_>>)), pattern: ($List<string> | (string)[]));
        static MAP_CODEC: $MapCodec<$ShapedRecipePattern$Data>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        key(): $Map<string, $Ingredient>;
        pattern(): $List<string>;
        toString(): string;
    }

    export class $ShapelessRecipe implements $CraftingRecipe {
        constructor(arg0: string, arg1: $CraftingBookCategory_, arg2: $ItemStack_, arg3: $NonNullList<$Ingredient>);
        get group(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        result: $ItemStack;
        getGroup(): string;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        category(): $CraftingBookCategory;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $ShieldDecorationRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $ShulkerBoxColoring extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $SingleItemRecipe implements $Recipe<$SingleRecipeInput> {
        constructor(arg0: $RecipeType<any>, arg1: $RecipeSerializer<any>, arg2: string, arg3: $Ingredient_, arg4: $ItemStack_);
        result: $ItemStack;
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        assemble(arg0: $SingleRecipeInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $SingleRecipeInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        matches(arg0: $SingleRecipeInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $SingleRecipeInput extends $Record implements $RecipeInput {
        constructor(arg0: $ItemStack_);
        get empty(): boolean;
        isEmpty(): boolean;
        equals(arg0: unknown): boolean;
        getItem(arg0: number): $ItemStack;
        hashCode(): number;
        item(): $ItemStack;
        size(): number;
        toString(): string;
    }

    export class $SmeltingRecipe extends $AbstractCookingRecipe {
        constructor(arg0: string, arg1: $CookingBookCategory_, arg2: $Ingredient_, arg3: $ItemStack_, arg4: number, arg5: number);
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        getRemainingItems(arg0: $SingleRecipeInput): $NonNullList<$ItemStack>;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export interface $SmithingRecipe extends $Recipe<$SmithingRecipeInput> {
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getToastSymbol(): $ItemStack;
        getType(): $RecipeType<any>;
        isAdditionIngredient(arg0: $ItemStack_): boolean;
        isBaseIngredient(arg0: $ItemStack_): boolean;
        isTemplateIngredient(arg0: $ItemStack_): boolean;
        showNotification(): boolean;
    }

    export class $SmithingRecipeInput extends $Record implements $RecipeInput {
        constructor(arg0: $ItemStack_, arg1: $ItemStack_, arg2: $ItemStack_);
        get empty(): boolean;
        isEmpty(): boolean;
        addition(): $ItemStack;
        base(): $ItemStack;
        equals(arg0: unknown): boolean;
        getItem(arg0: number): $ItemStack;
        hashCode(): number;
        size(): number;
        template(): $ItemStack;
        toString(): string;
    }

    export class $SmithingTransformRecipe implements $SmithingRecipe {
        constructor(arg0: $Ingredient_, arg1: $Ingredient_, arg2: $Ingredient_, arg3: $ItemStack_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        assemble(arg0: $SmithingRecipeInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $SmithingRecipeInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        isAdditionIngredient(arg0: $ItemStack_): boolean;
        isBaseIngredient(arg0: $ItemStack_): boolean;
        isTemplateIngredient(arg0: $ItemStack_): boolean;
        matches(arg0: $SmithingRecipeInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $SmithingTrimRecipe implements $SmithingRecipe {
        constructor(arg0: $Ingredient_, arg1: $Ingredient_, arg2: $Ingredient_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        assemble(arg0: $SmithingRecipeInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $SmithingRecipeInput): $NonNullList<$ItemStack>;
        getResultItem(arg0: $HolderLookup$Provider): $ItemStack;
        isAdditionIngredient(arg0: $ItemStack_): boolean;
        isBaseIngredient(arg0: $ItemStack_): boolean;
        isTemplateIngredient(arg0: $ItemStack_): boolean;
        matches(arg0: $SmithingRecipeInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $SmokingRecipe extends $AbstractCookingRecipe {
        constructor(arg0: string, arg1: $CookingBookCategory_, arg2: $Ingredient_, arg3: $ItemStack_, arg4: number, arg5: number);
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        getRemainingItems(arg0: $SingleRecipeInput): $NonNullList<$ItemStack>;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $StonecutterRecipe extends $SingleItemRecipe {
        constructor(arg0: string, arg1: $Ingredient_, arg2: $ItemStack_);
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        get special(): boolean;
        isSpecial(): boolean;
        getRemainingItems(arg0: $SingleRecipeInput): $NonNullList<$ItemStack>;
        matches(arg0: $SingleRecipeInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $SuspiciousStewRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export class $TippedArrowRecipe extends $CustomRecipe {
        constructor(arg0: $CraftingBookCategory_);
        get group(): string;
        getGroup(): string;
        get ingredients(): $NonNullList<$Ingredient>;
        getIngredients(): $NonNullList<$Ingredient>;
        get serializer(): $RecipeSerializer<any>;
        getSerializer(): $RecipeSerializer<any>;
        get toastSymbol(): $ItemStack;
        getToastSymbol(): $ItemStack;
        get type(): $RecipeType<any>;
        getType(): $RecipeType<any>;
        get incomplete(): boolean;
        isIncomplete(): boolean;
        assemble(arg0: $CraftingInput, arg1: $HolderLookup$Provider): $ItemStack;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        getRemainingItems(arg0: $CraftingInput): $NonNullList<$ItemStack>;
        matches(arg0: $CraftingInput, arg1: $Level): boolean;
        showNotification(): boolean;
        "showNotification()"(): boolean;
    }

    export type $CookingBookCategory_ = $CookingBookCategory | "BLOCKS" | "FOOD" | "MISC";
    export type $CraftingBookCategory_ = $CraftingBookCategory | "BUILDING" | "EQUIPMENT" | "MISC" | "REDSTONE";
    /** item:id | #tag | @mod | * | /regex/ | { item?|tag?|mod?|regex?|wildcard?|filter?|any?|all?|not? } */
    export type $Ingredient_ = $Ingredient | RegistryTypes.Item | `#${RegistryTypes.ItemTag}` | `@${RegistryTypes.Namespace}` | "*" | `/${string}` | $Ingredient_[] | $ItemStack | $Item | $NekoId | { item?: RegistryTypes.Item, tag?: RegistryTypes.ItemTag, mod?: RegistryTypes.Namespace, regex?: string, wildcard?: boolean, filter?: ((item: $ItemStack) => boolean), any?: $Ingredient_[], all?: $Ingredient_[], not?: $Ingredient_ };
    export type $Ingredient$Value_<CallbackResult = ($Collection<$ItemStack> | ($ItemStack_)[])> = (() => CallbackResult) | ($Ingredient$Value & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "getItems": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $RecipeManager$CachedCheck_<Host0 extends $RecipeInput = any, Host1 extends $Recipe<Host0> = any, CallbackArg0 = Host0, CallbackArg1 = $Level, CallbackResult = $Optional<$RecipeHolder<Host1>>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($RecipeManager$CachedCheck<Host0, Host1> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "getRecipeFor": (arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
