package com.tkisor.nekojs.core.error;

/** Temporary path-operation measurements in the owned diagnostic checkout only. */
@jdk.jfr.Name("neko.PathOperation6e")
@jdk.jfr.Label("Path operation diagnostic")
@jdk.jfr.StackTrace(true)
public final class PathOperationDiagnostic extends jdk.jfr.Event {
    public String operation;
    public String suffix;
    public boolean existing;
}
