"""Restore only the owned and digest-verified temporary diagnostic sources."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

tools = Path(__file__).resolve().parent
run = tools / '6e43b827-path-diagnostic'
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff').resolve()
binding = json.loads((run / 'binding.json').read_text(encoding='utf-8'))
assert json.loads((run / 'exit.json').read_text(encoding='utf-8'))['exitCode'] == 0
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == binding['revision']
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=tree, text=True).splitlines()
assert set(changed) == {row['path'] for row in binding['bindings']}
classes = {}
for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    base = tree / relative
    for path in base.rglob('*.class'):
        name = path.relative_to(base).as_posix()
        assert name not in classes
        classes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
jars = list((tree / 'versions/26.1.2/build/libs').glob('*.jar'))
assert len(jars) == 1 and len(classes) == 1643
artifact = jars[0]
shutil.copyfile(artifact, run / ('instrumented-' + artifact.name))
(run / 'instrumented-artifact.json').write_text(json.dumps(dict(sourceRevision=binding['revision'],
    diagnosticOnly=True, classBindings=classes, classCount=len(classes), artifact=artifact.name,
    sha256=hashlib.sha256(artifact.read_bytes()).hexdigest()), indent=2) + '\n', encoding='utf-8')
for row in binding['bindings']:
    target = (tree / row['path']).resolve()
    assert target.is_relative_to(tree)
    original = (run / row['saved']).read_bytes()
    assert hashlib.sha256(original).hexdigest() == row['originalSha256']
    assert hashlib.sha256(target.read_bytes()).hexdigest() == row['instrumentedSha256']
    target.write_bytes(original)
helper = (tree / binding['addedSource']).resolve()
assert helper.is_relative_to(tree) and helper.name == 'PathOperationDiagnostic.java'
assert hashlib.sha256(helper.read_bytes()).hexdigest() == binding['addedSha256']
helper.unlink()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
print(json.dumps(dict(sourceRestored=True, restoredSourceFiles=3, temporaryHelperRemoved=True,
                      instrumentedClasses=len(classes), buildRestoreRequired=True)))
