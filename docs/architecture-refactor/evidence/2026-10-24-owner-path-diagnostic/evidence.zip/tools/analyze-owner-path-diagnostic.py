"""Recalculate path call durations, preserving nested intervals and every observation."""
from collections import Counter, defaultdict
from datetime import datetime
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import statistics

root = Path(__file__).resolve().parent / '6e43b827-path-diagnostic'
events = json.loads((root / 'events.json').read_text(encoding='utf-8-sig'))['recording']['events']
observations = json.loads((root / 'session/observations.json').read_text(encoding='utf-8-sig'))
session = json.loads((root / 'session/session.json').read_text(encoding='utf-8-sig'))
assert not session['forcedKill'] and not session['extra']['killed'] and session['extra']['stopChannel'] == 'rcon'
assert len(observations) == 20 and len(events) == 440
def instant_ns(value):
    found = re.fullmatch(r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.(\d{1,9}))?(Z|[+-]\d\d:\d\d)', value)
    assert found, value
    seconds = int(datetime.fromisoformat(found[1] + found[3].replace('Z', '+00:00')).timestamp())
    return seconds * 1_000_000_000 + int((found[2] or '').ljust(9, '0'))
def duration_ns(value):
    found = re.fullmatch(r'PT([\d.]+)S', value)
    assert found, value
    return int(Decimal(found[1]) * 1_000_000_000)
def caller(value):
    own = {'com/tkisor/nekojs/core/fs/NekoJSPaths', 'com/tkisor/nekojs/core/module/NekoCanonicalPath',
           'com/tkisor/nekojs/core/fs/NekoModuleReadService'}
    for frame in (value.get('stackTrace') or {}).get('frames', []):
        method = frame['method']
        if method['type']['name'] not in own:
            return method['type']['name'].replace('/', '.') + '.' + method['name']
    return 'UNAVAILABLE_OR_TRUNCATED'
rows = []
seen = set()
caller_stats = defaultdict(lambda: dict(calls=0, nanos=0))
exists_stats = defaultdict(lambda: dict(calls=0, nanos=0))
for observation in [row for row in observations if row['command'] == 'nekojs reload']:
    assert 'phase=COMMIT - no errors.' in observation['response'] and observation['markerMs'] is not None
    start, end = instant_ns(observation['startedUtc']), instant_ns(observation['returnedUtc'])
    counts, nanos, intervals = Counter(), Counter(), []
    for index, event in enumerate(events):
        value = event['values']
        entered = instant_ns(value['startTime'])
        if not start <= entered <= end:
            continue
        assert index not in seen and event['type'] == 'neko.PathOperation6e'
        assert value['eventThread']['javaName'] == 'Server thread'
        seen.add(index)
        elapsed = duration_ns(value['duration'])
        operation = value['operation']
        counts[operation] += 1
        nanos[operation] += elapsed
        intervals.append((entered, entered + elapsed))
        stats = caller_stats[(operation, caller(value))]
        stats['calls'] += 1
        stats['nanos'] += elapsed
        if operation == 'legacy-original-exists':
            stats = exists_stats[(value['suffix'], value['existing'])]
            stats['calls'] += 1
            stats['nanos'] += elapsed
    assert sum(counts.values()) == 44
    merged = []
    for entered, exited in sorted(intervals):
        if merged and entered <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], exited)
        else:
            merged.append([entered, exited])
    rows.append(dict(pair=observation['pair'], markerMs=observation['markerMs'], calls=dict(counts),
        inclusiveMs={name: value / 1e6 for name, value in sorted(nanos.items())},
        measuredIntervalUnionMs=sum(end - start for start, end in merged) / 1e6))
assert len(rows) == 10 and len(seen) == len(events)
operations = sorted({event['values']['operation'] for event in events})
result = dict(sourceRevision=json.loads((root / 'binding.json').read_text(encoding='utf-8'))['revision'],
    diagnosticOnly=True, successfulReloads=10, controlQueries=10, normalStops=1, eventCount=len(events), rows=rows,
    operationCalls={name: sum(row['calls'].get(name, 0) for row in rows) for name in operations},
    inclusiveMeanMs={name: statistics.mean(row['inclusiveMs'].get(name, 0) for row in rows) for name in operations},
    measuredIntervalUnionMeanMs=statistics.mean(row['measuredIntervalUnionMs'] for row in rows),
    callers=[dict(operation=operation, caller=who, **value) for (operation, who), value in sorted(caller_stats.items())],
    existsProbes=[dict(suffix=suffix, existing=existing, **value) for (suffix, existing), value in sorted(exists_stats.items())],
    rawEventsSha256=hashlib.sha256((root / 'events.json').read_bytes()).hexdigest(),
    limits=['Instrumented boundaries and JFR stack capture may change cost; no formal policy replacement or causal savings.',
        'Operation totals are inclusive and nested; the separately computed interval union avoids double-counting.',
        'Only the four named boundaries are measured; other resolver and IO costs are not excluded.',
        'The exists outcome is meaningful only for legacy-original-exists; default boolean fields on other events are not observations.'])
(root / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result.items() if key not in ['rows', 'callers', 'limits']}))
