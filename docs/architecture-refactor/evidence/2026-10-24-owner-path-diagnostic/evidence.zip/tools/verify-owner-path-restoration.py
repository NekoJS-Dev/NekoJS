"""Compare every restored production class and the whole JAR with the formal candidate."""
import hashlib
import json
from pathlib import Path
import subprocess

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
root = tools / '6e43b827-path-diagnostic'
expected = json.loads((tools / 'final-6e43b827-formal/preparation.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == expected['revision']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
classes = {}
for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    base = tree / relative
    for path in base.rglob('*.class'):
        name = path.relative_to(base).as_posix()
        assert name not in classes
        classes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
assert classes == expected['classBindings']
artifact = Path(expected['artifact'])
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == expected['artifactSha256']
assert b'BUILD SUCCESSFUL' in (root / 'restore-build.log').read_bytes()
result = dict(revision=expected['revision'], sourceClean=True, classesMatch=True, jarMatches=True,
    classes=len(classes), artifactSha256=expected['artifactSha256'], classBindings=classes)
(root / 'restoration.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'classBindings'}))
