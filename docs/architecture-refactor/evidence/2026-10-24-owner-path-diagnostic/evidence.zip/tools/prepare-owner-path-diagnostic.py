"""Measure path operations without changing their checks or returned values."""
import hashlib
import json
from pathlib import Path
import subprocess

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = tools / '6e43b827-path-diagnostic'
revision = '6e43b82789a7dbf7b9659dc1c21fefecac662649'
helper_relative = 'common/src/main/java/com/tkisor/nekojs/core/error/PathOperationDiagnostic.java'
assert not out.exists() and not (tree / helper_relative).exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
out.mkdir()
bindings = []

def wrap(source, signature, operation):
    assert source.count(signature) == 1, signature
    start = source.index(signature)
    opening = source.index('{', start)
    # The selected bodies have balanced ordinary braces and no braces inside string literals.
    depth = 1
    end = opening + 1
    while depth:
        if source[end] == '{':
            depth += 1
        elif source[end] == '}':
            depth -= 1
        end += 1
    body = source[opening + 1:end - 1]
    changed = '''
        var profile = new com.tkisor.nekojs.core.error.PathOperationDiagnostic();
        profile.operation = "OPERATION";
        profile.begin();
        try {BODY
        } finally {
            profile.end();
            profile.commit();
        }
    '''.replace('OPERATION', operation).replace('BODY', body)
    return source[:opening + 1] + changed + source[end - 1:]

for relative, methods in [
    ('common/src/main/java/com/tkisor/nekojs/core/module/NekoCanonicalPath.java',
     [('static Path pathOf(Path path)', 'module-canonical-key')]),
    ('common/src/main/java/com/tkisor/nekojs/core/fs/NekoJSPaths.java',
     [('private static Path canonicalSplicedForm(Path path)', 'fs-canonical-spliced'),
      ('private Path verifyInsideRoot(Path path, Path rt)', 'fs-verify-root')]),
    ('common/src/main/java/com/tkisor/nekojs/core/fs/NekoModuleReadService.java', []),
]:
    target = tree / relative
    original = target.read_bytes()
    saved = target.name + '.original'
    (out / saved).write_bytes(original)
    source = original.decode('utf-8').replace('\r\n', '\n')
    for signature, operation in methods:
        source = wrap(source, signature, operation)
    if target.name == 'NekoModuleReadService.java':
        before = '        if (Files.exists(originalPath)) {\n            return originalPath;\n        }'
        after = '''        var profile = new com.tkisor.nekojs.core.error.PathOperationDiagnostic();
        profile.operation = "legacy-original-exists";
        profile.begin();
        boolean existing = Files.exists(originalPath);
        profile.end();
        profile.existing = existing;
        profile.suffix = originalPath.getFileName() == null ? "root"
                : originalPath.getFileName().toString().endsWith(".js") ? "js" : "other";
        profile.commit();
        if (existing) {
            return originalPath;
        }'''
        assert source.count(before) == 1
        source = source.replace(before, after)
    target.write_text(source, encoding='utf-8', newline='\n')
    bindings.append(dict(path=relative, saved=saved, originalSha256=hashlib.sha256(original).hexdigest(),
                         instrumentedSha256=hashlib.sha256(target.read_bytes()).hexdigest()))
helper = '''package com.tkisor.nekojs.core.error;

/** Temporary path-operation measurements in the owned diagnostic checkout only. */
@jdk.jfr.Name("neko.PathOperation6e")
@jdk.jfr.Label("Path operation diagnostic")
@jdk.jfr.StackTrace(true)
public final class PathOperationDiagnostic extends jdk.jfr.Event {
    public String operation;
    public String suffix;
    public boolean existing;
}
'''
(tree / helper_relative).write_text(helper, encoding='utf-8', newline='\n')
(out / 'PathOperationDiagnostic.java').write_text(helper, encoding='utf-8', newline='\n')
(out / 'binding.json').write_text(json.dumps(dict(revision=revision, diagnosticOnly=True,
    bindings=bindings, addedSource=helper_relative, addedSha256=hashlib.sha256((tree / helper_relative).read_bytes()).hexdigest()), indent=2) + '\n', encoding='utf-8')
(out / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *[row['path'] for row in bindings]], cwd=tree))
controller = (tools / '6e43b827-source-diagnostic/diagnostic.ps1').read_text(encoding='utf-8')
assert controller.count('6e43b827-source-diagnostic/session') == 1
controller = controller.replace('6e43b827-source-diagnostic/session', '6e43b827-path-diagnostic/session')
assert controller.count(').Count -ne 1)') == 1
controller = controller.replace(').Count -ne 1)', ').Count -ne 3)')
(out / 'diagnostic.ps1').write_text(controller, encoding='utf-8', newline='\n')
(out / 'run.py').write_bytes((tools / '6e43b827-source-diagnostic/run.py').read_bytes())
print(json.dumps(dict(prepared=True, revision=revision, modifiedSourceFiles=3, temporaryHelperFiles=1, diagnosticOnly=True)))
