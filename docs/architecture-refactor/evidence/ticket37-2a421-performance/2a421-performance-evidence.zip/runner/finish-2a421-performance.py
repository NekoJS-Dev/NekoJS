import json
import os
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
repair = root/'build/ticket37-config-sync-repair'
records = json.loads((repair/'2a421-performance-groups-exits.json').read_text(encoding='utf-8'))
assert len(records) == 3 and all(record['samplerExit'] == 0 for record in records)
# The parent observed exec session 83221 complete with exit_code=0 before invoking this recorder.
(repair/'2a421-performance-runner-exit.json').write_text(json.dumps(dict(exitCode=0,
    observation='Tool exec session 83221 direct completed exit_code=0; all three subprocess exit records also retained'), indent=2)+'\n', encoding='utf-8')
child_env = dict(os.environ)
child_env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
with (root/'build/ticket37-perf-2a421c18/final-owned-guard.txt').open('xb') as output:
    result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(repair/'guard-2a421-performance.ps1')], stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW, env=child_env)
(root/'build/ticket37-perf-2a421c18/final-owned-guard-exit.json').write_text(json.dumps(dict(exitCode=result.returncode), indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(directOuterExit=0, directSamplerExits=[record['samplerExit'] for record in records], finalGuardExit=result.returncode)))
raise SystemExit(result.returncode)
