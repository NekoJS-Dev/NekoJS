import json
import os
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
repair = root/'build/ticket37-config-sync-repair'
revision = '2a421c18bd36dc59d0006db8e68d515f0122ce8e'
contents = (repair/'prepare-cb5-performance.ps1').read_text(encoding='utf-8-sig')
contents = contents.replace('cb5f7fe6a81d1415acff69c5e91ac430457385d5', revision).replace('ticket37-perf-cb5f7fe6', 'ticket37-perf-2a421c18')
path = repair/'prepare-2a421-performance.ps1'
assert not path.exists()
path.write_text(contents, encoding='utf-8-sig')
guard = (repair/'guard-cb5-performance.ps1').read_text(encoding='utf-8-sig')
guard = guard.replace('cb5f7fe6a81d1415acff69c5e91ac430457385d5', revision).replace('ticket37-perf-cb5f7fe6', 'ticket37-perf-2a421c18')
(repair/'guard-2a421-performance.ps1').write_text(guard, encoding='utf-8-sig')
child_env = dict(os.environ)
child_env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(path)],
    env=child_env, creationflags=subprocess.CREATE_NO_WINDOW)
(repair/'2a421-performance-preparation-exit.json').write_text(json.dumps(dict(exitCode=result.returncode, sourceRevision=revision), indent=2)+'\n', encoding='utf-8')
raise SystemExit(result.returncode)
