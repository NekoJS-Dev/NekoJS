from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.consumer import Color, Color_, _NekoInput_Color_
from nekojs._events.server import ColorEventsType
def handler(event: Color) -> None:
    print(event.ordinal())
def valid(value: Color_) -> _NekoInput_Color_:
    print(value.localColorOnly())
    ColorEventsType.pick("RED", handler)
    return "RED"
