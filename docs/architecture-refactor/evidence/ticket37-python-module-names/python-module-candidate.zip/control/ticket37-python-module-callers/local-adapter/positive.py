from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.first import Record, Record_, _NekoInput_Record_
from nekojs._events.server import LocalEventsType
def handler(event: Record) -> None:
    print(event.firstOnly())
def valid(value: Record_) -> _NekoInput_Record_:
    print(value.aliasNameClassOnly())
    LocalEventsType.pick("value", handler)
    return "value"
