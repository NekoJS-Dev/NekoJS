from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.first import Record_
def invalid(value: Record_) -> int:
    return value.firstOnly()
