from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.first import Record, Record_
from nekojs._events.server import LocalEventsType
def handler(event: Record) -> None:
    print(event.firstOnly())
def valid(value: Record_) -> Record | str:
    print(value.aliasNameClassOnly())
    LocalEventsType.pick("value", handler)
    return "value"
