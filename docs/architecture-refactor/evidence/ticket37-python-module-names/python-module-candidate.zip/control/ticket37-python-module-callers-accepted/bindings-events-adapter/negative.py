from nekojs import First, SecondEvents
def invalid() -> None:
    print(First.secondOnly())
    SecondEvents.tick(lambda event: print(event.firstOnly()))
