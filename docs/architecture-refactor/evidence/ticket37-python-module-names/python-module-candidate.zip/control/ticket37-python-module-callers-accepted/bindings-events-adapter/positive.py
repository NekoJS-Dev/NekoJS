from nekojs import First, Second, FirstEvents, SecondEvents
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.first import Record as FirstType, Record_ as Input
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.second import Record as SecondType
def first_handler(event: FirstType) -> None:
    print(event.firstOnly())
def second_handler(event: SecondType) -> None:
    print(event.secondOnly())
def valid() -> Input:
    print(First.firstOnly(), Second.secondOnly())
    FirstEvents.tick(first_handler)
    SecondEvents.tick(second_handler)
    return Second
