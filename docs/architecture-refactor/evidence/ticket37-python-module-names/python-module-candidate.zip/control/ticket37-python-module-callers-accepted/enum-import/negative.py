from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.consumer import Record
def invalid(value: Record) -> int:
    return value.foreignColor().localColorOnly()
