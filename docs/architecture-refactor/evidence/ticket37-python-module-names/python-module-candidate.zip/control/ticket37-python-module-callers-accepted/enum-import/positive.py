from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.consumer import Record, Color_ as ColorInput
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.second import Color_ as Foreign
def valid(value: Record) -> tuple[Foreign, ColorInput]:
    print(value.foreignColor().foreignOnly())
    return value.foreignColor(), "RED"
