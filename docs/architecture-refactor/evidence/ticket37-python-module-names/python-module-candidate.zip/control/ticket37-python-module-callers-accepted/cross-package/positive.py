from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.consumer import Record as Consumer
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.first import Record as First
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.second import Record as Second
def valid(value: Consumer) -> tuple[First, Second, str, int]:
    return value.firstValue(), value.secondValue(), value.firstValue().firstOnly(), value.secondValue().secondOnly()
