from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.consumer import Record as Consumer
def invalid(value: Consumer) -> int:
    return value.firstValue().secondOnly()
