from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.consumer import Color_
def invalid(value: Color_) -> int:
    return value.ordinal()
