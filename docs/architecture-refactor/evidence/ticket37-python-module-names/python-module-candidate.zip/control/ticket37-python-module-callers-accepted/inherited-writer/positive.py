from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.writer import Child
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.second import Record as Writer
def valid(value: Child, incoming: Writer) -> str:
    value.payload = incoming
    return value.payload.firstOnly()
