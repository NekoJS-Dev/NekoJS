from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.writer import Child
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.first import Record as Reader
def invalid(value: Child, incoming: Reader) -> int:
    value.payload = incoming
    return value.payload.secondOnly()
