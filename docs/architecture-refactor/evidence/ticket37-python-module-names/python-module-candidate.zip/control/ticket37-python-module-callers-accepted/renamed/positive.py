from nekojs import Record
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.first import Renamed
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.consumer import Record as Consumer
from nekojs._java.com.tkisor.nekojs.probe.backend.python.fixture.names.second import Record_ as Input
def valid(value: Consumer) -> tuple[Renamed, Input]:
    print(Record.firstOnly())
    return value.firstValue(), Record
