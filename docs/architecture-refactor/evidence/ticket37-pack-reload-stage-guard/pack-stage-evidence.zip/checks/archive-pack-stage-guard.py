import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root=Path.cwd().resolve()
helpers=root/'build/ticket37-config-sync-repair'
repair=root/'build/ticket37-sam-module-import-repair'
out=root/'docs/architecture-refactor/evidence/ticket37-pack-reload-stage-guard'
out.mkdir()
files={}
for name in ['sam-module-import-matrix-green.txt','sam-module-import-matrix-green-exit.json',
             'pack-reload-failure-focused.txt','pack-reload-failure-focused-exit.json',
             'pack-reload-class-check.txt','pack-reload-class-check-exit.json',
             'sam-module-import-matrix-final.txt','sam-module-import-matrix-final-exit.json',
             'archive-pack-stage-guard.py']:
    files['checks/'+name]=(helpers/name).read_bytes()
files['failed/PackSyncClientTest.xml']=(repair/'matrix-failed/PackSyncClientTest.xml').read_bytes()
name='common/src/test/java/com/tkisor/nekojs/core/pack/sync/PackSyncClientTest.java'
files['source/'+name]=(root/name).read_bytes()
files['source/test.patch']=subprocess.check_output(['git','diff','--',name])
files['final-matrix/PackSyncClientTest.xml']=(repair/'matrix-xml/common/build/test-results/test/TEST-com.tkisor.nekojs.core.pack.sync.PackSyncClientTest.xml').read_bytes()
original=ET.fromstring(files['failed/PackSyncClientTest.xml'])
final=ET.fromstring(files['final-matrix/PackSyncClientTest.xml'])
assert original.get('failures')=='1' and final.get('failures')=='0'
assert 'LOCAL_TRUSTED' in original.find('testcase/failure').get('message')
for name,expected in [('sam-module-import-matrix-green',1),('pack-reload-failure-focused',0),('pack-reload-class-check',0),('sam-module-import-matrix-final',0)]:
    assert json.loads(files['checks/'+name+'-exit.json'].decode('utf-8-sig'))['exitCode']==expected
sha=lambda data:hashlib.sha256(data).hexdigest()
archive=out/'pack-stage-evidence.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as zip:
    for name,data in sorted(files.items()): zip.writestr(name,data)
summary=dict(sourceBase='da6bad60385d8685b34e58af02c92d3da8d293b5',
    initialFullMatrix='FAIL',focusedMethod='PASS',focusedClass='PASS',finalFullMatrix='PASS',
    failureRootCause='NOT_ESTABLISHED',productionTrustChange='NONE',testGuard='STRICTER_REJECTION_STAGE',
    archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),
    entries=[dict(name=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(files.items())])
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary['archive']))
