import hashlib
import importlib.util
import json
import os
import re
import shutil
import socket
import subprocess
import time
from pathlib import Path

p = Path.cwd()
root = p / 'build/priority-closeout/dynamic-commit-b47734c6-262-v1'
assert not (root / 'run-result.json').exists()
spec = importlib.util.spec_from_file_location('owned_rcon', p / 'bench/perf/rcon.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
props = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines()
             if '=' in line and not line.startswith('#'))
descriptor = json.loads((root / 'launch-descriptor.json').read_text())
helper = next((root / 'build/libs').glob('*.jar'))
shutil.copyfile(helper, root / 'server/mods' / helper.name)

processes = []
result = dict(sourceRevision='b47734c6721ee8434df48c0b2a86b887d577f02e', stages=[], errors=[], forced=[], exits={},
              helperSha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
              environmentKeys=list(descriptor['environment']), launchModFoldersPresent=any(
                  value.startswith('-Dfml.modFolders=') for value in descriptor['jvmArgs']))
server_ready = False


def log(name):
    file = root / (name + '-stdout.log')
    return file.read_text(encoding='utf8', errors='replace') if file.exists() else ''


def snapshot(side):
    try:
        value = json.loads((root / side / ('server-observation.json' if side == 'server' else 'client-observation.json')).read_text())
        assert value['sameThread']
        return value
    except (FileNotFoundError, json.JSONDecodeError, PermissionError):
        return None


def wait(predicate, seconds, label):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        value = predicate()
        if value:
            return value
        for name, process, side in processes:
            if name not in result['exits'] and process.poll() is not None:
                raise RuntimeError(f'{name} exited during {label}: {process.returncode}')
        time.sleep(0.2)
    raise TimeoutError(label)


def command(text):
    with socket.create_connection(('127.0.0.1', int(props['rcon.port'])), timeout=15) as connection:
        connection.settimeout(60)
        rcon.send_packet(connection, 1, 3, props['rcon.password'])
        auth = rcon.recv_packet(connection)
        assert auth is not None and auth[0] != -1
        rcon.send_packet(connection, 10, 2, text)
        response = rcon.recv_packet(connection)
        assert response is not None
    with (root / 'commands.jsonl').open('a', encoding='utf8') as output:
        output.write(json.dumps(dict(command=text, response=response[2])) + '\n')
    return response[2]


def start(name, args, side, environment=None):
    with (root / (name + '-stdout.log')).open('xb') as out, (root / (name + '-stderr.log')).open('xb') as err:
        process = subprocess.Popen(args, cwd=root / side, stdout=out, stderr=err, env=environment,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
    processes.append((name, process, side))
    (root / (name + '-owned-process.json')).write_text(json.dumps(dict(pid=process.pid, owner=root.name, side=side,
        executable=args[0]), indent=2) + '\n')
    return process


def start_client(side, name):
    folder = root / side
    (folder / 'action.txt').write_text('idle')
    program = root / 'build/moddev/clientRunProgramArgs.txt'
    copied = root / (name + '-program-arguments.txt')
    copied.write_text(program.read_text().replace('OwnedTcpA', 'OwnedTcpA' if side == 'clientA' else 'OwnedTcpB'))
    args = [value.replace(str(root / 'clientA'), str(folder)).replace('dynamic-commit-b47734c6-262-v1-clientA', root.name + '-' + side)
            for value in descriptor['jvmArgs']]
    # The VM argfile also contains the installed-JAR property; use a side-specific copy.
    prepared = []
    for arg in args:
        if arg.startswith('@'):
            original = Path(arg[1:])
            target = root / (name + '-vm-arguments.txt')
            target.write_text(original.read_text().replace('clientA', side))
            prepared.append('@' + str(target))
        else:
            prepared.append(arg)
    arguments = [('@' + str(copied)) if value.startswith('@') and Path(value[1:]).samefile(program) else value
                 for value in descriptor['args']]
    environment = dict(os.environ, **descriptor['environment'])
    return start(name, [descriptor['java'], *prepared, '-cp', os.pathsep.join(descriptor['classpath']),
                       descriptor['mainClass'], *arguments], side, environment)


def signal(side, action):
    (root / side / 'action.txt').write_text(action)


def note(name):
    data = dict(stage=name, server=snapshot('server'), clientA=snapshot('clientA'), clientB=snapshot('clientB'))
    (root / (name + '.json')).write_text(json.dumps(data, indent=2) + '\n')
    result['stages'].append(name)
    print('TCP_STAGE_PASS', name, flush=True)
    return data


def item_present(side, path):
    value = snapshot(side)
    return value is not None and value['items'][path]['present']


def reload_items(names):
    previous = snapshot('server')['ledgerGeneration']
    script = "DynamicRegistryEvents.dynamicRegistry(event => {\n" + ''.join(
        "  event.item('nekojs_acceptance:" + name + "', build => { build.maxStackSize = 16; build.rarity = 'rare'; });\n"
        for name in names) + "});\n"
    (root / 'server/nekojs/server_scripts/owned-dynamic-items.js').write_text(script)
    command('nekojs reload server')
    wait(lambda: snapshot('server') and snapshot('server')['ledgerGeneration'] > previous, 90, 'ledger publication')
    generation = snapshot('server')['ledgerGeneration']
    return generation


def terminal(generation, committed):
    def completed():
        value = snapshot('server')
        summary = value.get('lastSummary') if value else None
        return value if summary and summary['generation'] == generation and summary['committed'] == committed else None
    return wait(completed, 60, 'transaction terminal ' + str(generation))


def outcomes(generation, outcome):
    return [value for value in snapshot('server').get('syncOutcomes', [])
            if value['generation'] == generation and value['outcome'] == outcome]


def stop_client(name, process, side):
    signal(side, 'close')
    code = process.wait(timeout=90)
    result['exits'][name] = code
    assert code == 0, (name, code)


try:
    java = 'C:/Program Files/Java/jdk-25.0.2/bin/java.exe'
    prep = json.loads((root / 'preparation.json').read_text())
    jar_name = prep['jar']['name']
    server = start('server', [java, '-Xms512M', '-Xmx2G',
        '-Dnekojs.acceptance.owner=' + root.name + '-server',
        '-Dnekojs.acceptance.jar=' + str(root / 'server/mods' / jar_name),
        '@libraries/net/neoforged/neoforge/' + prep['serverLoader'] + '/win_args.txt', 'nogui'], 'server')
    wait(lambda: 'Done (' in log('server') and snapshot('server'), 300, 'server startup')
    server_ready = True
    assert 'OWNED-TCP-INSTALLED-SOURCE-PASS' in log('server')
    assert snapshot('server')['ledgerEmpty'] and snapshot('server')['ackTimeoutMillis'] == 10000
    assert not any(value['present'] for value in snapshot('server')['items'].values())
    a = start_client('clientA', 'clientA')
    wait(lambda: snapshot('clientA') and snapshot('clientA')['connected'], 300, 'client A join')
    b = start_client('clientB', 'clientB')
    wait(lambda: snapshot('clientB') and snapshot('clientB')['connected'], 300, 'client B join')
    assert snapshot('clientA')['gateEnabled'] and snapshot('clientB')['gateEnabled']
    assert 'OWNED-TCP-COMMIT-FAULT owner=' not in log('clientA')
    note('01-empty-two-enabled-clients')
    generation = reload_items(['tcp_seed'])
    terminal(generation, True)
    wait(lambda: all(item_present(side, 'tcp_seed') for side in ['server', 'clientA', 'clientB']), 30, 'normal physical activation')
    wait(lambda: len({value['participantId'] for value in outcomes(generation, 'activation-report')}) == 2, 30, 'normal dual reports')
    note('02-normal-dual-commit')
    generation = reload_items(['tcp_seed', 'tcp_commit_fail'])
    terminal(generation, True)
    wait(lambda: outcomes(generation, 'activation-failed-post-commit'), 30, 'real failed activation report')
    wait(lambda: item_present('server', 'tcp_commit_fail') and item_present('clientB', 'tcp_commit_fail'), 30, 'server and B physical activation')
    players = {value['name']: value['id'] for value in snapshot('server')['players']}
    assert {value['participantId'] for value in outcomes(generation, 'ack')} == set(players.values())
    failed = outcomes(generation, 'activation-failed-post-commit')
    assert len(failed) == 1 and failed[0]['participantId'] == players['OwnedTcpA']
    assert 'OWNED-TCP-COMMIT-FAULT' in failed[0]['reason']
    assert not item_present('clientA', 'tcp_commit_fail') and item_present('clientA', 'tcp_seed')
    assert snapshot('server')['status'] == 'COMMITTED' and snapshot('server')['activatedGeneration'] == generation
    assert any(value['generation'] == generation and value['phase'] == 'COMMIT' and value['passed'] for value in snapshot('server')['phaseLog'])
    note('03-real-commit-activation-failure')
    wait(lambda: outcomes(generation, 'state-sync-rejected'), 30, 'post-commit catch-up rejection')
    assert all(value['participantId'] == players['OwnedTcpA'] for value in outcomes(generation, 'state-sync-rejected'))
    assert log('clientA').count('OWNED-TCP-COMMIT-FAULT owner=') == 2
    assert 'thread=Render thread' in log('clientA')
    assert 'OWNED-TCP-COMMIT-FAULT owner=' not in log('clientB') + log('server')
    assert snapshot('clientA')['connected'] and snapshot('clientB')['connected']
    assert item_present('clientA', 'tcp_seed') and not item_present('clientA', 'tcp_commit_fail')
    note('04-failed-catch-up-retains-prior-client-state')
    rejected_before = len(outcomes(generation, 'state-sync-rejected'))
    command('kick OwnedTcpA Owned COMMIT failure reconnect acceptance')
    wait(lambda: not snapshot('clientA')['connected'] and len(snapshot('server')['players']) == 1, 30, 'A kicked')
    signal('clientA', 'connect:127.0.0.1:' + str(prep['port']))
    wait(lambda: len(outcomes(generation, 'state-sync-rejected')) > rejected_before, 90, 'configuration catch-up rejection')
    wait(lambda: not snapshot('clientA')['connected'] and 'DisconnectedScreen' in (snapshot('clientA').get('screen') or ''), 30, 'rejected A remains outside play')
    assert len(snapshot('server')['players']) == 1 and snapshot('clientB')['connected']
    assert not item_present('clientA', 'tcp_commit_fail') and snapshot('server')['activatedGeneration'] == generation
    assert log('clientA').count('OWNED-TCP-COMMIT-FAULT owner=') == 3
    assert outcomes(generation, 'state-sync-sent')
    note('05-reconnect-rejected-before-play')
    signal('clientA', 'fault:off')
    wait(lambda: snapshot('clientA') and not snapshot('clientA')['faultEnabled'], 30, 'fixture fault disabled')
    signal('clientA', 'connect:127.0.0.1:' + str(prep['port']))
    wait(lambda: snapshot('clientA')['connected'] and len(snapshot('server')['players']) == 2, 90, 'A recovery reconnect')
    wait(lambda: item_present('clientA', 'tcp_commit_fail') and outcomes(generation, 'state-sync-completed'), 30, 'successful physical catch-up')
    assert snapshot('server')['activatedGeneration'] == generation
    assert log('clientA').count('OWNED-TCP-COMMIT-FAULT owner=') == 3
    note('06-same-client-recovery-after-fault-removed')
    generation = reload_items(['tcp_seed', 'tcp_commit_fail', 'tcp_followup'])
    terminal(generation, True)
    wait(lambda: all(item_present(side, 'tcp_followup') for side in ['server', 'clientA', 'clientB']), 30, 'follow-up physical activation')
    wait(lambda: len({value['participantId'] for value in outcomes(generation, 'activation-report')}) == 2, 30, 'follow-up dual activation reports')
    assert {value['participantId'] for value in outcomes(generation, 'ack')} == set(players.values())
    assert not outcomes(generation, 'activation-failed-post-commit')
    for side in ['server', 'clientA', 'clientB']:
        for path in ['tcp_seed', 'tcp_commit_fail', 'tcp_followup']:
            assert snapshot(side)['items'][path] == dict(present=True, maxStackSize=16, rarity='RARE')
    note('07-subsequent-dual-commit-after-recovery')
except Exception as error:
    result['errors'].append(repr(error))
    print('TCP_FAILURE', repr(error), flush=True)
finally:
    for name, process, side in reversed(processes):
        if side != 'server' and name not in result['exits']:
            try:
                if process.poll() is None:
                    stop_client(name, process, side)
                else:
                    result['exits'][name] = process.returncode
                    result['errors'].append(name + ' exited before normal stop')
            except Exception as error:
                result['errors'].append(name + ' shutdown: ' + repr(error))
                process.terminate()
                process.wait(timeout=30)
                result['forced'].append(name)
                result['exits'][name] = process.returncode
    if server_ready:
        try:
            command('stop')
        except Exception as error:
            result['errors'].append('server stop: ' + repr(error))
    for name, process, side in processes:
        if side == 'server':
            try:
                process.wait(timeout=90)
            except subprocess.TimeoutExpired:
                process.terminate()
                process.wait(timeout=30)
                result['forced'].append(name)
            result['exits'][name] = process.returncode
    result['verdict'] = 'PASS' if len(result['stages']) == 7 and not result['errors'] and not result['forced'] and all(
        code == 0 for code in result['exits'].values()) else 'NOT GREEN'
    (root / 'run-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
