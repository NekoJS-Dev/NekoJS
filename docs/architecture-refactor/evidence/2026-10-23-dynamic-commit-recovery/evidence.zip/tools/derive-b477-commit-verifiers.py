"""Bind recovery verification to the new candidate and the same independent behavior checks."""
from pathlib import Path

tools = Path.cwd() / 'build/priority-closeout'
old = '1f877b0fa7435be6fea61a44ff2e9266ce2c3c2a'
revision = 'b47734c6721ee8434df48c0b2a86b887d577f02e'
for source, target in [('verify-dynamic-commit.py', 'verify-b477-dynamic-commit.py'),
                       ('bind-dynamic-commit-candidate.py', 'bind-b477-dynamic-commit.py')]:
    text = (tools / source).read_text(encoding='utf8').replace(old, revision)
    text = text.replace('dynamic-commit-1f877b0f-', 'dynamic-commit-b47734c6-')
    text = text.replace("('261', 'v3',", "('261', 'v1',").replace("('262', 'v2',", "('262', 'v1',")
    text = text.replace("len(proof['classes']) == 4", "len(proof['classes']) == 5")
    text = text.replace('dynamic-commit-summary.json', 'dynamic-commit-b477-summary.json')
    text = text.replace('productionChanges=False, maintainerAcceptance=False',
        "fixtureMutatesProduction=False, productionFix='b47734c6 intrusive holder cleanup', maintainerAcceptance=False")
    if source.startswith('bind-'):
        start = text.index('with zipfile.ZipFile(repo /')
        end = text.index("assert frozen['productionRevision']", start)
        text = text[:start] + "frozen = json.loads((tools / 'b47734c6-modern-build-summary.json').read_text())\n" + text[end:]
    (tools / target).write_text(text, encoding='utf8')
print('Derived strict seven-stage recovery verifier and source/artifact binder for b47734c6.')
