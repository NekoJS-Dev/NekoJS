"""Derive new isolated runs for the committed holder fix, retaining the same physical fault."""
from pathlib import Path

tools = Path.cwd() / 'build/priority-closeout'
old = '1f877b0fa7435be6fea61a44ff2e9266ce2c3c2a'
revision = 'b47734c6721ee8434df48c0b2a86b887d577f02e'
text = (tools / 'prepare-dynamic-commit-failure.py').read_text(encoding='utf8')
text = text.replace(old, revision).replace('dynamic-commit-1f877b0f-', 'dynamic-commit-b47734c6-')
text = text.replace('import socket\n', 'import socket\nimport subprocess\nimport zipfile\n')
text = text.replace('assert not root.exists()', '''assert not root.exists()
assert not subprocess.check_output(['git', 'diff', '--name-only', 'b47734c6', '--',
    'common/src/main', 'src/main', 'versions', 'buildSrc'], text=True).strip()
candidate = next((repo / 'versions' / node / 'build/libs').glob('*.jar'))
entry = 'com/tkisor/nekojs/dynamic/RegistrySurgery.class'
with zipfile.ZipFile(candidate) as archive:
    assert archive.read(entry) == (repo / 'versions' / node / 'build/classes/java/main' / entry).read_bytes()
''')
text = text.replace('"com.tkisor.nekojs.probe.backend.typescript.EventDeclarationGenerator"}',
    '"com.tkisor.nekojs.probe.backend.typescript.EventDeclarationGenerator", "com.tkisor.nekojs.dynamic.RegistrySurgery"}')
(tools / 'prepare-b477-dynamic-commit.py').write_text(text, encoding='utf8')
text = (tools / 'derive-dynamic-commit-runner.py').read_text(encoding='utf8')
text = text.replace(old, revision).replace('dynamic-commit-1f877b0f-', 'dynamic-commit-b47734c6-')
text = text.replace("attempt = 'v3' if short == '261' else 'v2'", "attempt = 'v1'")
text = text.replace("f'run-dynamic-commit-{short}.py'", "f'run-dynamic-commit-b477-{short}.py'")
(tools / 'derive-b477-commit-runner.py').write_text(text, encoding='utf8')
print('Derived current-source preparation and the same seven-stage physical-fault driver.')
