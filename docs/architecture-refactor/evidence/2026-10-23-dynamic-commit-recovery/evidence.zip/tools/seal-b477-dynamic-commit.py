"""Freeze both real recovery runs without exporting launch arguments or credentials."""
import hashlib
import json
import zipfile
from pathlib import Path

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
dest = repo / 'docs/architecture-refactor/evidence/2026-10-23-dynamic-commit-recovery'
assert not dest.exists()
summary = json.loads((tools / 'dynamic-commit-b477-summary.json').read_text())
assert len(summary['nodes']) == 2 and all(n['verdict'] == 'PASS' for n in summary['nodes'])
entries, redactions = {}, {}

def add(name, path, secrets=()):
    original = path.read_bytes()
    data = original
    for secret in secrets:
        if secret:
            for encoding in ['utf8', 'utf-16-le', 'utf-16-be']:
                data = data.replace(secret.encode(encoding), '[REDACTED]'.encode(encoding))
    if data != original:
        redactions[name] = dict(originalSha256=hashlib.sha256(original).hexdigest())
    entries[name] = data

for node in summary['nodes']:
    root = tools / node['root']
    binding = json.loads((root / 'candidate-binding.json').read_text())
    assert binding['jar'] == node['jar'] and len(binding['sourceBindings']) == 1099
    assert len(binding['classBindings']) == 1640
    props = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines()
                 if '=' in line and not line.startswith('#'))
    secrets = [props['rcon.password']]
    for file in root.iterdir():
        if file.is_file() and (file.suffix in ['.json', '.jsonl']
                              or file.name.endswith(('-stdout.log', '-stderr.log'))
                              or file.name == 'run-driver.py'):
            add(node['node'] + '/' + file.name, file, secrets)
    for file in (root / 'src').rglob('*'):
        if file.is_file():
            add(node['node'] + '/helper-src/' + file.relative_to(root / 'src').as_posix(), file, secrets)
    for side in ['server', 'clientA', 'clientB']:
        for file in (root / side).glob('*.json*'):
            add(node['node'] + '/' + side + '/' + file.name, file, secrets)
    helper = next((root / 'build/libs').glob('*.jar'))
    assert hashlib.sha256(helper.read_bytes()).hexdigest() == node['helperSha256']
    add(node['node'] + '/helper.jar', helper)
    add(node['node'] + '/build.gradle', root / 'build.gradle', secrets)
    add(node['node'] + '/settings.gradle', root / 'settings.gradle', secrets)

for name in ['derive-b477-dynamic-commit.py', 'prepare-b477-dynamic-commit.py',
             'derive-b477-commit-runner.py', 'derive-b477-commit-verifiers.py',
             'verify-b477-dynamic-commit.py', 'bind-b477-dynamic-commit.py',
             'seal-b477-dynamic-commit.py', 'b47734c6-modern-build-summary.json',
             'dynamic-commit-b477-261-helper-build.log', 'dynamic-commit-b477-262-helper-build.log',
             'dynamic-commit-b477-261-run.log', 'dynamic-commit-b477-262-run.log']:
    add('tools/' + name, tools / name)
summary['historicalFailure'] = dict(path='../2026-10-23-dynamic-commit-red/evidence.zip',
    archiveSha256=hashlib.sha256((dest.parent / '2026-10-23-dynamic-commit-red/evidence.zip').read_bytes()).hexdigest(),
    preserved=True)
summary['limits'].extend([
    '26.2 uses cached client loader 26.2.0.57 and server loader 26.2.0.75.',
    'Server stays COMMITTED after a client failure; no global DEGRADED or future-batch rejection claim.',
    'These two-node runs complement earlier ACK/NACK/timeout coverage, not every platform or release acceptance.'])
entries['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
dest.mkdir()
with zipfile.ZipFile(dest / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(dest / 'manifest.json').write_text(json.dumps(dict(
    archiveSha256=hashlib.sha256((dest / 'evidence.zip').read_bytes()).hexdigest(),
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
             for name, data in sorted(entries.items())}, redactions=redactions), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(dest / 'evidence.zip').stat().st_size,
                      stages=14, normalExits=6)))
