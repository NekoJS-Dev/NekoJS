package nekojs.acceptance.tcp.mixin;

import net.minecraft.core.Holder;
import net.minecraft.core.MappedRegistry;
import net.minecraft.core.RegistrationInfo;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Rejects only the owned client A fixture key at the actual physical registration boundary. */
@Mixin(MappedRegistry.class)
public abstract class CommitFaultMixin<T> {
    @Inject(method = "register(Lnet/minecraft/resources/ResourceKey;Ljava/lang/Object;Lnet/minecraft/core/RegistrationInfo;)Lnet/minecraft/core/Holder$Reference;",
            at = @At("HEAD"), require = 1)
    private void ownedCommitFault(ResourceKey<T> key, T value, RegistrationInfo info,
            CallbackInfoReturnable<Holder.Reference<T>> callback) {
        if (!key.identifier().toString().equals("nekojs_acceptance:tcp_commit_fail")) return;
        String owner = System.getProperty("nekojs.acceptance.owner", "");
        if (!owner.endsWith("-clientA") || (Object) this != BuiltInRegistries.ITEM
                || !Boolean.parseBoolean(System.getProperty("nekojs.acceptance.commitFault", "true"))) return;
        System.out.println("OWNED-TCP-COMMIT-FAULT owner=" + owner + " thread=" + Thread.currentThread().getName());
        throw new IllegalStateException("OWNED-TCP-COMMIT-FAULT physical registration rejected for " + key.identifier());
    }
}
