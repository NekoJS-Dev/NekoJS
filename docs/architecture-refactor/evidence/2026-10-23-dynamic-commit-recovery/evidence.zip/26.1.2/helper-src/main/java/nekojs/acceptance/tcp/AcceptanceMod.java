package nekojs.acceptance.tcp;

import com.google.gson.GsonBuilder;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipFile;

/** Checks the installed artifact before the owned TCP fixture observes it. */
@Mod("neko_tcp_acceptance")
public final class AcceptanceMod {
    public AcceptanceMod() throws Exception {
        Path expected = Path.of(System.getProperty("nekojs.acceptance.jar")).toAbsolutePath().normalize();
        Path actual = ModList.get().getModFileById("nekojs").getFile().getFilePath().toAbsolutePath().normalize();
        if (!Files.isSameFile(expected, actual)) throw new IllegalStateException("Owned installed mod source mismatch");
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("expectedJar", expected.toString());
        result.put("modFile", actual.toString());
        result.put("artifactSha256", sha256(Files.readAllBytes(actual)));
        Map<String, Object> classes = new LinkedHashMap<>();
        try (ZipFile archive = new ZipFile(expected.toFile())) {
            for (String name : new String[]{"com.tkisor.nekojs.NekoJS", "com.tkisor.nekojs.dynamic.DynamicRegistryFacade", "com.tkisor.nekojs.core.dynamic.txn.DynamicRegistryClientParticipant", "com.tkisor.nekojs.probe.backend.typescript.EventDeclarationGenerator", "com.tkisor.nekojs.dynamic.RegistrySurgery"}) {
                Class<?> type = Class.forName(name, false, getClass().getClassLoader());
                String entry = name.replace('.', '/') + ".class";
                byte[] packaged;
                try (var input = archive.getInputStream(archive.getEntry(entry))) { packaged = input.readAllBytes(); }
                byte[] loaded;
                try (var input = type.getResourceAsStream("/" + entry)) { loaded = input.readAllBytes(); }
                if (!java.util.Arrays.equals(packaged, loaded)) throw new IllegalStateException("Owned class bytes mismatch: " + name);
                String codeSource = type.getProtectionDomain().getCodeSource().getLocation().toExternalForm();
                if (!codeSource.contains(expected.getFileName().toString())) throw new IllegalStateException("Owned class source mismatch");
                classes.put(name, Map.of("sha256", sha256(loaded), "codeSource", codeSource,
                        "resource", type.getResource("/" + entry).toExternalForm()));
            }
        }
        result.put("classes", classes);
        result.put("pid", ProcessHandle.current().pid());
        Files.writeString(Path.of("installed-source-" + ProcessHandle.current().pid() + ".json"),
                new GsonBuilder().setPrettyPrinting().create().toJson(result) + "\n", StandardOpenOption.CREATE_NEW);
        System.out.println("OWNED-TCP-INSTALLED-SOURCE-PASS");
    }

    private static String sha256(byte[] value) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value));
    }
}
