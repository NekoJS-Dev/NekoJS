package nekojs.acceptance.tcp;

import com.google.gson.Gson;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashMap;
import java.util.Map;

/** Observes actual registry identity, including the defaulted registry's missing-key boundary. */
final class RegistryObservation {
    private RegistryObservation() {}

    private static int publishRetries;

    static Map<String, Object> items() {
        Map<String, Object> result = new LinkedHashMap<>();
        for (String path : new String[]{"tcp_seed", "tcp_dual", "tcp_timeout", "tcp_disconnect", "tcp_commit_fail", "tcp_followup"}) {
            Identifier id = Identifier.parse("nekojs_acceptance:" + path);
            var registry = BuiltInRegistries.ITEM;
            boolean present = registry.containsKey(id) && id.equals(registry.getKey(registry.getValue(id)));
            Map<String, Object> value = new LinkedHashMap<>();
            value.put("present", present);
            if (present) {
                var stack = registry.getValue(id).getDefaultInstance();
                value.put("maxStackSize", stack.getMaxStackSize());
                value.put("rarity", stack.getRarity().name());
            }
            result.put(path, value);
        }
        return result;
    }

    static boolean write(String name, String json) throws Exception {
        Path destination = Path.of(name + ".json");
        Path pending = Path.of(name + ".pending");
        Files.writeString(pending, json + "\n");
        try {
            Files.move(pending, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (java.nio.file.AccessDeniedException denied) {
            // Windows readers can briefly deny replacement; retry on a later tick without blocking it.
            if (++publishRetries > 100) throw denied;
            if (publishRetries == 1) System.out.println("OWNED-TCP-OBSERVATION-PUBLISH-RETRY " + name);
            return false;
        }
        publishRetries = 0;
        Files.writeString(Path.of(name + ".jsonl"), json + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        return true;
    }
}
