"""Prepare temporary, source-bound JFR events in the owned performance checkout."""
import hashlib
import json
from pathlib import Path
import subprocess

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = tools / '975496d3-stage-diagnostic'
revision = '975496d3bddf6fc76b206921a1d09207120ca24d'
assert not out.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
out.mkdir()
old = (tools / 'prepare-4405b0b0-stage-jfr.py').read_text()
event = old.split("event = '''", 1)[1].split("'''", 1)[0]
event = event.replace('neko.ReloadStage', 'neko.ReloadStage975')
changes = {
    'src/main/java/com/tkisor/nekojs/command/NekoJSCommands.java': [
        ('        NekoRuntimeRoot.ReloadResult reloadResult;\n        try {',
         '        NekoRuntimeRoot.ReloadResult reloadResult;\n        try (var profile = ReloadStage.begin("command")) {'),
        ('            reloadResult = root.reload(type);',
         '            try (var profile = ReloadStage.begin("root")) {\n            reloadResult = root.reload(type);\n            }'),
        ('                    recipeBroadcast = applyRecipeScripts(source);',
         '                    try (var profile = ReloadStage.begin("recipe")) {\n                    recipeBroadcast = applyRecipeScripts(source);\n                    }'),
    ],
    'common/src/main/java/com/tkisor/nekojs/script/ScriptManager.java': [
        ('                    try {\n                        candidateEnvironment = createCandidateEnvironment(candidateGeneration);',
         '                    try (var profile = ReloadStage.begin("preparation")) {\n                        candidateEnvironment = createCandidateEnvironment(candidateGeneration);'),
        ('                    try {\n                        environmentFactory.installEnvironmentBindings(',
         '                    try (var profile = ReloadStage.begin("bindings")) {\n                        environmentFactory.installEnvironmentBindings('),
        ('                    try {\n                        candidateScripts = discoverWithPacks();',
         '                    try (var profile = ReloadStage.begin("execution")) {\n                        candidateScripts = discoverWithPacks();'),
        ('                    commitGeneration(candidateGeneration, candidateEnvironment, candidateScripts, oldEnvironment);',
         '                    try (var profile = ReloadStage.begin("commit")) {\n                    commitGeneration(candidateGeneration, candidateEnvironment, candidateScripts, oldEnvironment);\n                    }'),
    ],
    'common/src/main/java/com/tkisor/nekojs/core/NekoSandboxFactory.java': [
        ('            ctx = contextBuilder.build();',
         '            try (var profile = ReloadStage.begin("context-build")) {\n            ctx = contextBuilder.build();\n            }'),
        ('            ctx.eval("js", CONSOLE_PATCH_JS);\n            ctx.eval("js", "Java.loadClass = Java.type;");',
         '            try (var profile = ReloadStage.begin("context-first-eval")) {\n            ctx.eval("js", CONSOLE_PATCH_JS);\n            ctx.eval("js", "Java.loadClass = Java.type;");\n            }'),
        ('            nodeRuntime = NekoNodeModuleInstaller.install(ctx, type,',
         '            try (var profile = ReloadStage.begin("node-install")) {\n            nodeRuntime = NekoNodeModuleInstaller.install(ctx, type,'),
        ('                    moduleSession);\n\n            Set<String> registeredExtensions',
         '                    moduleSession);\n            }\n\n            Set<String> registeredExtensions'),
    ],
    'common/src/main/java/com/tkisor/nekojs/script/ScriptEnvironmentFactory.java': [
        ('            var bindings = context.getBindings("js");\n            eventBridge.bindEvents(bindings, scriptType);',
         '            var bindings = context.getBindings("js");\n            try (var profile = ReloadStage.begin("bind-events")) {\n            eventBridge.bindEvents(bindings, scriptType);\n            }'),
        ('            environmentBindings.forEach((name, binding) -> {',
         '            try (var profile = ReloadStage.begin("bind-plugins")) {\n            environmentBindings.forEach((name, binding) -> {'),
        ('            });\n\n            // 受管 global/shared',
         '            });\n            }\n\n            // 受管 global/shared'),
        ('            bindManagedGlobals(bindings, scriptType, bindingSchema, ApiGuestErrorFactory.create(context));',
         '            try (var profile = ReloadStage.begin("bind-managed")) {\n            bindManagedGlobals(bindings, scriptType, bindingSchema, ApiGuestErrorFactory.create(context));\n            }'),
        ('            context.enter();\n            try {',
         '            try (var profile = ReloadStage.begin("bind-known-globals")) {\n            context.enter();\n            try {'),
        ('            knownGlobals.addAll(List.of("this", "arguments", "super"));',
         '            }\n            knownGlobals.addAll(List.of("this", "arguments", "super"));'),
    ],
}
bindings = []
for relative, edits in changes.items():
    target = tree / relative
    original = target.read_bytes()
    (out / target.name).write_bytes(original)
    source = original.decode('utf8').replace('\r\n', '\n')
    for before, after in edits:
        assert source.count(before) == 1, (relative, before)
        source = source.replace(before, after)
    end = source.rfind('\n}\n//?}') + 1 if target.name == 'NekoJSCommands.java' else source.rfind('}')
    assert end > 0
    source = source[:end] + event + source[end:]
    target.write_text(source, encoding='utf8', newline='\n')
    bindings.append(dict(path=relative, originalSha256=hashlib.sha256(original).hexdigest(),
        instrumentedSha256=hashlib.sha256(target.read_bytes()).hexdigest()))
(out / 'binding.json').write_text(json.dumps(dict(revision=revision, diagnosticOnly=True, bindings=bindings), indent=2) + '\n')
(out / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *changes], cwd=tree))
controller = (tools / '4405b0b0-stage-jfr-v2/diagnostic.ps1').read_text()
controller = controller.replace('4405b0b0-stage-jfr-v2/session', '975496d3-stage-diagnostic/session')
controller = controller.replace('4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349', revision).replace("'4405b0b0'", "'975496d3'")
controller = controller.replace(').Count -ne 2)', ').Count -ne 4)')
controller = controller.replace('period=2ms', 'period=1ms').replace('$pair -le 10', '$pair -le 30')
controller = controller.replace('Start-Sleep -Seconds 3', 'Start-Sleep -Seconds 1')
controller = controller.replace("'phase=COMMIT - no errors\\.'", "'reload committed:.*no errors\\.'")
(out / 'diagnostic.ps1').write_text(controller, encoding='utf8', newline='\n')
(out / 'run.py').write_bytes((tools / '4405b0b0-stage-jfr-v2/run.py').read_bytes())
print(json.dumps(dict(prepared=True, revision=revision, temporarySourceFiles=len(bindings), diagnosticOnly=True)))
