"""Summarize source-bound diagnostic JFR without exporting its raw payload."""
import json
from pathlib import Path
import statistics
import subprocess

tools = Path(__file__).resolve().parent
out = tools / '975496d3-stage-diagnostic-v3'
session = out / 'session'
assert json.loads((out / 'exit.json').read_text())['exitCode'] == 0
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
classpath = (tools / 'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf8').strip()
gson, = [part for part in classpath.split(';') if Path(part).name.startswith('gson-') and Path(part).is_file()]
classes = out / 'analysis-classes'
classes.mkdir(exist_ok=True)
source = (tools / 'ReloadStageAnalysis.java').read_text(encoding='utf8').replace('neko.ReloadStage', 'neko.ReloadStage975')
(out / 'ReloadStageAnalysis.java').write_text(source, encoding='utf8', newline='\n')
stages = ['root', 'recipe', 'command', 'preparation', 'bindings', 'execution', 'commit',
          'context-build', 'context-first-eval', 'node-install', 'bind-events', 'bind-plugins', 'bind-managed', 'bind-known-globals']
commands = [[str(java / 'javac.exe'), '-cp', gson, '-d', str(classes), str(out / 'ReloadStageAnalysis.java')]]
for stage in ['root', 'recipe', 'bindings', 'execution', 'node-install', 'context-first-eval']:
    commands.append([str(java / 'java.exe'), '-cp', str(classes) + ';' + gson, 'ReloadStageAnalysis',
        str(session / 'reload.jfr'), str(out / (stage + '-analysis.json')), stage])
for index, command in enumerate(commands):
    with (out / f'analysis-v2-{index}.log').open('xb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, index
analysis = json.loads((out / 'root-analysis.json').read_text(encoding='utf8'))
rows = json.loads((session / 'observations.json').read_text(encoding='utf-8-sig'))
state = json.loads((session / 'session.json').read_text(encoding='utf-8-sig'))
assert len(rows) == 60 and not state['forcedKill'] and not state['extra']['killed'] and state['extra']['stopChannel'] == 'rcon'
summary = dict(diagnosticOnly=True, formalVerdictUnchanged='FAIL', pairs=30,
    reloadRconMs=statistics.mean(row['rconMs'] for row in rows if row['command'] == 'nekojs reload'),
    queryRconMs=statistics.mean(row['rconMs'] for row in rows if row['command'] == 'list'),
    markerMs=statistics.mean(row['markerMs'] for row in rows if row['command'] == 'nekojs reload'), stages={})
for stage in stages:
    selected = [row for row in analysis['stages'] if row['stage'] == stage]
    assert len(selected) == 30 and all(row['thread'] == 'Server thread' for row in selected), (stage, len(selected))
    summary['stages'][stage] = dict(wallMs=statistics.mean(row['wallNs'] / 1e6 for row in selected),
        cpuMs=statistics.mean(row['cpuNs'] / 1e6 for row in selected))
summary['outsideCommandMs'] = summary['reloadRconMs'] - summary['stages']['command']['wallMs']
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf8')
print(json.dumps(summary, indent=2))
for stage in ['root', 'recipe', 'bindings', 'execution', 'node-install', 'context-first-eval']:
    selected = json.loads((out / (stage + '-analysis.json')).read_text(encoding='utf8'))
    print(stage.upper() + '_SAMPLES', selected['rootSamples'])
    print(stage.upper() + '_LEAVES', json.dumps(dict(list(selected['rootLeafCounts'].items())[:12])))
    print(stage.upper() + '_INCLUSIVE', json.dumps(dict(list(selected['rootNekoInclusiveCounts'].items())[:18])))
