"""Seal the source-bound stage profile and its exact source/class restoration."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-24-reload-stage-profile'
assert not out.exists()
trial = tools / '975496d3-stage-diagnostic-v3'
assert json.loads((trial / 'exit.json').read_text())['exitCode'] == 0
assert json.loads((trial / 'restoration.json').read_text())['classesMatchFrozenCandidate']
props = dict(line.split('=', 1) for line in Path('D:/mcmodDemo/NekoJS-perf-606d1fff/versions/26.1.2/run/server.properties').read_text().splitlines()
             if '=' in line and not line.startswith('#'))
secret = props['rcon.password']
entries = {}
redactions = {}
def add(name, file):
    original = data = file.read_bytes()
    for encoding in ['utf8', 'utf-16-le', 'utf-16-be']:
        if secret:
            data = data.replace(secret.encode(encoding), '[REDACTED]'.encode(encoding))
    if data != original:
        redactions[name] = hashlib.sha256(original).hexdigest()
    assert name not in entries
    entries[name] = data
for folder, prefix in [('975496d3-stage-diagnostic', 'failed-compile/'), ('975496d3-stage-diagnostic-v3', 'complete/')]:
    root = tools / folder
    for name in ['binding.json', 'instrumentation.patch', 'exit.json', 'run.py', 'diagnostic.ps1', 'controller.log', 'controller-stderr.log']:
        add(prefix + name, root / name)
    for file in root.glob('*.java'):
        add(prefix + file.name, file)
    for name in ['stages-stdout.log', 'stages-stderr.log']:
        add(prefix + 'session/' + name, root / 'session' / name)
for file in trial.glob('*-analysis.json'):
    add('complete/' + file.name, file)
for name in ['summary.json', 'instrumented-class-binding.json', 'source-restoration.json', 'restoration.json', 'restored-build.log']:
    add('complete/' + name, trial / name)
for name in ['owner.json', 'observations.json', 'session.json', 'jfr-start.txt', 'jfr-stop.txt']:
    add('complete/session/' + name, trial / 'session' / name)
for name in ['prepare-975-stage-diagnostic.py', 'derive-975-stage-v2.py', 'analyze-975-stage.py', 'restore-975-stage.py', 'rebuild-975-after-stage.py', 'seal-975-stage.py']:
    add('tools/' + name, tools / name)
add('frozen-source-binding.json', tools / '2026-10-24-method-bounds-performance-preparation/performance-source-binding.json')
reference = repo / 'docs/architecture-refactor/evidence/2026-10-24-method-bounds-performance/evidence.zip'
out.mkdir()
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(out / 'manifest.json').write_text(json.dumps(dict(sourceRevision='975496d3bddf6fc76b206921a1d09207120ca24d',
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    artifactReference=dict(path='../2026-10-24-method-bounds-performance/evidence.zip',
        archiveSha256=hashlib.sha256(reference.read_bytes()).hexdigest(), entry='artifact/nekojs-neoforge-26.1.2-1.1.0-preview3.jar'),
    localJfrSha256=hashlib.sha256((trial / 'session/reload.jfr').read_bytes()).hexdigest(),
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())},
    redactedOriginalHashes=redactions,
    exclusions=['raw JFR remains local', 'worlds', 'properties', 'full compiler/launcher arguments', 'environment snapshot']), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size, reloads=30,
    queries=30, successfulNormalStops=1, sourceAndClassBytesRestored=True, formalVerdict='FAIL')))
