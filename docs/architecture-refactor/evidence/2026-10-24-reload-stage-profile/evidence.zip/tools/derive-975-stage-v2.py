"""Keep the failed diagnostic, and repair its nested local variable name."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
previous = tools / '975496d3-stage-diagnostic'
target = tools / '975496d3-stage-diagnostic-v3'
assert json.loads((previous / 'exit.json').read_text())['exitCode'] == 1
assert not target.exists()
target.mkdir()
binding = json.loads((previous / 'binding.json').read_text())
for item in binding['bindings']:
    path = tree / item['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == item['instrumentedSha256']
    shutil.copyfile(previous / path.name, target / path.name)
    if path.name == 'NekoJSCommands.java':
        source = path.read_text(encoding='utf8')
        before = 'var profile = ReloadStage.begin("command")'
        assert source.count(before) == 1
        path.write_text(source.replace(before, 'var commandProfile = ReloadStage.begin("command")'), encoding='utf8', newline='\n')
        item['instrumentedSha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
(target / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
(target / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *[item['path'] for item in binding['bindings']]], cwd=tree))
(target / 'diagnostic.ps1').write_text((previous / 'diagnostic.ps1').read_text(encoding='utf8').replace('975496d3-stage-diagnostic/session', '975496d3-stage-diagnostic-v3/session'), encoding='utf8', newline='\n')
shutil.copyfile(previous / 'run.py', target / 'run.py')
print('OWNED_STAGE_V2_PREPARED')
