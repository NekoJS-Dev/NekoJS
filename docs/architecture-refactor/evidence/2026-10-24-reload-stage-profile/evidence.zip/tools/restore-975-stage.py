"""Restore exact owned source bytes after the diagnostic process has stopped."""
import hashlib
import json
from pathlib import Path
import subprocess

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = tools / '975496d3-stage-diagnostic-v3'
binding = json.loads((out / 'binding.json').read_text())
assert (out / 'exit.json').exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == binding['revision']
assert set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=tree, text=True).splitlines()) == {row['path'] for row in binding['bindings']}
classes = {}
for directory in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    for file in (tree / directory).rglob('*.class'):
        name = file.relative_to(tree / directory).as_posix()
        assert name not in classes
        classes[name] = hashlib.sha256(file.read_bytes()).hexdigest()
(out / 'instrumented-class-binding.json').write_text(json.dumps(classes, indent=2) + '\n')
for row in binding['bindings']:
    path = tree / row['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['instrumentedSha256']
    original = (out / path.name).read_bytes()
    assert hashlib.sha256(original).hexdigest() == row['originalSha256']
    path.write_bytes(original)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
(out / 'source-restoration.json').write_text(json.dumps(dict(sourceRestored=True, cleanCheckout=True,
    productionRevision=binding['revision'], restoredBuildPending=True), indent=2) + '\n')
print('OWNED_STAGE_SOURCE_RESTORED')
