"""Rebuild the restored candidate and verify all class bytes against its frozen manifest."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

repo = Path.cwd()
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = repo / 'build/priority-closeout/975496d3-stage-diagnostic-v3'
assert json.loads((out / 'source-restoration.json').read_text())['sourceRestored']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME'] + '/bin;' + environment['PATH']
environment['GRADLE_USER_HOME'] = 'D:/mcmodDemo/NekoJS/.gradle-[REDACTED]'
with (out / 'restored-build.log').open('xb') as log:
    result = subprocess.run(['cmd.exe', '/c', 'gradlew.bat', '--offline', ':26.1.2:jar', '--console=plain'],
        cwd=tree, env=environment, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
assert result.returncode == 0
frozen = json.loads((repo / 'build/priority-closeout/2026-10-24-method-bounds-performance-preparation/performance-source-binding.json').read_text())
classes = {}
for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
    for file in (tree / relative).rglob('*.class'):
        key = file.relative_to(tree / relative).as_posix()
        assert key not in classes
        classes[key] = hashlib.sha256(file.read_bytes()).hexdigest()
expected = frozen['classBindings'] if 'classBindings' in frozen else frozen['classes']
assert classes == expected, 'Restored class set differs from frozen candidate'
artifact, = (tree / 'versions/26.1.2/build/libs').glob('nekojs-neoforge-26.1.2-*.jar')
with zipfile.ZipFile(artifact) as archive:
    assert all(hashlib.sha256(archive.read(key)).hexdigest() == sha for key, sha in classes.items())
state = dict(sourceRestored=True, cleanCheckout=True, restoredBuildExit=0, classCount=len(classes),
    classesMatchFrozenCandidate=True, rebuiltArtifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),
    productionRevision='975496d3bddf6fc76b206921a1d09207120ca24d')
(out / 'restoration.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps(state))
