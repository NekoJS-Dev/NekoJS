// Bindings for test scripts
import { $RecipeSchemaBinding } from "java:com/tkisor/nekojs/bindings";
import { $BlockJS, $CapabilitiesJS, $ClientDataJS, $ColorJS, $DamageSourceJS, $DataMapJS, $FluidIngredientJS, $FluidJS, $IngredientFactory, $ItemJS, $KMathJS, $OnceJS, $OnceJS$ClearOnceJS, $ParticleOptionsJS, $StringUtilsJS, $TestJS, $TextIcons, $TimeJS, $UUIDJS, $UtilsJS } from "java:com/tkisor/nekojs/bindings/static_access";
import { $EntitySelectorsJS } from "java:com/tkisor/nekojs/util/selector";
import { $AssetGeneratorJS, $FluidAmounts } from "java:com/tkisor/nekojs/wrapper";
import { $ClientDataSyncJS } from "java:com/tkisor/nekojs/wrapper/clientdata";
import { $NetworkJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $Math } from "java:java/lang";
import { $BlockPos, $Direction } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleTypes } from "java:net/minecraft/core/particles";
import { $CompoundTag } from "java:net/minecraft/nbt";
import { $Component, $MutableComponent } from "java:net/minecraft/network/chat";
import { $Identifier } from "java:net/minecraft/resources";
import { $SoundEvents } from "java:net/minecraft/sounds";
import { $TriState } from "java:net/minecraft/util";
import { $DamageSource, $DamageTypes } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance, $MobEffects } from "java:net/minecraft/world/effect";
import { $EntityType } from "java:net/minecraft/world/entity";
import { $DyeColor, $Item, $ItemStack, $Items } from "java:net/minecraft/world/item";
import { $Ingredient } from "java:net/minecraft/world/item/crafting";
import { $Block, $Blocks } from "java:net/minecraft/world/level/block";
import { $Fluid, $Fluids } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3 } from "java:net/minecraft/world/phys";
import { $Capabilities } from "java:net/neoforged/neoforge/capabilities";
import { $FluidStack } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient } from "java:net/neoforged/neoforge/fluids/crafting";
type NekoFluidIngredientHelper = $FluidIngredientJS;
type NekoIngredientHelper = $IngredientFactory;
type NekoTestHelper = $TestJS;
type NekoItemHelper = $ItemJS;
type NekoFluidHelper = $FluidJS;
type AssetGeneratorJS = $AssetGeneratorJS;

export {};

declare global {
    let DamageSource: $DamageSourceJS & typeof $DamageSource;
    let DamageTypes: typeof $DamageTypes;
    let TextIcons: typeof $TextIcons;
    let clearOnce: $OnceJS$ClearOnceJS;
    let CompoundTag: typeof $CompoundTag;
    let FluidAmounts: typeof $FluidAmounts;
    let KMath: typeof $KMathJS;
    let DyeColor: typeof $DyeColor;
    let ClientData: typeof $ClientDataSyncJS;
    let MutableComponent: typeof $MutableComponent;
    /** Script-friendly FluidIngredient and SizedFluidIngredient helper. */
    let FluidIngredient: NekoFluidIngredientHelper & typeof $FluidIngredient;
    let FluidStack: typeof $FluidStack;
    let Direction: typeof $Direction;
    let StringUtils: $StringUtilsJS;
    let Vec3: typeof $Vec3;
    let TriState: typeof $TriState;
    let BlockPos: typeof $BlockPos;
    let Identifier: typeof $Identifier;
    let JavaMath: typeof $Math;
    let Time: $TimeJS;
    /** Script-friendly Ingredient and IngredientJS helper. */
    let Ingredient: NekoIngredientHelper & typeof $Ingredient;
    let Utils: $UtilsJS;
    /** Test-script assertion and smoke test helper. */
    let Test: NekoTestHelper;
    /** Script-friendly ItemStack factory and helpers (KubeJS-style: Item.of(id)); delegates of/empty to the helper, rest to MC Item. */
    let Item: NekoItemHelper & typeof $Item;
    let UUID: $UUIDJS;
    let EntityType: typeof $EntityType;
    let Items: typeof $Items;
    let AABB: typeof $AABB;
    let Color: $ColorJS;
    /** Script-friendly FluidStack helper. */
    let Fluid: NekoFluidHelper & typeof $Fluid;
    let Block: $BlockJS & typeof $Block;
    let Network: typeof $NetworkJS;
    let RecipeSchema: $RecipeSchemaBinding;
    let EntitySelectors: $EntitySelectorsJS;
    let DataMap: $DataMapJS;
    let ParticleTypes: typeof $ParticleTypes;
    let ItemStack: typeof $ItemStack;
    let Capabilities: $CapabilitiesJS & typeof $Capabilities;
    let clientData: $ClientDataJS;
    let ParticleOptions: $ParticleOptionsJS & typeof $ParticleOptions;
    let Component: typeof $Component;
    let once: $OnceJS;
    let MobEffects: typeof $MobEffects;
    /** Typed asset generators writing into NekoJS's assets pack (blockState/blockModel/itemModel/texture); takes effect on the next resource reload. */
    let Assets: AssetGeneratorJS;
    let Blocks: typeof $Blocks;
    let MobEffectInstance: typeof $MobEffectInstance;
    let SoundEvents: typeof $SoundEvents;
    let Fluids: typeof $Fluids;
}
