// Bindings for startup scripts
import { $RecipeSchemaBinding } from "java:com/tkisor/nekojs/bindings";
import { $BlockJS, $CapabilitiesJS, $ClientDataJS, $ColorJS, $DamageSourceJS, $DataMapJS, $FluidIngredientJS, $FluidJS, $IngredientFactory, $ItemJS, $KMathJS, $NativeEventsJS, $OnceJS, $OnceJS$ClearOnceJS, $ParticleOptionsJS, $StringUtilsJS, $TextIcons, $TimeJS, $UUIDJS, $UtilsJS } from "java:com/tkisor/nekojs/bindings/static_access";
import { $AssetGeneratorJS, $FluidAmounts } from "java:com/tkisor/nekojs/wrapper";
import { $ClientDataSyncJS } from "java:com/tkisor/nekojs/wrapper/clientdata";
import { $NetworkJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $Math } from "java:java/lang";
import { $BlockPos, $Direction } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleTypes } from "java:net/minecraft/core/particles";
import { $CompoundTag } from "java:net/minecraft/nbt";
import { $Component, $MutableComponent } from "java:net/minecraft/network/chat";
import { $Identifier } from "java:net/minecraft/resources";
import { $SoundEvents } from "java:net/minecraft/sounds";
import { $TriState } from "java:net/minecraft/util";
import { $DamageSource, $DamageTypes } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance, $MobEffects } from "java:net/minecraft/world/effect";
import { $EntityType } from "java:net/minecraft/world/entity";
import { $DyeColor, $Item, $ItemStack, $Items } from "java:net/minecraft/world/item";
import { $Ingredient } from "java:net/minecraft/world/item/crafting";
import { $Block, $Blocks } from "java:net/minecraft/world/level/block";
import { $Fluid, $Fluids } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3 } from "java:net/minecraft/world/phys";
import { $Capabilities } from "java:net/neoforged/neoforge/capabilities";
import { $FluidStack } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient } from "java:net/neoforged/neoforge/fluids/crafting";
type NekoFluidHelper = $FluidJS;
type AssetGeneratorJS = $AssetGeneratorJS;
type NekoIngredientHelper = $IngredientFactory;
type NekoFluidIngredientHelper = $FluidIngredientJS;
type NekoItemHelper = $ItemJS;

export {};

declare global {
    let AABB: typeof $AABB;
    let Fluids: typeof $Fluids;
    let KMath: typeof $KMathJS;
    let RecipeSchema: $RecipeSchemaBinding;
    /** Script-friendly FluidStack helper. */
    let Fluid: NekoFluidHelper & typeof $Fluid;
    let Block: $BlockJS & typeof $Block;
    /** Startup-side native NeoForge event bridge. */
    let NativeEvents: $NativeEventsJS;
    let Time: $TimeJS;
    let BlockPos: typeof $BlockPos;
    let Identifier: typeof $Identifier;
    let MobEffects: typeof $MobEffects;
    let clientData: $ClientDataJS;
    let TriState: typeof $TriState;
    let ItemStack: typeof $ItemStack;
    let Capabilities: $CapabilitiesJS & typeof $Capabilities;
    /** Typed asset generators writing into NekoJS's assets pack (blockState/blockModel/itemModel/texture); takes effect on the next resource reload. */
    let Assets: AssetGeneratorJS;
    let Vec3: typeof $Vec3;
    let clearOnce: $OnceJS$ClearOnceJS;
    let DataMap: $DataMapJS;
    let Utils: $UtilsJS;
    let UUID: $UUIDJS;
    let FluidStack: typeof $FluidStack;
    let Items: typeof $Items;
    let DamageTypes: typeof $DamageTypes;
    let DamageSource: $DamageSourceJS & typeof $DamageSource;
    let SoundEvents: typeof $SoundEvents;
    let CompoundTag: typeof $CompoundTag;
    let ParticleOptions: $ParticleOptionsJS & typeof $ParticleOptions;
    let FluidAmounts: typeof $FluidAmounts;
    let MutableComponent: typeof $MutableComponent;
    let Component: typeof $Component;
    let TextIcons: typeof $TextIcons;
    let ClientData: typeof $ClientDataSyncJS;
    /** Script-friendly Ingredient and IngredientJS helper. */
    let Ingredient: NekoIngredientHelper & typeof $Ingredient;
    let Blocks: typeof $Blocks;
    let MobEffectInstance: typeof $MobEffectInstance;
    let ParticleTypes: typeof $ParticleTypes;
    /** Script-friendly FluidIngredient and SizedFluidIngredient helper. */
    let FluidIngredient: NekoFluidIngredientHelper & typeof $FluidIngredient;
    /** Script-friendly ItemStack factory and helpers (KubeJS-style: Item.of(id)); delegates of/empty to the helper, rest to MC Item. */
    let Item: NekoItemHelper & typeof $Item;
    let EntityType: typeof $EntityType;
    let Direction: typeof $Direction;
    let StringUtils: $StringUtilsJS;
    let Color: $ColorJS;
    let Network: typeof $NetworkJS;
    let DyeColor: typeof $DyeColor;
    let JavaMath: typeof $Math;
    let once: $OnceJS;
}
