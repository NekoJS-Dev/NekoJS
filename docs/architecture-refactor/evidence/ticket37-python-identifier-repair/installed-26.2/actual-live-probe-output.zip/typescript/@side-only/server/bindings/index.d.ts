// Bindings for server scripts
import { $RecipeSchemaBinding } from "java:com/tkisor/nekojs/bindings";
import { $BlockJS, $CapabilitiesJS, $ClientDataJS, $ColorJS, $DamageSourceJS, $DataMapJS, $FluidIngredientJS, $FluidJS, $IngredientFactory, $ItemJS, $KMathJS, $OnceJS, $OnceJS$ClearOnceJS, $ParticleOptionsJS, $StringUtilsJS, $TextIcons, $TimeJS, $UUIDJS, $UtilsJS, $VillagerTradesJS } from "java:com/tkisor/nekojs/bindings/static_access";
import { $DynamicRegistryJS } from "java:com/tkisor/nekojs/dynamic";
import { $EntitySelectorsJS } from "java:com/tkisor/nekojs/util/selector";
import { $AssetGeneratorJS, $FluidAmounts } from "java:com/tkisor/nekojs/wrapper";
import { $ClientDataSyncJS } from "java:com/tkisor/nekojs/wrapper/clientdata";
import { $NetworkJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $Math } from "java:java/lang";
import { $BlockPos, $Direction } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleTypes } from "java:net/minecraft/core/particles";
import { $CompoundTag } from "java:net/minecraft/nbt";
import { $Component, $MutableComponent } from "java:net/minecraft/network/chat";
import { $Identifier } from "java:net/minecraft/resources";
import { $SoundEvents } from "java:net/minecraft/sounds";
import { $TriState } from "java:net/minecraft/util";
import { $DamageSource, $DamageTypes } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance, $MobEffects } from "java:net/minecraft/world/effect";
import { $EntityType } from "java:net/minecraft/world/entity";
import { $DyeColor, $Item, $ItemStack, $Items } from "java:net/minecraft/world/item";
import { $Ingredient } from "java:net/minecraft/world/item/crafting";
import { $Block, $Blocks } from "java:net/minecraft/world/level/block";
import { $Fluid, $Fluids } from "java:net/minecraft/world/level/material";
import { $AABB, $Vec3 } from "java:net/minecraft/world/phys";
import { $Capabilities } from "java:net/neoforged/neoforge/capabilities";
import { $FluidStack } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient } from "java:net/neoforged/neoforge/fluids/crafting";
type NekoIngredientHelper = $IngredientFactory;
type NekoFluidHelper = $FluidJS;
type AssetGeneratorJS = $AssetGeneratorJS;
type NekoFluidIngredientHelper = $FluidIngredientJS;
type NekoItemHelper = $ItemJS;

export {};

declare global {
    let ItemStack: typeof $ItemStack;
    let Direction: typeof $Direction;
    let MutableComponent: typeof $MutableComponent;
    let StringUtils: $StringUtilsJS;
    /** Script-friendly Ingredient and IngredientJS helper. */
    let Ingredient: NekoIngredientHelper & typeof $Ingredient;
    let FluidStack: typeof $FluidStack;
    let DataMap: $DataMapJS;
    let JavaMath: typeof $Math;
    let FluidAmounts: typeof $FluidAmounts;
    let AABB: typeof $AABB;
    let Time: $TimeJS;
    /** Script-friendly FluidStack helper. */
    let Fluid: NekoFluidHelper & typeof $Fluid;
    let Identifier: typeof $Identifier;
    let Blocks: typeof $Blocks;
    /** Typed asset generators writing into NekoJS's assets pack (blockState/blockModel/itemModel/texture); takes effect on the next resource reload. */
    let Assets: AssetGeneratorJS;
    let ClientData: typeof $ClientDataSyncJS;
    let DamageTypes: typeof $DamageTypes;
    let BlockPos: typeof $BlockPos;
    let Vec3: typeof $Vec3;
    let DyeColor: typeof $DyeColor;
    let DynamicRegistry: $DynamicRegistryJS;
    let DamageSource: $DamageSourceJS & typeof $DamageSource;
    let UUID: $UUIDJS;
    let KMath: typeof $KMathJS;
    let TextIcons: typeof $TextIcons;
    let EntitySelectors: $EntitySelectorsJS;
    let MobEffects: typeof $MobEffects;
    let MobEffectInstance: typeof $MobEffectInstance;
    /** Read-only, generation-bound villager trade queries. Declare trades through ServerEvents.tradeDeclaration; the platform adapter applies the candidate batch only after successful preflight and commit. */
    let VillagerTrades: $VillagerTradesJS;
    let RecipeSchema: $RecipeSchemaBinding;
    let Fluids: typeof $Fluids;
    let Component: typeof $Component;
    /** Script-friendly FluidIngredient and SizedFluidIngredient helper. */
    let FluidIngredient: NekoFluidIngredientHelper & typeof $FluidIngredient;
    let CompoundTag: typeof $CompoundTag;
    let Items: typeof $Items;
    /** Script-friendly ItemStack factory and helpers (KubeJS-style: Item.of(id)); delegates of/empty to the helper, rest to MC Item. */
    let Item: NekoItemHelper & typeof $Item;
    let Network: typeof $NetworkJS;
    let clearOnce: $OnceJS$ClearOnceJS;
    let Capabilities: $CapabilitiesJS & typeof $Capabilities;
    let SoundEvents: typeof $SoundEvents;
    let ParticleTypes: typeof $ParticleTypes;
    let once: $OnceJS;
    let Utils: $UtilsJS;
    let TriState: typeof $TriState;
    let Block: $BlockJS & typeof $Block;
    let ParticleOptions: $ParticleOptionsJS & typeof $ParticleOptions;
    let Color: $ColorJS;
    let clientData: $ClientDataJS;
    let EntityType: typeof $EntityType;
}
