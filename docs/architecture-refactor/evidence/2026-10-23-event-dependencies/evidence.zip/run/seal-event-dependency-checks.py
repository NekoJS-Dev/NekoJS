"""Freeze the committed event dependency fix and its actual verification records."""
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

tools = Path(__file__).resolve().parent
repo = tools.parent.parent
dest = repo / 'docs/architecture-refactor/evidence/2026-10-23-event-dependencies'
assert not dest.exists()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert revision.startswith('1f877b0f')
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {}
def add(name, path):
    entries[name] = path.read_bytes()

sources = [
    'common/src/main/java/com/tkisor/nekojs/probe/backend/typescript/EventDeclarationGenerator.java',
    'common/src/test/java/com/tkisor/nekojs/probe/backend/typescript/TypeScriptDeclarationClosureTest.java',
    'common/src/test/java/othermod/events/EventTypes.java',
    'common/src/test/resources/nekojs/dynamic/dynamic-registry-events.expected.d.ts',
    'package.json',
    'docs/architecture-refactor/baseline/2026-09-12-managed-surface/REGENERATE.md',
]
bindings = {}
for name in sources:
    data = (repo / name).read_bytes()
    committed = subprocess.check_output(['git', 'show', revision + ':' + name], cwd=repo)
    assert data.replace(b'\r\n', b'\n') == committed.replace(b'\r\n', b'\n'), name
    bindings[name] = dict(workingSha256=sha(data), committedSha256=sha(committed))
    entries['sources/' + name] = data
entries['code.patch'] = subprocess.check_output(['git', 'diff', '6fb9f99a', revision, '--', *sources], cwd=repo)
totals = dict.fromkeys(['tests', 'skipped', 'failures', 'errors'], 0)
for file in (repo / 'common/build/test-results/test').glob('TEST-*.xml'):
    suite = ET.fromstring(file.read_bytes())
    for key in totals:
        totals[key] += int(suite.get(key, '0'))
    add('common-xml/' + file.name, file)
assert totals == dict(tests=2416, skipped=4, failures=0, errors=0)
for name in [
    'event-dependency-red.log', 'event-dependency-red.xml',
    'event-key-red.log', 'event-key-red.xml',
    'event-dependency-green.log', 'event-dependency-common-check.log',
    'event-dependency-regenerate.log', 'event-dependency-final-focused.log',
    'event-dependency-final-focused.xml', 'event-dependency-final-golden.xml',
    'event-dependency-tsc.log', 'event-dependency-all-types.log',
    'event-dependency-final-common-check.log', 'event-dependency-original-golden.d.ts',
    'seal-event-dependency-checks.py',
]:
    add('run/' + name, tools / name)
for file in (repo / 'common/build/probe-ts-event-dependencies').rglob('*'):
    if file.is_file():
        add('strict-fixture/' + file.relative_to(repo / 'common/build/probe-ts-event-dependencies').as_posix(), file)
assert b'BUILD SUCCESSFUL' in entries['run/event-dependency-final-common-check.log']
assert b'DynamicRegistryEventsDeclarationGoldenTest' in entries['run/event-dependency-common-check.log']
assert b'BUILD FAILED' in entries['run/event-dependency-common-check.log']
summary = dict(revision=revision, common=totals,
    commonCheckExitCode=0, guardLintExitCode=0, fullProbeTypesExitCode=0,
    focusedTests=12, redRegressions=2, historicalCommonFailure='intentional dynamic event import golden difference',
    standards=dict(finalFindings=0, withdrawnFalsePositive='script-defined event key control flow'),
    spec=dict(initialFindings=1, fixed='non-emitted dispatch key dependency', finalFindings=0,
              withdrawnFalsePositive='script-defined event key control flow'),
    reviewersReadOnly=True, maintainerAcceptance=False,
    fullInstalledIdeNotRerun=True, performanceNotPassed=True, sourceBindings=bindings)
entries['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
dest.mkdir()
with zipfile.ZipFile(dest / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
manifest = dict(revision=revision, archiveSha256=sha((dest / 'evidence.zip').read_bytes()),
                entries={n: dict(size=len(d), sha256=sha(d)) for n, d in sorted(entries.items())})
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(revision=revision, entries=len(entries), bytes=(dest / 'evidence.zip').stat().st_size,
                     tests=totals)))
