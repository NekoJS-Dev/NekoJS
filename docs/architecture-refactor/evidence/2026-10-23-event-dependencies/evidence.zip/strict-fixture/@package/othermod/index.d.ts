export * as events from "java:othermod/events";

