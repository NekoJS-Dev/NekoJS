declare module "java:othermod/events" {
    export class $EventTypes$Payload {
        constructor();
        count: number;
    }

    export class $EventTypes$Key {
        constructor();
        name: string;
    }

}
