// NekoJS Probe Type Declarations

export * as othermod from "java:othermod";
