import { $EventTypes$Key, $EventTypes$Payload } from "java:othermod/events";

declare module "@side-only/startup/events" {
}

export {};

declare global {
    namespace ExternalEvents {
        function visit(handler: ((event: $EventTypes$Payload) => void)): void;
        function visit(extra: $EventTypes$Key, handler: ((event: $EventTypes$Payload) => void)): void;
    }

}
