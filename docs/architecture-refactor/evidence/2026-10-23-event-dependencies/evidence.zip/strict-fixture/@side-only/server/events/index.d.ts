import { $EventTypes$Key, $EventTypes$Payload } from "java:othermod/events";

declare module "@side-only/server/events" {
}

export {};

declare global {
    namespace ExternalEvents {
        function visit(handler: ((event: $EventTypes$Payload) => void)): void;
        function visit(extra: $EventTypes$Key, handler: ((event: $EventTypes$Payload) => void)): void;
    }

}
