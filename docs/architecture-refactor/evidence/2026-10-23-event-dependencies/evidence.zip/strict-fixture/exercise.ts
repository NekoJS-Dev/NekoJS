import type { $EventTypes$Key as Key } from 'java:othermod/events';
declare const key: Key;
ExternalEvents.visit(key, event => {
    const count: number = event.count;
    // @ts-expect-error Event dependencies retain their actual public members.
    const wrong: string = event.count;
    // @ts-expect-error Completing the closure does not fabricate extra members.
    event.missing;
});
// @ts-expect-error Dispatch keys retain their class shape.
ExternalEvents.visit(12, event => {});
