import json
import subprocess
from pathlib import Path

directory = Path('build/ticket37-config-sync-repair')
rows = []
for control in ['positive', 'negative']:
    config = directory/f'inherited-nested-python-{control}-config.json'
    with config.open('x') as stream:
        json.dump(dict(typeCheckingMode='strict', include=[f'inherited-nested-python-{control}.py',
            '../../common/build/probe-python-nested-getter/fixture.pyi'],
            extraPaths=['../../common/build/probe-python-nested-getter']), stream, indent=2)
    result_path = directory/f'inherited-nested-python-{control}-pyright.json'
    with result_path.open('xb') as stream:
        result = subprocess.run(['node', 'C:/Users/11515/AppData/Local/npm-cache/_npx/110e52990071af13/node_modules/pyright/index.js',
            '--project', str(config), '--outputjson'], stdout=stream, stderr=subprocess.PIPE)
    assert not result.stderr
    report = json.loads(result_path.read_text())
    assert report['summary']['filesAnalyzed'] == 2
    errors = [entry for entry in report['generalDiagnostics'] if entry['severity'] == 'error']
    if control == 'positive':
        assert result.returncode == 0 and not errors, report
    else:
        assert result.returncode == 1 and len(errors) == 1, report
        assert errors[0].get('rule') == 'reportAttributeAccessIssue' and 'str' in errors[0]['message'], errors
    rows.append(dict(control=control, exitCode=result.returncode, summary=report['summary']))
(directory/'inherited-nested-python-summary.json').write_text(json.dumps(rows, indent=2)+'\n')
print(json.dumps(rows))
