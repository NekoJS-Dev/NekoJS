from fixture import PythonBeanMemberCollisionTest_NestedGetterChild

target = PythonBeanMemberCollisionTest_NestedGetterChild()
target.value = "written"
read: str = target.value
explicit: str = target.getValue()
nested: str = target.getGetValue()
outer: str = target.getGetGetValue()
