"""Check full source SAM inputs with operand guards, without strengthening any factory."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess

base = Path('build/capture-domain-guard-20261026')
root = Path('build/capture-bound-operators-20261026')
root.mkdir()
function_source = Path('common/build/probe-ts-wildcard-optional/@package/java/util/function/index.d.ts')
source = function_source.read_bytes()
assert b'apply: <C extends T>' not in source
records = []
for mode in ['operators', 'supplier']:
    target = root / mode
    shutil.copytree(base, target)
    (target / '@package/java/util/function/index.d.ts').write_bytes(source)
    for module in ['util', 'util/stream']:
        path = target / '@package/java' / module / 'index.d.ts'
        text = path.read_text(encoding='utf-8')
        pattern = r'    type \$CaptureUnary<B> = .*?\n        \| .*?;\n    type \$CaptureBinary<B> = .*?\n        \| .*?;'
        replacement = ('    type $CaptureUnary<B> = $UnaryOperator_<B, B, B>;\n'
                       '    type $CaptureBinary<B> = $BinaryOperator_<B, B, B, B>;')
        text, count = re.subn(pattern, lambda _: replacement, text, count=1, flags=re.S)
        assert count == 1, module
        imported = '$BinaryOperator_' if module == 'util' else '$UnaryOperator_'
        imports = [line for line in text.splitlines() if line.startswith('import ') and 'from "java:java/util/function"' in line]
        if not any(re.search(r'(?<![\w$])' + re.escape(imported) + r'(?![\w$])', line) for line in imports):
            text = 'import type { ' + imported + ' } from "java:java/util/function";\n' + text
        if module == 'util/stream':
            old = 'reduce(arg0: B, arg1: <C extends B>(left: C, right: C) => C): B;'
            assert old in text
            text = text.replace(old, 'reduce<O extends $CaptureBinary<B>>(arg0: B, arg1: O & ([B, B] extends $CaptureArgs<O> ? O : never)): B;')
        if module == 'util' and mode == 'supplier':
            old = 'or(arg0: (() => $Optional<B>) | (<C extends B>() => $Optional<C>) | { readonly get: <C extends B>() => $Optional<C>; readonly [Symbol.hasInstance]?: never }): $OptionalView<B>;'
            if old not in text:
                candidates = [line for line in text.splitlines() if line.strip().startswith('or(')
                              and line.strip().endswith('$OptionalView<B>;')]
                assert len(candidates) == 1, candidates
                old = candidates[0].strip()
            text = text.replace(old, 'or(arg0: $Supplier_<$OptionalView<B>, $OptionalView<B>>): $OptionalView<B>;')
        path.write_text(text, encoding='utf-8', newline='\n')
    exercise = (target / 'exercise.ts').read_text(encoding='utf-8')
    exercise = exercise.replace('// @ts-expect-error An explicit generic argument must still admit the actual operand.',
                                '// @ts-expect-error The source apply method cannot be specialized into a narrow declaration.')
    exercise += """
declare const boundUnary: import('java:java/util/function').$UnaryOperator<Bound>;
declare const boundBinary: import('java:java/util/function').$BinaryOperator<Bound>;
list.replaceAll(boundUnary);
result.stream().reduce(boundBinary);
const seeded: Bound = result.stream().reduce(upper, boundBinary);
list.replaceAll($UnaryOperator.identity<Bound>());
declare const narrowUnary: import('java:java/util/function').$UnaryOperator<Narrow>;
declare const narrowBinary: import('java:java/util/function').$BinaryOperator<Narrow>;
// @ts-expect-error A narrowed host cannot consume every possible bound element.
list.replaceAll(narrowUnary);
// @ts-expect-error Both host operand domains must accept the bound.
result.stream().reduce(narrowBinary);
// @ts-expect-error An explicit narrow factory cannot consume the whole bound.
list.replaceAll($UnaryOperator.identity<Narrow>());
// @ts-expect-error A narrow binary factory cannot consume the whole bound.
result.stream().reduce($BinaryOperator.maxBy<Narrow>((left, right) => 0));
// @ts-expect-error Seeded reductions keep both operator operand domains checked.
result.stream().reduce(upper, narrowBinary);
"""
    if mode == 'supplier':
        exercise += """
declare const supplied: import('java:java/util/function').$Supplier<import('java:java/util').$Optional<Narrow>>;
const suppliedValue: Bound = result.or(supplied).get();
const directFallback: Bound = result.or(() => $Optional.of(upper)).get();
"""
    (target / 'exercise.ts').write_text(exercise, encoding='utf-8', newline='\n')
    proc = subprocess.run(['node', 'node_modules/typescript/bin/tsc', '-p', str(target / 'tsconfig.json')], capture_output=True, timeout=120)
    (target / 'tsc.txt').write_bytes(proc.stdout)
    (target / 'tsc-stderr.txt').write_bytes(proc.stderr)
    codes = Counter(re.findall(r': error (TS\d+):', proc.stdout.decode('utf-8')))
    assert not proc.stderr and proc.returncode in (0, 2)
    assert (proc.returncode == 0) == (not codes)
    record = {'mode': mode, 'exitCode': proc.returncode, 'errorCodes': dict(codes)}
    records.append(record)
    print(json.dumps(record))
(root / 'summary.json').write_text(json.dumps({'production': False, 'functionalModuleSource': str(function_source),
    'functionalModuleSha256': sha256(source).hexdigest(), 'records': records}, indent=2) + '\n', encoding='utf-8', newline='\n')
