import hashlib
import json
import zipfile
from pathlib import Path

p = Path.cwd()
raw = p / 'build/priority-closeout'
trial = p / 'build/closeout-4405b0b0-rollback'
out = p / 'docs/architecture-refactor/evidence/2026-10-22-candidate-rollback'
assert json.loads((trial / 'final-verdict.json').read_text())['verdict'] == 'PASS'
assert not (out / 'evidence.zip').exists()
out.mkdir(exist_ok=True)
entries = {}
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    def add(f, name):
        assert name not in entries
        data = f.read_bytes()
        entries[name] = dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
        z.writestr(name, data)
    for name in ['summary.json', 'backup-manifest.json', 'final-verdict.json']:
        add(trial / name, name)
    for phase in ['baseline-initial', 'candidate-advance', 'artifact-rollback', 'data-restore']:
        for name in ['preparation.json', 'result.json', 'commands.json', 'owned-process.json', 'server-stdout.log', 'server-stderr.log']:
            add(trial / phase / name, phase + '/' + name)
        add(trial / phase / 'nekojs/server_scripts/pdata-proof.js', phase + '/pdata-proof.js')
    for name in ['rollback-4405b0b0.py', '4405b0b0-rollback-run.log', 'seal-4405b0b0-rollback.py']:
        add(raw / name, 'tooling/' + name)
    add(p / 'bench/perf/rcon.py', 'tooling/rcon.py')
(out / 'manifest.json').write_text(json.dumps(dict(entries=entries,
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    oldRevision='d91ca974', candidateRevision='4405b0b0',
    exclusions=['world binaries', 'JARs', 'dependencies', 'server.properties', 'human release acceptance']), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size)))
