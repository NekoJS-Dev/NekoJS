import hashlib
import json
import os
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
owned = project / 'build/ticket37-perf-owned-ac810fa7'
destination = project / 'build/ticket37-reload-phase-7d'
helpers = project / 'build/ticket37-config-sync-repair'
manifest = json.loads((destination / 'manifest.json').read_text())
revision = '7d77308bfa400721304b20940ada91092180a1ed'
sha = lambda data: hashlib.sha256(data).hexdigest()
guard_source = (helpers / 'guard-node-assert-performance.ps1').read_text()
clean_clause = ' -or @(git -C $owned status --porcelain).Count -ne 0'
assert guard_source.count(clean_clause) == 1
guard_source = guard_source.replace(clean_clause, '')
guard_source += '''
$manifest = Get-Content -LiteralPath 'D:\\mcmodDemo\\NekoJS-mult\\build\\ticket37-reload-phase-7d\\manifest.json' -Raw | ConvertFrom-Json
if (@(git -C $owned status --porcelain).Count -ne 2) { throw 'Unexpected diagnostic working files' }
foreach ($entry in $manifest.files.PSObject.Properties) {
    $path = Join-Path $owned $entry.Name
    if ((Get-FileHash -LiteralPath $path).Hash -ne $entry.Value.instrumentedSha256) { throw 'Diagnostic source changed' }
}
Write-Output 'FROZEN_DIAGNOSTIC_SOURCE=PASS'
'''
guard_path = destination / 'guard.ps1'
assert not guard_path.exists()
guard_path.write_text(guard_source)
env = dict(os.environ)
env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
env['JAVA_HOME'] = r'C:\Program Files\Java\jdk-25.0.2'
env['PATH'] = env['JAVA_HOME'] + r'\bin;' + env['PATH']
ps = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass']

def guard(label):
    assert subprocess.check_output(['git', '-C', str(owned), 'rev-parse', 'HEAD'], text=True).strip() == revision
    changed = subprocess.check_output(['git', '-C', str(owned), 'diff', '--name-only'], text=True).splitlines()
    assert sorted(changed) == sorted(manifest['files'])
    assert sha(subprocess.check_output(['git', '-C', str(owned), 'diff'])) == manifest['instrumentationPatchSha256']
    for name, record in manifest['files'].items():
        assert sha((owned / name).read_bytes()) == record['instrumentedSha256']
    with (destination / (label + '-guard.txt')).open('xb') as output:
        result = subprocess.run(ps + ['-File', str(guard_path)], env=env, stdout=output,
                                stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    (destination / (label + '-guard-exit.json')).write_text(json.dumps(dict(exitCode=result.returncode)))
    assert result.returncode == 0

guard('before')
before = sorted(path.name for path in (owned / 'bench/perf/out').iterdir() if path.is_dir())
(destination / 'output-inventory-before.json').write_text(json.dumps(before, indent=2))
print('DIAGNOSTIC_PHASE_GROUP_START', flush=True)
with (destination / 'sampler.txt').open('xb') as output:
    result = subprocess.run(ps + ['-File', str(owned / 'bench/perf/sample.ps1'), '-Mode', 'reload',
        '-Node', '26.1.2', '-Warmup', '2', '-Samples', '5', '-Reloads', '5',
        '-GradleUserHome', 'D:/mcmodDemo/NekoJS/.gradle-perf02', '-ServerPort', '25871', '-RconPort', '25872'],
        cwd=owned, env=env, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
(destination / 'sampler-exit.json').write_text(json.dumps(dict(exitCode=result.returncode, sourceRevision=revision,
    instrumentationPatchSha256=manifest['instrumentationPatchSha256'], diagnosticOnly=True)))
assert result.returncode == 0
after = sorted(path.name for path in (owned / 'bench/perf/out').iterdir() if path.is_dir())
new = sorted(set(after) - set(before))
assert len(new) == 1
(destination / 'output-inventory-after.json').write_text(json.dumps(dict(all=after, new=new), indent=2))
guard('after')
print('DIAGNOSTIC_PHASE_GROUP_EXIT=0', flush=True)
