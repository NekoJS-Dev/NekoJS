import json
from pathlib import Path

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
work = project / 'build/ticket37-reload-module-7d'
source = (helpers / 'read-reload-execution-7d.py').read_text(encoding='utf-8')
source = source.replace('ticket37-reload-execution-7d', 'ticket37-reload-module-7d')
source = source.replace('DEBUG-7d-(?:phase|exec)', 'DEBUG-7d-(?:phase|exec|module)')
source = source.replace('(?:message|script)', '(?:message|script|path)')
exec(compile(source, str(helpers / 'read-reload-execution-7d.py'), 'exec'))
summary = json.loads((work / 'execution-summary.json').read_text())
for row in summary['reloads']:
    events = row['events']
    def pairs(begin, end):
        results = []
        stack = {}
        for event in events:
            if event['phase'] == begin:
                assert event['message'] not in stack
                stack[event['message']] = event
            elif event['phase'] == end:
                start = stack.pop(event['message'])
                assert start['nano'] < event['nano']
                results.append(dict(path=event['message'], ms=(event['nano']-start['nano'])/1e6,
                                    beginNano=start['nano'], endNano=event['nano']))
        assert not stack and len(results) == 6, (begin, end, results)
        ordered = sorted(results, key=lambda result: result['beginNano'])
        assert all(a['endNano'] <= b['beginNano'] for a, b in zip(ordered, ordered[1:])), (begin, 'nested spans cannot be summed')
        return ordered
    detail = {}
    for key, begin, end in [('resolution', 'resolve-begin', 'resolve-end'), ('dependencyRefresh', 'resolve-end', 'refresh-end'),
                           ('preparationCache', 'prepare-begin', 'prepare-cache-end'), ('preparationObserve', 'prepare-cache-end', 'prepare-end'),
                           ('guestExecutor', 'guest-execute-begin', 'guest-execute-end')]:
        detail[key] = pairs(begin, end)
        detail[key + 'Ms'] = sum(span['ms'] for span in detail[key])
    row['moduleBreakdown'] = detail
keys = ('resolutionMs', 'dependencyRefreshMs', 'preparationCacheMs', 'preparationObserveMs', 'guestExecutorMs')
summary['moduleMeans'] = {key: sum(row['moduleBreakdown'][key] for row in summary['reloads']) / 5 for key in keys}
summary['moduleLimits'] = 'Guest executor combines new Function compilation and function body execution. Preparation cache includes trust/read/compile/source-map work. Observer costs unquantified.'
(work / 'module-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(dict(result='PASS', means=summary['means'], executionMeans=summary['executionMeans'], moduleMeans=summary['moduleMeans']), indent=2))
