import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

project = Path.cwd().resolve()
owned = project / 'build/ticket37-perf-owned-ac810fa7'
work = project / 'build/ticket37-reload-phase-7d'
assert json.loads((work / 'runner-exit.json').read_text())['exitCode'] == 0
inventory = json.loads((work / 'output-inventory-after.json').read_text())
folder = owned / 'bench/perf/out' / inventory['new'][0]
samples = [json.loads(line) for line in (folder / 'samples.jsonl').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
assert len(samples) == 5 and [row['index'] for row in samples] == [1, 2, 3, 4, 5]
assert all(row['kind'] == 'formal' and row['mode'] == 'reload' and row['rev'] == '7d77308b'
           and row['stop_channel'] == 'rcon' and not row['forced_kill'] and not row['killed'] for row in samples)
pattern = re.compile(r'\[DEBUG-7d-phase\] ([-\w]+) type=(\S+) nano=(\d+) epoch=(\d+)(?: message=(.*))?')
events = {}
for path in folder.glob('*.log'):
    for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
        match = pattern.search(line)
        if not match:
            continue
        event = dict(phase=match[1], scriptType=match[2], nano=int(match[3]), epochMs=int(match[4]), message=match[5] or '')
        events[(event['phase'], event['nano'])] = event
events = sorted(events.values(), key=lambda row: row['nano'])
starts = [row for row in events if row['phase'] == 'root-begin' and row['scriptType'] == 'server']
ends = [row for row in events if row['phase'] == 'root-after-manager' and row['scriptType'] == 'server']
assert len(starts) == len(ends) == 6, (starts, ends)
stdout = (folder / 'reload-session-stdout.log').read_text(encoding='utf-8', errors='replace')
ready = re.findall(r'\[(\d\d:\d\d:\d\d)\].*DedicatedServer.*Done \(', stdout)
assert len(ready) == 1, ready
local = timezone(timedelta(hours=8))
hour, minute, second = map(int, ready[0].split(':'))
ready_time = datetime.fromtimestamp(starts[0]['epochMs']/1000, local).replace(hour=hour, minute=minute, second=second, microsecond=0)
ready_epoch = int(ready_time.timestamp()*1000)
initial = dict(start=starts[0], end=ends[0], observedRootMs=(ends[0]['nano']-starts[0]['nano'])/1e6)
assert ends[0]['epochMs'] < ready_epoch and starts[1]['epochMs'] >= ready_epoch+3000
starts, ends = starts[1:], ends[1:]
reloads = []
for sample, start, end in zip(samples, starts, ends):
    assert start['nano'] < end['nano']
    clock = datetime.fromtimestamp(start['epochMs']/1000, local).strftime('%H:%M:%S')
    assert '[' + clock + ']' in sample['marker_line'], (sample, start)
    current = [row for row in events if row['scriptType'] == 'server' and start['nano'] <= row['nano'] <= end['nano']]
    assert any(row['phase'] == 'finish' and row['message'] == 'server scripts ready' for row in current), current
    phases = []
    previous = start
    for event in current[1:]:
        phases.append(dict(phase=event['phase'], message=event['message'], elapsedFromRootMs=(event['nano'] - start['nano'])/1e6,
                           intervalFromPriorEventMs=(event['nano'] - previous['nano'])/1e6))
        previous = event
    duration = (end['nano'] - start['nano'])/1e6
    reloads.append(dict(index=sample['index'], rootThroughManagerMs=duration,
        rconRttMs=sample['rcon_rtt_ms'], markerMs=sample['marker_ms'],
        rttMinusObservedRootMs=sample['rcon_rtt_ms']-duration,
        markerMinusRttMs=sample['marker_ms']-sample['rcon_rtt_ms'], phases=phases, events=current))
summary = dict(sourceRevision='7d77308bfa400721304b20940ada91092180a1ed',
    instrumentationPatchSha256=json.loads((work / 'manifest.json').read_text())['instrumentationPatchSha256'],
    diagnosticOnly=True, formalReplacement=False, folder=folder.name, reloads=reloads,
    initialPreReadinessRoot=initial, readinessClock=ready[0], readinessEpochMsFloor=ready_epoch, allEvents=events,
    means={key:sum(row[key] for row in reloads)/5 for key in
           ('rootThroughManagerMs', 'rconRttMs', 'markerMs', 'rttMinusObservedRootMs', 'markerMinusRttMs')},
    synchronousObserverOverhead='NOT_QUANTIFIED', rootReturnProxy='After manager returns, before success result construction',
    queueAuthNetworkSplit='NOT_MEASURED', originalFormalPerformance='FAIL_RETAINED')
(work / 'phase-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(dict(result='PASS', means=summary['means'], reloads=[dict(index=row['index'], rootMs=row['rootThroughManagerMs'],
    phases=[dict(phase=p['message'] or p['phase'], intervalMs=p['intervalFromPriorEventMs']) for p in row['phases']]) for row in reloads])))
