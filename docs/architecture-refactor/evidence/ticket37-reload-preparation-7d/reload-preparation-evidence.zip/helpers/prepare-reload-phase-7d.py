import hashlib
import json
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
owned = project / 'build/ticket37-perf-owned-ac810fa7'
target = project / 'build/ticket37-reload-phase-7d'
revision = '7d77308bfa400721304b20940ada91092180a1ed'
assert owned.resolve() == owned and not owned.is_symlink()
assert subprocess.check_output(['git', '-C', str(owned), 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', '-C', str(owned), 'status', '--porcelain'], text=True).strip()
assert json.loads((project / 'build/ticket37-perf-7d77308b/final-owned-guard-exit.json').read_text())['exitCode'] == 0
assert json.loads((project / 'docs/architecture-refactor/evidence/ticket37-node-assert-performance/summary.json').read_text())['overall'] == 'FAIL'
for name in ('AGENTS.md', 'CONTEXT.md', 'docs/agents/coding.md'):
    assert (owned / name).read_bytes() == (project / name).read_bytes(), name
if target.exists():
    assert (target / 'preparation-failure.txt').is_file()
    assert not (target / 'manifest.json').exists() and not (target / 'instrumented').exists()
else:
    target.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
changes = {}
root_name = 'common/src/main/java/com/tkisor/nekojs/core/lifecycle/NekoRuntimeRoot.java'
tracker_name = 'common/src/main/java/com/tkisor/nekojs/core/lifecycle/ReloadProgressTracker.java'
for name in (root_name, tracker_name):
    path = owned / name
    assert path.resolve().is_relative_to(owned) and not path.is_symlink()
    original = path.read_bytes()
    stored = target / 'original' / name
    stored.parent.mkdir(parents=True, exist_ok=True)
    if stored.exists():
        assert stored.read_bytes() == original
    else:
        stored.write_bytes(original)
    text = path.read_text(encoding='utf-8')
    if name == root_name:
        before = '''    public ReloadResult reload(ScriptType type) {
        ScriptManager manager = scriptManagerOf(type);
        manager.reloadScripts();'''
        after = '''    public ReloadResult reload(ScriptType type) {
        long diagnosticStarted = System.nanoTime();
        System.err.println("[DEBUG-7d-phase] root-begin type=" + type.name
                + " nano=" + diagnosticStarted + " epoch=" + System.currentTimeMillis());
        ScriptManager manager = scriptManagerOf(type);
        manager.reloadScripts();
        System.err.println("[DEBUG-7d-phase] root-after-manager type=" + type.name
                + " nano=" + System.nanoTime() + " epoch=" + System.currentTimeMillis());'''
        assert text.count(before) == 1
        text = text.replace(before, after)
    else:
        for before, label in [
            ('STATE.set(new Snapshot(scriptType, true, 0.0f, "", clock() + UPDATE_LINGER_MILLIS));', 'begin'),
            ('STATE.set(new Snapshot(scriptType, true, progressOf(updated), message, clock() + UPDATE_LINGER_MILLIS));', 'step'),
            ('STATE.set(new Snapshot(scriptType, false, 1.0f, message, clock() + FINISH_LINGER_MILLIS));', 'finish')]:
            assert text.count(before) == 1
            message = '""' if label == 'begin' else 'message'
            text = text.replace(before, before + '\n        System.err.println("[DEBUG-7d-phase] ' + label
                + ' type=" + scriptType + " nano=" + System.nanoTime() + " epoch=" + System.currentTimeMillis()'
                + ' + " message=" + ' + message + ');')
    path.write_text(text, encoding='utf-8')
    stored = target / 'instrumented' / name
    stored.parent.mkdir(parents=True, exist_ok=True)
    stored.write_bytes(path.read_bytes())
    changes[name] = dict(originalSha256=sha(original), instrumentedSha256=sha(path.read_bytes()))
patch = subprocess.check_output(['git', '-C', str(owned), 'diff', '--', root_name, tracker_name])
(target / 'instrumentation.patch').write_bytes(patch)
assert sorted(subprocess.check_output(['git', '-C', str(owned), 'diff', '--name-only'], text=True).splitlines()) == sorted(changes)
(target / 'manifest.json').write_text(json.dumps(dict(sourceRevision=revision, instrumentationPatchSha256=sha(patch),
    files=changes, scope='Owned-only diagnostic source; synchronous time-point output has observer cost; successful SERVER reload only',
    officialPerformance='FAIL_RETAINED', formalReplacement=False), indent=2))
(target / 'PLAN.md').write_text('''# One predeclared instrumented phase group

The three exact 7d formal groups have ended and remain FAIL/PASS as recorded.
Run exactly one five-reload original sampler session on the owned checkout,
with only the frozen two-file timing patch. Original fixtures/sampler/JDK/cache/
ports and path/reparse/process guards remain unchanged. Dirty source is allowed
only for the exact recorded instrumentation; this is not formal certification.

Direct stderr nano/epoch timestamps mark root entry/after-manager and existing
begin/step/finish transitions. Synchronous prints perturb the measured work;
differences to RTT cannot distinguish queue/auth/network individually. Root
return after-manager is a proxy just before success result construction; no
failure/exception path timing guarantee. No guest permissions or host binding
changes, profiler attachment, GUI control or unrelated process operations.

Preserve every first/remaining value and direct exits. Compare observed root/
phase spans with RTT and marker only as diagnosis. Restore the two originals
only after exact patch/source/owned-process checks; never reset or clean.
''')
print(json.dumps(dict(result='PREPARED', sourceRevision=revision, instrumentationPatchSha256=sha(patch))))
