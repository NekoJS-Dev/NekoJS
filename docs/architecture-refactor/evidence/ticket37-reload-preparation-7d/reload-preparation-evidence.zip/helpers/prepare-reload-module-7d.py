import hashlib
import json
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
work = project / 'build/ticket37-reload-module-7d'
assert not work.exists()
assert json.loads((project / 'build/ticket37-reload-execution-7d/restored-source.json').read_text())['sourceRestoredByteEqual']
source = (helpers / 'prepare-reload-execution-7d.py').read_text(encoding='utf-8')
source = source.replace('ticket37-reload-execution-7d', 'ticket37-reload-module-7d')
source = source.replace("assert json.loads((project / 'build/ticket37-reload-phase-7d/restored-source.json').read_text())['sourceRestoredByteEqual']", "assert json.loads((project / 'build/ticket37-reload-execution-7d/restored-source.json').read_text())['sourceRestoredByteEqual']")
exec(compile(source, str(helpers / 'prepare-reload-execution-7d.py'), 'exec'))
manifest = json.loads((work / 'manifest.json').read_text())
owned = project / 'build/ticket37-perf-owned-ac810fa7'
sha = lambda data: hashlib.sha256(data).hexdigest()
name = 'common/src/main/java/com/tkisor/nekojs/core/module/NekoScriptModuleLoaderHost.java'
path = owned / name
assert path.resolve().is_relative_to(owned) and not path.is_symlink()
original = path.read_bytes()
stored = work / 'original' / name
stored.parent.mkdir(parents=True, exist_ok=True)
stored.write_bytes(original)
text = original.decode('utf-8')
def mark(label, expression):
    return ('System.err.println("[DEBUG-7d-module] ' + label
            + ' type=" + com.tkisor.nekojs.script.ScriptContextRegistry.scriptTypeOf(context).name'
            + ' + " nano=" + System.nanoTime() + " epoch=" + System.currentTimeMillis() + " path=" + ' + expression + ');')
before = '''    public CompletableFuture<?> loadEntryAsync(String entryPath) throws IOException {
        NekoResolvedModule resolved = resolveEntryPath(entryPath);
        dependencyGraph.markEntry(resolved.id());
        refreshPreparedExecutionTree(resolved.id());'''
after = '''    public CompletableFuture<?> loadEntryAsync(String entryPath) throws IOException {
        ''' + mark('resolve-begin', 'entryPath') + '''
        NekoResolvedModule resolved = resolveEntryPath(entryPath);
        ''' + mark('resolve-end', 'entryPath') + '''
        dependencyGraph.markEntry(resolved.id());
        refreshPreparedExecutionTree(resolved.id());
        ''' + mark('refresh-end', 'entryPath')
assert text.count(before) == 1
text = text.replace(before, after)
before = '''    private NekoPreparedModule prepare(NekoResolvedModule resolved) throws IOException {
        NekoPreparedModule prepared = preparationCache.prepare(resolved.path());
        observePrepared(resolved.id(), resolved.path(), prepared);'''
after = '''    private NekoPreparedModule prepare(NekoResolvedModule resolved) throws IOException {
        ''' + mark('prepare-begin', 'resolved.id()') + '''
        NekoPreparedModule prepared = preparationCache.prepare(resolved.path());
        ''' + mark('prepare-cache-end', 'resolved.id()') + '''
        observePrepared(resolved.id(), resolved.path(), prepared);
        ''' + mark('prepare-end', 'resolved.id()')
assert text.count(before) == 1
text = text.replace(before, after)
before = '            executor.execute(module.value(), require, resolve, resolved.id(), resolved.dirname(), prepared.code());'
assert text.count(before) == 1
text = text.replace(before, '            ' + mark('guest-execute-begin', 'resolved.id()') + '\n' + before
                    + '\n            ' + mark('guest-execute-end', 'resolved.id()'))
path.write_bytes(text.encode('utf-8'))
stored = work / 'instrumented' / name
stored.parent.mkdir(parents=True, exist_ok=True)
stored.write_bytes(path.read_bytes())
manifest['files'][name] = dict(originalSha256=sha(original), instrumentedSha256=sha(path.read_bytes()))
patch = subprocess.check_output(['git', '-C', str(owned), 'diff'])
assert sorted(subprocess.check_output(['git', '-C', str(owned), 'diff', '--name-only'], text=True).splitlines()) == sorted(manifest['files'])
manifest['instrumentationPatchSha256'] = sha(patch)
manifest['scope'] = 'Owned-only successful module path boundary diagnosis; five exact files; synchronous observer cost unquantified'
(work / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
(work / 'instrumentation.patch').write_bytes(patch)
(work / 'PLAN.md').write_text('''# One predeclared successful module path diagnostic

Ranked predictions: module preparation (read/trust/compile/source-map) dominates;
guest executor (compile/evaluate/body) dominates; or resolution/dependency refresh
dominates. Measure the unchanged work at those boundaries. One original sampler
group of five reloads, all first/readiness events retained, five-file diagnostic
patch only. No formal certification, no work disabled, no caches or security rules
changed. Output observer cost not quantified. Restore exact source after guards.
''', encoding='utf-8')
runner = (helpers / 'run-reload-execution-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-execution-7d', 'ticket37-reload-module-7d').replace('.Count -ne 4', '.Count -ne 5')
(helpers / 'run-reload-module-7d.py').write_text(runner, encoding='utf-8')
restore = (helpers / 'restore-reload-execution-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-execution-7d', 'ticket37-reload-module-7d')
(helpers / 'restore-reload-module-7d.py').write_text(restore, encoding='utf-8')
print(json.dumps(dict(result='PREPARED_MODULE', instrumentationPatchSha256=sha(patch), files=list(manifest['files']))))
