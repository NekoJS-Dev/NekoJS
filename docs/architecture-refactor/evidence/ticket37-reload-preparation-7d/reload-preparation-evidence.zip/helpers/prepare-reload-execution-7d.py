import hashlib
import json
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
work = project / 'build/ticket37-reload-execution-7d'
owned = project / 'build/ticket37-perf-owned-ac810fa7'
assert not work.exists()
assert json.loads((project / 'build/ticket37-reload-phase-7d/restored-source.json').read_text())['sourceRestoredByteEqual']
source = (helpers / 'prepare-reload-phase-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-phase-7d', 'ticket37-reload-execution-7d')
exec(compile(source, str(helpers / 'prepare-reload-phase-7d.py'), 'exec'))
manifest = json.loads((work / 'manifest.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()

def mark(label, type_expression='scriptType.name', suffix=''):
    return ('System.err.println("[DEBUG-7d-exec] ' + label + ' type=" + ' + type_expression
            + ' + " nano=" + System.nanoTime() + " epoch=" + System.currentTimeMillis()' + suffix + ');')

manager = 'common/src/main/java/com/tkisor/nekojs/script/ScriptManager.java'
executor = 'common/src/main/java/com/tkisor/nekojs/script/ScriptExecutor.java'
for name in (manager, executor):
    path = owned / name
    original = path.read_bytes()
    assert path.resolve().is_relative_to(owned) and not path.is_symlink()
    stored = work / 'original' / name
    stored.parent.mkdir(parents=True, exist_ok=True)
    stored.write_bytes(original)
    text = original.decode('utf-8')
    if name == manager:
        before = '                        pluginRuntime.fireBeforeScriptsLoaded(scriptType);'
        assert text.count(before) == 1
        text = text.replace(before, '                        ' + mark('before-hook-begin') + '\n' + before
                            + '\n                        ' + mark('before-hook-end'))
        before = '                            pluginRuntime.fireAfterScriptsLoaded(scriptType);'
        assert text.count(before) == 1
        text = text.replace(before, '                            ' + mark('after-hook-begin') + '\n' + before
                            + '\n                            ' + mark('after-hook-end'))
        before = '            if (!prepareScriptsForLoad(scriptsToLoad, context)) {'
        assert text.count(before) == 1
        text = text.replace(before, '            ' + mark('preload-begin') + '\n' + before)
        before = '            for (ScriptContainer script : scriptsToLoad) {'
        assert text.count(before) == 1
        text = text.replace(before, '            ' + mark('preload-end') + '\n' + before)
    else:
        entry = '        SyncEvalWatchdog.Guard watchdog = SyncEvalWatchdog.arm(ctx, sandboxConfig.scriptRunawayTimeoutSeconds());'
        assert text.count(entry) == 1
        text = text.replace(entry, '        ' + mark('entry-begin', 'script.type.name', ' + " script=" + script.id') + '\n' + entry)
        validation = '                    validateGlobalBindings(ctx, script, schemaView);'
        assert text.count(validation) == 1
        text = text.replace(validation, '                    ' + mark('validation-begin', 'script.type.name', ' + " script=" + script.id')
                            + '\n' + validation + '\n                    ' + mark('validation-end', 'script.type.name', ' + " script=" + script.id'))
        load = '                    waitForEntryModule(ctx, script, requirePath, nodeRuntime);'
        assert text.count(load) == 1
        text = text.replace(load, '                    ' + mark('module-begin', 'script.type.name', ' + " script=" + script.id')
                            + '\n' + load + '\n                    ' + mark('module-end', 'script.type.name', ' + " script=" + script.id'))
        end = '            watchdog.disarm();'
        assert text.count(end) == 1
        text = text.replace(end, end + '\n            ' + mark('entry-end', 'script.type.name', ' + " script=" + script.id'))
    path.write_bytes(text.encode('utf-8'))
    stored = work / 'instrumented' / name
    stored.parent.mkdir(parents=True, exist_ok=True)
    stored.write_bytes(path.read_bytes())
    manifest['files'][name] = dict(originalSha256=sha(original), instrumentedSha256=sha(path.read_bytes()))
patch = subprocess.check_output(['git', '-C', str(owned), 'diff'])
assert sorted(subprocess.check_output(['git', '-C', str(owned), 'diff', '--name-only'], text=True).splitlines()) == sorted(manifest['files'])
manifest['instrumentationPatchSha256'] = sha(patch)
manifest['scope'] = 'Owned-only execution boundary diagnostic; synchronous observer overhead not quantified; no formal replacement'
(work / 'instrumentation.patch').write_bytes(patch)
(work / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
(work / 'PLAN.md').write_text('''# One predeclared execution boundary diagnostic

Ranked predictions: preload/module preparation dominates; entry validation dominates;
or before/after plugin hooks dominate. Measure successful candidate execution at
those boundaries without disabling or changing any work, fixture, security rule,
original sampler or formal metric. One group, five original indexed reloads,
all initial readiness events and first samples retained. Synchronous output cost
is not quantified; dirty four-file source is diagnostic only. Restore exact
originals after source/patch/owned-process guards. Main production source untouched.
''', encoding='utf-8')
runner = (helpers / 'run-reload-phase-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-phase-7d', 'ticket37-reload-execution-7d')
runner = runner.replace('.Count -ne 2', '.Count -ne 4')
(helpers / 'run-reload-execution-7d.py').write_text(runner, encoding='utf-8')
restore = (helpers / 'restore-reload-phase-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-phase-7d', 'ticket37-reload-execution-7d')
(helpers / 'restore-reload-execution-7d.py').write_text(restore, encoding='utf-8')
print(json.dumps(dict(result='PREPARED', sourceRevision=manifest['sourceRevision'], instrumentationPatchSha256=sha(patch), files=list(manifest['files']))))
