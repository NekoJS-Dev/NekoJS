import hashlib
import json
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
work = project / 'build/ticket37-reload-preparation-7d'
assert not work.exists()
assert json.loads((project / 'build/ticket37-reload-module-7d/restored-source.json').read_text())['sourceRestoredByteEqual']
source = (helpers / 'prepare-reload-module-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-module-7d', 'ticket37-reload-preparation-7d')
exec(compile(source, str(helpers / 'prepare-reload-module-7d.py'), 'exec'))
owned = project / 'build/ticket37-perf-owned-ac810fa7'
manifest = json.loads((work / 'manifest.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
name = 'common/src/main/java/com/tkisor/nekojs/core/module/NekoModulePipelineCache.java'
path = owned / name
assert path.resolve().is_relative_to(owned) and not path.is_symlink()
original = path.read_bytes()
stored = work / 'original' / name
stored.parent.mkdir(parents=True, exist_ok=True)
stored.write_bytes(original)
text = original.decode('utf-8')
def mark(label, expression='path'):
    return ('System.err.println("[DEBUG-7d-cache] ' + label
            + ' type=" + (scriptTypeOf(' + expression + ') == null ? "shared" : scriptTypeOf(' + expression + ').name)'
            + ' + " nano=" + System.nanoTime() + " epoch=" + System.currentTimeMillis() + " path=" + ' + expression + ');')
before = '''    public NekoPreparedModule prepare(Path path) throws IOException {
        ensureOpen();
        Path key = key(path);
        NekoTrustApprovedSource approval = approvedSource(key);
        try {
            SourceSnapshot source = readSource(key);'''
after = '''    public NekoPreparedModule prepare(Path path) throws IOException {
        ''' + mark('cache-begin') + '''
        ensureOpen();
        Path key = key(path);
        ''' + mark('cache-key-end') + '''
        NekoTrustApprovedSource approval = approvedSource(key);
        ''' + mark('cache-approval-end') + '''
        try {
            SourceSnapshot source = readSource(key);
            ''' + mark('cache-read-end')
assert text.count(before) == 1
text = text.replace(before, after)
before = '                    NekoPreparedModule prepared = prepareSource(k, source, approval, bindingSchemaViewFor(k));'
assert text.count(before) == 1
text = text.replace(before, '                    ' + mark('cache-pipeline-begin', 'k') + '\n' + before
                    + '\n                    ' + mark('cache-pipeline-end', 'k'))
before = '            publishSourceMap(key, entry.prepared());'
assert text.count(before) == 1
text = text.replace(before, '            ' + mark('cache-compute-end') + '\n' + before
                    + '\n            ' + mark('cache-publish-end'))
path.write_bytes(text.encode('utf-8'))
stored = work / 'instrumented' / name
stored.parent.mkdir(parents=True, exist_ok=True)
stored.write_bytes(path.read_bytes())
manifest['files'][name] = dict(originalSha256=sha(original), instrumentedSha256=sha(path.read_bytes()))
patch = subprocess.check_output(['git', '-C', str(owned), 'diff'])
assert sorted(subprocess.check_output(['git', '-C', str(owned), 'diff', '--name-only'], text=True).splitlines()) == sorted(manifest['files'])
manifest['instrumentationPatchSha256'] = sha(patch)
manifest['scope'] = 'Owned-only successful module preparation boundary diagnosis; exact six files; synchronous observer cost unquantified'
(work / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
(work / 'instrumentation.patch').write_bytes(patch)
(work / 'PLAN.md').write_text('''# One predeclared preparation boundary diagnostic

Ranked predictions: canonical key/trust checks dominate; source read/stamp dominates;
or compiler/validation/source-map preparation dominates. Measure unchanged work at
those boundaries. One original sampler group of five reloads, all first/readiness
events retained. Exact six-file diagnostic patch only. No caches, work, trust or
path checks removed; no formal replacement. Restore originals after guards.
''', encoding='utf-8')
runner = (helpers / 'run-reload-module-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-module-7d', 'ticket37-reload-preparation-7d').replace('.Count -ne 5', '.Count -ne 6')
(helpers / 'run-reload-preparation-7d.py').write_text(runner, encoding='utf-8')
restore = (helpers / 'restore-reload-module-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-module-7d', 'ticket37-reload-preparation-7d')
(helpers / 'restore-reload-preparation-7d.py').write_text(restore, encoding='utf-8')
print(json.dumps(dict(result='PREPARED_PREPARATION', instrumentationPatchSha256=sha(patch), files=list(manifest['files']))))
