from pathlib import Path

helpers = Path.cwd() / 'build/ticket37-config-sync-repair'
source = (helpers / 'archive-reload-phase-7d.py').read_text(encoding='utf-8')
source = source.replace('ticket37-reload-phase-7d', 'ticket37-reload-preparation-7d')
source = source.replace('phase-summary.json', 'preparation-summary.json').replace('reload-phase-evidence.zip', 'reload-preparation-evidence.zip')
source = source.replace("'com/tkisor/nekojs/core/lifecycle/ReloadProgressTracker'", "'com/tkisor/nekojs/core/lifecycle/ReloadProgressTracker',\n                                'com/tkisor/nekojs/script/ScriptManager', 'com/tkisor/nekojs/script/ScriptExecutor',\n                                'com/tkisor/nekojs/core/module/NekoScriptModuleLoaderHost',\n                                'com/tkisor/nekojs/core/module/NekoModulePipelineCache'")
source = source.replace("'archive-reload-phase-7d.py'):", "'archive-reload-phase-7d.py', 'prepare-reload-execution-7d.py', 'run-reload-execution-7d.py',\n             'read-reload-execution-7d.py', 'restore-reload-execution-7d.py', 'prepare-reload-module-7d.py',\n             'run-reload-module-7d.py', 'read-reload-module-7d.py', 'restore-reload-module-7d.py',\n             'prepare-reload-preparation-7d.py', 'run-reload-preparation-7d.py', 'read-reload-preparation-7d.py',\n             'restore-reload-preparation-7d.py', 'archive-reload-preparation-7d.py'):")
exec(compile(source, str(helpers / 'archive-reload-phase-7d.py'), 'exec'))
