import json
from pathlib import Path

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
work = project / 'build/ticket37-reload-preparation-7d'
source = (helpers / 'read-reload-module-7d.py').read_text(encoding='utf-8').replace('ticket37-reload-module-7d', 'ticket37-reload-preparation-7d')
source = source.replace('DEBUG-7d-(?:phase|exec|module)', 'DEBUG-7d-(?:phase|exec|module|cache)')
exec(compile(source, str(helpers / 'read-reload-module-7d.py'), 'exec'))
summary = json.loads((work / 'module-summary.json').read_text())
for row in summary['reloads']:
    events = row['events']
    detail = {}
    for key, begin, end in [('canonicalKey', 'cache-begin', 'cache-key-end'), ('approval', 'cache-key-end', 'cache-approval-end'),
                           ('readStamp', 'cache-approval-end', 'cache-read-end'), ('pipeline', 'cache-pipeline-begin', 'cache-pipeline-end'),
                           ('publish', 'cache-compute-end', 'cache-publish-end')]:
        starts = [e for e in events if e['phase'] == begin]
        ends = [e for e in events if e['phase'] == end]
        assert len(starts) == len(ends) == 6, (begin, end, starts, ends)
        detail[key] = []
        for start, finish in zip(starts, ends):
            assert start['message'] == finish['message'] and start['nano'] < finish['nano']
            detail[key].append(dict(path=start['message'], ms=(finish['nano']-start['nano'])/1e6,
                                    beginNano=start['nano'], endNano=finish['nano']))
        assert all(a['endNano'] <= b['beginNano'] for a, b in zip(detail[key], detail[key][1:]))
        detail[key + 'Ms'] = sum(span['ms'] for span in detail[key])
    row['preparationBreakdown'] = detail
keys = ('canonicalKeyMs', 'approvalMs', 'readStampMs', 'pipelineMs', 'publishMs')
summary['preparationMeans'] = {key: sum(row['preparationBreakdown'][key] for row in summary['reloads']) / 5 for key in keys}
summary['preparationLimits'] = 'Pipeline includes approval.covers and compiler/source validation. Canonical key, approval and read/stamp remain distinct. Diagnostic output and type classification costs unquantified.'
(work / 'preparation-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(dict(result='PASS', means=summary['means'], moduleMeans=summary['moduleMeans'], preparationMeans=summary['preparationMeans']), indent=2))
