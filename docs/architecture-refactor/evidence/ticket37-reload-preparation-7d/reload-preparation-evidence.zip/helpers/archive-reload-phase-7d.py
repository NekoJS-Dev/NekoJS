import hashlib
import json
import re
import socket
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

project = Path.cwd().resolve()
owned = project / 'build/ticket37-perf-owned-ac810fa7'
work = project / 'build/ticket37-reload-phase-7d'
helpers = project / 'build/ticket37-config-sync-repair'
out = project / 'docs/architecture-refactor/evidence/ticket37-reload-phase-7d'
assert not out.exists()
assert not subprocess.check_output(['git', '-C', str(owned), 'status', '--porcelain'], text=True).strip()
assert subprocess.check_output(['git', '-C', str(owned), 'rev-parse', 'HEAD'], text=True).strip() == '7d77308bfa400721304b20940ada91092180a1ed'
for port in (25871, 25872):
    with socket.socket() as guard: guard.bind(('127.0.0.1', port))
summary = json.loads((work / 'phase-summary.json').read_text())
assert summary['diagnosticOnly'] and not summary['formalReplacement']
assert json.loads((work / 'restored-source.json').read_text())['sourceRestoredByteEqual']
for name in ('runner-exit.json', 'sampler-exit.json', 'before-guard-exit.json', 'after-guard-exit.json'):
    assert json.loads((work / name).read_text())['exitCode'] == 0
sha = lambda data: hashlib.sha256(data).hexdigest()
binding = json.loads((project / 'docs/architecture-refactor/evidence/ticket37-node-assert-repair/runtime-summary.json').read_text())
node = next(row for row in binding['nodes'] if row['node'] == '26.1.2')
changed = []
matched = 0
for name, expected in node['classBindings'].items():
    options = [owned / 'versions/26.1.2/build/classes/java/main' / name, owned / 'common/build/classes/java/main' / name]
    path = next(path for path in options if path.is_file())
    current = sha(path.read_bytes())
    if current != expected:
        assert name.startswith(('com/tkisor/nekojs/core/lifecycle/NekoRuntimeRoot',
                                'com/tkisor/nekojs/core/lifecycle/ReloadProgressTracker')), name
        changed.append(dict(name=name, officialSha256=expected, diagnosticSha256=current))
    else:
        matched += 1
assert changed and matched + len(changed) == 1592
summary['compiledBinding'] = dict(officialJarSha256=node['sha256'], matchedClasses=matched,
                                changedInstrumentedFamilyClasses=changed, officialCertification=False)
summary['sourceRestored'] = json.loads((work / 'restored-source.json').read_text())
files = {}
for path in work.rglob('*'):
    if path.is_file(): files['diagnostic/' + path.relative_to(work).as_posix()] = path.read_bytes()
folder = owned / 'bench/perf/out' / summary['folder']
for path in folder.iterdir():
    if path.is_file() and path.suffix in ('.txt', '.log', '.json', '.jsonl', '.csv'):
        files['samples/' + path.name] = path.read_bytes()
for name in ('prepare-reload-phase-7d.py', 'run-reload-phase-7d.py', 'read-reload-phase-7d.py',
             'restore-reload-phase-7d.py', 'archive-reload-phase-7d.py'):
    files['helpers/' + name] = (helpers / name).read_bytes()
sampler_digest = sha((owned / 'bench/perf/sample.ps1').read_bytes())
assert sampler_digest == '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
files['sampler/binding.json'] = json.dumps(dict(sha256=sampler_digest,
    sourceExcluded='The original benchmark source contains the actual default credential; only its hash is retained')).encode()
secrets = [line.partition('=')[2].encode() for line in (owned / 'versions/26.1.2/run/server.properties').read_text().splitlines()
           if line.startswith('rcon.password=')]
for name, data in files.items():
    checked = data.replace(b'.gradle-perf02', b'[owned-gradle-cache]')
    assert not any(secret and secret in checked for secret in secrets), name
    assert not re.search(rb'(?m)^rcon\.password=', data), name
out.mkdir()
archive = out / 'reload-phase-evidence.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED) as target:
    for name, data in sorted(files.items()): target.writestr(name, data)
summary['archive'] = dict(file=archive.name, entries=len(files), bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()))
summary['entries'] = [dict(name=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(files.items())]
summary['actualCredentialsScan'] = 'PASS'
summary['formalPortsFree'] = [25871, 25872]
summary['overallTickets'] = 'NOT_COMPLETE'
summary['exclusions'] = ['Actual credentials/properties', 'Original sampler source with credential default',
                         'Worlds', 'Binary artifacts', 'Raw JFR', 'Unrelated processes/data']
(out / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(dict(result='PASS', archive=summary['archive'], means=summary['means'], compiledBinding=summary['compiledBinding'])))
