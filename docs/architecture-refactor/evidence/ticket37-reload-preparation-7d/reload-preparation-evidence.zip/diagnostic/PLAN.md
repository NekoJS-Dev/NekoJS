# One predeclared preparation boundary diagnostic

Ranked predictions: canonical key/trust checks dominate; source read/stamp dominates;
or compiler/validation/source-map preparation dominates. Measure unchanged work at
those boundaries. One original sampler group of five reloads, all first/readiness
events retained. Exact six-file diagnostic patch only. No caches, work, trust or
path checks removed; no formal replacement. Restore originals after guards.
