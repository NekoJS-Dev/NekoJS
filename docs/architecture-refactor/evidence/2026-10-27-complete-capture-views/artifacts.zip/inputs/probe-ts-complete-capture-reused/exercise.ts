import type { $ProbeWildcardOptionalCaptureTest$ConstableLike as Parent,
    $ProbeWildcardOptionalCaptureTest$ConstDesc as Bound } from 'java:com/tkisor/nekojs/probe';
import type { $OptionalView } from 'java:java/util';
declare const parent: Parent;
const result: $OptionalView<Bound> = parent.describeConstable();
const present: boolean = result.present;
const label: string = result.filter(value => true).get().label;
// @ts-expect-error The previous snapshot's getter edit must not leak.
const stalePresent: string = result.present;
