import { $Optional } from "java:java/util";

declare module "java:com/tkisor/nekojs/probe" {
    export interface $ProbeWildcardOptionalCaptureTest$ConstableLike {
        describeConstable(): $Optional<$ProbeWildcardOptionalCaptureTest$ConstDesc>;
    }

    export class $ProbeWildcardOptionalCaptureTest$BooleanLike implements $ProbeWildcardOptionalCaptureTest$ConstableLike {
        constructor();
        describeConstable(): $Optional<$ProbeWildcardOptionalCaptureTest$DynamicDesc>;
    }

    export class $ProbeCompleteCaptureViewTest$SameBound implements $ProbeWildcardOptionalCaptureTest$ConstableLike {
        constructor();
        describeConstable(): $Optional<$ProbeWildcardOptionalCaptureTest$ConstDesc>;
    }

    export class $ProbeWildcardOptionalCaptureTest$ConstDesc {
        constructor();
        label: string;
    }

    export class $ProbeWildcardOptionalCaptureTest$DynamicDesc extends $ProbeWildcardOptionalCaptureTest$ConstDesc {
        constructor();
        code: number;
    }

    export type $ProbeWildcardOptionalCaptureTest$ConstableLike_<CallbackResult = $Optional<$ProbeWildcardOptionalCaptureTest$ConstDesc>> = (() => CallbackResult) | ($ProbeWildcardOptionalCaptureTest$ConstableLike & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "describeConstable": () => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
}
