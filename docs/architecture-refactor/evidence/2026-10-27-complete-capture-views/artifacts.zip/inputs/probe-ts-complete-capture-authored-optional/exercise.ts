import type { $ProbeWildcardOptionalCaptureTest$ConstableLike as Parent } from 'java:com/tkisor/nekojs/probe';
declare const parent: Parent;
const authored: string = parent.describeConstable().authoredOnly();
// @ts-expect-error Authored replacements must not regain native members from reflection.
parent.describeConstable().get();
// @ts-expect-error Native Bean aliases must not be restored either.
parent.describeConstable().present;
