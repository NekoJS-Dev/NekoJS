import type { $ProbeWildcardOptionalCaptureTest$ConstableLike as Parent } from 'java:com/tkisor/nekojs/probe';
declare const parent: Parent;
const result = parent.describeConstable();
const kept: string = result.keep(value => true).get().label;
const mapped: boolean = result.map<string>(value => value.label);
const present: string = result.present;
const custom: boolean = result.or('custom');
import type { $ProbeWildcardOptionalCaptureTest$DynamicDesc as Narrow } from 'java:com/tkisor/nekojs/probe';
import type { $Predicate, $BinaryOperator } from 'java:java/util/function';
declare const broadPredicate: $Predicate<import('java:com/tkisor/nekojs/probe').$ProbeWildcardOptionalCaptureTest$ConstDesc>;
result.keep(broadPredicate);
declare const narrowPredicate: $Predicate<Narrow>;
declare const narrowOperator: $BinaryOperator<Narrow>;
result.keep({test: value => true});
// @ts-expect-error A renamed SAM host still needs the complete operand domain.
result.keep(narrowPredicate);
// @ts-expect-error Renamed navigation must not fall back to an unguarded native stream.
result.keep(value => true).stream().reduce(narrowOperator);
const inherited: string = result.stream().findFirst().get().label;
// @ts-expect-error Renamed methods must not be restored from reflection.
result.filter(() => true);
// @ts-expect-error Hidden overloads must not be restored from reflection.
result.orElseThrow();
// @ts-expect-error The edited return is boolean, not a generated optional view.
result.map<string>(value => value.label).get();
// @ts-expect-error The edited Bean property keeps its authored read type.
const wrongPresent: boolean = result.present;
// @ts-expect-error Hidden Stream methods must not be regenerated.
result.stream().toList();
