import type {
    $ProbeWildcardOptionalCaptureTest$ConstableLike as ConstableLike,
    $ProbeWildcardOptionalCaptureTest$ConstDesc as ConstDesc,
    $ProbeWildcardOptionalCaptureTest$DynamicDesc as DynamicDesc,
    $ProbeWildcardOptionalCaptureTest$BooleanLike,
} from 'java:com/tkisor/nekojs/probe';
import type { $Optional, $OptionalView } from 'java:java/util';
import type { $Predicate_, $Supplier_ } from 'java:java/util/function';

declare const impl: $ProbeWildcardOptionalCaptureTest$BooleanLike;

// The Java-legal covariant override stays assignable to the interface.
const asInterface: ConstableLike = impl;

// The interface result keeps the upper bound through the capture view.
const captureResult = asInterface.describeConstable();
const explicit: $OptionalView<ConstDesc> = captureResult;
const upper: ConstDesc = captureResult.get();
const label: string = upper.label;
// @ts-expect-error The upper-bound view does not expose the narrow member.
upper.code;
// @ts-expect-error A wrong element kind cannot satisfy the bound.
const wrongElement: number = captureResult.get();

// The public instance surface of Optional stays available on the capture view.
const thrown: ConstDesc = captureResult.orElseThrow();
const present: boolean = captureResult.present;
const empty: boolean = captureResult.empty;
const filtered = captureResult.filter(() => true);
const orElse: ConstDesc = captureResult.orElse(upper);
// The SAM alias union does not infer method type variables from callback results (the
// concrete $Optional surface has the same limitation), so pass them explicitly.
const mapped = captureResult.map<string>((d: ConstDesc) => d.label);
const mappedLabel: string = mapped.get();
declare const otherOpt: $Optional<ConstDesc>;
const flatMapped = captureResult.flatMap<ConstDesc>((d: ConstDesc): $Optional<ConstDesc> => otherOpt);
const flatValue: ConstDesc = flatMapped.get();

// stream() navigation recurses through the terminal optionals.
const counted: number = captureResult.stream().findAny().stream().count();
const deep: ConstDesc = captureResult.stream().findAny().stream().findFirst().get();
const chained = captureResult.stream().filter(() => true).map((d: ConstDesc) => d.label).count();
const listed: ConstDesc = captureResult.stream().iterator().next();
const maxed = captureResult.stream().max(null as never);

// Existing overloads and method-local inference remain available.
const natural = captureResult.stream().sorted().count();
const ordered = captureResult.stream().sorted((a: ConstDesc, b: ConstDesc): number => 0).count();
const reduced: number = captureResult.stream().reduce(
    0, (u: number, d: ConstDesc): number => u, (x: number, y: number): number => x);
const collected: string[] = captureResult.stream().collect(
    (): string[] => [], (acc: string[], d: ConstDesc): void => {}, (a: string[], b: string[]): void => {});
const split = captureResult.stream().spliterator();

const fallback: ConstDesc = captureResult.or(() => otherOpt).get();
const reducedElement: ConstDesc = captureResult.stream().reduce((a: ConstDesc, b: ConstDesc): ConstDesc => a).get();
const reducedSeed: ConstDesc = captureResult.stream().reduce(upper, (a: ConstDesc, b: ConstDesc): ConstDesc => a);
const listElement: ConstDesc = captureResult.stream().toList().get(0);

// The concrete implementation view keeps its narrow result and full container surface.
const narrow: DynamicDesc = impl.describeConstable().get();
const code: number = narrow.code;
declare const goodSupplier: $Supplier_<$Optional<DynamicDesc>, $Optional<DynamicDesc>>;
const supplied: $Optional<DynamicDesc> = impl.describeConstable().or(goodSupplier);
declare const goodPredicate: $Predicate_<DynamicDesc, DynamicDesc, boolean>;
const implFiltered: $Optional<DynamicDesc> = impl.describeConstable().filter(goodPredicate);
declare const badSupplier: $Supplier_<$Optional<string>, $Optional<string>>;
// @ts-expect-error An unrelated supplier payload is rejected.
impl.describeConstable().or(badSupplier);
// The converted-callable branch deliberately accepts any host element; the callback
// result kind stays checked.
declare const badPredicate: $Predicate_<ConstDesc, ConstDesc, string>;
// @ts-expect-error A predicate returning the wrong kind is rejected.
impl.describeConstable().filter(badPredicate);
