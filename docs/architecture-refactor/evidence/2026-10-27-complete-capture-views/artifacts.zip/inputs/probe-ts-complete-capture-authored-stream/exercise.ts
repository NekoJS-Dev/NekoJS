import type { $ProbeWildcardOptionalCaptureTest$ConstableLike as Parent } from 'java:com/tkisor/nekojs/probe';
declare const parent: Parent;
const authored: string = parent.describeConstable().stream().authoredStream();
// @ts-expect-error Authored Stream replacements retain their own public surface.
parent.describeConstable().stream().count();
