import { $Codec } from "java:com/mojang/serialization";
import { $Byte, $Record, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Rotations } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener, $ClientboundAddEntityPacket } from "java:net/minecraft/network/protocol/game";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerEntity, $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Avatar, $Entity, $EntityDimensions, $EntityType, $EntityType_, $EquipmentSlot, $EquipmentSlot_, $HumanoidArm, $HumanoidArm_, $Leashable, $LightningBolt, $LivingEntity, $LivingEntity$Fallsounds, $MoverType, $MoverType_, $Pose, $Pose_, $SlotAccess } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ResolvableProfile } from "java:net/minecraft/world/item/component";
import { $Explosion, $Level } from "java:net/minecraft/world/level";
import { $Mirror, $Mirror_, $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $PushReaction, $PushReaction_ } from "java:net/minecraft/world/level/material";
import { $MapId } from "java:net/minecraft/world/level/saveddata/maps";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as painting from "java:net/minecraft/world/entity/decoration/painting";

declare module "java:net/minecraft/world/entity/decoration" {
    export class $ArmorStand extends $LivingEntity {
        constructor(type: $EntityType<$ArmorStand>, level: $Level);
        constructor(level: $Level, x: number, y: number, z: number);
        static CLIENT_FLAG_MARKER: number;
        static CLIENT_FLAG_NO_BASEPLATE: number;
        static CLIENT_FLAG_SHOW_ARMS: number;
        static CLIENT_FLAG_SMALL: number;
        static DATA_BODY_POSE: $EntityDataAccessor<$Rotations>;
        static DATA_CLIENT_FLAGS: $EntityDataAccessor<number>;
        static DATA_HEAD_POSE: $EntityDataAccessor<$Rotations>;
        static DATA_LEFT_ARM_POSE: $EntityDataAccessor<$Rotations>;
        static DATA_LEFT_LEG_POSE: $EntityDataAccessor<$Rotations>;
        static DATA_RIGHT_ARM_POSE: $EntityDataAccessor<$Rotations>;
        static DATA_RIGHT_LEG_POSE: $EntityDataAccessor<$Rotations>;
        static DEFAULT_BODY_POSE: $Rotations;
        static DEFAULT_HEAD_POSE: $Rotations;
        static DEFAULT_LEFT_ARM_POSE: $Rotations;
        static DEFAULT_LEFT_LEG_POSE: $Rotations;
        static DEFAULT_RIGHT_ARM_POSE: $Rotations;
        static DEFAULT_RIGHT_LEG_POSE: $Rotations;
        static DISABLE_PUTTING_OFFSET: number;
        static DISABLE_TAKING_OFFSET: number;
        static WOBBLE_TIME: number;
        lastHit: number;
        get armorStandPose(): $ArmorStand$ArmorStandPose;
        getArmorStandPose(): $ArmorStand$ArmorStandPose;
        set armorStandPose(value: $ArmorStand$ArmorStandPose);
        get bodyPose(): $Rotations;
        getBodyPose(): $Rotations;
        set bodyPose(value: $Rotations);
        get fallSounds(): $LivingEntity$Fallsounds;
        getFallSounds(): $LivingEntity$Fallsounds;
        get headPose(): $Rotations;
        getHeadPose(): $Rotations;
        set headPose(value: $Rotations);
        get leftArmPose(): $Rotations;
        getLeftArmPose(): $Rotations;
        set leftArmPose(value: $Rotations);
        get leftLegPose(): $Rotations;
        getLeftLegPose(): $Rotations;
        set leftLegPose(value: $Rotations);
        get mainArm(): $HumanoidArm;
        getMainArm(): $HumanoidArm;
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        get pistonPushReaction(): $PushReaction;
        getPistonPushReaction(): $PushReaction;
        get rightArmPose(): $Rotations;
        getRightArmPose(): $Rotations;
        set rightArmPose(value: $Rotations);
        get rightLegPose(): $Rotations;
        getRightLegPose(): $Rotations;
        set rightLegPose(value: $Rotations);
        get affectedByPotions(): boolean;
        isAffectedByPotions(): boolean;
        get baby(): boolean;
        isBaby(): boolean;
        get effectiveAi(): boolean;
        isEffectiveAi(): boolean;
        get ignoringBlockTriggers(): boolean;
        isIgnoringBlockTriggers(): boolean;
        get marker(): boolean;
        isMarker(): boolean;
        get pickable(): boolean;
        isPickable(): boolean;
        get pushable(): boolean;
        isPushable(): boolean;
        get small(): boolean;
        isSmall(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        attackable(): boolean;
        canBeSeenByAnyone(): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getLightProbePosition(partialTickTime: number): $Vec3;
        handleEntityEvent(id: number): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        ignoreExplosion(explosion: $Explosion): boolean;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        kill(level: $ServerLevel): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        refreshDimensions(): void;
        shouldRenderAtSqrDistance(distance: number): boolean;
        showArms(): boolean;
        showBasePlate(): boolean;
        skipAttackInteraction(source: $Entity): boolean;
        thunderHit(level: $ServerLevel, lightningBolt: $LightningBolt): void;
        travel(input: $Vec3_): void;
    }

    export class $ArmorStand$ArmorStandPose extends $Record {
        constructor(head: $Rotations, body: $Rotations, leftArm: $Rotations, rightArm: $Rotations, leftLeg: $Rotations, rightLeg: $Rotations);
        static CODEC: $Codec<$ArmorStand$ArmorStandPose>;
        static DEFAULT: $ArmorStand$ArmorStandPose;
        body(): $Rotations;
        equals(o: object): boolean;
        hashCode(): number;
        head(): $Rotations;
        leftArm(): $Rotations;
        leftLeg(): $Rotations;
        rightArm(): $Rotations;
        rightLeg(): $Rotations;
        toString(): string;
    }

    export class $BlockAttachedEntity extends $Entity {
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get pickable(): boolean;
        isPickable(): boolean;
        dropItem(level: $ServerLevel, causedBy: $Entity): void;
        hurtClient(source: $DamageSource): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        ignoreExplosion(explosion: $Explosion): boolean;
        move(moverType: $MoverType_, delta: $Vec3_): void;
        push(xa: number, ya: number, za: number): void;
        refreshDimensions(): void;
        setPos(x: number, y: number, z: number): void;
        skipAttackInteraction(source: $Entity): boolean;
        survives(): boolean;
        thunderHit(level: $ServerLevel, lightningBolt: $LightningBolt): void;
        tick(): void;
    }

    export class $GlowItemFrame extends $ItemFrame {
        constructor(type: $EntityType<$ItemFrame>, level: $Level);
        constructor(level: $Level, pos: $BlockPos_, direction: $Direction_);
        get addItemSound(): $SoundEvent;
        getAddItemSound(): $SoundEvent;
        get breakSound(): $SoundEvent;
        getBreakSound(): $SoundEvent;
        get placeSound(): $SoundEvent;
        getPlaceSound(): $SoundEvent;
        get removeItemSound(): $SoundEvent;
        getRemoveItemSound(): $SoundEvent;
        get rotateItemSound(): $SoundEvent;
        getRotateItemSound(): $SoundEvent;
    }

    export class $HangingEntity extends $BlockAttachedEntity {
        get direction(): $Direction;
        getDirection(): $Direction;
        mirror(mirror: $Mirror_): number;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playPlacementSound(): void;
        rotate(rotation: $Rotation_): number;
        spawnAtLocation(level: $ServerLevel, itemStack: $ItemStack_, yOffs: number): $ItemEntity;
        survives(): boolean;
    }

    export class $ItemFrame extends $HangingEntity {
        constructor(type: $EntityType<$ItemFrame>, level: $Level);
        constructor(type: $EntityType<$ItemFrame>, level: $Level, pos: $BlockPos_, direction: $Direction_);
        constructor(level: $Level, pos: $BlockPos_, direction: $Direction_);
        static NUM_ROTATIONS: number;
        get addItemSound(): $SoundEvent;
        getAddItemSound(): $SoundEvent;
        get analogOutput(): number;
        getAnalogOutput(): number;
        get breakSound(): $SoundEvent;
        getBreakSound(): $SoundEvent;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        set item(value: $ItemStack_);
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        get placeSound(): $SoundEvent;
        getPlaceSound(): $SoundEvent;
        get removeItemSound(): $SoundEvent;
        getRemoveItemSound(): $SoundEvent;
        get rotateItemSound(): $SoundEvent;
        getRotateItemSound(): $SoundEvent;
        get rotation(): number;
        getRotation(): number;
        set rotation(value: number);
        get visualRotationYInDegrees(): number;
        getVisualRotationYInDegrees(): number;
        dropItem(level: $ServerLevel, causedBy: $Entity): void;
        getAddEntityPacket(serverEntity: $ServerEntity): $Packet<$ClientGamePacketListener>;
        getFramedMapId(itemStack: $ItemStack_): $MapId;
        getSlot(slot: number): $SlotAccess;
        hasFramedMap(): boolean;
        hurtClient(source: $DamageSource): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        kill(level: $ServerLevel): void;
        move(moverType: $MoverType_, delta: $Vec3_): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playPlacementSound(): void;
        push(xa: number, ya: number, za: number): void;
        recreateFromPacket(packet: $ClientboundAddEntityPacket): void;
        setItem(itemStack: $ItemStack_, updateNeighbours: boolean): void;
        shouldRenderAtSqrDistance(distance: number): boolean;
        survives(): boolean;
    }

    export class $LeashFenceKnotEntity extends $BlockAttachedEntity {
        constructor(type: $EntityType<$LeashFenceKnotEntity>, level: $Level);
        constructor(level: $Level, pos: $BlockPos_);
        static OFFSET_Y: number;
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        static createKnot(level: $Level, pos: $BlockPos_): $LeashFenceKnotEntity;
        static getKnot(level: $Level, pos: $BlockPos_): $Optional<$LeashFenceKnotEntity>;
        static getOrCreateKnot(level: $Level, pos: $BlockPos_): $LeashFenceKnotEntity;
        dropItem(level: $ServerLevel, causedBy: $Entity): void;
        getAddEntityPacket(serverEntity: $ServerEntity): $Packet<$ClientGamePacketListener>;
        getRopeHoldPosition(partialTickTime: number): $Vec3;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        notifyLeasheeRemoved(entity: $Leashable): void;
        playPlacementSound(): void;
        shouldRenderAtSqrDistance(distance: number): boolean;
        survives(): boolean;
    }

    export class $Mannequin extends $Avatar {
        constructor(type: $EntityType<$Mannequin>, level: $Level);
        static DEFAULT_PROFILE: $ResolvableProfile;
        static POSE_CODEC: $Codec<$Pose>;
        get profile(): $ResolvableProfile;
        getProfile(): $ResolvableProfile;
        get effectiveAi(): boolean;
        isEffectiveAi(): boolean;
        static create(type: $EntityType<$Mannequin>, level: $Level): $Mannequin;
        aiStep(): void;
        get<T>(type: $DataComponentType<T>): T;
    }

}
