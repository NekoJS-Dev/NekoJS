import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $AgeableMob, $EntityDimensions, $EntityReference, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity, $NeutralMob, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/polarbear" {
    export class $PolarBear extends $Animal implements $NeutralMob {
        constructor(type: $EntityType<$PolarBear>, level: $Level);
        get persistentAngerEndTime(): number;
        getPersistentAngerEndTime(): number;
        set persistentAngerEndTime(value: number);
        get persistentAngerTarget(): $EntityReference<$LivingEntity>;
        getPersistentAngerTarget(): $EntityReference<$LivingEntity>;
        set persistentAngerTarget(value: $EntityReference<$LivingEntity>);
        get standing(): boolean;
        isStanding(): boolean;
        set standing(value: boolean);
        static checkPolarBearSpawnRules(type: $EntityType<$PolarBear>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getStandingAnimationScale(a: number): number;
        isFood(itemStack: $ItemStack_): boolean;
        startPersistentAngerTimer(): void;
        tick(): void;
    }

}
