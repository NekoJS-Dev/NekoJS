import { $Codec } from "java:com/mojang/serialization";
import { $Boolean, $Enum, $Float, $Integer, $String } from "java:java/lang";
import { $Map } from "java:java/util";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $EnvironmentAttribute, $LerpFunction } from "java:net/minecraft/world/attribute";

declare module "java:net/minecraft/world/attribute/modifier" {
    export interface $AttributeModifier<Subject, Argument> {
        apply(subject: Subject, argument: Argument): Subject;
        argumentCodec(attribute: $EnvironmentAttribute<Subject>): $Codec<Argument>;
        argumentKeyframeLerp(attribute: $EnvironmentAttribute<Subject>): $LerpFunction<Argument>;
        override<Value>(): $AttributeModifier<Value, Value>;
        static ARGB_COLOR_LIBRARY: $Map<$AttributeModifier$OperationId, $AttributeModifier<number, any>>;
        static BOOLEAN_LIBRARY: $Map<$AttributeModifier$OperationId, $AttributeModifier<boolean, any>>;
        static FLOAT_LIBRARY: $Map<$AttributeModifier$OperationId, $AttributeModifier<number, any>>;
        static INTEGER_LIBRARY: $Map<$AttributeModifier$OperationId, $AttributeModifier<number, any>>;
        static RGB_COLOR_LIBRARY: $Map<$AttributeModifier$OperationId, $AttributeModifier<number, any>>;
    }

    export class $AttributeModifier$OperationId {
        static ADD: $AttributeModifier$OperationId;
        static ALPHA_BLEND: $AttributeModifier$OperationId;
        static AND: $AttributeModifier$OperationId;
        static BLEND_TO_GRAY: $AttributeModifier$OperationId;
        static MAXIMUM: $AttributeModifier$OperationId;
        static MINIMUM: $AttributeModifier$OperationId;
        static MULTIPLY: $AttributeModifier$OperationId;
        static NAND: $AttributeModifier$OperationId;
        static NOR: $AttributeModifier$OperationId;
        static OR: $AttributeModifier$OperationId;
        static OVERRIDE: $AttributeModifier$OperationId;
        static SUBTRACT: $AttributeModifier$OperationId;
        static XNOR: $AttributeModifier$OperationId;
        static XOR: $AttributeModifier$OperationId;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AttributeModifier$OperationId[];
        static valueOf(name: string): $AttributeModifier$OperationId;
    }

    export type $AttributeModifier$OperationId_ = $AttributeModifier$OperationId | "ADD" | "ALPHA_BLEND" | "AND" | "BLEND_TO_GRAY" | "MAXIMUM" | "MINIMUM" | "MULTIPLY" | "NAND" | "NOR" | "OR" | "OVERRIDE" | "SUBTRACT" | "XNOR" | "XOR";
}
