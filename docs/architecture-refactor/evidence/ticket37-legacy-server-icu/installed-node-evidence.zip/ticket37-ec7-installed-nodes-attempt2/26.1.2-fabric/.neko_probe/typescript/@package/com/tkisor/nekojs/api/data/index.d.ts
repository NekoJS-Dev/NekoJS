import { $Record, $String } from "java:java/lang";
import { $HashMap } from "java:java/util";

declare module "java:com/tkisor/nekojs/api/data" {
    export class $AttachedData<T> extends $HashMap {
        constructor(parent: T);
        get parent(): T;
        getParent(): T;
        add(key: string, data: object): void;
    }

    export class $NekoId extends $Record {
        constructor(namespace: string, path: string);
        static DEFAULT_NAMESPACE: string;
        get namespace(): string;
        getNamespace(): string;
        get path(): string;
        getPath(): string;
        static of(namespace: string, path: string): $NekoId;
        static of(value: string): $NekoId;
        asString(): string;
        equals(o: object): boolean;
        hashCode(): number;
        namespace(): string;
        path(): string;
        toString(): string;
    }

}
