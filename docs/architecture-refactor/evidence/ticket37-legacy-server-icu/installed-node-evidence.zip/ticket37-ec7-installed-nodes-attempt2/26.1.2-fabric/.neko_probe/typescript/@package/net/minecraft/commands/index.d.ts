import { $CharMatcher } from "java:com/google/common/base";
import { $CommandDispatcher, $Message, $ParseResults, $ResultConsumer, $StringReader } from "java:com/mojang/brigadier";
import { $ArgumentType } from "java:com/mojang/brigadier/arguments";
import { $LiteralArgumentBuilder, $RequiredArgumentBuilder } from "java:com/mojang/brigadier/builder";
import { $CommandContext } from "java:com/mojang/brigadier/context";
import { $CommandExceptionType, $CommandSyntaxException, $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Suggestions, $SuggestionsBuilder } from "java:com/mojang/brigadier/suggestion";
import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Iterable, $String } from "java:java/lang";
import { $Collection, $Optional, $Set, $UUID } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $BinaryOperator, $Consumer, $Function, $Predicate, $Supplier, $UnaryOperator } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $PermissionContext, $PermissionContext$Type, $PermissionContextOwner } from "java:net/fabricmc/fabric/api/permission/v1";
import { $CommandPermissionContext$Extension } from "java:net/fabricmc/fabric/impl/permission";
import { $EntityAnchorArgument$Anchor, $EntityAnchorArgument$Anchor_ } from "java:net/minecraft/commands/arguments";
import { $ExecutionContext, $TraceCallbacks } from "java:net/minecraft/commands/execution";
import { $CommandFunction } from "java:net/minecraft/commands/functions";
import { $HolderLookup, $HolderLookup$Provider, $RegistryAccess } from "java:net/minecraft/core";
import { $ChatType$Bound, $Component, $Component_, $OutgoingChatMessage, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer, $ServerFunctionManager } from "java:net/minecraft/server";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $PermissionCheck, $PermissionProviderCheck, $PermissionSet, $PermissionSetSupplier } from "java:net/minecraft/server/permissions";
import { $TaskChainer } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Level } from "java:net/minecraft/world/level";
import { $Vec2, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as arguments from "java:net/minecraft/commands/arguments";
export * as execution from "java:net/minecraft/commands/execution";
export * as functions from "java:net/minecraft/commands/functions";

declare module "java:net/minecraft/commands" {
    export class $CacheableFunction {
        constructor(id: $Identifier_);
        static CODEC: $Codec<$CacheableFunction>;
        get id(): $Identifier;
        getId(): $Identifier;
        equals(obj: object): boolean;
        get(manager: $ServerFunctionManager): $Optional<$CommandFunction<$CommandSourceStack>>;
    }

    export interface $CommandBuildContext extends $HolderLookup$Provider {
        enabledFeatures(): $FeatureFlagSet;
        simple(access: $HolderLookup$Provider, enabledFeatures: $FeatureFlagSet): $CommandBuildContext;
    }

    export interface $CommandResultCallback {
        chain(first: $CommandResultCallback, second: $CommandResultCallback): $CommandResultCallback;
        onFailure(): void;
        onResult(success: boolean, result: number): void;
        onSuccess(result: number): void;
        static EMPTY: $CommandResultCallback;
    }

    export interface $CommandSigningContext {
        getArgument(name: string): $PlayerChatMessage;
        static ANONYMOUS: $CommandSigningContext;
    }

    export interface $CommandSource {
        acceptsFailure(): boolean;
        acceptsSuccess(): boolean;
        alwaysAccepts(): boolean;
        sendSystemMessage(message: $Component_): void;
        shouldInformAdmins(): boolean;
        static NULL: $CommandSource;
    }

    export class $CommandSourceStack implements $SharedSuggestionProvider, $ExecutionCommandSource, $PermissionContextOwner, $CommandPermissionContext$Extension {
        constructor(source: $CommandSource, position: $Vec3_, rotation: $Vec2, level: $ServerLevel, permissions: $PermissionSet, textName: string, displayName: $Component_, server: $MinecraftServer, entity: $Entity);
        static ERROR_NOT_ENTITY: $SimpleCommandExceptionType;
        static ERROR_NOT_PLAYER: $SimpleCommandExceptionType;
        get allTeams(): $Collection<string>;
        getAllTeams(): $Collection<string>;
        get anchor(): $EntityAnchorArgument$Anchor;
        getAnchor(): $EntityAnchorArgument$Anchor;
        get availableSounds(): $Stream<$Identifier>;
        getAvailableSounds(): $Stream<$Identifier>;
        get chatMessageChainer(): $TaskChainer;
        getChatMessageChainer(): $TaskChainer;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get entityOrException(): $Entity;
        getEntityOrException(): $Entity;
        get entity(): $Entity;
        getEntity(): $Entity;
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
        get onlinePlayerNames(): $Collection<string>;
        getOnlinePlayerNames(): $Collection<string>;
        get permissionContext(): $PermissionContext;
        getPermissionContext(): $PermissionContext;
        get playerOrException(): $ServerPlayer;
        getPlayerOrException(): $ServerPlayer;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get position(): $Vec3;
        getPosition(): $Vec3;
        get rotation(): $Vec2;
        getRotation(): $Vec2;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get signingContext(): $CommandSigningContext;
        getSigningContext(): $CommandSigningContext;
        get textName(): string;
        getTextName(): string;
        get silent(): boolean;
        isSilent(): boolean;
        callback(): $CommandResultCallback;
        customSuggestion(context: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        enabledFeatures(): $FeatureFlagSet;
        fabric_getType(): $PermissionContext$Type;
        fabric_getUuid(): $UUID;
        facing(entity: $Entity, anchor: $EntityAnchorArgument$Anchor_): $CommandSourceStack;
        facing(pos: $Vec3_): $CommandSourceStack;
        handleError(type: $CommandExceptionType, message: $Message, forked: boolean, tracer: $TraceCallbacks): void;
        levels(): $Set<$ResourceKey<$Level>>;
        permissions(): $PermissionSet;
        registryAccess(): $RegistryAccess;
        sendChatMessage(message: $OutgoingChatMessage, filtered: boolean, chatType: $ChatType$Bound): void;
        sendFailure(message: $Component_): void;
        sendSuccess(messageSupplier: $Supplier<$Component_>, broadcast: boolean): void;
        sendSystemMessage(message: $Component_): void;
        shouldFilterMessageTo(receiver: $ServerPlayer): boolean;
        suggestRegistryElements(key: $ResourceKey<$Registry<any>>, elements: $SharedSuggestionProvider$ElementSuggestionType_, builder: $SuggestionsBuilder, context: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        withAnchor(anchor: $EntityAnchorArgument$Anchor_): $CommandSourceStack;
        withCallback(newCallback: $CommandResultCallback, combiner: $BinaryOperator<$CommandResultCallback>): $CommandSourceStack;
        withCallback(resultCallback: $CommandResultCallback): $CommandSourceStack;
        withEntity(entity: $Entity): $CommandSourceStack;
        withLevel(level: $ServerLevel): $CommandSourceStack;
        withMaximumPermission(newPermissions: $PermissionSet): $CommandSourceStack;
        withPermission(permissions: $PermissionSet): $CommandSourceStack;
        withPosition(pos: $Vec3_): $CommandSourceStack;
        withRotation(rotation: $Vec2): $CommandSourceStack;
        withSigningContext(signingContext: $CommandSigningContext, chatMessageChainer: $TaskChainer): $CommandSourceStack;
        withSource(source: $CommandSource): $CommandSourceStack;
        withSuppressedOutput(): $CommandSourceStack;
    }

    export class $Commands {
        constructor(commandSelection: $Commands$CommandSelection_, context: $CommandBuildContext);
        static COMMAND_PREFIX: string;
        static LEVEL_ADMINS: $PermissionCheck;
        static LEVEL_ALL: $PermissionCheck;
        static LEVEL_GAMEMASTERS: $PermissionCheck;
        static LEVEL_MODERATORS: $PermissionCheck;
        static LEVEL_OWNERS: $PermissionCheck;
        get dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        getDispatcher(): $CommandDispatcher<$CommandSourceStack>;
        static argument<T>(name: string, type: $ArgumentType<T>): $RequiredArgumentBuilder<$CommandSourceStack, T>;
        static createCompilationContext(compilationPermissions: $PermissionSet): $CommandSourceStack;
        static createValidationContext(registries: $HolderLookup$Provider): $CommandBuildContext;
        static createValidator(parser: $Commands$ParseFunction): $Predicate<string>;
        static executeCommandInContext(context: $CommandSourceStack, config: $Consumer<$ExecutionContext<$CommandSourceStack>>): void;
        static getParseException<S>(parse: $ParseResults<S>): $CommandSyntaxException;
        static hasPermission<T>(permission: $PermissionCheck): $PermissionProviderCheck<T>;
        static literal(literal: string): $LiteralArgumentBuilder<$CommandSourceStack>;
        static mapSource<S>(parse: $ParseResults<S>, sourceOperator: $UnaryOperator<S>): $ParseResults<S>;
        static trimOptionalPrefix(command: string): string;
        static validateParseResults<S>(command: $ParseResults<S>): void;
        static validate(): void;
        performCommand(command: $ParseResults<$CommandSourceStack>, commandString: string): void;
        performPrefixedCommand(sender: $CommandSourceStack, command: string): void;
        sendCommands(player: $ServerPlayer): void;
    }

    export class $Commands$CommandSelection {
        static ALL: $Commands$CommandSelection;
        static DEDICATED: $Commands$CommandSelection;
        static INTEGRATED: $Commands$CommandSelection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Commands$CommandSelection[];
        static valueOf(name: string): $Commands$CommandSelection;
    }

    export interface $Commands$ParseFunction {
        parse(value: $StringReader): void;
    }

    export interface $ExecutionCommandSource<T extends $ExecutionCommandSource<T>> extends $PermissionSetSupplier {
        callback(): $CommandResultCallback;
        clearCallbacks(): T;
        dispatcher(): $CommandDispatcher<T>;
        handleError(type: $CommandExceptionType, message: $Message, forked: boolean, tracer: $TraceCallbacks): void;
        handleError(e: $CommandSyntaxException, forked: boolean, tracer: $TraceCallbacks): void;
        isSilent(): boolean;
        resultConsumer<T>(): $ResultConsumer<T>;
        withCallback(resultCallback: $CommandResultCallback): T;
    }

    export interface $SharedSuggestionProvider extends $PermissionSetSupplier {
        customSuggestion(context: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        enabledFeatures(): $FeatureFlagSet;
        filterResources<T>(values: $Iterable<T>, contents: string, prefix: string, converter: $Function<T, $Identifier_>, consumer: $Consumer<T>): void;
        filterResources<T>(values: $Iterable<T>, contents: string, converter: $Function<T, $Identifier_>, consumer: $Consumer<T>): void;
        getAbsoluteCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        getAllTeams(): $Collection<string>;
        getAvailableSounds(): $Stream<$Identifier>;
        getCustomTabSuggestions(): $Collection<string>;
        getOnlinePlayerNames(): $Collection<string>;
        getRelevantCoordinates(): $Collection<$SharedSuggestionProvider$TextCoordinates>;
        getSelectedEntities(): $Collection<string>;
        levels(): $Set<$ResourceKey<$Level>>;
        listSuggestions<S>(context: $CommandContext<S>, builder: $SuggestionsBuilder, registryKey: $ResourceKey<$Registry<any>>, type: $SharedSuggestionProvider$ElementSuggestionType_): $CompletableFuture<$Suggestions>;
        matchesSubStr(pattern: string, input: string): boolean;
        registryAccess(): $RegistryAccess;
        suggest2DCoordinates(currentInput: string, allSuggestions: $SharedSuggestionProvider$TextCoordinates[], builder: $SuggestionsBuilder, validator: $Predicate<string>): $CompletableFuture<$Suggestions>;
        suggestCoordinates(currentInput: string, allSuggestions: $SharedSuggestionProvider$TextCoordinates[], builder: $SuggestionsBuilder, validator: $Predicate<string>): $CompletableFuture<$Suggestions>;
        suggestRegistryElements(registry: $HolderLookup<any>, elements: $SharedSuggestionProvider$ElementSuggestionType_, builder: $SuggestionsBuilder): void;
        suggestRegistryElements(key: $ResourceKey<$Registry<any>>, elements: $SharedSuggestionProvider$ElementSuggestionType_, builder: $SuggestionsBuilder, context: $CommandContext<any>): $CompletableFuture<$Suggestions>;
        suggestResource<T>(values: $Iterable<T>, builder: $SuggestionsBuilder, id: $Function<T, $Identifier_>, tooltip: $Function<T, $Message>): $CompletableFuture<$Suggestions>;
        suggestResource(values: $Iterable<$Identifier_>, builder: $SuggestionsBuilder, prefix: string): $CompletableFuture<$Suggestions>;
        suggestResource(values: $Iterable<$Identifier_>, builder: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggestResource<T>(values: $Stream<T>, builder: $SuggestionsBuilder, id: $Function<T, $Identifier_>, tooltip: $Function<T, $Message>): $CompletableFuture<$Suggestions>;
        suggestResource(values: $Stream<$Identifier_>, builder: $SuggestionsBuilder, prefix: string): $CompletableFuture<$Suggestions>;
        suggestResource(values: $Stream<$Identifier_>, builder: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest<T>(values: $Iterable<T>, builder: $SuggestionsBuilder, toString: $Function<T, string>, tooltip: $Function<T, $Message>): $CompletableFuture<$Suggestions>;
        suggest(values: $Iterable<string>, builder: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest(values: string[], builder: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        suggest(values: $Stream<string>, builder: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        static MATCH_SPLITTER: $CharMatcher;
    }

    export class $SharedSuggestionProvider$ElementSuggestionType {
        static ALL: $SharedSuggestionProvider$ElementSuggestionType;
        static ELEMENTS: $SharedSuggestionProvider$ElementSuggestionType;
        static TAGS: $SharedSuggestionProvider$ElementSuggestionType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SharedSuggestionProvider$ElementSuggestionType[];
        static valueOf(name: string): $SharedSuggestionProvider$ElementSuggestionType;
    }

    export class $SharedSuggestionProvider$TextCoordinates {
        constructor(x: string, y: string, z: string);
        static DEFAULT_GLOBAL: $SharedSuggestionProvider$TextCoordinates;
        static DEFAULT_LOCAL: $SharedSuggestionProvider$TextCoordinates;
        x: string;
        y: string;
        z: string;
    }

    export type $Commands$CommandSelection_ = $Commands$CommandSelection | "ALL" | "DEDICATED" | "INTEGRATED";
    export type $SharedSuggestionProvider$ElementSuggestionType_ = $SharedSuggestionProvider$ElementSuggestionType | "ALL" | "ELEMENTS" | "TAGS";
}
