import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Holder, $Holder_, $Registry } from "java:net/minecraft/core";
import { $BootstrapContext } from "java:net/minecraft/data/worldgen";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $Entity, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FireworkRocketEntity } from "java:net/minecraft/world/entity/projectile";
import { $AbstractArrow } from "java:net/minecraft/world/entity/projectile/arrow";
import { $Fireball, $WitherSkull } from "java:net/minecraft/world/entity/projectile/hurtingprojectile";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Explosion } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/damagesource" {
    export class $CombatTracker {
        constructor(mob: $LivingEntity);
        static RESET_COMBAT_STATUS_TIME: number;
        static RESET_DAMAGE_STATUS_TIME: number;
        get combatDuration(): number;
        getCombatDuration(): number;
        get deathMessage(): $Component;
        getDeathMessage(): $Component;
        recheckStatus(): void;
        recordDamage(source: $DamageSource, damage: number): void;
    }

    export class $DamageEffects {
        static BURNING: $DamageEffects;
        static DROWNING: $DamageEffects;
        static FREEZING: $DamageEffects;
        static HURT: $DamageEffects;
        static POKING: $DamageEffects;
        static THORNS: $DamageEffects;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DamageEffects[];
        static valueOf(name: string): $DamageEffects;
    }

    export class $DamageScaling {
        static ALWAYS: $DamageScaling;
        static NEVER: $DamageScaling;
        static WHEN_CAUSED_BY_LIVING_NON_PLAYER: $DamageScaling;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DamageScaling[];
        static valueOf(name: string): $DamageScaling;
    }

    export class $DamageSource {
        constructor(type: $Holder<$DamageType>);
        constructor(type: $Holder<$DamageType>, causingEntity: $Entity);
        constructor(type: $Holder<$DamageType>, directEntity: $Entity, causingEntity: $Entity);
        constructor(type: $Holder<$DamageType>, damageSourcePosition: $Vec3_);
        get directEntity(): $Entity;
        getDirectEntity(): $Entity;
        get entity(): $Entity;
        getEntity(): $Entity;
        get foodExhaustion(): number;
        getFoodExhaustion(): number;
        get msgId(): string;
        getMsgId(): string;
        get sourcePosition(): $Vec3;
        getSourcePosition(): $Vec3;
        get weaponItem(): $ItemStack;
        getWeaponItem(): $ItemStack;
        get creativePlayer(): boolean;
        isCreativePlayer(): boolean;
        get direct(): boolean;
        isDirect(): boolean;
        getLocalizedDeathMessage(victim: $LivingEntity): $Component;
        is(typeKey: $ResourceKey<$DamageType>): boolean;
        is(tag: $TagKey<$DamageType>): boolean;
        scalesWithDifficulty(): boolean;
        sourcePositionRaw(): $Vec3;
        toString(): string;
        typeHolder(): $Holder<$DamageType>;
        type(): $DamageType;
    }

    export class $DamageSources {
        constructor(registries: $RegistryAccess);
        damageTypes: $Registry<$DamageType>;
        anvil(entity: $Entity): $DamageSource;
        arrow(arrow: $AbstractArrow, owner: $Entity): $DamageSource;
        badRespawnPointExplosion(boomPos: $Vec3_): $DamageSource;
        cactus(): $DamageSource;
        campfire(): $DamageSource;
        cramming(): $DamageSource;
        dragonBreath(): $DamageSource;
        drown(): $DamageSource;
        dryOut(): $DamageSource;
        enderPearl(): $DamageSource;
        explosion(entity: $Entity, cause: $Entity): $DamageSource;
        explosion(explosion: $Explosion): $DamageSource;
        fallingBlock(entity: $Entity): $DamageSource;
        fallingStalactite(entity: $Entity): $DamageSource;
        fall(): $DamageSource;
        fellOutOfWorld(): $DamageSource;
        fireball(fireball: $Fireball, owner: $Entity): $DamageSource;
        fireworks(rocket: $FireworkRocketEntity, owner: $Entity): $DamageSource;
        flyIntoWall(): $DamageSource;
        freeze(): $DamageSource;
        genericKill(): $DamageSource;
        generic(): $DamageSource;
        hotFloor(): $DamageSource;
        inFire(): $DamageSource;
        inWall(): $DamageSource;
        indirectMagic(entity: $Entity, owner: $Entity): $DamageSource;
        lava(): $DamageSource;
        lightningBolt(): $DamageSource;
        mace(owner: $Entity): $DamageSource;
        magic(): $DamageSource;
        mobAttack(mob: $LivingEntity): $DamageSource;
        mobProjectile(entity: $Entity, mob: $LivingEntity): $DamageSource;
        noAggroMobAttack(mob: $LivingEntity): $DamageSource;
        onFire(): $DamageSource;
        outOfBorder(): $DamageSource;
        playerAttack(player: $Player): $DamageSource;
        sonicBoom(entity: $Entity): $DamageSource;
        source(key: $ResourceKey<$DamageType>, directEntity: $Entity, causingEntity: $Entity): $DamageSource;
        source(key: $ResourceKey<$DamageType>, cause: $Entity): $DamageSource;
        source(key: $ResourceKey<$DamageType>): $DamageSource;
        spit(entity: $Entity, mob: $LivingEntity): $DamageSource;
        stalagmite(): $DamageSource;
        starve(): $DamageSource;
        sting(mob: $LivingEntity): $DamageSource;
        sweetBerryBush(): $DamageSource;
        thorns(source: $Entity): $DamageSource;
        thrown(entity: $Entity, owner: $Entity): $DamageSource;
        trident(trident: $Entity, owner: $Entity): $DamageSource;
        windCharge(entity: $Entity, mob: $LivingEntity): $DamageSource;
        witherSkull(witherSkull: $WitherSkull, owner: $Entity): $DamageSource;
        wither(): $DamageSource;
    }

    export class $DamageType extends $Record {
        constructor(msgdId: string, exhaustion: number);
        constructor(msgdId: string, exhaustion: number, effects: $DamageEffects_);
        constructor(msgdId: string, scaling: $DamageScaling_, exhaustion: number);
        constructor(msgdId: string, scaling: $DamageScaling_, exhaustion: number, effects: $DamageEffects_);
        constructor(msgId: string, scaling: $DamageScaling_, exhaustion: number, effects: $DamageEffects_, deathMessageType: $DeathMessageType_);
        static CODEC: $Codec<$Holder<$DamageType>>;
        static DIRECT_CODEC: $Codec<$DamageType>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$DamageType>>;
        deathMessageType(): $DeathMessageType;
        effects(): $DamageEffects;
        equals(o: object): boolean;
        exhaustion(): number;
        hashCode(): number;
        msgId(): string;
        scaling(): $DamageScaling;
        toString(): string;
    }

    export interface $DamageTypes {
        bootstrap(context: $BootstrapContext<$DamageType>): void;
        static ARROW: $ResourceKey<$DamageType>;
        static BAD_RESPAWN_POINT: $ResourceKey<$DamageType>;
        static CACTUS: $ResourceKey<$DamageType>;
        static CAMPFIRE: $ResourceKey<$DamageType>;
        static CRAMMING: $ResourceKey<$DamageType>;
        static DRAGON_BREATH: $ResourceKey<$DamageType>;
        static DROWN: $ResourceKey<$DamageType>;
        static DRY_OUT: $ResourceKey<$DamageType>;
        static ENDER_PEARL: $ResourceKey<$DamageType>;
        static EXPLOSION: $ResourceKey<$DamageType>;
        static FALL: $ResourceKey<$DamageType>;
        static FALLING_ANVIL: $ResourceKey<$DamageType>;
        static FALLING_BLOCK: $ResourceKey<$DamageType>;
        static FALLING_STALACTITE: $ResourceKey<$DamageType>;
        static FELL_OUT_OF_WORLD: $ResourceKey<$DamageType>;
        static FIREBALL: $ResourceKey<$DamageType>;
        static FIREWORKS: $ResourceKey<$DamageType>;
        static FLY_INTO_WALL: $ResourceKey<$DamageType>;
        static FREEZE: $ResourceKey<$DamageType>;
        static GENERIC: $ResourceKey<$DamageType>;
        static GENERIC_KILL: $ResourceKey<$DamageType>;
        static HOT_FLOOR: $ResourceKey<$DamageType>;
        static INDIRECT_MAGIC: $ResourceKey<$DamageType>;
        static IN_FIRE: $ResourceKey<$DamageType>;
        static IN_WALL: $ResourceKey<$DamageType>;
        static LAVA: $ResourceKey<$DamageType>;
        static LIGHTNING_BOLT: $ResourceKey<$DamageType>;
        static MACE_SMASH: $ResourceKey<$DamageType>;
        static MAGIC: $ResourceKey<$DamageType>;
        static MOB_ATTACK: $ResourceKey<$DamageType>;
        static MOB_ATTACK_NO_AGGRO: $ResourceKey<$DamageType>;
        static MOB_PROJECTILE: $ResourceKey<$DamageType>;
        static ON_FIRE: $ResourceKey<$DamageType>;
        static OUTSIDE_BORDER: $ResourceKey<$DamageType>;
        static PLAYER_ATTACK: $ResourceKey<$DamageType>;
        static PLAYER_EXPLOSION: $ResourceKey<$DamageType>;
        static SONIC_BOOM: $ResourceKey<$DamageType>;
        static SPEAR: $ResourceKey<$DamageType>;
        static SPIT: $ResourceKey<$DamageType>;
        static STALAGMITE: $ResourceKey<$DamageType>;
        static STARVE: $ResourceKey<$DamageType>;
        static STING: $ResourceKey<$DamageType>;
        static SWEET_BERRY_BUSH: $ResourceKey<$DamageType>;
        static THORNS: $ResourceKey<$DamageType>;
        static THROWN: $ResourceKey<$DamageType>;
        static TRIDENT: $ResourceKey<$DamageType>;
        static UNATTRIBUTED_FIREBALL: $ResourceKey<$DamageType>;
        static WIND_CHARGE: $ResourceKey<$DamageType>;
        static WITHER: $ResourceKey<$DamageType>;
        static WITHER_SKULL: $ResourceKey<$DamageType>;
    }

    export class $DeathMessageType {
        static DEFAULT: $DeathMessageType;
        static FALL_VARIANTS: $DeathMessageType;
        static INTENTIONAL_GAME_DESIGN: $DeathMessageType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DeathMessageType[];
        static valueOf(name: string): $DeathMessageType;
    }

    export type $DamageEffects_ = $DamageEffects | "BURNING" | "DROWNING" | "FREEZING" | "HURT" | "POKING" | "THORNS";
    export type $DamageScaling_ = $DamageScaling | "ALWAYS" | "NEVER" | "WHEN_CAUSED_BY_LIVING_NON_PLAYER";
    export type $DeathMessageType_ = $DeathMessageType | "DEFAULT" | "FALL_VARIANTS" | "INTENTIONAL_GAME_DESIGN";
}
