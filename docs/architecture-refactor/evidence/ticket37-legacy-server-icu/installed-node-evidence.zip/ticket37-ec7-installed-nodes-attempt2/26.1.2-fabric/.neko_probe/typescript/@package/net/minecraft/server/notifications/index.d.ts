import { $String } from "java:java/lang";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $IpBanListEntry, $NameAndId, $ServerOpListEntry, $UserBanListEntry } from "java:net/minecraft/server/players";
import { $GameRule } from "java:net/minecraft/world/level/gamerules";

declare module "java:net/minecraft/server/notifications" {
    export class $NotificationManager implements $NotificationService {
        constructor();
        ipBanned(ban: $IpBanListEntry): void;
        ipUnbanned(ip: string): void;
        onGameRuleChanged<T>(gameRule: $GameRule<T>, value: T): void;
        playerAddedToAllowlist(player: $NameAndId): void;
        playerBanned(ban: $UserBanListEntry): void;
        playerDeoped(operator: $ServerOpListEntry): void;
        playerJoined(player: $ServerPlayer): void;
        playerLeft(player: $ServerPlayer): void;
        playerOped(operator: $ServerOpListEntry): void;
        playerRemovedFromAllowlist(player: $NameAndId): void;
        playerUnbanned(player: $NameAndId): void;
        registerService(notificationService: $NotificationService): void;
        serverActivityOccured(): void;
        serverSaveCompleted(): void;
        serverSaveStarted(): void;
        serverShuttingDown(): void;
        serverStarted(): void;
        statusHeartbeat(): void;
    }

    export interface $NotificationService {
        ipBanned(ban: $IpBanListEntry): void;
        ipUnbanned(ip: string): void;
        onGameRuleChanged<T>(gameRule: $GameRule<T>, value: T): void;
        playerAddedToAllowlist(player: $NameAndId): void;
        playerBanned(ban: $UserBanListEntry): void;
        playerDeoped(operator: $ServerOpListEntry): void;
        playerJoined(player: $ServerPlayer): void;
        playerLeft(player: $ServerPlayer): void;
        playerOped(operator: $ServerOpListEntry): void;
        playerRemovedFromAllowlist(player: $NameAndId): void;
        playerUnbanned(player: $NameAndId): void;
        serverActivityOccured(): void;
        serverSaveCompleted(): void;
        serverSaveStarted(): void;
        serverShuttingDown(): void;
        serverStarted(): void;
        statusHeartbeat(): void;
    }

    export class $ServerActivityMonitor {
        constructor(notificationManager: $NotificationManager, secondsBetweenNotifications: number);
        reportLoginActivity(): void;
        tick(): void;
    }

}
