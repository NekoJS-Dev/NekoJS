import type { RegistryTypes } from "@special/types";
import { $Multimap } from "java:com/google/common/collect";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Collection, $List, $Set } from "java:java/util";
import { $Consumer, $IntFunction } from "java:java/util/function";
import { $AttributeSupplierAccessor, $AttributeSupplierBuilderAccessor } from "java:net/fabricmc/fabric/mixin/object/builder";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $StringRepresentable } from "java:net/minecraft/util";

declare module "java:net/minecraft/world/entity/ai/attributes" {
    export class $Attribute {
        static CODEC: $Codec<$Holder<$Attribute>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$Attribute>>;
        get defaultValue(): number;
        getDefaultValue(): number;
        get descriptionId(): string;
        getDescriptionId(): string;
        get clientSyncable(): boolean;
        isClientSyncable(): boolean;
        getStyle(valueIncrease: boolean): $ChatFormatting;
        sanitizeValue(value: number): number;
    }

    export class $Attribute$Sentiment {
        static NEGATIVE: $Attribute$Sentiment;
        static NEUTRAL: $Attribute$Sentiment;
        static POSITIVE: $Attribute$Sentiment;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Attribute$Sentiment[];
        static valueOf(name: string): $Attribute$Sentiment;
    }

    export class $AttributeInstance {
        constructor(attribute: $Holder<$Attribute_>, onDirty: $Consumer<$AttributeInstance>);
        get attribute(): $Holder<$Attribute>;
        getAttribute(): $Holder<$Attribute>;
        get baseValue(): number;
        getBaseValue(): number;
        set baseValue(value: number);
        get modifiers(): $Set<$AttributeModifier>;
        getModifiers(): $Set<$AttributeModifier>;
        get permanentModifiers(): $Set<$AttributeModifier>;
        getPermanentModifiers(): $Set<$AttributeModifier>;
        get value(): number;
        getValue(): number;
        addOrReplacePermanentModifier(modifier: $AttributeModifier): void;
        addOrUpdateTransientModifier(modifier: $AttributeModifier): void;
        addPermanentModifiers(modifiers: $AttributeModifier[]): void;
        addPermanentModifier(modifier: $AttributeModifier): void;
        addTransientModifier(modifier: $AttributeModifier): void;
        apply(packed: $AttributeInstance$Packed): void;
        getModifier(id: $Identifier_): $AttributeModifier;
        hasModifier(modifier: $Identifier_): boolean;
        pack(): $AttributeInstance$Packed;
        removeModifiers(): void;
        removeModifier(id: $Identifier_): boolean;
        removeModifier(modifier: $AttributeModifier): void;
        replaceFrom(other: $AttributeInstance): void;
    }

    export class $AttributeInstance$Packed extends $Record {
        constructor(attribute: $Holder<$Attribute_>, baseValue: number, modifiers: $AttributeModifier[]);
        static CODEC: $Codec<$AttributeInstance$Packed>;
        static LIST_CODEC: $Codec<$List<$AttributeInstance$Packed>>;
        attribute(): $Holder<$Attribute>;
        baseValue(): number;
        equals(o: object): boolean;
        hashCode(): number;
        modifiers(): $List<$AttributeModifier>;
        toString(): string;
    }

    export class $AttributeMap {
        constructor(supplier: $AttributeSupplier);
        get attributesToSync(): $Set<$AttributeInstance>;
        getAttributesToSync(): $Set<$AttributeInstance>;
        get attributesToUpdate(): $Set<$AttributeInstance>;
        getAttributesToUpdate(): $Set<$AttributeInstance>;
        get syncableAttributes(): $Collection<$AttributeInstance>;
        getSyncableAttributes(): $Collection<$AttributeInstance>;
        addTransientAttributeModifiers(modifiers: $Multimap<$Holder<$Attribute_>, $AttributeModifier>): void;
        apply(packedAttributes: $AttributeInstance$Packed[]): void;
        assignAllValues(other: $AttributeMap): void;
        assignBaseValues(other: $AttributeMap): void;
        assignPermanentModifiers(other: $AttributeMap): void;
        getBaseValue(attribute: $Holder<$Attribute_>): number;
        getInstance(attribute: $Holder<$Attribute_>): $AttributeInstance;
        getModifierValue(attribute: $Holder<$Attribute_>, id: $Identifier_): number;
        getValue(attribute: $Holder<$Attribute_>): number;
        hasAttribute(attribute: $Holder<$Attribute_>): boolean;
        hasModifier(attribute: $Holder<$Attribute_>, id: $Identifier_): boolean;
        pack(): $List<$AttributeInstance$Packed>;
        removeAttributeModifiers(modifiers: $Multimap<$Holder<$Attribute_>, $AttributeModifier>): void;
        resetBaseValue(attribute: $Holder<$Attribute_>): boolean;
    }

    export class $AttributeModifier extends $Record {
        constructor(id: $Identifier_, amount: number, operation: $AttributeModifier$Operation_);
        static CODEC: $Codec<$AttributeModifier>;
        static MAP_CODEC: $MapCodec<$AttributeModifier>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $AttributeModifier>;
        amount(): number;
        equals(o: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        is(id: $Identifier_): boolean;
        operation(): $AttributeModifier$Operation;
        toString(): string;
    }

    export class $AttributeModifier$Operation {
        static ADD_MULTIPLIED_BASE: $AttributeModifier$Operation;
        static ADD_MULTIPLIED_TOTAL: $AttributeModifier$Operation;
        static ADD_VALUE: $AttributeModifier$Operation;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AttributeModifier$Operation[];
        static valueOf(name: string): $AttributeModifier$Operation;
    }

    export class $AttributeSupplier implements $AttributeSupplierAccessor {
        static builder(): $AttributeSupplier$Builder;
        createInstance(onDirty: $Consumer<$AttributeInstance>, attribute: $Holder<$Attribute_>): $AttributeInstance;
        getBaseValue(attribute: $Holder<$Attribute_>): number;
        getModifierValue(attribute: $Holder<$Attribute_>, id: $Identifier_): number;
        getValue(attribute: $Holder<$Attribute_>): number;
        hasAttribute(attribute: $Holder<$Attribute_>): boolean;
        hasModifier(attribute: $Holder<$Attribute_>, modifier: $Identifier_): boolean;
    }

    export class $AttributeSupplier$Builder implements $AttributeSupplierBuilderAccessor {
        constructor();
        add(attribute: $Holder<$Attribute_>, baseValue: number): $AttributeSupplier$Builder;
        add(attribute: $Holder<$Attribute_>): $AttributeSupplier$Builder;
        build(): $AttributeSupplier;
    }

    export type $Attribute_ = $Attribute | RegistryTypes.Attribute | $NekoId | string;
    export type $Attribute$Sentiment_ = $Attribute$Sentiment | "NEGATIVE" | "NEUTRAL" | "POSITIVE";
    export type $AttributeModifier$Operation_ = $AttributeModifier$Operation | "ADD_MULTIPLIED_BASE" | "ADD_MULTIPLIED_TOTAL" | "ADD_VALUE";
}
