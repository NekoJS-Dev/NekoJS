import { $Predicate } from "java:java/util/function";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $AgeableMob, $EntitySpawnReason, $EntitySpawnReason_, $LivingEntity, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $AgeableWaterCreature } from "java:net/minecraft/world/entity/animal";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/dolphin" {
    export class $Dolphin extends $AgeableWaterCreature {
        constructor(type: $EntityType<$Dolphin>, level: $Level);
        static ALLOWED_ITEMS: $Predicate<$ItemEntity>;
        static BABY_SCALE: number;
        static TOTAL_AIR_SUPPLY: number;
        get ageScale(): number;
        getAgeScale(): number;
        get maxAirSupply(): number;
        getMaxAirSupply(): number;
        get maxHeadXRot(): number;
        getMaxHeadXRot(): number;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get moistnessLevel(): number;
        getMoistnessLevel(): number;
        static createAttributes(): $AttributeSupplier$Builder;
        canAttack(target: $LivingEntity): boolean;
        canBeLeashed(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Dolphin;
        gotFish(): boolean;
        handleEntityEvent(id: number): void;
        playAttackSound(): void;
        tick(): void;
    }

}
