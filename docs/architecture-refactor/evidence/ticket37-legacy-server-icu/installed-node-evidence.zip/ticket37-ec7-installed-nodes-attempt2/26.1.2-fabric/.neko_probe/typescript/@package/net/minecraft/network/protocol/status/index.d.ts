import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Record, $String } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $ClientboundPacketListener, $ConnectionProtocol, $ConnectionProtocol_ } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ClientPongPacketListener } from "java:net/minecraft/network/protocol/ping";
import { $NameAndId } from "java:net/minecraft/server/players";

declare module "java:net/minecraft/network/protocol/status" {
    export interface $ClientStatusPacketListener extends $ClientboundPacketListener, $ClientPongPacketListener {
        handleStatusResponse(packet: $ClientboundStatusResponsePacket): void;
        protocol(): $ConnectionProtocol;
    }

    export class $ClientboundStatusResponsePacket extends $Record implements $Packet {
        constructor(status: $ServerStatus);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundStatusResponsePacket>;
        equals(o: object): boolean;
        handle(listener: $ClientStatusPacketListener): void;
        hashCode(): number;
        status(): $ServerStatus;
        toString(): string;
        type(): $PacketType<$ClientboundStatusResponsePacket>;
    }

    export class $ServerStatus extends $Record {
        constructor(description: $Component_, players: $Optional<$ServerStatus$Players>, version: $Optional<$ServerStatus$Version>, favicon: $Optional<$ServerStatus$Favicon>, enforcesSecureChat: boolean);
        static CODEC: $Codec<$ServerStatus>;
        description(): $Component;
        enforcesSecureChat(): boolean;
        equals(o: object): boolean;
        favicon(): $Optional<$ServerStatus$Favicon>;
        hashCode(): number;
        players(): $Optional<$ServerStatus$Players>;
        toString(): string;
        version(): $Optional<$ServerStatus$Version>;
    }

    export class $ServerStatus$Favicon extends $Record {
        constructor(iconBytes: number[]);
        static CODEC: $Codec<$ServerStatus$Favicon>;
        equals(o: object): boolean;
        hashCode(): number;
        iconBytes(): number[];
        toString(): string;
    }

    export class $ServerStatus$Players extends $Record {
        constructor(max: number, online: number, sample: $NameAndId[]);
        static CODEC: $Codec<$ServerStatus$Players>;
        equals(o: object): boolean;
        hashCode(): number;
        max(): number;
        online(): number;
        sample(): $List<$NameAndId>;
        toString(): string;
    }

    export class $ServerStatus$Version extends $Record {
        constructor(name: string, protocol: number);
        static CODEC: $Codec<$ServerStatus$Version>;
        static current(): $ServerStatus$Version;
        equals(o: object): boolean;
        hashCode(): number;
        name(): string;
        protocol(): number;
        toString(): string;
    }

}
