import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AnimationState, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $Mob } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $LevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/ambient" {
    export class $AmbientCreature extends $Mob {
        canBeLeashed(): boolean;
    }

    export class $Bat extends $AmbientCreature {
        constructor(type: $EntityType<$Bat>, level: $Level);
        static FLAP_LENGTH_SECONDS: number;
        static TICKS_PER_FLAP: number;
        flyAnimationState: $AnimationState;
        restAnimationState: $AnimationState;
        get ambientSound(): $SoundEvent;
        getAmbientSound(): $SoundEvent;
        get voicePitch(): number;
        getVoicePitch(): number;
        get flapping(): boolean;
        isFlapping(): boolean;
        get ignoringBlockTriggers(): boolean;
        isIgnoringBlockTriggers(): boolean;
        get pushable(): boolean;
        isPushable(): boolean;
        get resting(): boolean;
        isResting(): boolean;
        set resting(value: boolean);
        static checkBatSpawnRules(type: $EntityType<$Bat>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        tick(): void;
    }

}
