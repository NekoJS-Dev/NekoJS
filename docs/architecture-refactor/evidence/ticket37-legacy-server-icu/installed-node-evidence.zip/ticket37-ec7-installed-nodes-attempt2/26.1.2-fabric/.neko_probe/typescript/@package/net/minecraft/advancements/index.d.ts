import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $Comparable, $Enum, $Iterable, $Record, $String } from "java:java/lang";
import { $Instant } from "java:java/time";
import { $Collection, $List, $Map, $Optional, $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $CacheableFunction } from "java:net/minecraft/commands";
import { $ClientAsset$ResourceTexture, $HolderGetter$Provider } from "java:net/minecraft/core";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $MutableComponent } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $PlayerAdvancements } from "java:net/minecraft/server";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $ProblemReporter, $StringRepresentable } from "java:net/minecraft/util";
import { $ItemStackTemplate } from "java:net/minecraft/world/item";
import { $Recipe } from "java:net/minecraft/world/item/crafting";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";

export * as criterion from "java:net/minecraft/advancements/criterion";

declare module "java:net/minecraft/advancements" {
    export class $Advancement extends $Record {
        constructor(parent: $Optional<$Identifier_>, display: $Optional<$DisplayInfo>, rewards: $AdvancementRewards, criteria: { [key: string]: $Criterion<any> }, requirements: $AdvancementRequirements, sendsTelemetryEvent: boolean);
        constructor(parent: $Optional<$Identifier_>, display: $Optional<$DisplayInfo>, rewards: $AdvancementRewards, criteria: { [key: string]: $Criterion<any> }, requirements: $AdvancementRequirements, sendsTelemetryEvent: boolean, name: $Optional<$Component_>);
        static CODEC: $Codec<$Advancement>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Advancement>;
        get root(): boolean;
        isRoot(): boolean;
        static name(holder: $AdvancementHolder): $Component;
        criteria(): $Map<string, $Criterion<any>>;
        display(): $Optional<$DisplayInfo>;
        equals(o: object): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        parent(): $Optional<$Identifier>;
        requirements(): $AdvancementRequirements;
        rewards(): $AdvancementRewards;
        sendsTelemetryEvent(): boolean;
        toString(): string;
        validate(reporter: $ProblemReporter, lootData: $HolderGetter$Provider): void;
    }

    export class $AdvancementHolder extends $Record {
        constructor(id: $Identifier_, value: $Advancement);
        static LIST_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $List<$AdvancementHolder>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $AdvancementHolder>;
        equals(obj: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
        value(): $Advancement;
    }

    export class $AdvancementNode {
        constructor(holder: $AdvancementHolder, parent: $AdvancementNode);
        static getRoot(advancement: $AdvancementNode): $AdvancementNode;
        addChild(child: $AdvancementNode): void;
        advancement(): $Advancement;
        children(): $Iterable<$AdvancementNode>;
        equals(obj: object): boolean;
        hashCode(): number;
        holder(): $AdvancementHolder;
        parent(): $AdvancementNode;
        root(): $AdvancementNode;
        toString(): string;
    }

    export class $AdvancementProgress implements $Comparable {
        constructor();
        static CODEC: $Codec<$AdvancementProgress>;
        get completedCriteria(): $Iterable<string>;
        getCompletedCriteria(): $Iterable<string>;
        get firstProgressDate(): $Instant;
        getFirstProgressDate(): $Instant;
        get percent(): number;
        getPercent(): number;
        get progressText(): $Component;
        getProgressText(): $Component;
        get remainingCriteria(): $Iterable<string>;
        getRemainingCriteria(): $Iterable<string>;
        get done(): boolean;
        isDone(): boolean;
        static fromNetwork(input: $FriendlyByteBuf): $AdvancementProgress;
        compareTo(o: $AdvancementProgress): number;
        getCriterion(id: string): $CriterionProgress;
        grantProgress(name: string): boolean;
        hasProgress(): boolean;
        revokeProgress(name: string): boolean;
        serializeToNetwork(output: $FriendlyByteBuf): void;
        toString(): string;
        update(requirements: $AdvancementRequirements): void;
    }

    export class $AdvancementRequirements extends $Record {
        constructor(requirements: string[][]);
        constructor(input: $FriendlyByteBuf);
        static CODEC: $Codec<$AdvancementRequirements>;
        static EMPTY: $AdvancementRequirements;
        get empty(): boolean;
        isEmpty(): boolean;
        static allOf(criteria: string[]): $AdvancementRequirements;
        static anyOf(criteria: string[]): $AdvancementRequirements;
        count(predicate: $Predicate<string>): number;
        equals(o: object): boolean;
        hashCode(): number;
        names(): $Set<string>;
        requirements(): $List<$List<string>>;
        size(): number;
        test(predicate: $Predicate<string>): boolean;
        toString(): string;
        validate(expectedCriteria: string[]): $DataResult<$AdvancementRequirements>;
        write(output: $FriendlyByteBuf): void;
    }

    export class $AdvancementRewards extends $Record {
        constructor(experience: number, loot: $ResourceKey<$LootTable>[], recipes: $ResourceKey<$Recipe<any>>[], function_: $Optional<$CacheableFunction>);
        static CODEC: $Codec<$AdvancementRewards>;
        static EMPTY: $AdvancementRewards;
        equals(o: object): boolean;
        experience(): number;
        function(): $Optional<$CacheableFunction>;
        grant(player: $ServerPlayer): void;
        hashCode(): number;
        loot(): $List<$ResourceKey<$LootTable>>;
        recipes(): $List<$ResourceKey<$Recipe<any>>>;
        toString(): string;
    }

    export class $AdvancementTree {
        constructor();
        addAll(advancements: $AdvancementHolder[]): void;
        clear(): void;
        get(advancement: $AdvancementHolder): $AdvancementNode;
        get(id: $Identifier_): $AdvancementNode;
        nodes(): $Collection<$AdvancementNode>;
        remove(ids: $Identifier_[]): void;
        roots(): $Iterable<$AdvancementNode>;
    }

    export interface $AdvancementTree$Listener {
        onAddAdvancementRoot(root: $AdvancementNode): void;
        onAddAdvancementTask(task: $AdvancementNode): void;
        onAdvancementsCleared(): void;
        onRemoveAdvancementRoot(root: $AdvancementNode): void;
        onRemoveAdvancementTask(task: $AdvancementNode): void;
    }

    export class $AdvancementType {
        static CHALLENGE: $AdvancementType;
        static GOAL: $AdvancementType;
        static TASK: $AdvancementType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AdvancementType[];
        static valueOf(name: string): $AdvancementType;
    }

    export class $Criterion<T extends $CriterionTriggerInstance> extends $Record {
        constructor(trigger: $CriterionTrigger<T>, triggerInstance: T);
        static CODEC: $Codec<$Criterion<any>>;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        triggerInstance(): T;
        trigger(): $CriterionTrigger<T>;
    }

    export class $CriterionProgress {
        constructor();
        constructor(obtained: $Instant);
        get obtained(): $Instant;
        getObtained(): $Instant;
        get done(): boolean;
        isDone(): boolean;
        static fromNetwork(input: $FriendlyByteBuf): $CriterionProgress;
        grant(): void;
        revoke(): void;
        serializeToNetwork(output: $FriendlyByteBuf): void;
        toString(): string;
    }

    export interface $CriterionTrigger<T extends $CriterionTriggerInstance> {
        addPlayerListener(player: $PlayerAdvancements, listener: $CriterionTrigger$Listener<T>): void;
        codec(): $Codec<T>;
        createCriterion(instance: T): $Criterion<T>;
        removePlayerListeners(player: $PlayerAdvancements): void;
        removePlayerListener(player: $PlayerAdvancements, listener: $CriterionTrigger$Listener<T>): void;
    }

    export class $CriterionTrigger$Listener<T extends $CriterionTriggerInstance> extends $Record {
        constructor(trigger: T, advancement: $AdvancementHolder, criterion: string);
        advancement(): $AdvancementHolder;
        criterion(): string;
        equals(o: object): boolean;
        hashCode(): number;
        run(player: $PlayerAdvancements): void;
        toString(): string;
        trigger(): T;
    }

    export class $DisplayInfo {
        constructor(icon: $ItemStackTemplate, title: $Component_, description: $Component_, background: $Optional<$ClientAsset$ResourceTexture>, type: $AdvancementType_, showToast: boolean, announceChat: boolean, hidden: boolean);
        static CODEC: $Codec<$DisplayInfo>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DisplayInfo>;
        get background(): $Optional<$ClientAsset$ResourceTexture>;
        getBackground(): $Optional<$ClientAsset$ResourceTexture>;
        get description(): $Component;
        getDescription(): $Component;
        get icon(): $ItemStackTemplate;
        getIcon(): $ItemStackTemplate;
        get title(): $Component;
        getTitle(): $Component;
        get type(): $AdvancementType;
        getType(): $AdvancementType;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get hidden(): boolean;
        isHidden(): boolean;
        setLocation(x: number, y: number): void;
        shouldAnnounceChat(): boolean;
        shouldShowToast(): boolean;
    }

    export type $AdvancementType_ = $AdvancementType | "CHALLENGE" | "GOAL" | "TASK";
}
