import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AnimationState, $ContainerUser, $Crackiness$Level, $Crackiness$Level_, $Entity, $EntityReference, $EntitySpawnReason, $EntitySpawnReason_, $EquipmentSlot, $EquipmentSlot_, $LightningBolt, $LivingEntity, $NeutralMob, $PathfinderMob, $Shearable, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $RangedAttackMob } from "java:net/minecraft/world/entity/monster";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $WeatheringCopper$WeatherState, $WeatheringCopper$WeatherState_ } from "java:net/minecraft/world/level/block";
import { $ContainerOpenersCounter } from "java:net/minecraft/world/level/block/entity";
import { $ValueInput, $ValueOutput } from "java:net/minecraft/world/level/storage";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/golem" {
    export class $AbstractGolem extends $PathfinderMob {
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        removeWhenFarAway(distSqr: number): boolean;
    }

    export class $CopperGolem extends $AbstractGolem implements $ContainerUser, $Shearable {
        constructor(type: $EntityType<$AbstractGolem>, level: $Level);
        static EQUIPMENT_SLOT_ANTENNA: $EquipmentSlot;
        get brain(): $Brain<$CopperGolem>;
        getBrain(): $Brain<$CopperGolem>;
        get containerInteractionRange(): number;
        getContainerInteractionRange(): number;
        get idleAnimationState(): $AnimationState;
        getIdleAnimationState(): $AnimationState;
        get interactionDropItemAnimationState(): $AnimationState;
        getInteractionDropItemAnimationState(): $AnimationState;
        get interactionDropNoItemAnimationState(): $AnimationState;
        getInteractionDropNoItemAnimationState(): $AnimationState;
        get interactionGetItemAnimationState(): $AnimationState;
        getInteractionGetItemAnimationState(): $AnimationState;
        get interactionGetNoItemAnimationState(): $AnimationState;
        getInteractionGetNoItemAnimationState(): $AnimationState;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get state(): $CopperGolemState;
        getState(): $CopperGolemState;
        set state(value: $CopperGolemState_);
        get weatherState(): $WeatheringCopper$WeatherState;
        getWeatherState(): $WeatheringCopper$WeatherState;
        set weatherState(value: $WeatheringCopper$WeatherState_);
        static createAttributes(): $AttributeSupplier$Builder;
        addAdditionalSaveData(output: $ValueOutput): void;
        clearOpenedChestPos(): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        hasContainerOpen(container: $ContainerOpenersCounter, blockPos: $BlockPos_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        playSpawnSound(): void;
        readAdditionalSaveData(input: $ValueInput): void;
        readyForShearing(): boolean;
        shear(level: $ServerLevel, soundSource: $SoundSource_, tool: $ItemStack_): void;
        spawn(weatherState: $WeatheringCopper$WeatherState_): void;
        thunderHit(level: $ServerLevel, lightningBolt: $LightningBolt): void;
        tick(): void;
    }

    export class $CopperGolemState {
        static DROPPING_ITEM: $CopperGolemState;
        static DROPPING_NO_ITEM: $CopperGolemState;
        static GETTING_ITEM: $CopperGolemState;
        static GETTING_NO_ITEM: $CopperGolemState;
        static IDLE: $CopperGolemState;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CopperGolemState[];
        static valueOf(name: string): $CopperGolemState;
    }

    export class $IronGolem extends $AbstractGolem implements $NeutralMob {
        constructor(type: $EntityType<$IronGolem>, level: $Level);
        get attackAnimationTick(): number;
        getAttackAnimationTick(): number;
        get crackiness(): $Crackiness$Level;
        getCrackiness(): $Crackiness$Level;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get offerFlowerTick(): number;
        getOfferFlowerTick(): number;
        get persistentAngerEndTime(): number;
        getPersistentAngerEndTime(): number;
        set persistentAngerEndTime(value: number);
        get persistentAngerTarget(): $EntityReference<$LivingEntity>;
        getPersistentAngerTarget(): $EntityReference<$LivingEntity>;
        set persistentAngerTarget(value: $EntityReference<$LivingEntity>);
        get playerCreated(): boolean;
        isPlayerCreated(): boolean;
        set playerCreated(value: boolean);
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canAttack(target: $LivingEntity): boolean;
        canSpawnSprintParticle(): boolean;
        checkSpawnObstruction(level: $LevelReader): boolean;
        die(source: $DamageSource): void;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        handleEntityEvent(id: number): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        offerFlower(offer: boolean): void;
        startPersistentAngerTimer(): void;
    }

    export class $SnowGolem extends $AbstractGolem implements $RangedAttackMob, $Shearable {
        constructor(type: $EntityType<$SnowGolem>, level: $Level);
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get sensitiveToWater(): boolean;
        isSensitiveToWater(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        hasPumpkin(): boolean;
        performRangedAttack(target: $LivingEntity, power: number): void;
        readyForShearing(): boolean;
        shear(level: $ServerLevel, soundSource: $SoundSource_, tool: $ItemStack_): void;
    }

    export type $CopperGolemState_ = $CopperGolemState | "DROPPING_ITEM" | "DROPPING_NO_ITEM" | "GETTING_ITEM" | "GETTING_NO_ITEM" | "IDLE";
}
