import { $GameProfile } from "java:com/mojang/authlib";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Record, $String } from "java:java/lang";
import { $PublicKey } from "java:java/security";
import { $ConnectionProtocol, $ConnectionProtocol_, $FriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ClientCookiePacketListener } from "java:net/minecraft/network/protocol/cookie";
import { $CustomQueryPayload } from "java:net/minecraft/network/protocol/login/custom";

export * as custom from "java:net/minecraft/network/protocol/login/custom";

declare module "java:net/minecraft/network/protocol/login" {
    export interface $ClientLoginPacketListener extends $ClientCookiePacketListener {
        handleCompression(packet: $ClientboundLoginCompressionPacket): void;
        handleCustomQuery(packet: $ClientboundCustomQueryPacket): void;
        handleDisconnect(packet: $ClientboundLoginDisconnectPacket): void;
        handleHello(packet: $ClientboundHelloPacket): void;
        handleLoginFinished(packet: $ClientboundLoginFinishedPacket): void;
        protocol(): $ConnectionProtocol;
    }

    export class $ClientboundCustomQueryPacket extends $Record implements $Packet {
        constructor(transactionId: number, payload: $CustomQueryPayload);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundCustomQueryPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientLoginPacketListener): void;
        hashCode(): number;
        payload(): $CustomQueryPayload;
        toString(): string;
        transactionId(): number;
        type(): $PacketType<$ClientboundCustomQueryPacket>;
    }

    export class $ClientboundHelloPacket implements $Packet {
        constructor(serverId: string, publicKey: number[], challenge: number[], shouldAuthenticate: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundHelloPacket>;
        get challenge(): number[];
        getChallenge(): number[];
        get publicKey(): $PublicKey;
        getPublicKey(): $PublicKey;
        get serverId(): string;
        getServerId(): string;
        handle(listener: $ClientLoginPacketListener): void;
        shouldAuthenticate(): boolean;
        type(): $PacketType<$ClientboundHelloPacket>;
    }

    export class $ClientboundLoginCompressionPacket implements $Packet {
        constructor(compressionThreshold: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundLoginCompressionPacket>;
        get compressionThreshold(): number;
        getCompressionThreshold(): number;
        handle(listener: $ClientLoginPacketListener): void;
        type(): $PacketType<$ClientboundLoginCompressionPacket>;
    }

    export class $ClientboundLoginDisconnectPacket extends $Record implements $Packet {
        constructor(reason: $Component_);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundLoginDisconnectPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientLoginPacketListener): void;
        hashCode(): number;
        reason(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundLoginDisconnectPacket>;
    }

    export class $ClientboundLoginFinishedPacket extends $Record implements $Packet {
        constructor(gameProfile: $GameProfile);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundLoginFinishedPacket>;
        get terminal(): boolean;
        isTerminal(): boolean;
        equals(o: object): boolean;
        gameProfile(): $GameProfile;
        handle(listener: $ClientLoginPacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundLoginFinishedPacket>;
    }

}
