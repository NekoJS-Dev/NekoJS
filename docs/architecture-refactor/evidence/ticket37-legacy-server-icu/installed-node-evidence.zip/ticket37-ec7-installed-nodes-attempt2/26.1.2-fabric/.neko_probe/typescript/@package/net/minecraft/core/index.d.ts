import { $ImmutableList } from "java:com/google/common/collect";
import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec, $DynamicOps, $Keyable, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Int2IntMap } from "java:it/unimi/dsi/fastutil/ints";
import { $LongConsumer } from "java:it/unimi/dsi/fastutil/longs";
import { $Comparable, $Enum, $Iterable, $Record, $String } from "java:java/lang";
import { $AbstractList, $Collection, $Iterator, $List, $Map$Entry, $Optional, $Set, $Spliterator } from "java:java/util";
import { $BiConsumer, $Consumer, $Function, $IntFunction, $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $FabricRegistry } from "java:net/fabricmc/fabric/api/event/registry";
import { $RemovableIdMapper } from "java:net/fabricmc/fabric/impl/registry/sync";
import { $RegistryMixin } from "java:net/fabricmc/fabric/mixin/registry/sync";
import { $DataComponentLookup, $DataComponentMap } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $RegistryOps, $ResourceKey } from "java:net/minecraft/resources";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $TagKey, $TagKey_, $TagLoader$LoadResult } from "java:net/minecraft/tags";
import { $RandomSource, $StringRepresentable, $StringRepresentable$EnumCodec } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $ChunkPos, $Level } from "java:net/minecraft/world/level";
import { $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $ChunkAccess } from "java:net/minecraft/world/level/chunk";
import { $EntityAccess } from "java:net/minecraft/world/level/entity";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";
import { $AABB, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $Matrix4fc, $Quaternionf, $Vector3f, $Vector3fc, $Vector3i } from "java:org/joml";
import { $Logger } from "java:org/slf4j";

export * as component from "java:net/minecraft/core/component";
export * as particles from "java:net/minecraft/core/particles";

declare module "java:net/minecraft/core" {
    export class $AxisCycle {
        static BACKWARD: $AxisCycle;
        static FORWARD: $AxisCycle;
        static NONE: $AxisCycle;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AxisCycle[];
        static valueOf(name: string): $AxisCycle;
    }

    export class $BlockPos extends $Vec3i {
        constructor(x: number, y: number, z: number);
        constructor(vec3i: $Vec3i);
        static CODEC: $Codec<$BlockPos>;
        static MAX_HORIZONTAL_COORDINATE: number;
        static PACKED_HORIZONTAL_LENGTH: number;
        static PACKED_Y_LENGTH: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $BlockPos>;
        static ZERO: $BlockPos;
        get bottomCenter(): $Vec3;
        getBottomCenter(): $Vec3;
        get center(): $Vec3;
        getCenter(): $Vec3;
        static asLong(x: number, y: number, z: number): number;
        static betweenClosedStream(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): $Stream<$BlockPos>;
        static betweenClosedStream(a: $BlockPos_, b: $BlockPos_): $Stream<$BlockPos>;
        static betweenClosedStream(boundingBox: $BoundingBox): $Stream<$BlockPos>;
        static betweenClosedStream(box: $AABB): $Stream<$BlockPos>;
        static betweenClosed(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): $Iterable<$BlockPos>;
        static betweenClosed(a: $BlockPos_, b: $BlockPos_): $Iterable<$BlockPos>;
        static betweenClosed(box: $AABB): $Iterable<$BlockPos>;
        static betweenCornersInDirection(firstCornerX: number, firstCornerY: number, firstCornerZ: number, secondCornerX: number, secondCornerY: number, secondCornerZ: number, direction: $Vec3_): $Iterable<$BlockPos>;
        static betweenCornersInDirection(firstCorner: $BlockPos_, secondCorner: $BlockPos_, direction: $Vec3_): $Iterable<$BlockPos>;
        static betweenCornersInDirection(aabb: $AABB, direction: $Vec3_): $Iterable<$BlockPos>;
        static breadthFirstTraversal(startPos: $BlockPos_, maxDepth: number, maxCount: number, neighbourProvider: $BiConsumer<$BlockPos_, $Consumer<$BlockPos_>>, nodeProcessor: $Function<$BlockPos_, $BlockPos$TraversalNodeStatus_>): number;
        static containing(x: number, y: number, z: number): $BlockPos;
        static containing(pos: $Position): $BlockPos;
        static findClosestMatch(startPos: $BlockPos_, horizontalSearchRadius: number, verticalSearchRadius: number, predicate: $Predicate<$BlockPos_>): $Optional<$BlockPos>;
        static getFlatIndex(neighborBlockNode: number): number;
        static getX(blockNode: number): number;
        static getY(blockNode: number): number;
        static getZ(blockNode: number): number;
        static max(a: $BlockPos_, b: $BlockPos_): $BlockPos;
        static min(a: $BlockPos_, b: $BlockPos_): $BlockPos;
        static offset(blockNode: number, stepX: number, stepY: number, stepZ: number): number;
        static offset(blockNode: number, offset: $Direction_): number;
        static of(blockNode: number): $BlockPos;
        static randomBetweenClosed(random: $RandomSource, limit: number, minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): $Iterable<$BlockPos>;
        static randomInCube(random: $RandomSource, limit: number, center: $BlockPos_, sizeToScanInAllDirections: number): $Iterable<$BlockPos>;
        static spiralAround(center: $BlockPos_, radius: number, firstDirection: $Direction_, secondDirection: $Direction_): $Iterable<$BlockPos$MutableBlockPos>;
        static squareOutSouthEast(from: $BlockPos_): $Stream<$BlockPos>;
        static withinManhattanStream(origin: $BlockPos_, reachX: number, reachY: number, reachZ: number): $Stream<$BlockPos>;
        static withinManhattan(origin: $BlockPos_, reachX: number, reachY: number, reachZ: number): $Iterable<$BlockPos>;
        above(steps: number): $BlockPos;
        above(): $BlockPos;
        asLong(): number;
        atY(y: number): $BlockPos;
        below(steps: number): $BlockPos;
        below(): $BlockPos;
        clampLocationWithin(location: $Vec3_): $Vec3;
        cross(upVector: $Vec3i): $BlockPos;
        east(steps: number): $BlockPos;
        east(): $BlockPos;
        immutable(): $BlockPos;
        multiply(scale: number): $BlockPos;
        mutable(): $BlockPos$MutableBlockPos;
        north(steps: number): $BlockPos;
        north(): $BlockPos;
        offset(x: number, y: number, z: number): $BlockPos;
        offset(vec: $Vec3i): $BlockPos;
        relative(axis: $Direction$Axis_, steps: number): $BlockPos;
        relative(direction: $Direction_, steps: number): $BlockPos;
        relative(direction: $Direction_): $BlockPos;
        rotate(rotation: $Rotation_): $BlockPos;
        south(steps: number): $BlockPos;
        south(): $BlockPos;
        subtract(vec: $Vec3i): $BlockPos;
        west(steps: number): $BlockPos;
        west(): $BlockPos;
    }

    export class $BlockPos$MutableBlockPos extends $BlockPos {
        constructor();
        constructor(x: number, y: number, z: number);
        constructor(x: number, y: number, z: number);
        clamp(axis: $Direction$Axis_, minimum: number, maximum: number): $BlockPos$MutableBlockPos;
        immutable(): $BlockPos;
        move(x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        move(direction: $Direction_, steps: number): $BlockPos$MutableBlockPos;
        move(direction: $Direction_): $BlockPos$MutableBlockPos;
        move(pos: $Vec3i): $BlockPos$MutableBlockPos;
        multiply(scale: number): $BlockPos;
        offset(x: number, y: number, z: number): $BlockPos;
        relative(axis: $Direction$Axis_, steps: number): $BlockPos;
        relative(direction: $Direction_, steps: number): $BlockPos;
        rotate(rotation: $Rotation_): $BlockPos;
        setWithOffset(pos: $Vec3i, x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        setWithOffset(pos: $Vec3i, direction: $Direction_): $BlockPos$MutableBlockPos;
        setWithOffset(pos: $Vec3i, offset: $Vec3i): $BlockPos$MutableBlockPos;
        set(x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        set(x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        set(pos: number): $BlockPos$MutableBlockPos;
        set(transform: $AxisCycle_, x: number, y: number, z: number): $BlockPos$MutableBlockPos;
        set(vec: $Vec3i): $BlockPos$MutableBlockPos;
    }

    export class $BlockPos$TraversalNodeStatus {
        static ACCEPT: $BlockPos$TraversalNodeStatus;
        static SKIP: $BlockPos$TraversalNodeStatus;
        static STOP: $BlockPos$TraversalNodeStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BlockPos$TraversalNodeStatus[];
        static valueOf(name: string): $BlockPos$TraversalNodeStatus;
    }

    export interface $ClientAsset {
        id(): $Identifier;
    }

    export class $ClientAsset$ResourceTexture extends $Record implements $ClientAsset$Texture {
        constructor(texture: $Identifier_);
        constructor(id: $Identifier_, texturePath: $Identifier_);
        static CODEC: $Codec<$ClientAsset$ResourceTexture>;
        static DEFAULT_FIELD_CODEC: $MapCodec<$ClientAsset$ResourceTexture>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientAsset$ResourceTexture>;
        equals(o: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        texturePath(): $Identifier;
        toString(): string;
    }

    export interface $ClientAsset$Texture extends $ClientAsset {
        texturePath(): $Identifier;
    }

    export class $Direction {
        static DOWN: $Direction;
        static EAST: $Direction;
        static NORTH: $Direction;
        static SOUTH: $Direction;
        static UP: $Direction;
        static WEST: $Direction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction[];
        static valueOf(name: string): $Direction;
    }

    export class $Direction$Axis {
        static X: $Direction$Axis;
        static Y: $Direction$Axis;
        static Z: $Direction$Axis;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$Axis[];
        static valueOf(name: string): $Direction$Axis;
    }

    export class $Direction$AxisDirection {
        static NEGATIVE: $Direction$AxisDirection;
        static POSITIVE: $Direction$AxisDirection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$AxisDirection[];
        static valueOf(name: string): $Direction$AxisDirection;
    }

    export class $Direction$Plane {
        static HORIZONTAL: $Direction$Plane;
        static VERTICAL: $Direction$Plane;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction$Plane[];
        static valueOf(name: string): $Direction$Plane;
    }

    export class $Direction8 {
        static EAST: $Direction8;
        static NORTH: $Direction8;
        static NORTH_EAST: $Direction8;
        static NORTH_WEST: $Direction8;
        static SOUTH: $Direction8;
        static SOUTH_EAST: $Direction8;
        static SOUTH_WEST: $Direction8;
        static WEST: $Direction8;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Direction8[];
        static valueOf(name: string): $Direction8;
    }

    export class $GlobalPos extends $Record {
        constructor(dimension: $ResourceKey<$Level>, pos: $BlockPos_);
        static CODEC: $Codec<$GlobalPos>;
        static MAP_CODEC: $MapCodec<$GlobalPos>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $GlobalPos>;
        static of(dimension: $ResourceKey<$Level>, pos: $BlockPos_): $GlobalPos;
        dimension(): $ResourceKey<$Level>;
        equals(o: object): boolean;
        hashCode(): number;
        isCloseEnough(dimension: $ResourceKey<$Level>, pos: $BlockPos_, maxDistance: number): boolean;
        pos(): $BlockPos;
        toString(): string;
    }

    export interface $Holder<T> {
        areComponentsBound(): boolean;
        canSerializeIn(registry: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        direct<T>(value: T, components: $DataComponentMap): $Holder<T>;
        direct<T>(value: T): $Holder<T>;
        getRegisteredName(): string;
        isBound(): boolean;
        is(predicate: $Predicate<$ResourceKey<T>>): boolean;
        is(holder: $Holder<T>): boolean;
        is(key: $Identifier_): boolean;
        is(key: $ResourceKey<T>): boolean;
        is(tag: $TagKey<T>): boolean;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export class $Holder$Kind {
        static DIRECT: $Holder$Kind;
        static REFERENCE: $Holder$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Holder$Kind[];
        static valueOf(name: string): $Holder$Kind;
    }

    export class $Holder$Reference<T> implements $Holder {
        get bound(): boolean;
        isBound(): boolean;
        static createIntrusive<T>(owner: $HolderOwner<T>, value: T): $Holder$Reference<T>;
        static createStandAlone<T>(owner: $HolderOwner<T>, key: $ResourceKey<T>): $Holder$Reference<T>;
        areComponentsBound(): boolean;
        bindComponents(components: $DataComponentMap): void;
        bindValue(value: T): void;
        canSerializeIn(context: $HolderOwner<T>): boolean;
        components(): $DataComponentMap;
        is(predicate: $Predicate<$ResourceKey<T>>): boolean;
        is(holder: $Holder<T>): boolean;
        is(key: $Identifier_): boolean;
        is(key: $ResourceKey<T>): boolean;
        is(tag: $TagKey<T>): boolean;
        key(): $ResourceKey<T>;
        kind(): $Holder$Kind;
        tags(): $Stream<$TagKey<T>>;
        toString(): string;
        unwrapKey(): $Optional<$ResourceKey<T>>;
        unwrap(): $Either<$ResourceKey<T>, T>;
        value(): T;
    }

    export interface $HolderGetter<T> {
        getOrThrow(id: $ResourceKey<T>): $Holder$Reference<T>;
        getOrThrow(id: $TagKey<T>): $HolderSet$Named<T>;
        getRandomElementOf(tag: $TagKey<T>, random: $RandomSource): $Optional<$Holder<T>>;
        get(id: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        get(id: $TagKey<T>): $Optional<$HolderSet$Named<T>>;
    }

    export interface $HolderGetter$Provider {
        getOrThrow<T>(id: $ResourceKey<T>): $Holder$Reference<T>;
        getOrThrow<T>(id: $TagKey<T>): $HolderSet$Named<T>;
        get<T>(id: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        get<T>(id: $TagKey<T>): $Optional<$HolderSet$Named<T>>;
        lookupOrThrow<T>(key: $ResourceKey<$Registry<T>>): $HolderGetter<T>;
        lookup<T>(key: $ResourceKey<$Registry<T>>): $Optional<$HolderGetter<T>>;
    }

    export interface $HolderLookup<T> extends $HolderGetter {
        listElementIds(): $Stream<$ResourceKey<T>>;
        listElements(): $Stream<$Holder$Reference<T>>;
        listTagIds(): $Stream<$TagKey<T>>;
        listTags(): $Stream<$HolderSet$Named<T>>;
    }

    export interface $HolderLookup$Provider extends $HolderGetter$Provider {
        allRegistriesLifecycle(): $Lifecycle;
        createSerializationContext<V>(parent: $DynamicOps<V>): $RegistryOps<V>;
        create(lookups: $Stream<$HolderLookup$RegistryLookup<any>>): $HolderLookup$Provider;
        listRegistries(): $Stream<$HolderLookup$RegistryLookup<any>>;
        listRegistryKeys(): $Stream<$ResourceKey<$Registry<any>>>;
        lookupOrThrow<T>(key: $ResourceKey<$Registry<T>>): $HolderLookup$RegistryLookup<T>;
        lookup<T>(key: $ResourceKey<$Registry<T>>): $Optional<$HolderLookup$RegistryLookup<T>>;
    }

    export interface $HolderLookup$RegistryLookup<T> extends $HolderLookup, $HolderOwner {
        filterElements(filter: $Predicate<T>): $HolderLookup$RegistryLookup<T>;
        filterFeatures(enabledFeatures: $FeatureFlagSet): $HolderLookup$RegistryLookup<T>;
        key(): $ResourceKey<$Registry<T>>;
        registryLifecycle(): $Lifecycle;
    }

    export interface $HolderOwner<T> {
        canSerializeIn(context: $HolderOwner<T>): boolean;
    }

    export interface $HolderSet<T> extends $Iterable {
        canSerializeIn(owner: $HolderOwner<T>): boolean;
        contains(value: $Holder<T>): boolean;
        direct<T>(values: $Holder<T>[]): $HolderSet$Direct<T>;
        direct<E, T>(holderGetter: $Function<E, $Holder<T>>, elements?: E[]): $HolderSet$Direct<T>;
        direct<E, T>(holderGetter: $Function<E, $Holder<T>>, elements: E[]): $HolderSet$Direct<T>;
        direct<T>(values?: $Holder<T>[]): $HolderSet$Direct<T>;
        emptyNamed<T>(owner: $HolderOwner<T>, key: $TagKey<T>): $HolderSet$Named<T>;
        empty<T>(): $HolderSet<T>;
        getRandomElement(random: $RandomSource): $Optional<$Holder<T>>;
        get(index: number): $Holder<T>;
        isBound(): boolean;
        size(): number;
        stream(): $Stream<$Holder<T>>;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export class $HolderSet$Direct<T> extends $HolderSet$ListBacked {
        get bound(): boolean;
        isBound(): boolean;
        contains(value: $Holder<T>): boolean;
        equals(obj: object): boolean;
        hashCode(): number;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export class $HolderSet$ListBacked<T> implements $HolderSet {
        constructor();
        canSerializeIn(owner: $HolderOwner<T>): boolean;
        getRandomElement(random: $RandomSource): $Optional<$Holder<T>>;
        get(index: number): $Holder<T>;
        iterator(): $Iterator<$Holder<T>>;
        size(): number;
        spliterator(): $Spliterator<$Holder<T>>;
        stream(): $Stream<$Holder<T>>;
    }

    export class $HolderSet$Named<T> extends $HolderSet$ListBacked {
        contents: $List<$Holder<T>>;
        get bound(): boolean;
        isBound(): boolean;
        canSerializeIn(context: $HolderOwner<T>): boolean;
        contains(value: $Holder<T>): boolean;
        key(): $TagKey<T>;
        toString(): string;
        unwrapKey(): $Optional<$TagKey<T>>;
        unwrap(): $Either<$TagKey<T>, $List<$Holder<T>>>;
    }

    export interface $IdMap<T> extends $Iterable {
        byIdOrThrow(id: number): T;
        byId(id: number): T;
        getIdOrThrow(value: T): number;
        getId(thing: T): number;
        size(): number;
        static DEFAULT: number;
    }

    export class $IdMapper<T> implements $IdMap, $RemovableIdMapper {
        constructor();
        constructor(expectedSize: number);
        addMapping(thing: T, id: number): void;
        add(thing: T): void;
        byId(id: number): T;
        contains(id: number): boolean;
        fabric_clear(): void;
        fabric_remapIds(arg0: $Int2IntMap): void;
        fabric_remapId(arg0: number, arg1: number): void;
        fabric_removeId(arg0: number): void;
        fabric_remove(arg0: object): void;
        getId(thing: T): number;
        iterator(): $Iterator<T>;
        size(): number;
    }

    export class $LayeredRegistryAccess<T> {
        constructor(keys: T[]);
        compositeAccess(): $RegistryAccess$Frozen;
        getAccessForLoading(forLayer: T): $RegistryAccess$Frozen;
        getAccessFrom(forLayer: T): $RegistryAccess$Frozen;
        getLayer(layer: T): $RegistryAccess$Frozen;
        replaceFrom(fromLayer: T, layers: $RegistryAccess$Frozen[]): $LayeredRegistryAccess<T>;
        replaceFrom(fromLayer: T, layers?: $RegistryAccess$Frozen[]): $LayeredRegistryAccess<T>;
    }

    export class $NonNullList<E> extends $AbstractList {
        static createWithCapacity<E>(capacity: number): $NonNullList<E>;
        static create<E>(): $NonNullList<E>;
        static of<E>(defaultValue: E, values?: E[]): $NonNullList<E>;
        static withSize<E>(size: number, defaultValue: E): $NonNullList<E>;
        add(index: number, element: E): void;
        clear(): void;
        get(index: number): E;
        remove(index: number): E;
        set(index: number, element: E): E;
        size(): number;
    }

    export interface $Position {
        x(): number;
        y(): number;
        z(): number;
    }

    export class $RegistrationInfo extends $Record {
        constructor(knownPackInfo: $Optional<$KnownPack>, lifecycle: $Lifecycle);
        static BUILT_IN: $RegistrationInfo;
        equals(o: object): boolean;
        hashCode(): number;
        knownPackInfo(): $Optional<$KnownPack>;
        lifecycle(): $Lifecycle;
        toString(): string;
    }

    export interface $Registry<T> extends $IdMap, $Keyable, $HolderLookup$RegistryLookup, $FabricRegistry, $RegistryMixin {
        asHolderIdMap(): $IdMap<$Holder<T>>;
        byNameCodec(): $Codec<T>;
        componentLookup(): $DataComponentLookup<T>;
        containsKey(key: $Identifier_): boolean;
        containsKey(key: $ResourceKey<T>): boolean;
        createIntrusiveHolder(value: T): $Holder$Reference<T>;
        entrySet(): $Set<$Map$Entry<$ResourceKey<T>, T>>;
        freeze(): $Registry<T>;
        getAny(): $Optional<$Holder$Reference<T>>;
        getId(thing: T): number;
        getKey(thing: T): $Identifier;
        getOptional(key: $Identifier_): $Optional<T>;
        getOptional(key: $ResourceKey<T>): $Optional<T>;
        getRandom(random: $RandomSource): $Optional<$Holder$Reference<T>>;
        getResourceKey(thing: T): $Optional<$ResourceKey<T>>;
        getTagOrEmpty(id: $TagKey<T>): $Iterable<$Holder<T>>;
        getTags(): $Stream<$HolderSet$Named<T>>;
        getValueOrThrow(key: $ResourceKey<T>): T;
        getValue(key: $Identifier_): T;
        getValue(key: $ResourceKey<T>): T;
        get(id: number): $Optional<$Holder$Reference<T>>;
        get(id: $Identifier_): $Optional<$Holder$Reference<T>>;
        holderByNameCodec(): $Codec<$Holder<T>>;
        keySet(): $Set<$Identifier>;
        keys<U>(ops: $DynamicOps<U>): $Stream<U>;
        key(): $ResourceKey<$Registry<T>>;
        prepareTagReload(tags: $TagLoader$LoadResult<T>): $Registry$PendingTags<T>;
        registerForHolder<R, T>(registry: $Registry<R>, location: $Identifier_, value: T): $Holder$Reference<T>;
        registerForHolder<R, T>(registry: $Registry<R>, key: $ResourceKey<R>, value: T): $Holder$Reference<T>;
        register<T>(registry: $Registry<any>, name: string, value: T): T;
        register<V, T>(registry: $Registry<V>, location: $Identifier_, value: T): T;
        register<V, T>(registry: $Registry<V>, key: $ResourceKey<V>, value: T): T;
        registrationInfo(element: $ResourceKey<T>): $Optional<$RegistrationInfo>;
        registryKeySet(): $Set<$ResourceKey<T>>;
        stream(): $Stream<T>;
        wrapAsHolder(value: T): $Holder<T>;
    }

    export interface $Registry$PendingTags<T> {
        apply(): void;
        key(): $ResourceKey<$Registry<T>>;
        lookup(): $HolderLookup$RegistryLookup<T>;
        size(): number;
    }

    export interface $RegistryAccess extends $HolderLookup$Provider {
        freeze(): $RegistryAccess$Frozen;
        fromRegistryOfRegistries(registries: $Registry<$Registry<any>>): $RegistryAccess$Frozen;
        listRegistryKeys(): $Stream<$ResourceKey<$Registry<any>>>;
        lookupOrThrow<E>(name: $ResourceKey<$Registry<E>>): $Registry<E>;
        lookup<E>(registryKey: $ResourceKey<$Registry<E>>): $Optional<$Registry<E>>;
        registries(): $Stream<$RegistryAccess$RegistryEntry<any>>;
        static EMPTY: $RegistryAccess$Frozen;
        static LOGGER: $Logger;
    }

    export interface $RegistryAccess$Frozen extends $RegistryAccess {
    }

    export class $RegistryAccess$RegistryEntry<T> extends $Record {
        constructor(key: $ResourceKey<$Registry<T>>, value: $Registry<T>);
        equals(o: object): boolean;
        hashCode(): number;
        key(): $ResourceKey<$Registry<T>>;
        toString(): string;
        value(): $Registry<T>;
    }

    export class $Rotations extends $Record {
        constructor(x: number, y: number, z: number);
        static CODEC: $Codec<$Rotations>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Rotations>;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        x(): number;
        y(): number;
        z(): number;
    }

    export class $SectionPos extends $Vec3i {
        static SECTION_BITS: number;
        static SECTION_HALF_SIZE: number;
        static SECTION_MASK: number;
        static SECTION_MAX_INDEX: number;
        static SECTION_SIZE: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $SectionPos>;
        static aroundAndAtBlockPos(blockX: number, blockY: number, blockZ: number, sectionConsumer: $LongConsumer): void;
        static aroundAndAtBlockPos(blockPos: number, sectionConsumer: $LongConsumer): void;
        static aroundAndAtBlockPos(blockPos: $BlockPos_, sectionConsumer: $LongConsumer): void;
        static aroundChunk(center: $ChunkPos, radius: number, minSection: number, maxSection: number): $Stream<$SectionPos>;
        static asLong(x: number, y: number, z: number): number;
        static asLong(pos: $BlockPos_): number;
        static betweenClosedStream(minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): $Stream<$SectionPos>;
        static blockToSectionCoord(coord: number): number;
        static blockToSectionCoord(blockCoord: number): number;
        static blockToSection(blockNode: number): number;
        static bottomOf(chunk: $ChunkAccess): $SectionPos;
        static cube(center: $SectionPos, radius: number): $Stream<$SectionPos>;
        static getZeroNode(x: number, z: number): number;
        static getZeroNode(sectionNode: number): number;
        static offset(sectionNode: number, stepX: number, stepY: number, stepZ: number): number;
        static offset(sectionNode: number, offset: $Direction_): number;
        static of(x: number, y: number, z: number): $SectionPos;
        static of(sectionNode: number): $SectionPos;
        static of(pos: $BlockPos_): $SectionPos;
        static of(pos: $Position): $SectionPos;
        static of(pos: $ChunkPos, sectionY: number): $SectionPos;
        static of(entity: $EntityAccess): $SectionPos;
        static posToSectionCoord(pos: number): number;
        static sectionRelativePos(pos: $BlockPos_): number;
        static sectionRelativeX(relative: number): number;
        static sectionRelativeY(relative: number): number;
        static sectionRelativeZ(relative: number): number;
        static sectionRelative(blockCoord: number): number;
        static sectionToBlockCoord(sectionCoord: number, offset: number): number;
        static sectionToBlockCoord(sectionCoord: number): number;
        static sectionToChunk(sectionNode: number): number;
        static x(sectionNode: number): number;
        static y(sectionNode: number): number;
        static z(sectionNode: number): number;
        asLong(): number;
        blocksInside(): $Stream<$BlockPos>;
        center(): $BlockPos;
        chunk(): $ChunkPos;
        maxBlockX(): number;
        maxBlockY(): number;
        maxBlockZ(): number;
        minBlockX(): number;
        minBlockY(): number;
        minBlockZ(): number;
        offset(x: number, y: number, z: number): $SectionPos;
        origin(): $BlockPos;
        relativeToBlockPos(relative: number): $BlockPos;
        relativeToBlockX(relative: number): number;
        relativeToBlockY(relative: number): number;
        relativeToBlockZ(relative: number): number;
        x(): number;
        y(): number;
        z(): number;
    }

    export interface $TypedInstance<T> {
        is(rawType: T): boolean;
        is(type: $Holder<T>): boolean;
        is(set: $HolderSet<T>): boolean;
        is(type: $ResourceKey<T>): boolean;
        is(tag: $TagKey<T>): boolean;
        tags(): $Stream<$TagKey<T>>;
        typeHolder(): $Holder<T>;
    }

    export class $Vec3i implements $Comparable {
        constructor(x: number, y: number, z: number);
        static CODEC: $Codec<$Vec3i>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Vec3i>;
        static ZERO: $Vec3i;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        static offsetCodec(maxOffsetPerAxis: number): $Codec<$Vec3i>;
        above(steps: number): $Vec3i;
        above(): $Vec3i;
        below(steps: number): $Vec3i;
        below(): $Vec3i;
        closerThan(pos: $Vec3i, distance: number): boolean;
        closerToCenterThan(pos: $Position, distance: number): boolean;
        compareTo(pos: $Vec3i): number;
        cross(upVector: $Vec3i): $Vec3i;
        distChessboard(pos: $Vec3i): number;
        distManhattan(pos: $Vec3i): number;
        distSqr(pos: $Vec3i): number;
        distToCenterSqr(x: number, y: number, z: number): number;
        distToCenterSqr(pos: $Position): number;
        distToLowCornerSqr(x: number, y: number, z: number): number;
        east(steps: number): $Vec3i;
        east(): $Vec3i;
        equals(o: object): boolean;
        get(axis: $Direction$Axis_): number;
        hashCode(): number;
        multiply(xScale: number, yScale: number, zScale: number): $Vec3i;
        multiply(scale: number): $Vec3i;
        north(steps: number): $Vec3i;
        north(): $Vec3i;
        offset(x: number, y: number, z: number): $Vec3i;
        offset(vec: $Vec3i): $Vec3i;
        relative(axis: $Direction$Axis_, steps: number): $Vec3i;
        relative(direction: $Direction_, steps: number): $Vec3i;
        relative(direction: $Direction_): $Vec3i;
        south(steps: number): $Vec3i;
        south(): $Vec3i;
        subtract(vec: $Vec3i): $Vec3i;
        toMutable(): $Vector3i;
        toShortString(): string;
        toString(): string;
        west(steps: number): $Vec3i;
        west(): $Vec3i;
    }

    export type $AxisCycle_ = $AxisCycle | "BACKWARD" | "FORWARD" | "NONE";
    export type $BlockPos_ = $BlockPos | $Vec3 | { x: number, y: number, z: number } | number[];
    export type $BlockPos$TraversalNodeStatus_ = $BlockPos$TraversalNodeStatus | "ACCEPT" | "SKIP" | "STOP";
    export type $Direction_ = $Direction | "DOWN" | "EAST" | "NORTH" | "SOUTH" | "UP" | "WEST";
    export type $Direction$Axis_ = $Direction$Axis | "X" | "Y" | "Z";
    export type $Direction$AxisDirection_ = $Direction$AxisDirection | "NEGATIVE" | "POSITIVE";
    export type $Direction$Plane_ = $Direction$Plane | "HORIZONTAL" | "VERTICAL";
    export type $Direction8_ = $Direction8 | "EAST" | "NORTH" | "NORTH_EAST" | "NORTH_WEST" | "SOUTH" | "SOUTH_EAST" | "SOUTH_WEST" | "WEST";
    /** registry entry id, e.g. 'minecraft:sharpness' (namespace defaults to minecraft) */
    export type $Holder_ = $Holder | string;
    export type $Holder$Kind_ = $Holder$Kind | "DIRECT" | "REFERENCE";
}
