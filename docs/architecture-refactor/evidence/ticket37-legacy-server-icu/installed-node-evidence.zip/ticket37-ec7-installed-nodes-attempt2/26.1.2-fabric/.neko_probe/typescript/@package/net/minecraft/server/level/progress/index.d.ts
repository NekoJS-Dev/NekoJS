import { $Enum, $String } from "java:java/lang";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $ChunkPos, $Level } from "java:net/minecraft/world/level";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";

declare module "java:net/minecraft/server/level/progress" {
    export interface $ChunkLoadStatusView {
        get(x: number, z: number): $ChunkStatus;
        moveTo(dimension: $ResourceKey<$Level>, centerChunk: $ChunkPos): void;
        radius(): number;
    }

    export interface $LevelLoadListener {
        compose(first: $LevelLoadListener, second: $LevelLoadListener): $LevelLoadListener;
        finish(stage: $LevelLoadListener$Stage_): void;
        start(stage: $LevelLoadListener$Stage_, totalChunks: number): void;
        updateFocus(dimension: $ResourceKey<$Level>, chunkPos: $ChunkPos): void;
        update(stage: $LevelLoadListener$Stage_, currentChunks: number, totalChunks: number): void;
    }

    export class $LevelLoadListener$Stage {
        static LOAD_INITIAL_CHUNKS: $LevelLoadListener$Stage;
        static LOAD_PLAYER_CHUNKS: $LevelLoadListener$Stage;
        static PREPARE_GLOBAL_SPAWN: $LevelLoadListener$Stage;
        static START_SERVER: $LevelLoadListener$Stage;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LevelLoadListener$Stage[];
        static valueOf(name: string): $LevelLoadListener$Stage;
    }

    export type $LevelLoadListener$Stage_ = $LevelLoadListener$Stage | "LOAD_INITIAL_CHUNKS" | "LOAD_PLAYER_CHUNKS" | "PREPARE_GLOBAL_SPAWN" | "START_SERVER";
}
