import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Integer, $Record, $RuntimeException, $StackTraceElement, $String, $StringBuilder, $Throwable } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Collection, $List } from "java:java/util";
import { $Callable } from "java:java/util/concurrent";
import { $Supplier } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $LevelHeightAccessor } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";

export * as advancements from "java:net/minecraft/advancements";
export * as commands from "java:net/minecraft/commands";
export * as core from "java:net/minecraft/core";
export * as data from "java:net/minecraft/data";
export * as gametest from "java:net/minecraft/gametest";
export * as nbt from "java:net/minecraft/nbt";
export * as network from "java:net/minecraft/network";
export * as resources from "java:net/minecraft/resources";
export * as server from "java:net/minecraft/server";
export * as sounds from "java:net/minecraft/sounds";
export * as stats from "java:net/minecraft/stats";
export * as tags from "java:net/minecraft/tags";
export * as util from "java:net/minecraft/util";
export * as world from "java:net/minecraft/world";

declare module "java:net/minecraft" {
    export class $ChatFormatting {
        static AQUA: $ChatFormatting;
        static BLACK: $ChatFormatting;
        static BLUE: $ChatFormatting;
        static BOLD: $ChatFormatting;
        static DARK_AQUA: $ChatFormatting;
        static DARK_BLUE: $ChatFormatting;
        static DARK_GRAY: $ChatFormatting;
        static DARK_GREEN: $ChatFormatting;
        static DARK_PURPLE: $ChatFormatting;
        static DARK_RED: $ChatFormatting;
        static GOLD: $ChatFormatting;
        static GRAY: $ChatFormatting;
        static GREEN: $ChatFormatting;
        static ITALIC: $ChatFormatting;
        static LIGHT_PURPLE: $ChatFormatting;
        static OBFUSCATED: $ChatFormatting;
        static RED: $ChatFormatting;
        static RESET: $ChatFormatting;
        static STRIKETHROUGH: $ChatFormatting;
        static UNDERLINE: $ChatFormatting;
        static WHITE: $ChatFormatting;
        static YELLOW: $ChatFormatting;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChatFormatting[];
        static valueOf(name: string): $ChatFormatting;
    }

    export class $CrashReport {
        constructor(title: string, t: $Throwable);
        get details(): string;
        getDetails(): string;
        get exceptionMessage(): string;
        getExceptionMessage(): string;
        get exception(): $Throwable;
        getException(): $Throwable;
        get saveFile(): $Path;
        getSaveFile(): $Path;
        get systemReport(): $SystemReport;
        getSystemReport(): $SystemReport;
        get title(): string;
        getTitle(): string;
        static forThrowable(t: $Throwable, title: string): $CrashReport;
        static preload(): void;
        addCategory(name: string, nestedOffset: number): $CrashReportCategory;
        addCategory(name: string): $CrashReportCategory;
        getDetails(builder: $StringBuilder): void;
        getFriendlyReport(reportType: $ReportType, extraComments: string[]): string;
        getFriendlyReport(reportType: $ReportType): string;
        saveToFile(saveFile: string, reportType: $ReportType, extraComments: string[]): boolean;
        saveToFile(file: string, reportType: $ReportType): boolean;
    }

    export class $CrashReportCategory {
        constructor(title: string);
        get stacktrace(): $StackTraceElement[];
        getStacktrace(): $StackTraceElement[];
        static formatLocation(x: number, y: number, z: number): string;
        static formatLocation(levelHeightAccessor: $LevelHeightAccessor, x: number, y: number, z: number): string;
        static formatLocation(levelHeightAccessor: $LevelHeightAccessor, x: number, y: number, z: number): string;
        static formatLocation(levelHeightAccessor: $LevelHeightAccessor, pos: $BlockPos_): string;
        static populateBlockDetails(category: $CrashReportCategory, levelHeightAccessor: $LevelHeightAccessor, pos: $BlockPos_, state: $BlockState_): void;
        static populateBlockLocationDetails(category: $CrashReportCategory, levelHeightAccessor: $LevelHeightAccessor, pos: $BlockPos_): $CrashReportCategory;
        fillInStackTrace(nestedOffset: number): number;
        getDetails(builder: $StringBuilder): void;
        setDetailError(key: string, t: $Throwable): void;
        setDetail(key: string, value: object): $CrashReportCategory;
        setDetail(key: string, callback: $CrashReportDetail<string>): $CrashReportCategory;
        trimStacktrace(length: number): void;
        validateStackTrace(source: $StackTraceElement, next: $StackTraceElement): boolean;
    }

    export interface $CrashReportDetail<V> extends $Callable {
    }

    export class $ReportType extends $Record {
        constructor(header: string, nuggets: string[]);
        static CHUNK_IO_ERROR: $ReportType;
        static CRASH: $ReportType;
        static NETWORK_PROTOCOL_ERROR: $ReportType;
        static PROFILE: $ReportType;
        static TEST: $ReportType;
        get errorComment(): string;
        getErrorComment(): string;
        appendHeader(builder: $StringBuilder, extraComments: string[]): void;
        equals(o: object): boolean;
        hashCode(): number;
        header(): string;
        nuggets(): $List<string>;
        toString(): string;
    }

    export class $ReportedException extends $RuntimeException {
        constructor(report: $CrashReport);
        get cause(): $Throwable;
        getCause(): $Throwable;
        get message(): string;
        getMessage(): string;
        get report(): $CrashReport;
        getReport(): $CrashReport;
    }

    export class $SystemReport {
        constructor();
        static BYTES_PER_MEBIBYTE: number;
        static sizeInMiB(bytes: number): number;
        appendToCrashReportString(sb: $StringBuilder): void;
        setDetail(key: string, value: string): void;
        setDetail(key: string, valueSupplier: $Supplier<string>): void;
        toLineSeparatedString(): string;
    }

    export type $ChatFormatting_ = $ChatFormatting | "AQUA" | "BLACK" | "BLUE" | "BOLD" | "DARK_AQUA" | "DARK_BLUE" | "DARK_GRAY" | "DARK_GREEN" | "DARK_PURPLE" | "DARK_RED" | "GOLD" | "GRAY" | "GREEN" | "ITALIC" | "LIGHT_PURPLE" | "OBFUSCATED" | "RED" | "RESET" | "STRIKETHROUGH" | "UNDERLINE" | "WHITE" | "YELLOW";
}
