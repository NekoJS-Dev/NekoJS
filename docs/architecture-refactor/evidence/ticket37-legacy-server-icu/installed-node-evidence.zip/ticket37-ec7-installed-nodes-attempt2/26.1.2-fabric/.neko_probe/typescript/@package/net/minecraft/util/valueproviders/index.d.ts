import { $MapCodec } from "java:com/mojang/serialization";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/util/valueproviders" {
    export interface $IntProvider {
        codec(): $MapCodec<$IntProvider>;
        maxInclusive(): number;
        minInclusive(): number;
        sample(random: $RandomSource): number;
    }

}
