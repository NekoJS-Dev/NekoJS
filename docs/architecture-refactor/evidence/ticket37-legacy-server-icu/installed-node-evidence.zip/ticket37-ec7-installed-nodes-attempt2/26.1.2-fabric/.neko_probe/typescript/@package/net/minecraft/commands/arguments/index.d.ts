import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $BiConsumer, $Supplier } from "java:java/util/function";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $CompoundTag, $CompoundTag_, $Tag } from "java:net/minecraft/nbt";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $MessageSignature, $SignableCommand } from "java:net/minecraft/network/chat";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as selector from "java:net/minecraft/commands/arguments/selector";

declare module "java:net/minecraft/commands/arguments" {
    export class $ArgumentSignatures extends $Record {
        constructor(entries: $ArgumentSignatures$Entry[]);
        constructor(input: $FriendlyByteBuf);
        static EMPTY: $ArgumentSignatures;
        static signCommand(command: $SignableCommand<any>, signer: $ArgumentSignatures$Signer): $ArgumentSignatures;
        entries(): $List<$ArgumentSignatures$Entry>;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        write(output: $FriendlyByteBuf): void;
    }

    export class $ArgumentSignatures$Entry extends $Record {
        constructor(name: string, signature: $MessageSignature);
        constructor(input: $FriendlyByteBuf);
        equals(o: object): boolean;
        hashCode(): number;
        name(): string;
        signature(): $MessageSignature;
        toString(): string;
        write(output: $FriendlyByteBuf): void;
    }

    export interface $ArgumentSignatures$Signer {
        sign(content: string): $MessageSignature;
    }

    export class $EntityAnchorArgument$Anchor {
        static EYES: $EntityAnchorArgument$Anchor;
        static FEET: $EntityAnchorArgument$Anchor;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EntityAnchorArgument$Anchor[];
        static valueOf(name: string): $EntityAnchorArgument$Anchor;
    }

    export class $NbtPathArgument$NbtPath {
        constructor(original: string, nodes: $NbtPathArgument$Node[], nodeToOriginalPosition: $Object2IntMap<$NbtPathArgument$Node>);
        static CODEC: $Codec<$NbtPathArgument$NbtPath>;
        static isTooDeep(tag: $Tag, depth: number): boolean;
        static of(string: string): $NbtPathArgument$NbtPath;
        asString(): string;
        countMatching(tag: $Tag): number;
        getOrCreate(tag: $Tag, newTagValue: $Supplier<$Tag>): $List<$Tag>;
        get(tag: $Tag): $List<$Tag>;
        insert(index: number, target: $CompoundTag_, toInsert: $Tag[]): number;
        remove(tag: $Tag): number;
        set(tag: $Tag, toAdd: $Tag): number;
        toString(): string;
    }

    export interface $NbtPathArgument$Node {
        collect(tags: $Tag[], collector: $BiConsumer<$Tag, $Tag[]>): $List<$Tag>;
        createPreferredParentTag(): $Tag;
        getOrCreateTag(parent: $Tag, child: $Supplier<$Tag>, output: $Tag[]): void;
        getOrCreate(tags: $Tag[], child: $Supplier<$Tag>): $List<$Tag>;
        getTag(parent: $Tag, output: $Tag[]): void;
        get(tags: $Tag[]): $List<$Tag>;
        removeTag(parent: $Tag): number;
        setTag(parent: $Tag, toAdd: $Supplier<$Tag>): number;
    }

    export type $EntityAnchorArgument$Anchor_ = $EntityAnchorArgument$Anchor | "EYES" | "FEET";
}
