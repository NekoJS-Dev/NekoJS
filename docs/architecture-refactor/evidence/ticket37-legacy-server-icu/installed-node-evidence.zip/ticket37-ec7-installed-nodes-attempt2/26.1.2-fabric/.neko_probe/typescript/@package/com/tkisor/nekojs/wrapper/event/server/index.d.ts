import { $JsonElement, $JsonObject } from "java:com/google/gson";
import { $CommandDispatcher } from "java:com/mojang/brigadier";
import { $RecipeCreationContext, $RecipeEntryJS, $RecipeFilter, $RecipeFilter_, $RecipeJsonBuilder, $RecipeJsonValue, $RecipeJsonValue_, $RecipeLifecycleContext } from "java:com/tkisor/nekojs/api/recipe";
import { $RecipeTypeDefinitionRegistry } from "java:com/tkisor/nekojs/api/recipe/definition";
import { $RecipeRegistryProxy } from "java:com/tkisor/nekojs/wrapper";
import { $Value } from "java:graal/graalvm/polyglot";
import { $ProxyObject } from "java:graal/graalvm/polyglot/proxy";
import { $Boolean, $Double, $Exception, $Float, $Integer, $Record, $String } from "java:java/lang";
import { $List, $Map, $Set } from "java:java/util";
import { $Consumer } from "java:java/util/function";
import { $CommandBuildContext, $CommandSourceStack } from "java:net/minecraft/commands";
import { $HolderLookup$Provider, $RegistryAccess } from "java:net/minecraft/core";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $PlayerList } from "java:net/minecraft/server/players";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_, $Recipe, $RecipeHolder } from "java:net/minecraft/world/item/crafting";
import { $LootTable$Builder } from "java:net/minecraft/world/level/storage/loot";

import { DocumentedRecipes } from "@side-only/server/events/recipes";

declare module "java:com/tkisor/nekojs/wrapper/event/server" {
    export class $BlockModificationEventJS {
        constructor(plan: $ModificationCandidatePlan);
        /**
         * Number of declarations recorded so far during this event.
         * @returns how many declarations this event has collected
         */
        get modifiedCount(): number;
        getModifiedCount(): number;
        /**
         * Records a runtime property modification declaration for one block.
         * @param blockId block id like 'minecraft:stone' (the 'minecraft:' prefix is optional)
         * @param modifier callback receiving a block property view; assign block.hardness / block.resistance / block.lightLevel / block.requiresTool / block.friction / block.jumpFactor
         */
        modify(blockId: string, modifier: $Consumer<$BlockModificationJS>): void;
    }

    export class $BlockModificationJS implements $ProxyObject {
        /**
         * Current surface friction of the block (0..1; ice is 0.98, default 0.6).
         * @returns the current friction: the pending change if set, otherwise the block's live value
         */
        get friction(): number;
        getFriction(): number;
        set friction(value: number);
        /**
         * Current destroy-time hardness of the block.
         * Reads the live value until you assign a new one; -1-style unbreakable is not allowed here (set a very high value instead).
         * @returns the current hardness: the pending change if set, otherwise the block's live value
         */
        get hardness(): number;
        getHardness(): number;
        set hardness(value: number);
        /**
         * Current jump factor of the block (vanilla blocks use 0.5..1).
         * @returns the current jump factor: the pending change if set, otherwise the block's live value
         */
        get jumpFactor(): number;
        getJumpFactor(): number;
        set jumpFactor(value: number);
        /**
         * Current light emission of the block (0..15).
         * @returns the current light level: the pending change if set, otherwise the block's live value
         */
        get lightLevel(): number;
        getLightLevel(): number;
        set lightLevel(value: number);
        get memberKeys(): object;
        getMemberKeys(): object;
        /**
         * Whether the block requires the correct tool tier to drop loot.
         * @returns the current flag: the pending change if set, otherwise the block's live value
         */
        get requiresTool(): boolean;
        getRequiresTool(): boolean;
        set requiresTool(value: boolean);
        /**
         * Current blast resistance of the block.
         * @returns the current resistance: the pending change if set, otherwise the block's live value
         */
        get resistance(): number;
        getResistance(): number;
        set resistance(value: number);
        getMember(name: string): object;
        hasMember(name: string): boolean;
        putMember(name: string, value: $Value): void;
        removeMember(name: string): boolean;
    }

    export class $CommandRegistryEventJS {
        constructor(dispatcher: $CommandDispatcher<$CommandSourceStack>, registryAccess: $CommandBuildContext);
        get dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        getDispatcher(): $CommandDispatcher<$CommandSourceStack>;
        get registryAccess(): $CommandBuildContext;
        getRegistryAccess(): $CommandBuildContext;
    }

    /**
     * Fired when datapack-synced content should be (re)sent to players.
     * player is null when syncing to all players after a reload.
     */
    export class $DatapackSyncEventJS {
        constructor(player: $ServerPlayer, playerList: $PlayerList);
        get playerList(): $PlayerList;
        getPlayerList(): $PlayerList;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
    }

    export class $ItemModificationComponents$FoodSpec extends $Record {
        constructor(nutrition: number, saturation: number, canAlwaysEat: boolean, eatSeconds: number);
        static fromNormalized(map: { [key: string]: object }): $ItemModificationComponents$FoodSpec;
        canAlwaysEat(): boolean;
        eatSeconds(): number;
        equals(o: object): boolean;
        hashCode(): number;
        nutrition(): number;
        saturation(): number;
        toNormalized(): $Map<string, object>;
        toString(): string;
    }

    export class $ItemModificationComponents$ToolSpec extends $Record {
        constructor(miningSpeed: number, damagePerBlock: number, canDestroyBlocksInCreative: boolean);
        static fromNormalized(map: { [key: string]: object }): $ItemModificationComponents$ToolSpec;
        canDestroyBlocksInCreative(): boolean;
        damagePerBlock(): number;
        equals(o: object): boolean;
        hashCode(): number;
        miningSpeed(): number;
        toNormalized(): $Map<string, object>;
        toString(): string;
    }

    export class $ItemModificationEventJS {
        constructor(plan: $ModificationCandidatePlan);
        get modifiedCount(): number;
        getModifiedCount(): number;
        modify(itemId: string, modifier: $Consumer<$ItemModificationJS>): void;
    }

    export class $ItemModificationJS implements $ProxyObject {
        constructor();
        /**
         * Replaces the item's base attack damage modifier (minecraft:base_attack_damage, ADD_VALUE on mainhand), keeping every other attribute entry - including attack speed.
         * The value is a bonus on top of the player's base attack damage (2.0 on 26.x), so total damage = 2.0 + value.
         * @returns Pending attack damage override, or null when not set.
         */
        get attackDamage(): number;
        getAttackDamage(): number;
        set attackDamage(value: number);
        /**
         * Replaces the item's base attack speed modifier (minecraft:base_attack_speed, ADD_VALUE on mainhand), keeping every other attribute entry - including attack damage.
         * The value is a bonus on top of the player's base attack speed (4.0 on 26.x): a sword uses -2.4 for a total of 1.6.
         * @returns Pending attack speed override, or null when not set.
         */
        get attackSpeed(): number;
        getAttackSpeed(): number;
        set attackSpeed(value: number);
        get fireResistant(): boolean;
        getFireResistant(): boolean;
        set fireResistant(value: boolean);
        /**
         * The pending food override as { nutrition, saturation, canAlwaysEat, eatSeconds }, or null when unset (keep current food) or when removal was requested with item.food = null.
         * @returns Pending food spec, or null.
         */
        get food(): $ItemModificationComponents$FoodSpec;
        getFood(): $ItemModificationComponents$FoodSpec;
        set food(value: object);
        get maxDamage(): number;
        getMaxDamage(): number;
        set maxDamage(value: number);
        get maxStackSize(): number;
        getMaxStackSize(): number;
        set maxStackSize(value: number);
        get memberKeys(): object;
        getMemberKeys(): object;
        get rarity(): string;
        getRarity(): string;
        set rarity(value: object);
        /**
         * The pending tool override as { miningSpeed, damagePerBlock, canDestroyBlocksInCreative }, or null when unset or when removal was requested.
         * @returns Pending tool spec, or null.
         */
        get tool(): $ItemModificationComponents$ToolSpec;
        getTool(): $ItemModificationComponents$ToolSpec;
        set tool(value: object);
        getMember(name: string): object;
        hasMember(name: string): boolean;
        putMember(name: string, value: $Value): void;
        removeMember(name: string): boolean;
    }

    /**
     * Fired when a loot table is loaded (ServerEvents.lootTableLoad).
     * Modify via event.table (builder on fabric, full table on NeoForge).
     */
    export class $LootTableLoadEventJS {
        constructor(id: $Identifier_, table: $LootTable$Builder, registries: $HolderLookup$Provider);
        get id(): $Identifier;
        getId(): $Identifier;
        get registries(): $HolderLookup$Provider;
        getRegistries(): $HolderLookup$Provider;
        get table(): $LootTable$Builder;
        getTable(): $LootTable$Builder;
    }

    export class $RecipeEventJS implements $RecipeLifecycleContext {
        constructor(originalJsons: { [key: $Identifier_]: $JsonElement }, registries: $HolderLookup$Provider);
        constructor(originalJsons: { [key: $Identifier_]: $JsonElement }, registries: $HolderLookup$Provider, recipeTypeDefinitions: $RecipeTypeDefinitionRegistry);
        get finalJsons(): $Map<$Identifier, $JsonElement>;
        getFinalJsons(): $Map<$Identifier, $JsonElement>;
        get recipeTypeDefinitions(): $RecipeTypeDefinitionRegistry;
        getRecipeTypeDefinitions(): $RecipeTypeDefinitionRegistry;
        get recipes(): DocumentedRecipes;
        static getIngredients(recipe: $Recipe<any>): $List<$Ingredient>;
        static getRecipeOutputId(recipe: $Recipe<any>, registries: $HolderLookup$Provider): string;
        static getRecipeOutputId(recipe: $Recipe<any>): string;
        static ingredientMatches(ingredient: $Ingredient_, tagKey: $TagKey<$Item_>, itemID: $Identifier_, registries: $HolderLookup$Provider): boolean;
        static recipeGroup(recipe: $Recipe<any>): string;
        static recipeHolderId(holder: $RecipeHolder<any>): $Identifier;
        all(): $List<$RecipeEntryJS>;
        blasting(result: $ItemStack_, ingredient: $Ingredient_, xp: number, cookTime: number): $RecipeJsonBuilder;
        blasting(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        builder(type: string): $RecipeJsonBuilder;
        campfireCooking(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        count(filter: $RecipeFilter_): number;
        count(): number;
        custom(recipeJson: $JsonObject): $RecipeJsonBuilder;
        custom(value: $RecipeJsonValue_): $RecipeJsonBuilder;
        custom(type: string, value: $RecipeJsonValue_): $RecipeJsonBuilder;
        describeRecipe(id: $Identifier_, json: $JsonObject): string;
        dump(filter: $RecipeFilter_): string;
        dump(): string;
        exists(filter: $RecipeFilter_): boolean;
        exists(id: string): boolean;
        find(filter: $RecipeFilter_): $List<$RecipeEntryJS>;
        forEach(filter: $RecipeFilter_, callback: $Consumer<$RecipeEntryJS>): void;
        forEach(callback: $Consumer<$RecipeEntryJS>): void;
        formatRecipeError(prefix: string, id: $Identifier_, json: $JsonObject, e: $Exception): string;
        generateRecipeId(prefix: string): $Identifier;
        getJson(id: string): string;
        getRecipeContext(id: $Identifier_): $RecipeCreationContext;
        get(id: string): $RecipeEntryJS;
        ids(): $Set<string>;
        modify(filter: $RecipeFilter_, callback: $Consumer<$RecipeEntryJS>): void;
        print(filter: $RecipeFilter_): void;
        print(): void;
        removeById(id: string): void;
        removeRecipeContext(id: $Identifier_): void;
        remove(filter: $RecipeFilter_): void;
        replaceInput(filter: $RecipeFilter_, match: $Ingredient_, replacement: $Ingredient_): void;
        replaceOutput(filter: $RecipeFilter_, match: $Ingredient_, replacement: $ItemStack_): void;
        serializeIngredient(ingredient: $Ingredient_): $JsonElement;
        serializeResult(stack: $ItemStack_): $JsonElement;
        setJson(id: string, json: string): void;
        setRecipeContext(id: $Identifier_, context: $RecipeCreationContext): void;
        shaped(result: $ItemStack_, pattern: string[], keys: { [key: string]: $Ingredient_ }): $RecipeJsonBuilder;
        shapeless(result: $ItemStack_, ingredients: $Ingredient_[]): $RecipeJsonBuilder;
        smelting(result: $ItemStack_, ingredient: $Ingredient_, xp: number, cookTime: number): $RecipeJsonBuilder;
        smelting(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        smoking(result: $ItemStack_, ingredient: $Ingredient_): $RecipeJsonBuilder;
        validateRecipe(id: $Identifier_, json: $JsonObject): void;
    }

    export class $ServerLifecycleEventJS {
        constructor(server: $MinecraftServer);
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
    }

    export class $ServerTickEventJS {
        constructor(server: $MinecraftServer);
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
    }

    /** Fired after tags have been (re)loaded on the server. */
    export class $TagUpdatedEventJS {
        constructor(registries: $RegistryAccess, shouldUpdateStaticData: boolean);
        get registries(): $RegistryAccess;
        getRegistries(): $RegistryAccess;
        get shouldUpdateStaticData(): boolean;
        isShouldUpdateStaticData(): boolean;
    }

}
