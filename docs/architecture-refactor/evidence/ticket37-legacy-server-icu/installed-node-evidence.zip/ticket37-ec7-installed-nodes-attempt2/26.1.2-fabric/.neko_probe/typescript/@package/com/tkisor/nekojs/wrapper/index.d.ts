import { $Value } from "java:graal/graalvm/polyglot";
import { $ProxyObject } from "java:graal/graalvm/polyglot/proxy";
import { $String } from "java:java/lang";
import { $List, $Map } from "java:java/util";

export * as clientdata from "java:com/tkisor/nekojs/wrapper/clientdata";
export * as entity from "java:com/tkisor/nekojs/wrapper/entity";
export * as event from "java:com/tkisor/nekojs/wrapper/event";
export * as item from "java:com/tkisor/nekojs/wrapper/item";
export * as network from "java:com/tkisor/nekojs/wrapper/network";
export * as pdata from "java:com/tkisor/nekojs/wrapper/pdata";
export * as registry from "java:com/tkisor/nekojs/wrapper/registry";

declare module "java:com/tkisor/nekojs/wrapper" {
    /** Implemented by JS wrappers that can expose their wrapped native object. */
    export interface $NekoWrapper<T> {
        /**
         * Unwraps the JS wrapper and returns the underlying native object.
         * @returns the wrapped native object, never null
         */
        unwrap(): T;
    }

    export class $RecipeRegistryProxy implements $ProxyObject {
        constructor(event: $RecipeEventJS);
        get memberKeys(): object;
        getMemberKeys(): object;
        describeType(namespace: string, type: string): $Map<string, object>;
        getMember(namespace: string): object;
        hasMember(key: string): boolean;
        hasNamespace(namespace: string): boolean;
        hasType(namespace: string, type: string): boolean;
        namespaces(): $List<string>;
        putMember(key: string, value: $Value): void;
        types(namespace: string): $List<string>;
    }

}
