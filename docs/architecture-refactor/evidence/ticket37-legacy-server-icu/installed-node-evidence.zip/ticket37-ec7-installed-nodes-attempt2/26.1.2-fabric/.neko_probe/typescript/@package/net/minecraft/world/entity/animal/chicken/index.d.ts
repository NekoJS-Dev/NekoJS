import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $ClientAsset$ResourceTexture, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $AgeableMob, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $ModelAndTexture, $PriorityProvider, $PriorityProvider$Selector, $SpawnCondition, $SpawnContext, $SpawnPrioritySelectors } from "java:net/minecraft/world/entity/variant";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/chicken" {
    export class $Chicken extends $Animal {
        constructor(type: $EntityType<$Chicken>, level: $Level);
        eggTime: number;
        flap: number;
        flapSpeed: number;
        flapping: number;
        isChickenJockey: boolean;
        oFlap: number;
        oFlapSpeed: number;
        get variant(): $Holder<$ChickenVariant>;
        getVariant(): $Holder<$ChickenVariant>;
        set variant(value: $Holder<$ChickenVariant>);
        get chickenJockey(): boolean;
        isChickenJockey(): boolean;
        set chickenJockey(value: boolean);
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Chicken;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        get<T>(type: $DataComponentType<T>): T;
        isFood(itemStack: $ItemStack_): boolean;
        removeWhenFarAway(distSqr: number): boolean;
    }

    export class $ChickenSoundVariant extends $Record {
        constructor(adultSounds: $ChickenSoundVariant$ChickenSoundSet, babySounds: $ChickenSoundVariant$ChickenSoundSet);
        static CODEC: $Codec<$Holder<$ChickenSoundVariant>>;
        static DIRECT_CODEC: $Codec<$ChickenSoundVariant>;
        static NETWORK_CODEC: $Codec<$ChickenSoundVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$ChickenSoundVariant>>;
        adultSounds(): $ChickenSoundVariant$ChickenSoundSet;
        babySounds(): $ChickenSoundVariant$ChickenSoundSet;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $ChickenSoundVariant$ChickenSoundSet extends $Record {
        constructor(ambientSound: $Holder<$SoundEvent_>, hurtSound: $Holder<$SoundEvent_>, deathSound: $Holder<$SoundEvent_>, stepSound: $Holder<$SoundEvent_>);
        ambientSound(): $Holder<$SoundEvent>;
        deathSound(): $Holder<$SoundEvent>;
        equals(o: object): boolean;
        hashCode(): number;
        hurtSound(): $Holder<$SoundEvent>;
        stepSound(): $Holder<$SoundEvent>;
        toString(): string;
    }

    export class $ChickenSoundVariants$SoundSet {
        static CLASSIC: $ChickenSoundVariants$SoundSet;
        static PICKY: $ChickenSoundVariants$SoundSet;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChickenSoundVariants$SoundSet[];
        static valueOf(name: string): $ChickenSoundVariants$SoundSet;
    }

    export class $ChickenVariant extends $Record implements $PriorityProvider {
        constructor(modelAndTexture: $ModelAndTexture<$ChickenVariant$ModelType_>, babyTexture: $ClientAsset$ResourceTexture, spawnConditions: $SpawnPrioritySelectors);
        static CODEC: $Codec<$Holder<$ChickenVariant>>;
        static DIRECT_CODEC: $Codec<$ChickenVariant>;
        static NETWORK_CODEC: $Codec<$ChickenVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$ChickenVariant>>;
        babyTexture(): $ClientAsset$ResourceTexture;
        equals(o: object): boolean;
        hashCode(): number;
        modelAndTexture(): $ModelAndTexture<$ChickenVariant$ModelType>;
        selectors(): $List<$PriorityProvider$Selector<$SpawnContext, $SpawnCondition>>;
        spawnConditions(): $SpawnPrioritySelectors;
        toString(): string;
    }

    export class $ChickenVariant$ModelType {
        static COLD: $ChickenVariant$ModelType;
        static NORMAL: $ChickenVariant$ModelType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChickenVariant$ModelType[];
        static valueOf(name: string): $ChickenVariant$ModelType;
    }

    export type $ChickenSoundVariants$SoundSet_ = $ChickenSoundVariants$SoundSet | "CLASSIC" | "PICKY";
    export type $ChickenVariant$ModelType_ = $ChickenVariant$ModelType | "COLD" | "NORMAL";
}
