import { $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $EndCrystal, $EnderDragon } from "java:net/minecraft/world/entity/boss/enderdragon";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/boss/enderdragon/phases" {
    export class $AbstractDragonPhaseInstance implements $DragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get turnSpeed(): number;
        getTurnSpeed(): number;
        get sitting(): boolean;
        isSitting(): boolean;
        begin(): void;
        doClientTick(): void;
        doServerTick(level: $ServerLevel): void;
        end(): void;
        onCrystalDestroyed(crystal: $EndCrystal, pos: $BlockPos_, source: $DamageSource, player: $Player): void;
        onHurt(source: $DamageSource, damage: number): number;
    }

    export class $AbstractDragonSittingPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get sitting(): boolean;
        isSitting(): boolean;
        onHurt(source: $DamageSource, damage: number): number;
    }

    export class $DragonChargePlayerPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonChargePlayerPhase>;
        getPhase(): $EnderDragonPhase<$DragonChargePlayerPhase>;
        begin(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export class $DragonDeathPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonDeathPhase>;
        getPhase(): $EnderDragonPhase<$DragonDeathPhase>;
        begin(): void;
        doClientTick(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export class $DragonHoldingPatternPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonHoldingPatternPhase>;
        getPhase(): $EnderDragonPhase<$DragonHoldingPatternPhase>;
        begin(): void;
        doServerTick(level: $ServerLevel): void;
        onCrystalDestroyed(crystal: $EndCrystal, pos: $BlockPos_, source: $DamageSource, player: $Player): void;
    }

    export class $DragonHoverPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonHoverPhase>;
        getPhase(): $EnderDragonPhase<$DragonHoverPhase>;
        get sitting(): boolean;
        isSitting(): boolean;
        begin(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export class $DragonLandingApproachPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonLandingApproachPhase>;
        getPhase(): $EnderDragonPhase<$DragonLandingApproachPhase>;
        begin(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export class $DragonLandingPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flySpeed(): number;
        getFlySpeed(): number;
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonLandingPhase>;
        getPhase(): $EnderDragonPhase<$DragonLandingPhase>;
        get turnSpeed(): number;
        getTurnSpeed(): number;
        begin(): void;
        doClientTick(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export interface $DragonPhaseInstance {
        begin(): void;
        doClientTick(): void;
        doServerTick(level: $ServerLevel): void;
        end(): void;
        getFlySpeed(): number;
        getFlyTargetLocation(): $Vec3;
        getPhase(): $EnderDragonPhase<$DragonPhaseInstance>;
        getTurnSpeed(): number;
        isSitting(): boolean;
        onCrystalDestroyed(crystal: $EndCrystal, pos: $BlockPos_, source: $DamageSource, player: $Player): void;
        onHurt(source: $DamageSource, damage: number): number;
    }

    export class $DragonSittingAttackingPhase extends $AbstractDragonSittingPhase {
        constructor(dragon: $EnderDragon);
        get phase(): $EnderDragonPhase<$DragonSittingAttackingPhase>;
        getPhase(): $EnderDragonPhase<$DragonSittingAttackingPhase>;
        begin(): void;
        doClientTick(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export class $DragonSittingFlamingPhase extends $AbstractDragonSittingPhase {
        constructor(dragon: $EnderDragon);
        get phase(): $EnderDragonPhase<$DragonSittingFlamingPhase>;
        getPhase(): $EnderDragonPhase<$DragonSittingFlamingPhase>;
        begin(): void;
        doClientTick(): void;
        doServerTick(level: $ServerLevel): void;
        end(): void;
        resetFlameCount(): void;
    }

    export class $DragonSittingScanningPhase extends $AbstractDragonSittingPhase {
        constructor(dragon: $EnderDragon);
        get phase(): $EnderDragonPhase<$DragonSittingScanningPhase>;
        getPhase(): $EnderDragonPhase<$DragonSittingScanningPhase>;
        begin(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export class $DragonStrafePlayerPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonStrafePlayerPhase>;
        getPhase(): $EnderDragonPhase<$DragonStrafePlayerPhase>;
        begin(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export class $DragonTakeoffPhase extends $AbstractDragonPhaseInstance {
        constructor(dragon: $EnderDragon);
        get flyTargetLocation(): $Vec3;
        getFlyTargetLocation(): $Vec3;
        get phase(): $EnderDragonPhase<$DragonTakeoffPhase>;
        getPhase(): $EnderDragonPhase<$DragonTakeoffPhase>;
        begin(): void;
        doServerTick(level: $ServerLevel): void;
    }

    export class $EnderDragonPhase<T extends $DragonPhaseInstance> {
        static CHARGING_PLAYER: $EnderDragonPhase<$DragonChargePlayerPhase>;
        static DYING: $EnderDragonPhase<$DragonDeathPhase>;
        static HOLDING_PATTERN: $EnderDragonPhase<$DragonHoldingPatternPhase>;
        static HOVERING: $EnderDragonPhase<$DragonHoverPhase>;
        static LANDING: $EnderDragonPhase<$DragonLandingPhase>;
        static LANDING_APPROACH: $EnderDragonPhase<$DragonLandingApproachPhase>;
        static SITTING_ATTACKING: $EnderDragonPhase<$DragonSittingAttackingPhase>;
        static SITTING_FLAMING: $EnderDragonPhase<$DragonSittingFlamingPhase>;
        static SITTING_SCANNING: $EnderDragonPhase<$DragonSittingScanningPhase>;
        static STRAFE_PLAYER: $EnderDragonPhase<$DragonStrafePlayerPhase>;
        static TAKEOFF: $EnderDragonPhase<$DragonTakeoffPhase>;
        get id(): number;
        getId(): number;
        static getById(id: number): $EnderDragonPhase<any>;
        static getCount(): number;
        createInstance(dragon: $EnderDragon): $DragonPhaseInstance;
        toString(): string;
    }

    export class $EnderDragonPhaseManager {
        constructor(dragon: $EnderDragon);
        get currentPhase(): $DragonPhaseInstance;
        getCurrentPhase(): $DragonPhaseInstance;
        getPhase<T>(phase: $EnderDragonPhase<T>): T;
    }

}
