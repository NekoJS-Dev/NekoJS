import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Record, $String } from "java:java/lang";
import { $List, $Map, $Optional } from "java:java/util";
import { $FabricTagKey } from "java:net/fabricmc/fabric/api/tag";
import { $TagKeyMixin } from "java:net/fabricmc/fabric/mixin/tag/convention";
import { $Holder, $Holder_, $Registry } from "java:net/minecraft/core";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";

declare module "java:net/minecraft/tags" {
    export class $TagKey<T> extends $Record implements $FabricTagKey, $TagKeyMixin {
        constructor(registry: $ResourceKey<$Registry<T>>, location: $Identifier_);
        static codec<T>(registryName: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static create<T>(registry: $ResourceKey<$Registry<T>>, location: $Identifier_): $TagKey<T>;
        static hashedCodec<T>(registryName: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static streamCodec<T>(registryName: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $TagKey<T>>;
        cast<E>(registry: $ResourceKey<$Registry<E>>): $Optional<$TagKey<E>>;
        equals(o: object): boolean;
        hashCode(): number;
        isFor(registry: $ResourceKey<$Registry<any>>): boolean;
        location(): $Identifier;
        registry(): $ResourceKey<$Registry<T>>;
        toString(): string;
    }

    export class $TagLoader$LoadResult<T> extends $Record {
        constructor(key: $ResourceKey<$Registry<T>>, tags: { [key: $TagKey<T>]: $Holder<T>[] });
        equals(o: object): boolean;
        hashCode(): number;
        key(): $ResourceKey<$Registry<T>>;
        tags(): $Map<$TagKey<T>, $List<$Holder<T>>>;
        toString(): string;
    }

    export class $TagNetworkSerialization$NetworkPayload {
        static EMPTY: $TagNetworkSerialization$NetworkPayload;
        get empty(): boolean;
        isEmpty(): boolean;
        static read(buf: $FriendlyByteBuf): $TagNetworkSerialization$NetworkPayload;
        resolve<T>(registry: $Registry<T>): $TagLoader$LoadResult<T>;
        size(): number;
        write(buf: $FriendlyByteBuf): void;
    }

    export type $TagKey_ = string | { type?: string, tag: string };
}
