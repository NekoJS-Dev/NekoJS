import { $DSL$TypeReference, $DataFixer } from "java:com/mojang/datafixers";
import { $Codec, $Dynamic } from "java:com/mojang/serialization";
import { $Enum, $String } from "java:java/lang";
import { $Set } from "java:java/util";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";

declare module "java:net/minecraft/util/datafix" {
    export class $DataFixTypes {
        static ADVANCEMENTS: $DataFixTypes;
        static CHUNK: $DataFixTypes;
        static DEBUG_PROFILE: $DataFixTypes;
        static ENTITY_CHUNK: $DataFixTypes;
        static HOTBAR: $DataFixTypes;
        static LEVEL: $DataFixTypes;
        static LEVEL_SUMMARY: $DataFixTypes;
        static OPTIONS: $DataFixTypes;
        static PLAYER: $DataFixTypes;
        static POI_CHUNK: $DataFixTypes;
        static SAVED_DATA_COMMAND_STORAGE: $DataFixTypes;
        static SAVED_DATA_CUSTOM_BOSS_EVENTS: $DataFixTypes;
        static SAVED_DATA_ENDER_DRAGON_FIGHT: $DataFixTypes;
        static SAVED_DATA_FORCED_CHUNKS: $DataFixTypes;
        static SAVED_DATA_GAME_RULES: $DataFixTypes;
        static SAVED_DATA_MAP_DATA: $DataFixTypes;
        static SAVED_DATA_MAP_INDEX: $DataFixTypes;
        static SAVED_DATA_RAIDS: $DataFixTypes;
        static SAVED_DATA_RANDOM_SEQUENCES: $DataFixTypes;
        static SAVED_DATA_SCHEDULED_EVENTS: $DataFixTypes;
        static SAVED_DATA_SCOREBOARD: $DataFixTypes;
        static SAVED_DATA_STOPWATCHES: $DataFixTypes;
        static SAVED_DATA_STRUCTURE_FEATURE_INDICES: $DataFixTypes;
        static SAVED_DATA_WANDERING_TRADER: $DataFixTypes;
        static SAVED_DATA_WEATHER: $DataFixTypes;
        static SAVED_DATA_WORLD_BORDER: $DataFixTypes;
        static SAVED_DATA_WORLD_CLOCKS: $DataFixTypes;
        static SAVED_DATA_WORLD_GEN_SETTINGS: $DataFixTypes;
        static STATS: $DataFixTypes;
        static STRUCTURE: $DataFixTypes;
        static WORLD_GEN_SETTINGS: $DataFixTypes;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DataFixTypes[];
        static valueOf(name: string): $DataFixTypes;
    }

    export type $DataFixTypes_ = $DataFixTypes | "ADVANCEMENTS" | "CHUNK" | "DEBUG_PROFILE" | "ENTITY_CHUNK" | "HOTBAR" | "LEVEL" | "LEVEL_SUMMARY" | "OPTIONS" | "PLAYER" | "POI_CHUNK" | "SAVED_DATA_COMMAND_STORAGE" | "SAVED_DATA_CUSTOM_BOSS_EVENTS" | "SAVED_DATA_ENDER_DRAGON_FIGHT" | "SAVED_DATA_FORCED_CHUNKS" | "SAVED_DATA_GAME_RULES" | "SAVED_DATA_MAP_DATA" | "SAVED_DATA_MAP_INDEX" | "SAVED_DATA_RAIDS" | "SAVED_DATA_RANDOM_SEQUENCES" | "SAVED_DATA_SCHEDULED_EVENTS" | "SAVED_DATA_SCOREBOARD" | "SAVED_DATA_STOPWATCHES" | "SAVED_DATA_STRUCTURE_FEATURE_INDICES" | "SAVED_DATA_WANDERING_TRADER" | "SAVED_DATA_WEATHER" | "SAVED_DATA_WORLD_BORDER" | "SAVED_DATA_WORLD_CLOCKS" | "SAVED_DATA_WORLD_GEN_SETTINGS" | "STATS" | "STRUCTURE" | "WORLD_GEN_SETTINGS";
}
