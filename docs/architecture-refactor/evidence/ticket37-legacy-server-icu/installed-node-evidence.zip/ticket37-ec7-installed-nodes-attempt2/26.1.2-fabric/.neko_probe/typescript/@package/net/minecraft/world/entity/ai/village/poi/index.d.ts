import type { RegistryTypes } from "@special/types";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Enum, $Record, $Runnable, $String } from "java:java/lang";
import { $Optional, $Set } from "java:java/util";
import { $BiPredicate, $BooleanSupplier, $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Holder, $Holder_, $SectionPos } from "java:net/minecraft/core";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $RandomSource } from "java:net/minecraft/util";
import { $DebugPoiInfo } from "java:net/minecraft/util/debug";
import { $ChunkPos, $LevelReader } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $LevelChunkSection } from "java:net/minecraft/world/level/chunk";
import { $SectionStorage } from "java:net/minecraft/world/level/chunk/storage";

declare module "java:net/minecraft/world/entity/ai/village/poi" {
    export class $PoiManager extends $SectionStorage {
        constructor(info: $RegionStorageInfo, folder: string, fixerUpper: $DataFixer, sync: boolean, registryAccess: $RegistryAccess, errorReporter: $ChunkIOErrorReporter, levelHeightAccessor: $LevelHeightAccessor);
        static MAX_VILLAGE_DISTANCE: number;
        static VILLAGE_SECTION_SIZE: number;
        add(pos: $BlockPos_, type: $Holder<$PoiType_>): $PoiRecord;
        checkConsistencyWithBlocks(sectionPos: $SectionPos, blockSection: $LevelChunkSection): void;
        ensureLoadedAndValid(reader: $LevelReader, center: $BlockPos_, radius: number): void;
        existsAtPosition(poiType: $ResourceKey<$PoiType_>, blockPos: $BlockPos_): boolean;
        exists(pos: $BlockPos_, predicate: $Predicate<$Holder<$PoiType_>>): boolean;
        findAllClosestFirstWithType(predicate: $Predicate<$Holder<$PoiType_>>, filter: $Predicate<$BlockPos_>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Stream<$Pair<$Holder<$PoiType>, $BlockPos>>;
        findAllWithType(predicate: $Predicate<$Holder<$PoiType_>>, filter: $Predicate<$BlockPos_>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Stream<$Pair<$Holder<$PoiType>, $BlockPos>>;
        findAll(predicate: $Predicate<$Holder<$PoiType_>>, filter: $Predicate<$BlockPos_>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Stream<$BlockPos>;
        findClosestWithType(predicate: $Predicate<$Holder<$PoiType_>>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Optional<$Pair<$Holder<$PoiType>, $BlockPos>>;
        findClosest(predicate: $Predicate<$Holder<$PoiType_>>, filter: $Predicate<$BlockPos_>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Optional<$BlockPos>;
        findClosest(predicate: $Predicate<$Holder<$PoiType_>>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Optional<$BlockPos>;
        find(predicate: $Predicate<$Holder<$PoiType_>>, filter: $Predicate<$BlockPos_>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Optional<$BlockPos>;
        getCountInRange(predicate: $Predicate<$Holder<$PoiType_>>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): number;
        getDebugPoiInfo(pos: $BlockPos_): $DebugPoiInfo;
        getInChunk(predicate: $Predicate<$Holder<$PoiType_>>, chunkPos: $ChunkPos, occupancy: $PoiManager$Occupancy_): $Stream<$PoiRecord>;
        getInRange(predicate: $Predicate<$Holder<$PoiType_>>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Stream<$PoiRecord>;
        getInSquare(predicate: $Predicate<$Holder<$PoiType_>>, center: $BlockPos_, radius: number, occupancy: $PoiManager$Occupancy_): $Stream<$PoiRecord>;
        getRandom(predicate: $Predicate<$Holder<$PoiType_>>, filter: $Predicate<$BlockPos_>, occupancy: $PoiManager$Occupancy_, center: $BlockPos_, radius: number, random: $RandomSource): $Optional<$BlockPos>;
        getType(pos: $BlockPos_): $Optional<$Holder<$PoiType>>;
        release(pos: $BlockPos_): boolean;
        remove(pos: $BlockPos_): void;
        sectionsToVillage(sectionPos: $SectionPos): number;
        take(predicate: $Predicate<$Holder<$PoiType_>>, filter: $BiPredicate<$Holder<$PoiType_>, $BlockPos_>, center: $BlockPos_, radius: number): $Optional<$BlockPos>;
        tick(haveTime: $BooleanSupplier): void;
    }

    export class $PoiManager$Occupancy {
        static ANY: $PoiManager$Occupancy;
        static HAS_SPACE: $PoiManager$Occupancy;
        static IS_OCCUPIED: $PoiManager$Occupancy;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PoiManager$Occupancy[];
        static valueOf(name: string): $PoiManager$Occupancy;
    }

    export class $PoiRecord {
        constructor(pos: $BlockPos_, poiType: $Holder<$PoiType_>, setDirty: $Runnable);
        get freeTickets(): number;
        getFreeTickets(): number;
        get poiType(): $Holder<$PoiType>;
        getPoiType(): $Holder<$PoiType>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get occupied(): boolean;
        isOccupied(): boolean;
        equals(o: object): boolean;
        hasSpace(): boolean;
        hashCode(): number;
        pack(): $PoiRecord$Packed;
    }

    export class $PoiRecord$Packed extends $Record {
        constructor(pos: $BlockPos_, poiType: $Holder<$PoiType_>, freeTickets: number);
        static CODEC: $Codec<$PoiRecord$Packed>;
        equals(o: object): boolean;
        freeTickets(): number;
        hashCode(): number;
        poiType(): $Holder<$PoiType>;
        pos(): $BlockPos;
        toString(): string;
        unpack(setDirty: $Runnable): $PoiRecord;
    }

    export class $PoiType extends $Record {
        constructor(matchingStates: $BlockState_[], maxTickets: number, validRange: number);
        static NONE: $Predicate<$Holder<$PoiType>>;
        equals(o: object): boolean;
        hashCode(): number;
        is(state: $BlockState_): boolean;
        matchingStates(): $Set<$BlockState>;
        maxTickets(): number;
        toString(): string;
        validRange(): number;
    }

    export type $PoiManager$Occupancy_ = $PoiManager$Occupancy | "ANY" | "HAS_SPACE" | "IS_OCCUPIED";
    export type $PoiType_ = $PoiType | RegistryTypes.PoiType | $NekoId | string;
}
