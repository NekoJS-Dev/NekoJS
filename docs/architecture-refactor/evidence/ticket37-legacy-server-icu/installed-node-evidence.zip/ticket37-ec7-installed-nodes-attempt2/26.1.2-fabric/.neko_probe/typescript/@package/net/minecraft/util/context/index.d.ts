import { $String } from "java:java/lang";
import { $Set } from "java:java/util";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/util/context" {
    export class $ContextKey<T> {
        constructor(name: $Identifier_);
        static vanilla<T>(name: string): $ContextKey<T>;
        name(): $Identifier;
        toString(): string;
    }

    export class $ContextKeySet {
        allowed(): $Set<$ContextKey<any>>;
        required(): $Set<$ContextKey<any>>;
        toString(): string;
    }

    export class $ContextMap {
        getOptional<T>(key: $ContextKey<T>): T;
        getOrDefault<T>(param: $ContextKey<T>, _default: T): T;
        getOrThrow<T>(key: $ContextKey<T>): T;
        has(key: $ContextKey<any>): boolean;
    }

}
