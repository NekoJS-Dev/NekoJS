import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $Function } from "java:java/util/function";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/util/random" {
    export class $Weighted<T> extends $Record {
        constructor(value: T, weight: number);
        static codec<E>(elementCodec: $Codec<E>): $Codec<$Weighted<E>>;
        static codec<E>(elementCodec: $MapCodec<E>): $Codec<$Weighted<E>>;
        static streamCodec<B, T>(valueCodec: $StreamCodec<B, T>): $StreamCodec<B, $Weighted<T>>;
        equals(o: object): boolean;
        hashCode(): number;
        map<U>(function_: $Function<T, U>): $Weighted<U>;
        toString(): string;
        value(): T;
        weight(): number;
    }

    export class $WeightedList<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        static builder<E>(): $WeightedList$Builder<E>;
        static codec<E>(elementCodec: $Codec<E>): $Codec<$WeightedList<E>>;
        static codec<E>(elementCodec: $MapCodec<E>): $Codec<$WeightedList<E>>;
        static nonEmptyCodec<E>(elementCodec: $Codec<E>): $Codec<$WeightedList<E>>;
        static nonEmptyCodec<E>(elementCodec: $MapCodec<E>): $Codec<$WeightedList<E>>;
        static of<E>(value: E): $WeightedList<E>;
        static of<E>(items: $Weighted<E>[]): $WeightedList<E>;
        static of<E>(items?: $Weighted<E>[]): $WeightedList<E>;
        static of<E>(): $WeightedList<E>;
        static streamCodec<E, B>(elementCodec: $StreamCodec<B, E>): $StreamCodec<B, $WeightedList<E>>;
        contains(value: E): boolean;
        equals(obj: object): boolean;
        getRandomOrThrow(random: $RandomSource): E;
        getRandom(random: $RandomSource): $Optional<E>;
        hashCode(): number;
        map<T>(mapper: $Function<E, T>): $WeightedList<T>;
        unwrap(): $List<$Weighted<E>>;
    }

    export class $WeightedList$Builder<E> {
        constructor();
        add(item: E, weight: number): $WeightedList$Builder<E>;
        add(item: E): $WeightedList$Builder<E>;
        build(): $WeightedList<E>;
    }

}
