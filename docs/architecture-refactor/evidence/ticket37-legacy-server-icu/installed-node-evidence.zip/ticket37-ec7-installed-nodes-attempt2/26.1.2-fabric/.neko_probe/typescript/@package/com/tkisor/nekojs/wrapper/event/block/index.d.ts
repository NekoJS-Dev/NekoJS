import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $InteractionHand, $InteractionHand_ } from "java:net/minecraft/world";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Level, $LevelAccessor } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";

declare module "java:com/tkisor/nekojs/wrapper/event/block" {
    /**
     * Fired when a block is broken (BlockEvents.broken). Listeners are dispatched by block id.
     * Return true to cancel the break.
     */
    export class $BlockBrokenEventJS {
        constructor(level: $LevelAccessor, pos: $BlockPos_, state: $BlockState_, player: $Player);
        /** The block that was broken. */
        get block(): $Block;
        getBlock(): $Block;
        get level(): $LevelAccessor;
        getLevel(): $LevelAccessor;
        get player(): $Player;
        getPlayer(): $Player;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
    }

    /**
     * Fired when a player left-clicks a block (BlockEvents.leftClicked).
     * Return true to consume the attack interaction.
     */
    export class $BlockLeftClickEventJS {
        constructor(player: $Player, level: $Level, pos: $BlockPos_, state: $BlockState_, hand: $InteractionHand_);
        /** The block that was clicked. */
        get block(): $Block;
        getBlock(): $Block;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get level(): $Level;
        getLevel(): $Level;
        get player(): $Player;
        getPlayer(): $Player;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
    }

    /**
     * Fired when a player right-clicks a block (BlockEvents.rightClicked).
     * Return true to consume the interaction.
     */
    export class $BlockRightClickEventJS {
        constructor(player: $Player, level: $Level, pos: $BlockPos_, state: $BlockState_, hand: $InteractionHand_);
        /** The block that was clicked. */
        get block(): $Block;
        getBlock(): $Block;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get level(): $Level;
        getLevel(): $Level;
        get player(): $Player;
        getPlayer(): $Player;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
    }

}
