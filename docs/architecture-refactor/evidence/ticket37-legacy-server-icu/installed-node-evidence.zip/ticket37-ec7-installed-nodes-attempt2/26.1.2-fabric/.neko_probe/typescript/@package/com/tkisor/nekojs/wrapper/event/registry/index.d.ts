import { $String } from "java:java/lang";
import { $BiFunction, $Supplier } from "java:java/util/function";
import { $BlockApiLookup, $BlockApiLookup$BlockApiProvider } from "java:net/fabricmc/fabric/api/lookup/v1/block";
import { $EntityApiLookup } from "java:net/fabricmc/fabric/api/lookup/v1/entity";
import { $ItemApiLookup } from "java:net/fabricmc/fabric/api/lookup/v1/item";
import { $ContainerItemContext } from "java:net/fabricmc/fabric/api/transfer/v1/context";
import { $Direction, $Direction_ } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";

declare module "java:com/tkisor/nekojs/wrapper/event/registry" {
    export class $CapabilityRegistryEventJS {
        constructor();
        apply(): void;
        registerBlockEntityContext(typeId: string, capability: string, provider: $BiFunction<$BlockEntity, $Direction_, any>): void;
        registerBlockEntityLookup<A, C>(typeId: string, lookup: $BlockApiLookup<A, C>, provider: $BiFunction<$BlockEntity, C, any>): void;
        registerBlockEntity(typeId: string, capability: string, provider: $Supplier<any>): void;
        registerBlockLookup<A, C>(blockId: string, lookup: $BlockApiLookup<A, C>, provider: $BlockApiLookup$BlockApiProvider<any, C>): void;
        registerEntityContext(typeId: string, capability: string, provider: $BiFunction<$Entity, $Direction_, any>): void;
        registerEntityLookup<A, C>(typeId: string, lookup: $EntityApiLookup<A, C>, provider: $BiFunction<$Entity, C, any>): void;
        registerEntity(typeId: string, capability: string, provider: $Supplier<any>): void;
        registerItemContext(itemId: string, capability: string, provider: $BiFunction<$ItemStack_, $ContainerItemContext, any>): void;
        registerItemLookup<A, C>(itemId: string, lookup: $ItemApiLookup<A, C>, provider: $BiFunction<$ItemStack_, C, any>): void;
        registerItem(itemId: string, capability: string, provider: $Supplier<any>): void;
    }

}
