import type { RegistryTypes } from "@special/types";
import { $ImmutableList } from "java:com/google/common/collect";
import { $Either } from "java:com/mojang/datafixers/util";
import { $Transformation } from "java:com/mojang/math";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $EntityExtension, $LivingEntityExtension, $NekoEntityPData } from "java:com/tkisor/nekojs/api/inject";
import { $MixinEntity, $MixinLivingEntity } from "java:com/tkisor/nekojs/fabric/mixin";
import { $ByteBuf } from "java:io/netty/buffer";
import { $IntList } from "java:it/unimi/dsi/fastutil/ints";
import { $Boolean, $Class, $Enum, $Float, $Iterable, $Record, $String } from "java:java/lang";
import { $Collection, $Iterator, $List, $Map, $Optional, $Set, $UUID } from "java:java/util";
import { $BiConsumer, $Consumer, $IntFunction, $Predicate, $Supplier } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $AttachmentTarget, $AttachmentType } from "java:net/fabricmc/fabric/api/attachment/v1";
import { $Event } from "java:net/fabricmc/fabric/api/event";
import { $EntityLoadData } from "java:net/fabricmc/fabric/api/event/lifecycle/v1";
import { $PermissionContext, $PermissionContextOwner } from "java:net/fabricmc/fabric/api/permission/v1";
import { $EntityFluidExtension } from "java:net/fabricmc/fabric/api/registry/fluid";
import { $AttachmentTargetImpl } from "java:net/fabricmc/fabric/impl/attachment";
import { $AttachmentChange, $AttachmentTargetInfo } from "java:net/fabricmc/fabric/impl/attachment/sync";
import { $InternalEntityFluidExtension } from "java:net/fabricmc/fabric/impl/content/registry/fluid";
import { $EntityLoadDataSetter } from "java:net/fabricmc/fabric/impl/event/lifecycle";
import { $FabricEntityTypeImpl } from "java:net/fabricmc/fabric/impl/object/builder";
import { $EntityAccessor, $LivingEntityAccessor } from "java:net/fabricmc/fabric/mixin/content/registry/fluid";
import { $CrashReportCategory } from "java:net/minecraft";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $EntityAnchorArgument$Anchor, $EntityAnchorArgument$Anchor_ } from "java:net/minecraft/commands/arguments";
import { $BlockPos, $BlockPos_, $Direction, $Direction$Axis, $Direction$Axis_, $Direction_, $Holder, $Holder$Reference, $Holder_, $RegistryAccess, $TypedInstance } from "java:net/minecraft/core";
import { $DataComponentGetter, $DataComponentType } from "java:net/minecraft/core/component";
import { $ParticleOptions } from "java:net/minecraft/core/particles";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener, $ClientboundAddEntityPacket, $VecDeltaCodec } from "java:net/minecraft/network/protocol/game";
import { $EntityDataAccessor, $SyncedDataHolder, $SynchedEntityData, $SynchedEntityData$DataValue } from "java:net/minecraft/network/syncher";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerEntity, $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_, $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $BlockUtil$FoundRectangle, $Brightness, $FormattedCharSequence, $ProblemReporter$PathElement, $RandomSource, $StringRepresentable, $StringRepresentable$EnumCodec } from "java:net/minecraft/util";
import { $DebugValueSource, $DebugValueSource$Registration } from "java:net/minecraft/util/debug";
import { $Container, $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult, $Nameable } from "java:net/minecraft/world";
import { $CombatTracker, $DamageSource, $DamageSources } from "java:net/minecraft/world/damagesource";
import { $MobEffect, $MobEffectInstance, $MobEffect_ } from "java:net/minecraft/world/effect";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $Attribute, $AttributeInstance, $AttributeMap, $AttributeSupplier$Builder, $Attribute_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $JumpControl, $LookControl, $MoveControl } from "java:net/minecraft/world/entity/ai/control";
import { $Goal, $GoalSelector } from "java:net/minecraft/world/entity/ai/goal";
import { $PathNavigation } from "java:net/minecraft/world/entity/ai/navigation";
import { $Sensing } from "java:net/minecraft/world/entity/ai/sensing";
import { $ReputationEventType } from "java:net/minecraft/world/entity/ai/village";
import { $Bat } from "java:net/minecraft/world/entity/ambient";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Allay } from "java:net/minecraft/world/entity/animal/allay";
import { $Armadillo } from "java:net/minecraft/world/entity/animal/armadillo";
import { $Axolotl } from "java:net/minecraft/world/entity/animal/axolotl";
import { $Bee } from "java:net/minecraft/world/entity/animal/bee";
import { $Camel, $CamelHusk } from "java:net/minecraft/world/entity/animal/camel";
import { $Chicken } from "java:net/minecraft/world/entity/animal/chicken";
import { $Cow, $MushroomCow } from "java:net/minecraft/world/entity/animal/cow";
import { $Dolphin } from "java:net/minecraft/world/entity/animal/dolphin";
import { $Donkey, $Horse, $Llama, $Mule, $SkeletonHorse, $TraderLlama, $ZombieHorse } from "java:net/minecraft/world/entity/animal/equine";
import { $Cat, $Ocelot } from "java:net/minecraft/world/entity/animal/feline";
import { $Cod, $Pufferfish, $Salmon, $TropicalFish } from "java:net/minecraft/world/entity/animal/fish";
import { $Fox } from "java:net/minecraft/world/entity/animal/fox";
import { $Frog, $Tadpole } from "java:net/minecraft/world/entity/animal/frog";
import { $Goat } from "java:net/minecraft/world/entity/animal/goat";
import { $CopperGolem, $IronGolem, $SnowGolem } from "java:net/minecraft/world/entity/animal/golem";
import { $HappyGhast } from "java:net/minecraft/world/entity/animal/happyghast";
import { $Nautilus, $ZombieNautilus } from "java:net/minecraft/world/entity/animal/nautilus";
import { $Panda } from "java:net/minecraft/world/entity/animal/panda";
import { $Parrot } from "java:net/minecraft/world/entity/animal/parrot";
import { $Pig } from "java:net/minecraft/world/entity/animal/pig";
import { $PolarBear } from "java:net/minecraft/world/entity/animal/polarbear";
import { $Rabbit } from "java:net/minecraft/world/entity/animal/rabbit";
import { $Sheep } from "java:net/minecraft/world/entity/animal/sheep";
import { $Sniffer } from "java:net/minecraft/world/entity/animal/sniffer";
import { $GlowSquid, $Squid } from "java:net/minecraft/world/entity/animal/squid";
import { $Turtle } from "java:net/minecraft/world/entity/animal/turtle";
import { $Wolf } from "java:net/minecraft/world/entity/animal/wolf";
import { $EndCrystal, $EnderDragon } from "java:net/minecraft/world/entity/boss/enderdragon";
import { $WitherBoss } from "java:net/minecraft/world/entity/boss/wither";
import { $ArmorStand, $GlowItemFrame, $ItemFrame, $LeashFenceKnotEntity, $Mannequin } from "java:net/minecraft/world/entity/decoration";
import { $Painting } from "java:net/minecraft/world/entity/decoration/painting";
import { $FallingBlockEntity, $ItemEntity, $PrimedTnt } from "java:net/minecraft/world/entity/item";
import { $Blaze, $Creeper, $ElderGuardian, $EnderMan, $Endermite, $Ghast, $Giant, $Guardian, $MagmaCube, $Phantom, $Ravager, $Shulker, $Silverfish, $Slime, $Strider, $Vex, $Witch, $Zoglin } from "java:net/minecraft/world/entity/monster";
import { $Breeze } from "java:net/minecraft/world/entity/monster/breeze";
import { $Creaking } from "java:net/minecraft/world/entity/monster/creaking";
import { $Hoglin } from "java:net/minecraft/world/entity/monster/hoglin";
import { $Evoker, $Illusioner, $Pillager, $Vindicator } from "java:net/minecraft/world/entity/monster/illager";
import { $Piglin, $PiglinBrute } from "java:net/minecraft/world/entity/monster/piglin";
import { $Bogged, $Parched, $Skeleton, $Stray, $WitherSkeleton } from "java:net/minecraft/world/entity/monster/skeleton";
import { $CaveSpider, $Spider } from "java:net/minecraft/world/entity/monster/spider";
import { $Warden } from "java:net/minecraft/world/entity/monster/warden";
import { $Drowned, $Husk, $Zombie, $ZombieVillager, $ZombifiedPiglin } from "java:net/minecraft/world/entity/monster/zombie";
import { $Villager } from "java:net/minecraft/world/entity/npc/villager";
import { $WanderingTrader } from "java:net/minecraft/world/entity/npc/wanderingtrader";
import { $Player, $PlayerModelPart, $PlayerModelPart_ } from "java:net/minecraft/world/entity/player";
import { $EvokerFangs, $EyeOfEnder, $FireworkRocketEntity, $FishingHook, $LlamaSpit, $Projectile, $ProjectileDeflection, $ShulkerBullet } from "java:net/minecraft/world/entity/projectile";
import { $Arrow, $SpectralArrow, $ThrownTrident } from "java:net/minecraft/world/entity/projectile/arrow";
import { $DragonFireball, $LargeFireball, $SmallFireball, $WitherSkull } from "java:net/minecraft/world/entity/projectile/hurtingprojectile";
import { $BreezeWindCharge, $WindCharge } from "java:net/minecraft/world/entity/projectile/hurtingprojectile/windcharge";
import { $Snowball, $ThrownEgg, $ThrownEnderpearl, $ThrownExperienceBottle, $ThrownLingeringPotion, $ThrownSplashPotion } from "java:net/minecraft/world/entity/projectile/throwableitemprojectile";
import { $Boat, $ChestBoat, $ChestRaft, $Raft } from "java:net/minecraft/world/entity/vehicle/boat";
import { $Minecart, $MinecartChest, $MinecartCommandBlock, $MinecartFurnace, $MinecartHopper, $MinecartSpawner, $MinecartTNT } from "java:net/minecraft/world/entity/vehicle/minecart";
import { $FeatureElement, $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemDisplayContext, $ItemDisplayContext_, $ItemInstance, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $PotionContents } from "java:net/minecraft/world/item/alchemy";
import { $AttackRange, $ResolvableProfile, $TypedEntityData } from "java:net/minecraft/world/item/component";
import { $Enchantment } from "java:net/minecraft/world/item/enchantment";
import { $EnchantmentLocationBasedEffect } from "java:net/minecraft/world/item/enchantment/effects";
import { $SlotCollection } from "java:net/minecraft/world/item/slot";
import { $BlockGetter, $ChunkPos, $ClipContext$Block, $ClipContext$Block_, $ClipContext$Fluid, $ClipContext$Fluid_, $Explosion, $ItemLike, $ItemLike_, $Level, $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Mirror, $Mirror_, $Portal, $Portal$Transition, $Portal$Transition_, $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $ContainerOpenersCounter } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $EntityAccess, $EntityInLevelCallback, $EntityTypeTest, $UUIDLookup } from "java:net/minecraft/world/level/entity";
import { $DynamicGameEventListener, $GameEvent, $GameEvent_ } from "java:net/minecraft/world/level/gameevent";
import { $Fluid, $FluidState, $Fluid_, $PushReaction, $PushReaction_ } from "java:net/minecraft/world/level/material";
import { $PathType, $PathType_ } from "java:net/minecraft/world/level/pathfinder";
import { $TeleportTransition } from "java:net/minecraft/world/level/portal";
import { $ValueInput, $ValueInput$ValueInputList, $ValueOutput } from "java:net/minecraft/world/level/storage";
import { $LootParams, $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $AABB, $HitResult, $Vec2, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $VoxelShape } from "java:net/minecraft/world/phys/shapes";
import { $PlayerTeam, $ScoreHolder, $Team } from "java:net/minecraft/world/scores";
import { $Waypoint$Icon, $WaypointTransmitter, $WaypointTransmitter$Connection } from "java:net/minecraft/world/waypoints";
import { $CallbackInfoReturnable } from "java:org/spongepowered/asm/mixin/injection/callback";

export * as ai from "java:net/minecraft/world/entity/ai";
export * as ambient from "java:net/minecraft/world/entity/ambient";
export * as animal from "java:net/minecraft/world/entity/animal";
export * as boss from "java:net/minecraft/world/entity/boss";
export * as decoration from "java:net/minecraft/world/entity/decoration";
export * as item from "java:net/minecraft/world/entity/item";
export * as monster from "java:net/minecraft/world/entity/monster";
export * as npc from "java:net/minecraft/world/entity/npc";
export * as player from "java:net/minecraft/world/entity/player";
export * as projectile from "java:net/minecraft/world/entity/projectile";
export * as raid from "java:net/minecraft/world/entity/raid";
export * as schedule from "java:net/minecraft/world/entity/schedule";
export * as variant from "java:net/minecraft/world/entity/variant";
export * as vehicle from "java:net/minecraft/world/entity/vehicle";

declare module "java:net/minecraft/world/entity" {
    export class $AgeableMob extends $PathfinderMob {
        static AGE_LOCK_COOLDOWN_TICKS: number;
        static AGE_LOCK_DOWNWARDS_MOVING_PARTICLE_Y_OFFSET: number;
        static BABY_START_AGE: number;
        get age(): number;
        getAge(): number;
        set age(value: number);
        get forcedAgeTimer(): number;
        getForcedAgeTimer(): number;
        get forcedAge(): number;
        getForcedAge(): number;
        get ageLocked(): boolean;
        isAgeLocked(): boolean;
        get baby(): boolean;
        isBaby(): boolean;
        set baby(value: boolean);
        static canUseGoldenDandelion(itemInHand: $ItemStack_, isBaby: boolean, cooldown: number, mob: $Mob): boolean;
        static getSpeedUpSecondsWhenFeeding(ticksUntilAdult: number): number;
        static makeAgeLockedParticle(level: $Level, mob: $Mob, ageLockParticleTimer: number, isAgeLocked: boolean): number;
        static setAgeLocked(mob: $Mob, isAgedLocked: $Supplier<boolean>, player: $Player, itemInHand: $ItemStack_, setAgeLockData: $Consumer<$Mob>): void;
        ageUp(seconds: number, forced: boolean): void;
        ageUp(seconds: number): void;
        aiStep(): void;
        canAgeUp(): boolean;
        canBreed(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
    }

    export class $AnimationState {
        constructor();
        get started(): boolean;
        isStarted(): boolean;
        animateWhen(condition: boolean, tickCount: number): void;
        copyFrom(state: $AnimationState): void;
        fastForward(ticks: number, timeScale: number): void;
        getTimeInMillis(ageInTicks: number): number;
        ifStarted(timer: $Consumer<$AnimationState>): void;
        startIfStopped(tickCount: number): void;
        start(tickCount: number): void;
        stop(): void;
    }

    export class $AreaEffectCloud extends $Entity implements $TraceableEntity {
        constructor(type: $EntityType<$AreaEffectCloud>, level: $Level);
        constructor(level: $Level, x: number, y: number, z: number);
        static DEFAULT_LINGERING_DURATION: number;
        static DEFAULT_WIDTH: number;
        static HEIGHT: number;
        static INFINITE_DURATION: number;
        get durationOnUse(): number;
        getDurationOnUse(): number;
        set durationOnUse(value: number);
        get duration(): number;
        getDuration(): number;
        set duration(value: number);
        get owner(): $LivingEntity;
        getOwner(): $LivingEntity;
        set owner(value: $LivingEntity);
        get particle(): $ParticleOptions;
        getParticle(): $ParticleOptions;
        get pistonPushReaction(): $PushReaction;
        getPistonPushReaction(): $PushReaction;
        get radiusOnUse(): number;
        getRadiusOnUse(): number;
        set radiusOnUse(value: number);
        get radiusPerTick(): number;
        getRadiusPerTick(): number;
        set radiusPerTick(value: number);
        get radius(): number;
        getRadius(): number;
        set radius(value: number);
        get waitTime(): number;
        getWaitTime(): number;
        set waitTime(value: number);
        get waiting(): boolean;
        isWaiting(): boolean;
        addEffect(effect: $MobEffectInstance): void;
        getDimensions(pose: $Pose_): $EntityDimensions;
        get<T>(type: $DataComponentType<T>): T;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        refreshDimensions(): void;
        tick(): void;
    }

    export interface $Attackable {
        getLastAttacker(): $LivingEntity;
    }

    export class $Avatar extends $LivingEntity {
        static DEFAULT_EYE_HEIGHT: number;
        static DEFAULT_MAIN_HAND: $HumanoidArm;
        static DEFAULT_MODEL_CUSTOMIZATION: number;
        static DEFAULT_VEHICLE_ATTACHMENT: $Vec3;
        static SWIMMING_BB_HEIGHT: number;
        get mainArm(): $HumanoidArm;
        getMainArm(): $HumanoidArm;
        set mainArm(value: $HumanoidArm_);
        get profile(): $ResolvableProfile;
        getProfile(): $ResolvableProfile;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        isModelPartShown(part: $PlayerModelPart_): boolean;
    }

    export interface $ContainerUser {
        getContainerInteractionRange(): number;
        getLivingEntity(): $LivingEntity;
        hasContainerOpen(container: $ContainerOpenersCounter, blockPos: $BlockPos_): boolean;
    }

    export class $ConversionParams extends $Record {
        constructor(type: $ConversionType_, keepEquipment: boolean, preserveCanPickUpLoot: boolean, team: $PlayerTeam);
        static single(mob: $Mob, keepEquipment: boolean, preserveCanPickUpLoot: boolean): $ConversionParams;
        equals(o: object): boolean;
        hashCode(): number;
        keepEquipment(): boolean;
        preserveCanPickUpLoot(): boolean;
        team(): $PlayerTeam;
        toString(): string;
        type(): $ConversionType;
    }

    export interface $ConversionParams$AfterConversion<T extends $Mob> {
        finalizeConversion(mob: T): void;
    }

    export class $ConversionType {
        static SINGLE: $ConversionType;
        static SPLIT_ON_DEATH: $ConversionType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ConversionType[];
        static valueOf(name: string): $ConversionType;
    }

    export class $Crackiness$Level {
        static HIGH: $Crackiness$Level;
        static LOW: $Crackiness$Level;
        static MEDIUM: $Crackiness$Level;
        static NONE: $Crackiness$Level;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Crackiness$Level[];
        static valueOf(name: string): $Crackiness$Level;
    }

    export class $Display extends $Entity {
        constructor(type: $EntityType<any>, level: $Level);
        static NO_BRIGHTNESS_OVERRIDE: number;
        static TAG_BILLBOARD: string;
        static TAG_BRIGHTNESS: string;
        static TAG_GLOW_COLOR_OVERRIDE: string;
        static TAG_HEIGHT: string;
        static TAG_POS_ROT_INTERPOLATION_DURATION: string;
        static TAG_SHADOW_RADIUS: string;
        static TAG_SHADOW_STRENGTH: string;
        static TAG_TRANSFORMATION: string;
        static TAG_TRANSFORMATION_INTERPOLATION_DURATION: string;
        static TAG_TRANSFORMATION_START_INTERPOLATION: string;
        static TAG_VIEW_RANGE: string;
        static TAG_WIDTH: string;
        get billboardConstraints(): $Display$BillboardConstraints;
        getBillboardConstraints(): $Display$BillboardConstraints;
        set billboardConstraints(value: $Display$BillboardConstraints_);
        get boundingBoxForCulling(): $AABB;
        getBoundingBoxForCulling(): $AABB;
        get brightnessOverride(): $Brightness;
        getBrightnessOverride(): $Brightness;
        set brightnessOverride(value: $Brightness);
        get glowColorOverride(): number;
        getGlowColorOverride(): number;
        set glowColorOverride(value: number);
        get height(): number;
        getHeight(): number;
        set height(value: number);
        get interpolation(): $InterpolationHandler;
        getInterpolation(): $InterpolationHandler;
        get packedBrightnessOverride(): number;
        getPackedBrightnessOverride(): number;
        get pistonPushReaction(): $PushReaction;
        getPistonPushReaction(): $PushReaction;
        get posRotInterpolationDuration(): number;
        getPosRotInterpolationDuration(): number;
        set posRotInterpolationDuration(value: number);
        get shadowRadius(): number;
        getShadowRadius(): number;
        set shadowRadius(value: number);
        get shadowStrength(): number;
        getShadowStrength(): number;
        set shadowStrength(value: number);
        get teamColor(): number;
        getTeamColor(): number;
        get transformationInterpolationDelay(): number;
        getTransformationInterpolationDelay(): number;
        set transformationInterpolationDelay(value: number);
        get transformationInterpolationDuration(): number;
        getTransformationInterpolationDuration(): number;
        set transformationInterpolationDuration(value: number);
        get viewRange(): number;
        getViewRange(): number;
        set viewRange(value: number);
        get width(): number;
        getWidth(): number;
        set width(value: number);
        get ignoringBlockTriggers(): boolean;
        isIgnoringBlockTriggers(): boolean;
        affectedByCulling(): boolean;
        calculateInterpolationProgress(partialTickTime: number): number;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        renderState(): $Display$RenderState;
        setPos(x: number, y: number, z: number): void;
        shouldRenderAtSqrDistance(distanceSqr: number): boolean;
        tick(): void;
    }

    export class $Display$BillboardConstraints {
        static CENTER: $Display$BillboardConstraints;
        static FIXED: $Display$BillboardConstraints;
        static HORIZONTAL: $Display$BillboardConstraints;
        static VERTICAL: $Display$BillboardConstraints;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Display$BillboardConstraints[];
        static valueOf(name: string): $Display$BillboardConstraints;
    }

    export class $Display$BlockDisplay extends $Display {
        constructor(type: $EntityType<any>, level: $Level);
        static TAG_BLOCK_STATE: string;
        get blockState(): $BlockState;
        getBlockState(): $BlockState;
        set blockState(value: $BlockState_);
        blockRenderState(): $Display$BlockDisplay$BlockRenderState;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
    }

    export class $Display$BlockDisplay$BlockRenderState extends $Record {
        constructor(blockState: $BlockState_);
        blockState(): $BlockState;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $Display$FloatInterpolator {
        constant(value: number): $Display$FloatInterpolator;
        get(progress: number): number;
    }

    export interface $Display$GenericInterpolator<T> {
        constant<T>(value: T): $Display$GenericInterpolator<T>;
        get(progress: number): T;
    }

    export interface $Display$IntInterpolator {
        constant(value: number): $Display$IntInterpolator;
        get(progress: number): number;
    }

    export class $Display$ItemDisplay extends $Display {
        constructor(type: $EntityType<any>, level: $Level);
        get itemStack(): $ItemStack;
        getItemStack(): $ItemStack;
        set itemStack(value: $ItemStack_);
        get itemTransform(): $ItemDisplayContext;
        getItemTransform(): $ItemDisplayContext;
        set itemTransform(value: $ItemDisplayContext_);
        getSlot(slot: number): $SlotAccess;
        itemRenderState(): $Display$ItemDisplay$ItemRenderState;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
    }

    export class $Display$ItemDisplay$ItemRenderState extends $Record {
        constructor(itemStack: $ItemStack_, itemTransform: $ItemDisplayContext_);
        equals(o: object): boolean;
        hashCode(): number;
        itemStack(): $ItemStack;
        itemTransform(): $ItemDisplayContext;
        toString(): string;
    }

    export class $Display$RenderState extends $Record {
        constructor(transformation: $Display$GenericInterpolator<$Transformation>, billboardConstraints: $Display$BillboardConstraints_, brightnessOverride: number, shadowRadius: $Display$FloatInterpolator, shadowStrength: $Display$FloatInterpolator, glowColorOverride: number);
        billboardConstraints(): $Display$BillboardConstraints;
        brightnessOverride(): number;
        equals(o: object): boolean;
        glowColorOverride(): number;
        hashCode(): number;
        shadowRadius(): $Display$FloatInterpolator;
        shadowStrength(): $Display$FloatInterpolator;
        toString(): string;
        transformation(): $Display$GenericInterpolator<$Transformation>;
    }

    export class $Display$TextDisplay extends $Display {
        constructor(type: $EntityType<any>, level: $Level);
        static FLAG_ALIGN_LEFT: number;
        static FLAG_ALIGN_RIGHT: number;
        static FLAG_SEE_THROUGH: number;
        static FLAG_SHADOW: number;
        static FLAG_USE_DEFAULT_BACKGROUND: number;
        static INITIAL_BACKGROUND: number;
        static TAG_TEXT: string;
        get backgroundColor(): number;
        getBackgroundColor(): number;
        set backgroundColor(value: number);
        get flags(): number;
        getFlags(): number;
        set flags(value: number);
        get lineWidth(): number;
        getLineWidth(): number;
        set lineWidth(value: number);
        get textOpacity(): number;
        getTextOpacity(): number;
        set textOpacity(value: number);
        get text(): $Component;
        getText(): $Component;
        set text(value: $Component_);
        static getAlign(flags: number): $Display$TextDisplay$Align;
        cacheDisplay(splitter: $Display$TextDisplay$LineSplitter): $Display$TextDisplay$CachedInfo;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        textRenderState(): $Display$TextDisplay$TextRenderState;
    }

    export class $Display$TextDisplay$Align {
        static CENTER: $Display$TextDisplay$Align;
        static LEFT: $Display$TextDisplay$Align;
        static RIGHT: $Display$TextDisplay$Align;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Display$TextDisplay$Align[];
        static valueOf(name: string): $Display$TextDisplay$Align;
    }

    export class $Display$TextDisplay$CachedInfo extends $Record {
        constructor(lines: $Display$TextDisplay$CachedLine[], width: number);
        equals(o: object): boolean;
        hashCode(): number;
        lines(): $List<$Display$TextDisplay$CachedLine>;
        toString(): string;
        width(): number;
    }

    export class $Display$TextDisplay$CachedLine extends $Record {
        constructor(contents: $FormattedCharSequence, width: number);
        contents(): $FormattedCharSequence;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        width(): number;
    }

    export interface $Display$TextDisplay$LineSplitter {
        split(input: $Component_, width: number): $Display$TextDisplay$CachedInfo;
    }

    export class $Display$TextDisplay$TextRenderState extends $Record {
        constructor(text: $Component_, lineWidth: number, textOpacity: $Display$IntInterpolator, backgroundColor: $Display$IntInterpolator, flags: number);
        backgroundColor(): $Display$IntInterpolator;
        equals(o: object): boolean;
        flags(): number;
        hashCode(): number;
        lineWidth(): number;
        textOpacity(): $Display$IntInterpolator;
        text(): $Component;
        toString(): string;
    }

    export class $DropChances extends $Record {
        constructor(byEquipment: { [key: $EquipmentSlot_]: number });
        static CODEC: $Codec<$DropChances>;
        static DEFAULT: $DropChances;
        static DEFAULT_EQUIPMENT_DROP_CHANCE: number;
        static PRESERVE_ITEM_DROP_CHANCE: number;
        static PRESERVE_ITEM_DROP_CHANCE_THRESHOLD: number;
        byEquipment(slot: $EquipmentSlot_): number;
        byEquipment(): $Map<$EquipmentSlot, number>;
        equals(o: object): boolean;
        hashCode(): number;
        isPreserved(slot: $EquipmentSlot_): boolean;
        toString(): string;
        withEquipmentChance(slot: $EquipmentSlot_, chance: number): $DropChances;
        withGuaranteedDrop(slot: $EquipmentSlot_): $DropChances;
    }

    export class $ElytraAnimationState {
        constructor(entity: $LivingEntity);
        getRotX(partialTicks: number): number;
        getRotY(partialTicks: number): number;
        getRotZ(partialTicks: number): number;
        tick(): void;
    }

    export class $Entity implements $Nameable, $EntityAccess, $ScoreHolder, $SyncedDataHolder, $DataComponentGetter, $ItemOwner, $SlotProvider, $DebugValueSource, $TypedInstance, $EntityFluidExtension, $AttachmentTarget, $EntityLoadData, $PermissionContextOwner, $EntityAccessor, $InternalEntityFluidExtension, $AttachmentTargetImpl, $EntityLoadDataSetter, $EntityExtension, $MixinEntity, $NekoEntityPData {
        constructor(type: $EntityType<any>, level: $Level);
        static BASE_SAFE_FALL_DISTANCE: number;
        static BASE_TICKS_REQUIRED_TO_FREEZE: number;
        static BOARDING_COOLDOWN: number;
        static CONTENTS_SLOT_INDEX: number;
        static DEFAULT_BB_HEIGHT: number;
        static DEFAULT_BB_WIDTH: number;
        static DELTA_AFFECTED_BY_BLOCKS_BELOW_0_2: number;
        static DELTA_AFFECTED_BY_BLOCKS_BELOW_0_5: number;
        static DELTA_AFFECTED_BY_BLOCKS_BELOW_1_0: number;
        static FREEZE_HURT_FREQUENCY: number;
        static MAX_ENTITY_TAG_COUNT: number;
        static MAX_MOVEMENTS_HANDELED_PER_TICK: number;
        static TAG_AIR: string;
        static TAG_CUSTOM_NAME: string;
        static TAG_DATA: string;
        static TAG_FALL_DISTANCE: string;
        static TAG_FIRE: string;
        static TAG_GLOWING: string;
        static TAG_ID: string;
        static TAG_INVULNERABLE: string;
        static TAG_MOTION: string;
        static TAG_NO_GRAVITY: string;
        static TAG_ON_GROUND: string;
        static TAG_PASSENGERS: string;
        static TAG_PORTAL_COOLDOWN: string;
        static TAG_POS: string;
        static TAG_ROTATION: string;
        static TAG_SILENT: string;
        static TAG_UUID: string;
        static TOTAL_AIR_SUPPLY: number;
        blocksBuilding: boolean;
        fallDistance: number;
        flyDist: number;
        horizontalCollision: boolean;
        hurtMarked: boolean;
        invulnerableTime: number;
        isInPowderSnow: boolean;
        mainSupportingBlockPos: $Optional<$BlockPos>;
        minorHorizontalCollision: boolean;
        moveDist: number;
        needsSync: boolean;
        noPhysics: boolean;
        portalProcess: $PortalProcessor;
        tickCount: number;
        verticalCollision: boolean;
        verticalCollisionBelow: boolean;
        wasInPowderSnow: boolean;
        xOld: number;
        xRotO: number;
        xo: number;
        yOld: number;
        yRotO: number;
        yo: number;
        zOld: number;
        zo: number;
        get airSupply(): number;
        getAirSupply(): number;
        set airSupply(value: number);
        get attachments(): $EntityAttachments;
        getAttachments(): $EntityAttachments;
        get bbHeight(): number;
        getBbHeight(): number;
        get bbWidth(): number;
        getBbWidth(): number;
        get blockPosBelowThatAffectsMyMovement(): $BlockPos;
        getBlockPosBelowThatAffectsMyMovement(): $BlockPos;
        get blockStateOn(): $BlockState;
        getBlockStateOn(): $BlockState;
        get blockX(): number;
        getBlockX(): number;
        get blockY(): number;
        getBlockY(): number;
        get blockZ(): number;
        getBlockZ(): number;
        get boundingBox(): $AABB;
        getBoundingBox(): $AABB;
        set boundingBox(value: $AABB);
        get controlledVehicle(): $Entity;
        getControlledVehicle(): $Entity;
        get controllingPassenger(): $LivingEntity;
        getControllingPassenger(): $LivingEntity;
        get customName(): $Component;
        getCustomName(): $Component;
        set customName(value: $Component_);
        get deltaMovement(): $Vec3;
        getDeltaMovement(): $Vec3;
        set deltaMovement(value: $Vec3_);
        get dimensionChangingDelay(): number;
        getDimensionChangingDelay(): number;
        get direction(): $Direction;
        getDirection(): $Direction;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get entityData(): $SynchedEntityData;
        getEntityData(): $SynchedEntityData;
        get eyeHeight(): number;
        getEyeHeight(): number;
        get eyePosition(): $Vec3;
        getEyePosition(): $Vec3;
        get eyeY(): number;
        getEyeY(): number;
        get firstPassenger(): $Entity;
        getFirstPassenger(): $Entity;
        get fluidInteractionBox(): $AABB;
        getFluidInteractionBox(): $AABB;
        get fluidJumpThreshold(): number;
        getFluidJumpThreshold(): number;
        get forward(): $Vec3;
        getForward(): $Vec3;
        get gravity(): number;
        getGravity(): number;
        get headLookAngle(): $Vec3;
        getHeadLookAngle(): $Vec3;
        get id(): number;
        getId(): number;
        set id(value: number);
        get inBlockState(): $BlockState;
        getInBlockState(): $BlockState;
        get indirectPassengers(): $Iterable<$Entity>;
        getIndirectPassengers(): $Iterable<$Entity>;
        get interpolation(): $InterpolationHandler;
        getInterpolation(): $InterpolationHandler;
        get knownMovement(): $Vec3;
        getKnownMovement(): $Vec3;
        get knownSpeed(): $Vec3;
        getKnownSpeed(): $Vec3;
        get lightLevelDependentMagicValue(): number;
        getLightLevelDependentMagicValue(): number;
        get lookAngle(): $Vec3;
        getLookAngle(): $Vec3;
        get lootTable(): $Optional<$ResourceKey<$LootTable>>;
        getLootTable(): $Optional<$ResourceKey<$LootTable>>;
        get maxAirSupply(): number;
        getMaxAirSupply(): number;
        get maxFallDistance(): number;
        getMaxFallDistance(): number;
        get motionDirection(): $Direction;
        getMotionDirection(): $Direction;
        get name(): $Component;
        getName(): $Component;
        get nearestViewDirection(): $Direction;
        getNearestViewDirection(): $Direction;
        get onPosLegacy(): $BlockPos;
        getOnPosLegacy(): $BlockPos;
        get onPos(): $BlockPos;
        getOnPos(): $BlockPos;
        get passengersAndSelf(): $Stream<$Entity>;
        getPassengersAndSelf(): $Stream<$Entity>;
        get passengers(): $List<$Entity>;
        getPassengers(): $List<$Entity>;
        get percentFrozen(): number;
        getPercentFrozen(): number;
        get permissionContext(): $PermissionContext;
        getPermissionContext(): $PermissionContext;
        get pickRadius(): number;
        getPickRadius(): number;
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        get pistonPushReaction(): $PushReaction;
        getPistonPushReaction(): $PushReaction;
        get portalCooldown(): number;
        getPortalCooldown(): number;
        set portalCooldown(value: number);
        get pose(): $Pose;
        getPose(): $Pose;
        set pose(value: $Pose_);
        get positionCodec(): $VecDeltaCodec;
        getPositionCodec(): $VecDeltaCodec;
        get quadLeashHolderOffsets(): $Vec3[];
        getQuadLeashHolderOffsets(): $Vec3[];
        get randomY(): number;
        getRandomY(): number;
        get random(): $RandomSource;
        getRandom(): $RandomSource;
        get remainingFireTicks(): number;
        getRemainingFireTicks(): number;
        set remainingFireTicks(value: number);
        get removalReason(): $Entity$RemovalReason;
        getRemovalReason(): $Entity$RemovalReason;
        get requiresPrecisePosition(): boolean;
        getRequiresPrecisePosition(): boolean;
        set requiresPrecisePosition(value: boolean);
        get rootVehicle(): $Entity;
        getRootVehicle(): $Entity;
        get rotationVector(): $Vec2;
        getRotationVector(): $Vec2;
        get scoreboardName(): string;
        getScoreboardName(): string;
        get selfAndPassengers(): $Stream<$Entity>;
        getSelfAndPassengers(): $Stream<$Entity>;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get stringUUID(): string;
        getStringUUID(): string;
        get teamColor(): number;
        getTeamColor(): number;
        get team(): $PlayerTeam;
        getTeam(): $PlayerTeam;
        get ticksFrozen(): number;
        getTicksFrozen(): number;
        set ticksFrozen(value: number);
        get ticksRequiredToFreeze(): number;
        getTicksRequiredToFreeze(): number;
        get type(): $EntityType<any>;
        getType(): $EntityType<any>;
        get uUID(): $UUID;
        getUUID(): $UUID;
        set uUID(value: string);
        get vehicle(): $Entity;
        getVehicle(): $Entity;
        get visualRotationYInDegrees(): number;
        getVisualRotationYInDegrees(): number;
        get weaponItem(): $ItemStack;
        getWeaponItem(): $ItemStack;
        get xRot(): number;
        getXRot(): number;
        set xRot(value: number);
        get x(): number;
        getX(): number;
        get yHeadRot(): number;
        getYHeadRot(): number;
        set yHeadRot(value: number);
        get yRot(): number;
        getYRot(): number;
        set yRot(value: number);
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        get alive(): boolean;
        isAlive(): boolean;
        get alwaysTicking(): boolean;
        isAlwaysTicking(): boolean;
        get attackable(): boolean;
        isAttackable(): boolean;
        get clientAuthoritative(): boolean;
        isClientAuthoritative(): boolean;
        get crouching(): boolean;
        isCrouching(): boolean;
        get currentlyGlowing(): boolean;
        isCurrentlyGlowing(): boolean;
        get customNameVisible(): boolean;
        isCustomNameVisible(): boolean;
        set customNameVisible(value: boolean);
        get descending(): boolean;
        isDescending(): boolean;
        get discrete(): boolean;
        isDiscrete(): boolean;
        get effectiveAi(): boolean;
        isEffectiveAi(): boolean;
        get flyingVehicle(): boolean;
        isFlyingVehicle(): boolean;
        get freezing(): boolean;
        isFreezing(): boolean;
        get fullyFrozen(): boolean;
        isFullyFrozen(): boolean;
        get ignoringBlockTriggers(): boolean;
        isIgnoringBlockTriggers(): boolean;
        get inClouds(): boolean;
        isInClouds(): boolean;
        get inLava(): boolean;
        isInLava(): boolean;
        get inLiquid(): boolean;
        isInLiquid(): boolean;
        get inShallowWater(): boolean;
        isInShallowWater(): boolean;
        get inWall(): boolean;
        isInWall(): boolean;
        get inWaterOrRain(): boolean;
        isInWaterOrRain(): boolean;
        get inWater(): boolean;
        isInWater(): boolean;
        get interpolating(): boolean;
        isInterpolating(): boolean;
        get invisible(): boolean;
        isInvisible(): boolean;
        set invisible(value: boolean);
        get invulnerable(): boolean;
        isInvulnerable(): boolean;
        set invulnerable(value: boolean);
        get loadedFromDisk(): boolean;
        isLoadedFromDisk(): boolean;
        get localInstanceAuthoritative(): boolean;
        isLocalInstanceAuthoritative(): boolean;
        get noGravity(): boolean;
        isNoGravity(): boolean;
        set noGravity(value: boolean);
        get onFire(): boolean;
        isOnFire(): boolean;
        get onPortalCooldown(): boolean;
        isOnPortalCooldown(): boolean;
        get onRails(): boolean;
        isOnRails(): boolean;
        get passenger(): boolean;
        isPassenger(): boolean;
        get pickable(): boolean;
        isPickable(): boolean;
        get pushable(): boolean;
        isPushable(): boolean;
        get pushedByFluid(): boolean;
        isPushedByFluid(): boolean;
        get removed(): boolean;
        isRemoved(): boolean;
        set removed(value: $Entity$RemovalReason_);
        get shiftKeyDown(): boolean;
        isShiftKeyDown(): boolean;
        set shiftKeyDown(value: boolean);
        get silent(): boolean;
        isSilent(): boolean;
        set silent(value: boolean);
        get spectator(): boolean;
        isSpectator(): boolean;
        get sprinting(): boolean;
        isSprinting(): boolean;
        set sprinting(value: boolean);
        get steppingCarefully(): boolean;
        isSteppingCarefully(): boolean;
        get suppressingBounce(): boolean;
        isSuppressingBounce(): boolean;
        get swimming(): boolean;
        isSwimming(): boolean;
        set swimming(value: boolean);
        get underWater(): boolean;
        isUnderWater(): boolean;
        get visuallyCrawling(): boolean;
        isVisuallyCrawling(): boolean;
        get visuallySwimming(): boolean;
        isVisuallySwimming(): boolean;
        get pDataRoot(): $CompoundTag;
        getPDataRoot(): $CompoundTag;
        static collectAllColliders(source: $Entity, level: $Level, boundingBox: $AABB): $List<$VoxelShape>;
        static collideBoundingBox(source: $Entity, movement: $Vec3_, boundingBox: $AABB, level: $Level, entityColliders: $VoxelShape[]): $Vec3;
        static getViewScale(): number;
        static setViewScale(viewScale: number): void;
        absSnapRotationTo(yRot: number, xRot: number): void;
        absSnapTo(x: number, y: number, z: number, yRot: number, xRot: number): void;
        absSnapTo(x: number, y: number, z: number): void;
        addDeltaMovement(momentum: $Vec3_): void;
        addTag(tag: string): boolean;
        adjustSpawnLocation(level: $ServerLevel, spawnSuggestion: $BlockPos_): $BlockPos;
        animateHurt(direction: number): void;
        applyComponentsFromItemStack(stack: $ItemStack_): void;
        applyEffectsFromBlocks(from: $Vec3_, to: $Vec3_): void;
        awardKillScore(victim: $Entity, killingBlow: $DamageSource): void;
        baseTick(): void;
        belowNameDisplay(): $Component;
        blockPosition(): $BlockPos;
        broadcastToPlayer(player: $ServerPlayer): boolean;
        calculateViewVector(xRot: number, yRot: number): $Vec3;
        canBeCollidedWith(other: $Entity): boolean;
        canBeHitByProjectile(): boolean;
        canCollideWith(entity: $Entity): boolean;
        canControlVehicle(): boolean;
        canFreeze(): boolean;
        canInteractWithLevel(): boolean;
        canSimulateMovement(): boolean;
        canSpawnSprintParticle(): boolean;
        canSprint(): boolean;
        canTeleport(from: $Level, to: $Level): boolean;
        canUsePortal(ignorePassenger: boolean): boolean;
        causeFallDamage(fallDistance: number, damageModifier: number, damageSource: $DamageSource): boolean;
        checkBelowWorld(): void;
        checkDespawn(): void;
        checkFallDistanceAccumulation(): void;
        chunkPosition(): $ChunkPos;
        clearFire(): void;
        clearFreeze(): void;
        closerThan(other: $Entity, distanceXZ: number, distanceY: number): boolean;
        closerThan(other: $Entity, distance: number): boolean;
        collidedWithFluid(fluidState: $FluidState, blockPos: $BlockPos_, from: $Vec3_, to: $Vec3_): boolean;
        collidedWithShapeMovingFrom(from: $Vec3_, to: $Vec3_, aabbs: $AABB[]): boolean;
        copyPosition(target: $Entity): void;
        countPlayerPassengers(): number;
        createCommandSourceStackForNameResolution(level: $ServerLevel): $CommandSourceStack;
        damageSources(): $DamageSources;
        dampensVibrations(): boolean;
        deflection(projectile: $Projectile): $ProjectileDeflection;
        discard(): void;
        dismountTo(x: number, y: number, z: number): void;
        dismountsUnderwater(): boolean;
        displayFireAnimation(): boolean;
        distanceToSqr(x2: number, y2: number, z2: number): number;
        distanceToSqr(entity: $Entity): number;
        distanceToSqr(pos: $Vec3_): number;
        distanceTo(entity: $Entity): number;
        doCheckFallDamage(xa: number, ya: number, za: number, onGround: boolean): void;
        dropAllLeashConnections(player: $Player): boolean;
        ejectPassengers(): void;
        entityTags(): $Set<string>;
        equals(obj: object): boolean;
        extinguishFire(): void;
        fabric_api$getTouchedCustomFluids(): $Set;
        fabric_clearDeferredSyncChanges(): void;
        fabric_computeInitialSyncChanges(arg0: $ServerPlayer, arg1: $Consumer): void;
        fabric_getAttachments(): $Map;
        fabric_getRegistryAccess(): $RegistryAccess;
        fabric_getSyncTargetInfo(): $AttachmentTargetInfo;
        fabric_hasPersistentAttachments(): boolean;
        fabric_readAttachmentsFromNbt(arg0: $ValueInput): void;
        fabric_sendAndClearDeferredSyncChanges(arg0: $List): void;
        fabric_setLoadedFromDisk(arg0: boolean): void;
        fabric_setSpawnReason(arg0: $EntitySpawnReason_): void;
        fabric_shouldTryToSync(): boolean;
        fabric_syncChange(arg0: $AttachmentType, arg1: $AttachmentChange): void;
        fabric_updateSyncTarget(arg0: $AttachmentTargetInfo, arg1: $AttachmentTargetInfo): void;
        fabric_writeAttachmentsToNbt(arg0: $ValueOutput): void;
        fillCrashReportCategory(category: $CrashReportCategory): void;
        fireImmune(): boolean;
        forceSetRotation(yRot: number, relativeY: boolean, xRot: number, relativeX: boolean): void;
        fudgePositionAfterSizeChange(previousDimensions: $EntityDimensions): boolean;
        gameEvent(event: $Holder<$GameEvent_>, sourceEntity: $Entity): void;
        gameEvent(event: $Holder<$GameEvent_>): void;
        getAddEntityPacket(serverEntity: $ServerEntity): $Packet<$ClientGamePacketListener>;
        getAttached(arg0: $AttachmentType): object;
        getAvailableSpaceBelow(maxDistance: number): number;
        getBlockExplosionResistance(explosion: $Explosion, level: $BlockGetter, pos: $BlockPos_, block: $BlockState_, fluid: $FluidState, resistance: number): number;
        getDimensions(pose: $Pose_): $EntityDimensions;
        getDismountLocationForPassenger(passenger: $LivingEntity): $Vec3;
        getEyeHeight(pose: $Pose_): number;
        getEyePosition(partialTickTime: number): $Vec3;
        getFluidHeight(type: $TagKey<$Fluid_>): number;
        getHandHoldingItemAngle(item: $Item_): $Vec3;
        getLightProbePosition(partialTickTime: number): $Vec3;
        getPassengerRidingPosition(passenger: $Entity): $Vec3;
        getPosition(partialTickTime: number): $Vec3;
        getPreciseBodyRotation(partial: number): number;
        getRandomX(spread: number): number;
        getRandomY(spread: number): number;
        getRandomZ(spread: number): number;
        getRelativePortalPosition(axis: $Direction$Axis_, portalArea: $BlockUtil$FoundRectangle): $Vec3;
        getRopeHoldPosition(partialTickTime: number): $Vec3;
        getSlot(slot: number): $SlotAccess;
        getUpVector(a: number): $Vec3;
        getVehicleAttachmentPoint(vehicle: $Entity): $Vec3;
        getViewVector(a: number): $Vec3;
        getViewXRot(a: number): number;
        getViewYRot(a: number): number;
        getXRot(partialTicks: number): number;
        getX(progress: number): number;
        getYRot(partialTicks: number): number;
        getY(progress: number): number;
        getZ(progress: number): number;
        get<T>(type: $DataComponentType<T>): T;
        handleDamageEvent(source: $DamageSource): void;
        handleEntityEvent(id: number): void;
        hasAttached(arg0: $AttachmentType): boolean;
        hasControllingPassenger(): boolean;
        hasCustomName(): boolean;
        hasExactlyOnePlayerPassenger(): boolean;
        hasGlowingTag(): boolean;
        hasIndirectPassenger(entity: $Entity): boolean;
        hasMovedHorizontallyRecently(): boolean;
        hasPassenger(test: $Predicate<$Entity>): boolean;
        hasPassenger(entity: $Entity): boolean;
        hasPose(pose: $Pose_): boolean;
        hashCode(): number;
        hurtClient(source: $DamageSource): boolean;
        hurtOrSimulate(source: $DamageSource, damage: number): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        hurt(source: $DamageSource, damage: number): void;
        igniteForSeconds(numberOfSeconds: number): void;
        igniteForTicks(numberOfTicks: number): void;
        ignoreExplosion(explosion: $Explosion): boolean;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        isAlliedTo(other: $Entity): boolean;
        isAlliedTo(other: $Team): boolean;
        isColliding(pos: $BlockPos_, state: $BlockState_): boolean;
        isEyeInFluid(type: $TagKey<$Fluid_>): boolean;
        isFree(xa: number, ya: number, za: number): boolean;
        isInFluid(arg0: $TagKey_): boolean;
        isInvisibleTo(player: $Player): boolean;
        isPassengerOfSameVehicle(other: $Entity): boolean;
        isSupportedBy(pos: $BlockPos_): boolean;
        is(other: $Entity): boolean;
        killedEntity(level: $ServerLevel, entity: $LivingEntity, source: $DamageSource): boolean;
        kill(level: $ServerLevel): void;
        lavaHurt(): void;
        lavaIgnite(): void;
        lerpHeadTo(yRot: number, steps: number): void;
        lerpMotion(movement: $Vec3_): void;
        level(): $Level;
        load(input: $ValueInput): void;
        lookAt(anchor: $EntityAnchorArgument$Anchor_, pos: $Vec3_): void;
        makeStuckInBlock(blockState: $BlockState_, speedMultiplier: $Vec3_): void;
        maxUpStep(): number;
        mayInteract(level: $ServerLevel, pos: $BlockPos_): boolean;
        mirror(mirror: $Mirror_): number;
        moveOrInterpolateTo(yRot: number, xRot: number): void;
        moveOrInterpolateTo(position: $Optional<$Vec3_>, yRot: $Optional<number>, xRot: $Optional<number>): void;
        moveOrInterpolateTo(position: $Vec3_, yRot: number, xRot: number): void;
        moveOrInterpolateTo(position: $Vec3_): void;
        moveRelative(speed: number, input: $Vec3_): void;
        move(moverType: $MoverType_, delta: $Vec3_): void;
        notifyLeashHolder(entity: $Leashable): void;
        notifyLeasheeRemoved(entity: $Leashable): void;
        oldPosition(): $Vec3;
        onAboveBubbleColumn(dragDown: boolean, pos: $BlockPos_): void;
        onAttachedSet(arg0: $AttachmentType): $Event;
        onClientRemoval(): void;
        onExplosionHit(explosionCausedBy: $Entity): void;
        onGround(): boolean;
        onInsideBubbleColumn(dragDown: boolean): void;
        onPassengerTurned(passenger: $Entity): void;
        onRemoval(reason: $Entity$RemovalReason_): void;
        onSyncedDataUpdated(updatedItems: $SynchedEntityData$DataValue<any>[]): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        pick(range: number, a: number, withLiquids: boolean): $HitResult;
        placePortalTicket(ticketPosition: $BlockPos_): void;
        playSound(sound: $SoundEvent_, volume: number, pitch: number): void;
        playSound(sound: $SoundEvent_): void;
        playerTouch(player: $Player): void;
        positionRider(passenger: $Entity): void;
        position(): $Vec3;
        problemPath(): $ProblemReporter$PathElement;
        push(xa: number, ya: number, za: number): void;
        push(entity: $Entity): void;
        push(impulse: $Vec3_): void;
        recreateFromPacket(packet: $ClientboundAddEntityPacket): void;
        refreshDimensions(): void;
        registerDebugValues(level: $ServerLevel, registration: $DebugValueSource$Registration): void;
        registryAccess(): $RegistryAccess;
        removeLatestMovementRecording(): void;
        removeTag(tag: string): boolean;
        removeVehicle(): void;
        remove(reason: $Entity$RemovalReason_): void;
        resetFallDistance(): void;
        restoreFrom(oldEntity: $Entity): void;
        rideTick(): void;
        rotate(rotation: $Rotation_): number;
        saveAsPassenger(output: $ValueOutput): boolean;
        saveWithoutId(output: $ValueOutput): void;
        save(output: $ValueOutput): boolean;
        setAsInsidePortal(portal: $Portal, pos: $BlockPos_): void;
        setAttached(arg0: $AttachmentType, arg1: object): object;
        setComponent<T>(type: $DataComponentType<T>, value: T): void;
        setDeltaMovement(xd: number, yd: number, zd: number): void;
        setOldPosAndRot(position: $Vec3_, yRot: number, xRot: number): void;
        setOldPosAndRot(): void;
        setOldRot(): void;
        setOnGroundWithMovement(onGround: boolean, horizontalCollision: boolean, movement: $Vec3_): void;
        setOnGroundWithMovement(onGround: boolean, movement: $Vec3_): void;
        setPortalCooldown(): void;
        setPosRaw(x: number, y: number, z: number): void;
        setPos(x: number, y: number, z: number): void;
        shearOffAllLeashConnections(player: $Player): boolean;
        shouldBeSaved(): boolean;
        shouldBlockExplode(explosion: $Explosion, level: $BlockGetter, pos: $BlockPos_, state: $BlockState_, power: number): boolean;
        shouldRenderAtSqrDistance(distance: number): boolean;
        shouldRender(camX: number, camY: number, camZ: number): boolean;
        shouldShowName(): boolean;
        showVehicleHealth(): boolean;
        skipAttackInteraction(source: $Entity): boolean;
        snapTo(x: number, y: number, z: number, yRot: number, xRot: number): void;
        snapTo(x: number, y: number, z: number): void;
        snapTo(spawnPos: $BlockPos_, yRot: number, xRot: number): void;
        snapTo(spawnPos: $Vec3_, yRot: number, xRot: number): void;
        snapTo(pos: $Vec3_): void;
        spawnAtLocation(level: $ServerLevel, itemStack: $ItemStack_, offset: number): $ItemEntity;
        spawnAtLocation(level: $ServerLevel, itemStack: $ItemStack_, offset: $Vec3_): $ItemEntity;
        spawnAtLocation(level: $ServerLevel, itemStack: $ItemStack_): $ItemEntity;
        spawnAtLocation(level: $ServerLevel, resource: $ItemLike_): $ItemEntity;
        spawnReason(): $EntitySpawnReason;
        startRiding(entityToRide: $Entity, force: boolean, sendEventAndTriggers: boolean): boolean;
        startRiding(entity: $Entity): boolean;
        startSeenByPlayer(player: $ServerPlayer): void;
        stopRiding(): void;
        stopSeenByPlayer(player: $ServerPlayer): void;
        supportQuadLeashAsHolder(): boolean;
        syncPacketPositionCodec(x: number, y: number, z: number): void;
        teleportRelative(dx: number, dy: number, dz: number): void;
        teleportSetPosition(destination: $PositionMoveRotation, relatives: $Relative_[]): void;
        teleportSetPosition(currentValues: $PositionMoveRotation, destination: $PositionMoveRotation, relatives: $Relative_[]): void;
        teleportTo(x: number, y: number, z: number): void;
        teleportTo(level: $ServerLevel, x: number, y: number, z: number, relatives: $Relative_[], newYRot: number, newXRot: number, resetCamera: boolean): boolean;
        teleport(transition: $TeleportTransition): $Entity;
        thunderHit(level: $ServerLevel, lightningBolt: $LightningBolt): void;
        tick(): void;
        toString(): string;
        touchingUnloadedChunk(): boolean;
        trackingPosition(): $Vec3;
        turn(xo: number, yo: number): void;
        typeHolder(): $Holder<$EntityType<any>>;
        unRide(): void;
        updateDataBeforeSync(): void;
        updateDynamicGameEventListener(action: $BiConsumer<$DynamicGameEventListener<any>, $ServerLevel>): void;
        updateSwimming(): void;
    }

    export class $Entity$RemovalReason {
        static CHANGED_DIMENSION: $Entity$RemovalReason;
        static DISCARDED: $Entity$RemovalReason;
        static KILLED: $Entity$RemovalReason;
        static UNLOADED_TO_CHUNK: $Entity$RemovalReason;
        static UNLOADED_WITH_PLAYER: $Entity$RemovalReason;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Entity$RemovalReason[];
        static valueOf(name: string): $Entity$RemovalReason;
    }

    export class $EntityAttachment {
        static NAME_TAG: $EntityAttachment;
        static PASSENGER: $EntityAttachment;
        static VEHICLE: $EntityAttachment;
        static WARDEN_CHEST: $EntityAttachment;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EntityAttachment[];
        static valueOf(name: string): $EntityAttachment;
    }

    export class $EntityAttachments {
        static builder(): $EntityAttachments$Builder;
        static createDefault(width: number, height: number): $EntityAttachments;
        getAverage(attachment: $EntityAttachment_): $Vec3;
        getClamped(attachment: $EntityAttachment_, index: number, rotY: number): $Vec3;
        getNullable(attachment: $EntityAttachment_, index: number, rotY: number): $Vec3;
        get(attachment: $EntityAttachment_, index: number, rotY: number): $Vec3;
        scale(x: number, y: number, z: number): $EntityAttachments;
    }

    export class $EntityAttachments$Builder {
        attach(attachment: $EntityAttachment_, x: number, y: number, z: number): $EntityAttachments$Builder;
        attach(attachment: $EntityAttachment_, point: $Vec3_): $EntityAttachments$Builder;
        build(width: number, height: number): $EntityAttachments;
    }

    export class $EntityDimensions extends $Record {
        constructor(width: number, height: number, eyeHeight: number, attachments: $EntityAttachments, fixed: boolean);
        static fixed(width: number, height: number): $EntityDimensions;
        static scalable(width: number, height: number): $EntityDimensions;
        attachments(): $EntityAttachments;
        equals(o: object): boolean;
        eyeHeight(): number;
        fixed(): boolean;
        hashCode(): number;
        height(): number;
        makeBoundingBox(x: number, y: number, z: number): $AABB;
        makeBoundingBox(pos: $Vec3_): $AABB;
        scale(widthScaleFactor: number, heightScaleFactor: number): $EntityDimensions;
        scale(scaleFactor: number): $EntityDimensions;
        toString(): string;
        width(): number;
        withAttachments(attachments: $EntityAttachments$Builder): $EntityDimensions;
        withEyeHeight(eyeHeight: number): $EntityDimensions;
    }

    export class $EntityEquipment {
        constructor();
        static CODEC: $Codec<$EntityEquipment>;
        get empty(): boolean;
        isEmpty(): boolean;
        clear(): void;
        dropAll(dropper: $LivingEntity): void;
        get(slot: $EquipmentSlot_): $ItemStack;
        set(slot: $EquipmentSlot_, itemStack: $ItemStack_): $ItemStack;
        tick(owner: $Entity): void;
    }

    export interface $EntityProcessor {
        process(input: $Entity): $Entity;
        static NOP: $EntityProcessor;
    }

    export class $EntityReference<StoredEntityType extends $UniquelyIdentifyable> {
        get uUID(): $UUID;
        getUUID(): $UUID;
        static codec<Type>(): $Codec<$EntityReference<Type>>;
        static getEntity(reference: $EntityReference<$Entity>, level: $Level): $Entity;
        static getLivingEntity(reference: $EntityReference<$LivingEntity>, level: $Level): $LivingEntity;
        static getPlayer(reference: $EntityReference<$Player>, level: $Level): $Player;
        static get<StoredEntityType>(reference: $EntityReference<StoredEntityType>, level: $Level, clazz: $Class<StoredEntityType>): StoredEntityType;
        static of<T>(entity: T): $EntityReference<T>;
        static of<T>(uuid: string): $EntityReference<T>;
        static readWithOldOwnerConversion<StoredEntityType>(input: $ValueInput, key: string, level: $Level): $EntityReference<StoredEntityType>;
        static read<StoredEntityType>(input: $ValueInput, key: string): $EntityReference<StoredEntityType>;
        static store(reference: $EntityReference<any>, output: $ValueOutput, key: string): void;
        static streamCodec<Type>(): $StreamCodec<$ByteBuf, $EntityReference<Type>>;
        equals(obj: object): boolean;
        getEntity(level: $Level, clazz: $Class<StoredEntityType>): StoredEntityType;
        getEntity(lookup: $UUIDLookup<$UniquelyIdentifyable>, clazz: $Class<StoredEntityType>): StoredEntityType;
        hashCode(): number;
        matches(entity: StoredEntityType): boolean;
        store(output: $ValueOutput, key: string): void;
    }

    export class $EntitySpawnReason {
        static BREEDING: $EntitySpawnReason;
        static BUCKET: $EntitySpawnReason;
        static CHUNK_GENERATION: $EntitySpawnReason;
        static COMMAND: $EntitySpawnReason;
        static CONVERSION: $EntitySpawnReason;
        static DIMENSION_TRAVEL: $EntitySpawnReason;
        static DISPENSER: $EntitySpawnReason;
        static EVENT: $EntitySpawnReason;
        static JOCKEY: $EntitySpawnReason;
        static LOAD: $EntitySpawnReason;
        static MOB_SUMMONED: $EntitySpawnReason;
        static NATURAL: $EntitySpawnReason;
        static PATROL: $EntitySpawnReason;
        static REINFORCEMENT: $EntitySpawnReason;
        static SPAWNER: $EntitySpawnReason;
        static SPAWN_ITEM_USE: $EntitySpawnReason;
        static STRUCTURE: $EntitySpawnReason;
        static TRIAL_SPAWNER: $EntitySpawnReason;
        static TRIGGERED: $EntitySpawnReason;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EntitySpawnReason[];
        static valueOf(name: string): $EntitySpawnReason;
    }

    export class $EntityType<T extends $Entity> implements $EntityTypeTest, $FeatureElement, $FabricEntityTypeImpl {
        constructor(factory: $EntityType$EntityFactory<T>, category: $MobCategory_, serialize: boolean, summon: boolean, fireImmune: boolean, canSpawnFarFromPlayer: boolean, immuneTo: $ImmutableSet<$Block_>, dimensions: $EntityDimensions, spawnDimensionsScale: number, clientTrackingRange: number, updateInterval: number, descriptionId: string, lootTable: $Optional<$ResourceKey<$LootTable>>, requiredFeatures: $FeatureFlagSet, allowedInPeaceful: boolean);
        static ACACIA_BOAT: $EntityType<$Boat>;
        static ACACIA_CHEST_BOAT: $EntityType<$ChestBoat>;
        static ALLAY: $EntityType<$Allay>;
        static AREA_EFFECT_CLOUD: $EntityType<$AreaEffectCloud>;
        static ARMADILLO: $EntityType<$Armadillo>;
        static ARMOR_STAND: $EntityType<$ArmorStand>;
        static ARROW: $EntityType<$Arrow>;
        static AXOLOTL: $EntityType<$Axolotl>;
        static BAMBOO_CHEST_RAFT: $EntityType<$ChestRaft>;
        static BAMBOO_RAFT: $EntityType<$Raft>;
        static BAT: $EntityType<$Bat>;
        static BEE: $EntityType<$Bee>;
        static BIRCH_BOAT: $EntityType<$Boat>;
        static BIRCH_CHEST_BOAT: $EntityType<$ChestBoat>;
        static BLAZE: $EntityType<$Blaze>;
        static BLOCK_DISPLAY: $EntityType<$Display$BlockDisplay>;
        static BOGGED: $EntityType<$Bogged>;
        static BREEZE: $EntityType<$Breeze>;
        static BREEZE_WIND_CHARGE: $EntityType<$BreezeWindCharge>;
        static CAMEL: $EntityType<$Camel>;
        static CAMEL_HUSK: $EntityType<$CamelHusk>;
        static CAT: $EntityType<$Cat>;
        static CAVE_SPIDER: $EntityType<$CaveSpider>;
        static CHERRY_BOAT: $EntityType<$Boat>;
        static CHERRY_CHEST_BOAT: $EntityType<$ChestBoat>;
        static CHEST_MINECART: $EntityType<$MinecartChest>;
        static CHICKEN: $EntityType<$Chicken>;
        static COD: $EntityType<$Cod>;
        static CODEC: $Codec<$EntityType<any>>;
        static COMMAND_BLOCK_MINECART: $EntityType<$MinecartCommandBlock>;
        static COPPER_GOLEM: $EntityType<$CopperGolem>;
        static COW: $EntityType<$Cow>;
        static CREAKING: $EntityType<$Creaking>;
        static CREEPER: $EntityType<$Creeper>;
        static DARK_OAK_BOAT: $EntityType<$Boat>;
        static DARK_OAK_CHEST_BOAT: $EntityType<$ChestBoat>;
        static DOLPHIN: $EntityType<$Dolphin>;
        static DONKEY: $EntityType<$Donkey>;
        static DRAGON_FIREBALL: $EntityType<$DragonFireball>;
        static DROWNED: $EntityType<$Drowned>;
        static EGG: $EntityType<$ThrownEgg>;
        static ELDER_GUARDIAN: $EntityType<$ElderGuardian>;
        static ENDERMAN: $EntityType<$EnderMan>;
        static ENDERMITE: $EntityType<$Endermite>;
        static ENDER_DRAGON: $EntityType<$EnderDragon>;
        static ENDER_PEARL: $EntityType<$ThrownEnderpearl>;
        static END_CRYSTAL: $EntityType<$EndCrystal>;
        static EVOKER: $EntityType<$Evoker>;
        static EVOKER_FANGS: $EntityType<$EvokerFangs>;
        static EXPERIENCE_BOTTLE: $EntityType<$ThrownExperienceBottle>;
        static EXPERIENCE_ORB: $EntityType<$ExperienceOrb>;
        static EYE_OF_ENDER: $EntityType<$EyeOfEnder>;
        static FALLING_BLOCK: $EntityType<$FallingBlockEntity>;
        static FIREBALL: $EntityType<$LargeFireball>;
        static FIREWORK_ROCKET: $EntityType<$FireworkRocketEntity>;
        static FISHING_BOBBER: $EntityType<$FishingHook>;
        static FOX: $EntityType<$Fox>;
        static FROG: $EntityType<$Frog>;
        static FURNACE_MINECART: $EntityType<$MinecartFurnace>;
        static GHAST: $EntityType<$Ghast>;
        static GIANT: $EntityType<$Giant>;
        static GLOW_ITEM_FRAME: $EntityType<$GlowItemFrame>;
        static GLOW_SQUID: $EntityType<$GlowSquid>;
        static GOAT: $EntityType<$Goat>;
        static GUARDIAN: $EntityType<$Guardian>;
        static HAPPY_GHAST: $EntityType<$HappyGhast>;
        static HOGLIN: $EntityType<$Hoglin>;
        static HOPPER_MINECART: $EntityType<$MinecartHopper>;
        static HORSE: $EntityType<$Horse>;
        static HUSK: $EntityType<$Husk>;
        static ILLUSIONER: $EntityType<$Illusioner>;
        static INTERACTION: $EntityType<$Interaction>;
        static IRON_GOLEM: $EntityType<$IronGolem>;
        static ITEM: $EntityType<$ItemEntity>;
        static ITEM_DISPLAY: $EntityType<$Display$ItemDisplay>;
        static ITEM_FRAME: $EntityType<$ItemFrame>;
        static JUNGLE_BOAT: $EntityType<$Boat>;
        static JUNGLE_CHEST_BOAT: $EntityType<$ChestBoat>;
        static LEASH_KNOT: $EntityType<$LeashFenceKnotEntity>;
        static LIGHTNING_BOLT: $EntityType<$LightningBolt>;
        static LINGERING_POTION: $EntityType<$ThrownLingeringPotion>;
        static LLAMA: $EntityType<$Llama>;
        static LLAMA_SPIT: $EntityType<$LlamaSpit>;
        static MAGMA_CUBE: $EntityType<$MagmaCube>;
        static MANGROVE_BOAT: $EntityType<$Boat>;
        static MANGROVE_CHEST_BOAT: $EntityType<$ChestBoat>;
        static MANNEQUIN: $EntityType<$Mannequin>;
        static MARKER: $EntityType<$Marker>;
        static MINECART: $EntityType<$Minecart>;
        static MOOSHROOM: $EntityType<$MushroomCow>;
        static MULE: $EntityType<$Mule>;
        static NAUTILUS: $EntityType<$Nautilus>;
        static OAK_BOAT: $EntityType<$Boat>;
        static OAK_CHEST_BOAT: $EntityType<$ChestBoat>;
        static OCELOT: $EntityType<$Ocelot>;
        static OMINOUS_ITEM_SPAWNER: $EntityType<$OminousItemSpawner>;
        static PAINTING: $EntityType<$Painting>;
        static PALE_OAK_BOAT: $EntityType<$Boat>;
        static PALE_OAK_CHEST_BOAT: $EntityType<$ChestBoat>;
        static PANDA: $EntityType<$Panda>;
        static PARCHED: $EntityType<$Parched>;
        static PARROT: $EntityType<$Parrot>;
        static PHANTOM: $EntityType<$Phantom>;
        static PIG: $EntityType<$Pig>;
        static PIGLIN: $EntityType<$Piglin>;
        static PIGLIN_BRUTE: $EntityType<$PiglinBrute>;
        static PILLAGER: $EntityType<$Pillager>;
        static PLAYER: $EntityType<$Player>;
        static POLAR_BEAR: $EntityType<$PolarBear>;
        static PUFFERFISH: $EntityType<$Pufferfish>;
        static RABBIT: $EntityType<$Rabbit>;
        static RAVAGER: $EntityType<$Ravager>;
        static SALMON: $EntityType<$Salmon>;
        static SHEEP: $EntityType<$Sheep>;
        static SHULKER: $EntityType<$Shulker>;
        static SHULKER_BULLET: $EntityType<$ShulkerBullet>;
        static SILVERFISH: $EntityType<$Silverfish>;
        static SKELETON: $EntityType<$Skeleton>;
        static SKELETON_HORSE: $EntityType<$SkeletonHorse>;
        static SLIME: $EntityType<$Slime>;
        static SMALL_FIREBALL: $EntityType<$SmallFireball>;
        static SNIFFER: $EntityType<$Sniffer>;
        static SNOWBALL: $EntityType<$Snowball>;
        static SNOW_GOLEM: $EntityType<$SnowGolem>;
        static SPAWNER_MINECART: $EntityType<$MinecartSpawner>;
        static SPECTRAL_ARROW: $EntityType<$SpectralArrow>;
        static SPIDER: $EntityType<$Spider>;
        static SPLASH_POTION: $EntityType<$ThrownSplashPotion>;
        static SPRUCE_BOAT: $EntityType<$Boat>;
        static SPRUCE_CHEST_BOAT: $EntityType<$ChestBoat>;
        static SQUID: $EntityType<$Squid>;
        static STRAY: $EntityType<$Stray>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $EntityType<any>>;
        static STRIDER: $EntityType<$Strider>;
        static TADPOLE: $EntityType<$Tadpole>;
        static TEXT_DISPLAY: $EntityType<$Display$TextDisplay>;
        static TNT: $EntityType<$PrimedTnt>;
        static TNT_MINECART: $EntityType<$MinecartTNT>;
        static TRADER_LLAMA: $EntityType<$TraderLlama>;
        static TRIDENT: $EntityType<$ThrownTrident>;
        static TROPICAL_FISH: $EntityType<$TropicalFish>;
        static TURTLE: $EntityType<$Turtle>;
        static VEX: $EntityType<$Vex>;
        static VILLAGER: $EntityType<$Villager>;
        static VINDICATOR: $EntityType<$Vindicator>;
        static WANDERING_TRADER: $EntityType<$WanderingTrader>;
        static WARDEN: $EntityType<$Warden>;
        static WIND_CHARGE: $EntityType<$WindCharge>;
        static WITCH: $EntityType<$Witch>;
        static WITHER: $EntityType<$WitherBoss>;
        static WITHER_SKELETON: $EntityType<$WitherSkeleton>;
        static WITHER_SKULL: $EntityType<$WitherSkull>;
        static WOLF: $EntityType<$Wolf>;
        static ZOGLIN: $EntityType<$Zoglin>;
        static ZOMBIE: $EntityType<$Zombie>;
        static ZOMBIE_HORSE: $EntityType<$ZombieHorse>;
        static ZOMBIE_NAUTILUS: $EntityType<$ZombieNautilus>;
        static ZOMBIE_VILLAGER: $EntityType<$ZombieVillager>;
        static ZOMBIFIED_PIGLIN: $EntityType<$ZombifiedPiglin>;
        get baseClass(): $Class<$Entity>;
        getBaseClass(): $Class<$Entity>;
        get category(): $MobCategory;
        getCategory(): $MobCategory;
        get defaultLootTable(): $Optional<$ResourceKey<$LootTable>>;
        getDefaultLootTable(): $Optional<$ResourceKey<$LootTable>>;
        get descriptionId(): string;
        getDescriptionId(): string;
        get description(): $Component;
        getDescription(): $Component;
        get dimensions(): $EntityDimensions;
        getDimensions(): $EntityDimensions;
        get height(): number;
        getHeight(): number;
        get width(): number;
        getWidth(): number;
        get allowedInPeaceful(): boolean;
        isAllowedInPeaceful(): boolean;
        static appendComponentsConfig<T>(initialConfig: $Consumer<T>, itemStack: $ItemStack_): $Consumer<T>;
        static appendCustomEntityStackConfig<T>(initialConfig: $Consumer<T>, level: $Level, itemStack: $ItemStack_, user: $LivingEntity): $Consumer<T>;
        static appendDefaultStackConfig<T>(initialConfig: $Consumer<T>, level: $Level, itemStack: $ItemStack_, user: $LivingEntity): $Consumer<T>;
        static byString(id: string): $Optional<$EntityType<any>>;
        static by(input: $ValueInput): $Optional<$EntityType<any>>;
        static createDefaultStackConfig<T>(level: $Level, itemStack: $ItemStack_, user: $LivingEntity): $Consumer<T>;
        static create(type: $EntityType<any>, input: $ValueInput, level: $Level, reason: $EntitySpawnReason_): $Optional<$Entity>;
        static create(input: $ValueInput, level: $Level, reason: $EntitySpawnReason_): $Optional<$Entity>;
        static getKey(type: $EntityType<any>): $Identifier;
        static loadEntitiesRecursive(entities: $ValueInput$ValueInputList, level: $Level, reason: $EntitySpawnReason_): $Stream<$Entity>;
        static loadEntityRecursive(tag: $CompoundTag_, level: $Level, reason: $EntitySpawnReason_, postLoad: $EntityProcessor): $Entity;
        static loadEntityRecursive(type: $EntityType<any>, tag: $CompoundTag_, level: $Level, reason: $EntitySpawnReason_, postLoad: $EntityProcessor): $Entity;
        static loadEntityRecursive(type: $EntityType<any>, input: $ValueInput, level: $Level, reason: $EntitySpawnReason_, postLoad: $EntityProcessor): $Entity;
        static loadEntityRecursive(input: $ValueInput, level: $Level, reason: $EntitySpawnReason_, postLoad: $EntityProcessor): $Entity;
        static updateCustomEntityTag(level: $Level, user: $LivingEntity, entity: $Entity, entityData: $TypedEntityData<$EntityType<any>>): void;
        builtInRegistryHolder(): $Holder$Reference<$EntityType<any>>;
        canSerialize(): boolean;
        canSpawnFarFromPlayer(): boolean;
        canSummon(): boolean;
        clientTrackingRange(): number;
        create(level: $ServerLevel, postSpawnConfig: $Consumer<T>, spawnPos: $BlockPos_, spawnReason: $EntitySpawnReason_, tryMoveDown: boolean, movedUp: boolean): T;
        create(level: $Level, reason: $EntitySpawnReason_): T;
        fabric_setAlwaysUpdateVelocity(arg0: boolean): void;
        fabric_setCanPotentiallyExecuteCommands(arg0: boolean): void;
        fireImmune(): boolean;
        getSpawnAABB(x: number, y: number, z: number): $AABB;
        handler$zij000$fabric-object-builder-api-v1$onAlwaysUpdateVelocity(arg0: $CallbackInfoReturnable): void;
        handler$zij000$fabric-object-builder-api-v1$onCanPotentiallyExecuteCommands(arg0: $CallbackInfoReturnable): void;
        isBlockDangerous(state: $BlockState_): boolean;
        onlyOpCanSetNbt(): boolean;
        requiredFeatures(): $FeatureFlagSet;
        spawn(level: $ServerLevel, postSpawnConfig: $Consumer<T>, spawnPos: $BlockPos_, spawnReason: $EntitySpawnReason_, tryMoveDown: boolean, movedUp: boolean): T;
        spawn(level: $ServerLevel, spawnPos: $BlockPos_, spawnReason: $EntitySpawnReason_): T;
        spawn(level: $ServerLevel, itemStack: $ItemStack_, user: $LivingEntity, spawnPos: $BlockPos_, spawnReason: $EntitySpawnReason_, tryMoveDown: boolean, movedUp: boolean): T;
        toShortString(): string;
        toString(): string;
        trackDeltas(): boolean;
        tryCast(entity: $Entity): T;
        updateInterval(): number;
    }

    export interface $EntityType$EntityFactory<T extends $Entity> {
        create(entityType: $EntityType<T>, level: $Level): T;
    }

    export class $EquipmentSlot {
        static BODY: $EquipmentSlot;
        static CHEST: $EquipmentSlot;
        static FEET: $EquipmentSlot;
        static HEAD: $EquipmentSlot;
        static LEGS: $EquipmentSlot;
        static MAINHAND: $EquipmentSlot;
        static OFFHAND: $EquipmentSlot;
        static SADDLE: $EquipmentSlot;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EquipmentSlot[];
        static valueOf(name: string): $EquipmentSlot;
    }

    export class $EquipmentSlot$Type {
        static ANIMAL_ARMOR: $EquipmentSlot$Type;
        static HAND: $EquipmentSlot$Type;
        static HUMANOID_ARMOR: $EquipmentSlot$Type;
        static SADDLE: $EquipmentSlot$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EquipmentSlot$Type[];
        static valueOf(name: string): $EquipmentSlot$Type;
    }

    export class $EquipmentSlotGroup {
        static ANY: $EquipmentSlotGroup;
        static ARMOR: $EquipmentSlotGroup;
        static BODY: $EquipmentSlotGroup;
        static CHEST: $EquipmentSlotGroup;
        static FEET: $EquipmentSlotGroup;
        static HAND: $EquipmentSlotGroup;
        static HEAD: $EquipmentSlotGroup;
        static LEGS: $EquipmentSlotGroup;
        static MAINHAND: $EquipmentSlotGroup;
        static OFFHAND: $EquipmentSlotGroup;
        static SADDLE: $EquipmentSlotGroup;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EquipmentSlotGroup[];
        static valueOf(name: string): $EquipmentSlotGroup;
    }

    export class $EquipmentTable extends $Record {
        constructor(lootTable: $ResourceKey<$LootTable>, dropChance: number);
        constructor(lootTable: $ResourceKey<$LootTable>, slotDropChances: { [key: $EquipmentSlot_]: number });
        static CODEC: $Codec<$EquipmentTable>;
        static DROP_CHANCES_CODEC: $Codec<$Map<$EquipmentSlot, number>>;
        equals(o: object): boolean;
        hashCode(): number;
        lootTable(): $ResourceKey<$LootTable>;
        slotDropChances(): $Map<$EquipmentSlot, number>;
        toString(): string;
    }

    export interface $EquipmentUser {
        equip(lootTable: $ResourceKey<$LootTable>, lootParams: $LootParams, dropChances: { [key: $EquipmentSlot_]: number }): void;
        equip(lootTable: $ResourceKey<$LootTable>, lootParams: $LootParams, optionalLootTableSeed: number, dropChances: { [key: $EquipmentSlot_]: number }): void;
        equip(equipment: $EquipmentTable, lootParams: $LootParams): void;
        getItemBySlot(slot: $EquipmentSlot_): $ItemStack;
        resolveSlot(toEquip: $ItemStack_, alreadyInsertedIntoSlots: $EquipmentSlot_[]): $EquipmentSlot;
        setDropChance(slot: $EquipmentSlot_, dropChance: number): void;
        setItemSlot(slot: $EquipmentSlot_, stack: $ItemStack_): void;
    }

    export class $ExperienceOrb extends $Entity {
        constructor(type: $EntityType<$ExperienceOrb>, level: $Level);
        constructor(level: $Level, x: number, y: number, z: number, value: number);
        constructor(level: $Level, pos: $Vec3_, roughly: $Vec3_, value: number);
        get blockPosBelowThatAffectsMyMovement(): $BlockPos;
        getBlockPosBelowThatAffectsMyMovement(): $BlockPos;
        get icon(): number;
        getIcon(): number;
        get interpolation(): $InterpolationHandler;
        getInterpolation(): $InterpolationHandler;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get value(): number;
        getValue(): number;
        get attackable(): boolean;
        isAttackable(): boolean;
        static awardWithDirection(level: $ServerLevel, pos: $Vec3_, roughDirection: $Vec3_, amount: number): void;
        static award(level: $ServerLevel, pos: $Vec3_, amount: number): void;
        static getExperienceValue(maxValue: number): number;
        hurtClient(source: $DamageSource): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        playerTouch(player: $Player): void;
        tick(): void;
    }

    export interface $HasCustomInventoryScreen {
        openCustomInventoryScreen(player: $Player): void;
    }

    export class $HumanoidArm {
        static LEFT: $HumanoidArm;
        static RIGHT: $HumanoidArm;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $HumanoidArm[];
        static valueOf(name: string): $HumanoidArm;
    }

    export interface $InsideBlockEffectApplier {
        apply(type: $InsideBlockEffectType_): void;
        runAfter(type: $InsideBlockEffectType_, effect: $Consumer<$Entity>): void;
        runBefore(type: $InsideBlockEffectType_, effect: $Consumer<$Entity>): void;
        static NOOP: $InsideBlockEffectApplier;
    }

    export class $InsideBlockEffectType {
        static CLEAR_FREEZE: $InsideBlockEffectType;
        static EXTINGUISH: $InsideBlockEffectType;
        static FIRE_IGNITE: $InsideBlockEffectType;
        static FREEZE: $InsideBlockEffectType;
        static LAVA_IGNITE: $InsideBlockEffectType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $InsideBlockEffectType[];
        static valueOf(name: string): $InsideBlockEffectType;
    }

    export class $Interaction extends $Entity implements $Attackable, $Targeting {
        constructor(type: $EntityType<any>, level: $Level);
        get height(): number;
        getHeight(): number;
        set height(value: number);
        get lastAttacker(): $LivingEntity;
        getLastAttacker(): $LivingEntity;
        get pistonPushReaction(): $PushReaction;
        getPistonPushReaction(): $PushReaction;
        get response(): boolean;
        getResponse(): boolean;
        set response(value: boolean);
        get target(): $LivingEntity;
        getTarget(): $LivingEntity;
        get width(): number;
        getWidth(): number;
        set width(value: number);
        get ignoringBlockTriggers(): boolean;
        isIgnoringBlockTriggers(): boolean;
        get pickable(): boolean;
        isPickable(): boolean;
        canBeHitByProjectile(): boolean;
        getDimensions(pose: $Pose_): $EntityDimensions;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        skipAttackInteraction(source: $Entity): boolean;
        tick(): void;
    }

    export class $InterpolationHandler {
        constructor(entity: $Entity);
        constructor(entity: $Entity, interpolationSteps: number);
        constructor(entity: $Entity, interpolationSteps: number, onInterpolationStart: $Consumer<$InterpolationHandler>);
        constructor(entity: $Entity, onInterpolationStart: $Consumer<$InterpolationHandler>);
        static DEFAULT_INTERPOLATION_STEPS: number;
        cancel(): void;
        hasActiveInterpolation(): boolean;
        interpolateTo(position: $Vec3_, yRot: number, xRot: number): void;
        interpolate(): void;
        position(): $Vec3;
        xRot(): number;
        yRot(): number;
    }

    export interface $ItemOwner {
        asLivingEntity(): $LivingEntity;
        getVisualRotationYInDegrees(): number;
        level(): $Level;
        offsetFromOwner(owner: $ItemOwner, offset: $Vec3_): $ItemOwner;
        position(): $Vec3;
    }

    export interface $ItemSteerable {
        boost(): boolean;
    }

    export interface $Leashable {
        angularFriction<E>(entity: E): number;
        canBeLeashed(): boolean;
        canHaveALeashAttachedTo(entity: $Entity): boolean;
        checkElasticInteractions(leashHolder: $Entity, leashData: $Leashable$LeashData): boolean;
        closeRangeLeashBehaviour(leashHolder: $Entity): void;
        createQuadLeashOffsets(entity: $Entity, frontOffset: number, frontBack: number, leftRight: number, height: number): $Vec3[];
        dropLeash(): void;
        getLeashData(): $Leashable$LeashData;
        getLeashHolder(): $Entity;
        getLeashOffset(partialTicks: number): $Vec3;
        getLeashOffset(): $Vec3;
        getQuadLeashOffsets(): $Vec3[];
        isLeashed(): boolean;
        leashDistanceTo(entity: $Entity): number;
        leashElasticDistance(): number;
        leashSnapDistance(): number;
        leashTooFarBehaviour(): void;
        leashableInArea(entity: $Entity, test: $Predicate<$Leashable>): $List<$Leashable>;
        leashableInArea(level: $Level, pos: $Vec3_, test: $Predicate<$Leashable>): $List<$Leashable>;
        leashableLeashedTo(entity: $Entity): $List<$Leashable>;
        mayBeLeashed(): boolean;
        onElasticLeashPull(): void;
        onLeashRemoved(): void;
        readLeashData(input: $ValueInput): void;
        removeLeash(): void;
        setDelayedLeashHolderId(entityId: number): void;
        setLeashData(leashData: $Leashable$LeashData): void;
        setLeashedTo(holder: $Entity, synch: boolean): void;
        supportQuadLeash(): boolean;
        tickLeash<E>(level: $ServerLevel, entity: E): void;
        whenLeashedTo(leashHolder: $Entity): void;
        writeLeashData(output: $ValueOutput, leashData: $Leashable$LeashData): void;
        static AXIS_SPECIFIC_ELASTICITY: $Vec3;
        static ENTITY_ATTACHMENT_POINT: $List<$Vec3>;
        static LEASHER_ATTACHMENT_POINT: $List<$Vec3>;
        static LEASH_ELASTIC_DIST: number;
        static LEASH_TAG: string;
        static LEASH_TOO_FAR_DIST: number;
        static MAXIMUM_ALLOWED_LEASHED_DIST: number;
        static SHARED_QUAD_ATTACHMENT_POINTS: $List<$Vec3>;
        static SPRING_DAMPENING: number;
        static STIFFNESS: number;
        static TORSIONAL_ELASTICITY: number;
    }

    export class $Leashable$LeashData {
        static CODEC: $Codec<$Leashable$LeashData>;
        angularMomentum: number;
        delayedLeashInfo: $Either<$UUID, $BlockPos>;
        leashHolder: $Entity;
    }

    export class $LightningBolt extends $Entity {
        constructor(type: $EntityType<$LightningBolt>, level: $Level);
        seed: number;
        get blocksSetOnFire(): number;
        getBlocksSetOnFire(): number;
        get cause(): $ServerPlayer;
        getCause(): $ServerPlayer;
        set cause(value: $ServerPlayer);
        get hitEntities(): $Stream<$Entity>;
        getHitEntities(): $Stream<$Entity>;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        shouldRenderAtSqrDistance(distance: number): boolean;
        tick(): void;
    }

    export class $LivingEntity extends $Entity implements $Attackable, $WaypointTransmitter, $LivingEntityAccessor, $LivingEntityExtension, $MixinLivingEntity {
        static ARMOR_SLOT_OFFSET: number;
        static BASE_JUMP_POWER: number;
        static BODY_ARMOR_OFFSET: number;
        static DEATH_DURATION: number;
        static DEFAULT_BABY_SCALE: number;
        static DEFAULT_BASE_GRAVITY: number;
        static EQUIPMENT_SLOT_OFFSET: number;
        static EXTRA_RENDER_CULLING_SIZE_WITH_BIG_HAT: number;
        static MIN_MOVEMENT_DISTANCE: number;
        static PLAYER_HURT_EXPERIENCE_TIME: number;
        static PLAYER_NOT_WEARING_DISGUISE_ITEM: $Predicate<$LivingEntity>;
        static SADDLE_OFFSET: number;
        static TAG_ATTRIBUTES: string;
        static TAG_BRAIN: string;
        static TAG_DEATH_TIME: string;
        static TAG_EQUIPMENT: string;
        static TAG_FALL_FLYING: string;
        static TAG_HEALTH: string;
        static TAG_HURT_BY_TIMESTAMP: string;
        static TAG_HURT_TIME: string;
        static TAG_SLEEPING_POS: string;
        attackAnim: number;
        currentExplosionCause: $Entity;
        currentImpulseImpactPos: $Vec3;
        deathTime: number;
        elytraAnimationState: $ElytraAnimationState;
        hurtDuration: number;
        hurtTime: number;
        oAttackAnim: number;
        removeArrowTime: number;
        removeStingerTime: number;
        swingTime: number;
        swinging: boolean;
        swingingArm: $InteractionHand;
        walkAnimation: $WalkAnimationState;
        xxa: number;
        yBodyRot: number;
        yBodyRotO: number;
        yHeadRot: number;
        yHeadRotO: number;
        yya: number;
        zza: number;
        get absorptionAmount(): number;
        getAbsorptionAmount(): number;
        set absorptionAmount(value: number);
        get activeEffectsMap(): $Map<$Holder<$MobEffect>, $MobEffectInstance>;
        getActiveEffectsMap(): $Map<$Holder<$MobEffect>, $MobEffectInstance>;
        get activeEffects(): $Collection<$MobEffectInstance>;
        getActiveEffects(): $Collection<$MobEffectInstance>;
        get activeItem(): $ItemStack;
        getActiveItem(): $ItemStack;
        get ageScale(): number;
        getAgeScale(): number;
        get armorCoverPercentage(): number;
        getArmorCoverPercentage(): number;
        get armorValue(): number;
        getArmorValue(): number;
        get arrowCount(): number;
        getArrowCount(): number;
        set arrowCount(value: number);
        get attributes(): $AttributeMap;
        getAttributes(): $AttributeMap;
        get bedOrientation(): $Direction;
        getBedOrientation(): $Direction;
        get brain(): $Brain<$LivingEntity>;
        getBrain(): $Brain<$LivingEntity>;
        get combatTracker(): $CombatTracker;
        getCombatTracker(): $CombatTracker;
        get dismountPoses(): $ImmutableList<$Pose>;
        getDismountPoses(): $ImmutableList<$Pose>;
        get fallFlyingTicks(): number;
        getFallFlyingTicks(): number;
        get fallSounds(): $LivingEntity$Fallsounds;
        getFallSounds(): $LivingEntity$Fallsounds;
        get health(): number;
        getHealth(): number;
        set health(value: number);
        get hurtDir(): number;
        getHurtDir(): number;
        get interpolation(): $InterpolationHandler;
        getInterpolation(): $InterpolationHandler;
        get itemBlockingWith(): $ItemStack;
        getItemBlockingWith(): $ItemStack;
        get jumpBoostPower(): number;
        getJumpBoostPower(): number;
        get killCredit(): $LivingEntity;
        getKillCredit(): $LivingEntity;
        get lastAttacker(): $LivingEntity;
        getLastAttacker(): $LivingEntity;
        get lastClimbablePos(): $Optional<$BlockPos>;
        getLastClimbablePos(): $Optional<$BlockPos>;
        get lastDamageSource(): $DamageSource;
        getLastDamageSource(): $DamageSource;
        get lastHurtByMobTimestamp(): number;
        getLastHurtByMobTimestamp(): number;
        get lastHurtByMob(): $LivingEntity;
        getLastHurtByMob(): $LivingEntity;
        set lastHurtByMob(value: $LivingEntity);
        get lastHurtByPlayerMemoryTime(): number;
        getLastHurtByPlayerMemoryTime(): number;
        get lastHurtByPlayer(): $Player;
        getLastHurtByPlayer(): $Player;
        get lastHurtMobTimestamp(): number;
        getLastHurtMobTimestamp(): number;
        get lastHurtMob(): $LivingEntity;
        getLastHurtMob(): $LivingEntity;
        set lastHurtMob(value: $Entity);
        get liquidCollisionShape(): $VoxelShape;
        getLiquidCollisionShape(): $VoxelShape;
        get lootTableSeed(): number;
        getLootTableSeed(): number;
        get luck(): number;
        getLuck(): number;
        get mainArm(): $HumanoidArm;
        getMainArm(): $HumanoidArm;
        get mainHandItem(): $ItemStack;
        getMainHandItem(): $ItemStack;
        get maxAbsorption(): number;
        getMaxAbsorption(): number;
        get maxFallDistance(): number;
        getMaxFallDistance(): number;
        get maxHealth(): number;
        getMaxHealth(): number;
        get noActionTime(): number;
        getNoActionTime(): number;
        set noActionTime(value: number);
        get offhandItem(): $ItemStack;
        getOffhandItem(): $ItemStack;
        get scale(): number;
        getScale(): number;
        get secondsToDisableBlocking(): number;
        getSecondsToDisableBlocking(): number;
        get sleepingPos(): $Optional<$BlockPos>;
        getSleepingPos(): $Optional<$BlockPos>;
        set sleepingPos(value: $BlockPos_);
        get speed(): number;
        getSpeed(): number;
        set speed(value: number);
        get stingerCount(): number;
        getStingerCount(): number;
        set stingerCount(value: number);
        get ticksUsingItem(): number;
        getTicksUsingItem(): number;
        get useItemRemainingTicks(): number;
        getUseItemRemainingTicks(): number;
        get useItem(): $ItemStack;
        getUseItem(): $ItemStack;
        get usedItemHand(): $InteractionHand;
        getUsedItemHand(): $InteractionHand;
        get visualRotationYInDegrees(): number;
        getVisualRotationYInDegrees(): number;
        get voicePitch(): number;
        getVoicePitch(): number;
        get weaponItem(): $ItemStack;
        getWeaponItem(): $ItemStack;
        get yHeadRot(): number;
        getYHeadRot(): number;
        set yHeadRot(value: number);
        get affectedByFluids(): boolean;
        isAffectedByFluids(): boolean;
        get affectedByPotions(): boolean;
        isAffectedByPotions(): boolean;
        get alive(): boolean;
        isAlive(): boolean;
        get autoSpinAttack(): boolean;
        isAutoSpinAttack(): boolean;
        get baby(): boolean;
        isBaby(): boolean;
        get blocking(): boolean;
        isBlocking(): boolean;
        get currentlyGlowing(): boolean;
        isCurrentlyGlowing(): boolean;
        get deadOrDying(): boolean;
        isDeadOrDying(): boolean;
        get fallFlying(): boolean;
        isFallFlying(): boolean;
        get ignoringFallDamageFromCurrentImpulse(): boolean;
        isIgnoringFallDamageFromCurrentImpulse(): boolean;
        get inPostImpulseGraceTime(): boolean;
        isInPostImpulseGraceTime(): boolean;
        get inWall(): boolean;
        isInWall(): boolean;
        get invertedHealAndHarm(): boolean;
        isInvertedHealAndHarm(): boolean;
        get jumping(): boolean;
        isJumping(): boolean;
        set jumping(value: boolean);
        get pickable(): boolean;
        isPickable(): boolean;
        get pushable(): boolean;
        isPushable(): boolean;
        get sensitiveToWater(): boolean;
        isSensitiveToWater(): boolean;
        get sleeping(): boolean;
        isSleeping(): boolean;
        get suppressingSlidingDownLadder(): boolean;
        isSuppressingSlidingDownLadder(): boolean;
        get transmittingWaypoint(): boolean;
        isTransmittingWaypoint(): boolean;
        get usingItem(): boolean;
        isUsingItem(): boolean;
        get visuallySwimming(): boolean;
        isVisuallySwimming(): boolean;
        static areAllEffectsAmbient(effects: $MobEffectInstance[]): boolean;
        static canGlideUsing(itemStack: $ItemStack_, slot: $EquipmentSlot_): boolean;
        static createLivingAttributes(): $AttributeSupplier$Builder;
        static resetForwardDirectionOfRelativePortalPosition(offsets: $Vec3_): $Vec3;
        activeLocationDependentEnchantments(slot: $EquipmentSlot_): $Map<$Enchantment, $Set<$EnchantmentLocationBasedEffect>>;
        addEffect(newEffect: $MobEffectInstance, source: $Entity): boolean;
        addEffect(newEffect: $MobEffectInstance): boolean;
        aiStep(): void;
        animateHurt(yaw: number): void;
        applyItemBlocking(level: $ServerLevel, source: $DamageSource, damage: number): number;
        applyPostImpulseGraceTime(ticks: number): void;
        asLivingEntity(): $LivingEntity;
        attackable(): boolean;
        baseTick(): void;
        calculateEntityAnimation(useY: boolean): void;
        canAttack(target: $LivingEntity): boolean;
        canBeAffected(newEffect: $MobEffectInstance): boolean;
        canBeSeenAsEnemy(): boolean;
        canBeSeenByAnyone(): boolean;
        canBreatheUnderwater(): boolean;
        canEquipWithDispenser(itemStack: $ItemStack_): boolean;
        canFreeze(): boolean;
        canPickUpLoot(): boolean;
        canStandOnFluid(fluid: $FluidState): boolean;
        canUsePortal(ignorePassenger: boolean): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        causeExtraKnockback(target: $Entity, knockback: number, oldMovement: $Vec3_): void;
        causeFallDamage(fallDistance: number, damageModifier: number, damageSource: $DamageSource): boolean;
        clearSleepingPos(): void;
        die(source: $DamageSource): void;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        dropFromEntityInteractLootTable(level: $ServerLevel, key: $ResourceKey<$LootTable>, interactingEntity: $Entity, tool: $ItemInstance, consumer: $BiConsumer<$ServerLevel, $ItemStack_>): boolean;
        dropFromGiftLootTable(level: $ServerLevel, key: $ResourceKey<$LootTable>, consumer: $BiConsumer<$ServerLevel, $ItemStack_>): boolean;
        dropFromLootTable(level: $ServerLevel, source: $DamageSource, playerKilled: boolean, lootTable: $ResourceKey<$LootTable>, itemStackConsumer: $Consumer<$ItemStack_>): void;
        dropFromLootTable(level: $ServerLevel, source: $DamageSource, playerKilled: boolean, lootTable: $ResourceKey<$LootTable>): void;
        drop(itemStack: $ItemStack_, randomly: boolean, thrownFromHand: boolean): $ItemEntity;
        equipmentHasChanged(previous: $ItemStack_, current: $ItemStack_): boolean;
        forceAddEffect(newEffect: $MobEffectInstance, source: $Entity): void;
        getAttackAnim(a: number): number;
        getAttackRangeWith(weaponItem: $ItemStack_): $AttackRange;
        getAttributeBaseValue(attribute: $Holder<$Attribute_>): number;
        getAttributeValue(attribute: $Holder<$Attribute_>): number;
        getAttribute(attribute: $Holder<$Attribute_>): $AttributeInstance;
        getDimensions(pose: $Pose_): $EntityDimensions;
        getEffectBlendFactor(effect: $Holder<$MobEffect_>, partialTicks: number): number;
        getEffect(effect: $Holder<$MobEffect_>): $MobEffectInstance;
        getEquipmentSlotForItem(itemStack: $ItemStack_): $EquipmentSlot;
        getExperienceReward(level: $ServerLevel, killer: $Entity): number;
        getFluidFallingAdjustedMovement(baseGravity: number, isFalling: boolean, movement: $Vec3_): $Vec3;
        getItemBySlot(slot: $EquipmentSlot_): $ItemStack;
        getItemHeldByArm(arm: $HumanoidArm_): $ItemStack;
        getItemInHand(hand: $InteractionHand_): $ItemStack;
        getLocalBoundsForPose(pose: $Pose_): $AABB;
        getPassengerRidingPosition(passenger: $Entity): $Vec3;
        getPreciseBodyRotation(partial: number): number;
        getProjectile(heldWeapon: $ItemStack_): $ItemStack;
        getRelativePortalPosition(axis: $Direction$Axis_, portalArea: $BlockUtil$FoundRectangle): $Vec3;
        getSlot(slot: number): $SlotAccess;
        getSwimAmount(a: number): number;
        getTicksSinceLastKineticHitFeedback(partial: number): number;
        getTicksUsingItem(partialTicks: number): number;
        getViewYRot(a: number): number;
        getVisibilityPercent(targetingEntity: $Entity): number;
        handleDamageEvent(source: $DamageSource): void;
        handleEntityEvent(id: number): void;
        handleExtraItemsCreatedOnUse(extraCreatedRemainder: $ItemStack_): void;
        hasEffect(effect: $Holder<$MobEffect_>): boolean;
        hasInfiniteMaterials(): boolean;
        hasItemInSlot(slot: $EquipmentSlot_): boolean;
        hasLandedInLiquid(): boolean;
        hasLineOfSight(target: $Entity, blockCollidingContext: $ClipContext$Block_, fluidCollidingContext: $ClipContext$Fluid_, eyeHeight: number): boolean;
        hasLineOfSight(target: $Entity): boolean;
        heal(heal: number): void;
        hurtArmor(damageSource: $DamageSource, damage: number): void;
        hurtHelmet(damageSource: $DamageSource, damage: number): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        igniteForTicks(numberOfTicks: number): void;
        indicateDamage(xd: number, zd: number): void;
        isEquippableInSlot(itemStack: $ItemStack_, slot: $EquipmentSlot_): boolean;
        isHolding(itemPredicate: $Predicate<$ItemStack_>): boolean;
        isHolding(item: $Item_): boolean;
        isInvulnerableTo(level: $ServerLevel, source: $DamageSource): boolean;
        isLookingAtMe(target: $LivingEntity, coneSize: number, adjustForDistance: boolean, seeThroughTransparentBlocks: boolean, gazeHeights?: number[]): boolean;
        jumpFromGround(): void;
        kill(level: $ServerLevel): void;
        knockback(power: number, xd: number, zd: number): void;
        lerpHeadTo(yRot: number, steps: number): void;
        lookAt(anchor: $EntityAnchorArgument$Anchor_, pos: $Vec3_): void;
        makePoofParticles(): void;
        makeSound(sound: $SoundEvent_): void;
        makeWaypointConnectionWith(player: $ServerPlayer): $Optional<$WaypointTransmitter$Connection>;
        maxUpStep(): number;
        onAttack(): void;
        onClimbable(): boolean;
        onEnterCombat(): void;
        onEquipItem(slot: $EquipmentSlot_, oldStack: $ItemStack_, stack: $ItemStack_): void;
        onEquippedItemBroken(brokenItem: $Item_, inSlot: $EquipmentSlot_): void;
        onItemPickup(entity: $ItemEntity): void;
        onLeaveCombat(): void;
        onRemoval(reason: $Entity$RemovalReason_): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        postPiercingAttack(): void;
        push(entity: $Entity): void;
        randomTeleport(xx: number, yy: number, zz: number, showParticles: boolean): boolean;
        recreateFromPacket(packet: $ClientboundAddEntityPacket): void;
        releaseUsingItem(): void;
        rememberStabbedEntity(target: $Entity): void;
        removeAllEffects(): boolean;
        removeEffectNoUpdate(effect: $Holder<$MobEffect_>): $MobEffectInstance;
        removeEffect(effect: $Holder<$MobEffect_>): boolean;
        remove(reason: $Entity$RemovalReason_): void;
        resetCurrentImpulseContext(): void;
        rideTick(): void;
        sendEffectToPassengers(effect: $MobEffectInstance): void;
        setIgnoreFallDamageFromCurrentImpulse(ignoreFallDamage: boolean, newImpulseImpactPos: $Vec3_): void;
        setItemInHand(hand: $InteractionHand_, itemStack: $ItemStack_): void;
        setItemSlot(slot: $EquipmentSlot_, itemStack: $ItemStack_): void;
        setLastHurtByPlayer(player: string, timeToRemember: number): void;
        setLastHurtByPlayer(player: $Player, timeToRemember: number): void;
        setRecordPlayingNearby(jukebox: $BlockPos_, isPlaying: boolean): void;
        shouldDiscardFriction(): boolean;
        shouldDropExperience(): boolean;
        shouldShowName(): boolean;
        skipDropExperience(): void;
        spawnItemParticles(itemStack: $ItemStack_, count: number): void;
        stabAttack(weaponSlot: $EquipmentSlot_, target: $Entity, baseDamage: number, dealsDamage: boolean, dealsKnockback: boolean, dismounts: boolean): boolean;
        stabbedEntities(filter: $Predicate<$Entity>): number;
        startSleeping(bedPosition: $BlockPos_): void;
        startUsingItem(hand: $InteractionHand_): void;
        stopFallFlying(): void;
        stopRiding(): void;
        stopSleeping(): void;
        stopUsingItem(): void;
        swing(hand: $InteractionHand_, sendToSwingingEntity: boolean): void;
        swing(hand: $InteractionHand_): void;
        take(entity: $Entity, orgCount: number): void;
        tick(): void;
        travel(input: $Vec3_): void;
        tryResetCurrentImpulseContext(): void;
        updateDataBeforeSync(): void;
        wasExperienceConsumed(): boolean;
        wasRecentlyStabbed(target: $Entity, allowedTime: number): boolean;
        waypointIcon(): $Waypoint$Icon;
    }

    export class $LivingEntity$Fallsounds extends $Record {
        constructor(small: $SoundEvent_, big: $SoundEvent_);
        big(): $SoundEvent;
        equals(o: object): boolean;
        hashCode(): number;
        small(): $SoundEvent;
        toString(): string;
    }

    export class $Marker extends $Entity {
        constructor(type: $EntityType<any>, level: $Level);
        get pistonPushReaction(): $PushReaction;
        getPistonPushReaction(): $PushReaction;
        get ignoringBlockTriggers(): boolean;
        isIgnoringBlockTriggers(): boolean;
        getAddEntityPacket(serverEntity: $ServerEntity): $Packet<$ClientGamePacketListener>;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        tick(): void;
    }

    export class $Mob extends $LivingEntity implements $Targeting, $EquipmentUser, $Leashable {
        static MAX_ENCHANTED_ARMOR_CHANCE: number;
        static MAX_ENCHANTED_WEAPON_CHANCE: number;
        static MAX_PICKUP_LOOT_CHANCE: number;
        static MAX_WEARING_ARMOR_CHANCE: number;
        static TAG_CAN_PICK_UP_LOOT: string;
        static TAG_DROP_CHANCES: string;
        static TAG_LEFT_HANDED: string;
        static TAG_NO_AI: string;
        static UPDATE_GOAL_SELECTOR_EVERY_N_TICKS: number;
        static WEARING_ARMOR_UPGRADE_MATERIAL_ATTEMPTS: number;
        static WEARING_ARMOR_UPGRADE_MATERIAL_CHANCE: number;
        ambientSoundTime: number;
        goalSelector: $GoalSelector;
        targetSelector: $GoalSelector;
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get bodyArmorItem(): $ItemStack;
        getBodyArmorItem(): $ItemStack;
        set bodyArmorItem(value: $ItemStack_);
        get controllingPassenger(): $LivingEntity;
        getControllingPassenger(): $LivingEntity;
        get dropChances(): $DropChances;
        getDropChances(): $DropChances;
        get headRotSpeed(): number;
        getHeadRotSpeed(): number;
        get homePosition(): $BlockPos;
        getHomePosition(): $BlockPos;
        get homeRadius(): number;
        getHomeRadius(): number;
        get jumpControl(): $JumpControl;
        getJumpControl(): $JumpControl;
        get leashData(): $Leashable$LeashData;
        getLeashData(): $Leashable$LeashData;
        set leashData(value: $Leashable$LeashData);
        get lookControl(): $LookControl;
        getLookControl(): $LookControl;
        get lootTableSeed(): number;
        getLootTableSeed(): number;
        get lootTable(): $Optional<$ResourceKey<$LootTable>>;
        getLootTable(): $Optional<$ResourceKey<$LootTable>>;
        get mainArm(): $HumanoidArm;
        getMainArm(): $HumanoidArm;
        get maxFallDistance(): number;
        getMaxFallDistance(): number;
        get maxHeadXRot(): number;
        getMaxHeadXRot(): number;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get maxSpawnClusterSize(): number;
        getMaxSpawnClusterSize(): number;
        get moveControl(): $MoveControl;
        getMoveControl(): $MoveControl;
        get navigation(): $PathNavigation;
        getNavigation(): $PathNavigation;
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        get preferredWeaponType(): $TagKey<$Item>;
        getPreferredWeaponType(): $TagKey<$Item>;
        get sensing(): $Sensing;
        getSensing(): $Sensing;
        get targetUnchecked(): $LivingEntity;
        getTargetUnchecked(): $LivingEntity;
        get target(): $LivingEntity;
        getTarget(): $LivingEntity;
        set target(value: $LivingEntity);
        get aggressive(): boolean;
        isAggressive(): boolean;
        set aggressive(value: boolean);
        get effectiveAi(): boolean;
        isEffectiveAi(): boolean;
        get leftHanded(): boolean;
        isLeftHanded(): boolean;
        set leftHanded(value: boolean);
        get noAi(): boolean;
        isNoAi(): boolean;
        set noAi(value: boolean);
        get persistenceRequired(): boolean;
        isPersistenceRequired(): boolean;
        get saddled(): boolean;
        isSaddled(): boolean;
        get wearingBodyArmor(): boolean;
        isWearingBodyArmor(): boolean;
        get withinHome(): boolean;
        isWithinHome(): boolean;
        static checkMobSpawnRules(type: $EntityType<$Mob>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createMobAttributes(): $AttributeSupplier$Builder;
        static getEquipmentForSlot(slot: $EquipmentSlot_, type: number): $Item;
        aiStep(): void;
        ate(): void;
        baseTick(): void;
        canAttack(target: $LivingEntity): boolean;
        canBeLeashed(): boolean;
        canHoldItem(itemStack: $ItemStack_): boolean;
        canPickUpLoot(): boolean;
        canReplaceEqualItem(newItemStack: $ItemStack_, currentItemStack: $ItemStack_): boolean;
        canUseNonMeleeWeapon(item: $ItemStack_): boolean;
        chargeSpeedModifier(): number;
        checkDespawn(): void;
        checkSpawnObstruction(level: $LevelReader): boolean;
        checkSpawnRules(level: $LevelAccessor, spawnReason: $EntitySpawnReason_): boolean;
        clearHome(): void;
        convertTo<T>(entityType: $EntityType<T>, params: $ConversionParams, afterConversion: $ConversionParams$AfterConversion<T>): T;
        convertTo<T>(entityType: $EntityType<T>, params: $ConversionParams, spawnReason: $EntitySpawnReason_, afterConversion: $ConversionParams$AfterConversion<T>): T;
        createEquipmentSlotContainer(slot: $EquipmentSlot_): $Container;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        dropPreservedEquipment(level: $ServerLevel, shouldDrop: $Predicate<$ItemStack_>): $Set<$EquipmentSlot>;
        dropPreservedEquipment(level: $ServerLevel): void;
        equipItemIfPossible(level: $ServerLevel, itemStack: $ItemStack_): $ItemStack;
        equip(lootTable: $ResourceKey<$LootTable>, dropChances: { [key: $EquipmentSlot_]: number }): void;
        equip(equipment: $EquipmentTable): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getPathfindingMalus(pathType: $PathType_): number;
        handleEntityEvent(id: number): void;
        hasHome(): boolean;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        isMaxGroupSizeReached(groupSize: number): boolean;
        isWithinHome(pos: $BlockPos_): boolean;
        isWithinHome(pos: $Vec3_): boolean;
        isWithinMeleeAttackRange(target: $LivingEntity): boolean;
        leashTooFarBehaviour(): void;
        lookAt(entity: $Entity, yMax: number, xMax: number): void;
        onLeashRemoved(): void;
        onPathfindingDone(): void;
        onPathfindingStart(): void;
        playAmbientSound(): void;
        registerDebugValues(level: $ServerLevel, registration: $DebugValueSource$Registration): void;
        removeAllGoals(predicate: $Predicate<$Goal>): void;
        removeFreeWill(): void;
        removeWhenFarAway(distSqr: number): boolean;
        requiresCustomPersistence(): boolean;
        setDropChance(slot: $EquipmentSlot_, percent: number): void;
        setHomeTo(newCenter: $BlockPos_, radius: number): void;
        setPathfindingMalus(pathType: $PathType_, cost: number): void;
        setPersistenceRequired(): void;
        spawnAnim(): void;
        startRiding(entity: $Entity, force: boolean, sendEventAndTriggers: boolean): boolean;
        stopInPlace(): void;
        tick(): void;
        wantsToPickUp(level: $ServerLevel, itemStack: $ItemStack_): boolean;
    }

    export class $MobCategory {
        static AMBIENT: $MobCategory;
        static AXOLOTLS: $MobCategory;
        static CREATURE: $MobCategory;
        static MISC: $MobCategory;
        static MONSTER: $MobCategory;
        static UNDERGROUND_WATER_CREATURE: $MobCategory;
        static WATER_AMBIENT: $MobCategory;
        static WATER_CREATURE: $MobCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MobCategory[];
        static valueOf(name: string): $MobCategory;
    }

    export class $MoverType {
        static PISTON: $MoverType;
        static PLAYER: $MoverType;
        static SELF: $MoverType;
        static SHULKER: $MoverType;
        static SHULKER_BOX: $MoverType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MoverType[];
        static valueOf(name: string): $MoverType;
    }

    export interface $NeutralMob {
        addPersistentAngerSaveData(output: $ValueOutput): void;
        canAttack(target: $LivingEntity): boolean;
        forgetCurrentTargetAndRefreshUniversalAnger(): void;
        getLastHurtByMob(): $LivingEntity;
        getPersistentAngerEndTime(): number;
        getPersistentAngerTarget(): $EntityReference<$LivingEntity>;
        getTargetUnchecked(): $LivingEntity;
        getTarget(): $LivingEntity;
        isAngryAtAllPlayers(level: $ServerLevel): boolean;
        isAngryAt(entity: $LivingEntity, level: $ServerLevel): boolean;
        isAngry(): boolean;
        level(): $Level;
        playerDied(level: $ServerLevel, player: $Player): void;
        readPersistentAngerSaveData(level: $Level, input: $ValueInput): void;
        setLastHurtByMob(hurtBy: $LivingEntity): void;
        setPersistentAngerEndTime(endTime: number): void;
        setPersistentAngerTarget(persistentAngerTarget: $EntityReference<$LivingEntity>): void;
        setTarget(target: $LivingEntity): void;
        setTimeToRemainAngry(remainingTime: number): void;
        startPersistentAngerTimer(): void;
        stopBeingAngry(): void;
        updatePersistentAnger(level: $ServerLevel, stayAngryIfTargetPresent: boolean): void;
        static NO_ANGER_END_TIME: number;
        static TAG_ANGER_END_TIME: string;
        static TAG_ANGRY_AT: string;
    }

    export class $OminousItemSpawner extends $Entity {
        constructor(type: $EntityType<$OminousItemSpawner>, level: $Level);
        static TICKS_BEFORE_ABOUT_TO_SPAWN_SOUND: number;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get pistonPushReaction(): $PushReaction;
        getPistonPushReaction(): $PushReaction;
        get ignoringBlockTriggers(): boolean;
        isIgnoringBlockTriggers(): boolean;
        static create(level: $Level, item: $ItemStack_): $OminousItemSpawner;
        addParticles(): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        tick(): void;
    }

    export interface $OwnableEntity {
        getOwnerReference(): $EntityReference<$LivingEntity>;
        getOwner(): $LivingEntity;
        getRootOwner(): $LivingEntity;
        level(): $Level;
    }

    export class $PathfinderMob extends $Mob {
        get panicking(): boolean;
        isPanicking(): boolean;
        get pathFinding(): boolean;
        isPathFinding(): boolean;
        checkSpawnRules(level: $LevelAccessor, spawnReason: $EntitySpawnReason_): boolean;
        closeRangeLeashBehaviour(leashHolder: $Entity): void;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        getWalkTargetValue(pos: $BlockPos_): number;
        whenLeashedTo(leashHolder: $Entity): void;
    }

    export interface $PlayerRideable {
    }

    export interface $PlayerRideableJumping extends $PlayerRideable {
        canJump(): boolean;
        getJumpCooldown(): number;
        getPlayerJumpPendingScale(jumpAmount: number): number;
        handleStartJump(jumpScale: number): void;
        handleStopJump(): void;
        onPlayerJump(jumpAmount: number): void;
    }

    export class $PortalProcessor {
        constructor(portal: $Portal, portalEntryPosition: $BlockPos_);
        get entryPosition(): $BlockPos;
        getEntryPosition(): $BlockPos;
        get portalLocalTransition(): $Portal$Transition;
        getPortalLocalTransition(): $Portal$Transition;
        get portalTime(): number;
        getPortalTime(): number;
        get insidePortalThisTick(): boolean;
        isInsidePortalThisTick(): boolean;
        getPortalDestination(serverLevel: $ServerLevel, entity: $Entity): $TeleportTransition;
        hasExpired(): boolean;
        isSamePortal(portal: $Portal): boolean;
        processPortalTeleportation(serverLevel: $ServerLevel, entity: $Entity, allowedToTeleport: boolean): boolean;
        updateEntryPosition(entryPosition: $BlockPos_): void;
    }

    export class $Pose {
        static CROAKING: $Pose;
        static CROUCHING: $Pose;
        static DIGGING: $Pose;
        static DYING: $Pose;
        static EMERGING: $Pose;
        static FALL_FLYING: $Pose;
        static INHALING: $Pose;
        static LONG_JUMPING: $Pose;
        static ROARING: $Pose;
        static SHOOTING: $Pose;
        static SITTING: $Pose;
        static SLEEPING: $Pose;
        static SLIDING: $Pose;
        static SNIFFING: $Pose;
        static SPIN_ATTACK: $Pose;
        static STANDING: $Pose;
        static SWIMMING: $Pose;
        static USING_TONGUE: $Pose;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Pose[];
        static valueOf(name: string): $Pose;
    }

    export class $PositionMoveRotation extends $Record {
        constructor(position: $Vec3_, deltaMovement: $Vec3_, yRot: number, xRot: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $PositionMoveRotation>;
        static calculateAbsolute(source: $PositionMoveRotation, change: $PositionMoveRotation, relatives: $Relative_[]): $PositionMoveRotation;
        static of(entity: $Entity): $PositionMoveRotation;
        static of(transition: $TeleportTransition): $PositionMoveRotation;
        deltaMovement(): $Vec3;
        equals(o: object): boolean;
        hashCode(): number;
        position(): $Vec3;
        toString(): string;
        withRotation(yRot: number, xRot: number): $PositionMoveRotation;
        xRot(): number;
        yRot(): number;
    }

    export class $Relative {
        static DELTA_X: $Relative;
        static DELTA_Y: $Relative;
        static DELTA_Z: $Relative;
        static ROTATE_DELTA: $Relative;
        static X: $Relative;
        static X_ROT: $Relative;
        static Y: $Relative;
        static Y_ROT: $Relative;
        static Z: $Relative;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Relative[];
        static valueOf(name: string): $Relative;
    }

    export interface $ReputationEventHandler {
        onReputationEventFrom(type: $ReputationEventType, source: $Entity): void;
    }

    export interface $Shearable {
        readyForShearing(): boolean;
        shear(level: $ServerLevel, soundSource: $SoundSource_, tool: $ItemStack_): void;
    }

    export interface $SlotAccess {
        forEquipmentSlot(entity: $LivingEntity, slot: $EquipmentSlot_, validator: $Predicate<$ItemStack_>): $SlotAccess;
        forEquipmentSlot(entity: $LivingEntity, slot: $EquipmentSlot_): $SlotAccess;
        forListElement(stacks: $ItemStack_[], index: number): $SlotAccess;
        get(): $ItemStack;
        of(getter: $Supplier<$ItemStack_>, setter: $Consumer<$ItemStack_>): $SlotAccess;
        set(itemStack: $ItemStack_): boolean;
    }

    export interface $SlotProvider {
        getSlotsFromRange(slots: $IntList): $SlotCollection;
        getSlot(slot: number): $SlotAccess;
    }

    export interface $SpawnGroupData {
    }

    export interface $SpawnPlacementType {
        adjustSpawnPosition(level: $LevelReader, candidate: $BlockPos_): $BlockPos;
        isSpawnPositionOk(level: $LevelReader, blockPos: $BlockPos_, type: $EntityType<any>): boolean;
    }

    export class $TamableAnimal extends $Animal implements $OwnableEntity {
        static TELEPORT_WHEN_DISTANCE_IS_SQ: number;
        get ownerReference(): $EntityReference<$LivingEntity>;
        getOwnerReference(): $EntityReference<$LivingEntity>;
        set ownerReference(value: $EntityReference<$LivingEntity>);
        get team(): $PlayerTeam;
        getTeam(): $PlayerTeam;
        get inSittingPose(): boolean;
        isInSittingPose(): boolean;
        set inSittingPose(value: boolean);
        get orderedToSit(): boolean;
        isOrderedToSit(): boolean;
        set orderedToSit(value: boolean);
        get tame(): boolean;
        isTame(): boolean;
        canAttack(target: $LivingEntity): boolean;
        canBeLeashed(): boolean;
        die(source: $DamageSource): void;
        handleEntityEvent(id: number): void;
        isOwnedBy(entity: $LivingEntity): boolean;
        setTame(isTame: boolean, includeSideEffects: boolean): void;
        shouldTryTeleportToOwner(): boolean;
        tame(player: $Player): void;
        tryToTeleportToOwner(): void;
        unableToMoveToOwner(): boolean;
        wantsToAttack(target: $LivingEntity, owner: $LivingEntity): boolean;
    }

    export interface $Targeting {
        getTarget(): $LivingEntity;
    }

    export interface $TraceableEntity {
        getOwner(): $Entity;
    }

    export class $WalkAnimationState {
        constructor();
        get moving(): boolean;
        isMoving(): boolean;
        position(partialTicks: number): number;
        position(): number;
        speed(partialTicks: number): number;
        speed(): number;
        stop(): void;
        update(targetSpeed: number, factor: number, positionScale: number): void;
    }

    export type $ConversionType_ = $ConversionType | "SINGLE" | "SPLIT_ON_DEATH";
    export type $Crackiness$Level_ = $Crackiness$Level | "HIGH" | "LOW" | "MEDIUM" | "NONE";
    export type $Display$BillboardConstraints_ = $Display$BillboardConstraints | "CENTER" | "FIXED" | "HORIZONTAL" | "VERTICAL";
    export type $Display$TextDisplay$Align_ = $Display$TextDisplay$Align | "CENTER" | "LEFT" | "RIGHT";
    export type $Entity$RemovalReason_ = $Entity$RemovalReason | "CHANGED_DIMENSION" | "DISCARDED" | "KILLED" | "UNLOADED_TO_CHUNK" | "UNLOADED_WITH_PLAYER";
    export type $EntityAttachment_ = $EntityAttachment | "NAME_TAG" | "PASSENGER" | "VEHICLE" | "WARDEN_CHEST";
    export type $EntitySpawnReason_ = $EntitySpawnReason | "BREEDING" | "BUCKET" | "CHUNK_GENERATION" | "COMMAND" | "CONVERSION" | "DIMENSION_TRAVEL" | "DISPENSER" | "EVENT" | "JOCKEY" | "LOAD" | "MOB_SUMMONED" | "NATURAL" | "PATROL" | "REINFORCEMENT" | "SPAWNER" | "SPAWN_ITEM_USE" | "STRUCTURE" | "TRIAL_SPAWNER" | "TRIGGERED";
    export type $EntityType_ = $EntityType | RegistryTypes.EntityType | $NekoId | string;
    export type $EquipmentSlot_ = $EquipmentSlot | "BODY" | "CHEST" | "FEET" | "HEAD" | "LEGS" | "MAINHAND" | "OFFHAND" | "SADDLE";
    export type $EquipmentSlot$Type_ = $EquipmentSlot$Type | "ANIMAL_ARMOR" | "HAND" | "HUMANOID_ARMOR" | "SADDLE";
    export type $EquipmentSlotGroup_ = $EquipmentSlotGroup | "ANY" | "ARMOR" | "BODY" | "CHEST" | "FEET" | "HAND" | "HEAD" | "LEGS" | "MAINHAND" | "OFFHAND" | "SADDLE";
    export type $HumanoidArm_ = $HumanoidArm | "LEFT" | "RIGHT";
    export type $InsideBlockEffectType_ = $InsideBlockEffectType | "CLEAR_FREEZE" | "EXTINGUISH" | "FIRE_IGNITE" | "FREEZE" | "LAVA_IGNITE";
    export type $MobCategory_ = $MobCategory | "AMBIENT" | "AXOLOTLS" | "CREATURE" | "MISC" | "MONSTER" | "UNDERGROUND_WATER_CREATURE" | "WATER_AMBIENT" | "WATER_CREATURE";
    export type $MoverType_ = $MoverType | "PISTON" | "PLAYER" | "SELF" | "SHULKER" | "SHULKER_BOX";
    export type $Pose_ = $Pose | "CROAKING" | "CROUCHING" | "DIGGING" | "DYING" | "EMERGING" | "FALL_FLYING" | "INHALING" | "LONG_JUMPING" | "ROARING" | "SHOOTING" | "SITTING" | "SLEEPING" | "SLIDING" | "SNIFFING" | "SPIN_ATTACK" | "STANDING" | "SWIMMING" | "USING_TONGUE";
    export type $Relative_ = $Relative | "DELTA_X" | "DELTA_Y" | "DELTA_Z" | "ROTATE_DELTA" | "X" | "X_ROT" | "Y" | "Y_ROT" | "Z";
}
