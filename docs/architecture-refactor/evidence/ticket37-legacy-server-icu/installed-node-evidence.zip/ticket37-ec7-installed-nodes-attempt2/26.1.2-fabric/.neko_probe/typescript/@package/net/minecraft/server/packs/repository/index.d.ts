import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Collection, $List, $Set } from "java:java/util";
import { $Consumer, $Function, $Predicate, $UnaryOperator } from "java:java/util/function";
import { $FabricPack } from "java:net/fabricmc/fabric/impl/resource/pack";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $PackLocationInfo, $PackResources, $PackSelectionConfig, $PackType, $PackType_ } from "java:net/minecraft/server/packs";
import { $PackFormat } from "java:net/minecraft/server/packs/metadata/pack";
import { $InclusiveRange } from "java:net/minecraft/util";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $CallbackInfo } from "java:org/spongepowered/asm/mixin/injection/callback";

declare module "java:net/minecraft/server/packs/repository" {
    export class $KnownPack extends $Record {
        constructor(namespace: string, id: string, version: string);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $KnownPack>;
        static VANILLA_NAMESPACE: string;
        get vanilla(): boolean;
        isVanilla(): boolean;
        static vanilla(id: string): $KnownPack;
        equals(o: object): boolean;
        hashCode(): number;
        id(): string;
        namespace(): string;
        toString(): string;
        version(): string;
    }

    export class $Pack implements $FabricPack {
        constructor(location: $PackLocationInfo, resources: $Pack$ResourcesSupplier, metadata: $Pack$Metadata, selectionConfig: $PackSelectionConfig);
        get compatibility(): $PackCompatibility;
        getCompatibility(): $PackCompatibility;
        get defaultPosition(): $Pack$Position;
        getDefaultPosition(): $Pack$Position;
        get description(): $Component;
        getDescription(): $Component;
        get id(): string;
        getId(): string;
        get packSource(): $PackSource;
        getPackSource(): $PackSource;
        get requestedFeatures(): $FeatureFlagSet;
        getRequestedFeatures(): $FeatureFlagSet;
        get title(): $Component;
        getTitle(): $Component;
        get fixedPosition(): boolean;
        isFixedPosition(): boolean;
        get required(): boolean;
        isRequired(): boolean;
        static readMetaAndCreate(location: $PackLocationInfo, resources: $Pack$ResourcesSupplier, packType: $PackType_, selectionConfig: $PackSelectionConfig): $Pack;
        static readPackMetadata(location: $PackLocationInfo, resources: $Pack$ResourcesSupplier, currentPackVersion: $PackFormat, type: $PackType_): $Pack$Metadata;
        equals(o: object): boolean;
        fabric$isHidden(): boolean;
        fabric$parentsEnabled(arg0: $Set): boolean;
        fabric$setParentsPredicate(arg0: $Predicate): void;
        getChatLink(enabled: boolean): $Component;
        hashCode(): number;
        location(): $PackLocationInfo;
        open(): $PackResources;
        selectionConfig(): $PackSelectionConfig;
    }

    export class $Pack$Metadata extends $Record {
        constructor(description: $Component_, compatibility: $PackCompatibility_, requestedFeatures: $FeatureFlagSet, overlays: string[]);
        compatibility(): $PackCompatibility;
        description(): $Component;
        equals(o: object): boolean;
        hashCode(): number;
        overlays(): $List<string>;
        requestedFeatures(): $FeatureFlagSet;
        toString(): string;
    }

    export class $Pack$Position {
        static BOTTOM: $Pack$Position;
        static TOP: $Pack$Position;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Pack$Position[];
        static valueOf(name: string): $Pack$Position;
    }

    export interface $Pack$ResourcesSupplier {
        openFull(location: $PackLocationInfo, metadata: $Pack$Metadata): $PackResources;
        openPrimary(location: $PackLocationInfo): $PackResources;
    }

    export class $PackCompatibility {
        static COMPATIBLE: $PackCompatibility;
        static TOO_NEW: $PackCompatibility;
        static TOO_OLD: $PackCompatibility;
        static UNKNOWN: $PackCompatibility;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PackCompatibility[];
        static valueOf(name: string): $PackCompatibility;
    }

    export class $PackRepository {
        constructor(sources?: $RepositorySource[]);
        sources: $Set<$RepositorySource>;
        get availableIds(): $Collection<string>;
        getAvailableIds(): $Collection<string>;
        get availablePacks(): $Collection<$Pack>;
        getAvailablePacks(): $Collection<$Pack>;
        get requestedFeatureFlags(): $FeatureFlagSet;
        getRequestedFeatureFlags(): $FeatureFlagSet;
        get selectedIds(): $Collection<string>;
        getSelectedIds(): $Collection<string>;
        get selectedPacks(): $Collection<$Pack>;
        getSelectedPacks(): $Collection<$Pack>;
        get ableToClearAnyPack(): boolean;
        isAbleToClearAnyPack(): boolean;
        static displayPackList(packs: $Pack[]): string;
        addPack(packId: string): boolean;
        getPack(id: string): $Pack;
        handler$zlb000$fabric-resource-loader-v1$construct(arg0: $RepositorySource[], arg1: $CallbackInfo): void;
        isAvailable(id: string): boolean;
        openAllSelected(): $List<$PackResources>;
        reload(): void;
        removePack(packId: string): boolean;
    }

    export interface $PackSource {
        create(decorator: $UnaryOperator<$Component_>, addAutomatically: boolean): $PackSource;
        decorate(packDescription: $Component_): $Component;
        shouldAddAutomatically(): boolean;
        static BUILT_IN: $PackSource;
        static DEFAULT: $PackSource;
        static FEATURE: $PackSource;
        static NO_DECORATION: $UnaryOperator<$Component>;
        static SERVER: $PackSource;
        static WORLD: $PackSource;
    }

    export interface $RepositorySource {
        loadPacks(result: $Consumer<$Pack>): void;
    }

    export type $Pack$Position_ = $Pack$Position | "BOTTOM" | "TOP";
    export type $PackCompatibility_ = $PackCompatibility | "COMPATIBLE" | "TOO_NEW" | "TOO_OLD" | "UNKNOWN";
}
