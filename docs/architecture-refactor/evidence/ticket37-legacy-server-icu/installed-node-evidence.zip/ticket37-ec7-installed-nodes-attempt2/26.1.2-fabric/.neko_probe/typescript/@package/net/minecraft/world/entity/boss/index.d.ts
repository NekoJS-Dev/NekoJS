export * as enderdragon from "java:net/minecraft/world/entity/boss/enderdragon";
export * as wither from "java:net/minecraft/world/entity/boss/wither";

