import { $ContextChain } from "java:com/mojang/brigadier/context";
import { $AutoCloseable, $Record, $String } from "java:java/lang";
import { $CommandResultCallback } from "java:net/minecraft/commands";
import { $InstantiatedFunction } from "java:net/minecraft/commands/functions";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ProfilerFiller } from "java:net/minecraft/util/profiling";

declare module "java:net/minecraft/commands/execution" {
    export class $CommandQueueEntry<T> extends $Record {
        constructor(frame: $Frame, action: $EntryAction<T>);
        action(): $EntryAction<T>;
        equals(o: object): boolean;
        execute(context: $ExecutionContext<T>): void;
        frame(): $Frame;
        hashCode(): number;
        toString(): string;
    }

    export interface $EntryAction<T> {
        execute(context: $ExecutionContext<T>, frame: $Frame): void;
    }

    export class $ExecutionContext<T> implements $AutoCloseable {
        constructor(commandLimit: number, forkLimit: number, profiler: $ProfilerFiller);
        static queueInitialCommandExecution<T>(context: $ExecutionContext<T>, command: string, executionChain: $ContextChain<T>, sender: T, commandReturn: $CommandResultCallback): void;
        static queueInitialFunctionCall<T>(context: $ExecutionContext<T>, function_: $InstantiatedFunction<T>, sender: T, functionReturn: $CommandResultCallback): void;
        close(): void;
        discardAtDepthOrHigher(depthToDiscard: number): void;
        forkLimit(): number;
        frameControlForDepth(depthToDiscard: number): $Frame$FrameControl;
        incrementCost(): void;
        profiler(): $ProfilerFiller;
        queueNext(entry: $CommandQueueEntry<T>): void;
        runCommandQueue(): void;
        tracer(tracer: $TraceCallbacks): void;
        tracer(): $TraceCallbacks;
    }

    export class $Frame extends $Record {
        constructor(depth: number, returnValueConsumer: $CommandResultCallback, frameControl: $Frame$FrameControl);
        depth(): number;
        discard(): void;
        equals(o: object): boolean;
        frameControl(): $Frame$FrameControl;
        hashCode(): number;
        returnFailure(): void;
        returnSuccess(value: number): void;
        returnValueConsumer(): $CommandResultCallback;
        toString(): string;
    }

    export interface $Frame$FrameControl {
        discard(): void;
    }

    export interface $TraceCallbacks extends $AutoCloseable {
        close(): void;
        onCall(depth: number, function_: $Identifier_, size: number): void;
        onCommand(depth: number, command: string): void;
        onError(message: string): void;
        onReturn(depth: number, command: string, result: number): void;
    }

    export interface $UnboundEntryAction<T> {
        bind(sender: T): $EntryAction<T>;
        execute(sender: T, context: $ExecutionContext<T>, frame: $Frame): void;
    }

}
