import { $Class, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/network/syncher" {
    export class $EntityDataAccessor<T> extends $Record {
        constructor(id: number, serializer: $EntityDataSerializer<T>);
        equals(o: object): boolean;
        hashCode(): number;
        id(): number;
        serializer(): $EntityDataSerializer<T>;
        toString(): string;
    }

    export interface $EntityDataSerializer<T> {
        codec(): $StreamCodec<any, T>;
        copy(value: T): T;
        createAccessor(id: number): $EntityDataAccessor<T>;
        forValueType<T>(codec: $StreamCodec<any, T>): $EntityDataSerializer<T>;
    }

    export interface $SyncedDataHolder {
        onSyncedDataUpdated(updatedItems: $SynchedEntityData$DataValue<any>[]): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
    }

    export class $SynchedEntityData {
        get nonDefaultValues(): $List<$SynchedEntityData$DataValue<any>>;
        getNonDefaultValues(): $List<$SynchedEntityData$DataValue<any>>;
        get dirty(): boolean;
        isDirty(): boolean;
        static defineId<T>(clazz: $Class<$SyncedDataHolder>, type: $EntityDataSerializer<T>): $EntityDataAccessor<T>;
        assignValues(items: $SynchedEntityData$DataValue<any>[]): void;
        get<T>(accessor: $EntityDataAccessor<T>): T;
        packDirty(): $List<$SynchedEntityData$DataValue<any>>;
        set<T>(accessor: $EntityDataAccessor<T>, value: T, forceDirty: boolean): void;
        set<T>(accessor: $EntityDataAccessor<T>, value: T): void;
    }

    export class $SynchedEntityData$DataValue<T> extends $Record {
        constructor(id: number, serializer: $EntityDataSerializer<T>, value: T);
        static create<T>(accessor: $EntityDataAccessor<T>, value: T): $SynchedEntityData$DataValue<T>;
        static read(input: $RegistryFriendlyByteBuf, id: number): $SynchedEntityData$DataValue<any>;
        equals(o: object): boolean;
        hashCode(): number;
        id(): number;
        serializer(): $EntityDataSerializer<T>;
        toString(): string;
        value(): T;
        write(output: $RegistryFriendlyByteBuf): void;
    }

}
