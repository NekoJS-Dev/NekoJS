import { $MapCodec } from "java:com/mojang/serialization";
import { $Stream } from "java:java/util/stream";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";

declare module "java:net/minecraft/network/chat/contents/data" {
    export interface $DataSource {
        codec(): $MapCodec<$DataSource>;
        getData(sender: $CommandSourceStack): $Stream<$CompoundTag>;
    }

}
