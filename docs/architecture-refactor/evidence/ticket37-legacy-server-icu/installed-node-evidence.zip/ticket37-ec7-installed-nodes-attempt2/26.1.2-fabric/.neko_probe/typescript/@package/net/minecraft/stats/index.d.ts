import { $JsonElement } from "java:com/google/gson";
import { $DataFixer } from "java:com/mojang/datafixers";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Iterable, $Record, $String } from "java:java/lang";
import { $DecimalFormat } from "java:java/text";
import { $Collection, $Iterator, $List } from "java:java/util";
import { $Consumer, $Predicate } from "java:java/util/function";
import { $Registry } from "java:net/minecraft/core";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $RecipeBookType, $RecipeBookType_ } from "java:net/minecraft/world/inventory";
import { $Recipe, $RecipeHolder } from "java:net/minecraft/world/item/crafting";
import { $RecipeDisplayEntry } from "java:net/minecraft/world/item/crafting/display";
import { $ObjectiveCriteria } from "java:net/minecraft/world/scores/criteria";

declare module "java:net/minecraft/stats" {
    export class $RecipeBook {
        constructor();
        get bookSettings(): $RecipeBookSettings;
        getBookSettings(): $RecipeBookSettings;
        set bookSettings(value: $RecipeBookSettings);
        isFiltering(type: $RecipeBookType_): boolean;
        isOpen(recipeBookType: $RecipeBookType_): boolean;
        setBookSetting(bookType: $RecipeBookType_, open: boolean, filtering: boolean): void;
        setFiltering(type: $RecipeBookType_, filtering: boolean): void;
        setOpen(recipeBookType: $RecipeBookType_, open: boolean): void;
    }

    export class $RecipeBookSettings {
        constructor();
        static MAP_CODEC: $MapCodec<$RecipeBookSettings>;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $RecipeBookSettings>;
        copy(): $RecipeBookSettings;
        getSettings(type: $RecipeBookType_): $RecipeBookSettings$TypeSettings;
        isFiltering(type: $RecipeBookType_): boolean;
        isOpen(type: $RecipeBookType_): boolean;
        replaceFrom(other: $RecipeBookSettings): void;
        setFiltering(type: $RecipeBookType_, filtering: boolean): void;
        setOpen(type: $RecipeBookType_, open: boolean): void;
    }

    export class $RecipeBookSettings$TypeSettings extends $Record {
        constructor(open: boolean, filtering: boolean);
        static BLAST_FURNACE_MAP_CODEC: $MapCodec<$RecipeBookSettings$TypeSettings>;
        static CRAFTING_MAP_CODEC: $MapCodec<$RecipeBookSettings$TypeSettings>;
        static DEFAULT: $RecipeBookSettings$TypeSettings;
        static FURNACE_MAP_CODEC: $MapCodec<$RecipeBookSettings$TypeSettings>;
        static SMOKER_MAP_CODEC: $MapCodec<$RecipeBookSettings$TypeSettings>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $RecipeBookSettings$TypeSettings>;
        equals(o: object): boolean;
        filtering(): boolean;
        hashCode(): number;
        open(): boolean;
        toString(): string;
    }

    export class $ServerRecipeBook extends $RecipeBook {
        constructor(displayResolver: $ServerRecipeBook$DisplayResolver);
        static RECIPE_BOOK_TAG: string;
        addRecipes(recipes: $RecipeHolder<any>[], player: $ServerPlayer): number;
        add(id: $ResourceKey<$Recipe<any>>): void;
        contains(id: $ResourceKey<$Recipe<any>>): boolean;
        copyOverData(bookToCopy: $ServerRecipeBook): void;
        loadUntrusted(packed: $ServerRecipeBook$Packed, validator: $Predicate<$ResourceKey<$Recipe<any>>>): void;
        pack(): $ServerRecipeBook$Packed;
        removeHighlight(id: $ResourceKey<$Recipe<any>>): void;
        removeRecipes(recipes: $RecipeHolder<any>[], player: $ServerPlayer): number;
        remove(id: $ResourceKey<$Recipe<any>>): void;
        sendInitialRecipeBook(player: $ServerPlayer): void;
    }

    export interface $ServerRecipeBook$DisplayResolver {
        displaysForRecipe(id: $ResourceKey<$Recipe<any>>, output: $Consumer<$RecipeDisplayEntry>): void;
    }

    export class $ServerRecipeBook$Packed extends $Record {
        constructor(settings: $RecipeBookSettings, known: $ResourceKey<$Recipe<any>>[], highlight: $ResourceKey<$Recipe<any>>[]);
        static CODEC: $Codec<$ServerRecipeBook$Packed>;
        equals(o: object): boolean;
        hashCode(): number;
        highlight(): $List<$ResourceKey<$Recipe<any>>>;
        known(): $List<$ResourceKey<$Recipe<any>>>;
        settings(): $RecipeBookSettings;
        toString(): string;
    }

    export class $ServerStatsCounter extends $StatsCounter {
        constructor(server: $MinecraftServer, file: string);
        markAllDirty(): void;
        parse(fixerUpper: $DataFixer, element: $JsonElement): void;
        save(): void;
        sendStats(player: $ServerPlayer): void;
        setValue(player: $Player, stat: $Stat<any>, count: number): void;
    }

    export class $Stat<T> extends $ObjectiveCriteria {
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Stat<any>>;
        get type(): $StatType<T>;
        getType(): $StatType<T>;
        get value(): T;
        getValue(): T;
        static buildName<T>(type: $StatType<T>, value: T): string;
        equals(o: object): boolean;
        format(value: number): string;
        hashCode(): number;
        toString(): string;
    }

    export interface $StatFormatter {
        format(value: number): string;
        static DECIMAL_FORMAT: $DecimalFormat;
        static DEFAULT: $StatFormatter;
        static DISTANCE: $StatFormatter;
        static DIVIDE_BY_TEN: $StatFormatter;
        static TIME: $StatFormatter;
    }

    export class $StatType<T> implements $Iterable {
        constructor(registry: $Registry<T>, displayName: $Component_);
        get displayName(): $Component;
        getDisplayName(): $Component;
        get registry(): $Registry<T>;
        getRegistry(): $Registry<T>;
        contains(key: T): boolean;
        get(argument: T, formatter: $StatFormatter): $Stat<T>;
        get(argument: T): $Stat<T>;
        iterator(): $Iterator<$Stat<T>>;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, $Stat<T>>;
    }

    export class $StatsCounter {
        constructor();
        getValue(stat: $Stat<any>): number;
        getValue<T>(type: $StatType<T>, key: T): number;
        increment(player: $Player, stat: $Stat<any>, count: number): void;
        setValue(player: $Player, stat: $Stat<any>, count: number): void;
    }

}
