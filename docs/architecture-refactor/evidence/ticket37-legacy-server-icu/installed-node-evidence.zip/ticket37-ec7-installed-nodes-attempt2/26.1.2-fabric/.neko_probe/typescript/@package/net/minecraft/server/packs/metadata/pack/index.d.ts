import { $Codec, $DataResult, $MapCodec } from "java:com/mojang/serialization";
import { $Comparable, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $BiFunction } from "java:java/util/function";
import { $PackType, $PackType_ } from "java:net/minecraft/server/packs";
import { $InclusiveRange } from "java:net/minecraft/util";

declare module "java:net/minecraft/server/packs/metadata/pack" {
    export class $PackFormat extends $Record implements $Comparable {
        constructor(major: number, minor: number);
        static BOTTOM_CODEC: $Codec<$PackFormat>;
        static TOP_CODEC: $Codec<$PackFormat>;
        static lastPreMinorVersion(type: $PackType_): number;
        static of(major: number, minor: number): $PackFormat;
        static of(major: number): $PackFormat;
        static packCodec(type: $PackType_): $MapCodec<$InclusiveRange<$PackFormat>>;
        static validateHolderList<ResultType, HolderType>(list: HolderType[], lastPreMinorVersion: number, constructor: $BiFunction<HolderType, $InclusiveRange<$PackFormat>, ResultType>): $DataResult<$List<ResultType>>;
        compareTo(other: $PackFormat): number;
        equals(o: object): boolean;
        hashCode(): number;
        major(): number;
        minorRange(): $InclusiveRange<$PackFormat>;
        minor(): number;
        toString(): string;
    }

}
