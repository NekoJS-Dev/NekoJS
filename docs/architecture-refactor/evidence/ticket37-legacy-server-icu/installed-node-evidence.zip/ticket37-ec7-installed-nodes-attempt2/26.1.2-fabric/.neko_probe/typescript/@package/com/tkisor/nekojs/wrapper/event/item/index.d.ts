import { $List } from "java:java/util";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $InteractionHand, $InteractionHand_ } from "java:net/minecraft/world";
import { $Entity, $LivingEntity } from "java:net/minecraft/world/entity";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Level } from "java:net/minecraft/world/level";

declare module "java:com/tkisor/nekojs/wrapper/event/item" {
    /**
     * Fired when a player tosses an item from their inventory (ItemEvents.dropped). Not cancellable on fabric.
     * Members: player / item (ItemStack).
     */
    export class $ItemDroppedEventJS {
        constructor(player: $Player, item: $ItemStack_);
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get player(): $Player;
        getPlayer(): $Player;
    }

    /**
     * Fired when a player is about to pick up / has picked up an item entity (ItemEvents.canPickUp / pickedUpPre / pickedUp).
     * canPickUp / pickedUpPre are cancellable: return true to prevent the pickup. pickedUp is not cancellable.
     */
    export class $ItemEntityPickupEventJS {
        constructor(player: $Player, itemEntity: $ItemEntity);
        get itemEntity(): $ItemEntity;
        getItemEntity(): $ItemEntity;
        /** The item stack on the item entity. */
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get player(): $Player;
        getPlayer(): $Player;
    }

    /**
     * Fired when a player right-clicks while holding an item (ItemEvents.rightClicked).
     * Return true to consume the interaction.
     */
    export class $ItemRightClickEventJS {
        constructor(player: $Player, itemStack: $ItemStack_, hand: $InteractionHand_, level: $Level);
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get itemStack(): $ItemStack;
        getItemStack(): $ItemStack;
        get level(): $Level;
        getLevel(): $Level;
        get player(): $Player;
        getPlayer(): $Player;
    }

    export class $ItemTooltipEventJS {
        constructor(itemStack: $ItemStack_, lines: $Component_[]);
        get itemStack(): $ItemStack;
        getItemStack(): $ItemStack;
        get lines(): $List<$Component>;
        getLines(): $List<$Component>;
    }

    /**
     * Fired when a living entity finishes using an item (food eaten, potion drunk, bow shot, ...) — ItemEvents.foodEaten.
     * Fires for any item-use completion; use event.isFood() to filter to foods. Not cancellable.
     */
    export class $ItemUseFinishedEventJS {
        constructor(entity: $LivingEntity, item: $ItemStack_, hand: $InteractionHand_);
        get entity(): $LivingEntity;
        getEntity(): $LivingEntity;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        /** Whether the used item is food (has the FOOD data component, 26.x equivalent of isEdible()). */
        get food(): boolean;
        isFood(): boolean;
    }

    /**
     * Fired when a player interacts (right-click) with an entity (ItemEvents.entityInteracted). Dispatched by the item in the main hand.
     * Cancellable: return true to cancel the interaction.
     */
    export class $PlayerEntityInteractEventJS {
        constructor(player: $Player, target: $Entity, item: $ItemStack_, hand: $InteractionHand_);
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get player(): $Player;
        getPlayer(): $Player;
        get target(): $Entity;
        getTarget(): $Entity;
    }

}
