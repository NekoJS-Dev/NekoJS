import { $Entity } from "java:net/minecraft/world/entity";

declare module "java:net/minecraft/world/entity/ai/sensing" {
    export class $Sensing {
        constructor(mob: $Mob);
        hasLineOfSight(target: $Entity): boolean;
        tick(): void;
    }

}
