import { $Boolean, $Long } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $AnimationState, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $AbstractHorse } from "java:net/minecraft/world/entity/animal/equine";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/camel" {
    export class $Camel extends $AbstractHorse {
        constructor(type: $EntityType<$Camel>, level: $Level);
        static BABY_SCALE: number;
        static DASH: $EntityDataAccessor<boolean>;
        static DASH_COOLDOWN_TICKS: number;
        static LAST_POSE_CHANGE_TICK: $EntityDataAccessor<number>;
        static MAX_HEAD_Y_ROT: number;
        dashAnimationState: $AnimationState;
        idleAnimationState: $AnimationState;
        sitAnimationState: $AnimationState;
        sitPoseAnimationState: $AnimationState;
        sitUpAnimationState: $AnimationState;
        get ageScale(): number;
        getAgeScale(): number;
        get brain(): $Brain<$Camel>;
        getBrain(): $Brain<$Camel>;
        get jumpCooldown(): number;
        getJumpCooldown(): number;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get poseTime(): number;
        getPoseTime(): number;
        get quadLeashOffsets(): $Vec3[];
        getQuadLeashOffsets(): $Vec3[];
        get camelSitting(): boolean;
        isCamelSitting(): boolean;
        get camelVisuallySitting(): boolean;
        isCamelVisuallySitting(): boolean;
        get dashing(): boolean;
        isDashing(): boolean;
        set dashing(value: boolean);
        get inPoseTransition(): boolean;
        isInPoseTransition(): boolean;
        get tamed(): boolean;
        isTamed(): boolean;
        static checkCamelSpawnRules(type: $EntityType<$Camel>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canCamelChangePose(): boolean;
        canJump(): boolean;
        canMate(partner: $Animal): boolean;
        canSprint(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Camel;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getLeashOffset(partialTicks: number): $Vec3;
        handleStartJump(jumpScale: number): void;
        handleStopJump(): void;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        onElasticLeashPull(): void;
        onPlayerJump(jumpAmount: number): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        openCustomInventoryScreen(player: $Player): void;
        refuseToMove(): boolean;
        resetLastPoseChangeTick(syncedPoseTickTime: number): void;
        sitDown(): void;
        standUpInstantly(): void;
        standUp(): void;
        tick(): void;
        travel(input: $Vec3_): void;
    }

    export class $CamelHusk extends $Camel {
        constructor(type: $EntityType<$Camel>, level: $Level);
        get baby(): boolean;
        isBaby(): boolean;
        get mobControlled(): boolean;
        isMobControlled(): boolean;
        canBeLeashed(): boolean;
        canFallInLove(): boolean;
        canMate(partner: $Animal): boolean;
        chargeSpeedModifier(): number;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Camel;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        isFood(itemStack: $ItemStack_): boolean;
        removeWhenFarAway(distSqr: number): boolean;
    }

}
