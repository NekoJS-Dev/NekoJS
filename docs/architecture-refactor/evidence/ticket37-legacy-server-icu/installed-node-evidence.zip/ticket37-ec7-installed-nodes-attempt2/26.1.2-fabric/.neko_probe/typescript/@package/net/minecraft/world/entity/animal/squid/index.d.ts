import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $AgeableWaterCreature } from "java:net/minecraft/world/entity/animal";
import { $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/squid" {
    export class $GlowSquid extends $Squid {
        constructor(type: $EntityType<$GlowSquid>, level: $Level);
        get darkTicksRemaining(): number;
        getDarkTicksRemaining(): number;
        static checkGlowSquidSpawnRules(type: $EntityType<$LivingEntity>, level: $ServerLevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        aiStep(): void;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
    }

    export class $Squid extends $AgeableWaterCreature {
        constructor(type: $EntityType<$Squid>, level: $Level);
        oldTentacleAngle: number;
        oldTentacleMovement: number;
        tentacleAngle: number;
        tentacleMovement: number;
        xBodyRot: number;
        xBodyRotO: number;
        zBodyRot: number;
        zBodyRotO: number;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canBeLeashed(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        handleEntityEvent(id: number): void;
        hasMovementVector(): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        travel(input: $Vec3_): void;
    }

}
