import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $AgeableMob, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Biome } from "java:net/minecraft/world/level/biome";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/fox" {
    export class $Fox extends $Animal {
        constructor(type: $EntityType<$Fox>, level: $Level);
        static FLAG_CROUCHING: number;
        static FLAG_INTERESTED: number;
        static FLAG_POUNCING: number;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get variant(): $Fox$Variant;
        getVariant(): $Fox$Variant;
        get crouching(): boolean;
        isCrouching(): boolean;
        get faceplanted(): boolean;
        isFaceplanted(): boolean;
        get fullyCrouched(): boolean;
        isFullyCrouched(): boolean;
        get interested(): boolean;
        isInterested(): boolean;
        get pouncing(): boolean;
        isPouncing(): boolean;
        get sitting(): boolean;
        isSitting(): boolean;
        set sitting(value: boolean);
        get sleeping(): boolean;
        isSleeping(): boolean;
        static checkFoxSpawnRules(type: $EntityType<$Fox>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        static isPathClear(fox: $Fox, target: $LivingEntity): boolean;
        aiStep(): void;
        canHoldItem(itemStack: $ItemStack_): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Fox;
        getCrouchAmount(a: number): number;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getHeadRollAngle(a: number): number;
        get<T>(type: $DataComponentType<T>): T;
        handleEntityEvent(id: number): void;
        isFood(itemStack: $ItemStack_): boolean;
        playAmbientSound(): void;
        tick(): void;
    }

    export class $Fox$Variant {
        static RED: $Fox$Variant;
        static SNOW: $Fox$Variant;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Fox$Variant[];
        static valueOf(name: string): $Fox$Variant;
    }

    export type $Fox$Variant_ = $Fox$Variant | "RED" | "SNOW";
}
