import { $Integer, $Record, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener, $ClientboundAddEntityPacket } from "java:net/minecraft/network/protocol/game";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerEntity, $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance } from "java:net/minecraft/world/effect";
import { $Entity, $EntityDimensions, $LivingEntity, $Mob, $Pose, $Pose_ } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $EnderDragonPhaseManager } from "java:net/minecraft/world/entity/boss/enderdragon/phases";
import { $Enemy } from "java:net/minecraft/world/entity/monster";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $EnderDragonFight } from "java:net/minecraft/world/level/dimension/end";
import { $Node, $Path } from "java:net/minecraft/world/level/pathfinder";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as phases from "java:net/minecraft/world/entity/boss/enderdragon/phases";

declare module "java:net/minecraft/world/entity/boss/enderdragon" {
    export class $DragonFlightHistory {
        constructor();
        static LENGTH: number;
        copyFrom(history: $DragonFlightHistory): void;
        get(delay: number, partialTicks: number): $DragonFlightHistory$Sample;
        get(delay: number): $DragonFlightHistory$Sample;
        record(y: number, yRot: number): void;
    }

    export class $DragonFlightHistory$Sample extends $Record {
        constructor(y: number, yRot: number);
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        yRot(): number;
        y(): number;
    }

    export class $EndCrystal extends $Entity {
        constructor(type: $EntityType<$EndCrystal>, level: $Level);
        constructor(level: $Level, x: number, y: number, z: number);
        time: number;
        get beamTarget(): $BlockPos;
        getBeamTarget(): $BlockPos;
        set beamTarget(value: $BlockPos_);
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        get pickable(): boolean;
        isPickable(): boolean;
        hurtClient(source: $DamageSource): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        kill(level: $ServerLevel): void;
        shouldRenderAtSqrDistance(distance: number): boolean;
        showsBottom(): boolean;
        tick(): void;
    }

    export class $EnderDragon extends $Mob implements $Enemy {
        constructor(type: $EntityType<$EnderDragon>, level: $Level);
        static DATA_PHASE: $EntityDataAccessor<number>;
        dragonDeathTime: number;
        flapTime: number;
        flightHistory: $DragonFlightHistory;
        head: $EnderDragonPart;
        inWall: boolean;
        nearestCrystal: $EndCrystal;
        oFlapTime: number;
        yRotA: number;
        get dragonFight(): $EnderDragonFight;
        getDragonFight(): $EnderDragonFight;
        set dragonFight(value: $EnderDragonFight);
        get fightOrigin(): $BlockPos;
        getFightOrigin(): $BlockPos;
        set fightOrigin(value: $BlockPos_);
        get phaseManager(): $EnderDragonPhaseManager;
        getPhaseManager(): $EnderDragonPhaseManager;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get subEntities(): $EnderDragonPart[];
        getSubEntities(): $EnderDragonPart[];
        get flapping(): boolean;
        isFlapping(): boolean;
        get pickable(): boolean;
        isPickable(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        addEffect(newEffect: $MobEffectInstance, source: $Entity): boolean;
        aiStep(): void;
        canAttack(target: $LivingEntity): boolean;
        canUsePortal(ignorePassenger: boolean): boolean;
        checkDespawn(): void;
        findClosestNode(tX: number, tY: number, tZ: number): number;
        findClosestNode(): number;
        findPath(startIndex: number, endIndex: number, finalNode: $Node): $Path;
        getHeadLookVector(a: number): $Vec3;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        hurt(level: $ServerLevel, part: $EnderDragonPart, source: $DamageSource, damage: number): boolean;
        kill(level: $ServerLevel): void;
        knockback(power: number, xd: number, zd: number): void;
        onCrystalDestroyed(level: $ServerLevel, crystal: $EndCrystal, pos: $BlockPos_, source: $DamageSource): void;
        onFlap(): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        recreateFromPacket(packet: $ClientboundAddEntityPacket): void;
    }

    export class $EnderDragonPart extends $Entity {
        constructor(parentMob: $EnderDragon, name: string, w: number, h: number);
        name: string;
        parentMob: $EnderDragon;
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        get pickable(): boolean;
        isPickable(): boolean;
        getAddEntityPacket(serverEntity: $ServerEntity): $Packet<$ClientGamePacketListener>;
        getDimensions(pose: $Pose_): $EntityDimensions;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        is(other: $Entity): boolean;
        shouldBeSaved(): boolean;
    }

}
