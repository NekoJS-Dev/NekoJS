import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $AnimationState, $Entity, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/armadillo" {
    export class $Armadillo extends $Animal {
        constructor(type: $EntityType<$Animal>, level: $Level);
        static BABY_SCALE: number;
        static MAX_HEAD_ROTATION_EXTENT: number;
        static SCARE_CHECK_INTERVAL: number;
        peekAnimationState: $AnimationState;
        rollOutAnimationState: $AnimationState;
        rollUpAnimationState: $AnimationState;
        get ageScale(): number;
        getAgeScale(): number;
        get brain(): $Brain<$Armadillo>;
        getBrain(): $Brain<$Armadillo>;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get state(): $Armadillo$ArmadilloState;
        getState(): $Armadillo$ArmadilloState;
        get scared(): boolean;
        isScared(): boolean;
        static checkArmadilloSpawnRules(type: $EntityType<$Armadillo>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        brushOffScute(interactingEntity: $Entity, tool: $ItemStack_): boolean;
        canFallInLove(): boolean;
        canStayRolledUp(): boolean;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        handleEntityEvent(id: number): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        isScaredBy(livingEntity: $LivingEntity): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        rollOut(): void;
        rollUp(): void;
        shouldHideInShell(): boolean;
        shouldSwitchToScaredState(): boolean;
        switchToState(state: $Armadillo$ArmadilloState_): void;
        tick(): void;
    }

    export class $Armadillo$ArmadilloState {
        static IDLE: $Armadillo$ArmadilloState;
        static ROLLING: $Armadillo$ArmadilloState;
        static SCARED: $Armadillo$ArmadilloState;
        static UNROLLING: $Armadillo$ArmadilloState;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Armadillo$ArmadilloState[];
        static valueOf(name: string): $Armadillo$ArmadilloState;
    }

    export type $Armadillo$ArmadilloState_ = $Armadillo$ArmadilloState | "IDLE" | "ROLLING" | "SCARED" | "UNROLLING";
}
