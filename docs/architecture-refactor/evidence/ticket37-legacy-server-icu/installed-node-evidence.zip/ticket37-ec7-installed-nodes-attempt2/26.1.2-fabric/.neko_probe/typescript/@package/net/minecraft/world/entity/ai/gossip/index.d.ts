import { $Codec } from "java:com/mojang/serialization";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $Enum, $String } from "java:java/lang";
import { $Map, $UUID } from "java:java/util";
import { $DoublePredicate, $Predicate } from "java:java/util/function";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";

declare module "java:net/minecraft/world/entity/ai/gossip" {
    export class $GossipContainer {
        constructor();
        static CODEC: $Codec<$GossipContainer>;
        static DISCARD_THRESHOLD: number;
        get gossipEntries(): $Map<$UUID, $Object2IntMap<$GossipType>>;
        getGossipEntries(): $Map<$UUID, $Object2IntMap<$GossipType>>;
        add(target: string, type: $GossipType_, amountToAdd: number): void;
        clear(): void;
        copy(): $GossipContainer;
        decay(): void;
        getCountForType(type: $GossipType_, valueTest: $DoublePredicate): number;
        getReputation(entity: string, types: $Predicate<$GossipType_>): number;
        putAll(container: $GossipContainer): void;
        remove(target: string, type: $GossipType_, amountToRemove: number): void;
        remove(target: string, type: $GossipType_): void;
        remove(type: $GossipType_): void;
        transferFrom(source: $GossipContainer, random: $RandomSource, maxCount: number): void;
    }

    export class $GossipType {
        static MAJOR_NEGATIVE: $GossipType;
        static MAJOR_POSITIVE: $GossipType;
        static MINOR_NEGATIVE: $GossipType;
        static MINOR_POSITIVE: $GossipType;
        static TRADING: $GossipType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GossipType[];
        static valueOf(name: string): $GossipType;
    }

    export type $GossipType_ = $GossipType | "MAJOR_NEGATIVE" | "MAJOR_POSITIVE" | "MINOR_NEGATIVE" | "MINOR_POSITIVE" | "TRADING";
}
