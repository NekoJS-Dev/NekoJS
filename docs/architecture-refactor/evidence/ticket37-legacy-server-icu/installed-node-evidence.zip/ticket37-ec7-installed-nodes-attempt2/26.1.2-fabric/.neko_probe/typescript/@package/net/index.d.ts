export * as minecraft from "java:net/minecraft";

