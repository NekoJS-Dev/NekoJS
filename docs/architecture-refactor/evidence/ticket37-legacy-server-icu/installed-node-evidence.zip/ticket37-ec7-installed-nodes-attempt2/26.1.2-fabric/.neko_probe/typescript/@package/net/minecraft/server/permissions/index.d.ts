import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Predicate } from "java:java/util/function";
import { $StringRepresentable } from "java:net/minecraft/util";

declare module "java:net/minecraft/server/permissions" {
    export interface $LevelBasedPermissionSet extends $PermissionSet {
        forLevel(level: $PermissionLevel_): $LevelBasedPermissionSet;
        hasPermission(permission: $Permission): boolean;
        level(): $PermissionLevel;
        union(other: $PermissionSet): $PermissionSet;
        static ADMIN: $LevelBasedPermissionSet;
        static ALL: $LevelBasedPermissionSet;
        static GAMEMASTER: $LevelBasedPermissionSet;
        static MODERATOR: $LevelBasedPermissionSet;
        static OWNER: $LevelBasedPermissionSet;
    }

    export interface $Permission {
        codec(): $MapCodec<$Permission>;
        static CODEC: $Codec<$Permission>;
        static FULL_CODEC: $Codec<$Permission>;
    }

    export interface $PermissionCheck {
        check(source: $PermissionSet): boolean;
        codec(): $MapCodec<$PermissionCheck>;
        static CODEC: $Codec<$PermissionCheck>;
    }

    export class $PermissionLevel {
        static ADMINS: $PermissionLevel;
        static ALL: $PermissionLevel;
        static GAMEMASTERS: $PermissionLevel;
        static MODERATORS: $PermissionLevel;
        static OWNERS: $PermissionLevel;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PermissionLevel[];
        static valueOf(name: string): $PermissionLevel;
    }

    export class $PermissionProviderCheck<T extends $PermissionSetSupplier> extends $Record implements $Predicate {
        constructor(test: $PermissionCheck);
        equals(o: object): boolean;
        hashCode(): number;
        test(t: T): boolean;
        test(): $PermissionCheck;
        toString(): string;
    }

    export interface $PermissionSet {
        hasPermission(permission: $Permission): boolean;
        union(other: $PermissionSet): $PermissionSet;
        static ALL_PERMISSIONS: $PermissionSet;
        static NO_PERMISSIONS: $PermissionSet;
    }

    export interface $PermissionSetSupplier {
        permissions(): $PermissionSet;
    }

    export type $PermissionLevel_ = $PermissionLevel | "ADMINS" | "ALL" | "GAMEMASTERS" | "MODERATORS" | "OWNERS";
}
