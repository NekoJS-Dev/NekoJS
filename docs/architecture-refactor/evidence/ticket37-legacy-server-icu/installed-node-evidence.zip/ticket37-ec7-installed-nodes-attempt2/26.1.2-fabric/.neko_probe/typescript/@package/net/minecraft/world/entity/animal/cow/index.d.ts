import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $BlockPos, $BlockPos_, $ClientAsset$ResourceTexture, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_, $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LightningBolt, $Pose, $Pose_, $Shearable, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ModelAndTexture, $PriorityProvider, $PriorityProvider$Selector, $SpawnCondition, $SpawnContext, $SpawnPrioritySelectors } from "java:net/minecraft/world/entity/variant";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";

declare module "java:net/minecraft/world/entity/animal/cow" {
    export class $AbstractCow extends $Animal {
        constructor(type: $EntityType<$AbstractCow>, level: $Level);
        static createAttributes(): $AttributeSupplier$Builder;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
    }

    export class $Cow extends $AbstractCow {
        constructor(type: $EntityType<$Cow>, level: $Level);
        get variant(): $Holder<$CowVariant>;
        getVariant(): $Holder<$CowVariant>;
        set variant(value: $Holder<$CowVariant>);
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Cow;
        get<T>(type: $DataComponentType<T>): T;
    }

    export class $CowSoundVariant extends $Record {
        constructor(ambientSound: $Holder<$SoundEvent_>, hurtSound: $Holder<$SoundEvent_>, deathSound: $Holder<$SoundEvent_>, stepSound: $Holder<$SoundEvent_>);
        static CODEC: $Codec<$Holder<$CowSoundVariant>>;
        static DIRECT_CODEC: $Codec<$CowSoundVariant>;
        static NETWORK_CODEC: $Codec<$CowSoundVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$CowSoundVariant>>;
        ambientSound(): $Holder<$SoundEvent>;
        deathSound(): $Holder<$SoundEvent>;
        equals(o: object): boolean;
        hashCode(): number;
        hurtSound(): $Holder<$SoundEvent>;
        stepSound(): $Holder<$SoundEvent>;
        toString(): string;
    }

    export class $CowSoundVariants$SoundSet {
        static CLASSIC: $CowSoundVariants$SoundSet;
        static MOODY: $CowSoundVariants$SoundSet;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CowSoundVariants$SoundSet[];
        static valueOf(name: string): $CowSoundVariants$SoundSet;
    }

    export class $CowVariant extends $Record implements $PriorityProvider {
        constructor(modelAndTexture: $ModelAndTexture<$CowVariant$ModelType_>, babyTexture: $ClientAsset$ResourceTexture, spawnConditions: $SpawnPrioritySelectors);
        static CODEC: $Codec<$Holder<$CowVariant>>;
        static DIRECT_CODEC: $Codec<$CowVariant>;
        static NETWORK_CODEC: $Codec<$CowVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$CowVariant>>;
        babyTexture(): $ClientAsset$ResourceTexture;
        equals(o: object): boolean;
        hashCode(): number;
        modelAndTexture(): $ModelAndTexture<$CowVariant$ModelType>;
        selectors(): $List<$PriorityProvider$Selector<$SpawnContext, $SpawnCondition>>;
        spawnConditions(): $SpawnPrioritySelectors;
        toString(): string;
    }

    export class $CowVariant$ModelType {
        static COLD: $CowVariant$ModelType;
        static NORMAL: $CowVariant$ModelType;
        static WARM: $CowVariant$ModelType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CowVariant$ModelType[];
        static valueOf(name: string): $CowVariant$ModelType;
    }

    export class $MushroomCow extends $AbstractCow implements $Shearable {
        constructor(type: $EntityType<$MushroomCow>, level: $Level);
        get variant(): $MushroomCow$Variant;
        getVariant(): $MushroomCow$Variant;
        static checkMushroomSpawnRules(type: $EntityType<$MushroomCow>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $MushroomCow;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        get<T>(type: $DataComponentType<T>): T;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        readyForShearing(): boolean;
        shear(level: $ServerLevel, soundSource: $SoundSource_, tool: $ItemStack_): void;
        thunderHit(level: $ServerLevel, lightningBolt: $LightningBolt): void;
    }

    export class $MushroomCow$Variant {
        static BROWN: $MushroomCow$Variant;
        static RED: $MushroomCow$Variant;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MushroomCow$Variant[];
        static valueOf(name: string): $MushroomCow$Variant;
    }

    export type $CowSoundVariants$SoundSet_ = $CowSoundVariants$SoundSet | "CLASSIC" | "MOODY";
    export type $CowVariant$ModelType_ = $CowVariant$ModelType | "COLD" | "NORMAL" | "WARM";
    export type $MushroomCow$Variant_ = $MushroomCow$Variant | "BROWN" | "RED";
}
