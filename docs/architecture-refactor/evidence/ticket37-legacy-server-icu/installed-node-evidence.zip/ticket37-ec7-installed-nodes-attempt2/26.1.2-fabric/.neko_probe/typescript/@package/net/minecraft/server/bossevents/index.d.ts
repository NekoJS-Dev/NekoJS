import { $Codec } from "java:com/mojang/serialization";
import { $Record, $Runnable, $String } from "java:java/lang";
import { $Collection, $Set, $UUID } from "java:java/util";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ServerBossEvent, $ServerPlayer } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $BossEvent$BossBarColor, $BossEvent$BossBarColor_, $BossEvent$BossBarOverlay, $BossEvent$BossBarOverlay_ } from "java:net/minecraft/world";
import { $SavedData, $SavedDataType } from "java:net/minecraft/world/level/saveddata";

declare module "java:net/minecraft/server/bossevents" {
    export class $CustomBossEvent extends $ServerBossEvent {
        constructor(id: string, customId: $Identifier_, name: $Component_, dirtyCallback: $Runnable);
        get displayName(): $Component;
        getDisplayName(): $Component;
        static load(id: string, customId: $Identifier_, packed: $CustomBossEvent$Packed, setDirty: $Runnable): $CustomBossEvent;
        addPlayer(player: $ServerPlayer): void;
        customId(): $Identifier;
        max(): number;
        onPlayerConnect(player: $ServerPlayer): void;
        onPlayerDisconnect(player: $ServerPlayer): void;
        pack(): $CustomBossEvent$Packed;
        removeAllPlayers(): void;
        removePlayer(player: $ServerPlayer): void;
        setDirty(): void;
        value(): number;
    }

    export class $CustomBossEvent$Packed extends $Record {
        constructor(name: $Component_, visible: boolean, value: number, max: number, color: $BossEvent$BossBarColor_, overlay: $BossEvent$BossBarOverlay_, darkenScreen: boolean, playBossMusic: boolean, createWorldFog: boolean, players: string[]);
        static CODEC: $Codec<$CustomBossEvent$Packed>;
        color(): $BossEvent$BossBarColor;
        createWorldFog(): boolean;
        darkenScreen(): boolean;
        equals(o: object): boolean;
        hashCode(): number;
        max(): number;
        name(): $Component;
        overlay(): $BossEvent$BossBarOverlay;
        playBossMusic(): boolean;
        players(): $Set<$UUID>;
        toString(): string;
        value(): number;
        visible(): boolean;
    }

    export class $CustomBossEvents extends $SavedData {
        constructor();
        static TYPE: $SavedDataType<$CustomBossEvents>;
        get events(): $Collection<$CustomBossEvent>;
        getEvents(): $Collection<$CustomBossEvent>;
        get ids(): $Collection<$Identifier>;
        getIds(): $Collection<$Identifier>;
        create(random: $RandomSource, id: $Identifier_, name: $Component_): $CustomBossEvent;
        get(id: $Identifier_): $CustomBossEvent;
        onPlayerConnect(player: $ServerPlayer): void;
        onPlayerDisconnect(player: $ServerPlayer): void;
        remove(event: $CustomBossEvent): void;
    }

}
