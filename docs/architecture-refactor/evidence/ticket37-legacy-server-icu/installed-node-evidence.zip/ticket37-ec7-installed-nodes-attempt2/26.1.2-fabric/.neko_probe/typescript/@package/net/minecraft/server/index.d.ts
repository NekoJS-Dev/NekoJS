import { $GameProfile, $GameProfileRepository } from "java:com/mojang/authlib";
import { $MinecraftSessionService } from "java:com/mojang/authlib/minecraft";
import { $ServicesKeySet, $YggdrasilAuthenticationService } from "java:com/mojang/authlib/yggdrasil";
import { $CommandDispatcher } from "java:com/mojang/brigadier";
import { $DataFixer } from "java:com/mojang/datafixers";
import { $Either, $Pair } from "java:com/mojang/datafixers/util";
import { $AttachedData } from "java:com/tkisor/nekojs/api/data";
import { $ServerExtension } from "java:com/tkisor/nekojs/api/inject";
import { $ByteBuf } from "java:io/netty/buffer";
import { $File } from "java:java/io";
import { $AutoCloseable, $Enum, $Iterable, $Record, $Runnable, $String, $Thread, $Throwable, $Void } from "java:java/lang";
import { $Proxy, $URI } from "java:java/net";
import { $Path } from "java:java/nio/file";
import { $KeyPair } from "java:java/security";
import { $Collection, $List, $Map, $Optional, $Set, $UUID } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $Consumer, $Function, $Supplier } from "java:java/util/function";
import { $GlobalAttachments, $GlobalAttachmentsProvider } from "java:net/fabricmc/fabric/api/attachment/v1";
import { $DataResourceStore, $DataResourceStore$Key, $DataResourceStore$Mutable } from "java:net/fabricmc/fabric/api/resource/v1";
import { $FabricDataResourceStoreHolder, $FabricResourceReloader } from "java:net/fabricmc/fabric/impl/resource";
import { $FabricOriginalKnownPacksGetter } from "java:net/fabricmc/fabric/impl/resource/pack";
import { $SystemReport } from "java:net/minecraft";
import { $AdvancementHolder, $AdvancementProgress, $AdvancementTree } from "java:net/minecraft/advancements";
import { $CommandSource, $CommandSourceStack, $Commands, $Commands$CommandSelection, $Commands$CommandSelection_ } from "java:net/minecraft/commands";
import { $CommandFunction } from "java:net/minecraft/commands/functions";
import { $BlockPos, $BlockPos_, $HolderLookup$Provider, $LayeredRegistryAccess, $Registry, $Registry$PendingTags, $RegistryAccess$Frozen } from "java:net/minecraft/core";
import { $Tag } from "java:net/minecraft/nbt";
import { $PacketProcessor } from "java:net/minecraft/network";
import { $ChatDecorator, $ChatType$Bound, $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ServerStatus } from "java:net/minecraft/network/protocol/status";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $CustomBossEvents } from "java:net/minecraft/server/bossevents";
import { $ServerLevel, $ServerPlayer, $ServerPlayerGameMode } from "java:net/minecraft/server/level";
import { $ChunkLoadStatusView, $LevelLoadListener } from "java:net/minecraft/server/level/progress";
import { $ServerConnectionListener, $TextFilter } from "java:net/minecraft/server/network";
import { $NotificationManager, $ServerActivityMonitor } from "java:net/minecraft/server/notifications";
import { $PackRepository } from "java:net/minecraft/server/packs/repository";
import { $CloseableResourceManager, $PreparableReloadListener, $PreparableReloadListener$PreparationBarrier, $PreparableReloadListener$SharedState, $ResourceManager, $SimpleJsonResourceReloadListener } from "java:net/minecraft/server/packs/resources";
import { $LevelBasedPermissionSet, $PermissionSet } from "java:net/minecraft/server/permissions";
import { $NameAndId, $PlayerList, $ProfileResolver, $UserNameToIdResolver } from "java:net/minecraft/server/players";
import { $ModCheck, $RandomSource, $SignatureValidator } from "java:net/minecraft/util";
import { $ServerDebugSubscribers } from "java:net/minecraft/util/debug";
import { $ProfileResults } from "java:net/minecraft/util/profiling";
import { $ReentrantBlockableEventLoop } from "java:net/minecraft/util/thread";
import { $Difficulty, $Difficulty_, $RandomSequences, $Stopwatches, $TickRateManager } from "java:net/minecraft/world";
import { $ServerClockManager } from "java:net/minecraft/world/clock";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $PotionBrewing } from "java:net/minecraft/world/item/alchemy";
import { $RecipeManager } from "java:net/minecraft/world/item/crafting";
import { $ChunkPos, $GameType, $GameType_, $Level, $LevelSettings, $WorldDataConfiguration } from "java:net/minecraft/world/level";
import { $FuelValues } from "java:net/minecraft/world/level/block/entity";
import { $ChunkIOErrorReporter, $RegionStorageInfo } from "java:net/minecraft/world/level/chunk/storage";
import { $GameRule, $GameRules } from "java:net/minecraft/world/level/gamerules";
import { $WorldGenSettings } from "java:net/minecraft/world/level/levelgen";
import { $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";
import { $WeatherData } from "java:net/minecraft/world/level/saveddata";
import { $CommandStorage, $LevelData$RespawnData, $LevelDataAndDimensions$WorldDataAndGenSettings, $LevelResource, $SavedDataStorage, $WorldData } from "java:net/minecraft/world/level/storage";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $TimerQueue } from "java:net/minecraft/world/level/timers";
import { $DisplaySlot, $DisplaySlot_, $Objective, $PlayerTeam, $ScoreHolder, $Scoreboard, $ScoreboardSaveData, $ScoreboardSaveData$Packed } from "java:net/minecraft/world/scores";

export * as bossevents from "java:net/minecraft/server/bossevents";
export * as dialog from "java:net/minecraft/server/dialog";
export * as level from "java:net/minecraft/server/level";
export * as network from "java:net/minecraft/server/network";
export * as notifications from "java:net/minecraft/server/notifications";
export * as packs from "java:net/minecraft/server/packs";
export * as permissions from "java:net/minecraft/server/permissions";
export * as players from "java:net/minecraft/server/players";
export * as waypoints from "java:net/minecraft/server/waypoints";

declare module "java:net/minecraft/server" {
    export class $MinecraftServer extends $ReentrantBlockableEventLoop implements $CommandSource, $ServerInfo, $ChunkIOErrorReporter, $GlobalAttachmentsProvider, $DataResourceStore, $FabricOriginalKnownPacksGetter, $ServerExtension {
        constructor(serverThread: $Thread, storageSource: $LevelStorageSource$LevelStorageAccess, packRepository: $PackRepository, worldStem: $WorldStem, gameRules: $Optional<$GameRules>, proxy: $Proxy, fixerUpper: $DataFixer, services: $Services, levelLoadListener: $LevelLoadListener, propagatesCrashes: boolean);
        static ABSOLUTE_MAX_WORLD_SIZE: number;
        static ANONYMOUS_PLAYER_PROFILE: $NameAndId;
        static DEFAULT_GAME_RULES: $Supplier<$GameRules>;
        static DEMO_SETTINGS: $LevelSettings;
        static SPAWN_POSITION_SEARCH_RADIUS: number;
        static VANILLA_BRAND: string;
        get absoluteMaxWorldSize(): number;
        getAbsoluteMaxWorldSize(): number;
        get advancements(): $ServerAdvancementManager;
        getAdvancements(): $ServerAdvancementManager;
        get allLevels(): $Iterable<$ServerLevel>;
        getAllLevels(): $Iterable<$ServerLevel>;
        get averageTickTimeNanos(): number;
        getAverageTickTimeNanos(): number;
        get chatDecorator(): $ChatDecorator;
        getChatDecorator(): $ChatDecorator;
        get codeOfConducts(): $Map<string, string>;
        getCodeOfConducts(): $Map<string, string>;
        get commandStorage(): $CommandStorage;
        getCommandStorage(): $CommandStorage;
        get commands(): $Commands;
        getCommands(): $Commands;
        get compressionThreshold(): number;
        getCompressionThreshold(): number;
        get connection(): $ServerConnectionListener;
        getConnection(): $ServerConnectionListener;
        get currentSmoothedTickTime(): number;
        getCurrentSmoothedTickTime(): number;
        get customBossEvents(): $CustomBossEvents;
        getCustomBossEvents(): $CustomBossEvents;
        get dataStorage(): $SavedDataStorage;
        getDataStorage(): $SavedDataStorage;
        get defaultGameType(): $GameType;
        getDefaultGameType(): $GameType;
        set defaultGameType(value: $GameType_);
        get fixerUpper(): $DataFixer;
        getFixerUpper(): $DataFixer;
        get forcedGameType(): $GameType;
        getForcedGameType(): $GameType;
        get functionCompilationPermissions(): $PermissionSet;
        getFunctionCompilationPermissions(): $PermissionSet;
        get functions(): $ServerFunctionManager;
        getFunctions(): $ServerFunctionManager;
        get gameRules(): $GameRules;
        getGameRules(): $GameRules;
        get globalGameRules(): $GameRules;
        getGlobalGameRules(): $GameRules;
        get keyPair(): $KeyPair;
        getKeyPair(): $KeyPair;
        get levelLoadListener(): $LevelLoadListener;
        getLevelLoadListener(): $LevelLoadListener;
        get localIp(): string;
        getLocalIp(): string;
        set localIp(value: string);
        get maxChainedNeighborUpdates(): number;
        getMaxChainedNeighborUpdates(): number;
        get moddedStatus(): $ModCheck;
        getModdedStatus(): $ModCheck;
        get motd(): string;
        getMotd(): string;
        set motd(value: string);
        get nextTickTime(): number;
        getNextTickTime(): number;
        get packRepository(): $PackRepository;
        getPackRepository(): $PackRepository;
        get playerCount(): number;
        getPlayerCount(): number;
        get playerList(): $PlayerList;
        getPlayerList(): $PlayerList;
        set playerList(value: $PlayerList);
        get playerNames(): string[];
        getPlayerNames(): string[];
        get port(): number;
        getPort(): number;
        set port(value: number);
        get preventProxyConnections(): boolean;
        getPreventProxyConnections(): boolean;
        set preventProxyConnections(value: boolean);
        get proxy(): $Proxy;
        getProxy(): $Proxy;
        get randomSequences(): $RandomSequences;
        getRandomSequences(): $RandomSequences;
        get rateLimitPacketsPerSecond(): number;
        getRateLimitPacketsPerSecond(): number;
        get recipeManager(): $RecipeManager;
        getRecipeManager(): $RecipeManager;
        get resourceManager(): $ResourceManager;
        getResourceManager(): $ResourceManager;
        get respawnData(): $LevelData$RespawnData;
        getRespawnData(): $LevelData$RespawnData;
        set respawnData(value: $LevelData$RespawnData);
        get runningThread(): $Thread;
        getRunningThread(): $Thread;
        get scheduledEvents(): $TimerQueue<$MinecraftServer>;
        getScheduledEvents(): $TimerQueue<$MinecraftServer>;
        get scoreboard(): $ServerScoreboard;
        getScoreboard(): $ServerScoreboard;
        get serverActivityMonitor(): $ServerActivityMonitor;
        getServerActivityMonitor(): $ServerActivityMonitor;
        get serverDirectory(): $Path;
        getServerDirectory(): $Path;
        get serverModName(): string;
        getServerModName(): string;
        get serverResourcePack(): $Optional<$MinecraftServer$ServerResourcePackInfo>;
        getServerResourcePack(): $Optional<$MinecraftServer$ServerResourcePackInfo>;
        get serverVersion(): string;
        getServerVersion(): string;
        get singleplayerProfile(): $GameProfile;
        getSingleplayerProfile(): $GameProfile;
        set singleplayerProfile(value: $GameProfile);
        get status(): $ServerStatus;
        getStatus(): $ServerStatus;
        get stopwatches(): $Stopwatches;
        getStopwatches(): $Stopwatches;
        get structureManager(): $StructureTemplateManager;
        getStructureManager(): $StructureTemplateManager;
        get tickCount(): number;
        getTickCount(): number;
        get tickTimesNanos(): number[];
        getTickTimesNanos(): number[];
        get weatherData(): $WeatherData;
        getWeatherData(): $WeatherData;
        get worldData(): $WorldData;
        getWorldData(): $WorldData;
        get worldGenSettings(): $WorldGenSettings;
        getWorldGenSettings(): $WorldGenSettings;
        get worldScreenshotFile(): $Optional<$Path>;
        getWorldScreenshotFile(): $Optional<$Path>;
        get autoSave(): boolean;
        isAutoSave(): boolean;
        set autoSave(value: boolean);
        get currentlySaving(): boolean;
        isCurrentlySaving(): boolean;
        get dedicatedServer(): boolean;
        isDedicatedServer(): boolean;
        get demo(): boolean;
        isDemo(): boolean;
        set demo(value: boolean);
        get enforceWhitelist(): boolean;
        isEnforceWhitelist(): boolean;
        set enforceWhitelist(value: boolean);
        get hardcore(): boolean;
        isHardcore(): boolean;
        get paused(): boolean;
        isPaused(): boolean;
        get published(): boolean;
        isPublished(): boolean;
        get ready(): boolean;
        isReady(): boolean;
        get recordingMetrics(): boolean;
        isRecordingMetrics(): boolean;
        get resourcePackRequired(): boolean;
        isResourcePackRequired(): boolean;
        get running(): boolean;
        isRunning(): boolean;
        get shutdown(): boolean;
        isShutdown(): boolean;
        get singleplayer(): boolean;
        isSingleplayer(): boolean;
        get stopped(): boolean;
        isStopped(): boolean;
        get tickTimeLoggingEnabled(): boolean;
        isTickTimeLoggingEnabled(): boolean;
        get timeProfilerRunning(): boolean;
        isTimeProfilerRunning(): boolean;
        get usingWhitelist(): boolean;
        isUsingWhitelist(): boolean;
        set usingWhitelist(value: boolean);
        static configurePackRepository(packRepository: $PackRepository, initialDataConfig: $WorldDataConfiguration, initMode: boolean, safeMode: boolean): $WorldDataConfiguration;
        static spin<S>(factory: $Function<$Thread, S>): S;
        acceptsFailure(): boolean;
        acceptsSuccess(): boolean;
        acceptsTransfers(): boolean;
        addTickable(tickable: $Runnable): void;
        allowFlight(): boolean;
        cancelRecordingMetrics(): void;
        clockManager(): $ServerClockManager;
        close(): void;
        createChunkLoadStatusView(radius: number): $ChunkLoadStatusView;
        createCommandSourceStack(): $CommandSourceStack;
        createGameModeForPlayer(player: $ServerPlayer): $ServerPlayerGameMode;
        createTextFilterForPlayer(player: $ServerPlayer): $TextFilter;
        debugSubscribers(): $ServerDebugSubscribers;
        dumpServerProperties(path: string): void;
        enforceGameTypeForPlayers(gameType: $GameType_): number;
        enforceSecureProfile(): boolean;
        executeIfPossible(command: $Runnable): void;
        fabric$getOriginalKnownPacks(): $List;
        fillServerSystemReport(systemReport: $SystemReport): $SystemReport;
        fillSystemReport(systemReport: $SystemReport): $SystemReport;
        findRespawnDimension(): $ServerLevel;
        finishRecordingMetrics(): void;
        forceGameTimeSynchronization(): void;
        forceSynchronousWrites(): boolean;
        fuelValues(): $FuelValues;
        getFile(name: string): $Path;
        getLevel(dimension: $ResourceKey<$Level>): $ServerLevel;
        getOrThrow(arg0: $DataResourceStore$Key): object;
        getProfilePermissions(nameAndId: $NameAndId): $LevelBasedPermissionSet;
        getRandomSequence(key: $Identifier_): $RandomSource;
        getScaledTrackingDistance(baseRange: number): number;
        getWorldPath(resource: $LevelResource): $Path;
        globalAttachments(): $GlobalAttachments;
        halt(wait: boolean): void;
        handleCustomClickAction(id: $Identifier_, payload: $Optional<$Tag>): void;
        hidesOnlinePlayers(): boolean;
        invalidateStatus(): void;
        isSingleplayerOwner(nameAndId: $NameAndId): boolean;
        isUnderSpawnProtection(level: $ServerLevel, pos: $BlockPos_, player: $Player): boolean;
        kickUnlistedPlayers(): void;
        levelKeys(): $Set<$ResourceKey<$Level>>;
        logChatMessage(message: $Component_, chatType: $ChatType$Bound, tag: string): void;
        logIPs(): boolean;
        data(): $AttachedData;
        notificationManager(): $NotificationManager;
        onGameRuleChanged<T>(rule: $GameRule<T>, value: T): void;
        onTickRateChanged(): void;
        operatorUserPermissions(): $LevelBasedPermissionSet;
        overworld(): $ServerLevel;
        packetProcessor(): $PacketProcessor;
        playerIdleTimeout(): number;
        potionBrewing(): $PotionBrewing;
        publishServer(gameMode: $GameType_, allowCommands: boolean, port: number): boolean;
        registries(): $LayeredRegistryAccess<$RegistryLayer>;
        registryAccess(): $RegistryAccess$Frozen;
        reloadResources(packsToEnable: string[]): $CompletableFuture<void>;
        reloadableRegistries(): $ReloadableServerRegistries$Holder;
        repliesToStatus(): boolean;
        reportChunkLoadFailure(throwable: $Throwable, storageInfo: $RegionStorageInfo, pos: $ChunkPos): void;
        reportChunkSaveFailure(throwable: $Throwable, storageInfo: $RegionStorageInfo, pos: $ChunkPos): void;
        reportPacketHandlingException(throwable: $Throwable, packetType: $PacketType<any>): void;
        saveAllChunks(silent: boolean, flush: boolean, force: boolean): boolean;
        saveEverything(silent: boolean, flush: boolean, force: boolean): boolean;
        scheduleExecutables(): boolean;
        sendLowDiskSpaceWarning(): void;
        sendSystemMessage(message: $Component_): void;
        serverLinks(): $ServerLinks;
        services(): $Services;
        setDifficulty(difficulty: $Difficulty_, ignoreLock: boolean): void;
        setWeatherParameters(clearTime: number, rainTime: number, raining: boolean, thundering: boolean): void;
        shouldInformAdmins(): boolean;
        shouldRconBroadcast(): boolean;
        startRecordingMetrics(onStopped: $Consumer<$ProfileResults>, onFinished: $Consumer<string>): void;
        startTimeProfiler(): void;
        stopRecordingMetrics(): void;
        stopTimeProfiler(): $ProfileResults;
        tickRateManager(): $ServerTickRateManager;
        updateMobSpawningFlags(): void;
        useNativeTransport(): boolean;
        usesAuthentication(): boolean;
        wrapRunnable(runnable: $Runnable): $TickTask;
    }

    export class $MinecraftServer$ServerResourcePackInfo extends $Record {
        constructor(id: string, url: string, hash: string, isRequired: boolean, prompt: $Component_);
        get required(): boolean;
        isRequired(): boolean;
        equals(o: object): boolean;
        hashCode(): number;
        hash(): string;
        id(): $UUID;
        prompt(): $Component;
        toString(): string;
        url(): string;
    }

    export class $PlayerAdvancements {
        constructor(dataFixer: $DataFixer, playerList: $PlayerList, manager: $ServerAdvancementManager, playerSavePath: string, player: $ServerPlayer);
        award(holder: $AdvancementHolder, criterion: string): boolean;
        flushDirty(player: $ServerPlayer, showAdvancements: boolean): void;
        getOrStartProgress(advancement: $AdvancementHolder): $AdvancementProgress;
        reload(manager: $ServerAdvancementManager): void;
        revoke(advancement: $AdvancementHolder, criterion: string): boolean;
        save(): void;
        stopListening(): void;
    }

    export class $RegistryLayer {
        static DIMENSIONS: $RegistryLayer;
        static RELOADABLE: $RegistryLayer;
        static STATIC: $RegistryLayer;
        static WORLDGEN: $RegistryLayer;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RegistryLayer[];
        static valueOf(name: string): $RegistryLayer;
    }

    export class $ReloadableServerRegistries$Holder {
        constructor(registries: $HolderLookup$Provider);
        getLootTable(id: $ResourceKey<$LootTable>): $LootTable;
        lookup(): $HolderLookup$Provider;
    }

    export class $ReloadableServerResources implements $FabricDataResourceStoreHolder {
        get advancements(): $ServerAdvancementManager;
        getAdvancements(): $ServerAdvancementManager;
        get commands(): $Commands;
        getCommands(): $Commands;
        get functionLibrary(): $ServerFunctionLibrary;
        getFunctionLibrary(): $ServerFunctionLibrary;
        get recipeManager(): $RecipeManager;
        getRecipeManager(): $RecipeManager;
        static loadResources(resourceManager: $ResourceManager, contextLayers: $LayeredRegistryAccess<$RegistryLayer_>, updatedContextTags: $Registry$PendingTags<any>[], enabledFeatures: $FeatureFlagSet, commandSelection: $Commands$CommandSelection_, functionCompilationPermissions: $PermissionSet, backgroundExecutor: $Executor, mainThreadExecutor: $Executor): $CompletableFuture<$ReloadableServerResources>;
        fabric$getDataResourceStore(): $DataResourceStore$Mutable;
        fullRegistries(): $ReloadableServerRegistries$Holder;
        listeners(): $List<$PreparableReloadListener>;
        updateComponentsAndStaticRegistryTags(): void;
    }

    export class $ServerAdvancementManager extends $SimpleJsonResourceReloadListener implements $FabricResourceReloader {
        constructor(registries: $HolderLookup$Provider);
        get allAdvancements(): $Collection<$AdvancementHolder>;
        getAllAdvancements(): $Collection<$AdvancementHolder>;
        fabric$getId(): $Identifier;
        get(id: $Identifier_): $AdvancementHolder;
        tree(): $AdvancementTree;
    }

    export class $ServerFunctionLibrary implements $PreparableReloadListener, $FabricResourceReloader {
        constructor(functionCompilationPermissions: $PermissionSet, dispatcher: $CommandDispatcher<$CommandSourceStack>);
        static TYPE_KEY: $ResourceKey<$Registry<$CommandFunction<$CommandSourceStack>>>;
        get availableTags(): $Iterable<$Identifier>;
        getAvailableTags(): $Iterable<$Identifier>;
        get functions(): $Map<$Identifier, $CommandFunction<$CommandSourceStack>>;
        getFunctions(): $Map<$Identifier, $CommandFunction<$CommandSourceStack>>;
        fabric$getId(): $Identifier;
        getFunction(id: $Identifier_): $Optional<$CommandFunction<$CommandSourceStack>>;
        getTag(tag: $Identifier_): $List<$CommandFunction<$CommandSourceStack>>;
        reload(currentReload: $PreparableReloadListener$SharedState, taskExecutor: $Executor, preparationBarrier: $PreparableReloadListener$PreparationBarrier, reloadExecutor: $Executor): $CompletableFuture<void>;
    }

    export class $ServerFunctionManager {
        constructor(server: $MinecraftServer, library: $ServerFunctionLibrary);
        get dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        getDispatcher(): $CommandDispatcher<$CommandSourceStack>;
        get functionNames(): $Iterable<$Identifier>;
        getFunctionNames(): $Iterable<$Identifier>;
        get gameLoopSender(): $CommandSourceStack;
        getGameLoopSender(): $CommandSourceStack;
        get tagNames(): $Iterable<$Identifier>;
        getTagNames(): $Iterable<$Identifier>;
        execute(functionIn: $CommandFunction<$CommandSourceStack>, sender: $CommandSourceStack): void;
        getTag(id: $Identifier_): $List<$CommandFunction<$CommandSourceStack>>;
        get(id: $Identifier_): $Optional<$CommandFunction<$CommandSourceStack>>;
        replaceLibrary(library: $ServerFunctionLibrary): void;
        tick(): void;
    }

    export interface $ServerInfo {
        getMaxPlayers(): number;
        getMotd(): string;
        getPlayerCount(): number;
        getServerVersion(): string;
    }

    export class $ServerLinks extends $Record {
        constructor(entries: $ServerLinks$Entry[]);
        static EMPTY: $ServerLinks;
        static TYPE_STREAM_CODEC: $StreamCodec<$ByteBuf, $Either<$ServerLinks$KnownLinkType, $Component>>;
        static UNTRUSTED_LINKS_STREAM_CODEC: $StreamCodec<$ByteBuf, $List<$ServerLinks$UntrustedEntry>>;
        get empty(): boolean;
        isEmpty(): boolean;
        entries(): $List<$ServerLinks$Entry>;
        equals(o: object): boolean;
        findKnownType(type: $ServerLinks$KnownLinkType_): $Optional<$ServerLinks$Entry>;
        hashCode(): number;
        toString(): string;
        untrust(): $List<$ServerLinks$UntrustedEntry>;
    }

    export class $ServerLinks$Entry extends $Record {
        constructor(type: $Either<$ServerLinks$KnownLinkType_, $Component_>, link: $URI);
        static custom(displayName: $Component_, link: $URI): $ServerLinks$Entry;
        static knownType(type: $ServerLinks$KnownLinkType_, link: $URI): $ServerLinks$Entry;
        displayName(): $Component;
        equals(o: object): boolean;
        hashCode(): number;
        link(): $URI;
        toString(): string;
        type(): $Either<$ServerLinks$KnownLinkType, $Component>;
    }

    export class $ServerLinks$KnownLinkType {
        static ANNOUNCEMENTS: $ServerLinks$KnownLinkType;
        static BUG_REPORT: $ServerLinks$KnownLinkType;
        static COMMUNITY: $ServerLinks$KnownLinkType;
        static COMMUNITY_GUIDELINES: $ServerLinks$KnownLinkType;
        static FEEDBACK: $ServerLinks$KnownLinkType;
        static FORUMS: $ServerLinks$KnownLinkType;
        static NEWS: $ServerLinks$KnownLinkType;
        static STATUS: $ServerLinks$KnownLinkType;
        static SUPPORT: $ServerLinks$KnownLinkType;
        static WEBSITE: $ServerLinks$KnownLinkType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerLinks$KnownLinkType[];
        static valueOf(name: string): $ServerLinks$KnownLinkType;
    }

    export class $ServerLinks$UntrustedEntry extends $Record {
        constructor(type: $Either<$ServerLinks$KnownLinkType_, $Component_>, link: string);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerLinks$UntrustedEntry>;
        equals(o: object): boolean;
        hashCode(): number;
        link(): string;
        toString(): string;
        type(): $Either<$ServerLinks$KnownLinkType, $Component>;
    }

    export class $ServerScoreboard extends $Scoreboard {
        constructor(server: $MinecraftServer);
        addPlayerToTeam(player: string, team: $PlayerTeam): boolean;
        getObjectiveDisplaySlotCount(objective: $Objective): number;
        getStartTrackingPackets(objective: $Objective): $List<$Packet<any>>;
        getStopTrackingPackets(objective: $Objective): $List<$Packet<any>>;
        load(data: $ScoreboardSaveData$Packed): void;
        onObjectiveAdded(objective: $Objective): void;
        onObjectiveChanged(objective: $Objective): void;
        onObjectiveRemoved(objective: $Objective): void;
        onPlayerRemoved(player: $ScoreHolder): void;
        onPlayerScoreRemoved(player: $ScoreHolder, objective: $Objective): void;
        onTeamAdded(team: $PlayerTeam): void;
        onTeamChanged(team: $PlayerTeam): void;
        onTeamRemoved(team: $PlayerTeam): void;
        removePlayerFromTeam(player: string, team: $PlayerTeam): void;
        setDisplayObjective(slot: $DisplaySlot_, objective: $Objective): void;
        startTrackingObjective(objective: $Objective): void;
        stopTrackingObjective(objective: $Objective): void;
        storeToSaveDataIfDirty(saveData: $ScoreboardSaveData): void;
    }

    export class $ServerTickRateManager extends $TickRateManager {
        constructor(server: $MinecraftServer);
        get sprinting(): boolean;
        isSprinting(): boolean;
        checkShouldSprintThisTick(): boolean;
        endTickWork(): void;
        requestGameToSprint(time: number): boolean;
        stepGameIfPaused(ticks: number): boolean;
        stopSprinting(): boolean;
        stopStepping(): boolean;
        updateJoiningPlayer(player: $ServerPlayer): void;
    }

    export class $Services extends $Record {
        constructor(sessionService: $MinecraftSessionService, servicesKeySet: $ServicesKeySet, profileRepository: $GameProfileRepository, nameToIdCache: $UserNameToIdResolver, profileResolver: $ProfileResolver);
        static create(serviceAccess: $YggdrasilAuthenticationService, nameCacheDir: string): $Services;
        canValidateProfileKeys(): boolean;
        equals(o: object): boolean;
        hashCode(): number;
        nameToIdCache(): $UserNameToIdResolver;
        profileKeySignatureValidator(): $SignatureValidator;
        profileRepository(): $GameProfileRepository;
        profileResolver(): $ProfileResolver;
        servicesKeySet(): $ServicesKeySet;
        sessionService(): $MinecraftSessionService;
        toString(): string;
    }

    export class $TickTask implements $Runnable {
        constructor(tick: number, runnable: $Runnable);
        get tick(): number;
        getTick(): number;
        run(): void;
    }

    export class $WorldLoader$PackConfig extends $Record {
        constructor(packRepository: $PackRepository, initialDataConfig: $WorldDataConfiguration, safeMode: boolean, initMode: boolean);
        createResourceManager(): $Pair<$WorldDataConfiguration, $CloseableResourceManager>;
        equals(o: object): boolean;
        hashCode(): number;
        initMode(): boolean;
        initialDataConfig(): $WorldDataConfiguration;
        packRepository(): $PackRepository;
        safeMode(): boolean;
        toString(): string;
    }

    export class $WorldStem extends $Record implements $AutoCloseable {
        constructor(resourceManager: $CloseableResourceManager, dataPackResources: $ReloadableServerResources, registries: $LayeredRegistryAccess<$RegistryLayer_>, worldDataAndGenSettings: $LevelDataAndDimensions$WorldDataAndGenSettings);
        close(): void;
        dataPackResources(): $ReloadableServerResources;
        equals(o: object): boolean;
        hashCode(): number;
        registries(): $LayeredRegistryAccess<$RegistryLayer>;
        resourceManager(): $CloseableResourceManager;
        toString(): string;
        worldDataAndGenSettings(): $LevelDataAndDimensions$WorldDataAndGenSettings;
    }

    export type $RegistryLayer_ = $RegistryLayer | "DIMENSIONS" | "RELOADABLE" | "STATIC" | "WORLDGEN";
    export type $ServerLinks$KnownLinkType_ = $ServerLinks$KnownLinkType | "ANNOUNCEMENTS" | "BUG_REPORT" | "COMMUNITY" | "COMMUNITY_GUIDELINES" | "FEEDBACK" | "FORUMS" | "NEWS" | "STATUS" | "SUPPORT" | "WEBSITE";
}
