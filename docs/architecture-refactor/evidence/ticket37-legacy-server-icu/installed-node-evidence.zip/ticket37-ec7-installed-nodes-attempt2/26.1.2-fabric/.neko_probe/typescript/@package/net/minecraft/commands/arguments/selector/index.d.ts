import { $Codec } from "java:com/mojang/serialization";
import { $List } from "java:java/util";
import { $BiConsumer } from "java:java/util/function";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $CompilableString } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/commands/arguments/selector" {
    export class $EntitySelector {
        constructor(maxResults: number, includesEntities: boolean, worldLimited: boolean, contextFreePredicates: $Predicate<$Entity>[], range: $MinMaxBounds$Doubles, position: $Function<$Vec3_, $Vec3_>, aabb: $AABB, order: $BiConsumer<$Vec3_, $Entity[]>, currentEntity: boolean, playerName: string, entityUUID: string, type: $EntityType<any>, usesSelector: boolean);
        static COMPILABLE_CODEC: $Codec<$CompilableString<$EntitySelector>>;
        static INFINITE: number;
        static ORDER_ARBITRARY: $BiConsumer<$Vec3, $List<$Entity>>;
        get maxResults(): number;
        getMaxResults(): number;
        get selfSelector(): boolean;
        isSelfSelector(): boolean;
        get worldLimited(): boolean;
        isWorldLimited(): boolean;
        static joinNames(entities: $Entity[]): $Component;
        findEntities(sender: $CommandSourceStack): $List<$Entity>;
        findPlayers(sender: $CommandSourceStack): $List<$ServerPlayer>;
        findSingleEntity(sender: $CommandSourceStack): $Entity;
        findSinglePlayer(sender: $CommandSourceStack): $ServerPlayer;
        includesEntities(): boolean;
        usesSelector(): boolean;
    }

}
