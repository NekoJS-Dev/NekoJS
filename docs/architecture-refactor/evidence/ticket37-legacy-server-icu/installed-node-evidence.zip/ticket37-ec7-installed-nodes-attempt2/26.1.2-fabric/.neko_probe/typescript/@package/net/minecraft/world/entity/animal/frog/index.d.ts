import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_, $ClientAsset$ResourceTexture, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $AnimationState, $Entity, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $AbstractFish } from "java:net/minecraft/world/entity/animal/fish";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $PriorityProvider, $PriorityProvider$Selector, $SpawnCondition, $SpawnContext, $SpawnPrioritySelectors } from "java:net/minecraft/world/entity/variant";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/frog" {
    export class $Frog extends $Animal {
        constructor(type: $EntityType<$Animal>, level: $Level);
        croakAnimationState: $AnimationState;
        jumpAnimationState: $AnimationState;
        swimIdleAnimationState: $AnimationState;
        tongueAnimationState: $AnimationState;
        get brain(): $Brain<$Frog>;
        getBrain(): $Brain<$Frog>;
        get headRotSpeed(): number;
        getHeadRotSpeed(): number;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get target(): $LivingEntity;
        getTarget(): $LivingEntity;
        get tongueTarget(): $Optional<$Entity>;
        getTongueTarget(): $Optional<$Entity>;
        set tongueTarget(value: $Entity);
        get variant(): $Holder<$FrogVariant>;
        getVariant(): $Holder<$FrogVariant>;
        get baby(): boolean;
        isBaby(): boolean;
        set baby(value: boolean);
        get pushedByFluid(): boolean;
        isPushedByFluid(): boolean;
        static canEat(entity: $LivingEntity): boolean;
        static checkFrogSpawnRules(type: $EntityType<$Animal>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        eraseTongueTarget(): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        get<T>(type: $DataComponentType<T>): T;
        isFood(itemStack: $ItemStack_): boolean;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playEatingSound(): void;
        spawnChildFromBreeding(level: $ServerLevel, partner: $Animal): void;
        tick(): void;
    }

    export class $FrogVariant extends $Record implements $PriorityProvider {
        constructor(assetInfo: $ClientAsset$ResourceTexture, spawnConditions: $SpawnPrioritySelectors);
        static CODEC: $Codec<$Holder<$FrogVariant>>;
        static DIRECT_CODEC: $Codec<$FrogVariant>;
        static NETWORK_CODEC: $Codec<$FrogVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$FrogVariant>>;
        assetInfo(): $ClientAsset$ResourceTexture;
        equals(o: object): boolean;
        hashCode(): number;
        selectors(): $List<$PriorityProvider$Selector<$SpawnContext, $SpawnCondition>>;
        spawnConditions(): $SpawnPrioritySelectors;
        toString(): string;
    }

    export class $Tadpole extends $AbstractFish {
        constructor(type: $EntityType<$AbstractFish>, level: $Level);
        static HITBOX_HEIGHT: number;
        static HITBOX_WIDTH: number;
        static ticksToBeFrog: number;
        get brain(): $Brain<$Tadpole>;
        getBrain(): $Brain<$Tadpole>;
        get bucketItemStack(): $ItemStack;
        getBucketItemStack(): $ItemStack;
        get pickupSound(): $SoundEvent;
        getPickupSound(): $SoundEvent;
        get ageLocked(): boolean;
        isAgeLocked(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        fromBucket(): boolean;
        loadFromBucketTag(tag: $CompoundTag_): void;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        saveToBucketTag(bucket: $ItemStack_): void;
        shouldDropExperience(): boolean;
    }

}
