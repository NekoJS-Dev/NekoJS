import { $EntityExtension, $LivingEntityExtension } from "java:com/tkisor/nekojs/api/inject";
import { $Connection } from "java:net/minecraft/network";

declare module "java:com/tkisor/nekojs/fabric/mixin" {
    export interface $MixinEntity extends $EntityExtension {
    }

    export interface $MixinLivingEntity extends $LivingEntityExtension {
    }

    export interface $ServerCommonPacketListenerAccessor {
        nekojs$connection(): $Connection;
    }

}
