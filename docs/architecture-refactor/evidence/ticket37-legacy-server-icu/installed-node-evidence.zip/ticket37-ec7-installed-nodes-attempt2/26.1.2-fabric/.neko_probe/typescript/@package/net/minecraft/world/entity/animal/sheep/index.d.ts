import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $EntitySpawnReason, $EntitySpawnReason_, $Shearable, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $DyeColor, $DyeColor_, $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/sheep" {
    export class $Sheep extends $Animal implements $Shearable {
        constructor(type: $EntityType<$Sheep>, level: $Level);
        get color(): $DyeColor;
        getColor(): $DyeColor;
        set color(value: $DyeColor_);
        get sheared(): boolean;
        isSheared(): boolean;
        set sheared(value: boolean);
        static createAttributes(): $AttributeSupplier$Builder;
        static getRandomSheepColor(level: $ServerLevelAccessor, pos: $BlockPos_): $DyeColor;
        aiStep(): void;
        ate(): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Sheep;
        getHeadEatAngleScale(a: number): number;
        getHeadEatPositionScale(a: number): number;
        get<T>(type: $DataComponentType<T>): T;
        handleEntityEvent(id: number): void;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        readyForShearing(): boolean;
        shear(level: $ServerLevel, soundSource: $SoundSource_, tool: $ItemStack_): void;
    }

}
