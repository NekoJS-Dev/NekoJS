import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $ClientAsset$ResourceTexture, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $EntitySpawnReason, $EntitySpawnReason_, $EquipmentSlot, $EquipmentSlot_, $ItemSteerable, $LightningBolt, $LivingEntity, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ModelAndTexture, $PriorityProvider, $PriorityProvider$Selector, $SpawnCondition, $SpawnContext, $SpawnPrioritySelectors } from "java:net/minecraft/world/entity/variant";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/pig" {
    export class $Pig extends $Animal implements $ItemSteerable {
        constructor(type: $EntityType<$Pig>, level: $Level);
        get controllingPassenger(): $LivingEntity;
        getControllingPassenger(): $LivingEntity;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get variant(): $Holder<$PigVariant>;
        getVariant(): $Holder<$PigVariant>;
        static createAttributes(): $AttributeSupplier$Builder;
        boost(): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Pig;
        get<T>(type: $DataComponentType<T>): T;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        thunderHit(level: $ServerLevel, lightningBolt: $LightningBolt): void;
    }

    export class $PigSoundVariant extends $Record {
        constructor(adultSounds: $PigSoundVariant$PigSoundSet, babySounds: $PigSoundVariant$PigSoundSet);
        static CODEC: $Codec<$Holder<$PigSoundVariant>>;
        static DIRECT_CODEC: $Codec<$PigSoundVariant>;
        static NETWORK_CODEC: $Codec<$PigSoundVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$PigSoundVariant>>;
        adultSounds(): $PigSoundVariant$PigSoundSet;
        babySounds(): $PigSoundVariant$PigSoundSet;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $PigSoundVariant$PigSoundSet extends $Record {
        constructor(ambientSound: $Holder<$SoundEvent_>, hurtSound: $Holder<$SoundEvent_>, deathSound: $Holder<$SoundEvent_>, stepSound: $Holder<$SoundEvent_>, eatSound: $Holder<$SoundEvent_>);
        static CODEC: $Codec<$PigSoundVariant$PigSoundSet>;
        ambientSound(): $Holder<$SoundEvent>;
        deathSound(): $Holder<$SoundEvent>;
        eatSound(): $Holder<$SoundEvent>;
        equals(o: object): boolean;
        hashCode(): number;
        hurtSound(): $Holder<$SoundEvent>;
        stepSound(): $Holder<$SoundEvent>;
        toString(): string;
    }

    export class $PigSoundVariants$SoundSet {
        static BIG: $PigSoundVariants$SoundSet;
        static CLASSIC: $PigSoundVariants$SoundSet;
        static MINI: $PigSoundVariants$SoundSet;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PigSoundVariants$SoundSet[];
        static valueOf(name: string): $PigSoundVariants$SoundSet;
    }

    export class $PigVariant extends $Record implements $PriorityProvider {
        constructor(modelAndTexture: $ModelAndTexture<$PigVariant$ModelType_>, babyTexture: $ClientAsset$ResourceTexture, spawnConditions: $SpawnPrioritySelectors);
        static CODEC: $Codec<$Holder<$PigVariant>>;
        static DIRECT_CODEC: $Codec<$PigVariant>;
        static NETWORK_CODEC: $Codec<$PigVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$PigVariant>>;
        babyTexture(): $ClientAsset$ResourceTexture;
        equals(o: object): boolean;
        hashCode(): number;
        modelAndTexture(): $ModelAndTexture<$PigVariant$ModelType>;
        selectors(): $List<$PriorityProvider$Selector<$SpawnContext, $SpawnCondition>>;
        spawnConditions(): $SpawnPrioritySelectors;
        toString(): string;
    }

    export class $PigVariant$ModelType {
        static COLD: $PigVariant$ModelType;
        static NORMAL: $PigVariant$ModelType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PigVariant$ModelType[];
        static valueOf(name: string): $PigVariant$ModelType;
    }

    export type $PigSoundVariants$SoundSet_ = $PigSoundVariants$SoundSet | "BIG" | "CLASSIC" | "MINI";
    export type $PigVariant$ModelType_ = $PigVariant$ModelType | "COLD" | "NORMAL";
}
