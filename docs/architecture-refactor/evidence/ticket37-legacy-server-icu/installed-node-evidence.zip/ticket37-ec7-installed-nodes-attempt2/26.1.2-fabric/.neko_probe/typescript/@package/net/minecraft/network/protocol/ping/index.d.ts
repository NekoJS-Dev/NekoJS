import { $ByteBuf } from "java:io/netty/buffer";
import { $Record, $String } from "java:java/lang";
import { $FriendlyByteBuf, $PacketListener } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";

declare module "java:net/minecraft/network/protocol/ping" {
    export interface $ClientPongPacketListener extends $PacketListener {
        handlePongResponse(packet: $ClientboundPongResponsePacket): void;
    }

    export class $ClientboundPongResponsePacket extends $Record implements $Packet {
        constructor(time: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPongResponsePacket>;
        equals(o: object): boolean;
        handle(listener: $ClientPongPacketListener): void;
        hashCode(): number;
        time(): number;
        toString(): string;
        type(): $PacketType<$ClientboundPongResponsePacket>;
    }

    export interface $ServerPingPacketListener extends $PacketListener {
        handlePingRequest(packet: $ServerboundPingRequestPacket): void;
    }

    export class $ServerboundPingRequestPacket implements $Packet {
        constructor(time: number);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundPingRequestPacket>;
        get time(): number;
        getTime(): number;
        handle(listener: $ServerPingPacketListener): void;
        type(): $PacketType<$ServerboundPingRequestPacket>;
    }

}
