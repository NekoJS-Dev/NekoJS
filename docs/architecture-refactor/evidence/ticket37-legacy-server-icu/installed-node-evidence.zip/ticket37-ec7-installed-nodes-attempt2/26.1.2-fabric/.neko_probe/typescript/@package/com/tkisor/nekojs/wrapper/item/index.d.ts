import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $NekoWrapper } from "java:com/tkisor/nekojs/wrapper";
import { $PersistentDataJS } from "java:com/tkisor/nekojs/wrapper/pdata";
import { $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_ } from "java:net/minecraft/world/item/crafting";

declare module "java:com/tkisor/nekojs/wrapper/item" {
    export class $IngredientJS implements $NekoWrapper {
        constructor();
        constructor(ids?: string[]);
        constructor(ingredient: $Ingredient_);
        get empty(): boolean;
        isEmpty(): boolean;
        asIngredient(): $IngredientJS;
        displayStacks(): $List<$ItemStack>;
        first(): $ItemStack;
        matches(stack: $ItemStack_): boolean;
        matches(ingredient: $Ingredient_): boolean;
        or(id: $NekoId): $IngredientJS;
        or(other: $IngredientJS): $IngredientJS;
        or(id: string): $IngredientJS;
        or(stack: $ItemStack_): $IngredientJS;
        or(item: $Item_): $IngredientJS;
        or(ingredient: $Ingredient_): $IngredientJS;
        stacks(): $List<$ItemStack>;
        test(stack: $ItemStack_): boolean;
        unwrap(): $Ingredient;
    }

    export class $PersistentDataJS extends $PersistentDataJS {
        constructor(rawStack: $ItemStack_);
    }

}
