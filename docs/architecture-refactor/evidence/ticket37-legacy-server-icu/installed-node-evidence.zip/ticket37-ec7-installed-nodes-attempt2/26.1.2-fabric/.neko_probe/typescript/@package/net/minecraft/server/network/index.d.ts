import { $Operation } from "java:com/llamalad7/mixinextras/injector/wrapoperation";
import { $LocalRef } from "java:com/llamalad7/mixinextras/sugar/ref";
import { $GameProfile } from "java:com/mojang/authlib";
import { $ServerCommonPacketListenerAccessor } from "java:com/tkisor/nekojs/fabric/mixin";
import { $ChannelFutureListener, $EventLoopGroup } from "java:io/netty/channel";
import { $Class, $Exception, $Record, $String } from "java:java/lang";
import { $InetAddress, $SocketAddress } from "java:java/net";
import { $List, $Set } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $PacketContext, $PacketContextProvider } from "java:net/fabricmc/fabric/api/networking/v1/context";
import { $PacketListenerExtensions } from "java:net/fabricmc/fabric/impl/networking";
import { $ServerPlayNetworkAddon } from "java:net/fabricmc/fabric/impl/networking/server";
import { $ServerCommonPacketListenerImplAccessor } from "java:net/fabricmc/fabric/mixin/networking/accessor";
import { $ServerCommonPacketListenerImplAccessor } from "java:net/fabricmc/fabric/mixin/recipe/sync";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Connection, $DisconnectionDetails, $TickablePacketListener } from "java:net/minecraft/network";
import { $ChatType$Bound, $Component, $Component_, $FilterMask, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ServerCommonPacketListener, $ServerboundClientInformationPacket, $ServerboundCustomClickActionPacket, $ServerboundCustomPayloadPacket, $ServerboundKeepAlivePacket, $ServerboundPongPacket, $ServerboundResourcePackPacket } from "java:net/minecraft/network/protocol/common";
import { $ServerboundCookieResponsePacket } from "java:net/minecraft/network/protocol/cookie";
import { $GameProtocols$Context, $ServerGamePacketListener, $ServerboundAcceptTeleportationPacket, $ServerboundAttackPacket, $ServerboundBlockEntityTagQueryPacket, $ServerboundChangeDifficultyPacket, $ServerboundChangeGameModePacket, $ServerboundChatAckPacket, $ServerboundChatCommandPacket, $ServerboundChatCommandSignedPacket, $ServerboundChatPacket, $ServerboundChatSessionUpdatePacket, $ServerboundChunkBatchReceivedPacket, $ServerboundClientCommandPacket, $ServerboundClientTickEndPacket, $ServerboundCommandSuggestionPacket, $ServerboundConfigurationAcknowledgedPacket, $ServerboundContainerButtonClickPacket, $ServerboundContainerClickPacket, $ServerboundContainerClosePacket, $ServerboundContainerSlotStateChangedPacket, $ServerboundDebugSubscriptionRequestPacket, $ServerboundEditBookPacket, $ServerboundEntityTagQueryPacket, $ServerboundInteractPacket, $ServerboundJigsawGeneratePacket, $ServerboundLockDifficultyPacket, $ServerboundMovePlayerPacket, $ServerboundMoveVehiclePacket, $ServerboundPaddleBoatPacket, $ServerboundPickItemFromBlockPacket, $ServerboundPickItemFromEntityPacket, $ServerboundPlaceRecipePacket, $ServerboundPlayerAbilitiesPacket, $ServerboundPlayerActionPacket, $ServerboundPlayerCommandPacket, $ServerboundPlayerInputPacket, $ServerboundPlayerLoadedPacket, $ServerboundRecipeBookChangeSettingsPacket, $ServerboundRecipeBookSeenRecipePacket, $ServerboundRenameItemPacket, $ServerboundSeenAdvancementsPacket, $ServerboundSelectBundleItemPacket, $ServerboundSelectTradePacket, $ServerboundSetBeaconPacket, $ServerboundSetCarriedItemPacket, $ServerboundSetCommandBlockPacket, $ServerboundSetCommandMinecartPacket, $ServerboundSetCreativeModeSlotPacket, $ServerboundSetGameRulePacket, $ServerboundSetJigsawBlockPacket, $ServerboundSetStructureBlockPacket, $ServerboundSetTestBlockPacket, $ServerboundSignUpdatePacket, $ServerboundSpectateEntityPacket, $ServerboundSwingPacket, $ServerboundTeleportToEntityPacket, $ServerboundTestInstanceBlockActionPacket, $ServerboundUseItemOnPacket, $ServerboundUseItemPacket } from "java:net/minecraft/network/protocol/game";
import { $ServerboundPingRequestPacket } from "java:net/minecraft/network/protocol/ping";
import { $MinecraftServer } from "java:net/minecraft/server";
import { $ClientInformation, $ServerPlayer } from "java:net/minecraft/server/level";
import { $Entity, $PositionMoveRotation, $Relative, $Relative_ } from "java:net/minecraft/world/entity";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ChunkPos, $LevelReader } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $LevelChunk } from "java:net/minecraft/world/level/chunk";
import { $CallbackInfo } from "java:org/spongepowered/asm/mixin/injection/callback";

declare module "java:net/minecraft/server/network" {
    export class $CommonListenerCookie extends $Record {
        constructor(gameProfile: $GameProfile, latency: number, clientInformation: $ClientInformation, transferred: boolean);
        static createInitial(gameProfile: $GameProfile, transferred: boolean): $CommonListenerCookie;
        clientInformation(): $ClientInformation;
        equals(o: object): boolean;
        gameProfile(): $GameProfile;
        hashCode(): number;
        latency(): number;
        toString(): string;
        transferred(): boolean;
    }

    export class $EventLoopGroupHolder {
        static local(): $EventLoopGroupHolder;
        static remote(allowNativeTransport: boolean): $EventLoopGroupHolder;
        channelCls(): $Class<$Channel>;
        eventLoopGroup(): $EventLoopGroup;
        serverChannelCls(): $Class<$ServerChannel>;
    }

    export class $FilteredText extends $Record {
        constructor(raw: string, mask: $FilterMask);
        static EMPTY: $FilteredText;
        get filtered(): boolean;
        isFiltered(): boolean;
        static fullyFiltered(message: string): $FilteredText;
        static passThrough(message: string): $FilteredText;
        equals(o: object): boolean;
        filteredOrEmpty(): string;
        filtered(): string;
        hashCode(): number;
        mask(): $FilterMask;
        raw(): string;
        toString(): string;
    }

    export class $PlayerChunkSender {
        constructor(memoryConnection: boolean);
        static MAX_CHUNKS_PER_TICK: number;
        static MIN_CHUNKS_PER_TICK: number;
        dropChunk(player: $ServerPlayer, pos: $ChunkPos): void;
        isPending(pos: number): boolean;
        markChunkPendingToSend(chunk: $LevelChunk): void;
        onChunkBatchReceivedByClient(desiredChunksPerTick: number): void;
        sendNextChunks(player: $ServerPlayer): void;
    }

    export class $ServerCommonPacketListenerImpl implements $ServerCommonPacketListener, $PacketContextProvider, $PacketListenerExtensions, $ServerCommonPacketListenerImplAccessor, $ServerCommonPacketListenerImplAccessor, $ServerCommonPacketListenerAccessor {
        constructor(server: $MinecraftServer, connection: $Connection, cookie: $CommonListenerCookie);
        static LATENCY_CHECK_INTERVAL: number;
        get owner(): $GameProfile;
        getOwner(): $GameProfile;
        get packetContext(): $PacketContext;
        getPacketContext(): $PacketContext;
        disconnect(details: $DisconnectionDetails): void;
        disconnect(reason: $Component_): void;
        handleCookieResponse(packet: $ServerboundCookieResponsePacket): void;
        handleCustomClickAction(packet: $ServerboundCustomClickActionPacket): void;
        handleCustomPayload(packet: $ServerboundCustomPayloadPacket): void;
        handleKeepAlive(packet: $ServerboundKeepAlivePacket): void;
        handlePong(serverboundPongPacket: $ServerboundPongPacket): void;
        handleResourcePackResponse(packet: $ServerboundResourcePackPacket): void;
        latency(): number;
        onDisconnect(details: $DisconnectionDetails): void;
        onPacketError(packet: $Packet, e: $Exception): void;
        resumeFlushing(): void;
        send(packet: $Packet<any>, listener: $ChannelFutureListener): void;
        send(packet: $Packet<any>): void;
        suspendFlushing(): void;
    }

    export class $ServerConnectionListener {
        constructor(server: $MinecraftServer);
        running: boolean;
        get connections(): $List<$Connection>;
        getConnections(): $List<$Connection>;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        startMemoryChannel(): $SocketAddress;
        startTcpServerListener(address: $InetAddress, port: number): void;
        stop(): void;
        tick(): void;
    }

    export class $ServerGamePacketListenerImpl extends $ServerCommonPacketListenerImpl implements $ServerGamePacketListener, $ServerPlayerConnection, $TickablePacketListener, $GameProtocols$Context, $PacketListenerExtensions {
        constructor(server: $MinecraftServer, connection: $Connection, player: $ServerPlayer, cookie: $CommonListenerCookie);
        static CLIENT_LOADED_TIMEOUT_TIME: number;
        chunkSender: $PlayerChunkSender;
        player: $ServerPlayer;
        get addon(): $ServerPlayNetworkAddon;
        getAddon(): $ServerPlayNetworkAddon;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get remoteAddress(): $SocketAddress;
        getRemoteAddress(): $SocketAddress;
        get acceptingMessages(): boolean;
        isAcceptingMessages(): boolean;
        ackBlockChangesUpTo(packetSequenceNr: number): void;
        handleAcceptPlayerLoad(packet: $ServerboundPlayerLoadedPacket): void;
        handleAcceptTeleportPacket(packet: $ServerboundAcceptTeleportationPacket): void;
        handleAnimate(packet: $ServerboundSwingPacket): void;
        handleAttack(packet: $ServerboundAttackPacket): void;
        handleBlockEntityTagQuery(packet: $ServerboundBlockEntityTagQueryPacket): void;
        handleBundleItemSelectedPacket(packet: $ServerboundSelectBundleItemPacket): void;
        handleChangeDifficulty(packet: $ServerboundChangeDifficultyPacket): void;
        handleChangeGameMode(packet: $ServerboundChangeGameModePacket): void;
        handleChatAck(packet: $ServerboundChatAckPacket): void;
        handleChatCommand(packet: $ServerboundChatCommandPacket): void;
        handleChatSessionUpdate(packet: $ServerboundChatSessionUpdatePacket): void;
        handleChat(packet: $ServerboundChatPacket): void;
        handleChunkBatchReceived(packet: $ServerboundChunkBatchReceivedPacket): void;
        handleClientCommand(packet: $ServerboundClientCommandPacket): void;
        handleClientInformation(packet: $ServerboundClientInformationPacket): void;
        handleClientTickEnd(packet: $ServerboundClientTickEndPacket): void;
        handleConfigurationAcknowledged(packet: $ServerboundConfigurationAcknowledgedPacket): void;
        handleContainerButtonClick(packet: $ServerboundContainerButtonClickPacket): void;
        handleContainerClick(packet: $ServerboundContainerClickPacket): void;
        handleContainerClose(packet: $ServerboundContainerClosePacket): void;
        handleContainerSlotStateChanged(packet: $ServerboundContainerSlotStateChangedPacket): void;
        handleCustomCommandSuggestions(packet: $ServerboundCommandSuggestionPacket): void;
        handleCustomPayload(packet: $ServerboundCustomPayloadPacket): void;
        handleDebugSubscriptionRequest(packet: $ServerboundDebugSubscriptionRequestPacket): void;
        handleEditBook(packet: $ServerboundEditBookPacket): void;
        handleEntityTagQuery(packet: $ServerboundEntityTagQueryPacket): void;
        handleInteract(packet: $ServerboundInteractPacket): void;
        handleJigsawGenerate(packet: $ServerboundJigsawGeneratePacket): void;
        handleLockDifficulty(packet: $ServerboundLockDifficultyPacket): void;
        handleMovePlayer(packet: $ServerboundMovePlayerPacket): void;
        handleMoveVehicle(packet: $ServerboundMoveVehiclePacket): void;
        handlePaddleBoat(packet: $ServerboundPaddleBoatPacket): void;
        handlePickItemFromBlock(packet: $ServerboundPickItemFromBlockPacket): void;
        handlePickItemFromEntity(packet: $ServerboundPickItemFromEntityPacket): void;
        handlePingRequest(packet: $ServerboundPingRequestPacket): void;
        handlePlaceRecipe(packet: $ServerboundPlaceRecipePacket): void;
        handlePlayerAbilities(packet: $ServerboundPlayerAbilitiesPacket): void;
        handlePlayerAction(packet: $ServerboundPlayerActionPacket): void;
        handlePlayerCommand(packet: $ServerboundPlayerCommandPacket): void;
        handlePlayerInput(packet: $ServerboundPlayerInputPacket): void;
        handleRecipeBookChangeSettingsPacket(packet: $ServerboundRecipeBookChangeSettingsPacket): void;
        handleRecipeBookSeenRecipePacket(packet: $ServerboundRecipeBookSeenRecipePacket): void;
        handleRenameItem(packet: $ServerboundRenameItemPacket): void;
        handleSeenAdvancements(packet: $ServerboundSeenAdvancementsPacket): void;
        handleSelectTrade(packet: $ServerboundSelectTradePacket): void;
        handleSetBeaconPacket(packet: $ServerboundSetBeaconPacket): void;
        handleSetCarriedItem(packet: $ServerboundSetCarriedItemPacket): void;
        handleSetCommandBlock(packet: $ServerboundSetCommandBlockPacket): void;
        handleSetCommandMinecart(packet: $ServerboundSetCommandMinecartPacket): void;
        handleSetCreativeModeSlot(packet: $ServerboundSetCreativeModeSlotPacket): void;
        handleSetGameRule(packet: $ServerboundSetGameRulePacket): void;
        handleSetJigsawBlock(packet: $ServerboundSetJigsawBlockPacket): void;
        handleSetStructureBlock(packet: $ServerboundSetStructureBlockPacket): void;
        handleSetTestBlock(packet: $ServerboundSetTestBlockPacket): void;
        handleSignUpdate(packet: $ServerboundSignUpdatePacket): void;
        handleSignedChatCommand(packet: $ServerboundChatCommandSignedPacket): void;
        handleSpectateEntity(packet: $ServerboundSpectateEntityPacket): void;
        handleTeleportToEntityPacket(packet: $ServerboundTeleportToEntityPacket): void;
        handleTestInstanceBlockAction(packet: $ServerboundTestInstanceBlockActionPacket): void;
        handleUseItemOn(packet: $ServerboundUseItemOnPacket): void;
        handleUseItem(packet: $ServerboundUseItemPacket): void;
        handler$zej000$fabric-events-interaction-v0$handleInteract(arg0: $ServerboundInteractPacket, arg1: $CallbackInfo, arg2: $Entity): void;
        hasClientLoaded(): boolean;
        hasInfiniteMaterials(): boolean;
        markClientUnloadedAfterDeath(): void;
        onDisconnect(details: $DisconnectionDetails): void;
        resetFlyingTicks(): void;
        resetPosition(): void;
        sendDisguisedChatMessage(content: $Component_, chatType: $ChatType$Bound): void;
        sendPlayerChatMessage(message: $PlayerChatMessage, chatType: $ChatType$Bound): void;
        shouldHandleMessage(packet: $Packet<any>): boolean;
        switchToConfig(): void;
        teleport(x: number, y: number, z: number, yRot: number, xRot: number): void;
        teleport(destination: $PositionMoveRotation, relatives: $Relative_[]): void;
        tickClientLoadTimeout(): void;
        tick(): void;
        wrapOperation$zej000$fabric-events-interaction-v0$onPickItemFromBlock$mixinextras$bridge$151(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: boolean, arg4: $Operation, arg5: $LocalRef): $ItemStack;
        wrapOperation$zej000$fabric-events-interaction-v0$onPickItemFromBlock(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: boolean, arg4: $Operation, arg5: $ServerboundPickItemFromBlockPacket): $ItemStack;
        wrapOperation$zej000$fabric-events-interaction-v0$onPickItemFromEntity$mixinextras$bridge$152(arg0: $Entity, arg1: $Operation, arg2: $LocalRef): $ItemStack;
        wrapOperation$zej000$fabric-events-interaction-v0$onPickItemFromEntity(arg0: $Entity, arg1: $Operation, arg2: $ServerboundPickItemFromEntityPacket): $ItemStack;
    }

    export interface $ServerPlayerConnection {
        getPlayer(): $ServerPlayer;
        send(packet: $Packet<any>): void;
    }

    export interface $TextFilter {
        join(): void;
        leave(): void;
        processMessageBundle(messages: string[]): $CompletableFuture<$List<$FilteredText>>;
        processStreamMessage(message: string): $CompletableFuture<$FilteredText>;
        static DUMMY: $TextFilter;
    }

}
