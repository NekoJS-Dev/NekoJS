import { $JsonElement } from "java:com/google/gson";
import { $Codec, $DynamicOps } from "java:com/mojang/serialization";
import { $BufferedReader, $InputStream } from "java:java/io";
import { $AutoCloseable, $String, $Void } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Collection, $List, $Map, $Optional, $Set } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $ZipEntry, $ZipFile } from "java:java/util/zip";
import { $FabricResource } from "java:net/fabricmc/fabric/api/resource/v1";
import { $FileToIdConverter, $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $PackResources } from "java:net/minecraft/server/packs";
import { $MetadataSectionType, $MetadataSectionType$WithValue } from "java:net/minecraft/server/packs/metadata";
import { $KnownPack, $PackSource } from "java:net/minecraft/server/packs/repository";

declare module "java:net/minecraft/server/packs/resources" {
    export interface $CloseableResourceManager extends $ResourceManager, $AutoCloseable {
        close(): void;
    }

    export interface $IoSupplier<T> {
        create(path: string): $IoSupplier<$InputStream>;
        create(zipFile: $ZipFile, entry: $ZipEntry): $IoSupplier<$InputStream>;
        get(): T;
    }

    export interface $PreparableReloadListener {
        getName(): string;
        prepareSharedState(currentReload: $PreparableReloadListener$SharedState): void;
        reload(currentReload: $PreparableReloadListener$SharedState, taskExecutor: $Executor, preparationBarrier: $PreparableReloadListener$PreparationBarrier, reloadExecutor: $Executor): $CompletableFuture<void>;
    }

    export interface $PreparableReloadListener$PreparationBarrier {
        wait<T>(t: T): $CompletableFuture<T>;
    }

    export class $PreparableReloadListener$SharedState {
        constructor(manager: $ResourceManager);
        get<T>(key: $PreparableReloadListener$StateKey<T>): T;
        resourceManager(): $ResourceManager;
        set<T>(key: $PreparableReloadListener$StateKey<T>, value: T): void;
    }

    export class $PreparableReloadListener$StateKey<T> {
        constructor();
    }

    export class $Resource implements $FabricResource {
        constructor(source: $PackResources, streamSupplier: $IoSupplier<$InputStream>);
        constructor(source: $PackResources, streamSupplier: $IoSupplier<$InputStream>, metadataSupplier: $IoSupplier<$ResourceMetadata>);
        get fabricPackSource(): $PackSource;
        getFabricPackSource(): $PackSource;
        knownPackInfo(): $Optional<$KnownPack>;
        metadata(): $ResourceMetadata;
        openAsReader(): $BufferedReader;
        open(): $InputStream;
        sourcePackId(): string;
        source(): $PackResources;
    }

    export interface $ResourceManager extends $ResourceProvider {
        getNamespaces(): $Set<string>;
        getResourceStack(location: $Identifier_): $List<$Resource>;
        listPacks(): $Stream<$PackResources>;
        listResourceStacks(directory: string, filter: $Predicate<$Identifier_>): $Map<$Identifier, $List<$Resource>>;
        listResources(directory: string, filter: $Predicate<$Identifier_>): $Map<$Identifier, $Resource>;
    }

    export interface $ResourceMetadata {
        fromJsonStream(inputStream: $InputStream): $ResourceMetadata;
        getSection<T>(serializer: $MetadataSectionType<T>): $Optional<T>;
        getTypedSections(types: $MetadataSectionType<any>[]): $List<$MetadataSectionType$WithValue<any>>;
        getTypedSection<T>(type: $MetadataSectionType<T>): $Optional<$MetadataSectionType$WithValue<T>>;
        of<T1, T2>(k1: $MetadataSectionType<T1>, v1: T1, k2: $MetadataSectionType<T2>, v2: T2): $ResourceMetadata;
        of<T>(k: $MetadataSectionType<T>, v: T): $ResourceMetadata;
        static EMPTY: $ResourceMetadata;
        static EMPTY_SUPPLIER: $IoSupplier<$ResourceMetadata>;
    }

    export interface $ResourceProvider {
        fromMap(map: { [key: $Identifier_]: $Resource }): $ResourceProvider;
        getResourceOrThrow(location: $Identifier_): $Resource;
        getResource(location: $Identifier_): $Optional<$Resource>;
        openAsReader(location: $Identifier_): $BufferedReader;
        open(location: $Identifier_): $InputStream;
        static EMPTY: $ResourceProvider;
    }

    export class $SimpleJsonResourceReloadListener<T> extends $SimplePreparableReloadListener {
        static scanDirectory<T>(manager: $ResourceManager, lister: $FileToIdConverter, ops: $DynamicOps<$JsonElement>, codec: $Codec<T>, result: { [key: $Identifier_]: T }): void;
        static scanDirectory<T>(manager: $ResourceManager, registryKey: $ResourceKey<$Registry<T>>, ops: $DynamicOps<$JsonElement>, codec: $Codec<T>, result: { [key: $Identifier_]: T }): void;
    }

    export class $SimplePreparableReloadListener<T> implements $PreparableReloadListener {
        constructor();
        reload(currentReload: $PreparableReloadListener$SharedState, taskExecutor: $Executor, preparationBarrier: $PreparableReloadListener$PreparationBarrier, reloadExecutor: $Executor): $CompletableFuture<void>;
    }

}
