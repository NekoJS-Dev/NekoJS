import { $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity, $Mob } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as allay from "java:net/minecraft/world/entity/animal/allay";
export * as armadillo from "java:net/minecraft/world/entity/animal/armadillo";
export * as axolotl from "java:net/minecraft/world/entity/animal/axolotl";
export * as bee from "java:net/minecraft/world/entity/animal/bee";
export * as camel from "java:net/minecraft/world/entity/animal/camel";
export * as chicken from "java:net/minecraft/world/entity/animal/chicken";
export * as cow from "java:net/minecraft/world/entity/animal/cow";
export * as dolphin from "java:net/minecraft/world/entity/animal/dolphin";
export * as equine from "java:net/minecraft/world/entity/animal/equine";
export * as feline from "java:net/minecraft/world/entity/animal/feline";
export * as fish from "java:net/minecraft/world/entity/animal/fish";
export * as fox from "java:net/minecraft/world/entity/animal/fox";
export * as frog from "java:net/minecraft/world/entity/animal/frog";
export * as goat from "java:net/minecraft/world/entity/animal/goat";
export * as golem from "java:net/minecraft/world/entity/animal/golem";
export * as happyghast from "java:net/minecraft/world/entity/animal/happyghast";
export * as nautilus from "java:net/minecraft/world/entity/animal/nautilus";
export * as panda from "java:net/minecraft/world/entity/animal/panda";
export * as parrot from "java:net/minecraft/world/entity/animal/parrot";
export * as pig from "java:net/minecraft/world/entity/animal/pig";
export * as polarbear from "java:net/minecraft/world/entity/animal/polarbear";
export * as rabbit from "java:net/minecraft/world/entity/animal/rabbit";
export * as sheep from "java:net/minecraft/world/entity/animal/sheep";
export * as sniffer from "java:net/minecraft/world/entity/animal/sniffer";
export * as squid from "java:net/minecraft/world/entity/animal/squid";
export * as turtle from "java:net/minecraft/world/entity/animal/turtle";
export * as wolf from "java:net/minecraft/world/entity/animal/wolf";

declare module "java:net/minecraft/world/entity/animal" {
    export class $AgeableWaterCreature extends $AgeableMob {
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get pushedByFluid(): boolean;
        isPushedByFluid(): boolean;
        static checkSurfaceAgeableWaterCreatureSpawnRules(type: $EntityType<$AgeableWaterCreature>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        baseTick(): void;
        canBeLeashed(): boolean;
        checkSpawnObstruction(level: $LevelReader): boolean;
        getBaseExperienceReward(level: $ServerLevel): number;
    }

    export class $Animal extends $AgeableMob {
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get inLoveTime(): number;
        getInLoveTime(): number;
        set inLoveTime(value: number);
        get loveCause(): $ServerPlayer;
        getLoveCause(): $ServerPlayer;
        get inLove(): boolean;
        isInLove(): boolean;
        set inLove(value: $Player);
        static checkAnimalSpawnRules(type: $EntityType<$Animal>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAnimalAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canFallInLove(): boolean;
        canMate(partner: $Animal): boolean;
        finalizeSpawnChildFromBreeding(level: $ServerLevel, partner: $Animal, offspring: $AgeableMob): void;
        getDismountLocationForPassenger(passenger: $LivingEntity): $Vec3;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        handleEntityEvent(id: number): void;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        removeWhenFarAway(distSqr: number): boolean;
        resetLove(): void;
        spawnChildFromBreeding(level: $ServerLevel, partner: $Animal): void;
    }

    export interface $Bucketable {
        bucketMobPickup<T>(player: $Player, hand: $InteractionHand_, pickupEntity: T): $Optional<$InteractionResult>;
        fromBucket(): boolean;
        getBucketItemStack(): $ItemStack;
        getPickupSound(): $SoundEvent;
        loadDefaultDataFromBucketTag(entity: $Mob, tag: $CompoundTag_): void;
        loadFromBucketTag(tag: $CompoundTag_): void;
        saveDefaultDataToBucketTag(entity: $Mob, bucket: $ItemStack_): void;
        saveToBucketTag(bucket: $ItemStack_): void;
        setFromBucket(fromBucket: boolean): void;
    }

    export interface $FlyingAnimal {
        isFlying(): boolean;
    }

}
