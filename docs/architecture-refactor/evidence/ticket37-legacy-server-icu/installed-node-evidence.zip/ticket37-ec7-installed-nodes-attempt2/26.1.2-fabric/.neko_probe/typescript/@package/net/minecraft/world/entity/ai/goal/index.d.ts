import { $Enum, $String } from "java:java/lang";
import { $EnumSet, $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";

declare module "java:net/minecraft/world/entity/ai/goal" {
    export class $Goal {
        constructor();
        get flags(): $EnumSet<$Goal$Flag>;
        getFlags(): $EnumSet<$Goal$Flag>;
        set flags(value: $EnumSet<$Goal$Flag_>);
        get interruptable(): boolean;
        isInterruptable(): boolean;
        canContinueToUse(): boolean;
        canUse(): boolean;
        requiresUpdateEveryTick(): boolean;
        start(): void;
        stop(): void;
        tick(): void;
        toString(): string;
    }

    export class $Goal$Flag {
        static JUMP: $Goal$Flag;
        static LOOK: $Goal$Flag;
        static MOVE: $Goal$Flag;
        static TARGET: $Goal$Flag;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Goal$Flag[];
        static valueOf(name: string): $Goal$Flag;
    }

    export class $GoalSelector {
        constructor();
        get availableGoals(): $Set<$WrappedGoal>;
        getAvailableGoals(): $Set<$WrappedGoal>;
        addGoal(prio: number, goal: $Goal): void;
        disableControlFlag(flag: $Goal$Flag_): void;
        enableControlFlag(flag: $Goal$Flag_): void;
        removeAllGoals(predicate: $Predicate<$Goal>): void;
        removeGoal(toRemove: $Goal): void;
        setControlFlag(flag: $Goal$Flag_, enabled: boolean): void;
        tickRunningGoals(forceTickAllRunningGoals: boolean): void;
        tick(): void;
    }

    export class $WrappedGoal extends $Goal {
        constructor(priority: number, goal: $Goal);
        get flags(): $EnumSet<$Goal$Flag>;
        getFlags(): $EnumSet<$Goal$Flag>;
        set flags(value: $EnumSet<$Goal$Flag_>);
        get goal(): $Goal;
        getGoal(): $Goal;
        get priority(): number;
        getPriority(): number;
        get interruptable(): boolean;
        isInterruptable(): boolean;
        get running(): boolean;
        isRunning(): boolean;
        canBeReplacedBy(goal: $WrappedGoal): boolean;
        canContinueToUse(): boolean;
        canUse(): boolean;
        equals(o: object): boolean;
        hashCode(): number;
        requiresUpdateEveryTick(): boolean;
        start(): void;
        stop(): void;
        tick(): void;
    }

    export type $Goal$Flag_ = $Goal$Flag | "JUMP" | "LOOK" | "MOVE" | "TARGET";
}
