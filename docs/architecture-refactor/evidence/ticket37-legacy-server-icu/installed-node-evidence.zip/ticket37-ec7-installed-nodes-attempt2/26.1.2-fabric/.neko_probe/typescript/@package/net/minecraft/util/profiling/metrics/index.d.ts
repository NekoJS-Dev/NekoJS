import { $Enum, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Consumer, $DoubleSupplier, $ToDoubleFunction } from "java:java/util/function";

declare module "java:net/minecraft/util/profiling/metrics" {
    export class $MetricCategory {
        static CHUNK_RENDERING: $MetricCategory;
        static CHUNK_RENDERING_DISPATCHING: $MetricCategory;
        static CONSECUTIVE_EXECUTORS: $MetricCategory;
        static CPU: $MetricCategory;
        static EVENT_LOOPS: $MetricCategory;
        static GPU: $MetricCategory;
        static JVM: $MetricCategory;
        static PATH_FINDING: $MetricCategory;
        static TICK_LOOP: $MetricCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MetricCategory[];
        static valueOf(name: string): $MetricCategory;
    }

    export class $MetricSampler {
        get category(): $MetricCategory;
        getCategory(): $MetricCategory;
        get name(): string;
        getName(): string;
        static builder<T>(metricName: string, category: $MetricCategory_, sampler: $ToDoubleFunction<T>, context: T): $MetricSampler$MetricSamplerBuilder<T>;
        static create<T>(metricName: string, category: $MetricCategory_, context: T, sampler: $ToDoubleFunction<T>): $MetricSampler;
        static create(name: string, category: $MetricCategory_, sampler: $DoubleSupplier): $MetricSampler;
        equals(o: object): boolean;
        hashCode(): number;
        onEndTick(currentTick: number): void;
        onFinished(): void;
        onStartTick(): void;
        result(): $MetricSampler$SamplerResult;
        triggersThreshold(): boolean;
    }

    export class $MetricSampler$MetricSamplerBuilder<T> {
        constructor(name: string, category: $MetricCategory_, sampler: $ToDoubleFunction<T>, context: T);
        build(): $MetricSampler;
        withBeforeTick(beforeTick: $Consumer<T>): $MetricSampler$MetricSamplerBuilder<T>;
        withThresholdAlert(thresholdTest: $MetricSampler$ThresholdTest): $MetricSampler$MetricSamplerBuilder<T>;
    }

    export class $MetricSampler$SamplerResult {
        constructor(firstTick: number, lastTick: number, recording: $Int2DoubleMap);
        get firstTick(): number;
        getFirstTick(): number;
        get lastTick(): number;
        getLastTick(): number;
        valueAtTick(tick: number): number;
    }

    export interface $ProfilerMeasured {
        profiledMetrics(): $List<$MetricSampler>;
    }

    export type $MetricCategory_ = $MetricCategory | "CHUNK_RENDERING" | "CHUNK_RENDERING_DISPATCHING" | "CONSECUTIVE_EXECUTORS" | "CPU" | "EVENT_LOOPS" | "GPU" | "JVM" | "PATH_FINDING" | "TICK_LOOP";
}
