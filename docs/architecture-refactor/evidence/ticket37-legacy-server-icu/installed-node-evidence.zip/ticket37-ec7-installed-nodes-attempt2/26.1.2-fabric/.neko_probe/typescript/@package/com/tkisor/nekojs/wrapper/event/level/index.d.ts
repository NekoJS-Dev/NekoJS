import { $ServerLevel } from "java:net/minecraft/server/level";

declare module "java:com/tkisor/nekojs/wrapper/event/level" {
    export class $LevelEventJS {
        constructor(level: $ServerLevel);
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
    }

}
