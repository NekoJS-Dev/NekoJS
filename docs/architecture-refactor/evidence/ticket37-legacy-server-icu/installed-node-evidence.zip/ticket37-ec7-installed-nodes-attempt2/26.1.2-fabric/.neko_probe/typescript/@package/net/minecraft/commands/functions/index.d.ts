import { $CommandDispatcher, $StringReader } from "java:com/mojang/brigadier";
import { $CharSequence, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $UnboundEntryAction } from "java:net/minecraft/commands/execution";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/commands/functions" {
    export interface $CommandFunction<T> {
        checkCommandLineLength(line: $CharSequence): void;
        fromLines<T>(id: $Identifier_, dispatcher: $CommandDispatcher<T>, compilationContext: T, lines: string[]): $CommandFunction<T>;
        id(): $Identifier;
        instantiate(arguments_: $CompoundTag_, dispatcher: $CommandDispatcher<T>): $InstantiatedFunction<T>;
        parseCommand<T>(dispatcher: $CommandDispatcher<T>, compilationContext: T, input: $StringReader): $UnboundEntryAction<T>;
    }

    export interface $InstantiatedFunction<T> {
        entries(): $List<$UnboundEntryAction<T>>;
        id(): $Identifier;
    }

}
