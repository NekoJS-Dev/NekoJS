import { $InputStream } from "java:java/io";
import { $AutoCloseable, $Enum, $Record, $String } from "java:java/lang";
import { $Optional, $Set } from "java:java/util";
import { $BiConsumer } from "java:java/util/function";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $MetadataSectionType } from "java:net/minecraft/server/packs/metadata";
import { $KnownPack, $Pack$Position, $Pack$Position_, $PackSource } from "java:net/minecraft/server/packs/repository";
import { $IoSupplier } from "java:net/minecraft/server/packs/resources";

export * as metadata from "java:net/minecraft/server/packs/metadata";
export * as repository from "java:net/minecraft/server/packs/repository";
export * as resources from "java:net/minecraft/server/packs/resources";

declare module "java:net/minecraft/server/packs" {
    export class $PackLocationInfo extends $Record {
        constructor(id: string, title: $Component_, source: $PackSource, knownPackInfo: $Optional<$KnownPack>);
        createChatLink(enabled: boolean, description: $Component_): $Component;
        equals(o: object): boolean;
        hashCode(): number;
        id(): string;
        knownPackInfo(): $Optional<$KnownPack>;
        source(): $PackSource;
        title(): $Component;
        toString(): string;
    }

    export interface $PackResources extends $AutoCloseable {
        close(): void;
        getMetadataSection<T>(metadataSerializer: $MetadataSectionType<T>): T;
        getNamespaces(type: $PackType_): $Set<string>;
        getResource(type: $PackType_, location: $Identifier_): $IoSupplier<$InputStream>;
        getRootResource(path?: string[]): $IoSupplier<$InputStream>;
        knownPackInfo(): $Optional<$KnownPack>;
        listResources(type: $PackType_, namespace: string, directory: string, output: $PackResources$ResourceOutput): void;
        location(): $PackLocationInfo;
        packId(): string;
        static METADATA_EXTENSION: string;
        static PACK_META: string;
    }

    export interface $PackResources$ResourceOutput extends $BiConsumer {
    }

    export class $PackSelectionConfig extends $Record {
        constructor(required: boolean, defaultPosition: $Pack$Position_, fixedPosition: boolean);
        defaultPosition(): $Pack$Position;
        equals(o: object): boolean;
        fixedPosition(): boolean;
        hashCode(): number;
        required(): boolean;
        toString(): string;
    }

    export class $PackType {
        static CLIENT_RESOURCES: $PackType;
        static SERVER_DATA: $PackType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PackType[];
        static valueOf(name: string): $PackType;
    }

    export type $PackType_ = $PackType | "CLIENT_RESOURCES" | "SERVER_DATA";
}
