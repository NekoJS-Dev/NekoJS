import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $EntityReference, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity, $NeutralMob, $SpawnGroupData, $TamableAnimal } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $TargetingConditions$Selector } from "java:net/minecraft/world/entity/ai/targeting";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $DyeColor, $DyeColor_, $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/wolf" {
    export class $Wolf extends $TamableAnimal implements $NeutralMob {
        constructor(type: $EntityType<$Wolf>, level: $Level);
        static DEFAULT_TAIL_ANGLE: number;
        static PREY_SELECTOR: $TargetingConditions$Selector;
        get collarColor(): $DyeColor;
        getCollarColor(): $DyeColor;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get maxHeadXRot(): number;
        getMaxHeadXRot(): number;
        get maxSpawnClusterSize(): number;
        getMaxSpawnClusterSize(): number;
        get persistentAngerEndTime(): number;
        getPersistentAngerEndTime(): number;
        set persistentAngerEndTime(value: number);
        get persistentAngerTarget(): $EntityReference<$LivingEntity>;
        getPersistentAngerTarget(): $EntityReference<$LivingEntity>;
        set persistentAngerTarget(value: $EntityReference<$LivingEntity>);
        get tailAngle(): number;
        getTailAngle(): number;
        get texture(): $Identifier;
        getTexture(): $Identifier;
        get interested(): boolean;
        isInterested(): boolean;
        static checkWolfSpawnRules(type: $EntityType<$Wolf>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canBeLeashed(): boolean;
        canMate(partner: $Animal): boolean;
        die(source: $DamageSource): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Wolf;
        getHeadRollAngle(a: number): number;
        getShakeAnim(a: number): number;
        getWetShade(a: number): number;
        get<T>(type: $DataComponentType<T>): T;
        handleEntityEvent(id: number): void;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        startPersistentAngerTimer(): void;
        tick(): void;
        wantsToAttack(target: $LivingEntity, owner: $LivingEntity): boolean;
    }

    export class $WolfSoundVariant extends $Record {
        constructor(adultSounds: $WolfSoundVariant$WolfSoundSet, babySounds: $WolfSoundVariant$WolfSoundSet);
        static CODEC: $Codec<$Holder<$WolfSoundVariant>>;
        static DIRECT_CODEC: $Codec<$WolfSoundVariant>;
        static NETWORK_CODEC: $Codec<$WolfSoundVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$WolfSoundVariant>>;
        adultSounds(): $WolfSoundVariant$WolfSoundSet;
        babySounds(): $WolfSoundVariant$WolfSoundSet;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $WolfSoundVariant$WolfSoundSet extends $Record {
        constructor(ambientSound: $Holder<$SoundEvent_>, deathSound: $Holder<$SoundEvent_>, growlSound: $Holder<$SoundEvent_>, hurtSound: $Holder<$SoundEvent_>, pantSound: $Holder<$SoundEvent_>, whineSound: $Holder<$SoundEvent_>, stepSound: $Holder<$SoundEvent_>);
        static CODEC: $Codec<$WolfSoundVariant$WolfSoundSet>;
        ambientSound(): $Holder<$SoundEvent>;
        deathSound(): $Holder<$SoundEvent>;
        equals(o: object): boolean;
        growlSound(): $Holder<$SoundEvent>;
        hashCode(): number;
        hurtSound(): $Holder<$SoundEvent>;
        pantSound(): $Holder<$SoundEvent>;
        stepSound(): $Holder<$SoundEvent>;
        toString(): string;
        whineSound(): $Holder<$SoundEvent>;
    }

    export class $WolfSoundVariants$SoundSet {
        static ANGRY: $WolfSoundVariants$SoundSet;
        static BIG: $WolfSoundVariants$SoundSet;
        static CLASSIC: $WolfSoundVariants$SoundSet;
        static CUTE: $WolfSoundVariants$SoundSet;
        static GRUMPY: $WolfSoundVariants$SoundSet;
        static PUGLIN: $WolfSoundVariants$SoundSet;
        static SAD: $WolfSoundVariants$SoundSet;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $WolfSoundVariants$SoundSet[];
        static valueOf(name: string): $WolfSoundVariants$SoundSet;
    }

    export type $WolfSoundVariants$SoundSet_ = $WolfSoundVariants$SoundSet | "ANGRY" | "BIG" | "CLASSIC" | "CUTE" | "GRUMPY" | "PUGLIN" | "SAD";
}
