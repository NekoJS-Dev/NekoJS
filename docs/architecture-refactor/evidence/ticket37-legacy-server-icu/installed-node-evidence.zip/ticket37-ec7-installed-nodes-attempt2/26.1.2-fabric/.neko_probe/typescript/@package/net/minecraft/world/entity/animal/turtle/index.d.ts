import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $AgeableMob, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LightningBolt, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $TargetingConditions$Selector } from "java:net/minecraft/world/entity/ai/targeting";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/turtle" {
    export class $Turtle extends $Animal {
        constructor(type: $EntityType<$Turtle>, level: $Level);
        static BABY_ON_LAND_SELECTOR: $TargetingConditions$Selector;
        get ageScale(): number;
        getAgeScale(): number;
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get layingEgg(): boolean;
        isLayingEgg(): boolean;
        get pushedByFluid(): boolean;
        isPushedByFluid(): boolean;
        static checkTurtleSpawnRules(type: $EntityType<$Turtle>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canBeLeashed(): boolean;
        canFallInLove(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        hasEgg(): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        thunderHit(level: $ServerLevel, lightningBolt: $LightningBolt): void;
    }

}
