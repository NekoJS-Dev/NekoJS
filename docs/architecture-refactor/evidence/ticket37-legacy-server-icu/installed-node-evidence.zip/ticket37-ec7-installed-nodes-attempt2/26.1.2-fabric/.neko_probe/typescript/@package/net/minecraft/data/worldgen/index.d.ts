import { $Lifecycle } from "java:com/mojang/serialization";
import { $Holder$Reference, $HolderGetter } from "java:net/minecraft/core";
import { $ResourceKey } from "java:net/minecraft/resources";

declare module "java:net/minecraft/data/worldgen" {
    export interface $BootstrapContext<T> {
        lookup<S>(key: $ResourceKey<$Registry<S>>): $HolderGetter<S>;
        register(key: $ResourceKey<T>, value: T, lifecycle: $Lifecycle): $Holder$Reference<T>;
        register(key: $ResourceKey<T>, value: T): $Holder$Reference<T>;
    }

}
