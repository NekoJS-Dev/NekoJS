import { $AutoCloseable, $Runnable, $String, $Throwable, $Void } from "java:java/lang";
import { $List } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $BooleanSupplier, $Consumer, $Supplier } from "java:java/util/function";
import { $CrashReport } from "java:net/minecraft";
import { $MetricSampler, $ProfilerMeasured } from "java:net/minecraft/util/profiling/metrics";

declare module "java:net/minecraft/util/thread" {
    export class $AbstractConsecutiveExecutor<T extends $Runnable> implements $Runnable, $TaskScheduler, $ProfilerMeasured {
        constructor(queue: $StrictQueue<T>, executor: $Executor, name: string);
        close(): void;
        hasWork(): boolean;
        name(): string;
        profiledMetrics(): $List<$MetricSampler>;
        runAll(): void;
        run(): void;
        schedule(task: T): void;
        size(): number;
        toString(): string;
    }

    export class $BlockableEventLoop<R extends $Runnable> implements $Executor, $TaskScheduler, $ProfilerMeasured {
        static BLOCK_TIME_NANOS: number;
        get pendingTasksCount(): number;
        getPendingTasksCount(): number;
        get sameThread(): boolean;
        isSameThread(): boolean;
        static isNonRecoverable(t: $Throwable): boolean;
        static relayDelayCrash(crashReport: $CrashReport): void;
        delayCrash(crashReport: $CrashReport): void;
        executeBlocking(runnable: $Runnable): void;
        executeIfPossible(command: $Runnable): void;
        execute(command: $Runnable): void;
        managedBlock(condition: $BooleanSupplier): void;
        name(): string;
        profiledMetrics(): $List<$MetricSampler>;
        schedule(r: R): void;
        submit(runnable: $Runnable): $CompletableFuture<void>;
        submit<V>(supplier: $Supplier<V>): $CompletableFuture<V>;
    }

    export class $ConsecutiveExecutor extends $AbstractConsecutiveExecutor {
        constructor(dispatcher: $Executor, name: string);
        wrapRunnable(runnable: $Runnable): $Runnable;
    }

    export class $ReentrantBlockableEventLoop<R extends $Runnable> extends $BlockableEventLoop {
        constructor(name: string, propagatesCrashes: boolean);
    }

    export interface $TaskScheduler<R extends $Runnable> extends $AutoCloseable {
        close(): void;
        name(): string;
        scheduleWithResult<Source>(futureConsumer: $Consumer<$CompletableFuture<Source>>): $CompletableFuture<Source>;
        schedule(r: R): void;
        wrapExecutor(name: string, executor: $Executor): $TaskScheduler<$Runnable>;
        wrapRunnable(runnable: $Runnable): R;
    }

}
