import { $Codec, $DynamicOps, $MapCodec } from "java:com/mojang/serialization";
import { $DataInput, $DataOutput } from "java:java/io";
import { $Boolean, $Byte, $Double, $Enum, $Float, $Integer, $Iterable, $Long, $Number, $Record, $Short, $String, $StringBuilder } from "java:java/lang";
import { $AbstractList, $Collection, $Iterator, $Map$Entry, $Optional, $Set } from "java:java/util";
import { $BiConsumer } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";

declare module "java:net/minecraft/nbt" {
    export class $ByteArrayTag implements $CollectionTag {
        constructor(data: number[]);
        static TYPE: $TagType<$ByteArrayTag>;
        get asByteArray(): number[];
        getAsByteArray(): number[];
        get id(): number;
        getId(): number;
        get type(): $TagType<$ByteArrayTag>;
        getType(): $TagType<$ByteArrayTag>;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        addTag(index: number, tag: $Tag): boolean;
        asByteArray(): $Optional<number[]>;
        clear(): void;
        copy(): $Tag;
        equals(obj: object): boolean;
        get(index: number): $ByteTag;
        hashCode(): number;
        remove(index: number): $ByteTag;
        setTag(index: number, tag: $Tag): boolean;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(output: $DataOutput): void;
    }

    export class $ByteTag extends $Record implements $NumericTag {
        constructor(value: number);
        static ONE: $ByteTag;
        static TYPE: $TagType<$ByteTag>;
        static ZERO: $ByteTag;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ByteTag>;
        getType(): $TagType<$ByteTag>;
        static valueOf(data: boolean): $ByteTag;
        static valueOf(data: number): $ByteTag;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $ByteTag;
        doubleValue(): number;
        equals(o: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(output: $DataOutput): void;
    }

    export interface $CollectionTag extends $Tag, $Iterable {
        addTag(index: number, tag: $Tag): boolean;
        clear(): void;
        get(index: number): $Tag;
        isEmpty(): boolean;
        iterator(): $Iterator<$Tag>;
        remove(index: number): $Tag;
        setTag(index: number, tag: $Tag): boolean;
        size(): number;
        stream(): $Stream<$Tag>;
    }

    export class $CompoundTag implements $Tag {
        constructor();
        static CODEC: $Codec<$CompoundTag>;
        static TYPE: $TagType<$CompoundTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$CompoundTag>;
        getType(): $TagType<$CompoundTag>;
        get empty(): boolean;
        isEmpty(): boolean;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        asCompound(): $Optional<$CompoundTag>;
        contains(name: string): boolean;
        copy(): $CompoundTag;
        entrySet(): $Set<$Map$Entry<string, $Tag>>;
        equals(obj: object): boolean;
        forEach(consumer: $BiConsumer<string, $Tag>): void;
        getBooleanOr(string: string, defaultValue: boolean): boolean;
        getBoolean(name: string): $Optional<boolean>;
        getByteArray(name: string): $Optional<number[]>;
        getByteOr(name: string, defaultValue: number): number;
        getByte(name: string): $Optional<number>;
        getCompoundOrEmpty(name: string): $CompoundTag;
        getCompound(name: string): $Optional<$CompoundTag>;
        getDoubleOr(name: string, defaultValue: number): number;
        getDouble(name: string): $Optional<number>;
        getFloatOr(name: string, defaultValue: number): number;
        getFloat(name: string): $Optional<number>;
        getIntArray(name: string): $Optional<number[]>;
        getIntOr(name: string, defaultValue: number): number;
        getInt(name: string): $Optional<number>;
        getListOrEmpty(name: string): $ListTag;
        getList(name: string): $Optional<$ListTag>;
        getLongArray(name: string): $Optional<number[]>;
        getLongOr(name: string, defaultValue: number): number;
        getLong(name: string): $Optional<number>;
        getShortOr(name: string, defaultValue: number): number;
        getShort(name: string): $Optional<number>;
        getStringOr(name: string, defaultValue: string): string;
        getString(name: string): $Optional<string>;
        get(name: string): $Tag;
        hashCode(): number;
        keySet(): $Set<string>;
        merge(other: $CompoundTag_): $CompoundTag;
        putBoolean(name: string, value: boolean): void;
        putByteArray(name: string, value: number[]): void;
        putByte(name: string, value: number): void;
        putDouble(name: string, value: number): void;
        putFloat(name: string, value: number): void;
        putIntArray(name: string, value: number[]): void;
        putInt(name: string, value: number): void;
        putLongArray(name: string, value: number[]): void;
        putLong(name: string, value: number): void;
        putShort(name: string, value: number): void;
        putString(name: string, value: string): void;
        put(name: string, tag: $Tag): $Tag;
        read<T>(codec: $MapCodec<T>, ops: $DynamicOps<$Tag>): $Optional<T>;
        read<T>(codec: $MapCodec<T>): $Optional<T>;
        read<T>(name: string, codec: $Codec<T>, ops: $DynamicOps<$Tag>): $Optional<T>;
        read<T>(name: string, codec: $Codec<T>): $Optional<T>;
        remove(name: string): $Tag;
        sizeInBytes(): number;
        size(): number;
        storeNullable<T>(name: string, codec: $Codec<T>, value: T): void;
        storeNullable<T>(name: string, codec: $Codec<T>, ops: $DynamicOps<$Tag>, value: T): void;
        store<T>(codec: $MapCodec<T>, value: T): void;
        store<T>(codec: $MapCodec<T>, ops: $DynamicOps<$Tag>, value: T): void;
        store<T>(name: string, codec: $Codec<T>, value: T): void;
        store<T>(name: string, codec: $Codec<T>, ops: $DynamicOps<$Tag>, value: T): void;
        toString(): string;
        values(): $Collection<$Tag>;
        write(output: $DataOutput): void;
    }

    export class $DoubleTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$DoubleTag>;
        static ZERO: $DoubleTag;
        get id(): number;
        getId(): number;
        get type(): $TagType<$DoubleTag>;
        getType(): $TagType<$DoubleTag>;
        static valueOf(data: number): $DoubleTag;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $DoubleTag;
        doubleValue(): number;
        equals(o: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(output: $DataOutput): void;
    }

    export class $EndTag implements $Tag {
        static INSTANCE: $EndTag;
        static TYPE: $TagType<$EndTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$EndTag>;
        getType(): $TagType<$EndTag>;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        copy(): $EndTag;
        sizeInBytes(): number;
        toString(): string;
        write(output: $DataOutput): void;
    }

    export class $FloatTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$FloatTag>;
        static ZERO: $FloatTag;
        get id(): number;
        getId(): number;
        get type(): $TagType<$FloatTag>;
        getType(): $TagType<$FloatTag>;
        static valueOf(data: number): $FloatTag;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $FloatTag;
        doubleValue(): number;
        equals(o: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(output: $DataOutput): void;
    }

    export class $IntArrayTag implements $CollectionTag {
        constructor(data: number[]);
        static TYPE: $TagType<$IntArrayTag>;
        get asIntArray(): number[];
        getAsIntArray(): number[];
        get id(): number;
        getId(): number;
        get type(): $TagType<$IntArrayTag>;
        getType(): $TagType<$IntArrayTag>;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        addTag(index: number, tag: $Tag): boolean;
        asIntArray(): $Optional<number[]>;
        clear(): void;
        copy(): $IntArrayTag;
        equals(obj: object): boolean;
        get(index: number): $IntTag;
        hashCode(): number;
        remove(index: number): $IntTag;
        setTag(index: number, tag: $Tag): boolean;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(output: $DataOutput): void;
    }

    export class $IntTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$IntTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$IntTag>;
        getType(): $TagType<$IntTag>;
        static valueOf(i: number): $IntTag;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $IntTag;
        doubleValue(): number;
        equals(o: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(output: $DataOutput): void;
    }

    export class $ListTag extends $AbstractList implements $CollectionTag {
        constructor();
        static TYPE: $TagType<$ListTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ListTag>;
        getType(): $TagType<$ListTag>;
        get empty(): boolean;
        isEmpty(): boolean;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        addAndUnwrap(tag: $Tag): void;
        addTag(index: number, tag: $Tag): boolean;
        add(index: number, tag: $Tag): void;
        asList(): $Optional<$ListTag>;
        clear(): void;
        compoundStream(): $Stream<$CompoundTag>;
        copy(): $ListTag;
        equals(obj: object): boolean;
        getCompoundOrEmpty(index: number): $CompoundTag;
        getCompound(index: number): $Optional<$CompoundTag>;
        getDoubleOr(index: number, defaultValue: number): number;
        getDouble(index: number): $Optional<number>;
        getFloatOr(index: number, defaultValue: number): number;
        getFloat(index: number): $Optional<number>;
        getIntArray(index: number): $Optional<number[]>;
        getIntOr(index: number, defaultValue: number): number;
        getInt(index: number): $Optional<number>;
        getListOrEmpty(index: number): $ListTag;
        getList(index: number): $Optional<$ListTag>;
        getLongArray(index: number): $Optional<number[]>;
        getShortOr(index: number, defaultValue: number): number;
        getShort(index: number): $Optional<number>;
        getStringOr(index: number, defaultValue: string): string;
        getString(index: number): $Optional<string>;
        get(index: number): $Tag;
        hashCode(): number;
        remove(index: number): $Tag;
        setTag(index: number, tag: $Tag): boolean;
        set(index: number, tag: $Tag): $Tag;
        sizeInBytes(): number;
        size(): number;
        stream(): $Stream<$Tag>;
        toString(): string;
        write(output: $DataOutput): void;
    }

    export class $LongArrayTag implements $CollectionTag {
        constructor(data: number[]);
        static TYPE: $TagType<$LongArrayTag>;
        get asLongArray(): number[];
        getAsLongArray(): number[];
        get id(): number;
        getId(): number;
        get type(): $TagType<$LongArrayTag>;
        getType(): $TagType<$LongArrayTag>;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        addTag(index: number, tag: $Tag): boolean;
        asLongArray(): $Optional<number[]>;
        clear(): void;
        copy(): $LongArrayTag;
        equals(obj: object): boolean;
        get(index: number): $LongTag;
        hashCode(): number;
        remove(index: number): $LongTag;
        setTag(index: number, tag: $Tag): boolean;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(output: $DataOutput): void;
    }

    export class $LongTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$LongTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$LongTag>;
        getType(): $TagType<$LongTag>;
        static valueOf(i: number): $LongTag;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $LongTag;
        doubleValue(): number;
        equals(o: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(output: $DataOutput): void;
    }

    export class $NbtAccounter {
        constructor(quota: number, maxDepth: number);
        static DEFAULT_NBT_QUOTA: number;
        static UNCOMPRESSED_NBT_QUOTA: number;
        get depth(): number;
        getDepth(): number;
        get usage(): number;
        getUsage(): number;
        static create(quota: number): $NbtAccounter;
        static defaultQuota(): $NbtAccounter;
        static uncompressedQuota(): $NbtAccounter;
        static unlimitedHeap(): $NbtAccounter;
        accountBytes(bytesPerEntry: number, count: number): void;
        accountBytes(size: number): void;
        popDepth(): void;
        pushDepth(): void;
    }

    export interface $NumericTag extends $PrimitiveTag {
        asBoolean(): $Optional<boolean>;
        asByte(): $Optional<number>;
        asDouble(): $Optional<number>;
        asFloat(): $Optional<number>;
        asInt(): $Optional<number>;
        asLong(): $Optional<number>;
        asNumber(): $Optional<number>;
        asShort(): $Optional<number>;
        box(): number;
        byteValue(): number;
        doubleValue(): number;
        floatValue(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
    }

    export interface $PrimitiveTag extends $Tag {
        copy(): $Tag;
    }

    export class $ShortTag extends $Record implements $NumericTag {
        constructor(value: number);
        static TYPE: $TagType<$ShortTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ShortTag>;
        getType(): $TagType<$ShortTag>;
        static valueOf(i: number): $ShortTag;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        box(): number;
        byteValue(): number;
        copy(): $ShortTag;
        doubleValue(): number;
        equals(o: object): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        shortValue(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): number;
        write(output: $DataOutput): void;
    }

    export interface $StreamTagVisitor {
        visitContainerEnd(): $StreamTagVisitor$ValueResult;
        visitElement(type: $TagType<any>, index: number): $StreamTagVisitor$EntryResult;
        visitEnd(): $StreamTagVisitor$ValueResult;
        visitEntry(type: $TagType<any>, id: string): $StreamTagVisitor$EntryResult;
        visitEntry(type: $TagType<any>): $StreamTagVisitor$EntryResult;
        visitList(elementType: $TagType<any>, size: number): $StreamTagVisitor$ValueResult;
        visitRootEntry(type: $TagType<any>): $StreamTagVisitor$ValueResult;
        visit(value: number[]): $StreamTagVisitor$ValueResult;
        visit(value: number): $StreamTagVisitor$ValueResult;
        visit(value: number): $StreamTagVisitor$ValueResult;
        visit(value: number): $StreamTagVisitor$ValueResult;
        visit(value: number[]): $StreamTagVisitor$ValueResult;
        visit(value: number): $StreamTagVisitor$ValueResult;
        visit(value: string): $StreamTagVisitor$ValueResult;
        visit(value: number[]): $StreamTagVisitor$ValueResult;
        visit(value: number): $StreamTagVisitor$ValueResult;
        visit(value: number): $StreamTagVisitor$ValueResult;
    }

    export class $StreamTagVisitor$EntryResult {
        static BREAK: $StreamTagVisitor$EntryResult;
        static ENTER: $StreamTagVisitor$EntryResult;
        static HALT: $StreamTagVisitor$EntryResult;
        static SKIP: $StreamTagVisitor$EntryResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StreamTagVisitor$EntryResult[];
        static valueOf(name: string): $StreamTagVisitor$EntryResult;
    }

    export class $StreamTagVisitor$ValueResult {
        static BREAK: $StreamTagVisitor$ValueResult;
        static CONTINUE: $StreamTagVisitor$ValueResult;
        static HALT: $StreamTagVisitor$ValueResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StreamTagVisitor$ValueResult[];
        static valueOf(name: string): $StreamTagVisitor$ValueResult;
    }

    export class $StringTag extends $Record implements $PrimitiveTag {
        constructor(value: string);
        static TYPE: $TagType<$StringTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$StringTag>;
        getType(): $TagType<$StringTag>;
        static escapeWithoutQuotes(input: string, result: $StringBuilder): void;
        static escapeWithoutQuotes(input: string): string;
        static quoteAndEscape(input: string, result: $StringBuilder): void;
        static quoteAndEscape(input: string): string;
        static skipString(input: $DataInput): void;
        static valueOf(data: string): $StringTag;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        asString(): $Optional<string>;
        copy(): $StringTag;
        equals(o: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        toString(): string;
        value(): string;
        write(output: $DataOutput): void;
    }

    export interface $Tag {
        acceptAsRoot(output: $StreamTagVisitor): void;
        accept(visitor: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(visitor: $TagVisitor): void;
        asBoolean(): $Optional<boolean>;
        asByteArray(): $Optional<number[]>;
        asByte(): $Optional<number>;
        asCompound(): $Optional<$CompoundTag>;
        asDouble(): $Optional<number>;
        asFloat(): $Optional<number>;
        asIntArray(): $Optional<number[]>;
        asInt(): $Optional<number>;
        asList(): $Optional<$ListTag>;
        asLongArray(): $Optional<number[]>;
        asLong(): $Optional<number>;
        asNumber(): $Optional<number>;
        asShort(): $Optional<number>;
        asString(): $Optional<string>;
        copy(): $Tag;
        getId(): number;
        getType(): $TagType<any>;
        sizeInBytes(): number;
        toString(): string;
        write(output: $DataOutput): void;
        static ARRAY_HEADER: number;
        static MAX_DEPTH: number;
        static OBJECT_HEADER: number;
        static OBJECT_REFERENCE: number;
        static STRING_SIZE: number;
        static TAG_BYTE: number;
        static TAG_BYTE_ARRAY: number;
        static TAG_COMPOUND: number;
        static TAG_DOUBLE: number;
        static TAG_END: number;
        static TAG_FLOAT: number;
        static TAG_INT: number;
        static TAG_INT_ARRAY: number;
        static TAG_LIST: number;
        static TAG_LONG: number;
        static TAG_LONG_ARRAY: number;
        static TAG_SHORT: number;
        static TAG_STRING: number;
    }

    export interface $TagType<T extends $Tag> {
        createInvalid(id: number): $TagType<$EndTag>;
        getName(): string;
        getPrettyName(): string;
        load(input: $DataInput, accounter: $NbtAccounter): T;
        parseRoot(input: $DataInput, output: $StreamTagVisitor, accounter: $NbtAccounter): void;
        parse(input: $DataInput, output: $StreamTagVisitor, accounter: $NbtAccounter): $StreamTagVisitor$ValueResult;
        skip(input: $DataInput, count: number, accounter: $NbtAccounter): void;
        skip(input: $DataInput, accounter: $NbtAccounter): void;
    }

    export interface $TagVisitor {
        visitByteArray(tag: $ByteArrayTag): void;
        visitByte(tag: $ByteTag): void;
        visitCompound(tag: $CompoundTag_): void;
        visitDouble(tag: $DoubleTag): void;
        visitEnd(tag: $EndTag): void;
        visitFloat(tag: $FloatTag): void;
        visitIntArray(tag: $IntArrayTag): void;
        visitInt(tag: $IntTag): void;
        visitList(tag: $ListTag): void;
        visitLongArray(tag: $LongArrayTag): void;
        visitLong(tag: $LongTag): void;
        visitShort(tag: $ShortTag): void;
        visitString(tag: $StringTag): void;
    }

    export type $CompoundTag_ = $CompoundTag | { [key: string]: any };
    export type $StreamTagVisitor$EntryResult_ = $StreamTagVisitor$EntryResult | "BREAK" | "ENTER" | "HALT" | "SKIP";
    export type $StreamTagVisitor$ValueResult_ = $StreamTagVisitor$ValueResult | "BREAK" | "CONTINUE" | "HALT";
}
