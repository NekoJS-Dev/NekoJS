import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener, $ClientboundAddEntityPacket } from "java:net/minecraft/network/protocol/game";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $ServerEntity, $ServerLevel } from "java:net/minecraft/server/level";
import { $Entity } from "java:net/minecraft/world/entity";
import { $HangingEntity } from "java:net/minecraft/world/entity/decoration";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Level } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/decoration/painting" {
    export class $Painting extends $HangingEntity {
        constructor(type: $EntityType<$Painting>, level: $Level);
        constructor(level: $Level, blockPos: $BlockPos_, direction: $Direction_, variant: $Holder<$PaintingVariant>);
        static DEPTH: number;
        get pickResult(): $ItemStack;
        getPickResult(): $ItemStack;
        get variant(): $Holder<$PaintingVariant>;
        getVariant(): $Holder<$PaintingVariant>;
        static create(level: $Level, pos: $BlockPos_, direction: $Direction_): $Optional<$Painting>;
        dropItem(level: $ServerLevel, causedBy: $Entity): void;
        getAddEntityPacket(serverEntity: $ServerEntity): $Packet<$ClientGamePacketListener>;
        get<T>(type: $DataComponentType<T>): T;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playPlacementSound(): void;
        recreateFromPacket(packet: $ClientboundAddEntityPacket): void;
        snapTo(x: number, y: number, z: number, yRot: number, xRot: number): void;
        trackingPosition(): $Vec3;
    }

    export class $PaintingVariant extends $Record {
        constructor(width: number, height: number, assetId: $Identifier_, title: $Optional<$Component_>, author: $Optional<$Component_>);
        static CODEC: $Codec<$Holder<$PaintingVariant>>;
        static DIRECT_CODEC: $Codec<$PaintingVariant>;
        static DIRECT_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $PaintingVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$PaintingVariant>>;
        area(): number;
        assetId(): $Identifier;
        author(): $Optional<$Component>;
        equals(o: object): boolean;
        hashCode(): number;
        height(): number;
        title(): $Optional<$Component>;
        toString(): string;
        width(): number;
    }

}
