import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $Container, $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance } from "java:net/minecraft/world/effect";
import { $AgeableMob, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $EquipmentSlot, $EquipmentSlot_, $HasCustomInventoryScreen, $LivingEntity, $PlayerRideableJumping, $SlotAccess, $SpawnGroupData, $TamableAnimal } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ModelAndTexture, $PriorityProvider, $PriorityProvider$Selector, $SpawnCondition, $SpawnContext, $SpawnPrioritySelectors } from "java:net/minecraft/world/entity/variant";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/nautilus" {
    export class $AbstractNautilus extends $TamableAnimal implements $PlayerRideableJumping, $HasCustomInventoryScreen {
        static INVENTORY_ROWS: number;
        static INVENTORY_SLOT_OFFSET: number;
        static LARGE_RESTRICTION_RADIUS: number;
        static RESTRICTION_RADIUS_BUFFER: number;
        static SMALL_RESTRICTION_RADIUS: number;
        get controllingPassenger(): $LivingEntity;
        getControllingPassenger(): $LivingEntity;
        get inventoryColumns(): number;
        getInventoryColumns(): number;
        get inventorySize(): number;
        getInventorySize(): number;
        get jumpCooldown(): number;
        getJumpCooldown(): number;
        get dashing(): boolean;
        isDashing(): boolean;
        set dashing(value: boolean);
        get pushedByFluid(): boolean;
        isPushedByFluid(): boolean;
        static checkNautilusSpawnRules(type: $EntityType<$AbstractNautilus>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canBeAffected(newEffect: $MobEffectInstance): boolean;
        canJump(): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        checkSpawnObstruction(level: $LevelReader): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getSlot(slot: number): $SlotAccess;
        getWalkTargetValue(pos: $BlockPos_, level: $LevelReader): number;
        handleStartJump(jumpScale: number): void;
        handleStopJump(): void;
        hasInventoryChanged(oldInventory: $Container): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        onPlayerJump(jumpAmount: number): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        openCustomInventoryScreen(player: $Player): void;
        removeWhenFarAway(distSqr: number): boolean;
        requiresCustomPersistence(): boolean;
        tick(): void;
    }

    export class $Nautilus extends $AbstractNautilus {
        constructor(type: $EntityType<$Nautilus>, level: $Level);
        get brain(): $Brain<$Nautilus>;
        getBrain(): $Brain<$Nautilus>;
        get maxAirSupply(): number;
        getMaxAirSupply(): number;
        baseTick(): void;
        canBeLeashed(): boolean;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Nautilus;
    }

    export class $ZombieNautilus extends $AbstractNautilus {
        constructor(type: $EntityType<$ZombieNautilus>, level: $Level);
        get brain(): $Brain<$ZombieNautilus>;
        getBrain(): $Brain<$ZombieNautilus>;
        get variant(): $Holder<$ZombieNautilusVariant>;
        getVariant(): $Holder<$ZombieNautilusVariant>;
        set variant(value: $Holder<$ZombieNautilusVariant>);
        get baby(): boolean;
        isBaby(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canBeLeashed(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $ZombieNautilus;
        get<T>(type: $DataComponentType<T>): T;
    }

    export class $ZombieNautilusVariant extends $Record implements $PriorityProvider {
        constructor(modelAndTexture: $ModelAndTexture<$ZombieNautilusVariant$ModelType_>, spawnConditions: $SpawnPrioritySelectors);
        static CODEC: $Codec<$Holder<$ZombieNautilusVariant>>;
        static DIRECT_CODEC: $Codec<$ZombieNautilusVariant>;
        static NETWORK_CODEC: $Codec<$ZombieNautilusVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$ZombieNautilusVariant>>;
        equals(o: object): boolean;
        hashCode(): number;
        modelAndTexture(): $ModelAndTexture<$ZombieNautilusVariant$ModelType>;
        selectors(): $List<$PriorityProvider$Selector<$SpawnContext, $SpawnCondition>>;
        spawnConditions(): $SpawnPrioritySelectors;
        toString(): string;
    }

    export class $ZombieNautilusVariant$ModelType {
        static NORMAL: $ZombieNautilusVariant$ModelType;
        static WARM: $ZombieNautilusVariant$ModelType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ZombieNautilusVariant$ModelType[];
        static valueOf(name: string): $ZombieNautilusVariant$ModelType;
    }

    export type $ZombieNautilusVariant$ModelType_ = $ZombieNautilusVariant$ModelType | "NORMAL" | "WARM";
}
