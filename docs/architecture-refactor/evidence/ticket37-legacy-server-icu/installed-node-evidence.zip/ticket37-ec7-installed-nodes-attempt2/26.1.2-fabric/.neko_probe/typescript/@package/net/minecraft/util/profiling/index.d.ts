import { $AutoCloseable, $Comparable, $String } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $List } from "java:java/util";
import { $Supplier } from "java:java/util/function";
import { $MetricCategory, $MetricCategory_ } from "java:net/minecraft/util/profiling/metrics";

export * as metrics from "java:net/minecraft/util/profiling/metrics";

declare module "java:net/minecraft/util/profiling" {
    export interface $ProfileResults {
        demanglePath(path: string): string;
        getEndTimeNano(): number;
        getEndTimeTicks(): number;
        getNanoDuration(): number;
        getProfilerResults(): string;
        getStartTimeNano(): number;
        getStartTimeTicks(): number;
        getTickDuration(): number;
        getTimes(path: string): $List<$ResultField>;
        saveResults(file: string): boolean;
        static PATH_SEPARATOR: string;
    }

    export interface $ProfilerFiller {
        addZoneText(text: string): void;
        addZoneValue(value: number): void;
        combine(first: $ProfilerFiller, second: $ProfilerFiller): $ProfilerFiller;
        endTick(): void;
        incrementCounter(name: string, amount: number): void;
        incrementCounter(name: string): void;
        incrementCounter(name: $Supplier<string>, amount: number): void;
        incrementCounter(name: $Supplier<string>): void;
        markForCharting(category: $MetricCategory_): void;
        popPush(name: string): void;
        popPush(name: $Supplier<string>): void;
        pop(): void;
        push(name: string): void;
        push(name: $Supplier<string>): void;
        setZoneColor(color: number): void;
        startTick(): void;
        zone(name: string): $Zone;
        zone(name: $Supplier<string>): $Zone;
        static ROOT: string;
    }

    export class $ResultField implements $Comparable {
        constructor(name: string, percentage: number, globalPercentage: number, count: number);
        count: number;
        globalPercentage: number;
        name: string;
        percentage: number;
        get color(): number;
        getColor(): number;
        compareTo(resultField: $ResultField): number;
    }

    export class $Zone implements $AutoCloseable {
        static INACTIVE: $Zone;
        addText(text: string): $Zone;
        addText(text: $Supplier<string>): $Zone;
        addValue(value: number): $Zone;
        close(): void;
    }

}
