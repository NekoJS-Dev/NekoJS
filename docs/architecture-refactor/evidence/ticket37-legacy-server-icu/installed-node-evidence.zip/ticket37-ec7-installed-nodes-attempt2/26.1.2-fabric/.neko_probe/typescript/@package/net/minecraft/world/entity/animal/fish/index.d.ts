import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Consumer } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $DataComponentGetter, $DataComponentType } from "java:net/minecraft/core/component";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $PathfinderMob, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Bucketable } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $DyeColor, $DyeColor_, $Item$TooltipContext, $ItemStack, $ItemStack_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $TooltipProvider } from "java:net/minecraft/world/item/component";
import { $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/fish" {
    export class $AbstractFish extends $WaterAnimal implements $Bucketable {
        constructor(type: $EntityType<$AbstractFish>, level: $Level);
        get maxSpawnClusterSize(): number;
        getMaxSpawnClusterSize(): number;
        get pickupSound(): $SoundEvent;
        getPickupSound(): $SoundEvent;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        fromBucket(): boolean;
        loadFromBucketTag(tag: $CompoundTag_): void;
        removeWhenFarAway(distSqr: number): boolean;
        requiresCustomPersistence(): boolean;
        saveToBucketTag(bucket: $ItemStack_): void;
    }

    export class $AbstractSchoolingFish extends $AbstractFish {
        constructor(type: $EntityType<$AbstractSchoolingFish>, level: $Level);
        get maxSchoolSize(): number;
        getMaxSchoolSize(): number;
        get maxSpawnClusterSize(): number;
        getMaxSpawnClusterSize(): number;
        get follower(): boolean;
        isFollower(): boolean;
        addFollowers(abstractSchoolingFishStream: $Stream<$AbstractSchoolingFish>): void;
        canBeFollowed(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        hasFollowers(): boolean;
        inRangeOfLeader(): boolean;
        pathToLeader(): void;
        startFollowing(leader: $AbstractSchoolingFish): $AbstractSchoolingFish;
        stopFollowing(): void;
        tick(): void;
    }

    export class $Cod extends $AbstractSchoolingFish {
        constructor(type: $EntityType<$Cod>, level: $Level);
        get bucketItemStack(): $ItemStack;
        getBucketItemStack(): $ItemStack;
    }

    export class $Pufferfish extends $AbstractFish {
        constructor(type: $EntityType<$Pufferfish>, level: $Level);
        static STATE_FULL: number;
        static STATE_MID: number;
        static STATE_SMALL: number;
        get bucketItemStack(): $ItemStack;
        getBucketItemStack(): $ItemStack;
        get puffState(): number;
        getPuffState(): number;
        set puffState(value: number);
        aiStep(): void;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        playerTouch(player: $Player): void;
        tick(): void;
    }

    export class $Salmon extends $AbstractSchoolingFish {
        constructor(type: $EntityType<$Salmon>, level: $Level);
        get bucketItemStack(): $ItemStack;
        getBucketItemStack(): $ItemStack;
        get maxSchoolSize(): number;
        getMaxSchoolSize(): number;
        get salmonScale(): number;
        getSalmonScale(): number;
        get variant(): $Salmon$Variant;
        getVariant(): $Salmon$Variant;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        get<T>(type: $DataComponentType<T>): T;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        saveToBucketTag(bucket: $ItemStack_): void;
    }

    export class $Salmon$Variant {
        static LARGE: $Salmon$Variant;
        static MEDIUM: $Salmon$Variant;
        static SMALL: $Salmon$Variant;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Salmon$Variant[];
        static valueOf(name: string): $Salmon$Variant;
    }

    export class $TropicalFish extends $AbstractSchoolingFish {
        constructor(type: $EntityType<$TropicalFish>, level: $Level);
        static COMMON_VARIANTS: $List<$TropicalFish$Variant>;
        static DEFAULT_VARIANT: $TropicalFish$Variant;
        get baseColor(): $DyeColor;
        getBaseColor(): $DyeColor;
        get bucketItemStack(): $ItemStack;
        getBucketItemStack(): $ItemStack;
        get patternColor(): $DyeColor;
        getPatternColor(): $DyeColor;
        get pattern(): $TropicalFish$Pattern;
        getPattern(): $TropicalFish$Pattern;
        static checkTropicalFishSpawnRules(type: $EntityType<$TropicalFish>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static getBaseColor(packedVariant: number): $DyeColor;
        static getPatternColor(packedVariant: number): $DyeColor;
        static getPattern(packedVariant: number): $TropicalFish$Pattern;
        static getPredefinedName(index: number): string;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        get<T>(type: $DataComponentType<T>): T;
        isMaxGroupSizeReached(groupSize: number): boolean;
        saveToBucketTag(bucket: $ItemStack_): void;
    }

    export class $TropicalFish$Base {
        static LARGE: $TropicalFish$Base;
        static SMALL: $TropicalFish$Base;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TropicalFish$Base[];
        static valueOf(name: string): $TropicalFish$Base;
    }

    export class $TropicalFish$Pattern {
        static BETTY: $TropicalFish$Pattern;
        static BLOCKFISH: $TropicalFish$Pattern;
        static BRINELY: $TropicalFish$Pattern;
        static CLAYFISH: $TropicalFish$Pattern;
        static DASHER: $TropicalFish$Pattern;
        static FLOPPER: $TropicalFish$Pattern;
        static GLITTER: $TropicalFish$Pattern;
        static KOB: $TropicalFish$Pattern;
        static SNOOPER: $TropicalFish$Pattern;
        static SPOTTY: $TropicalFish$Pattern;
        static STRIPEY: $TropicalFish$Pattern;
        static SUNSTREAK: $TropicalFish$Pattern;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TropicalFish$Pattern[];
        static valueOf(name: string): $TropicalFish$Pattern;
    }

    export class $TropicalFish$Variant extends $Record {
        constructor(packedId: number);
        constructor(pattern: $TropicalFish$Pattern_, baseColor: $DyeColor_, patternColor: $DyeColor_);
        static CODEC: $Codec<$TropicalFish$Variant>;
        get packedId(): number;
        getPackedId(): number;
        baseColor(): $DyeColor;
        equals(o: object): boolean;
        hashCode(): number;
        patternColor(): $DyeColor;
        pattern(): $TropicalFish$Pattern;
        toString(): string;
    }

    export class $WaterAnimal extends $PathfinderMob {
        static AMBIENT_SOUND_INTERVAL: number;
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get pushedByFluid(): boolean;
        isPushedByFluid(): boolean;
        static checkSurfaceWaterAnimalSpawnRules(type: $EntityType<$WaterAnimal>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        baseTick(): void;
        canBeLeashed(): boolean;
        checkSpawnObstruction(level: $LevelReader): boolean;
    }

    export type $Salmon$Variant_ = $Salmon$Variant | "LARGE" | "MEDIUM" | "SMALL";
    export type $TropicalFish$Base_ = $TropicalFish$Base | "LARGE" | "SMALL";
    export type $TropicalFish$Pattern_ = $TropicalFish$Pattern | "BETTY" | "BLOCKFISH" | "BRINELY" | "CLAYFISH" | "DASHER" | "FLOPPER" | "GLITTER" | "KOB" | "SNOOPER" | "SPOTTY" | "STRIPEY" | "SUNSTREAK";
}
