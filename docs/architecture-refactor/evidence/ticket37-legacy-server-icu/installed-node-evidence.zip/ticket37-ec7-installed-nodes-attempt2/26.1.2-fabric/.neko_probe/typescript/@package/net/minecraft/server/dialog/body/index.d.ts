import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $List } from "java:java/util";

declare module "java:net/minecraft/server/dialog/body" {
    export interface $DialogBody {
        mapCodec(): $MapCodec<$DialogBody>;
        static COMPACT_LIST_CODEC: $Codec<$List<$DialogBody>>;
        static DIALOG_BODY_CODEC: $Codec<$DialogBody>;
    }

}
