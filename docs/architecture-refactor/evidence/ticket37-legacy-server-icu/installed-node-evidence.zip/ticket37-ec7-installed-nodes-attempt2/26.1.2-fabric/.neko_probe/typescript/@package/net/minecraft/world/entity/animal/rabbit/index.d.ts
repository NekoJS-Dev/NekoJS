import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $AgeableMob, $AnimationState, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $Leashable$LeashData, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/rabbit" {
    export class $Rabbit extends $Animal {
        constructor(type: $EntityType<$Rabbit>, level: $Level);
        static ATTACK_SPEED_MOD: number;
        static BREED_SPEED_MOD: number;
        static FLEE_SPEED_MOD: number;
        static FOLLOW_SPEED_MOD: number;
        static STROLL_SPEED_MOD: number;
        hopAnimationState: $AnimationState;
        idleHeadTiltAnimationState: $AnimationState;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get variant(): $Rabbit$Variant;
        getVariant(): $Rabbit$Variant;
        static checkRabbitSpawnRules(type: $EntityType<$Rabbit>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        baseTick(): void;
        canSpawnSprintParticle(): boolean;
        customServerAiStep(level: $ServerLevel): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Rabbit;
        getJumpCompletion(a: number): number;
        get<T>(type: $DataComponentType<T>): T;
        handleEntityEvent(id: number): void;
        isFood(itemStack: $ItemStack_): boolean;
        jumpFromGround(): void;
        playAttackSound(): void;
        startJumping(): void;
    }

    export class $Rabbit$Variant {
        static BLACK: $Rabbit$Variant;
        static BROWN: $Rabbit$Variant;
        static EVIL: $Rabbit$Variant;
        static GOLD: $Rabbit$Variant;
        static SALT: $Rabbit$Variant;
        static WHITE: $Rabbit$Variant;
        static WHITE_SPLOTCHED: $Rabbit$Variant;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Rabbit$Variant[];
        static valueOf(name: string): $Rabbit$Variant;
    }

    export type $Rabbit$Variant_ = $Rabbit$Variant | "BLACK" | "BROWN" | "EVIL" | "GOLD" | "SALT" | "WHITE" | "WHITE_SPLOTCHED";
}
