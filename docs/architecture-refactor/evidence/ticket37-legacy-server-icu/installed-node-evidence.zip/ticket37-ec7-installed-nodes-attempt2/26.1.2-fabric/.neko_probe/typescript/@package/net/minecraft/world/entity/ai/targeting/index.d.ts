import { $ServerLevel } from "java:net/minecraft/server/level";
import { $LivingEntity } from "java:net/minecraft/world/entity";

declare module "java:net/minecraft/world/entity/ai/targeting" {
    export class $TargetingConditions {
        static DEFAULT: $TargetingConditions;
        static forCombat(): $TargetingConditions;
        static forNonCombat(): $TargetingConditions;
        copy(): $TargetingConditions;
        ignoreInvisibilityTesting(): $TargetingConditions;
        ignoreLineOfSight(): $TargetingConditions;
        range(range: number): $TargetingConditions;
        selector(selector: $TargetingConditions$Selector): $TargetingConditions;
        test(level: $ServerLevel, targeter: $LivingEntity, target: $LivingEntity): boolean;
    }

    export interface $TargetingConditions$Selector {
        test(target: $LivingEntity, level: $ServerLevel): boolean;
    }

}
