import { $Function10, $Function11, $Function12, $Function3, $Function4, $Function5, $Function6, $Function7, $Function8, $Function9 } from "java:com/mojang/datafixers/util";
import { $BiFunction, $Function, $UnaryOperator } from "java:java/util/function";

declare module "java:net/minecraft/network/codec" {
    export interface $StreamCodec<B, V> extends $StreamEncoder, $StreamDecoder {
        apply<O>(operation: $StreamCodec$CodecOperation<B, V, O>): $StreamCodec<B, O>;
        cast<S>(): $StreamCodec<S, V>;
        composite<B, C, T1>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, constructor: $Function<T1, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, constructor: $BiFunction<T1, T2, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, constructor: $Function3<T1, T2, T3, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, constructor: $Function4<T1, T2, T3, T4, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, codec5: $StreamCodec<any, T5>, getter5: $Function<C, T5>, constructor: $Function5<T1, T2, T3, T4, T5, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, codec5: $StreamCodec<any, T5>, getter5: $Function<C, T5>, codec6: $StreamCodec<any, T6>, getter6: $Function<C, T6>, constructor: $Function6<T1, T2, T3, T4, T5, T6, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6, T7>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, codec5: $StreamCodec<any, T5>, getter5: $Function<C, T5>, codec6: $StreamCodec<any, T6>, getter6: $Function<C, T6>, codec7: $StreamCodec<any, T7>, getter7: $Function<C, T7>, constructor: $Function7<T1, T2, T3, T4, T5, T6, T7, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6, T7, T8>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, codec5: $StreamCodec<any, T5>, getter5: $Function<C, T5>, codec6: $StreamCodec<any, T6>, getter6: $Function<C, T6>, codec7: $StreamCodec<any, T7>, getter7: $Function<C, T7>, codec8: $StreamCodec<any, T8>, getter8: $Function<C, T8>, constructor: $Function8<T1, T2, T3, T4, T5, T6, T7, T8, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, codec5: $StreamCodec<any, T5>, getter5: $Function<C, T5>, codec6: $StreamCodec<any, T6>, getter6: $Function<C, T6>, codec7: $StreamCodec<any, T7>, getter7: $Function<C, T7>, codec8: $StreamCodec<any, T8>, getter8: $Function<C, T8>, codec9: $StreamCodec<any, T9>, getter9: $Function<C, T9>, constructor: $Function9<T1, T2, T3, T4, T5, T6, T7, T8, T9, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, codec5: $StreamCodec<any, T5>, getter5: $Function<C, T5>, codec6: $StreamCodec<any, T6>, getter6: $Function<C, T6>, codec7: $StreamCodec<any, T7>, getter7: $Function<C, T7>, codec8: $StreamCodec<any, T8>, getter8: $Function<C, T8>, codec9: $StreamCodec<any, T9>, getter9: $Function<C, T9>, codec10: $StreamCodec<any, T10>, getter10: $Function<C, T10>, constructor: $Function10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, codec5: $StreamCodec<any, T5>, getter5: $Function<C, T5>, codec6: $StreamCodec<any, T6>, getter6: $Function<C, T6>, codec7: $StreamCodec<any, T7>, getter7: $Function<C, T7>, codec8: $StreamCodec<any, T8>, getter8: $Function<C, T8>, codec9: $StreamCodec<any, T9>, getter9: $Function<C, T9>, codec10: $StreamCodec<any, T10>, getter10: $Function<C, T10>, codec11: $StreamCodec<any, T11>, getter11: $Function<C, T11>, constructor: $Function11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, C>): $StreamCodec<B, C>;
        composite<B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>(codec1: $StreamCodec<any, T1>, getter1: $Function<C, T1>, codec2: $StreamCodec<any, T2>, getter2: $Function<C, T2>, codec3: $StreamCodec<any, T3>, getter3: $Function<C, T3>, codec4: $StreamCodec<any, T4>, getter4: $Function<C, T4>, codec5: $StreamCodec<any, T5>, getter5: $Function<C, T5>, codec6: $StreamCodec<any, T6>, getter6: $Function<C, T6>, codec7: $StreamCodec<any, T7>, getter7: $Function<C, T7>, codec8: $StreamCodec<any, T8>, getter8: $Function<C, T8>, codec9: $StreamCodec<any, T9>, getter9: $Function<C, T9>, codec10: $StreamCodec<any, T10>, getter10: $Function<C, T10>, codec11: $StreamCodec<any, T11>, getter11: $Function<C, T11>, codec12: $StreamCodec<any, T12>, getter12: $Function<C, T12>, constructor: $Function12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, C>): $StreamCodec<B, C>;
        dispatch<U>(type: $Function<any, V>, codec: $Function<any, $StreamCodec<any, U>>): $StreamCodec<B, U>;
        mapStream<O>(operation: $Function<O, B>): $StreamCodec<O, V>;
        map<O>(to: $Function<any, O>, from: $Function<any, V>): $StreamCodec<B, O>;
        ofMember<B, V>(encoder: $StreamMemberEncoder<B, V>, decoder: $StreamDecoder<B, V>): $StreamCodec<B, V>;
        of<B, V>(encoder: $StreamEncoder<B, V>, decoder: $StreamDecoder<B, V>): $StreamCodec<B, V>;
        recursive<B, T>(factory: $UnaryOperator<$StreamCodec<B, T>>): $StreamCodec<B, T>;
        unit<B, V>(instance: V): $StreamCodec<B, V>;
    }

    export interface $StreamCodec$CodecOperation<B, S, T> {
        apply(original: $StreamCodec<B, S>): $StreamCodec<B, T>;
    }

    export interface $StreamDecoder<I, T> {
        decode(input: I): T;
    }

    export interface $StreamEncoder<O, T> {
        encode(output: O, value: T): void;
    }

    export interface $StreamMemberEncoder<O, T> {
        encode(value: T, output: O): void;
    }

}
