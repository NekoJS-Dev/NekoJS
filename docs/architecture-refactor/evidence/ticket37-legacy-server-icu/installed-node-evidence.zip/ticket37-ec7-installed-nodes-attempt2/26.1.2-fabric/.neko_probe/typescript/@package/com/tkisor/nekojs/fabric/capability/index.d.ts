import { $SingleFluidStorage } from "java:net/fabricmc/fabric/api/transfer/v1/fluid/base";
import { $CombinedSlottedStorage } from "java:net/fabricmc/fabric/api/transfer/v1/storage/base";
import { $TransactionContext } from "java:net/fabricmc/fabric/api/transfer/v1/transaction";
import { $SnapshotParticipant } from "java:net/fabricmc/fabric/api/transfer/v1/transaction/base";
import { $ValueInput, $ValueOutput } from "java:net/minecraft/world/level/storage";

declare module "java:com/tkisor/nekojs/fabric/capability" {
    export interface $FabricEnergyHandler {
        extract(maxAmount: number, transaction: $TransactionContext): number;
        getAmount(): number;
        getCapacity(): number;
        insert(maxAmount: number, transaction: $TransactionContext): number;
    }

    export class $FabricEnergyStorage extends $SnapshotParticipant implements $FabricEnergyHandler {
        constructor(capacity: number, maxReceive: number, maxExtract: number, onChange: $Runnable);
        get amount(): number;
        getAmount(): number;
        get capacity(): number;
        getCapacity(): number;
        extract(maxAmount: number, transaction: $TransactionContext): number;
        insert(maxAmount: number, transaction: $TransactionContext): number;
        readValue(input: $ValueInput): void;
        writeValue(output: $ValueOutput): void;
    }

    export class $FabricFluidStorage extends $SingleFluidStorage {
        constructor(capacity: number, onChange: $Runnable);
        readValue(input: $ValueInput): void;
        writeValue(output: $ValueOutput): void;
    }

    export class $FabricItemStorage extends $CombinedSlottedStorage {
        constructor(size: number, onChange: $Runnable);
        readValue(input: $ValueInput): void;
        writeValue(output: $ValueOutput): void;
    }

}
