import { $Enum, $String } from "java:java/lang";
import { $Set } from "java:java/util";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $MemoryModuleType } from "java:net/minecraft/world/entity/ai/memory";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/ai/behavior" {
    export class $Behavior$Status {
        static RUNNING: $Behavior$Status;
        static STOPPED: $Behavior$Status;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Behavior$Status[];
        static valueOf(name: string): $Behavior$Status;
    }

    export interface $BehaviorControl<E extends $LivingEntity> {
        debugString(): string;
        doStop(level: $ServerLevel, body: E, timestamp: number): void;
        getRequiredMemories(): $Set<$MemoryModuleType<any>>;
        getStatus(): $Behavior$Status;
        tickOrStop(level: $ServerLevel, body: E, timestamp: number): void;
        tryStart(level: $ServerLevel, body: E, timestamp: number): boolean;
    }

    export interface $PositionTracker {
        currentBlockPosition(): $BlockPos;
        currentPosition(): $Vec3;
        isVisibleBy(body: $LivingEntity): boolean;
    }

    export class $SpearAttack$SpearStatus {
        static APPROACH: $SpearAttack$SpearStatus;
        static CHARGING: $SpearAttack$SpearStatus;
        static RETREAT: $SpearAttack$SpearStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $SpearAttack$SpearStatus[];
        static valueOf(name: string): $SpearAttack$SpearStatus;
    }

    export type $Behavior$Status_ = $Behavior$Status | "RUNNING" | "STOPPED";
    export type $SpearAttack$SpearStatus_ = $SpearAttack$SpearStatus | "APPROACH" | "CHARGING" | "RETREAT";
}
