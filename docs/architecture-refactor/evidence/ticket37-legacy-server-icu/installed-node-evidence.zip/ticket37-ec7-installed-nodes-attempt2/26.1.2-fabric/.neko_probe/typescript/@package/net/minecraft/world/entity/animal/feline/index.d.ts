import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $BlockPos, $BlockPos_, $ClientAsset$ResourceTexture, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $SpawnGroupData, $TamableAnimal } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $PriorityProvider, $PriorityProvider$Selector, $SpawnCondition, $SpawnContext, $SpawnPrioritySelectors } from "java:net/minecraft/world/entity/variant";
import { $DyeColor, $DyeColor_, $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $LevelReader, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/feline" {
    export class $Cat extends $TamableAnimal {
        constructor(type: $EntityType<$Cat>, level: $Level);
        static SPRINT_SPEED_MOD: number;
        static TEMPT_SPEED_MOD: number;
        static WALK_SPEED_MOD: number;
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get collarColor(): $DyeColor;
        getCollarColor(): $DyeColor;
        get variant(): $Holder<$CatVariant>;
        getVariant(): $Holder<$CatVariant>;
        get lyingOnTopOfSleepingPlayer(): boolean;
        isLyingOnTopOfSleepingPlayer(): boolean;
        get lying(): boolean;
        isLying(): boolean;
        set lying(value: boolean);
        get steppingCarefully(): boolean;
        isSteppingCarefully(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canMate(partner: $Animal): boolean;
        customServerAiStep(level: $ServerLevel): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Cat;
        getLieDownAmountTail(a: number): number;
        getLieDownAmount(a: number): number;
        getRelaxStateOneAmount(a: number): number;
        get<T>(type: $DataComponentType<T>): T;
        hiss(): void;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        removeWhenFarAway(distSqr: number): boolean;
        setTame(isTame: boolean, includeSideEffects: boolean): void;
        tick(): void;
    }

    export class $CatSoundVariant extends $Record {
        constructor(adultSounds: $CatSoundVariant$CatSoundSet, babySounds: $CatSoundVariant$CatSoundSet);
        static CODEC: $Codec<$Holder<$CatSoundVariant>>;
        static DIRECT_CODEC: $Codec<$CatSoundVariant>;
        static NETWORK_CODEC: $Codec<$CatSoundVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$CatSoundVariant>>;
        adultSounds(): $CatSoundVariant$CatSoundSet;
        babySounds(): $CatSoundVariant$CatSoundSet;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $CatSoundVariant$CatSoundSet extends $Record {
        constructor(ambientSound: $Holder<$SoundEvent_>, strayAmbientSound: $Holder<$SoundEvent_>, hissSound: $Holder<$SoundEvent_>, hurtSound: $Holder<$SoundEvent_>, deathSound: $Holder<$SoundEvent_>, eatSound: $Holder<$SoundEvent_>, begForFoodSound: $Holder<$SoundEvent_>, purrSound: $Holder<$SoundEvent_>, purreowSound: $Holder<$SoundEvent_>);
        ambientSound(): $Holder<$SoundEvent>;
        begForFoodSound(): $Holder<$SoundEvent>;
        deathSound(): $Holder<$SoundEvent>;
        eatSound(): $Holder<$SoundEvent>;
        equals(o: object): boolean;
        hashCode(): number;
        hissSound(): $Holder<$SoundEvent>;
        hurtSound(): $Holder<$SoundEvent>;
        purrSound(): $Holder<$SoundEvent>;
        purreowSound(): $Holder<$SoundEvent>;
        strayAmbientSound(): $Holder<$SoundEvent>;
        toString(): string;
    }

    export class $CatSoundVariants$SoundSet {
        static CLASSIC: $CatSoundVariants$SoundSet;
        static ROYAL: $CatSoundVariants$SoundSet;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CatSoundVariants$SoundSet[];
        static valueOf(name: string): $CatSoundVariants$SoundSet;
    }

    export class $CatVariant extends $Record implements $PriorityProvider {
        constructor(adultAssetInfo: $ClientAsset$ResourceTexture, babyAssetInfo: $ClientAsset$ResourceTexture, spawnConditions: $SpawnPrioritySelectors);
        static CODEC: $Codec<$Holder<$CatVariant>>;
        static DIRECT_CODEC: $Codec<$CatVariant>;
        static NETWORK_CODEC: $Codec<$CatVariant>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$CatVariant>>;
        adultAssetInfo(): $ClientAsset$ResourceTexture;
        assetInfo(isBaby: boolean): $ClientAsset$ResourceTexture;
        babyAssetInfo(): $ClientAsset$ResourceTexture;
        equals(o: object): boolean;
        hashCode(): number;
        selectors(): $List<$PriorityProvider$Selector<$SpawnContext, $SpawnCondition>>;
        spawnConditions(): $SpawnPrioritySelectors;
        toString(): string;
    }

    export class $Ocelot extends $Animal {
        constructor(type: $EntityType<$Ocelot>, level: $Level);
        static CROUCH_SPEED_MOD: number;
        static SPRINT_SPEED_MOD: number;
        static WALK_SPEED_MOD: number;
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get steppingCarefully(): boolean;
        isSteppingCarefully(): boolean;
        static checkOcelotSpawnRules(type: $EntityType<$Ocelot>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        checkSpawnObstruction(level: $LevelReader): boolean;
        customServerAiStep(level: $ServerLevel): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Ocelot;
        handleEntityEvent(id: number): void;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        removeWhenFarAway(distSqr: number): boolean;
    }

    export type $CatSoundVariants$SoundSet_ = $CatSoundVariants$SoundSet | "CLASSIC" | "ROYAL";
}
