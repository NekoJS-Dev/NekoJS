import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $Float, $Integer, $Record, $String } from "java:java/lang";
import { $Map, $Set } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $ToFloatFunction } from "java:net/minecraft/util";
import { $AttributeModifier, $AttributeModifier$OperationId, $AttributeModifier$OperationId_ } from "java:net/minecraft/world/attribute/modifier";
import { $ClockManager } from "java:net/minecraft/world/clock";
import { $Level } from "java:net/minecraft/world/level";
import { $LootContext } from "java:net/minecraft/world/level/storage/loot";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $Timeline } from "java:net/minecraft/world/timeline";

export * as modifier from "java:net/minecraft/world/attribute/modifier";

declare module "java:net/minecraft/world/attribute" {
    export interface $AttributeRange<Value> {
        any<Value>(): $AttributeRange<Value>;
        ofFloat(minValue: number, maxValue: number): $AttributeRange<number>;
        sanitize(value: Value): Value;
        validate(value: Value): $DataResult<Value>;
        static NON_NEGATIVE_FLOAT: $AttributeRange<number>;
        static UNIT_FLOAT: $AttributeRange<number>;
    }

    export class $AttributeType<Value> extends $Record {
        constructor(valueCodec: $Codec<Value>, modifierLibrary: { [key: $AttributeModifier$OperationId_]: $AttributeModifier<Value, any> }, modifierCodec: $Codec<$AttributeModifier<Value, any>>, keyframeLerp: $LerpFunction<Value>, stateChangeLerp: $LerpFunction<Value>, spatialLerp: $LerpFunction<Value>, partialTickLerp: $LerpFunction<Value>, toFloat: $ToFloatFunction<Value>);
        static ofInterpolated<Value>(valueCodec: $Codec<Value>, modifierLibrary: { [key: $AttributeModifier$OperationId_]: $AttributeModifier<Value, any> }, lerp: $LerpFunction<Value>, partialTickLerp: $LerpFunction<Value>, toFloat: $ToFloatFunction<Value>): $AttributeType<Value>;
        static ofInterpolated<Value>(valueCodec: $Codec<Value>, modifierLibrary: { [key: $AttributeModifier$OperationId_]: $AttributeModifier<Value, any> }, lerp: $LerpFunction<Value>): $AttributeType<Value>;
        static ofNotInterpolated<Value>(valueCodec: $Codec<Value>, modifierLibrary: { [key: $AttributeModifier$OperationId_]: $AttributeModifier<Value, any> }): $AttributeType<Value>;
        static ofNotInterpolated<Value>(valueCodec: $Codec<Value>): $AttributeType<Value>;
        checkAllowedModifier(modifier: $AttributeModifier<Value, any>): void;
        equals(o: object): boolean;
        hashCode(): number;
        keyframeLerp(): $LerpFunction<Value>;
        modifierCodec(): $Codec<$AttributeModifier<Value, any>>;
        modifierLibrary(): $Map<$AttributeModifier$OperationId, $AttributeModifier<Value, any>>;
        partialTickLerp(): $LerpFunction<Value>;
        spatialLerp(): $LerpFunction<Value>;
        stateChangeLerp(): $LerpFunction<Value>;
        toFloat(value: Value): number;
        toFloat(): $ToFloatFunction<Value>;
        toString(): string;
        valueCodec(): $Codec<Value>;
    }

    export class $EnvironmentAttribute<Value> {
        get positional(): boolean;
        isPositional(): boolean;
        get spatiallyInterpolated(): boolean;
        isSpatiallyInterpolated(): boolean;
        get syncable(): boolean;
        isSyncable(): boolean;
        static builder<Value>(type: $AttributeType<Value>): $EnvironmentAttribute$Builder<Value>;
        defaultValue(): Value;
        sanitizeValue(value: Value): Value;
        toString(): string;
        type(): $AttributeType<Value>;
        valueCodec(): $Codec<Value>;
    }

    export class $EnvironmentAttribute$Builder<Value> {
        constructor(type: $AttributeType<Value>);
        build(): $EnvironmentAttribute<Value>;
        defaultValue(defaultValue: Value): $EnvironmentAttribute$Builder<Value>;
        notPositional(): $EnvironmentAttribute$Builder<Value>;
        spatiallyInterpolated(): $EnvironmentAttribute$Builder<Value>;
        syncable(): $EnvironmentAttribute$Builder<Value>;
        valueRange(valueRange: $AttributeRange<Value>): $EnvironmentAttribute$Builder<Value>;
    }

    export interface $EnvironmentAttributeLayer<Value> {
    }

    export interface $EnvironmentAttributeLayer$Constant<Value> extends $EnvironmentAttributeLayer {
        applyConstant(baseValue: Value): Value;
    }

    export interface $EnvironmentAttributeLayer$Positional<Value> extends $EnvironmentAttributeLayer {
        applyPositional(baseValue: Value, pos: $Vec3_, biomeInterpolator: $SpatialAttributeInterpolator): Value;
    }

    export interface $EnvironmentAttributeLayer$TimeBased<Value> extends $EnvironmentAttributeLayer {
        applyTimeBased(baseValue: Value, cacheTickId: number): Value;
    }

    export class $EnvironmentAttributeMap {
        static CODEC: $Codec<$EnvironmentAttributeMap>;
        static CODEC_ONLY_POSITIONAL: $Codec<$EnvironmentAttributeMap>;
        static EMPTY: $EnvironmentAttributeMap;
        static NETWORK_CODEC: $Codec<$EnvironmentAttributeMap>;
        static builder(): $EnvironmentAttributeMap$Builder;
        applyModifier<Value>(attribute: $EnvironmentAttribute<Value>, baseValue: Value): Value;
        contains(attribute: $EnvironmentAttribute<any>): boolean;
        equals(obj: object): boolean;
        get<Value>(attribute: $EnvironmentAttribute<Value>): $EnvironmentAttributeMap$Entry<Value, any>;
        hashCode(): number;
        keySet(): $Set<$EnvironmentAttribute<any>>;
        toString(): string;
    }

    export class $EnvironmentAttributeMap$Builder {
        build(): $EnvironmentAttributeMap;
        modify<Value, Parameter>(attribute: $EnvironmentAttribute<Value>, modifier: $AttributeModifier<Value, Parameter>, value: Parameter): $EnvironmentAttributeMap$Builder;
        putAll(map: $EnvironmentAttributeMap): $EnvironmentAttributeMap$Builder;
        set<Value>(attribute: $EnvironmentAttribute<Value>, value: Value): $EnvironmentAttributeMap$Builder;
    }

    export class $EnvironmentAttributeMap$Entry<Value, Argument> extends $Record {
        constructor(argument: Argument, modifier: $AttributeModifier<Value, Argument>);
        applyModifier(subject: Value): Value;
        argument(): Argument;
        equals(o: object): boolean;
        hashCode(): number;
        modifier(): $AttributeModifier<Value, Argument>;
        toString(): string;
    }

    export interface $EnvironmentAttributeReader {
        getDimensionValue<Value>(attribute: $EnvironmentAttribute<Value>): Value;
        getValue<Value>(attribute: $EnvironmentAttribute<Value>, pos: $BlockPos_): Value;
        getValue<Value>(attribute: $EnvironmentAttribute<Value>, pos: $Vec3_, biomeInterpolator: $SpatialAttributeInterpolator): Value;
        getValue<Value>(attribute: $EnvironmentAttribute<Value>, pos: $Vec3_): Value;
        getValue<Value>(context: $LootContext, attribute: $EnvironmentAttribute<Value>): Value;
        static EMPTY: $EnvironmentAttributeReader;
    }

    export class $EnvironmentAttributeSystem implements $EnvironmentAttributeReader {
        static builder(): $EnvironmentAttributeSystem$Builder;
        getDimensionValue<Value>(attribute: $EnvironmentAttribute<Value>): Value;
        getValue<Value>(attribute: $EnvironmentAttribute<Value>, pos: $Vec3_, biomeInterpolator: $SpatialAttributeInterpolator): Value;
        invalidateTickCache(): void;
    }

    export class $EnvironmentAttributeSystem$Builder {
        addConstantLayer<Value>(attribute: $EnvironmentAttribute<Value>, layer: $EnvironmentAttributeLayer$Constant<Value>): $EnvironmentAttributeSystem$Builder;
        addConstantLayer(attributeMap: $EnvironmentAttributeMap): $EnvironmentAttributeSystem$Builder;
        addDefaultLayers(level: $Level): $EnvironmentAttributeSystem$Builder;
        addPositionalLayer<Value>(attribute: $EnvironmentAttribute<Value>, layer: $EnvironmentAttributeLayer$Positional<Value>): $EnvironmentAttributeSystem$Builder;
        addTimeBasedLayer<Value>(attribute: $EnvironmentAttribute<Value>, layer: $EnvironmentAttributeLayer$TimeBased<Value>): $EnvironmentAttributeSystem$Builder;
        addTimelineLayer(timeline: $Holder<$Timeline>, clockManager: $ClockManager): $EnvironmentAttributeSystem$Builder;
        build(): $EnvironmentAttributeSystem;
    }

    export interface $LerpFunction<T> {
        apply(alpha: number, from: T, to: T): T;
        ofColor(): $LerpFunction<number>;
        ofConstant<T>(): $LerpFunction<T>;
        ofDegrees(maxDelta: number): $LerpFunction<number>;
        ofFloat(): $LerpFunction<number>;
        ofInteger(): $LerpFunction<number>;
        ofStep<T>(threshold: number): $LerpFunction<T>;
    }

    export class $SpatialAttributeInterpolator {
        constructor();
        accumulate(weight: number, attributes: $EnvironmentAttributeMap): $SpatialAttributeInterpolator;
        applyAttributeLayer<Value>(attribute: $EnvironmentAttribute<Value>, baseValue: Value): Value;
        clear(): void;
    }

}
