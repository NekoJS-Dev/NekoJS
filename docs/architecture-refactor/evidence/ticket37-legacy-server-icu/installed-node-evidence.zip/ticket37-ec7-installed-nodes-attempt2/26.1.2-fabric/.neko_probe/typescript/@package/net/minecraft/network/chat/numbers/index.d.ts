import { $MapCodec } from "java:com/mojang/serialization";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $MutableComponent } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/network/chat/numbers" {
    export interface $NumberFormat {
        format(value: number): $MutableComponent;
        type(): $NumberFormatType<$NumberFormat>;
    }

    export interface $NumberFormatType<T extends $NumberFormat> {
        mapCodec(): $MapCodec<T>;
        streamCodec(): $StreamCodec<$RegistryFriendlyByteBuf, T>;
    }

}
