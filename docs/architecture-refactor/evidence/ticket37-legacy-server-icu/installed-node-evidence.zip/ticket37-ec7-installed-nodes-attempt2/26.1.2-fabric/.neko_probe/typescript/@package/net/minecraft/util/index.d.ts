import { $ServicesKeySet, $ServicesKeyType } from "java:com/mojang/authlib/yggdrasil";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult, $DynamicOps, $Keyable, $MapCodec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Int2IntFunction } from "java:it/unimi/dsi/fastutil/ints";
import { $Class, $Enum, $Integer, $Record, $Runnable, $String } from "java:java/lang";
import { $PublicKey } from "java:java/security";
import { $List, $Optional, $Set } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $Consumer, $Function, $Supplier } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Component, $Component_, $Style } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $LerpFunction } from "java:net/minecraft/world/attribute";
import { $PositionalRandomFactory } from "java:net/minecraft/world/level/levelgen";
import { $Logger } from "java:org/slf4j";

export * as context from "java:net/minecraft/util/context";
export * as datafix from "java:net/minecraft/util/datafix";
export * as debug from "java:net/minecraft/util/debug";
export * as debugchart from "java:net/minecraft/util/debugchart";
export * as profiling from "java:net/minecraft/util/profiling";
export * as random from "java:net/minecraft/util/random";
export * as thread from "java:net/minecraft/util/thread";
export * as valueproviders from "java:net/minecraft/util/valueproviders";

declare module "java:net/minecraft/util" {
    export class $BinaryAnimator {
        constructor(animationLength: number);
        constructor(animationLength: number, easing: $EasingType);
        getFactor(partialTicks: number): number;
        tick(active: boolean): void;
    }

    export class $BlockUtil$FoundRectangle {
        constructor(minCorner: $BlockPos_, axis1Size: number, axis2Size: number);
        axis1Size: number;
        axis2Size: number;
        minCorner: $BlockPos;
    }

    export class $Brightness extends $Record {
        constructor(block: number, sky: number);
        static CODEC: $Codec<$Brightness>;
        static FULL_BRIGHT: $Brightness;
        static LIGHT_VALUE_CODEC: $Codec<number>;
        static unpack(packed: number): $Brightness;
        block(): number;
        equals(o: object): boolean;
        hashCode(): number;
        pack(): number;
        sky(): number;
        toString(): string;
    }

    export class $CompilableString<T> {
        static codec<T>(compiler: $Function<string, $DataResult<T>>): $Codec<$CompilableString<T>>;
        compiled(): T;
        equals(o: object): boolean;
        hashCode(): number;
        source(): string;
        toString(): string;
    }

    export interface $EasingType {
        apply(x: number): number;
        cubicBezier(x1: number, y1: number, x2: number, y2: number): $EasingType;
        registerSimple(id: string, easing: $EasingType): $EasingType;
        symmetricCubicBezier(x1: number, y1: number): $EasingType;
        static CODEC: $Codec<$EasingType>;
        static CONSTANT: $EasingType;
        static IN_BACK: $EasingType;
        static IN_BOUNCE: $EasingType;
        static IN_CIRC: $EasingType;
        static IN_CUBIC: $EasingType;
        static IN_ELASTIC: $EasingType;
        static IN_EXPO: $EasingType;
        static IN_OUT_BACK: $EasingType;
        static IN_OUT_BOUNCE: $EasingType;
        static IN_OUT_CIRC: $EasingType;
        static IN_OUT_CUBIC: $EasingType;
        static IN_OUT_ELASTIC: $EasingType;
        static IN_OUT_EXPO: $EasingType;
        static IN_OUT_QUAD: $EasingType;
        static IN_OUT_QUART: $EasingType;
        static IN_OUT_QUINT: $EasingType;
        static IN_OUT_SINE: $EasingType;
        static IN_QUAD: $EasingType;
        static IN_QUART: $EasingType;
        static IN_QUINT: $EasingType;
        static IN_SINE: $EasingType;
        static LINEAR: $EasingType;
        static OUT_BACK: $EasingType;
        static OUT_BOUNCE: $EasingType;
        static OUT_CIRC: $EasingType;
        static OUT_CUBIC: $EasingType;
        static OUT_ELASTIC: $EasingType;
        static OUT_EXPO: $EasingType;
        static OUT_QUAD: $EasingType;
        static OUT_QUART: $EasingType;
        static OUT_QUINT: $EasingType;
        static OUT_SINE: $EasingType;
        static SIMPLE_REGISTRY: $ExtraCodecs$LateBoundIdMapper<string, $EasingType>;
    }

    export class $ExtraCodecs$LateBoundIdMapper<I, V> {
        constructor();
        codec(idCodec: $Codec<I>): $Codec<V>;
        put(id: I, value: V): $ExtraCodecs$LateBoundIdMapper<I, V>;
        values(): $Set<V>;
    }

    export interface $FormattedCharSequence {
        accept(output: $FormattedCharSink): boolean;
        backward(plainText: string, style: $Style, modifier: $Int2IntFunction): $FormattedCharSequence;
        backward(plainText: string, style: $Style): $FormattedCharSequence;
        codepoint(codepoint: number, style: $Style): $FormattedCharSequence;
        composite(parts: $FormattedCharSequence[]): $FormattedCharSequence;
        composite(parts?: $FormattedCharSequence[]): $FormattedCharSequence;
        composite(first: $FormattedCharSequence, second: $FormattedCharSequence): $FormattedCharSequence;
        composite(part: $FormattedCharSequence): $FormattedCharSequence;
        composite(): $FormattedCharSequence;
        decorateOutput(output: $FormattedCharSink, modifier: $Int2IntFunction): $FormattedCharSink;
        forward(plainText: string, style: $Style, modifier: $Int2IntFunction): $FormattedCharSequence;
        forward(plainText: string, style: $Style): $FormattedCharSequence;
        fromList(partCopy: $FormattedCharSequence[]): $FormattedCharSequence;
        fromPair(first: $FormattedCharSequence, second: $FormattedCharSequence): $FormattedCharSequence;
        static EMPTY: $FormattedCharSequence;
    }

    export interface $FormattedCharSink {
        accept(position: number, style: $Style, codepoint: number): boolean;
    }

    export class $InclusiveRange<T extends $Comparable<T>> extends $Record {
        constructor(value: T);
        constructor(minInclusive: T, maxInclusive: T);
        static INT: $Codec<$InclusiveRange<number>>;
        static codec<T>(elementCodec: $Codec<T>, minAllowedInclusive: T, maxAllowedInclusive: T): $Codec<$InclusiveRange<T>>;
        static codec<T>(elementCodec: $Codec<T>): $Codec<$InclusiveRange<T>>;
        static create<T>(minInclusive: T, maxInclusive: T): $DataResult<$InclusiveRange<T>>;
        contains(subRange: $InclusiveRange<T>): boolean;
        equals(o: object): boolean;
        hashCode(): number;
        isValueInRange(value: T): boolean;
        map<S>(mapper: $Function<any, S>): $InclusiveRange<S>;
        maxInclusive(): T;
        minInclusive(): T;
        toString(): string;
    }

    export class $KeyDispatchDataCodec<A> extends $Record {
        constructor(codec: $MapCodec<A>);
        static of<A>(codec: $MapCodec<A>): $KeyDispatchDataCodec<A>;
        codec(): $MapCodec<A>;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $KeyframeTrack<T> extends $Record {
        constructor(keyframes: $Keyframe<T>[], easingType: $EasingType);
        static mapCodec<T>(valueCodec: $Codec<T>): $MapCodec<$KeyframeTrack<T>>;
        static validatePeriod(track: $KeyframeTrack<any>, periodTicks: number): $DataResult<$KeyframeTrack<any>>;
        bakeSampler(periodTicks: $Optional<number>, lerp: $LerpFunction<T>): $KeyframeTrackSampler<T>;
        easingType(): $EasingType;
        equals(o: object): boolean;
        hashCode(): number;
        keyframes(): $List<$Keyframe<T>>;
        toString(): string;
    }

    export class $KeyframeTrack$Builder<T> {
        constructor();
        addKeyframe(ticks: number, value: T): $KeyframeTrack$Builder<T>;
        build(): $KeyframeTrack<T>;
    }

    export class $ModCheck extends $Record {
        constructor(confidence: $ModCheck$Confidence_, description: string);
        static identify(expectedBrand: string, actualBrand: $Supplier<string>, component: string, canaryClass: $Class<any>): $ModCheck;
        confidence(): $ModCheck$Confidence;
        description(): string;
        equals(o: object): boolean;
        fullDescription(): string;
        hashCode(): number;
        merge(other: $ModCheck): $ModCheck;
        shouldReportAsModified(): boolean;
        toString(): string;
    }

    export class $ModCheck$Confidence {
        static DEFINITELY: $ModCheck$Confidence;
        static PROBABLY_NOT: $ModCheck$Confidence;
        static VERY_LIKELY: $ModCheck$Confidence;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ModCheck$Confidence[];
        static valueOf(name: string): $ModCheck$Confidence;
    }

    export interface $ProblemReporter {
        forChild(path: $ProblemReporter$PathElement): $ProblemReporter;
        report(problem: $ProblemReporter$Problem): void;
        static DISCARDING: $ProblemReporter;
    }

    export interface $ProblemReporter$PathElement {
        get(): string;
    }

    export interface $ProblemReporter$Problem {
        description(): string;
    }

    export interface $ProgressListener {
        progressStagePercentage(i: number): void;
        progressStage(string: $Component_): void;
        progressStartNoAbort(string: $Component_): void;
        progressStart(string: $Component_): void;
        stop(): void;
    }

    export interface $RandomSource {
        consumeCount(rounds: number): void;
        createThreadLocalInstance(seed: number): $RandomSource;
        createThreadLocalInstance(): $RandomSource;
        createThreadSafe(): $RandomSource;
        create(seed: number): $RandomSource;
        create(): $RandomSource;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextGaussian(): number;
        nextIntBetweenInclusive(min: number, maxInclusive: number): number;
        nextInt(origin: number, bound: number): number;
        nextInt(bound: number): number;
        nextInt(): number;
        nextLong(): number;
        setSeed(seed: number): void;
        triangle(mean: number, spread: number): number;
        triangle(mean: number, spread: number): number;
        static GAUSSIAN_SPREAD_FACTOR: number;
    }

    export interface $SignatureUpdater {
        update(output: $SignatureUpdater$Output): void;
    }

    export interface $SignatureUpdater$Output {
        update(payload: number[]): void;
    }

    export interface $SignatureValidator {
        from(keySet: $ServicesKeySet, type: $ServicesKeyType_): $SignatureValidator;
        from(publicKey: $PublicKey, algorithm: string): $SignatureValidator;
        validate(payload: number[], signature: number[]): boolean;
        validate(updater: $SignatureUpdater, signature: number[]): boolean;
        static LOGGER: $Logger;
        static NO_VALIDATION: $SignatureValidator;
    }

    export class $StaticCache2D<T> {
        static create<T>(centerX: number, centerZ: number, range: number, initializer: $StaticCache2D$Initializer<T>): $StaticCache2D<T>;
        contains(x: number, z: number): boolean;
        forEach(consumer: $Consumer<T>): void;
        get(x: number, z: number): T;
        toString(): string;
    }

    export interface $StaticCache2D$Initializer<T> {
        get(x: number, z: number): T;
    }

    export interface $StringRepresentable {
        createNameLookup<T>(valueArray: T[], converter: $Function<T, string>): $Function<string, T>;
        createNameLookup<T>(valueArray: T[]): $Function<string, T>;
        fromEnumWithMapping<E>(values: $Supplier<E[]>, converter: $Function<string, string>): $StringRepresentable$EnumCodec<E>;
        fromEnum<E>(values: $Supplier<E[]>): $StringRepresentable$EnumCodec<E>;
        fromValues<T>(values: $Supplier<T[]>): $Codec<T>;
        getSerializedName(): string;
        keys(values: $StringRepresentable[]): $Keyable;
        static PRE_BUILT_MAP_THRESHOLD: number;
    }

    export class $StringRepresentable$EnumCodec<E extends $Enum<E>> extends $StringRepresentable$StringRepresentableCodec {
        constructor(valueArray: E[], nameResolver: $Function<string, E>);
        byName(name: string, _default: E): E;
        byName(name: string, defaultSupplier: $Supplier<E>): E;
        byName(name: string): E;
    }

    export class $StringRepresentable$StringRepresentableCodec<S extends $StringRepresentable> implements $Codec {
        constructor(valueArray: S[], nameResolver: $Function<string, S>, idResolver: $ToIntFunction<S>);
        decode<T>(ops: $DynamicOps<T>, input: T): $DataResult<$Pair<S, T>>;
        encode<T>(input: S, ops: $DynamicOps<T>, prefix: T): $DataResult<T>;
    }

    export interface $TaskChainer {
        append(task: $Runnable): void;
        append<T>(preparation: $CompletableFuture<T>, chainedTask: $Consumer<T>): void;
        immediate(executor: $Executor): $TaskChainer;
        static LOGGER: $Logger;
    }

    export interface $ToFloatFunction<T> {
        applyAsFloat(value: T): number;
    }

    export class $TriState {
        static DEFAULT: $TriState;
        static FALSE: $TriState;
        static TRUE: $TriState;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TriState[];
        static valueOf(name: string): $TriState;
    }

    export class $Unit {
        static INSTANCE: $Unit;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Unit[];
        static valueOf(name: string): $Unit;
    }

    export type $ModCheck$Confidence_ = $ModCheck$Confidence | "DEFINITELY" | "PROBABLY_NOT" | "VERY_LIKELY";
    export type $TriState_ = $TriState | "DEFAULT" | "FALSE" | "TRUE";
    export type $Unit_ = $Unit | "INSTANCE";
}
