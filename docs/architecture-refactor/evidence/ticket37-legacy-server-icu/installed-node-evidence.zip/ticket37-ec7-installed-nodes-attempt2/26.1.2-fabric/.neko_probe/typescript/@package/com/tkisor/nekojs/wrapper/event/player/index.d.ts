import { $String } from "java:java/lang";
import { $AdvancementHolder } from "java:net/minecraft/advancements";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $Container, $InteractionHand, $InteractionHand_ } from "java:net/minecraft/world";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $AbstractContainerMenu } from "java:net/minecraft/world/inventory";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Level } from "java:net/minecraft/world/level";

declare module "java:com/tkisor/nekojs/wrapper/event/player" {
    /**
     * Event fired when a slot in a player's inventory changes (PlayerEvents.inventoryChanged).
     * Listeners are dispatched by item id, e.g. PlayerEvents.inventoryChanged('minecraft:stone', event => ...).
     */
    export class $InventoryChangedEventJS {
        constructor(player: $Player, item: $ItemStack_, slot: number);
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get player(): $Player;
        getPlayer(): $Player;
        get slot(): number;
        getSlot(): number;
    }

    /**
     * Fired when a player earns an advancement (PlayerEvents.advancement).
     * event.advancement is the AdvancementHolder; event.id its Identifier; event.displayName the title or null.
     */
    export class $PlayerAdvancementEventJS {
        constructor(player: $ServerPlayer, advancement: $AdvancementHolder);
        get advancement(): $AdvancementHolder;
        getAdvancement(): $AdvancementHolder;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get id(): $Identifier;
        getId(): $Identifier;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
    }

    /**
     * Fired when a player changes dimension (PlayerEvents.changedDimension).
     * event.from / event.to are ResourceKey<Level> of the old and new dimensions.
     */
    export class $PlayerChangedDimensionEventJS {
        constructor(player: $ServerPlayer, from: $ResourceKey<$Level>, to: $ResourceKey<$Level>);
        get from(): $ResourceKey<$Level>;
        getFrom(): $ResourceKey<$Level>;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get to(): $ResourceKey<$Level>;
        getTo(): $ResourceKey<$Level>;
    }

    export class $PlayerCloneEventJS {
        constructor(player: $ServerPlayer, original: $ServerPlayer, alive: boolean);
        get original(): $ServerPlayer;
        getOriginal(): $ServerPlayer;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get alive(): boolean;
        isAlive(): boolean;
    }

    /**
     * Fired when a player opens or closes a container menu (PlayerEvents.containerOpened / containerClosed).
     * containerOpened also exists under the deprecated alias inventoryOpened; containerClosed under inventoryClosed.
     */
    export class $PlayerContainerEventJS {
        constructor(player: $ServerPlayer, container: $AbstractContainerMenu);
        get container(): $AbstractContainerMenu;
        getContainer(): $AbstractContainerMenu;
        /** Alias of container (the menu being opened/closed). */
        get menu(): $AbstractContainerMenu;
        getMenu(): $AbstractContainerMenu;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
    }

    /**
     * Fired when a player takes a crafted or smelted item (PlayerEvents.crafted / smelted, dispatched by item id).
     * event.result is the produced stack; event.container (crafted only) is the crafting input container, null for smelted.
     */
    export class $PlayerCraftedEventJS {
        constructor(player: $ServerPlayer, result: $ItemStack_, container: $Container);
        get container(): $Container;
        getContainer(): $Container;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get result(): $ItemStack;
        getResult(): $ItemStack;
    }

    /**
     * Fired when a player's item breaks from durability damage (PlayerEvents.destroyed, dispatched by item id).
     * event.itemStack is the broken stack at the break point (damage capped, count still before the -1 of the broken item).
     */
    export class $PlayerDestroyItemEventJS {
        constructor(player: $ServerPlayer, itemStack: $ItemStack_);
        get itemStack(): $ItemStack;
        getItemStack(): $ItemStack;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
    }

    /**
     * Fired when a player interacts (right-clicks) an entity (PlayerEvents.entityInteract).
     * Return true to cancel the interaction.
     */
    export class $PlayerEntityInteractEventJS {
        constructor(player: $ServerPlayer, target: $Entity, hand: $InteractionHand_);
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get target(): $Entity;
        getTarget(): $Entity;
    }

    export class $PlayerLifecycleEventJS {
        constructor(player: $Player);
        get player(): $Player;
        getPlayer(): $Player;
    }

    export class $PlayerRespawnEventJS {
        constructor(player: $ServerPlayer, oldPlayer: $ServerPlayer, alive: boolean);
        get oldPlayer(): $ServerPlayer;
        getOldPlayer(): $ServerPlayer;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
        get alive(): boolean;
        isAlive(): boolean;
    }

    export class $PlayerTickEventJS {
        constructor(player: $Player);
        get player(): $Player;
        getPlayer(): $Player;
    }

    export class $ServerChatEventJS {
        constructor(player: $Player, message: string);
        get message(): string;
        getMessage(): string;
        get player(): $Player;
        getPlayer(): $Player;
        get username(): string;
        getUsername(): string;
    }

}
