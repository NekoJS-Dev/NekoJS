import { $String } from "java:java/lang";

export * as poi from "java:net/minecraft/world/entity/ai/village/poi";

declare module "java:net/minecraft/world/entity/ai/village" {
    export interface $ReputationEventType {
        register(name: string): $ReputationEventType;
        static GOLEM_KILLED: $ReputationEventType;
        static TRADE: $ReputationEventType;
        static VILLAGER_HURT: $ReputationEventType;
        static VILLAGER_KILLED: $ReputationEventType;
        static ZOMBIE_VILLAGER_CURED: $ReputationEventType;
    }

}
