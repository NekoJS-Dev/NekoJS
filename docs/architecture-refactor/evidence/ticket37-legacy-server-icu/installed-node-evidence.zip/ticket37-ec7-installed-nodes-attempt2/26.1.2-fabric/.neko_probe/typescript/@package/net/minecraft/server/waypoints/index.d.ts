import { $Set } from "java:java/util";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $WaypointManager, $WaypointTransmitter } from "java:net/minecraft/world/waypoints";

declare module "java:net/minecraft/server/waypoints" {
    export class $ServerWaypointManager implements $WaypointManager {
        constructor();
        addPlayer(player: $ServerPlayer): void;
        breakAllConnections(): void;
        remakeConnections(waypoint: $WaypointTransmitter): void;
        removePlayer(player: $ServerPlayer): void;
        trackWaypoint(waypoint: $WaypointTransmitter): void;
        transmitters(): $Set<$WaypointTransmitter>;
        untrackWaypoint(waypoint: $WaypointTransmitter): void;
        updatePlayer(player: $ServerPlayer): void;
        updateWaypoint(waypoint: $WaypointTransmitter): void;
    }

}
