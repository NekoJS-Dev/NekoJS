import { $Entity } from "java:net/minecraft/world/entity";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/ai/control" {
    export interface $Control {
        rotateTowards(fromAngle: number, toAngle: number, maxRot: number): number;
    }

    export class $JumpControl implements $Control {
        constructor(mob: $Mob);
        jump(): void;
        tick(): void;
    }

    export class $LookControl implements $Control {
        constructor(mob: $Mob);
        get wantedX(): number;
        getWantedX(): number;
        get wantedY(): number;
        getWantedY(): number;
        get wantedZ(): number;
        getWantedZ(): number;
        get lookingAtTarget(): boolean;
        isLookingAtTarget(): boolean;
        setLookAt(x: number, y: number, z: number, yMaxRotSpeed: number, xMaxRotAngle: number): void;
        setLookAt(x: number, y: number, z: number): void;
        setLookAt(target: $Entity, yMaxRotSpeed: number, xMaxRotAngle: number): void;
        tick(): void;
    }

    export class $MoveControl implements $Control {
        constructor(mob: $Mob);
        static MIN_SPEED: number;
        static MIN_SPEED_SQR: number;
        get speedModifier(): number;
        getSpeedModifier(): number;
        get wantedX(): number;
        getWantedX(): number;
        get wantedY(): number;
        getWantedY(): number;
        get wantedZ(): number;
        getWantedZ(): number;
        hasWanted(): boolean;
        setWait(): void;
        setWantedPosition(x: number, y: number, z: number, speedModifier: number): void;
        strafe(forwards: number, right: number): void;
        tick(): void;
    }

}
