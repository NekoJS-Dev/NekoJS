import { $Codec } from "java:com/mojang/serialization";
import { $Boolean, $Enum, $Integer, $Iterable, $Long, $Record, $String, $Void } from "java:java/lang";
import { $Iterator, $List, $Optional, $Set, $UUID } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $GlobalPos } from "java:net/minecraft/core";
import { $Unit, $Unit_ } from "java:net/minecraft/util";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $Entity, $LivingEntity, $Mob } from "java:net/minecraft/world/entity";
import { $PositionTracker, $SpearAttack$SpearStatus, $SpearAttack$SpearStatus_ } from "java:net/minecraft/world/entity/ai/behavior";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Hoglin } from "java:net/minecraft/world/entity/monster/hoglin";
import { $AbstractPiglin } from "java:net/minecraft/world/entity/monster/piglin";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Path } from "java:net/minecraft/world/level/pathfinder";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/ai/memory" {
    export class $ExpirableValue<T> extends $Record {
        constructor(value: T, timeToLive: $Optional<number>);
        static codec<T>(valueCodec: $Codec<T>): $Codec<$ExpirableValue<T>>;
        static of<T>(value: T, ticksUntilExpiry: number): $ExpirableValue<T>;
        static of<T>(value: T): $ExpirableValue<T>;
        equals(o: object): boolean;
        hashCode(): number;
        timeToLive(): $Optional<number>;
        toString(): string;
        value(): T;
    }

    export class $MemoryMap implements $Iterable {
        static CODEC: $Codec<$MemoryMap>;
        static EMPTY: $MemoryMap;
        static of(memories: $Stream<$MemoryMap$Value<any>>): $MemoryMap;
        equals(obj: object): boolean;
        get<U>(type: $MemoryModuleType<U>): $ExpirableValue<U>;
        hashCode(): number;
        iterator(): $Iterator<$MemoryMap$Value<any>>;
        toString(): string;
    }

    export class $MemoryMap$Value<U> extends $Record {
        constructor(type: $MemoryModuleType<U>, value: $ExpirableValue<U>);
        static createUnchecked<U>(type: $MemoryModuleType<U>, value: $ExpirableValue<any>): $MemoryMap$Value<U>;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $MemoryModuleType<U>;
        value(): $ExpirableValue<U>;
    }

    export class $MemoryModuleType<U> {
        constructor(codec: $Optional<$Codec<U>>);
        static ADMIRING_DISABLED: $MemoryModuleType<boolean>;
        static ADMIRING_ITEM: $MemoryModuleType<boolean>;
        static ANGRY_AT: $MemoryModuleType<$UUID>;
        static ATE_RECENTLY: $MemoryModuleType<boolean>;
        static ATTACK_COOLING_DOWN: $MemoryModuleType<boolean>;
        static ATTACK_TARGET: $MemoryModuleType<$LivingEntity>;
        static ATTACK_TARGET_COOLDOWN: $MemoryModuleType<number>;
        static AVOID_TARGET: $MemoryModuleType<$LivingEntity>;
        static BREED_TARGET: $MemoryModuleType<$AgeableMob>;
        static BREEZE_JUMP_COOLDOWN: $MemoryModuleType<$Unit>;
        static BREEZE_JUMP_INHALING: $MemoryModuleType<$Unit>;
        static BREEZE_JUMP_TARGET: $MemoryModuleType<$BlockPos>;
        static BREEZE_LEAVING_WATER: $MemoryModuleType<$Unit>;
        static BREEZE_SHOOT: $MemoryModuleType<$Unit>;
        static BREEZE_SHOOT_CHARGING: $MemoryModuleType<$Unit>;
        static BREEZE_SHOOT_COOLDOWN: $MemoryModuleType<$Unit>;
        static BREEZE_SHOOT_RECOVERING: $MemoryModuleType<$Unit>;
        static CANT_REACH_WALK_TARGET_SINCE: $MemoryModuleType<number>;
        static CELEBRATE_LOCATION: $MemoryModuleType<$BlockPos>;
        static CHARGE_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static DANCING: $MemoryModuleType<boolean>;
        static DANGER_DETECTED_RECENTLY: $MemoryModuleType<boolean>;
        static DIG_COOLDOWN: $MemoryModuleType<$Unit>;
        static DISABLE_WALK_TO_ADMIRE_ITEM: $MemoryModuleType<boolean>;
        static DISTURBANCE_LOCATION: $MemoryModuleType<$BlockPos>;
        static DOORS_TO_CLOSE: $MemoryModuleType<$Set<$GlobalPos>>;
        static DUMMY: $MemoryModuleType<void>;
        static GAZE_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static GOLEM_DETECTED_RECENTLY: $MemoryModuleType<boolean>;
        static HAS_HUNTING_COOLDOWN: $MemoryModuleType<boolean>;
        static HEARD_BELL_TIME: $MemoryModuleType<number>;
        static HIDING_PLACE: $MemoryModuleType<$GlobalPos>;
        static HOME: $MemoryModuleType<$GlobalPos>;
        static HUNTED_RECENTLY: $MemoryModuleType<boolean>;
        static HURT_BY: $MemoryModuleType<$DamageSource>;
        static HURT_BY_ENTITY: $MemoryModuleType<$LivingEntity>;
        static INTERACTION_TARGET: $MemoryModuleType<$LivingEntity>;
        static IS_EMERGING: $MemoryModuleType<$Unit>;
        static IS_IN_WATER: $MemoryModuleType<$Unit>;
        static IS_PANICKING: $MemoryModuleType<boolean>;
        static IS_PREGNANT: $MemoryModuleType<$Unit>;
        static IS_SNIFFING: $MemoryModuleType<$Unit>;
        static IS_TEMPTED: $MemoryModuleType<boolean>;
        static ITEM_PICKUP_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static JOB_SITE: $MemoryModuleType<$GlobalPos>;
        static LAST_SLEPT: $MemoryModuleType<number>;
        static LAST_WOKEN: $MemoryModuleType<number>;
        static LAST_WORKED_AT_POI: $MemoryModuleType<number>;
        static LIKED_NOTEBLOCK_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static LIKED_NOTEBLOCK_POSITION: $MemoryModuleType<$GlobalPos>;
        static LIKED_PLAYER: $MemoryModuleType<$UUID>;
        static LONG_JUMP_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static LONG_JUMP_MID_JUMP: $MemoryModuleType<boolean>;
        static LOOK_TARGET: $MemoryModuleType<$PositionTracker>;
        static MEETING_POINT: $MemoryModuleType<$GlobalPos>;
        static NEARBY_ADULT_PIGLINS: $MemoryModuleType<$List<$AbstractPiglin>>;
        static NEAREST_ATTACKABLE: $MemoryModuleType<$LivingEntity>;
        static NEAREST_BED: $MemoryModuleType<$BlockPos>;
        static NEAREST_HOSTILE: $MemoryModuleType<$LivingEntity>;
        static NEAREST_LIVING_ENTITIES: $MemoryModuleType<$List<$LivingEntity>>;
        static NEAREST_PLAYERS: $MemoryModuleType<$List<$Player>>;
        static NEAREST_PLAYER_HOLDING_WANTED_ITEM: $MemoryModuleType<$Player>;
        static NEAREST_REPELLENT: $MemoryModuleType<$BlockPos>;
        static NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD: $MemoryModuleType<$Player>;
        static NEAREST_VISIBLE_ADULT: $MemoryModuleType<$LivingEntity>;
        static NEAREST_VISIBLE_ADULT_HOGLINS: $MemoryModuleType<$List<$Hoglin>>;
        static NEAREST_VISIBLE_ADULT_PIGLIN: $MemoryModuleType<$AbstractPiglin>;
        static NEAREST_VISIBLE_ADULT_PIGLINS: $MemoryModuleType<$List<$AbstractPiglin>>;
        static NEAREST_VISIBLE_ATTACKABLE_PLAYER: $MemoryModuleType<$Player>;
        static NEAREST_VISIBLE_ATTACKABLE_PLAYERS: $MemoryModuleType<$List<$Player>>;
        static NEAREST_VISIBLE_BABY_HOGLIN: $MemoryModuleType<$Hoglin>;
        static NEAREST_VISIBLE_HUNTABLE_HOGLIN: $MemoryModuleType<$Hoglin>;
        static NEAREST_VISIBLE_LIVING_ENTITIES: $MemoryModuleType<$NearestVisibleLivingEntities>;
        static NEAREST_VISIBLE_NEMESIS: $MemoryModuleType<$Mob>;
        static NEAREST_VISIBLE_PLAYER: $MemoryModuleType<$Player>;
        static NEAREST_VISIBLE_WANTED_ITEM: $MemoryModuleType<$ItemEntity>;
        static NEAREST_VISIBLE_ZOMBIFIED: $MemoryModuleType<$LivingEntity>;
        static PACIFIED: $MemoryModuleType<boolean>;
        static PATH: $MemoryModuleType<$Path>;
        static PLAY_DEAD_TICKS: $MemoryModuleType<number>;
        static POTENTIAL_JOB_SITE: $MemoryModuleType<$GlobalPos>;
        static RAM_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static RAM_TARGET: $MemoryModuleType<$Vec3>;
        static RECENT_PROJECTILE: $MemoryModuleType<$Unit>;
        static RIDE_TARGET: $MemoryModuleType<$Entity>;
        static ROAR_SOUND_COOLDOWN: $MemoryModuleType<$Unit>;
        static ROAR_SOUND_DELAY: $MemoryModuleType<$Unit>;
        static ROAR_TARGET: $MemoryModuleType<$LivingEntity>;
        static SECONDARY_JOB_SITE: $MemoryModuleType<$List<$GlobalPos>>;
        static SNIFFER_DIGGING: $MemoryModuleType<boolean>;
        static SNIFFER_EXPLORED_POSITIONS: $MemoryModuleType<$List<$GlobalPos>>;
        static SNIFFER_HAPPY: $MemoryModuleType<boolean>;
        static SNIFFER_SNIFFING_TARGET: $MemoryModuleType<$BlockPos>;
        static SNIFF_COOLDOWN: $MemoryModuleType<$Unit>;
        static SONIC_BOOM_COOLDOWN: $MemoryModuleType<$Unit>;
        static SONIC_BOOM_SOUND_COOLDOWN: $MemoryModuleType<$Unit>;
        static SONIC_BOOM_SOUND_DELAY: $MemoryModuleType<$Unit>;
        static SPEAR_CHARGE_POSITION: $MemoryModuleType<$Vec3>;
        static SPEAR_ENGAGE_TIME: $MemoryModuleType<number>;
        static SPEAR_FLEEING_POSITION: $MemoryModuleType<$Vec3>;
        static SPEAR_FLEEING_TIME: $MemoryModuleType<number>;
        static SPEAR_STATUS: $MemoryModuleType<$SpearAttack$SpearStatus>;
        static TEMPTATION_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static TEMPTING_PLAYER: $MemoryModuleType<$Player>;
        static TIME_TRYING_TO_REACH_ADMIRE_ITEM: $MemoryModuleType<number>;
        static TOUCH_COOLDOWN: $MemoryModuleType<$Unit>;
        static TRANSPORT_ITEMS_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static UNIVERSAL_ANGER: $MemoryModuleType<boolean>;
        static UNREACHABLE_TONGUE_TARGETS: $MemoryModuleType<$List<$UUID>>;
        static UNREACHABLE_TRANSPORT_BLOCK_POSITIONS: $MemoryModuleType<$Set<$GlobalPos>>;
        static VIBRATION_COOLDOWN: $MemoryModuleType<$Unit>;
        static VISIBLE_ADULT_HOGLIN_COUNT: $MemoryModuleType<number>;
        static VISIBLE_ADULT_PIGLIN_COUNT: $MemoryModuleType<number>;
        static VISIBLE_VILLAGER_BABIES: $MemoryModuleType<$List<$LivingEntity>>;
        static VISITED_BLOCK_POSITIONS: $MemoryModuleType<$Set<$GlobalPos>>;
        static WALK_TARGET: $MemoryModuleType<$WalkTarget>;
        get codec(): $Optional<$Codec<$ExpirableValue<U>>>;
        getCodec(): $Optional<$Codec<$ExpirableValue<U>>>;
        canSerialize(): boolean;
        toString(): string;
    }

    export class $MemoryStatus {
        static REGISTERED: $MemoryStatus;
        static VALUE_ABSENT: $MemoryStatus;
        static VALUE_PRESENT: $MemoryStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MemoryStatus[];
        static valueOf(name: string): $MemoryStatus;
    }

    export class $NearestVisibleLivingEntities {
        constructor(level: $ServerLevel, body: $LivingEntity, livingEntities: $LivingEntity[]);
        static empty(): $NearestVisibleLivingEntities;
        contains(filter: $Predicate<$LivingEntity>): boolean;
        contains(targetEntity: $LivingEntity): boolean;
        findAll(filter: $Predicate<$LivingEntity>): $Iterable<$LivingEntity>;
        findClosest(filter: $Predicate<$LivingEntity>): $Optional<$LivingEntity>;
        find(filter: $Predicate<$LivingEntity>): $Stream<$LivingEntity>;
        nearbyEntities(): $List<$LivingEntity>;
    }

    export class $WalkTarget {
        constructor(target: $BlockPos_, speedModifier: number, closeEnoughDist: number);
        constructor(target: $Entity, speedModifier: number, closeEnoughDist: number);
        constructor(target: $PositionTracker, speedModifier: number, closeEnoughDist: number);
        constructor(target: $Vec3_, speedModifier: number, closeEnoughDist: number);
        get closeEnoughDist(): number;
        getCloseEnoughDist(): number;
        get speedModifier(): number;
        getSpeedModifier(): number;
        get target(): $PositionTracker;
        getTarget(): $PositionTracker;
    }

    export type $MemoryStatus_ = $MemoryStatus | "REGISTERED" | "VALUE_ABSENT" | "VALUE_PRESENT";
}
