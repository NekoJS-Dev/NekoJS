import { $ImmutableList } from "java:com/google/common/collect";
import { $Float } from "java:java/lang";
import { $BiConsumer } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SimpleContainer } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $PathfinderMob } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $InventoryCarrier } from "java:net/minecraft/world/entity/npc";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $DynamicGameEventListener } from "java:net/minecraft/world/level/gameevent";
import { $VibrationSystem, $VibrationSystem$Data, $VibrationSystem$User } from "java:net/minecraft/world/level/gameevent/vibrations";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/allay" {
    export class $Allay extends $PathfinderMob implements $InventoryCarrier, $VibrationSystem {
        constructor(type: $EntityType<$Allay>, level: $Level);
        static MAX_NOTEBLOCK_DISTANCE: number;
        static THROW_SOUND_PITCHES: $ImmutableList<number>;
        get brain(): $Brain<$Allay>;
        getBrain(): $Brain<$Allay>;
        get inventory(): $SimpleContainer;
        getInventory(): $SimpleContainer;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get vibrationData(): $VibrationSystem$Data;
        getVibrationData(): $VibrationSystem$Data;
        get vibrationUser(): $VibrationSystem$User;
        getVibrationUser(): $VibrationSystem$User;
        get dancing(): boolean;
        isDancing(): boolean;
        set dancing(value: boolean);
        get flapping(): boolean;
        isFlapping(): boolean;
        get spinning(): boolean;
        isSpinning(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canPickUpLoot(): boolean;
        equipmentHasChanged(previous: $ItemStack_, current: $ItemStack_): boolean;
        getHoldingItemAnimationProgress(a: number): number;
        getSpinningProgress(a: number): number;
        handleEntityEvent(id: number): void;
        hasItemInHand(): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        removeWhenFarAway(distSqr: number): boolean;
        setJukeboxPlaying(jukebox: $BlockPos_, isPlaying: boolean): void;
        tick(): void;
        travel(input: $Vec3_): void;
        updateDynamicGameEventListener(action: $BiConsumer<$DynamicGameEventListener<any>, $ServerLevel>): void;
        wantsToPickUp(level: $ServerLevel, itemStack: $ItemStack_): boolean;
    }

}
