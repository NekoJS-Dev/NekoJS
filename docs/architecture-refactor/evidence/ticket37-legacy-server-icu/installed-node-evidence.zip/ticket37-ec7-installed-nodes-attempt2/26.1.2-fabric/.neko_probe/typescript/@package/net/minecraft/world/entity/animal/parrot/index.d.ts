import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_, $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $Entity, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $SpawnGroupData, $TamableAnimal } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal, $FlyingAnimal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Level, $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/parrot" {
    export class $Parrot extends $ShoulderRidingEntity implements $FlyingAnimal {
        constructor(type: $EntityType<$Parrot>, level: $Level);
        flap: number;
        flapSpeed: number;
        oFlap: number;
        oFlapSpeed: number;
        get ambientSound(): $SoundEvent;
        getAmbientSound(): $SoundEvent;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get variant(): $Parrot$Variant;
        getVariant(): $Parrot$Variant;
        get voicePitch(): number;
        getVoicePitch(): number;
        get baby(): boolean;
        isBaby(): boolean;
        get flying(): boolean;
        isFlying(): boolean;
        get partyParrot(): boolean;
        isPartyParrot(): boolean;
        get pushable(): boolean;
        isPushable(): boolean;
        static checkParrotSpawnRules(type: $EntityType<$Parrot>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        static getAmbient(level: $Level, random: $RandomSource): $SoundEvent;
        static getPitch(random: $RandomSource): number;
        static imitateNearbyMobs(level: $Level, entity: $Entity): boolean;
        aiStep(): void;
        canMate(partner: $Animal): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        get<T>(type: $DataComponentType<T>): T;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        setRecordPlayingNearby(jukebox: $BlockPos_, isPlaying: boolean): void;
    }

    export class $Parrot$Variant {
        static BLUE: $Parrot$Variant;
        static GRAY: $Parrot$Variant;
        static GREEN: $Parrot$Variant;
        static RED_BLUE: $Parrot$Variant;
        static YELLOW_BLUE: $Parrot$Variant;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Parrot$Variant[];
        static valueOf(name: string): $Parrot$Variant;
    }

    export class $ShoulderRidingEntity extends $TamableAnimal {
        canSitOnShoulder(): boolean;
        tick(): void;
    }

    export type $Parrot$Variant_ = $Parrot$Variant | "BLUE" | "GRAY" | "GREEN" | "RED_BLUE" | "YELLOW_BLUE";
}
