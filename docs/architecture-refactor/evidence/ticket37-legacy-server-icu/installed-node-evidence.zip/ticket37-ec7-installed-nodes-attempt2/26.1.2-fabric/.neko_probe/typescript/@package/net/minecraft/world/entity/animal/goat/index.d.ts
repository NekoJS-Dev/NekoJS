import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $AgeableMob, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/goat" {
    export class $Goat extends $Animal {
        constructor(type: $EntityType<$Goat>, level: $Level);
        static BABY_DEFAULT_X_HEAD_ROT: number;
        static GOAT_FALL_DAMAGE_REDUCTION: number;
        static GOAT_SCREAMING_CHANCE: number;
        static LONG_JUMPING_DIMENSIONS: $EntityDimensions;
        static MAX_ADDED_RAMMING_X_HEAD_ROT: number;
        static UNIHORN_CHANCE: number;
        get ageScale(): number;
        getAgeScale(): number;
        get brain(): $Brain<$Goat>;
        getBrain(): $Brain<$Goat>;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get rammingXHeadRot(): number;
        getRammingXHeadRot(): number;
        get screamingGoat(): boolean;
        isScreamingGoat(): boolean;
        set screamingGoat(value: boolean);
        static checkGoatSpawnRules(type: $EntityType<$Animal>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        createHorn(): $ItemStack;
        dropHorn(): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Goat;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        handleEntityEvent(id: number): void;
        hasLeftHorn(): boolean;
        hasRightHorn(): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
    }

}
