import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $String } from "java:java/lang";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $Container, $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $EntityDimensions, $EntityReference, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $EquipmentSlot, $EquipmentSlot_, $HasCustomInventoryScreen, $LivingEntity, $OwnableEntity, $PlayerRideableJumping, $Pose, $Pose_, $SlotAccess, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $RangedAttackMob } from "java:net/minecraft/world/entity/monster";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LevelAccessor, $ServerLevelAccessor } from "java:net/minecraft/world/level";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/equine" {
    export class $AbstractChestedHorse extends $AbstractHorse {
        get inventoryColumns(): number;
        getInventoryColumns(): number;
        get quadLeashOffsets(): $Vec3[];
        getQuadLeashOffsets(): $Vec3[];
        static createBaseChestedHorseAttributes(): $AttributeSupplier$Builder;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getSlot(slot: number): $SlotAccess;
        hasChest(): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
    }

    export class $AbstractHorse extends $Animal implements $PlayerRideableJumping, $HasCustomInventoryScreen, $OwnableEntity {
        static BREEDING_CROSS_FACTOR: number;
        static CHEST_SLOT_OFFSET: number;
        static INVENTORY_ROWS: number;
        static INVENTORY_SLOT_OFFSET: number;
        sprintCounter: number;
        tailCounter: number;
        get ambientSoundInterval(): number;
        getAmbientSoundInterval(): number;
        get ambientStandInterval(): number;
        getAmbientStandInterval(): number;
        get ambientStandSound(): $SoundEvent;
        getAmbientStandSound(): $SoundEvent;
        get controllingPassenger(): $LivingEntity;
        getControllingPassenger(): $LivingEntity;
        get inventoryColumns(): number;
        getInventoryColumns(): number;
        get inventorySize(): number;
        getInventorySize(): number;
        get maxSpawnClusterSize(): number;
        getMaxSpawnClusterSize(): number;
        get maxTemper(): number;
        getMaxTemper(): number;
        get ownerReference(): $EntityReference<$LivingEntity>;
        getOwnerReference(): $EntityReference<$LivingEntity>;
        get quadLeashOffsets(): $Vec3[];
        getQuadLeashOffsets(): $Vec3[];
        get temper(): number;
        getTemper(): number;
        set temper(value: number);
        get bred(): boolean;
        isBred(): boolean;
        set bred(value: boolean);
        get eating(): boolean;
        isEating(): boolean;
        set eating(value: boolean);
        get immobile(): boolean;
        isImmobile(): boolean;
        get mobControlled(): boolean;
        isMobControlled(): boolean;
        get pushable(): boolean;
        isPushable(): boolean;
        get standing(): boolean;
        isStanding(): boolean;
        set standing(value: number);
        get tamed(): boolean;
        isTamed(): boolean;
        set tamed(value: boolean);
        static createBaseHorseAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canEatGrass(): boolean;
        canJump(): boolean;
        canMate(partner: $Animal): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        causeFallDamage(fallDistance: number, damageModifier: number, damageSource: $DamageSource): boolean;
        clearStanding(): void;
        equipBodyArmor(player: $Player, itemStack: $ItemStack_): void;
        fedFood(player: $Player, itemStack: $ItemStack_): $InteractionResult;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDismountLocationForPassenger(passenger: $LivingEntity): $Vec3;
        getEatAnim(a: number): number;
        getMouthAnim(a: number): number;
        getSlot(slot: number): $SlotAccess;
        getStandAnim(a: number): number;
        handleEntityEvent(id: number): void;
        handleStartJump(jumpScale: number): void;
        handleStopJump(): void;
        hasInventoryChanged(oldInventory: $Container): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        makeMad(): void;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        modifyTemper(amount: number): number;
        onClimbable(): boolean;
        onElasticLeashPull(): void;
        onPlayerJump(jumpAmount: number): void;
        openCustomInventoryScreen(player: $Player): void;
        standIfPossible(): void;
        supportQuadLeash(): boolean;
        tameWithName(player: $Player): boolean;
        tick(): void;
    }

    export class $Donkey extends $AbstractChestedHorse {
        constructor(type: $EntityType<$Donkey>, level: $Level);
        canMate(partner: $Animal): boolean;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
    }

    export class $Horse extends $AbstractHorse {
        constructor(type: $EntityType<$Horse>, level: $Level);
        get markings(): $Markings;
        getMarkings(): $Markings;
        get variant(): $Variant;
        getVariant(): $Variant;
        canMate(partner: $Animal): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        get<T>(type: $DataComponentType<T>): T;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
    }

    export class $Llama extends $AbstractChestedHorse implements $RangedAttackMob {
        constructor(type: $EntityType<$Llama>, level: $Level);
        get caravanHead(): $Llama;
        getCaravanHead(): $Llama;
        get inventoryColumns(): number;
        getInventoryColumns(): number;
        get leashOffset(): $Vec3;
        getLeashOffset(): $Vec3;
        get maxTemper(): number;
        getMaxTemper(): number;
        get strength(): number;
        getStrength(): number;
        get variant(): $Llama$Variant;
        getVariant(): $Llama$Variant;
        get immobile(): boolean;
        isImmobile(): boolean;
        get traderLlama(): boolean;
        isTraderLlama(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canEatGrass(): boolean;
        canMate(partner: $Animal): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        causeFallDamage(fallDistance: number, damageModifier: number, damageSource: $DamageSource): boolean;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $Llama;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        get<T>(type: $DataComponentType<T>): T;
        hasCaravanTail(): boolean;
        inCaravan(): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        joinCaravan(tail: $Llama): void;
        leaveCaravan(): void;
        performRangedAttack(target: $LivingEntity, power: number): void;
        supportQuadLeash(): boolean;
    }

    export class $Llama$Variant {
        static BROWN: $Llama$Variant;
        static CREAMY: $Llama$Variant;
        static GRAY: $Llama$Variant;
        static WHITE: $Llama$Variant;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Llama$Variant[];
        static valueOf(name: string): $Llama$Variant;
    }

    export class $Markings {
        static BLACK_DOTS: $Markings;
        static NONE: $Markings;
        static WHITE: $Markings;
        static WHITE_DOTS: $Markings;
        static WHITE_FIELD: $Markings;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Markings[];
        static valueOf(name: string): $Markings;
    }

    export class $Mule extends $AbstractChestedHorse {
        constructor(type: $EntityType<$Mule>, level: $Level);
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
    }

    export class $SkeletonHorse extends $AbstractHorse {
        constructor(type: $EntityType<$SkeletonHorse>, level: $Level);
        get trap(): boolean;
        isTrap(): boolean;
        set trap(value: boolean);
        static checkSkeletonHorseSpawnRules(type: $EntityType<$Animal>, level: $LevelAccessor, spawnReason: $EntitySpawnReason_, pos: $BlockPos_, random: $RandomSource): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        aiStep(): void;
        canAgeUp(): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
    }

    export class $TraderLlama extends $Llama {
        constructor(type: $EntityType<$TraderLlama>, level: $Level);
        get traderLlama(): boolean;
        isTraderLlama(): boolean;
        aiStep(): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
    }

    export class $Variant {
        static BLACK: $Variant;
        static BROWN: $Variant;
        static CHESTNUT: $Variant;
        static CREAMY: $Variant;
        static DARK_BROWN: $Variant;
        static GRAY: $Variant;
        static WHITE: $Variant;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Variant[];
        static valueOf(name: string): $Variant;
    }

    export class $ZombieHorse extends $AbstractHorse {
        constructor(type: $EntityType<$ZombieHorse>, level: $Level);
        get quadLeashOffsets(): $Vec3[];
        getQuadLeashOffsets(): $Vec3[];
        get mobControlled(): boolean;
        isMobControlled(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canAgeUp(): boolean;
        canBeLeashed(): boolean;
        canFallInLove(): boolean;
        canUseSlot(slot: $EquipmentSlot_): boolean;
        chargeSpeedModifier(): number;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        interact(player: $Player, hand: $InteractionHand_, location: $Vec3_): $InteractionResult;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        removeWhenFarAway(distSqr: number): boolean;
    }

    export type $Llama$Variant_ = $Llama$Variant | "BROWN" | "CREAMY" | "GRAY" | "WHITE";
    export type $Markings_ = $Markings | "BLACK_DOTS" | "NONE" | "WHITE" | "WHITE_DOTS" | "WHITE_FIELD";
    export type $Variant_ = $Variant | "BLACK" | "BROWN" | "CHESTNUT" | "CREAMY" | "DARK_BROWN" | "GRAY" | "WHITE";
}
