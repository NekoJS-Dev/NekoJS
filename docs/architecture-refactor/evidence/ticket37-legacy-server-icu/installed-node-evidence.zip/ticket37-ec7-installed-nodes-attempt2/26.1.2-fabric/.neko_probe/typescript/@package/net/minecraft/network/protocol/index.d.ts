import { $Enum, $Iterable, $Record, $String } from "java:java/lang";
import { $Consumer, $Function } from "java:java/util/function";
import { $StreamCodec, $StreamDecoder, $StreamMemberEncoder } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

export * as common from "java:net/minecraft/network/protocol/common";
export * as cookie from "java:net/minecraft/network/protocol/cookie";
export * as game from "java:net/minecraft/network/protocol/game";
export * as login from "java:net/minecraft/network/protocol/login";
export * as ping from "java:net/minecraft/network/protocol/ping";
export * as status from "java:net/minecraft/network/protocol/status";

declare module "java:net/minecraft/network/protocol" {
    export class $BundleDelimiterPacket<T extends $PacketListener> implements $Packet {
        constructor();
        handle(listener: T): void;
        type(): $PacketType<$BundleDelimiterPacket<T>>;
    }

    export class $BundlePacket<T extends $PacketListener> implements $Packet {
        subPackets(): $Iterable<$Packet<any>>;
        type(): $PacketType<$BundlePacket<T>>;
    }

    export interface $BundlerInfo {
        createForPacket<T, P>(bundlePacketType: $PacketType<P>, constructor: $Function<$Iterable<$Packet<any>>, P>, delimiterPacket: $BundleDelimiterPacket<any>): $BundlerInfo;
        startPacketBundling(packet: $Packet<any>): $BundlerInfo$Bundler;
        unbundlePacket(packet: $Packet<any>, output: $Consumer<$Packet<any>>): void;
        static BUNDLE_SIZE_LIMIT: number;
    }

    export interface $BundlerInfo$Bundler {
        addPacket(packet: $Packet<any>): $Packet<any>;
    }

    export interface $Packet<T extends $PacketListener> {
        codec<B, T>(writer: $StreamMemberEncoder<B, T>, reader: $StreamDecoder<B, T>): $StreamCodec<B, T>;
        handle(listener: T): void;
        isSkippable(): boolean;
        isTerminal(): boolean;
        type(): $PacketType<$Packet<T>>;
    }

    export class $PacketFlow {
        static CLIENTBOUND: $PacketFlow;
        static SERVERBOUND: $PacketFlow;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PacketFlow[];
        static valueOf(name: string): $PacketFlow;
    }

    export class $PacketType<T extends $Packet<any>> extends $Record {
        constructor(flow: $PacketFlow_, id: $Identifier_);
        equals(o: object): boolean;
        flow(): $PacketFlow;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
    }

    export type $PacketFlow_ = $PacketFlow | "CLIENTBOUND" | "SERVERBOUND";
}
