import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance } from "java:net/minecraft/world/effect";
import { $Entity, $LivingEntity } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Monster, $RangedAttackMob } from "java:net/minecraft/world/entity/monster";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/boss/wither" {
    export class $WitherBoss extends $Monster implements $RangedAttackMob {
        constructor(type: $EntityType<$WitherBoss>, level: $Level);
        get headXRots(): number[];
        getHeadXRots(): number[];
        get headYRots(): number[];
        getHeadYRots(): number[];
        get invulnerableTicks(): number;
        getInvulnerableTicks(): number;
        set invulnerableTicks(value: number);
        get powered(): boolean;
        isPowered(): boolean;
        static canDestroy(state: $BlockState_): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        addEffect(newEffect: $MobEffectInstance, source: $Entity): boolean;
        aiStep(): void;
        canBeAffected(newEffect: $MobEffectInstance): boolean;
        canUsePortal(ignorePassenger: boolean): boolean;
        checkDespawn(): void;
        getAlternativeTarget(headIndex: number): number;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        makeInvulnerable(): void;
        makeStuckInBlock(blockState: $BlockState_, speedMultiplier: $Vec3_): void;
        performRangedAttack(target: $LivingEntity, power: number): void;
        setAlternativeTarget(headIndex: number, entityId: number): void;
        startSeenByPlayer(player: $ServerPlayer): void;
        stopSeenByPlayer(player: $ServerPlayer): void;
    }

}
