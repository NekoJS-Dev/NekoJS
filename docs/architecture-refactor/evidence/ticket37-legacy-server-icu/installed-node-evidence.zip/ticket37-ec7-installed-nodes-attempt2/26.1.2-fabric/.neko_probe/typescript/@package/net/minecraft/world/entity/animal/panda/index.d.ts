import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $String } from "java:java/lang";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource, $StringRepresentable } from "java:net/minecraft/util";
import { $DifficultyInstance, $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $Entity, $EntityDimensions, $EntitySpawnReason, $EntitySpawnReason_, $Pose, $Pose_, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/world/entity/animal/panda" {
    export class $Panda extends $Animal {
        constructor(type: $EntityType<$Panda>, level: $Level);
        static TOTAL_ROLL_STEPS: number;
        rollCounter: number;
        get hiddenGene(): $Panda$Gene;
        getHiddenGene(): $Panda$Gene;
        set hiddenGene(value: $Panda$Gene_);
        get mainGene(): $Panda$Gene;
        getMainGene(): $Panda$Gene;
        set mainGene(value: $Panda$Gene_);
        get sneezeCounter(): number;
        getSneezeCounter(): number;
        set sneezeCounter(value: number);
        get unhappyCounter(): number;
        getUnhappyCounter(): number;
        set unhappyCounter(value: number);
        get variant(): $Panda$Gene;
        getVariant(): $Panda$Gene;
        get aggressive(): boolean;
        isAggressive(): boolean;
        get brown(): boolean;
        isBrown(): boolean;
        get eating(): boolean;
        isEating(): boolean;
        get lazy(): boolean;
        isLazy(): boolean;
        get onBack(): boolean;
        isOnBack(): boolean;
        set onBack(value: boolean);
        get playful(): boolean;
        isPlayful(): boolean;
        get rolling(): boolean;
        isRolling(): boolean;
        get scared(): boolean;
        isScared(): boolean;
        get sitting(): boolean;
        isSitting(): boolean;
        get sneezing(): boolean;
        isSneezing(): boolean;
        get weak(): boolean;
        isWeak(): boolean;
        get worried(): boolean;
        isWorried(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canBeLeashed(): boolean;
        canPerformAction(): boolean;
        doHurtTarget(level: $ServerLevel, target: $Entity): boolean;
        eat(value: boolean): void;
        finalizeSpawn(level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnReason: $EntitySpawnReason_, groupData: $SpawnGroupData): $SpawnGroupData;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        getLieOnBackAmount(a: number): number;
        getRollAmount(a: number): number;
        getSitAmount(a: number): number;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        isFood(itemStack: $ItemStack_): boolean;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        playAttackSound(): void;
        roll(value: boolean): void;
        setAttributes(): void;
        setGeneFromParents(parent1: $Panda, parent2: $Panda): void;
        sit(value: boolean): void;
        sneeze(value: boolean): void;
        tick(): void;
    }

    export class $Panda$Gene {
        static AGGRESSIVE: $Panda$Gene;
        static BROWN: $Panda$Gene;
        static LAZY: $Panda$Gene;
        static NORMAL: $Panda$Gene;
        static PLAYFUL: $Panda$Gene;
        static WEAK: $Panda$Gene;
        static WORRIED: $Panda$Gene;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Panda$Gene[];
        static valueOf(name: string): $Panda$Gene;
    }

    export type $Panda$Gene_ = $Panda$Gene | "AGGRESSIVE" | "BROWN" | "LAZY" | "NORMAL" | "PLAYFUL" | "WEAK" | "WORRIED";
}
