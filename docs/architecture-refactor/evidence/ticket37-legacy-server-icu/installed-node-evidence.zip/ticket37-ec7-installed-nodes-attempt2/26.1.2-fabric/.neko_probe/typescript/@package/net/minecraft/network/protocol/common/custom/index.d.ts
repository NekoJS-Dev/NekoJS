import { $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $StreamCodec, $StreamDecoder, $StreamMemberEncoder } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";

declare module "java:net/minecraft/network/protocol/common/custom" {
    export interface $CustomPacketPayload {
        codec<B, T>(writer: $StreamMemberEncoder<B, T>, reader: $StreamDecoder<B, T>): $StreamCodec<B, T>;
        codec<B>(fallback: $CustomPacketPayload$FallbackProvider<B>, types: $CustomPacketPayload$TypeAndCodec<any, any>[]): $StreamCodec<B, $CustomPacketPayload>;
        createType<T>(id: string): $CustomPacketPayload$Type<T>;
        type(): $CustomPacketPayload$Type<$CustomPacketPayload>;
    }

    export interface $CustomPacketPayload$FallbackProvider<B extends $FriendlyByteBuf> {
        create(typeId: $Identifier_): $StreamCodec<B, $CustomPacketPayload>;
    }

    export class $CustomPacketPayload$Type<T extends $CustomPacketPayload> extends $Record {
        constructor(id: $Identifier_);
        equals(o: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
    }

    export class $CustomPacketPayload$TypeAndCodec<B extends $FriendlyByteBuf, T extends $CustomPacketPayload> extends $Record {
        constructor(type: $CustomPacketPayload$Type<T>, codec: $StreamCodec<B, T>);
        codec(): $StreamCodec<B, T>;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $CustomPacketPayload$Type<T>;
    }

}
