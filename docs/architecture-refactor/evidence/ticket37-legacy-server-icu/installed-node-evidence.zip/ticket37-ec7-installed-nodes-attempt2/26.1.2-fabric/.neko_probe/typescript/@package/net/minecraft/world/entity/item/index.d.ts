import { $String } from "java:java/lang";
import { $UUID } from "java:java/util";
import { $CrashReportCategory } from "java:net/minecraft";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener, $ClientboundAddEntityPacket } from "java:net/minecraft/network/protocol/game";
import { $ServerEntity, $ServerLevel } from "java:net/minecraft/server/level";
import { $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $LivingEntity, $SlotAccess, $TraceableEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Explosion, $Level } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $TeleportTransition } from "java:net/minecraft/world/level/portal";

declare module "java:net/minecraft/world/entity/item" {
    export class $FallingBlockEntity extends $Entity {
        constructor(type: $EntityType<$FallingBlockEntity>, level: $Level);
        blockData: $CompoundTag;
        dropItem: boolean;
        forceTickAfterTeleportToDuplicate: boolean;
        time: number;
        get blockState(): $BlockState;
        getBlockState(): $BlockState;
        get startPos(): $BlockPos;
        getStartPos(): $BlockPos;
        set startPos(value: $BlockPos_);
        get attackable(): boolean;
        isAttackable(): boolean;
        get pickable(): boolean;
        isPickable(): boolean;
        static fall(level: $Level, pos: $BlockPos_, state: $BlockState_): $FallingBlockEntity;
        callOnBrokenAfterFall(block: $Block_, pos: $BlockPos_): void;
        causeFallDamage(fallDistance: number, damageModifier: number, damageSource: $DamageSource): boolean;
        disableDrop(): void;
        displayFireAnimation(): boolean;
        fillCrashReportCategory(category: $CrashReportCategory): void;
        getAddEntityPacket(serverEntity: $ServerEntity): $Packet<$ClientGamePacketListener>;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        recreateFromPacket(packet: $ClientboundAddEntityPacket): void;
        setHurtsEntities(damagePerDistance: number, damageMax: number): void;
        teleport(transition: $TeleportTransition): $Entity;
        tick(): void;
    }

    export class $ItemEntity extends $Entity implements $TraceableEntity {
        constructor(type: $EntityType<$ItemEntity>, level: $Level);
        constructor(level: $Level, x: number, y: number, z: number, itemStack: $ItemStack_);
        constructor(level: $Level, x: number, y: number, z: number, itemStack: $ItemStack_, deltaX: number, deltaY: number, deltaZ: number);
        static DEFAULT_HEALTH: number;
        static EYE_HEIGHT: number;
        bobOffs: number;
        get age(): number;
        getAge(): number;
        get blockPosBelowThatAffectsMyMovement(): $BlockPos;
        getBlockPosBelowThatAffectsMyMovement(): $BlockPos;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        set item(value: $ItemStack_);
        get name(): $Component;
        getName(): $Component;
        get owner(): $Entity;
        getOwner(): $Entity;
        get soundSource(): $SoundSource;
        getSoundSource(): $SoundSource;
        get visualRotationYInDegrees(): number;
        getVisualRotationYInDegrees(): number;
        get attackable(): boolean;
        isAttackable(): boolean;
        static areMergable(thisItemStack: $ItemStack_, otherItemStack: $ItemStack_): boolean;
        static getSpin(ageInTicks: number, bobOffset: number): number;
        static merge(toStack: $ItemStack_, fromStack: $ItemStack_, maxCount: number): $ItemStack;
        dampensVibrations(): boolean;
        fireImmune(): boolean;
        getSlot(slot: number): $SlotAccess;
        hasPickUpDelay(): boolean;
        hurtClient(source: $DamageSource): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        ignoreExplosion(explosion: $Explosion): boolean;
        makeFakeItem(): void;
        playerTouch(player: $Player): void;
        restoreFrom(oldEntity: $Entity): void;
        setDefaultPickUpDelay(): void;
        setExtendedLifetime(): void;
        setNeverPickUp(): void;
        setNoPickUpDelay(): void;
        setUnlimitedLifetime(): void;
        teleport(transition: $TeleportTransition): $Entity;
        tick(): void;
    }

    export class $PrimedTnt extends $Entity implements $TraceableEntity {
        constructor(type: $EntityType<$PrimedTnt>, level: $Level);
        constructor(level: $Level, x: number, y: number, z: number, owner: $LivingEntity);
        static TAG_FUSE: string;
        get blockState(): $BlockState;
        getBlockState(): $BlockState;
        set blockState(value: $BlockState_);
        get fuse(): number;
        getFuse(): number;
        set fuse(value: number);
        get owner(): $LivingEntity;
        getOwner(): $LivingEntity;
        get pickable(): boolean;
        isPickable(): boolean;
        hurtServer(level: $ServerLevel, source: $DamageSource, damage: number): boolean;
        restoreFrom(oldEntity: $Entity): void;
        teleport(transition: $TeleportTransition): $Entity;
        tick(): void;
    }

}
