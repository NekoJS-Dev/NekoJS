import { $StringReader } from "java:com/mojang/brigadier";
import { $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult, $Dynamic, $DynamicOps, $Lifecycle, $ListBuilder, $MapLike, $RecordBuilder } from "java:com/mojang/serialization";
import { $RecordCodecBuilder } from "java:com/mojang/serialization/codecs";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Boolean, $Comparable, $Number, $Record, $String } from "java:java/lang";
import { $ByteBuffer } from "java:java/nio";
import { $Path } from "java:java/nio/file";
import { $List, $Map, $Optional } from "java:java/util";
import { $BiConsumer, $Consumer, $UnaryOperator } from "java:java/util/function";
import { $IntStream, $LongStream, $Stream } from "java:java/util/stream";
import { $FileToIdConverterAccessor } from "java:net/fabricmc/fabric/mixin/loot";
import { $FileToIdConverterAccessor, $RegistryOpsAccessor } from "java:net/fabricmc/fabric/mixin/resource/conditions";
import { $Holder$Reference, $HolderGetter, $HolderLookup$Provider, $HolderLookup$RegistryLookup, $HolderOwner, $Registry } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Resource, $ResourceManager } from "java:net/minecraft/server/packs/resources";

declare module "java:net/minecraft/resources" {
    export class $DelegatingOps<T> implements $DynamicOps {
        compressMaps(): boolean;
        convertTo<U>(outOps: $DynamicOps<U>, input: T): U;
        createBoolean(value: boolean): T;
        createByteList(input: $ByteBuffer): T;
        createByte(value: number): T;
        createDouble(value: number): T;
        createFloat(value: number): T;
        createIntList(input: $IntStream): T;
        createInt(value: number): T;
        createList(input: $Stream<T>): T;
        createLongList(input: $LongStream): T;
        createLong(value: number): T;
        createMap(map: { [key: T]: T }): T;
        createMap(map: $Stream<$Pair<T, T>>): T;
        createNumeric(i: number): T;
        createShort(value: number): T;
        createString(value: string): T;
        emptyList(): T;
        emptyMap(): T;
        empty(): T;
        getBooleanValue(input: T): $DataResult<boolean>;
        getByteBuffer(input: T): $DataResult<$ByteBuffer>;
        getIntStream(input: T): $DataResult<$IntStream>;
        getList(input: T): $DataResult<$Consumer<$Consumer<T>>>;
        getLongStream(input: T): $DataResult<$LongStream>;
        getMapEntries(input: T): $DataResult<$Consumer<$BiConsumer<T, T>>>;
        getMapValues(input: T): $DataResult<$Stream<$Pair<T, T>>>;
        getMap(input: T): $DataResult<$MapLike<T>>;
        getNumberValue(input: T): $DataResult<number>;
        getStream(input: T): $DataResult<$Stream<T>>;
        getStringValue(input: T): $DataResult<string>;
        listBuilder(): $ListBuilder<T>;
        mapBuilder(): $RecordBuilder<T>;
        mergeToList(list: T, value: T): $DataResult<T>;
        mergeToList(list: T, values: T[]): $DataResult<T>;
        mergeToMap(map: T, key: T, value: T): $DataResult<T>;
        mergeToMap(map: T, values: $MapLike<T>): $DataResult<T>;
        mergeToMap(map: T, values: { [key: T]: T }): $DataResult<T>;
        mergeToPrimitive(prefix: T, value: T): $DataResult<T>;
        remove(input: T, key: string): T;
    }

    export class $FileToIdConverter extends $Record implements $FileToIdConverterAccessor, $FileToIdConverterAccessor {
        constructor(prefix: string, extension: string);
        static json(prefix: string): $FileToIdConverter;
        static registry(registry: $ResourceKey<$Registry<any>>): $FileToIdConverter;
        equals(o: object): boolean;
        extensionMatches(id: $Identifier_): boolean;
        extension(): string;
        fileToId(file: $Identifier_): $Identifier;
        hashCode(): number;
        idToFile(id: $Identifier_): $Identifier;
        listMatchingResourceStacks(manager: $ResourceManager): $Map<$Identifier, $List<$Resource>>;
        listMatchingResources(manager: $ResourceManager): $Map<$Identifier, $Resource>;
        prefix(): string;
        toString(): string;
    }

    export class $Identifier implements $Comparable {
        static ALLOWED_NAMESPACE_CHARACTERS: string;
        static CODEC: $Codec<$Identifier>;
        static DEFAULT_NAMESPACE: string;
        static ERROR_INVALID: $SimpleCommandExceptionType;
        static NAMESPACE_SEPARATOR: string;
        static REALMS_NAMESPACE: string;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Identifier>;
        get namespace(): string;
        getNamespace(): string;
        get path(): string;
        getPath(): string;
        static bySeparator(identifier: string, separator: string): $Identifier;
        static fromNamespaceAndPath(namespace: string, path: string): $Identifier;
        static isAllowedInIdentifier(c: string): boolean;
        static isValidNamespace(namespace: string): boolean;
        static isValidPath(path: string): boolean;
        static parse(identifier: string): $Identifier;
        static readNonEmpty(reader: $StringReader): $Identifier;
        static read(reader: $StringReader): $Identifier;
        static read(input: string): $DataResult<$Identifier>;
        static tryBuild(namespace: string, path: string): $Identifier;
        static tryBySeparator(identifier: string, separator: string): $Identifier;
        static tryParse(identifier: string): $Identifier;
        static validPathChar(c: string): boolean;
        static withDefaultNamespace(path: string): $Identifier;
        compareTo(o: $Identifier_): number;
        equals(o: object): boolean;
        hashCode(): number;
        resolveAgainst(root: string): $Path;
        toDebugFileName(): string;
        toLanguageKey(prefix: string, suffix: string): string;
        toLanguageKey(prefix: string): string;
        toLanguageKey(): string;
        toShortLanguageKey(): string;
        toShortString(): string;
        toString(): string;
        withPath(newPath: string): $Identifier;
        withPath(modifier: $UnaryOperator<string>): $Identifier;
        withPrefix(prefix: string): $Identifier;
        withSuffix(suffix: string): $Identifier;
    }

    export class $RegistryOps<T> extends $DelegatingOps implements $RegistryOpsAccessor {
        lookupProvider: $RegistryOps$RegistryInfoLookup;
        static create<T>(parent: $DynamicOps<T>, lookupProvider: $HolderLookup$Provider): $RegistryOps<T>;
        static create<T>(parent: $DynamicOps<T>, lookupProvider: $RegistryOps$RegistryInfoLookup): $RegistryOps<T>;
        static injectRegistryContext<T>(dynamic: $Dynamic<T>, lookupProvider: $HolderLookup$Provider): $Dynamic<T>;
        static retrieveElement<E, O>(key: $ResourceKey<E>): $RecordCodecBuilder<O, $Holder$Reference<E>>;
        static retrieveGetter<E, O>(registryKey: $ResourceKey<$Registry<E>>): $RecordCodecBuilder<O, $HolderGetter<E>>;
        equals(obj: object): boolean;
        getter<E>(registryKey: $ResourceKey<$Registry<E>>): $Optional<$HolderGetter<E>>;
        hashCode(): number;
        owner<E>(registryKey: $ResourceKey<$Registry<E>>): $Optional<$HolderOwner<E>>;
        withParent<U>(parent: $DynamicOps<U>): $RegistryOps<U>;
    }

    export class $RegistryOps$RegistryInfo<T> extends $Record {
        constructor(owner: $HolderOwner<T>, getter: $HolderGetter<T>, elementsLifecycle: $Lifecycle);
        get ter(): $HolderGetter<T>;
        getter(): $HolderGetter<T>;
        static fromRegistryLookup<T>(registry: $HolderLookup$RegistryLookup<T>): $RegistryOps$RegistryInfo<T>;
        elementsLifecycle(): $Lifecycle;
        equals(o: object): boolean;
        hashCode(): number;
        owner(): $HolderOwner<T>;
        toString(): string;
    }

    export interface $RegistryOps$RegistryInfoLookup {
        lookup<T>(registryKey: $ResourceKey<$Registry<T>>): $Optional<$RegistryOps$RegistryInfo<T>>;
    }

    export class $ResourceKey<T> {
        static codec<T>(registryName: $ResourceKey<$Registry<T>>): $Codec<$ResourceKey<T>>;
        static createRegistryKey<T>(identifier: $Identifier_): $ResourceKey<$Registry<T>>;
        static create<T>(registryName: $ResourceKey<$Registry<T>>, location: $Identifier_): $ResourceKey<T>;
        static streamCodec<T>(registryName: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $ResourceKey<T>>;
        cast<E>(registry: $ResourceKey<$Registry<E>>): $Optional<$ResourceKey<E>>;
        identifier(): $Identifier;
        isFor(registry: $ResourceKey<$Registry<any>>): boolean;
        registryKey(): $ResourceKey<$Registry<T>>;
        registry(): $Identifier;
        toString(): string;
    }

    export type $Identifier_ = $Identifier | string | $NekoId;
}
