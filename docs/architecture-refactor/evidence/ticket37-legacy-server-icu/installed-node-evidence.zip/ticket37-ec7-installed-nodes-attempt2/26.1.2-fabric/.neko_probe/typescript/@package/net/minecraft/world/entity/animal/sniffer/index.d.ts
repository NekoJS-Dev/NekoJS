import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $String } from "java:java/lang";
import { $IntFunction } from "java:java/util/function";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $EntityDataAccessor } from "java:net/minecraft/network/syncher";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $InteractionHand, $InteractionHand_, $InteractionResult } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $AnimationState, $EntityDimensions, $Pose, $Pose_ } from "java:net/minecraft/world/entity";
import { $Brain } from "java:net/minecraft/world/entity/ai";
import { $AttributeSupplier$Builder } from "java:net/minecraft/world/entity/ai/attributes";
import { $Animal } from "java:net/minecraft/world/entity/animal";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/animal/sniffer" {
    export class $Sniffer extends $Animal {
        constructor(type: $EntityType<$Animal>, level: $Level);
        diggingAnimationState: $AnimationState;
        feelingHappyAnimationState: $AnimationState;
        risingAnimationState: $AnimationState;
        scentingAnimationState: $AnimationState;
        sniffingAnimationState: $AnimationState;
        get babyStartAge(): number;
        getBabyStartAge(): number;
        get brain(): $Brain<$Sniffer>;
        getBrain(): $Brain<$Sniffer>;
        get maxHeadYRot(): number;
        getMaxHeadYRot(): number;
        get quadLeashOffsets(): $Vec3[];
        getQuadLeashOffsets(): $Vec3[];
        get searching(): boolean;
        isSearching(): boolean;
        get tempted(): boolean;
        isTempted(): boolean;
        static createAttributes(): $AttributeSupplier$Builder;
        canMate(partner: $Animal): boolean;
        canPlayDiggingSound(): boolean;
        canSniff(): boolean;
        die(source: $DamageSource): void;
        getBreedOffspring(level: $ServerLevel, partner: $AgeableMob): $AgeableMob;
        getDefaultDimensions(pose: $Pose_): $EntityDimensions;
        isFood(itemStack: $ItemStack_): boolean;
        jumpFromGround(): void;
        mobInteract(player: $Player, hand: $InteractionHand_): $InteractionResult;
        onDiggingComplete(success: boolean): $Sniffer;
        onPathfindingDone(): void;
        onPathfindingStart(): void;
        onSyncedDataUpdated(accessor: $EntityDataAccessor<any>): void;
        spawnChildFromBreeding(level: $ServerLevel, partner: $Animal): void;
        supportQuadLeash(): boolean;
        tick(): void;
        transitionTo(state: $Sniffer$State_): $Sniffer;
    }

    export class $Sniffer$State {
        static DIGGING: $Sniffer$State;
        static FEELING_HAPPY: $Sniffer$State;
        static IDLING: $Sniffer$State;
        static RISING: $Sniffer$State;
        static SCENTING: $Sniffer$State;
        static SEARCHING: $Sniffer$State;
        static SNIFFING: $Sniffer$State;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Sniffer$State[];
        static valueOf(name: string): $Sniffer$State;
    }

    export type $Sniffer$State_ = $Sniffer$State | "DIGGING" | "FEELING_HAPPY" | "IDLING" | "RISING" | "SCENTING" | "SEARCHING" | "SNIFFING";
}
