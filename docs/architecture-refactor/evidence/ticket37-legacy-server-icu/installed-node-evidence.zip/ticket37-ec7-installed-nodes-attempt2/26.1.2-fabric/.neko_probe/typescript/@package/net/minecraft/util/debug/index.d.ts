import { $Record, $String } from "java:java/lang";
import { $Optional, $Set } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $Entity } from "java:net/minecraft/world/entity";
import { $PoiRecord, $PoiType, $PoiType_ } from "java:net/minecraft/world/entity/ai/village/poi";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $LevelChunk } from "java:net/minecraft/world/level/chunk";

declare module "java:net/minecraft/util/debug" {
    export class $DebugPoiInfo extends $Record {
        constructor(pos: $BlockPos_, poiType: $Holder<$PoiType_>, freeTicketCount: number);
        constructor(record: $PoiRecord);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DebugPoiInfo>;
        equals(o: object): boolean;
        freeTicketCount(): number;
        hashCode(): number;
        poiType(): $Holder<$PoiType>;
        pos(): $BlockPos;
        toString(): string;
    }

    export class $DebugSubscription<T> {
        constructor(valueStreamCodec: $StreamCodec<any, T>);
        constructor(valueStreamCodec: $StreamCodec<any, T>, expireAfterTicks: number);
        static DOES_NOT_EXPIRE: number;
        emptyUpdate(): $DebugSubscription$Update<T>;
        expireAfterTicks(): number;
        packEvent(value: T): $DebugSubscription$Event<T>;
        packUpdate(value: T): $DebugSubscription$Update<T>;
        toString(): string;
        valueStreamCodec(): $StreamCodec<any, T>;
    }

    export class $DebugSubscription$Event<T> extends $Record {
        constructor(subscription: $DebugSubscription<T>, value: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DebugSubscription$Event<any>>;
        equals(o: object): boolean;
        hashCode(): number;
        subscription(): $DebugSubscription<T>;
        toString(): string;
        value(): T;
    }

    export class $DebugSubscription$Update<T> extends $Record {
        constructor(subscription: $DebugSubscription<T>, value: $Optional<T>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DebugSubscription$Update<any>>;
        equals(o: object): boolean;
        hashCode(): number;
        subscription(): $DebugSubscription<T>;
        toString(): string;
        value(): $Optional<T>;
    }

    export interface $DebugValueSource {
        registerDebugValues(level: $ServerLevel, registration: $DebugValueSource$Registration): void;
    }

    export interface $DebugValueSource$Registration {
        register<T>(subscription: $DebugSubscription<T>, getter: $DebugValueSource$ValueGetter<T>): void;
    }

    export interface $DebugValueSource$ValueGetter<T> {
        get(): T;
    }

    export class $LevelDebugSynchronizers {
        constructor(level: $ServerLevel);
        broadcastEventToTracking<T>(blockPos: $BlockPos_, subscription: $DebugSubscription<T>, value: T): void;
        clearBlockValue<T>(blockPos: $BlockPos_, subscription: $DebugSubscription<T>): void;
        clearEntityValue<T>(entity: $Entity, subscription: $DebugSubscription<T>): void;
        dropBlockEntity(blockPos: $BlockPos_): void;
        dropChunk(chunkPos: $ChunkPos): void;
        dropEntity(entity: $Entity): void;
        dropPoi(pos: $BlockPos_): void;
        hasAnySubscriberFor(subscription: $DebugSubscription<any>): boolean;
        registerBlockEntity(blockEntity: $BlockEntity): void;
        registerChunk(chunk: $LevelChunk): void;
        registerEntity(entity: $Entity): void;
        registerPoi(poi: $PoiRecord): void;
        sendBlockValue<T>(blockPos: $BlockPos_, subscription: $DebugSubscription<T>, value: T): void;
        sendEntityValue<T>(entity: $Entity, subscription: $DebugSubscription<T>, value: T): void;
        startTrackingChunk(player: $ServerPlayer, chunkPos: $ChunkPos): void;
        startTrackingEntity(player: $ServerPlayer, entity: $Entity): void;
        tick(serverSubscribers: $ServerDebugSubscribers): void;
        updatePoi(pos: $BlockPos_): void;
    }

    export class $ServerDebugSubscribers {
        constructor(server: $MinecraftServer);
        broadcastToAll(subscription: $DebugSubscription<any>, packet: $Packet<any>): void;
        enabledSubscriptions(): $Set<$DebugSubscription<any>>;
        hasAnySubscriberFor(subscription: $DebugSubscription<any>): boolean;
        hasRequiredPermissions(player: $ServerPlayer): boolean;
        tick(): void;
    }

}
