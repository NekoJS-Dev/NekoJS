import { $GameProfile } from "java:com/mojang/authlib";
import { $Message, $ParseResults } from "java:com/mojang/brigadier";
import { $Codec, $DataResult, $MapCodec } from "java:com/mojang/serialization";
import { $MutableComponentExtension } from "java:com/tkisor/nekojs/api/inject";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Boolean, $Enum, $Integer, $Record, $String } from "java:java/lang";
import { $URI } from "java:java/net";
import { $ByteBuffer } from "java:java/nio";
import { $Duration, $Instant } from "java:java/time";
import { $BitSet, $Date, $List, $Optional, $UUID } from "java:java/util";
import { $BooleanSupplier, $Predicate, $UnaryOperator } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $NbtPathArgument$NbtPath } from "java:net/minecraft/commands/arguments";
import { $EntitySelector } from "java:net/minecraft/commands/arguments/selector";
import { $Holder, $Holder_, $RegistryAccess } from "java:net/minecraft/core";
import { $BootstrapContext } from "java:net/minecraft/data/worldgen";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $DataSource } from "java:net/minecraft/network/chat/contents/data";
import { $ObjectInfo } from "java:net/minecraft/network/chat/contents/objects";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $CompilableString, $FormattedCharSequence, $SignatureUpdater, $SignatureUpdater$Output, $SignatureValidator, $StringRepresentable, $Unit, $Unit_ } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $ProfilePublicKey, $ProfilePublicKey$Data } from "java:net/minecraft/world/entity/player";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $Logger } from "java:org/slf4j";

export * as contents from "java:net/minecraft/network/chat/contents";
export * as numbers from "java:net/minecraft/network/chat/numbers";

declare module "java:net/minecraft/network/chat" {
    export interface $ChatDecorator {
        decorate(player: $ServerPlayer, plain: $Component_): $Component;
        static PLAIN: $ChatDecorator;
    }

    export class $ChatType extends $Record {
        constructor(chat: $ChatTypeDecoration, narration: $ChatTypeDecoration);
        static CHAT: $ResourceKey<$ChatType>;
        static DEFAULT_CHAT_DECORATION: $ChatTypeDecoration;
        static DIRECT_CODEC: $Codec<$ChatType>;
        static DIRECT_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ChatType>;
        static EMOTE_COMMAND: $ResourceKey<$ChatType>;
        static MSG_COMMAND_INCOMING: $ResourceKey<$ChatType>;
        static MSG_COMMAND_OUTGOING: $ResourceKey<$ChatType>;
        static SAY_COMMAND: $ResourceKey<$ChatType>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$ChatType>>;
        static TEAM_MSG_COMMAND_INCOMING: $ResourceKey<$ChatType>;
        static TEAM_MSG_COMMAND_OUTGOING: $ResourceKey<$ChatType>;
        static bind(chatType: $ResourceKey<$ChatType>, source: $CommandSourceStack): $ChatType$Bound;
        static bind(chatType: $ResourceKey<$ChatType>, registryAccess: $RegistryAccess, name: $Component_): $ChatType$Bound;
        static bind(chatType: $ResourceKey<$ChatType>, entity: $Entity): $ChatType$Bound;
        static bootstrap(context: $BootstrapContext<$ChatType>): void;
        chat(): $ChatTypeDecoration;
        equals(o: object): boolean;
        hashCode(): number;
        narration(): $ChatTypeDecoration;
        toString(): string;
    }

    export class $ChatType$Bound extends $Record {
        constructor(chatType: $Holder<$ChatType>, name: $Component_, targetName: $Optional<$Component_>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ChatType$Bound>;
        chatType(): $Holder<$ChatType>;
        decorateNarration(content: $Component_): $Component;
        decorate(content: $Component_): $Component;
        equals(o: object): boolean;
        hashCode(): number;
        name(): $Component;
        targetName(): $Optional<$Component>;
        toString(): string;
        withTargetName(targetName: $Component_): $ChatType$Bound;
    }

    export class $ChatTypeDecoration extends $Record {
        constructor(translationKey: string, parameters: $ChatTypeDecoration$Parameter_[], style: $Style);
        static CODEC: $Codec<$ChatTypeDecoration>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ChatTypeDecoration>;
        static incomingDirectMessage(translationKey: string): $ChatTypeDecoration;
        static outgoingDirectMessage(translationKey: string): $ChatTypeDecoration;
        static teamMessage(translationKey: string): $ChatTypeDecoration;
        static withSender(translationKey: string): $ChatTypeDecoration;
        decorate(content: $Component_, chatType: $ChatType$Bound): $Component;
        equals(o: object): boolean;
        hashCode(): number;
        parameters(): $List<$ChatTypeDecoration$Parameter>;
        style(): $Style;
        toString(): string;
        translationKey(): string;
    }

    export class $ChatTypeDecoration$Parameter {
        static CONTENT: $ChatTypeDecoration$Parameter;
        static SENDER: $ChatTypeDecoration$Parameter;
        static TARGET: $ChatTypeDecoration$Parameter;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChatTypeDecoration$Parameter[];
        static valueOf(name: string): $ChatTypeDecoration$Parameter;
    }

    export interface $ClickEvent {
        action(): $ClickEvent$Action;
        static CODEC: $Codec<$ClickEvent>;
    }

    export class $ClickEvent$Action {
        static CHANGE_PAGE: $ClickEvent$Action;
        static COPY_TO_CLIPBOARD: $ClickEvent$Action;
        static CUSTOM: $ClickEvent$Action;
        static OPEN_FILE: $ClickEvent$Action;
        static OPEN_URL: $ClickEvent$Action;
        static RUN_COMMAND: $ClickEvent$Action;
        static SHOW_DIALOG: $ClickEvent$Action;
        static SUGGEST_COMMAND: $ClickEvent$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClickEvent$Action[];
        static valueOf(name: string): $ClickEvent$Action;
    }

    export interface $Component extends $Message, $FormattedText {
        contains(other: $Component_): boolean;
        copy(): $MutableComponent;
        empty(): $MutableComponent;
        getContents(): $ComponentContents;
        getSiblings(): $List<$Component>;
        getString(limit: number): string;
        getString(): string;
        getStyle(): $Style;
        getVisualOrderText(): $FormattedCharSequence;
        keybind(name: string): $MutableComponent;
        literal(text: string): $MutableComponent;
        nbt(nbtPath: $CompilableString<$NbtPathArgument$NbtPath>, interpreting: boolean, plain: boolean, separator: $Optional<$Component_>, dataSource: $DataSource): $MutableComponent;
        nullToEmpty(text: string): $Component;
        object(info: $ObjectInfo, fallback: $Component_): $MutableComponent;
        object(info: $ObjectInfo): $MutableComponent;
        plainCopy(): $MutableComponent;
        score(name: string, objective: string): $MutableComponent;
        score(pattern: $CompilableString<$EntitySelector>, objective: string): $MutableComponent;
        selector(pattern: $CompilableString<$EntitySelector>, separator: $Optional<$Component_>): $MutableComponent;
        toFlatList(rootStyle: $Style): $List<$Component>;
        toFlatList(): $List<$Component>;
        translatableEscape(key: string, args?: object[]): $MutableComponent;
        translatableWithFallback(key: string, fallback: string, args?: object[]): $MutableComponent;
        translatableWithFallback(key: string, fallback: string): $MutableComponent;
        translatable(key: string, args?: object[]): $MutableComponent;
        translatable(key: string): $MutableComponent;
        translationArg(message: $Message): $Component;
        translationArg(uri: $URI): $Component;
        translationArg(date: $Date): $Component;
        translationArg(uuid: string): $Component;
        translationArg(id: $Identifier_): $Component;
        translationArg(chunkPos: $ChunkPos): $Component;
        tryCollapseToString(): string;
        visit<T>(output: $FormattedText$ContentConsumer<T>): $Optional<T>;
        visit<T>(output: $FormattedText$StyledContentConsumer<T>, parentStyle: $Style): $Optional<T>;
    }

    export interface $ComponentContents {
        codec(): $MapCodec<$ComponentContents>;
        resolve(context: $ResolutionContext, recursionDepth: number): $MutableComponent;
        visit<T>(output: $FormattedText$ContentConsumer<T>): $Optional<T>;
        visit<T>(output: $FormattedText$StyledContentConsumer<T>, currentStyle: $Style): $Optional<T>;
    }

    export class $FilterMask {
        constructor(length: number);
        static CODEC: $Codec<$FilterMask>;
        static FILTERED_STYLE: $Style;
        static FULLY_FILTERED: $FilterMask;
        static PASS_THROUGH: $FilterMask;
        get empty(): boolean;
        isEmpty(): boolean;
        get fullyFiltered(): boolean;
        isFullyFiltered(): boolean;
        static read(input: $FriendlyByteBuf): $FilterMask;
        static write(output: $FriendlyByteBuf, mask: $FilterMask): void;
        applyWithFormatting(text: string): $Component;
        apply(text: string): string;
        equals(o: object): boolean;
        hashCode(): number;
    }

    export interface $FontDescription {
        static CODEC: $Codec<$FontDescription>;
        static DEFAULT: $FontDescription$Resource;
    }

    export class $FontDescription$Resource extends $Record implements $FontDescription {
        constructor(id: $Identifier_);
        equals(o: object): boolean;
        hashCode(): number;
        id(): $Identifier;
        toString(): string;
    }

    export interface $FormattedText {
        composite(parts: $FormattedText[]): $FormattedText;
        composite(parts?: $FormattedText[]): $FormattedText;
        getString(): string;
        of(text: string, style: $Style): $FormattedText;
        of(text: string): $FormattedText;
        visit<T>(output: $FormattedText$ContentConsumer<T>): $Optional<T>;
        visit<T>(output: $FormattedText$StyledContentConsumer<T>, parentStyle: $Style): $Optional<T>;
        static EMPTY: $FormattedText;
        static STOP_ITERATION: $Optional<$Unit>;
    }

    export interface $FormattedText$ContentConsumer<T> {
        accept(contents: string): $Optional<T>;
    }

    export interface $FormattedText$StyledContentConsumer<T> {
        accept(style: $Style, contents: string): $Optional<T>;
    }

    export interface $HoverEvent {
        action(): $HoverEvent$Action;
        static CODEC: $Codec<$HoverEvent>;
    }

    export class $HoverEvent$Action {
        static SHOW_ENTITY: $HoverEvent$Action;
        static SHOW_ITEM: $HoverEvent$Action;
        static SHOW_TEXT: $HoverEvent$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $HoverEvent$Action[];
        static valueOf(name: string): $HoverEvent$Action;
    }

    export class $LastSeenMessages extends $Record {
        constructor(entries: $MessageSignature[]);
        static CODEC: $Codec<$LastSeenMessages>;
        static EMPTY: $LastSeenMessages;
        static LAST_SEEN_MESSAGES_MAX_LENGTH: number;
        computeChecksum(): number;
        entries(): $List<$MessageSignature>;
        equals(o: object): boolean;
        hashCode(): number;
        pack(cache: $MessageSignatureCache): $LastSeenMessages$Packed;
        toString(): string;
        updateSignature(output: $SignatureUpdater$Output): void;
    }

    export class $LastSeenMessages$Packed extends $Record {
        constructor(entries: $MessageSignature$Packed[]);
        constructor(input: $FriendlyByteBuf);
        static EMPTY: $LastSeenMessages$Packed;
        entries(): $List<$MessageSignature$Packed>;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        unpack(cache: $MessageSignatureCache): $Optional<$LastSeenMessages>;
        write(output: $FriendlyByteBuf): void;
    }

    export class $LastSeenMessages$Update extends $Record {
        constructor(offset: number, acknowledged: $BitSet, checksum: number);
        constructor(input: $FriendlyByteBuf);
        static IGNORE_CHECKSUM: number;
        acknowledged(): $BitSet;
        checksum(): number;
        equals(o: object): boolean;
        hashCode(): number;
        offset(): number;
        toString(): string;
        verifyChecksum(lastSeen: $LastSeenMessages): boolean;
        write(output: $FriendlyByteBuf): void;
    }

    export class $MessageSignature extends $Record {
        constructor(bytes: number[]);
        static BYTES: number;
        static CODEC: $Codec<$MessageSignature>;
        static describe(signature: $MessageSignature): string;
        static read(input: $FriendlyByteBuf): $MessageSignature;
        static write(output: $FriendlyByteBuf, signature: $MessageSignature): void;
        asByteBuffer(): $ByteBuffer;
        bytes(): number[];
        checksum(): number;
        equals(o: object): boolean;
        hashCode(): number;
        pack(cache: $MessageSignatureCache): $MessageSignature$Packed;
        toString(): string;
        verify(signature: $SignatureValidator, updater: $SignatureUpdater): boolean;
    }

    export class $MessageSignature$Packed extends $Record {
        constructor(id: number);
        constructor(id: number, fullSignature: $MessageSignature);
        constructor(signature: $MessageSignature);
        static FULL_SIGNATURE: number;
        static read(input: $FriendlyByteBuf): $MessageSignature$Packed;
        static write(output: $FriendlyByteBuf, packed: $MessageSignature$Packed): void;
        equals(o: object): boolean;
        fullSignature(): $MessageSignature;
        hashCode(): number;
        id(): number;
        toString(): string;
        unpack(cache: $MessageSignatureCache): $Optional<$MessageSignature>;
    }

    export class $MessageSignatureCache {
        constructor(capacity: number);
        static NOT_FOUND: number;
        static createDefault(): $MessageSignatureCache;
        pack(signature: $MessageSignature): number;
        push(body: $SignedMessageBody, signature: $MessageSignature): void;
        unpack(id: number): $MessageSignature;
    }

    export class $MutableComponent implements $Component, $MutableComponentExtension {
        get contents(): $ComponentContents;
        getContents(): $ComponentContents;
        get siblings(): $List<$Component>;
        getSiblings(): $List<$Component>;
        get style(): $Style;
        getStyle(): $Style;
        set style(value: $Style);
        get visualOrderText(): $FormattedCharSequence;
        getVisualOrderText(): $FormattedCharSequence;
        static create(contents: $ComponentContents): $MutableComponent;
        append(text: string): $MutableComponent;
        append(component: $Component_): $MutableComponent;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        withColor(color: number): $MutableComponent;
        withStyle(updater: $UnaryOperator<$Style>): $MutableComponent;
        withStyle(formats?: $ChatFormatting_[]): $MutableComponent;
        withStyle(format: $ChatFormatting_): $MutableComponent;
        withStyle(patch: $Style): $MutableComponent;
        withoutShadow(): $MutableComponent;
    }

    export interface $OutgoingChatMessage {
        content(): $Component;
        create(message: $PlayerChatMessage): $OutgoingChatMessage;
        sendToPlayer(player: $ServerPlayer, filtered: boolean, chatType: $ChatType$Bound): void;
    }

    export class $PlayerChatMessage extends $Record {
        constructor(link: $SignedMessageLink, signature: $MessageSignature, signedBody: $SignedMessageBody, unsignedContent: $Component_, filterMask: $FilterMask);
        static MAP_CODEC: $MapCodec<$PlayerChatMessage>;
        static MESSAGE_EXPIRES_AFTER_CLIENT: $Duration;
        static MESSAGE_EXPIRES_AFTER_SERVER: $Duration;
        get fullyFiltered(): boolean;
        isFullyFiltered(): boolean;
        get system(): boolean;
        isSystem(): boolean;
        static describeSigned(message: $PlayerChatMessage): string;
        static system(content: string): $PlayerChatMessage;
        static unsigned(sender: string, content: string): $PlayerChatMessage;
        static updateSignature(output: $SignatureUpdater$Output, link: $SignedMessageLink, body: $SignedMessageBody): void;
        decoratedContent(): $Component;
        equals(o: object): boolean;
        filterMask(): $FilterMask;
        filter(filtered: boolean): $PlayerChatMessage;
        filter(filterMask: $FilterMask): $PlayerChatMessage;
        hasExpiredClient(now: $Instant): boolean;
        hasExpiredServer(now: $Instant): boolean;
        hasSignatureFrom(profileId: string): boolean;
        hasSignature(): boolean;
        hashCode(): number;
        link(): $SignedMessageLink;
        removeSignature(): $PlayerChatMessage;
        removeUnsignedContent(): $PlayerChatMessage;
        salt(): number;
        sender(): $UUID;
        signature(): $MessageSignature;
        signedBody(): $SignedMessageBody;
        signedContent(): string;
        timeStamp(): $Instant;
        toString(): string;
        unsignedContent(): $Component;
        verify(signatureValidator: $SignatureValidator): boolean;
        withUnsignedContent(content: $Component_): $PlayerChatMessage;
    }

    export class $RemoteChatSession extends $Record {
        constructor(sessionId: string, profilePublicKey: $ProfilePublicKey);
        asData(): $RemoteChatSession$Data;
        createMessageDecoder(profileId: string): $SignedMessageChain$Decoder;
        createMessageValidator(gracePeriod: $Duration): $SignedMessageValidator;
        equals(o: object): boolean;
        hasExpired(): boolean;
        hashCode(): number;
        profilePublicKey(): $ProfilePublicKey;
        sessionId(): $UUID;
        toString(): string;
    }

    export class $RemoteChatSession$Data extends $Record {
        constructor(sessionId: string, profilePublicKey: $ProfilePublicKey$Data);
        static read(input: $FriendlyByteBuf): $RemoteChatSession$Data;
        static write(output: $FriendlyByteBuf, data: $RemoteChatSession$Data): void;
        equals(o: object): boolean;
        hashCode(): number;
        profilePublicKey(): $ProfilePublicKey$Data;
        sessionId(): $UUID;
        toString(): string;
        validate(profile: $GameProfile, serviceSignatureValidator: $SignatureValidator): $RemoteChatSession;
    }

    export class $ResolutionContext extends $Record {
        constructor(source: $CommandSourceStack, defaultScoreboardEntity: $Entity, objectInfoValidator: $Predicate<$ObjectInfo>, depthLimit: number, depthLimitBehavior: $ResolutionContext$LimitBehavior_);
        static builder(): $ResolutionContext$Builder;
        static create(source: $CommandSourceStack): $ResolutionContext;
        defaultScoreboardEntity(): $Entity;
        depthLimitBehavior(): $ResolutionContext$LimitBehavior;
        depthLimit(): number;
        equals(o: object): boolean;
        hashCode(): number;
        objectInfoValidator(): $Predicate<$ObjectInfo>;
        source(): $CommandSourceStack;
        toString(): string;
        validate(description: $ObjectInfo): $ObjectInfo;
    }

    export class $ResolutionContext$Builder {
        constructor();
        build(): $ResolutionContext;
        withEntityOverride(defaultScoreboardEntity: $Entity): $ResolutionContext$Builder;
        withObjectInfoValidator(objectInfoValidator: $Predicate<$ObjectInfo>): $ResolutionContext$Builder;
        withSource(source: $CommandSourceStack): $ResolutionContext$Builder;
    }

    export class $ResolutionContext$LimitBehavior {
        static DISCARD_REMAINING: $ResolutionContext$LimitBehavior;
        static STOP_PROCESSING_AND_COPY_REMAINING: $ResolutionContext$LimitBehavior;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ResolutionContext$LimitBehavior[];
        static valueOf(name: string): $ResolutionContext$LimitBehavior;
    }

    export class $SignableCommand<S> extends $Record {
        constructor(arguments_: $SignableCommand$Argument<S>[]);
        static hasSignableArguments<S>(command: $ParseResults<S>): boolean;
        static of<S>(command: $ParseResults<S>): $SignableCommand<S>;
        arguments(): $List<$SignableCommand$Argument<S>>;
        equals(o: object): boolean;
        getArgument(name: string): $SignableCommand$Argument<S>;
        hashCode(): number;
        toString(): string;
    }

    export class $SignedMessageBody extends $Record {
        constructor(content: string, timeStamp: $Instant, salt: number, lastSeen: $LastSeenMessages);
        static MAP_CODEC: $MapCodec<$SignedMessageBody>;
        static unsigned(content: string): $SignedMessageBody;
        content(): string;
        equals(o: object): boolean;
        hashCode(): number;
        lastSeen(): $LastSeenMessages;
        pack(cache: $MessageSignatureCache): $SignedMessageBody$Packed;
        salt(): number;
        timeStamp(): $Instant;
        toString(): string;
        updateSignature(output: $SignatureUpdater$Output): void;
    }

    export class $SignedMessageBody$Packed extends $Record {
        constructor(content: string, timeStamp: $Instant, salt: number, lastSeen: $LastSeenMessages$Packed);
        constructor(input: $FriendlyByteBuf);
        content(): string;
        equals(o: object): boolean;
        hashCode(): number;
        lastSeen(): $LastSeenMessages$Packed;
        salt(): number;
        timeStamp(): $Instant;
        toString(): string;
        unpack(cache: $MessageSignatureCache): $Optional<$SignedMessageBody>;
        write(output: $FriendlyByteBuf): void;
    }

    export interface $SignedMessageChain$Decoder {
        setChainBroken(): void;
        unpack(signature: $MessageSignature, body: $SignedMessageBody): $PlayerChatMessage;
        unsigned(profileId: string, enforcesSecureChat: $BooleanSupplier): $SignedMessageChain$Decoder;
    }

    export class $SignedMessageLink extends $Record {
        constructor(index: number, sender: string, sessionId: string);
        static CODEC: $Codec<$SignedMessageLink>;
        static root(sender: string, sessionId: string): $SignedMessageLink;
        static unsigned(sender: string): $SignedMessageLink;
        advance(): $SignedMessageLink;
        equals(o: object): boolean;
        hashCode(): number;
        index(): number;
        isDescendantOf(link: $SignedMessageLink): boolean;
        sender(): $UUID;
        sessionId(): $UUID;
        toString(): string;
        updateSignature(output: $SignatureUpdater$Output): void;
    }

    export interface $SignedMessageValidator {
        updateAndValidate(message: $PlayerChatMessage): $PlayerChatMessage;
        static ACCEPT_UNSIGNED: $SignedMessageValidator;
        static LOGGER: $Logger;
        static REJECT_ALL: $SignedMessageValidator;
    }

    export class $Style {
        static EMPTY: $Style;
        static NO_SHADOW: number;
        get clickEvent(): $ClickEvent;
        getClickEvent(): $ClickEvent;
        get color(): $TextColor;
        getColor(): $TextColor;
        get font(): $FontDescription;
        getFont(): $FontDescription;
        get hoverEvent(): $HoverEvent;
        getHoverEvent(): $HoverEvent;
        get insertion(): string;
        getInsertion(): string;
        get shadowColor(): number;
        getShadowColor(): number;
        get bold(): boolean;
        isBold(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        get italic(): boolean;
        isItalic(): boolean;
        get obfuscated(): boolean;
        isObfuscated(): boolean;
        get strikethrough(): boolean;
        isStrikethrough(): boolean;
        get underlined(): boolean;
        isUnderlined(): boolean;
        applyFormats(formats?: $ChatFormatting_[]): $Style;
        applyFormat(format: $ChatFormatting_): $Style;
        applyLegacyFormat(format: $ChatFormatting_): $Style;
        applyTo(other: $Style): $Style;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        withBold(bold: boolean): $Style;
        withClickEvent(clickEvent: $ClickEvent): $Style;
        withColor(color: number): $Style;
        withColor(color: $ChatFormatting_): $Style;
        withColor(color: $TextColor): $Style;
        withFont(font: $FontDescription): $Style;
        withHoverEvent(hoverEvent: $HoverEvent): $Style;
        withInsertion(insertion: string): $Style;
        withItalic(italic: boolean): $Style;
        withObfuscated(obfuscated: boolean): $Style;
        withShadowColor(shadowColor: number): $Style;
        withStrikethrough(strikethrough: boolean): $Style;
        withUnderlined(underlined: boolean): $Style;
        withoutShadow(): $Style;
    }

    export class $TextColor {
        static CODEC: $Codec<$TextColor>;
        get value(): number;
        getValue(): number;
        static fromLegacyFormat(format: $ChatFormatting_): $TextColor;
        static fromRgb(rgb: number): $TextColor;
        static parseColor(color: string): $DataResult<$TextColor>;
        equals(o: object): boolean;
        formatValue(): string;
        hashCode(): number;
        serialize(): string;
        toString(): string;
    }

    export type $ChatTypeDecoration$Parameter_ = $ChatTypeDecoration$Parameter | "CONTENT" | "SENDER" | "TARGET";
    export type $ClickEvent$Action_ = $ClickEvent$Action | "CHANGE_PAGE" | "COPY_TO_CLIPBOARD" | "CUSTOM" | "OPEN_FILE" | "OPEN_URL" | "RUN_COMMAND" | "SHOW_DIALOG" | "SUGGEST_COMMAND";
    export type $Component_ = $Component | string | $TextValue;
    export type $HoverEvent$Action_ = $HoverEvent$Action | "SHOW_ENTITY" | "SHOW_ITEM" | "SHOW_TEXT";
    export type $ResolutionContext$LimitBehavior_ = $ResolutionContext$LimitBehavior | "DISCARD_REMAINING" | "STOP_PROCESSING_AND_COPY_REMAINING";
}
