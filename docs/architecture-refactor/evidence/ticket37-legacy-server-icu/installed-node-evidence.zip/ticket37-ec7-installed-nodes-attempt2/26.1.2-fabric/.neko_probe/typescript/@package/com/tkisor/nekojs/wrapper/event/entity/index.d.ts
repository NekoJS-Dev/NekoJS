import { $GoalRegistry$GoalBuilderJS } from "java:com/tkisor/nekojs/wrapper/entity";
import { $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Consumer } from "java:java/util/function";
import { $DifficultyInstance } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity, $EntitySpawnReason, $EntitySpawnReason_, $EntityType, $EntityType_, $LivingEntity, $Mob, $SpawnGroupData } from "java:net/minecraft/world/entity";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Level, $ServerLevelAccessor } from "java:net/minecraft/world/level";

declare module "java:com/tkisor/nekojs/wrapper/event/entity" {
    export class $EntityJoinLevelEventJS {
        constructor(entity: $Entity, level: $Level);
        get entity(): $Entity;
        getEntity(): $Entity;
        get level(): $Level;
        getLevel(): $Level;
    }

    /**
     * Fired when an entity is unloaded / removed from a ServerLevel (EntityEvents.leaveLevel). Dispatched by entity type.
     * Not cancellable. Server-side instances only.
     */
    export class $EntityLeaveLevelEventJS {
        constructor(entity: $Entity, level: $Level);
        get entity(): $Entity;
        getEntity(): $Entity;
        get level(): $Level;
        getLevel(): $Level;
    }

    /**
     * Fired before / after each entity's tick (EntityEvents.tickPre / tickPost). Dispatched by entity type.
     * Not cancellable. Server-side instances only. High-frequency: use carefully.
     */
    export class $EntityTickEventJS {
        constructor(entity: $Entity, level: $Level);
        get entity(): $Entity;
        getEntity(): $Entity;
        get level(): $Level;
        getLevel(): $Level;
    }

    /** Event given to GoalEvents.register callbacks (startup scripts) for registering built-in AI goals on entity types. */
    export class $GoalRegisterEventJS {
        constructor();
        /**
         * Registers goals on the entity type with the given id via a builder callback; register() runs automatically afterwards.
         * @param id entity type id like 'minecraft:zombie'
         * @param consumer callback receiving the GoalBuilderJS to configure
         */
        forType(id: string, consumer: $Consumer<$GoalRegistry$GoalBuilderJS>): void;
        /**
         * Starts a goal builder for the entity type with the given id; call builder.register() to apply.
         * @param id entity type id like 'minecraft:zombie'
         * @returns a GoalBuilderJS bound to the entity type; not registered until register() is called
         */
        forType(id: string): $GoalRegistry$GoalBuilderJS;
        /**
         * Registers goals on the given entity type via a builder callback; register() runs automatically afterwards.
         * @param type the entity type to register goals for
         * @param consumer callback receiving the GoalBuilderJS to configure
         */
        forType(type: $EntityType<any>, consumer: $Consumer<$GoalRegistry$GoalBuilderJS>): void;
        /**
         * Starts a goal builder for the given entity type; call builder.register() to apply.
         * @param type the entity type to register goals for
         * @returns a GoalBuilderJS bound to the entity type; not registered until register() is called
         */
        forType(type: $EntityType<any>): $GoalRegistry$GoalBuilderJS;
    }

    /**
     * Fired when a living entity is about to take / just took damage (EntityEvents.damagePre / damagePost).
     * damagePre is cancellable (return true to negate the damage; on NeoForge the damage becomes 0 and damagePost still fires); damagePost is not cancellable.
     */
    export class $LivingDamageEventJS {
        constructor(entity: $LivingEntity, source: $DamageSource, amount: number);
        get amount(): number;
        getAmount(): number;
        get entity(): $LivingEntity;
        getEntity(): $LivingEntity;
        get source(): $DamageSource;
        getSource(): $DamageSource;
    }

    export class $LivingDeathEventJS {
        constructor(entity: $LivingEntity, source: $DamageSource);
        get entity(): $LivingEntity;
        getEntity(): $LivingEntity;
        get source(): $DamageSource;
        getSource(): $DamageSource;
    }

    /**
     * Fired when a living entity's death drops are generated (EntityEvents.drops). Dispatched by entity type.
     * Cancellable on fabric: return true to skip vanilla death drops (script-provided event.drops are then spawned).
     */
    export class $LivingDropsEventJS {
        constructor(entity: $LivingEntity, source: $DamageSource, drops: $ItemStack_[]);
        get drops(): $List<$ItemStack>;
        getDrops(): $List<$ItemStack>;
        get entity(): $LivingEntity;
        getEntity(): $LivingEntity;
        get source(): $DamageSource;
        getSource(): $DamageSource;
    }

    /**
     * Fired after a mob's spawn data is finalized (EntityEvents.finalizeSpawn). Dispatched by entity type.
     * Fabric: notification only — not cancellable, spawn data / difficulty cannot be rewritten.
     */
    export class $MobFinalizeSpawnEventJS {
        constructor(mob: $Mob, level: $ServerLevelAccessor, difficulty: $DifficultyInstance, spawnType: $EntitySpawnReason_, spawnData: $SpawnGroupData);
        get difficulty(): $DifficultyInstance;
        getDifficulty(): $DifficultyInstance;
        get level(): $ServerLevelAccessor;
        getLevel(): $ServerLevelAccessor;
        get mob(): $Mob;
        getMob(): $Mob;
        get spawnData(): $SpawnGroupData;
        getSpawnData(): $SpawnGroupData;
        get spawnType(): $EntitySpawnReason;
        getSpawnType(): $EntitySpawnReason;
    }

}
