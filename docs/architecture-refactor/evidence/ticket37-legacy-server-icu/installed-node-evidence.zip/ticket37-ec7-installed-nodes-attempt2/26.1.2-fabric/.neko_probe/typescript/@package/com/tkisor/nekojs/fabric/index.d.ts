export * as capability from "java:com/tkisor/nekojs/fabric/capability";
export * as mixin from "java:com/tkisor/nekojs/fabric/mixin";

