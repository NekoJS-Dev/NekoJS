import { $Set } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $NodeEvaluator, $Path, $PathType, $PathType_ } from "java:net/minecraft/world/level/pathfinder";

declare module "java:net/minecraft/world/entity/ai/navigation" {
    export class $PathNavigation {
        constructor(mob: $Mob, level: $Level);
        get maxDistanceToWaypoint(): number;
        getMaxDistanceToWaypoint(): number;
        get nodeEvaluator(): $NodeEvaluator;
        getNodeEvaluator(): $NodeEvaluator;
        get path(): $Path;
        getPath(): $Path;
        get targetPos(): $BlockPos;
        getTargetPos(): $BlockPos;
        get done(): boolean;
        isDone(): boolean;
        get inProgress(): boolean;
        isInProgress(): boolean;
        get stuck(): boolean;
        isStuck(): boolean;
        canCutCorner(pathType: $PathType_): boolean;
        canFloat(): boolean;
        canNavigateGround(): boolean;
        createPath(x: number, y: number, z: number, reachRange: number): $Path;
        createPath(positions: $BlockPos_[], reachRange: number): $Path;
        createPath(positions: $Stream<$BlockPos_>, reachRange: number): $Path;
        createPath(pos: $BlockPos_, reachRange: number, maxPathLength: number): $Path;
        createPath(pos: $BlockPos_, reachRange: number): $Path;
        createPath(target: $Entity, reachRange: number): $Path;
        isStableDestination(pos: $BlockPos_): boolean;
        moveTo(x: number, y: number, z: number, speedModifier: number): boolean;
        moveTo(x: number, y: number, z: number, reachRange: number, speedModifier: number): boolean;
        moveTo(target: $Entity, speedModifier: number): boolean;
        moveTo(newPath: $Path, speedModifier: number): boolean;
        recomputePath(): void;
        resetMaxVisitedNodesMultiplier(): void;
        shouldRecomputePath(pos: $BlockPos_): boolean;
        stop(): void;
        tick(): void;
        updatePathfinderMaxVisitedNodes(): void;
    }

}
