import { $Enum, $String } from "java:java/lang";
import { $DebugSubscription } from "java:net/minecraft/util/debug";

declare module "java:net/minecraft/util/debugchart" {
    export class $AbstractSampleLogger implements $SampleLogger {
        logFullSample(sample: number[]): void;
        logPartialSample(sample: number, dimension: number): void;
        logSample(sample: number): void;
    }

    export class $LocalSampleLogger extends $AbstractSampleLogger implements $SampleStorage {
        constructor(dimensions: number);
        constructor(dimensions: number, defaults: number[]);
        static CAPACITY: number;
        capacity(): number;
        get(index: number, dimension: number): number;
        get(index: number): number;
        reset(): void;
        size(): number;
    }

    export class $RemoteDebugSampleType {
        static TICK_TIME: $RemoteDebugSampleType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RemoteDebugSampleType[];
        static valueOf(name: string): $RemoteDebugSampleType;
    }

    export interface $SampleLogger {
        logFullSample(sample: number[]): void;
        logPartialSample(sample: number, dimension: number): void;
        logSample(sample: number): void;
    }

    export interface $SampleStorage {
        capacity(): number;
        get(index: number, dimension: number): number;
        get(index: number): number;
        reset(): void;
        size(): number;
    }

    export type $RemoteDebugSampleType_ = $RemoteDebugSampleType | "TICK_TIME";
}
