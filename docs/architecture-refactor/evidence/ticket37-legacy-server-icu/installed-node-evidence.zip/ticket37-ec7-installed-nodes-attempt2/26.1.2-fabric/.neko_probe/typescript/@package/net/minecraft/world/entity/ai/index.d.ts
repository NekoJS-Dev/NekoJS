import { $ImmutableList } from "java:com/google/common/collect";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Collection, $List, $Optional, $Set } from "java:java/util";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $EnvironmentAttribute, $EnvironmentAttributeSystem } from "java:net/minecraft/world/attribute";
import { $BehaviorControl } from "java:net/minecraft/world/entity/ai/behavior";
import { $MemoryMap, $MemoryModuleType, $MemoryStatus, $MemoryStatus_ } from "java:net/minecraft/world/entity/ai/memory";
import { $Activity, $Activity_ } from "java:net/minecraft/world/entity/schedule";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as attributes from "java:net/minecraft/world/entity/ai/attributes";
export * as behavior from "java:net/minecraft/world/entity/ai/behavior";
export * as control from "java:net/minecraft/world/entity/ai/control";
export * as goal from "java:net/minecraft/world/entity/ai/goal";
export * as gossip from "java:net/minecraft/world/entity/ai/gossip";
export * as memory from "java:net/minecraft/world/entity/ai/memory";
export * as navigation from "java:net/minecraft/world/entity/ai/navigation";
export * as sensing from "java:net/minecraft/world/entity/ai/sensing";
export * as targeting from "java:net/minecraft/world/entity/ai/targeting";
export * as village from "java:net/minecraft/world/entity/ai/village";

declare module "java:net/minecraft/world/entity/ai" {
    export class $ActivityData<E extends $LivingEntity> extends $Record {
        constructor(activityType: $Activity_, behaviorPriorityPairs: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, conditions: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[], memoriesToEraseWhenStopped: $MemoryModuleType<any>[]);
        static createPriorityPairs<E>(priorityOfFirstBehavior: number, behaviorList: $ImmutableList<$BehaviorControl<any>>): $ImmutableList<$Pair<number, $BehaviorControl<any>>>;
        static create<E>(activity: $Activity_, behaviorPriorityPairs: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, conditions: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[], memoriesToEraseWhenStopped: $MemoryModuleType<any>[]): $ActivityData<E>;
        static create<E>(activity: $Activity_, behaviorPriorityPairs: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, conditions: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[]): $ActivityData<E>;
        static create<E>(activity: $Activity_, behaviorPriorityPairs: $ImmutableList<$Pair<number, $BehaviorControl<any>>>): $ActivityData<E>;
        static create<E>(activity: $Activity_, priorityOfFirstBehavior: number, behaviorList: $ImmutableList<$BehaviorControl<any>>, conditions: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[]): $ActivityData<E>;
        static create<E>(activity: $Activity_, priorityOfFirstBehavior: number, behaviorList: $ImmutableList<$BehaviorControl<any>>, memoryThatMustHaveValueAndWillBeErasedAfter: $MemoryModuleType<any>): $ActivityData<E>;
        static create<E>(activity: $Activity_, priorityOfFirstBehavior: number, behaviorList: $ImmutableList<$BehaviorControl<any>>): $ActivityData<E>;
        activityType(): $Activity;
        behaviorPriorityPairs(): $ImmutableList<$Pair<number, $BehaviorControl<any>>>;
        conditions(): $Set<$Pair<$MemoryModuleType<any>, $MemoryStatus>>;
        equals(o: object): boolean;
        hashCode(): number;
        memoriesToEraseWhenStopped(): $Set<$MemoryModuleType<any>>;
        toString(): string;
    }

    export class $Brain<E extends $LivingEntity> {
        constructor();
        get activeActivities(): $Set<$Activity>;
        getActiveActivities(): $Set<$Activity>;
        get activeNonCoreActivity(): $Optional<$Activity>;
        getActiveNonCoreActivity(): $Optional<$Activity>;
        get runningBehaviors(): $List<$BehaviorControl<any>>;
        getRunningBehaviors(): $List<$BehaviorControl<any>>;
        get brainDead(): boolean;
        isBrainDead(): boolean;
        static provider<E>(memoryTypes: $MemoryModuleType<any>[], sensorTypes: $SensorType<$Sensor<any>>[], activities: $Brain$ActivitySupplier<E>): $Brain$Provider<E>;
        static provider<E>(sensorTypes: $SensorType<$Sensor<any>>[], activities: $Brain$ActivitySupplier<E>): $Brain$Provider<E>;
        static provider<E>(sensorTypes: $SensorType<$Sensor<any>>[]): $Brain$Provider<E>;
        addActivity(activity: $Activity_, behaviorPriorityPairs: $ImmutableList<$Pair<number, $BehaviorControl<any>>>, conditions: $Pair<$MemoryModuleType<any>, $MemoryStatus_>[], memoriesToEraseWhenStopped: $MemoryModuleType<any>[]): void;
        checkMemory(type: $MemoryModuleType<any>, status: $MemoryStatus_): boolean;
        clearMemories(): void;
        eraseMemory<U>(type: $MemoryModuleType<U>): void;
        forEach(visitor: $Brain$Visitor): void;
        getMemoryInternal<U>(type: $MemoryModuleType<U>): $Optional<U>;
        getMemory<U>(type: $MemoryModuleType<U>): $Optional<U>;
        getTimeUntilExpiry<U>(type: $MemoryModuleType<U>): number;
        hasMemoryValue(type: $MemoryModuleType<any>): boolean;
        isActive(activity: $Activity_): boolean;
        isMemoryValue<U>(memoryType: $MemoryModuleType<U>, value: U): boolean;
        pack(): $Brain$Packed;
        removeAllBehaviors(): void;
        setMemoryWithExpiry<U>(type: $MemoryModuleType<U>, value: U, timeToLive: number): void;
        setMemory<U>(type: $MemoryModuleType<U>, value: U): void;
        setMemory<U>(type: $MemoryModuleType<U>, optionalValue: $Optional<U>): void;
        stopAll(level: $ServerLevel, body: E): void;
        tick(level: $ServerLevel, body: E): void;
        updateActivityFromSchedule(environmentAttributes: $EnvironmentAttributeSystem, gameTime: number, pos: $Vec3_): void;
        useDefaultActivity(): void;
    }

    export interface $Brain$ActivitySupplier<E extends $LivingEntity> {
        createActivities(body: E): $List<$ActivityData<E>>;
    }

    export class $Brain$Packed extends $Record {
        constructor(memories: $MemoryMap);
        static CODEC: $Codec<$Brain$Packed>;
        static EMPTY: $Brain$Packed;
        equals(o: object): boolean;
        hashCode(): number;
        memories(): $MemoryMap;
        toString(): string;
    }

    export class $Brain$Provider<E extends $LivingEntity> {
        makeBrain(body: E, packed: $Brain$Packed): $Brain<E>;
    }

    export interface $Brain$Visitor {
        acceptEmpty<U>(type: $MemoryModuleType<U>): void;
        accept<U>(type: $MemoryModuleType<U>, value: U, timeToLive: number): void;
        accept<U>(type: $MemoryModuleType<U>, value: U): void;
    }

}
