import { $Range } from "java:com/google/common/collect";
import { $StringReader } from "java:com/mojang/brigadier";
import { $DynamicCommandExceptionType, $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Codec, $DataResult } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Double, $Record, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Function, $Supplier } from "java:java/util/function";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/advancements/criterion" {
    export interface $MinMaxBounds<T extends number> {
        bounds(): $MinMaxBounds$Bounds<T>;
        isAny(): boolean;
        max(): $Optional<T>;
        min(): $Optional<T>;
        validateContainedInRange<V, B>(allowed: $MinMaxBounds<V>): $Function<B, $DataResult<B>>;
        static ERROR_EMPTY: $SimpleCommandExceptionType;
        static ERROR_SWAPPED: $SimpleCommandExceptionType;
    }

    export class $MinMaxBounds$Bounds<T extends number> extends $Record {
        constructor(min: $Optional<T>, max: $Optional<T>);
        get any(): boolean;
        isAny(): boolean;
        static any<T>(): $MinMaxBounds$Bounds<T>;
        static atLeast<T>(value: T): $MinMaxBounds$Bounds<T>;
        static atMost<T>(value: T): $MinMaxBounds$Bounds<T>;
        static between<T>(min: T, max: T): $MinMaxBounds$Bounds<T>;
        static exactly<T>(value: T): $MinMaxBounds$Bounds<T>;
        static fromReader<T>(reader: $StringReader, converter: $Function<string, T>, parseExc: $Supplier<$DynamicCommandExceptionType>): $MinMaxBounds$Bounds<T>;
        areSwapped(): boolean;
        asPoint(): $Optional<T>;
        asRange(): $Range<T>;
        equals(o: object): boolean;
        hashCode(): number;
        map<U>(mapper: $Function<T, U>): $MinMaxBounds$Bounds<U>;
        max(): $Optional<T>;
        min(): $Optional<T>;
        toString(): string;
        validateSwappedBoundsInCodec(): $DataResult<$MinMaxBounds$Bounds<T>>;
    }

    export class $MinMaxBounds$Doubles extends $Record implements $MinMaxBounds {
        constructor(bounds: $MinMaxBounds$Bounds<number>, boundsSqr: $MinMaxBounds$Bounds<number>);
        static ANY: $MinMaxBounds$Doubles;
        static CODEC: $Codec<$MinMaxBounds$Doubles>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $MinMaxBounds$Doubles>;
        static atLeast(value: number): $MinMaxBounds$Doubles;
        static atMost(value: number): $MinMaxBounds$Doubles;
        static between(min: number, max: number): $MinMaxBounds$Doubles;
        static exactly(value: number): $MinMaxBounds$Doubles;
        static fromReader(reader: $StringReader): $MinMaxBounds$Doubles;
        boundsSqr(): $MinMaxBounds$Bounds<number>;
        bounds(): $MinMaxBounds$Bounds<number>;
        equals(o: object): boolean;
        hashCode(): number;
        matchesSqr(valueSqr: number): boolean;
        matches(value: number): boolean;
        toString(): string;
    }

}
