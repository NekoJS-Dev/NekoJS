import { $GameProfile } from "java:com/mojang/authlib";
import { $ArgumentType } from "java:com/mojang/brigadier/arguments";
import { $ArgumentBuilder } from "java:com/mojang/brigadier/builder";
import { $Suggestions } from "java:com/mojang/brigadier/suggestion";
import { $ArgumentCommandNode, $CommandNode, $RootCommandNode } from "java:com/mojang/brigadier/tree";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Int2ObjectMap, $IntList } from "java:it/unimi/dsi/fastutil/ints";
import { $Object2IntMap } from "java:it/unimi/dsi/fastutil/objects";
import { $Enum, $Record, $String } from "java:java/lang";
import { $Instant } from "java:java/time";
import { $BitSet, $Collection, $EnumSet, $List, $Map, $Optional, $Set, $UUID } from "java:java/util";
import { $BiConsumer, $BiFunction, $Consumer, $IntFunction } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $AdvancementHolder, $AdvancementProgress } from "java:net/minecraft/advancements";
import { $CommandBuildContext } from "java:net/minecraft/commands";
import { $ArgumentSignatures, $EntityAnchorArgument$Anchor, $EntityAnchorArgument$Anchor_ } from "java:net/minecraft/commands/arguments";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $GlobalPos, $Holder, $Holder_, $RegistryAccess, $Vec3i } from "java:net/minecraft/core";
import { $ExplosionParticleInfo, $ParticleOptions } from "java:net/minecraft/core/particles";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ConnectionProtocol, $ConnectionProtocol_, $FriendlyByteBuf, $HashedStack, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $ChatType$Bound, $Component, $Component_, $FilterMask, $LastSeenMessages$Update, $MessageSignature, $MessageSignature$Packed, $RemoteChatSession$Data, $SignedMessageBody$Packed } from "java:net/minecraft/network/chat";
import { $NumberFormat } from "java:net/minecraft/network/chat/numbers";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $BundlePacket, $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ClientCommonPacketListener, $ServerCommonPacketListener } from "java:net/minecraft/network/protocol/common";
import { $ClientPongPacketListener, $ServerPingPacketListener } from "java:net/minecraft/network/protocol/ping";
import { $SynchedEntityData$DataValue } from "java:net/minecraft/network/syncher";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_, $SoundSource, $SoundSource_ } from "java:net/minecraft/sounds";
import { $RecipeBookSettings, $Stat } from "java:net/minecraft/stats";
import { $DebugSubscription, $DebugSubscription$Event, $DebugSubscription$Update } from "java:net/minecraft/util/debug";
import { $RemoteDebugSampleType, $RemoteDebugSampleType_ } from "java:net/minecraft/util/debugchart";
import { $WeightedList } from "java:net/minecraft/util/random";
import { $BossEvent, $BossEvent$BossBarColor, $BossEvent$BossBarColor_, $BossEvent$BossBarOverlay, $BossEvent$BossBarOverlay_, $Difficulty, $Difficulty_, $InteractionHand, $InteractionHand_, $TickRateManager } from "java:net/minecraft/world";
import { $ClockNetworkState, $WorldClock } from "java:net/minecraft/world/clock";
import { $DamageSource, $DamageType } from "java:net/minecraft/world/damagesource";
import { $MobEffect, $MobEffect_ } from "java:net/minecraft/world/effect";
import { $Entity, $EntityType, $EntityType_, $EquipmentSlot, $EquipmentSlot_, $PositionMoveRotation, $Relative, $Relative_ } from "java:net/minecraft/world/entity";
import { $Attribute, $AttributeModifier, $Attribute_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $Input } from "java:net/minecraft/world/entity/player";
import { $NewMinecartBehavior$MinecartStep } from "java:net/minecraft/world/entity/vehicle/minecart";
import { $ContainerInput, $ContainerInput_, $MenuType, $RecipeBookType, $RecipeBookType_ } from "java:net/minecraft/world/inventory";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $RecipePropertySet, $SelectableRecipe$SingleInputSet, $StonecutterRecipe } from "java:net/minecraft/world/item/crafting";
import { $RecipeDisplay, $RecipeDisplayEntry, $RecipeDisplayId } from "java:net/minecraft/world/item/crafting/display";
import { $MerchantOffers } from "java:net/minecraft/world/item/trading";
import { $BaseCommandBlock, $ChunkPos, $GameType, $GameType_, $Level } from "java:net/minecraft/world/level";
import { $Block, $Block_, $Mirror, $Mirror_, $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_, $CommandBlockEntity$Mode, $CommandBlockEntity$Mode_, $JigsawBlockEntity$JointType, $JigsawBlockEntity$JointType_, $StructureBlockEntity$UpdateType, $StructureBlockEntity$UpdateType_, $TestInstanceBlockEntity$Data } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $StructureMode, $StructureMode_, $TestBlockMode, $TestBlockMode_ } from "java:net/minecraft/world/level/block/state/properties";
import { $LevelChunk } from "java:net/minecraft/world/level/chunk";
import { $DimensionType } from "java:net/minecraft/world/level/dimension";
import { $GameRule } from "java:net/minecraft/world/level/gamerules";
import { $Heightmap$Types, $Heightmap$Types_ } from "java:net/minecraft/world/level/levelgen";
import { $MapDecoration, $MapId, $MapItemSavedData, $MapItemSavedData$MapPatch } from "java:net/minecraft/world/level/saveddata/maps";
import { $LevelData$RespawnData } from "java:net/minecraft/world/level/storage";
import { $BlockHitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $DisplaySlot, $DisplaySlot_, $PlayerTeam, $Team$CollisionRule, $Team$CollisionRule_, $Team$Visibility, $Team$Visibility_ } from "java:net/minecraft/world/scores";
import { $ObjectiveCriteria$RenderType, $ObjectiveCriteria$RenderType_ } from "java:net/minecraft/world/scores/criteria";
import { $TrackedWaypoint, $TrackedWaypointManager, $Waypoint$Icon } from "java:net/minecraft/world/waypoints";

declare module "java:net/minecraft/network/protocol/game" {
    export interface $ClientGamePacketListener extends $ClientCommonPacketListener, $ClientPongPacketListener {
        handleAddEntity(packet: $ClientboundAddEntityPacket): void;
        handleAddObjective(packet: $ClientboundSetObjectivePacket): void;
        handleAnimate(packet: $ClientboundAnimatePacket): void;
        handleAwardStats(packet: $ClientboundAwardStatsPacket): void;
        handleBlockChangedAck(packet: $ClientboundBlockChangedAckPacket): void;
        handleBlockDestruction(packet: $ClientboundBlockDestructionPacket): void;
        handleBlockEntityData(packet: $ClientboundBlockEntityDataPacket): void;
        handleBlockEvent(packet: $ClientboundBlockEventPacket): void;
        handleBlockUpdate(packet: $ClientboundBlockUpdatePacket): void;
        handleBossUpdate(packet: $ClientboundBossEventPacket): void;
        handleBundlePacket(packet: $ClientboundBundlePacket): void;
        handleChangeDifficulty(packet: $ClientboundChangeDifficultyPacket): void;
        handleChunkBatchFinished(packet: $ClientboundChunkBatchFinishedPacket): void;
        handleChunkBatchStart(packet: $ClientboundChunkBatchStartPacket): void;
        handleChunkBlocksUpdate(packet: $ClientboundSectionBlocksUpdatePacket): void;
        handleChunksBiomes(packet: $ClientboundChunksBiomesPacket): void;
        handleCommandSuggestions(packet: $ClientboundCommandSuggestionsPacket): void;
        handleCommands(packet: $ClientboundCommandsPacket): void;
        handleConfigurationStart(packet: $ClientboundStartConfigurationPacket): void;
        handleContainerClose(packet: $ClientboundContainerClosePacket): void;
        handleContainerContent(packet: $ClientboundContainerSetContentPacket): void;
        handleContainerSetData(packet: $ClientboundContainerSetDataPacket): void;
        handleContainerSetSlot(packet: $ClientboundContainerSetSlotPacket): void;
        handleCustomChatCompletions(packet: $ClientboundCustomChatCompletionsPacket): void;
        handleDamageEvent(packet: $ClientboundDamageEventPacket): void;
        handleDebugBlockValue(packet: $ClientboundDebugBlockValuePacket): void;
        handleDebugChunkValue(packet: $ClientboundDebugChunkValuePacket): void;
        handleDebugEntityValue(packet: $ClientboundDebugEntityValuePacket): void;
        handleDebugEvent(packet: $ClientboundDebugEventPacket): void;
        handleDebugSample(packet: $ClientboundDebugSamplePacket): void;
        handleDeleteChat(packet: $ClientboundDeleteChatPacket): void;
        handleDisguisedChat(packet: $ClientboundDisguisedChatPacket): void;
        handleEntityEvent(packet: $ClientboundEntityEventPacket): void;
        handleEntityLinkPacket(packet: $ClientboundSetEntityLinkPacket): void;
        handleEntityPositionSync(packet: $ClientboundEntityPositionSyncPacket): void;
        handleExplosion(packet: $ClientboundExplodePacket): void;
        handleForgetLevelChunk(packet: $ClientboundForgetLevelChunkPacket): void;
        handleGameEvent(packet: $ClientboundGameEventPacket): void;
        handleGameRuleValues(packet: $ClientboundGameRuleValuesPacket): void;
        handleGameTestHighlightPos(packet: $ClientboundGameTestHighlightPosPacket): void;
        handleHurtAnimation(packet: $ClientboundHurtAnimationPacket): void;
        handleInitializeBorder(packet: $ClientboundInitializeBorderPacket): void;
        handleItemCooldown(packet: $ClientboundCooldownPacket): void;
        handleLevelChunkWithLight(packet: $ClientboundLevelChunkWithLightPacket): void;
        handleLevelEvent(packet: $ClientboundLevelEventPacket): void;
        handleLightUpdatePacket(packet: $ClientboundLightUpdatePacket): void;
        handleLogin(packet: $ClientboundLoginPacket): void;
        handleLookAt(packet: $ClientboundPlayerLookAtPacket): void;
        handleLowDiskSpaceWarning(packet: $ClientboundLowDiskSpaceWarningPacket): void;
        handleMapItemData(packet: $ClientboundMapItemDataPacket): void;
        handleMerchantOffers(packet: $ClientboundMerchantOffersPacket): void;
        handleMinecartAlongTrack(packet: $ClientboundMoveMinecartPacket): void;
        handleMountScreenOpen(packet: $ClientboundMountScreenOpenPacket): void;
        handleMoveEntity(packet: $ClientboundMoveEntityPacket): void;
        handleMovePlayer(packet: $ClientboundPlayerPositionPacket): void;
        handleMoveVehicle(packet: $ClientboundMoveVehiclePacket): void;
        handleOpenBook(packet: $ClientboundOpenBookPacket): void;
        handleOpenScreen(packet: $ClientboundOpenScreenPacket): void;
        handleOpenSignEditor(packet: $ClientboundOpenSignEditorPacket): void;
        handleParticleEvent(packet: $ClientboundLevelParticlesPacket): void;
        handlePlaceRecipe(packet: $ClientboundPlaceGhostRecipePacket): void;
        handlePlayerAbilities(packet: $ClientboundPlayerAbilitiesPacket): void;
        handlePlayerChat(packet: $ClientboundPlayerChatPacket): void;
        handlePlayerCombatEnd(packet: $ClientboundPlayerCombatEndPacket): void;
        handlePlayerCombatEnter(packet: $ClientboundPlayerCombatEnterPacket): void;
        handlePlayerCombatKill(packet: $ClientboundPlayerCombatKillPacket): void;
        handlePlayerInfoRemove(packet: $ClientboundPlayerInfoRemovePacket): void;
        handlePlayerInfoUpdate(packet: $ClientboundPlayerInfoUpdatePacket): void;
        handleProjectilePowerPacket(packet: $ClientboundProjectilePowerPacket): void;
        handleRecipeBookAdd(packet: $ClientboundRecipeBookAddPacket): void;
        handleRecipeBookRemove(packet: $ClientboundRecipeBookRemovePacket): void;
        handleRecipeBookSettings(packet: $ClientboundRecipeBookSettingsPacket): void;
        handleRemoveEntities(packet: $ClientboundRemoveEntitiesPacket): void;
        handleRemoveMobEffect(packet: $ClientboundRemoveMobEffectPacket): void;
        handleResetScore(packet: $ClientboundResetScorePacket): void;
        handleRespawn(packet: $ClientboundRespawnPacket): void;
        handleRotateMob(packet: $ClientboundRotateHeadPacket): void;
        handleRotatePlayer(packet: $ClientboundPlayerRotationPacket): void;
        handleSelectAdvancementsTab(packet: $ClientboundSelectAdvancementsTabPacket): void;
        handleServerData(packet: $ClientboundServerDataPacket): void;
        handleSetBorderCenter(packet: $ClientboundSetBorderCenterPacket): void;
        handleSetBorderLerpSize(packet: $ClientboundSetBorderLerpSizePacket): void;
        handleSetBorderSize(packet: $ClientboundSetBorderSizePacket): void;
        handleSetBorderWarningDelay(packet: $ClientboundSetBorderWarningDelayPacket): void;
        handleSetBorderWarningDistance(packet: $ClientboundSetBorderWarningDistancePacket): void;
        handleSetCamera(packet: $ClientboundSetCameraPacket): void;
        handleSetChunkCacheCenter(packet: $ClientboundSetChunkCacheCenterPacket): void;
        handleSetChunkCacheRadius(packet: $ClientboundSetChunkCacheRadiusPacket): void;
        handleSetCursorItem(packet: $ClientboundSetCursorItemPacket): void;
        handleSetDisplayObjective(packet: $ClientboundSetDisplayObjectivePacket): void;
        handleSetEntityData(packet: $ClientboundSetEntityDataPacket): void;
        handleSetEntityMotion(packet: $ClientboundSetEntityMotionPacket): void;
        handleSetEntityPassengersPacket(packet: $ClientboundSetPassengersPacket): void;
        handleSetEquipment(packet: $ClientboundSetEquipmentPacket): void;
        handleSetExperience(packet: $ClientboundSetExperiencePacket): void;
        handleSetHealth(packet: $ClientboundSetHealthPacket): void;
        handleSetHeldSlot(packet: $ClientboundSetHeldSlotPacket): void;
        handleSetPlayerInventory(packet: $ClientboundSetPlayerInventoryPacket): void;
        handleSetPlayerTeamPacket(packet: $ClientboundSetPlayerTeamPacket): void;
        handleSetScore(packet: $ClientboundSetScorePacket): void;
        handleSetSimulationDistance(packet: $ClientboundSetSimulationDistancePacket): void;
        handleSetSpawn(packet: $ClientboundSetDefaultSpawnPositionPacket): void;
        handleSetTime(packet: $ClientboundSetTimePacket): void;
        handleSoundEntityEvent(packet: $ClientboundSoundEntityPacket): void;
        handleSoundEvent(packet: $ClientboundSoundPacket): void;
        handleStopSoundEvent(packet: $ClientboundStopSoundPacket): void;
        handleSystemChat(packet: $ClientboundSystemChatPacket): void;
        handleTabListCustomisation(packet: $ClientboundTabListPacket): void;
        handleTagQueryPacket(packet: $ClientboundTagQueryPacket): void;
        handleTakeItemEntity(packet: $ClientboundTakeItemEntityPacket): void;
        handleTeleportEntity(packet: $ClientboundTeleportEntityPacket): void;
        handleTestInstanceBlockStatus(packet: $ClientboundTestInstanceBlockStatus): void;
        handleTickingState(packet: $ClientboundTickingStatePacket): void;
        handleTickingStep(packet: $ClientboundTickingStepPacket): void;
        handleTitlesClear(packet: $ClientboundClearTitlesPacket): void;
        handleUpdateAdvancementsPacket(packet: $ClientboundUpdateAdvancementsPacket): void;
        handleUpdateAttributes(packet: $ClientboundUpdateAttributesPacket): void;
        handleUpdateMobEffect(packet: $ClientboundUpdateMobEffectPacket): void;
        handleUpdateRecipes(packet: $ClientboundUpdateRecipesPacket): void;
        handleWaypoint(packet: $ClientboundTrackedWaypointPacket): void;
        protocol(): $ConnectionProtocol;
        setActionBarText(packet: $ClientboundSetActionBarTextPacket): void;
        setSubtitleText(packet: $ClientboundSetSubtitleTextPacket): void;
        setTitleText(packet: $ClientboundSetTitleTextPacket): void;
        setTitlesAnimation(packet: $ClientboundSetTitlesAnimationPacket): void;
    }

    export class $ClientboundAddEntityPacket implements $Packet {
        constructor(id: number, uuid: string, x: number, y: number, z: number, xRot: number, yRot: number, type: $EntityType<any>, data: number, movement: $Vec3_, yHeadRot: number);
        constructor(entity: $Entity, data: number, pos: $BlockPos_);
        constructor(entity: $Entity, serverEntity: $ServerEntity);
        constructor(entity: $Entity, serverEntity: $ServerEntity, data: number);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundAddEntityPacket>;
        get data(): number;
        getData(): number;
        get id(): number;
        getId(): number;
        get movement(): $Vec3;
        getMovement(): $Vec3;
        get type(): $EntityType<any>;
        getType(): $EntityType<any>;
        get uUID(): $UUID;
        getUUID(): $UUID;
        get xRot(): number;
        getXRot(): number;
        get x(): number;
        getX(): number;
        get yHeadRot(): number;
        getYHeadRot(): number;
        get yRot(): number;
        getYRot(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundAddEntityPacket>;
    }

    export class $ClientboundAnimatePacket implements $Packet {
        constructor(entity: $Entity, action: number);
        static CRITICAL_HIT: number;
        static MAGIC_CRITICAL_HIT: number;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundAnimatePacket>;
        static SWING_MAIN_HAND: number;
        static SWING_OFF_HAND: number;
        static WAKE_UP: number;
        get action(): number;
        getAction(): number;
        get id(): number;
        getId(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundAnimatePacket>;
    }

    export class $ClientboundAwardStatsPacket extends $Record implements $Packet {
        constructor(stats: $Object2IntMap<$Stat<any>>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundAwardStatsPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        stats(): $Object2IntMap<$Stat<any>>;
        toString(): string;
        type(): $PacketType<$ClientboundAwardStatsPacket>;
    }

    export class $ClientboundBlockChangedAckPacket extends $Record implements $Packet {
        constructor(sequence: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundBlockChangedAckPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        sequence(): number;
        toString(): string;
        type(): $PacketType<$ClientboundBlockChangedAckPacket>;
    }

    export class $ClientboundBlockDestructionPacket implements $Packet {
        constructor(id: number, pos: $BlockPos_, progress: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundBlockDestructionPacket>;
        get id(): number;
        getId(): number;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get progress(): number;
        getProgress(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundBlockDestructionPacket>;
    }

    export class $ClientboundBlockEntityDataPacket implements $Packet {
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundBlockEntityDataPacket>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get tag(): $CompoundTag;
        getTag(): $CompoundTag;
        get type(): $BlockEntityType<any>;
        getType(): $BlockEntityType<any>;
        static create(blockEntity: $BlockEntity, updateTagSaver: $BiFunction<$BlockEntity, $RegistryAccess, $CompoundTag_>): $ClientboundBlockEntityDataPacket;
        static create(blockEntity: $BlockEntity): $ClientboundBlockEntityDataPacket;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundBlockEntityDataPacket>;
    }

    export class $ClientboundBlockEventPacket implements $Packet {
        constructor(pos: $BlockPos_, block: $Block_, b0: number, b1: number);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundBlockEventPacket>;
        get b0(): number;
        getB0(): number;
        get b1(): number;
        getB1(): number;
        get block(): $Block;
        getBlock(): $Block;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundBlockEventPacket>;
    }

    export class $ClientboundBlockUpdatePacket implements $Packet {
        constructor(pos: $BlockPos_, state: $BlockState_);
        constructor(level: $BlockGetter, pos: $BlockPos_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundBlockUpdatePacket>;
        get blockState(): $BlockState;
        getBlockState(): $BlockState;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundBlockUpdatePacket>;
    }

    export class $ClientboundBossEventPacket implements $Packet {
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundBossEventPacket>;
        static createAddPacket(event: $BossEvent): $ClientboundBossEventPacket;
        static createRemovePacket(id: string): $ClientboundBossEventPacket;
        static createUpdateNamePacket(event: $BossEvent): $ClientboundBossEventPacket;
        static createUpdateProgressPacket(event: $BossEvent): $ClientboundBossEventPacket;
        static createUpdatePropertiesPacket(event: $BossEvent): $ClientboundBossEventPacket;
        static createUpdateStylePacket(event: $BossEvent): $ClientboundBossEventPacket;
        dispatch(handler: $ClientboundBossEventPacket$Handler): void;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundBossEventPacket>;
    }

    export interface $ClientboundBossEventPacket$Handler {
        add(id: string, name: $Component_, progress: number, color: $BossEvent$BossBarColor_, overlay: $BossEvent$BossBarOverlay_, darkenScreen: boolean, playMusic: boolean, createWorldFog: boolean): void;
        remove(id: string): void;
        updateName(id: string, name: $Component_): void;
        updateProgress(id: string, progress: number): void;
        updateProperties(id: string, darkenScreen: boolean, playMusic: boolean, createWorldFog: boolean): void;
        updateStyle(id: string, color: $BossEvent$BossBarColor_, overlay: $BossEvent$BossBarOverlay_): void;
    }

    export class $ClientboundBundlePacket extends $BundlePacket {
        constructor(packets: $Iterable<$Packet<any>>);
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundBundlePacket>;
    }

    export class $ClientboundChangeDifficultyPacket extends $Record implements $Packet {
        constructor(difficulty: $Difficulty_, locked: boolean);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundChangeDifficultyPacket>;
        difficulty(): $Difficulty;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        locked(): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundChangeDifficultyPacket>;
    }

    export class $ClientboundChunkBatchFinishedPacket extends $Record implements $Packet {
        constructor(batchSize: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundChunkBatchFinishedPacket>;
        batchSize(): number;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundChunkBatchFinishedPacket>;
    }

    export class $ClientboundChunkBatchStartPacket implements $Packet {
        static INSTANCE: $ClientboundChunkBatchStartPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundChunkBatchStartPacket>;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundChunkBatchStartPacket>;
    }

    export class $ClientboundChunksBiomesPacket extends $Record implements $Packet {
        constructor(chunkBiomeData: $ClientboundChunksBiomesPacket$ChunkBiomeData[]);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundChunksBiomesPacket>;
        static forChunks(chunks: $LevelChunk[]): $ClientboundChunksBiomesPacket;
        chunkBiomeData(): $List<$ClientboundChunksBiomesPacket$ChunkBiomeData>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundChunksBiomesPacket>;
    }

    export class $ClientboundChunksBiomesPacket$ChunkBiomeData extends $Record {
        constructor(input: $FriendlyByteBuf);
        constructor(pos: $ChunkPos, buffer: number[]);
        constructor(chunk: $LevelChunk);
        get readBuffer(): $FriendlyByteBuf;
        getReadBuffer(): $FriendlyByteBuf;
        static extractChunkData(buffer: $FriendlyByteBuf, chunk: $LevelChunk): void;
        buffer(): number[];
        equals(o: object): boolean;
        hashCode(): number;
        pos(): $ChunkPos;
        toString(): string;
        write(output: $FriendlyByteBuf): void;
    }

    export class $ClientboundClearTitlesPacket implements $Packet {
        constructor(resetTimes: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundClearTitlesPacket>;
        handle(listener: $ClientGamePacketListener): void;
        shouldResetTimes(): boolean;
        type(): $PacketType<$ClientboundClearTitlesPacket>;
    }

    export class $ClientboundCommandSuggestionsPacket extends $Record implements $Packet {
        constructor(id: number, suggestions: $Suggestions);
        constructor(id: number, start: number, length: number, suggestions: $ClientboundCommandSuggestionsPacket$Entry[]);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundCommandSuggestionsPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        id(): number;
        length(): number;
        start(): number;
        suggestions(): $List<$ClientboundCommandSuggestionsPacket$Entry>;
        toString(): string;
        toSuggestions(): $Suggestions;
        type(): $PacketType<$ClientboundCommandSuggestionsPacket>;
    }

    export class $ClientboundCommandSuggestionsPacket$Entry extends $Record {
        constructor(text: string, tooltip: $Optional<$Component_>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundCommandSuggestionsPacket$Entry>;
        equals(o: object): boolean;
        hashCode(): number;
        text(): string;
        toString(): string;
        tooltip(): $Optional<$Component>;
    }

    export class $ClientboundCommandsPacket implements $Packet {
        constructor(root: $RootCommandNode<S>, inspector: $ClientboundCommandsPacket$NodeInspector<S>);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundCommandsPacket>;
        getRoot<S>(context: $CommandBuildContext, builder: $ClientboundCommandsPacket$NodeBuilder<S>): $RootCommandNode<S>;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundCommandsPacket>;
    }

    export interface $ClientboundCommandsPacket$NodeBuilder<S> {
        configure(input: $ArgumentBuilder<S, any>, executable: boolean, restricted: boolean): $ArgumentBuilder<S, any>;
        createArgument(id: string, argumentType: $ArgumentType<any>, suggestionId: $Identifier_): $ArgumentBuilder<S, any>;
        createLiteral(id: string): $ArgumentBuilder<S, any>;
    }

    export interface $ClientboundCommandsPacket$NodeInspector<S> {
        isExecutable(node: $CommandNode<S>): boolean;
        isRestricted(node: $CommandNode<S>): boolean;
        suggestionId(node: $ArgumentCommandNode<S, any>): $Identifier;
    }

    export class $ClientboundContainerClosePacket implements $Packet {
        constructor(containerId: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundContainerClosePacket>;
        get containerId(): number;
        getContainerId(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundContainerClosePacket>;
    }

    export class $ClientboundContainerSetContentPacket extends $Record implements $Packet {
        constructor(containerId: number, stateId: number, items: $ItemStack_[], carriedItem: $ItemStack_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundContainerSetContentPacket>;
        carriedItem(): $ItemStack;
        containerId(): number;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        items(): $List<$ItemStack>;
        stateId(): number;
        toString(): string;
        type(): $PacketType<$ClientboundContainerSetContentPacket>;
    }

    export class $ClientboundContainerSetDataPacket implements $Packet {
        constructor(containerId: number, id: number, value: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundContainerSetDataPacket>;
        get containerId(): number;
        getContainerId(): number;
        get id(): number;
        getId(): number;
        get value(): number;
        getValue(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundContainerSetDataPacket>;
    }

    export class $ClientboundContainerSetSlotPacket implements $Packet {
        constructor(containerId: number, stateId: number, slot: number, itemStack: $ItemStack_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundContainerSetSlotPacket>;
        get containerId(): number;
        getContainerId(): number;
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get slot(): number;
        getSlot(): number;
        get stateId(): number;
        getStateId(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundContainerSetSlotPacket>;
    }

    export class $ClientboundCooldownPacket extends $Record implements $Packet {
        constructor(cooldownGroup: $Identifier_, duration: number);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundCooldownPacket>;
        cooldownGroup(): $Identifier;
        duration(): number;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundCooldownPacket>;
    }

    export class $ClientboundCustomChatCompletionsPacket extends $Record implements $Packet {
        constructor(action: $ClientboundCustomChatCompletionsPacket$Action_, entries: string[]);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundCustomChatCompletionsPacket>;
        action(): $ClientboundCustomChatCompletionsPacket$Action;
        entries(): $List<string>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundCustomChatCompletionsPacket>;
    }

    export class $ClientboundCustomChatCompletionsPacket$Action {
        static ADD: $ClientboundCustomChatCompletionsPacket$Action;
        static REMOVE: $ClientboundCustomChatCompletionsPacket$Action;
        static SET: $ClientboundCustomChatCompletionsPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClientboundCustomChatCompletionsPacket$Action[];
        static valueOf(name: string): $ClientboundCustomChatCompletionsPacket$Action;
    }

    export class $ClientboundDamageEventPacket extends $Record implements $Packet {
        constructor(entityId: number, sourceType: $Holder<$DamageType>, sourceCauseId: number, sourceDirectId: number, sourcePosition: $Optional<$Vec3_>);
        constructor(entity: $Entity, source: $DamageSource);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundDamageEventPacket>;
        entityId(): number;
        equals(o: object): boolean;
        getSource(level: $Level): $DamageSource;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        sourceCauseId(): number;
        sourceDirectId(): number;
        sourcePosition(): $Optional<$Vec3>;
        sourceType(): $Holder<$DamageType>;
        toString(): string;
        type(): $PacketType<$ClientboundDamageEventPacket>;
    }

    export class $ClientboundDebugBlockValuePacket extends $Record implements $Packet {
        constructor(blockPos: $BlockPos_, update: $DebugSubscription$Update<any>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundDebugBlockValuePacket>;
        blockPos(): $BlockPos;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundDebugBlockValuePacket>;
        update(): $DebugSubscription$Update<any>;
    }

    export class $ClientboundDebugChunkValuePacket extends $Record implements $Packet {
        constructor(chunkPos: $ChunkPos, update: $DebugSubscription$Update<any>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundDebugChunkValuePacket>;
        chunkPos(): $ChunkPos;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundDebugChunkValuePacket>;
        update(): $DebugSubscription$Update<any>;
    }

    export class $ClientboundDebugEntityValuePacket extends $Record implements $Packet {
        constructor(entityId: number, update: $DebugSubscription$Update<any>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundDebugEntityValuePacket>;
        entityId(): number;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundDebugEntityValuePacket>;
        update(): $DebugSubscription$Update<any>;
    }

    export class $ClientboundDebugEventPacket extends $Record implements $Packet {
        constructor(event: $DebugSubscription$Event<any>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundDebugEventPacket>;
        equals(o: object): boolean;
        event(): $DebugSubscription$Event<any>;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundDebugEventPacket>;
    }

    export class $ClientboundDebugSamplePacket extends $Record implements $Packet {
        constructor(sample: number[], debugSampleType: $RemoteDebugSampleType_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundDebugSamplePacket>;
        debugSampleType(): $RemoteDebugSampleType;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        sample(): number[];
        toString(): string;
        type(): $PacketType<$ClientboundDebugSamplePacket>;
    }

    export class $ClientboundDeleteChatPacket extends $Record implements $Packet {
        constructor(messageSignature: $MessageSignature$Packed);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundDeleteChatPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        messageSignature(): $MessageSignature$Packed;
        toString(): string;
        type(): $PacketType<$ClientboundDeleteChatPacket>;
    }

    export class $ClientboundDisguisedChatPacket extends $Record implements $Packet {
        constructor(message: $Component_, chatType: $ChatType$Bound);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundDisguisedChatPacket>;
        get skippable(): boolean;
        isSkippable(): boolean;
        chatType(): $ChatType$Bound;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        message(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundDisguisedChatPacket>;
    }

    export class $ClientboundEntityEventPacket implements $Packet {
        constructor(entity: $Entity, eventId: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundEntityEventPacket>;
        get eventId(): number;
        getEventId(): number;
        getEntity(level: $Level): $Entity;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundEntityEventPacket>;
    }

    export class $ClientboundEntityPositionSyncPacket extends $Record implements $Packet {
        constructor(id: number, values: $PositionMoveRotation, onGround: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundEntityPositionSyncPacket>;
        static of(entity: $Entity): $ClientboundEntityPositionSyncPacket;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        id(): number;
        onGround(): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundEntityPositionSyncPacket>;
        values(): $PositionMoveRotation;
    }

    export class $ClientboundExplodePacket extends $Record implements $Packet {
        constructor(center: $Vec3_, radius: number, blockCount: number, playerKnockback: $Optional<$Vec3_>, explosionParticle: $ParticleOptions, explosionSound: $Holder<$SoundEvent_>, blockParticles: $WeightedList<$ExplosionParticleInfo>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundExplodePacket>;
        blockCount(): number;
        blockParticles(): $WeightedList<$ExplosionParticleInfo>;
        center(): $Vec3;
        equals(o: object): boolean;
        explosionParticle(): $ParticleOptions;
        explosionSound(): $Holder<$SoundEvent>;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        playerKnockback(): $Optional<$Vec3>;
        radius(): number;
        toString(): string;
        type(): $PacketType<$ClientboundExplodePacket>;
    }

    export class $ClientboundForgetLevelChunkPacket extends $Record implements $Packet {
        constructor(pos: $ChunkPos);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundForgetLevelChunkPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        pos(): $ChunkPos;
        toString(): string;
        type(): $PacketType<$ClientboundForgetLevelChunkPacket>;
    }

    export class $ClientboundGameEventPacket implements $Packet {
        constructor(event: $ClientboundGameEventPacket$Type, param: number);
        static CHANGE_GAME_MODE: $ClientboundGameEventPacket$Type;
        static DEMO_EVENT: $ClientboundGameEventPacket$Type;
        static DEMO_PARAM_HINT_1: number;
        static DEMO_PARAM_HINT_2: number;
        static DEMO_PARAM_HINT_3: number;
        static DEMO_PARAM_HINT_4: number;
        static DEMO_PARAM_INTRO: number;
        static GUARDIAN_ELDER_EFFECT: $ClientboundGameEventPacket$Type;
        static IMMEDIATE_RESPAWN: $ClientboundGameEventPacket$Type;
        static LEVEL_CHUNKS_LOAD_START: $ClientboundGameEventPacket$Type;
        static LIMITED_CRAFTING: $ClientboundGameEventPacket$Type;
        static NO_RESPAWN_BLOCK_AVAILABLE: $ClientboundGameEventPacket$Type;
        static PLAY_ARROW_HIT_SOUND: $ClientboundGameEventPacket$Type;
        static PUFFER_FISH_STING: $ClientboundGameEventPacket$Type;
        static RAIN_LEVEL_CHANGE: $ClientboundGameEventPacket$Type;
        static START_RAINING: $ClientboundGameEventPacket$Type;
        static STOP_RAINING: $ClientboundGameEventPacket$Type;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundGameEventPacket>;
        static THUNDER_LEVEL_CHANGE: $ClientboundGameEventPacket$Type;
        static WIN_GAME: $ClientboundGameEventPacket$Type;
        get event(): $ClientboundGameEventPacket$Type;
        getEvent(): $ClientboundGameEventPacket$Type;
        get param(): number;
        getParam(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundGameEventPacket>;
    }

    export class $ClientboundGameEventPacket$Type {
        constructor(id: number);
    }

    export class $ClientboundGameRuleValuesPacket extends $Record implements $Packet {
        constructor(values: { [key: $ResourceKey<$GameRule<any>>]: string });
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundGameRuleValuesPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundGameRuleValuesPacket>;
        values(): $Map<$ResourceKey<$GameRule<any>>, string>;
    }

    export class $ClientboundGameTestHighlightPosPacket extends $Record implements $Packet {
        constructor(absolutePos: $BlockPos_, relativePos: $BlockPos_);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundGameTestHighlightPosPacket>;
        absolutePos(): $BlockPos;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        relativePos(): $BlockPos;
        toString(): string;
        type(): $PacketType<$ClientboundGameTestHighlightPosPacket>;
    }

    export class $ClientboundHurtAnimationPacket extends $Record implements $Packet {
        constructor(id: number, yaw: number);
        constructor(entity: $LivingEntity);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundHurtAnimationPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        id(): number;
        toString(): string;
        type(): $PacketType<$ClientboundHurtAnimationPacket>;
        yaw(): number;
    }

    export class $ClientboundInitializeBorderPacket implements $Packet {
        constructor(border: $WorldBorder);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundInitializeBorderPacket>;
        get lerpTime(): number;
        getLerpTime(): number;
        get newAbsoluteMaxSize(): number;
        getNewAbsoluteMaxSize(): number;
        get newCenterX(): number;
        getNewCenterX(): number;
        get newCenterZ(): number;
        getNewCenterZ(): number;
        get newSize(): number;
        getNewSize(): number;
        get oldSize(): number;
        getOldSize(): number;
        get warningBlocks(): number;
        getWarningBlocks(): number;
        get warningTime(): number;
        getWarningTime(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundInitializeBorderPacket>;
    }

    export class $ClientboundLevelChunkPacketData {
        constructor(input: $RegistryFriendlyByteBuf, x: number, z: number);
        constructor(levelChunk: $LevelChunk);
        get heightmaps(): $Map<$Heightmap$Types, number[]>;
        getHeightmaps(): $Map<$Heightmap$Types, number[]>;
        get readBuffer(): $FriendlyByteBuf;
        getReadBuffer(): $FriendlyByteBuf;
        static extractChunkData(buffer: $FriendlyByteBuf, chunk: $LevelChunk): void;
        getBlockEntitiesTagsConsumer(x: number, z: number): $Consumer<$ClientboundLevelChunkPacketData$BlockEntityTagOutput>;
        write(output: $RegistryFriendlyByteBuf): void;
    }

    export interface $ClientboundLevelChunkPacketData$BlockEntityTagOutput {
        accept(pos: $BlockPos_, type: $BlockEntityType<any>, tag: $CompoundTag_): void;
    }

    export class $ClientboundLevelChunkWithLightPacket implements $Packet {
        constructor(levelChunk: $LevelChunk, lightEngine: $LevelLightEngine, skyChangedLightSectionFilter: $BitSet, blockChangedLightSectionFilter: $BitSet);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundLevelChunkWithLightPacket>;
        get chunkData(): $ClientboundLevelChunkPacketData;
        getChunkData(): $ClientboundLevelChunkPacketData;
        get lightData(): $ClientboundLightUpdatePacketData;
        getLightData(): $ClientboundLightUpdatePacketData;
        get x(): number;
        getX(): number;
        get z(): number;
        getZ(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundLevelChunkWithLightPacket>;
    }

    export class $ClientboundLevelEventPacket implements $Packet {
        constructor(type: number, pos: $BlockPos_, data: number, globalEvent: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundLevelEventPacket>;
        get data(): number;
        getData(): number;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get type(): number;
        getType(): number;
        get globalEvent(): boolean;
        isGlobalEvent(): boolean;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundLevelEventPacket>;
    }

    export class $ClientboundLevelParticlesPacket implements $Packet {
        constructor(particle: T, overrideLimiter: boolean, alwaysShow: boolean, x: number, y: number, z: number, xDist: number, yDist: number, zDist: number, maxSpeed: number, count: number);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundLevelParticlesPacket>;
        get count(): number;
        getCount(): number;
        get maxSpeed(): number;
        getMaxSpeed(): number;
        get particle(): $ParticleOptions;
        getParticle(): $ParticleOptions;
        get xDist(): number;
        getXDist(): number;
        get x(): number;
        getX(): number;
        get yDist(): number;
        getYDist(): number;
        get y(): number;
        getY(): number;
        get zDist(): number;
        getZDist(): number;
        get z(): number;
        getZ(): number;
        get overrideLimiter(): boolean;
        isOverrideLimiter(): boolean;
        alwaysShow(): boolean;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundLevelParticlesPacket>;
    }

    export class $ClientboundLightUpdatePacket implements $Packet {
        constructor(pos: $ChunkPos, lightEngine: $LevelLightEngine, skyChangedLightSectionFilter: $BitSet, blockChangedLightSectionFilter: $BitSet);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundLightUpdatePacket>;
        get lightData(): $ClientboundLightUpdatePacketData;
        getLightData(): $ClientboundLightUpdatePacketData;
        get x(): number;
        getX(): number;
        get z(): number;
        getZ(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundLightUpdatePacket>;
    }

    export class $ClientboundLightUpdatePacketData {
        constructor(input: $FriendlyByteBuf, x: number, z: number);
        constructor(chunkPos: $ChunkPos, lightEngine: $LevelLightEngine, skyChangedLightSectionFilter: $BitSet, blockChangedLightSectionFilter: $BitSet);
        get blockUpdates(): $List<number[]>;
        getBlockUpdates(): $List<number[]>;
        get blockYMask(): $BitSet;
        getBlockYMask(): $BitSet;
        get emptyBlockYMask(): $BitSet;
        getEmptyBlockYMask(): $BitSet;
        get emptySkyYMask(): $BitSet;
        getEmptySkyYMask(): $BitSet;
        get skyUpdates(): $List<number[]>;
        getSkyUpdates(): $List<number[]>;
        get skyYMask(): $BitSet;
        getSkyYMask(): $BitSet;
        write(output: $FriendlyByteBuf): void;
    }

    export class $ClientboundLoginPacket extends $Record implements $Packet {
        constructor(playerId: number, hardcore: boolean, levels: $ResourceKey<$Level>[], maxPlayers: number, chunkRadius: number, simulationDistance: number, reducedDebugInfo: boolean, showDeathScreen: boolean, doLimitedCrafting: boolean, commonPlayerSpawnInfo: $CommonPlayerSpawnInfo, enforcesSecureChat: boolean);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundLoginPacket>;
        chunkRadius(): number;
        commonPlayerSpawnInfo(): $CommonPlayerSpawnInfo;
        doLimitedCrafting(): boolean;
        enforcesSecureChat(): boolean;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hardcore(): boolean;
        hashCode(): number;
        levels(): $Set<$ResourceKey<$Level>>;
        maxPlayers(): number;
        playerId(): number;
        reducedDebugInfo(): boolean;
        showDeathScreen(): boolean;
        simulationDistance(): number;
        toString(): string;
        type(): $PacketType<$ClientboundLoginPacket>;
    }

    export class $ClientboundLowDiskSpaceWarningPacket implements $Packet {
        static INSTANCE: $ClientboundLowDiskSpaceWarningPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundLowDiskSpaceWarningPacket>;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundLowDiskSpaceWarningPacket>;
    }

    export class $ClientboundMapItemDataPacket extends $Record implements $Packet {
        constructor(mapId: $MapId, scale: number, locked: boolean, decorations: $MapDecoration[], colorPatch: $MapItemSavedData$MapPatch);
        constructor(mapId: $MapId, scale: number, locked: boolean, decorations: $Optional<$MapDecoration[]>, colorPatch: $Optional<$MapItemSavedData$MapPatch>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundMapItemDataPacket>;
        applyToMap(map: $MapItemSavedData): void;
        colorPatch(): $Optional<$MapItemSavedData$MapPatch>;
        decorations(): $Optional<$List<$MapDecoration>>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        locked(): boolean;
        mapId(): $MapId;
        scale(): number;
        toString(): string;
        type(): $PacketType<$ClientboundMapItemDataPacket>;
    }

    export class $ClientboundMerchantOffersPacket implements $Packet {
        constructor(containerId: number, offers: $MerchantOffers, merchantLevel: number, merchantXp: number, showProgress: boolean, canRestock: boolean);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundMerchantOffersPacket>;
        get containerId(): number;
        getContainerId(): number;
        get offers(): $MerchantOffers;
        getOffers(): $MerchantOffers;
        get villagerLevel(): number;
        getVillagerLevel(): number;
        get villagerXp(): number;
        getVillagerXp(): number;
        canRestock(): boolean;
        handle(listener: $ClientGamePacketListener): void;
        showProgress(): boolean;
        type(): $PacketType<$ClientboundMerchantOffersPacket>;
    }

    export class $ClientboundMountScreenOpenPacket implements $Packet {
        constructor(containerId: number, inventoryColumns: number, entityId: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundMountScreenOpenPacket>;
        get containerId(): number;
        getContainerId(): number;
        get entityId(): number;
        getEntityId(): number;
        get inventoryColumns(): number;
        getInventoryColumns(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundMountScreenOpenPacket>;
    }

    export class $ClientboundMoveEntityPacket implements $Packet {
        get xRot(): number;
        getXRot(): number;
        get xa(): number;
        getXa(): number;
        get yRot(): number;
        getYRot(): number;
        get ya(): number;
        getYa(): number;
        get za(): number;
        getZa(): number;
        get onGround(): boolean;
        isOnGround(): boolean;
        getEntity(level: $Level): $Entity;
        handle(listener: $ClientGamePacketListener): void;
        hasPosition(): boolean;
        hasRotation(): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundMoveEntityPacket>;
    }

    export class $ClientboundMoveMinecartPacket extends $Record implements $Packet {
        constructor(entityId: number, lerpSteps: $NewMinecartBehavior$MinecartStep[]);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundMoveMinecartPacket>;
        entityId(): number;
        equals(o: object): boolean;
        getEntity(level: $Level): $Entity;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        lerpSteps(): $List<$NewMinecartBehavior$MinecartStep>;
        toString(): string;
        type(): $PacketType<$ClientboundMoveMinecartPacket>;
    }

    export class $ClientboundMoveVehiclePacket extends $Record implements $Packet {
        constructor(position: $Vec3_, yRot: number, xRot: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundMoveVehiclePacket>;
        static fromEntity(entity: $Entity): $ClientboundMoveVehiclePacket;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        position(): $Vec3;
        toString(): string;
        type(): $PacketType<$ClientboundMoveVehiclePacket>;
        xRot(): number;
        yRot(): number;
    }

    export class $ClientboundOpenBookPacket implements $Packet {
        constructor(hand: $InteractionHand_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundOpenBookPacket>;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundOpenBookPacket>;
    }

    export class $ClientboundOpenScreenPacket implements $Packet {
        constructor(containerId: number, type: $MenuType<any>, title: $Component_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundOpenScreenPacket>;
        get containerId(): number;
        getContainerId(): number;
        get title(): $Component;
        getTitle(): $Component;
        get type(): $MenuType<any>;
        getType(): $MenuType<any>;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundOpenScreenPacket>;
    }

    export class $ClientboundOpenSignEditorPacket implements $Packet {
        constructor(pos: $BlockPos_, isFrontText: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundOpenSignEditorPacket>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get frontText(): boolean;
        isFrontText(): boolean;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundOpenSignEditorPacket>;
    }

    export class $ClientboundPlaceGhostRecipePacket extends $Record implements $Packet {
        constructor(containerId: number, recipeDisplay: $RecipeDisplay);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundPlaceGhostRecipePacket>;
        containerId(): number;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        recipeDisplay(): $RecipeDisplay;
        toString(): string;
        type(): $PacketType<$ClientboundPlaceGhostRecipePacket>;
    }

    export class $ClientboundPlayerAbilitiesPacket implements $Packet {
        constructor(abilities: $Abilities);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPlayerAbilitiesPacket>;
        get flyingSpeed(): number;
        getFlyingSpeed(): number;
        get walkingSpeed(): number;
        getWalkingSpeed(): number;
        get flying(): boolean;
        isFlying(): boolean;
        get invulnerable(): boolean;
        isInvulnerable(): boolean;
        canFly(): boolean;
        canInstabuild(): boolean;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundPlayerAbilitiesPacket>;
    }

    export class $ClientboundPlayerChatPacket extends $Record implements $Packet {
        constructor(globalIndex: number, sender: string, index: number, signature: $MessageSignature, body: $SignedMessageBody$Packed, unsignedContent: $Component_, filterMask: $FilterMask, chatType: $ChatType$Bound);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundPlayerChatPacket>;
        get skippable(): boolean;
        isSkippable(): boolean;
        body(): $SignedMessageBody$Packed;
        chatType(): $ChatType$Bound;
        equals(o: object): boolean;
        filterMask(): $FilterMask;
        globalIndex(): number;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        index(): number;
        sender(): $UUID;
        signature(): $MessageSignature;
        toString(): string;
        type(): $PacketType<$ClientboundPlayerChatPacket>;
        unsignedContent(): $Component;
    }

    export class $ClientboundPlayerCombatEndPacket implements $Packet {
        constructor(duration: number);
        constructor(tracker: $CombatTracker);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPlayerCombatEndPacket>;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundPlayerCombatEndPacket>;
    }

    export class $ClientboundPlayerCombatEnterPacket implements $Packet {
        static INSTANCE: $ClientboundPlayerCombatEnterPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundPlayerCombatEnterPacket>;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundPlayerCombatEnterPacket>;
    }

    export class $ClientboundPlayerCombatKillPacket extends $Record implements $Packet {
        constructor(playerId: number, message: $Component_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundPlayerCombatKillPacket>;
        get skippable(): boolean;
        isSkippable(): boolean;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        message(): $Component;
        playerId(): number;
        toString(): string;
        type(): $PacketType<$ClientboundPlayerCombatKillPacket>;
    }

    export class $ClientboundPlayerInfoRemovePacket extends $Record implements $Packet {
        constructor(profileIds: string[]);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPlayerInfoRemovePacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        profileIds(): $List<$UUID>;
        toString(): string;
        type(): $PacketType<$ClientboundPlayerInfoRemovePacket>;
    }

    export class $ClientboundPlayerInfoUpdatePacket implements $Packet {
        constructor(actions: $EnumSet<$ClientboundPlayerInfoUpdatePacket$Action_>, players: $ServerPlayer[]);
        constructor(action: $ClientboundPlayerInfoUpdatePacket$Action_, player: $ServerPlayer);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundPlayerInfoUpdatePacket>;
        static createPlayerInitializing(players: $ServerPlayer[]): $ClientboundPlayerInfoUpdatePacket;
        actions(): $EnumSet<$ClientboundPlayerInfoUpdatePacket$Action>;
        entries(): $List<$ClientboundPlayerInfoUpdatePacket$Entry>;
        handle(listener: $ClientGamePacketListener): void;
        newEntries(): $List<$ClientboundPlayerInfoUpdatePacket$Entry>;
        toString(): string;
        type(): $PacketType<$ClientboundPlayerInfoUpdatePacket>;
    }

    export class $ClientboundPlayerInfoUpdatePacket$Action {
        static ADD_PLAYER: $ClientboundPlayerInfoUpdatePacket$Action;
        static INITIALIZE_CHAT: $ClientboundPlayerInfoUpdatePacket$Action;
        static UPDATE_DISPLAY_NAME: $ClientboundPlayerInfoUpdatePacket$Action;
        static UPDATE_GAME_MODE: $ClientboundPlayerInfoUpdatePacket$Action;
        static UPDATE_HAT: $ClientboundPlayerInfoUpdatePacket$Action;
        static UPDATE_LATENCY: $ClientboundPlayerInfoUpdatePacket$Action;
        static UPDATE_LISTED: $ClientboundPlayerInfoUpdatePacket$Action;
        static UPDATE_LIST_ORDER: $ClientboundPlayerInfoUpdatePacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClientboundPlayerInfoUpdatePacket$Action[];
        static valueOf(name: string): $ClientboundPlayerInfoUpdatePacket$Action;
    }

    export class $ClientboundPlayerInfoUpdatePacket$Entry extends $Record {
        constructor(profileId: string, profile: $GameProfile, listed: boolean, latency: number, gameMode: $GameType_, displayName: $Component_, showHat: boolean, listOrder: number, chatSession: $RemoteChatSession$Data);
        chatSession(): $RemoteChatSession$Data;
        displayName(): $Component;
        equals(o: object): boolean;
        gameMode(): $GameType;
        hashCode(): number;
        latency(): number;
        listOrder(): number;
        listed(): boolean;
        profileId(): $UUID;
        profile(): $GameProfile;
        showHat(): boolean;
        toString(): string;
    }

    export class $ClientboundPlayerLookAtPacket implements $Packet {
        constructor(fromAnchor: $EntityAnchorArgument$Anchor_, x: number, y: number, z: number);
        constructor(fromAnchor: $EntityAnchorArgument$Anchor_, entity: $Entity, toAnchor: $EntityAnchorArgument$Anchor_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPlayerLookAtPacket>;
        get fromAnchor(): $EntityAnchorArgument$Anchor;
        getFromAnchor(): $EntityAnchorArgument$Anchor;
        getPosition(level: $Level): $Vec3;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundPlayerLookAtPacket>;
    }

    export class $ClientboundPlayerPositionPacket extends $Record implements $Packet {
        constructor(id: number, change: $PositionMoveRotation, relatives: $Relative_[]);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPlayerPositionPacket>;
        static of(id: number, values: $PositionMoveRotation, relatives: $Relative_[]): $ClientboundPlayerPositionPacket;
        change(): $PositionMoveRotation;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        id(): number;
        relatives(): $Set<$Relative>;
        toString(): string;
        type(): $PacketType<$ClientboundPlayerPositionPacket>;
    }

    export class $ClientboundPlayerRotationPacket extends $Record implements $Packet {
        constructor(yRot: number, relativeY: boolean, xRot: number, relativeX: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPlayerRotationPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        relativeX(): boolean;
        relativeY(): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundPlayerRotationPacket>;
        xRot(): number;
        yRot(): number;
    }

    export class $ClientboundProjectilePowerPacket implements $Packet {
        constructor(id: number, accelerationPower: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundProjectilePowerPacket>;
        get accelerationPower(): number;
        getAccelerationPower(): number;
        get id(): number;
        getId(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundProjectilePowerPacket>;
    }

    export class $ClientboundRecipeBookAddPacket extends $Record implements $Packet {
        constructor(entries: $ClientboundRecipeBookAddPacket$Entry[], replace: boolean);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundRecipeBookAddPacket>;
        entries(): $List<$ClientboundRecipeBookAddPacket$Entry>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        replace(): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundRecipeBookAddPacket>;
    }

    export class $ClientboundRecipeBookAddPacket$Entry extends $Record {
        constructor(contents: $RecipeDisplayEntry, notification: boolean, highlight: boolean);
        constructor(contents: $RecipeDisplayEntry, flags: number);
        static FLAG_HIGHLIGHT: number;
        static FLAG_NOTIFICATION: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundRecipeBookAddPacket$Entry>;
        contents(): $RecipeDisplayEntry;
        equals(o: object): boolean;
        flags(): number;
        hashCode(): number;
        highlight(): boolean;
        notification(): boolean;
        toString(): string;
    }

    export class $ClientboundRecipeBookRemovePacket extends $Record implements $Packet {
        constructor(recipes: $RecipeDisplayId[]);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundRecipeBookRemovePacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        recipes(): $List<$RecipeDisplayId>;
        toString(): string;
        type(): $PacketType<$ClientboundRecipeBookRemovePacket>;
    }

    export class $ClientboundRecipeBookSettingsPacket extends $Record implements $Packet {
        constructor(bookSettings: $RecipeBookSettings);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundRecipeBookSettingsPacket>;
        bookSettings(): $RecipeBookSettings;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundRecipeBookSettingsPacket>;
    }

    export class $ClientboundRemoveEntitiesPacket implements $Packet {
        constructor(ids?: number[]);
        constructor(ids: $IntList);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundRemoveEntitiesPacket>;
        get entityIds(): $IntList;
        getEntityIds(): $IntList;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundRemoveEntitiesPacket>;
    }

    export class $ClientboundRemoveMobEffectPacket extends $Record implements $Packet {
        constructor(entityId: number, effect: $Holder<$MobEffect_>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundRemoveMobEffectPacket>;
        effect(): $Holder<$MobEffect>;
        entityId(): number;
        equals(o: object): boolean;
        getEntity(level: $Level): $Entity;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundRemoveMobEffectPacket>;
    }

    export class $ClientboundResetScorePacket extends $Record implements $Packet {
        constructor(owner: string, objectiveName: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundResetScorePacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        objectiveName(): string;
        owner(): string;
        toString(): string;
        type(): $PacketType<$ClientboundResetScorePacket>;
    }

    export class $ClientboundRespawnPacket extends $Record implements $Packet {
        constructor(commonPlayerSpawnInfo: $CommonPlayerSpawnInfo, dataToKeep: number);
        static KEEP_ALL_DATA: number;
        static KEEP_ATTRIBUTE_MODIFIERS: number;
        static KEEP_ENTITY_DATA: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundRespawnPacket>;
        commonPlayerSpawnInfo(): $CommonPlayerSpawnInfo;
        dataToKeep(): number;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        shouldKeep(mask: number): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundRespawnPacket>;
    }

    export class $ClientboundRotateHeadPacket implements $Packet {
        constructor(entity: $Entity, yHeadRot: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundRotateHeadPacket>;
        get yHeadRot(): number;
        getYHeadRot(): number;
        getEntity(level: $Level): $Entity;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundRotateHeadPacket>;
    }

    export class $ClientboundSectionBlocksUpdatePacket implements $Packet {
        constructor(sectionPos: $SectionPos, changes: $ShortSet, section: $LevelChunkSection);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSectionBlocksUpdatePacket>;
        handle(listener: $ClientGamePacketListener): void;
        runUpdates(updateFunction: $BiConsumer<$BlockPos_, $BlockState_>): void;
        type(): $PacketType<$ClientboundSectionBlocksUpdatePacket>;
    }

    export class $ClientboundSelectAdvancementsTabPacket implements $Packet {
        constructor(tab: $Identifier_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSelectAdvancementsTabPacket>;
        get tab(): $Identifier;
        getTab(): $Identifier;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSelectAdvancementsTabPacket>;
    }

    export class $ClientboundServerDataPacket extends $Record implements $Packet {
        constructor(motd: $Component_, iconBytes: $Optional<number[]>);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundServerDataPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        iconBytes(): $Optional<number[]>;
        motd(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundServerDataPacket>;
    }

    export class $ClientboundSetActionBarTextPacket extends $Record implements $Packet {
        constructor(text: $Component_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetActionBarTextPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        text(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundSetActionBarTextPacket>;
    }

    export class $ClientboundSetBorderCenterPacket implements $Packet {
        constructor(border: $WorldBorder);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetBorderCenterPacket>;
        get newCenterX(): number;
        getNewCenterX(): number;
        get newCenterZ(): number;
        getNewCenterZ(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetBorderCenterPacket>;
    }

    export class $ClientboundSetBorderLerpSizePacket implements $Packet {
        constructor(border: $WorldBorder);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetBorderLerpSizePacket>;
        get lerpTime(): number;
        getLerpTime(): number;
        get newSize(): number;
        getNewSize(): number;
        get oldSize(): number;
        getOldSize(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetBorderLerpSizePacket>;
    }

    export class $ClientboundSetBorderSizePacket implements $Packet {
        constructor(border: $WorldBorder);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetBorderSizePacket>;
        get size(): number;
        getSize(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetBorderSizePacket>;
    }

    export class $ClientboundSetBorderWarningDelayPacket implements $Packet {
        constructor(border: $WorldBorder);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetBorderWarningDelayPacket>;
        get warningDelay(): number;
        getWarningDelay(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetBorderWarningDelayPacket>;
    }

    export class $ClientboundSetBorderWarningDistancePacket implements $Packet {
        constructor(border: $WorldBorder);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetBorderWarningDistancePacket>;
        get warningBlocks(): number;
        getWarningBlocks(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetBorderWarningDistancePacket>;
    }

    export class $ClientboundSetCameraPacket implements $Packet {
        constructor(camera: $Entity);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetCameraPacket>;
        getEntity(level: $Level): $Entity;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetCameraPacket>;
    }

    export class $ClientboundSetChunkCacheCenterPacket implements $Packet {
        constructor(x: number, z: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetChunkCacheCenterPacket>;
        get x(): number;
        getX(): number;
        get z(): number;
        getZ(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetChunkCacheCenterPacket>;
    }

    export class $ClientboundSetChunkCacheRadiusPacket implements $Packet {
        constructor(radius: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetChunkCacheRadiusPacket>;
        get radius(): number;
        getRadius(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetChunkCacheRadiusPacket>;
    }

    export class $ClientboundSetCursorItemPacket extends $Record implements $Packet {
        constructor(contents: $ItemStack_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetCursorItemPacket>;
        contents(): $ItemStack;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundSetCursorItemPacket>;
    }

    export class $ClientboundSetDefaultSpawnPositionPacket extends $Record implements $Packet {
        constructor(respawnData: $LevelData$RespawnData);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetDefaultSpawnPositionPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        respawnData(): $LevelData$RespawnData;
        toString(): string;
        type(): $PacketType<$ClientboundSetDefaultSpawnPositionPacket>;
    }

    export class $ClientboundSetDisplayObjectivePacket implements $Packet {
        constructor(slot: $DisplaySlot_, objective: $Objective);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetDisplayObjectivePacket>;
        get objectiveName(): string;
        getObjectiveName(): string;
        get slot(): $DisplaySlot;
        getSlot(): $DisplaySlot;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetDisplayObjectivePacket>;
    }

    export class $ClientboundSetEntityDataPacket extends $Record implements $Packet {
        constructor(id: number, packedItems: $SynchedEntityData$DataValue<any>[]);
        static EOF_MARKER: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetEntityDataPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        id(): number;
        packedItems(): $List<$SynchedEntityData$DataValue<any>>;
        toString(): string;
        type(): $PacketType<$ClientboundSetEntityDataPacket>;
    }

    export class $ClientboundSetEntityLinkPacket implements $Packet {
        constructor(sourceEntity: $Entity, destEntity: $Entity);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetEntityLinkPacket>;
        get destId(): number;
        getDestId(): number;
        get sourceId(): number;
        getSourceId(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetEntityLinkPacket>;
    }

    export class $ClientboundSetEntityMotionPacket extends $Record implements $Packet {
        constructor(id: number, movement: $Vec3_);
        constructor(entity: $Entity);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundSetEntityMotionPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        id(): number;
        movement(): $Vec3;
        toString(): string;
        type(): $PacketType<$ClientboundSetEntityMotionPacket>;
    }

    export class $ClientboundSetEquipmentPacket implements $Packet {
        constructor(entity: number, slots: $Pair<$EquipmentSlot_, $ItemStack_>[]);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetEquipmentPacket>;
        get entity(): number;
        getEntity(): number;
        get slots(): $List<$Pair<$EquipmentSlot, $ItemStack>>;
        getSlots(): $List<$Pair<$EquipmentSlot, $ItemStack>>;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetEquipmentPacket>;
    }

    export class $ClientboundSetExperiencePacket implements $Packet {
        constructor(experienceProgress: number, totalExperience: number, experienceLevel: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetExperiencePacket>;
        get experienceLevel(): number;
        getExperienceLevel(): number;
        get experienceProgress(): number;
        getExperienceProgress(): number;
        get totalExperience(): number;
        getTotalExperience(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetExperiencePacket>;
    }

    export class $ClientboundSetHealthPacket implements $Packet {
        constructor(health: number, food: number, saturation: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetHealthPacket>;
        get food(): number;
        getFood(): number;
        get health(): number;
        getHealth(): number;
        get saturation(): number;
        getSaturation(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetHealthPacket>;
    }

    export class $ClientboundSetHeldSlotPacket extends $Record implements $Packet {
        constructor(slot: number);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundSetHeldSlotPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        slot(): number;
        toString(): string;
        type(): $PacketType<$ClientboundSetHeldSlotPacket>;
    }

    export class $ClientboundSetObjectivePacket implements $Packet {
        constructor(objective: $Objective, method: number);
        static METHOD_ADD: number;
        static METHOD_CHANGE: number;
        static METHOD_REMOVE: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetObjectivePacket>;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get method(): number;
        getMethod(): number;
        get numberFormat(): $Optional<$NumberFormat>;
        getNumberFormat(): $Optional<$NumberFormat>;
        get objectiveName(): string;
        getObjectiveName(): string;
        get renderType(): $ObjectiveCriteria$RenderType;
        getRenderType(): $ObjectiveCriteria$RenderType;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetObjectivePacket>;
    }

    export class $ClientboundSetPassengersPacket implements $Packet {
        constructor(vehicle: $Entity);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetPassengersPacket>;
        get passengers(): number[];
        getPassengers(): number[];
        get vehicle(): number;
        getVehicle(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetPassengersPacket>;
    }

    export class $ClientboundSetPlayerInventoryPacket extends $Record implements $Packet {
        constructor(slot: number, contents: $ItemStack_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetPlayerInventoryPacket>;
        contents(): $ItemStack;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        slot(): number;
        toString(): string;
        type(): $PacketType<$ClientboundSetPlayerInventoryPacket>;
    }

    export class $ClientboundSetPlayerTeamPacket implements $Packet {
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetPlayerTeamPacket>;
        get name(): string;
        getName(): string;
        get parameters(): $Optional<$ClientboundSetPlayerTeamPacket$Parameters>;
        getParameters(): $Optional<$ClientboundSetPlayerTeamPacket$Parameters>;
        get playerAction(): $ClientboundSetPlayerTeamPacket$Action;
        getPlayerAction(): $ClientboundSetPlayerTeamPacket$Action;
        get players(): $Collection<string>;
        getPlayers(): $Collection<string>;
        get teamAction(): $ClientboundSetPlayerTeamPacket$Action;
        getTeamAction(): $ClientboundSetPlayerTeamPacket$Action;
        static createAddOrModifyPacket(team: $PlayerTeam, createNew: boolean): $ClientboundSetPlayerTeamPacket;
        static createPlayerPacket(team: $PlayerTeam, player: string, action: $ClientboundSetPlayerTeamPacket$Action_): $ClientboundSetPlayerTeamPacket;
        static createRemovePacket(team: $PlayerTeam): $ClientboundSetPlayerTeamPacket;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetPlayerTeamPacket>;
    }

    export class $ClientboundSetPlayerTeamPacket$Action {
        static ADD: $ClientboundSetPlayerTeamPacket$Action;
        static REMOVE: $ClientboundSetPlayerTeamPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClientboundSetPlayerTeamPacket$Action[];
        static valueOf(name: string): $ClientboundSetPlayerTeamPacket$Action;
    }

    export class $ClientboundSetPlayerTeamPacket$Parameters {
        constructor(input: $RegistryFriendlyByteBuf);
        constructor(team: $PlayerTeam);
        get collisionRule(): $Team$CollisionRule;
        getCollisionRule(): $Team$CollisionRule;
        get color(): $ChatFormatting;
        getColor(): $ChatFormatting;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get nametagVisibility(): $Team$Visibility;
        getNametagVisibility(): $Team$Visibility;
        get options(): number;
        getOptions(): number;
        get playerPrefix(): $Component;
        getPlayerPrefix(): $Component;
        get playerSuffix(): $Component;
        getPlayerSuffix(): $Component;
        write(output: $RegistryFriendlyByteBuf): void;
    }

    export class $ClientboundSetScorePacket extends $Record implements $Packet {
        constructor(owner: string, objectiveName: string, score: number, display: $Optional<$Component_>, numberFormat: $Optional<$NumberFormat>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetScorePacket>;
        display(): $Optional<$Component>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        numberFormat(): $Optional<$NumberFormat>;
        objectiveName(): string;
        owner(): string;
        score(): number;
        toString(): string;
        type(): $PacketType<$ClientboundSetScorePacket>;
    }

    export class $ClientboundSetSimulationDistancePacket extends $Record implements $Packet {
        constructor(simulationDistance: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetSimulationDistancePacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        simulationDistance(): number;
        toString(): string;
        type(): $PacketType<$ClientboundSetSimulationDistancePacket>;
    }

    export class $ClientboundSetSubtitleTextPacket extends $Record implements $Packet {
        constructor(text: $Component_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetSubtitleTextPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        text(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundSetSubtitleTextPacket>;
    }

    export class $ClientboundSetTimePacket extends $Record implements $Packet {
        constructor(gameTime: number, clockUpdates: { [key: $Holder<$WorldClock>]: $ClockNetworkState });
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetTimePacket>;
        clockUpdates(): $Map<$Holder<$WorldClock>, $ClockNetworkState>;
        equals(o: object): boolean;
        gameTime(): number;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundSetTimePacket>;
    }

    export class $ClientboundSetTitleTextPacket extends $Record implements $Packet {
        constructor(text: $Component_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSetTitleTextPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        text(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundSetTitleTextPacket>;
    }

    export class $ClientboundSetTitlesAnimationPacket implements $Packet {
        constructor(fadeIn: number, stay: number, fadeOut: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundSetTitlesAnimationPacket>;
        get fadeIn(): number;
        getFadeIn(): number;
        get fadeOut(): number;
        getFadeOut(): number;
        get stay(): number;
        getStay(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSetTitlesAnimationPacket>;
    }

    export class $ClientboundSoundEntityPacket implements $Packet {
        constructor(sound: $Holder<$SoundEvent_>, source: $SoundSource_, sourceEntity: $Entity, volume: number, pitch: number, seed: number);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSoundEntityPacket>;
        get id(): number;
        getId(): number;
        get pitch(): number;
        getPitch(): number;
        get seed(): number;
        getSeed(): number;
        get sound(): $Holder<$SoundEvent>;
        getSound(): $Holder<$SoundEvent>;
        get source(): $SoundSource;
        getSource(): $SoundSource;
        get volume(): number;
        getVolume(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSoundEntityPacket>;
    }

    export class $ClientboundSoundPacket implements $Packet {
        constructor(sound: $Holder<$SoundEvent_>, source: $SoundSource_, x: number, y: number, z: number, volume: number, pitch: number, seed: number);
        static LOCATION_ACCURACY: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSoundPacket>;
        get pitch(): number;
        getPitch(): number;
        get seed(): number;
        getSeed(): number;
        get sound(): $Holder<$SoundEvent>;
        getSound(): $Holder<$SoundEvent>;
        get source(): $SoundSource;
        getSource(): $SoundSource;
        get volume(): number;
        getVolume(): number;
        get x(): number;
        getX(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundSoundPacket>;
    }

    export class $ClientboundStartConfigurationPacket implements $Packet {
        static INSTANCE: $ClientboundStartConfigurationPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundStartConfigurationPacket>;
        get terminal(): boolean;
        isTerminal(): boolean;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundStartConfigurationPacket>;
    }

    export class $ClientboundStopSoundPacket implements $Packet {
        constructor(name: $Identifier_, source: $SoundSource_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundStopSoundPacket>;
        get name(): $Identifier;
        getName(): $Identifier;
        get source(): $SoundSource;
        getSource(): $SoundSource;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundStopSoundPacket>;
    }

    export class $ClientboundSystemChatPacket extends $Record implements $Packet {
        constructor(content: $Component_, overlay: boolean);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundSystemChatPacket>;
        get skippable(): boolean;
        isSkippable(): boolean;
        content(): $Component;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        overlay(): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundSystemChatPacket>;
    }

    export class $ClientboundTabListPacket extends $Record implements $Packet {
        constructor(header: $Component_, footer: $Component_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundTabListPacket>;
        equals(o: object): boolean;
        footer(): $Component;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        header(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundTabListPacket>;
    }

    export class $ClientboundTagQueryPacket implements $Packet {
        constructor(transactionId: number, tag: $CompoundTag_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundTagQueryPacket>;
        get tag(): $CompoundTag;
        getTag(): $CompoundTag;
        get transactionId(): number;
        getTransactionId(): number;
        get skippable(): boolean;
        isSkippable(): boolean;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundTagQueryPacket>;
    }

    export class $ClientboundTakeItemEntityPacket implements $Packet {
        constructor(itemId: number, playerId: number, amount: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundTakeItemEntityPacket>;
        get amount(): number;
        getAmount(): number;
        get itemId(): number;
        getItemId(): number;
        get playerId(): number;
        getPlayerId(): number;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundTakeItemEntityPacket>;
    }

    export class $ClientboundTeleportEntityPacket extends $Record implements $Packet {
        constructor(id: number, change: $PositionMoveRotation, relatives: $Relative_[], onGround: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundTeleportEntityPacket>;
        static teleport(id: number, values: $PositionMoveRotation, relatives: $Relative_[], onGround: boolean): $ClientboundTeleportEntityPacket;
        change(): $PositionMoveRotation;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        id(): number;
        onGround(): boolean;
        relatives(): $Set<$Relative>;
        toString(): string;
        type(): $PacketType<$ClientboundTeleportEntityPacket>;
    }

    export class $ClientboundTestInstanceBlockStatus extends $Record implements $Packet {
        constructor(status: $Component_, size: $Optional<$Vec3i>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundTestInstanceBlockStatus>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        size(): $Optional<$Vec3i>;
        status(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundTestInstanceBlockStatus>;
    }

    export class $ClientboundTickingStatePacket extends $Record implements $Packet {
        constructor(tickRate: number, isFrozen: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundTickingStatePacket>;
        get frozen(): boolean;
        isFrozen(): boolean;
        static from(manager: $TickRateManager): $ClientboundTickingStatePacket;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        tickRate(): number;
        toString(): string;
        type(): $PacketType<$ClientboundTickingStatePacket>;
    }

    export class $ClientboundTickingStepPacket extends $Record implements $Packet {
        constructor(tickSteps: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundTickingStepPacket>;
        static from(manager: $TickRateManager): $ClientboundTickingStepPacket;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        tickSteps(): number;
        toString(): string;
        type(): $PacketType<$ClientboundTickingStepPacket>;
    }

    export class $ClientboundTrackedWaypointPacket extends $Record implements $Packet {
        constructor(operation: $ClientboundTrackedWaypointPacket$Operation_, waypoint: $TrackedWaypoint);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundTrackedWaypointPacket>;
        static addWaypointAzimuth(identifier: string, icon: $Waypoint$Icon, angle: number): $ClientboundTrackedWaypointPacket;
        static addWaypointChunk(identifier: string, icon: $Waypoint$Icon, chunk: $ChunkPos): $ClientboundTrackedWaypointPacket;
        static addWaypointPosition(identifier: string, icon: $Waypoint$Icon, position: $Vec3i): $ClientboundTrackedWaypointPacket;
        static removeWaypoint(identifier: string): $ClientboundTrackedWaypointPacket;
        static updateWaypointAzimuth(identifier: string, icon: $Waypoint$Icon, angle: number): $ClientboundTrackedWaypointPacket;
        static updateWaypointChunk(identifier: string, icon: $Waypoint$Icon, chunk: $ChunkPos): $ClientboundTrackedWaypointPacket;
        static updateWaypointPosition(identifier: string, icon: $Waypoint$Icon, position: $Vec3i): $ClientboundTrackedWaypointPacket;
        apply(manager: $TrackedWaypointManager): void;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        operation(): $ClientboundTrackedWaypointPacket$Operation;
        toString(): string;
        type(): $PacketType<$ClientboundTrackedWaypointPacket>;
        waypoint(): $TrackedWaypoint;
    }

    export class $ClientboundTrackedWaypointPacket$Operation {
        static TRACK: $ClientboundTrackedWaypointPacket$Operation;
        static UNTRACK: $ClientboundTrackedWaypointPacket$Operation;
        static UPDATE: $ClientboundTrackedWaypointPacket$Operation;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClientboundTrackedWaypointPacket$Operation[];
        static valueOf(name: string): $ClientboundTrackedWaypointPacket$Operation;
    }

    export class $ClientboundUpdateAdvancementsPacket implements $Packet {
        constructor(reset: boolean, newAdvancements: $AdvancementHolder[], removedAdvancements: $Identifier_[], progress: { [key: $Identifier_]: $AdvancementProgress }, showAdvancements: boolean);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundUpdateAdvancementsPacket>;
        get added(): $List<$AdvancementHolder>;
        getAdded(): $List<$AdvancementHolder>;
        get progress(): $Map<$Identifier, $AdvancementProgress>;
        getProgress(): $Map<$Identifier, $AdvancementProgress>;
        get removed(): $Set<$Identifier>;
        getRemoved(): $Set<$Identifier>;
        handle(listener: $ClientGamePacketListener): void;
        shouldReset(): boolean;
        shouldShowAdvancements(): boolean;
        type(): $PacketType<$ClientboundUpdateAdvancementsPacket>;
    }

    export class $ClientboundUpdateAttributesPacket implements $Packet {
        constructor(entityId: number, values: $AttributeInstance[]);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundUpdateAttributesPacket>;
        get entityId(): number;
        getEntityId(): number;
        get values(): $List<$ClientboundUpdateAttributesPacket$AttributeSnapshot>;
        getValues(): $List<$ClientboundUpdateAttributesPacket$AttributeSnapshot>;
        handle(listener: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundUpdateAttributesPacket>;
    }

    export class $ClientboundUpdateAttributesPacket$AttributeSnapshot extends $Record {
        constructor(attribute: $Holder<$Attribute_>, base: number, modifiers: $AttributeModifier[]);
        static MODIFIER_STREAM_CODEC: $StreamCodec<$ByteBuf, $AttributeModifier>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundUpdateAttributesPacket$AttributeSnapshot>;
        attribute(): $Holder<$Attribute>;
        base(): number;
        equals(o: object): boolean;
        hashCode(): number;
        modifiers(): $Collection<$AttributeModifier>;
        toString(): string;
    }

    export class $ClientboundUpdateMobEffectPacket implements $Packet {
        constructor(entityId: number, effect: $MobEffectInstance, blend: boolean);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundUpdateMobEffectPacket>;
        get effectAmplifier(): number;
        getEffectAmplifier(): number;
        get effectDurationTicks(): number;
        getEffectDurationTicks(): number;
        get effect(): $Holder<$MobEffect>;
        getEffect(): $Holder<$MobEffect>;
        get entityId(): number;
        getEntityId(): number;
        get effectAmbient(): boolean;
        isEffectAmbient(): boolean;
        get effectVisible(): boolean;
        isEffectVisible(): boolean;
        effectShowsIcon(): boolean;
        handle(listener: $ClientGamePacketListener): void;
        shouldBlend(): boolean;
        type(): $PacketType<$ClientboundUpdateMobEffectPacket>;
    }

    export class $ClientboundUpdateRecipesPacket extends $Record implements $Packet {
        constructor(itemSets: { [key: $ResourceKey<$RecipePropertySet>]: $RecipePropertySet }, stonecutterRecipes: $SelectableRecipe$SingleInputSet<$StonecutterRecipe>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundUpdateRecipesPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientGamePacketListener): void;
        hashCode(): number;
        itemSets(): $Map<$ResourceKey<$RecipePropertySet>, $RecipePropertySet>;
        stonecutterRecipes(): $SelectableRecipe$SingleInputSet<$StonecutterRecipe>;
        toString(): string;
        type(): $PacketType<$ClientboundUpdateRecipesPacket>;
    }

    export class $CommonPlayerSpawnInfo extends $Record {
        constructor(dimensionType: $Holder<$DimensionType>, dimension: $ResourceKey<$Level>, seed: number, gameType: $GameType_, previousGameType: $GameType_, isDebug: boolean, isFlat: boolean, lastDeathLocation: $Optional<$GlobalPos>, portalCooldown: number, seaLevel: number);
        constructor(input: $RegistryFriendlyByteBuf);
        get debug(): boolean;
        isDebug(): boolean;
        get flat(): boolean;
        isFlat(): boolean;
        dimensionType(): $Holder<$DimensionType>;
        dimension(): $ResourceKey<$Level>;
        equals(o: object): boolean;
        gameType(): $GameType;
        hashCode(): number;
        lastDeathLocation(): $Optional<$GlobalPos>;
        portalCooldown(): number;
        previousGameType(): $GameType;
        seaLevel(): number;
        seed(): number;
        toString(): string;
        write(output: $RegistryFriendlyByteBuf): void;
    }

    export interface $GameProtocols$Context {
        hasInfiniteMaterials(): boolean;
    }

    export interface $ServerGamePacketListener extends $ServerCommonPacketListener, $ServerPingPacketListener {
        handleAcceptPlayerLoad(packet: $ServerboundPlayerLoadedPacket): void;
        handleAcceptTeleportPacket(packet: $ServerboundAcceptTeleportationPacket): void;
        handleAnimate(packet: $ServerboundSwingPacket): void;
        handleAttack(packet: $ServerboundAttackPacket): void;
        handleBlockEntityTagQuery(packet: $ServerboundBlockEntityTagQueryPacket): void;
        handleBundleItemSelectedPacket(packet: $ServerboundSelectBundleItemPacket): void;
        handleChangeDifficulty(packet: $ServerboundChangeDifficultyPacket): void;
        handleChangeGameMode(packet: $ServerboundChangeGameModePacket): void;
        handleChatAck(packet: $ServerboundChatAckPacket): void;
        handleChatCommand(packet: $ServerboundChatCommandPacket): void;
        handleChatSessionUpdate(packet: $ServerboundChatSessionUpdatePacket): void;
        handleChat(packet: $ServerboundChatPacket): void;
        handleChunkBatchReceived(packet: $ServerboundChunkBatchReceivedPacket): void;
        handleClientCommand(packet: $ServerboundClientCommandPacket): void;
        handleClientTickEnd(packet: $ServerboundClientTickEndPacket): void;
        handleConfigurationAcknowledged(packet: $ServerboundConfigurationAcknowledgedPacket): void;
        handleContainerButtonClick(packet: $ServerboundContainerButtonClickPacket): void;
        handleContainerClick(packet: $ServerboundContainerClickPacket): void;
        handleContainerClose(packet: $ServerboundContainerClosePacket): void;
        handleContainerSlotStateChanged(packet: $ServerboundContainerSlotStateChangedPacket): void;
        handleCustomCommandSuggestions(packet: $ServerboundCommandSuggestionPacket): void;
        handleDebugSubscriptionRequest(packet: $ServerboundDebugSubscriptionRequestPacket): void;
        handleEditBook(packet: $ServerboundEditBookPacket): void;
        handleEntityTagQuery(packet: $ServerboundEntityTagQueryPacket): void;
        handleInteract(packet: $ServerboundInteractPacket): void;
        handleJigsawGenerate(packet: $ServerboundJigsawGeneratePacket): void;
        handleLockDifficulty(packet: $ServerboundLockDifficultyPacket): void;
        handleMovePlayer(packet: $ServerboundMovePlayerPacket): void;
        handleMoveVehicle(packet: $ServerboundMoveVehiclePacket): void;
        handlePaddleBoat(packet: $ServerboundPaddleBoatPacket): void;
        handlePickItemFromBlock(packet: $ServerboundPickItemFromBlockPacket): void;
        handlePickItemFromEntity(packet: $ServerboundPickItemFromEntityPacket): void;
        handlePlaceRecipe(packet: $ServerboundPlaceRecipePacket): void;
        handlePlayerAbilities(packet: $ServerboundPlayerAbilitiesPacket): void;
        handlePlayerAction(packet: $ServerboundPlayerActionPacket): void;
        handlePlayerCommand(packet: $ServerboundPlayerCommandPacket): void;
        handlePlayerInput(packet: $ServerboundPlayerInputPacket): void;
        handleRecipeBookChangeSettingsPacket(packet: $ServerboundRecipeBookChangeSettingsPacket): void;
        handleRecipeBookSeenRecipePacket(packet: $ServerboundRecipeBookSeenRecipePacket): void;
        handleRenameItem(packet: $ServerboundRenameItemPacket): void;
        handleSeenAdvancements(packet: $ServerboundSeenAdvancementsPacket): void;
        handleSelectTrade(packet: $ServerboundSelectTradePacket): void;
        handleSetBeaconPacket(packet: $ServerboundSetBeaconPacket): void;
        handleSetCarriedItem(packet: $ServerboundSetCarriedItemPacket): void;
        handleSetCommandBlock(packet: $ServerboundSetCommandBlockPacket): void;
        handleSetCommandMinecart(packet: $ServerboundSetCommandMinecartPacket): void;
        handleSetCreativeModeSlot(packet: $ServerboundSetCreativeModeSlotPacket): void;
        handleSetGameRule(packet: $ServerboundSetGameRulePacket): void;
        handleSetJigsawBlock(packet: $ServerboundSetJigsawBlockPacket): void;
        handleSetStructureBlock(packet: $ServerboundSetStructureBlockPacket): void;
        handleSetTestBlock(packet: $ServerboundSetTestBlockPacket): void;
        handleSignUpdate(packet: $ServerboundSignUpdatePacket): void;
        handleSignedChatCommand(packet: $ServerboundChatCommandSignedPacket): void;
        handleSpectateEntity(packet: $ServerboundSpectateEntityPacket): void;
        handleTeleportToEntityPacket(packet: $ServerboundTeleportToEntityPacket): void;
        handleTestInstanceBlockAction(packet: $ServerboundTestInstanceBlockActionPacket): void;
        handleUseItemOn(packet: $ServerboundUseItemOnPacket): void;
        handleUseItem(packet: $ServerboundUseItemPacket): void;
        protocol(): $ConnectionProtocol;
    }

    export class $ServerboundAcceptTeleportationPacket implements $Packet {
        constructor(id: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundAcceptTeleportationPacket>;
        get id(): number;
        getId(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundAcceptTeleportationPacket>;
    }

    export class $ServerboundAttackPacket extends $Record implements $Packet {
        constructor(entityId: number);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundAttackPacket>;
        entityId(): number;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundAttackPacket>;
    }

    export class $ServerboundBlockEntityTagQueryPacket implements $Packet {
        constructor(transactionId: number, pos: $BlockPos_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundBlockEntityTagQueryPacket>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get transactionId(): number;
        getTransactionId(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundBlockEntityTagQueryPacket>;
    }

    export class $ServerboundChangeDifficultyPacket extends $Record implements $Packet {
        constructor(difficulty: $Difficulty_);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundChangeDifficultyPacket>;
        difficulty(): $Difficulty;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChangeDifficultyPacket>;
    }

    export class $ServerboundChangeGameModePacket extends $Record implements $Packet {
        constructor(mode: $GameType_);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundChangeGameModePacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        mode(): $GameType;
        toString(): string;
        type(): $PacketType<$ServerboundChangeGameModePacket>;
    }

    export class $ServerboundChatAckPacket extends $Record implements $Packet {
        constructor(offset: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatAckPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        offset(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChatAckPacket>;
    }

    export class $ServerboundChatCommandPacket extends $Record implements $Packet {
        constructor(command: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatCommandPacket>;
        command(): string;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChatCommandPacket>;
    }

    export class $ServerboundChatCommandSignedPacket extends $Record implements $Packet {
        constructor(command: string, timeStamp: $Instant, salt: number, argumentSignatures: $ArgumentSignatures, lastSeenMessages: $LastSeenMessages$Update);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatCommandSignedPacket>;
        argumentSignatures(): $ArgumentSignatures;
        command(): string;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        lastSeenMessages(): $LastSeenMessages$Update;
        salt(): number;
        timeStamp(): $Instant;
        toString(): string;
        type(): $PacketType<$ServerboundChatCommandSignedPacket>;
    }

    export class $ServerboundChatPacket extends $Record implements $Packet {
        constructor(message: string, timeStamp: $Instant, salt: number, signature: $MessageSignature, lastSeenMessages: $LastSeenMessages$Update);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        lastSeenMessages(): $LastSeenMessages$Update;
        message(): string;
        salt(): number;
        signature(): $MessageSignature;
        timeStamp(): $Instant;
        toString(): string;
        type(): $PacketType<$ServerboundChatPacket>;
    }

    export class $ServerboundChatSessionUpdatePacket extends $Record implements $Packet {
        constructor(chatSession: $RemoteChatSession$Data);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatSessionUpdatePacket>;
        chatSession(): $RemoteChatSession$Data;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChatSessionUpdatePacket>;
    }

    export class $ServerboundChunkBatchReceivedPacket extends $Record implements $Packet {
        constructor(desiredChunksPerTick: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChunkBatchReceivedPacket>;
        desiredChunksPerTick(): number;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChunkBatchReceivedPacket>;
    }

    export class $ServerboundClientCommandPacket implements $Packet {
        constructor(action: $ServerboundClientCommandPacket$Action_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundClientCommandPacket>;
        get action(): $ServerboundClientCommandPacket$Action;
        getAction(): $ServerboundClientCommandPacket$Action;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundClientCommandPacket>;
    }

    export class $ServerboundClientCommandPacket$Action {
        static PERFORM_RESPAWN: $ServerboundClientCommandPacket$Action;
        static REQUEST_GAMERULE_VALUES: $ServerboundClientCommandPacket$Action;
        static REQUEST_STATS: $ServerboundClientCommandPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundClientCommandPacket$Action[];
        static valueOf(name: string): $ServerboundClientCommandPacket$Action;
    }

    export class $ServerboundClientTickEndPacket extends $Record implements $Packet {
        constructor();
        static INSTANCE: $ServerboundClientTickEndPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundClientTickEndPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundClientTickEndPacket>;
    }

    export class $ServerboundCommandSuggestionPacket implements $Packet {
        constructor(id: number, command: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCommandSuggestionPacket>;
        get command(): string;
        getCommand(): string;
        get id(): number;
        getId(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundCommandSuggestionPacket>;
    }

    export class $ServerboundConfigurationAcknowledgedPacket implements $Packet {
        static INSTANCE: $ServerboundConfigurationAcknowledgedPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundConfigurationAcknowledgedPacket>;
        get terminal(): boolean;
        isTerminal(): boolean;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundConfigurationAcknowledgedPacket>;
    }

    export class $ServerboundContainerButtonClickPacket extends $Record implements $Packet {
        constructor(containerId: number, buttonId: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundContainerButtonClickPacket>;
        buttonId(): number;
        containerId(): number;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundContainerButtonClickPacket>;
    }

    export class $ServerboundContainerClickPacket extends $Record implements $Packet {
        constructor(containerId: number, stateId: number, slotNum: number, buttonNum: number, containerInput: $ContainerInput_, changedSlots: $Int2ObjectMap<$HashedStack>, carriedItem: $HashedStack);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ServerboundContainerClickPacket>;
        buttonNum(): number;
        carriedItem(): $HashedStack;
        changedSlots(): $Int2ObjectMap<$HashedStack>;
        containerId(): number;
        containerInput(): $ContainerInput;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        slotNum(): number;
        stateId(): number;
        toString(): string;
        type(): $PacketType<$ServerboundContainerClickPacket>;
    }

    export class $ServerboundContainerClosePacket implements $Packet {
        constructor(containerId: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundContainerClosePacket>;
        get containerId(): number;
        getContainerId(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundContainerClosePacket>;
    }

    export class $ServerboundContainerSlotStateChangedPacket extends $Record implements $Packet {
        constructor(slotId: number, containerId: number, newState: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundContainerSlotStateChangedPacket>;
        containerId(): number;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        newState(): boolean;
        slotId(): number;
        toString(): string;
        type(): $PacketType<$ServerboundContainerSlotStateChangedPacket>;
    }

    export class $ServerboundDebugSubscriptionRequestPacket extends $Record implements $Packet {
        constructor(subscriptions: $DebugSubscription<any>[]);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ServerboundDebugSubscriptionRequestPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        subscriptions(): $Set<$DebugSubscription<any>>;
        toString(): string;
        type(): $PacketType<$ServerboundDebugSubscriptionRequestPacket>;
    }

    export class $ServerboundEditBookPacket extends $Record implements $Packet {
        constructor(slot: number, pages: string[], title: $Optional<string>);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundEditBookPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        pages(): $List<string>;
        slot(): number;
        title(): $Optional<string>;
        toString(): string;
        type(): $PacketType<$ServerboundEditBookPacket>;
    }

    export class $ServerboundEntityTagQueryPacket implements $Packet {
        constructor(transactionId: number, entityId: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundEntityTagQueryPacket>;
        get entityId(): number;
        getEntityId(): number;
        get transactionId(): number;
        getTransactionId(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundEntityTagQueryPacket>;
    }

    export class $ServerboundInteractPacket extends $Record implements $Packet {
        constructor(entityId: number, hand: $InteractionHand_, location: $Vec3_, usingSecondaryAction: boolean);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundInteractPacket>;
        entityId(): number;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hand(): $InteractionHand;
        hashCode(): number;
        location(): $Vec3;
        toString(): string;
        type(): $PacketType<$ServerboundInteractPacket>;
        usingSecondaryAction(): boolean;
    }

    export class $ServerboundJigsawGeneratePacket implements $Packet {
        constructor(blockPos: $BlockPos_, levels: number, keepJigsaws: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundJigsawGeneratePacket>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        handle(listener: $ServerGamePacketListener): void;
        keepJigsaws(): boolean;
        levels(): number;
        type(): $PacketType<$ServerboundJigsawGeneratePacket>;
    }

    export class $ServerboundLockDifficultyPacket implements $Packet {
        constructor(locked: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundLockDifficultyPacket>;
        get locked(): boolean;
        isLocked(): boolean;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundLockDifficultyPacket>;
    }

    export class $ServerboundMovePlayerPacket implements $Packet {
        get onGround(): boolean;
        isOnGround(): boolean;
        getXRot(fallback: number): number;
        getX(fallback: number): number;
        getYRot(fallback: number): number;
        getY(fallback: number): number;
        getZ(fallback: number): number;
        handle(listener: $ServerGamePacketListener): void;
        hasPosition(): boolean;
        hasRotation(): boolean;
        horizontalCollision(): boolean;
        type(): $PacketType<$ServerboundMovePlayerPacket>;
    }

    export class $ServerboundMoveVehiclePacket extends $Record implements $Packet {
        constructor(position: $Vec3_, yRot: number, xRot: number, onGround: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundMoveVehiclePacket>;
        static fromEntity(entity: $Entity): $ServerboundMoveVehiclePacket;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        onGround(): boolean;
        position(): $Vec3;
        toString(): string;
        type(): $PacketType<$ServerboundMoveVehiclePacket>;
        xRot(): number;
        yRot(): number;
    }

    export class $ServerboundPaddleBoatPacket implements $Packet {
        constructor(left: boolean, right: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPaddleBoatPacket>;
        get left(): boolean;
        getLeft(): boolean;
        get right(): boolean;
        getRight(): boolean;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPaddleBoatPacket>;
    }

    export class $ServerboundPickItemFromBlockPacket extends $Record implements $Packet {
        constructor(pos: $BlockPos_, includeData: boolean);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundPickItemFromBlockPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        includeData(): boolean;
        pos(): $BlockPos;
        toString(): string;
        type(): $PacketType<$ServerboundPickItemFromBlockPacket>;
    }

    export class $ServerboundPickItemFromEntityPacket extends $Record implements $Packet {
        constructor(id: number, includeData: boolean);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundPickItemFromEntityPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        id(): number;
        includeData(): boolean;
        toString(): string;
        type(): $PacketType<$ServerboundPickItemFromEntityPacket>;
    }

    export class $ServerboundPlaceRecipePacket extends $Record implements $Packet {
        constructor(containerId: number, recipe: $RecipeDisplayId, useMaxItems: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlaceRecipePacket>;
        containerId(): number;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        recipe(): $RecipeDisplayId;
        toString(): string;
        type(): $PacketType<$ServerboundPlaceRecipePacket>;
        useMaxItems(): boolean;
    }

    export class $ServerboundPlayerAbilitiesPacket implements $Packet {
        constructor(abilities: $Abilities);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlayerAbilitiesPacket>;
        get flying(): boolean;
        isFlying(): boolean;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPlayerAbilitiesPacket>;
    }

    export class $ServerboundPlayerActionPacket implements $Packet {
        constructor(action: $ServerboundPlayerActionPacket$Action_, pos: $BlockPos_, direction: $Direction_);
        constructor(action: $ServerboundPlayerActionPacket$Action_, pos: $BlockPos_, direction: $Direction_, sequence: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlayerActionPacket>;
        get action(): $ServerboundPlayerActionPacket$Action;
        getAction(): $ServerboundPlayerActionPacket$Action;
        get direction(): $Direction;
        getDirection(): $Direction;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get sequence(): number;
        getSequence(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPlayerActionPacket>;
    }

    export class $ServerboundPlayerActionPacket$Action {
        static ABORT_DESTROY_BLOCK: $ServerboundPlayerActionPacket$Action;
        static DROP_ALL_ITEMS: $ServerboundPlayerActionPacket$Action;
        static DROP_ITEM: $ServerboundPlayerActionPacket$Action;
        static RELEASE_USE_ITEM: $ServerboundPlayerActionPacket$Action;
        static STAB: $ServerboundPlayerActionPacket$Action;
        static START_DESTROY_BLOCK: $ServerboundPlayerActionPacket$Action;
        static STOP_DESTROY_BLOCK: $ServerboundPlayerActionPacket$Action;
        static SWAP_ITEM_WITH_OFFHAND: $ServerboundPlayerActionPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundPlayerActionPacket$Action[];
        static valueOf(name: string): $ServerboundPlayerActionPacket$Action;
    }

    export class $ServerboundPlayerCommandPacket implements $Packet {
        constructor(entity: $Entity, action: $ServerboundPlayerCommandPacket$Action_);
        constructor(entity: $Entity, action: $ServerboundPlayerCommandPacket$Action_, data: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlayerCommandPacket>;
        get action(): $ServerboundPlayerCommandPacket$Action;
        getAction(): $ServerboundPlayerCommandPacket$Action;
        get data(): number;
        getData(): number;
        get id(): number;
        getId(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPlayerCommandPacket>;
    }

    export class $ServerboundPlayerCommandPacket$Action {
        static OPEN_INVENTORY: $ServerboundPlayerCommandPacket$Action;
        static START_FALL_FLYING: $ServerboundPlayerCommandPacket$Action;
        static START_RIDING_JUMP: $ServerboundPlayerCommandPacket$Action;
        static START_SPRINTING: $ServerboundPlayerCommandPacket$Action;
        static STOP_RIDING_JUMP: $ServerboundPlayerCommandPacket$Action;
        static STOP_SLEEPING: $ServerboundPlayerCommandPacket$Action;
        static STOP_SPRINTING: $ServerboundPlayerCommandPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundPlayerCommandPacket$Action[];
        static valueOf(name: string): $ServerboundPlayerCommandPacket$Action;
    }

    export class $ServerboundPlayerInputPacket extends $Record implements $Packet {
        constructor(input: $Input);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlayerInputPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        input(): $Input;
        toString(): string;
        type(): $PacketType<$ServerboundPlayerInputPacket>;
    }

    export class $ServerboundPlayerLoadedPacket extends $Record implements $Packet {
        constructor();
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundPlayerLoadedPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundPlayerLoadedPacket>;
    }

    export class $ServerboundRecipeBookChangeSettingsPacket implements $Packet {
        constructor(bookType: $RecipeBookType_, isOpen: boolean, isFiltering: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundRecipeBookChangeSettingsPacket>;
        get bookType(): $RecipeBookType;
        getBookType(): $RecipeBookType;
        get filtering(): boolean;
        isFiltering(): boolean;
        get open(): boolean;
        isOpen(): boolean;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundRecipeBookChangeSettingsPacket>;
    }

    export class $ServerboundRecipeBookSeenRecipePacket extends $Record implements $Packet {
        constructor(recipe: $RecipeDisplayId);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundRecipeBookSeenRecipePacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        recipe(): $RecipeDisplayId;
        toString(): string;
        type(): $PacketType<$ServerboundRecipeBookSeenRecipePacket>;
    }

    export class $ServerboundRenameItemPacket implements $Packet {
        constructor(name: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundRenameItemPacket>;
        get name(): string;
        getName(): string;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundRenameItemPacket>;
    }

    export class $ServerboundSeenAdvancementsPacket implements $Packet {
        constructor(action: $ServerboundSeenAdvancementsPacket$Action_, tab: $Identifier_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSeenAdvancementsPacket>;
        get action(): $ServerboundSeenAdvancementsPacket$Action;
        getAction(): $ServerboundSeenAdvancementsPacket$Action;
        get tab(): $Identifier;
        getTab(): $Identifier;
        static closedScreen(): $ServerboundSeenAdvancementsPacket;
        static openedTab(tab: $AdvancementHolder): $ServerboundSeenAdvancementsPacket;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSeenAdvancementsPacket>;
    }

    export class $ServerboundSeenAdvancementsPacket$Action {
        static CLOSED_SCREEN: $ServerboundSeenAdvancementsPacket$Action;
        static OPENED_TAB: $ServerboundSeenAdvancementsPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundSeenAdvancementsPacket$Action[];
        static valueOf(name: string): $ServerboundSeenAdvancementsPacket$Action;
    }

    export class $ServerboundSelectBundleItemPacket extends $Record implements $Packet {
        constructor(slotId: number, selectedItemIndex: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSelectBundleItemPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        selectedItemIndex(): number;
        slotId(): number;
        toString(): string;
        type(): $PacketType<$ServerboundSelectBundleItemPacket>;
    }

    export class $ServerboundSelectTradePacket implements $Packet {
        constructor(item: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSelectTradePacket>;
        get item(): number;
        getItem(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSelectTradePacket>;
    }

    export class $ServerboundSetBeaconPacket extends $Record implements $Packet {
        constructor(primary: $Optional<$Holder<$MobEffect_>>, secondary: $Optional<$Holder<$MobEffect_>>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ServerboundSetBeaconPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        primary(): $Optional<$Holder<$MobEffect>>;
        secondary(): $Optional<$Holder<$MobEffect>>;
        toString(): string;
        type(): $PacketType<$ServerboundSetBeaconPacket>;
    }

    export class $ServerboundSetCarriedItemPacket implements $Packet {
        constructor(slot: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetCarriedItemPacket>;
        get slot(): number;
        getSlot(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetCarriedItemPacket>;
    }

    export class $ServerboundSetCommandBlockPacket implements $Packet {
        constructor(pos: $BlockPos_, command: string, mode: $CommandBlockEntity$Mode_, trackOutput: boolean, conditional: boolean, automatic: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetCommandBlockPacket>;
        get command(): string;
        getCommand(): string;
        get mode(): $CommandBlockEntity$Mode;
        getMode(): $CommandBlockEntity$Mode;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get automatic(): boolean;
        isAutomatic(): boolean;
        get conditional(): boolean;
        isConditional(): boolean;
        get trackOutput(): boolean;
        isTrackOutput(): boolean;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetCommandBlockPacket>;
    }

    export class $ServerboundSetCommandMinecartPacket implements $Packet {
        constructor(entity: number, command: string, trackOutput: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetCommandMinecartPacket>;
        get command(): string;
        getCommand(): string;
        get trackOutput(): boolean;
        isTrackOutput(): boolean;
        getCommandBlock(level: $Level): $BaseCommandBlock;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetCommandMinecartPacket>;
    }

    export class $ServerboundSetCreativeModeSlotPacket extends $Record implements $Packet {
        constructor(slotNum: number, itemStack: $ItemStack_);
        constructor(slotNum: number, itemStack: $ItemStack_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ServerboundSetCreativeModeSlotPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        itemStack(): $ItemStack;
        slotNum(): number;
        toString(): string;
        type(): $PacketType<$ServerboundSetCreativeModeSlotPacket>;
    }

    export class $ServerboundSetGameRulePacket extends $Record implements $Packet {
        constructor(entries: $ServerboundSetGameRulePacket$Entry[]);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundSetGameRulePacket>;
        entries(): $List<$ServerboundSetGameRulePacket$Entry>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundSetGameRulePacket>;
    }

    export class $ServerboundSetGameRulePacket$Entry extends $Record {
        constructor(gameRuleKey: $ResourceKey<$GameRule<any>>, value: string);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundSetGameRulePacket$Entry>;
        equals(o: object): boolean;
        gameRuleKey(): $ResourceKey<$GameRule<any>>;
        hashCode(): number;
        toString(): string;
        value(): string;
    }

    export class $ServerboundSetJigsawBlockPacket implements $Packet {
        constructor(blockPos: $BlockPos_, name: $Identifier_, target: $Identifier_, pool: $Identifier_, finalState: string, joint: $JigsawBlockEntity$JointType_, selectionPriority: number, placementPriority: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetJigsawBlockPacket>;
        get finalState(): string;
        getFinalState(): string;
        get joint(): $JigsawBlockEntity$JointType;
        getJoint(): $JigsawBlockEntity$JointType;
        get name(): $Identifier;
        getName(): $Identifier;
        get placementPriority(): number;
        getPlacementPriority(): number;
        get pool(): $Identifier;
        getPool(): $Identifier;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get selectionPriority(): number;
        getSelectionPriority(): number;
        get target(): $Identifier;
        getTarget(): $Identifier;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetJigsawBlockPacket>;
    }

    export class $ServerboundSetStructureBlockPacket implements $Packet {
        constructor(pos: $BlockPos_, updateType: $StructureBlockEntity$UpdateType_, mode: $StructureMode_, name: string, offset: $BlockPos_, size: $Vec3i, mirror: $Mirror_, rotation: $Rotation_, data: string, ignoreEntities: boolean, strict: boolean, showAir: boolean, showBoundingBox: boolean, integrity: number, seed: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetStructureBlockPacket>;
        get data(): string;
        getData(): string;
        get integrity(): number;
        getIntegrity(): number;
        get mirror(): $Mirror;
        getMirror(): $Mirror;
        get mode(): $StructureMode;
        getMode(): $StructureMode;
        get name(): string;
        getName(): string;
        get offset(): $BlockPos;
        getOffset(): $BlockPos;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get rotation(): $Rotation;
        getRotation(): $Rotation;
        get seed(): number;
        getSeed(): number;
        get size(): $Vec3i;
        getSize(): $Vec3i;
        get updateType(): $StructureBlockEntity$UpdateType;
        getUpdateType(): $StructureBlockEntity$UpdateType;
        get ignoreEntities(): boolean;
        isIgnoreEntities(): boolean;
        get showAir(): boolean;
        isShowAir(): boolean;
        get showBoundingBox(): boolean;
        isShowBoundingBox(): boolean;
        get strict(): boolean;
        isStrict(): boolean;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetStructureBlockPacket>;
    }

    export class $ServerboundSetTestBlockPacket extends $Record implements $Packet {
        constructor(position: $BlockPos_, mode: $TestBlockMode_, message: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetTestBlockPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        message(): string;
        mode(): $TestBlockMode;
        position(): $BlockPos;
        toString(): string;
        type(): $PacketType<$ServerboundSetTestBlockPacket>;
    }

    export class $ServerboundSignUpdatePacket implements $Packet {
        constructor(pos: $BlockPos_, isFrontText: boolean, line0: string, line1: string, line2: string, line3: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSignUpdatePacket>;
        get lines(): string[];
        getLines(): string[];
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get frontText(): boolean;
        isFrontText(): boolean;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSignUpdatePacket>;
    }

    export class $ServerboundSpectateEntityPacket extends $Record implements $Packet {
        constructor(entityId: number);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundSpectateEntityPacket>;
        entityId(): number;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundSpectateEntityPacket>;
    }

    export class $ServerboundSwingPacket implements $Packet {
        constructor(hand: $InteractionHand_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSwingPacket>;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSwingPacket>;
    }

    export class $ServerboundTeleportToEntityPacket implements $Packet {
        constructor(uuid: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundTeleportToEntityPacket>;
        getEntity(level: $ServerLevel): $Entity;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundTeleportToEntityPacket>;
    }

    export class $ServerboundTestInstanceBlockActionPacket extends $Record implements $Packet {
        constructor(pos: $BlockPos_, action: $ServerboundTestInstanceBlockActionPacket$Action_, test: $Optional<$ResourceKey<$GameTestInstance>>, size: $Vec3i, rotation: $Rotation_, ignoreEntities: boolean);
        constructor(pos: $BlockPos_, action: $ServerboundTestInstanceBlockActionPacket$Action_, data: $TestInstanceBlockEntity$Data);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ServerboundTestInstanceBlockActionPacket>;
        action(): $ServerboundTestInstanceBlockActionPacket$Action;
        data(): $TestInstanceBlockEntity$Data;
        equals(o: object): boolean;
        handle(listener: $ServerGamePacketListener): void;
        hashCode(): number;
        pos(): $BlockPos;
        toString(): string;
        type(): $PacketType<$ServerboundTestInstanceBlockActionPacket>;
    }

    export class $ServerboundTestInstanceBlockActionPacket$Action {
        static EXPORT: $ServerboundTestInstanceBlockActionPacket$Action;
        static INIT: $ServerboundTestInstanceBlockActionPacket$Action;
        static QUERY: $ServerboundTestInstanceBlockActionPacket$Action;
        static RESET: $ServerboundTestInstanceBlockActionPacket$Action;
        static RUN: $ServerboundTestInstanceBlockActionPacket$Action;
        static SAVE: $ServerboundTestInstanceBlockActionPacket$Action;
        static SET: $ServerboundTestInstanceBlockActionPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundTestInstanceBlockActionPacket$Action[];
        static valueOf(name: string): $ServerboundTestInstanceBlockActionPacket$Action;
    }

    export class $ServerboundUseItemOnPacket implements $Packet {
        constructor(hand: $InteractionHand_, blockHit: $BlockHitResult, sequence: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundUseItemOnPacket>;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get hitResult(): $BlockHitResult;
        getHitResult(): $BlockHitResult;
        get sequence(): number;
        getSequence(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundUseItemOnPacket>;
    }

    export class $ServerboundUseItemPacket implements $Packet {
        constructor(hand: $InteractionHand_, sequence: number, yRot: number, xRot: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundUseItemPacket>;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get sequence(): number;
        getSequence(): number;
        get xRot(): number;
        getXRot(): number;
        get yRot(): number;
        getYRot(): number;
        handle(listener: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundUseItemPacket>;
    }

    export class $VecDeltaCodec {
        constructor();
        get base(): $Vec3;
        getBase(): $Vec3;
        set base(value: $Vec3_);
        decode(xa: number, ya: number, za: number): $Vec3;
        delta(pos: $Vec3_): $Vec3;
        encodeX(pos: $Vec3_): number;
        encodeY(pos: $Vec3_): number;
        encodeZ(pos: $Vec3_): number;
    }

    export type $ClientboundCustomChatCompletionsPacket$Action_ = $ClientboundCustomChatCompletionsPacket$Action | "ADD" | "REMOVE" | "SET";
    export type $ClientboundPlayerInfoUpdatePacket$Action_ = $ClientboundPlayerInfoUpdatePacket$Action | "ADD_PLAYER" | "INITIALIZE_CHAT" | "UPDATE_DISPLAY_NAME" | "UPDATE_GAME_MODE" | "UPDATE_HAT" | "UPDATE_LATENCY" | "UPDATE_LISTED" | "UPDATE_LIST_ORDER";
    export type $ClientboundSetPlayerTeamPacket$Action_ = $ClientboundSetPlayerTeamPacket$Action | "ADD" | "REMOVE";
    export type $ClientboundTrackedWaypointPacket$Operation_ = $ClientboundTrackedWaypointPacket$Operation | "TRACK" | "UNTRACK" | "UPDATE";
    export type $ServerboundClientCommandPacket$Action_ = $ServerboundClientCommandPacket$Action | "PERFORM_RESPAWN" | "REQUEST_GAMERULE_VALUES" | "REQUEST_STATS";
    export type $ServerboundPlayerActionPacket$Action_ = $ServerboundPlayerActionPacket$Action | "ABORT_DESTROY_BLOCK" | "DROP_ALL_ITEMS" | "DROP_ITEM" | "RELEASE_USE_ITEM" | "STAB" | "START_DESTROY_BLOCK" | "STOP_DESTROY_BLOCK" | "SWAP_ITEM_WITH_OFFHAND";
    export type $ServerboundPlayerCommandPacket$Action_ = $ServerboundPlayerCommandPacket$Action | "OPEN_INVENTORY" | "START_FALL_FLYING" | "START_RIDING_JUMP" | "START_SPRINTING" | "STOP_RIDING_JUMP" | "STOP_SLEEPING" | "STOP_SPRINTING";
    export type $ServerboundSeenAdvancementsPacket$Action_ = $ServerboundSeenAdvancementsPacket$Action | "CLOSED_SCREEN" | "OPENED_TAB";
    export type $ServerboundTestInstanceBlockActionPacket$Action_ = $ServerboundTestInstanceBlockActionPacket$Action | "EXPORT" | "INIT" | "QUERY" | "RESET" | "RUN" | "SAVE" | "SET";
}
