import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $String } from "java:java/lang";
import { $Map, $Optional } from "java:java/util";
import { $Supplier } from "java:java/util/function";
import { $Tag } from "java:net/minecraft/nbt";
import { $ClickEvent } from "java:net/minecraft/network/chat";

declare module "java:net/minecraft/server/dialog/action" {
    export interface $Action {
        codec(): $MapCodec<$Action>;
        createAction(parameters: { [key: string]: $Action$ValueGetter }): $Optional<$ClickEvent>;
        static CODEC: $Codec<$Action>;
    }

    export interface $Action$ValueGetter {
        asTag(): $Tag;
        asTemplateSubstitution(): string;
        getAsTemplateSubstitutions(parameters: { [key: string]: $Action$ValueGetter }): $Map<string, string>;
        of(value: string): $Action$ValueGetter;
        of(value: $Supplier<string>): $Action$ValueGetter;
    }

}
