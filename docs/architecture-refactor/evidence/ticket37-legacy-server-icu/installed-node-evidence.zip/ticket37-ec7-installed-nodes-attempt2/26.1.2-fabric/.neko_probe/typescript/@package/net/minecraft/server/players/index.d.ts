import { $JsonObject } from "java:com/google/gson";
import { $GameProfile } from "java:com/mojang/authlib";
import { $Either } from "java:com/mojang/datafixers/util";
import { $Codec } from "java:com/mojang/serialization";
import { $File } from "java:java/io";
import { $Boolean, $Record, $String } from "java:java/lang";
import { $SocketAddress } from "java:java/net";
import { $SimpleDateFormat } from "java:java/text";
import { $Collection, $Date, $List, $Optional, $UUID } from "java:java/util";
import { $Function } from "java:java/util/function";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Connection } from "java:net/minecraft/network";
import { $ChatType$Bound, $Component, $Component_, $PlayerChatMessage } from "java:net/minecraft/network/chat";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $MinecraftServer, $PlayerAdvancements } from "java:net/minecraft/server";
import { $ServerLevel, $ServerPlayer } from "java:net/minecraft/server/level";
import { $CommonListenerCookie, $ServerGamePacketListenerImpl } from "java:net/minecraft/server/network";
import { $LevelBasedPermissionSet } from "java:net/minecraft/server/permissions";
import { $ServerStatsCounter } from "java:net/minecraft/stats";
import { $Entity$RemovalReason, $Entity$RemovalReason_, $LivingEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Level } from "java:net/minecraft/world/level";

declare module "java:net/minecraft/server/players" {
    export class $BanListEntry<T> extends $StoredUserEntry {
        constructor(user: T, created: $Date, source: string, expires: $Date, reason: string);
        static DATE_FORMAT: $SimpleDateFormat;
        static EXPIRES_NEVER: string;
        get created(): $Date;
        getCreated(): $Date;
        get displayName(): $Component;
        getDisplayName(): $Component;
        get expires(): $Date;
        getExpires(): $Date;
        get reasonMessage(): $Component;
        getReasonMessage(): $Component;
        get reason(): string;
        getReason(): string;
        get source(): string;
        getSource(): string;
        equals(o: object): boolean;
    }

    export class $IpBanList extends $StoredUserList {
        constructor(file: string, notificationService: $NotificationService);
        add(infos: $IpBanListEntry): boolean;
        clear(): void;
        get(address: $SocketAddress): $IpBanListEntry;
        isBanned(ip: string): boolean;
        isBanned(address: $SocketAddress): boolean;
        remove(ip: string): boolean;
    }

    export class $IpBanListEntry extends $BanListEntry {
        constructor(object: $JsonObject);
        constructor(address: string);
        constructor(address: string, created: $Date, source: string, expires: $Date, reason: string);
        get displayName(): $Component;
        getDisplayName(): $Component;
    }

    export class $NameAndId extends $Record {
        constructor(profile: $GameProfile);
        constructor(profile: $NameAndId);
        constructor(id: string, name: string);
        static CODEC: $Codec<$NameAndId>;
        static createOffline(name: string): $NameAndId;
        static fromJson(object: $JsonObject): $NameAndId;
        appendTo(output: $JsonObject): void;
        equals(o: object): boolean;
        hashCode(): number;
        id(): $UUID;
        name(): string;
        toString(): string;
    }

    export class $PlayerList {
        constructor(server: $MinecraftServer, registries: $LayeredRegistryAccess<$RegistryLayer_>, playerIo: $PlayerDataStorage, notificationService: $NotificationService);
        static CHAT_FILTERED_FULL: $Component;
        static DUPLICATE_LOGIN_DISCONNECT_MESSAGE: $Component;
        static IPBANLIST_FILE: $File;
        static OPLIST_FILE: $File;
        static USERBANLIST_FILE: $File;
        static WHITELIST_FILE: $File;
        get bans(): $UserBanList;
        getBans(): $UserBanList;
        get ipBans(): $IpBanList;
        getIpBans(): $IpBanList;
        get maxPlayers(): number;
        getMaxPlayers(): number;
        get opNames(): string[];
        getOpNames(): string[];
        get ops(): $ServerOpList;
        getOps(): $ServerOpList;
        get playerCount(): number;
        getPlayerCount(): number;
        get playerNamesArray(): string[];
        getPlayerNamesArray(): string[];
        get players(): $List<$ServerPlayer>;
        getPlayers(): $List<$ServerPlayer>;
        get server(): $MinecraftServer;
        getServer(): $MinecraftServer;
        get simulationDistance(): number;
        getSimulationDistance(): number;
        set simulationDistance(value: number);
        get viewDistance(): number;
        getViewDistance(): number;
        set viewDistance(value: number);
        get whiteListNames(): string[];
        getWhiteListNames(): string[];
        get whiteList(): $UserWhiteList;
        getWhiteList(): $UserWhiteList;
        get allowCommandsForAllPlayers(): boolean;
        isAllowCommandsForAllPlayers(): boolean;
        set allowCommandsForAllPlayers(value: boolean);
        get usingWhitelist(): boolean;
        isUsingWhitelist(): boolean;
        addWorldborderListener(level: $ServerLevel): void;
        broadcastAll(packet: $Packet<any>, dimension: $ResourceKey<$Level>): void;
        broadcastAll(packet: $Packet<any>): void;
        broadcastChatMessage(message: $PlayerChatMessage, sender: $CommandSourceStack, chatType: $ChatType$Bound): void;
        broadcastChatMessage(message: $PlayerChatMessage, sender: $ServerPlayer, chatType: $ChatType$Bound): void;
        broadcastSystemMessage(message: $Component_, overlay: boolean): void;
        broadcastSystemMessage(message: $Component_, playerMessages: $Function<$ServerPlayer, $Component_>, overlay: boolean): void;
        broadcastSystemToAllExceptTeam(player: $Player, message: $Component_): void;
        broadcastSystemToTeam(player: $Player, message: $Component_): void;
        broadcast(except: $Player, x: number, y: number, z: number, range: number, dimension: $ResourceKey<$Level>, packet: $Packet<any>): void;
        canBypassPlayerLimit(nameAndId: $NameAndId): boolean;
        canPlayerLogin(address: $SocketAddress, nameAndId: $NameAndId): $Component;
        deop(nameAndId: $NameAndId): void;
        disconnectAllPlayersWithProfile(playerId: string): boolean;
        getPlayerAdvancements(player: $ServerPlayer): $PlayerAdvancements;
        getPlayerByName(name: string): $ServerPlayer;
        getPlayerStats(player: $Player): $ServerStatsCounter;
        getPlayersWithAddress(ip: string): $List<$ServerPlayer>;
        getPlayer(playerName: string): $ServerPlayer;
        getPlayer(uuid: string): $ServerPlayer;
        isOp(nameAndId: $NameAndId): boolean;
        isWhiteListed(nameAndId: $NameAndId): boolean;
        loadPlayerData(nameAndId: $NameAndId): $Optional<$CompoundTag>;
        op(nameAndId: $NameAndId, permissions: $Optional<$LevelBasedPermissionSet>, canBypassPlayerLimit: $Optional<boolean>): void;
        op(nameAndId: $NameAndId): void;
        placeNewPlayer(connection: $Connection, player: $ServerPlayer, cookie: $CommonListenerCookie): void;
        reloadResources(): void;
        reloadWhiteList(): void;
        removeAll(): void;
        remove(player: $ServerPlayer): void;
        respawn(serverPlayer: $ServerPlayer, keepAllPlayerData: boolean, removalReason: $Entity$RemovalReason_): $ServerPlayer;
        saveAll(): void;
        sendActiveEffects(livingEntity: $LivingEntity, connection: $ServerGamePacketListenerImpl): void;
        sendActivePlayerEffects(player: $ServerPlayer): void;
        sendAllPlayerInfo(player: $ServerPlayer): void;
        sendLevelInfo(player: $ServerPlayer, level: $ServerLevel): void;
        sendPlayerPermissionLevel(player: $ServerPlayer): void;
        tick(): void;
    }

    export interface $ProfileResolver {
        fetchById(id: string): $Optional<$GameProfile>;
        fetchByNameOrId(nameOrId: $Either<string, string>): $Optional<$GameProfile>;
        fetchByName(name: string): $Optional<$GameProfile>;
    }

    export class $ServerOpList extends $StoredUserList {
        constructor(file: string, notificationService: $NotificationService);
        get userList(): string[];
        getUserList(): string[];
        add(infos: $ServerOpListEntry): boolean;
        canBypassPlayerLimit(user: $NameAndId): boolean;
        clear(): void;
        remove(user: $NameAndId): boolean;
    }

    export class $ServerOpListEntry extends $StoredUserEntry {
        constructor(object: $JsonObject);
        constructor(user: $NameAndId, permissions: $LevelBasedPermissionSet, bypassesPlayerLimit: boolean);
        get bypassesPlayerLimit(): boolean;
        getBypassesPlayerLimit(): boolean;
        permissions(): $LevelBasedPermissionSet;
    }

    export class $StoredUserEntry<T> {
        constructor(user: T);
        get user(): T;
        getUser(): T;
    }

    export class $StoredUserList<K, V extends $StoredUserEntry<K>> {
        constructor(file: string, notificationService: $NotificationService);
        get entries(): $Collection<V>;
        getEntries(): $Collection<V>;
        get file(): $File;
        getFile(): $File;
        get userList(): string[];
        getUserList(): string[];
        get empty(): boolean;
        isEmpty(): boolean;
        add(infos: V): boolean;
        clear(): void;
        get(user: K): V;
        load(): void;
        remove(user: K): boolean;
        remove(infos: $StoredUserEntry<K>): boolean;
        save(): void;
    }

    export class $UserBanList extends $StoredUserList {
        constructor(file: string, notificationService: $NotificationService);
        get userList(): string[];
        getUserList(): string[];
        add(infos: $UserBanListEntry): boolean;
        clear(): void;
        isBanned(user: $NameAndId): boolean;
        remove(user: $NameAndId): boolean;
    }

    export class $UserBanListEntry extends $BanListEntry {
        constructor(object: $JsonObject);
        constructor(user: $NameAndId);
        constructor(user: $NameAndId, created: $Date, source: string, expires: $Date, reason: string);
        get displayName(): $Component;
        getDisplayName(): $Component;
    }

    export interface $UserNameToIdResolver {
        add(nameAndId: $NameAndId): void;
        get(name: string): $Optional<$NameAndId>;
        get(id: string): $Optional<$NameAndId>;
        resolveOfflineUsers(value: boolean): void;
        save(): void;
    }

    export class $UserWhiteList extends $StoredUserList {
        constructor(file: string, notificationService: $NotificationService);
        get userList(): string[];
        getUserList(): string[];
        add(infos: $UserWhiteListEntry): boolean;
        clear(): void;
        isWhiteListed(user: $NameAndId): boolean;
        remove(user: $NameAndId): boolean;
    }

    export class $UserWhiteListEntry extends $StoredUserEntry {
        constructor(object: $JsonObject);
        constructor(user: $NameAndId);
    }

}
