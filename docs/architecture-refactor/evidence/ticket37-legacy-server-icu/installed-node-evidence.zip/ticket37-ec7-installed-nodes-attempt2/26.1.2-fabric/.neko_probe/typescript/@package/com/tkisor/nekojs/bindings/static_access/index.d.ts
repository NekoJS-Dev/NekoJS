import { $FabricEnergyStorage, $FabricFluidStorage, $FabricItemStorage } from "java:com/tkisor/nekojs/fabric/capability";
import { $IngredientJS } from "java:com/tkisor/nekojs/wrapper/item";
import { $Value } from "java:graal/graalvm/polyglot";
import { $ProxyExecutable } from "java:graal/graalvm/polyglot/proxy";
import { $Runnable, $String } from "java:java/lang";
import { $Set, $UUID } from "java:java/util";
import { $BlockApiLookup } from "java:net/fabricmc/fabric/api/lookup/v1/block";
import { $EntityApiLookup } from "java:net/fabricmc/fabric/api/lookup/v1/entity";
import { $ItemApiLookup } from "java:net/fabricmc/fabric/api/lookup/v1/item";
import { $ContainerItemContext } from "java:net/fabricmc/fabric/api/transfer/v1/context";
import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $ParticleOptions } from "java:net/minecraft/core/particles";
import { $Identifier, $Identifier_ } from "java:net/minecraft/resources";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_ } from "java:net/minecraft/world/item/crafting";
import { $Level } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:com/tkisor/nekojs/bindings/static_access" {
    export class $BlockJS {
        constructor();
        idOf(block: $Block_): $Identifier;
        id(id: string): $Block;
    }

    export class $CapabilitiesJS {
        constructor();
        blockLookup(capability: string): $BlockApiLookup<any, $Direction>;
        energyStorage(capacity: number, maxReceive: number, maxExtract: number, onChange: $Runnable): $FabricEnergyStorage;
        energyStorage(capacity: number, maxReceive: number, maxExtract: number): $FabricEnergyStorage;
        entityLookup(capability: string): $EntityApiLookup<any, $Direction>;
        fluidTank(capacity: number, onChange: $Runnable): $FabricFluidStorage;
        fluidTank(capacity: number): $FabricFluidStorage;
        getBlock(level: $Level, position: $BlockPos_, capability: string, direction: $Direction_): object;
        getEntity(entity: $Entity, capability: string, direction: $Direction_): object;
        getItem(stack: $ItemStack_, capability: string, context: $ContainerItemContext): object;
        itemHandler(size: number, onChange: $Runnable): $FabricItemStorage;
        itemHandler(size: number): $FabricItemStorage;
        itemLookup(capability: string): $ItemApiLookup<any, $ContainerItemContext>;
    }

    /**
     * Read-only client-side view of key-value data pushed by server scripts via ClientData.sync.
     * Values round-trip JSON types only (string/number/bool/object/array/null); re-pushed keys overwrite.
     */
    export class $ClientDataJS {
        constructor();
        /**
         * Returns the value stored under the key, or null when missing (or when the value is JSON null).
         * @param key data key the server pushed with ClientData.sync
         * @returns the stored value converted from JSON; null when absent
         */
        get(key: string): object;
        /**
         * Returns whether the key has been synced (true even when the stored value is JSON null).
         * @param key data key to check
         * @returns true when the key exists in the store
         */
        has(key: string): boolean;
        /**
         * Returns a snapshot of all currently synced keys.
         * @returns unordered set of keys; empty when nothing is synced
         */
        keys(): $Set<string>;
        /**
         * Returns how many keys are currently stored.
         * @returns number of synced keys
         */
        size(): number;
    }

    /** Color helpers for packing, extracting, and parsing ARGB color ints. */
    export class $ColorJS {
        constructor();
        /**
         * Extracts the alpha channel of a color.
         * @param color ARGB color int
         * @returns alpha channel value, 0-255
         */
        alpha(color: number): number;
        /**
         * Packs ARGB channels into a color int; channels are clamped to 0-255.
         * @param alpha alpha channel, 0-255
         * @param red red channel, 0-255
         * @param green green channel, 0-255
         * @param blue blue channel, 0-255
         * @returns ARGB color int
         */
        argb(alpha: number, red: number, green: number, blue: number): number;
        /**
         * Extracts the blue channel of a color.
         * @param color ARGB color int
         * @returns blue channel value, 0-255
         */
        blue(color: number): number;
        /**
         * Extracts the green channel of a color.
         * @param color ARGB color int
         * @returns green channel value, 0-255
         */
        green(color: number): number;
        /**
         * Formats the color as '#AARRGGBB', including the alpha channel.
         * @param color ARGB color int
         * @returns hex string like '#AARRGGBB'
         */
        hexArgb(color: number): string;
        /**
         * Formats the color as '#RRGGBB', ignoring the alpha channel.
         * @param color ARGB color int
         * @returns hex string like '#RRGGBB'
         */
        hex(color: number): string;
        /**
         * Parses '#RRGGBB' or '#AARRGGBB' into a color int; the leading '#' is optional.
         * @param value hex color string, with or without leading '#'
         * @returns ARGB color int; 6-digit form gets opaque alpha
         */
        parse(value: string): number;
        /**
         * Extracts the red channel of a color.
         * @param color ARGB color int
         * @returns red channel value, 0-255
         */
        red(color: number): number;
        /**
         * Packs RGB channels into an opaque color int; channels are clamped to 0-255.
         * @param red red channel, 0-255
         * @param green green channel, 0-255
         * @param blue blue channel, 0-255
         * @returns opaque ARGB color int (alpha = 255)
         */
        rgb(red: number, green: number, blue: number): number;
    }

    export class $DamageSourceJS {
        constructor();
        drowning(level: $Level): $DamageSource;
        explosion(level: $Level): $DamageSource;
        fall(level: $Level): $DamageSource;
        generic(level: $Level): $DamageSource;
        lava(level: $Level): $DamageSource;
        lightning(level: $Level): $DamageSource;
        magic(level: $Level): $DamageSource;
        of(level: $Level, damageTypeId: $Identifier_, causingEntity: $Entity): $DamageSource;
        of(level: $Level, damageTypeId: $Identifier_): $DamageSource;
        outOfWorld(level: $Level): $DamageSource;
        starvation(level: $Level): $DamageSource;
    }

    /** Static binding 'Ingredient': factory helpers for item ingredients. */
    export class $IngredientFactory {
        constructor();
        /**
         * Creates a true wildcard ingredient matching every registered item.
         * @returns an IngredientJS backed by a live any-holder set, so items registered later still match
         */
        all(): $IngredientJS;
        /**
         * Combines several ingredients into one that matches any of them.
         * @param ingredients the ingredients to combine with OR
         * @returns an IngredientJS matching any of the given ingredients
         */
        any(ingredients?: $Ingredient_[]): $IngredientJS;
        /**
         * Creates an ingredient matching a single item.
         * @param id item id like 'minecraft:stick'
         * @returns an IngredientJS matching only that item
         */
        item(id: string): $IngredientJS;
        /**
         * Negates an ingredient: matches every item except the given one.
         * @param ingredient the ingredient whose matches to exclude
         * @returns an IngredientJS matching all items not matched by the given ingredient
         */
        not(ingredient: $Ingredient_): $IngredientJS;
        /**
         * Builds an ingredient matching any of the given item-like values.
         * Accepts item ids and selector strings: '#tag', '@mod', '*' (any item), and '/regex/'.
         * @param values item ids, '#tag'/'@mod'/'*'/'/regex/' strings, items, stacks, or ingredients
         * @returns an IngredientJS combining all values with OR; empty wrapper when no value is given
         */
        of(values?: object[]): $IngredientJS;
        /**
         * Creates an ingredient matching an item tag.
         * @param id tag id; a leading '#' is added automatically when missing
         * @returns an IngredientJS matching all items in the tag
         */
        tag(id: string): $IngredientJS;
    }

    export class $ItemJS {
        constructor();
        empty(): $ItemStack;
        idOf(item: $Item_): $Identifier;
        id(id: string): $Item;
        of(id: string, count: number): $ItemStack;
        of(id: string): $ItemStack;
        of(stack: $ItemStack_, count: number): $ItemStack;
        of(stack: $ItemStack_): $ItemStack;
    }

    export class $KMathJS {
        static DEGREES_TO_RADIANS: number;
        static E: number;
        static PI: number;
        static RADIANS_TO_DEGREES: number;
        static blockPos(x: number, y: number, z: number): $BlockPos;
        static blockPos(x: number, y: number, z: number): $BlockPos;
        static deg(degrees: number): number;
        static rad(radians: number): number;
        static vec3(x: number, y: number, z: number): $Vec3;
        static vec3(pos: $BlockPos_): $Vec3;
    }

    /**
     * Run-once guard: once(key, callback) executes the callback only the first time the key is used.
     * Markers deliberately survive script reloads (process-lifetime, in-memory); use clearOnce(key) to re-arm.
     */
    export class $OnceJS implements $ProxyExecutable {
        static CLEAR_ONCE: $OnceJS$ClearOnceJS;
        static ONCE: $OnceJS;
        execute(arguments_?: $Value[]): object;
    }

    /** clearOnce(key) removes one run-once marker (returns whether it existed); clearOnce() clears all markers. */
    export class $OnceJS$ClearOnceJS implements $ProxyExecutable {
        execute(arguments_?: $Value[]): object;
    }

    export class $ParticleOptionsJS {
        constructor();
        of(particleId: $Identifier_, options: $Value): $ParticleOptions;
        of(particleId: $Identifier_): $ParticleOptions;
    }

    /** String helpers for blank checks and case-convention conversion. */
    export class $StringUtilsJS {
        constructor();
        /**
         * Converts snake_case, kebab-case, or space-separated input to camelCase.
         * @param value input string; null is allowed
         * @returns camelCase string, or the input unchanged when null/empty
         */
        camelCase(value: string): string;
        /**
         * Upper-cases the first character, keeping the rest unchanged.
         * @param value input string; null is allowed
         * @returns capitalized string, or the input unchanged when null/empty
         */
        capitalize(value: string): string;
        /**
         * Lower-cases the first character, keeping the rest unchanged.
         * @param value input string; null is allowed
         * @returns decapitalized string, or the input unchanged when null/empty
         */
        decapitalize(value: string): string;
        /**
         * Checks whether the value is null, empty, or whitespace-only.
         * @param value string to check; null is allowed
         * @returns true when null, empty, or whitespace-only
         */
        isBlank(value: string): boolean;
        /**
         * Checks whether the value is null or the empty string (whitespace counts as non-empty).
         * @param value string to check; null is allowed
         * @returns true only when null or empty
         */
        isEmpty(value: string): boolean;
        /**
         * Converts camelCase, kebab-case, or space-separated input to lower_snake_case.
         * @param value input string; null is allowed
         * @returns snake_case string, or the input unchanged when null/empty
         */
        snakeCase(value: string): string;
    }

    /** Tiny assertion harness for test scripts; failures throw AssertionError. */
    export class $TestJS {
        constructor();
        /**
         * Asserts that expected and actual are equal (Objects.equals semantics).
         * @param expected expected value
         * @param actual actual value
         * @param message optional label prepended to the failure error
         * @returns this, for chaining
         */
        assertEquals(expected: object, actual: object, message: string): $TestJS;
        /**
         * Asserts that the condition is false; throws on failure.
         * @param condition condition expected to be false
         * @param message label used in the pass log and the failure error
         * @returns this, for chaining
         */
        assertFalse(condition: boolean, message: string): $TestJS;
        /**
         * Asserts that the value is not null; throws on failure.
         * @param value value expected to be non-null
         * @param message label used in the pass log and the failure error
         * @returns this, for chaining
         */
        assertNotNull(value: object, message: string): $TestJS;
        /**
         * Runs the given JS function and asserts that it throws.
         * @param callback JS function expected to throw when executed with no arguments
         * @param message optional label prepended to the failure error
         * @returns this, for chaining
         */
        assertThrows(callback: object, message: string): $TestJS;
        /**
         * Asserts that the condition is true; throws on failure.
         * @param condition condition expected to be true
         * @param message label used in the pass log and the failure error
         * @returns this, for chaining
         */
        assertTrue(condition: boolean, message: string): $TestJS;
        /**
         * Number of assertions failed so far.
         * @returns count of failed assertions
         */
        failed(): number;
        /**
         * Records a failure and throws an AssertionError; never returns normally.
         * @param message failure message; a default text is used when null/blank
         */
        fail(message: string): $TestJS;
        /**
         * Number of assertions passed so far.
         * @returns count of passed assertions
         */
        passed(): number;
        /**
         * Records a passed assertion and logs it.
         * @param message optional label shown in the log; null/blank renders as empty
         * @returns this, for chaining
         */
        pass(message: string): $TestJS;
        /**
         * Logs a section header to group the assertions that follow.
         * @param name section name shown in the log
         * @returns this, for chaining
         */
        section(name: string): $TestJS;
        /**
         * Logs the current passed/failed counts as a summary.
         * @returns this, for chaining
         */
        summary(): $TestJS;
    }

    export interface $TextIcons {
        static ANVIL: string;
        static ARROW_DOWN: string;
        static ARROW_LEFT: string;
        static ARROW_RIGHT: string;
        static ARROW_UP: string;
        static BULLET_SQUARE: string;
        static CHECK: string;
        static CROSS: string;
        static DOT: string;
        static ENCHANT_BOOK: string;
        static FIRE: string;
        static GEAR: string;
        static HEART: string;
        static MINUS: string;
        static MOON: string;
        static PICKAXE: string;
        static PLUS: string;
        static POTION: string;
        static SHIELD: string;
        static SKULL: string;
        static SNOWFLAKE: string;
        static STAR: string;
        static SUN: string;
        static SWORD: string;
        static WARNING: string;
    }

    /** Time unit helpers in game ticks (1 second = 20 ticks). */
    export class $TimeJS {
        constructor();
        /** Ticks per hour (72000). */
        HOUR: number;
        /** Ticks per minute (1200). */
        MINUTE: number;
        /** Ticks per second (20). */
        SECOND: number;
        /**
         * Converts hours to ticks.
         * @param value amount of hours
         * @returns equivalent amount of ticks
         */
        hours(value: number): number;
        /**
         * Converts minutes to ticks.
         * @param value amount of minutes
         * @returns equivalent amount of ticks
         */
        minutes(value: number): number;
        /**
         * Parses a time string into milliseconds; plain numbers are treated as milliseconds.
         * @param str time string with unit suffix (ms/s/m/h/t)
         * @returns millisecond count; 0 for null or empty input
         */
        parseMs(str: string): number;
        /**
         * Parses a time string like '5s', '10m', '2h', '100ms' or '100t' into ticks.
         * @param str time string with unit suffix (ms/s/m/h/t); plain numbers are treated as ticks
         * @returns tick count; 0 for null or empty input
         */
        parseTime(str: string): number;
        /**
         * Converts seconds to ticks.
         * @param value amount of seconds
         * @returns equivalent amount of ticks
         */
        seconds(value: number): number;
    }

    /** UUID helpers: random, string-parsed, and name-derived UUIDs. */
    export class $UUIDJS {
        constructor();
        /**
         * Derives a deterministic UUID (version 3) from the UTF-8 bytes of the name.
         * @param value any string; the same name always yields the same UUID
         * @returns the name-derived UUID
         */
        fromName(value: string): $UUID;
        /**
         * Parses the canonical hyphenated UUID string form.
         * @param value canonical UUID string in hyphenated hex form
         * @returns the parsed UUID; throws on malformed input
         */
        fromString(value: string): $UUID;
        /**
         * Generates a new random UUID (version 4).
         * @returns a fresh random UUID
         */
        random(): $UUID;
    }

    /** Misc helpers: randomness and Java value type checks. */
    export class $UtilsJS {
        constructor();
        /**
         * Returns true with the given probability.
         * @param probability chance of true, from 0 (never) to 1 (always)
         * @returns true with the given probability, false otherwise
         */
        chance(probability: number): boolean;
        /**
         * Checks whether the value is a Java array.
         * @param value value to check; null is allowed
         * @returns true for arrays; false for null and non-arrays
         */
        isArray(value: object): boolean;
        /**
         * Checks whether the value is a Java List.
         * @param value value to check; null is allowed
         * @returns true for List instances; false for null and other types
         */
        isList(value: object): boolean;
        /**
         * Checks whether the value is a Java Map.
         * @param value value to check; null is allowed
         * @returns true for Map instances; false for null and other types
         */
        isMap(value: object): boolean;
        /**
         * Returns a random double in [minInclusive, maxExclusive).
         * @param minInclusive inclusive lower bound
         * @param maxExclusive exclusive upper bound
         * @returns random double within the range
         */
        randomDouble(minInclusive: number, maxExclusive: number): number;
        /**
         * Returns a random double in [0, maxExclusive).
         * @param maxExclusive exclusive upper bound; must be positive
         * @returns random double within the range
         */
        randomDouble(maxExclusive: number): number;
        /**
         * Returns a random double in [0, 1).
         * @returns random double, never 1.0
         */
        randomDouble(): number;
        /**
         * Returns a random int in [minInclusive, maxExclusive).
         * @param minInclusive inclusive lower bound
         * @param maxExclusive exclusive upper bound
         * @returns random int within the range
         */
        randomInt(minInclusive: number, maxExclusive: number): number;
        /**
         * Returns a random int in [0, maxExclusive).
         * @param maxExclusive exclusive upper bound; must be positive
         * @returns random int, never equal to maxExclusive
         */
        randomInt(maxExclusive: number): number;
    }

}
