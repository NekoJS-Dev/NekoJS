import { $MapCodec } from "java:com/mojang/serialization";

declare module "java:net/minecraft/server/dialog/input" {
    export interface $InputControl {
        mapCodec(): $MapCodec<$InputControl>;
        static MAP_CODEC: $MapCodec<$InputControl>;
    }

}
