import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Optional } from "java:java/util";

export * as pack from "java:net/minecraft/server/packs/metadata/pack";

declare module "java:net/minecraft/server/packs/metadata" {
    export class $MetadataSectionType<T> extends $Record {
        constructor(name: string, codec: $Codec<T>);
        codec(): $Codec<T>;
        equals(o: object): boolean;
        hashCode(): number;
        name(): string;
        toString(): string;
        withValue(value: T): $MetadataSectionType$WithValue<T>;
    }

    export class $MetadataSectionType$WithValue<T> extends $Record {
        constructor(type: $MetadataSectionType<T>, value: T);
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $MetadataSectionType<T>;
        unwrapToType<U>(type: $MetadataSectionType<U>): $Optional<U>;
        value(): T;
    }

}
