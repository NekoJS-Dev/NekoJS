import { $ByteBuf } from "java:io/netty/buffer";
import { $ChannelHandlerContext } from "java:io/netty/channel";
import { $Enum, $Record, $String } from "java:java/lang";
import { $List, $Map, $Optional, $UUID } from "java:java/util";
import { $Consumer } from "java:java/util/function";
import { $GenericPayloadAccessor, $PayloadTypeRegistryImpl } from "java:net/fabricmc/fabric/impl/networking";
import { $SplittablePacket } from "java:net/fabricmc/fabric/impl/networking/splitter";
import { $ClientboundCustomPayloadPacketAccessor } from "java:net/fabricmc/fabric/mixin/attachment";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $Tag } from "java:net/minecraft/nbt";
import { $FriendlyByteBuf, $PacketEncoder, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $CustomPacketPayload } from "java:net/minecraft/network/protocol/common/custom";
import { $ClientCookiePacketListener, $ServerCookiePacketListener } from "java:net/minecraft/network/protocol/cookie";
import { $Identifier, $Identifier_, $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLinks$UntrustedEntry } from "java:net/minecraft/server";
import { $Dialog } from "java:net/minecraft/server/dialog";
import { $ClientInformation } from "java:net/minecraft/server/level";
import { $TagNetworkSerialization$NetworkPayload } from "java:net/minecraft/tags";

export * as custom from "java:net/minecraft/network/protocol/common/custom";

declare module "java:net/minecraft/network/protocol/common" {
    export interface $ClientCommonPacketListener extends $ClientCookiePacketListener {
        handleClearDialog(packet: $ClientboundClearDialogPacket): void;
        handleCustomPayload(packet: $ClientboundCustomPayloadPacket): void;
        handleCustomReportDetails(packet: $ClientboundCustomReportDetailsPacket): void;
        handleDisconnect(packet: $ClientboundDisconnectPacket): void;
        handleKeepAlive(packet: $ClientboundKeepAlivePacket): void;
        handlePing(packet: $ClientboundPingPacket): void;
        handleResourcePackPop(packet: $ClientboundResourcePackPopPacket): void;
        handleResourcePackPush(packet: $ClientboundResourcePackPushPacket): void;
        handleServerLinks(packet: $ClientboundServerLinksPacket): void;
        handleShowDialog(packet: $ClientboundShowDialogPacket): void;
        handleStoreCookie(packet: $ClientboundStoreCookiePacket): void;
        handleTransfer(packet: $ClientboundTransferPacket): void;
        handleUpdateTags(packet: $ClientboundUpdateTagsPacket): void;
    }

    export class $ClientboundClearDialogPacket implements $Packet {
        static INSTANCE: $ClientboundClearDialogPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundClearDialogPacket>;
        handle(listener: $ClientCommonPacketListener): void;
        type(): $PacketType<$ClientboundClearDialogPacket>;
    }

    export class $ClientboundCustomPayloadPacket extends $Record implements $Packet, $ClientboundCustomPayloadPacketAccessor, $SplittablePacket, $GenericPayloadAccessor {
        constructor(payload: $CustomPacketPayload);
        static CONFIG_STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundCustomPayloadPacket>;
        static GAMEPLAY_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundCustomPayloadPacket>;
        static MAX_PAYLOAD_SIZE: number;
        equals(o: object): boolean;
        fabric_payload(): $CustomPacketPayload;
        fabric_split(arg0: $PayloadTypeRegistryImpl, arg1: $ChannelHandlerContext, arg2: $PacketEncoder, arg3: $Packet, arg4: $Consumer): void;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        payload(): $CustomPacketPayload;
        toString(): string;
        type(): $PacketType<$ClientboundCustomPayloadPacket>;
    }

    export class $ClientboundCustomReportDetailsPacket extends $Record implements $Packet {
        constructor(details: { [key: string]: string });
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundCustomReportDetailsPacket>;
        details(): $Map<string, string>;
        equals(o: object): boolean;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundCustomReportDetailsPacket>;
    }

    export class $ClientboundDisconnectPacket extends $Record implements $Packet {
        constructor(reason: $Component_);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundDisconnectPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        reason(): $Component;
        toString(): string;
        type(): $PacketType<$ClientboundDisconnectPacket>;
    }

    export class $ClientboundKeepAlivePacket implements $Packet {
        constructor(id: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundKeepAlivePacket>;
        get id(): number;
        getId(): number;
        handle(listener: $ClientCommonPacketListener): void;
        type(): $PacketType<$ClientboundKeepAlivePacket>;
    }

    export class $ClientboundPingPacket implements $Packet {
        constructor(id: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundPingPacket>;
        get id(): number;
        getId(): number;
        handle(listener: $ClientCommonPacketListener): void;
        type(): $PacketType<$ClientboundPingPacket>;
    }

    export class $ClientboundResourcePackPopPacket extends $Record implements $Packet {
        constructor(id: $Optional<string>);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundResourcePackPopPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        id(): $Optional<$UUID>;
        toString(): string;
        type(): $PacketType<$ClientboundResourcePackPopPacket>;
    }

    export class $ClientboundResourcePackPushPacket extends $Record implements $Packet {
        constructor(id: string, url: string, hash: string, required: boolean, prompt: $Optional<$Component_>);
        static MAX_HASH_LENGTH: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundResourcePackPushPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        hash(): string;
        id(): $UUID;
        prompt(): $Optional<$Component>;
        required(): boolean;
        toString(): string;
        type(): $PacketType<$ClientboundResourcePackPushPacket>;
        url(): string;
    }

    export class $ClientboundServerLinksPacket extends $Record implements $Packet {
        constructor(links: $ServerLinks$UntrustedEntry[]);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundServerLinksPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        links(): $List<$ServerLinks$UntrustedEntry>;
        toString(): string;
        type(): $PacketType<$ClientboundServerLinksPacket>;
    }

    export class $ClientboundShowDialogPacket extends $Record implements $Packet {
        constructor(dialog: $Holder<$Dialog>);
        static CONTEXT_FREE_STREAM_CODEC: $StreamCodec<$ByteBuf, $ClientboundShowDialogPacket>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundShowDialogPacket>;
        dialog(): $Holder<$Dialog>;
        equals(o: object): boolean;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ClientboundShowDialogPacket>;
    }

    export class $ClientboundStoreCookiePacket extends $Record implements $Packet {
        constructor(key: $Identifier_, payload: number[]);
        static PAYLOAD_STREAM_CODEC: $StreamCodec<$ByteBuf, number[]>;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundStoreCookiePacket>;
        equals(o: object): boolean;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        key(): $Identifier;
        payload(): number[];
        toString(): string;
        type(): $PacketType<$ClientboundStoreCookiePacket>;
    }

    export class $ClientboundTransferPacket extends $Record implements $Packet {
        constructor(host: string, port: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundTransferPacket>;
        equals(o: object): boolean;
        handle(listener: $ClientCommonPacketListener): void;
        hashCode(): number;
        host(): string;
        port(): number;
        toString(): string;
        type(): $PacketType<$ClientboundTransferPacket>;
    }

    export class $ClientboundUpdateTagsPacket implements $Packet {
        constructor(tags: { [key: $ResourceKey<$Registry<any>>]: $TagNetworkSerialization$NetworkPayload });
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundUpdateTagsPacket>;
        get tags(): $Map<$ResourceKey<$Registry<any>>, $TagNetworkSerialization$NetworkPayload>;
        getTags(): $Map<$ResourceKey<$Registry<any>>, $TagNetworkSerialization$NetworkPayload>;
        handle(listener: $ClientCommonPacketListener): void;
        type(): $PacketType<$ClientboundUpdateTagsPacket>;
    }

    export interface $ServerCommonPacketListener extends $ServerCookiePacketListener {
        handleClientInformation(packet: $ServerboundClientInformationPacket): void;
        handleCustomClickAction(packet: $ServerboundCustomClickActionPacket): void;
        handleCustomPayload(packet: $ServerboundCustomPayloadPacket): void;
        handleKeepAlive(packet: $ServerboundKeepAlivePacket): void;
        handlePong(serverboundPongPacket: $ServerboundPongPacket): void;
        handleResourcePackResponse(packet: $ServerboundResourcePackPacket): void;
    }

    export class $ServerboundClientInformationPacket extends $Record implements $Packet {
        constructor(information: $ClientInformation);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundClientInformationPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerCommonPacketListener): void;
        hashCode(): number;
        information(): $ClientInformation;
        toString(): string;
        type(): $PacketType<$ServerboundClientInformationPacket>;
    }

    export class $ServerboundCustomClickActionPacket extends $Record implements $Packet {
        constructor(id: $Identifier_, payload: $Optional<$Tag>);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundCustomClickActionPacket>;
        equals(o: object): boolean;
        handle(listener: $ServerCommonPacketListener): void;
        hashCode(): number;
        id(): $Identifier;
        payload(): $Optional<$Tag>;
        toString(): string;
        type(): $PacketType<$ServerboundCustomClickActionPacket>;
    }

    export class $ServerboundCustomPayloadPacket extends $Record implements $Packet, $SplittablePacket, $GenericPayloadAccessor {
        constructor(payload: $CustomPacketPayload);
        static MAX_PAYLOAD_SIZE: number;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCustomPayloadPacket>;
        equals(o: object): boolean;
        fabric_payload(): $CustomPacketPayload;
        fabric_split(arg0: $PayloadTypeRegistryImpl, arg1: $ChannelHandlerContext, arg2: $PacketEncoder, arg3: $Packet, arg4: $Consumer): void;
        handle(listener: $ServerCommonPacketListener): void;
        hashCode(): number;
        payload(): $CustomPacketPayload;
        toString(): string;
        type(): $PacketType<$ServerboundCustomPayloadPacket>;
    }

    export class $ServerboundKeepAlivePacket implements $Packet {
        constructor(id: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundKeepAlivePacket>;
        get id(): number;
        getId(): number;
        handle(listener: $ServerCommonPacketListener): void;
        type(): $PacketType<$ServerboundKeepAlivePacket>;
    }

    export class $ServerboundPongPacket implements $Packet {
        constructor(id: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPongPacket>;
        get id(): number;
        getId(): number;
        handle(listener: $ServerCommonPacketListener): void;
        type(): $PacketType<$ServerboundPongPacket>;
    }

    export class $ServerboundResourcePackPacket extends $Record implements $Packet {
        constructor(id: string, action: $ServerboundResourcePackPacket$Action_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundResourcePackPacket>;
        action(): $ServerboundResourcePackPacket$Action;
        equals(o: object): boolean;
        handle(listener: $ServerCommonPacketListener): void;
        hashCode(): number;
        id(): $UUID;
        toString(): string;
        type(): $PacketType<$ServerboundResourcePackPacket>;
    }

    export class $ServerboundResourcePackPacket$Action {
        static ACCEPTED: $ServerboundResourcePackPacket$Action;
        static DECLINED: $ServerboundResourcePackPacket$Action;
        static DISCARDED: $ServerboundResourcePackPacket$Action;
        static DOWNLOADED: $ServerboundResourcePackPacket$Action;
        static FAILED_DOWNLOAD: $ServerboundResourcePackPacket$Action;
        static FAILED_RELOAD: $ServerboundResourcePackPacket$Action;
        static INVALID_URL: $ServerboundResourcePackPacket$Action;
        static SUCCESSFULLY_LOADED: $ServerboundResourcePackPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundResourcePackPacket$Action[];
        static valueOf(name: string): $ServerboundResourcePackPacket$Action;
    }

    export type $ServerboundResourcePackPacket$Action_ = $ServerboundResourcePackPacket$Action | "ACCEPTED" | "DECLINED" | "DISCARDED" | "DOWNLOADED" | "FAILED_DOWNLOAD" | "FAILED_RELOAD" | "INVALID_URL" | "SUCCESSFULLY_LOADED";
}
