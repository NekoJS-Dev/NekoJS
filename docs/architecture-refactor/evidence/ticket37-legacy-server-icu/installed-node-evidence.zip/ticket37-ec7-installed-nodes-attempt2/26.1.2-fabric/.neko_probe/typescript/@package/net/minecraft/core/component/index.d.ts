import { $Codec, $DataResult, $DynamicOps } from "java:com/mojang/serialization";
import { $Class, $Iterable, $Record, $String } from "java:java/lang";
import { $Collection, $Iterator, $List, $Map, $Map$Entry, $Optional, $Set } from "java:java/util";
import { $Consumer, $Predicate, $Supplier } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $FabricComponentMapBuilder } from "java:net/fabricmc/fabric/api/item/v1";
import { $Holder, $HolderLookup$Provider, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceKey } from "java:net/minecraft/resources";

declare module "java:net/minecraft/core/component" {
    export class $DataComponentExactPredicate implements $Predicate {
        static CODEC: $Codec<$DataComponentExactPredicate>;
        static EMPTY: $DataComponentExactPredicate;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentExactPredicate>;
        get empty(): boolean;
        isEmpty(): boolean;
        static allOf(components: $DataComponentMap): $DataComponentExactPredicate;
        static builder(): $DataComponentExactPredicate$Builder;
        static expect<T>(type: $DataComponentType<T>, value: T): $DataComponentExactPredicate;
        static someOf(components: $DataComponentMap, types?: $DataComponentType<any>[]): $DataComponentExactPredicate;
        alwaysMatches(): boolean;
        asPatch(): $DataComponentPatch;
        equals(obj: object): boolean;
        hashCode(): number;
        test(actualComponents: $DataComponentGetter): boolean;
        toString(): string;
    }

    export class $DataComponentExactPredicate$Builder {
        build(): $DataComponentExactPredicate;
        expect<T>(type: $DataComponentType<any>, value: T): $DataComponentExactPredicate$Builder;
        expect<T>(value: $TypedDataComponent<T>): $DataComponentExactPredicate$Builder;
    }

    export interface $DataComponentGetter {
        getOrDefault<T>(type: $DataComponentType<T>, defaultValue: T): T;
        getTyped<T>(type: $DataComponentType<T>): $TypedDataComponent<T>;
        get<T>(type: $DataComponentType<T>): T;
    }

    export interface $DataComponentHolder extends $DataComponentGetter {
        getAllOfType<T>(valueClass: $Class<T>): $Stream<T>;
        getComponents(): $DataComponentMap;
        getOrDefault<T>(type: $DataComponentType<T>, defaultValue: T): T;
        get<T>(type: $DataComponentType<T>): T;
        has(type: $DataComponentType<any>): boolean;
    }

    export interface $DataComponentInitializers$Initializer<T> {
        add<C>(type: $DataComponentType<C>, value: C): $DataComponentInitializers$Initializer<T>;
        andThen(other: $DataComponentInitializers$Initializer<T>): $DataComponentInitializers$Initializer<T>;
        run(components: $DataComponentMap$Builder, context: $HolderLookup$Provider, key: $ResourceKey<T>): void;
    }

    export interface $DataComponentInitializers$SingleComponentInitializer<C> {
        asInitializer<T>(type: $DataComponentType<C>): $DataComponentInitializers$Initializer<T>;
        create(context: $HolderLookup$Provider): C;
    }

    export class $DataComponentLookup<T> {
        constructor(elements: $Iterable<$Holder<T>>);
        findAll<C>(type: $DataComponentType<C>, value: C): $Collection<$Holder<T>>;
        findAll<C>(type: $DataComponentType<C>): $Collection<$Holder<T>>;
        findMatching<C>(type: $DataComponentType<C>, predicate: $Predicate<C>): $Stream<$Holder<T>>;
    }

    export interface $DataComponentMap extends $Iterable, $DataComponentGetter {
        builder(): $DataComponentMap$Builder;
        composite(prototype: $DataComponentMap, overrides: $DataComponentMap): $DataComponentMap;
        filter(predicate: $Predicate<$DataComponentType<any>>): $DataComponentMap;
        has(type: $DataComponentType<any>): boolean;
        isEmpty(): boolean;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        makeCodecFromMap(mapCodec: $Codec<{ [key: $DataComponentType<any>]: object }>): $Codec<$DataComponentMap>;
        makeCodec(componentTypeCodec: $Codec<$DataComponentType<any>>): $Codec<$DataComponentMap>;
        size(): number;
        stream(): $Stream<$TypedDataComponent<any>>;
        static CODEC: $Codec<$DataComponentMap>;
        static EMPTY: $DataComponentMap;
    }

    export class $DataComponentMap$Builder implements $FabricComponentMapBuilder {
        addAll(map: $DataComponentMap): $DataComponentMap$Builder;
        addValidator(newValidator: $Consumer<$DataComponentMap>): $DataComponentMap$Builder;
        build(): $DataComponentMap;
        contains(arg0: $DataComponentType): boolean;
        getOrCreate(arg0: $DataComponentType, arg1: $Supplier): object;
        getOrEmpty(arg0: $DataComponentType): $List;
        set<T>(type: $DataComponentType<T>, value: T): $DataComponentMap$Builder;
    }

    export class $DataComponentPatch {
        static CODEC: $Codec<$DataComponentPatch>;
        static DELIMITED_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentPatch>;
        static EMPTY: $DataComponentPatch;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentPatch>;
        get empty(): boolean;
        isEmpty(): boolean;
        static builder(): $DataComponentPatch$Builder;
        entrySet(): $Set<$Map$Entry<$DataComponentType<any>, $Optional<any>>>;
        equals(obj: object): boolean;
        forget(test: $Predicate<$DataComponentType<any>>): $DataComponentPatch;
        get<T>(prototype: $DataComponentGetter, type: $DataComponentType<T>): T;
        hashCode(): number;
        size(): number;
        split(): $DataComponentPatch$SplitResult;
        toString(): string;
    }

    export class $DataComponentPatch$Builder {
        build(): $DataComponentPatch;
        remove<T>(type: $DataComponentType<T>): $DataComponentPatch$Builder;
        set<T>(components: $Iterable<$TypedDataComponent<any>>): $DataComponentPatch$Builder;
        set<T>(type: $DataComponentType<T>, value: T): $DataComponentPatch$Builder;
        set<T>(component: $TypedDataComponent<T>): $DataComponentPatch$Builder;
    }

    export class $DataComponentPatch$SplitResult extends $Record {
        constructor(added: $DataComponentMap, removed: $DataComponentType<any>[]);
        static EMPTY: $DataComponentPatch$SplitResult;
        added(): $DataComponentMap;
        equals(o: object): boolean;
        hashCode(): number;
        removed(): $Set<$DataComponentType<any>>;
        toString(): string;
    }

    export interface $DataComponentType<T> {
        builder<T>(): $DataComponentType$Builder<T>;
        codecOrThrow(): $Codec<T>;
        codec(): $Codec<T>;
        ignoreSwapAnimation(): boolean;
        isTransient(): boolean;
        streamCodec(): $StreamCodec<any, T>;
        static CODEC: $Codec<$DataComponentType<any>>;
        static PERSISTENT_CODEC: $Codec<$DataComponentType<any>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentType<any>>;
        static VALUE_MAP_CODEC: $Codec<$Map<$DataComponentType<any>, object>>;
    }

    export class $DataComponentType$Builder<T> {
        constructor();
        build(): $DataComponentType<T>;
        cacheEncoding(): $DataComponentType$Builder<T>;
        ignoreSwapAnimation(): $DataComponentType$Builder<T>;
        networkSynchronized(streamCodec: $StreamCodec<any, T>): $DataComponentType$Builder<T>;
        persistent(codec: $Codec<T>): $DataComponentType$Builder<T>;
    }

    export class $PatchedDataComponentMap implements $DataComponentMap {
        constructor(prototype: $DataComponentMap);
        static fromPatch(prototype: $DataComponentMap, patch: $DataComponentPatch): $PatchedDataComponentMap;
        applyPatch(patch: $DataComponentPatch): void;
        asPatch(): $DataComponentPatch;
        clearPatch(): void;
        copy(): $PatchedDataComponentMap;
        equals(obj: object): boolean;
        get<T>(type: $DataComponentType<T>): T;
        hasNonDefault(type: $DataComponentType<any>): boolean;
        hashCode(): number;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        remove<T>(type: $DataComponentType<T>): T;
        restorePatch(patch: $DataComponentPatch): void;
        set<T>(type: $DataComponentType<T>, value: T): T;
        set<T>(value: $TypedDataComponent<T>): T;
        size(): number;
        toImmutableMap(): $DataComponentMap;
        toString(): string;
    }

    export class $TypedDataComponent<T> extends $Record {
        constructor(type: $DataComponentType<T>, value: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $TypedDataComponent<any>>;
        static createUnchecked<T>(type: $DataComponentType<T>, value: object): $TypedDataComponent<T>;
        applyTo(components: $PatchedDataComponentMap): void;
        encodeValue<D>(ops: $DynamicOps<D>): $DataResult<D>;
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $DataComponentType<T>;
        value(): T;
    }

}
