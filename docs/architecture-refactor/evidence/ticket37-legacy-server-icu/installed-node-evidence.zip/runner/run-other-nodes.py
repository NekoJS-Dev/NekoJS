import concurrent.futures
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else 'build/ticket37-ec7-installed-nodes').resolve()
assert root.parent == (Path.cwd() / 'build').resolve() and not root.is_symlink()
nodes = [
    ('1.21.1', '21.1.227', 'jdk-21.0.10'),
    ('26.1.2', '26.1.2.71', 'jdk-25.0.2'),
    ('26.1.2-fabric', None, 'jdk-25.0.2'),
    ('26.2.0-fabric', None, 'jdk-25.0.2'),
]
selected = [arg for arg in sys.argv[2:] if arg != '--skip-install']
if selected:
    nodes = [entry for entry in nodes if entry[0] in selected]
assert nodes
for node, version, runtime in nodes:
    assert not (root / node / 'owned-process.json').exists(), 'Preserve existing server ownership'

def install(entry):
    node, version, runtime = entry
    directory = root / node
    java = f'C:/Program Files/Java/{runtime}/bin/java.exe'
    with (directory / 'installer-repeat-stdout.log').open('xb') as out, (directory / 'installer-repeat-stderr.log').open('xb') as err:
        result = subprocess.run([java, '-jar', str(root / f'downloads/neoforge-{version}-installer.jar'), '--installServer'], cwd=directory, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
    (directory / 'installer-repeat-exit.json').write_text(json.dumps(dict(node=node, exitCode=result.returncode)))
    print('INSTALLER_REPEAT_EXIT', node, result.returncode, flush=True)
    assert result.returncode == 0

if '--skip-install' not in sys.argv:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        for result in executor.map(install, [entry for entry in nodes if entry[1] is not None]):
            pass
servers = []
for node, version, runtime in nodes:
    directory = root / node
    java = f'C:/Program Files/Java/{runtime}/bin/java.exe'
    arguments = [java, '-Xms512M', '-Xmx2G']
    arguments += ['-jar', 'fabric-server-launch.jar', 'nogui'] if version is None else [f'@libraries/net/neoforged/neoforge/{version}/win_args.txt', 'nogui']
    with (directory / 'server-stdout.log').open('xb') as out, (directory / 'server-stderr.log').open('xb') as err:
        process = subprocess.Popen(arguments, cwd=directory, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
    (directory / 'owned-process.json').write_text(json.dumps(dict(node=node, pid=process.pid, executable=java, arguments=arguments, directory=str(directory)), indent=2))
    servers.append((node, process))
    print('SERVER_STARTED', node, process.pid, flush=True)
for node, process in servers:
    code = process.wait()
    (root / node / 'server-exit.json').write_text(json.dumps(dict(node=node, exitCode=code)))
    print('SERVER_EXIT', node, code, flush=True)
