$ErrorActionPreference='Stop'
$project='D:\mcmodDemo\NekoJS-mult'
$root=Join-Path $project 'build\ticket37-ec7-installed-nodes'
$manifest=Get-Content -LiteralPath (Join-Path $root 'preparation-manifest.json') -Raw | ConvertFrom-Json
foreach($path in @($project,(Join-Path $project 'build'),$root)) {
    $item=Get-Item -LiteralPath $path -Force
    if($item.FullName -ne [IO.Path]::GetFullPath($path) -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Unexpected owned node root'}
}
if(@(Get-CimInstance Win32_Process -Filter "Name='java.exe'" | Where-Object {$_.CommandLine -and $_.CommandLine.Contains($root)}).Count -ne 0){throw 'Existing owned node process'}
if(@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object {$_.LocalPort -in 25921,25922,25931,25932,25941,25942,25951,25952}).Count -ne 0){throw 'Owned node ports occupied'}
foreach($artifact in $manifest.artifacts){
    $jar=Join-Path $root "$($artifact.node)\mods\$($artifact.file)"
    if((Get-FileHash -LiteralPath $jar).Hash -ne $artifact.sha256){throw 'Installed artifact changed'}
}
$installers=@()
foreach($entry in @(@('1.21.1','21.1.227','jdk-21.0.10'),@('26.1.2','26.1.2.71','jdk-25.0.2'))){
    $node=$entry[0];$version=$entry[1];$java="C:\Program Files\Java\$($entry[2])\bin\java.exe"
    $server=Join-Path $root $node
    if(Test-Path -LiteralPath (Join-Path $server 'installer-stdout.log')){throw 'Preserve installer output'}
    $installer=Join-Path $root "downloads\neoforge-$version-installer.jar"
    $process=Start-Process -FilePath $java -WindowStyle Hidden -ArgumentList @('-jar',$installer,'--installServer') -WorkingDirectory $server -RedirectStandardOutput (Join-Path $server 'installer-stdout.log') -RedirectStandardError (Join-Path $server 'installer-stderr.log') -PassThru
    $installers+=@{node=$node;process=$process}
    Write-Output "INSTALLER_STARTED node=$node pid=$($process.Id)"
}
foreach($entry in $installers){
    $process=$entry.process
    while(-not $process.HasExited){Start-Sleep -Milliseconds 500;$process.Refresh()}
    $process.WaitForExit()
    Write-Output "INSTALLER_EXIT node=$($entry.node) code=$($process.ExitCode)"
    if($process.ExitCode -ne 0){throw 'Installer failed; preserve output'}
}
$servers=@()
foreach($node in @('1.21.1','26.1.2','26.1.2-fabric','26.2.0-fabric')){
    $server=Join-Path $root $node
    if(Test-Path -LiteralPath (Join-Path $server 'server-stdout.log')){throw 'Preserve server output'}
    $java=if($node -eq '1.21.1'){'C:\Program Files\Java\jdk-21.0.10\bin\java.exe'}else{'C:\Program Files\Java\jdk-25.0.2\bin\java.exe'}
    $arguments=@('-Xms512M','-Xmx2G')
    if($node -like '*-fabric'){$arguments+=@('-jar','fabric-server-launch.jar','nogui')}
    else{$version=if($node -eq '1.21.1'){'21.1.227'}else{'26.1.2.71'};$arguments+=@("@libraries/net/neoforged/neoforge/$version/win_args.txt",'nogui')}
    $process=Start-Process -FilePath $java -WindowStyle Hidden -ArgumentList $arguments -WorkingDirectory $server -RedirectStandardOutput (Join-Path $server 'server-stdout.log') -RedirectStandardError (Join-Path $server 'server-stderr.log') -PassThru
    $servers+=@{node=$node;process=$process}
    Write-Output "SERVER_STARTED node=$node pid=$($process.Id)"
    @{node=$node;pid=$process.Id;executable=$java;arguments=$arguments;directory=$server}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $server 'owned-process.json') -Encoding utf8
}
foreach($entry in $servers){
    $process=$entry.process
    while(-not $process.HasExited){Start-Sleep -Milliseconds 500;$process.Refresh()}
    $process.WaitForExit()
    Write-Output "SERVER_EXIT node=$($entry.node) code=$($process.ExitCode)"
    @{node=$entry.node;exitCode=$process.ExitCode}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $root "$($entry.node)\server-exit.json") -Encoding utf8
}
