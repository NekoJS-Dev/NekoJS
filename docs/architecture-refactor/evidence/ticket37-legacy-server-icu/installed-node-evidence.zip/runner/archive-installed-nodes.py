import hashlib
import json
import gzip
import re
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
repair = root / 'build/ticket37-config-sync-repair'
managed = Path('C:/Users/11515/.codex/worktrees/config-sync-validation/NekoJS-mult')
revision = '0d06a6fb35a52a2c0d334e3d8f31f97c922ee55c'
assert subprocess.check_output(['git', '-C', str(managed), 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', '-C', str(managed), 'status', '--porcelain'], text=True).strip()
sha = lambda data: hashlib.sha256(data).hexdigest()
write_json = lambda path, data: path.write_bytes((json.dumps(data, indent=2) + '\n').encode())
dest = root / 'docs/architecture-refactor/evidence/ticket37-legacy-server-icu'
assert not (dest / 'manifest.json').exists(), 'Preserve completed evidence'
projects = ['common', 'common-api-processor'] + ['versions/' + n for n in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']]
counts = []
with ZipFile(dest / 'full-matrix-ordinary-xml.zip', 'w', ZIP_DEFLATED) as archive:
    for project in projects:
        row = dict(project=project, xml=0, tests=0, skipped=0, failures=0, errors=0)
        for path in sorted((managed / project / 'build/test-results/test').glob('TEST-*.xml')):
            suite = ET.parse(path).getroot()
            row['xml'] += 1
            for key in ['tests', 'skipped', 'failures', 'errors']:
                row[key] += int(suite.get(key, 0))
            archive.writestr(path.relative_to(managed).as_posix(), path.read_bytes())
        counts.append(row)
totals = {k: sum(r[k] for r in counts) for k in ['xml', 'tests', 'skipped', 'failures', 'errors']}
assert totals['tests'] == 4587 and totals['failures'] == totals['errors'] == 0, totals
summary = dict(source=revision, projects=counts, total=totals, note='Ordinary test report snapshot; cached/up-to-date results are included, not claimed as fresh executions.')
write_json(dest / 'test-summary.json', summary)

roots = [root / 'build' / name for name in ['ticket37-ec7-installed-nodes', 'ticket37-ec7-installed-nodes-attempt2', 'ticket37-legacy-server-icu-installed']]
secrets = []
for trial in roots:
    for props in trial.glob('*/server.properties'):
        for line in props.read_text(encoding='utf-8-sig').splitlines():
            if line.startswith('rcon.password=') and line.partition('=')[2]:
                secrets.append(line.partition('=')[2].encode())

def checked(path):
    data = path.read_bytes()
    scanned = gzip.decompress(data) if path.suffix == '.gz' else data
    assert not any(secret in scanned for secret in secrets), path
    assert not re.search(rb'(?m)^rcon\.password=', scanned), path
    return data

files = []
artifacts = []
verdicts = []
for trial in roots:
    for path in trial.glob('*.json'):
        files.append((path, trial.name + '/' + path.name))
    for node in sorted(trial.iterdir()):
        if not node.is_dir():
            continue
        for path in node.glob('*.json'):
            if path.name not in ['banned-ips.json', 'banned-players.json', 'ops.json', 'whitelist.json', 'usercache.json']:
                files.append((path, path.relative_to(root / 'build').as_posix()))
        for path in node.glob('*.log'):
            files.append((path, path.relative_to(root / 'build').as_posix()))
        for name in ['command-proof.txt', 'jsconfig.json', 'pyrightconfig.json']:
            path = node / name
            if path.is_file():
                files.append((path, path.relative_to(root / 'build').as_posix()))
        for folder in ['logs', 'crash-reports', '.neko_probe', 'nekojs', 'config/nekojs']:
            for path in (node / folder).rglob('*'):
                if path.is_file() and path.suffix in ['.log', '.txt', '.js', '.mjs', '.ts', '.pyi', '.py', '.json', '.toml', '.gz']:
                    files.append((path, path.relative_to(root / 'build').as_posix()))
        for jar in (node / 'mods').glob('nekojs-*.jar'):
            independently_built = managed / 'versions' / node.name / 'build/libs' / jar.name
            assert independently_built.is_file(), jar.name
            assert independently_built.read_bytes() == jar.read_bytes(), jar.name
            artifacts.append(dict(trial=trial.name, node=node.name, file=jar.name, sha256=sha(jar.read_bytes()), bytes=jar.stat().st_size, exactCommitRebuildMatches=True))
        verdict_file = node / 'runtime-verdict.json'
        if verdict_file.is_file():
            verdict = json.loads(verdict_file.read_text())
            verdicts.append(dict(trial=trial.name, node=node.name, checks=verdict['checks'], verdict=verdict['verdict']))

for name in ['prepare-other-nodes.py', 'prepare-other-nodes.txt', 'install-and-launch-other-nodes.ps1', 'install-and-launch-other-nodes.txt', 'run-other-nodes.py', 'run-other-nodes.txt', 'configure-other-node-proofs.py', 'prove-other-nodes.py', 'prove-other-nodes.txt', 'run-other-nodes-attempt2.txt', 'prove-other-nodes-attempt2.txt', 'run-legacy-server-variant.txt', 'prove-legacy-server-variant.txt', 'legacy-server-artifact-first.txt', 'legacy-server-full-matrix.txt', 'legacy-variant-byte-check.json', 'archive-installed-nodes.py']:
    files.append((repair / name, 'runner/' + name))
entries = []
seen = set()
archive_path = dest / 'installed-node-evidence.zip'
with ZipFile(archive_path, 'w', ZIP_DEFLATED) as archive:
    for path, name in sorted(files, key=lambda pair: pair[1]):
        if name in seen:
            continue
        seen.add(name)
        data = checked(path)
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in entries:
        assert sha(archive.read(record['path'])) == record['sha256']
manifest = dict(packagingSource=revision, unchangedRuntimeSource='ec7fe6848afc1970661ee1f38a7c7c6d4575530c', testSummary=summary, artifacts=artifacts, verdicts=verdicts, archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes())), entries=entries, exclusions=['server.properties and RCON credentials', 'worlds', 'launcher/account files', 'raw JFR', 'game libraries and binaries'])
write_json(dest / 'manifest.json', manifest)
(dest / 'legacy-server-full-matrix.txt').write_bytes(checked(repair / 'legacy-server-full-matrix.txt'))
(dest / '.gitattributes').write_bytes(b'*.txt -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\n')
print(json.dumps(dict(tests=totals, entries=len(entries), artifactMatches=len(artifacts), archiveSha256=manifest['archive']['sha256'])))
