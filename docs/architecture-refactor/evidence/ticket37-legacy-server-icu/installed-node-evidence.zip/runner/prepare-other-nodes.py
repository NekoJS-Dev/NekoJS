import hashlib
import json
import shutil
import subprocess
import urllib.request
from pathlib import Path

project = Path.cwd()
source = Path('C:/Users/11515/.codex/worktrees/config-sync-validation/NekoJS-mult')
root = project / 'build/ticket37-ec7-installed-nodes'
revision = 'ec7fe6848afc1970661ee1f38a7c7c6d4575530c'
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True).strip()
assert not root.exists(), 'Preserve installed node evidence'
root.mkdir()
downloads = root / 'downloads'
downloads.mkdir()
manifest = dict(source=revision, artifacts=[], downloads=[])

def download(url, target):
    request = urllib.request.Request(url, headers={'User-Agent': 'NekoJS-owned-acceptance'})
    with urllib.request.urlopen(request, timeout=45) as response:
        data = response.read()
    target.write_bytes(data)
    manifest['downloads'].append(dict(url=url, file=target.name, size=len(data), sha256=hashlib.sha256(data).hexdigest()))

nodes = [
    ('1.21.1', 'neoforge', '21.1.227', 25921),
    ('26.1.2', 'neoforge', '26.1.2.71', 25931),
    ('26.1.2-fabric', 'fabric', '0.19.3', 25941),
    ('26.2.0-fabric', 'fabric', '0.19.5', 25951),
]
for node, loader, version, port in nodes:
    server = root / node
    server.mkdir()
    for relative in ['mods', 'nekojs/config', 'nekojs/startup_scripts', 'nekojs/server_scripts']:
        (server / relative).mkdir(parents=True, exist_ok=True)
    jars = list((source / f'versions/{node}/build/libs').glob('*.jar'))
    assert len(jars) == 1
    jar = jars[0]
    shutil.copyfile(jar, server / 'mods' / jar.name)
    manifest['artifacts'].append(dict(node=node, file=jar.name, size=jar.stat().st_size, sha256=hashlib.sha256(jar.read_bytes()).hexdigest()))
    graal = project / ('build/issue4-server-fabric/mods/graal-1504336-8762963.jar' if loader == 'fabric' else 'build/ticket15-startup-reviewed-installed-26.2/mods/graal-1504336-8762962.jar')
    shutil.copyfile(graal, server / 'mods' / graal.name)
    shutil.copyfile(project / 'build/ticket15-startup-reviewed-installed-26.2/nekojs/config/engine.toml', server / 'nekojs/config/engine.toml')
    if loader == 'fabric':
        if node == '26.2.0-fabric':
            dependencies = Path('build/issue4-server-fabric')
            shutil.copyfile(dependencies / 'fabric-server-launch.jar', server / 'fabric-server-launch.jar')
            shutil.copyfile(dependencies / 'server.jar', server / 'server.jar')
            shutil.copytree(dependencies / 'versions', server / 'versions')
            (server / 'libraries').symlink_to((dependencies / 'libraries').resolve(), target_is_directory=True)
            api = dependencies / 'mods/fabric-api-0.159.0+26.2.jar'
        else:
            game = '26.1.2'
            download(f'https://meta.fabricmc.net/v2/versions/loader/{game}/{version}/1.1.0/server/jar', server / 'fabric-server-launch.jar')
            api = next(p for p in (Path.home() / '.gradle/caches/modules-2/files-2.1/net.fabricmc.fabric-api/fabric-api/0.155.2+26.1.2').rglob('*.jar') if not p.name.endswith('-sources.jar'))
        shutil.copyfile(api, server / 'mods' / api.name)
    else:
        installer = downloads / f'neoforge-{version}-installer.jar'
        download(f'https://maven.neoforged.net/releases/net/neoforged/neoforge/{version}/neoforge-{version}-installer.jar', installer)

    (server / 'eula.txt').write_text('eula=true\n')
    import secrets
    credential = secrets.token_hex(24)
    (server / 'server.properties').write_text('\n'.join(['server-ip=127.0.0.1', f'server-port={port}', 'enable-rcon=true', f'rcon.port={port+1}', f'rcon.password={credential}', 'level-name=owned-installed-proof', 'online-mode=false', 'view-distance=2', 'simulation-distance=2', 'spawn-protection=0']) + '\n')
    startup = """RegistryEvents.register(event => {
    event.soundEvent('installed_ec7:nullable', build => { build.fixedRange = null; });
    event.soundEvent('installed_ec7:named', 'basic', build => { build.setFixedRange(null); });
    event.item('installed_ec7:token', build => { build.maxStackSize = 16; });
    event.block('installed_ec7:stone', build => { build.item.maxStackSize = 16; });
    event.block('installed_ec7:no_item', build => { build.noItem(); });
"""
    if loader == 'neoforge':
        startup += "    event.fluid('installed_ec7:spring', build => { build.lightLevel = 5; });\n    event.fluid('installed_ec7:bare', build => { build.noBlock(); build.noBucket(); });\n"
    startup += "    console.info('EC7-INSTALLED-STARTUP-CALLBACKS-PASS');\n});\n"
    (server / 'nekojs/startup_scripts/proof-startup.js').write_text(startup)
    if loader == 'neoforge' and node != '1.21.1':
        dynamic = (project / 'build/ticket15-startup-reviewed-installed-26.2/nekojs/server_scripts/proof-dynamic.js').read_text().replace('ticket37_b7:', 'installed_ec7:')
        (server / 'nekojs/server_scripts/proof-dynamic.js').write_text(dynamic)
    manifest_path = root / 'preparation-manifest.json'
    manifest_path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
    print('PREPARED', node, 'PORT', port, flush=True)
print('PREPARATION_COMPLETE', flush=True)
