from pathlib import Path
import sys

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('build/ticket37-ec7-installed-nodes')
for node in sys.argv[2:] or ['1.21.1', '26.1.2', '26.1.2-fabric', '26.2.0-fabric']:
    server = root / node
    assert not (server / 'server-stdout.log').exists(), 'Configure before the first boot'
    old = node == '1.21.1'
    fabric = node.endswith('-fabric')
    checks = [
        ['minecraft:sound_event', 'nullable', True], ['minecraft:sound_event', 'named', True],
        ['minecraft:item', 'token', True], ['minecraft:block', 'stone', True],
        ['minecraft:item', 'stone', True], ['minecraft:block', 'no_item', True],
        ['minecraft:item', 'no_item', False],
    ]
    if not fabric:
        checks += [
            ['minecraft:fluid', 'spring', True], ['minecraft:fluid', 'flowing_spring', True],
            ['minecraft:block', 'spring', True], ['minecraft:item', 'spring_bucket', True],
            ['minecraft:fluid', 'bare', True], ['minecraft:block', 'bare', False],
            ['minecraft:item', 'bare_bucket', False],
        ]
    import json
    script = f"const Location = Java.type('net.minecraft.resources.{'ResourceLocation' if old else 'Identifier'}');\n"
    script += "const builtin = Java.type('net.minecraft.core.registries.BuiltInRegistries');\n"
    script += f"const checks = {json.dumps(checks)};\n"
    script += """for (const check of checks) {
    const registry = builtin.REGISTRY.getValue(Location.parse(check[0]));
    if (registry.containsKey(Location.parse('installed_ec7:' + check[1])) !== check[2]) {
        throw new Error('Installed registration mismatch: ' + check[0] + '/' + check[1]);
    }
}
console.info('EC7-INSTALLED-REGISTRATIONS-PASS checks=' + checks.length);
"""
    if old:
        script = script.replace('builtin.REGISTRY.getValue(', 'builtin.REGISTRY.get(')
    script += """const BlockBuilder = Java.type('com.tkisor.nekojs.wrapper.registry.gen.BlockBuilder');
const Surface = Java.type('com.tkisor.nekojs.wrapper.registry.gen.BuilderSurface');
const Fingerprints = Java.type('com.tkisor.nekojs.wrapper.registry.gen.StartupRegistryRuntime');
const propertyBuilder = new BlockBuilder(Location.parse('installed_ec7:fingerprint_only'));
const setterBuilder = new BlockBuilder(Location.parse('installed_ec7:fingerprint_only'));
const propertySurface = Surface.of(propertyBuilder);
const setterSurface = Surface.of(setterBuilder);
propertySurface.item.maxStackSize = 16;
setterSurface.item.setMaxStackSize(16);
const fingerprints = new Fingerprints('owned-installed-fingerprint');
const propertyFingerprint = fingerprints.definitionFingerprint(propertyBuilder);
const setterFingerprint = fingerprints.definitionFingerprint(setterBuilder);
if (propertyFingerprint !== setterFingerprint) throw new Error('Actual nested builder fingerprints differ');
setterSurface.item.maxStackSize = 15;
const changedFingerprint = fingerprints.definitionFingerprint(setterBuilder);
if (propertyFingerprint === changedFingerprint) throw new Error('Nested mutation is absent from the actual fingerprint');
console.info('EC7-INSTALLED-NESTED-FINGERPRINT-PASS property=' + propertyFingerprint
    + ' setter=' + setterFingerprint + ' changed=' + changedFingerprint);
"""
    if not fabric:
        accessor = 'get' if old else 'getValue'
        script += f"""const neoRegistries = Java.type('net.neoforged.neoforge.registries.NeoForgeRegistries');
const sourceFluid = builtin.FLUID.{accessor}(Location.parse('installed_ec7:spring'));
const flowingFluid = builtin.FLUID.{accessor}(Location.parse('installed_ec7:flowing_spring'));
const registeredType = neoRegistries.FLUID_TYPES.{accessor}(Location.parse('installed_ec7:spring'));
if (!sourceFluid.getFluidType().equals(registeredType) || !flowingFluid.getFluidType().equals(registeredType)) {{
    throw new Error('Source, flowing and registered FluidType identities differ');
}}
console.info('EC7-INSTALLED-FLUIDTYPE-IDENTITY-PASS source=true flowing=true');
"""
    (server / 'nekojs/server_scripts/proof-startup-check.js').write_text(script, encoding='utf-8')
print('OTHER_NODE_PROOFS_CONFIGURED')
