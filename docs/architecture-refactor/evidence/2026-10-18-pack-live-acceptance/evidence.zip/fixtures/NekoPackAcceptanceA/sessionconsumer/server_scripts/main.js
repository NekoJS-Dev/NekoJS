const stamp = Pack.require('sessionprobe', 'worldstamp')({});
if (stamp.world !== 'A' || stamp.count !== 1) throw Error('World package state was not rebuilt');
console.info('NEKO_WORLD_ACCEPTANCE side=server world=A pack=sessionconsumer event=capability world=' + stamp.world + ' count=' + stamp.count + ' providerActivation=' + stamp.activation);
