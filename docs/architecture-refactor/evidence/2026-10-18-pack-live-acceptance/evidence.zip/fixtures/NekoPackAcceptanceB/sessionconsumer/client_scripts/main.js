const stamp = Pack.require('sessionprobe', 'worldstamp')({});
if (stamp.world !== 'B' || stamp.count !== 1) throw Error('World package state was not rebuilt');
console.info('NEKO_WORLD_ACCEPTANCE side=client world=B pack=sessionconsumer event=capability world=' + stamp.world + ' count=' + stamp.count + ' providerActivation=' + stamp.activation);
