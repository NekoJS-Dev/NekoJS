global.count = (global.count || 0) + 1;
globalThis.privatePayload = new Array(4096).fill('payload');
const activation = Pack.activation;
const prefix = 'NEKO_WORLD_ACCEPTANCE side=server world=B pack=sessionprobe activation=' + activation;
console.info(prefix + ' event=entry count=' + global.count);
Pack.provide('worldstamp', data => ({world:'B', count:global.count, activation:activation}));
let ticks = 0;
ServerEvents.tickPost(event => {
    ticks++;
    if (ticks === 1 || ticks % 100 === 0) console.info(prefix + ' event=tick n=' + ticks);
});
setInterval(() => console.info(prefix + ' event=timer'), 2000);
