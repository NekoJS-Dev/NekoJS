"""Assert remote callbacks stop in a bounded window after a real disconnect."""
import datetime
import json
import sys
import time
import urllib.request
from pathlib import Path

root = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance')
stage = sys.argv[1]
assert stage.isalnum()
output = root / ('signed-quiet-' + stage + '.json')
assert not output.exists()
log = root / 'client-launch-7.log'
before = log.read_bytes()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
time.sleep(8)
status = json.load(urllib.request.urlopen('http://127.0.0.1:9876/api/status'))
assert status['pid'] == 25128
after = log.read_bytes()
assert after.startswith(before)
unexpected = [line for line in after[len(before):].decode(errors='replace').splitlines() if 'NEKO_SIGNED_ACCEPTANCE' in line]
result = dict(stage=stage, pid=status['pid'], startedAtUtc=started,
              completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              startByte=len(before), endByte=len(after), observedSeconds=8,
              unexpected=unexpected, passed=not unexpected)
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
assert not unexpected, 'Remote callback continued after disconnect'
