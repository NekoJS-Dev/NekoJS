"""Compile and validate owned acceptance inputs; never print local server credentials."""
import hashlib
import json
import secrets
import shutil
import socket
import subprocess
import sys
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
root=tools/'client-world-acceptance'
assert root.is_dir() and not (root/'network-preparation.json').exists()
classpath=(tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text().strip()
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
resume='--resume-after-fixture-correction' in sys.argv
classes=root/'signing-helper-classes';classes.mkdir(exist_ok=resume)
stages=[]
prefix='attempt2-' if resume else ''
def run(name,command):
    with (root/(prefix+name+'.log')).open('xb') as out,(root/(prefix+name+'-stderr.log')).open('xb') as err:
        result=subprocess.run(command,cwd=project,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    stages.append(dict(stage=name,exitCode=result.returncode))
    (root/'network-preparation-stages.json').write_text(json.dumps(stages,indent=2)+'\n')
    assert result.returncode==0,name

if not resume:
    run('signer-compile',[str(java/'javac.exe'),'-encoding','UTF-8','-cp',classpath,'-d',str(classes),str(tools/'PrepareSignedAcceptance.java')])
    run('signer-run',[str(java/'java.exe'),'-cp',str(classes)+';'+classpath,'com.tkisor.nekojs.core.pack.sync.PrepareSignedAcceptance',str(root)])
else:
    assert (root/'initial-preparation-stages.json').exists() and json.loads((root/'signature-preparation.json').read_text())['validSignature']
packs=list((root/'game/saves').glob('*/nekojs_packs/*'))+[root/'server/nekojs/packs/signedacceptance']
for index,pack in enumerate(packs):
    run('pack-validate-'+str(index),[str(java/'java.exe'),'-cp',classpath,'com.tkisor.nekojs.core.pack.tool.PackToolMain','validate',str(pack)])
for index,path in enumerate(sorted((root/'game').rglob('*.js'))+sorted((root/'server').rglob('*.js'))):
    run('syntax-'+str(index),['C:/Program Files/nodejs/node.exe','--check',str(path)])
config='[packSync]\nmode = "all"\nallowUnsigned = false\n'
for location in ['game','server']:
    folder=root/location/'nekojs/config';folder.mkdir(parents=True,exist_ok=True)
    (folder/'engine.toml').write_text(config,encoding='utf-8')
server=root/'server'
shutil.copytree(project/'build/script-pack-native-final/neo262/world',server/'world',ignore=shutil.ignore_patterns('session.lock','nekojs_packs'))
for port in [25873,25874]:
    with socket.socket() as probe:probe.bind(('127.0.0.1',port))
(server/'eula.txt').write_text('eula=true\n')
credential=secrets.token_urlsafe(24)
(server/'server.properties').write_text('server-ip=127.0.0.1\nserver-port=25873\nenable-rcon=true\nrcon.port=25874\nrcon.password='+credential+'\nonline-mode=false\nlevel-name=world\nview-distance=3\nsimulation-distance=3\nspawn-protection=0\n',encoding='utf-8')
shutil.copy2(server/'nekojs/packs/signedacceptance/manifest.json',root/'valid-signed-manifest.json')
shutil.copy2(server/'nekojs/packs/signedacceptance/client_scripts/main.js',root/'valid-signed-client.js')
result=dict(preparedOnly=True,ports=[25873,25874],unsignedAllowed=False,serverTrustGranted=False,
    packValidationCount=len(packs),syntaxChecks=sum(row['stage'].startswith('syntax-') for row in stages),stages=stages,
    sourceHelpers={name:hashlib.sha256((tools/name).read_bytes()).hexdigest() for name in ['PrepareSignedAcceptance.java','prepare-client-network-inputs.py','prepare-client-world-acceptance.py']})
(root/'network-preparation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(preparedOnly=True,packValidationCount=result['packValidationCount'],syntaxChecks=result['syntaxChecks'],allStagesPassed=True,privateKeyDistributed=False,networkVerified=False)))
