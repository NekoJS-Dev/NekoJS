package com.tkisor.nekojs.core.pack.sync;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.Signature;
import java.util.Map;

/** One-shot fixture preparation; private key material stays outside the distributed pack. */
public final class PrepareSignedAcceptance {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]).toAbsolutePath().normalize();
        Path pack = root.resolve("server/nekojs/packs/signedacceptance");
        Path key = root.resolve("server-only-signing/private.pk8");
        if (Files.exists(key) || Files.exists(pack)) throw new IllegalStateException("Preserve the existing acceptance fixture");
        Files.createDirectories(pack.resolve("client_scripts"));
        Files.createDirectories(key.getParent());
        String script = """
                const activation = Pack.activation;
                console.info('NEKO_SIGNED_ACCEPTANCE event=entry selector=' + Pack.selector + ' activation=' + activation);
                let ticks = 0;
                ClientEvents.tickPost(event => {
                    ticks++;
                    if (ticks === 1 || ticks % 100 === 0) console.info('NEKO_SIGNED_ACCEPTANCE event=tick activation=' + activation + ' n=' + ticks);
                });
                setInterval(() => console.info('NEKO_SIGNED_ACCEPTANCE event=timer activation=' + activation), 2000);
                """;
        Files.writeString(pack.resolve("client_scripts/main.js"), script, StandardCharsets.UTF_8);
        JsonObject manifest = JsonParser.parseString("""
                {"formatVersion":1,"id":"signedacceptance","version":"1.0.0","clientSync":true,"entries":{"client":["main.js"]}}
                """).getAsJsonObject();
        Files.writeString(pack.resolve("manifest.json"), manifest.toString(), StandardCharsets.UTF_8);
        var files = PackHasher.readContentFiles(pack);
        var pair = PackSigner.generateKeyPair();
        byte[] payload = PackSignaturePayload.build("packs:signedacceptance", "GLOBAL", manifest.toString(), files);
        JsonObject signed = PackSigner.sign("acceptance-local-20261018", pair, "packs:signedacceptance", "GLOBAL", manifest.toString(), files);
        byte[] signature = java.util.Base64.getDecoder().decode(signed.get("signature").getAsString());
        if (!verify(pair.getPublic(), payload, signature)) throw new AssertionError("Prepared signature must verify");
        byte[] changed = payload.clone(); changed[0] ^= 1;
        if (verify(pair.getPublic(), changed, signature)) throw new AssertionError("Changed payload must be rejected");
        manifest.add("signature", signed);
        String finalManifest = new GsonBuilder().setPrettyPrinting().create().toJson(manifest) + "\n";
        if (!verify(pair.getPublic(), PackSignaturePayload.build("packs:signedacceptance", "GLOBAL", finalManifest, files), signature))
            throw new AssertionError("Signature must cover the final canonical manifest");
        if (verify(pair.getPublic(), PackSignaturePayload.build("worldpacks:signedacceptance", "WORLD", finalManifest, files), signature))
            throw new AssertionError("Changed source scope must be rejected");
        Files.writeString(pack.resolve("manifest.json"), finalManifest, StandardCharsets.UTF_8);
        Files.write(key, pair.getPrivate().getEncoded(), StandardOpenOption.CREATE_NEW);
        Files.write(key.resolveSibling("public.spki"), pair.getPublic().getEncoded(), StandardOpenOption.CREATE_NEW);
        Files.writeString(root.resolve("signature-preparation.json"), new GsonBuilder().setPrettyPrinting().create().toJson(Map.of(
            "preparedOnly", true, "algorithm", "Ed25519", "keyId", "acceptance-local-20261018",
            "privateKeyDistributed", false, "validSignature", true, "changedPayloadRejected", true,
            "changedScopeRejected", true, "finalManifestHash", PackHasher.hash(Files.readAllBytes(pack.resolve("manifest.json")), files))) + "\n");
        System.out.println("SIGNED_FIXTURE_PREPARED_NOT_NETWORK_VERIFIED");
    }

    private static boolean verify(java.security.PublicKey key, byte[] payload, byte[] signature) throws Exception {
        Signature verifier = Signature.getInstance("Ed25519");
        verifier.initVerify(key); verifier.update(payload); return verifier.verify(signature);
    }
}
