"""Recompute actual world/session and signed-network assertions before freezing evidence."""
import hashlib
import json
import re
from pathlib import Path

root=Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance')
raw=(root/'client-launch-7.log').read_bytes()
log=raw.decode('utf-8-sig',errors='replace')
entries=re.findall(r'NEKO_WORLD_ACCEPTANCE side=(server|client) world=([AB]) pack=sessionprobe activation=(\d+) event=entry count=(\d+)',log)
worlds={}
for side in ['server','client']:
    rows=[dict(world=w,activation=int(a),count=int(c)) for s,w,a,c in entries if s==side]
    assert [row['world'] for row in rows]==['A','B','A','A'],rows
    assert all(row['count']==1 for row in rows)
    assert len({row['activation'] for row in rows})==4
    consumers=re.findall(r'NEKO_WORLD_ACCEPTANCE side='+side+r' world=([AB]) pack=sessionconsumer event=capability world=([AB]) count=(\d+) providerActivation=(\d+)',log)
    assert len(consumers)==4 and all(w==actual and int(count)==1 for w,actual,count,_ in consumers)
    assert [int(a) for *_,a in consumers]==[row['activation'] for row in rows]
    worlds[side]=rows
quiet=[]
for stage in ['a1','b1','a2','a3']:
    row=json.loads((root/('quiet-'+stage+'.json')).read_text())
    suffix=raw[row['startByte']:row['endByte']].decode(errors='replace')
    assert row['pid']==25128 and row['passed'] and row['observedSeconds']==8
    assert not any('NEKO_WORLD_ACCEPTANCE' in line and ('world='+row['world']) in line for line in suffix.splitlines())
    quiet.append(row)
signed=[int(n) for n in re.findall(r'NEKO_SIGNED_ACCEPTANCE event=entry selector=SERVER_CACHE:packs:signedacceptance activation=(\d+)',log)]
assert len(signed)==2 and signed[0]!=signed[1],signed
for activation in signed:
    assert f'NEKO_SIGNED_ACCEPTANCE event=tick activation={activation} n=1' in log
    assert f'NEKO_SIGNED_ACCEPTANCE event=timer activation={activation}' in log
assert 'NEKO_TAMPERED_CONTENT_MUST_NOT_EXECUTE' not in log
assert 'this server distributes signed script packs (kubernetes.docker.internal)' in log
checks=[('tamper1','restore1','signature mismatch for acceptance-local-20261018'),
        ('replacement1','restore2','embedded public key does not match pinned key')]
for start,end,reason in checks:
    first=json.loads((root/('signed-fixture-'+start+'.json')).read_text())['clientLogStartByte']
    last=json.loads((root/('signed-fixture-'+end+'.json')).read_text())['clientLogStartByte']
    window=raw[first:last].decode(errors='replace')
    assert reason in window and 'NEKO_SIGNED_ACCEPTANCE event=entry' not in window
for stage in ['valid1','valid2']:
    row=json.loads((root/('signed-quiet-'+stage+'.json')).read_text())
    assert row['passed'] and row['pid']==25128
    assert b'NEKO_SIGNED_ACCEPTANCE' not in raw[row['startByte']:row['endByte']]
original=json.loads((root/'valid-signed-manifest.json').read_text())
trust=json.loads((root/'game/nekojs/config/trusted-servers.json').read_text())
assert len(trust['trustedServers'])==len(trust['trustedKeys'])==1
assert trust['trustedKeys']['acceptance-local-20261018']['publicKey']==original['signature']['publicKey']
assert (root/'server/nekojs/packs/signedacceptance/manifest.json').read_bytes()==(root/'valid-signed-manifest.json').read_bytes()
assert (root/'server/nekojs/packs/signedacceptance/client_scripts/main.js').read_bytes()==(root/'valid-signed-client.js').read_bytes()
(root/'network-final-trust.json').write_text(json.dumps(trust,indent=2)+'\n')
memory=[]
for stage in ['a1','menu1','b1','menu2','a2','menu3','remotevalid2','menu4','menu4gc']:
    folder=root/('memory-'+stage)
    row=json.loads((folder/'process.json').read_text(encoding='utf-8-sig'))
    nmt=(folder/'nmt.log').read_text(encoding='utf-16')
    total=int(re.search(r'Total: reserved=\d+KB, committed=(\d+)KB',nmt).group(1))
    heap=int(re.search(r'Java Heap \(reserved=\d+KB, committed=(\d+)KB\)',nmt).group(1))
    assert row['pid']==25128
    memory.append(dict(stage=stage,**row,nmtTotalCommittedKiB=total,nmtHeapCommittedKiB=heap,
                       nmtNonHeapCommittedKiB=total-heap))
before=json.loads((root/'world-login-main-class-bindings.json').read_text())
after={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in before}
assert before==after,'Production class files changed during live acceptance'
(root/'production-class-final.json').write_text(json.dumps(after,indent=2)+'\n')
assert 'MCP_ACCEPTANCE_MANUAL_TAKEOVER active=true' in log
assert 'MCP_ACCEPTANCE_LIST_SELECTION_PATCH_V2' in log and 'MCP_ACCEPTANCE_NATIVE_SCREENSHOT_PATCH' in log
assert '[minecraft/Minecraft]: Stopping!' in log and 'MCP_ACCEPTANCE_TEST_HTTP_EXECUTOR_CLOSED terminated=true' in log
assert 'BUILD SUCCESSFUL' in log
server=(root/'server-launch-2.log').read_text(encoding='utf-8-sig',errors='replace')
assert 'Done (' in server and 'BUILD SUCCESSFUL' in server
result=dict(pid=25128,productionClasses=len(after),worldEntries=worlds,worldQuietWindows=quiet,
            signedActivations=signed,untrustedRejected=True,tamperedRejected=True,keyReplacementRejected=True,
            originalRestoredAndReconnected=True,finalPinMatchesOriginal=True,remoteQuietWindows=2,
            memory=memory,clientMenuExit=True,unassistedJvmExit=False,mcpExecutorCleanupRequired=True,
            clientGradleExitSuccessful=True,serverNormalStopSuccessful=True,gameTrustCommandVerified=False,
            maintainerAcceptance=None,perContextGameMemoryBudgetVerified=False)
(root/'live-acceptance-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['memory','worldQuietWindows']}))
print(json.dumps([dict(stage=x['stage'],privateMiB=round(x['privateBytes']/1048576,2),
                       nmtNonHeapMiB=round(x['nmtNonHeapCommittedKiB']/1024,2),threads=x['threads'],handles=x['handles']) for x in memory]))
