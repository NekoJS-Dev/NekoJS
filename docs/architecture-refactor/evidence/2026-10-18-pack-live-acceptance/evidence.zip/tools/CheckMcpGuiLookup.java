/** Verify the actual patched class, the GUI owner, null input, and the existing legacy field path. */
public final class CheckMcpGuiLookup {
    public static final class Gui {
        private Object screen = new Object();
        public Object screen() { return screen; }
        public void setScreen(Object value) { screen = value; }
    }
    public static final class ModernClient { public final Gui gui = new Gui(); public final Object screen = new Object(); }
    public static final class LegacyClient { public final Object screen = new Object(); }
    public static void main(String[] args) throws Exception {
        Class<?> cache = Class.forName("xyz.langyo.minecraft.mcp.common.ReflectionCache");
        var lookup = cache.getDeclaredMethod("getCurrentScreen", Object.class);
        lookup.setAccessible(true);
        ModernClient modern = new ModernClient();
        boolean original = args.length == 1 && args[0].equals("original");
        Object expected = original ? modern.screen : modern.gui.screen();
        if (lookup.invoke(null, modern) != expected) throw new AssertionError("Modern GUI owner lookup failed");
        modern.gui.setScreen(null);
        if (lookup.invoke(null, modern) != (original ? modern.screen : null)) throw new AssertionError("Modern empty screen must be authoritative");
        LegacyClient legacy = new LegacyClient();
        if (lookup.invoke(null, legacy) != legacy.screen) throw new AssertionError("Legacy lookup changed");
        try {
            lookup.invoke(null, new Object[]{null});
            throw new AssertionError("Expected the existing null-input rejection");
        } catch (java.lang.reflect.InvocationTargetException failure) {
            if (!(failure.getCause() instanceof NullPointerException)) throw failure;
        }
        if (!original) {
            modern.gui.setScreen(new Object());
            var helper = Class.forName("xyz.langyo.minecraft.mcp.common.PlayerWorldHelper");
            var close = helper.getDeclaredMethod("closeScreen", Object.class);
            close.setAccessible(true);
            close.invoke(null, modern);
            if (modern.gui.screen() != null) throw new AssertionError("Modern close-screen setter failed");
        }
        System.out.println("PATCHED_GUI_OWNER_AND_LEGACY_LOOKUP_PASS");
    }
}
