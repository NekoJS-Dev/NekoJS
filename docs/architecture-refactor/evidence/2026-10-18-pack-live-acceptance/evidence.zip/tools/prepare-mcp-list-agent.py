"""Build and verify the narrow list selection patch before attachment to the owned JVM."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project / 'build/priority-closeout'
run = tools / 'client-world-acceptance'
output = run / 'mcp-list-selection-v1'
assert not output.exists()
classes = output / 'classes'
classes.mkdir(parents=True)
patched = output / 'patched/xyz/langyo/minecraft/mcp/common/ScreenInteractionHelper.class'
patched.parent.mkdir(parents=True)
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
asm = Path('C:/Users/11515/.gradle/wrapper/dists/gradle-9.6.0-bin/42k10rwplmzkhuboz9kdazi7s/gradle-9.6.0/lib/asm-9.9.jar')
mcp = run / 'game/mods/minecraft-mcp-26.2-neoforge.jar'
original = output / 'ScreenInteractionHelper-original.class'
with zipfile.ZipFile(mcp) as data:
    original.write_bytes(data.read('xyz/langyo/minecraft/mcp/common/ScreenInteractionHelper.class'))
steps = []

def execute(stage, command):
    with (output / (stage + '.log')).open('xb') as stdout, (output / (stage + '-stderr.log')).open('xb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    steps.append(dict(stage=stage, exitCode=result.returncode))
    (output / 'steps.json').write_text(json.dumps(steps, indent=2) + '\n')
    assert result.returncode == 0, stage

sources = ['McpModernListSelection.java', 'PatchMcpListSelection.java', 'McpSelectionAgent.java',
           'AttachMcpSelectionAgent.java', 'CheckMcpModernListSelection.java']
execute('compile', [str(java/'javac.exe'), '--release', '25', '-encoding', 'UTF-8',
                    '-cp', str(asm) + ';' + str(mcp), '-d', str(classes), *[str(tools/name) for name in sources]])
execute('patch', [str(java/'java.exe'), '-cp', str(classes) + ';' + str(asm),
                  'PatchMcpListSelection', str(original), str(patched)])
execute('check', [str(java/'java.exe'), '-Xverify:all', '-cp', str(output/'patched') + ';' + str(classes) + ';' + str(mcp),
                  'CheckMcpModernListSelection'])
artifact = output / 'selection-agent.jar'
with zipfile.ZipFile(artifact, 'x', zipfile.ZIP_DEFLATED) as data:
    data.writestr('META-INF/MANIFEST.MF', 'Manifest-Version: 1.0\nAgent-Class: com.tkisor.nekojs.acceptance.mcp.McpSelectionAgent\nCan-Redefine-Classes: true\n\n')
    for name in ['McpSelectionAgent', 'McpModernListSelection']:
        file = classes / ('com/tkisor/nekojs/acceptance/mcp/' + name + '.class')
        data.write(file, file.relative_to(classes).as_posix())
binding = dict(targetPid=25128, attached=False, controlStateChanged=False,
               originalSha256=hashlib.sha256(original.read_bytes()).hexdigest(),
               patchedSha256=hashlib.sha256(patched.read_bytes()).hexdigest(),
               agentSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(), steps=steps)
(output / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
print(json.dumps(binding))
