package com.tkisor.nekojs.acceptance.tools;

import com.sun.net.httpserver.HttpServer;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

/** Releases only the owned MCP HTTP executor after the Minecraft render loop has stopped. */
public final class McpStopAgent {
    public static void agentmain(String ignored, Instrumentation instrumentation) throws Exception {
        if (ProcessHandle.current().pid() != 25128) throw new IllegalStateException("Owned client PID mismatch");
        if (Thread.getAllStackTraces().keySet().stream().anyMatch(thread -> thread.isAlive() && thread.getName().equals("Render thread"))) {
            throw new IllegalStateException("The Minecraft render loop is still running");
        }
        Class<?> entry = null;
        for (Class<?> type : instrumentation.getAllLoadedClasses()) {
            if (!type.getName().equals("xyz.langyo.minecraft.mcp.mod.ModDevMcpMod")) continue;
            if (entry != null) throw new IllegalStateException("Ambiguous owned MCP entry");
            entry = type;
        }
        if (entry == null) throw new IllegalStateException("Owned MCP entry is unavailable");
        Module agent = McpStopAgent.class.getModule();
        instrumentation.redefineModule(entry.getModule(), Set.of(agent), Map.of(),
                Map.of(entry.getPackageName(), Set.of(agent), "xyz.langyo.minecraft.mcp.common", Set.of(agent)), Set.of(), Map.of());
        Object mod = entry.getField("INSTANCE").get(null);
        Field bridgeField = entry.getDeclaredField("httpServer");
        bridgeField.setAccessible(true);
        Object bridge = bridgeField.get(mod);
        Field serverField = bridge.getClass().getDeclaredField("server");
        serverField.setAccessible(true);
        HttpServer server = (HttpServer) serverField.get(bridge);
        if (!(server.getExecutor() instanceof ExecutorService executor)) throw new IllegalStateException("Unexpected owned MCP executor");
        bridge.getClass().getMethod("stop").invoke(bridge);
        executor.shutdown();
        if (!executor.awaitTermination(5, TimeUnit.SECONDS)) executor.shutdownNow();
        System.out.println("MCP_ACCEPTANCE_TEST_HTTP_EXECUTOR_CLOSED terminated=" + executor.isTerminated());
    }
}
