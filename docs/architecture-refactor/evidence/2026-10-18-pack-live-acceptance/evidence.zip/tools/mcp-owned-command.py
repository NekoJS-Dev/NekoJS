"""Operate only the manually activated, PID-bound isolated acceptance client."""
import base64
import datetime
import json
import sys
import urllib.request
from pathlib import Path

root = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance')
status = json.load(urllib.request.urlopen('http://127.0.0.1:9876/api/status', timeout=10))
assert status['pid'] == 25128 and status['type'] == 'minecraft-mod'
assert 'MCP_ACCEPTANCE_MANUAL_TAKEOVER active=true' in (root / 'client-launch-7.log').read_text(errors='replace')
command = sys.argv[1]
allowed = {'get_screen_buttons', 'enumerate_widgets', 'get_player_info', 'get_world_info', 'pause_game',
           'close_screen', 'click', 'click_button_index', 'select_list_item', 'press_key', 'type_text', 'execute_command'}
assert command in allowed or command == 'screenshot'
if command == 'screenshot':
    name = sys.argv[2]
    assert name.endswith('.png') and Path(name).name == name
    result = json.load(urllib.request.urlopen('http://127.0.0.1:9876/api/screenshot', timeout=10))
    (root / name).write_bytes(base64.b64decode(result['original'].split(',', 1)[1]))
    print(json.dumps({'pid': status['pid'], 'screenshot': name}))
else:
    parameters = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    assert isinstance(parameters, dict) and 'cmd' not in parameters
    payload = dict(cmd=command, **parameters)
    request = urllib.request.Request('http://127.0.0.1:9876/api/cmd', data=json.dumps(payload).encode(),
                                     headers={'Content-Type': 'application/json'})
    result = json.load(urllib.request.urlopen(request, timeout=30))
    record = dict(atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=status['pid'],
                  request=payload, response=result)
    with (root / 'owned-mcp-actions.jsonl').open('a', encoding='utf-8') as log:
        log.write(json.dumps(record, ensure_ascii=False) + '\n')
    if command == 'get_screen_buttons':
        print(json.dumps({'screen': result.get('screen'), 'buttonCount': len(result.get('buttons', []))}))
    else:
        print(json.dumps(result, ensure_ascii=False))
