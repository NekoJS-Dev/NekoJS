package com.tkisor.nekojs.acceptance.mcp;

import java.lang.instrument.ClassDefinition;
import java.lang.instrument.Instrumentation;
import java.lang.invoke.MethodHandles;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;
import java.util.Set;

/** Defines the adapter in the owned test mod's loader before replacing one MCP method. */
public final class McpScreenshotAgent {
    public static void agentmain(String arguments, Instrumentation instrumentation) throws Exception {
        if (ProcessHandle.current().pid() != 25128) throw new IllegalStateException("Owned client PID mismatch");
        String[] inputs = arguments.split("\\|", -1);
        if (inputs.length != 2) throw new IllegalArgumentException("Expected patch and helper files");
        Class<?> target = null, anchor = null;
        for (Class<?> type : instrumentation.getAllLoadedClasses()) {
            if (type.getName().equals("xyz.langyo.minecraft.mcp.common.ReflectedInputHandler")) {
                if (target != null) throw new IllegalStateException("Ambiguous MCP class loader");
                target = type;
            }
            if (type.getName().equals("com.tkisor.nekojs.acceptance.mcp.McpAcceptancePauseMenu")) {
                if (anchor != null) throw new IllegalStateException("Ambiguous test adapter class loader");
                anchor = type;
            }
        }
        if (target == null || anchor == null) throw new IllegalStateException("Owned test classes are not loaded");
        Module agent = McpScreenshotAgent.class.getModule();
        instrumentation.redefineModule(anchor.getModule(), Set.of(agent), Map.of(),
                Map.of(anchor.getPackageName(), Set.of(agent)), Set.of(), Map.of());
        MethodHandles.privateLookupIn(anchor, MethodHandles.lookup())
                .defineClass(Files.readAllBytes(Path.of(inputs[1])));
        instrumentation.redefineModule(target.getModule(), Set.of(anchor.getModule()),
                Map.of(), Map.of(), Set.of(), Map.of());
        byte[] bytes = Files.readAllBytes(Path.of(inputs[0]));
        instrumentation.redefineClasses(new ClassDefinition(target, bytes));
        System.out.println("MCP_ACCEPTANCE_NATIVE_SCREENSHOT_PATCH sha256="
                + HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)));
    }
}
