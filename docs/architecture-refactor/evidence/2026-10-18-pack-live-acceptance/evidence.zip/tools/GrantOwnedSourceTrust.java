import com.tkisor.nekojs.core.pack.sync.PackSyncTrustStore;
import com.google.gson.JsonParser;
import java.nio.file.Files;
import java.nio.file.Path;

/** Uses the same trust-store operation as the game command for the owned loopback fixture. */
public final class GrantOwnedSourceTrust {
    public static void main(String[] args) throws Exception {
        Path file = Path.of("D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance/game/nekojs/config/trusted-servers.json");
        String address = "kubernetes.docker.internal";
        if (Files.exists(file)) {
            JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            Files.copy(file, file.resolveSibling("trusted-servers.before-owned-acceptance.json"));
        }
        PackSyncTrustStore store = new PackSyncTrustStore(file);
        if (store.isServerTrusted(PackSyncTrustStore.bucketFor(address))) {
            throw new IllegalStateException("Source was already trusted before the owned grant");
        }
        if (store.trustedPublicKey("acceptance-local-20261018") != null) {
            throw new IllegalStateException("The owned signing key was already pinned");
        }
        store.trustServer(address);
        if (!store.isServerTrusted(PackSyncTrustStore.bucketFor(address))) {
            throw new IllegalStateException("Owned source trust was not persisted");
        }
        System.out.println("Granted only the observed loopback source; no signing key was pinned by this operation.");
    }
}
