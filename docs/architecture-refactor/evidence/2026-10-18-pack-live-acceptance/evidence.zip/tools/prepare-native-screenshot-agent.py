"""Build a capture adapter for the actual 26.2 render target without a client restart."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
run=tools/'client-world-acceptance'
output=run/'mcp-native-screenshot-v1'
assert not output.exists()
classes=output/'classes'
classes.mkdir(parents=True)
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
asm=Path('C:/Users/11515/.gradle/wrapper/dists/gradle-9.6.0-bin/42k10rwplmzkhuboz9kdazi7s/gradle-9.6.0/lib/asm-9.9.jar')
classpath=(run/'adapter-classpath.txt').read_text().strip()+';'+str(asm)
original=output/'ReflectedInputHandler-original.class'
patched=output/'ReflectedInputHandler-patched.class'
with zipfile.ZipFile(run/'game/mods/minecraft-mcp-26.2-neoforge.jar') as archive:
    original.write_bytes(archive.read('xyz/langyo/minecraft/mcp/common/ReflectedInputHandler.class'))
steps=[]
for name,command in [
    ('compile',[str(java/'javac.exe'),'-proc:none','-encoding','UTF-8','-cp',classpath,'-d',str(classes),
                 *[str(tools/name) for name in ['McpModernScreenshot.java','McpScreenshotAgent.java','AttachMcpScreenshotAgent.java','PatchMcpScreenshot.java']]]),
    ('patch',[str(java/'java.exe'),'-cp',str(classes)+';'+str(asm),'PatchMcpScreenshot',str(original),str(patched)])]:
    with (output/(name+'.log')).open('xb') as stdout,(output/(name+'-stderr.log')).open('xb') as stderr:
        result=subprocess.run(command,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    steps.append(dict(stage=name,exitCode=result.returncode))
    (output/'steps.json').write_text(json.dumps(steps,indent=2)+'\n')
    assert result.returncode==0,name
artifact=output/'capture-agent.jar'
with zipfile.ZipFile(artifact,'x',zipfile.ZIP_DEFLATED) as archive:
    archive.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nAgent-Class: com.tkisor.nekojs.acceptance.mcp.McpScreenshotAgent\nCan-Redefine-Classes: true\n\n')
    source=classes/'com/tkisor/nekojs/acceptance/mcp/McpScreenshotAgent.class'
    archive.write(source,source.relative_to(classes).as_posix())
binding=dict(targetPid=25128,controlStateChanged=False,applied=False,steps=steps,
             originalSha256=hashlib.sha256(original.read_bytes()).hexdigest(),
             patchedSha256=hashlib.sha256(patched.read_bytes()).hexdigest(),
             agentSha256=hashlib.sha256(artifact.read_bytes()).hexdigest())
(output/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
print(json.dumps(binding))
