package com.tkisor.nekojs.acceptance.mcp;

import java.lang.instrument.ClassDefinition;
import java.lang.instrument.Instrumentation;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;
import java.util.Set;

/** Applies one test-only method replacement to the already manually activated client. */
public final class McpSelectionAgent {
    public static void agentmain(String patchFile, Instrumentation instrumentation) throws Exception {
        if (ProcessHandle.current().pid() != 25128) throw new IllegalStateException("Owned client PID mismatch");
        Class<?> target = null;
        for (Class<?> type : instrumentation.getAllLoadedClasses()) {
            if (!type.getName().equals("xyz.langyo.minecraft.mcp.common.ScreenInteractionHelper")) continue;
            if (target != null) throw new IllegalStateException("Ambiguous MCP class loader");
            target = type;
        }
        if (target == null) throw new IllegalStateException("MCP screen helper is not loaded");
        byte[] bytes = Files.readAllBytes(Path.of(patchFile));
        instrumentation.redefineModule(target.getModule(), Set.of(McpModernListSelection.class.getModule()),
                Map.of(), Map.of(), Set.of(), Map.of());
        instrumentation.redefineClasses(new ClassDefinition(target, bytes));
        System.out.println("MCP_ACCEPTANCE_LIST_SELECTION_PATCH sha256="
                + HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)));
    }
}
