"""Repair only owned test dependency metadata; preserve every executable class byte."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

tools=Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout')
root=tools/'client-world-acceptance'
target=root/'metadata-repaired-dependencies'
assert not target.exists();target.mkdir()
classpath=(tools/'root-reload-diagnostic-v3/runtime-classpath.txt').read_text().strip()
graal=[Path(p) for p in classpath.split(';') if p.endswith('graal-1504336-8762962.jar')]
assert len(graal)==1
mcp=root/'game/mods/minecraft-mcp-26.2-neoforge.jar'
result={}
for label,original,entry in [('graalmc',graal[0],'META-INF/neoforge.mods.toml'),('mcp',mcp,'pack.mcmeta')]:
    before=target/(label+'-original.jar')
    shutil.copy2(original,before)
    output=target/(label+'-metadata-repaired.jar')
    with zipfile.ZipFile(before) as source,zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
        assert not any(name.upper().endswith(('.SF','.RSA','.DSA','.EC')) for name in source.namelist())
        for info in source.infolist():
            data=source.read(info.filename)
            if info.filename==entry:
                if label=='graalmc':
                    text=data.decode('utf-8');assert text.count('logoFile = "icon.png"')==1
                    data=text.replace('logoFile = "icon.png"','iconFile = "icon.png"').encode()
                else:
                    document=json.loads(data);assert document['pack']['pack_format']==88
                    document['pack'].update(min_format=88,max_format=88)
                    data=(json.dumps(document,indent=2)+'\n').encode()
            archive.writestr(info,data)
    with zipfile.ZipFile(before) as source,zipfile.ZipFile(output) as repaired:
        assert source.namelist()==repaired.namelist()
        changed=[name for name in source.namelist() if source.read(name)!=repaired.read(name)]
        assert changed==[entry]
        classes=sum(name.endswith('.class') for name in source.namelist())
    result[label]=dict(originalSha256=hashlib.sha256(before.read_bytes()).hexdigest(),repairedSha256=hashlib.sha256(output.read_bytes()).hexdigest(),changedEntries=changed,executableClassesPreserved=classes)
    if label=='mcp':shutil.copy2(output,mcp)
(root/'metadata-repair.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(ownedTestMetadataRepaired=True,allExecutableClassesUnchanged=True,globalCachesChanged=False,details=result)))
