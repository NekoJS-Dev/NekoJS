param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference = 'Stop'
if ($Stage -notmatch '^[a-z0-9-]+$') { throw 'Invalid observation stage.' }
$client = Get-Process -Id 25128
if ($client.ProcessName -ne 'java') { throw 'Owned client process mismatch.' }
$status = Invoke-RestMethod 'http://127.0.0.1:9876/api/status'
if ($status.pid -ne $client.Id) { throw 'Owned client bridge mismatch.' }
$folder = Join-Path 'D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance' ('memory-' + $Stage)
if (Test-Path -LiteralPath $folder) { throw 'Observation stage already exists.' }
New-Item -ItemType Directory -Path $folder | Out-Null
$client.Refresh()
[ordered]@{
    atUtc = [DateTime]::UtcNow.ToString('o')
    pid = $client.Id
    processStartUtc = $client.StartTime.ToUniversalTime().ToString('o')
    workingSetBytes = $client.WorkingSet64
    privateBytes = $client.PrivateMemorySize64
    handles = $client.HandleCount
    threads = $client.Threads.Count
} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $folder 'process.json') -Encoding utf8
& 'C:/Program Files/Java/jdk-25.0.2/bin/jcmd.exe' 25128 VM.native_memory summary scale=KB *> (Join-Path $folder 'nmt.log')
if ($LASTEXITCODE -ne 0) { throw 'NMT observation failed.' }
Get-Content -LiteralPath (Join-Path $folder 'process.json')
