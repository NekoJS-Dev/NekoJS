"""Send one command only to the owned loopback acceptance server, keeping credentials local."""
import importlib.util
import json
import socket
import sys
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
root=project/'build/priority-closeout/client-world-acceptance'
command=sys.argv[1]
assert command=='stop' or command.startswith('nekojs packs') or command=='list'
spec=importlib.util.spec_from_file_location('acceptance_rcon',project/'bench/perf/rcon.py')
rcon=importlib.util.module_from_spec(spec);spec.loader.exec_module(rcon)
properties=dict(line.split('=',1) for line in (root/'server/server.properties').read_text().splitlines() if '=' in line)
assert properties['server-ip']=='127.0.0.1' and properties['rcon.port']=='25874'
with socket.create_connection(('127.0.0.1',25874),timeout=10) as connection:
    connection.settimeout(10)
    rcon.send_packet(connection,11,3,properties['rcon.password'])
    while True:
        response=rcon.recv_packet(connection)
        assert response is not None and response[0]!=-1,'Acceptance RCON authentication failed'
        if response[1]==2:break
    rcon.send_packet(connection,12,2,command)
    response=rcon.recv_packet(connection)
    assert response is not None and response[0]==12
result=dict(command=command,response=response[2])
with (root/'server-commands.jsonl').open('a',encoding='utf-8') as file:file.write(json.dumps(result)+'\n')
print(json.dumps(result))
