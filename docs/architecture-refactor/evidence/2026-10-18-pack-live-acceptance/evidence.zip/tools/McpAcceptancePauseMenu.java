package com.tkisor.nekojs.acceptance.mcp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;
import xyz.langyo.minecraft.mcp.common.ControlModeHelper;

/** Owned test adapter: the MCP jar has no NeoForge screen or tick registrations. */
@Mod(value = "nekojs_acceptance_mcp", dist = Dist.CLIENT)
public final class McpAcceptancePauseMenu {
    public McpAcceptancePauseMenu() {
        NeoForge.EVENT_BUS.addListener(McpAcceptancePauseMenu::onScreenInit);
        NeoForge.EVENT_BUS.addListener(McpAcceptancePauseMenu::onClientTick);
    }

    private static void onScreenInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof PauseScreen screen)) return;
        event.addListener(Button.builder(Component.literal("MCP Take Over"), button -> {
            // Only a physical user click reaches this callback before control is enabled.
            ControlModeHelper.enterMcpControlMode(Minecraft.getInstance());
            System.out.println("MCP_ACCEPTANCE_MANUAL_TAKEOVER active=" + ControlModeHelper.isMcpControlMode());
        }).bounds((screen.width - 204) / 2, screen.height - 26, 204, 20).build());
    }

    private static void onClientTick(ClientTickEvent.Post event) {
        if (ControlModeHelper.isMcpControlMode()) {
            ControlModeHelper.tickMcpControlMode(Minecraft.getInstance());
        }
    }
}
