"""Build an owned test mod whose pause button requires the user's physical click."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
run = project / 'build/priority-closeout/client-world-acceptance'
output = run / 'mcp-pause-menu-addon-v1'
assert not output.exists()
classes = output / 'classes'
classes.mkdir(parents=True)
classpath = (run / 'adapter-classpath.txt').read_text().strip() + ';' + str(run / 'game/mods/minecraft-mcp-26.2-neoforge.jar')
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
command = [str(java / 'javac.exe'), '-proc:none', '--release', '25', '-encoding', 'UTF-8',
           '-cp', classpath, '-d', str(classes), str(project / 'build/priority-closeout/McpAcceptancePauseMenu.java')]
with (output / 'compile.log').open('xb') as stdout, (output / 'compile-stderr.log').open('xb') as stderr:
    result = subprocess.run(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
assert result.returncode == 0, 'Compile failed; do not change the running client.'
metadata = '''modLoader="javafml"
loaderVersion="[1,)"
license="MIT"
[[mods]]
modId="nekojs_acceptance_mcp"
version="1.0.0"
displayName="NekoJS isolated MCP acceptance adapter"
description="Owned test-only pause menu and active control tick wiring."
[[dependencies.nekojs_acceptance_mcp]]
modId="mcpmod"
type="required"
versionRange="[0.4.2,)"
ordering="AFTER"
side="CLIENT"
'''
artifact = output / 'nekojs-acceptance-mcp.jar'
with zipfile.ZipFile(artifact, 'x', zipfile.ZIP_DEFLATED) as data:
    data.writestr('META-INF/neoforge.mods.toml', metadata)
    for file in classes.rglob('*.class'):
        data.write(file, file.relative_to(classes).as_posix())
code = subprocess.check_output([str(java / 'javap.exe'), '-c', '-p', '-classpath', str(artifact),
                                'com.tkisor.nekojs.acceptance.mcp.McpAcceptancePauseMenu'], text=True)
(output / 'bytecode.txt').write_text(code)
assert code.count('ControlModeHelper.enterMcpControlMode:') == 1
assert code.index('ControlModeHelper.enterMcpControlMode:') > code.index('lambda$onScreenInit$')
assert 'ControlModeHelper.isMcpControlMode:()Z' in code
binding = dict(artifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),
               sourceSha256=hashlib.sha256((project / 'build/priority-closeout/McpAcceptancePauseMenu.java').read_bytes()).hexdigest(),
               automaticControlActivation=False, installed=False, userActivationObserved=False)
(output / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
print(json.dumps(binding))
