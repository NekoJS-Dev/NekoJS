"""Freeze allowlisted live acceptance records without world data or credentials."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
run = project / 'build/priority-closeout/client-world-acceptance'
target = project / 'docs/architecture-refactor/evidence/2026-10-18-pack-live-acceptance'
target.mkdir(parents=True, exist_ok=True)
archive = target / 'evidence.zip'
assert not archive.exists(), 'Evidence archives are immutable.'
secrets = []
for file in [run / 'server/server.properties', Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run/server.properties')]:
    secrets.extend(line.split('=', 1)[1] for line in file.read_text().splitlines() if line.startswith('rcon.password='))
assert len(secrets) == 2 and all(secrets)
entries = {}

def add(file, name=None):
    data = file.read_bytes()
    key = name or 'run/' + file.relative_to(run).as_posix()
    assert key not in entries and not any(secret in key for secret in secrets)
    if file.suffix in {'.log', '.xml', '.json', '.jsonl', '.java', '.py', '.ps1', '.gradle', '.js'}:
        encoding = 'utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
        value = data.decode(encoding)
        changed = any(secret in value for secret in secrets)
        if changed:
            assert file.name != 'client-launch-7.log', 'Raw byte windows must remain unchanged.'
            for secret in secrets:
                value = value.replace(secret, '<REDACTED-RCON-CREDENTIAL>')
            data = value.encode(encoding)
    for secret in secrets:
        for encoding in ['utf-8', 'utf-16-le', 'utf-16-be']:
            assert secret.encode(encoding) not in data, 'Credential found in evidence.'
    entries[key] = data

for file in run.iterdir():
    if file.is_file() and file.suffix in {'.log', '.xml', '.json', '.jsonl', '.png', '.gradle', '.js'}:
        add(file)
for folder in ['mcp-gui-compat', 'mcp-gui-compat-v2', 'mcp-gui-compat-v3',
               'mcp-pause-menu-addon-v1', 'mcp-list-selection-v1', 'mcp-list-selection-v2',
               'mcp-native-screenshot-v1', 'mcp-owned-shutdown', 'owned-source-grant', 'replacement-signing']:
    for file in (run / folder).rglob('*'):
        if file.is_file() and file.suffix in {'.log', '.json'}:
            add(file)
for folder in run.glob('memory-*'):
    for name in ['process.json', 'nmt.log']:
        add(folder / name)
helpers = ['prepare-client-world-acceptance.py', 'PrepareSignedAcceptance.java',
           'prepare-client-network-inputs.py', 'acceptance-server-command.py',
           'repair-client-test-metadata.py', 'McpGuiLookup.java', 'PatchMcpGuiLookup.java',
           'PatchMcpScreenSetters.java', 'CheckMcpGuiLookup.java', 'prepare-mcp-gui-compat.py',
           'McpAcceptancePauseMenu.java', 'prepare-mcp-pause-adapter.py', 'mcp-owned-command.py',
           'observe-owned-client.ps1', 'assert-client-world-quiet.py', 'assert-client-signed-quiet.py',
           'prepare-owned-server-list.py', 'McpModernListSelection.java', 'PatchMcpListSelection.java',
           'McpSelectionAgent.java', 'AttachMcpSelectionAgent.java', 'CheckMcpModernListSelection.java',
           'prepare-mcp-list-agent.py', 'McpSelectionAgentV2.java', 'AttachMcpSelectionAgentV2.java',
           'prepare-mcp-list-agent-v2.py', 'GrantOwnedSourceTrust.java', 'grant-owned-source-trust.py',
           'PrepareReplacementAcceptance.java', 'prepare-owned-replacement.py', 'set-owned-signed-fixture.py',
           'McpModernScreenshot.java', 'PatchMcpScreenshot.java', 'McpScreenshotAgent.java',
           'AttachMcpScreenshotAgent.java', 'prepare-native-screenshot-agent.py',
           'McpStopAgent.java', 'stop-owned-mcp-executor.py', 'analyze-pack-live-acceptance.py',
           'archive-pack-live-acceptance.py']
for name in helpers:
    add(project / 'build/priority-closeout' / name, 'tools/' + name)
for world in ['NekoPackAcceptanceA', 'NekoPackAcceptanceB']:
    base = run / 'game/saves' / world / 'nekojs_packs'
    for file in base.rglob('*'):
        if file.is_file() and (file.name == 'manifest.json' or file.suffix == '.js'):
            add(file, 'fixtures/' + world + '/' + file.relative_to(base).as_posix())
for name in ['src/main/java/com/tkisor/nekojs/client/NekoJSClient.java',
             'versions/1.21.1/src/main/java/com/tkisor/nekojs/client/NekoJSClient.java',
             'src/test/java/com/tkisor/nekojs/network/PackSyncBridgeSourceTraceTest.java']:
    add(project / name, 'source/' + name)
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(entries.items()):
        output.writestr(name, data)
manifest = dict(sourceCommit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project, text=True).strip(),
                productFixCommit='32504630', clientPid=25128,
                archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(), archiveBytes=archive.stat().st_size,
                entries={name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())},
                excluded=['private keys', 'server.properties', 'world NBT and player data',
                          'vendor jar binaries', 'full dependency classpath'],
                credentialsScanned=2, binaryRedaction=False)
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k != 'entries'}))
print('entries=' + str(len(entries)))
