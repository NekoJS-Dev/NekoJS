package com.tkisor.nekojs.acceptance.mcp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;

/** Reads the actual 26.2 GPU render target instead of synthesizing a fallback image. */
public final class McpModernScreenshot {
    public static byte[] capture() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.isSameThread()) throw new IllegalStateException("Screenshot HTTP work must not block the render thread");
        CompletableFuture<byte[]> completion = new CompletableFuture<>();
        minecraft.execute(() -> {
            try {
                Screenshot.takeScreenshot(minecraft.gameRenderer.mainRenderTarget(), image -> {
                    Path file = null;
                    try (image) {
                        Path folder = Path.of("D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance/native-capture");
                        Files.createDirectories(folder);
                        file = Files.createTempFile(folder, "frame-", ".png");
                        image.writeToFile(file);
                        completion.complete(Files.readAllBytes(file));
                    } catch (Exception failure) {
                        completion.completeExceptionally(failure);
                    } finally {
                        if (file != null) {
                            try { Files.deleteIfExists(file); }
                            catch (Exception failure) { System.err.println("MCP acceptance capture temporary cleanup failed: " + failure); }
                        }
                    }
                });
            } catch (Exception failure) {
                completion.completeExceptionally(failure);
            }
        });
        try { return completion.get(10, TimeUnit.SECONDS); }
        catch (Exception failure) { throw new IllegalStateException("Native MCP screenshot failed", failure); }
    }
}
