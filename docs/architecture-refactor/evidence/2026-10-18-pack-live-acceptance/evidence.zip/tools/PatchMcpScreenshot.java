import java.nio.file.Files;
import java.nio.file.Path;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

public final class PatchMcpScreenshot {
    public static void main(String[] args) throws Exception {
        ClassReader reader = new ClassReader(Files.readAllBytes(Path.of(args[0])));
        ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS);
        int[] count = {0};
        reader.accept(new ClassVisitor(Opcodes.ASM9, writer) {
            @Override public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
                MethodVisitor next = super.visitMethod(access, name, descriptor, signature, exceptions);
                if (!name.equals("screenshot") || !descriptor.equals("()[B")) return next;
                count[0]++;
                next.visitCode();
                next.visitMethodInsn(Opcodes.INVOKESTATIC, "com/tkisor/nekojs/acceptance/mcp/McpModernScreenshot", "capture", descriptor, false);
                next.visitInsn(Opcodes.ARETURN);
                next.visitMaxs(1, 1);
                next.visitEnd();
                return null;
            }
        }, 0);
        if (count[0] != 1) throw new AssertionError("Unexpected screenshot method shape");
        Files.write(Path.of(args[1]), writer.toByteArray());
    }
}
