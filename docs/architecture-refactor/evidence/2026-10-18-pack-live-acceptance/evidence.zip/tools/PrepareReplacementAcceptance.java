package com.tkisor.nekojs.core.pack.sync;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Map;

/** Creates a valid second key with the same keyId to exercise the real pinned-key refusal. */
public final class PrepareReplacementAcceptance {
    public static void main(String[] args) throws Exception {
        Path root = Path.of("D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance");
        Path pack = root.resolve("server/nekojs/packs/signedacceptance");
        Path replacement = root.resolve("replacement-signed-manifest.json");
        Path privateKey = root.resolve("server-only-signing/replacement-private.pk8");
        if (Files.exists(replacement) || Files.exists(privateKey)) throw new IllegalStateException("Preserve the replacement fixture");
        byte[] originalScript = Files.readAllBytes(root.resolve("valid-signed-client.js"));
        if (!MessageDigest.isEqual(Files.readAllBytes(pack.resolve("client_scripts/main.js")), originalScript)) {
            throw new IllegalStateException("Restore the original script before preparing the replacement key");
        }
        String original = Files.readString(root.resolve("valid-signed-manifest.json"));
        JsonObject manifest = JsonParser.parseString(original).getAsJsonObject();
        String originalPublic = manifest.getAsJsonObject("signature").get("publicKey").getAsString();
        manifest.remove("signature");
        var files = PackHasher.readContentFiles(pack);
        var pair = PackSigner.generateKeyPair();
        if (MessageDigest.isEqual(pair.getPublic().getEncoded(), Base64.getDecoder().decode(originalPublic))) {
            throw new AssertionError("Replacement public key must differ");
        }
        manifest.add("signature", PackSigner.sign("acceptance-local-20261018", pair,
                "packs:signedacceptance", "GLOBAL", manifest.toString(), files));
        String json = new GsonBuilder().setPrettyPrinting().create().toJson(manifest) + "\n";
        var empty = new PackSyncTrustStore(root.resolve("replacement-empty-trust.json"));
        var pinned = new PackSyncTrustStore(root.resolve("game/nekojs/config/trusted-servers.json"));
        var valid = PackSignatureVerifier.verify("packs:signedacceptance", "GLOBAL", json, files, false, empty);
        var rejected = PackSignatureVerifier.verify("packs:signedacceptance", "GLOBAL", json, files, false, pinned);
        if (!valid.valid() || rejected.valid() || !rejected.reason().contains("does not match pinned key")) {
            throw new AssertionError("Replacement signature must be valid independently and rejected by the existing pin");
        }
        Files.writeString(replacement, json, StandardOpenOption.CREATE_NEW);
        Files.write(privateKey, pair.getPrivate().getEncoded(), StandardOpenOption.CREATE_NEW);
        Files.writeString(root.resolve("replacement-signature-preparation.json"), new GsonBuilder().setPrettyPrinting().create().toJson(Map.of(
                "sameKeyId", true, "differentPublicKey", true, "validIndependentSignature", valid.valid(),
                "originalPinRejects", !rejected.valid(), "rejectionReason", rejected.reason(), "privateKeyDistributed", false)) + "\n");
        System.out.println("Valid replacement signature prepared; original public key pin rejects it.");
    }
}
