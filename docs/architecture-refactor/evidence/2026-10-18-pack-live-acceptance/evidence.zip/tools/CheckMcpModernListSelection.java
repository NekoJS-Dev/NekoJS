import java.util.List;
import xyz.langyo.minecraft.mcp.common.ScreenInteractionHelper;

public final class CheckMcpModernListSelection {
    public static final class FakeLevelSummary {
        public String getLevelId() { return "NekoPackAcceptanceB"; }
        public String getLevelName() { return "Neko Pack Acceptance B"; }
    }
    public static final class Entry { private final FakeLevelSummary summary = new FakeLevelSummary(); }
    public static final class FakeSelectionList {
        private final List<Entry> entries = List.of(new Entry(), new Entry());
        private Entry selected;
        public List<Entry> children() { return entries; }
        public void setSelected(Entry entry) { selected = entry; }
    }
    public static final class Screen {
        public final FakeSelectionList list = new FakeSelectionList();
        public List<Object> children() { return List.of(list); }
    }
    public static final class Gui {
        private final Screen screen = new Screen();
        public Screen screen() { return screen; }
    }
    public static final class Minecraft { public final Gui gui = new Gui(); }
    public static void main(String[] args) {
        Minecraft minecraft = new Minecraft();
        String result = ScreenInteractionHelper.selectListItem(minecraft, 1);
        if (minecraft.gui.screen.list.selected != minecraft.gui.screen.list.entries.get(1)
                || !result.contains("\"worldId\":\"NekoPackAcceptanceB\"")) throw new AssertionError(result);
        if (!ScreenInteractionHelper.selectListItem(minecraft, 2).contains("out of range")) throw new AssertionError();
        if (!ScreenInteractionHelper.selectListItem(minecraft, -1).contains("out of range")) throw new AssertionError();
        System.out.println("Modern entry selection and both bounds passed.");
    }
}
