"""Change only the owned signed fixture while retaining immutable valid originals."""
import datetime
import hashlib
import json
import sys
from pathlib import Path

root = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance')
mode, stage = sys.argv[1:3]
assert mode in {'original', 'tampered', 'replacement'} and stage.isalnum()
record = root / ('signed-fixture-' + stage + '.json')
assert not record.exists()
pack = root / 'server/nekojs/packs/signedacceptance'
script = pack / 'client_scripts/main.js'
manifest = pack / 'manifest.json'
original_script = (root / 'valid-signed-client.js').read_bytes()
original_manifest = (root / 'valid-signed-manifest.json').read_bytes()
tampered = original_script + b"\nconsole.info('NEKO_TAMPERED_CONTENT_MUST_NOT_EXECUTE');\n"
assert script.read_bytes() in {original_script, tampered}
known_manifests = [original_manifest]
replacement = root / 'replacement-signed-manifest.json'
if replacement.exists():
    known_manifests.append(replacement.read_bytes())
assert manifest.read_bytes() in known_manifests
before = dict(scriptSha256=hashlib.sha256(script.read_bytes()).hexdigest(),
              manifestSha256=hashlib.sha256(manifest.read_bytes()).hexdigest())
script.write_bytes(tampered if mode == 'tampered' else original_script)
manifest.write_bytes(replacement.read_bytes() if mode == 'replacement' else original_manifest)
result = dict(mode=mode, atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), before=before,
              after=dict(scriptSha256=hashlib.sha256(script.read_bytes()).hexdigest(),
                         manifestSha256=hashlib.sha256(manifest.read_bytes()).hexdigest()),
              clientLogStartByte=(root/'client-launch-7.log').stat().st_size,
              publicKeyChanged=mode == 'replacement', signatureRetained=mode == 'tampered')
record.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
