"""Build and check a temporary MCP screen-owner compatibility patch before restarting the client."""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

tools=Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout')
full='--gui-setters-and-empty-screen' in sys.argv
root=tools/('client-world-acceptance/mcp-gui-compat-v3' if full else 'client-world-acceptance/mcp-gui-compat-v2' if '--correct-null-control' in sys.argv else 'client-world-acceptance/mcp-gui-compat')
assert not root.exists();root.mkdir()
classes=root/'classes';classes.mkdir()
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
asm=Path('C:/Users/11515/.gradle/wrapper/dists/gradle-9.6.0-bin/42k10rwplmzkhuboz9kdazi7s/gradle-9.6.0/lib/asm-9.9.jar')
source=tools/'client-world-acceptance/metadata-repaired-dependencies/mcp-metadata-repaired.jar'
with zipfile.ZipFile(source) as archive:
    original=archive.read('xyz/langyo/minecraft/mcp/common/ReflectionCache.class')
(root/'ReflectionCache-original.class').write_bytes(original)
steps=[]
def run(name,command):
    with (root/(name+'.log')).open('xb') as out,(root/(name+'-stderr.log')).open('xb') as err:
        process=subprocess.run(command,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    steps.append(dict(stage=name,exitCode=process.returncode))
    (root/'steps.json').write_text(json.dumps(steps,indent=2)+'\n')
    assert process.returncode==0,name

run('compile',[str(java/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',str(asm),'-d',str(classes),*[str(tools/name) for name in ['McpGuiLookup.java','PatchMcpGuiLookup.java','PatchMcpScreenSetters.java','CheckMcpGuiLookup.java']]])
run('original-control',[str(java/'java.exe'),'-Xverify:all','-cp',str(classes)+';'+str(source),'CheckMcpGuiLookup','original'])
run('patch',[str(java/'java.exe'),'-cp',str(classes)+';'+str(asm),'PatchMcpGuiLookup',str(root/'ReflectionCache-original.class'),str(root/'ReflectionCache-patched.class')])
replacements={'xyz/langyo/minecraft/mcp/common/ReflectionCache.class':root/'ReflectionCache-patched.class'}
if full:
    for name,kind in [('PlayerWorldHelper','player'),('ControlModeHelper','control')]:
        entry='xyz/langyo/minecraft/mcp/common/'+name+'.class'
        with zipfile.ZipFile(source) as archive:(root/(name+'-original.class')).write_bytes(archive.read(entry))
        destination=root/(name+'-patched.class')
        run('patch-'+kind,[str(java/'java.exe'),'-cp',str(classes)+';'+str(asm),'PatchMcpScreenSetters',str(root/(name+'-original.class')),str(destination),kind])
        replacements[entry]=destination
patched=root/'minecraft-mcp-gui-compat.jar'
with zipfile.ZipFile(source) as archive,zipfile.ZipFile(patched,'x',zipfile.ZIP_DEFLATED) as output:
    for info in archive.infolist():
        data=replacements[info.filename].read_bytes() if info.filename in replacements else archive.read(info.filename)
        output.writestr(info,data)
    output.write(classes/'xyz/langyo/minecraft/mcp/common/McpGuiLookup.class','xyz/langyo/minecraft/mcp/common/McpGuiLookup.class')
run('check',[str(java/'java.exe'),'-Xverify:all','-cp',str(classes)+';'+str(patched),'CheckMcpGuiLookup'])
with zipfile.ZipFile(source) as before,zipfile.ZipFile(patched) as after:
    changed=[name for name in before.namelist() if before.read(name)!=after.read(name)]
    added=sorted(set(after.namelist())-set(before.namelist()))
    assert set(changed)==set(replacements)
    assert added==['xyz/langyo/minecraft/mcp/common/McpGuiLookup.class']
result=dict(preparedOnly=True,liveClientRestarted=False,sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),patchedSha256=hashlib.sha256(patched.read_bytes()).hexdigest(),changedEntries=changed,addedEntries=added,controlModeChecksChanged=False,steps=steps)
(root/'binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
