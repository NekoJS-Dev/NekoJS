"""Create the isolated client's first server list with only the owned loopback fixture."""
import hashlib
import json
import struct
from pathlib import Path

root = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance')
target = root / 'game/servers.dat'
assert not target.exists(), 'Do not replace an existing server list.'

def string(value):
    encoded = value.encode('utf-8')
    return struct.pack('>H', len(encoded)) + encoded

def text(name, value):
    return b'\x08' + string(name) + string(value)

entry = text('name', 'Neko Signed Acceptance') + text('ip', '127.0.0.1:25873')
entry += b'\x01' + string('acceptTextures') + b'\x00\x00'
data = b'\x0a\x00\x00\x09' + string('servers') + b'\x0a' + struct.pack('>i', 1) + entry + b'\x00'
target.write_bytes(data)
result = dict(address='127.0.0.1:25873', entries=1, sha256=hashlib.sha256(data).hexdigest(), overwritten=False)
(root / 'owned-server-list.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
