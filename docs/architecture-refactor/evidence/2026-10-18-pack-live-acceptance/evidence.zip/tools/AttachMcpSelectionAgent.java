import com.sun.tools.attach.VirtualMachine;
import java.time.Instant;

/** Refuses attachment if Windows has reused the owned client PID. */
public final class AttachMcpSelectionAgent {
    public static void main(String[] args) throws Exception {
        ProcessHandle process = ProcessHandle.of(25128).orElseThrow();
        long expected = Instant.parse("2026-10-18T12:57:26.3646991Z").toEpochMilli();
        if (process.info().startInstant().orElseThrow().toEpochMilli() != expected) {
            throw new IllegalStateException("Owned client creation time changed");
        }
        VirtualMachine vm = VirtualMachine.attach("25128");
        try { vm.loadAgent(args[0], args[1]); }
        finally { vm.detach(); }
    }
}
