"""Prepare two owned saves and observable pack lifecycles without touching user game data."""
import gzip
import hashlib
import json
import os
import shutil
import struct
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult').resolve()
root=project/'build/priority-closeout/client-world-acceptance'
assert root.resolve().is_relative_to(project/'build/priority-closeout') and not root.exists()
root.mkdir()
game=root/'game'
game.mkdir()
source=project/'build/script-pack-native-final/neo262/world'
assert (source/'level.dat').is_file()
root_binding=dict(sourceWorld=str(source),sourceLevelSha256=hashlib.sha256((source/'level.dat').read_bytes()).hexdigest(),worlds={},preparedOnly=True)
for label in ['A','B']:
    save=game/'saves'/('NekoPackAcceptance'+label)
    shutil.copytree(source,save,ignore=shutil.ignore_patterns('session.lock','nekojs_packs'))
    level=gzip.decompress((save/'level.dat').read_bytes())
    marker=b'\x08\x00\x09LevelName'
    assert level.count(marker)==1
    offset=level.index(marker)+len(marker)
    length=struct.unpack('>H',level[offset:offset+2])[0]
    name=('Neko Pack Acceptance '+label).encode()
    level=level[:offset]+struct.pack('>H',len(name))+name+level[offset+2+length:]
    (save/'level.dat').write_bytes(gzip.compress(level,mtime=0))
    for identifier in ['sessionprobe','sessionconsumer']:
        pack=save/'nekojs_packs'/identifier
        manifest=dict(formatVersion=1,id=identifier,version='1.0.0',clientSync=False,entries=dict(server=['main.js'],client=['main.js']))
        if identifier=='sessionprobe':manifest['capabilities']=dict(provides=['worldstamp'])
        else:
            manifest['dependencies']=dict(sessionprobe='*')
            manifest['capabilities']=dict(requires=dict(sessionprobe=['worldstamp']))
        pack.mkdir(parents=True)
        (pack/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
        for side,group in [('server','ServerEvents'),('client','ClientEvents')]:
            directory=pack/(side+'_scripts');directory.mkdir()
            prefix=f'NEKO_WORLD_ACCEPTANCE side={side} world={label} pack={identifier}'
            if identifier=='sessionprobe':
                code=f'''global.count = (global.count || 0) + 1;
globalThis.privatePayload = new Array(4096).fill('payload');
const activation = Pack.activation;
const prefix = '{prefix} activation=' + activation;
console.info(prefix + ' event=entry count=' + global.count);
Pack.provide('worldstamp', data => ({{world:'{label}', count:global.count, activation:activation}}));
let ticks = 0;
{group}.tickPost(event => {{
    ticks++;
    if (ticks === 1 || ticks % 100 === 0) console.info(prefix + ' event=tick n=' + ticks);
}});
setInterval(() => console.info(prefix + ' event=timer'), 2000);
'''
            else:
                code=f'''const stamp = Pack.require('sessionprobe', 'worldstamp')({{}});
if (stamp.world !== '{label}' || stamp.count !== 1) throw Error('World package state was not rebuilt');
console.info('{prefix} event=capability world=' + stamp.world + ' count=' + stamp.count + ' providerActivation=' + stamp.activation);
'''
            (directory/'main.js').write_text(code,encoding='utf-8')
    root_binding['worlds'][label]=dict(directory=str(save),levelSha256=hashlib.sha256((save/'level.dat').read_bytes()).hexdigest())
mods=game/'mods';mods.mkdir()
cached=Path(os.environ['APPDATA'])/'.minecraft/mcp_launcher/modjars/minecraft-mcp-26.2-neoforge.jar'
assert cached.is_file()
shutil.copy2(cached,mods/cached.name)
root_binding['mcpMod']=dict(version='0.4.2',sha256=hashlib.sha256(cached.read_bytes()).hexdigest())
root_binding['files']={path.relative_to(game).as_posix():hashlib.sha256(path.read_bytes()).hexdigest() for path in game.rglob('*') if path.is_file() and (path.suffix in ['.js','.json'] or path.name=='level.dat')}
(root/'preparation.json').write_text(json.dumps(root_binding,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(preparedOnly=True,ownedGameDirectory=str(game),worlds=['A','B'],mcpModCopied=True,userGameDataChanged=False)))
