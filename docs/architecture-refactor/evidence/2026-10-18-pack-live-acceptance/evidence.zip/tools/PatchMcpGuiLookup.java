import java.nio.file.Files;
import java.nio.file.Path;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/** Instrument only the shared screen lookup in the owned test dependency. */
public final class PatchMcpGuiLookup {
    public static void main(String[] args) throws Exception {
        ClassReader original = new ClassReader(Files.readAllBytes(Path.of(args[0])));
        ClassWriter output = new ClassWriter(original, ClassWriter.COMPUTE_MAXS);
        int[] patched = {0};
        original.accept(new ClassVisitor(Opcodes.ASM9, output) {
            @Override public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
                MethodVisitor next = super.visitMethod(access, name, descriptor, signature, exceptions);
                if (!name.equals("getCurrentScreen") || !descriptor.equals("(Ljava/lang/Object;)Ljava/lang/Object;")) return next;
                if ((access & Opcodes.ACC_STATIC) == 0) throw new AssertionError("Expected the static shared lookup");
                patched[0]++;
                return new MethodVisitor(Opcodes.ASM9, next) {
                    @Override public void visitCode() {
                        super.visitCode();
                        visitVarInsn(Opcodes.ALOAD, 0);
                        visitMethodInsn(Opcodes.INVOKESTATIC, "xyz/langyo/minecraft/mcp/common/McpGuiLookup", "supported", "(Ljava/lang/Object;)Z", false);
                        Label fallback = new Label();
                        visitJumpInsn(Opcodes.IFEQ, fallback);
                        visitVarInsn(Opcodes.ALOAD, 0);
                        visitMethodInsn(Opcodes.INVOKESTATIC, "xyz/langyo/minecraft/mcp/common/McpGuiLookup", "screen", descriptor, false);
                        visitInsn(Opcodes.ARETURN);
                        visitLabel(fallback);
                        visitFrame(Opcodes.F_SAME, 0, null, 0, null);
                    }
                };
            }
        }, 0);
        if (patched[0] != 1) throw new AssertionError("Expected exactly one shared screen lookup");
        Files.write(Path.of(args[1]), output.toByteArray());
    }
}
