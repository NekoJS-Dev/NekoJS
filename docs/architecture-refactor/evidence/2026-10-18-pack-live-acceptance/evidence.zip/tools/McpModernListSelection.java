package com.tkisor.nekojs.acceptance.mcp;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/** Uses the current screen's actual selection entries; does not load worlds directly. */
public final class McpModernListSelection {
    public static String select(Object minecraft, int index) {
        try {
            Object gui = minecraft.getClass().getField("gui").get(minecraft);
            Object screen = gui.getClass().getMethod("screen").invoke(gui);
            if (screen == null) return "{\"error\":\"no screen\"}";
            List<?> widgets = (List<?>) screen.getClass().getMethod("children").invoke(screen);
            for (Object widget : widgets) {
                if (!widget.getClass().getSimpleName().contains("SelectionList")) continue;
                List<?> entries = (List<?>) widget.getClass().getMethod("children").invoke(widget);
                if (index < 0 || index >= entries.size()) return "{\"error\":\"entry index out of range\",\"count\":" + entries.size() + "}";
                Object entry = entries.get(index);
                for (Method method : widget.getClass().getMethods()) {
                    if (!method.getName().equals("setSelected") || method.getParameterCount() != 1
                            || !method.getParameterTypes()[0].isInstance(entry)) continue;
                    method.invoke(widget, entry);
                    String worldId = "", worldName = "";
                    for (Class<?> type = entry.getClass(); type != null; type = type.getSuperclass()) {
                        for (Field field : type.getDeclaredFields()) {
                            if (!field.getType().getSimpleName().contains("LevelSummary")) continue;
                            field.setAccessible(true);
                            Object summary = field.get(entry);
                            worldId = (String) summary.getClass().getMethod("getLevelId").invoke(summary);
                            worldName = (String) summary.getClass().getMethod("getLevelName").invoke(summary);
                        }
                    }
                    return "{\"selected\":true,\"index\":" + index + ",\"count\":" + entries.size()
                            + ",\"worldId\":" + quote(worldId) + ",\"worldName\":" + quote(worldName) + "}";
                }
            }
            return "{\"error\":\"no compatible selection list\"}";
        } catch (ReflectiveOperationException failure) {
            return "{\"error\":" + quote(failure.toString()) + "}";
        }
    }

    private static String quote(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\"";
    }
}
