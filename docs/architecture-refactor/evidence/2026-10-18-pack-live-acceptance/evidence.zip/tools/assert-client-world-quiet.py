"""Observe a bounded title-menu window after a world exit; retain the exact log suffix."""
import datetime
import json
import sys
import time
import urllib.request
from pathlib import Path

root = Path('D:/mcmodDemo/NekoJS-mult/build/priority-closeout/client-world-acceptance')
stage, world = sys.argv[1:3]
assert stage.isalnum() and world in {'A', 'B'}
output = root / ('quiet-' + stage + '.json')
assert not output.exists()
log = root / 'client-launch-7.log'
before = log.read_bytes()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
time.sleep(8)
status = json.load(urllib.request.urlopen('http://127.0.0.1:9876/api/status'))
assert status['pid'] == 25128
after = log.read_bytes()
assert after.startswith(before)
suffix = after[len(before):].decode('utf-8-sig', errors='replace')
unexpected = [line for line in suffix.splitlines() if 'NEKO_WORLD_ACCEPTANCE' in line and ('world=' + world) in line]
result = dict(stage=stage, world=world, pid=status['pid'], startedAtUtc=started,
              completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              startByte=len(before), endByte=len(after), observedSeconds=8,
              unexpected=unexpected, passed=not unexpected)
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
assert not unexpected, 'World callback continued after world exit'
