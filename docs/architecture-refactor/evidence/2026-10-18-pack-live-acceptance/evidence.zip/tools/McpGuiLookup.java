package xyz.langyo.minecraft.mcp.common;

/** Compatibility for the 26.2 screen owner; legacy lookup remains in ReflectionCache. */
public final class McpGuiLookup {
    private McpGuiLookup() {}

    public static Object screen(Object minecraft) {
        Object gui = gui(minecraft);
        if (gui == null) return null;
        try {
            return gui.getClass().getMethod("screen").invoke(gui);
        } catch (ReflectiveOperationException failure) {
            return null;
        }
    }

    public static boolean supported(Object minecraft) { return gui(minecraft) != null; }

    public static Object owner(Object value) {
        Object gui = gui(value);
        return gui == null ? value : gui;
    }

    public static Object invoke(java.lang.reflect.Method method, Object target, Object[] arguments)
            throws ReflectiveOperationException {
        if (target != null && !method.getDeclaringClass().isInstance(target)) {
            Object candidate = owner(target);
            if (method.getDeclaringClass().isInstance(candidate)) target = candidate;
        }
        return method.invoke(target, arguments);
    }

    private static Object gui(Object minecraft) {
        if (minecraft == null) return null;
        try {
            Object gui = minecraft.getClass().getField("gui").get(minecraft);
            if (gui != null) gui.getClass().getMethod("screen");
            return gui;
        } catch (ReflectiveOperationException failure) {
            return null;
        }
    }
}
