"""Close the MCP-owned executor after native Minecraft shutdown; never kill the JVM."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
root=project/'build/priority-closeout/client-world-acceptance'
output=root/'mcp-owned-shutdown'
assert not output.exists()
output.mkdir()
java=Path('C:/Program Files/Java/jdk-25.0.2/bin')
with (output/'compile.log').open('xb') as stdout,(output/'compile-stderr.log').open('xb') as stderr:
    result=subprocess.run([str(java/'javac.exe'),'-encoding','UTF-8','-d',str(output),
                           str(project/'build/priority-closeout/McpStopAgent.java')],stdout=stdout,stderr=stderr)
assert result.returncode==0
agent=output/'stop-agent.jar'
with zipfile.ZipFile(agent,'x',zipfile.ZIP_DEFLATED) as archive:
    archive.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nAgent-Class: com.tkisor.nekojs.acceptance.tools.McpStopAgent\n\n')
    file=output/'com/tkisor/nekojs/acceptance/tools/McpStopAgent.class'
    archive.write(file,file.relative_to(output).as_posix())
with (output/'attach.log').open('xb') as stdout,(output/'attach-stderr.log').open('xb') as stderr:
    attached=subprocess.run([str(java/'java.exe'),'-cp',str(root/'mcp-list-selection-v1/classes'),
                             'AttachMcpSelectionAgent',str(agent),'owned-mcp-shutdown'],stdout=stdout,stderr=stderr)
result=dict(agentSha256=hashlib.sha256(agent.read_bytes()).hexdigest(),attachExitCode=attached.returncode,
            processKillIssued=False,scope='MCP HTTP service and its executor after Minecraft shutdown')
(output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert attached.returncode==0
