"""Build a valid second signature; leave its private key outside all distributed content."""
import json
import subprocess
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
run = project / 'build/priority-closeout/client-world-acceptance'
output = run / 'replacement-signing'
assert not output.exists()
output.mkdir()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
classpath = (run / 'adapter-classpath.txt').read_text().strip()
steps = []
for name, command in [
    ('compile', [str(java/'javac.exe'), '-proc:none', '-encoding', 'UTF-8', '-cp', classpath,
                 '-d', str(output), str(project/'build/priority-closeout/PrepareReplacementAcceptance.java')]),
    ('prepare', [str(java/'java.exe'), '-cp', str(output) + ';' + classpath,
                 'com.tkisor.nekojs.core.pack.sync.PrepareReplacementAcceptance'])]:
    with (output/(name+'.log')).open('xb') as stdout, (output/(name+'-stderr.log')).open('xb') as stderr:
        process = subprocess.run(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    steps.append(dict(stage=name, exitCode=process.returncode))
    (output/'steps.json').write_text(json.dumps(steps, indent=2)+'\n')
    assert process.returncode == 0, name
print(json.dumps(steps))
