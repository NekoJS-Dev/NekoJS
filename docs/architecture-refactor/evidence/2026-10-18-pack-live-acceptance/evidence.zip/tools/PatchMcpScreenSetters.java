import java.nio.file.Files;
import java.nio.file.Path;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/** Preserve the existing command and human-input branches while adapting their reflective receiver. */
public final class PatchMcpScreenSetters {
    public static void main(String[] args) throws Exception {
        ClassReader reader = new ClassReader(Files.readAllBytes(Path.of(args[0])));
        ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS);
        int[] methods = {0};
        reader.accept(new ClassVisitor(Opcodes.ASM9, writer) {
            @Override public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
                MethodVisitor next = super.visitMethod(access, name, descriptor, signature, exceptions);
                boolean selected = args[2].equals("player")
                    ? (name.equals("closeScreen") || name.equals("openPauseMenu")) && descriptor.equals("(Ljava/lang/Object;)Ljava/lang/String;")
                    : name.equals("handleTransferOverlayClick") && descriptor.equals("(IILjava/lang/Object;)Ljava/lang/String;");
                if (!selected) return next;
                methods[0]++;
                return new MethodVisitor(Opcodes.ASM9, next) {
                    @Override public void visitMethodInsn(int opcode, String owner, String method, String type, boolean isInterface) {
                        if (opcode == Opcodes.INVOKEVIRTUAL && owner.equals("java/lang/Object") && method.equals("getClass") && type.equals("()Ljava/lang/Class;")) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "xyz/langyo/minecraft/mcp/common/McpGuiLookup", "owner", "(Ljava/lang/Object;)Ljava/lang/Object;", false);
                        }
                        if (opcode == Opcodes.INVOKEVIRTUAL && owner.equals("java/lang/reflect/Method") && method.equals("invoke") && type.equals("(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;")) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "xyz/langyo/minecraft/mcp/common/McpGuiLookup", "invoke", "(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;", false);
                        } else super.visitMethodInsn(opcode, owner, method, type, isInterface);
                    }
                };
            }
        }, 0);
        if (methods[0] != (args[2].equals("player") ? 2 : 1)) throw new AssertionError("Unexpected screen setter method shape");
        Files.write(Path.of(args[1]), writer.toByteArray());
    }
}
