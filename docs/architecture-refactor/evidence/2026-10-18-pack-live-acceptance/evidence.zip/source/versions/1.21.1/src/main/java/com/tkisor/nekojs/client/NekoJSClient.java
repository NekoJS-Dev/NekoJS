// 1.21.1 实现，与版本树 src/ 下的同名 26.x 文件成对。内容等于那份文件在本节点求值后的形态
//（可用 tools/extract_evaluated.py 重新提取核对）；26.x 侧行为变更时须同步本文件。
package com.tkisor.nekojs.client;

import com.tkisor.nekojs.NekoJS;
import com.tkisor.nekojs.bindings.event.client.ClientEvents;
import com.tkisor.nekojs.client.renderer.NekoEntityRenderers;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.core.fs.NekoJSPaths;
import com.tkisor.nekojs.core.lifecycle.NekoRuntimeRoot;
import com.tkisor.nekojs.core.pack.ScriptPackRegistry;
import com.tkisor.nekojs.core.plugin.PluginGenerationHooks;
import com.tkisor.nekojs.wrapper.DataGeneratorJS;
import com.tkisor.nekojs.wrapper.LangGeneratorJS;
import com.tkisor.nekojs.wrapper.clientdata.ClientDataStore;
import com.tkisor.nekojs.wrapper.registry.gen.EntityTypeBuilder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLConstructModEvent;
import com.tkisor.nekojs.wrapper.pdata.PDataSyncService;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.common.NeoForge;
import java.nio.file.Path;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;

public class NekoJSClient {

    public static void register(IEventBus modEventBus, NekoRuntimeRoot root) {
        modEventBus.addListener((FMLConstructModEvent event) -> onClientSetup(event, root));
        modEventBus.addListener((RegisterClientReloadListenersEvent event) -> onClientResourceReload(event, root));
        modEventBus.addListener(NekoJSClient::onRegisterEntityRenderers);
        NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post event) -> onClientTickPost(event, root));
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingIn event) -> onClientLoggingIn(event, root));
        NeoForge.EVENT_BUS.addListener(NekoJSClient::onLevelUnload);
        // Reload progress HUD (8e)：自包含订阅 RenderGuiEvent.Post，不走 ClientEvents
        com.tkisor.nekojs.client.hud.NekoReloadProgressHud.install();
        ClientEvents.bindModBus(modEventBus);
    }

    /// 某些事件需要极早期的时机，如RegisterKeyMappingsEvent
    private static void onClientSetup(FMLConstructModEvent event, NekoRuntimeRoot root) {
        event.enqueueWork(() -> {
            NekoJS.LOGGER.debug("Client environment ready, loading CLIENT scripts...");
            root.load(ScriptType.CLIENT);
            com.tkisor.nekojs.script.ScriptTypeEnv.logger(ScriptType.CLIENT).debug("Early script injection...");
        });
    }

    private static void onRegisterEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
        EntityTypeBuilder.registeredEntityTypes().forEach(type -> event.registerEntityRenderer(type,
                NekoEntityRenderers.provider(EntityTypeBuilder.renderConfiguration(type))));
    }

    private static void onClientLoggingIn(ClientPlayerNetworkEvent.LoggingIn event, NekoRuntimeRoot root) {
        // Login runs on the client thread after the integrated server publishes WORLD sources.
        // Remote sources already activate during configuration; do not reload them again here.
        if (!event.getConnection().isMemoryConnection() || ScriptPackRegistry.get().worldPacks().isEmpty()) {
            return;
        }
        try {
            root.reload(ScriptType.CLIENT);
        } catch (Exception failure) {
            NekoJS.LOGGER.error("[NEKO-1017] CLIENT reload after local world pack activation failed", failure);
            root.errorTracker().recordCallbackError(ScriptType.CLIENT, "world_pack_login", failure);
        }
    }

    private static void onClientTickPost(ClientTickEvent.Post event, NekoRuntimeRoot root) {
        root.flushReadyNodeTimers(ScriptType.CLIENT);
    }

    private static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel().isClientSide()) {
            PDataSyncService.clearClientMirrors();
            // ClientData 键值存储随断线/切世界一并清空（服务端重连后会重新推送）
            ClientDataStore.SHARED.clear();
        }
    }

    private static void onClientResourceReload(RegisterClientReloadListenersEvent event, NekoRuntimeRoot root) {
        // 1.21.1: NeoForge 注册重载监听器不需要手动指定 ID，直接 registerReloadListener 即可
        event.registerReloadListener((ResourceManagerReloadListener) resourceManager -> {
            NekoJS.LOGGER.debug("Detected client resource reload (F3 + T), reloading CLIENT scripts...");
            try {
                root.reload(ScriptType.CLIENT);
            } catch (Exception e) {
                // 旧环境的监听器已被 reload 清空、新环境没建起来时，玩家不会有任何提示——
                // 必须 error 级日志 + 错误面板（rt/ 条目），不再只打 DEBUG
                NekoJS.LOGGER.error("CLIENT script reload (F3+T) failed", e);
                root.errorTracker().recordCallbackError(ScriptType.CLIENT, "client_reload", e);
            }
            postClientGeneration(root);
        });
    }

    /**
     * 客户端生成事件：脚本把 asset JSON 写入 {@code <gameDir>/nekojs/assets}（磁盘 resource
     * pack，懒读保证 reload 时序正确）。先聚合 lang 再生成 assets，与 KubeJS 流程一致。
     */
    private static void postClientGeneration(NekoRuntimeRoot root) {
        try {
            Path assets = NekoJSPaths.get().assets();
            DataGeneratorJS generator = new DataGeneratorJS(assets, "after_mods");
            com.tkisor.nekojs.resource.NekoJSPackLoader.prepareItemAssets(net.minecraft.server.packs.PackType.CLIENT_RESOURCES);
            PluginGenerationHooks.fireGenerateAssets(generator);
            ClientEvents.GENERATE_ASSETS.post(generator, "after_mods");
            // 脚本模型文件已落盘后，为声明过 renderType 且未自写模型的方块补默认模型
            // （26.x 模型驱动：translucent 需要 force_translucent 贴图引用）
            generateSpawnEggModels(generator);
            // 本轮语言集合 = 插件 generatedLangs() 声明 ∪ 脚本 keyed listener 语言，字典序确定；
            // 先整体校验再逐语言生成，任一非法语言代码在写入任何 lang 文件之前整批拒绝，
            // 因此不会产生部分语言文件（非 en_us 的插件语言必须显式声明，见 generatedLangs()）。
            var langs = PluginGenerationHooks.resolveGeneratedLangs(ClientEvents.LANG.registeredKeys());
            for (String lang : langs) {
                LangGeneratorJS langGenerator = new LangGeneratorJS(lang);
                PluginGenerationHooks.fireGenerateLang(langGenerator);
                ClientEvents.LANG.post(langGenerator, lang);
                langGenerator.writeTo(assets, lang);
            }
        } catch (Exception e) {
            // 资产生成失败 = 客户端脚本产物不完整（模型/lang 缺失），同样进错误面板
            NekoJS.LOGGER.error("Client asset generation failed", e);
            root.errorTracker().recordCallbackError(ScriptType.CLIENT, "generate_assets", e);
        }
    }
    private static void generateSpawnEggModels(DataGeneratorJS generator) {
        for (ResourceLocation id : EntityTypeBuilder.registeredSpawnEggs()) {
            String modelPath = id.getNamespace() + "/models/item/" + id.getPath() + ".json";
            if (generator.getJson(modelPath) != null) {
                continue;
            }
            com.google.gson.JsonObject model = new com.google.gson.JsonObject();
            model.addProperty("parent", "minecraft:item/template_spawn_egg");
            generator.json(modelPath, model);
        }
    }
}
