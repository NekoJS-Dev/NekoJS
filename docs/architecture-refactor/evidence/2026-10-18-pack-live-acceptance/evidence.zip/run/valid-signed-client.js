const activation = Pack.activation;
console.info('NEKO_SIGNED_ACCEPTANCE event=entry selector=' + Pack.selector + ' activation=' + activation);
let ticks = 0;
ClientEvents.tickPost(event => {
    ticks++;
    if (ticks === 1 || ticks % 100 === 0) console.info('NEKO_SIGNED_ACCEPTANCE event=tick activation=' + activation + ' n=' + ticks);
});
setInterval(() => console.info('NEKO_SIGNED_ACCEPTANCE event=timer activation=' + activation), 2000);
