import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

repo=Path('D:/mcmodDemo/NekoJS-mult')
tools=repo/'build/priority-closeout'
out=repo/'docs/architecture-refactor/evidence/2026-10-22-source-facts'
assert not out.exists()
out.mkdir()
review=json.loads((tools/'source-facts-review/binding.json').read_text())
for name,sha in review['files'].items(): assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha,name
assert 'BUILD SUCCESSFUL in 6m 50s' in (tools/'source-facts-owner-check.log').read_text(encoding='utf-8')
entries={}
totals=dict.fromkeys(['tests','skipped','failures','errors'],0)
with zipfile.ZipFile(out/'evidence.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def add(path,name):
        data=path.read_bytes();assert name not in entries
        entries[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
    for module,task in [('common','test'),('common-api-processor','test'),('versions/26.1.2','test'),('versions/26.1.2','platformGateTest')]:
        for path in sorted((repo/module/'build/test-results'/task).glob('TEST-*.xml')):
            suite=ET.parse(path).getroot()
            for key in totals: totals[key]+=int(suite.get(key,'0'))
            add(path,'checks/'+module+'/'+task+'/'+path.name)
    for name in ['source-facts-red.log','source-facts-green.log','source-facts-integrated.log','source-facts-owner-check.log','seal-source-facts-checks.py']:
        add(tools/name,'tooling/'+name)
    for path in sorted((tools/'source-facts-review').iterdir()):
        if path.is_file(): add(path,'review/'+path.name)
    for name in review['files']: add(repo/name,'source/'+name)
assert totals==dict(tests=3113,skipped=85,failures=0,errors=0),totals
class_bindings={}
for relative in ['common/build/classes/java/main','versions/26.1.2/build/classes/java/main']:
    for path in (repo/relative).rglob('*.class'):
        name=path.relative_to(repo/relative).as_posix();assert name not in class_bindings
        class_bindings[name]=hashlib.sha256(path.read_bytes()).hexdigest()
artifact,=(repo/'versions/26.1.2/build/libs').glob('*.jar')
with zipfile.ZipFile(artifact) as jar:
    for name,sha in class_bindings.items(): assert hashlib.sha256(jar.read(name)).hexdigest()==sha,name
manifest=dict(base=review['base'],sourceHashes=review['files'],tests=totals,
    classes=class_bindings,artifact=artifact.name,artifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),
    archiveSha256=hashlib.sha256((out/'evidence.zip').read_bytes()).hexdigest(),entries=entries,
    formalPerformance='NOT_RUN_FOR_THIS_SOURCE',remainingNodeBuilds=['1.21.1','26.2.0','26.1.2-fabric','26.2.0-fabric'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(tests=totals,classes=len(class_bindings),entries=len(entries))))
