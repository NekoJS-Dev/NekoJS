"""Archive allowlisted client setup and lifecycle evidence without world data or credentials."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
run = project / 'build/priority-closeout/client-world-acceptance'
destination = project / 'docs/architecture-refactor/evidence/2026-10-18-client-world-login'
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'evidence.zip'
assert not archive.exists(), 'Evidence archives are immutable; choose a new directory.'
secrets = []
for file in [run / 'server/server.properties', Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run/server.properties')]:
    for line in file.read_text().splitlines():
        if line.startswith('rcon.password='):
            secrets.append(line.split('=', 1)[1].encode())
assert all(secrets)
entries = {}

def add(file, name=None):
    data = file.read_bytes()
    if file.suffix in {'.log', '.xml', '.json', '.jsonl', '.java', '.py', '.gradle', '.patch'}:
        for secret in secrets:
            data = data.replace(secret, b'<REDACTED-RCON-CREDENTIAL>')
    else:
        assert not any(secret in data for secret in secrets), 'Unexpected secret in binary evidence'
    key = name or 'run/' + file.relative_to(run).as_posix()
    assert key not in entries
    entries[key] = data

for file in run.iterdir():
    if file.is_file() and file.suffix in {'.log', '.xml', '.json', '.jsonl', '.png', '.gradle'}:
        add(file)
for folder in ['mcp-gui-compat', 'mcp-gui-compat-v2', 'mcp-gui-compat-v3']:
    for file in (run / folder).iterdir():
        if file.is_file() and file.suffix in {'.log', '.json'}:
            add(file)
for name in ['McpGuiLookup.java', 'PatchMcpGuiLookup.java', 'PatchMcpScreenSetters.java',
             'CheckMcpGuiLookup.java', 'prepare-mcp-gui-compat.py', 'repair-client-test-metadata.py',
             'PrepareSignedAcceptance.java', 'prepare-client-network-inputs.py',
             'prepare-client-world-acceptance.py', 'acceptance-server-command.py',
             'archive-client-world-evidence.py']:
    add(project / 'build/priority-closeout' / name, 'tools/' + name)
for world in ['NekoPackAcceptanceA', 'NekoPackAcceptanceB']:
    for file in (run / 'game/saves' / world / 'nekojs_packs').rglob('*'):
        if file.is_file() and file.name == 'manifest.json' or file.is_file() and file.suffix == '.js':
            add(file, 'fixtures/' + world + '/' + file.relative_to(run / 'game/saves' / world / 'nekojs_packs').as_posix())
for name in ['valid-signed-client.js', 'valid-signed-manifest.json']:
    if 'run/' + name not in entries:
        add(run / name)
for node in ['1.21.1', '26.1.2', '26.2.0']:
    for file in (project / 'versions' / node / 'build/test-results').rglob('TEST-*.xml'):
        add(file, 'node-results/' + node + '/' + file.relative_to(project / 'versions' / node / 'build/test-results').as_posix())
files = ['src/main/java/com/tkisor/nekojs/client/NekoJSClient.java',
         'versions/1.21.1/src/main/java/com/tkisor/nekojs/client/NekoJSClient.java',
         'src/test/java/com/tkisor/nekojs/network/PackSyncBridgeSourceTraceTest.java']
for name in files:
    add(project / name, 'source/' + name)
entries['source/change.patch'] = subprocess.check_output(['git', 'diff', '--', *files], cwd=project)
assert not any(secret in data for data in entries.values() for secret in secrets)
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(entries.items()):
        output.writestr(name, data)
manifest = {
    'baseCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project, text=True).strip(),
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archiveBytes': archive.stat().st_size,
    'entries': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())},
    'excluded': ['private keys', 'server.properties', 'world NBT/player data', 'vendor jar binaries'],
}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'entries': len(entries), 'archiveBytes': manifest['archiveBytes'], 'archiveSha256': manifest['archiveSha256']}))
