// Bindings for test scripts
import { $ScriptType } from "java:com/tkisor/nekojs/api";

export {};

declare global {
    let ScriptTypes: typeof $ScriptType;
}
