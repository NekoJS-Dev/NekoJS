/// <reference path="../../../@event-builders/index.d.ts" />

interface DynamicRegistryEvent {
    item(id: string, build?: (build: DynamicItemBuilder) => void): boolean;
    mobEffect(id: string, build?: (build: DynamicMobEffectBuilder) => void): boolean;
    soundEvent(id: string, build?: (build: DynamicSoundEventBuilder) => void): boolean;
}

declare module "@side-only/test/events" {
}

export {};

declare global {
    namespace DynamicRegistryEvents {
        function dynamicRegistry(handler: ((event: DynamicRegistryEvent) => void)): void;
    }

}
