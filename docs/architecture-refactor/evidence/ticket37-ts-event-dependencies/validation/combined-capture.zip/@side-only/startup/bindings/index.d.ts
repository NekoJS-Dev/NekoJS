// Bindings for startup scripts
import { $ScriptType } from "java:com/tkisor/nekojs/api";

export {};

declare global {
    let ScriptTypes: typeof $ScriptType;
}
