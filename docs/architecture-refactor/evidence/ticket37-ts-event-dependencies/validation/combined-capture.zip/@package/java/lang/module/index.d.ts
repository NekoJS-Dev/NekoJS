import { $InputStream } from "java:java/io";
import { $Comparable, $Enum, $String } from "java:java/lang";
import { $AccessFlag, $AccessFlag_ } from "java:java/lang/reflect";
import { $ByteBuffer } from "java:java/nio";
import { $Collection, $List, $Optional, $Set } from "java:java/util";
import { $Supplier } from "java:java/util/function";

declare module "java:java/lang/module" {
    export class $Configuration {
        static empty(): $Configuration;
        static resolveAndBind(arg0: $ModuleFinder, arg1: $Configuration[], arg2: $ModuleFinder, arg3: string[]): $Configuration;
        static resolve(arg0: $ModuleFinder, arg1: $Configuration[], arg2: $ModuleFinder, arg3: string[]): $Configuration;
        findModule(arg0: string): $Optional<$ResolvedModule>;
        modules(): $Set<$ResolvedModule>;
        parents(): $List<$Configuration>;
        resolveAndBind(arg0: $ModuleFinder, arg1: $ModuleFinder, arg2: string[]): $Configuration;
        resolve(arg0: $ModuleFinder, arg1: $ModuleFinder, arg2: string[]): $Configuration;
        toString(): string;
    }

    export class $ModuleDescriptor implements $Comparable {
        get automatic(): boolean;
        isAutomatic(): boolean;
        get open(): boolean;
        isOpen(): boolean;
        static newAutomaticModule(arg0: string): $ModuleDescriptor$Builder;
        static newModule(arg0: string, arg1: $ModuleDescriptor$Modifier_[]): $ModuleDescriptor$Builder;
        static newModule(arg0: string): $ModuleDescriptor$Builder;
        static newOpenModule(arg0: string): $ModuleDescriptor$Builder;
        static read(arg0: $InputStream, arg1: $Supplier<string[]>): $ModuleDescriptor;
        static read(arg0: $InputStream): $ModuleDescriptor;
        static read(arg0: $ByteBuffer, arg1: $Supplier<string[]>): $ModuleDescriptor;
        static read(arg0: $ByteBuffer): $ModuleDescriptor;
        accessFlags(): $Set<$AccessFlag>;
        compareTo(arg0: $ModuleDescriptor): number;
        equals(arg0: object): boolean;
        exports(): $Set<$ModuleDescriptor$Exports>;
        hashCode(): number;
        mainClass(): $Optional<string>;
        modifiers(): $Set<$ModuleDescriptor$Modifier>;
        name(): string;
        opens(): $Set<$ModuleDescriptor$Opens>;
        packages(): $Set<string>;
        provides(): $Set<$ModuleDescriptor$Provides>;
        rawVersion(): $Optional<string>;
        requires(): $Set<$ModuleDescriptor$Requires>;
        toNameAndVersion(): string;
        toString(): string;
        uses(): $Set<string>;
        version(): $Optional<$ModuleDescriptor$Version>;
    }

    export class $ModuleDescriptor$Builder {
        build(): $ModuleDescriptor;
        exports(arg0: string, arg1: string[]): $ModuleDescriptor$Builder;
        exports(arg0: string): $ModuleDescriptor$Builder;
        exports(arg0: $ModuleDescriptor$Exports): $ModuleDescriptor$Builder;
        exports(arg0: $ModuleDescriptor$Exports$Modifier_[], arg1: string, arg2: string[]): $ModuleDescriptor$Builder;
        exports(arg0: $ModuleDescriptor$Exports$Modifier_[], arg1: string): $ModuleDescriptor$Builder;
        mainClass(arg0: string): $ModuleDescriptor$Builder;
        opens(arg0: string, arg1: string[]): $ModuleDescriptor$Builder;
        opens(arg0: string): $ModuleDescriptor$Builder;
        opens(arg0: $ModuleDescriptor$Opens): $ModuleDescriptor$Builder;
        opens(arg0: $ModuleDescriptor$Opens$Modifier_[], arg1: string, arg2: string[]): $ModuleDescriptor$Builder;
        opens(arg0: $ModuleDescriptor$Opens$Modifier_[], arg1: string): $ModuleDescriptor$Builder;
        packages(arg0: string[]): $ModuleDescriptor$Builder;
        provides(arg0: string, arg1: string[]): $ModuleDescriptor$Builder;
        provides(arg0: $ModuleDescriptor$Provides): $ModuleDescriptor$Builder;
        requires(arg0: string): $ModuleDescriptor$Builder;
        requires(arg0: $ModuleDescriptor$Requires): $ModuleDescriptor$Builder;
        requires(arg0: $ModuleDescriptor$Requires$Modifier_[], arg1: string, arg2: $ModuleDescriptor$Version): $ModuleDescriptor$Builder;
        requires(arg0: $ModuleDescriptor$Requires$Modifier_[], arg1: string): $ModuleDescriptor$Builder;
        uses(arg0: string): $ModuleDescriptor$Builder;
        version(arg0: string): $ModuleDescriptor$Builder;
        version(arg0: $ModuleDescriptor$Version): $ModuleDescriptor$Builder;
    }

    export class $ModuleDescriptor$Exports implements $Comparable {
        get qualified(): boolean;
        isQualified(): boolean;
        accessFlags(): $Set<$AccessFlag>;
        compareTo(arg0: $ModuleDescriptor$Exports): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        modifiers(): $Set<$ModuleDescriptor$Exports$Modifier>;
        source(): string;
        targets(): $Set<string>;
        toString(): string;
    }

    export class $ModuleDescriptor$Modifier {
        static AUTOMATIC: $ModuleDescriptor$Modifier;
        static MANDATED: $ModuleDescriptor$Modifier;
        static OPEN: $ModuleDescriptor$Modifier;
        static SYNTHETIC: $ModuleDescriptor$Modifier;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ModuleDescriptor$Modifier[];
        static valueOf(name: string): $ModuleDescriptor$Modifier;
    }

    export class $ModuleDescriptor$Opens implements $Comparable {
        get qualified(): boolean;
        isQualified(): boolean;
        accessFlags(): $Set<$AccessFlag>;
        compareTo(arg0: $ModuleDescriptor$Opens): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        modifiers(): $Set<$ModuleDescriptor$Opens$Modifier>;
        source(): string;
        targets(): $Set<string>;
        toString(): string;
    }

    export class $ModuleDescriptor$Provides implements $Comparable {
        compareTo(arg0: $ModuleDescriptor$Provides): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        providers(): $List<string>;
        service(): string;
        toString(): string;
    }

    export class $ModuleDescriptor$Requires implements $Comparable {
        accessFlags(): $Set<$AccessFlag>;
        compareTo(arg0: $ModuleDescriptor$Requires): number;
        compiledVersion(): $Optional<$ModuleDescriptor$Version>;
        equals(arg0: object): boolean;
        hashCode(): number;
        modifiers(): $Set<$ModuleDescriptor$Requires$Modifier>;
        name(): string;
        rawCompiledVersion(): $Optional<string>;
        toString(): string;
    }

    export class $ModuleDescriptor$Version implements $Comparable {
        static parse(arg0: string): $ModuleDescriptor$Version;
        compareTo(arg0: $ModuleDescriptor$Version): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export type $ModuleDescriptor$Modifier_ = $ModuleDescriptor$Modifier | "AUTOMATIC" | "MANDATED" | "OPEN" | "SYNTHETIC";
}
