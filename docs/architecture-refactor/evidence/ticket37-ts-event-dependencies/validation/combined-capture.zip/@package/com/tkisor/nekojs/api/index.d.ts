import { $Enum, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";

declare module "java:com/tkisor/nekojs/api" {
    export class $ScriptType {
        static CLIENT: $ScriptType;
        static SERVER: $ScriptType;
        static STARTUP: $ScriptType;
        static TEST: $ScriptType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ScriptType[];
        static valueOf(name: string): $ScriptType;
    }

    export interface $ScriptTypePredicate extends $Predicate {
        any(): $ScriptTypePredicate;
        canApplyOn(type: $ScriptType_): boolean;
        exact(type: $ScriptType_): $ScriptTypePredicate;
        negate(): $ScriptTypePredicate;
        streamMatched(): $Stream<$ScriptType>;
    }

    export type $ScriptType_ = $ScriptType | "CLIENT" | "SERVER" | "STARTUP" | "TEST";
}
