export * as api from "java:com/tkisor/nekojs/api";

