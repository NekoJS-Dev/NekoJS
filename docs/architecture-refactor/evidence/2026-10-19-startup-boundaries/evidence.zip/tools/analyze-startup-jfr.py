import json
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

tools = Path(__file__).resolve().parent
out = tools / 'startup-jfr-606d1fff-v2'
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
cp = (tools / 'root-reload-diagnostic-v3/runtime-classpath.txt').read_text(encoding='utf-8').strip()
gson = [part for part in cp.split(';') if Path(part).name.startswith('gson-') and Path(part).is_file()]
assert len(gson) == 1
classes = out / 'analysis-classes'
classes.mkdir()
binding = json.loads((out / 'binding.json').read_text(encoding='utf-8-sig'))
session = json.loads((out / 'session.json').read_text(encoding='utf-8-sig'))
cutoff = datetime.fromisoformat(binding['launchRequestedUtc']) + timedelta(milliseconds=session['doneWallMs'])
commands = [
    [str(java / 'javac.exe'), '-cp', gson[0], '-d', str(classes), str(tools / 'StartupJfrAnalysis.java')],
    [str(java / 'java.exe'), '-cp', str(classes)+';'+gson[0], 'StartupJfrAnalysis', str(out / 'startup.jfr'), str(out / 'analysis.json'), cutoff.isoformat()],
]
for i, command in enumerate(commands):
    with (out / f'analysis-{i}.log').open('xb') as stdout, (out / f'analysis-{i}-stderr.log').open('xb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, i
analysis = json.loads((out / 'analysis.json').read_text(encoding='utf-8'))
print(json.dumps({k: analysis[k] for k in ['firstEventUtc', 'lastEventUtc', 'jvmStartUtc', 'processId', 'recordingArgumentMatched', 'threadSamples', 'eventDurationSumsMsNotAdditiveAcrossThreads']}, indent=2))
