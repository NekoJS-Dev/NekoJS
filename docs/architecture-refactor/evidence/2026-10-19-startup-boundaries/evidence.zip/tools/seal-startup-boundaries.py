"""Preserve failed controllers and the recovered startup recording analysis."""
import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project / 'build/priority-closeout'
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
first = tools / 'startup-jfr-606d1fff'
second = tools / 'startup-jfr-606d1fff-v2'
prep = json.loads((tools / 'source-map-606d1fff-formal/preparation.json').read_text())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True).strip()
classes = {}
for relative in ['common/build/classes/java/main','versions/26.1.2/build/classes/java/main']:
    base = tree / relative
    for file in base.rglob('*.class'):
        name = file.relative_to(base).as_posix()
        assert name not in classes
        classes[name] = hashlib.sha256(file.read_bytes()).hexdigest()
assert classes == prep['classBindings']
for file in (tree / 'versions/26.1.2/build').rglob('*.txt'):
    assert 'nekoStartup' not in file.read_text(errors='replace'), file
state = json.loads((second/'session.json').read_text(encoding='utf-8-sig'))
analysis = json.loads((second/'analysis-at.json').read_text())
binding = json.loads((second/'binding.json').read_text(encoding='utf-8-sig'))
assert state['extra']['profileFailure'] == 'Unexpected game owner or missing startup JFR argument'
assert not state['forcedKill'] and not state['extra']['killed'] and state['extra']['stopChannel']=='rcon'
assert analysis['processId']==18976 and analysis['recordingArgumentMatched']
launch = datetime.fromisoformat(binding['launchRequestedUtc'])
jvm = datetime.fromisoformat(analysis['jvmStartUtc'])
done = launch + timedelta(milliseconds=state['doneWallMs'])
task = re.search(r'STARTUP_PROFILE_GAME_TASK (\S+)', (second/'startup-profile-stdout.log').read_text(encoding='utf-8')).group(1)
cfg = tree/'src/main/resources/META-INF/accesstransformer.cfg'
instructions = [line.split() for line in cfg.read_text(encoding='utf-8').splitlines() if re.match(r'^(public|protected|private|default)([+-]f)?\s+',line.strip())]
summary = dict(diagnosticOnly=True, formalVerdictUnchanged='FAIL', controllerExitCodes=[1,1],
    firstGameStarted=False, recoveredFromDumpOnExit=True, unassistedJfrStopAtDone=False,
    jfrPid=analysis['processId'], recordingArgumentMatched=True,
    launchRequestedUtc=launch.isoformat(), taskActionUtc=task, jvmStartUtc=jvm.isoformat(),
    approximateDoneUtc=done.isoformat(), launchToJvmMs=(jvm-launch).total_seconds()*1000,
    jvmToApproximateDoneMs=(done-jvm).total_seconds()*1000, observedDoneWallMs=state['doneWallMs'],
    rawJfrSha256=hashlib.sha256((second/'startup.jfr').read_bytes()).hexdigest(),
    sourceAt=dict(lines=len(cfg.read_text(encoding='utf-8').splitlines()), instructions=len(instructions), classes=len({p[1] for p in instructions})),
    postRunClassesUnchanged=True, normalRunConfigurationRestored=True)
(second/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(second/'post-run-bindings.json').write_text(json.dumps(dict(classBindings=classes,trackedSourcesClean=True,normalRunConfigurationRestored=True),indent=2)+'\n')
target=project/'docs/architecture-refactor/evidence/2026-10-19-startup-boundaries'
target.mkdir(parents=True,exist_ok=True)
secrets=[]
for file in [tree/'versions/26.1.2/run/server.properties',tools/'client-world-acceptance/server/server.properties']:
    secrets.extend(line.split('=',1)[1] for line in file.read_text().splitlines() if line.startswith('rcon.password='))
entries,redactions={},{}
def add(file,name):
    data=file.read_bytes()
    encoding='utf-16' if data.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig'
    try: text=data.decode(encoding)
    except UnicodeDecodeError:
        encoding='gb18030';text=data.decode(encoding)
    if any(secret in text for secret in secrets):
        redactions[name]=dict(originalSha256=hashlib.sha256(data).hexdigest())
        for secret in secrets: text=text.replace(secret,'<REDACTED-RCON-CREDENTIAL>')
        data=text.encode(encoding)
    assert all(secret.encode(codec) not in data for secret in secrets for codec in ['utf-8','utf-16-le','utf-16-be'])
    assert name not in entries
    entries[name]=data
for folder,label in [(first,'initial-failure'),(second,'recovered-recording')]:
    for file in folder.rglob('*'):
        if file.is_file() and file.suffix not in {'.jfr','.class'} and 'analysis-classes' not in file.parts:
            add(file,label+'/'+file.relative_to(folder).as_posix())
for name in ['startup-jfr-v2.init.gradle','startup-jfr-v2-diagnostic.ps1','run-startup-jfr-v2.py',
             'startup-jfr-v2-controller.log','startup-jfr-v2-controller-stderr.log','startup-jfr-v2-exit.json',
             'StartupJfrAnalysis.java','analyze-startup-jfr.py','analyze-startup-jfr-at.py',
             'startup-jfr-restored-run-config.log','seal-startup-boundaries.py']:
    add(tools/name,'tools/'+name)
add(tools/'source-map-606d1fff-formal/preparation.json','formal-reference/preparation.json')
add(cfg,'source/accesstransformer.cfg')
entries['redactions.json']=(json.dumps(redactions,indent=2)+'\n').encode()
packed=target/'evidence.zip'
with zipfile.ZipFile(packed,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,data in sorted(entries.items()):archive.writestr(name,data)
manifest=dict(sourceRevision=prep['revision'],diagnosticOnly=True,formalVerdictUnchanged='FAIL',
              controllerExitCodes=[1,1],rawJfrExcluded=True,rawJfrSha256=summary['rawJfrSha256'],
              archiveBytes=packed.stat().st_size,archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
              entries={name:hashlib.sha256(data).hexdigest() for name,data in sorted(entries.items())})
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in manifest.items() if k!='entries'}))
