"""Run one owned startup recording; keep it separate from formal measurements."""
import json
import os
import subprocess
import time
from pathlib import Path

tools = Path(__file__).resolve().parent
tree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
environment = dict(os.environ)
properties = dict(line.split('=', 1) for line in (tree / 'versions/26.1.2/run/server.properties').read_text().splitlines()
                  if line and not line.startswith('#') and '=' in line)
environment['NEKO_PERF_RCON_PASS'] = properties['rcon.password']
started = time.monotonic()
with (tools / 'startup-jfr-v2-controller.log').open('xb') as out, (tools / 'startup-jfr-v2-controller-stderr.log').open('xb') as err:
    process = subprocess.Popen(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(tools / 'startup-jfr-v2-diagnostic.ps1')],
                               cwd=tree, env=environment, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
code = process.wait()
result = dict(exitCode=code, seconds=time.monotonic() - started)
(tools / 'startup-jfr-v2-exit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
raise SystemExit(code)
