import jdk.jfr.consumer.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import com.google.gson.*;

/** Exports timing and stack counts without JVM command lines or environment properties. */
public class StartupJfrAnalysis {
    static Map<String, Long> sorted(Map<String, Long> values, int limit) {
        var result = new LinkedHashMap<String, Long>();
        values.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed())
            .limit(limit).forEach(e -> result.put(e.getKey(), e.getValue()));
        return result;
    }
    public static void main(String[] args) throws Exception {
        Instant first = Instant.MAX, last = Instant.MIN, jvmStart = null;
        Instant cutoff = Instant.parse(args[2]);
        Long processId = null;
        boolean recordingArgumentMatched = false;
        var eventCounts = new HashMap<String, Long>();
        var threads = new HashMap<String, Long>();
        var leaves = new HashMap<String, Map<String, Long>>();
        var stacks = new HashMap<String, Map<String, Long>>();
        var neko = new HashMap<String, Long>();
        var loader = new HashMap<String, Long>();
        var seconds = new TreeMap<Long, Map<String, Long>>();
        var durations = new HashMap<String, Double>();
        var longEvents = new ArrayList<Map<String, Object>>();
        var cpuLoad = new ArrayList<Map<String, Object>>();
        try (var file = new RecordingFile(Path.of(args[0]))) {
            while (file.hasMoreEvents()) {
                var e = file.readEvent();
                if (e.getStartTime().isBefore(first)) first = e.getStartTime();
                if (e.getEndTime().isAfter(last)) last = e.getEndTime();
                String type = e.getEventType().getName();
                if (type.equals("jdk.JVMInformation")) {
                    jvmStart = Instant.ofEpochMilli(e.getLong("jvmStartTime"));
                    if (e.hasField("pid")) processId = e.getLong("pid");
                    String arguments = e.getString("jvmArguments");
                    recordingArgumentMatched = arguments != null && arguments.contains("filename=D:/mcmodDemo/NekoJS-mult/build/priority-closeout/startup-jfr-606d1fff-v2/startup.jfr");
                }
                if (e.getStartTime().isAfter(cutoff)) continue;
                eventCounts.merge(type, 1L, Long::sum);
                if (type.equals("jdk.CPULoad")) {
                    cpuLoad.add(Map.of("utc", e.getStartTime().toString(), "jvmUser", e.getFloat("jvmUser"),
                        "jvmSystem", e.getFloat("jvmSystem"), "machineTotal", e.getFloat("machineTotal")));
                }
                if (Set.of("jdk.Compilation", "jdk.FileRead", "jdk.FileWrite", "jdk.GCPhasePause", "jdk.JavaMonitorEnter").contains(type)) {
                    double millis = e.getDuration().toNanos() / 1e6;
                    durations.merge(type, millis, Double::sum);
                    if (millis >= 20) {
                        var row = new LinkedHashMap<String, Object>();
                        row.put("event", type); row.put("startUtc", e.getStartTime().toString()); row.put("wallMs", millis);
                        row.put("thread", e.getThread() == null ? "" : e.getThread().getJavaName());
                        if (e.hasField("path")) row.put("path", e.getString("path"));
                        longEvents.add(row);
                    }
                }
                if (!type.equals("jdk.ExecutionSample") && !type.equals("jdk.NativeMethodSample")) continue;
                var thread = e.getThread("sampledThread");
                if (thread == null || e.getStackTrace() == null || e.getStackTrace().getFrames().isEmpty()) continue;
                String name = thread.getJavaName();
                threads.merge(name, 1L, Long::sum);
                seconds.computeIfAbsent(e.getStartTime().getEpochSecond(), ignored -> new TreeMap<>()).merge(name, 1L, Long::sum);
                var frames = e.getStackTrace().getFrames();
                var leaf = frames.getFirst().getMethod();
                leaves.computeIfAbsent(name, ignored -> new HashMap<>()).merge(leaf.getType().getName()+"."+leaf.getName(), 1L, Long::sum);
                var labels = new ArrayList<String>();
                var uniqueNeko = new HashSet<String>();
                var uniqueLoader = new HashSet<String>();
                for (var frame : frames) {
                    var method = frame.getMethod();
                    String label = method.getType().getName()+"."+method.getName()+":"+frame.getLineNumber();
                    labels.add(label);
                    if (method.getType().getName().startsWith("com.tkisor.nekojs.")) uniqueNeko.add(name+" | "+label);
                    if (method.getType().getName().startsWith("net.neoforged.accesstransformer.")) uniqueLoader.add(name+" | "+label);
                }
                for (String label : uniqueNeko) neko.merge(label, 1L, Long::sum);
                for (String label : uniqueLoader) loader.merge(label, 1L, Long::sum);
                stacks.computeIfAbsent(name, ignored -> new HashMap<>()).merge(String.join("\n", labels), 1L, Long::sum);
            }
        }
        var outputLeaves = new LinkedHashMap<String, Object>();
        var outputStacks = new LinkedHashMap<String, Object>();
        for (String thread : sorted(threads, 20).keySet()) {
            outputLeaves.put(thread, sorted(leaves.get(thread), 35));
            outputStacks.put(thread, sorted(stacks.get(thread), 25));
        }
        longEvents.sort(Comparator.<Map<String, Object>>comparingDouble(row -> ((Number)row.get("wallMs")).doubleValue()).reversed());
        var result = new LinkedHashMap<String, Object>();
        result.put("diagnosticOnly", true); result.put("countsAreNotMilliseconds", true);
        result.put("firstEventUtc", first.toString()); result.put("lastEventUtc", last.toString());
        result.put("jvmStartUtc", jvmStart == null ? null : jvmStart.toString());
        result.put("processId", processId); result.put("recordingArgumentMatched", recordingArgumentMatched);
        result.put("approximateDoneCutoffUtc", cutoff.toString());
        result.put("eventCounts", sorted(eventCounts, 150)); result.put("threadSamples", sorted(threads, 100));
        result.put("threadLeafCounts", outputLeaves); result.put("threadStacks", outputStacks);
        result.put("nekoInclusiveCounts", sorted(neko, 150)); result.put("samplesByUtcSecond", seconds);
        result.put("accessTransformerInclusiveCounts", sorted(loader, 100));
        result.put("eventDurationSumsMsNotAdditiveAcrossThreads", durations);
        result.put("longEvents", longEvents.stream().limit(100).toList()); result.put("cpuLoad", cpuLoad);
        Files.writeString(Path.of(args[1]), new GsonBuilder().setPrettyPrinting().create().toJson(result));
        System.out.println("STARTUP_JFR_PARSED threads="+threads.size()+" first="+first+" last="+last);
    }
}
