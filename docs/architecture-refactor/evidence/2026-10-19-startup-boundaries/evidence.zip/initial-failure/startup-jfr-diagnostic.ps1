﻿$ErrorActionPreference = 'Stop'
$env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
$ProjectDir = 'C:\Users\11515\.codex\worktrees\domain-perf-0965\NekoJS-mult'
$OutDir = 'D:\mcmodDemo\NekoJS-mult\build\priority-closeout\startup-jfr-606d1fff'
$javaRoot = 'C:\Program Files\Java\jdk-25.0.2'
$env:JAVA_HOME = $javaRoot
$env:PATH = "$javaRoot\bin;$env:PATH"
$GradleUserHome = 'D:\mcmodDemo\NekoJS\.gradle-<REDACTED-RCON-CREDENTIAL>'
$Node = '26.1.2'
$ServerPort = 25871
$RconPort = 25872
$RconPass = $env:NEKO_PERF_RCON_PASS
$RunDir = Join-Path $ProjectDir 'versions\26.1.2\run'
$sampleDirectory = Join-Path $ProjectDir 'bench\perf'
$FixtureDir = Join-Path $sampleDirectory 'fixtures\nekojs'
$perfOut = Join-Path $RunDir 'nekojs\perf-out'
$GitRev = '606d1fff'
$script:StdinOk = $null
$script:TestStdin = $false
if (Test-Path -LiteralPath $OutDir) { throw 'Diagnostic output already exists' }
if ((& git -C $ProjectDir rev-parse HEAD).Trim() -ne '606d1fff6b14e4a513bf16e247b0ec37437195c6') { throw 'Source mismatch' }
if (@(& git -C $ProjectDir status --porcelain).Count) { throw 'Owned source is not clean' }
if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 25871,25872).Count) { throw 'Diagnostic ports occupied' }
foreach ($target in @($RunDir, (Join-Path $RunDir 'nekojs'), (Join-Path $RunDir '.neko_probe'), (Join-Path $RunDir 'world'))) {
    if (-not [IO.Path]::GetFullPath($target).StartsWith([IO.Path]::GetFullPath($RunDir), [StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside owned run directory' }
    if (Test-Path -LiteralPath $target) {
        $items = @((Get-Item -LiteralPath $target -Force)) + @(Get-ChildItem -LiteralPath $target -Recurse -Force)
        if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Reparse point on owned run path' }
    }
}
$ancestor = Get-Item -LiteralPath $RunDir
while ($ancestor) {
    if ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point on run ancestor' }
    $ancestor = $ancestor.Parent
}
$sampleFile = Join-Path $sampleDirectory 'sample.ps1'
if ((Get-FileHash -LiteralPath $sampleFile -Algorithm SHA256).Hash.ToLowerInvariant() -ne '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4') { throw 'Sampler source changed' }
$parseTokens = $null
$parseErrors = $null
$sampleAst = [Management.Automation.Language.Parser]::ParseFile($sampleFile, [ref]$parseTokens, [ref]$parseErrors)
if ($parseErrors.Count) { throw 'Sampler parse failed' }
foreach ($definition in $sampleAst.FindAll({ param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] }, $false)) {
    $source = $definition.Extent.Text.Replace('$PSScriptRoot', "'$sampleDirectory'")
    if ($definition.Name -eq 'Invoke-ServerSession') {
        $original = '/c gradlew.bat :$Node`:runServer --console=plain'
        if (-not $source.Contains($original)) { throw 'Launcher patch target missing' }
        $source = $source.Replace($original, $original + ' --offline --init-script D:/mcmodDemo/NekoJS-mult/build/priority-closeout/startup-jfr.init.gradle')
    }
    . ([ScriptBlock]::Create($source))
}
New-Item -ItemType Directory -Path $OutDir | Out-Null
Write-EnvSnapshot
Deploy-Fixtures -Bench:$false
$script:ProfileFailure = $null
@{launchRequestedUtc=[DateTime]::UtcNow.ToString('o');diagnosticOnly=$true;sourceRevision='606d1fff6b14e4a513bf16e247b0ec37437195c6'} | ConvertTo-Json | Set-Content (Join-Path $OutDir 'binding.json') -Encoding UTF8
$session = Invoke-ServerSession -Tag 'startup-profile' -OnDone {
    param($proc, $outLog, $sw)
    try {
        $listeners = @(Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 25871)
        if ($listeners.Count -ne 1) { throw 'Expected one owned game listener' }
        $gameId = $listeners[0].OwningProcess
        $game = Get-CimInstance Win32_Process -Filter "ProcessId=$gameId"
        if ($game.ExecutablePath -ne "$javaRoot\bin\java.exe" -or -not $game.CommandLine.Contains($ProjectDir) -or -not $game.CommandLine.Contains('startup-jfr-606d1fff/startup.jfr')) { throw 'Unexpected game owner or missing startup JFR argument' }
        @{pid=$gameId;launcher=$proc.Id;createdUtc=$game.CreationDate.ToUniversalTime().ToString('o');doneObservedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content (Join-Path $OutDir 'owner.json') -Encoding UTF8
        & "$javaRoot\bin\jcmd.exe" $gameId JFR.stop name=nekoStartup | Set-Content (Join-Path $OutDir 'jfr-stop.txt')
        if ($LASTEXITCODE -ne 0) { throw 'Startup JFR stop failed' }
    } catch {
        $script:ProfileFailure = $_.Exception.Message
    } finally {
        $stop = Stop-Server $proc
    }
    @{stopSent=$true;stopChannel=$stop.channel;killed=$stop.killed;profileFailure=$script:ProfileFailure}
}
$session | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $OutDir 'session.json') -Encoding UTF8
if ($null -eq $session.doneWallMs -or $session.forcedKill -or $session.extra.killed -or $session.extra.stopChannel -ne 'rcon' -or $script:ProfileFailure) { throw 'Startup diagnostic was not successful; inspect retained artifacts' }
if (-not (Test-Path -LiteralPath (Join-Path $OutDir 'startup.jfr'))) { throw 'Startup recording missing' }
Write-Output 'STARTUP_PROFILE_COMPLETE'
