const fs = require('node:fs');
const Minecraft = Java.type('net.minecraft.client.Minecraft');
const InputDriver = Java.type('nekojs.acceptance.frame.InputDriver');
const Compat = Java.type('com.tkisor.nekojs.platform.compat.McClientCompat');
let last = '';
ClientEvents.postEffects(event => {
    if (!event.register('minecraft:invert', {blurRadius:16,blurRounds:1})) throw new Error('Owned effect declaration rejected');
});
ClientEvents.tickPost(() => {
    const mc = Minecraft.getInstance();
    if (!fs.existsSync('nekojs/data/step.txt')) return;
    const step = String(fs.readFileSync('nekojs/data/step.txt','utf8')).trim();
    if (step === last || step === 'idle') return;
    last = step;
    if (step === 'close') { console.info('POST-FRAME-OWNED-STOP'); mc.stop(); return; }
    if (mc.player === null || mc.gui.overlay() !== null) { last = ''; return; }
    if (step.startsWith('reload')) {
        fs.writeFileSync('nekojs/data/step.txt','idle');
        console.info('POST-FRAME-RELOAD-REQUEST ' + step);
        InputDriver.reloadResourcesWithF3T();
        return;
    }
    if (!step.startsWith('clear-') && !step.startsWith('effect-') && !step.startsWith('retained-')) return;
    Compat.get().showScreen(null);
    const noSetRequested = step.startsWith('retained-');
    const accepted = noSetRequested ? null : step.startsWith('effect-') ? PostEffects.set('minecraft:invert') : PostEffects.clear();
    const arm = {step,accepted,noSetRequested,generation:PostEffects.activeGeneration(),current:PostEffects.current(),active:PostEffects.isActive(),sameThread:mc.isSameThread()};
    console.info('POST-FRAME-SET-RETURN ' + JSON.stringify(arm));
    fs.writeFileSync('nekojs/data/arm.json',JSON.stringify(arm));
});
console.info('POST-FRAME-CLIENT-READY');
