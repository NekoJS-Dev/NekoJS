package nekojs.acceptance.frame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import nekojs.acceptance.frame.mixin.KeyboardInvoker;
import net.minecraft.client.input.KeyEvent;
import org.lwjgl.glfw.GLFW;
/** Exercises native debug-key dispatch with a temporary synthetic F3 state. */
public final class InputDriver {
    private static boolean f3Held;
    private InputDriver() {}
    public static boolean f3Held() { return f3Held; }
    public static void reloadResourcesWithF3T() {
        Minecraft minecraft = Minecraft.getInstance();
        if (!minecraft.isSameThread()) throw new IllegalStateException("Owned input requires the client thread");
        KeyboardInvoker keyboard = (KeyboardInvoker) minecraft.keyboardHandler;
        long window = minecraft.getWindow().handle();
        f3Held = true;
        try {
            KeyMapping.setAll();
            System.out.println("OWNED-F3T-NATIVE-PRESS-BEGIN");
            keyboard.nekoFramePress(window, GLFW.GLFW_PRESS, new KeyEvent(GLFW.GLFW_KEY_T, 0, 0));
        } finally {
            f3Held = false;
            KeyMapping.setAll();
            keyboard.nekoFramePress(window, GLFW.GLFW_RELEASE, new KeyEvent(GLFW.GLFW_KEY_T, 0, 0));
            System.out.println("OWNED-F3T-NATIVE-PRESS-END held=" + f3Held);
        }
    }
}
