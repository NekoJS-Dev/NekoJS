package nekojs.acceptance.frame.mixin;
import nekojs.acceptance.frame.InputDriver;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
/** Calls the same native key entry used by the GLFW callback in a development run. */
@Mixin(value = KeyboardHandler.class, remap = false)
public interface KeyboardInvoker {
    @Invoker("keyPress")
    void nekoFramePress(long window, int action, KeyEvent event);
}
