"""Seal current installed-client frames, exact artifacts and independent source/pixel reviews."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-24-candidate-render'
assert not out.exists()
trials = [(short, tools / f'posteffects-{short}-installed-975496d3-v1') for short in ['121', '261', '262']]
secrets = set()
for short, trial in trials:
    result = json.loads((trial / 'run-result.json').read_text())
    review = json.loads((trial / 'pixel-review.json').read_text())
    assert result['mechanicalVerdict'] == review['verdict'] == 'PASS' and review['screenshotsReviewed']
    assert result['clientExit'] == result['serverExit'] == 0 and not result['errors'] and not result['forced']
    assert len(result['stages']) == (16 if short == '121' else 7)
    props = dict(line.split('=', 1) for line in (trial / 'server/server.properties').read_text().splitlines()
                 if '=' in line and not line.startswith('#'))
    secrets.add(props['rcon.password'])
entries = {}
redactions = {}
def add(name, file):
    original = data = file.read_bytes()
    for secret in secrets:
        if secret:
            for encoding in ['utf8', 'utf-16-le', 'utf-16-be']:
                data = data.replace(secret.encode(encoding), '[REDACTED]'.encode(encoding))
    if data != original:
        redactions[name] = hashlib.sha256(original).hexdigest()
    assert name not in entries
    entries[name] = data
references = {}
for short, folder, name in [
    ('261', '2026-10-24-method-bounds-performance', 'nekojs-neoforge-26.1.2-1.1.0-preview3.jar'),
    ('262', '2026-10-24-candidate-tcp', 'nekojs-neoforge-26.2.0-1.1.0-preview3.jar')]:
    file = repo / 'docs/architecture-refactor/evidence' / folder / 'evidence.zip'
    references[short] = dict(path='../' + folder + '/evidence.zip', archiveSha256=hashlib.sha256(file.read_bytes()).hexdigest(), entry='artifact/' + name)
for short, trial in trials:
    for file in trial.iterdir():
        if file.is_file() and file.suffix in ['.json', '.jsonl', '.log', '.png', '.gradle']:
            add(short + '/' + file.name, file)
    for folder in ['src', 'build/classes/java/main']:
        for file in (trial / folder).rglob('*'):
            if file.is_file():
                add(short + '/' + folder + '/' + file.relative_to(trial / folder).as_posix(), file)
    binding = json.loads((trial / 'candidate-binding.json').read_text())
    for side in ['server', 'client']:
        for name in ['stdout.log', 'stderr.log', 'installed-source.json', 'owned-process.json']:
            file = trial / side / name
            if file.exists():
                add(short + '/' + side + '/' + name, file)
        for file in (trial / side / 'nekojs').rglob('*'):
            if file.is_file() and file.suffix in ['.js', '.toml'] and 'data' not in file.relative_to(trial / side / 'nekojs').parts:
                add(short + '/' + side + '/' + file.relative_to(trial / side).as_posix(), file)
        artifact = binding['artifacts'][side]
        jar = trial / side / 'mods' / artifact['name']
        assert hashlib.sha256(jar.read_bytes()).hexdigest() == artifact['sha256']
        with zipfile.ZipFile(jar) as archive:
            for name, expected in binding['classBindings'].items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == expected
        if short == '121':
            add('artifact/' + artifact['name'], jar)
            assert entries['artifact/' + artifact['name']] == jar.read_bytes()
for name in ['prepare-method-bounds-native.py', 'run-method-bounds-native-all.py', 'review-method-bounds-native.py',
    'review-121-f3t-final.py', 'bind-method-bounds-runtime.py', 'method-bounds-runtime-binding-v3.log',
    'method-bounds-native-controller.log', 'seal-method-bounds-native.py']:
    add('tools/' + name, tools / name)
for short in ['121', '261', '262']:
    for name in [f'run-method-bounds-native-{short}.py', f'review-method-bounds-native-{short}.py',
                 f'method-bounds-native-{short}-run.log', f'method-bounds-native-{short}-pixel-review.log']:
        add('tools/' + name, tools / name)
add('tools/rcon.py', repo / 'bench/perf/rcon.py')
out.mkdir()
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(out / 'manifest.json').write_text(json.dumps(dict(sourceRevision='975496d3bddf6fc76b206921a1d09207120ca24d',
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(), artifactReferences=references,
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())},
    redactedOriginalHashes=redactions,
    exclusions=['world binaries', 'server.properties', 'full launch argument files', 'runtime libraries', 'maintainer acceptance']), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size, frames=30, normalExits=6)))
