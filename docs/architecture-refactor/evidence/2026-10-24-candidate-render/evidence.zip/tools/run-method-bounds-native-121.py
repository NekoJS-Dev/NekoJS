import hashlib
import importlib.util
import json
import os
import re
import socket
import subprocess
import time
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/priority-closeout/posteffects-121-installed-975496d3-v1'
server = root / 'server'
client = root / 'client'
assert root.is_dir() and not (root / 'run-result.json').exists()
spec = importlib.util.spec_from_file_location('owned_rcon', project / 'bench/perf/rcon.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
props = dict(line.split('=', 1) for line in (server / 'server.properties').read_text().splitlines() if '=' in line and not line.startswith('#'))
result = dict(stages=[], errors=[], forced=[], clientExit=None, serverExit=None, screenshotsReviewed=False)
processes = []


def wait_for(predicate, seconds, label):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        value = predicate()
        if value:
            return value
        for name, process, directory in processes:
            if process.poll() is not None:
                raise RuntimeError(f'{name} exited during {label}: {process.returncode}')
        time.sleep(0.5)
    raise TimeoutError(label)


def log(directory):
    path = directory / 'stdout.log'
    return path.read_text(encoding='utf8', errors='replace') if path.exists() else ''


def command(text):
    with socket.create_connection(('127.0.0.1', int(props['rcon.port'])), timeout=15) as connection:
        connection.settimeout(60)
        rcon.send_packet(connection, 1, 3, props['rcon.password'])
        auth = rcon.recv_packet(connection)
        assert auth is not None and auth[0] != -1, 'Owned RCON authentication failed'
        rcon.send_packet(connection, 10, 2, text)
        response = rcon.recv_packet(connection)
        assert response is not None, 'Owned RCON response missing'
    with (root / 'commands.jsonl').open('a', encoding='utf8') as output:
        output.write(json.dumps(dict(command=text, response=response[2])) + '\n')
    return response[2]


def start(name, args, directory, env=None, cwd=None):
    with (directory / 'stdout.log').open('xb') as out, (directory / 'stderr.log').open('xb') as err:
        process = subprocess.Popen(args, cwd=cwd or directory, stdout=out, stderr=err, env=env,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
    (directory / 'owned-process.json').write_text(json.dumps(dict(pid=process.pid, executable=args[0],
        directory=str(directory), owner=root.name), indent=2), encoding='utf8')
    processes.append((name, process, directory))
    return process


def signal(step):
    (client / 'nekojs/data/step.txt').write_text(step, encoding='utf8')


def capture(step):
    seen = set((client / 'screenshots').glob('*.png'))
    signal(step)
    marker = wait_for(lambda: next((json.loads(match.group(1)) for match in
        re.finditer(r'POST-FRAME-REQUEST (\{[^\r\n]*\})', log(client))
        if json.loads(match.group(1))['step'] == step), None), 60, 'frame request ' + step)
    assert marker['sameThread'] and not marker['overlayPresent'], marker
    if not step.startswith('retained-'):
        assert marker['accepted'] is True, marker
    images = wait_for(lambda: set((client / 'screenshots').glob('*.png')) - seen, 30, 'PNG ' + step)
    assert len(images) == 1, images
    path = next(iter(images))
    time.sleep(1)
    destination = root / (step + '.png')
    destination.write_bytes(path.read_bytes())
    result['stages'].append(dict(step=step, request=marker, image=destination.name,
        sha256=hashlib.sha256(destination.read_bytes()).hexdigest()))
    print('CAPTURE', step, json.dumps(marker), flush=True)
    return marker


server_ready = False
client_process = None
server_process = None
try:
    java = 'C:/Program Files/Java/jdk-21.0.10/bin/java.exe'
    server_process = start('server', [java, '-Xms512M', '-Xmx2G',
        '@libraries/net/neoforged/neoforge/21.1.227/win_args.txt', 'nogui'], server)
    wait_for(lambda: 'Done (' in log(server), 300, 'server startup')
    server_ready = True
    for text in ['forceload add -16 -16 32 16', 'time set noon', 'gamerule doDaylightCycle false',
        'weather clear', 'fill -2 72 -13 18 84 -1 air', 'fill -2 71 -14 18 71 1 stone',
        'fill 0 72 0 16 82 0 black_concrete',
        *['fill ' + str(x) + ' 72 0 ' + str(x+1) + ' 82 0 white_concrete' for x in (2, 6, 10, 14)]]:
        command(text)
    env = dict(os.environ, JAVA_HOME='C:/Program Files/Java/jdk-25.0.2')
    client_process = start('client', [str(project / 'gradlew.bat'), '-g', 'D:/mcmodDemo/NekoJS/.gradle-perf02',
        '-Dorg.gradle.java.home=C:/Program Files/Java/jdk-25.0.2', '--offline', '--no-parallel',
        '--project-dir', str(root), 'runClient', '--console=plain'], client, env, cwd=project)
    wait_for(lambda: 'PackAcceptance joined the game' in log(server), 600, 'client join')
    assert 'INSTALLED-NEKOJS-SOURCE-PASS' in log(client)
    assert (client / 'installed-source.json').is_file()
    command('tp PackAcceptance 8.5 72 -12.5 0 0')
    time.sleep(5)
    before = capture('clear-before')
    capture('effect-before')
    offset = len(log(client))
    signal('reload-resource')
    wait_for(lambda: 'POST-FRAME-CLIENT-READY' in log(client)[offset:], 120, 'resource reload')
    resource = capture('retained-resource')
    assert resource['current'] == 'minecraft:invert' and resource['active'], resource
    after = capture('clear-after')
    assert after['generation'] > before['generation'], (before, after)
    capture('effect-after')
    rejected = client / 'nekojs/client_scripts/rejected.js'
    rejected.write_text("throw new Error('Owned post-effect candidate rejection');\n", encoding='utf8')
    offset = len(log(client))
    signal('reload-rejected')
    wait_for(lambda: 'NEKO-1008' in log(client)[offset:] and 'Owned post-effect candidate rejection' in log(client)[offset:],
             120, 'rejected candidate')
    retained = capture('retained-rejected')
    assert retained['generation'] == after['generation'] and retained['noSetRequested'], retained
    assert retained['current'] == 'minecraft:invert' and retained['active'], retained
    rejected.rename(rejected.with_suffix('.js.rejected-installed-121'))
    offset = len(log(client))
    signal('reload-recovery')
    wait_for(lambda: 'POST-FRAME-CLIENT-READY' in log(client)[offset:], 120, 'recovery reload')
    restored = capture('clear-recovered')
    assert restored['generation'] > after['generation'], restored
    capture('effect-recovered')
    offset = len(log(client))
    signal('reload-cleared')
    wait_for(lambda: 'POST-FRAME-CLIENT-READY' in log(client)[offset:], 120, 'reload after explicit clear')
    cleared = capture('retained-cleared')
    assert cleared['current'] is None and cleared['active'] is False, cleared
    capture('effect-retiring')
    (client / 'nekojs/data/retire.flag').write_text('retire')
    offset = len(log(client))
    signal('reload-retired')
    wait_for(lambda: 'POST-FRAME-CLIENT-READY' in log(client)[offset:], 120, 'retired effect reload')
    retired = capture('retained-retired')
    assert retired['current'] is None and retired['active'] is False, retired
    inactive = capture('effect-inactive')
    assert inactive['current'] == 'minecraft:invert' and inactive['active'] is False, inactive
    offset = len(log(client))
    signal('reload-inactive')
    wait_for(lambda: 'POST-FRAME-CLIENT-READY' in log(client)[offset:], 120, 'inactive effect reload')
    inactive_after = capture('retained-inactive')
    assert inactive_after['current'] == 'minecraft:invert' and inactive_after['active'] is False, inactive_after
    capture('effect-native-target')
    (client / 'nekojs/data/retire.flag').unlink()
    (client / 'nekojs/data/native.flag').write_text('replace')
    offset = len(log(client))
    signal('reload-native')
    wait_for(lambda: 'OWNED-NATIVE-EFFECT-REPLACED' in log(client)[offset:], 120, 'native effect replacement')
    native = capture('retained-native')
    assert native['current'] is None and native['active'] is True and native['hasDefinition'], native
    retired_native = capture('retained-native-retired')
    assert retired_native['current'] is None and retired_native['active'] is True and not retired_native['hasDefinition'], retired_native



except Exception as error:
    result['errors'].append(repr(error))
    print('NATIVE_FAILURE', repr(error), flush=True)
finally:
    if client_process is not None and client_process.poll() is None:
        signal('close')
        try:
            client_process.wait(timeout=90)
        except subprocess.TimeoutExpired:
            result['errors'].append('Owned client did not stop through its tick fixture')
            # This records failure and targets only this run's uniquely marked game JVM.
            ps = "$owned = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'java.exe' -and $_.CommandLine -like '*-Dnekojs.acceptance.owner=posteffects-121-installed-975496d3-v1*' }; $owned | ForEach-Object { Stop-Process -Id $_.ProcessId -Force; Write-Output $_.ProcessId }"
            stopped = subprocess.run(['powershell', '-NoProfile', '-Command', ps], capture_output=True, text=True,
                                     creationflags=subprocess.CREATE_NO_WINDOW)
            result['forced'].append(dict(target='marked game JVM', pids=stopped.stdout.strip(), error=stopped.stderr))
            try:
                client_process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                result['errors'].append('Owned Gradle launcher remained alive after game termination')
    if server_ready and server_process.poll() is None:
        try:
            command('stop')
            server_process.wait(timeout=90)
        except Exception as error:
            result['errors'].append('Owned server shutdown: ' + repr(error))
    if server_process is not None and server_process.poll() is None:
        result['errors'].append('Owned server remained alive after shutdown attempt')
        server_process.terminate()
        server_process.wait(timeout=30)
        result['forced'].append(dict(target='owned server handle', pid=server_process.pid))
    for name, process, directory in processes:
        result[name + 'Exit'] = process.poll()
    result['mechanicalVerdict'] = 'PASS' if not result['errors'] and not result['forced'] and len(result['stages']) == 16 and result['clientExit'] == 0 and result['serverExit'] == 0 else 'NOT GREEN'
    (root / 'run-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
print(json.dumps(result), flush=True)

raise SystemExit(0 if result['mechanicalVerdict'] == 'PASS' else 1)
