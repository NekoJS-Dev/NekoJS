"""Run the existing pixel checks after the primary agent inspected all thirty original frames."""
from pathlib import Path
import subprocess
import sys

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
for short, source, old_root in [
    ('121', 'review-121-installed-v2.py', 'posteffects-121-installed-4405b0b0-v2'),
    ('261', 'review-261-4405b0b0.py', 'posteffects-261-installed-4405b0b0-v1'),
    ('262', 'review-262-4405b0b0.py', 'posteffects-262-installed-4405b0b0-v1')]:
    text = (tools / source).read_text().replace(old_root, f'posteffects-{short}-installed-975496d3-v1')
    if short != '121':
        text = text.replace("for row in manifest['artifacts'])", "for row in manifest['artifacts'].values())")
    target = tools / f'review-method-bounds-native-{short}.py'
    assert not target.exists()
    target.write_text(text, newline='\n')
    with (tools / f'method-bounds-native-{short}-pixel-review.log').open('xb') as log:
        result = subprocess.run([sys.executable, str(target)], stdout=log, stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, short
    print('CURRENT_PIXEL_AND_SOURCE_REVIEW_PASS', short, flush=True)
