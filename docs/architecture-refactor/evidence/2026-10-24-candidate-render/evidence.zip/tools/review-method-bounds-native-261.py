import hashlib
import json
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image

p = Path.cwd()
r = p / 'build/priority-closeout/posteffects-261-installed-975496d3-v1'
run = json.loads((r / 'run-result.json').read_text())
assert run['mechanicalVerdict'] == 'PASS' and run['clientExit'] == run['serverExit'] == 0
assert not run['errors'] and not run['forced'] and len(run['stages']) == 7
source = json.loads((r / 'client/installed-source.json').read_text())
manifest = json.loads((r / 'artifact-manifest.json').read_text())
jar = Path(source['expectedJar'])
assert jar.samefile(Path(source['modFile']))
assert hashlib.sha256(jar.read_bytes()).hexdigest() == source['artifactSha256']
assert any(row['sha256'] == source['artifactSha256'] for row in manifest['artifacts'].values())
with zipfile.ZipFile(jar) as archive:
    for entry, expected in manifest['nodeClassBindings'].items():
        assert hashlib.sha256(archive.read(entry)).hexdigest() == expected
    for name, binding in source['classes'].items():
        assert jar.name in binding['codeSource'] and jar.name in binding['resource']
        assert hashlib.sha256(archive.read(name.replace('.', '/') + '.class')).hexdigest() == binding['sha256']
rows = []
for stage in run['stages']:
    image = r / stage['image']
    assert hashlib.sha256(image.read_bytes()).hexdigest() == stage['sha256']
    values = np.asarray(Image.open(image).crop((230, 200, 380, 260)).convert('L')).astype(float)
    score = float(np.mean(np.diff(values, axis=1) ** 2))
    clear = stage['step'].startswith('clear')
    passed = score > 100 if clear else 0.5 < score < 50
    assert passed, (stage['step'], score)
    rows.append(dict(step=stage['step'], gradientSquaredMean=score, expected='clear' if clear else 'blur', passed=passed))
log = (r / 'client/stdout.log').read_text(encoding='utf8', errors='replace')
assert log.count('OWNED-F3T-NATIVE-PRESS-BEGIN') == log.count('OWNED-F3T-NATIVE-PRESS-END held=false') == 3
assert log.count('INSTALLED-NEKOJS-SOURCE-PASS') == 1
review = dict(sourceRevision=manifest['sourceRevision'], artifactSha256=source['artifactSha256'],
    sourceBindingVerified=True, packagedClassCount=len(manifest['nodeClassBindings']),
    roi=[230, 200, 380, 260], roiSelection='Wall edges inspected in all seven original PNGs; outside HUD overlays.',
    rows=rows, nativeKeyboardDispatches=3, screenshotsReviewed=True,
    reviewer='Primary agent; all seven original PNGs inspected. Not physical keyboard, present, or maintainer sign-off.',
    verdict='PASS')
destination = r / 'pixel-review.json'
assert not destination.exists()
destination.write_text(json.dumps(review, indent=2) + '\n', encoding='utf8')
print(json.dumps(review))
