"""Retain the initial channel-handling verifier failure without changing any measured data."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-24-candidate-render'
manifest = json.loads((out / 'manifest.json').read_text())
assert 'verifierHistory' not in manifest
old_hash = hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest()
assert old_hash == manifest['archiveSha256']
with zipfile.ZipFile(out / 'evidence.zip', 'a', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in ['method-bounds-render-verify-v1.py', 'method-bounds-render-verify-initial.log', 'append-render-verifier-history.py']:
        key = 'tools/' + name
        assert key not in archive.namelist()
        data = (tools / name).read_bytes()
        archive.writestr(key, data)
        manifest['entries'][key] = dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
manifest['archiveSha256'] = hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest()
manifest['verifierHistory'] = dict(initialArchiveSha256=old_hash,
    correction='Initial verifier converted RGBA to RGB before comparing original-channel metrics. Retain original channels instead; no image, ROI, threshold or measured value changed.')
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(entries=len(manifest['entries']), bytes=(out / 'evidence.zip').stat().st_size)))
