import { $StringReader } from "java:com/mojang/brigadier";
import { $CommandContext } from "java:com/mojang/brigadier/context";
import { $Suggestions, $SuggestionsBuilder } from "java:com/mojang/brigadier/suggestion";
import { $Collection } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";

declare module "java:com/mojang/brigadier/arguments" {
    export interface $ArgumentType<T> {
        getExamples(): $Collection<string>;
        listSuggestions<S>(arg0: $CommandContext<S>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        parse<S>(arg0: $StringReader, arg1: S): T;
        parse(arg0: $StringReader): T;
    }

    export type $ArgumentType_<Host0 = any, CallbackArg0 = $StringReader, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($ArgumentType<Host0> & { readonly [Symbol.hasInstance]?: never });
}
