import { $TypeToken } from "java:com/google/common/reflect";
import { $PointFree, $PointFreeRule, $PointFreeRule_ } from "java:com/mojang/datafixers/functions";
import { $App, $App2, $Applicative, $K1, $K2 } from "java:com/mojang/datafixers/kinds";
import { $Optic, $Optic_ } from "java:com/mojang/datafixers/optics";
import { $Schema } from "java:com/mojang/datafixers/schemas";
import { $Type, $Type$FieldNotFoundException } from "java:com/mojang/datafixers/types";
import { $TaggedChoice$TaggedChoiceType, $TypeTemplate } from "java:com/mojang/datafixers/types/templates";
import { $Either, $Function10, $Function10_, $Function11, $Function11_, $Function12, $Function12_, $Function13, $Function13_, $Function14, $Function14_, $Function15, $Function15_, $Function16, $Function16_, $Function3, $Function3_, $Function4, $Function4_, $Function5, $Function5_, $Function6, $Function6_, $Function7, $Function7_, $Function8, $Function8_, $Function9, $Function9_, $Pair } from "java:com/mojang/datafixers/util";
import { $DataResult, $Dynamic, $DynamicOps } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $BitSet, $Collection, $List, $Optional, $Set } from "java:java/util";
import { $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function, $Function_, $Supplier, $Supplier_ } from "java:java/util/function";

export * as functions from "java:com/mojang/datafixers/functions";
export * as kinds from "java:com/mojang/datafixers/kinds";
export * as optics from "java:com/mojang/datafixers/optics";
export * as schemas from "java:com/mojang/datafixers/schemas";
export * as types from "java:com/mojang/datafixers/types";
export * as util from "java:com/mojang/datafixers/util";

declare module "java:com/mojang/datafixers" {
    export interface $DSL$TypeReference {
        in(arg0: $Schema): $TypeTemplate;
        typeName(): string;
    }

    export interface $DataFixer {
        getSchema(arg0: number): $Schema;
        update<T>(arg0: $DSL$TypeReference_<string>, arg1: $Dynamic<T>, arg2: number, arg3: number): $Dynamic<T>;
    }

    export interface $FamilyOptic<A, B> {
        apply(arg0: number): $TypedOptic<any, any, A, B>;
    }

    export interface $OpticFinder<FT> {
        findType<A>(arg0: $Type<A>, arg1: boolean): $Either<$TypedOptic<A, any, FT, FT>, $Type$FieldNotFoundException>;
        findType<A, FR>(arg0: $Type<A>, arg1: $Type<FR>, arg2: boolean): $Either<$TypedOptic<A, any, FT, FR>, $Type$FieldNotFoundException>;
        inField<GT>(arg0: string, arg1: $Type<GT>): $OpticFinder<FT>;
        type(): $Type<FT>;
    }

    export class $Products$P1<F extends $K1, T1> {
        constructor(arg0: $App<F, T1>);
        and<T2, T3>(arg0: $Products$P2<F, T2, T3>): $Products$P3<F, T1, T2, T3>;
        and<T2, T3, T4>(arg0: $Products$P3<F, T2, T3, T4>): $Products$P4<F, T1, T2, T3, T4>;
        and<T2, T3, T4, T5>(arg0: $Products$P4<F, T2, T3, T4, T5>): $Products$P5<F, T1, T2, T3, T4, T5>;
        and<T2, T3, T4, T5, T6>(arg0: $Products$P5<F, T2, T3, T4, T5, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        and<T2, T3, T4, T5, T6, T7>(arg0: $Products$P6<F, T2, T3, T4, T5, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T2, T3, T4, T5, T6, T7, T8>(arg0: $Products$P7<F, T2, T3, T4, T5, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T2>(arg0: $App<F, T2>): $Products$P2<F, T1, T2>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function<T1, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function_<T1, R, T1, R>): $App<F, R>;
        t1(): $App<F, T1>;
    }

    export class $Products$P10<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>, arg8: $App<F, T9>, arg9: $App<F, T10>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function10_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, R>): $App<F, R>;
    }

    export class $Products$P11<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>, arg8: $App<F, T9>, arg9: $App<F, T10>, arg10: $App<F, T11>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function11_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, R>): $App<F, R>;
    }

    export class $Products$P12<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>, arg8: $App<F, T9>, arg9: $App<F, T10>, arg10: $App<F, T11>, arg11: $App<F, T12>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function12_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, R>): $App<F, R>;
    }

    export class $Products$P13<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>, arg8: $App<F, T9>, arg9: $App<F, T10>, arg10: $App<F, T11>, arg11: $App<F, T12>, arg12: $App<F, T13>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function13_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, R>): $App<F, R>;
    }

    export class $Products$P14<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>, arg8: $App<F, T9>, arg9: $App<F, T10>, arg10: $App<F, T11>, arg11: $App<F, T12>, arg12: $App<F, T13>, arg13: $App<F, T14>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function14_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, R>): $App<F, R>;
    }

    export class $Products$P15<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>, arg8: $App<F, T9>, arg9: $App<F, T10>, arg10: $App<F, T11>, arg11: $App<F, T12>, arg12: $App<F, T13>, arg13: $App<F, T14>, arg14: $App<F, T15>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function15_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, R>): $App<F, R>;
    }

    export class $Products$P16<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>, arg8: $App<F, T9>, arg9: $App<F, T10>, arg10: $App<F, T11>, arg11: $App<F, T12>, arg12: $App<F, T13>, arg13: $App<F, T14>, arg14: $App<F, T15>, arg15: $App<F, T16>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function16_<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, R>): $App<F, R>;
    }

    export class $Products$P2<F extends $K1, T1, T2> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>);
        and<T3, T4>(arg0: $Products$P2<F, T3, T4>): $Products$P4<F, T1, T2, T3, T4>;
        and<T3, T4, T5>(arg0: $Products$P3<F, T3, T4, T5>): $Products$P5<F, T1, T2, T3, T4, T5>;
        and<T3, T4, T5, T6>(arg0: $Products$P4<F, T3, T4, T5, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        and<T3, T4, T5, T6, T7>(arg0: $Products$P5<F, T3, T4, T5, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T3, T4, T5, T6, T7, T8>(arg0: $Products$P6<F, T3, T4, T5, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T3>(arg0: $App<F, T3>): $Products$P3<F, T1, T2, T3>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $BiFunction<T1, T2, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $BiFunction_<T1, T2, R, T1, T2, R>): $App<F, R>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
    }

    export class $Products$P3<F extends $K1, T1, T2, T3> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>);
        and<T4, T5>(arg0: $Products$P2<F, T4, T5>): $Products$P5<F, T1, T2, T3, T4, T5>;
        and<T4, T5, T6>(arg0: $Products$P3<F, T4, T5, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        and<T4, T5, T6, T7>(arg0: $Products$P4<F, T4, T5, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T4, T5, T6, T7, T8>(arg0: $Products$P5<F, T4, T5, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T4>(arg0: $App<F, T4>): $Products$P4<F, T1, T2, T3, T4>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function3<T1, T2, T3, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function3_<T1, T2, T3, R, T1, T2, T3, R>): $App<F, R>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
    }

    export class $Products$P4<F extends $K1, T1, T2, T3, T4> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>);
        and<T5, T6>(arg0: $Products$P2<F, T5, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        and<T5, T6, T7>(arg0: $Products$P3<F, T5, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T5, T6, T7, T8>(arg0: $Products$P4<F, T5, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T5>(arg0: $App<F, T5>): $Products$P5<F, T1, T2, T3, T4, T5>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function4<T1, T2, T3, T4, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function4_<T1, T2, T3, T4, R, T1, T2, T3, T4, R>): $App<F, R>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
    }

    export class $Products$P5<F extends $K1, T1, T2, T3, T4, T5> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>);
        and<T6, T7>(arg0: $Products$P2<F, T6, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        and<T6, T7, T8>(arg0: $Products$P3<F, T6, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T6>(arg0: $App<F, T6>): $Products$P6<F, T1, T2, T3, T4, T5, T6>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function5<T1, T2, T3, T4, T5, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function5_<T1, T2, T3, T4, T5, R, T1, T2, T3, T4, T5, R>): $App<F, R>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
    }

    export class $Products$P6<F extends $K1, T1, T2, T3, T4, T5, T6> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>);
        and<T7, T8>(arg0: $Products$P2<F, T7, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        and<T7>(arg0: $App<F, T7>): $Products$P7<F, T1, T2, T3, T4, T5, T6, T7>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function6<T1, T2, T3, T4, T5, T6, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function6_<T1, T2, T3, T4, T5, T6, R, T1, T2, T3, T4, T5, T6, R>): $App<F, R>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
    }

    export class $Products$P7<F extends $K1, T1, T2, T3, T4, T5, T6, T7> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>);
        and<T8>(arg0: $App<F, T8>): $Products$P8<F, T1, T2, T3, T4, T5, T6, T7, T8>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function7<T1, T2, T3, T4, T5, T6, T7, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function7_<T1, T2, T3, T4, T5, T6, T7, R, T1, T2, T3, T4, T5, T6, T7, R>): $App<F, R>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
    }

    export class $Products$P8<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function8<T1, T2, T3, T4, T5, T6, T7, T8, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function8_<T1, T2, T3, T4, T5, T6, T7, T8, R, T1, T2, T3, T4, T5, T6, T7, T8, R>): $App<F, R>;
        t1(): $App<F, T1>;
        t2(): $App<F, T2>;
        t3(): $App<F, T3>;
        t4(): $App<F, T4>;
        t5(): $App<F, T5>;
        t6(): $App<F, T6>;
        t7(): $App<F, T7>;
        t8(): $App<F, T8>;
    }

    export class $Products$P9<F extends $K1, T1, T2, T3, T4, T5, T6, T7, T8, T9> {
        constructor(arg0: $App<F, T1>, arg1: $App<F, T2>, arg2: $App<F, T3>, arg3: $App<F, T4>, arg4: $App<F, T5>, arg5: $App<F, T6>, arg6: $App<F, T7>, arg7: $App<F, T8>, arg8: $App<F, T9>);
        apply<R>(arg0: $Applicative<F, any>, arg1: $App<F, $Function9<T1, T2, T3, T4, T5, T6, T7, T8, T9, R>>): $App<F, R>;
        apply<R>(arg0: $Applicative<F, any>, arg1: $Function9_<T1, T2, T3, T4, T5, T6, T7, T8, T9, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, R>): $App<F, R>;
    }

    export class $RewriteResult<A, B> extends $Record {
        constructor(view: $View<A, B>, recData: $BitSet);
        static create<A, B>(arg0: $View<A, B>, arg1: $BitSet): $RewriteResult<A, B>;
        static nop<A>(arg0: $Type<A>): $RewriteResult<A, A>;
        compose<C>(arg0: $RewriteResult<C, A>): $RewriteResult<C, B>;
        equals(arg0: object): boolean;
        hashCode(): number;
        recData(): $BitSet;
        toString(): string;
        view(): $View<A, B>;
    }

    export interface $TypeRewriteRule {
        rewrite<A>(arg0: $Type<A>): $Optional<$RewriteResult<A, any>>;
    }
    export const $TypeRewriteRule: {
        all(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: boolean, arg2: boolean): $TypeRewriteRule;
        checkOnce(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: $Consumer_<$Type<any>, $Type<any>>): $TypeRewriteRule;
        everywhere(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>, arg2: boolean, arg3: boolean): $TypeRewriteRule;
        ifSame<B>(arg0: $Type<B>, arg1: $RewriteResult<B, any>): $TypeRewriteRule;
        nop(): $TypeRewriteRule;
        once(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>): $TypeRewriteRule;
        one(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>): $TypeRewriteRule;
        orElse(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>): $TypeRewriteRule;
        orElse(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: $Supplier_<$TypeRewriteRule, $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>>): $TypeRewriteRule;
        seq(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1?: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>[]): $TypeRewriteRule;
        seq(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>): $TypeRewriteRule;
        seq(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>[]): $TypeRewriteRule;
    };

    export class $Typed<A> {
        constructor(arg0: $Type<A>, arg1: $DynamicOps<any>, arg2: A);
        get ops(): $DynamicOps<any>;
        getOps(): $DynamicOps<any>;
        get type(): $Type<A>;
        getType(): $Type<A>;
        get value(): A;
        getValue(): A;
        static pair<A, B>(arg0: $Typed<A>, arg1: $Typed<B>): $Typed<$Pair<A, B>>;
        getAllTyped<FT>(arg0: $OpticFinder<FT>): $List<$Typed<FT>>;
        getAll<FT>(arg0: $TypedOptic<A, any, FT, any>): $List<FT>;
        getOptionalTyped<FT>(arg0: $OpticFinder<FT>): $Optional<$Typed<FT>>;
        getOptional<FT>(arg0: $OpticFinder<FT>): $Optional<FT>;
        getOrCreateTyped<FT>(arg0: $OpticFinder<FT>): $Typed<FT>;
        getOrCreate<FT>(arg0: $OpticFinder<FT>): FT;
        getOrDefault<FT>(arg0: $OpticFinder<FT>, arg1: FT): FT;
        getTyped<FT>(arg0: $OpticFinder<FT>): $Typed<FT>;
        get<FT>(arg0: $OpticFinder<FT>): FT;
        inj1<B>(arg0: $Type<B>): $Typed<$Either<A, B>>;
        inj2<B>(arg0: $Type<B>): $Typed<$Either<B, A>>;
        out(): $Typed<A>;
        set<FT>(arg0: $OpticFinder<FT>, arg1: FT): $Typed<any>;
        set<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Typed<FR>): $Typed<any>;
        set<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: FR): $Typed<any>;
        toString(): string;
        updateRecursiveTyped<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: $Function_<$Typed<any>, $Typed<any>, $Typed<any>, $Typed<any>>): $Typed<any>;
        updateRecursiveTyped<FT>(arg0: $OpticFinder<FT>, arg1: $Function_<$Typed<any>, $Typed<any>, $Typed<any>, $Typed<any>>): $Typed<any>;
        updateRecursive<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: $Function_<FT, FR, FT, FR>): $Typed<any>;
        updateRecursive<FT>(arg0: $OpticFinder<FT>, arg1: $Function_<FT, FT, FT, FT>): $Typed<any>;
        updateTyped<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: $Function_<$Typed<any>, $Typed<any>, $Typed<any>, $Typed<any>>): $Typed<any>;
        updateTyped<FT>(arg0: $OpticFinder<FT>, arg1: $Function_<$Typed<any>, $Typed<any>, $Typed<any>, $Typed<any>>): $Typed<any>;
        update<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: $Function_<FT, FR, FT, FR>): $Typed<any>;
        update<FT>(arg0: $OpticFinder<FT>, arg1: $Function_<FT, FT, FT, FT>): $Typed<any>;
        write(): $DataResult<$Dynamic<any>>;
    }

    export class $TypedOptic<S, T, A, B> extends $Record {
        constructor(arg0: $TypeToken<$K1>, arg1: $Type<S>, arg2: $Type<T>, arg3: $Type<A>, arg4: $Type<B>, arg5: $Optic_<any, S, T, A, B, $App<any, any>, $Function_<$App2<any, A, B>, $App2<any, S, T>, $App2<any, A, B>, $App2<any, S, T>>>);
        constructor(arg0: $TypeToken<$K1>[], arg1: $Type<S>, arg2: $Type<T>, arg3: $Type<A>, arg4: $Type<B>, arg5: $Optic_<any, S, T, A, B, $App<any, any>, $Function_<$App2<any, A, B>, $App2<any, S, T>, $App2<any, A, B>, $App2<any, S, T>>>);
        constructor(bounds: $TypeToken<$K1>[], elements: $TypedOptic$Element<any, any, any, any>[]);
        static adapter<S, T>(arg0: $Type<S>, arg1: $Type<T>): $TypedOptic<S, T, S, T>;
        static compoundListElements<K, V, V2>(arg0: $Type<K>, arg1: $Type<V>, arg2: $Type<V2>): $TypedOptic<$List<$Pair<K, V>>, $List<$Pair<K, V2>>, V, V2>;
        static compoundListKeys<K, V, K2>(arg0: $Type<K>, arg1: $Type<K2>, arg2: $Type<V>): $TypedOptic<$List<$Pair<K, V>>, $List<$Pair<K2, V>>, K, K2>;
        static inj1<F, G, F2>(arg0: $Type<F>, arg1: $Type<G>, arg2: $Type<F2>): $TypedOptic<$Either<F, G>, $Either<F2, G>, F, F2>;
        static inj2<F, G, G2>(arg0: $Type<F>, arg1: $Type<G>, arg2: $Type<G2>): $TypedOptic<$Either<F, G>, $Either<F, G2>, G, G2>;
        static instanceOf<Proof2 extends $K1>(arg0: $TypeToken<$K1>[], arg1: $TypeToken<Proof2>): boolean;
        static list<A, B>(arg0: $Type<A>, arg1: $Type<B>): $TypedOptic<$List<A>, $List<B>, A, B>;
        static proj1<F, G, F2>(arg0: $Type<F>, arg1: $Type<G>, arg2: $Type<F2>): $TypedOptic<$Pair<F, G>, $Pair<F2, G>, F, F2>;
        static proj2<F, G, G2>(arg0: $Type<F>, arg1: $Type<G>, arg2: $Type<G2>): $TypedOptic<$Pair<F, G>, $Pair<F, G2>, G, G2>;
        static tagged<K, A, B>(arg0: $TaggedChoice$TaggedChoiceType<K>, arg1: K, arg2: $Type<A>, arg3: $Type<B>): $TypedOptic<$Pair<K, any>, $Pair<K, any>, A, B>;
        aType(): $Type<A>;
        apply<P extends $K2, Proof2 extends $K1>(arg0: $TypeToken<Proof2>, arg1: $App<Proof2, P>, arg2: $App2<P, A, B>): $App2<P, S, T>;
        bType(): $Type<B>;
        bounds(): $Set<$TypeToken<$K1>>;
        castOuterUnchecked<S2, T2>(arg0: $Type<S2>, arg1: $Type<T2>): $TypedOptic<S2, T2, A, B>;
        castOuter(arg0: $Type<S>, arg1: $Type<T>): $TypedOptic<S, T, A, B>;
        compose<A1, B1>(arg0: $TypedOptic<A, B, A1, B1>): $TypedOptic<S, T, A1, B1>;
        elements(): $List<$TypedOptic$Element<any, any, any, any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        innermost(): $Optic<any, any, any, A, B>;
        outermost(): $Optic<any, S, T, any, any>;
        sType(): $Type<S>;
        tType(): $Type<T>;
        toString(): string;
        upCast<Proof2 extends $K1>(arg0: $TypeToken<Proof2>): $Optional<$Optic<any, S, T, A, B>>;
    }

    export class $View<A, B> extends $Record implements $App2<$View$Mu, A, B> {
        constructor(function_: $PointFree<$Function<A, B>>);
        get nop(): boolean;
        isNop(): boolean;
        static create<A, B>(arg0: $PointFree<$Function<A, B>>): $View<A, B>;
        static create<A, B>(arg0: string, arg1: $Type<A>, arg2: $Type<B>, arg3: $Function_<$DynamicOps<any>, $Function<A, B>, $DynamicOps<any>, $Function_<A, B, A, B>>): $View<A, B>;
        static nopView<A>(arg0: $Type<A>): $View<A, A>;
        compose<C>(arg0: $View<C, A>): $View<C, B>;
        equals(arg0: object): boolean;
        flatMap<C>(arg0: $Function_<$Type<B>, $View<B, C>, $Type<B>, $View<B, C>>): $View<A, C>;
        funcType(): $Type<$Function<A, B>>;
        function(): $PointFree<$Function<A, B>>;
        hashCode(): number;
        newType(): $Type<B>;
        rewriteOrNop(arg0: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $View<A, B>;
        rewrite(arg0: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $Optional<$View<A, B>>;
        toString(): string;
        type(): $Type<A>;
    }

    export class $View$Mu implements $K2 {
    }

    export type $DSL$TypeReference_<CallbackResult = string> = (() => CallbackResult) | ($DSL$TypeReference & { readonly [Symbol.hasInstance]?: never });
    export type $FamilyOptic_<Host0 = any, Host1 = any, CallbackArg0 = number, CallbackResult = $TypedOptic<any, any, Host0, Host1>> = ((arg0: CallbackArg0) => CallbackResult) | ($FamilyOptic<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
    export type $TypeRewriteRule_<CallbackArg0 = $Type<any>, CallbackResult = $Optional<$RewriteResult<any, any>>> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeRewriteRule & { readonly [Symbol.hasInstance]?: never });
}
