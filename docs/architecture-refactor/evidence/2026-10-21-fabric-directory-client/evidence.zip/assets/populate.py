"""Populate only missing Loom assets from verified local objects or pinned Mojang content."""
import concurrent.futures
import hashlib
import json
import shutil
import urllib.request
from pathlib import Path

base=Path('D:/mcmodDemo/NekoJS/.gradle-perf02/caches')
output=Path(__file__).resolve().parent
assets=base/'fabric-loom/assets'
neo=base/'neoformruntime/assets'
objects={}
indexes=[]
for version in ['26.2','26.1.2']:
 info=json.loads((base/'fabric-loom'/version/'mojang_minecraft_info.json').read_text())['assetIndex']
 candidate=neo/'indexes'/(info['id']+'.json')
 if candidate.is_file() and hashlib.sha1(candidate.read_bytes()).hexdigest()==info['sha1']:
  raw=candidate.read_bytes()
 else:raw=urllib.request.urlopen(info['url'],timeout=30).read()
 assert hashlib.sha1(raw).hexdigest()==info['sha1'] and len(raw)==info['size']
 name=version+'-'+info['id']+'.json'
 (output/name).write_bytes(raw)
 target=assets/'indexes'/name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==raw,'Preserve an existing mismatching index: '+str(target)
 else:
  with target.open('xb') as f:f.write(raw)
 indexes.append(dict(version=version,file=name,sha1=info['sha1']))
 for row in json.loads(raw)['objects'].values():
  key=row['hash'];assert len(key)==40 and all(c in '0123456789abcdef' for c in key)
  assert key not in objects or objects[key]==row['size']
  objects[key]=row['size']

def populate(entry):
 key,size=entry
 target=assets/'objects'/key[:2]/key
 if target.exists():
  raw=target.read_bytes();source='existing-loom'
 else:
  candidate=neo/'objects'/key[:2]/key
  if candidate.exists():
   raw=candidate.read_bytes();source='verified-local'
   assert len(raw)==size and hashlib.sha1(raw).hexdigest()==key,'Invalid local object: '+key
  else:
   raw=urllib.request.urlopen('https://resources.download.minecraft.net/'+key[:2]+'/'+key,timeout=60).read();source='pinned-mojang'
 assert len(raw)==size and hashlib.sha1(raw).hexdigest()==key,key
 if not target.exists():
  target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write(raw)
 return dict(hash=key,size=size,source=source)

rows=[]
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  for row in pool.map(populate,objects.items()):
   rows.append(row)
   if len(rows)%1000==0:print('VERIFIED_ASSETS',len(rows),flush=True)
finally:
 (output/'population.json').write_text(json.dumps(dict(indexes=indexes,objects=rows,complete=len(rows)==len(objects)),indent=2)+'\n')
counts={source:sum(row['source']==source for row in rows) for source in {row['source'] for row in rows}}
print('VERIFIED_ASSET_CACHE_COMPLETE',len(rows),counts,flush=True)
