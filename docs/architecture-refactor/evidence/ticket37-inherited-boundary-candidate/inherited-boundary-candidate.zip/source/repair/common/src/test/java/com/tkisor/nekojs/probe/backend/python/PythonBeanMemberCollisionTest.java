package com.tkisor.nekojs.probe.backend.python;

import com.tkisor.nekojs.core.NekoSharedHostAccess;
import com.tkisor.nekojs.core.config.SandboxConfig;
import com.tkisor.nekojs.core.fs.ClassFilter;
import com.tkisor.nekojs.probe.ir.TypeReflector;
import graal.graalvm.polyglot.Context;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PythonBeanMemberCollisionTest {
    public interface Matches {
        default int matches(String input) { return input.length(); }
    }

    public static class MixedMatches implements Matches {
        public static boolean matches(String left, String right) { return left.equals(right); }
        public static boolean matches(String left, String right, boolean enabled) { return enabled && left.equals(right); }
    }

    public static class MixedChild extends MixedMatches {
        public static boolean combine(String left, String right) { return left.equals(right); }
        public int combine(int input) { return input; }
    }
    public static class SameNameChild extends MixedMatches {
        public static boolean matches(String left, String right, int repetitions) {
            return repetitions > 0 && left.equals(right);
        }
    }
    public static class FieldParent {
        public String getLevel() { return "read"; }
    }
    public static class FieldChild extends FieldParent {
        public int level = 7;
    }
    public static class StaticFieldName {
        public boolean tag = true;
        public boolean isTag() { return tag; }
        public static String tag(String input) { return input; }
    }

    @Test
    void staticMethodsAndInstanceFieldsRetainDifferentBindings() {
        var declaration = new TypeReflector().reflect(StaticFieldName.class);
        String output = new PythonClassRenderer(new ApiTypeRefPyRenderer(Set.of(declaration.fqn))).render(declaration);
        assertTrue(output.contains("class _NekoMeta_"), output);
        assertTrue(output.contains("def tag(self) -> _NekoStatic_"), output);
    }

    @Test
    void subclassClassBindingsRetainActualSuperclassOverloads() {
        var declaration = new TypeReflector().reflect(SameNameChild.class);
        String output = new PythonClassRenderer(new ApiTypeRefPyRenderer(Set.of(declaration.fqn)))
                .render(declaration);
        assertTrue(output.contains("def __call__(self, left: str, right: str) -> bool"), output);
    }

    @Test
    void mixedStaticAndInstanceCallsRetainTheirRealBinding() throws Exception {
        var reflector = new TypeReflector();
        var parent = reflector.reflect(Matches.class);
        var mixed = reflector.reflect(MixedMatches.class);
        var child = reflector.reflect(MixedChild.class);
        var same = reflector.reflect(SameNameChild.class);
        var fieldParent = reflector.reflect(FieldParent.class);
        var fieldChild = reflector.reflect(FieldChild.class);
        var fieldStatic = reflector.reflect(StaticFieldName.class);
        var renderer = new PythonClassRenderer(new ApiTypeRefPyRenderer(Set.of(parent.fqn, mixed.fqn, child.fqn,
                same.fqn, fieldParent.fqn, fieldChild.fqn, fieldStatic.fqn)),
                List.of(parent, mixed, child, same, fieldParent, fieldChild, fieldStatic));
        Path output = Path.of("build", "probe-python-mixed-binding", "fixture.pyi");
        Files.createDirectories(output.getParent());
        Files.writeString(output, "from typing import Protocol, overload\n\n"
                + renderer.render(parent) + "\n" + renderer.render(mixed) + "\n" + renderer.render(child)
                + "\n" + renderer.render(same) + "\n" + renderer.render(fieldParent)
                + "\n" + renderer.render(fieldChild) + "\n" + renderer.render(fieldStatic));
        try (Context context = Context.newBuilder("js")
                .allowExperimentalOptions(true)
                .allowHostAccess(new NekoSharedHostAccess(List.of()).get())
                .allowHostClassLookup(new ClassFilter(SandboxConfig.defaultConfig()))
                .allowCreateProcess(false)
                .option("js.nashorn-compat", "true")
                .build()) {
            context.getBindings("js").putMember("mixed", new MixedMatches());
            assertTrue(context.eval("js", "Java.type('" + MixedMatches.class.getName()
                    + "').matches('x', 'x') && mixed.matches('word') === 4").asBoolean());
            assertTrue(context.eval("js", "var rejected = false; try { mixed.matches('x', 'x'); }"
                    + " catch (error) { rejected = true; } rejected").asBoolean());
            assertTrue(context.eval("js", "Java.type('" + SameNameChild.class.getName()
                    + "').matches('x', 'x')").asBoolean());
            context.getBindings("js").putMember("fieldStatic", new StaticFieldName());
            assertTrue(context.eval("js", "fieldStatic.tag === true && Java.type('" + StaticFieldName.class.getName()
                    + "').tag('class') === 'class'").asBoolean());
        }
    }
    public static final class CollisionFixture {
        public int count = 4;
        private String value = "bean";

        public String getRead() { return value; }
        public void setRead(String value) { this.value = value; }
        public void setRead(int value) { this.value = Integer.toString(value); }
        public String read() { return "method"; }
        public int getCount() { return count; }
        public void setCount(int value) { count = value; }
        public String getName() { return "fixture"; }
        public static String name(String value) { return "factory:" + value; }
        public boolean isReady() { return true; }
    }

    @Test
    void originalAccessorsAndRealMethodsRemainCallableUnderProductionHostAccess() {
        try (Context context = Context.newBuilder("js")
                .allowExperimentalOptions(true)
                .allowHostAccess(new NekoSharedHostAccess(List.of()).get())
                .allowHostClassLookup(new ClassFilter(SandboxConfig.defaultConfig()))
                .allowCreateProcess(false)
                .option("js.nashorn-compat", "true")
                .build()) {
            context.getBindings("js").putMember("fixture", new CollisionFixture());
            assertTrue(context.eval("js", "fixture.read() === 'method' && fixture.getRead() === 'bean'").asBoolean());
            assertTrue(context.eval("js", "fixture.setRead('changed'); fixture.getRead() === 'changed'").asBoolean());
            assertTrue(context.eval("js", "fixture.setRead(7); fixture.getRead() === '7'").asBoolean());
            assertTrue(context.eval("js", "fixture.setCount(9); fixture.count === 9 && fixture.getCount() === 9").asBoolean());
            assertTrue(context.eval("js", "Java.type('" + CollisionFixture.class.getName()
                    + "').name('x') === 'factory:x' && fixture.getName() === 'fixture'").asBoolean());
        }
    }

    @Test
    void collisionsKeepOriginalAccessorsWithoutShadowingMethodsOrFields() {
        var declaration = new TypeReflector().reflect(CollisionFixture.class);
        var renderer = new PythonClassRenderer(new ApiTypeRefPyRenderer(Set.of(declaration.fqn)));
        String output = renderer.render(declaration);
        assertTrue(output.contains("def getRead(self) -> str"), output);
        assertTrue(output.contains("def setRead(self, value: str) -> None"), output);
        assertTrue(output.contains("def read(self) -> str"), output);
        assertTrue(output.contains("def getCount(self) -> int"), output);
        assertTrue(output.contains("def setCount(self, value: int) -> None"), output);
        assertTrue(output.contains("@property\n    def count(self) -> int"), output);
        assertTrue(output.contains("def getName(self) -> str"), output);
        assertTrue(output.contains("def name(value: str) -> str"), output);
        assertFalse(output.contains("@property\n    def read("), output);
        assertFalse(output.contains("@property\n    def name("), output);
        assertTrue(output.contains("@property\n    def ready(self) -> bool"), output);
        assertTrue(output.contains("@overload\n    def setRead(self, value: int) -> None"), output);
        assertTrue(output.contains("@overload\n    def setRead(self, value: str) -> None"), output);
        assertTrue(PythonClassRenderer.hasOverloads(declaration));
    }

    @Test
    void hiddenOrRenamedMembersDoNotSuppressUnambiguousBeanProperties() {
        var declaration = new TypeReflector().reflect(CollisionFixture.class);
        declaration.methods.stream().filter(m -> m.name.equals("read")).forEach(m -> m.hidden = true);
        declaration.methods.stream().filter(m -> m.name.equals("name")).forEach(m -> m.renameTo = "factory");
        declaration.fields.forEach(f -> f.hidden = true);
        String output = new PythonClassRenderer(new ApiTypeRefPyRenderer(Set.of(declaration.fqn))).render(declaration);
        assertTrue(output.contains("@property\n    def read(self) -> str"), output);
        assertTrue(output.contains("@property\n    def count(self) -> int"), output);
        assertTrue(output.contains("@property\n    def name(self) -> str"), output);
        assertTrue(output.contains("def factory(value: str) -> str"), output);
        assertFalse(output.contains("def getRead("), output);
        assertFalse(output.contains("def getCount("), output);
    }
}
