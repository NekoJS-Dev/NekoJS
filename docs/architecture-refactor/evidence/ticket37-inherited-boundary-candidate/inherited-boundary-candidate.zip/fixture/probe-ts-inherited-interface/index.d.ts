    export interface $TypeScriptInheritedInterfaceTest$Values<T> {
        array(input: T[]): T[];
        echo(input: T): T;
        identity<R>(input: R): R;
        value(): T;
    }
    export const $TypeScriptInheritedInterfaceTest$Values: {
        factory(): string;
    };
    export interface $TypeScriptInheritedInterfaceTest$ChildValues<T> extends $TypeScriptInheritedInterfaceTest$Values<T> {
    }
    export interface $TypeScriptInheritedInterfaceTest$Sized {
        size(): number;
    }
    export class $TypeScriptInheritedInterfaceTest$Value<T> implements $TypeScriptInheritedInterfaceTest$ChildValues<T>, $TypeScriptInheritedInterfaceTest$Sized {
        constructor(input: T);
        array(input: T[]): T[];
        echo(input: T): T;
        echo(): number;
        identity<R>(input: R): R;
        size(): number;
        value(): T;
    }
    export class $TypeScriptInheritedInterfaceTest$TextValue extends $TypeScriptInheritedInterfaceTest$Value<string> {
        constructor(input: string);
        array(input: string[]): string[];
        echo(input: string): string;
        echo(): number;
        identity<R>(input: R): R;
        size(): number;
        value(): string;
    }
    export class $TypeScriptInheritedInterfaceTest$RemappedParent {
        constructor();
        call(input: string): string;
    }
    export class $TypeScriptInheritedInterfaceTest$RemappedChild extends $TypeScriptInheritedInterfaceTest$RemappedParent {
        constructor();
        call(input: string): string;
        call(input: number): number;
    }
    export interface $TypeScriptInheritedInterfaceTest$ReadOnlyValue {
        getValue(): string;
    }
    export class $TypeScriptInheritedInterfaceTest$StaticSetter implements $TypeScriptInheritedInterfaceTest$ReadOnlyValue {
        constructor();
        get value(): string;
        getValue(): string;
        static setValue(input: string): void;
    }
    export class $TypeScriptInheritedInterfaceTest$RootValue {
        constructor();
        marker: string;
    }
    export class $TypeScriptInheritedInterfaceTest$Constrained<T extends $TypeScriptInheritedInterfaceTest$RootValue> {
        constructor(input: T);
        input: T;
    }
    export interface $TypeScriptInheritedInterfaceTest$GenericSource<A> {
        bounded<T extends $TypeScriptInheritedInterfaceTest$RootValue>(input: T): $TypeScriptInheritedInterfaceTest$Constrained<T>;
        transform<T>(input: A, result: T): T;
    }
    export class $TypeScriptInheritedInterfaceTest$GenericValue<T> implements $TypeScriptInheritedInterfaceTest$GenericSource<T> {
        constructor();
        bounded<T1 extends $TypeScriptInheritedInterfaceTest$RootValue>(input: T1): $TypeScriptInheritedInterfaceTest$Constrained<T1>;
        transform<T1>(input: T, result: T1): T1;
    }
    export interface $TypeScriptInheritedInterfaceTest$BoundedCallback<T extends $TypeScriptInheritedInterfaceTest$RootValue> {
        apply(input: T): T;
    }
    export class $TypeScriptInheritedInterfaceTest$BoundedReceiver {
        constructor();
        apply(callback: $TypeScriptInheritedInterfaceTest$BoundedCallback_<$TypeScriptInheritedInterfaceTest$RootValue, $TypeScriptInheritedInterfaceTest$RootValue, $TypeScriptInheritedInterfaceTest$RootValue>): $TypeScriptInheritedInterfaceTest$RootValue;
    }
    export class $TypeScriptInheritedInterfaceTest$BoundedHost implements $TypeScriptInheritedInterfaceTest$BoundedCallback<$TypeScriptInheritedInterfaceTest$RootValue> {
        constructor();
        apply(input: $TypeScriptInheritedInterfaceTest$RootValue): $TypeScriptInheritedInterfaceTest$RootValue;
    }
    export interface $TypeScriptInheritedInterfaceTest$ObjectContract {
        equals(other: object): boolean;
        hashCode(): number;
    }
    export class $TypeScriptInheritedInterfaceTest$ObjectValue implements $TypeScriptInheritedInterfaceTest$ObjectContract {
        constructor();
        equals(arg0: object): boolean;
        hashCode(): number;
    }
    export class $TypeScriptInheritedInterfaceTest$ObjectChild extends $TypeScriptInheritedInterfaceTest$ObjectValue {
        constructor();
        equals(arg0: object): boolean;
        equals(other: string): boolean;
        hashCode(): number;
    }
    export interface $TypeScriptInheritedInterfaceTest$ReadyContract {
        getReady(): boolean;
        isReady(): boolean;
    }
    export class $TypeScriptInheritedInterfaceTest$ReadyValue implements $TypeScriptInheritedInterfaceTest$ReadyContract {
        constructor();
        get ready(): boolean;
        getReady(): boolean;
        isReady(): boolean;
    }
    export interface $Comparable<T> {
        compareTo(arg0: T): number;
    }
    export interface $TypeScriptInheritedInterfaceTest$SelfComparable<T extends ($Comparable<T> | string | number | boolean)> {
        select(input: T): T;
    }
    export class $TypeScriptInheritedInterfaceTest$ComparableReceiver {
        constructor();
        apply(operation: $TypeScriptInheritedInterfaceTest$SelfComparable_<number, number, number>): number;
        flag(operation: $TypeScriptInheritedInterfaceTest$SelfComparable_<boolean, boolean, boolean>): boolean;
        text(operation: $TypeScriptInheritedInterfaceTest$SelfComparable_<string, string, string>): string;
    }
    export interface $TypeScriptInheritedInterfaceTest$OtherComparable<T extends $Comparable<string>> {
    }
    export class $TypeScriptInheritedInterfaceTest$NumericBounds {
        constructor();
        select<T extends number & ($Comparable<T> | string | number | boolean)>(input: T): T;
    }
    export type $TypeScriptInheritedInterfaceTest$BoundedCallback_<Host0 extends $TypeScriptInheritedInterfaceTest$RootValue = any, CallbackArg0 = Host0, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptInheritedInterfaceTest$BoundedCallback<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptInheritedInterfaceTest$SelfComparable_<Host0 extends ($Comparable<Host0> | string | number | boolean) = any, CallbackArg0 = Host0, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptInheritedInterfaceTest$SelfComparable<Host0> & { readonly [Symbol.hasInstance]?: never });
