import { $Comparable, $Comparable_ } from "java:java/lang";

declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $SyntheticContractHost implements $TypeReflectorSyntheticContractTest$Values<string>, $Comparable<$SyntheticContractHost> {
        constructor();
        get values(): $TypeReflectorSyntheticContractTest$Box<string>;
        getValues(): $TypeReflectorSyntheticContractTest$Box<string>;
        ownLabel(): string;
        compareTo(other: $SyntheticContractHost): number;
    }

    export interface $TypeReflectorSyntheticContractTest$Values<T> {
        ownLabel(): string;
        getValues(): $TypeReflectorSyntheticContractTest$Box<T>;
    }

    export class $TypeReflectorSyntheticContractTest$Box<T> {
        constructor(value: T);
        value: T;
    }

}
