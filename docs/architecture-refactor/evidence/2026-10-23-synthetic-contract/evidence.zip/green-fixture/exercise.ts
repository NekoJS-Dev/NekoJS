import type { $SyntheticContractHost as Host } from 'java:com/tkisor/nekojs/probe/ir';
declare const host: Host;
const result: string = host.getValues().value;
const bean: string = host.values.value;
const label: string = host.ownLabel();
// @ts-expect-error The recovered contract retains its element type.
const wrong: number = host.getValues().value;
// @ts-expect-error Unrelated synthetic methods remain implementation details.
host.noise();
// @ts-expect-error An explicit remap retains ownership of the method name.
host.alias();
// @ts-expect-error Hidden implementation methods remain hidden.
host.secret();
