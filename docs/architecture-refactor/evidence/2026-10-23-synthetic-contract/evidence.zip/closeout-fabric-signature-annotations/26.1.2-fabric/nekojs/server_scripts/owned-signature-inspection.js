ServerEvents.started(event => {
  const names = ['com.mojang.brigadier.context.ContextChain', 'net.minecraft.world.level.gamerules.GameRule', 'net.fabricmc.fabric.impl.gamerule.RuleTypeExtensions'];
  for (const name of names) {
    const host = Java.type(name).class;
    const methods = [];
    for (const method of host.getDeclaredMethods()) {
      if (String(method.name) !== 'getModifiers' && String(method.name) !== 'fabric_enumCycle') continue;
      methods.push({ name: String(method.name), synthetic: method.isSynthetic(), bridge: method.isBridge(), signature: String(method.toGenericString()), annotations: Array.from(method.declaredAnnotations, annotation => String(annotation.annotationType().name)),
        parameterTypes: Array.from(method.genericParameterTypes, String), returnType: String(method.genericReturnType),
        variables: Array.from(method.typeParameters, variable => ({name: String(variable.name), bounds: Array.from(variable.bounds, String)})) });
    }
    console.info('OWNED-FABRIC-SIGNATURE ' + JSON.stringify({host: name, interfaces: Array.from(host.genericInterfaces, String), methods}));
  }
  try {
    const input = 'say owned_signature';
    const server = event.server;
    const commandContext = server.commands.dispatcher.parse(input, server.createCommandSourceStack()).context.build(input);
    const Chain = Java.type('com.mojang.brigadier.context.ContextChain');
    const chain = Chain.tryFlatten(commandContext).orElseThrow();
    const methodType = typeof chain['getModifiers'];
    console.info('OWNED-FABRIC-ACCESSOR ' + JSON.stringify({methodType, resultSize: methodType === 'function' ? chain['getModifiers']().size() : -1}));
  } catch (error) {
    console.info('OWNED-FABRIC-ACCESSOR-FAILED ' + String(error));
  }
  console.info('OWNED-FABRIC-SIGNATURE-DONE');
});
