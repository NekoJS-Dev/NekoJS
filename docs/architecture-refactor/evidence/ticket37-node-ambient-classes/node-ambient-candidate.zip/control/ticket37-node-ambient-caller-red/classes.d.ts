declare module 'container' {
    export declare class Container<T> implements Base {
    label: string;
    value: T;
    static count: number;
    constructor(value: T);
    getValue(): T;
    static create(value: number): Container<number>;
    }
    interface Base { label: string }

}
declare module 'node:container' {
    export declare class Container<T> implements Base {
    label: string;
    value: T;
    static count: number;
    constructor(value: T);
    getValue(): T;
    static create(value: number): Container<number>;
    }
    interface Base { label: string }

}
