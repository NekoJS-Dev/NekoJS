import { Container } from 'container';
new Container<string>(42);
const value: string = Container.create(1).getValue();
Container.count = 'bad';
