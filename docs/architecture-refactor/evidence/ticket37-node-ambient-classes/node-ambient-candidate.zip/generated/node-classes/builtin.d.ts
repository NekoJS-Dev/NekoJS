declare module 'buffer' {
    export function Buffer(value?: unknown, encoding?: string): Buffer;
    export class Blob {
    _text: string;
    type: string;
    size: number;
    constructor(parts?: unknown[], options?: NekoBlobOptions);
    text(): Promise<string>;
    arrayBuffer(): Promise<ArrayBuffer>;
    slice(start?: number, end?: number, type?: string): Blob;
    }
    export const constants: { MAX_LENGTH: number; MAX_STRING_LENGTH: number };
    interface NekoHostBuffer {
        length(): number
        bytes(): NekoHostBytes
        get(i: number): number
        set(i: number, v: number): void
        slice(start: number, end: number): NekoHostBuffer
        fill(value: number, start: number, end: number): NekoHostBuffer
        indexOf(needle: unknown, from: number): number
        includes(needle: unknown): boolean
        copy(target: NekoHostBuffer, targetStart: number, sourceStart: number, sourceEnd: number): number
        equals(other: NekoHostBuffer): boolean
        compare(other: NekoHostBuffer): number
        toString(encoding?: string): string
        readUInt8(offset: number): number
        readInt8(offset: number): number
        readUInt16LE(offset: number): number
        readUInt16BE(offset: number): number
        readInt16LE(offset: number): number
        readInt16BE(offset: number): number
        readUInt32LE(offset: number): number
        readUInt32BE(offset: number): number
        readInt32LE(offset: number): number
        readInt32BE(offset: number): number
        readFloatLE(offset: number): number
        readFloatBE(offset: number): number
        readDoubleLE(offset: number): number
        readDoubleBE(offset: number): number
        writeUInt8(offset: number, value: number): void
        writeInt8(offset: number, value: number): void
        writeUInt16LE(offset: number, value: number): void
        writeUInt16BE(offset: number, value: number): void
        writeInt16LE(offset: number, value: number): void
        writeInt16BE(offset: number, value: number): void
        writeUInt32LE(offset: number, value: number): void
        writeUInt32BE(offset: number, value: number): void
        writeInt32LE(offset: number, value: number): void
        writeInt32BE(offset: number, value: number): void
        writeFloatLE(offset: number, value: number): void
        writeFloatBE(offset: number, value: number): void
        writeDoubleLE(offset: number, value: number): void
        writeDoubleBE(offset: number, value: number): void
      }
    interface NekoHostBytes { buffer: ArrayBuffer }
    interface NekoBufferJson { type: 'Buffer'; data: number[] }
    interface NekoBlobOptions { type?: string }
    interface NekoPartLike { toString: () => string }
    type NekoAnyFn = (...a: unknown[]) => unknown
    interface Buffer {
        readonly length: number
        readonly byteLength: number
        readonly buffer: ArrayBuffer
        readonly byteOffset: number
        toString(encoding?: string): string
        bytes(): NekoHostBytes
        slice(start?: number, end?: number): Buffer
        subarray(start?: number, end?: number): Buffer
        fill(value: number, start?: number, end?: number): Buffer
        indexOf(needle: unknown, fromIndex?: number): number
        includes(needle: unknown): boolean
        write(value: string, offset?: number, encoding?: string): number
        copy(target: unknown, targetStart?: number, sourceStart?: number, sourceEnd?: number): number
        equals(other: unknown): boolean
        compare(other: unknown): number
        toJSON(): NekoBufferJson
        [index: number]: number
      }
    interface BufferConstructor {
        new(value?: unknown, encoding?: string): Buffer
        (value?: unknown, encoding?: string): Buffer
        from(value: unknown, encoding?: string): Buffer
        alloc(size: number, fill?: unknown, encoding?: string): Buffer
        allocUnsafe(size: number): Buffer
        allocUnsafeSlow(size: number): Buffer
        isBuffer(value: unknown): value is Buffer
        byteLength(value: unknown, encoding?: string): number
        isEncoding(encoding: string): boolean
        concat(values: Buffer[], totalLength?: number): Buffer
        compare(a: unknown, b: unknown): number
      }

}
declare module 'node:buffer' {
    export function Buffer(value?: unknown, encoding?: string): Buffer;
    export class Blob {
    _text: string;
    type: string;
    size: number;
    constructor(parts?: unknown[], options?: NekoBlobOptions);
    text(): Promise<string>;
    arrayBuffer(): Promise<ArrayBuffer>;
    slice(start?: number, end?: number, type?: string): Blob;
    }
    export const constants: { MAX_LENGTH: number; MAX_STRING_LENGTH: number };
    interface NekoHostBuffer {
        length(): number
        bytes(): NekoHostBytes
        get(i: number): number
        set(i: number, v: number): void
        slice(start: number, end: number): NekoHostBuffer
        fill(value: number, start: number, end: number): NekoHostBuffer
        indexOf(needle: unknown, from: number): number
        includes(needle: unknown): boolean
        copy(target: NekoHostBuffer, targetStart: number, sourceStart: number, sourceEnd: number): number
        equals(other: NekoHostBuffer): boolean
        compare(other: NekoHostBuffer): number
        toString(encoding?: string): string
        readUInt8(offset: number): number
        readInt8(offset: number): number
        readUInt16LE(offset: number): number
        readUInt16BE(offset: number): number
        readInt16LE(offset: number): number
        readInt16BE(offset: number): number
        readUInt32LE(offset: number): number
        readUInt32BE(offset: number): number
        readInt32LE(offset: number): number
        readInt32BE(offset: number): number
        readFloatLE(offset: number): number
        readFloatBE(offset: number): number
        readDoubleLE(offset: number): number
        readDoubleBE(offset: number): number
        writeUInt8(offset: number, value: number): void
        writeInt8(offset: number, value: number): void
        writeUInt16LE(offset: number, value: number): void
        writeUInt16BE(offset: number, value: number): void
        writeInt16LE(offset: number, value: number): void
        writeInt16BE(offset: number, value: number): void
        writeUInt32LE(offset: number, value: number): void
        writeUInt32BE(offset: number, value: number): void
        writeInt32LE(offset: number, value: number): void
        writeInt32BE(offset: number, value: number): void
        writeFloatLE(offset: number, value: number): void
        writeFloatBE(offset: number, value: number): void
        writeDoubleLE(offset: number, value: number): void
        writeDoubleBE(offset: number, value: number): void
      }
    interface NekoHostBytes { buffer: ArrayBuffer }
    interface NekoBufferJson { type: 'Buffer'; data: number[] }
    interface NekoBlobOptions { type?: string }
    interface NekoPartLike { toString: () => string }
    type NekoAnyFn = (...a: unknown[]) => unknown
    interface Buffer {
        readonly length: number
        readonly byteLength: number
        readonly buffer: ArrayBuffer
        readonly byteOffset: number
        toString(encoding?: string): string
        bytes(): NekoHostBytes
        slice(start?: number, end?: number): Buffer
        subarray(start?: number, end?: number): Buffer
        fill(value: number, start?: number, end?: number): Buffer
        indexOf(needle: unknown, fromIndex?: number): number
        includes(needle: unknown): boolean
        write(value: string, offset?: number, encoding?: string): number
        copy(target: unknown, targetStart?: number, sourceStart?: number, sourceEnd?: number): number
        equals(other: unknown): boolean
        compare(other: unknown): number
        toJSON(): NekoBufferJson
        [index: number]: number
      }
    interface BufferConstructor {
        new(value?: unknown, encoding?: string): Buffer
        (value?: unknown, encoding?: string): Buffer
        from(value: unknown, encoding?: string): Buffer
        alloc(size: number, fill?: unknown, encoding?: string): Buffer
        allocUnsafe(size: number): Buffer
        allocUnsafeSlow(size: number): Buffer
        isBuffer(value: unknown): value is Buffer
        byteLength(value: unknown, encoding?: string): number
        isEncoding(encoding: string): boolean
        concat(values: Buffer[], totalLength?: number): Buffer
        compare(a: unknown, b: unknown): number
      }

}
declare module 'crypto' {
    export function randomUUID(): string;
    export function randomBytes(size: number): unknown;
    export function createHash(algorithm: string): NekoDigest;
    export function createHmac(algorithm: string, key: unknown): NekoDigest;
    export function timingSafeEqual(a: unknown, b: unknown): boolean;
    interface NekoHostHash {
        updateBuffer(data: unknown): NekoHostHash
        updateString(data: string, encoding: string): NekoHostHash
        digestBuffer(): unknown
        digestString(encoding: string): string
      }
    interface NekoDigest { update(data: unknown, encoding?: string): NekoDigest; digest(encoding?: string): unknown }

}
declare module 'node:crypto' {
    export function randomUUID(): string;
    export function randomBytes(size: number): unknown;
    export function createHash(algorithm: string): NekoDigest;
    export function createHmac(algorithm: string, key: unknown): NekoDigest;
    export function timingSafeEqual(a: unknown, b: unknown): boolean;
    interface NekoHostHash {
        updateBuffer(data: unknown): NekoHostHash
        updateString(data: string, encoding: string): NekoHostHash
        digestBuffer(): unknown
        digestString(encoding: string): string
      }
    interface NekoDigest { update(data: unknown, encoding?: string): NekoDigest; digest(encoding?: string): unknown }

}
declare module 'fs' {
    export const F_OK: number;
    export const R_OK: number;
    export const W_OK: number;
    export const X_OK: number;
    export function existsSync(path: unknown): boolean;
    export function accessSync(path: unknown, mode?: unknown): void;
    export function readFileSync(path: unknown, options?: unknown): unknown;
    export function writeFileSync(path: unknown, data: unknown, options?: unknown): void;
    export function appendFileSync(path: unknown, data: unknown, options?: unknown): void;
    export function mkdirSync(path: unknown, options?: unknown): void;
    export function rmSync(path: unknown, options?: unknown): void;
    export function unlinkSync(path: unknown): void;
    export function readdirSync(path: unknown, options?: unknown): unknown;
    export function statSync(path: unknown): NekoStats;
    export function lstatSync(path: unknown): NekoStats;
    export function renameSync(oldPath: unknown, newPath: unknown): void;
    export function copyFileSync(source: unknown, destination: unknown): void;
    export function realpathSync(path: unknown): string;
    export function readlinkSync(path: unknown): string;
    interface NekoStats {
        dev: number; ino: number; mode: number; nlink: number; uid: number; gid: number; rdev: number
        size: number; blksize: number; blocks: number; atimeMs: number; mtimeMs: number; ctimeMs: number; birthtimeMs: number
        isFile(): boolean; isDirectory(): boolean; isSymbolicLink(): boolean; isBlockDevice(): boolean
        isCharacterDevice(): boolean; isFIFO(): boolean; isSocket(): boolean; isOther(): boolean
      }
    interface NekoDirent {
        name: string
        isFile(): boolean
        isDirectory(): boolean
        isSymbolicLink(): boolean
        isBlockDevice(): boolean
        isCharacterDevice(): boolean
        isFIFO(): boolean
        isSocket(): boolean
      }
    interface NekoWriteFlag { append: boolean; exclusive: boolean }
    type NekoFsCallback = (error: unknown, value?: unknown) => void

}
declare module 'node:fs' {
    export const F_OK: number;
    export const R_OK: number;
    export const W_OK: number;
    export const X_OK: number;
    export function existsSync(path: unknown): boolean;
    export function accessSync(path: unknown, mode?: unknown): void;
    export function readFileSync(path: unknown, options?: unknown): unknown;
    export function writeFileSync(path: unknown, data: unknown, options?: unknown): void;
    export function appendFileSync(path: unknown, data: unknown, options?: unknown): void;
    export function mkdirSync(path: unknown, options?: unknown): void;
    export function rmSync(path: unknown, options?: unknown): void;
    export function unlinkSync(path: unknown): void;
    export function readdirSync(path: unknown, options?: unknown): unknown;
    export function statSync(path: unknown): NekoStats;
    export function lstatSync(path: unknown): NekoStats;
    export function renameSync(oldPath: unknown, newPath: unknown): void;
    export function copyFileSync(source: unknown, destination: unknown): void;
    export function realpathSync(path: unknown): string;
    export function readlinkSync(path: unknown): string;
    interface NekoStats {
        dev: number; ino: number; mode: number; nlink: number; uid: number; gid: number; rdev: number
        size: number; blksize: number; blocks: number; atimeMs: number; mtimeMs: number; ctimeMs: number; birthtimeMs: number
        isFile(): boolean; isDirectory(): boolean; isSymbolicLink(): boolean; isBlockDevice(): boolean
        isCharacterDevice(): boolean; isFIFO(): boolean; isSocket(): boolean; isOther(): boolean
      }
    interface NekoDirent {
        name: string
        isFile(): boolean
        isDirectory(): boolean
        isSymbolicLink(): boolean
        isBlockDevice(): boolean
        isCharacterDevice(): boolean
        isFIFO(): boolean
        isSocket(): boolean
      }
    interface NekoWriteFlag { append: boolean; exclusive: boolean }
    type NekoFsCallback = (error: unknown, value?: unknown) => void

}
declare module 'fs/promises' {
    export function readFile(path: unknown, options?: unknown): Promise<unknown>;
    export function writeFile(path: unknown, data: unknown, options?: unknown): Promise<void>;
    export function appendFile(path: unknown, data: unknown, options?: unknown): Promise<void>;
    export function mkdir(path: unknown, options?: unknown): Promise<void>;
    export function rm(path: unknown, options?: unknown): Promise<void>;
    export function unlink(path: unknown): Promise<void>;
    export function readdir(path: unknown, options?: unknown): Promise<unknown>;
    export function stat(path: unknown): Promise<NekoStats>;
    export function lstat(path: unknown): Promise<NekoStats>;
    export function rename(oldPath: unknown, newPath: unknown): Promise<void>;
    export function copyFile(source: unknown, destination: unknown): Promise<void>;
    export function realpath(path: unknown): Promise<string>;
    export function access(path: unknown, mode?: unknown): Promise<void>;
    interface NekoStats {
        dev: number; ino: number; mode: number; nlink: number; uid: number; gid: number; rdev: number
        size: number; blksize: number; blocks: number; atimeMs: number; mtimeMs: number; ctimeMs: number; birthtimeMs: number
        isFile(): boolean; isDirectory(): boolean; isSymbolicLink(): boolean; isBlockDevice(): boolean
        isCharacterDevice(): boolean; isFIFO(): boolean; isSocket(): boolean; isOther(): boolean
      }
    interface NekoDirent {
        name: string
        isFile(): boolean
        isDirectory(): boolean
        isSymbolicLink(): boolean
        isBlockDevice(): boolean
        isCharacterDevice(): boolean
        isFIFO(): boolean
        isSocket(): boolean
      }
    interface NekoWriteFlag { append: boolean; exclusive: boolean }
    type NekoFsCallback = (error: unknown, value?: unknown) => void

}
declare module 'node:fs/promises' {
    export function readFile(path: unknown, options?: unknown): Promise<unknown>;
    export function writeFile(path: unknown, data: unknown, options?: unknown): Promise<void>;
    export function appendFile(path: unknown, data: unknown, options?: unknown): Promise<void>;
    export function mkdir(path: unknown, options?: unknown): Promise<void>;
    export function rm(path: unknown, options?: unknown): Promise<void>;
    export function unlink(path: unknown): Promise<void>;
    export function readdir(path: unknown, options?: unknown): Promise<unknown>;
    export function stat(path: unknown): Promise<NekoStats>;
    export function lstat(path: unknown): Promise<NekoStats>;
    export function rename(oldPath: unknown, newPath: unknown): Promise<void>;
    export function copyFile(source: unknown, destination: unknown): Promise<void>;
    export function realpath(path: unknown): Promise<string>;
    export function access(path: unknown, mode?: unknown): Promise<void>;
    interface NekoStats {
        dev: number; ino: number; mode: number; nlink: number; uid: number; gid: number; rdev: number
        size: number; blksize: number; blocks: number; atimeMs: number; mtimeMs: number; ctimeMs: number; birthtimeMs: number
        isFile(): boolean; isDirectory(): boolean; isSymbolicLink(): boolean; isBlockDevice(): boolean
        isCharacterDevice(): boolean; isFIFO(): boolean; isSocket(): boolean; isOther(): boolean
      }
    interface NekoDirent {
        name: string
        isFile(): boolean
        isDirectory(): boolean
        isSymbolicLink(): boolean
        isBlockDevice(): boolean
        isCharacterDevice(): boolean
        isFIFO(): boolean
        isSocket(): boolean
      }
    interface NekoWriteFlag { append: boolean; exclusive: boolean }
    type NekoFsCallback = (error: unknown, value?: unknown) => void

}
declare module 'path' {
    interface NekoParsedPath { root: string; dir: string; base: string; ext: string; name: string }
    interface NekoPathApi {
        readonly sep: string
        readonly delimiter: string
        join(...parts: string[]): string
        resolve(...parts: string[]): string
        normalize(path: string): string
        dirname(path: string): string
        basename(path: string, suffix?: string): string
        extname(path: string): string
        relative(from: string, to: string): string
        isAbsolute(path: string): boolean
        parse(path: string): NekoParsedPath
        format(pathObject: unknown): string
        toNamespacedPath(path: string): string
      }
    interface NekoPathModule extends NekoPathApi {
        posix: NekoPathApi
        win32: NekoPathApi
      }

}
declare module 'node:path' {
    interface NekoParsedPath { root: string; dir: string; base: string; ext: string; name: string }
    interface NekoPathApi {
        readonly sep: string
        readonly delimiter: string
        join(...parts: string[]): string
        resolve(...parts: string[]): string
        normalize(path: string): string
        dirname(path: string): string
        basename(path: string, suffix?: string): string
        extname(path: string): string
        relative(from: string, to: string): string
        isAbsolute(path: string): boolean
        parse(path: string): NekoParsedPath
        format(pathObject: unknown): string
        toNamespacedPath(path: string): string
      }
    interface NekoPathModule extends NekoPathApi {
        posix: NekoPathApi
        win32: NekoPathApi
      }

}
declare module 'util' {
    export function format(format: unknown, ...args: unknown[]): string;
    export function inspect(value: unknown): string;
    export function promisify(fn: Function): Function;
    export function callbackify(fn: Function): Function;
    export function deprecate<T extends Function>(fn: T, message: string, code?: string): T;
    export function inherits(ctor: Function, superCtor: Function): void;
    export function isDeepStrictEqual(left: unknown, right: unknown): boolean;
    export function debuglog(_section?: unknown): Function;
    export const types: { isPromise(value: unknown): value is Promise<unknown>; isProxy(_value: unknown): value is object; isNativeError(value: unknown): value is Error; isDate(value: unknown): value is Date; isRegExp(value: unknown): value is RegExp; isMap(value: unknown): value is AnyMap; isSet(value: unknown): value is Set<unknown>; isWeakMap(value: unknown): value is AnyWeakMap; isWeakSet(value: unknown): value is WeakSet<object>; isArrayBuffer(value: unknown): value is ArrayBuffer; isSharedArrayBuffer(value: unknown): value is SharedArrayBuffer; isAnyArrayBuffer(value: unknown): value is ArrayBufferLike; isTypedArray(value: unknown): value is ArrayBufferView; isUint8Array(value: unknown): value is Uint8Array; isDataView(value: unknown): value is DataView; isArgumentsObject(value: unknown): value is ArrayLike<unknown>; isBoxedPrimitive(value: unknown): value is object; isBooleanObject(value: unknown): value is Boolean; isNumberObject(value: unknown): value is Number; isStringObject(value: unknown): value is String; isSymbolObject(value: unknown): value is Symbol; isBigIntObject(value: unknown): value is BigInt };
    interface NekoInspect {
        (value: unknown): string
        custom: symbol
      }
    type AnyMap = Map<unknown, unknown>
    type AnyWeakMap = WeakMap<object, unknown>
    type NekoCloneSeen = Map<unknown, unknown>
    interface NekoTypedArrayCtor { new (source: unknown): unknown }

}
declare module 'node:util' {
    export function format(format: unknown, ...args: unknown[]): string;
    export function inspect(value: unknown): string;
    export function promisify(fn: Function): Function;
    export function callbackify(fn: Function): Function;
    export function deprecate<T extends Function>(fn: T, message: string, code?: string): T;
    export function inherits(ctor: Function, superCtor: Function): void;
    export function isDeepStrictEqual(left: unknown, right: unknown): boolean;
    export function debuglog(_section?: unknown): Function;
    export const types: { isPromise(value: unknown): value is Promise<unknown>; isProxy(_value: unknown): value is object; isNativeError(value: unknown): value is Error; isDate(value: unknown): value is Date; isRegExp(value: unknown): value is RegExp; isMap(value: unknown): value is AnyMap; isSet(value: unknown): value is Set<unknown>; isWeakMap(value: unknown): value is AnyWeakMap; isWeakSet(value: unknown): value is WeakSet<object>; isArrayBuffer(value: unknown): value is ArrayBuffer; isSharedArrayBuffer(value: unknown): value is SharedArrayBuffer; isAnyArrayBuffer(value: unknown): value is ArrayBufferLike; isTypedArray(value: unknown): value is ArrayBufferView; isUint8Array(value: unknown): value is Uint8Array; isDataView(value: unknown): value is DataView; isArgumentsObject(value: unknown): value is ArrayLike<unknown>; isBoxedPrimitive(value: unknown): value is object; isBooleanObject(value: unknown): value is Boolean; isNumberObject(value: unknown): value is Number; isStringObject(value: unknown): value is String; isSymbolObject(value: unknown): value is Symbol; isBigIntObject(value: unknown): value is BigInt };
    interface NekoInspect {
        (value: unknown): string
        custom: symbol
      }
    type AnyMap = Map<unknown, unknown>
    type AnyWeakMap = WeakMap<object, unknown>
    type NekoCloneSeen = Map<unknown, unknown>
    interface NekoTypedArrayCtor { new (source: unknown): unknown }

}
declare module 'assert' {
    interface NekoAssertOptions {
        message?: string
        actual?: unknown
        expected?: unknown
        operator?: string
      }
    interface NekoAssertErrorOptions extends NekoAssertOptions {}
    type NekoAssertExpected = RegExp | (new (...args: unknown[]) => Error) | ((error: unknown) => boolean) | Record<string, unknown>
    type NekoSyncFn = () => unknown
    type NekoMaybeAsyncFn = (() => unknown) | Promise<unknown>
    type NekoErrorCtor = new (...args: unknown[]) => Error
    type NekoErrorPredicate = (error: unknown) => boolean
    interface NekoAssert {
        (value: unknown, message?: string): void
        ok(value: unknown, message?: string): void
        equal(actual: unknown, expected: unknown, message?: string): void
        notEqual(actual: unknown, expected: unknown, message?: string): void
        strictEqual(actual: unknown, expected: unknown, message?: string): void
        notStrictEqual(actual: unknown, expected: unknown, message?: string): void
        deepEqual(actual: unknown, expected: unknown, message?: string): void
        deepStrictEqual(actual: unknown, expected: unknown, message?: string): void
        notDeepEqual(actual: unknown, expected: unknown, message?: string): void
        notDeepStrictEqual(actual: unknown, expected: unknown, message?: string): void
        throws(fn: NekoSyncFn, expected?: NekoAssertExpected | string, message?: string): unknown
        doesNotThrow(fn: NekoSyncFn, expected?: NekoAssertExpected | string, message?: string): void
        rejects(fn: NekoMaybeAsyncFn, expected?: NekoAssertExpected | string, message?: string): Promise<unknown>
        doesNotReject(fn: NekoMaybeAsyncFn, expected?: NekoAssertExpected | string, message?: string): Promise<void>
        match(value: unknown, regexp: RegExp, message?: string): void
        doesNotMatch(value: unknown, regexp: RegExp, message?: string): void
        ifError(value: unknown): void
        fail(actual?: unknown, expected?: unknown, message?: string, operator?: string): void
        AssertionError: typeof AssertionError
        default: NekoAssert
      }
    type NekoSeenPairs = WeakMap<object, object[]>
    type NekoSyncFn = () => unknown

}
declare module 'node:assert' {
    interface NekoAssertOptions {
        message?: string
        actual?: unknown
        expected?: unknown
        operator?: string
      }
    interface NekoAssertErrorOptions extends NekoAssertOptions {}
    type NekoAssertExpected = RegExp | (new (...args: unknown[]) => Error) | ((error: unknown) => boolean) | Record<string, unknown>
    type NekoSyncFn = () => unknown
    type NekoMaybeAsyncFn = (() => unknown) | Promise<unknown>
    type NekoErrorCtor = new (...args: unknown[]) => Error
    type NekoErrorPredicate = (error: unknown) => boolean
    interface NekoAssert {
        (value: unknown, message?: string): void
        ok(value: unknown, message?: string): void
        equal(actual: unknown, expected: unknown, message?: string): void
        notEqual(actual: unknown, expected: unknown, message?: string): void
        strictEqual(actual: unknown, expected: unknown, message?: string): void
        notStrictEqual(actual: unknown, expected: unknown, message?: string): void
        deepEqual(actual: unknown, expected: unknown, message?: string): void
        deepStrictEqual(actual: unknown, expected: unknown, message?: string): void
        notDeepEqual(actual: unknown, expected: unknown, message?: string): void
        notDeepStrictEqual(actual: unknown, expected: unknown, message?: string): void
        throws(fn: NekoSyncFn, expected?: NekoAssertExpected | string, message?: string): unknown
        doesNotThrow(fn: NekoSyncFn, expected?: NekoAssertExpected | string, message?: string): void
        rejects(fn: NekoMaybeAsyncFn, expected?: NekoAssertExpected | string, message?: string): Promise<unknown>
        doesNotReject(fn: NekoMaybeAsyncFn, expected?: NekoAssertExpected | string, message?: string): Promise<void>
        match(value: unknown, regexp: RegExp, message?: string): void
        doesNotMatch(value: unknown, regexp: RegExp, message?: string): void
        ifError(value: unknown): void
        fail(actual?: unknown, expected?: unknown, message?: string, operator?: string): void
        AssertionError: typeof AssertionError
        default: NekoAssert
      }
    type NekoSeenPairs = WeakMap<object, object[]>
    type NekoSyncFn = () => unknown

}
declare module 'assert/strict' {
    interface NekoAssertOptions {
        message?: string
        actual?: unknown
        expected?: unknown
        operator?: string
      }
    interface NekoAssertErrorOptions extends NekoAssertOptions {}
    type NekoAssertExpected = RegExp | (new (...args: unknown[]) => Error) | ((error: unknown) => boolean) | Record<string, unknown>
    type NekoSyncFn = () => unknown
    type NekoMaybeAsyncFn = (() => unknown) | Promise<unknown>
    type NekoErrorCtor = new (...args: unknown[]) => Error
    type NekoErrorPredicate = (error: unknown) => boolean
    interface NekoAssert {
        (value: unknown, message?: string): void
        ok(value: unknown, message?: string): void
        equal(actual: unknown, expected: unknown, message?: string): void
        notEqual(actual: unknown, expected: unknown, message?: string): void
        strictEqual(actual: unknown, expected: unknown, message?: string): void
        notStrictEqual(actual: unknown, expected: unknown, message?: string): void
        deepEqual(actual: unknown, expected: unknown, message?: string): void
        deepStrictEqual(actual: unknown, expected: unknown, message?: string): void
        notDeepEqual(actual: unknown, expected: unknown, message?: string): void
        notDeepStrictEqual(actual: unknown, expected: unknown, message?: string): void
        throws(fn: NekoSyncFn, expected?: NekoAssertExpected | string, message?: string): unknown
        doesNotThrow(fn: NekoSyncFn, expected?: NekoAssertExpected | string, message?: string): void
        rejects(fn: NekoMaybeAsyncFn, expected?: NekoAssertExpected | string, message?: string): Promise<unknown>
        doesNotReject(fn: NekoMaybeAsyncFn, expected?: NekoAssertExpected | string, message?: string): Promise<void>
        match(value: unknown, regexp: RegExp, message?: string): void
        doesNotMatch(value: unknown, regexp: RegExp, message?: string): void
        ifError(value: unknown): void
        fail(actual?: unknown, expected?: unknown, message?: string, operator?: string): void
        AssertionError: typeof AssertionError
        default: NekoAssert
      }
    type NekoSeenPairs = WeakMap<object, object[]>
    type NekoSyncFn = () => unknown

}
declare module 'node:assert/strict' {
    interface NekoAssertOptions {
        message?: string
        actual?: unknown
        expected?: unknown
        operator?: string
      }
    interface NekoAssertErrorOptions extends NekoAssertOptions {}
    type NekoAssertExpected = RegExp | (new (...args: unknown[]) => Error) | ((error: unknown) => boolean) | Record<string, unknown>
    type NekoSyncFn = () => unknown
    type NekoMaybeAsyncFn = (() => unknown) | Promise<unknown>
    type NekoErrorCtor = new (...args: unknown[]) => Error
    type NekoErrorPredicate = (error: unknown) => boolean
    interface NekoAssert {
        (value: unknown, message?: string): void
        ok(value: unknown, message?: string): void
        equal(actual: unknown, expected: unknown, message?: string): void
        notEqual(actual: unknown, expected: unknown, message?: string): void
        strictEqual(actual: unknown, expected: unknown, message?: string): void
        notStrictEqual(actual: unknown, expected: unknown, message?: string): void
        deepEqual(actual: unknown, expected: unknown, message?: string): void
        deepStrictEqual(actual: unknown, expected: unknown, message?: string): void
        notDeepEqual(actual: unknown, expected: unknown, message?: string): void
        notDeepStrictEqual(actual: unknown, expected: unknown, message?: string): void
        throws(fn: NekoSyncFn, expected?: NekoAssertExpected | string, message?: string): unknown
        doesNotThrow(fn: NekoSyncFn, expected?: NekoAssertExpected | string, message?: string): void
        rejects(fn: NekoMaybeAsyncFn, expected?: NekoAssertExpected | string, message?: string): Promise<unknown>
        doesNotReject(fn: NekoMaybeAsyncFn, expected?: NekoAssertExpected | string, message?: string): Promise<void>
        match(value: unknown, regexp: RegExp, message?: string): void
        doesNotMatch(value: unknown, regexp: RegExp, message?: string): void
        ifError(value: unknown): void
        fail(actual?: unknown, expected?: unknown, message?: string, operator?: string): void
        AssertionError: typeof AssertionError
        default: NekoAssert
      }
    type NekoSeenPairs = WeakMap<object, object[]>
    type NekoSyncFn = () => unknown

}
declare module 'test' {
    interface NekoNodeTestOptions { skip?: boolean | string; todo?: boolean | string }
    type NekoNodeTestCallback = (context: NekoNodeTestContext) => unknown | Promise<unknown>
    interface NekoNodeTestContext {
        name: string
        diagnostic(message: string): void
        test(name: string, fn: NekoNodeTestCallback): unknown
        test(name: string, options: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        skip(message?: string): void
        todo(message?: string): void
      }
    interface NekoNodeTestDescribe {
        (name: string, fn: NekoNodeTestCallback): unknown
        (name: string, options: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        skip(name: string, options?: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        todo(name: string, options?: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        only: NekoNodeTestDescribe
      }
    interface NekoNodeTestRunner {
        (name: string, fn: NekoNodeTestCallback): unknown
        (name: string, options: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        skip(name: string, options?: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        todo(name: string, options?: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        only: NekoNodeTestRunner
        before(fn: NekoNodeTestCallback): void
        after(fn: NekoNodeTestCallback): void
        beforeEach(fn: NekoNodeTestCallback): void
        afterEach(fn: NekoNodeTestCallback): void
        describe: NekoNodeTestDescribe
        it: NekoNodeTestRunner
        run(): void
        default: NekoNodeTestRunner
      }
    interface NekoNodeTestSuite {
        kind: 'suite'
        name: string
        options: NekoNodeTestOptions
        only: boolean
        parent: NekoNodeTestSuite | null
        nodes: NekoNodeTestNode[]
        before: NekoNodeTestCallback[]
        after: NekoNodeTestCallback[]
        beforeEach: NekoNodeTestCallback[]
        afterEach: NekoNodeTestCallback[]
      }
    interface NekoNodeTestCase {
        kind: 'test'
        name: string
        options: NekoNodeTestOptions
        only: boolean
        fn: NekoNodeTestCallback | undefined
      }
    type NekoNodeTestNode = NekoNodeTestSuite | NekoNodeTestCase
    interface NekoNodeTestState {
        count: number
        passed: number
        failed: number
        skipped: number
        todo: number
        scheduled: boolean
        running: boolean
        finished: boolean
        /** 任一 test.only/describe.only 注册后置位：未标记 only 的用例按 skip 处理。 */
        only: boolean
        root: NekoNodeTestSuite | null
        stack: NekoNodeTestSuite[]
      }
    interface NekoNormalizedArgs {
        name: string
        options: NekoNodeTestOptions
        fn: NekoNodeTestCallback | undefined
      }
    interface NekoMappedValue { get: (k: string) => unknown }
    interface NekoMappedStackLine { path: string | null; line: number; column: number }
    type NekoValueFn = () => unknown
    type NekoVoidCallback = () => void
    type NekoEnqueue = (cb: NekoVoidCallback) => unknown
    type NekoTestExtra = { mapStackLine?: (line: string) => string; formatError?: (error: unknown) => string }

}
declare module 'node:test' {
    interface NekoNodeTestOptions { skip?: boolean | string; todo?: boolean | string }
    type NekoNodeTestCallback = (context: NekoNodeTestContext) => unknown | Promise<unknown>
    interface NekoNodeTestContext {
        name: string
        diagnostic(message: string): void
        test(name: string, fn: NekoNodeTestCallback): unknown
        test(name: string, options: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        skip(message?: string): void
        todo(message?: string): void
      }
    interface NekoNodeTestDescribe {
        (name: string, fn: NekoNodeTestCallback): unknown
        (name: string, options: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        skip(name: string, options?: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        todo(name: string, options?: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        only: NekoNodeTestDescribe
      }
    interface NekoNodeTestRunner {
        (name: string, fn: NekoNodeTestCallback): unknown
        (name: string, options: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        skip(name: string, options?: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        todo(name: string, options?: NekoNodeTestOptions, fn?: NekoNodeTestCallback): unknown
        only: NekoNodeTestRunner
        before(fn: NekoNodeTestCallback): void
        after(fn: NekoNodeTestCallback): void
        beforeEach(fn: NekoNodeTestCallback): void
        afterEach(fn: NekoNodeTestCallback): void
        describe: NekoNodeTestDescribe
        it: NekoNodeTestRunner
        run(): void
        default: NekoNodeTestRunner
      }
    interface NekoNodeTestSuite {
        kind: 'suite'
        name: string
        options: NekoNodeTestOptions
        only: boolean
        parent: NekoNodeTestSuite | null
        nodes: NekoNodeTestNode[]
        before: NekoNodeTestCallback[]
        after: NekoNodeTestCallback[]
        beforeEach: NekoNodeTestCallback[]
        afterEach: NekoNodeTestCallback[]
      }
    interface NekoNodeTestCase {
        kind: 'test'
        name: string
        options: NekoNodeTestOptions
        only: boolean
        fn: NekoNodeTestCallback | undefined
      }
    type NekoNodeTestNode = NekoNodeTestSuite | NekoNodeTestCase
    interface NekoNodeTestState {
        count: number
        passed: number
        failed: number
        skipped: number
        todo: number
        scheduled: boolean
        running: boolean
        finished: boolean
        /** 任一 test.only/describe.only 注册后置位：未标记 only 的用例按 skip 处理。 */
        only: boolean
        root: NekoNodeTestSuite | null
        stack: NekoNodeTestSuite[]
      }
    interface NekoNormalizedArgs {
        name: string
        options: NekoNodeTestOptions
        fn: NekoNodeTestCallback | undefined
      }
    interface NekoMappedValue { get: (k: string) => unknown }
    interface NekoMappedStackLine { path: string | null; line: number; column: number }
    type NekoValueFn = () => unknown
    type NekoVoidCallback = () => void
    type NekoEnqueue = (cb: NekoVoidCallback) => unknown
    type NekoTestExtra = { mapStackLine?: (line: string) => string; formatError?: (error: unknown) => string }

}
declare module 'timers' {
    export function setTimeout(callback: TimerCallback, delay?: number, ...args: unknown[]): NekoTimerId;
    export function clearTimeout(id: unknown): void;
    export function setInterval(callback: TimerCallback, delay?: number, ...args: unknown[]): NekoTimerId;
    export function clearInterval(id: unknown): void;
    export function setImmediate(callback: TimerCallback, ...args: unknown[]): NekoTimerId;
    export function clearImmediate(id: unknown): void;
    type NekoTimerId = number
    type TimerCallback = (...args: unknown[]) => void

}
declare module 'node:timers' {
    export function setTimeout(callback: TimerCallback, delay?: number, ...args: unknown[]): NekoTimerId;
    export function clearTimeout(id: unknown): void;
    export function setInterval(callback: TimerCallback, delay?: number, ...args: unknown[]): NekoTimerId;
    export function clearInterval(id: unknown): void;
    export function setImmediate(callback: TimerCallback, ...args: unknown[]): NekoTimerId;
    export function clearImmediate(id: unknown): void;
    type NekoTimerId = number
    type TimerCallback = (...args: unknown[]) => void

}
declare module 'timers/promises' {
    export function setTimeout(delay?: number, value?: unknown): Promise<unknown>;
    export function setImmediate(value?: unknown): Promise<unknown>;
    export const setInterval: unknown;
    type NekoTimerId = number
    type TimerCallback = (...args: unknown[]) => void

}
declare module 'node:timers/promises' {
    export function setTimeout(delay?: number, value?: unknown): Promise<unknown>;
    export function setImmediate(value?: unknown): Promise<unknown>;
    export const setInterval: unknown;
    type NekoTimerId = number
    type TimerCallback = (...args: unknown[]) => void

}
declare module 'process' {
    interface NekoMemoryUsage { rss: number; heapTotal: number; heapUsed: number; external: number; arrayBuffers: number }
    interface NekoCpuUsage { user: number; system: number }
    interface NekoHrtime { (previous?: [number, number]): [number, number]; bigint(previous?: [number, number]): bigint }
    interface NekoVoidFn { (): void }
    interface NekoStdStream {
        isTTY: boolean
        write(chunk: unknown): boolean
      }
    interface NekoProcessModule {
        argv: string[]
        exitCode: number | string
        readonly pid: number
        readonly platform: string
        readonly versions: Record<string, string>
        readonly env: Record<string, string>
        readonly stdout: NekoStdStream
        readonly stderr: NekoStdStream
        cwd(): string
        chdir(path: string): void
        exit(code?: number | string): void
        uptime(): number
        hrtime: NekoHrtime
        memoryUsage(): NekoMemoryUsage
        cpuUsage(previousValue?: NekoCpuUsage): NekoCpuUsage
        nextTick(callback: (...args: unknown[]) => void, ...args: unknown[]): unknown
      }

}
declare module 'node:process' {
    interface NekoMemoryUsage { rss: number; heapTotal: number; heapUsed: number; external: number; arrayBuffers: number }
    interface NekoCpuUsage { user: number; system: number }
    interface NekoHrtime { (previous?: [number, number]): [number, number]; bigint(previous?: [number, number]): bigint }
    interface NekoVoidFn { (): void }
    interface NekoStdStream {
        isTTY: boolean
        write(chunk: unknown): boolean
      }
    interface NekoProcessModule {
        argv: string[]
        exitCode: number | string
        readonly pid: number
        readonly platform: string
        readonly versions: Record<string, string>
        readonly env: Record<string, string>
        readonly stdout: NekoStdStream
        readonly stderr: NekoStdStream
        cwd(): string
        chdir(path: string): void
        exit(code?: number | string): void
        uptime(): number
        hrtime: NekoHrtime
        memoryUsage(): NekoMemoryUsage
        cpuUsage(previousValue?: NekoCpuUsage): NekoCpuUsage
        nextTick(callback: (...args: unknown[]) => void, ...args: unknown[]): unknown
      }

}
declare module 'events' {
    export class EventEmitter {
    _events: Record<string | symbol, NekoEventListener[]>;
    _maxListeners: number | undefined;
    constructor();
    on(name: string | symbol, listener: NekoEventListener): this;
    addListener(name: string | symbol, listener: NekoEventListener): this;
    prependListener(name: string | symbol, listener: NekoEventListener): this;
    warnIfExceeded(name: string | symbol): void;
    once(name: string | symbol, listener: NekoEventListener): this;
    prependOnceListener(name: string | symbol, listener: NekoEventListener): this;
    off(name: string | symbol, listener: NekoEventListener): this;
    removeListener(name: string | symbol, listener: NekoEventListener): this;
    emit(name: string | symbol, ...args: unknown[]): boolean;
    listeners(name: string | symbol): NekoEventListener[];
    rawListeners(name: string | symbol): NekoEventListener[];
    listenerCount(name: string | symbol): number;
    eventNames(): Array<string | symbol>;
    setMaxListeners(value: number): this;
    getMaxListeners(): number;
    removeAllListeners(name?: string | symbol): this;
    static defaultMaxListeners: number;
    }
    export const errorMonitor: unknown;
    export const defaultMaxListeners: number;
    export const once: unknown;
    export const on: unknown;
    export const listenerCount: unknown;
    type NekoEventListener = (...args: unknown[]) => void

}
declare module 'node:events' {
    export class EventEmitter {
    _events: Record<string | symbol, NekoEventListener[]>;
    _maxListeners: number | undefined;
    constructor();
    on(name: string | symbol, listener: NekoEventListener): this;
    addListener(name: string | symbol, listener: NekoEventListener): this;
    prependListener(name: string | symbol, listener: NekoEventListener): this;
    warnIfExceeded(name: string | symbol): void;
    once(name: string | symbol, listener: NekoEventListener): this;
    prependOnceListener(name: string | symbol, listener: NekoEventListener): this;
    off(name: string | symbol, listener: NekoEventListener): this;
    removeListener(name: string | symbol, listener: NekoEventListener): this;
    emit(name: string | symbol, ...args: unknown[]): boolean;
    listeners(name: string | symbol): NekoEventListener[];
    rawListeners(name: string | symbol): NekoEventListener[];
    listenerCount(name: string | symbol): number;
    eventNames(): Array<string | symbol>;
    setMaxListeners(value: number): this;
    getMaxListeners(): number;
    removeAllListeners(name?: string | symbol): this;
    static defaultMaxListeners: number;
    }
    export const errorMonitor: unknown;
    export const defaultMaxListeners: number;
    export const once: unknown;
    export const on: unknown;
    export const listenerCount: unknown;
    type NekoEventListener = (...args: unknown[]) => void

}
declare module 'module' {
    export function createRequire(metaUrl: string): NekoRequire;
    export const builtinModules: string[];
    export function isBuiltin(id: unknown): boolean;
    interface NekoRequire {
        (id: string): unknown
        resolve(id: string): string
      }

}
declare module 'node:module' {
    export function createRequire(metaUrl: string): NekoRequire;
    export const builtinModules: string[];
    export function isBuiltin(id: unknown): boolean;
    interface NekoRequire {
        (id: string): unknown
        resolve(id: string): string
      }

}
declare module 'os' {
    export function arch(): string;
    export function platform(): string;
    export function cpus(): NekoCpuInfo[];
    export function freemem(): number;
    export function totalmem(): number;
    export function homedir(): string;
    export function hostname(): string;
    export function tmpdir(): string;
    export function uptime(): number;
    export function userInfo(): NekoUserInfo;
    export function networkInterfaces(): Record<string, NekoNetworkInterfaceInfo[]>;
    export function endianness(): string;
    export function loadavg(): [number, number, number];
    export const EOL: unknown;
    export function release(): string;
    export function type(): string;
    export function version(): string;
    export const constants: { UV_UDP_REUSEADDR: number; SIGTRAP: number; SIGKILL: number; SIGUSR1: number; SIGUSR2: number; SIGPIPE: number; SIGALRM: number; SIGTERM: number; errno: Record<string, unknown>; priority: Record<string, unknown>; dlopen: Record<string, unknown>; signals: Record<string, unknown> };
    export const devNull: unknown;
    interface NekoCpuInfo { model: string; speed: number; times: { user: number; nice: number; sys: number; idle: number; irq: number } }
    interface NekoUserInfo { username: string; homedir: string; shell: string }
    interface NekoNetworkInterfaceInfo { address: string; family: string; netmask: string; mac: string; internal: boolean; cidr: string; scopeid: number }

}
declare module 'node:os' {
    export function arch(): string;
    export function platform(): string;
    export function cpus(): NekoCpuInfo[];
    export function freemem(): number;
    export function totalmem(): number;
    export function homedir(): string;
    export function hostname(): string;
    export function tmpdir(): string;
    export function uptime(): number;
    export function userInfo(): NekoUserInfo;
    export function networkInterfaces(): Record<string, NekoNetworkInterfaceInfo[]>;
    export function endianness(): string;
    export function loadavg(): [number, number, number];
    export const EOL: unknown;
    export function release(): string;
    export function type(): string;
    export function version(): string;
    export const constants: { UV_UDP_REUSEADDR: number; SIGTRAP: number; SIGKILL: number; SIGUSR1: number; SIGUSR2: number; SIGPIPE: number; SIGALRM: number; SIGTERM: number; errno: Record<string, unknown>; priority: Record<string, unknown>; dlopen: Record<string, unknown>; signals: Record<string, unknown> };
    export const devNull: unknown;
    interface NekoCpuInfo { model: string; speed: number; times: { user: number; nice: number; sys: number; idle: number; irq: number } }
    interface NekoUserInfo { username: string; homedir: string; shell: string }
    interface NekoNetworkInterfaceInfo { address: string; family: string; netmask: string; mac: string; internal: boolean; cidr: string; scopeid: number }

}
declare module 'example' {
    /** 根据 id 构造示例信息。 */
    export function getInfo(id: number): ExampleInfo;
    /** 返回当前状态。 */
    export function status(): Status;
    export const version: string;
    interface ExampleInfo { id: number; name: string }
    type Status = 'ok' | 'error';

}
declare module 'node:example' {
    /** 根据 id 构造示例信息。 */
    export function getInfo(id: number): ExampleInfo;
    /** 返回当前状态。 */
    export function status(): Status;
    export const version: string;
    interface ExampleInfo { id: number; name: string }
    type Status = 'ok' | 'error';

}
declare module 'nekojs/jsx-runtime' {
    export const jsx: NekoUiJsxFactory;
    export const jsxs: NekoUiJsxFactory;
    export const Fragment: NekoUiFragment;
    export const UI: NekoUiApi;
    type NekoUiProfile = 1 | 2 | 3 | 4 | 5 | 6
    type NekoUiPrimitive = 'screen' | 'panel' | 'row' | 'column' | 'stack' | 'scroll' | 'label' | 'button' | 'input' | 'image' | 'spacer'
    type NekoUiJsxType = NekoUiPrimitive | NekoUiComponent | symbol
    type NekoUiLayoutSize = number | 'auto' | 'fill' | `${number}%`
    type NekoUiResponsive<T> = T | { readonly base?: T; readonly profiles?: Partial<Record<NekoUiProfile, T>> }
    type NekoUiEventName = 'onClick' | 'onRelease' | 'onScroll' | 'onKey' | 'onTextInput' | 'onFocus' | 'onBlur' | 'onChange' | 'onSubmit'
    type NekoUiDirection = 'row' | 'column'
    type NekoUiAnchor = 'topLeft' | 'top' | 'topRight' | 'left' | 'center' | 'right' | 'bottomLeft' | 'bottom' | 'bottomRight'
    interface NekoUiSafeArea {
        readonly left?: number
        readonly top?: number
        readonly right?: number
        readonly bottom?: number
      }
    interface NekoUiViewportCapabilities {
        readonly maxProfile?: NekoUiProfile
      }
    interface NekoUiViewportInput {
        readonly width: number
        readonly height: number
        readonly safeArea?: NekoUiSafeArea
        readonly guiScale?: number
        readonly capabilities?: NekoUiViewportCapabilities
        readonly designWidth?: number
        readonly designHeight?: number
      }
    interface NekoUiViewport {
        readonly width: number
        readonly height: number
        readonly safeArea: Required<NekoUiSafeArea>
        readonly contentWidth: number
        readonly contentHeight: number
        readonly profile: NekoUiProfile
        readonly guiScale?: number
        readonly capabilities: NekoUiViewportCapabilities
        readonly designScale: number
      }
    interface NekoUiEvent {
        readonly type: string
        readonly target: string
        readonly x?: number
        readonly y?: number
        readonly button?: number
        readonly key?: string
        readonly value?: string
        readonly delta?: number
      }
    interface NekoVNode {
        readonly $$nekoJsx: true
        readonly type: string | symbol | NekoUiComponent
        readonly key: string | null
        readonly props: Readonly<Record<string, unknown>>
        readonly children: readonly unknown[]
      }
    type NekoUiComponent = Function
    type NekoUiCallback = Function
    interface NekoUiDiagnostic {
        readonly rootId: string
        readonly phase: 'render' | 'component' | 'layout' | 'event' | 'host-update'
        readonly error: unknown
      }
    interface NekoUiHostNode {
        readonly type: NekoUiPrimitive | '#text'
        readonly key: string | null
        readonly props: Readonly<Record<string, unknown>>
        readonly children: readonly NekoUiHostNode[]
      }
    interface NekoUiHostTransaction {
        create(type: NekoUiPrimitive | '#text', key: string | null, props: Readonly<Record<string, unknown>>): unknown
        update(handle: unknown, type: NekoUiPrimitive | '#text', key: string | null, props: Readonly<Record<string, unknown>>): void
        order(parent: unknown | null, children: readonly unknown[]): void
        remove(handle: unknown): void
        commit(roots: readonly unknown[]): void
        rollback(): void
      }
    interface NekoUiRect {
        readonly x: number
        readonly y: number
        readonly width: number
        readonly height: number
      }
    interface NekoUiLayoutNode {
        readonly type: NekoUiPrimitive | '#text'
        readonly key: string | null
        readonly id?: string
        readonly profile: NekoUiProfile
        readonly visible: boolean
        readonly rect: NekoUiRect
        readonly clip: NekoUiRect
        readonly overflow: Readonly<Record<'left' | 'top' | 'right' | 'bottom', number>>
        readonly style: Readonly<Record<string, unknown>>
        readonly bindings: readonly string[]
        readonly children: readonly NekoUiLayoutNode[]
      }
    interface NekoUiLayoutSnapshot {
        readonly profile: NekoUiProfile
        readonly viewport: NekoUiViewport
        readonly nodes: readonly NekoUiLayoutNode[]
        readonly diagnostics: readonly string[]
      }
    interface NekoUiHostAdapter {
        isOwnerThread(): boolean
        enqueue(action: NekoUiCallback): boolean
        supportsPrimitive(type: NekoUiPrimitive): boolean
        layout(tree: readonly NekoUiHostNode[], viewport?: NekoUiViewport, snapshot?: NekoUiLayoutSnapshot, publish?: boolean): void
        measureText?(text: string, fontSize: number, maxWidth: number, font?: string): { readonly width: number; readonly height: number }
        begin(): NekoUiHostTransaction
        reportDiagnostic(diagnostic: NekoUiDiagnostic): void
        viewport?(): NekoUiViewportInput
      }
    interface NekoUiSignal<T> {
        get(): T
        set(value: T): boolean | 'queued'
        update(updater: NekoUiCallback): boolean | 'queued'
      }
    interface NekoUiStore {
        get(key: string): unknown
        set(key: string, value: unknown): boolean | 'queued'
        update(key: string, updater: NekoUiCallback): boolean | 'queued'
        snapshot(): Readonly<Record<string, unknown>>
      }
    interface NekoUiRootHandle {
        readonly id: string
        refresh(): boolean | 'queued'
        resize(viewport: NekoUiViewportInput): boolean | 'queued'
        layout(): NekoUiLayoutSnapshot | null
        dispatch(id: string, eventName: string, event: Partial<NekoUiEvent>): boolean | 'queued'
        isDisposed(): boolean
        close(): boolean | 'queued'
      }
    interface NekoUiSharedProps {
        id?: string
        key?: string | number
        children?: unknown
        width?: NekoUiResponsive<NekoUiLayoutSize>
        height?: NekoUiResponsive<NekoUiLayoutSize>
        minWidth?: NekoUiResponsive<NekoUiLayoutSize>
        maxWidth?: NekoUiResponsive<NekoUiLayoutSize>
        minHeight?: NekoUiResponsive<NekoUiLayoutSize>
        maxHeight?: NekoUiResponsive<NekoUiLayoutSize>
        gap?: NekoUiResponsive<number>
        spacing?: NekoUiResponsive<number>
        padding?: NekoUiResponsive<number>
        align?: NekoUiResponsive<'start' | 'center' | 'end' | 'stretch'>
        justify?: NekoUiResponsive<'start' | 'center' | 'end' | 'spaceBetween' | 'spaceAround'>
        direction?: NekoUiResponsive<NekoUiDirection>
        anchor?: NekoUiResponsive<NekoUiAnchor>
        coordinateSpace?: 'logical' | 'design'
        visible?: NekoUiResponsive<boolean>
        onClick?: NekoUiCallback
        onRelease?: NekoUiCallback
        onScroll?: NekoUiCallback
        onKey?: NekoUiCallback
        onTextInput?: NekoUiCallback
        onFocus?: NekoUiCallback
        onBlur?: NekoUiCallback
        onChange?: NekoUiCallback
        onSubmit?: NekoUiCallback
      }
    type NekoUiCrop = { readonly x: number; readonly y: number; readonly width: number; readonly height: number } | readonly [number, number, number, number]
    type NekoUiPrimitivePropsByType = {
        screen: NekoUiSharedProps & { title?: string; pausesGame?: boolean; closeOnEscape?: boolean }
        panel: NekoUiSharedProps & { background?: string | number; borderColor?: string | number; borderWidth?: number; radius?: number; opacity?: number }
        row: NekoUiSharedProps
        column: NekoUiSharedProps
        stack: NekoUiSharedProps
        scroll: NekoUiSharedProps & { scrollX?: NekoUiResponsive<boolean>; scrollY?: NekoUiResponsive<boolean>; scrollOffset?: NekoUiResponsive<number> }
        label: NekoUiSharedProps & { text?: string; color?: string | number; fontSize?: NekoUiResponsive<number>; font?: NekoUiResponsive<string>; wrap?: boolean; truncate?: boolean }
        button: NekoUiSharedProps & { text?: string; disabled?: boolean; tooltip?: string }
        input: NekoUiSharedProps & { value?: string; placeholder?: string; maxLength?: number; disabled?: boolean }
        image: NekoUiSharedProps & { resource?: string; fit?: 'contain' | 'cover' | 'stretch'; opacity?: number; icon?: string; crop?: NekoUiCrop }
        spacer: NekoUiSharedProps
      }
    type NekoUiPrimitiveProps = NekoUiPrimitivePropsByType[NekoUiPrimitive]
    type NekoUiElementProps<T extends NekoUiJsxType> = T extends NekoUiPrimitive ? NekoUiPrimitivePropsByType[T] : object
    type NekoUiJsxFactory = <T extends NekoUiJsxType>(type: T, props: NekoUiElementProps<T> | null, key?: string | number) => NekoVNode
    interface NekoUiFragment {
        (props: object): NekoVNode
      }
    export namespace JSX {
        interface Element extends NekoVNode {}
        interface ElementChildrenAttribute { children: {} }
        interface IntrinsicElements {
          screen: NekoUiPrimitivePropsByType['screen']
          panel: NekoUiPrimitivePropsByType['panel']
          row: NekoUiPrimitivePropsByType['row']
          column: NekoUiPrimitivePropsByType['column']
          stack: NekoUiPrimitivePropsByType['stack']
          scroll: NekoUiPrimitivePropsByType['scroll']
          label: NekoUiPrimitivePropsByType['label']
          button: NekoUiPrimitivePropsByType['button']
          input: NekoUiPrimitivePropsByType['input']
          image: NekoUiPrimitivePropsByType['image']
          spacer: NekoUiPrimitivePropsByType['spacer']
        }
      }
    interface NekoUiRootOptions {
        id?: string
        viewport?: NekoUiViewportInput
      }
    interface NekoUiApi {
        primitives(): readonly NekoUiPrimitive[]
        resolveViewport(input: NekoUiViewportInput): NekoUiViewport
        profileFor(input: NekoUiViewportInput): NekoUiProfile
        element<T extends NekoUiJsxType>(type: T, props: NekoUiElementProps<T> | null, key?: string | number): NekoVNode
        createSignal<T>(initial: T): NekoUiSignal<T>
        createStore(initial: Record<string, unknown>): NekoUiStore
        createRoot(render: NekoUiCallback, adapter: NekoUiHostAdapter, options?: NekoUiRootOptions): NekoUiRootHandle
        batch<T>(callback: () => T): T
        readonly fragment: NekoUiFragment
      }

}
declare function require(id: string): any;
declare const module: { exports: any };
declare const exports: any;
