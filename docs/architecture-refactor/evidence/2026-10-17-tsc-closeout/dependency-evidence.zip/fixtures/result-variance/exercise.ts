import type { $TypeScriptResultVarianceTest$Producer as Producer, $TypeScriptResultVarianceTest$Producer_ as Input } from 'java:com/tkisor/nekojs/probe/ir';
interface Animal { animal: true; }
interface Dog extends Animal { dog: true; }
declare const narrowResult: Producer<Animal, Dog>;
declare const broadResult: Producer<Animal, Animal>;
const covariant: Producer<Animal, Animal> = narrowResult;
const hostInput: Input<Dog, Animal, object, Animal> = narrowResult;
const callback: Input<Dog, Animal, object, Animal> = key => ({animal: true});
// @ts-expect-error The original result relation still rejects a broader host result.
const wrongResult: Producer<Animal, Dog> = broadResult;
// @ts-expect-error Callback results retain their original bound.
const wrongCallback: Input<Dog, Animal, object, Animal> = key => 1;
