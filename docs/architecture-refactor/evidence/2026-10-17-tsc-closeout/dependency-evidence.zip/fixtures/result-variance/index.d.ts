declare module "java:com/tkisor/nekojs/probe/ir" {
    export interface $TypeScriptResultVarianceTest$Producer<K, out V> {
        defaultReturnValue(value: V): void;
        get(key: object): V;
    }

    export type $TypeScriptResultVarianceTest$Producer_<Host0 = any, Host1 = any, CallbackArg0 = object, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptResultVarianceTest$Producer<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
}
