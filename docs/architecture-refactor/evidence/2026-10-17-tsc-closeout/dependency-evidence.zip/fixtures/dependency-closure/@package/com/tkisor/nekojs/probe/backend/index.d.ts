export * as typescript from "java:com/tkisor/nekojs/probe/backend/typescript";

