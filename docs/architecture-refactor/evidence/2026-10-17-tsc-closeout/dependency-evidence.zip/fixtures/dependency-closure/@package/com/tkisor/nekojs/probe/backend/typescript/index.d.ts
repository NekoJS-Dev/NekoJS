import { $ClosureTypes$Leaf } from "java:com/tkisor/nekojs/probe/testfixture/closure";

declare module "java:com/tkisor/nekojs/probe/backend/typescript" {
    export class $TypeScriptDeclarationClosureTest$Root {
        constructor();
        leaf: $ClosureTypes$Leaf;
    }

}
