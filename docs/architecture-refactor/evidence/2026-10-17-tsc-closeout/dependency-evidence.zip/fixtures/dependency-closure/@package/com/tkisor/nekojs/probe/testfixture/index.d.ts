export * as closure from "java:com/tkisor/nekojs/probe/testfixture/closure";

