declare module "java:com/tkisor/nekojs/probe/testfixture/closure" {
    export class $ClosureTypes$Leaf extends $ClosureTypes$Parent {
        constructor();
        nested: $ClosureTypes$Child;
    }

    export class $ClosureTypes$Child {
        constructor();
        text: string;
    }

    export class $ClosureTypes$Parent {
        constructor();
        token: number;
    }

}
