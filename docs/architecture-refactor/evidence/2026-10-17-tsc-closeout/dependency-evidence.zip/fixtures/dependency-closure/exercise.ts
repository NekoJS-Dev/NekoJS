import type { $TypeScriptDeclarationClosureTest$Root as Root } from 'java:com/tkisor/nekojs/probe/backend/typescript';
declare const root: Root;
const inherited: number = root.leaf.token;
const nested: string = root.leaf.nested.text;
// @ts-expect-error The completed dependency retains real inherited members.
const wrongParent: string = root.leaf.token;
// @ts-expect-error The completed member graph is not an empty or any declaration.
root.leaf.nested.missing;
