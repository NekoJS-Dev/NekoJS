// Bindings for server scripts
import { $TypeScriptDeclarationClosureTest$Root } from "java:com/tkisor/nekojs/probe/backend/typescript";

export {};

declare global {
    let Root: $TypeScriptDeclarationClosureTest$Root;
}
