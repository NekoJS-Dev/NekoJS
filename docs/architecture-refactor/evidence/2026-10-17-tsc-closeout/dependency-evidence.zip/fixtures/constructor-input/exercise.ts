import { $TypeScriptConstructorInputTest$Api as Api, $TypeScriptConstructorInputTest$Payload as Payload } from 'constructor-input-fixture';
declare const payload: Payload;
const api = new Api<Payload>({value: payload}, payload);
new Api<Payload>([1, 'text']);
new Api<Payload>(1, payload);
const result: Payload = api.identity(payload);
// @ts-expect-error Constructor-local bounds remain meaningful inside host containers.
new Api<Payload>({value: 1}, payload);
// @ts-expect-error Class-level variables are not erased along with constructor locals.
new Api<Payload>({value: payload}, 1);
// @ts-expect-error A constructor-local bound on a class variable retains that class scope.
new Api<Payload>(1, {listen() {}});
// @ts-expect-error Generic methods retain their declared bounds.
api.identity({listen() {}});
// @ts-expect-error Class-level method inputs remain precise.
api.owner(1);
