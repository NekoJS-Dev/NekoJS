declare module 'constructor-input-fixture' {
    export interface $TypeScriptConstructorInputTest$Listener {
        listen(): void;
    }
    export class $TypeScriptConstructorInputTest$Payload implements $TypeScriptConstructorInputTest$Listener {
        constructor();
        label: string;
        listen(): void;
    }
    export class $TypeScriptConstructorInputTest$Box<T> {
        constructor();
        value: T;
    }
    export class $TypeScriptConstructorInputTest$Api<L extends $TypeScriptConstructorInputTest$Listener> {
        constructor(values: any[]);
        constructor(value: $TypeScriptConstructorInputTest$Box<$TypeScriptConstructorInputTest$Payload>, owner: L);
        constructor(marker: number, owner: L);
        identity<S extends $TypeScriptConstructorInputTest$Payload>(value: S): S;
        owner(value: L): L;
    }
}
