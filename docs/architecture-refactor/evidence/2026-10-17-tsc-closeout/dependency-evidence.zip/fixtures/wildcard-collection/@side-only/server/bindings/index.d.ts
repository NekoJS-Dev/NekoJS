// Bindings for server scripts
import { $ProbeWildcardCollectionTest$Root } from "java:com/tkisor/nekojs/probe";

export {};

declare global {
    let Root: $ProbeWildcardCollectionTest$Root;
}
