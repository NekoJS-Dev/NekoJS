declare module "java:com/tkisor/nekojs/probe" {
    export class $ProbeWildcardCollectionTest$BeyondDepth {
        constructor();
    }

    export class $ProbeWildcardCollectionTest$Box<T> {
        constructor();
        value: T;
    }

    export class $ProbeWildcardCollectionTest$Root {
        constructor();
        values: $ProbeWildcardCollectionTest$Box<$ProbeWildcardCollectionTest$Value[][]>;
    }

    export class $ProbeWildcardCollectionTest$Value {
        constructor();
        label: string;
        next: $ProbeWildcardCollectionTest$BeyondDepth;
    }

}
