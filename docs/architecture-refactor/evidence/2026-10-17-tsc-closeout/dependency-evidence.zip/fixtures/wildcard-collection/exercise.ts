import type { $ProbeWildcardCollectionTest$Root as Root } from 'java:com/tkisor/nekojs/probe';
declare const root: Root;
const label: string = root.values.value[0][0].label;
// @ts-expect-error The wildcard upper bound keeps its member types.
const invalid: number = root.values.value[0][0].label;
// @ts-expect-error The nested array shape remains precise.
const missingDimension: string = root.values.value[0].label;
