export * as function from "java:org/apache/commons/lang3/function";

