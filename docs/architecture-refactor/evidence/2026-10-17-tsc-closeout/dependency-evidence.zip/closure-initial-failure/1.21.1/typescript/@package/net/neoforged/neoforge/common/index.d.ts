import { $Codec } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Collection, $List } from "java:java/util";
import { $BiFunction, $BiFunction_, $Supplier, $Supplier_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $DataComponentHolder, $DataComponentHolder_, $DataComponentMap, $DataComponentPatch, $DataComponentType } from "java:net/minecraft/core/component";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $AbstractMinecart } from "java:net/minecraft/world/entity/vehicle";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Level } from "java:net/minecraft/world/level";
import { $AABB } from "java:net/minecraft/world/phys";

export * as brewing from "java:net/neoforged/neoforge/common/brewing";
export * as conditions from "java:net/neoforged/neoforge/common/conditions";
export * as crafting from "java:net/neoforged/neoforge/common/crafting";
export * as damagesource from "java:net/neoforged/neoforge/common/damagesource";
export * as enums from "java:net/neoforged/neoforge/common/enums";
export * as extensions from "java:net/neoforged/neoforge/common/extensions";
export * as util from "java:net/neoforged/neoforge/common/util";
export * as world from "java:net/neoforged/neoforge/common/world";

declare module "java:net/neoforged/neoforge/common" {
    export class $EffectCure {
        static CODEC: $Codec<$EffectCure>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $EffectCure>;
        static getAllCures(): $Collection<$EffectCure>;
        static get(arg0: string): $EffectCure;
        name(): string;
        toString(): string;
    }

    export interface $IMinecartCollisionHandler {
        getBoundingBox(arg0: $AbstractMinecart): $AABB;
        getCollisionBox(arg0: $AbstractMinecart, arg1: $Entity): $AABB;
        getMinecartCollisionBox(arg0: $AbstractMinecart): $AABB;
        onEntityCollision(arg0: $AbstractMinecart, arg1: $Entity): void;
    }

    export interface $IShearable {
        isShearable(arg0: $Player, arg1: $ItemStack_, arg2: $Level, arg3: $BlockPos_): boolean;
        onSheared(arg0: $Player, arg1: $ItemStack_, arg2: $Level, arg3: $BlockPos_): $List<$ItemStack>;
        spawnShearedDrop(arg0: $Level, arg1: $BlockPos_, arg2: $ItemStack_): void;
    }

    export class $ItemAbility {
        static CODEC: $Codec<$ItemAbility>;
        static getActions(): $Collection<$ItemAbility>;
        static get(arg0: string): $ItemAbility;
        name(): string;
        toString(): string;
    }

    export interface $MutableDataComponentHolder extends $DataComponentHolder {
        applyComponents(arg0: $DataComponentMap): void;
        applyComponents(arg0: $DataComponentPatch): void;
        copyFrom(arg0: $DataComponentHolder_<$DataComponentMap>, arg1?: $Supplier_<$DataComponentType<any>, $DataComponentType<any>>[]): void;
        copyFrom(arg0: $DataComponentHolder_<$DataComponentMap>, arg1?: $DataComponentType<any>[]): void;
        remove<T>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>): T;
        remove<T>(arg0: $DataComponentType<T>): T;
        set<T>(arg0: $Supplier_<$DataComponentType<any>, $DataComponentType<any>>, arg1: T): T;
        set<T>(arg0: $DataComponentType<any>, arg1: T): T;
        update<T, U>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>, arg1: T, arg2: U, arg3: $BiFunction_<T, U, T, T, U, T>): T;
        update<T>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>, arg1: T, arg2: $UnaryOperator_<T, T, T>): T;
        update<T, U>(arg0: $DataComponentType<T>, arg1: T, arg2: U, arg3: $BiFunction_<T, U, T, T, U, T>): T;
        update<T>(arg0: $DataComponentType<T>, arg1: T, arg2: $UnaryOperator_<T, T, T>): T;
    }

    export class $SoundAction {
        static get(arg0: string): $SoundAction;
        name(): string;
        toString(): string;
    }

}
