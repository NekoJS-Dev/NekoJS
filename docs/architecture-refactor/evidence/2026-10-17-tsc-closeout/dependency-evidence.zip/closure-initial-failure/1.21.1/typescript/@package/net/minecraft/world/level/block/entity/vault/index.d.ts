import { $Record } from "java:java/lang";
import { $List, $Optional, $UUID } from "java:java/util";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Connection } from "java:net/minecraft/network";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientGamePacketListener, $ClientboundBlockEntityDataPacket } from "java:net/minecraft/network/protocol/game";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $PlayerDetector, $PlayerDetector$EntitySelector, $PlayerDetector_ } from "java:net/minecraft/world/level/block/entity/trialspawner";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $AttachmentType } from "java:net/neoforged/neoforge/attachment";
import { $ModelData } from "java:net/neoforged/neoforge/client/model/data";

declare module "java:net/minecraft/world/level/block/entity/vault" {
    export class $VaultBlockEntity extends $BlockEntity {
        constructor(arg0: $BlockPos_, arg1: $BlockState_);
        get clientData(): $VaultClientData;
        getClientData(): $VaultClientData;
        get config(): $VaultConfig;
        getConfig(): $VaultConfig;
        set config(value: $VaultConfig);
        get modelData(): $ModelData;
        getModelData(): $ModelData;
        get serverData(): $VaultServerData;
        getServerData(): $VaultServerData;
        get sharedData(): $VaultSharedData;
        getSharedData(): $VaultSharedData;
        get updatePacket(): $Packet<$ClientGamePacketListener>;
        getUpdatePacket(): $Packet<$ClientGamePacketListener>;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        getUpdateTag(arg0: $HolderLookup$Provider): $CompoundTag;
        handleUpdateTag(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): void;
        hasCustomOutlineRendering(arg0: $Player): boolean;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        invalidateCapabilities(): void;
        onChunkUnloaded(): void;
        onDataPacket(arg0: $Connection, arg1: $ClientboundBlockEntityDataPacket, arg2: $HolderLookup$Provider): void;
        onLoad(): void;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        requestModelDataUpdate(): void;
        setConfig(arg0: $VaultConfig): void;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
    }

    export class $VaultClientData {
        static ROTATION_SPEED: number;
        currentSpin(): number;
        previousSpin(): number;
    }

    export class $VaultConfig extends $Record {
        constructor(arg0: $ResourceKey<$LootTable>, arg1: number, arg2: number, arg3: $ItemStack_, arg4: $Optional<$ResourceKey<$LootTable>>);
        constructor(arg0: $ResourceKey<$LootTable>, arg1: number, arg2: number, arg3: $ItemStack_, arg4: $Optional<$ResourceKey<$LootTable>>, arg5: $PlayerDetector_<$ServerLevel, $PlayerDetector$EntitySelector, $BlockPos, number, boolean, $UUID[]>, arg6: $PlayerDetector$EntitySelector);
        activationRange(): number;
        deactivationRange(): number;
        entitySelector(): $PlayerDetector$EntitySelector;
        equals(arg0: object): boolean;
        hashCode(): number;
        keyItem(): $ItemStack;
        lootTable(): $ResourceKey<$LootTable>;
        overrideLootTableToDisplay(): $Optional<$ResourceKey<$LootTable>>;
        playerDetector(): $PlayerDetector;
        toString(): string;
    }

    export class $VaultServerData {
        addToRewardedPlayers(arg0: $Player): void;
        ejectionProgress(): number;
    }

    export class $VaultSharedData {
        get displayItem(): $ItemStack;
        getDisplayItem(): $ItemStack;
        set displayItem(value: $ItemStack_);
        hasDisplayItem(): boolean;
        setDisplayItem(arg0: $ItemStack_): void;
    }

}
