import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $AbstractContainerMenu } from "java:net/minecraft/world/inventory";

declare module "java:net/neoforged/neoforge/client/extensions" {
    export interface $IMenuProviderExtension {
        shouldTriggerClientSideContainerClosingOnOpen(): boolean;
        writeClientSideData(arg0: $AbstractContainerMenu, arg1: $RegistryFriendlyByteBuf): void;
    }

}
