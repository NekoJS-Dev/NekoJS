import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Function, $Function_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Holder, $HolderSet, $Holder_, $RegistryAccess } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $FloatProvider } from "java:net/minecraft/util/valueproviders";
import { $ChunkPos, $LevelHeightAccessor } from "java:net/minecraft/world/level";
import { $Biome } from "java:net/minecraft/world/level/biome";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $CarvingMask, $ChunkAccess } from "java:net/minecraft/world/level/chunk";
import { $Aquifer, $NoiseBasedChunkGenerator, $NoiseChunk, $RandomState, $SurfaceRules$RuleSource, $VerticalAnchor, $VerticalAnchor_, $WorldGenerationContext } from "java:net/minecraft/world/level/levelgen";
import { $ConfiguredFeature } from "java:net/minecraft/world/level/levelgen/feature";
import { $ProbabilityFeatureConfiguration } from "java:net/minecraft/world/level/levelgen/feature/configurations";
import { $HeightProvider } from "java:net/minecraft/world/level/levelgen/heightproviders";

declare module "java:net/minecraft/world/level/levelgen/carver" {
    export class $CarverConfiguration extends $ProbabilityFeatureConfiguration {
        constructor(arg0: number, arg1: $HeightProvider, arg2: $FloatProvider, arg3: $VerticalAnchor_<$WorldGenerationContext, number>, arg4: $CarverDebugSettings, arg5: $HolderSet<$Block>);
        static CODEC: $MapCodec<$CarverConfiguration>;
        debugSettings: $CarverDebugSettings;
        lavaLevel: $VerticalAnchor;
        replaceable: $HolderSet<$Block>;
        y: $HeightProvider;
        yScale: $FloatProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $CarvingContext extends $WorldGenerationContext {
        constructor(arg0: $NoiseBasedChunkGenerator, arg1: $RegistryAccess, arg2: $LevelHeightAccessor, arg3: $NoiseChunk, arg4: $RandomState, arg5: $SurfaceRules$RuleSource);
        randomState(): $RandomState;
        registryAccess(): $RegistryAccess;
        topMaterial(arg0: $Function_<$BlockPos, $Holder<$Biome>, $BlockPos, $Holder_<$Biome>>, arg1: $ChunkAccess, arg2: $BlockPos_, arg3: boolean): $Optional<$BlockState>;
    }

    export class $ConfiguredWorldCarver<WC extends $CarverConfiguration> extends $Record {
        constructor(arg0: $WorldCarver<WC>, arg1: WC);
        static CODEC: $Codec<$Holder<$ConfiguredWorldCarver<any>>>;
        static DIRECT_CODEC: $Codec<$ConfiguredWorldCarver<any>>;
        static LIST_CODEC: $Codec<$HolderSet<$ConfiguredWorldCarver<any>>>;
        carve(arg0: $CarvingContext, arg1: $ChunkAccess, arg2: $Function_<$BlockPos, $Holder<$Biome>, $BlockPos, $Holder_<$Biome>>, arg3: $RandomSource, arg4: $Aquifer, arg5: $ChunkPos, arg6: $CarvingMask): boolean;
        config(): WC;
        equals(arg0: object): boolean;
        hashCode(): number;
        isStartChunk(arg0: $RandomSource): boolean;
        toString(): string;
        worldCarver(): $WorldCarver<WC>;
    }

    export class $WorldCarver<C extends $CarverConfiguration> {
        constructor(arg0: $Codec<C>);
        static CANYON: $WorldCarver<$CanyonCarverConfiguration>;
        static CAVE: $WorldCarver<$CaveCarverConfiguration>;
        static NETHER_CAVE: $WorldCarver<$CaveCarverConfiguration>;
        get range(): number;
        getRange(): number;
        carve(arg0: $CarvingContext, arg1: C, arg2: $ChunkAccess, arg3: $Function_<$BlockPos, $Holder<$Biome>, $BlockPos, $Holder_<$Biome>>, arg4: $RandomSource, arg5: $Aquifer, arg6: $ChunkPos, arg7: $CarvingMask): boolean;
        configuredCodec(): $MapCodec<$ConfiguredWorldCarver<C>>;
        configured(arg0: C): $ConfiguredWorldCarver<C>;
        isStartChunk(arg0: C, arg1: $RandomSource): boolean;
    }

    export class $CarverDebugSettings {
        static CODEC: $Codec<$CarverDebugSettings>;
        static DEFAULT: $CarverDebugSettings;
        get airState(): $BlockState;
        getAirState(): $BlockState;
        get barrierState(): $BlockState;
        getBarrierState(): $BlockState;
        get lavaState(): $BlockState;
        getLavaState(): $BlockState;
        get waterState(): $BlockState;
        getWaterState(): $BlockState;
        get debugMode(): boolean;
        isDebugMode(): boolean;
        static of(arg0: boolean, arg1: $BlockState_, arg2: $BlockState_, arg3: $BlockState_, arg4: $BlockState_): $CarverDebugSettings;
        static of(arg0: boolean, arg1: $BlockState_): $CarverDebugSettings;
        static of(arg0: $BlockState_, arg1: $BlockState_, arg2: $BlockState_, arg3: $BlockState_): $CarverDebugSettings;
    }

    export class $CanyonCarverConfiguration extends $CarverConfiguration {
        constructor(arg0: number, arg1: $HeightProvider, arg2: $FloatProvider, arg3: $VerticalAnchor_<$WorldGenerationContext, number>, arg4: $CarverDebugSettings, arg5: $HolderSet<$Block>, arg6: $FloatProvider, arg7: $CanyonCarverConfiguration$CanyonShapeConfiguration);
        constructor(arg0: $CarverConfiguration, arg1: $FloatProvider, arg2: $CanyonCarverConfiguration$CanyonShapeConfiguration);
        static CODEC: $Codec<$CanyonCarverConfiguration>;
        shape: $CanyonCarverConfiguration$CanyonShapeConfiguration;
        verticalRotation: $FloatProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $CaveCarverConfiguration extends $CarverConfiguration {
        constructor(arg0: number, arg1: $HeightProvider, arg2: $FloatProvider, arg3: $VerticalAnchor_<$WorldGenerationContext, number>, arg4: $HolderSet<$Block>, arg5: $FloatProvider, arg6: $FloatProvider, arg7: $FloatProvider);
        constructor(arg0: number, arg1: $HeightProvider, arg2: $FloatProvider, arg3: $VerticalAnchor_<$WorldGenerationContext, number>, arg4: $CarverDebugSettings, arg5: $HolderSet<$Block>, arg6: $FloatProvider, arg7: $FloatProvider, arg8: $FloatProvider);
        constructor(arg0: $CarverConfiguration, arg1: $FloatProvider, arg2: $FloatProvider, arg3: $FloatProvider);
        static CODEC: $Codec<$CaveCarverConfiguration>;
        horizontalRadiusMultiplier: $FloatProvider;
        verticalRadiusMultiplier: $FloatProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $CanyonCarverConfiguration$CanyonShapeConfiguration {
        constructor(arg0: $FloatProvider, arg1: $FloatProvider, arg2: number, arg3: $FloatProvider, arg4: number, arg5: number);
        static CODEC: $Codec<$CanyonCarverConfiguration$CanyonShapeConfiguration>;
        distanceFactor: $FloatProvider;
        horizontalRadiusFactor: $FloatProvider;
        thickness: $FloatProvider;
        verticalRadiusCenterFactor: number;
        verticalRadiusDefaultFactor: number;
        widthSmoothness: number;
    }

}
