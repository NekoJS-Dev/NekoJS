import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Iterable } from "java:java/lang";
import { $List, $Optional, $Set, $UUID } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $GlobalPos } from "java:net/minecraft/core";
import { $Unit, $Unit_ } from "java:net/minecraft/util";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $AgeableMob, $Entity, $LivingEntity, $Mob } from "java:net/minecraft/world/entity";
import { $PositionTracker } from "java:net/minecraft/world/entity/ai/behavior";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Hoglin } from "java:net/minecraft/world/entity/monster/hoglin";
import { $AbstractPiglin } from "java:net/minecraft/world/entity/monster/piglin";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $Path } from "java:net/minecraft/world/level/pathfinder";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/entity/ai/memory" {
    export class $ExpirableValue<T> {
        constructor(arg0: T, arg1: number);
        get timeToLive(): number;
        getTimeToLive(): number;
        get value(): T;
        getValue(): T;
        static codec<T>(arg0: $Codec<T>): $Codec<$ExpirableValue<T>>;
        static of<T>(arg0: T, arg1: number): $ExpirableValue<T>;
        static of<T>(arg0: T): $ExpirableValue<T>;
        canExpire(): boolean;
        hasExpired(): boolean;
        tick(): void;
        toString(): string;
    }

    export class $MemoryModuleType<U> {
        constructor(arg0: $Optional<$Codec<U>>);
        static ADMIRING_DISABLED: $MemoryModuleType<boolean>;
        static ADMIRING_ITEM: $MemoryModuleType<boolean>;
        static ANGRY_AT: $MemoryModuleType<$UUID>;
        static ATE_RECENTLY: $MemoryModuleType<boolean>;
        static ATTACK_COOLING_DOWN: $MemoryModuleType<boolean>;
        static ATTACK_TARGET: $MemoryModuleType<$LivingEntity>;
        static AVOID_TARGET: $MemoryModuleType<$LivingEntity>;
        static BREED_TARGET: $MemoryModuleType<$AgeableMob>;
        static BREEZE_JUMP_COOLDOWN: $MemoryModuleType<$Unit>;
        static BREEZE_JUMP_INHALING: $MemoryModuleType<$Unit>;
        static BREEZE_JUMP_TARGET: $MemoryModuleType<$BlockPos>;
        static BREEZE_LEAVING_WATER: $MemoryModuleType<$Unit>;
        static BREEZE_SHOOT: $MemoryModuleType<$Unit>;
        static BREEZE_SHOOT_CHARGING: $MemoryModuleType<$Unit>;
        static BREEZE_SHOOT_COOLDOWN: $MemoryModuleType<$Unit>;
        static BREEZE_SHOOT_RECOVERING: $MemoryModuleType<$Unit>;
        static CANT_REACH_WALK_TARGET_SINCE: $MemoryModuleType<number>;
        static CELEBRATE_LOCATION: $MemoryModuleType<$BlockPos>;
        static DANCING: $MemoryModuleType<boolean>;
        static DANGER_DETECTED_RECENTLY: $MemoryModuleType<boolean>;
        static DIG_COOLDOWN: $MemoryModuleType<$Unit>;
        static DISABLE_WALK_TO_ADMIRE_ITEM: $MemoryModuleType<boolean>;
        static DISTURBANCE_LOCATION: $MemoryModuleType<$BlockPos>;
        static DOORS_TO_CLOSE: $MemoryModuleType<$Set<$GlobalPos>>;
        static DUMMY: $MemoryModuleType<void>;
        static GAZE_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static GOLEM_DETECTED_RECENTLY: $MemoryModuleType<boolean>;
        static HAS_HUNTING_COOLDOWN: $MemoryModuleType<boolean>;
        static HEARD_BELL_TIME: $MemoryModuleType<number>;
        static HIDING_PLACE: $MemoryModuleType<$GlobalPos>;
        static HOME: $MemoryModuleType<$GlobalPos>;
        static HUNTED_RECENTLY: $MemoryModuleType<boolean>;
        static HURT_BY: $MemoryModuleType<$DamageSource>;
        static HURT_BY_ENTITY: $MemoryModuleType<$LivingEntity>;
        static INTERACTABLE_DOORS: $MemoryModuleType<$List<$GlobalPos>>;
        static INTERACTION_TARGET: $MemoryModuleType<$LivingEntity>;
        static IS_EMERGING: $MemoryModuleType<$Unit>;
        static IS_IN_WATER: $MemoryModuleType<$Unit>;
        static IS_PANICKING: $MemoryModuleType<boolean>;
        static IS_PREGNANT: $MemoryModuleType<$Unit>;
        static IS_SNIFFING: $MemoryModuleType<$Unit>;
        static IS_TEMPTED: $MemoryModuleType<boolean>;
        static ITEM_PICKUP_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static JOB_SITE: $MemoryModuleType<$GlobalPos>;
        static LAST_SLEPT: $MemoryModuleType<number>;
        static LAST_WOKEN: $MemoryModuleType<number>;
        static LAST_WORKED_AT_POI: $MemoryModuleType<number>;
        static LIKED_NOTEBLOCK_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static LIKED_NOTEBLOCK_POSITION: $MemoryModuleType<$GlobalPos>;
        static LIKED_PLAYER: $MemoryModuleType<$UUID>;
        static LONG_JUMP_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static LONG_JUMP_MID_JUMP: $MemoryModuleType<boolean>;
        static LOOK_TARGET: $MemoryModuleType<$PositionTracker>;
        static MEETING_POINT: $MemoryModuleType<$GlobalPos>;
        static NEARBY_ADULT_PIGLINS: $MemoryModuleType<$List<$AbstractPiglin>>;
        static NEAREST_ATTACKABLE: $MemoryModuleType<$LivingEntity>;
        static NEAREST_BED: $MemoryModuleType<$BlockPos>;
        static NEAREST_HOSTILE: $MemoryModuleType<$LivingEntity>;
        static NEAREST_LIVING_ENTITIES: $MemoryModuleType<$List<$LivingEntity>>;
        static NEAREST_PLAYERS: $MemoryModuleType<$List<$Player>>;
        static NEAREST_PLAYER_HOLDING_WANTED_ITEM: $MemoryModuleType<$Player>;
        static NEAREST_REPELLENT: $MemoryModuleType<$BlockPos>;
        static NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD: $MemoryModuleType<$Player>;
        static NEAREST_VISIBLE_ADULT: $MemoryModuleType<$AgeableMob>;
        static NEAREST_VISIBLE_ADULT_HOGLINS: $MemoryModuleType<$List<$Hoglin>>;
        static NEAREST_VISIBLE_ADULT_PIGLIN: $MemoryModuleType<$AbstractPiglin>;
        static NEAREST_VISIBLE_ADULT_PIGLINS: $MemoryModuleType<$List<$AbstractPiglin>>;
        static NEAREST_VISIBLE_ATTACKABLE_PLAYER: $MemoryModuleType<$Player>;
        static NEAREST_VISIBLE_BABY_HOGLIN: $MemoryModuleType<$Hoglin>;
        static NEAREST_VISIBLE_HUNTABLE_HOGLIN: $MemoryModuleType<$Hoglin>;
        static NEAREST_VISIBLE_LIVING_ENTITIES: $MemoryModuleType<$NearestVisibleLivingEntities>;
        static NEAREST_VISIBLE_NEMESIS: $MemoryModuleType<$Mob>;
        static NEAREST_VISIBLE_PLAYER: $MemoryModuleType<$Player>;
        static NEAREST_VISIBLE_WANTED_ITEM: $MemoryModuleType<$ItemEntity>;
        static NEAREST_VISIBLE_ZOMBIFIED: $MemoryModuleType<$LivingEntity>;
        static PACIFIED: $MemoryModuleType<boolean>;
        static PATH: $MemoryModuleType<$Path>;
        static PLAY_DEAD_TICKS: $MemoryModuleType<number>;
        static POTENTIAL_JOB_SITE: $MemoryModuleType<$GlobalPos>;
        static RAM_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static RAM_TARGET: $MemoryModuleType<$Vec3>;
        static RECENT_PROJECTILE: $MemoryModuleType<$Unit>;
        static RIDE_TARGET: $MemoryModuleType<$Entity>;
        static ROAR_SOUND_COOLDOWN: $MemoryModuleType<$Unit>;
        static ROAR_SOUND_DELAY: $MemoryModuleType<$Unit>;
        static ROAR_TARGET: $MemoryModuleType<$LivingEntity>;
        static SECONDARY_JOB_SITE: $MemoryModuleType<$List<$GlobalPos>>;
        static SNIFFER_DIGGING: $MemoryModuleType<boolean>;
        static SNIFFER_EXPLORED_POSITIONS: $MemoryModuleType<$List<$GlobalPos>>;
        static SNIFFER_HAPPY: $MemoryModuleType<boolean>;
        static SNIFFER_SNIFFING_TARGET: $MemoryModuleType<$BlockPos>;
        static SNIFF_COOLDOWN: $MemoryModuleType<$Unit>;
        static SONIC_BOOM_COOLDOWN: $MemoryModuleType<$Unit>;
        static SONIC_BOOM_SOUND_COOLDOWN: $MemoryModuleType<$Unit>;
        static SONIC_BOOM_SOUND_DELAY: $MemoryModuleType<$Unit>;
        static TEMPTATION_COOLDOWN_TICKS: $MemoryModuleType<number>;
        static TEMPTING_PLAYER: $MemoryModuleType<$Player>;
        static TIME_TRYING_TO_REACH_ADMIRE_ITEM: $MemoryModuleType<number>;
        static TOUCH_COOLDOWN: $MemoryModuleType<$Unit>;
        static UNIVERSAL_ANGER: $MemoryModuleType<boolean>;
        static UNREACHABLE_TONGUE_TARGETS: $MemoryModuleType<$List<$UUID>>;
        static VIBRATION_COOLDOWN: $MemoryModuleType<$Unit>;
        static VISIBLE_ADULT_HOGLIN_COUNT: $MemoryModuleType<number>;
        static VISIBLE_ADULT_PIGLIN_COUNT: $MemoryModuleType<number>;
        static VISIBLE_VILLAGER_BABIES: $MemoryModuleType<$List<$LivingEntity>>;
        static WALK_TARGET: $MemoryModuleType<$WalkTarget>;
        get codec(): $Optional<$Codec<$ExpirableValue<U>>>;
        getCodec(): $Optional<$Codec<$ExpirableValue<U>>>;
        toString(): string;
    }

    export class $MemoryStatus {
        static REGISTERED: $MemoryStatus;
        static VALUE_ABSENT: $MemoryStatus;
        static VALUE_PRESENT: $MemoryStatus;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MemoryStatus[];
        static valueOf(name: string): $MemoryStatus;
    }
    export interface $MemoryStatus extends $Enum<$MemoryStatus> {}

    export class $NearestVisibleLivingEntities {
        constructor(arg0: $LivingEntity, arg1: $LivingEntity[]);
        static empty(): $NearestVisibleLivingEntities;
        contains(arg0: $Predicate_<$LivingEntity, $LivingEntity, boolean>): boolean;
        contains(arg0: $LivingEntity): boolean;
        findAll(arg0: $Predicate_<$LivingEntity, $LivingEntity, boolean>): $Iterable<$LivingEntity>;
        findClosest(arg0: $Predicate_<$LivingEntity, $LivingEntity, boolean>): $Optional<$LivingEntity>;
        find(arg0: $Predicate_<$LivingEntity, $LivingEntity, boolean>): $Stream<$LivingEntity>;
    }

    export class $WalkTarget {
        constructor(arg0: $BlockPos_, arg1: number, arg2: number);
        constructor(arg0: $Entity, arg1: number, arg2: number);
        constructor(arg0: $PositionTracker, arg1: number, arg2: number);
        constructor(arg0: $Vec3_, arg1: number, arg2: number);
        get closeEnoughDist(): number;
        getCloseEnoughDist(): number;
        get speedModifier(): number;
        getSpeedModifier(): number;
        get target(): $PositionTracker;
        getTarget(): $PositionTracker;
    }

    export type $MemoryStatus_ = $MemoryStatus | "REGISTERED" | "VALUE_ABSENT" | "VALUE_PRESENT";
}
