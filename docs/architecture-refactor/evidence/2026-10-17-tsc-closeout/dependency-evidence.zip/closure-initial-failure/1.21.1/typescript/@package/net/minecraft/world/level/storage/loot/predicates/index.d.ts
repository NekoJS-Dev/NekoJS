import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Iterable, $Record } from "java:java/lang";
import { $Function, $Function_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $LootContext, $LootContextUser } from "java:net/minecraft/world/level/storage/loot";

declare module "java:net/minecraft/world/level/storage/loot/predicates" {
    export class $AllOfCondition$Builder extends $CompositeLootItemCondition$Builder {
        constructor(arg0?: $LootItemCondition$Builder_<$LootItemCondition>[]);
        and(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AllOfCondition$Builder;
        invert(): $LootItemCondition$Builder;
        or(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AnyOfCondition$Builder;
    }

    export class $AnyOfCondition$Builder extends $CompositeLootItemCondition$Builder {
        constructor(arg0?: $LootItemCondition$Builder_<$LootItemCondition>[]);
        and(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AllOfCondition$Builder;
        invert(): $LootItemCondition$Builder;
        or(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AnyOfCondition$Builder;
    }

    export class $CompositeLootItemCondition$Builder implements $LootItemCondition$Builder {
        addTerm(arg0: $LootItemCondition$Builder_<$LootItemCondition>): void;
        and(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AllOfCondition$Builder;
        build(): $LootItemCondition;
        invert(): $LootItemCondition$Builder;
        or(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AnyOfCondition$Builder;
    }

    export interface $ConditionUserBuilder<T extends $ConditionUserBuilder<T>> {
        unwrap(): T;
        when<E>(arg0: $Iterable<E>, arg1: $Function_<E, $LootItemCondition$Builder, E, $LootItemCondition$Builder_<$LootItemCondition>>): T;
        when(arg0: $LootItemCondition$Builder_<$LootItemCondition>): T;
    }

    export interface $LootItemCondition extends $LootContextUser, $Predicate<$LootContext> {
        getType(): $LootItemConditionType;
    }
    export const $LootItemCondition: {
        readonly CODEC: $Codec<$Holder<$LootItemCondition>>;
        readonly DIRECT_CODEC: $Codec<$LootItemCondition>;
        readonly TYPED_CODEC: $Codec<$LootItemCondition>;
    };

    export interface $LootItemCondition$Builder {
        and(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AllOfCondition$Builder;
        build(): $LootItemCondition;
        invert(): $LootItemCondition$Builder;
        or(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AnyOfCondition$Builder;
    }

    export class $LootItemConditionType extends $Record {
        constructor(arg0: $MapCodec<$LootItemCondition>);
        codec(): $MapCodec<$LootItemCondition>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export type $LootItemCondition$Builder_<CallbackResult = $LootItemCondition> = (() => CallbackResult) | ($LootItemCondition$Builder & { readonly [Symbol.hasInstance]?: never });
    export type $LootItemConditionType_ = $LootItemConditionType | RegistryTypes.LootItemConditionType | $NekoId | string;
}
