import { $Codec } from "java:com/mojang/serialization";
import { $DoubleList } from "java:it/unimi/dsi/fastutil/doubles";
import { $Record, $StringBuilder } from "java:java/lang";
import { $List } from "java:java/util";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/world/level/levelgen/synth" {
    export class $NormalNoise {
        static createLegacyNetherBiome(arg0: $RandomSource, arg1: $NormalNoise$NoiseParameters): $NormalNoise;
        static create(arg0: $RandomSource, arg1: number, arg2?: number[]): $NormalNoise;
        static create(arg0: $RandomSource, arg1: $NormalNoise$NoiseParameters): $NormalNoise;
        getValue(arg0: number, arg1: number, arg2: number): number;
        maxValue(): number;
        parameters(): $NormalNoise$NoiseParameters;
        parityConfigString(arg0: $StringBuilder): void;
    }

    export class $NormalNoise$NoiseParameters extends $Record {
        constructor(arg0: number, arg1: number, arg2?: number[]);
        constructor(arg0: number, arg1: $DoubleList);
        constructor(arg0: number, arg1: number[]);
        static CODEC: $Codec<$Holder<$NormalNoise$NoiseParameters>>;
        static DIRECT_CODEC: $Codec<$NormalNoise$NoiseParameters>;
        amplitudes(): $DoubleList;
        equals(arg0: object): boolean;
        firstOctave(): number;
        hashCode(): number;
        toString(): string;
    }

    export class $PerlinSimplexNoise {
        constructor(arg0: $RandomSource, arg1: number[]);
        getValue(arg0: number, arg1: number, arg2: boolean): number;
    }

}
