import { $Either } from "java:com/mojang/datafixers/util";
import { $Transformation } from "java:com/mojang/math";
import { $Enum, $Iterable, $Runnable, $Runnable_ } from "java:java/lang";
import { $DecimalFormat } from "java:java/text";
import { $Collection, $List, $Map, $Optional, $OptionalInt, $Set } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $BiPredicate, $BiPredicate_, $Consumer, $Consumer_, $IntFunction, $IntFunction_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $AdvancementHolder } from "java:net/minecraft/advancements";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $Holder$Reference, $HolderLookup$Provider, $HolderLookup$RegistryLookup, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentMap$Builder, $DataComponentType } from "java:net/minecraft/core/component";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $Connection, $FriendlyByteBuf, $PacketListener, $PacketSendListener, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_, $MutableComponent, $TextColor } from "java:net/minecraft/network/chat";
import { $StreamDecoder, $StreamDecoder_, $StreamEncoder, $StreamEncoder_ } from "java:net/minecraft/network/codec";
import { $Packet, $PacketFlow, $PacketFlow_ } from "java:net/minecraft/network/protocol";
import { $CustomPacketPayload, $CustomPacketPayload$Type, $CustomPacketPayload_ } from "java:net/minecraft/network/protocol/common/custom";
import { $ClientboundBlockEntityDataPacket } from "java:net/minecraft/network/protocol/game";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ServerChunkCache, $ServerLevel, $ServerPlayer, $ServerPlayer$RespawnPosAngle } from "java:net/minecraft/server/level";
import { $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $ReentrantBlockableEventLoop } from "java:net/minecraft/util/thread";
import { $InteractionHand, $InteractionHand_, $InteractionResult, $InteractionResult_, $MenuProvider } from "java:net/minecraft/world";
import { $DamageSource } from "java:net/minecraft/world/damagesource";
import { $MobEffectInstance } from "java:net/minecraft/world/effect";
import { $Entity, $EntityType, $EntityType_, $EquipmentSlot, $EquipmentSlot_, $LivingEntity, $Mob, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $AttributeModifier, $AttributeModifier$Operation, $AttributeModifier$Operation_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $EnderMan } from "java:net/minecraft/world/entity/monster";
import { $Inventory, $Player } from "java:net/minecraft/world/entity/player";
import { $Boat } from "java:net/minecraft/world/entity/vehicle";
import { $FoodProperties } from "java:net/minecraft/world/food";
import { $AbstractContainerMenu, $MenuType } from "java:net/minecraft/world/inventory";
import { $ArmorMaterial$Layer, $Item, $Item$Properties, $Item$TooltipContext, $ItemStack, $ItemStack_, $Item_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $ItemAttributeModifiers, $TooltipProvider, $TooltipProvider_ } from "java:net/minecraft/world/item/component";
import { $UseOnContext } from "java:net/minecraft/world/item/context";
import { $RecipeManager, $RecipeType } from "java:net/minecraft/world/item/crafting";
import { $Enchantment, $EnchantmentInstance, $ItemEnchantments } from "java:net/minecraft/world/item/enchantment";
import { $BlockAndTintGetter, $BlockGetter, $ChunkPos, $Explosion, $Level, $LevelAccessor, $LevelReader, $SignalGetter } from "java:net/minecraft/world/level";
import { $Rotation, $Rotation_, $SoundType } from "java:net/minecraft/world/level/block";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $TreeConfiguration } from "java:net/minecraft/world/level/levelgen/feature/configurations";
import { $FluidState, $MapColor, $PushReaction, $PushReaction_ } from "java:net/minecraft/world/level/material";
import { $PathType, $PathType_ } from "java:net/minecraft/world/level/pathfinder";
import { $AABB, $HitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $Scoreboard } from "java:net/minecraft/world/scores";
import { $LogicalSide, $LogicalSide_ } from "java:net/neoforged/fml";
import { $BlockCapability, $ItemCapability } from "java:net/neoforged/neoforge/capabilities";
import { $ModelData, $ModelDataManager } from "java:net/neoforged/neoforge/client/model/data";
import { $EffectCure, $ItemAbility, $SoundAction } from "java:net/neoforged/neoforge/common";
import { $DamageContainer } from "java:net/neoforged/neoforge/common/damagesource";
import { $BubbleColumnDirection, $BubbleColumnDirection_ } from "java:net/neoforged/neoforge/common/enums";
import { $INBTSerializable, $TriState, $TriState_ } from "java:net/neoforged/neoforge/common/util";
import { $AuxiliaryLightManager } from "java:net/neoforged/neoforge/common/world";
import { $PartEntity } from "java:net/neoforged/neoforge/entity";
import { $FluidType } from "java:net/neoforged/neoforge/fluids";
import { $IContainerFactory, $IContainerFactory_ } from "java:net/neoforged/neoforge/network";
import { $ConnectionType, $ConnectionType_ } from "java:net/neoforged/neoforge/network/connection";
import { $IWithData } from "java:net/neoforged/neoforge/registries/datamaps";
import { $TriConsumer, $TriConsumer_ } from "java:org/apache/commons/lang3/function";
import { $Vector3f, $Vector4f } from "java:org/joml";

declare module "java:net/neoforged/neoforge/common/extensions" {
    export interface $IAbstractMinecartExtension {
        canBeRidden(): boolean;
        canUseRail(): boolean;
        getComparatorLevel(): number;
        getCurrentCartSpeedCapOnRail(): number;
        getCurrentRailPosition(): $BlockPos;
        getDragAir(): number;
        getMaxCartSpeedOnRail(): number;
        getMaxSpeedAirLateral(): number;
        getMaxSpeedAirVertical(): number;
        getMaxSpeedWithRail(): number;
        getSlopeAdjustment(): number;
        isPoweredCart(): boolean;
        moveMinecartOnRail(arg0: $BlockPos_): void;
        setCanUseRail(arg0: boolean): void;
        setCurrentCartSpeedCapOnRail(arg0: number): void;
        setDragAir(arg0: number): void;
        setMaxSpeedAirLateral(arg0: number): void;
        setMaxSpeedAirVertical(arg0: number): void;
        shouldDoRailFunctions(): boolean;
    }
    export const $IAbstractMinecartExtension: {
        readonly DEFAULT_AIR_DRAG: number;
        readonly DEFAULT_MAX_SPEED_AIR_LATERAL: number;
        readonly DEFAULT_MAX_SPEED_AIR_VERTICAL: number;
    };

    export interface $IAttributeExtension {
        getBaseId(): $ResourceLocation;
        getDebugInfo(arg0: $AttributeModifier, arg1: $TooltipFlag): $Component;
        getMergedStyle(arg0: boolean): $TextColor;
        toBaseComponent(arg0: number, arg1: number, arg2: boolean, arg3: $TooltipFlag): $MutableComponent;
        toComponent(arg0: $AttributeModifier, arg1: $TooltipFlag): $MutableComponent;
        toValueComponent(arg0: $AttributeModifier$Operation_, arg1: number, arg2: $TooltipFlag): $MutableComponent;
    }
    export const $IAttributeExtension: {
        isNullOrAddition(arg0: $AttributeModifier$Operation_): boolean;
        readonly FORMAT: $DecimalFormat;
    };

    export interface $IBlockAndTintGetterExtension {
        getShade(arg0: number, arg1: number, arg2: number, arg3: boolean): number;
    }

    export interface $IBlockEntityExtension {
        getModelData(): $ModelData;
        getPersistentData(): $CompoundTag;
        handleUpdateTag(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): void;
        hasCustomOutlineRendering(arg0: $Player): boolean;
        invalidateCapabilities(): void;
        onChunkUnloaded(): void;
        onDataPacket(arg0: $Connection, arg1: $ClientboundBlockEntityDataPacket, arg2: $HolderLookup$Provider): void;
        onLoad(): void;
        requestModelDataUpdate(): void;
    }

    export interface $IBlockExtension {
        addLandingEffects(arg0: $BlockState_, arg1: $ServerLevel, arg2: $BlockPos_, arg3: $BlockState_, arg4: $LivingEntity, arg5: number): boolean;
        addRunningEffects(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Entity): boolean;
        canBeHydrated(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $FluidState, arg4: $BlockPos_): boolean;
        canConnectRedstone(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): boolean;
        canDropFromExplosion(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Explosion): boolean;
        canEntityDestroy(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Entity): boolean;
        canHarvestBlock(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Player): boolean;
        canStickTo(arg0: $BlockState_, arg1: $BlockState_): boolean;
        canSustainPlant(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_, arg4: $BlockState_): $TriState;
        collisionExtendsVertically(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Entity): boolean;
        getAdjacentBlockPathType(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob, arg4: $PathType_): $PathType;
        getAppearance(arg0: $BlockState_, arg1: $BlockAndTintGetter, arg2: $BlockPos_, arg3: $Direction_, arg4: $BlockState_, arg5: $BlockPos_): $BlockState;
        getBeaconColorMultiplier(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $BlockPos_): number;
        getBedDirection(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_): $Direction;
        getBlockPathType(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob): $PathType;
        getBubbleColumnDirection(arg0: $BlockState_): $BubbleColumnDirection;
        getCloneItemStack(arg0: $BlockState_, arg1: $HitResult, arg2: $LevelReader, arg3: $BlockPos_, arg4: $Player): $ItemStack;
        getEnchantPowerBonus(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_): number;
        getExpDrop(arg0: $BlockState_, arg1: $LevelAccessor, arg2: $BlockPos_, arg3: $BlockEntity, arg4: $Entity, arg5: $ItemStack_): number;
        getExplosionResistance(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Explosion): number;
        getFireSpreadSpeed(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): number;
        getFlammability(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): number;
        getFriction(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Entity): number;
        getLightEmission(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): number;
        getMapColor(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $MapColor): $MapColor;
        getPistonPushReaction(arg0: $BlockState_): $PushReaction;
        getRespawnPosition(arg0: $BlockState_, arg1: $EntityType_<any>, arg2: $LevelReader, arg3: $BlockPos_, arg4: number): $Optional<$ServerPlayer$RespawnPosAngle>;
        getSoundType(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Entity): $SoundType;
        getStateAtViewpoint(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Vec3_): $BlockState;
        getToolModifiedState(arg0: $BlockState_, arg1: $UseOnContext, arg2: $ItemAbility, arg3: boolean): $BlockState;
        getWeakChanges(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_): boolean;
        hasDynamicLightEmission(arg0: $BlockState_): boolean;
        hidesNeighborFace(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockState_, arg4: $Direction_): boolean;
        ignitedByLava(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): boolean;
        isBed(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $LivingEntity): boolean;
        isBurning(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        isConduitFrame(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $BlockPos_): boolean;
        isEmpty(arg0: $BlockState_): boolean;
        isFertile(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        isFireSource(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Direction_): boolean;
        isFlammable(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Direction_): boolean;
        isLadder(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $LivingEntity): boolean;
        isPortalFrame(arg0: $BlockState_, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        isScaffolding(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $LivingEntity): boolean;
        isSlimeBlock(arg0: $BlockState_): boolean;
        isStickyBlock(arg0: $BlockState_): boolean;
        makesOpenTrapdoorAboveClimbable(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $BlockState_): boolean;
        onBlockExploded(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Explosion): void;
        onBlockStateChange(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockState_): void;
        onCaughtFire(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Direction_, arg4: $LivingEntity): void;
        onDestroyedByPlayer(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Player, arg4: boolean, arg5: $FluidState): boolean;
        onDestroyedByPushReaction(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $Direction_, arg4: $FluidState): void;
        onNeighborChange(arg0: $BlockState_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $BlockPos_): void;
        onTreeGrow(arg0: $BlockState_, arg1: $LevelReader, arg2: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>, arg3: $RandomSource, arg4: $BlockPos_, arg5: $TreeConfiguration): boolean;
        rotate(arg0: $BlockState_, arg1: $LevelAccessor, arg2: $BlockPos_, arg3: $Rotation_): $BlockState;
        setBedOccupied(arg0: $BlockState_, arg1: $Level, arg2: $BlockPos_, arg3: $LivingEntity, arg4: boolean): void;
        shouldCheckWeakPower(arg0: $BlockState_, arg1: $SignalGetter, arg2: $BlockPos_, arg3: $Direction_): boolean;
        shouldDisplayFluidOverlay(arg0: $BlockState_, arg1: $BlockAndTintGetter, arg2: $BlockPos_, arg3: $FluidState): boolean;
        shouldHideAdjacentFluidFace(arg0: $BlockState_, arg1: $Direction_, arg2: $FluidState): boolean;
        supportsExternalFaceHiding(arg0: $BlockState_): boolean;
    }

    export interface $IBlockGetterExtension {
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getModelData(arg0: $BlockPos_): $ModelData;
    }

    export interface $IBlockStateExtension {
        addLandingEffects(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $BlockState_, arg3: $LivingEntity, arg4: number): boolean;
        addRunningEffects(arg0: $Level, arg1: $BlockPos_, arg2: $Entity): boolean;
        canBeHydrated(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $FluidState, arg3: $BlockPos_): boolean;
        canDropFromExplosion(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Explosion): boolean;
        canEntityDestroy(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Entity): boolean;
        canHarvestBlock(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Player): boolean;
        canRedstoneConnectTo(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): boolean;
        canStickTo(arg0: $BlockState_): boolean;
        canSustainPlant(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_, arg3: $BlockState_): $TriState;
        collisionExtendsVertically(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Entity): boolean;
        getAdjacentBlockPathType(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Mob, arg3: $PathType_): $PathType;
        getAppearance(arg0: $BlockAndTintGetter, arg1: $BlockPos_, arg2: $Direction_, arg3: $BlockState_, arg4: $BlockPos_): $BlockState;
        getBeaconColorMultiplier(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockPos_): number;
        getBedDirection(arg0: $LevelReader, arg1: $BlockPos_): $Direction;
        getBlockPathType(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Mob): $PathType;
        getBubbleColumnDirection(): $BubbleColumnDirection;
        getCloneItemStack(arg0: $HitResult, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Player): $ItemStack;
        getEnchantPowerBonus(arg0: $LevelReader, arg1: $BlockPos_): number;
        getExpDrop(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $BlockEntity, arg3: $Entity, arg4: $ItemStack_): number;
        getExplosionResistance(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Explosion): number;
        getFireSpreadSpeed(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): number;
        getFlammability(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): number;
        getFriction(arg0: $LevelReader, arg1: $BlockPos_, arg2: $Entity): number;
        getLightEmission(arg0: $BlockGetter, arg1: $BlockPos_): number;
        getRespawnPosition(arg0: $EntityType_<any>, arg1: $LevelReader, arg2: $BlockPos_, arg3: number): $Optional<$ServerPlayer$RespawnPosAngle>;
        getSoundType(arg0: $LevelReader, arg1: $BlockPos_, arg2: $Entity): $SoundType;
        getStateAtViewpoint(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Vec3_): $BlockState;
        getToolModifiedState(arg0: $UseOnContext, arg1: $ItemAbility, arg2: boolean): $BlockState;
        getWeakChanges(arg0: $LevelReader, arg1: $BlockPos_): boolean;
        hasDynamicLightEmission(): boolean;
        hidesNeighborFace(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $BlockState_, arg3: $Direction_): boolean;
        ignitedByLava(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): boolean;
        isBed(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $LivingEntity): boolean;
        isBurning(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        isConduitFrame(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockPos_): boolean;
        isEmpty(): boolean;
        isFertile(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        isFireSource(arg0: $LevelReader, arg1: $BlockPos_, arg2: $Direction_): boolean;
        isFlammable(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Direction_): boolean;
        isLadder(arg0: $LevelReader, arg1: $BlockPos_, arg2: $LivingEntity): boolean;
        isPortalFrame(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        isScaffolding(arg0: $LivingEntity): boolean;
        isSlimeBlock(): boolean;
        isStickyBlock(): boolean;
        onBlockExploded(arg0: $Level, arg1: $BlockPos_, arg2: $Explosion): void;
        onBlockStateChange(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockState_): void;
        onCaughtFire(arg0: $Level, arg1: $BlockPos_, arg2: $Direction_, arg3: $LivingEntity): void;
        onDestroyedByPlayer(arg0: $Level, arg1: $BlockPos_, arg2: $Player, arg3: boolean, arg4: $FluidState): boolean;
        onDestroyedByPushReaction(arg0: $Level, arg1: $BlockPos_, arg2: $Direction_, arg3: $FluidState): void;
        onNeighborChange(arg0: $LevelReader, arg1: $BlockPos_, arg2: $BlockPos_): void;
        onTreeGrow(arg0: $LevelReader, arg1: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>, arg2: $RandomSource, arg3: $BlockPos_, arg4: $TreeConfiguration): boolean;
        rotate(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $Rotation_): $BlockState;
        setBedOccupied(arg0: $Level, arg1: $BlockPos_, arg2: $LivingEntity, arg3: boolean): void;
        shouldCheckWeakPower(arg0: $SignalGetter, arg1: $BlockPos_, arg2: $Direction_): boolean;
        shouldDisplayFluidOverlay(arg0: $BlockAndTintGetter, arg1: $BlockPos_, arg2: $FluidState): boolean;
        shouldHideAdjacentFluidFace(arg0: $Direction_, arg1: $FluidState): boolean;
        supportsExternalFaceHiding(): boolean;
    }

    export interface $IBoatExtension {
        canBoatInFluid(arg0: $FluidState): boolean;
        canBoatInFluid(arg0: $FluidType): boolean;
    }

    export interface $ICommandSourceStackExtension {
        getAdvancement(arg0: $ResourceLocation_): $AdvancementHolder;
        getRecipeManager(): $RecipeManager;
        getScoreboard(): $Scoreboard;
        getUnsidedLevel(): $Level;
    }

    export interface $ICommonPacketListener extends $PacketListener {
        disconnect(arg0: $Component_): void;
        getConnectionType(): $ConnectionType;
        getConnection(): $Connection;
        getMainThreadEventLoop(): $ReentrantBlockableEventLoop<any>;
        hasChannel(arg0: $CustomPacketPayload$Type<any>): boolean;
        hasChannel(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): boolean;
        hasChannel(arg0: $ResourceLocation_): boolean;
        send(arg0: $Packet<any>): void;
        send(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): void;
    }

    export interface $IDataComponentHolderExtension {
        addToTooltip<T extends $TooltipProvider>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>, arg1: $Item$TooltipContext, arg2: $Consumer_<$Component, $Component>, arg3: $TooltipFlag): void;
        addToTooltip<T extends $TooltipProvider>(arg0: $DataComponentType<T>, arg1: $Item$TooltipContext, arg2: $Consumer_<$Component, $Component>, arg3: $TooltipFlag): void;
        getOrDefault<T>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>, arg1: T): T;
        get<T>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>): T;
        has(arg0: $Supplier_<$DataComponentType<any>, $DataComponentType<any>>): boolean;
    }

    export interface $IDataComponentMapBuilderExtensions {
        set<T>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>, arg1: T): $DataComponentMap$Builder;
    }

    export interface $IEntityExtension extends $INBTSerializable<$CompoundTag> {
        canBeRiddenUnderFluidType(arg0: $FluidType, arg1: $Entity): boolean;
        canFluidExtinguish(arg0: $FluidType): boolean;
        canHydrateInFluidType(arg0: $FluidType): boolean;
        canRiderInteract(): boolean;
        canStartSwimming(): boolean;
        canSwimInFluidType(arg0: $FluidType): boolean;
        canTrample(arg0: $BlockState_, arg1: $BlockPos_, arg2: number): boolean;
        captureDrops(arg0: $ItemEntity[]): $Collection<$ItemEntity>;
        captureDrops(): $Collection<$ItemEntity>;
        copyAttachmentsFrom(arg0: $Entity, arg1: boolean): void;
        deserializeNBT(arg0: $HolderLookup$Provider, arg1: $CompoundTag_): void;
        getClassification(arg0: boolean): $MobCategory;
        getEyeInFluidType(): $FluidType;
        getFluidFallDistanceModifier(arg0: $FluidType): number;
        getFluidMotionScale(arg0: $FluidType): number;
        getFluidTypeHeight(arg0: $FluidType): number;
        getMaxHeightFluidType(): $FluidType;
        getParts(): $PartEntity<any>[];
        getPersistentData(): $CompoundTag;
        getPickedResult(arg0: $HitResult): $ItemStack;
        getSoundFromFluidType(arg0: $FluidType, arg1: $SoundAction): $SoundEvent;
        hasCustomOutlineRendering(arg0: $Player): boolean;
        isAddedToLevel(): boolean;
        isEyeInFluidType(arg0: $FluidType): boolean;
        isInFluidType(arg0: $BiPredicate_<$FluidType, number, $FluidType, number, boolean>, arg1: boolean): boolean;
        isInFluidType(arg0: $BiPredicate_<$FluidType, number, $FluidType, number, boolean>): boolean;
        isInFluidType(arg0: $FluidState): boolean;
        isInFluidType(arg0: $FluidType): boolean;
        isInFluidType(): boolean;
        isMultipartEntity(): boolean;
        isPushedByFluid(arg0: $FluidType): boolean;
        onAddedToLevel(): void;
        onRemovedFromLevel(): void;
        revive(): void;
        sendPairingData(arg0: $ServerPlayer, arg1: $Consumer_<$CustomPacketPayload, $CustomPacketPayload>): void;
        serializeNBT(arg0: $HolderLookup$Provider): $CompoundTag;
        shouldRiderSit(): boolean;
    }

    export interface $IFluidExtension {
        canConvertToSource(arg0: $FluidState, arg1: $Level, arg2: $BlockPos_): boolean;
        canExtinguish(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_): boolean;
        canHydrate(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $BlockState_, arg4: $BlockPos_): boolean;
        getAdjacentBlockPathType(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob, arg4: $PathType_): $PathType;
        getBlockPathType(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Mob, arg4: boolean): $PathType;
        getExplosionResistance(arg0: $FluidState, arg1: $BlockGetter, arg2: $BlockPos_, arg3: $Explosion): number;
        getFluidType(): $FluidType;
        move(arg0: $FluidState, arg1: $LivingEntity, arg2: $Vec3_, arg3: number): boolean;
        supportsBoating(arg0: $FluidState, arg1: $Boat): boolean;
    }

    export interface $IFluidStateExtension {
        canConvertToSource(arg0: $Level, arg1: $BlockPos_): boolean;
        canExtinguish(arg0: $BlockGetter, arg1: $BlockPos_): boolean;
        canHydrate(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockPos_): boolean;
        getAdjacentBlockPathType(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Mob, arg3: $PathType_): $PathType;
        getBlockPathType(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Mob, arg3: boolean): $PathType;
        getExplosionResistance(arg0: $BlockGetter, arg1: $BlockPos_, arg2: $Explosion): number;
        getFluidType(): $FluidType;
        move(arg0: $LivingEntity, arg1: $Vec3_, arg2: number): boolean;
        supportsBoating(arg0: $Boat): boolean;
    }

    export interface $IFriendlyByteBufExtension {
        readArray<T>(arg0: $IntFunction_<T[], number, T[]>, arg1: $StreamDecoder_<$FriendlyByteBuf, T, $FriendlyByteBuf, T>): T[];
        readMap<K, V>(arg0: $StreamDecoder_<$FriendlyByteBuf, K, $FriendlyByteBuf, K>, arg1: $BiFunction_<$FriendlyByteBuf, K, V, $FriendlyByteBuf, K, V>): $Map<K, V>;
        writeArray<T>(arg0: T[], arg1: $StreamEncoder_<$FriendlyByteBuf, T, $FriendlyByteBuf, T>): $FriendlyByteBuf;
        writeByte(arg0: number): $FriendlyByteBuf;
        writeMap<K, V>(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg1: $StreamEncoder_<$FriendlyByteBuf, K, $FriendlyByteBuf, K>, arg2: $TriConsumer_<$FriendlyByteBuf, K, V, $FriendlyByteBuf, K, V>): void;
        writeObjectCollection<T>(arg0: T[], arg1: $BiConsumer_<T, $FriendlyByteBuf, T, $FriendlyByteBuf>): void;
    }

    export interface $IHolderExtension<T> extends $IWithData<T> {
        getDelegate(): $Holder<T>;
        getKey(): $ResourceKey<T>;
        unwrapLookup(): $HolderLookup$RegistryLookup<T>;
    }

    export interface $IHolderLookupProviderExtension {
        holderOrThrow<T>(arg0: $ResourceKey<T>): $Holder<T>;
        holder<T>(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
    }

    export interface $IHolderSetExtension<T> {
        addInvalidationListener(arg0: $Runnable_): void;
        serializationType(): $IHolderSetExtension$SerializationType;
    }

    export class $IHolderSetExtension$SerializationType {
        static LIST: $IHolderSetExtension$SerializationType;
        static OBJECT: $IHolderSetExtension$SerializationType;
        static STRING: $IHolderSetExtension$SerializationType;
        static UNKNOWN: $IHolderSetExtension$SerializationType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $IHolderSetExtension$SerializationType[];
        static valueOf(name: string): $IHolderSetExtension$SerializationType;
    }
    export interface $IHolderSetExtension$SerializationType extends $Enum<$IHolderSetExtension$SerializationType> {}

    export interface $IItemExtension {
        applyEnchantments(arg0: $ItemStack_, arg1: $EnchantmentInstance[]): $ItemStack;
        canBeHurtBy(arg0: $ItemStack_, arg1: $DamageSource): boolean;
        canContinueUsing(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        canDisableShield(arg0: $ItemStack_, arg1: $ItemStack_, arg2: $LivingEntity, arg3: $LivingEntity): boolean;
        canElytraFly(arg0: $ItemStack_, arg1: $LivingEntity): boolean;
        canEquip(arg0: $ItemStack_, arg1: $EquipmentSlot_, arg2: $LivingEntity): boolean;
        canFitInsideContainerItems(arg0: $ItemStack_): boolean;
        canGrindstoneRepair(arg0: $ItemStack_): boolean;
        canPerformAction(arg0: $ItemStack_, arg1: $ItemAbility): boolean;
        canWalkOnPowderedSnow(arg0: $ItemStack_, arg1: $LivingEntity): boolean;
        createEntity(arg0: $Level, arg1: $Entity, arg2: $ItemStack_): $Entity;
        damageItem<T extends $LivingEntity>(arg0: $ItemStack_, arg1: number, arg2: T, arg3: $Consumer_<$Item, $Item>): number;
        doesSneakBypassUse(arg0: $ItemStack_, arg1: $LevelReader, arg2: $BlockPos_, arg3: $Player): boolean;
        elytraFlightTick(arg0: $ItemStack_, arg1: $LivingEntity, arg2: number): boolean;
        getAllEnchantments(arg0: $ItemStack_, arg1: $HolderLookup$RegistryLookup<$Enchantment>): $ItemEnchantments;
        getArmorTexture(arg0: $ItemStack_, arg1: $Entity, arg2: $EquipmentSlot_, arg3: $ArmorMaterial$Layer, arg4: boolean): $ResourceLocation;
        getBurnTime(arg0: $ItemStack_, arg1: $RecipeType<any>): number;
        getCraftingRemainingItem(arg0: $ItemStack_): $ItemStack;
        getCreatorModId(arg0: $ItemStack_): string;
        getDamage(arg0: $ItemStack_): number;
        getDefaultAttributeModifiers(arg0: $ItemStack_): $ItemAttributeModifiers;
        getEnchantmentLevel(arg0: $ItemStack_, arg1: $Holder_<$Enchantment>): number;
        getEnchantmentValue(arg0: $ItemStack_): number;
        getEntityLifespan(arg0: $ItemStack_, arg1: $Level): number;
        getEquipmentSlot(arg0: $ItemStack_): $EquipmentSlot;
        getFoodProperties(arg0: $ItemStack_, arg1: $LivingEntity): $FoodProperties;
        getHighlightTip(arg0: $ItemStack_, arg1: $Component_): $Component;
        getMaxDamage(arg0: $ItemStack_): number;
        getMaxStackSize(arg0: $ItemStack_): number;
        getSweepHitBox(arg0: $ItemStack_, arg1: $Player, arg2: $Entity): $AABB;
        getXpRepairRatio(arg0: $ItemStack_): number;
        hasCraftingRemainingItem(arg0: $ItemStack_): boolean;
        hasCustomEntity(arg0: $ItemStack_): boolean;
        isBookEnchantable(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        isDamageable(arg0: $ItemStack_): boolean;
        isDamaged(arg0: $ItemStack_): boolean;
        isEnderMask(arg0: $ItemStack_, arg1: $Player, arg2: $EnderMan): boolean;
        isNotReplaceableByPickAction(arg0: $ItemStack_, arg1: $Player, arg2: number): boolean;
        isPiglinCurrency(arg0: $ItemStack_): boolean;
        isPrimaryItemFor(arg0: $ItemStack_, arg1: $Holder_<$Enchantment>): boolean;
        isRepairable(arg0: $ItemStack_): boolean;
        makesPiglinsNeutral(arg0: $ItemStack_, arg1: $LivingEntity): boolean;
        onAnimalArmorTick(arg0: $ItemStack_, arg1: $Level, arg2: $Mob): void;
        onDestroyed(arg0: $ItemEntity, arg1: $DamageSource): void;
        onDroppedByPlayer(arg0: $ItemStack_, arg1: $Player): boolean;
        onEntityItemUpdate(arg0: $ItemStack_, arg1: $ItemEntity): boolean;
        onEntitySwing(arg0: $ItemStack_, arg1: $LivingEntity, arg2: $InteractionHand_): boolean;
        onEntitySwing(arg0: $ItemStack_, arg1: $LivingEntity): boolean;
        onItemUseFirst(arg0: $ItemStack_, arg1: $UseOnContext): $InteractionResult;
        onLeftClickEntity(arg0: $ItemStack_, arg1: $Player, arg2: $Entity): boolean;
        onStopUsing(arg0: $ItemStack_, arg1: $LivingEntity, arg2: number): void;
        setDamage(arg0: $ItemStack_, arg1: number): void;
        shouldCauseBlockBreakReset(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        shouldCauseReequipAnimation(arg0: $ItemStack_, arg1: $ItemStack_, arg2: boolean): boolean;
        supportsEnchantment(arg0: $ItemStack_, arg1: $Holder_<$Enchantment>): boolean;
    }

    export interface $IItemPropertiesExtensions {
        component<T>(arg0: $Supplier_<$DataComponentType<T>, $DataComponentType<T>>, arg1: T): $Item$Properties;
    }

    export interface $IItemStackExtension {
        canDisableShield(arg0: $ItemStack_, arg1: $LivingEntity, arg2: $LivingEntity): boolean;
        canElytraFly(arg0: $LivingEntity): boolean;
        canEquip(arg0: $EquipmentSlot_, arg1: $LivingEntity): boolean;
        canFitInsideContainerItems(): boolean;
        canGrindstoneRepair(): boolean;
        canPerformAction(arg0: $ItemAbility): boolean;
        canWalkOnPowderedSnow(arg0: $LivingEntity): boolean;
        doesSneakBypassUse(arg0: $LevelReader, arg1: $BlockPos_, arg2: $Player): boolean;
        elytraFlightTick(arg0: $LivingEntity, arg1: number): boolean;
        getAllEnchantments(arg0: $HolderLookup$RegistryLookup<$Enchantment>): $ItemEnchantments;
        getAttributeModifiers(): $ItemAttributeModifiers;
        getBurnTime(arg0: $RecipeType<any>): number;
        getCapability<T, C>(arg0: $ItemCapability<T, C>, arg1: C): T;
        getCapability<T>(arg0: $ItemCapability<T, void>): T;
        getCraftingRemainingItem(): $ItemStack;
        getEnchantmentLevel(arg0: $Holder_<$Enchantment>): number;
        getEnchantmentValue(): number;
        getEntityLifespan(arg0: $Level): number;
        getEquipmentSlot(): $EquipmentSlot;
        getFoodProperties(arg0: $LivingEntity): $FoodProperties;
        getHighlightTip(arg0: $Component_): $Component;
        getSweepHitBox(arg0: $Player, arg1: $Entity): $AABB;
        getXpRepairRatio(): number;
        hasCraftingRemainingItem(): boolean;
        isBookEnchantable(arg0: $ItemStack_): boolean;
        isEnderMask(arg0: $Player, arg1: $EnderMan): boolean;
        isNotReplaceableByPickAction(arg0: $Player, arg1: number): boolean;
        isPiglinCurrency(): boolean;
        isPrimaryItemFor(arg0: $Holder_<$Enchantment>): boolean;
        isRepairable(): boolean;
        makesPiglinsNeutral(arg0: $LivingEntity): boolean;
        onAnimalArmorTick(arg0: $Level, arg1: $Mob): void;
        onDestroyed(arg0: $ItemEntity, arg1: $DamageSource): void;
        onDroppedByPlayer(arg0: $Player): boolean;
        onEntityItemUpdate(arg0: $ItemEntity): boolean;
        onEntitySwing(arg0: $LivingEntity, arg1: $InteractionHand_): boolean;
        onEntitySwing(arg0: $LivingEntity): boolean;
        onItemUseFirst(arg0: $UseOnContext): $InteractionResult;
        onStopUsing(arg0: $LivingEntity, arg1: number): void;
        shouldCauseBlockBreakReset(arg0: $ItemStack_): boolean;
        supportsEnchantment(arg0: $Holder_<$Enchantment>): boolean;
    }

    export interface $ILevelExtension {
        getCapability<T, C>(arg0: $BlockCapability<T, C>, arg1: $BlockPos_, arg2: C): T;
        getCapability<T, C>(arg0: $BlockCapability<T, C>, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity, arg4: C): T;
        getCapability<T>(arg0: $BlockCapability<T, void>, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity): T;
        getCapability<T>(arg0: $BlockCapability<T, void>, arg1: $BlockPos_): T;
        getDescriptionKey(): string;
        getDescription(): $Component;
        getMaxEntityRadius(): number;
        getModelDataManager(): $ModelDataManager;
        getPartEntities(): $Collection<$PartEntity<any>>;
        increaseMaxEntityRadius(arg0: number): number;
        invalidateCapabilities(arg0: $BlockPos_): void;
        invalidateCapabilities(arg0: $ChunkPos): void;
    }
    export const $ILevelExtension: {
        readonly TRANSLATION_PREFIX: string;
    };

    export interface $ILevelReaderExtension {
        holderOrThrow<T>(arg0: $ResourceKey<T>): $Holder<T>;
        holder<T>(arg0: $ResourceKey<T>): $Optional<$Holder$Reference<T>>;
        isAreaLoaded(arg0: $BlockPos_, arg1: number): boolean;
    }

    export interface $ILivingEntityExtension extends $IEntityExtension {
        canDrownInFluidType(arg0: $FluidType): boolean;
        canSwimInFluidType(arg0: $FluidType): boolean;
        jumpInFluid(arg0: $FluidType): void;
        moveInFluid(arg0: $FluidState, arg1: $Vec3_, arg2: number): boolean;
        onDamageTaken(arg0: $DamageContainer): void;
        self(): $LivingEntity;
        sinkInFluid(arg0: $FluidType): void;
    }

    export interface $IMenuTypeExtension<T> {
        create(arg0: number, arg1: $Inventory, arg2: $RegistryFriendlyByteBuf): T;
    }
    export const $IMenuTypeExtension: {
        create<T extends $AbstractContainerMenu>(arg0: $IContainerFactory_<T, number, $Inventory, $RegistryFriendlyByteBuf, T>): $MenuType<T>;
    };

    export interface $IMobEffectExtension {
        fillEffectCures(arg0: $EffectCure[], arg1: $MobEffectInstance): void;
        getSortOrder(arg0: $MobEffectInstance): number;
    }

    export interface $IOwnedSpawner {
        getOwner(): $Either<$BlockEntity, $Entity>;
    }

    export interface $IPackResourcesExtension {
        isHidden(): boolean;
    }

    export interface $IPacketFlowExtension {
        getReceptionSide(): $LogicalSide;
        isClientbound(): boolean;
        isServerbound(): boolean;
        self(): $PacketFlow;
    }

    export interface $IPlayerExtension {
        isCloseEnough(arg0: $Entity, arg1: number): boolean;
        isFakePlayer(): boolean;
        mayFly(): boolean;
        openMenu(arg0: $MenuProvider, arg1: $Consumer_<$RegistryFriendlyByteBuf, $RegistryFriendlyByteBuf>): $OptionalInt;
        openMenu(arg0: $MenuProvider, arg1: $BlockPos_): $OptionalInt;
    }

    export interface $IServerChunkCacheExtension {
        broadcastAndSend(arg0: $Entity, arg1: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): void;
        broadcast(arg0: $Entity, arg1: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): void;
        self(): $ServerChunkCache;
    }

    export interface $IServerCommonPacketListenerExtension extends $ICommonPacketListener {
        send(arg0: $Packet<any>, arg1: $PacketSendListener): void;
        send(arg0: $Packet<any>): void;
        send(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>, arg1: $PacketSendListener): void;
        send(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): void;
    }

    export interface $IServerGamePacketListenerExtension extends $IServerCommonPacketListenerExtension {
        sendBundled(arg0: $Iterable<$CustomPacketPayload>): void;
        sendBundled(arg0?: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>[]): void;
    }

    export interface $ITransformationExtension {
        applyOrigin(arg0: $Vector3f): $Transformation;
        blockCenterToCorner(): $Transformation;
        blockCornerToCenter(): $Transformation;
        isIdentity(): boolean;
        rotateTransform(arg0: $Direction_): $Direction;
        transformNormal(arg0: $Vector3f): void;
        transformPosition(arg0: $Vector4f): void;
    }

    export type $IAttributeExtension_<CallbackArg0 = boolean, CallbackResult = $TextColor> = ((arg0: CallbackArg0) => CallbackResult) | ($IAttributeExtension & { readonly [Symbol.hasInstance]?: never });
    export type $IBlockEntityExtension_<CallbackResult = $CompoundTag_> = (() => CallbackResult) | ($IBlockEntityExtension & { readonly [Symbol.hasInstance]?: never });
    export type $IFluidExtension_<CallbackResult = $FluidType> = (() => CallbackResult) | ($IFluidExtension & { readonly [Symbol.hasInstance]?: never });
    export type $IHolderSetExtension$SerializationType_ = $IHolderSetExtension$SerializationType | "LIST" | "OBJECT" | "STRING" | "UNKNOWN";
    export type $IItemExtension_<CallbackArg0 = $ItemStack, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($IItemExtension & { readonly [Symbol.hasInstance]?: never });
    export type $IMenuTypeExtension_<Host0 = any, CallbackArg0 = number, CallbackArg1 = $Inventory, CallbackArg2 = $RegistryFriendlyByteBuf, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($IMenuTypeExtension<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $IOwnedSpawner_<CallbackResult = $Either<$BlockEntity, $Entity>> = (() => CallbackResult) | ($IOwnedSpawner & { readonly [Symbol.hasInstance]?: never });
}
