import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $Tag } from "java:net/minecraft/nbt";
import { $INBTSerializable } from "java:net/neoforged/neoforge/common/util";

declare module "java:net/neoforged/neoforge/energy" {
    export class $EnergyStorage implements $IEnergyStorage, $INBTSerializable<$Tag> {
        constructor(arg0: number);
        constructor(arg0: number, arg1: number);
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        get energyStored(): number;
        getEnergyStored(): number;
        get maxEnergyStored(): number;
        getMaxEnergyStored(): number;
        canExtract(): boolean;
        canReceive(): boolean;
        deserializeNBT(arg0: $HolderLookup$Provider, arg1: $Tag): void;
        extractEnergy(arg0: number, arg1: boolean): number;
        receiveEnergy(arg0: number, arg1: boolean): number;
        serializeNBT(arg0: $HolderLookup$Provider): $Tag;
    }

    export interface $IEnergyStorage {
        canExtract(): boolean;
        canReceive(): boolean;
        extractEnergy(arg0: number, arg1: boolean): number;
        getEnergyStored(): number;
        getMaxEnergyStored(): number;
        receiveEnergy(arg0: number, arg1: boolean): number;
    }

}
