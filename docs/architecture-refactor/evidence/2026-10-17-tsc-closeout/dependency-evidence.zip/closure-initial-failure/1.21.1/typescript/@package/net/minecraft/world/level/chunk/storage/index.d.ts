import { $DataFixer } from "java:com/mojang/datafixers";
import { $Codec, $Dynamic, $MapCodec } from "java:com/mojang/serialization";
import { $AutoCloseable, $AutoCloseable_, $Record, $Runnable, $Runnable_, $Throwable } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Optional } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Function, $Function_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $ReportedException } from "java:net/minecraft";
import { $RegistryAccess } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $StreamTagVisitor, $Tag } from "java:net/minecraft/nbt";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $DataFixTypes, $DataFixTypes_ } from "java:net/minecraft/util/datafix";
import { $ChunkPos, $Level, $LevelHeightAccessor } from "java:net/minecraft/world/level";
import { $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $DimensionDataStorage } from "java:net/minecraft/world/level/storage";

declare module "java:net/minecraft/world/level/chunk/storage" {
    export interface $ChunkIOErrorReporter {
        reportChunkLoadFailure(arg0: $Throwable, arg1: $RegionStorageInfo, arg2: $ChunkPos): void;
        reportChunkSaveFailure(arg0: $Throwable, arg1: $RegionStorageInfo, arg2: $ChunkPos): void;
        reportMisplacedChunk(arg0: $ChunkPos, arg1: $ChunkPos, arg2: $RegionStorageInfo): void;
    }
    export const $ChunkIOErrorReporter: {
        createMisplacedChunkReport(arg0: $ChunkPos, arg1: $ChunkPos): $ReportedException;
    };

    export interface $ChunkScanAccess {
        scanChunk(arg0: $ChunkPos, arg1: $StreamTagVisitor): $CompletableFuture<void>;
    }

    export class $ChunkStorage implements $AutoCloseable {
        constructor(arg0: $RegionStorageInfo, arg1: $Path, arg2: $DataFixer, arg3: boolean);
        static LAST_MONOLYTH_STRUCTURE_DATA_VERSION: number;
        static getVersion(arg0: $CompoundTag_): number;
        static injectDatafixingContext(arg0: $CompoundTag_, arg1: $ResourceKey<$Level>, arg2: $Optional<$ResourceKey<$MapCodec<$ChunkGenerator>>>): void;
        chunkScanner(): $ChunkScanAccess;
        close(): void;
        flushWorker(): void;
        isOldChunkAround(arg0: $ChunkPos, arg1: number): boolean;
        read(arg0: $ChunkPos): $CompletableFuture<$Optional<$CompoundTag>>;
        upgradeChunkTag(arg0: $ResourceKey<$Level>, arg1: $Supplier_<$DimensionDataStorage, $DimensionDataStorage>, arg2: $CompoundTag_, arg3: $Optional<$ResourceKey<$MapCodec<$ChunkGenerator>>>): $CompoundTag;
        write(arg0: $ChunkPos, arg1: $CompoundTag_): $CompletableFuture<void>;
    }

    export class $RegionStorageInfo extends $Record {
        constructor(arg0: string, arg1: $ResourceKey<$Level>, arg2: string);
        dimension(): $ResourceKey<$Level>;
        equals(arg0: object): boolean;
        hashCode(): number;
        level(): string;
        toString(): string;
        type(): string;
        withTypeSuffix(arg0: string): $RegionStorageInfo;
    }

    export class $SectionStorage<R> implements $AutoCloseable {
        constructor(arg0: $SimpleRegionStorage, arg1: $Function_<$Runnable, $Codec<R>, $Runnable, $Codec<R>>, arg2: $Function_<$Runnable, R, $Runnable, R>, arg3: $RegistryAccess, arg4: $ChunkIOErrorReporter, arg5: $LevelHeightAccessor);
        close(): void;
        flush(arg0: $ChunkPos): void;
        hasWork(): boolean;
        remove(arg0: number): void;
    }

    export class $SimpleRegionStorage implements $AutoCloseable {
        constructor(arg0: $RegionStorageInfo, arg1: $Path, arg2: $DataFixer, arg3: boolean, arg4: $DataFixTypes_);
        close(): void;
        read(arg0: $ChunkPos): $CompletableFuture<$Optional<$CompoundTag>>;
        storageInfo(): $RegionStorageInfo;
        synchronize(arg0: boolean): $CompletableFuture<void>;
        upgradeChunkTag(arg0: $Dynamic<$Tag>, arg1: number): $Dynamic<$Tag>;
        upgradeChunkTag(arg0: $CompoundTag_, arg1: number): $CompoundTag;
        write(arg0: $ChunkPos, arg1: $CompoundTag_): $CompletableFuture<void>;
    }

    export type $ChunkScanAccess_<CallbackArg0 = $ChunkPos, CallbackArg1 = $StreamTagVisitor, CallbackResult = $CompletableFuture<void>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($ChunkScanAccess & { readonly [Symbol.hasInstance]?: never });
}
