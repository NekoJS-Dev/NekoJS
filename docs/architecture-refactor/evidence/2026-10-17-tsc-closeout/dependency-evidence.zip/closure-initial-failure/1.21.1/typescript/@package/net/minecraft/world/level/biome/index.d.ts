import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Iterable, $Record } from "java:java/lang";
import { $List, $Map, $Optional, $Set } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $ParticleOptions, $ParticleOptions_, $ParticleType, $ParticleType_ } from "java:net/minecraft/core/particles";
import { $Music, $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $RandomSource } from "java:net/minecraft/util";
import { $Weight, $WeightedEntry$IntrusiveBase, $WeightedRandomList } from "java:net/minecraft/util/random";
import { $EntityType, $EntityType_, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $LevelReader } from "java:net/minecraft/world/level";
import { $DensityFunction, $GenerationStep$Carving, $GenerationStep$Carving_, $GenerationStep$Decoration, $GenerationStep$Decoration_ } from "java:net/minecraft/world/level/levelgen";
import { $ConfiguredWorldCarver } from "java:net/minecraft/world/level/levelgen/carver";
import { $ConfiguredFeature } from "java:net/minecraft/world/level/levelgen/feature";
import { $PlacedFeature } from "java:net/minecraft/world/level/levelgen/placement";
import { $PerlinSimplexNoise } from "java:net/minecraft/world/level/levelgen/synth";
import { $ModifiableBiomeInfo } from "java:net/neoforged/neoforge/common/world";

declare module "java:net/minecraft/world/level/biome" {
    export class $AmbientAdditionsSettings {
        constructor(arg0: $Holder_<$SoundEvent>, arg1: number);
        static CODEC: $Codec<$AmbientAdditionsSettings>;
        get soundEvent(): $Holder<$SoundEvent>;
        getSoundEvent(): $Holder<$SoundEvent>;
        get tickChance(): number;
        getTickChance(): number;
    }

    export class $AmbientMoodSettings {
        constructor(arg0: $Holder_<$SoundEvent>, arg1: number, arg2: number, arg3: number);
        static CODEC: $Codec<$AmbientMoodSettings>;
        static LEGACY_CAVE_SETTINGS: $AmbientMoodSettings;
        get blockSearchExtent(): number;
        getBlockSearchExtent(): number;
        get soundEvent(): $Holder<$SoundEvent>;
        getSoundEvent(): $Holder<$SoundEvent>;
        get soundPositionOffset(): number;
        getSoundPositionOffset(): number;
        get tickDelay(): number;
        getTickDelay(): number;
    }

    export class $AmbientParticleSettings {
        constructor(arg0: $ParticleOptions_<$ParticleType_<any>>, arg1: number);
        static CODEC: $Codec<$AmbientParticleSettings>;
        get options(): $ParticleOptions;
        getOptions(): $ParticleOptions;
        canSpawn(arg0: $RandomSource): boolean;
    }

    export class $Biome {
        static BIOME_INFO_NOISE: $PerlinSimplexNoise;
        static CODEC: $Codec<$Holder<$Biome>>;
        static DIRECT_CODEC: $Codec<$Biome>;
        static LIST_CODEC: $Codec<$HolderSet<$Biome>>;
        static NETWORK_CODEC: $Codec<$Biome>;
        get ambientAdditions(): $Optional<$AmbientAdditionsSettings>;
        getAmbientAdditions(): $Optional<$AmbientAdditionsSettings>;
        get ambientLoop(): $Optional<$Holder<$SoundEvent>>;
        getAmbientLoop(): $Optional<$Holder<$SoundEvent>>;
        get ambientMood(): $Optional<$AmbientMoodSettings>;
        getAmbientMood(): $Optional<$AmbientMoodSettings>;
        get ambientParticle(): $Optional<$AmbientParticleSettings>;
        getAmbientParticle(): $Optional<$AmbientParticleSettings>;
        get backgroundMusic(): $Optional<$Music>;
        getBackgroundMusic(): $Optional<$Music>;
        get baseTemperature(): number;
        getBaseTemperature(): number;
        get fogColor(): number;
        getFogColor(): number;
        get foliageColor(): number;
        getFoliageColor(): number;
        get generationSettings(): $BiomeGenerationSettings;
        getGenerationSettings(): $BiomeGenerationSettings;
        get mobSettings(): $MobSpawnSettings;
        getMobSettings(): $MobSpawnSettings;
        get modifiedClimateSettings(): $Biome$ClimateSettings;
        getModifiedClimateSettings(): $Biome$ClimateSettings;
        get modifiedSpecialEffects(): $BiomeSpecialEffects;
        getModifiedSpecialEffects(): $BiomeSpecialEffects;
        get skyColor(): number;
        getSkyColor(): number;
        get specialEffects(): $BiomeSpecialEffects;
        getSpecialEffects(): $BiomeSpecialEffects;
        get waterColor(): number;
        getWaterColor(): number;
        get waterFogColor(): number;
        getWaterFogColor(): number;
        coldEnoughToSnow(arg0: $BlockPos_): boolean;
        getGrassColor(arg0: number, arg1: number): number;
        getPrecipitationAt(arg0: $BlockPos_): $Biome$Precipitation;
        hasPrecipitation(): boolean;
        modifiableBiomeInfo(): $ModifiableBiomeInfo;
        shouldFreeze(arg0: $LevelReader, arg1: $BlockPos_, arg2: boolean): boolean;
        shouldFreeze(arg0: $LevelReader, arg1: $BlockPos_): boolean;
        shouldMeltFrozenOceanIcebergSlightly(arg0: $BlockPos_): boolean;
        shouldSnow(arg0: $LevelReader, arg1: $BlockPos_): boolean;
        warmEnoughToRain(arg0: $BlockPos_): boolean;
    }

    export class $Biome$ClimateSettings extends $Record {
        constructor(hasPrecipitation: boolean, temperature: number, temperatureModifier: $Biome$TemperatureModifier_, downfall: number);
        static CODEC: $MapCodec<$Biome$ClimateSettings>;
        downfall(): number;
        equals(arg0: object): boolean;
        hasPrecipitation(): boolean;
        hashCode(): number;
        temperatureModifier(): $Biome$TemperatureModifier;
        temperature(): number;
        toString(): string;
    }

    export class $Biome$Precipitation {
        static NONE: $Biome$Precipitation;
        static RAIN: $Biome$Precipitation;
        static SNOW: $Biome$Precipitation;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Biome$Precipitation[];
        static valueOf(name: string): $Biome$Precipitation;
    }
    export interface $Biome$Precipitation extends $Enum<$Biome$Precipitation> {}

    export class $Biome$TemperatureModifier {
        static FROZEN: $Biome$TemperatureModifier;
        static NONE: $Biome$TemperatureModifier;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Biome$TemperatureModifier[];
        static valueOf(name: string): $Biome$TemperatureModifier;
    }
    export interface $Biome$TemperatureModifier extends $Enum<$Biome$TemperatureModifier> {}

    export class $BiomeGenerationSettings {
        constructor(arg0: ($Map<$GenerationStep$Carving_, $HolderSet<$ConfiguredWorldCarver<any>>> | ([$GenerationStep$Carving_] extends [PropertyKey] ? Partial<Record<Extract<$GenerationStep$Carving_, PropertyKey>, $HolderSet<$ConfiguredWorldCarver<any>>>> : never)), arg1: $HolderSet<$PlacedFeature>[]);
        static CODEC: $MapCodec<$BiomeGenerationSettings>;
        static EMPTY: $BiomeGenerationSettings;
        get carvingStages(): $Set<$GenerationStep$Carving>;
        getCarvingStages(): $Set<$GenerationStep$Carving>;
        get flowerFeatures(): $List<$ConfiguredFeature<any, any>>;
        getFlowerFeatures(): $List<$ConfiguredFeature<any, any>>;
        features(): $List<$HolderSet<$PlacedFeature>>;
        getCarvers(arg0: $GenerationStep$Carving_): $Iterable<$Holder<$ConfiguredWorldCarver<any>>>;
        hasFeature(arg0: $PlacedFeature): boolean;
    }

    export class $BiomeManager {
        constructor(arg0: $BiomeManager$NoiseBiomeSource_<number, number, number, $Holder_<$Biome>>, arg1: number);
        static CHUNK_CENTER_QUART: number;
        static obfuscateSeed(arg0: number): number;
        getBiome(arg0: $BlockPos_): $Holder<$Biome>;
        getNoiseBiomeAtPosition(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getNoiseBiomeAtPosition(arg0: $BlockPos_): $Holder<$Biome>;
        getNoiseBiomeAtQuart(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        withDifferentSource(arg0: $BiomeManager$NoiseBiomeSource_<number, number, number, $Holder_<$Biome>>): $BiomeManager;
    }

    export interface $BiomeManager$NoiseBiomeSource {
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
    }

    export interface $BiomeResolver {
        getNoiseBiome(arg0: number, arg1: number, arg2: number, arg3: $Climate$Sampler): $Holder<$Biome>;
    }

    export class $BiomeSource implements $BiomeResolver {
        static CODEC: $Codec<$BiomeSource>;
        addDebugInfo(arg0: string[], arg1: $BlockPos_, arg2: $Climate$Sampler): void;
        findBiomeHorizontal(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>, arg6: $RandomSource, arg7: boolean, arg8: $Climate$Sampler): $Pair<$BlockPos, $Holder<$Biome>>;
        findBiomeHorizontal(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>, arg5: $RandomSource, arg6: $Climate$Sampler): $Pair<$BlockPos, $Holder<$Biome>>;
        findClosestBiome3d(arg0: $BlockPos_, arg1: number, arg2: number, arg3: number, arg4: $Predicate_<$Holder<$Biome>, $Holder<$Biome>, boolean>, arg5: $Climate$Sampler, arg6: $LevelReader): $Pair<$BlockPos, $Holder<$Biome>>;
        getBiomesWithin(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $Climate$Sampler): $Set<$Holder<$Biome>>;
        getNoiseBiome(arg0: number, arg1: number, arg2: number, arg3: $Climate$Sampler): $Holder<$Biome>;
        possibleBiomes(): $Set<$Holder<$Biome>>;
    }

    export class $BiomeSpecialEffects {
        static CODEC: $Codec<$BiomeSpecialEffects>;
        get ambientAdditionsSettings(): $Optional<$AmbientAdditionsSettings>;
        getAmbientAdditionsSettings(): $Optional<$AmbientAdditionsSettings>;
        get ambientLoopSoundEvent(): $Optional<$Holder<$SoundEvent>>;
        getAmbientLoopSoundEvent(): $Optional<$Holder<$SoundEvent>>;
        get ambientMoodSettings(): $Optional<$AmbientMoodSettings>;
        getAmbientMoodSettings(): $Optional<$AmbientMoodSettings>;
        get ambientParticleSettings(): $Optional<$AmbientParticleSettings>;
        getAmbientParticleSettings(): $Optional<$AmbientParticleSettings>;
        get backgroundMusic(): $Optional<$Music>;
        getBackgroundMusic(): $Optional<$Music>;
        get fogColor(): number;
        getFogColor(): number;
        get foliageColorOverride(): $Optional<number>;
        getFoliageColorOverride(): $Optional<number>;
        get grassColorModifier(): $BiomeSpecialEffects$GrassColorModifier;
        getGrassColorModifier(): $BiomeSpecialEffects$GrassColorModifier;
        get grassColorOverride(): $Optional<number>;
        getGrassColorOverride(): $Optional<number>;
        get skyColor(): number;
        getSkyColor(): number;
        get waterColor(): number;
        getWaterColor(): number;
        get waterFogColor(): number;
        getWaterFogColor(): number;
    }

    export class $BiomeSpecialEffects$GrassColorModifier {
        static DARK_FOREST: $BiomeSpecialEffects$GrassColorModifier;
        static NONE: $BiomeSpecialEffects$GrassColorModifier;
        static SWAMP: $BiomeSpecialEffects$GrassColorModifier;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BiomeSpecialEffects$GrassColorModifier[];
        static valueOf(name: string): $BiomeSpecialEffects$GrassColorModifier;
    }
    export interface $BiomeSpecialEffects$GrassColorModifier extends $Enum<$BiomeSpecialEffects$GrassColorModifier> {}

    export class $Climate$Parameter extends $Record {
        constructor(arg0: number, arg1: number);
        static CODEC: $Codec<$Climate$Parameter>;
        static point(arg0: number): $Climate$Parameter;
        static span(arg0: number, arg1: number): $Climate$Parameter;
        static span(arg0: $Climate$Parameter, arg1: $Climate$Parameter): $Climate$Parameter;
        distance(arg0: number): number;
        distance(arg0: $Climate$Parameter): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        max(): number;
        min(): number;
        span(arg0: $Climate$Parameter): $Climate$Parameter;
        toString(): string;
    }

    export class $Climate$ParameterPoint extends $Record {
        constructor(arg0: $Climate$Parameter, arg1: $Climate$Parameter, arg2: $Climate$Parameter, arg3: $Climate$Parameter, arg4: $Climate$Parameter, arg5: $Climate$Parameter, arg6: number);
        static CODEC: $Codec<$Climate$ParameterPoint>;
        continentalness(): $Climate$Parameter;
        depth(): $Climate$Parameter;
        equals(arg0: object): boolean;
        erosion(): $Climate$Parameter;
        hashCode(): number;
        humidity(): $Climate$Parameter;
        offset(): number;
        temperature(): $Climate$Parameter;
        toString(): string;
        weirdness(): $Climate$Parameter;
    }

    export class $Climate$Sampler extends $Record {
        constructor(arg0: $DensityFunction, arg1: $DensityFunction, arg2: $DensityFunction, arg3: $DensityFunction, arg4: $DensityFunction, arg5: $DensityFunction, arg6: $Climate$ParameterPoint[]);
        continentalness(): $DensityFunction;
        depth(): $DensityFunction;
        equals(arg0: object): boolean;
        erosion(): $DensityFunction;
        findSpawnPosition(): $BlockPos;
        hashCode(): number;
        humidity(): $DensityFunction;
        sample(arg0: number, arg1: number, arg2: number): $Climate$TargetPoint;
        spawnTarget(): $List<$Climate$ParameterPoint>;
        temperature(): $DensityFunction;
        toString(): string;
        weirdness(): $DensityFunction;
    }

    export class $Climate$TargetPoint extends $Record {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number);
        continentalness(): number;
        depth(): number;
        equals(arg0: object): boolean;
        erosion(): number;
        hashCode(): number;
        humidity(): number;
        temperature(): number;
        toString(): string;
        weirdness(): number;
    }

    export class $MobSpawnSettings {
        static CODEC: $MapCodec<$MobSpawnSettings>;
        static EMPTY: $MobSpawnSettings;
        static EMPTY_MOB_LIST: $WeightedRandomList<$MobSpawnSettings$SpawnerData>;
        get creatureProbability(): number;
        getCreatureProbability(): number;
        get entityTypes(): $Set<$EntityType<any>>;
        getEntityTypes(): $Set<$EntityType<any>>;
        get spawnerTypes(): $Set<$MobCategory>;
        getSpawnerTypes(): $Set<$MobCategory>;
        getMobSpawnCost(arg0: $EntityType_<any>): $MobSpawnSettings$MobSpawnCost;
        getMobs(arg0: $MobCategory_): $WeightedRandomList<$MobSpawnSettings$SpawnerData>;
    }

    export class $MobSpawnSettings$MobSpawnCost extends $Record {
        constructor(energyBudget: number, charge: number);
        static CODEC: $Codec<$MobSpawnSettings$MobSpawnCost>;
        charge(): number;
        energyBudget(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $MobSpawnSettings$SpawnerData extends $WeightedEntry$IntrusiveBase {
        constructor(arg0: $EntityType_<any>, arg1: number, arg2: number, arg3: number);
        constructor(arg0: $EntityType_<any>, arg1: $Weight, arg2: number, arg3: number);
        static CODEC: $Codec<$MobSpawnSettings$SpawnerData>;
        maxCount: number;
        minCount: number;
        type: $EntityType<any>;
        toString(): string;
    }

    export class $BiomeGenerationSettings$PlainBuilder {
        constructor();
        addCarver(arg0: $GenerationStep$Carving_, arg1: $Holder_<$ConfiguredWorldCarver<any>>): $BiomeGenerationSettings$PlainBuilder;
        addFeature(arg0: number, arg1: $Holder_<$PlacedFeature>): $BiomeGenerationSettings$PlainBuilder;
        addFeature(arg0: $GenerationStep$Decoration_, arg1: $Holder_<$PlacedFeature>): $BiomeGenerationSettings$PlainBuilder;
        build(): $BiomeGenerationSettings;
    }

    export class $BiomeSpecialEffects$Builder {
        constructor();
        ambientAdditionsSound(arg0: $AmbientAdditionsSettings): $BiomeSpecialEffects$Builder;
        ambientLoopSound(arg0: $Holder_<$SoundEvent>): $BiomeSpecialEffects$Builder;
        ambientMoodSound(arg0: $AmbientMoodSettings): $BiomeSpecialEffects$Builder;
        ambientParticle(arg0: $AmbientParticleSettings): $BiomeSpecialEffects$Builder;
        backgroundMusic(arg0: $Music): $BiomeSpecialEffects$Builder;
        build(): $BiomeSpecialEffects;
        fogColor(arg0: number): $BiomeSpecialEffects$Builder;
        foliageColorOverride(arg0: number): $BiomeSpecialEffects$Builder;
        grassColorModifier(arg0: $BiomeSpecialEffects$GrassColorModifier_): $BiomeSpecialEffects$Builder;
        grassColorOverride(arg0: number): $BiomeSpecialEffects$Builder;
        skyColor(arg0: number): $BiomeSpecialEffects$Builder;
        waterColor(arg0: number): $BiomeSpecialEffects$Builder;
        waterFogColor(arg0: number): $BiomeSpecialEffects$Builder;
    }

    export class $MobSpawnSettings$Builder {
        constructor();
        addMobCharge(arg0: $EntityType_<any>, arg1: number, arg2: number): $MobSpawnSettings$Builder;
        addSpawn(arg0: $MobCategory_, arg1: $MobSpawnSettings$SpawnerData): $MobSpawnSettings$Builder;
        build(): $MobSpawnSettings;
        creatureGenerationProbability(arg0: number): $MobSpawnSettings$Builder;
    }

    export type $Biome$Precipitation_ = $Biome$Precipitation | "NONE" | "RAIN" | "SNOW";
    export type $Biome$TemperatureModifier_ = $Biome$TemperatureModifier | "FROZEN" | "NONE";
    export type $BiomeManager$NoiseBiomeSource_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackResult = $Holder_<$Biome>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($BiomeManager$NoiseBiomeSource & { readonly [Symbol.hasInstance]?: never });
    export type $BiomeResolver_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackArg3 = $Climate$Sampler, CallbackResult = $Holder_<$Biome>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => CallbackResult) | ($BiomeResolver & { readonly [Symbol.hasInstance]?: never });
    export type $BiomeSpecialEffects$GrassColorModifier_ = $BiomeSpecialEffects$GrassColorModifier | "DARK_FOREST" | "NONE" | "SWAMP";
}
