import { $Enum } from "java:java/lang";

declare module "java:net/neoforged/neoforge/network/connection" {
    export class $ConnectionType {
        static NEOFORGE: $ConnectionType;
        static OTHER: $ConnectionType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ConnectionType[];
        static valueOf(name: string): $ConnectionType;
    }
    export interface $ConnectionType extends $Enum<$ConnectionType> {}

    export type $ConnectionType_ = $ConnectionType | "NEOFORGE" | "OTHER";
}
