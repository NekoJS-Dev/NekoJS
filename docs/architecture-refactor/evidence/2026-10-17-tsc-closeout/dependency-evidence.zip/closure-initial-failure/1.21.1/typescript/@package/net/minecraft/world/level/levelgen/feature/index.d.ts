import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $Function, $Function_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $RandomSource } from "java:net/minecraft/util";
import { $LevelSimulatedReader, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $BlockPredicate } from "java:net/minecraft/world/level/levelgen/blockpredicates";
import { $BlockColumnConfiguration, $BlockPileConfiguration, $BlockStateConfiguration, $ColumnFeatureConfiguration, $CountConfiguration, $DeltaFeatureConfiguration, $DiskConfiguration, $DripstoneClusterConfiguration, $EndGatewayConfiguration, $FeatureConfiguration, $GeodeConfiguration, $HugeMushroomFeatureConfiguration, $LargeDripstoneConfiguration, $LayerConfiguration, $MultifaceGrowthConfiguration, $NetherForestVegetationConfig, $NoneFeatureConfiguration, $OreConfiguration, $PointedDripstoneConfiguration, $ProbabilityFeatureConfiguration, $RandomBooleanFeatureConfiguration, $RandomFeatureConfiguration, $RandomPatchConfiguration, $ReplaceBlockConfiguration, $ReplaceSphereConfiguration, $RootSystemConfiguration, $SculkPatchConfiguration, $SimpleBlockConfiguration, $SimpleRandomFeatureConfiguration, $SpikeConfiguration, $SpringConfiguration, $TreeConfiguration, $TwistingVinesConfig, $UnderwaterMagmaConfiguration, $VegetationPatchConfiguration } from "java:net/minecraft/world/level/levelgen/feature/configurations";
import { $BlockStateProvider } from "java:net/minecraft/world/level/levelgen/feature/stateproviders";
import { $PlacedFeature } from "java:net/minecraft/world/level/levelgen/placement";
import { $StructureProcessorList } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";
import { $AABB } from "java:net/minecraft/world/phys";

export * as configurations from "java:net/minecraft/world/level/levelgen/feature/configurations";
export * as featuresize from "java:net/minecraft/world/level/levelgen/feature/featuresize";
export * as foliageplacers from "java:net/minecraft/world/level/levelgen/feature/foliageplacers";
export * as rootplacers from "java:net/minecraft/world/level/levelgen/feature/rootplacers";
export * as stateproviders from "java:net/minecraft/world/level/levelgen/feature/stateproviders";
export * as treedecorators from "java:net/minecraft/world/level/levelgen/feature/treedecorators";
export * as trunkplacers from "java:net/minecraft/world/level/levelgen/feature/trunkplacers";

declare module "java:net/minecraft/world/level/levelgen/feature" {
    export class $BonusChestFeature extends $Feature<$NoneFeatureConfiguration> {
        constructor(arg0: $Codec<$NoneFeatureConfiguration>);
        place(arg0: $FeaturePlaceContext<$NoneFeatureConfiguration>): boolean;
        place(arg0: $NoneFeatureConfiguration, arg1: $WorldGenLevel, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BlockPos_): boolean;
    }

    export class $ConfiguredFeature<FC extends $FeatureConfiguration, F extends $Feature<FC>> extends $Record {
        constructor(arg0: F, arg1: FC);
        static CODEC: $Codec<$Holder<$ConfiguredFeature<any, any>>>;
        static DIRECT_CODEC: $Codec<$ConfiguredFeature<any, any>>;
        static LIST_CODEC: $Codec<$HolderSet<$ConfiguredFeature<any, any>>>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        config(): FC;
        equals(arg0: object): boolean;
        feature(): F;
        hashCode(): number;
        place(arg0: $WorldGenLevel, arg1: $ChunkGenerator, arg2: $RandomSource, arg3: $BlockPos_): boolean;
        toString(): string;
    }

    export class $Feature<FC extends $FeatureConfiguration> {
        constructor(arg0: $Codec<FC>);
        static BAMBOO: $Feature<$ProbabilityFeatureConfiguration>;
        static BASALT_COLUMNS: $Feature<$ColumnFeatureConfiguration>;
        static BASALT_PILLAR: $Feature<$NoneFeatureConfiguration>;
        static BLOCK_COLUMN: $Feature<$BlockColumnConfiguration>;
        static BLOCK_PILE: $Feature<$BlockPileConfiguration>;
        static BLUE_ICE: $Feature<$NoneFeatureConfiguration>;
        static BONUS_CHEST: $BonusChestFeature;
        static CHORUS_PLANT: $Feature<$NoneFeatureConfiguration>;
        static CORAL_CLAW: $Feature<$NoneFeatureConfiguration>;
        static CORAL_MUSHROOM: $Feature<$NoneFeatureConfiguration>;
        static CORAL_TREE: $Feature<$NoneFeatureConfiguration>;
        static DELTA_FEATURE: $Feature<$DeltaFeatureConfiguration>;
        static DESERT_WELL: $Feature<$NoneFeatureConfiguration>;
        static DISK: $Feature<$DiskConfiguration>;
        static DRIPSTONE_CLUSTER: $Feature<$DripstoneClusterConfiguration>;
        static END_GATEWAY: $Feature<$EndGatewayConfiguration>;
        static END_ISLAND: $Feature<$NoneFeatureConfiguration>;
        static END_PLATFORM: $Feature<$NoneFeatureConfiguration>;
        static END_SPIKE: $Feature<$SpikeConfiguration>;
        static FILL_LAYER: $Feature<$LayerConfiguration>;
        static FLOWER: $Feature<$RandomPatchConfiguration>;
        static FOREST_ROCK: $Feature<$BlockStateConfiguration>;
        static FOSSIL: $Feature<$FossilFeatureConfiguration>;
        static FREEZE_TOP_LAYER: $Feature<$NoneFeatureConfiguration>;
        static GEODE: $Feature<$GeodeConfiguration>;
        static GLOWSTONE_BLOB: $Feature<$NoneFeatureConfiguration>;
        static HUGE_BROWN_MUSHROOM: $Feature<$HugeMushroomFeatureConfiguration>;
        static HUGE_FUNGUS: $Feature<$HugeFungusConfiguration>;
        static HUGE_RED_MUSHROOM: $Feature<$HugeMushroomFeatureConfiguration>;
        static ICEBERG: $Feature<$BlockStateConfiguration>;
        static ICE_SPIKE: $Feature<$NoneFeatureConfiguration>;
        static KELP: $Feature<$NoneFeatureConfiguration>;
        static LAKE: $Feature<$LakeFeature$Configuration>;
        static LARGE_DRIPSTONE: $Feature<$LargeDripstoneConfiguration>;
        static MONSTER_ROOM: $Feature<$NoneFeatureConfiguration>;
        static MULTIFACE_GROWTH: $Feature<$MultifaceGrowthConfiguration>;
        static NETHER_FOREST_VEGETATION: $Feature<$NetherForestVegetationConfig>;
        static NO_BONEMEAL_FLOWER: $Feature<$RandomPatchConfiguration>;
        static NO_OP: $Feature<$NoneFeatureConfiguration>;
        static ORE: $Feature<$OreConfiguration>;
        static POINTED_DRIPSTONE: $Feature<$PointedDripstoneConfiguration>;
        static RANDOM_BOOLEAN_SELECTOR: $Feature<$RandomBooleanFeatureConfiguration>;
        static RANDOM_PATCH: $Feature<$RandomPatchConfiguration>;
        static RANDOM_SELECTOR: $Feature<$RandomFeatureConfiguration>;
        static REPLACE_BLOBS: $Feature<$ReplaceSphereConfiguration>;
        static REPLACE_SINGLE_BLOCK: $Feature<$ReplaceBlockConfiguration>;
        static ROOT_SYSTEM: $Feature<$RootSystemConfiguration>;
        static SCATTERED_ORE: $Feature<$OreConfiguration>;
        static SCULK_PATCH: $Feature<$SculkPatchConfiguration>;
        static SEAGRASS: $SeagrassFeature;
        static SEA_PICKLE: $Feature<$CountConfiguration>;
        static SIMPLE_BLOCK: $Feature<$SimpleBlockConfiguration>;
        static SIMPLE_RANDOM_SELECTOR: $Feature<$SimpleRandomFeatureConfiguration>;
        static SPRING: $Feature<$SpringConfiguration>;
        static TREE: $Feature<$TreeConfiguration>;
        static TWISTING_VINES: $Feature<$TwistingVinesConfig>;
        static UNDERWATER_MAGMA: $Feature<$UnderwaterMagmaConfiguration>;
        static VEGETATION_PATCH: $Feature<$VegetationPatchConfiguration>;
        static VINES: $Feature<$NoneFeatureConfiguration>;
        static VOID_START_PLATFORM: $Feature<$NoneFeatureConfiguration>;
        static WATERLOGGED_VEGETATION_PATCH: $Feature<$VegetationPatchConfiguration>;
        static WEEPING_VINES: $Feature<$NoneFeatureConfiguration>;
        static checkNeighbors(arg0: $Function_<$BlockPos, $BlockState, $BlockPos, $BlockState_>, arg1: $BlockPos_, arg2: $Predicate_<$BlockState, $BlockState, boolean>): boolean;
        static isAdjacentToAir(arg0: $Function_<$BlockPos, $BlockState, $BlockPos, $BlockState_>, arg1: $BlockPos_): boolean;
        static isDirt(arg0: $BlockState_): boolean;
        static isGrassOrDirt(arg0: $LevelSimulatedReader, arg1: $BlockPos_): boolean;
        static isReplaceable(arg0: $TagKey_<$Block>): $Predicate<$BlockState>;
        configuredCodec(): $MapCodec<$ConfiguredFeature<FC, $Feature<FC>>>;
        place(arg0: FC, arg1: $WorldGenLevel, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BlockPos_): boolean;
        place(arg0: $FeaturePlaceContext<FC>): boolean;
    }

    export class $FeaturePlaceContext<FC extends $FeatureConfiguration> {
        constructor(arg0: $Optional<$ConfiguredFeature<any, any>>, arg1: $WorldGenLevel, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BlockPos_, arg5: FC);
        chunkGenerator(): $ChunkGenerator;
        config(): FC;
        level(): $WorldGenLevel;
        origin(): $BlockPos;
        random(): $RandomSource;
        topFeature(): $Optional<$ConfiguredFeature<any, any>>;
    }

    export class $FossilFeatureConfiguration implements $FeatureConfiguration {
        constructor(arg0: $ResourceLocation_[], arg1: $ResourceLocation_[], arg2: $Holder_<$StructureProcessorList>, arg3: $Holder_<$StructureProcessorList>, arg4: number);
        static CODEC: $Codec<$FossilFeatureConfiguration>;
        fossilProcessors: $Holder<$StructureProcessorList>;
        fossilStructures: $List<$ResourceLocation>;
        maxEmptyCornersAllowed: number;
        overlayProcessors: $Holder<$StructureProcessorList>;
        overlayStructures: $List<$ResourceLocation>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $HugeFungusConfiguration implements $FeatureConfiguration {
        constructor(arg0: $BlockState_, arg1: $BlockState_, arg2: $BlockState_, arg3: $BlockState_, arg4: $BlockPredicate, arg5: boolean);
        static CODEC: $Codec<$HugeFungusConfiguration>;
        decorState: $BlockState;
        hatState: $BlockState;
        planted: boolean;
        replaceableBlocks: $BlockPredicate;
        stemState: $BlockState;
        validBaseState: $BlockState;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $LakeFeature$Configuration extends $Record implements $FeatureConfiguration {
        constructor(arg0: $BlockStateProvider, arg1: $BlockStateProvider);
        static CODEC: $Codec<$LakeFeature$Configuration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        barrier(): $BlockStateProvider;
        equals(arg0: object): boolean;
        fluid(): $BlockStateProvider;
        hashCode(): number;
        toString(): string;
    }

    export class $SeagrassFeature extends $Feature<$ProbabilityFeatureConfiguration> {
        constructor(arg0: $Codec<$ProbabilityFeatureConfiguration>);
        place(arg0: $FeaturePlaceContext<$ProbabilityFeatureConfiguration>): boolean;
        place(arg0: $ProbabilityFeatureConfiguration, arg1: $WorldGenLevel, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BlockPos_): boolean;
    }

    export class $SpikeFeature$EndSpike {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: boolean);
        static CODEC: $Codec<$SpikeFeature$EndSpike>;
        get centerX(): number;
        getCenterX(): number;
        get centerZ(): number;
        getCenterZ(): number;
        get height(): number;
        getHeight(): number;
        get radius(): number;
        getRadius(): number;
        get topBoundingBox(): $AABB;
        getTopBoundingBox(): $AABB;
        get guarded(): boolean;
        isGuarded(): boolean;
        isCenterWithinChunk(arg0: $BlockPos_): boolean;
    }

    export class $WeightedPlacedFeature {
        constructor(arg0: $Holder_<$PlacedFeature>, arg1: number);
        static CODEC: $Codec<$WeightedPlacedFeature>;
        chance: number;
        feature: $Holder<$PlacedFeature>;
        place(arg0: $WorldGenLevel, arg1: $ChunkGenerator, arg2: $RandomSource, arg3: $BlockPos_): boolean;
    }

}
