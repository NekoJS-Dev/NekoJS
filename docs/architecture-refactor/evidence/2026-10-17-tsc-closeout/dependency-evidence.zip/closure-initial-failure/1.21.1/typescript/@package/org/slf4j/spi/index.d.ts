import { $Throwable } from "java:java/lang";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $Marker } from "java:org/slf4j";

declare module "java:org/slf4j/spi" {
    export interface $LoggingEventBuilder {
        addArgument(arg0: object): $LoggingEventBuilder;
        addArgument(arg0: $Supplier_<any, any>): $LoggingEventBuilder;
        addKeyValue(arg0: string, arg1: object): $LoggingEventBuilder;
        addKeyValue(arg0: string, arg1: $Supplier_<object, object>): $LoggingEventBuilder;
        addMarker(arg0: $Marker): $LoggingEventBuilder;
        log(arg0: string, arg1?: object[]): void;
        log(arg0: string, arg1: object, arg2: object): void;
        log(arg0: string, arg1: object): void;
        log(arg0: string): void;
        log(arg0: $Supplier_<string, string>): void;
        log(): void;
        setCause(arg0: $Throwable): $LoggingEventBuilder;
        setMessage(arg0: string): $LoggingEventBuilder;
        setMessage(arg0: $Supplier_<string, string>): $LoggingEventBuilder;
    }

}
