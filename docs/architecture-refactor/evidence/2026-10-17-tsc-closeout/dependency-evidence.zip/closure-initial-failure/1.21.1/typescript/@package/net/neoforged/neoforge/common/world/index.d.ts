import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record } from "java:java/lang";
import { $List, $Map, $Optional, $Set } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $HolderLookup$Provider, $HolderSet, $Holder_, $RegistryAccess } from "java:net/minecraft/core";
import { $ListTag } from "java:net/minecraft/nbt";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientboundLevelChunkWithLightPacket } from "java:net/minecraft/network/protocol/game";
import { $Music, $SoundEvent, $SoundEvent_ } from "java:net/minecraft/sounds";
import { $EntityType, $EntityType_, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $AmbientAdditionsSettings, $AmbientMoodSettings, $AmbientParticleSettings, $Biome, $Biome$ClimateSettings, $Biome$TemperatureModifier, $Biome$TemperatureModifier_, $BiomeGenerationSettings, $BiomeGenerationSettings$PlainBuilder, $BiomeSpecialEffects, $BiomeSpecialEffects$Builder, $BiomeSpecialEffects$GrassColorModifier, $BiomeSpecialEffects$GrassColorModifier_, $MobSpawnSettings, $MobSpawnSettings$Builder, $MobSpawnSettings$MobSpawnCost, $MobSpawnSettings$SpawnerData } from "java:net/minecraft/world/level/biome";
import { $LevelChunk } from "java:net/minecraft/world/level/chunk";
import { $GenerationStep$Carving, $GenerationStep$Carving_, $GenerationStep$Decoration, $GenerationStep$Decoration_ } from "java:net/minecraft/world/level/levelgen";
import { $ConfiguredWorldCarver } from "java:net/minecraft/world/level/levelgen/carver";
import { $PlacedFeature } from "java:net/minecraft/world/level/levelgen/placement";
import { $Structure, $Structure$StructureSettings, $StructureSpawnOverride, $StructureSpawnOverride$BoundingBoxType, $StructureSpawnOverride$BoundingBoxType_, $TerrainAdjustment, $TerrainAdjustment_ } from "java:net/minecraft/world/level/levelgen/structure";
import { $INBTSerializable } from "java:net/neoforged/neoforge/common/util";

declare module "java:net/neoforged/neoforge/common/world" {
    export interface $AuxiliaryLightManager {
        getLightAt(arg0: $BlockPos_): number;
        removeLightAt(arg0: $BlockPos_): void;
        setLightAt(arg0: $BlockPos_, arg1: number): void;
    }

    export interface $BiomeModifier {
        codec(): $MapCodec<$BiomeModifier>;
        modify(arg0: $Holder_<$Biome>, arg1: $BiomeModifier$Phase_, arg2: $ModifiableBiomeInfo$BiomeInfo$Builder): void;
    }
    export const $BiomeModifier: {
        readonly DIRECT_CODEC: $Codec<$BiomeModifier>;
        readonly LIST_CODEC: $Codec<$HolderSet<$BiomeModifier>>;
        readonly REFERENCE_CODEC: $Codec<$Holder<$BiomeModifier>>;
    };

    export class $BiomeModifier$Phase {
        static ADD: $BiomeModifier$Phase;
        static AFTER_EVERYTHING: $BiomeModifier$Phase;
        static BEFORE_EVERYTHING: $BiomeModifier$Phase;
        static MODIFY: $BiomeModifier$Phase;
        static REMOVE: $BiomeModifier$Phase;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $BiomeModifier$Phase[];
        static valueOf(name: string): $BiomeModifier$Phase;
    }
    export interface $BiomeModifier$Phase extends $Enum<$BiomeModifier$Phase> {}

    export class $LevelChunkAuxiliaryLightManager implements $AuxiliaryLightManager, $INBTSerializable<$ListTag> {
        constructor(arg0: $LevelChunk);
        static LIGHT_NBT_KEY: string;
        deserializeNBT(arg0: $HolderLookup$Provider, arg1: $ListTag): void;
        getLightAt(arg0: $BlockPos_): number;
        handleLightDataSync(arg0: ($Map<$BlockPos_, number> | ([$BlockPos_] extends [PropertyKey] ? Partial<Record<Extract<$BlockPos_, PropertyKey>, number>> : never))): void;
        removeLightAt(arg0: $BlockPos_): void;
        sendLightDataTo(arg0: $ClientboundLevelChunkWithLightPacket): $Packet<any>;
        serializeNBT(arg0: $HolderLookup$Provider): $ListTag;
        setLightAt(arg0: $BlockPos_, arg1: number): void;
    }

    export class $ModifiableBiomeInfo {
        constructor(arg0: $ModifiableBiomeInfo$BiomeInfo);
        get modifiedBiomeInfo(): $ModifiableBiomeInfo$BiomeInfo;
        getModifiedBiomeInfo(): $ModifiableBiomeInfo$BiomeInfo;
        get originalBiomeInfo(): $ModifiableBiomeInfo$BiomeInfo;
        getOriginalBiomeInfo(): $ModifiableBiomeInfo$BiomeInfo;
        applyBiomeModifiers(arg0: $Holder_<$Biome>, arg1: $BiomeModifier[], arg2: $RegistryAccess): boolean;
        get(): $ModifiableBiomeInfo$BiomeInfo;
    }

    export class $ModifiableBiomeInfo$BiomeInfo extends $Record {
        constructor(climateSettings: $Biome$ClimateSettings, effects: $BiomeSpecialEffects, generationSettings: $BiomeGenerationSettings, mobSpawnSettings: $MobSpawnSettings);
        climateSettings(): $Biome$ClimateSettings;
        effects(): $BiomeSpecialEffects;
        equals(arg0: object): boolean;
        generationSettings(): $BiomeGenerationSettings;
        hashCode(): number;
        mobSpawnSettings(): $MobSpawnSettings;
        toString(): string;
    }

    export class $ModifiableBiomeInfo$BiomeInfo$Builder {
        get climateSettings(): $ClimateSettingsBuilder;
        getClimateSettings(): $ClimateSettingsBuilder;
        get generationSettings(): $BiomeGenerationSettingsBuilder;
        getGenerationSettings(): $BiomeGenerationSettingsBuilder;
        get mobSpawnSettings(): $MobSpawnSettingsBuilder;
        getMobSpawnSettings(): $MobSpawnSettingsBuilder;
        get specialEffects(): $BiomeSpecialEffectsBuilder;
        getSpecialEffects(): $BiomeSpecialEffectsBuilder;
        static copyOf(arg0: $ModifiableBiomeInfo$BiomeInfo): $ModifiableBiomeInfo$BiomeInfo$Builder;
        build(): $ModifiableBiomeInfo$BiomeInfo;
    }

    export class $ModifiableStructureInfo {
        constructor(arg0: $ModifiableStructureInfo$StructureInfo);
        get modifiedStructureInfo(): $ModifiableStructureInfo$StructureInfo;
        getModifiedStructureInfo(): $ModifiableStructureInfo$StructureInfo;
        get originalStructureInfo(): $ModifiableStructureInfo$StructureInfo;
        getOriginalStructureInfo(): $ModifiableStructureInfo$StructureInfo;
        applyStructureModifiers(arg0: $Holder_<$Structure>, arg1: $StructureModifier[]): void;
        get(): $ModifiableStructureInfo$StructureInfo;
    }

    export class $ModifiableStructureInfo$StructureInfo extends $Record {
        constructor(structureSettings: $Structure$StructureSettings);
        equals(arg0: object): boolean;
        hashCode(): number;
        structureSettings(): $Structure$StructureSettings;
        toString(): string;
    }

    export class $ModifiableStructureInfo$StructureInfo$Builder {
        get structureSettings(): $StructureSettingsBuilder;
        getStructureSettings(): $StructureSettingsBuilder;
        static copyOf(arg0: $ModifiableStructureInfo$StructureInfo): $ModifiableStructureInfo$StructureInfo$Builder;
        build(): $ModifiableStructureInfo$StructureInfo;
    }

    export interface $StructureModifier {
        codec(): $MapCodec<$StructureModifier>;
        modify(arg0: $Holder_<$Structure>, arg1: $StructureModifier$Phase_, arg2: $ModifiableStructureInfo$StructureInfo$Builder): void;
    }
    export const $StructureModifier: {
        readonly DIRECT_CODEC: $Codec<$StructureModifier>;
        readonly LIST_CODEC: $Codec<$HolderSet<$StructureModifier>>;
        readonly REFERENCE_CODEC: $Codec<$Holder<$StructureModifier>>;
    };

    export class $StructureModifier$Phase {
        static ADD: $StructureModifier$Phase;
        static AFTER_EVERYTHING: $StructureModifier$Phase;
        static BEFORE_EVERYTHING: $StructureModifier$Phase;
        static MODIFY: $StructureModifier$Phase;
        static REMOVE: $StructureModifier$Phase;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StructureModifier$Phase[];
        static valueOf(name: string): $StructureModifier$Phase;
    }
    export interface $StructureModifier$Phase extends $Enum<$StructureModifier$Phase> {}

    export class $BiomeGenerationSettingsBuilder extends $BiomeGenerationSettings$PlainBuilder {
        constructor(arg0: $BiomeGenerationSettings);
        getCarvers(arg0: $GenerationStep$Carving_): $List<$Holder<$ConfiguredWorldCarver<any>>>;
        getFeatures(arg0: $GenerationStep$Decoration_): $List<$Holder<$PlacedFeature>>;
    }

    export class $BiomeSpecialEffectsBuilder extends $BiomeSpecialEffects$Builder {
        getAmbientAdditionsSound(): $Optional<$AmbientAdditionsSettings>;
        getAmbientLoopSound(): $Optional<$Holder<$SoundEvent>>;
        getAmbientMoodSound(): $Optional<$AmbientMoodSettings>;
        getAmbientParticle(): $Optional<$AmbientParticleSettings>;
        getBackgroundMusic(): $Optional<$Music>;
        getFogColor(): number;
        getFoliageColorOverride(): $Optional<number>;
        getGrassColorModifier(): $BiomeSpecialEffects$GrassColorModifier;
        getGrassColorOverride(): $Optional<number>;
        getSkyColor(): number;
        getWaterFogColor(): number;
        static copyOf(arg0: $BiomeSpecialEffects): $BiomeSpecialEffectsBuilder;
        static create(arg0: number, arg1: number, arg2: number, arg3: number): $BiomeSpecialEffectsBuilder;
        ambientAdditionsSound(arg0: $AmbientAdditionsSettings): $BiomeSpecialEffects$Builder;
        ambientLoopSound(arg0: $Holder_<$SoundEvent>): $BiomeSpecialEffects$Builder;
        ambientMoodSound(arg0: $AmbientMoodSettings): $BiomeSpecialEffects$Builder;
        ambientParticle(arg0: $AmbientParticleSettings): $BiomeSpecialEffects$Builder;
        backgroundMusic(arg0: $Music): $BiomeSpecialEffects$Builder;
        fogColor(arg0: number): $BiomeSpecialEffects$Builder;
        foliageColorOverride(arg0: number): $BiomeSpecialEffects$Builder;
        grassColorModifier(arg0: $BiomeSpecialEffects$GrassColorModifier_): $BiomeSpecialEffects$Builder;
        grassColorOverride(arg0: number): $BiomeSpecialEffects$Builder;
        skyColor(arg0: number): $BiomeSpecialEffects$Builder;
        waterColor(arg0: number): $BiomeSpecialEffects$Builder;
        waterColor(): number;
        waterFogColor(arg0: number): $BiomeSpecialEffects$Builder;
    }

    export class $ClimateSettingsBuilder {
        get downfall(): number;
        getDownfall(): number;
        set downfall(value: number);
        get temperatureModifier(): $Biome$TemperatureModifier;
        getTemperatureModifier(): $Biome$TemperatureModifier;
        set temperatureModifier(value: $Biome$TemperatureModifier_);
        get temperature(): number;
        getTemperature(): number;
        set temperature(value: number);
        static copyOf(arg0: $Biome$ClimateSettings): $ClimateSettingsBuilder;
        static create(arg0: boolean, arg1: number, arg2: $Biome$TemperatureModifier_, arg3: number): $ClimateSettingsBuilder;
        build(): $Biome$ClimateSettings;
        hasPrecipitation(): boolean;
        setDownfall(arg0: number): void;
        setHasPrecipitation(arg0: boolean): void;
        setTemperatureModifier(arg0: $Biome$TemperatureModifier_): void;
        setTemperature(arg0: number): void;
    }

    export class $MobSpawnSettingsBuilder extends $MobSpawnSettings$Builder {
        constructor(arg0: $MobSpawnSettings);
        get entityTypes(): $Set<$EntityType<any>>;
        getEntityTypes(): $Set<$EntityType<any>>;
        get probability(): number;
        getProbability(): number;
        get spawnerTypes(): $Set<$MobCategory>;
        getSpawnerTypes(): $Set<$MobCategory>;
        disablePlayerSpawn(): $MobSpawnSettingsBuilder;
        getCost(arg0: $EntityType_<any>): $MobSpawnSettings$MobSpawnCost;
        getSpawner(arg0: $MobCategory_): $List<$MobSpawnSettings$SpawnerData>;
        removeSpawnCost(arg0?: $EntityType_<any>[]): $MobSpawnSettingsBuilder;
    }

    export class $StructureSettingsBuilder {
        get biomes(): $HolderSet<$Biome>;
        getBiomes(): $HolderSet<$Biome>;
        set biomes(value: $HolderSet<$Biome>);
        get decorationStep(): $GenerationStep$Decoration;
        getDecorationStep(): $GenerationStep$Decoration;
        set decorationStep(value: $GenerationStep$Decoration_);
        get terrainAdaptation(): $TerrainAdjustment;
        getTerrainAdaptation(): $TerrainAdjustment;
        set terrainAdaptation(value: $TerrainAdjustment_);
        static copyOf(arg0: $Structure$StructureSettings): $StructureSettingsBuilder;
        build(): $Structure$StructureSettings;
        getOrAddSpawnOverrides(arg0: $MobCategory_): $StructureSettingsBuilder$StructureSpawnOverrideBuilder;
        getSpawnOverrides(arg0: $MobCategory_): $StructureSettingsBuilder$StructureSpawnOverrideBuilder;
        removeSpawnOverrides(arg0: $MobCategory_): void;
        setBiomes(arg0: $HolderSet<$Biome>): void;
        setDecorationStep(arg0: $GenerationStep$Decoration_): void;
        setTerrainAdaptation(arg0: $TerrainAdjustment_): void;
    }

    export class $StructureSettingsBuilder$StructureSpawnOverrideBuilder {
        get boundingBox(): $StructureSpawnOverride$BoundingBoxType;
        getBoundingBox(): $StructureSpawnOverride$BoundingBoxType;
        set boundingBox(value: $StructureSpawnOverride$BoundingBoxType_);
        get spawns(): $List<$MobSpawnSettings$SpawnerData>;
        getSpawns(): $List<$MobSpawnSettings$SpawnerData>;
        static copyOf(arg0: $StructureSpawnOverride): $StructureSettingsBuilder$StructureSpawnOverrideBuilder;
        addSpawn(arg0: $MobSpawnSettings$SpawnerData): void;
        build(): $StructureSpawnOverride;
        removeSpawns(arg0: $Predicate_<$MobSpawnSettings$SpawnerData, $MobSpawnSettings$SpawnerData, boolean>): void;
        removeSpawn(arg0: $MobSpawnSettings$SpawnerData): void;
        setBoundingBox(arg0: $StructureSpawnOverride$BoundingBoxType_): void;
    }

    export type $BiomeModifier$Phase_ = $BiomeModifier$Phase | "ADD" | "AFTER_EVERYTHING" | "BEFORE_EVERYTHING" | "MODIFY" | "REMOVE";
    export type $StructureModifier$Phase_ = $StructureModifier$Phase | "ADD" | "AFTER_EVERYTHING" | "BEFORE_EVERYTHING" | "MODIFY" | "REMOVE";
}
