import { $HolderLookup$Provider, $NonNullList } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $INBTSerializable } from "java:net/neoforged/neoforge/common/util";

declare module "java:net/neoforged/neoforge/items" {
    export interface $IItemHandler {
        extractItem(arg0: number, arg1: number, arg2: boolean): $ItemStack;
        getSlotLimit(arg0: number): number;
        getSlots(): number;
        getStackInSlot(arg0: number): $ItemStack;
        insertItem(arg0: number, arg1: $ItemStack_, arg2: boolean): $ItemStack;
        isItemValid(arg0: number, arg1: $ItemStack_): boolean;
    }

    export interface $IItemHandlerModifiable extends $IItemHandler {
        setStackInSlot(arg0: number, arg1: $ItemStack_): void;
    }

    export class $ItemStackHandler implements $IItemHandler, $IItemHandlerModifiable, $INBTSerializable<$CompoundTag> {
        constructor();
        constructor(arg0: number);
        constructor(arg0: $NonNullList<$ItemStack>);
        get slots(): number;
        getSlots(): number;
        deserializeNBT(arg0: $HolderLookup$Provider, arg1: $CompoundTag_): void;
        extractItem(arg0: number, arg1: number, arg2: boolean): $ItemStack;
        getSlotLimit(arg0: number): number;
        getStackInSlot(arg0: number): $ItemStack;
        insertItem(arg0: number, arg1: $ItemStack_, arg2: boolean): $ItemStack;
        isItemValid(arg0: number, arg1: $ItemStack_): boolean;
        serializeNBT(arg0: $HolderLookup$Provider): $CompoundTag;
        setSize(arg0: number): void;
        setStackInSlot(arg0: number, arg1: $ItemStack_): void;
    }

}
