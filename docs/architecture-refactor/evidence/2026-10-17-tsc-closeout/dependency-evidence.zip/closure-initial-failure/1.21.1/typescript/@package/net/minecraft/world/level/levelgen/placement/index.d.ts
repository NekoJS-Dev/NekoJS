import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $IntProvider } from "java:net/minecraft/util/valueproviders";
import { $ChunkPos, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $CarvingMask, $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $GenerationStep$Carving, $GenerationStep$Carving_, $Heightmap$Types, $Heightmap$Types_, $VerticalAnchor, $VerticalAnchor_, $WorldGenerationContext } from "java:net/minecraft/world/level/levelgen";
import { $BlockPredicate } from "java:net/minecraft/world/level/levelgen/blockpredicates";
import { $ConfiguredFeature } from "java:net/minecraft/world/level/levelgen/feature";
import { $HeightProvider } from "java:net/minecraft/world/level/levelgen/heightproviders";

declare module "java:net/minecraft/world/level/levelgen/placement" {
    export class $CaveSurface {
        static CEILING: $CaveSurface;
        static FLOOR: $CaveSurface;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $CaveSurface[];
        static valueOf(name: string): $CaveSurface;
    }
    export interface $CaveSurface extends $Enum<$CaveSurface> {}

    export class $PlacedFeature extends $Record {
        constructor(arg0: $Holder_<$ConfiguredFeature<any, any>>, arg1: $PlacementModifier[]);
        static CODEC: $Codec<$Holder<$PlacedFeature>>;
        static DIRECT_CODEC: $Codec<$PlacedFeature>;
        static LIST_CODEC: $Codec<$HolderSet<$PlacedFeature>>;
        static LIST_OF_LISTS_CODEC: $Codec<$List<$HolderSet<$PlacedFeature>>>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        equals(arg0: object): boolean;
        feature(): $Holder<$ConfiguredFeature<any, any>>;
        hashCode(): number;
        placeWithBiomeCheck(arg0: $WorldGenLevel, arg1: $ChunkGenerator, arg2: $RandomSource, arg3: $BlockPos_): boolean;
        placement(): $List<$PlacementModifier>;
        place(arg0: $WorldGenLevel, arg1: $ChunkGenerator, arg2: $RandomSource, arg3: $BlockPos_): boolean;
        toString(): string;
    }

    export class $PlacementModifier {
        constructor();
        static CODEC: $Codec<$PlacementModifier>;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $PlacementContext extends $WorldGenerationContext {
        constructor(arg0: $WorldGenLevel, arg1: $ChunkGenerator, arg2: $Optional<$PlacedFeature>);
        get level(): $WorldGenLevel;
        getLevel(): $WorldGenLevel;
        get minBuildHeight(): number;
        getMinBuildHeight(): number;
        generator(): $ChunkGenerator;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getCarvingMask(arg0: $ChunkPos, arg1: $GenerationStep$Carving_): $CarvingMask;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        topFeature(): $Optional<$PlacedFeature>;
    }

    export interface $PlacementModifierType<P extends $PlacementModifier> {
        codec(): $MapCodec<P>;
    }
    export const $PlacementModifierType: {
        readonly BIOME_FILTER: $PlacementModifierType<$BiomeFilter>;
        readonly BLOCK_PREDICATE_FILTER: $PlacementModifierType<$BlockPredicateFilter>;
        readonly CARVING_MASK_PLACEMENT: $PlacementModifierType<$CarvingMaskPlacement>;
        readonly COUNT: $PlacementModifierType<$CountPlacement>;
        readonly COUNT_ON_EVERY_LAYER: $PlacementModifierType<$CountOnEveryLayerPlacement>;
        readonly ENVIRONMENT_SCAN: $PlacementModifierType<$EnvironmentScanPlacement>;
        readonly FIXED_PLACEMENT: $PlacementModifierType<$FixedPlacement>;
        readonly HEIGHTMAP: $PlacementModifierType<$HeightmapPlacement>;
        readonly HEIGHT_RANGE: $PlacementModifierType<$HeightRangePlacement>;
        readonly IN_SQUARE: $PlacementModifierType<$InSquarePlacement>;
        readonly NOISE_BASED_COUNT: $PlacementModifierType<$NoiseBasedCountPlacement>;
        readonly NOISE_THRESHOLD_COUNT: $PlacementModifierType<$NoiseThresholdCountPlacement>;
        readonly RANDOM_OFFSET: $PlacementModifierType<$RandomOffsetPlacement>;
        readonly RARITY_FILTER: $PlacementModifierType<$RarityFilter>;
        readonly SURFACE_RELATIVE_THRESHOLD_FILTER: $PlacementModifierType<$SurfaceRelativeThresholdFilter>;
        readonly SURFACE_WATER_DEPTH_FILTER: $PlacementModifierType<$SurfaceWaterDepthFilter>;
    };

    export class $BiomeFilter extends $PlacementFilter {
        static CODEC: $MapCodec<$BiomeFilter>;
        static biome(): $BiomeFilter;
        type(): $PlacementModifierType<any>;
    }

    export class $BlockPredicateFilter extends $PlacementFilter {
        static CODEC: $MapCodec<$BlockPredicateFilter>;
        static forPredicate(arg0: $BlockPredicate): $BlockPredicateFilter;
        type(): $PlacementModifierType<any>;
    }

    export class $CarvingMaskPlacement extends $PlacementModifier {
        static CODEC: $MapCodec<$CarvingMaskPlacement>;
        static forStep(arg0: $GenerationStep$Carving_): $CarvingMaskPlacement;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $CountOnEveryLayerPlacement extends $PlacementModifier {
        static CODEC: $MapCodec<$CountOnEveryLayerPlacement>;
        static of(arg0: number): $CountOnEveryLayerPlacement;
        static of(arg0: $IntProvider): $CountOnEveryLayerPlacement;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $CountPlacement extends $RepeatingPlacement {
        static CODEC: $MapCodec<$CountPlacement>;
        static of(arg0: number): $CountPlacement;
        static of(arg0: $IntProvider): $CountPlacement;
        type(): $PlacementModifierType<any>;
    }

    export class $EnvironmentScanPlacement extends $PlacementModifier {
        static CODEC: $MapCodec<$EnvironmentScanPlacement>;
        static scanningFor(arg0: $Direction_, arg1: $BlockPredicate, arg2: number): $EnvironmentScanPlacement;
        static scanningFor(arg0: $Direction_, arg1: $BlockPredicate, arg2: $BlockPredicate, arg3: number): $EnvironmentScanPlacement;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $FixedPlacement extends $PlacementModifier {
        static CODEC: $MapCodec<$FixedPlacement>;
        static of(arg0?: $BlockPos_[]): $FixedPlacement;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $HeightRangePlacement extends $PlacementModifier {
        static CODEC: $MapCodec<$HeightRangePlacement>;
        static of(arg0: $HeightProvider): $HeightRangePlacement;
        static triangle(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>): $HeightRangePlacement;
        static uniform(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>): $HeightRangePlacement;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $HeightmapPlacement extends $PlacementModifier {
        static CODEC: $MapCodec<$HeightmapPlacement>;
        static onHeightmap(arg0: $Heightmap$Types_): $HeightmapPlacement;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $InSquarePlacement extends $PlacementModifier {
        constructor();
        static CODEC: $MapCodec<$InSquarePlacement>;
        static spread(): $InSquarePlacement;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $NoiseBasedCountPlacement extends $RepeatingPlacement {
        static CODEC: $MapCodec<$NoiseBasedCountPlacement>;
        static of(arg0: number, arg1: number, arg2: number): $NoiseBasedCountPlacement;
        type(): $PlacementModifierType<any>;
    }

    export class $NoiseThresholdCountPlacement extends $RepeatingPlacement {
        static CODEC: $MapCodec<$NoiseThresholdCountPlacement>;
        static of(arg0: number, arg1: number, arg2: number): $NoiseThresholdCountPlacement;
        type(): $PlacementModifierType<any>;
    }

    export class $RandomOffsetPlacement extends $PlacementModifier {
        static CODEC: $MapCodec<$RandomOffsetPlacement>;
        static horizontal(arg0: $IntProvider): $RandomOffsetPlacement;
        static of(arg0: $IntProvider, arg1: $IntProvider): $RandomOffsetPlacement;
        static vertical(arg0: $IntProvider): $RandomOffsetPlacement;
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
        type(): $PlacementModifierType<any>;
    }

    export class $RarityFilter extends $PlacementFilter {
        static CODEC: $MapCodec<$RarityFilter>;
        static onAverageOnceEvery(arg0: number): $RarityFilter;
        type(): $PlacementModifierType<any>;
    }

    export class $SurfaceRelativeThresholdFilter extends $PlacementFilter {
        static CODEC: $MapCodec<$SurfaceRelativeThresholdFilter>;
        static of(arg0: $Heightmap$Types_, arg1: number, arg2: number): $SurfaceRelativeThresholdFilter;
        type(): $PlacementModifierType<any>;
    }

    export class $SurfaceWaterDepthFilter extends $PlacementFilter {
        static CODEC: $MapCodec<$SurfaceWaterDepthFilter>;
        static forMaxDepth(arg0: number): $SurfaceWaterDepthFilter;
        type(): $PlacementModifierType<any>;
    }

    export class $PlacementFilter extends $PlacementModifier {
        constructor();
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
    }

    export class $RepeatingPlacement extends $PlacementModifier {
        constructor();
        getPositions(arg0: $PlacementContext, arg1: $RandomSource, arg2: $BlockPos_): $Stream<$BlockPos>;
    }

    export type $CaveSurface_ = $CaveSurface | "CEILING" | "FLOOR";
    export type $PlacementModifierType_<Host0 extends $PlacementModifier = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($PlacementModifierType<Host0> & { readonly [Symbol.hasInstance]?: never });
}
