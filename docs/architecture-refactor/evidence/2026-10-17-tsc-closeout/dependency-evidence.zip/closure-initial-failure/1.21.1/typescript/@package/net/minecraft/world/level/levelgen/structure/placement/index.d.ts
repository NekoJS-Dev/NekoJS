import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $HolderSet, $Holder_, $Vec3i } from "java:net/minecraft/core";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $Biome } from "java:net/minecraft/world/level/biome";
import { $ChunkGeneratorStructureState } from "java:net/minecraft/world/level/chunk";
import { $StructureSet } from "java:net/minecraft/world/level/levelgen/structure";

declare module "java:net/minecraft/world/level/levelgen/structure/placement" {
    export class $ConcentricRingsStructurePlacement extends $StructurePlacement {
        constructor(arg0: number, arg1: number, arg2: number, arg3: $HolderSet<$Biome>);
        constructor(arg0: $Vec3i, arg1: $StructurePlacement$FrequencyReductionMethod_, arg2: number, arg3: number, arg4: $Optional<$StructurePlacement$ExclusionZone>, arg5: number, arg6: number, arg7: number, arg8: $HolderSet<$Biome>);
        static CODEC: $MapCodec<$ConcentricRingsStructurePlacement>;
        count(): number;
        distance(): number;
        preferredBiomes(): $HolderSet<$Biome>;
        spread(): number;
        type(): $StructurePlacementType<any>;
    }

    export class $RandomSpreadStructurePlacement extends $StructurePlacement {
        constructor(arg0: number, arg1: number, arg2: $RandomSpreadType_, arg3: number);
        constructor(arg0: $Vec3i, arg1: $StructurePlacement$FrequencyReductionMethod_, arg2: number, arg3: number, arg4: $Optional<$StructurePlacement$ExclusionZone>, arg5: number, arg6: number, arg7: $RandomSpreadType_);
        static CODEC: $MapCodec<$RandomSpreadStructurePlacement>;
        getPotentialStructureChunk(arg0: number, arg1: number, arg2: number): $ChunkPos;
        separation(): number;
        spacing(): number;
        spreadType(): $RandomSpreadType;
        type(): $StructurePlacementType<any>;
    }

    export class $StructurePlacement {
        static CODEC: $Codec<$StructurePlacement>;
        applyAdditionalChunkRestrictions(arg0: number, arg1: number, arg2: number): boolean;
        applyInteractionsWithOtherStructures(arg0: $ChunkGeneratorStructureState, arg1: number, arg2: number): boolean;
        getLocatePos(arg0: $ChunkPos): $BlockPos;
        isStructureChunk(arg0: $ChunkGeneratorStructureState, arg1: number, arg2: number): boolean;
        type(): $StructurePlacementType<any>;
    }

    export class $StructurePlacement$ExclusionZone extends $Record {
        constructor(arg0: $Holder_<$StructureSet>, arg1: number);
        static CODEC: $Codec<$StructurePlacement$ExclusionZone>;
        chunkCount(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        otherSet(): $Holder<$StructureSet>;
        toString(): string;
    }

    export class $StructurePlacement$FrequencyReductionMethod {
        static DEFAULT: $StructurePlacement$FrequencyReductionMethod;
        static LEGACY_TYPE_1: $StructurePlacement$FrequencyReductionMethod;
        static LEGACY_TYPE_2: $StructurePlacement$FrequencyReductionMethod;
        static LEGACY_TYPE_3: $StructurePlacement$FrequencyReductionMethod;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StructurePlacement$FrequencyReductionMethod[];
        static valueOf(name: string): $StructurePlacement$FrequencyReductionMethod;
    }
    export interface $StructurePlacement$FrequencyReductionMethod extends $Enum<$StructurePlacement$FrequencyReductionMethod> {}

    export interface $StructurePlacementType<SP extends $StructurePlacement> {
        codec(): $MapCodec<SP>;
    }
    export const $StructurePlacementType: {
        readonly CONCENTRIC_RINGS: $StructurePlacementType<$ConcentricRingsStructurePlacement>;
        readonly RANDOM_SPREAD: $StructurePlacementType<$RandomSpreadStructurePlacement>;
    };

    export class $RandomSpreadType {
        static LINEAR: $RandomSpreadType;
        static TRIANGULAR: $RandomSpreadType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RandomSpreadType[];
        static valueOf(name: string): $RandomSpreadType;
    }
    export interface $RandomSpreadType extends $Enum<$RandomSpreadType> {}

    export type $StructurePlacement$FrequencyReductionMethod_ = $StructurePlacement$FrequencyReductionMethod | "DEFAULT" | "LEGACY_TYPE_1" | "LEGACY_TYPE_2" | "LEGACY_TYPE_3";
    export type $StructurePlacementType_<Host0 extends $StructurePlacement = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($StructurePlacementType<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $RandomSpreadType_ = $RandomSpreadType | "LINEAR" | "TRIANGULAR";
}
