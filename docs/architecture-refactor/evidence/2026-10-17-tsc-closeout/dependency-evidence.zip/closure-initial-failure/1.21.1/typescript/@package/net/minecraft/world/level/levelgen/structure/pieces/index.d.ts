import type { RegistryTypes } from "@special/types";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Record } from "java:java/lang";
import { $List } from "java:java/util";
import { $BlockPos, $BlockPos_, $RegistryAccess } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $ListTag, $Tag } from "java:net/minecraft/nbt";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $ResourceManager } from "java:net/minecraft/server/packs/resources";
import { $RandomSource } from "java:net/minecraft/util";
import { $BoundingBox, $StructurePiece, $StructurePieceAccessor } from "java:net/minecraft/world/level/levelgen/structure";
import { $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";

declare module "java:net/minecraft/world/level/levelgen/structure/pieces" {
    export class $PiecesContainer extends $Record {
        constructor(arg0: $StructurePiece[]);
        get empty(): boolean;
        isEmpty(): boolean;
        static load(arg0: $ListTag, arg1: $StructurePieceSerializationContext): $PiecesContainer;
        calculateBoundingBox(): $BoundingBox;
        equals(arg0: object): boolean;
        hashCode(): number;
        isInsidePiece(arg0: $BlockPos_): boolean;
        pieces(): $List<$StructurePiece>;
        save(arg0: $StructurePieceSerializationContext): $Tag;
        toString(): string;
    }

    export class $StructurePieceSerializationContext extends $Record {
        constructor(arg0: $ResourceManager, arg1: $RegistryAccess, arg2: $StructureTemplateManager);
        static fromLevel(arg0: $ServerLevel): $StructurePieceSerializationContext;
        equals(arg0: object): boolean;
        hashCode(): number;
        registryAccess(): $RegistryAccess;
        resourceManager(): $ResourceManager;
        structureTemplateManager(): $StructureTemplateManager;
        toString(): string;
    }

    export interface $StructurePieceType {
        load(arg0: $StructurePieceSerializationContext, arg1: $CompoundTag_): $StructurePiece;
    }
    export const $StructurePieceType: {
        readonly BURIED_TREASURE_PIECE: $StructurePieceType;
        readonly DESERT_PYRAMID_PIECE: $StructurePieceType;
        readonly END_CITY_PIECE: $StructurePieceType;
        readonly IGLOO: $StructurePieceType;
        readonly JIGSAW: $StructurePieceType;
        readonly JUNGLE_PYRAMID_PIECE: $StructurePieceType;
        readonly MINE_SHAFT_CORRIDOR: $StructurePieceType;
        readonly MINE_SHAFT_CROSSING: $StructurePieceType;
        readonly MINE_SHAFT_ROOM: $StructurePieceType;
        readonly MINE_SHAFT_STAIRS: $StructurePieceType;
        readonly NETHER_FORTRESS_BRIDGE_CROSSING: $StructurePieceType;
        readonly NETHER_FORTRESS_BRIDGE_END_FILLER: $StructurePieceType;
        readonly NETHER_FORTRESS_BRIDGE_STRAIGHT: $StructurePieceType;
        readonly NETHER_FORTRESS_CASTLE_CORRIDOR_STAIRS: $StructurePieceType;
        readonly NETHER_FORTRESS_CASTLE_CORRIDOR_T_BALCONY: $StructurePieceType;
        readonly NETHER_FORTRESS_CASTLE_ENTRANCE: $StructurePieceType;
        readonly NETHER_FORTRESS_CASTLE_SMALL_CORRIDOR: $StructurePieceType;
        readonly NETHER_FORTRESS_CASTLE_SMALL_CORRIDOR_CROSSING: $StructurePieceType;
        readonly NETHER_FORTRESS_CASTLE_SMALL_CORRIDOR_LEFT_TURN: $StructurePieceType;
        readonly NETHER_FORTRESS_CASTLE_SMALL_CORRIDOR_RIGHT_TURN: $StructurePieceType;
        readonly NETHER_FORTRESS_CASTLE_STALK_ROOM: $StructurePieceType;
        readonly NETHER_FORTRESS_MONSTER_THRONE: $StructurePieceType;
        readonly NETHER_FORTRESS_ROOM_CROSSING: $StructurePieceType;
        readonly NETHER_FORTRESS_STAIRS_ROOM: $StructurePieceType;
        readonly NETHER_FORTRESS_START: $StructurePieceType;
        readonly NETHER_FOSSIL: $StructurePieceType;
        readonly OCEAN_MONUMENT_BUILDING: $StructurePieceType;
        readonly OCEAN_MONUMENT_CORE_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_DOUBLE_XY_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_DOUBLE_X_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_DOUBLE_YZ_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_DOUBLE_Y_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_DOUBLE_Z_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_ENTRY_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_PENTHOUSE: $StructurePieceType;
        readonly OCEAN_MONUMENT_SIMPLE_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_SIMPLE_TOP_ROOM: $StructurePieceType;
        readonly OCEAN_MONUMENT_WING_ROOM: $StructurePieceType;
        readonly OCEAN_RUIN: $StructurePieceType;
        readonly RUINED_PORTAL: $StructurePieceType;
        readonly SHIPWRECK_PIECE: $StructurePieceType;
        readonly STRONGHOLD_CHEST_CORRIDOR: $StructurePieceType;
        readonly STRONGHOLD_FILLER_CORRIDOR: $StructurePieceType;
        readonly STRONGHOLD_FIVE_CROSSING: $StructurePieceType;
        readonly STRONGHOLD_LEFT_TURN: $StructurePieceType;
        readonly STRONGHOLD_LIBRARY: $StructurePieceType;
        readonly STRONGHOLD_PORTAL_ROOM: $StructurePieceType;
        readonly STRONGHOLD_PRISON_HALL: $StructurePieceType;
        readonly STRONGHOLD_RIGHT_TURN: $StructurePieceType;
        readonly STRONGHOLD_ROOM_CROSSING: $StructurePieceType;
        readonly STRONGHOLD_STAIRS_DOWN: $StructurePieceType;
        readonly STRONGHOLD_START: $StructurePieceType;
        readonly STRONGHOLD_STRAIGHT: $StructurePieceType;
        readonly STRONGHOLD_STRAIGHT_STAIRS_DOWN: $StructurePieceType;
        readonly SWAMPLAND_HUT: $StructurePieceType;
        readonly WOODLAND_MANSION_PIECE: $StructurePieceType;
    };

    export class $StructurePiecesBuilder implements $StructurePieceAccessor {
        constructor();
        get boundingBox(): $BoundingBox;
        getBoundingBox(): $BoundingBox;
        get empty(): boolean;
        isEmpty(): boolean;
        addPiece(arg0: $StructurePiece): void;
        build(): $PiecesContainer;
        clear(): void;
        findCollisionPiece(arg0: $BoundingBox): $StructurePiece;
        moveBelowSeaLevel(arg0: number, arg1: number, arg2: $RandomSource, arg3: number): number;
        moveInsideHeights(arg0: $RandomSource, arg1: number, arg2: number): void;
        offsetPiecesVertically(arg0: number): void;
    }

    export type $StructurePieceType_ = $StructurePieceType | RegistryTypes.StructurePieceType | $NekoId | string;
}
