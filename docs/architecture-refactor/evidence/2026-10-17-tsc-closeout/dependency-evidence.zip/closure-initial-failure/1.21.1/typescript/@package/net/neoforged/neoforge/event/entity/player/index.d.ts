import { $Enum } from "java:java/lang";
import { $List } from "java:java/util";
import { $AdvancementHolder } from "java:net/minecraft/advancements";
import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $Container, $InteractionHand, $InteractionHand_, $InteractionResult, $InteractionResult_ } from "java:net/minecraft/world";
import { $Entity } from "java:net/minecraft/world/entity";
import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $AbstractContainerMenu } from "java:net/minecraft/world/inventory";
import { $Item$TooltipContext, $ItemStack, $ItemStack_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $Level } from "java:net/minecraft/world/level";
import { $BlockHitResult } from "java:net/minecraft/world/phys";
import { $Event, $ICancellableEvent } from "java:net/neoforged/bus/api";
import { $LogicalSide, $LogicalSide_ } from "java:net/neoforged/fml";
import { $TriState, $TriState_ } from "java:net/neoforged/neoforge/common/util";
import { $LivingEvent } from "java:net/neoforged/neoforge/event/entity/living";

declare module "java:net/neoforged/neoforge/event/entity/player" {
    export class $AdvancementEvent extends $PlayerEvent {
        constructor(arg0: $Player, arg1: $AdvancementHolder);
        get advancement(): $AdvancementHolder;
        getAdvancement(): $AdvancementHolder;
    }

    export class $AdvancementEvent$AdvancementEarnEvent extends $AdvancementEvent {
        constructor(arg0: $Player, arg1: $AdvancementHolder);
    }

    export class $ItemEntityPickupEvent extends $Event {
        constructor(arg0: $Player, arg1: $ItemEntity);
        get itemEntity(): $ItemEntity;
        getItemEntity(): $ItemEntity;
        get player(): $Player;
        getPlayer(): $Player;
    }

    export class $ItemEntityPickupEvent$Post extends $ItemEntityPickupEvent {
        constructor(arg0: $Player, arg1: $ItemEntity, arg2: $ItemStack_);
        get currentStack(): $ItemStack;
        getCurrentStack(): $ItemStack;
        get originalStack(): $ItemStack;
        getOriginalStack(): $ItemStack;
    }

    export class $ItemEntityPickupEvent$Pre extends $ItemEntityPickupEvent {
        constructor(arg0: $Player, arg1: $ItemEntity);
        canPickup(): $TriState;
        setCanPickup(arg0: $TriState_): void;
    }

    export class $ItemTooltipEvent extends $PlayerEvent {
        constructor(arg0: $ItemStack_, arg1: $Player, arg2: $Component_[], arg3: $TooltipFlag, arg4: $Item$TooltipContext);
        get context(): $Item$TooltipContext;
        getContext(): $Item$TooltipContext;
        get entity(): $Player;
        getEntity(): $Player;
        get flags(): $TooltipFlag;
        getFlags(): $TooltipFlag;
        get itemStack(): $ItemStack;
        getItemStack(): $ItemStack;
        get toolTip(): $List<$Component>;
        getToolTip(): $List<$Component>;
    }

    export class $PlayerContainerEvent extends $PlayerEvent {
        constructor(arg0: $Player, arg1: $AbstractContainerMenu);
        get container(): $AbstractContainerMenu;
        getContainer(): $AbstractContainerMenu;
    }

    export class $PlayerContainerEvent$Close extends $PlayerContainerEvent {
        constructor(arg0: $Player, arg1: $AbstractContainerMenu);
    }

    export class $PlayerContainerEvent$Open extends $PlayerContainerEvent {
        constructor(arg0: $Player, arg1: $AbstractContainerMenu);
    }

    export class $PlayerDestroyItemEvent extends $PlayerEvent {
        constructor(arg0: $Player, arg1: $ItemStack_, arg2: $InteractionHand_);
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get original(): $ItemStack;
        getOriginal(): $ItemStack;
    }

    export class $PlayerEvent extends $LivingEvent {
        constructor(arg0: $Player);
        get entity(): $Player;
        getEntity(): $Player;
    }

    export class $PlayerEvent$Clone extends $PlayerEvent {
        constructor(arg0: $Player, arg1: $Player, arg2: boolean);
        get entity(): $Player;
        getEntity(): $Player;
        get original(): $Player;
        getOriginal(): $Player;
        get wasDeath(): boolean;
        isWasDeath(): boolean;
    }

    export class $PlayerEvent$ItemCraftedEvent extends $PlayerEvent {
        constructor(arg0: $Player, arg1: $ItemStack_, arg2: $Container);
        get crafting(): $ItemStack;
        getCrafting(): $ItemStack;
        get entity(): $Player;
        getEntity(): $Player;
        get inventory(): $Container;
        getInventory(): $Container;
    }

    export class $PlayerEvent$ItemSmeltedEvent extends $PlayerEvent {
        constructor(arg0: $Player, arg1: $ItemStack_);
        get entity(): $Player;
        getEntity(): $Player;
        get smelting(): $ItemStack;
        getSmelting(): $ItemStack;
    }

    export class $PlayerEvent$PlayerChangedDimensionEvent extends $PlayerEvent {
        constructor(arg0: $Player, arg1: $ResourceKey<$Level>, arg2: $ResourceKey<$Level>);
        get entity(): $Player;
        getEntity(): $Player;
        get from(): $ResourceKey<$Level>;
        getFrom(): $ResourceKey<$Level>;
        get to(): $ResourceKey<$Level>;
        getTo(): $ResourceKey<$Level>;
    }

    export class $PlayerEvent$PlayerLoggedInEvent extends $PlayerEvent {
        constructor(arg0: $Player);
        get entity(): $Player;
        getEntity(): $Player;
    }

    export class $PlayerEvent$PlayerLoggedOutEvent extends $PlayerEvent {
        constructor(arg0: $Player);
        get entity(): $Player;
        getEntity(): $Player;
    }

    export class $PlayerEvent$PlayerRespawnEvent extends $PlayerEvent {
        constructor(arg0: $Player, arg1: boolean);
        get entity(): $Player;
        getEntity(): $Player;
        get endConquered(): boolean;
        isEndConquered(): boolean;
    }

    export class $PlayerInteractEvent extends $PlayerEvent {
        get face(): $Direction;
        getFace(): $Direction;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get itemStack(): $ItemStack;
        getItemStack(): $ItemStack;
        get level(): $Level;
        getLevel(): $Level;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get side(): $LogicalSide;
        getSide(): $LogicalSide;
    }

    export class $PlayerInteractEvent$EntityInteract extends $PlayerInteractEvent implements $ICancellableEvent {
        constructor(arg0: $Player, arg1: $InteractionHand_, arg2: $Entity);
        get cancellationResult(): $InteractionResult;
        getCancellationResult(): $InteractionResult;
        set cancellationResult(value: $InteractionResult_);
        get target(): $Entity;
        getTarget(): $Entity;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
        setCancellationResult(arg0: $InteractionResult_): void;
    }

    export class $PlayerInteractEvent$LeftClickBlock extends $PlayerInteractEvent implements $ICancellableEvent {
        constructor(arg0: $Player, arg1: $BlockPos_, arg2: $Direction_, arg3: $PlayerInteractEvent$LeftClickBlock$Action_);
        get action(): $PlayerInteractEvent$LeftClickBlock$Action;
        getAction(): $PlayerInteractEvent$LeftClickBlock$Action;
        get useBlock(): $TriState;
        getUseBlock(): $TriState;
        set useBlock(value: $TriState_);
        get useItem(): $TriState;
        getUseItem(): $TriState;
        set useItem(value: $TriState_);
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
        setUseBlock(arg0: $TriState_): void;
        setUseItem(arg0: $TriState_): void;
    }

    export class $PlayerInteractEvent$LeftClickBlock$Action {
        static ABORT: $PlayerInteractEvent$LeftClickBlock$Action;
        static CLIENT_HOLD: $PlayerInteractEvent$LeftClickBlock$Action;
        static START: $PlayerInteractEvent$LeftClickBlock$Action;
        static STOP: $PlayerInteractEvent$LeftClickBlock$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PlayerInteractEvent$LeftClickBlock$Action[];
        static valueOf(name: string): $PlayerInteractEvent$LeftClickBlock$Action;
    }
    export interface $PlayerInteractEvent$LeftClickBlock$Action extends $Enum<$PlayerInteractEvent$LeftClickBlock$Action> {}

    export class $PlayerInteractEvent$RightClickBlock extends $PlayerInteractEvent implements $ICancellableEvent {
        constructor(arg0: $Player, arg1: $InteractionHand_, arg2: $BlockPos_, arg3: $BlockHitResult);
        get cancellationResult(): $InteractionResult;
        getCancellationResult(): $InteractionResult;
        set cancellationResult(value: $InteractionResult_);
        get hitVec(): $BlockHitResult;
        getHitVec(): $BlockHitResult;
        get useBlock(): $TriState;
        getUseBlock(): $TriState;
        set useBlock(value: $TriState_);
        get useItem(): $TriState;
        getUseItem(): $TriState;
        set useItem(value: $TriState_);
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
        setCancellationResult(arg0: $InteractionResult_): void;
        setUseBlock(arg0: $TriState_): void;
        setUseItem(arg0: $TriState_): void;
    }

    export class $PlayerInteractEvent$RightClickItem extends $PlayerInteractEvent implements $ICancellableEvent {
        constructor(arg0: $Player, arg1: $InteractionHand_);
        get cancellationResult(): $InteractionResult;
        getCancellationResult(): $InteractionResult;
        set cancellationResult(value: $InteractionResult_);
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
        setCancellationResult(arg0: $InteractionResult_): void;
    }

    export type $PlayerInteractEvent$LeftClickBlock$Action_ = $PlayerInteractEvent$LeftClickBlock$Action | "ABORT" | "CLIENT_HOLD" | "START" | "STOP";
}
