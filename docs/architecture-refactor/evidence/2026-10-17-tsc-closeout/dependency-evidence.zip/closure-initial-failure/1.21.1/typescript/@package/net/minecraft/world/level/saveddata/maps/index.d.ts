import type { RegistryTypes } from "@special/types";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $ByteBuf } from "java:io/netty/buffer";
import { $File } from "java:java/io";
import { $Iterable, $Record } from "java:java/lang";
import { $Collection, $List, $Optional } from "java:java/util";
import { $BlockPos, $BlockPos_, $Holder, $HolderLookup$Provider, $Holder_ } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $DyeColor, $DyeColor_, $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $BlockGetter, $Level, $LevelAccessor } from "java:net/minecraft/world/level";
import { $SavedData, $SavedData$Factory } from "java:net/minecraft/world/level/saveddata";

declare module "java:net/minecraft/world/level/saveddata/maps" {
    export class $MapBanner extends $Record {
        constructor(arg0: $BlockPos_, arg1: $DyeColor_, arg2: $Optional<$Component>);
        static CODEC: $Codec<$MapBanner>;
        static LIST_CODEC: $Codec<$List<$MapBanner>>;
        get decoration(): $Holder<$MapDecorationType>;
        getDecoration(): $Holder<$MapDecorationType>;
        get id(): string;
        getId(): string;
        static fromWorld(arg0: $BlockGetter, arg1: $BlockPos_): $MapBanner;
        color(): $DyeColor;
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        pos(): $BlockPos;
        toString(): string;
    }

    export class $MapDecoration extends $Record {
        constructor(arg0: $Holder_<$MapDecorationType>, arg1: number, arg2: number, arg3: number, arg4: $Optional<$Component>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $MapDecoration>;
        get spriteLocation(): $ResourceLocation;
        getSpriteLocation(): $ResourceLocation;
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): $Optional<$Component>;
        renderOnFrame(): boolean;
        rot(): number;
        toString(): string;
        type(): $Holder<$MapDecorationType>;
        x(): number;
        y(): number;
    }

    export class $MapDecorationType extends $Record {
        constructor(arg0: $ResourceLocation_, arg1: boolean, arg2: number, arg3: boolean, arg4: boolean);
        static CODEC: $Codec<$Holder<$MapDecorationType>>;
        static NO_MAP_COLOR: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$MapDecorationType>>;
        assetId(): $ResourceLocation;
        equals(arg0: object): boolean;
        explorationMapElement(): boolean;
        hasMapColor(): boolean;
        hashCode(): number;
        mapColor(): number;
        showOnItemFrame(): boolean;
        toString(): string;
        trackCount(): boolean;
    }

    export class $MapId extends $Record {
        constructor(arg0: number);
        static CODEC: $Codec<$MapId>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $MapId>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): number;
        key(): string;
        toString(): string;
    }

    export class $MapItemSavedData extends $SavedData {
        static MAX_SCALE: number;
        static TRACKED_DECORATION_LIMIT: number;
        centerX: number;
        centerZ: number;
        colors: number[];
        dimension: $ResourceKey<$Level>;
        locked: boolean;
        scale: number;
        get banners(): $Collection<$MapBanner>;
        getBanners(): $Collection<$MapBanner>;
        get decorations(): $Iterable<$MapDecoration>;
        getDecorations(): $Iterable<$MapDecoration>;
        get explorationMap(): boolean;
        isExplorationMap(): boolean;
        static addTargetDecoration(arg0: $ItemStack_, arg1: $BlockPos_, arg2: string, arg3: $Holder_<$MapDecorationType>): void;
        static createForClient(arg0: number, arg1: boolean, arg2: $ResourceKey<$Level>): $MapItemSavedData;
        static createFresh(arg0: number, arg1: number, arg2: number, arg3: boolean, arg4: boolean, arg5: $ResourceKey<$Level>): $MapItemSavedData;
        static factory(): $SavedData$Factory<$MapItemSavedData>;
        static load(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): $MapItemSavedData;
        addClientSideDecorations(arg0: $MapDecoration[]): void;
        addDecoration(arg0: $Holder_<$MapDecorationType>, arg1: $LevelAccessor, arg2: string, arg3: number, arg4: number, arg5: number, arg6: $Component_): void;
        checkBanners(arg0: $BlockGetter, arg1: number, arg2: number): void;
        getHoldingPlayer(arg0: $Player): $MapItemSavedData$HoldingPlayer;
        getUpdatePacket(arg0: $MapId, arg1: $Player): $Packet<any>;
        isTrackedCountOverLimit(arg0: number): boolean;
        locked(): $MapItemSavedData;
        removeDecoration(arg0: string): void;
        removedFromFrame(arg0: $BlockPos_, arg1: number): void;
        save(arg0: $File, arg1: $HolderLookup$Provider): void;
        save(arg0: $CompoundTag_, arg1: $HolderLookup$Provider): $CompoundTag;
        scaled(): $MapItemSavedData;
        setColor(arg0: number, arg1: number, arg2: number): void;
        tickCarriedBy(arg0: $Player, arg1: $ItemStack_): void;
        toggleBanner(arg0: $LevelAccessor, arg1: $BlockPos_): boolean;
        updateColor(arg0: number, arg1: number, arg2: number): boolean;
    }

    export class $MapItemSavedData$HoldingPlayer {
        player: $Player;
        step: number;
    }

    export type $MapDecorationType_ = $MapDecorationType | RegistryTypes.MapDecorationType | $NekoId | string;
}
