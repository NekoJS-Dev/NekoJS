import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $RandomSource } from "java:net/minecraft/util";
import { $WeightedRandomList } from "java:net/minecraft/util/random";
import { $ChunkPos, $StructureManager, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $MobSpawnSettings$SpawnerData } from "java:net/minecraft/world/level/biome";
import { $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $Heightmap$Types, $Heightmap$Types_ } from "java:net/minecraft/world/level/levelgen";
import { $HeightProvider } from "java:net/minecraft/world/level/levelgen/heightproviders";
import { $BoundingBox, $SinglePieceStructure, $Structure, $Structure$GenerationContext, $Structure$GenerationStub, $Structure$StructureSettings, $StructureType, $StructureType_ } from "java:net/minecraft/world/level/levelgen/structure";
import { $PiecesContainer } from "java:net/minecraft/world/level/levelgen/structure/pieces";
import { $DimensionPadding, $StructureTemplatePool } from "java:net/minecraft/world/level/levelgen/structure/pools";
import { $PoolAliasBinding } from "java:net/minecraft/world/level/levelgen/structure/pools/alias";
import { $LiquidSettings, $LiquidSettings_ } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";

declare module "java:net/minecraft/world/level/levelgen/structure/structures" {
    export class $BuriedTreasureStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$BuriedTreasureStructure>;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $DesertPyramidStructure extends $SinglePieceStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$DesertPyramidStructure>;
        afterPlace(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BoundingBox, arg5: $ChunkPos, arg6: $PiecesContainer): void;
        type(): $StructureType<any>;
    }

    export class $EndCityStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$EndCityStructure>;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $IglooStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$IglooStructure>;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $JigsawStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings, arg1: $Holder_<$StructureTemplatePool>, arg2: number, arg3: $HeightProvider, arg4: boolean);
        constructor(arg0: $Structure$StructureSettings, arg1: $Holder_<$StructureTemplatePool>, arg2: number, arg3: $HeightProvider, arg4: boolean, arg5: $Heightmap$Types_);
        constructor(arg0: $Structure$StructureSettings, arg1: $Holder_<$StructureTemplatePool>, arg2: $Optional<$ResourceLocation>, arg3: number, arg4: $HeightProvider, arg5: boolean, arg6: $Optional<$Heightmap$Types>, arg7: number, arg8: $PoolAliasBinding[], arg9: $DimensionPadding, arg10: $LiquidSettings_);
        static CODEC: $MapCodec<$JigsawStructure>;
        static DEFAULT_DIMENSION_PADDING: $DimensionPadding;
        static DEFAULT_LIQUID_SETTINGS: $LiquidSettings;
        static MAX_DEPTH: number;
        static MAX_TOTAL_STRUCTURE_RANGE: number;
        static MIN_DEPTH: number;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $JungleTempleStructure extends $SinglePieceStructure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$JungleTempleStructure>;
        type(): $StructureType<any>;
    }

    export class $MineshaftStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings, arg1: $MineshaftStructure$Type_);
        static CODEC: $MapCodec<$MineshaftStructure>;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $MineshaftStructure$Type {
        static MESA: $MineshaftStructure$Type;
        static NORMAL: $MineshaftStructure$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MineshaftStructure$Type[];
        static valueOf(name: string): $MineshaftStructure$Type;
    }
    export interface $MineshaftStructure$Type extends $Enum<$MineshaftStructure$Type> {}

    export class $NetherFortressStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$NetherFortressStructure>;
        static FORTRESS_ENEMIES: $WeightedRandomList<$MobSpawnSettings$SpawnerData>;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $NetherFossilStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings, arg1: $HeightProvider);
        static CODEC: $MapCodec<$NetherFossilStructure>;
        height: $HeightProvider;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $OceanMonumentStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$OceanMonumentStructure>;
        static regeneratePiecesAfterLoad(arg0: $ChunkPos, arg1: number, arg2: $PiecesContainer): $PiecesContainer;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $OceanRuinStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings, arg1: $OceanRuinStructure$Type_, arg2: number, arg3: number);
        static CODEC: $MapCodec<$OceanRuinStructure>;
        biomeTemp: $OceanRuinStructure$Type;
        clusterProbability: number;
        largeProbability: number;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $OceanRuinStructure$Type {
        static COLD: $OceanRuinStructure$Type;
        static WARM: $OceanRuinStructure$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $OceanRuinStructure$Type[];
        static valueOf(name: string): $OceanRuinStructure$Type;
    }
    export interface $OceanRuinStructure$Type extends $Enum<$OceanRuinStructure$Type> {}

    export class $RuinedPortalStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings, arg1: $RuinedPortalStructure$Setup[]);
        constructor(arg0: $Structure$StructureSettings, arg1: $RuinedPortalStructure$Setup);
        static CODEC: $MapCodec<$RuinedPortalStructure>;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $RuinedPortalStructure$Setup extends $Record {
        constructor(arg0: $RuinedPortalPiece$VerticalPlacement_, arg1: number, arg2: number, arg3: boolean, arg4: boolean, arg5: boolean, arg6: boolean, arg7: number);
        static CODEC: $Codec<$RuinedPortalStructure$Setup>;
        airPocketProbability(): number;
        canBeCold(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        mossiness(): number;
        overgrown(): boolean;
        placement(): $RuinedPortalPiece$VerticalPlacement;
        replaceWithBlackstone(): boolean;
        toString(): string;
        vines(): boolean;
        weight(): number;
    }

    export class $ShipwreckStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings, arg1: boolean);
        static CODEC: $MapCodec<$ShipwreckStructure>;
        isBeached: boolean;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $StrongholdStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$StrongholdStructure>;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $SwampHutStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$SwampHutStructure>;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $WoodlandMansionStructure extends $Structure {
        constructor(arg0: $Structure$StructureSettings);
        static CODEC: $MapCodec<$WoodlandMansionStructure>;
        afterPlace(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkGenerator, arg3: $RandomSource, arg4: $BoundingBox, arg5: $ChunkPos, arg6: $PiecesContainer): void;
        findGenerationPoint(arg0: $Structure$GenerationContext): $Optional<$Structure$GenerationStub>;
        type(): $StructureType<any>;
    }

    export class $RuinedPortalPiece$VerticalPlacement {
        static IN_MOUNTAIN: $RuinedPortalPiece$VerticalPlacement;
        static IN_NETHER: $RuinedPortalPiece$VerticalPlacement;
        static ON_LAND_SURFACE: $RuinedPortalPiece$VerticalPlacement;
        static ON_OCEAN_FLOOR: $RuinedPortalPiece$VerticalPlacement;
        static PARTLY_BURIED: $RuinedPortalPiece$VerticalPlacement;
        static UNDERGROUND: $RuinedPortalPiece$VerticalPlacement;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RuinedPortalPiece$VerticalPlacement[];
        static valueOf(name: string): $RuinedPortalPiece$VerticalPlacement;
    }
    export interface $RuinedPortalPiece$VerticalPlacement extends $Enum<$RuinedPortalPiece$VerticalPlacement> {}

    export type $MineshaftStructure$Type_ = $MineshaftStructure$Type | "MESA" | "NORMAL";
    export type $OceanRuinStructure$Type_ = $OceanRuinStructure$Type | "COLD" | "WARM";
    export type $RuinedPortalPiece$VerticalPlacement_ = $RuinedPortalPiece$VerticalPlacement | "IN_MOUNTAIN" | "IN_NETHER" | "ON_LAND_SURFACE" | "ON_OCEAN_FLOOR" | "PARTLY_BURIED" | "UNDERGROUND";
}
