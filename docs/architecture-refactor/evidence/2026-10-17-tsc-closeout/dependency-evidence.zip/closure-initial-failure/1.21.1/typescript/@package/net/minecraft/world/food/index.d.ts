import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $MobEffectInstance } from "java:net/minecraft/world/effect";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";

declare module "java:net/minecraft/world/food" {
    export class $FoodData {
        constructor();
        get exhaustionLevel(): number;
        getExhaustionLevel(): number;
        get foodLevel(): number;
        getFoodLevel(): number;
        set foodLevel(value: number);
        get lastFoodLevel(): number;
        getLastFoodLevel(): number;
        get saturationLevel(): number;
        getSaturationLevel(): number;
        addAdditionalSaveData(arg0: $CompoundTag_): void;
        addExhaustion(arg0: number): void;
        eat(arg0: number, arg1: number): void;
        eat(arg0: $FoodProperties): void;
        needsFood(): boolean;
        readAdditionalSaveData(arg0: $CompoundTag_): void;
        setExhaustion(arg0: number): void;
        setFoodLevel(arg0: number): void;
        setSaturation(arg0: number): void;
        tick(arg0: $Player): void;
    }

    export class $FoodProperties extends $Record {
        constructor(nutrition: number, saturation: number, canAlwaysEat: boolean, eatSeconds: number, usingConvertsTo: $Optional<$ItemStack>, effects: $FoodProperties$PossibleEffect[]);
        static DIRECT_CODEC: $Codec<$FoodProperties>;
        static DIRECT_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FoodProperties>;
        canAlwaysEat(): boolean;
        eatDurationTicks(): number;
        eatSeconds(): number;
        effects(): $List<$FoodProperties$PossibleEffect>;
        equals(arg0: object): boolean;
        hashCode(): number;
        nutrition(): number;
        saturation(): number;
        toString(): string;
        usingConvertsTo(): $Optional<$ItemStack>;
    }

    export class $FoodProperties$PossibleEffect extends $Record {
        constructor(effectSupplier: $Supplier_<$MobEffectInstance, $MobEffectInstance>, probability: number);
        static CODEC: $Codec<$FoodProperties$PossibleEffect>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FoodProperties$PossibleEffect>;
        effectSupplier(): $Supplier<$MobEffectInstance>;
        effect(): $MobEffectInstance;
        equals(arg0: object): boolean;
        hashCode(): number;
        probability(): number;
        toString(): string;
    }

}
