import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $LongSet } from "java:it/unimi/dsi/fastutil/longs";
import { $ShortList } from "java:it/unimi/dsi/fastutil/shorts";
import { $AutoCloseable, $AutoCloseable_, $Enum, $Record } from "java:java/lang";
import { $Collection, $List, $Map, $Map$Entry, $Optional, $Set } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $BiConsumer, $BiConsumer_, $BiPredicate, $BiPredicate_, $BooleanSupplier, $BooleanSupplier_, $Consumer, $Consumer_, $Function, $Function_, $Predicate, $Predicate_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $LongStream, $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Holder, $HolderLookup, $HolderLookup$Provider, $HolderSet, $Holder_, $IdMap, $Registry, $RegistryAccess, $SectionPos } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_, $Tag } from "java:net/minecraft/nbt";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $ClientboundLevelChunkPacketData$BlockEntityTagOutput, $ClientboundLevelChunkPacketData$BlockEntityTagOutput_ } from "java:net/minecraft/network/protocol/game";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $FullChunkStatus, $FullChunkStatus_, $ServerLevel, $WorldGenRegion } from "java:net/minecraft/server/level";
import { $BitStorage } from "java:net/minecraft/util";
import { $WeightedRandomList } from "java:net/minecraft/util/random";
import { $Entity, $MobCategory, $MobCategory_ } from "java:net/minecraft/world/entity";
import { $BlockGetter, $ChunkPos, $ClipBlockStateContext, $ClipContext, $Level, $LevelHeightAccessor, $LightLayer, $LightLayer_, $NoiseColumn, $StructureManager, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Biome, $BiomeGenerationSettings, $BiomeManager, $BiomeManager$NoiseBiomeSource, $BiomeManager$NoiseBiomeSource_, $BiomeResolver, $BiomeResolver_, $BiomeSource, $Climate$Sampler, $MobSpawnSettings$SpawnerData } from "java:net/minecraft/world/level/biome";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_ } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";
import { $GameEventListenerRegistry } from "java:net/minecraft/world/level/gameevent";
import { $BelowZeroRetrogen, $GenerationStep$Carving, $GenerationStep$Carving_, $Heightmap, $Heightmap$Types, $Heightmap$Types_, $NoiseChunk, $RandomState } from "java:net/minecraft/world/level/levelgen";
import { $Blender, $BlendingData } from "java:net/minecraft/world/level/levelgen/blending";
import { $Structure, $StructureSet, $StructureStart } from "java:net/minecraft/world/level/levelgen/structure";
import { $ConcentricRingsStructurePlacement, $StructurePlacement } from "java:net/minecraft/world/level/levelgen/structure/placement";
import { $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";
import { $ChunkSkyLightSources, $LevelLightEngine } from "java:net/minecraft/world/level/lighting";
import { $Fluid, $FluidState, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $AABB, $BlockHitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $VoxelShape } from "java:net/minecraft/world/phys/shapes";
import { $LevelChunkTicks, $ProtoChunkTicks, $SerializableTickContainer, $SerializableTickContainer_, $TickContainerAccess } from "java:net/minecraft/world/ticks";
import { $AttachmentHolder$AsField, $AttachmentType, $IAttachmentHolder } from "java:net/neoforged/neoforge/attachment";
import { $ModelData } from "java:net/neoforged/neoforge/client/model/data";
import { $AuxiliaryLightManager, $LevelChunkAuxiliaryLightManager } from "java:net/neoforged/neoforge/common/world";

export * as status from "java:net/minecraft/world/level/chunk/status";
export * as storage from "java:net/minecraft/world/level/chunk/storage";

declare module "java:net/minecraft/world/level/chunk" {
    export interface $BlockColumn {
        getBlock(arg0: number): $BlockState;
        setBlock(arg0: number, arg1: $BlockState_): void;
    }

    export class $CarvingMask {
        constructor(arg0: number, arg1: number);
        constructor(arg0: number[], arg1: number);
        get(arg0: number, arg1: number, arg2: number): boolean;
        setAdditionalMask(arg0: $CarvingMask$Mask_<number, number, number, boolean>): void;
        set(arg0: number, arg1: number, arg2: number): void;
        stream(arg0: $ChunkPos): $Stream<$BlockPos>;
        toArray(): number[];
    }

    export interface $CarvingMask$Mask {
        test(arg0: number, arg1: number, arg2: number): boolean;
    }

    export class $ChunkAccess implements $BlockGetter, $BiomeManager$NoiseBiomeSource, $LightChunk, $StructureAccess, $IAttachmentHolder {
        constructor(arg0: $ChunkPos, arg1: $UpgradeData, arg2: $LevelHeightAccessor, arg3: $Registry<$Biome>, arg4: number, arg5: $LevelChunkSection[], arg6: $BlendingData);
        static NO_FILLED_SECTION: number;
        get allReferences(): $Map<$Structure, $LongSet>;
        getAllReferences(): $Map<$Structure, $LongSet>;
        set allReferences(value: ($Map<$Structure, $LongSet> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $LongSet>> : never)));
        get allStarts(): $Map<$Structure, $StructureStart>;
        getAllStarts(): $Map<$Structure, $StructureStart>;
        set allStarts(value: ($Map<$Structure, $StructureStart> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $StructureStart>> : never)));
        get attachmentHolder(): $AttachmentHolder$AsField;
        getAttachmentHolder(): $AttachmentHolder$AsField;
        get belowZeroRetrogen(): $BelowZeroRetrogen;
        getBelowZeroRetrogen(): $BelowZeroRetrogen;
        get blendingData(): $BlendingData;
        getBlendingData(): $BlendingData;
        set blendingData(value: $BlendingData);
        get blockEntitiesPos(): $Set<$BlockPos>;
        getBlockEntitiesPos(): $Set<$BlockPos>;
        get blockTicks(): $TickContainerAccess<$Block>;
        getBlockTicks(): $TickContainerAccess<$Block>;
        get fluidTicks(): $TickContainerAccess<$Fluid>;
        getFluidTicks(): $TickContainerAccess<$Fluid>;
        get heightAccessorForGeneration(): $LevelHeightAccessor;
        getHeightAccessorForGeneration(): $LevelHeightAccessor;
        get heightmaps(): $Collection<$Map$Entry<$Heightmap$Types, $Heightmap>>;
        getHeightmaps(): $Collection<$Map$Entry<$Heightmap$Types, $Heightmap>>;
        get height(): number;
        getHeight(): number;
        get highestFilledSectionIndex(): number;
        getHighestFilledSectionIndex(): number;
        get highestGeneratedStatus(): $ChunkStatus;
        getHighestGeneratedStatus(): $ChunkStatus;
        get highestSectionPosition(): number;
        getHighestSectionPosition(): number;
        get inhabitedTime(): number;
        getInhabitedTime(): number;
        set inhabitedTime(value: number);
        get level(): $Level;
        getLevel(): $Level;
        get maxBuildHeight(): number;
        getMaxBuildHeight(): number;
        get maxLightLevel(): number;
        getMaxLightLevel(): number;
        get maxSection(): number;
        getMaxSection(): number;
        get minBuildHeight(): number;
        getMinBuildHeight(): number;
        get minSection(): number;
        getMinSection(): number;
        get persistedStatus(): $ChunkStatus;
        getPersistedStatus(): $ChunkStatus;
        get postProcessing(): $ShortList[];
        getPostProcessing(): $ShortList[];
        get pos(): $ChunkPos;
        getPos(): $ChunkPos;
        get sectionsCount(): number;
        getSectionsCount(): number;
        get sections(): $LevelChunkSection[];
        getSections(): $LevelChunkSection[];
        get skyLightSources(): $ChunkSkyLightSources;
        getSkyLightSources(): $ChunkSkyLightSources;
        get ticksForSerialization(): $ChunkAccess$TicksToSave;
        getTicksForSerialization(): $ChunkAccess$TicksToSave;
        get upgradeData(): $UpgradeData;
        getUpgradeData(): $UpgradeData;
        get lightCorrect(): boolean;
        isLightCorrect(): boolean;
        set lightCorrect(value: boolean);
        get oldNoiseGeneration(): boolean;
        isOldNoiseGeneration(): boolean;
        get unsaved(): boolean;
        isUnsaved(): boolean;
        set unsaved(value: boolean);
        get upgrading(): boolean;
        isUpgrading(): boolean;
        static getOrCreateOffsetList(arg0: $ShortList[], arg1: number): $ShortList;
        addEntity(arg0: $Entity): void;
        addPackedPostProcess(arg0: number, arg1: number): void;
        addReferenceForStructure(arg0: $Structure, arg1: number): void;
        carverBiome(arg0: $Supplier_<$BiomeGenerationSettings, $BiomeGenerationSettings>): $BiomeGenerationSettings;
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        fillBiomesFromNoise(arg0: $BiomeResolver_<number, number, number, $Climate$Sampler, $Holder_<$Biome>>, arg1: $Climate$Sampler): void;
        findBlockLightSources(arg0: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>): void;
        findBlocks(arg0: $BiPredicate_<$BlockState, $BlockPos, $BlockState, $BlockPos, boolean>, arg1: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>): void;
        findBlocks(arg0: $Predicate_<$BlockState, $BlockState, boolean>, arg1: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>): void;
        findBlocks(arg0: $Predicate_<$BlockState, $BlockState, boolean>, arg1: $BiPredicate_<$BlockState, $BlockPos, $BlockState, $BlockPos, boolean>, arg2: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>): void;
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getBlockEntityNbtForSaving(arg0: $BlockPos_, arg1: $HolderLookup$Provider): $CompoundTag;
        getBlockEntityNbt(arg0: $BlockPos_): $CompoundTag;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getLightEmission(arg0: $BlockPos_): number;
        getListenerRegistry(arg0: number): $GameEventListenerRegistry;
        getModelData(arg0: $BlockPos_): $ModelData;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getOrCreateHeightmapUnprimed(arg0: $Heightmap$Types_): $Heightmap;
        getOrCreateNoiseChunk(arg0: $Function_<$ChunkAccess, $NoiseChunk, $ChunkAccess, $NoiseChunk>): $NoiseChunk;
        getReferencesForStructure(arg0: $Structure): $LongSet;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        getSection(arg0: number): $LevelChunkSection;
        getStartForStructure(arg0: $Structure): $StructureStart;
        hasAnyStructureReferences(): boolean;
        hasAttachments(): boolean;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        hasPrimedHeightmap(arg0: $Heightmap$Types_): boolean;
        incrementInhabitedTime(arg0: number): void;
        initializeLightSources(): void;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
        isSectionEmpty(arg0: number): boolean;
        isYSpaceEmpty(arg0: number, arg1: number): boolean;
        markPosForPostprocessing(arg0: $BlockPos_): void;
        readAttachmentsFromNBT(arg0: $HolderLookup$Provider, arg1: $CompoundTag_): void;
        removeBlockEntity(arg0: $BlockPos_): void;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        setAllReferences(arg0: ($Map<$Structure, $LongSet> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $LongSet>> : never))): void;
        setAllStarts(arg0: ($Map<$Structure, $StructureStart> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $StructureStart>> : never))): void;
        setBlendingData(arg0: $BlendingData): void;
        setBlockEntityNbt(arg0: $CompoundTag_): void;
        setBlockEntity(arg0: $BlockEntity): void;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_, arg2: boolean): $BlockState;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        setHeightmap(arg0: $Heightmap$Types_, arg1: number[]): void;
        setInhabitedTime(arg0: number): void;
        setLightCorrect(arg0: boolean): void;
        setStartForStructure(arg0: $Structure, arg1: $StructureStart): void;
        setUnsaved(arg0: boolean): void;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
        writeAttachmentsToNBT(arg0: $HolderLookup$Provider): $CompoundTag;
    }

    export class $ChunkAccess$TicksToSave extends $Record {
        constructor(blocks: $SerializableTickContainer_<$Block, number, $Function<$Block, string>, $Tag>, fluids: $SerializableTickContainer_<$Fluid, number, $Function<$Fluid, string>, $Tag>);
        blocks(): $SerializableTickContainer<$Block>;
        equals(arg0: object): boolean;
        fluids(): $SerializableTickContainer<$Fluid>;
        hashCode(): number;
        toString(): string;
    }

    export class $ChunkGenerator {
        constructor(arg0: $BiomeSource);
        constructor(arg0: $BiomeSource, arg1: $Function_<$Holder<$Biome>, $BiomeGenerationSettings, $Holder<$Biome>, $BiomeGenerationSettings>);
        static CODEC: $Codec<$ChunkGenerator>;
        get biomeSource(): $BiomeSource;
        getBiomeSource(): $BiomeSource;
        get genDepth(): number;
        getGenDepth(): number;
        get minY(): number;
        getMinY(): number;
        get seaLevel(): number;
        getSeaLevel(): number;
        get typeNameForDataFixer(): $Optional<$ResourceKey<$MapCodec<$ChunkGenerator>>>;
        getTypeNameForDataFixer(): $Optional<$ResourceKey<$MapCodec<$ChunkGenerator>>>;
        addDebugScreenInfo(arg0: string[], arg1: $RandomState, arg2: $BlockPos_): void;
        applyBiomeDecoration(arg0: $WorldGenLevel, arg1: $ChunkAccess, arg2: $StructureManager): void;
        applyCarvers(arg0: $WorldGenRegion, arg1: number, arg2: $RandomState, arg3: $BiomeManager, arg4: $StructureManager, arg5: $ChunkAccess, arg6: $GenerationStep$Carving_): void;
        buildSurface(arg0: $WorldGenRegion, arg1: $StructureManager, arg2: $RandomState, arg3: $ChunkAccess): void;
        createBiomes(arg0: $RandomState, arg1: $Blender, arg2: $StructureManager, arg3: $ChunkAccess): $CompletableFuture<$ChunkAccess>;
        createReferences(arg0: $WorldGenLevel, arg1: $StructureManager, arg2: $ChunkAccess): void;
        createState(arg0: $HolderLookup<$StructureSet>, arg1: $RandomState, arg2: number): $ChunkGeneratorStructureState;
        createStructures(arg0: $RegistryAccess, arg1: $ChunkGeneratorStructureState, arg2: $StructureManager, arg3: $ChunkAccess, arg4: $StructureTemplateManager): void;
        fillFromNoise(arg0: $Blender, arg1: $RandomState, arg2: $StructureManager, arg3: $ChunkAccess): $CompletableFuture<$ChunkAccess>;
        findNearestMapStructure(arg0: $ServerLevel, arg1: $HolderSet<$Structure>, arg2: $BlockPos_, arg3: number, arg4: boolean): $Pair<$BlockPos, $Holder<$Structure>>;
        getBaseColumn(arg0: number, arg1: number, arg2: $LevelHeightAccessor, arg3: $RandomState): $NoiseColumn;
        getBaseHeight(arg0: number, arg1: number, arg2: $Heightmap$Types_, arg3: $LevelHeightAccessor, arg4: $RandomState): number;
        getBiomeGenerationSettings(arg0: $Holder_<$Biome>): $BiomeGenerationSettings;
        getFirstFreeHeight(arg0: number, arg1: number, arg2: $Heightmap$Types_, arg3: $LevelHeightAccessor, arg4: $RandomState): number;
        getFirstOccupiedHeight(arg0: number, arg1: number, arg2: $Heightmap$Types_, arg3: $LevelHeightAccessor, arg4: $RandomState): number;
        getMobsAt(arg0: $Holder_<$Biome>, arg1: $StructureManager, arg2: $MobCategory_, arg3: $BlockPos_): $WeightedRandomList<$MobSpawnSettings$SpawnerData>;
        getSpawnHeight(arg0: $LevelHeightAccessor): number;
        refreshFeaturesPerStep(): void;
        spawnOriginalMobs(arg0: $WorldGenRegion): void;
        validate(): void;
    }

    export class $ChunkGeneratorStructureState {
        get levelSeed(): number;
        getLevelSeed(): number;
        static createForFlat(arg0: $RandomState, arg1: number, arg2: $BiomeSource, arg3: $Stream<$Holder<$StructureSet>>): $ChunkGeneratorStructureState;
        static createForNormal(arg0: $RandomState, arg1: number, arg2: $BiomeSource, arg3: $HolderLookup<$StructureSet>): $ChunkGeneratorStructureState;
        ensureStructuresGenerated(): void;
        getPlacementsForStructure(arg0: $Holder_<$Structure>): $List<$StructurePlacement>;
        getRingPositionsFor(arg0: $ConcentricRingsStructurePlacement): $List<$ChunkPos>;
        hasStructureChunkInRange(arg0: $Holder_<$StructureSet>, arg1: number, arg2: number, arg3: number): boolean;
        possibleStructureSets(): $List<$Holder<$StructureSet>>;
        randomState(): $RandomState;
    }

    export class $ChunkSource implements $LightChunkGetter, $AutoCloseable {
        constructor();
        get level(): $BlockGetter;
        getLevel(): $BlockGetter;
        get lightEngine(): $LevelLightEngine;
        getLightEngine(): $LevelLightEngine;
        get loadedChunksCount(): number;
        getLoadedChunksCount(): number;
        close(): void;
        gatherStats(): string;
        getChunkForLighting(arg0: number, arg1: number): $LightChunk;
        getChunkNow(arg0: number, arg1: number): $LevelChunk;
        getChunk(arg0: number, arg1: number, arg2: boolean): $LevelChunk;
        getChunk(arg0: number, arg1: number, arg2: $ChunkStatus_, arg3: boolean): $ChunkAccess;
        hasChunk(arg0: number, arg1: number): boolean;
        onLightUpdate(arg0: $LightLayer_, arg1: $SectionPos): void;
        setSpawnSettings(arg0: boolean, arg1: boolean): void;
        tick(arg0: $BooleanSupplier_<boolean>, arg1: boolean): void;
        updateChunkForced(arg0: $ChunkPos, arg1: boolean): void;
    }

    export class $DataLayer {
        constructor();
        constructor(arg0: number[]);
        constructor(arg0: number);
        static LAYER_COUNT: number;
        static LAYER_SIZE: number;
        static SIZE: number;
        get data(): number[];
        getData(): number[];
        get definitelyHomogenous(): boolean;
        isDefinitelyHomogenous(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        copy(): $DataLayer;
        fill(arg0: number): void;
        get(arg0: number, arg1: number, arg2: number): number;
        isDefinitelyFilledWith(arg0: number): boolean;
        layerToString(arg0: number): string;
        set(arg0: number, arg1: number, arg2: number, arg3: number): void;
        toString(): string;
    }

    export class $ImposterProtoChunk extends $ProtoChunk {
        constructor(arg0: $LevelChunk, arg1: boolean);
        get allReferences(): $Map<$Structure, $LongSet>;
        getAllReferences(): $Map<$Structure, $LongSet>;
        set allReferences(value: ($Map<$Structure, $LongSet> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $LongSet>> : never)));
        get allStarts(): $Map<$Structure, $StructureStart>;
        getAllStarts(): $Map<$Structure, $StructureStart>;
        set allStarts(value: ($Map<$Structure, $StructureStart> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $StructureStart>> : never)));
        get attachmentHolder(): $AttachmentHolder$AsField;
        getAttachmentHolder(): $AttachmentHolder$AsField;
        get blendingData(): $BlendingData;
        getBlendingData(): $BlendingData;
        set blendingData(value: $BlendingData);
        get blockTicks(): $TickContainerAccess<$Block>;
        getBlockTicks(): $TickContainerAccess<$Block>;
        get fluidTicks(): $TickContainerAccess<$Fluid>;
        getFluidTicks(): $TickContainerAccess<$Fluid>;
        get height(): number;
        getHeight(): number;
        get maxBuildHeight(): number;
        getMaxBuildHeight(): number;
        get maxLightLevel(): number;
        getMaxLightLevel(): number;
        get maxSection(): number;
        getMaxSection(): number;
        get minSection(): number;
        getMinSection(): number;
        get persistedStatus(): $ChunkStatus;
        getPersistedStatus(): $ChunkStatus;
        set persistedStatus(value: $ChunkStatus_);
        get pos(): $ChunkPos;
        getPos(): $ChunkPos;
        get sectionsCount(): number;
        getSectionsCount(): number;
        get sections(): $LevelChunkSection[];
        getSections(): $LevelChunkSection[];
        get skyLightSources(): $ChunkSkyLightSources;
        getSkyLightSources(): $ChunkSkyLightSources;
        get ticksForSerialization(): $ChunkAccess$TicksToSave;
        getTicksForSerialization(): $ChunkAccess$TicksToSave;
        get wrapped(): $LevelChunk;
        getWrapped(): $LevelChunk;
        get lightCorrect(): boolean;
        isLightCorrect(): boolean;
        set lightCorrect(value: boolean);
        get unsaved(): boolean;
        isUnsaved(): boolean;
        set unsaved(value: boolean);
        addEntity(arg0: $CompoundTag_): void;
        addEntity(arg0: $Entity): void;
        addReferenceForStructure(arg0: $Structure, arg1: number): void;
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        fillBiomesFromNoise(arg0: $BiomeResolver_<number, number, number, $Climate$Sampler, $Holder_<$Biome>>, arg1: $Climate$Sampler): void;
        findBlocks(arg0: $BiPredicate_<$BlockState, $BlockPos, $BlockState, $BlockPos, boolean>, arg1: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>): void;
        findBlocks(arg0: $Predicate_<$BlockState, $BlockState, boolean>, arg1: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>): void;
        findBlocks(arg0: $Predicate_<$BlockState, $BlockState, boolean>, arg1: $BiPredicate_<$BlockState, $BlockPos, $BlockState, $BlockPos, boolean>, arg2: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>): void;
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getBlockEntityNbtForSaving(arg0: $BlockPos_, arg1: $HolderLookup$Provider): $CompoundTag;
        getBlockEntityNbt(arg0: $BlockPos_): $CompoundTag;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getCarvingMask(arg0: $GenerationStep$Carving_): $CarvingMask;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getHeight(arg0: $Heightmap$Types_, arg1: number, arg2: number): number;
        getLightEmission(arg0: $BlockPos_): number;
        getModelData(arg0: $BlockPos_): $ModelData;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getOrCreateCarvingMask(arg0: $GenerationStep$Carving_): $CarvingMask;
        getOrCreateHeightmapUnprimed(arg0: $Heightmap$Types_): $Heightmap;
        getReferencesForStructure(arg0: $Structure): $LongSet;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        getSection(arg0: number): $LevelChunkSection;
        getStartForStructure(arg0: $Structure): $StructureStart;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        initializeLightSources(): void;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
        markPosForPostprocessing(arg0: $BlockPos_): void;
        removeBlockEntity(arg0: $BlockPos_): void;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        setAllReferences(arg0: ($Map<$Structure, $LongSet> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $LongSet>> : never))): void;
        setAllStarts(arg0: ($Map<$Structure, $StructureStart> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $StructureStart>> : never))): void;
        setBlendingData(arg0: $BlendingData): void;
        setBlockEntityNbt(arg0: $CompoundTag_): void;
        setBlockEntity(arg0: $BlockEntity): void;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_, arg2: boolean): $BlockState;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        setHeightmap(arg0: $Heightmap$Types_, arg1: number[]): void;
        setLightCorrect(arg0: boolean): void;
        setPersistedStatus(arg0: $ChunkStatus_): void;
        setStartForStructure(arg0: $Structure, arg1: $StructureStart): void;
        setUnsaved(arg0: boolean): void;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
    }

    export class $LevelChunk extends $ChunkAccess implements $IAttachmentHolder {
        constructor(arg0: $ServerLevel, arg1: $ProtoChunk, arg2: $LevelChunk$PostLoadProcessor_<$LevelChunk>);
        constructor(arg0: $Level, arg1: $ChunkPos);
        constructor(arg0: $Level, arg1: $ChunkPos, arg2: $UpgradeData, arg3: $LevelChunkTicks<$Block>, arg4: $LevelChunkTicks<$Fluid>, arg5: number, arg6: $LevelChunkSection[], arg7: $LevelChunk$PostLoadProcessor_<$LevelChunk>, arg8: $BlendingData);
        get blockEntities(): $Map<$BlockPos, $BlockEntity>;
        getBlockEntities(): $Map<$BlockPos, $BlockEntity>;
        get blockTicks(): $TickContainerAccess<$Block>;
        getBlockTicks(): $TickContainerAccess<$Block>;
        get fluidTicks(): $TickContainerAccess<$Fluid>;
        getFluidTicks(): $TickContainerAccess<$Fluid>;
        get fullStatus(): $FullChunkStatus;
        getFullStatus(): $FullChunkStatus;
        set fullStatus(value: $Supplier_<$FullChunkStatus, $FullChunkStatus_>);
        get level(): $Level;
        getLevel(): $Level;
        get maxBuildHeight(): number;
        getMaxBuildHeight(): number;
        get maxLightLevel(): number;
        getMaxLightLevel(): number;
        get maxSection(): number;
        getMaxSection(): number;
        get minSection(): number;
        getMinSection(): number;
        get persistedStatus(): $ChunkStatus;
        getPersistedStatus(): $ChunkStatus;
        get sectionsCount(): number;
        getSectionsCount(): number;
        get ticksForSerialization(): $ChunkAccess$TicksToSave;
        getTicksForSerialization(): $ChunkAccess$TicksToSave;
        get empty(): boolean;
        isEmpty(): boolean;
        addAndRegisterBlockEntity(arg0: $BlockEntity): void;
        addEntity(arg0: $Entity): void;
        clearAllBlockEntities(): void;
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $LevelChunkAuxiliaryLightManager;
        getBlockEntityNbtForSaving(arg0: $BlockPos_, arg1: $HolderLookup$Provider): $CompoundTag;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_, arg1: $LevelChunk$EntityCreationType_): $BlockEntity;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        getFluidState(arg0: number, arg1: number, arg2: number): $FluidState;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getLightEmission(arg0: $BlockPos_): number;
        getListenerRegistry(arg0: number): $GameEventListenerRegistry;
        getModelData(arg0: $BlockPos_): $ModelData;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        hasAttachments(): boolean;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
        postProcessGeneration(): void;
        registerAllBlockEntitiesAfterLevelLoad(): void;
        registerTickContainerInLevel(arg0: $ServerLevel): void;
        removeBlockEntity(arg0: $BlockPos_): void;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        replaceBiomes(arg0: $FriendlyByteBuf): void;
        replaceWithPacketData(arg0: $FriendlyByteBuf, arg1: $CompoundTag_, arg2: $Consumer_<$ClientboundLevelChunkPacketData$BlockEntityTagOutput, $ClientboundLevelChunkPacketData$BlockEntityTagOutput>): void;
        runPostLoad(): void;
        setBlockEntity(arg0: $BlockEntity): void;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_, arg2: boolean): $BlockState;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        setFullStatus(arg0: $Supplier_<$FullChunkStatus, $FullChunkStatus_>): void;
        setLoaded(arg0: boolean): void;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
        unpackTicks(arg0: number): void;
        unregisterTickContainerFromLevel(arg0: $ServerLevel): void;
    }

    export class $LevelChunk$EntityCreationType {
        static CHECK: $LevelChunk$EntityCreationType;
        static IMMEDIATE: $LevelChunk$EntityCreationType;
        static QUEUED: $LevelChunk$EntityCreationType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $LevelChunk$EntityCreationType[];
        static valueOf(name: string): $LevelChunk$EntityCreationType;
    }
    export interface $LevelChunk$EntityCreationType extends $Enum<$LevelChunk$EntityCreationType> {}

    export interface $LevelChunk$PostLoadProcessor {
        run(arg0: $LevelChunk): void;
    }

    export class $LevelChunkSection {
        constructor(arg0: $Registry<$Biome>);
        constructor(arg0: $PalettedContainer<$BlockState>, arg1: $PalettedContainerRO<$Holder<$Biome>>);
        static BIOME_CONTAINER_BITS: number;
        static SECTION_HEIGHT: number;
        static SECTION_SIZE: number;
        static SECTION_WIDTH: number;
        get biomes(): $PalettedContainerRO<$Holder<$Biome>>;
        getBiomes(): $PalettedContainerRO<$Holder<$Biome>>;
        get serializedSize(): number;
        getSerializedSize(): number;
        get states(): $PalettedContainer<$BlockState>;
        getStates(): $PalettedContainer<$BlockState>;
        get randomlyTickingBlocks(): boolean;
        isRandomlyTickingBlocks(): boolean;
        get randomlyTickingFluids(): boolean;
        isRandomlyTickingFluids(): boolean;
        get randomlyTicking(): boolean;
        isRandomlyTicking(): boolean;
        acquire(): void;
        fillBiomesFromNoise(arg0: $BiomeResolver_<number, number, number, $Climate$Sampler, $Holder_<$Biome>>, arg1: $Climate$Sampler, arg2: number, arg3: number, arg4: number): void;
        getBlockState(arg0: number, arg1: number, arg2: number): $BlockState;
        getFluidState(arg0: number, arg1: number, arg2: number): $FluidState;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        hasOnlyAir(): boolean;
        maybeHas(arg0: $Predicate_<$BlockState, $BlockState, boolean>): boolean;
        readBiomes(arg0: $FriendlyByteBuf): void;
        read(arg0: $FriendlyByteBuf): void;
        recalcBlockCounts(): void;
        release(): void;
        setBlockState(arg0: number, arg1: number, arg2: number, arg3: $BlockState_, arg4: boolean): $BlockState;
        setBlockState(arg0: number, arg1: number, arg2: number, arg3: $BlockState_): $BlockState;
        write(arg0: $FriendlyByteBuf): void;
    }

    export interface $LightChunk extends $BlockGetter {
        findBlockLightSources(arg0: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>): void;
        getSkyLightSources(): $ChunkSkyLightSources;
    }

    export interface $LightChunkGetter {
        getChunkForLighting(arg0: number, arg1: number): $LightChunk;
        getLevel(): $BlockGetter;
        onLightUpdate(arg0: $LightLayer_, arg1: $SectionPos): void;
    }

    export interface $PaletteResize<T> {
        onResize(arg0: number, arg1: T): number;
    }

    export class $PalettedContainer<T> implements $PaletteResize<T>, $PalettedContainerRO<T> {
        constructor(arg0: $IdMap<T>, arg1: T, arg2: $PalettedContainer$Strategy);
        constructor(arg0: $IdMap<T>, arg1: $PalettedContainer$Strategy, arg2: $PalettedContainer$Configuration<T>, arg3: $BitStorage, arg4: T[]);
        get serializedSize(): number;
        getSerializedSize(): number;
        static codecRO<T>(arg0: $IdMap<T>, arg1: $Codec<T>, arg2: $PalettedContainer$Strategy, arg3: T): $Codec<$PalettedContainerRO<T>>;
        static codecRW<T>(arg0: $IdMap<T>, arg1: $Codec<T>, arg2: $PalettedContainer$Strategy, arg3: T): $Codec<$PalettedContainer<T>>;
        acquire(): void;
        copy(): $PalettedContainer<T>;
        count(arg0: $PalettedContainer$CountConsumer_<T, T, number>): void;
        getAll(arg0: $Consumer_<T, T>): void;
        getAndSetUnchecked(arg0: number, arg1: number, arg2: number, arg3: T): T;
        getAndSet(arg0: number, arg1: number, arg2: number, arg3: T): T;
        get(arg0: number, arg1: number, arg2: number): T;
        maybeHas(arg0: $Predicate_<T, T, boolean>): boolean;
        onResize(arg0: number, arg1: T): number;
        pack(arg0: $IdMap<T>, arg1: $PalettedContainer$Strategy): $PalettedContainerRO$PackedData<T>;
        read(arg0: $FriendlyByteBuf): void;
        recreate(): $PalettedContainer<T>;
        release(): void;
        set(arg0: number, arg1: number, arg2: number, arg3: T): void;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $PalettedContainer$Configuration<T> extends $Record {
        bits(): number;
        createData(arg0: $IdMap<T>, arg1: $PaletteResize_<T, number, T, number>, arg2: number): $PalettedContainer$Data<T>;
        equals(arg0: object): boolean;
        factory(): $Palette$Factory;
        hashCode(): number;
        toString(): string;
    }

    export interface $PalettedContainer$CountConsumer<T> {
        accept(arg0: T, arg1: number): void;
    }

    export class $PalettedContainer$Strategy {
        static HASHMAP_PALETTE_FACTORY: $Palette$Factory;
        static LINEAR_PALETTE_FACTORY: $Palette$Factory;
        static SECTION_BIOMES: $PalettedContainer$Strategy;
        static SECTION_STATES: $PalettedContainer$Strategy;
        static SINGLE_VALUE_PALETTE_FACTORY: $Palette$Factory;
        getConfiguration<A>(arg0: $IdMap<A>, arg1: number): $PalettedContainer$Configuration<A>;
        getIndex(arg0: number, arg1: number, arg2: number): number;
        size(): number;
    }

    export interface $PalettedContainerRO<T> {
        count(arg0: $PalettedContainer$CountConsumer_<T, T, number>): void;
        getAll(arg0: $Consumer_<T, T>): void;
        getSerializedSize(): number;
        get(arg0: number, arg1: number, arg2: number): T;
        maybeHas(arg0: $Predicate_<T, T, boolean>): boolean;
        pack(arg0: $IdMap<T>, arg1: $PalettedContainer$Strategy): $PalettedContainerRO$PackedData<T>;
        recreate(): $PalettedContainer<T>;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $PalettedContainerRO$PackedData<T> extends $Record {
        constructor(arg0: T[], arg1: $Optional<$LongStream>);
        equals(arg0: object): boolean;
        hashCode(): number;
        paletteEntries(): $List<T>;
        storage(): $Optional<$LongStream>;
        toString(): string;
    }

    export class $ProtoChunk extends $ChunkAccess {
        constructor(arg0: $ChunkPos, arg1: $UpgradeData, arg2: $LevelHeightAccessor, arg3: $Registry<$Biome>, arg4: $BlendingData);
        constructor(arg0: $ChunkPos, arg1: $UpgradeData, arg2: $LevelChunkSection[], arg3: $ProtoChunkTicks<$Block>, arg4: $ProtoChunkTicks<$Fluid>, arg5: $LevelHeightAccessor, arg6: $Registry<$Biome>, arg7: $BlendingData);
        get belowZeroRetrogen(): $BelowZeroRetrogen;
        getBelowZeroRetrogen(): $BelowZeroRetrogen;
        set belowZeroRetrogen(value: $BelowZeroRetrogen);
        get blockEntities(): $Map<$BlockPos, $BlockEntity>;
        getBlockEntities(): $Map<$BlockPos, $BlockEntity>;
        get blockEntityNbts(): $Map<$BlockPos, $CompoundTag>;
        getBlockEntityNbts(): $Map<$BlockPos, $CompoundTag>;
        get blockTicks(): $TickContainerAccess<$Block>;
        getBlockTicks(): $TickContainerAccess<$Block>;
        get entities(): $List<$CompoundTag>;
        getEntities(): $List<$CompoundTag>;
        get fluidTicks(): $TickContainerAccess<$Fluid>;
        getFluidTicks(): $TickContainerAccess<$Fluid>;
        get heightAccessorForGeneration(): $LevelHeightAccessor;
        getHeightAccessorForGeneration(): $LevelHeightAccessor;
        get maxBuildHeight(): number;
        getMaxBuildHeight(): number;
        get maxLightLevel(): number;
        getMaxLightLevel(): number;
        get maxSection(): number;
        getMaxSection(): number;
        get minSection(): number;
        getMinSection(): number;
        get persistedStatus(): $ChunkStatus;
        getPersistedStatus(): $ChunkStatus;
        set persistedStatus(value: $ChunkStatus_);
        get sectionsCount(): number;
        getSectionsCount(): number;
        get ticksForSerialization(): $ChunkAccess$TicksToSave;
        getTicksForSerialization(): $ChunkAccess$TicksToSave;
        static packOffsetCoordinates(arg0: $BlockPos_): number;
        static unpackOffsetCoordinates(arg0: number, arg1: number, arg2: $ChunkPos): $BlockPos;
        addEntity(arg0: $CompoundTag_): void;
        addEntity(arg0: $Entity): void;
        addPackedPostProcess(arg0: number, arg1: number): void;
        clipWithInteractionOverride(arg0: $Vec3_, arg1: $Vec3_, arg2: $BlockPos_, arg3: $VoxelShape, arg4: $BlockState_): $BlockHitResult;
        clip(arg0: $ClipContext): $BlockHitResult;
        getAuxLightManager(arg0: $BlockPos_): $AuxiliaryLightManager;
        getAuxLightManager(arg0: $ChunkPos): $AuxiliaryLightManager;
        getBlockEntityNbtForSaving(arg0: $BlockPos_, arg1: $HolderLookup$Provider): $CompoundTag;
        getBlockEntity<T extends $BlockEntity>(arg0: $BlockPos_, arg1: $BlockEntityType_<T>): $Optional<T>;
        getBlockEntity(arg0: $BlockPos_): $BlockEntity;
        getBlockFloorHeight(arg0: $BlockPos_): number;
        getBlockFloorHeight(arg0: $VoxelShape, arg1: $Supplier_<$VoxelShape, $VoxelShape>): number;
        getBlockStates(arg0: $AABB): $Stream<$BlockState>;
        getBlockState(arg0: $BlockPos_): $BlockState;
        getCarvingMask(arg0: $GenerationStep$Carving_): $CarvingMask;
        getData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getData<T>(arg0: $AttachmentType<T>): T;
        getExistingDataOrNull<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        getExistingDataOrNull<T>(arg0: $AttachmentType<T>): T;
        getExistingData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): $Optional<T>;
        getExistingData<T>(arg0: $AttachmentType<T>): $Optional<T>;
        getFluidState(arg0: $BlockPos_): $FluidState;
        getLightEmission(arg0: $BlockPos_): number;
        getModelData(arg0: $BlockPos_): $ModelData;
        getNoiseBiome(arg0: number, arg1: number, arg2: number): $Holder<$Biome>;
        getOrCreateCarvingMask(arg0: $GenerationStep$Carving_): $CarvingMask;
        getSectionIndexFromSectionY(arg0: number): number;
        getSectionIndex(arg0: number): number;
        getSectionYFromSectionIndex(arg0: number): number;
        hasData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): boolean;
        hasData(arg0: $AttachmentType<any>): boolean;
        isBlockInLine(arg0: $ClipBlockStateContext): $BlockHitResult;
        isOutsideBuildHeight(arg0: number): boolean;
        isOutsideBuildHeight(arg0: $BlockPos_): boolean;
        markPosForPostprocessing(arg0: $BlockPos_): void;
        removeBlockEntity(arg0: $BlockPos_): void;
        removeData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>): T;
        removeData<T>(arg0: $AttachmentType<T>): T;
        setBelowZeroRetrogen(arg0: $BelowZeroRetrogen): void;
        setBlockEntity(arg0: $BlockEntity): void;
        setBlockState(arg0: $BlockPos_, arg1: $BlockState_, arg2: boolean): $BlockState;
        setCarvingMask(arg0: $GenerationStep$Carving_, arg1: $CarvingMask): void;
        setData<T>(arg0: $Supplier_<$AttachmentType<T>, $AttachmentType<T>>, arg1: T): T;
        setData<T>(arg0: $AttachmentType<T>, arg1: T): T;
        setLightEngine(arg0: $LevelLightEngine): void;
        setPersistedStatus(arg0: $ChunkStatus_): void;
        setStartForStructure(arg0: $Structure, arg1: $StructureStart): void;
        syncData(arg0: $Supplier_<$AttachmentType<any>, $AttachmentType<any>>): void;
        syncData(arg0: $AttachmentType<any>): void;
        unpackBlockTicks(): $LevelChunkTicks<$Block>;
        unpackFluidTicks(): $LevelChunkTicks<$Fluid>;
    }

    export interface $StructureAccess {
        addReferenceForStructure(arg0: $Structure, arg1: number): void;
        getAllReferences(): $Map<$Structure, $LongSet>;
        getReferencesForStructure(arg0: $Structure): $LongSet;
        getStartForStructure(arg0: $Structure): $StructureStart;
        setAllReferences(arg0: ($Map<$Structure, $LongSet> | ([$Structure] extends [PropertyKey] ? Partial<Record<Extract<$Structure, PropertyKey>, $LongSet>> : never))): void;
        setStartForStructure(arg0: $Structure, arg1: $StructureStart): void;
    }

    export class $UpgradeData {
        constructor(arg0: $CompoundTag_, arg1: $LevelHeightAccessor);
        static EMPTY: $UpgradeData;
        get empty(): boolean;
        isEmpty(): boolean;
        upgrade(arg0: $LevelChunk): void;
        write(): $CompoundTag;
    }

    export interface $Palette$Factory {
        create<A>(arg0: number, arg1: $IdMap<A>, arg2: $PaletteResize_<A, number, A, number>, arg3: A[]): $Palette<A>;
    }

    export class $PalettedContainer$Data<T> extends $Record {
        get serializedSize(): number;
        getSerializedSize(): number;
        configuration(): $PalettedContainer$Configuration<T>;
        copyFrom(arg0: $Palette<T>, arg1: $BitStorage): void;
        copy(): $PalettedContainer$Data<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        palette(): $Palette<T>;
        storage(): $BitStorage;
        toString(): string;
        write(arg0: $FriendlyByteBuf): void;
    }

    export interface $Palette<T> {
        copy(): $Palette<T>;
        getSerializedSize(): number;
        getSize(): number;
        idFor(arg0: T): number;
        maybeHas(arg0: $Predicate_<T, T, boolean>): boolean;
        read(arg0: $FriendlyByteBuf): void;
        valueFor(arg0: number): T;
        write(arg0: $FriendlyByteBuf): void;
    }

    export type $CarvingMask$Mask_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackResult = boolean> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($CarvingMask$Mask & { readonly [Symbol.hasInstance]?: never });
    export type $LevelChunk$EntityCreationType_ = $LevelChunk$EntityCreationType | "CHECK" | "IMMEDIATE" | "QUEUED";
    export type $LevelChunk$PostLoadProcessor_<CallbackArg0 = $LevelChunk> = ((arg0: CallbackArg0) => void) | ($LevelChunk$PostLoadProcessor & { readonly [Symbol.hasInstance]?: never });
    export type $PaletteResize_<Host0 = any, CallbackArg0 = number, CallbackArg1 = Host0, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($PaletteResize<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $PalettedContainer$CountConsumer_<Host0 = any, CallbackArg0 = Host0, CallbackArg1 = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($PalettedContainer$CountConsumer<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Palette$Factory_<CallbackArg0 = number, CallbackArg1 = $IdMap<any>, CallbackArg2 = $PaletteResize<any>, CallbackArg3 = $List<any>, CallbackResult = $Palette<any>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => CallbackResult) | ($Palette$Factory & { readonly [Symbol.hasInstance]?: never });
}
