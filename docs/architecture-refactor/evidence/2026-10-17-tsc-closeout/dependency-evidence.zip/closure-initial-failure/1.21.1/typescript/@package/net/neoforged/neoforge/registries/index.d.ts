import { $Class } from "java:java/lang";
import { $Map } from "java:java/util";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $RegistryCallback } from "java:net/neoforged/neoforge/registries/callback";
import { $DataMapType } from "java:net/neoforged/neoforge/registries/datamaps";

export * as callback from "java:net/neoforged/neoforge/registries/callback";
export * as datamaps from "java:net/neoforged/neoforge/registries/datamaps";

declare module "java:net/neoforged/neoforge/registries" {
    export interface $IRegistryExtension<T> {
        addAlias(arg0: $ResourceLocation_, arg1: $ResourceLocation_): void;
        addCallback<C extends $RegistryCallback<T>>(arg0: $Class<C>, arg1: C): void;
        addCallback(arg0: $RegistryCallback<T>): void;
        containsValue(arg0: T): boolean;
        doesSync(): boolean;
        getDataMap<A>(arg0: $DataMapType<T, A>): $Map<$ResourceKey<T>, A>;
        getData<A>(arg0: $DataMapType<T, A>, arg1: $ResourceKey<T>): A;
        getId(arg0: $ResourceKey<T>): number;
        getId(arg0: $ResourceLocation_): number;
        getKeyOrNull(arg0: T): $ResourceLocation;
        getMaxId(): number;
        resolve(arg0: $ResourceKey<T>): $ResourceKey<T>;
        resolve(arg0: $ResourceLocation_): $ResourceLocation;
    }

}
