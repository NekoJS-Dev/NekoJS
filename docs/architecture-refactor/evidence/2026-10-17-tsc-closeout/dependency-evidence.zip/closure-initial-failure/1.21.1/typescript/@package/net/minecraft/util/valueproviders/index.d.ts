import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $RandomSource } from "java:net/minecraft/util";
import { $SimpleWeightedRandomList } from "java:net/minecraft/util/random";

declare module "java:net/minecraft/util/valueproviders" {
    export class $BiasedToBottomInt extends $IntProvider {
        static CODEC: $MapCodec<$BiasedToBottomInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static of(arg0: number, arg1: number): $BiasedToBottomInt;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $ClampedInt extends $IntProvider {
        constructor(arg0: $IntProvider, arg1: number, arg2: number);
        static CODEC: $MapCodec<$ClampedInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static of(arg0: $IntProvider, arg1: number, arg2: number): $ClampedInt;
        sample(arg0: $RandomSource): number;
    }

    export class $ClampedNormalInt extends $IntProvider {
        static CODEC: $MapCodec<$ClampedNormalInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static of(arg0: number, arg1: number, arg2: number, arg3: number): $ClampedNormalInt;
        static sample(arg0: $RandomSource, arg1: number, arg2: number, arg3: number, arg4: number): number;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $ConstantInt extends $IntProvider {
        static CODEC: $MapCodec<$ConstantInt>;
        static ZERO: $ConstantInt;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        get value(): number;
        getValue(): number;
        static of(arg0: number): $ConstantInt;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $FloatProvider implements $SampledFloat {
        constructor();
        static CODEC: $Codec<$FloatProvider>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $FloatProviderType<any>;
        getType(): $FloatProviderType<any>;
        static codec(arg0: number, arg1: number): $Codec<$FloatProvider>;
        sample(arg0: $RandomSource): number;
    }

    export class $IntProvider {
        constructor();
        static CODEC: $Codec<$IntProvider>;
        static NON_NEGATIVE_CODEC: $Codec<$IntProvider>;
        static POSITIVE_CODEC: $Codec<$IntProvider>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static codec(arg0: number, arg1: number): $Codec<$IntProvider>;
        static validateCodec<T extends $IntProvider>(arg0: number, arg1: number, arg2: $Codec<T>): $Codec<T>;
        sample(arg0: $RandomSource): number;
    }

    export interface $IntProviderType<P extends $IntProvider> {
        codec(): $MapCodec<P>;
    }
    export const $IntProviderType: {
        register<P extends $IntProvider>(arg0: string, arg1: $MapCodec<P>): $IntProviderType<P>;
        readonly BIASED_TO_BOTTOM: $IntProviderType<$BiasedToBottomInt>;
        readonly CLAMPED: $IntProviderType<$ClampedInt>;
        readonly CLAMPED_NORMAL: $IntProviderType<$ClampedNormalInt>;
        readonly CONSTANT: $IntProviderType<$ConstantInt>;
        readonly UNIFORM: $IntProviderType<$UniformInt>;
        readonly WEIGHTED_LIST: $IntProviderType<$WeightedListInt>;
    };

    export class $UniformInt extends $IntProvider {
        static CODEC: $MapCodec<$UniformInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static of(arg0: number, arg1: number): $UniformInt;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $WeightedListInt extends $IntProvider {
        constructor(arg0: $SimpleWeightedRandomList<$IntProvider>);
        static CODEC: $MapCodec<$WeightedListInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        sample(arg0: $RandomSource): number;
    }

    export interface $FloatProviderType<P extends $FloatProvider> {
        codec(): $MapCodec<P>;
    }
    export const $FloatProviderType: {
        register<P extends $FloatProvider>(arg0: string, arg1: $MapCodec<P>): $FloatProviderType<P>;
        readonly CLAMPED_NORMAL: $FloatProviderType<$ClampedNormalFloat>;
        readonly CONSTANT: $FloatProviderType<$ConstantFloat>;
        readonly TRAPEZOID: $FloatProviderType<$TrapezoidFloat>;
        readonly UNIFORM: $FloatProviderType<$UniformFloat>;
    };

    export interface $SampledFloat {
        sample(arg0: $RandomSource): number;
    }

    export class $ClampedNormalFloat extends $FloatProvider {
        static CODEC: $MapCodec<$ClampedNormalFloat>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $FloatProviderType<any>;
        getType(): $FloatProviderType<any>;
        static of(arg0: number, arg1: number, arg2: number, arg3: number): $ClampedNormalFloat;
        static sample(arg0: $RandomSource, arg1: number, arg2: number, arg3: number, arg4: number): number;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $ConstantFloat extends $FloatProvider {
        static CODEC: $MapCodec<$ConstantFloat>;
        static ZERO: $ConstantFloat;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $FloatProviderType<any>;
        getType(): $FloatProviderType<any>;
        get value(): number;
        getValue(): number;
        static of(arg0: number): $ConstantFloat;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $TrapezoidFloat extends $FloatProvider {
        static CODEC: $MapCodec<$TrapezoidFloat>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $FloatProviderType<any>;
        getType(): $FloatProviderType<any>;
        static of(arg0: number, arg1: number, arg2: number): $TrapezoidFloat;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $UniformFloat extends $FloatProvider {
        static CODEC: $MapCodec<$UniformFloat>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $FloatProviderType<any>;
        getType(): $FloatProviderType<any>;
        static of(arg0: number, arg1: number): $UniformFloat;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export type $IntProviderType_<Host0 extends $IntProvider = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($IntProviderType<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $FloatProviderType_<Host0 extends $FloatProvider = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($FloatProviderType<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $SampledFloat_<CallbackArg0 = $RandomSource, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($SampledFloat & { readonly [Symbol.hasInstance]?: never });
}
