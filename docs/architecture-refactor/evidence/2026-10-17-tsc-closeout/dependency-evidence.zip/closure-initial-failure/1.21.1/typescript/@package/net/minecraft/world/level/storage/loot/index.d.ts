import { $Codec, $DynamicOps } from "java:com/mojang/serialization";
import { $ObjectArrayList } from "java:it/unimi/dsi/fastutil/objects";
import { $Iterable, $Record } from "java:java/lang";
import { $Map, $Optional, $Set } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $Consumer, $Consumer_, $Function, $Function_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $Holder, $HolderGetter, $HolderGetter$Provider, $HolderGetter$Provider_, $Holder_, $Registry } from "java:net/minecraft/core";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $ProblemReporter, $RandomSource } from "java:net/minecraft/util";
import { $Container } from "java:net/minecraft/world";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LootPoolEntryContainer$Builder } from "java:net/minecraft/world/level/storage/loot/entries";
import { $FunctionUserBuilder, $LootItemFunction, $LootItemFunction$Builder, $LootItemFunction$Builder_ } from "java:net/minecraft/world/level/storage/loot/functions";
import { $LootContextParam, $LootContextParamSet } from "java:net/minecraft/world/level/storage/loot/parameters";
import { $ConditionUserBuilder, $LootItemCondition, $LootItemCondition$Builder, $LootItemCondition$Builder_ } from "java:net/minecraft/world/level/storage/loot/predicates";
import { $NumberProvider } from "java:net/minecraft/world/level/storage/loot/providers/number";

export * as entries from "java:net/minecraft/world/level/storage/loot/entries";
export * as functions from "java:net/minecraft/world/level/storage/loot/functions";
export * as parameters from "java:net/minecraft/world/level/storage/loot/parameters";
export * as predicates from "java:net/minecraft/world/level/storage/loot/predicates";
export * as providers from "java:net/minecraft/world/level/storage/loot/providers";

declare module "java:net/minecraft/world/level/storage/loot" {
    export class $LootContext {
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
        get luck(): number;
        getLuck(): number;
        get queriedLootTableId(): $ResourceLocation;
        getQueriedLootTableId(): $ResourceLocation;
        set queriedLootTableId(value: $ResourceLocation_);
        get random(): $RandomSource;
        getRandom(): $RandomSource;
        get resolver(): $HolderGetter$Provider;
        getResolver(): $HolderGetter$Provider;
        static createVisitedEntry(arg0: $LootTable): $LootContext$VisitedEntry<$LootTable>;
        static createVisitedEntry(arg0: $LootItemFunction): $LootContext$VisitedEntry<$LootItemFunction>;
        static createVisitedEntry(arg0: $LootItemCondition): $LootContext$VisitedEntry<$LootItemCondition>;
        addDynamicDrops(arg0: $ResourceLocation_, arg1: $Consumer_<$ItemStack, $ItemStack>): void;
        getParamOrNull<T>(arg0: $LootContextParam<T>): T;
        getParam<T>(arg0: $LootContextParam<T>): T;
        hasParam(arg0: $LootContextParam<any>): boolean;
        hasVisitedElement(arg0: $LootContext$VisitedEntry<any>): boolean;
        popVisitedElement(arg0: $LootContext$VisitedEntry<any>): void;
        pushVisitedElement(arg0: $LootContext$VisitedEntry<any>): boolean;
        setQueriedLootTableId(arg0: $ResourceLocation_): void;
    }

    export class $LootContext$VisitedEntry<T> extends $Record {
        constructor(type: $LootDataType<T>, value: T);
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $LootDataType<T>;
        value(): T;
    }

    export interface $LootContextUser {
        getReferencedContextParams(): $Set<$LootContextParam<any>>;
        validate(arg0: $ValidationContext): void;
    }

    export class $LootDataType<T> extends $Record {
        constructor(registryKey: $ResourceKey<$Registry<T>>, codec: $Codec<T>, validator: $LootDataType$Validator_<T, $ValidationContext, $ResourceKey<T>, T>, defaultValue: T, conditionalCodec: $Codec<$Optional<T>>, idSetter: $BiConsumer_<T, $ResourceLocation, T, $ResourceLocation>);
        static MODIFIER: $LootDataType<$LootItemFunction>;
        static PREDICATE: $LootDataType<$LootItemCondition>;
        static TABLE: $LootDataType<$LootTable>;
        static values(): $Stream<$LootDataType<any>>;
        codec(): $Codec<T>;
        conditionalCodec(): $Codec<$Optional<T>>;
        defaultValue(): T;
        deserialize<V>(arg0: $ResourceLocation_, arg1: $DynamicOps<V>, arg2: V): $Optional<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        idSetter(): $BiConsumer<T, $ResourceLocation>;
        registryKey(): $ResourceKey<$Registry<T>>;
        runValidation(arg0: $ValidationContext, arg1: $ResourceKey<T>, arg2: T): void;
        toString(): string;
        validator(): $LootDataType$Validator<T>;
    }

    export interface $LootDataType$Validator<T> {
        run(arg0: $ValidationContext, arg1: $ResourceKey<T>, arg2: T): void;
    }

    export class $LootParams {
        constructor(arg0: $ServerLevel, arg1: ($Map<$LootContextParam<any>, object> | ([$LootContextParam<any>] extends [PropertyKey] ? Partial<Record<Extract<$LootContextParam<any>, PropertyKey>, object>> : never)), arg2: ($Map<$ResourceLocation_, $LootParams$DynamicDrop_<$Consumer<$ItemStack>>> | ([$ResourceLocation_] extends [PropertyKey] ? Partial<Record<Extract<$ResourceLocation_, PropertyKey>, $LootParams$DynamicDrop_<$Consumer<$ItemStack>>>> : never)), arg3: number);
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
        get luck(): number;
        getLuck(): number;
        addDynamicDrops(arg0: $ResourceLocation_, arg1: $Consumer_<$ItemStack, $ItemStack>): void;
        getOptionalParameter<T>(arg0: $LootContextParam<T>): T;
        getParamOrNull<T>(arg0: $LootContextParam<T>): T;
        getParameter<T>(arg0: $LootContextParam<T>): T;
        hasParam(arg0: $LootContextParam<any>): boolean;
    }

    export class $LootParams$Builder {
        constructor(arg0: $ServerLevel);
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
        create(arg0: $LootContextParamSet): $LootParams;
        getOptionalParameter<T>(arg0: $LootContextParam<T>): T;
        getParameter<T>(arg0: $LootContextParam<T>): T;
        withDynamicDrop(arg0: $ResourceLocation_, arg1: $LootParams$DynamicDrop_<$Consumer<$ItemStack>>): $LootParams$Builder;
        withLuck(arg0: number): $LootParams$Builder;
        withOptionalParameter<T>(arg0: $LootContextParam<T>, arg1: T): $LootParams$Builder;
        withParameter<T>(arg0: $LootContextParam<T>, arg1: T): $LootParams$Builder;
    }

    export interface $LootParams$DynamicDrop {
        add(arg0: $Consumer_<$ItemStack, $ItemStack>): void;
    }

    export class $LootPool {
        static CODEC: $Codec<$LootPool>;
        get bonusRolls(): $NumberProvider;
        getBonusRolls(): $NumberProvider;
        set bonusRolls(value: $NumberProvider);
        get name(): string;
        getName(): string;
        get rolls(): $NumberProvider;
        getRolls(): $NumberProvider;
        set rolls(value: $NumberProvider);
        get frozen(): boolean;
        isFrozen(): boolean;
        static lootPool(): $LootPool$Builder;
        addRandomItems(arg0: $Consumer_<$ItemStack, $ItemStack>, arg1: $LootContext): void;
        freeze(): void;
        setBonusRolls(arg0: $NumberProvider): void;
        setRolls(arg0: $NumberProvider): void;
        validate(arg0: $ValidationContext): void;
    }

    export class $LootPool$Builder implements $FunctionUserBuilder<$LootPool$Builder>, $ConditionUserBuilder<$LootPool$Builder> {
        constructor();
        add(arg0: $LootPoolEntryContainer$Builder<any>): $LootPool$Builder;
        apply<E>(arg0: E[], arg1: $Function_<E, $LootItemFunction$Builder, E, $LootItemFunction$Builder_<$LootItemFunction>>): $LootPool$Builder;
        apply<E>(arg0: $Iterable<E>, arg1: $Function_<E, $LootItemFunction$Builder, E, $LootItemFunction$Builder_<$LootItemFunction>>): $LootPool$Builder;
        apply(arg0: $LootItemFunction$Builder_<$LootItemFunction>): $LootPool$Builder;
        build(): $LootPool;
        name(arg0: string): $LootPool$Builder;
        setBonusRolls(arg0: $NumberProvider): $LootPool$Builder;
        setRolls(arg0: $NumberProvider): $LootPool$Builder;
        unwrap(): $LootPool$Builder;
        when<E>(arg0: $Iterable<E>, arg1: $Function_<E, $LootItemCondition$Builder, E, $LootItemCondition$Builder_<$LootItemCondition>>): $LootPool$Builder;
        when(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $LootPool$Builder;
    }

    export class $LootTable {
        static CODEC: $Codec<$Holder<$LootTable>>;
        static DEFAULT_PARAM_SET: $LootContextParamSet;
        static DIRECT_CODEC: $Codec<$LootTable>;
        static EMPTY: $LootTable;
        static RANDOMIZE_SEED: number;
        get lootTableId(): $ResourceLocation;
        getLootTableId(): $ResourceLocation;
        set lootTableId(value: $ResourceLocation_);
        get paramSet(): $LootContextParamSet;
        getParamSet(): $LootContextParamSet;
        get frozen(): boolean;
        isFrozen(): boolean;
        static createStackSplitter(arg0: $ServerLevel, arg1: $Consumer_<$ItemStack, $ItemStack>): $Consumer<$ItemStack>;
        static lootTable(): $LootTable$Builder;
        addPool(arg0: $LootPool): void;
        fill(arg0: $Container, arg1: $LootParams, arg2: number): void;
        freeze(): void;
        getPool(arg0: string): $LootPool;
        getRandomItemsRaw(arg0: $LootContext, arg1: $Consumer_<$ItemStack, $ItemStack>): void;
        getRandomItemsRaw(arg0: $LootParams, arg1: $Consumer_<$ItemStack, $ItemStack>): void;
        getRandomItems(arg0: $LootContext, arg1: $Consumer_<$ItemStack, $ItemStack>): void;
        getRandomItems(arg0: $LootParams, arg1: $Consumer_<$ItemStack, $ItemStack>): void;
        getRandomItems(arg0: $LootParams, arg1: number, arg2: $Consumer_<$ItemStack, $ItemStack>): void;
        getRandomItems(arg0: $LootParams, arg1: number): $ObjectArrayList<$ItemStack>;
        getRandomItems(arg0: $LootParams, arg1: $RandomSource): $ObjectArrayList<$ItemStack>;
        getRandomItems(arg0: $LootParams): $ObjectArrayList<$ItemStack>;
        removePool(arg0: string): $LootPool;
        setLootTableId(arg0: $ResourceLocation_): void;
        validate(arg0: $ValidationContext): void;
    }

    export class $LootTable$Builder implements $FunctionUserBuilder<$LootTable$Builder> {
        constructor();
        apply<E>(arg0: E[], arg1: $Function_<E, $LootItemFunction$Builder, E, $LootItemFunction$Builder_<$LootItemFunction>>): $LootTable$Builder;
        apply<E>(arg0: $Iterable<E>, arg1: $Function_<E, $LootItemFunction$Builder, E, $LootItemFunction$Builder_<$LootItemFunction>>): $LootTable$Builder;
        apply(arg0: $LootItemFunction$Builder_<$LootItemFunction>): $LootTable$Builder;
        build(): $LootTable;
        setParamSet(arg0: $LootContextParamSet): $LootTable$Builder;
        setRandomSequence(arg0: $ResourceLocation_): $LootTable$Builder;
        unwrap(): $LootTable$Builder;
        withPool(arg0: $LootPool$Builder): $LootTable$Builder;
    }

    export class $ValidationContext {
        constructor(arg0: $ProblemReporter, arg1: $LootContextParamSet);
        constructor(arg0: $ProblemReporter, arg1: $LootContextParamSet, arg2: $HolderGetter$Provider_<$ResourceKey<$Registry<any>>, $Optional<$HolderGetter<any>>>);
        allowsReferences(): boolean;
        enterElement(arg0: string, arg1: $ResourceKey<any>): $ValidationContext;
        forChild(arg0: string): $ValidationContext;
        hasVisitedElement(arg0: $ResourceKey<any>): boolean;
        reportProblem(arg0: string): void;
        reporter(): $ProblemReporter;
        resolver(): $HolderGetter$Provider;
        setParams(arg0: $LootContextParamSet): $ValidationContext;
        validateUser(arg0: $LootContextUser): void;
    }

    export type $LootDataType$Validator_<Host0 = any, CallbackArg0 = $ValidationContext, CallbackArg1 = $ResourceKey<Host0>, CallbackArg2 = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void) | ($LootDataType$Validator<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $LootParams$DynamicDrop_<CallbackArg0 = $Consumer<$ItemStack>> = ((arg0: CallbackArg0) => void) | ($LootParams$DynamicDrop & { readonly [Symbol.hasInstance]?: never });
}
