import { $Enum } from "java:java/lang";

declare module "java:org/slf4j/event" {
    export class $Level {
        static DEBUG: $Level;
        static ERROR: $Level;
        static INFO: $Level;
        static TRACE: $Level;
        static WARN: $Level;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Level[];
        static valueOf(name: string): $Level;
    }
    export interface $Level extends $Enum<$Level> {}

    export type $Level_ = $Level | "DEBUG" | "ERROR" | "INFO" | "TRACE" | "WARN";
}
