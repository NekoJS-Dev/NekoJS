import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record } from "java:java/lang";
import { $List } from "java:java/util";
import { $Function, $Function_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $Holder_, $Vec3i } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $LevelAccessor, $StructureManager, $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $PlacedFeature } from "java:net/minecraft/world/level/levelgen/placement";
import { $BoundingBox } from "java:net/minecraft/world/level/levelgen/structure";
import { $LiquidSettings, $LiquidSettings_, $StructureProcessorList, $StructureTemplate$StructureBlockInfo, $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";

export * as alias from "java:net/minecraft/world/level/levelgen/structure/pools/alias";

declare module "java:net/minecraft/world/level/levelgen/structure/pools" {
    export class $DimensionPadding extends $Record {
        constructor(arg0: number);
        constructor(arg0: number, arg1: number);
        static CODEC: $Codec<$DimensionPadding>;
        static ZERO: $DimensionPadding;
        bottom(): number;
        equals(arg0: object): boolean;
        hasEqualTopAndBottom(): boolean;
        hashCode(): number;
        toString(): string;
        top(): number;
    }

    export class $EmptyPoolElement extends $StructurePoolElement {
        static CODEC: $MapCodec<$EmptyPoolElement>;
        static INSTANCE: $EmptyPoolElement;
        get type(): $StructurePoolElementType<any>;
        getType(): $StructurePoolElementType<any>;
        getBoundingBox(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_): $BoundingBox;
        getShuffledJigsawBlocks(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_, arg3: $RandomSource): $List<$StructureTemplate$StructureBlockInfo>;
        getSize(arg0: $StructureTemplateManager, arg1: $Rotation_): $Vec3i;
        place(arg0: $StructureTemplateManager, arg1: $WorldGenLevel, arg2: $StructureManager, arg3: $ChunkGenerator, arg4: $BlockPos_, arg5: $BlockPos_, arg6: $Rotation_, arg7: $BoundingBox, arg8: $RandomSource, arg9: $LiquidSettings_, arg10: boolean): boolean;
        toString(): string;
    }

    export class $FeaturePoolElement extends $StructurePoolElement {
        static CODEC: $MapCodec<$FeaturePoolElement>;
        get type(): $StructurePoolElementType<any>;
        getType(): $StructurePoolElementType<any>;
        getBoundingBox(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_): $BoundingBox;
        getShuffledJigsawBlocks(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_, arg3: $RandomSource): $List<$StructureTemplate$StructureBlockInfo>;
        getSize(arg0: $StructureTemplateManager, arg1: $Rotation_): $Vec3i;
        place(arg0: $StructureTemplateManager, arg1: $WorldGenLevel, arg2: $StructureManager, arg3: $ChunkGenerator, arg4: $BlockPos_, arg5: $BlockPos_, arg6: $Rotation_, arg7: $BoundingBox, arg8: $RandomSource, arg9: $LiquidSettings_, arg10: boolean): boolean;
        toString(): string;
    }

    export class $LegacySinglePoolElement extends $SinglePoolElement {
        static CODEC: $MapCodec<$LegacySinglePoolElement>;
        get type(): $StructurePoolElementType<any>;
        getType(): $StructurePoolElementType<any>;
        toString(): string;
    }

    export class $ListPoolElement extends $StructurePoolElement {
        constructor(arg0: $StructurePoolElement[], arg1: $StructureTemplatePool$Projection_);
        static CODEC: $MapCodec<$ListPoolElement>;
        get type(): $StructurePoolElementType<any>;
        getType(): $StructurePoolElementType<any>;
        getBoundingBox(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_): $BoundingBox;
        getShuffledJigsawBlocks(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_, arg3: $RandomSource): $List<$StructureTemplate$StructureBlockInfo>;
        getSize(arg0: $StructureTemplateManager, arg1: $Rotation_): $Vec3i;
        place(arg0: $StructureTemplateManager, arg1: $WorldGenLevel, arg2: $StructureManager, arg3: $ChunkGenerator, arg4: $BlockPos_, arg5: $BlockPos_, arg6: $Rotation_, arg7: $BoundingBox, arg8: $RandomSource, arg9: $LiquidSettings_, arg10: boolean): boolean;
        setProjection(arg0: $StructureTemplatePool$Projection_): $StructurePoolElement;
        toString(): string;
    }

    export class $SinglePoolElement extends $StructurePoolElement {
        static CODEC: $MapCodec<$SinglePoolElement>;
        get type(): $StructurePoolElementType<any>;
        getType(): $StructurePoolElementType<any>;
        getBoundingBox(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_): $BoundingBox;
        getDataMarkers(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_, arg3: boolean): $List<$StructureTemplate$StructureBlockInfo>;
        getShuffledJigsawBlocks(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_, arg3: $RandomSource): $List<$StructureTemplate$StructureBlockInfo>;
        getSize(arg0: $StructureTemplateManager, arg1: $Rotation_): $Vec3i;
        place(arg0: $StructureTemplateManager, arg1: $WorldGenLevel, arg2: $StructureManager, arg3: $ChunkGenerator, arg4: $BlockPos_, arg5: $BlockPos_, arg6: $Rotation_, arg7: $BoundingBox, arg8: $RandomSource, arg9: $LiquidSettings_, arg10: boolean): boolean;
        toString(): string;
    }

    export class $StructurePoolElement {
        static CODEC: $Codec<$StructurePoolElement>;
        get groundLevelDelta(): number;
        getGroundLevelDelta(): number;
        get projection(): $StructureTemplatePool$Projection;
        getProjection(): $StructureTemplatePool$Projection;
        set projection(value: $StructureTemplatePool$Projection_);
        get type(): $StructurePoolElementType<any>;
        getType(): $StructurePoolElementType<any>;
        static empty(): $Function<$StructureTemplatePool$Projection, $EmptyPoolElement>;
        static feature(arg0: $Holder_<$PlacedFeature>): $Function<$StructureTemplatePool$Projection, $FeaturePoolElement>;
        static legacy(arg0: string, arg1: $Holder_<$StructureProcessorList>): $Function<$StructureTemplatePool$Projection, $LegacySinglePoolElement>;
        static legacy(arg0: string): $Function<$StructureTemplatePool$Projection, $LegacySinglePoolElement>;
        static list(arg0: $Function_<$StructureTemplatePool$Projection, $StructurePoolElement, $StructureTemplatePool$Projection, $StructurePoolElement>[]): $Function<$StructureTemplatePool$Projection, $ListPoolElement>;
        static single(arg0: string, arg1: $Holder_<$StructureProcessorList>, arg2: $LiquidSettings_): $Function<$StructureTemplatePool$Projection, $SinglePoolElement>;
        static single(arg0: string, arg1: $Holder_<$StructureProcessorList>): $Function<$StructureTemplatePool$Projection, $SinglePoolElement>;
        static single(arg0: string, arg1: $LiquidSettings_): $Function<$StructureTemplatePool$Projection, $SinglePoolElement>;
        static single(arg0: string): $Function<$StructureTemplatePool$Projection, $SinglePoolElement>;
        getBoundingBox(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_): $BoundingBox;
        getShuffledJigsawBlocks(arg0: $StructureTemplateManager, arg1: $BlockPos_, arg2: $Rotation_, arg3: $RandomSource): $List<$StructureTemplate$StructureBlockInfo>;
        getSize(arg0: $StructureTemplateManager, arg1: $Rotation_): $Vec3i;
        handleDataMarker(arg0: $LevelAccessor, arg1: $StructureTemplate$StructureBlockInfo, arg2: $BlockPos_, arg3: $Rotation_, arg4: $RandomSource, arg5: $BoundingBox): void;
        place(arg0: $StructureTemplateManager, arg1: $WorldGenLevel, arg2: $StructureManager, arg3: $ChunkGenerator, arg4: $BlockPos_, arg5: $BlockPos_, arg6: $Rotation_, arg7: $BoundingBox, arg8: $RandomSource, arg9: $LiquidSettings_, arg10: boolean): boolean;
        setProjection(arg0: $StructureTemplatePool$Projection_): $StructurePoolElement;
    }

    export interface $StructurePoolElementType<P extends $StructurePoolElement> {
        codec(): $MapCodec<P>;
    }
    export const $StructurePoolElementType: {
        register<P extends $StructurePoolElement>(arg0: string, arg1: $MapCodec<P>): $StructurePoolElementType<P>;
        readonly EMPTY: $StructurePoolElementType<$EmptyPoolElement>;
        readonly FEATURE: $StructurePoolElementType<$FeaturePoolElement>;
        readonly LEGACY: $StructurePoolElementType<$LegacySinglePoolElement>;
        readonly LIST: $StructurePoolElementType<$ListPoolElement>;
        readonly SINGLE: $StructurePoolElementType<$SinglePoolElement>;
    };

    export class $StructureTemplatePool {
        constructor(arg0: $Holder_<$StructureTemplatePool>, arg1: $Pair<$Function<$StructureTemplatePool$Projection, $StructurePoolElement>, number>[], arg2: $StructureTemplatePool$Projection_);
        constructor(arg0: $Holder_<$StructureTemplatePool>, arg1: $Pair<$StructurePoolElement, number>[]);
        static CODEC: $Codec<$Holder<$StructureTemplatePool>>;
        static DIRECT_CODEC: $Codec<$StructureTemplatePool>;
        get fallback(): $Holder<$StructureTemplatePool>;
        getFallback(): $Holder<$StructureTemplatePool>;
        getMaxSize(arg0: $StructureTemplateManager): number;
        getRandomTemplate(arg0: $RandomSource): $StructurePoolElement;
        getShuffledTemplates(arg0: $RandomSource): $List<$StructurePoolElement>;
        size(): number;
    }

    export class $StructureTemplatePool$Projection {
        static RIGID: $StructureTemplatePool$Projection;
        static TERRAIN_MATCHING: $StructureTemplatePool$Projection;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StructureTemplatePool$Projection[];
        static valueOf(name: string): $StructureTemplatePool$Projection;
    }
    export interface $StructureTemplatePool$Projection extends $Enum<$StructureTemplatePool$Projection> {}

    export type $StructurePoolElementType_<Host0 extends $StructurePoolElement = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($StructurePoolElementType<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $StructureTemplatePool$Projection_ = $StructureTemplatePool$Projection | "RIGID" | "TERRAIN_MATCHING";
}
