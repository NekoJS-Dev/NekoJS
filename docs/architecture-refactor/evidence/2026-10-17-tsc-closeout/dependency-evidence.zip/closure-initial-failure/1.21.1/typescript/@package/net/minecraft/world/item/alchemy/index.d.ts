import type { RegistryTypes } from "@special/types";
import { $Codec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Iterable, $Record } from "java:java/lang";
import { $List, $Optional, $OptionalInt } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $Holder, $Holder_, $RegistryAccess } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $MobEffectInstance } from "java:net/minecraft/world/effect";
import { $FeatureElement, $FeatureElement_, $FeatureFlag, $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_ } from "java:net/minecraft/world/item/crafting";
import { $IBrewingRecipe } from "java:net/neoforged/neoforge/common/brewing";

declare module "java:net/minecraft/world/item/alchemy" {
    export class $Potion implements $FeatureElement {
        constructor(arg0: string, arg1?: $MobEffectInstance[]);
        constructor(arg0?: $MobEffectInstance[]);
        static CODEC: $Codec<$Holder<$Potion>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$Potion>>;
        get effects(): $List<$MobEffectInstance>;
        getEffects(): $List<$MobEffectInstance>;
        static getName(arg0: $Optional<$Holder<$Potion>>, arg1: string): string;
        hasInstantEffects(): boolean;
        isEnabled(arg0: $FeatureFlagSet): boolean;
        requiredFeatures(arg0?: $FeatureFlag[]): $Potion;
        requiredFeatures(): $FeatureFlagSet;
    }

    export class $PotionBrewing {
        static BREWING_TIME_SECONDS: number;
        static EMPTY: $PotionBrewing;
        get recipes(): $List<$IBrewingRecipe>;
        getRecipes(): $List<$IBrewingRecipe>;
        static addVanillaMixes(arg0: $PotionBrewing$Builder): void;
        static bootstrap(arg0: $FeatureFlagSet, arg1: $RegistryAccess): $PotionBrewing;
        static bootstrap(arg0: $FeatureFlagSet): $PotionBrewing;
        hasContainerMix(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        hasMix(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        hasPotionMix(arg0: $ItemStack_, arg1: $ItemStack_): boolean;
        isBrewablePotion(arg0: $Holder_<$Potion>): boolean;
        isContainerIngredient(arg0: $ItemStack_): boolean;
        isIngredient(arg0: $ItemStack_): boolean;
        isInput(arg0: $ItemStack_): boolean;
        isPotionIngredient(arg0: $ItemStack_): boolean;
        mix(arg0: $ItemStack_, arg1: $ItemStack_): $ItemStack;
    }

    export class $PotionBrewing$Builder {
        constructor(arg0: $FeatureFlagSet);
        addContainerRecipe(arg0: $Item_, arg1: $Item_, arg2: $Item_): void;
        addContainer(arg0: $Item_): void;
        addMix(arg0: $Holder_<$Potion>, arg1: $Item_, arg2: $Holder_<$Potion>): void;
        addRecipe(arg0: $Ingredient_, arg1: $Ingredient_, arg2: $ItemStack_): void;
        addRecipe(arg0: $IBrewingRecipe): void;
        addStartMix(arg0: $Item_, arg1: $Holder_<$Potion>): void;
        build(): $PotionBrewing;
    }

    export class $PotionContents extends $Record {
        constructor(potion: $Optional<$Holder<$Potion>>, customColor: $Optional<number>, customEffects: $MobEffectInstance[]);
        constructor(arg0: $Holder_<$Potion>);
        static CODEC: $Codec<$PotionContents>;
        static EMPTY: $PotionContents;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $PotionContents>;
        get allEffects(): $Iterable<$MobEffectInstance>;
        getAllEffects(): $Iterable<$MobEffectInstance>;
        get color(): number;
        getColor(): number;
        static addPotionTooltip(arg0: $Iterable<$MobEffectInstance>, arg1: $Consumer_<$Component, $Component>, arg2: number, arg3: number): void;
        static createItemStack(arg0: $Item_, arg1: $Holder_<$Potion>): $ItemStack;
        static getColorOptional(arg0: $Iterable<$MobEffectInstance>): $OptionalInt;
        static getColor(arg0: $Iterable<$MobEffectInstance>): number;
        static getColor(arg0: $Holder_<$Potion>): number;
        addPotionTooltip(arg0: $Consumer_<$Component, $Component>, arg1: number, arg2: number): void;
        customColor(): $Optional<number>;
        customEffects(): $List<$MobEffectInstance>;
        equals(arg0: object): boolean;
        forEachEffect(arg0: $Consumer_<$MobEffectInstance, $MobEffectInstance>): void;
        hasEffects(): boolean;
        hashCode(): number;
        is(arg0: $Holder_<$Potion>): boolean;
        potion(): $Optional<$Holder<$Potion>>;
        toString(): string;
        withEffectAdded(arg0: $MobEffectInstance): $PotionContents;
        withPotion(arg0: $Holder_<$Potion>): $PotionContents;
    }

    export type $Potion_ = $Potion | RegistryTypes.Potion | $NekoId | string;
}
