import { $Enum } from "java:java/lang";
import { $FluidStack, $FluidStack_ } from "java:net/neoforged/neoforge/fluids";

export * as templates from "java:net/neoforged/neoforge/fluids/capability/templates";

declare module "java:net/neoforged/neoforge/fluids/capability" {
    export interface $IFluidHandler {
        drain(arg0: number, arg1: $IFluidHandler$FluidAction_): $FluidStack;
        drain(arg0: $FluidStack_, arg1: $IFluidHandler$FluidAction_): $FluidStack;
        fill(arg0: $FluidStack_, arg1: $IFluidHandler$FluidAction_): number;
        getFluidInTank(arg0: number): $FluidStack;
        getTankCapacity(arg0: number): number;
        getTanks(): number;
        isFluidValid(arg0: number, arg1: $FluidStack_): boolean;
    }

    export class $IFluidHandler$FluidAction {
        static EXECUTE: $IFluidHandler$FluidAction;
        static SIMULATE: $IFluidHandler$FluidAction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $IFluidHandler$FluidAction[];
        static valueOf(name: string): $IFluidHandler$FluidAction;
    }
    export interface $IFluidHandler$FluidAction extends $Enum<$IFluidHandler$FluidAction> {}

    export type $IFluidHandler$FluidAction_ = $IFluidHandler$FluidAction | "EXECUTE" | "SIMULATE";
}
