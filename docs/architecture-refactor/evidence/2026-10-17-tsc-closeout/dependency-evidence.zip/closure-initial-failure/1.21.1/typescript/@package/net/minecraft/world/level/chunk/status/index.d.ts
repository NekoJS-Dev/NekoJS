import type { RegistryTypes } from "@special/types";
import { $ImmutableList } from "java:com/google/common/collect";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Enum, $Record, $Runnable, $Runnable_ } from "java:java/lang";
import { $EnumSet, $List } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $ChunkTaskPriorityQueueSorter$Message, $GenerationChunkHolder, $ServerLevel, $ThreadedLevelLightEngine } from "java:net/minecraft/server/level";
import { $StaticCache2D } from "java:net/minecraft/util";
import { $ProcessorHandle } from "java:net/minecraft/util/thread";
import { $ChunkAccess, $ChunkGenerator } from "java:net/minecraft/world/level/chunk";
import { $Heightmap$Types, $Heightmap$Types_ } from "java:net/minecraft/world/level/levelgen";
import { $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";

declare module "java:net/minecraft/world/level/chunk/status" {
    export class $ChunkDependencies {
        constructor(arg0: $ImmutableList<$ChunkStatus>);
        get radius(): number;
        getRadius(): number;
        asList(): $ImmutableList<$ChunkStatus>;
        getRadiusOf(arg0: $ChunkStatus_): number;
        get(arg0: number): $ChunkStatus;
        size(): number;
        toString(): string;
    }

    export class $ChunkStatus {
        static BIOMES: $ChunkStatus;
        static CARVERS: $ChunkStatus;
        static EMPTY: $ChunkStatus;
        static FEATURES: $ChunkStatus;
        static FINAL_HEIGHTMAPS: $EnumSet<$Heightmap$Types>;
        static FULL: $ChunkStatus;
        static INITIALIZE_LIGHT: $ChunkStatus;
        static LIGHT: $ChunkStatus;
        static MAX_STRUCTURE_DISTANCE: number;
        static NOISE: $ChunkStatus;
        static SPAWN: $ChunkStatus;
        static STRUCTURE_REFERENCES: $ChunkStatus;
        static STRUCTURE_STARTS: $ChunkStatus;
        static SURFACE: $ChunkStatus;
        get chunkType(): $ChunkType;
        getChunkType(): $ChunkType;
        get index(): number;
        getIndex(): number;
        get name(): string;
        getName(): string;
        get parent(): $ChunkStatus;
        getParent(): $ChunkStatus;
        static byName(arg0: string): $ChunkStatus;
        static getStatusList(): $List<$ChunkStatus>;
        static max(arg0: $ChunkStatus_, arg1: $ChunkStatus_): $ChunkStatus;
        heightmapsAfter(): $EnumSet<$Heightmap$Types>;
        isAfter(arg0: $ChunkStatus_): boolean;
        isBefore(arg0: $ChunkStatus_): boolean;
        isOrAfter(arg0: $ChunkStatus_): boolean;
        isOrBefore(arg0: $ChunkStatus_): boolean;
        toString(): string;
    }

    export interface $ChunkStatusTask {
        doWork(arg0: $WorldGenContext, arg1: $ChunkStep, arg2: $StaticCache2D<$GenerationChunkHolder>, arg3: $ChunkAccess): $CompletableFuture<$ChunkAccess>;
    }

    export class $ChunkStep extends $Record {
        constructor(arg0: $ChunkStatus_, arg1: $ChunkDependencies, arg2: $ChunkDependencies, arg3: number, arg4: $ChunkStatusTask_<$WorldGenContext, $ChunkStep, $StaticCache2D<$GenerationChunkHolder>, $ChunkAccess, $CompletableFuture<$ChunkAccess>>);
        accumulatedDependencies(): $ChunkDependencies;
        apply(arg0: $WorldGenContext, arg1: $StaticCache2D<$GenerationChunkHolder>, arg2: $ChunkAccess): $CompletableFuture<$ChunkAccess>;
        blockStateWriteRadius(): number;
        directDependencies(): $ChunkDependencies;
        equals(arg0: object): boolean;
        getAccumulatedRadiusOf(arg0: $ChunkStatus_): number;
        hashCode(): number;
        targetStatus(): $ChunkStatus;
        task(): $ChunkStatusTask;
        toString(): string;
    }

    export class $ChunkType {
        static LEVELCHUNK: $ChunkType;
        static PROTOCHUNK: $ChunkType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChunkType[];
        static valueOf(name: string): $ChunkType;
    }
    export interface $ChunkType extends $Enum<$ChunkType> {}

    export class $WorldGenContext extends $Record {
        constructor(arg0: $ServerLevel, arg1: $ChunkGenerator, arg2: $StructureTemplateManager, arg3: $ThreadedLevelLightEngine, arg4: $ProcessorHandle<$ChunkTaskPriorityQueueSorter$Message<$Runnable>>);
        equals(arg0: object): boolean;
        generator(): $ChunkGenerator;
        hashCode(): number;
        level(): $ServerLevel;
        lightEngine(): $ThreadedLevelLightEngine;
        mainThreadMailBox(): $ProcessorHandle<$ChunkTaskPriorityQueueSorter$Message<$Runnable>>;
        structureManager(): $StructureTemplateManager;
        toString(): string;
    }

    export type $ChunkStatus_ = $ChunkStatus | RegistryTypes.ChunkStatus | $NekoId | string;
    export type $ChunkStatusTask_<CallbackArg0 = $WorldGenContext, CallbackArg1 = $ChunkStep, CallbackArg2 = $StaticCache2D<$GenerationChunkHolder>, CallbackArg3 = $ChunkAccess, CallbackResult = $CompletableFuture<$ChunkAccess>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => CallbackResult) | ($ChunkStatusTask & { readonly [Symbol.hasInstance]?: never });
    export type $ChunkType_ = $ChunkType | "LEVELCHUNK" | "PROTOCHUNK";
}
