import { $NetworkDataEventJS } from "java:com/tkisor/nekojs/wrapper/network";
import { $String } from "java:java/lang";
import { $Item, $Item_ } from "java:net/minecraft/world/item";
import { $ItemTooltipEvent } from "java:net/neoforged/neoforge/event/entity/player";

declare module "@side-only/client/events" {
}

export {};

declare global {
    namespace NetworkEvents {
        function client(handler: ((event: $NetworkDataEventJS) => void)): void;
        function client(extra: string, handler: ((event: $NetworkDataEventJS) => void)): void;
    }

    namespace ItemEvents {
        function tooltip(handler: ((event: $ItemTooltipEvent) => void)): void;
        function tooltip(extra: $Item_, handler: ((event: $ItemTooltipEvent) => void)): void;
    }

}
