import { $Enum, $Record } from "java:java/lang";
import { $List, $Set } from "java:java/util";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $Entity, $Mob } from "java:net/minecraft/world/entity";
import { $BlockGetter, $CollisionGetter, $PathNavigationRegion } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/level/pathfinder" {
    export class $Node {
        constructor(arg0: number, arg1: number, arg2: number);
        cameFrom: $Node;
        closed: boolean;
        costMalus: number;
        f: number;
        g: number;
        h: number;
        heapIdx: number;
        type: $PathType;
        walkedDistance: number;
        x: number;
        y: number;
        z: number;
        static createFromStream(arg0: $FriendlyByteBuf): $Node;
        static createHash(arg0: number, arg1: number, arg2: number): number;
        asBlockPos(): $BlockPos;
        asVec3(): $Vec3;
        cloneAndMove(arg0: number, arg1: number, arg2: number): $Node;
        distanceManhattan(arg0: $BlockPos_): number;
        distanceManhattan(arg0: $Node): number;
        distanceToSqr(arg0: $BlockPos_): number;
        distanceToSqr(arg0: $Node): number;
        distanceToXZ(arg0: $Node): number;
        distanceTo(arg0: $BlockPos_): number;
        distanceTo(arg0: $Node): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        inOpenSet(): boolean;
        toString(): string;
        writeToStream(arg0: $FriendlyByteBuf): void;
    }

    export class $NodeEvaluator {
        constructor();
        get start(): $Node;
        getStart(): $Node;
        static isBurningBlock(arg0: $BlockState_): boolean;
        canFloat(): boolean;
        canOpenDoors(): boolean;
        canPassDoors(): boolean;
        canWalkOverFences(): boolean;
        done(): void;
        getNeighbors(arg0: $Node[], arg1: $Node): number;
        getPathTypeOfMob(arg0: $PathfindingContext, arg1: number, arg2: number, arg3: number, arg4: $Mob): $PathType;
        getPathType(arg0: $Mob, arg1: $BlockPos_): $PathType;
        getPathType(arg0: $PathfindingContext, arg1: number, arg2: number, arg3: number): $PathType;
        getTarget(arg0: number, arg1: number, arg2: number): $Target;
        prepare(arg0: $PathNavigationRegion, arg1: $Mob): void;
        setCanFloat(arg0: boolean): void;
        setCanOpenDoors(arg0: boolean): void;
        setCanPassDoors(arg0: boolean): void;
        setCanWalkOverFences(arg0: boolean): void;
    }

    export class $Path {
        constructor(arg0: $Node[], arg1: $BlockPos_, arg2: boolean);
        get distToTarget(): number;
        getDistToTarget(): number;
        get endNode(): $Node;
        getEndNode(): $Node;
        get nextNodeIndex(): number;
        getNextNodeIndex(): number;
        set nextNodeIndex(value: number);
        get nextNodePos(): $BlockPos;
        getNextNodePos(): $BlockPos;
        get nextNode(): $Node;
        getNextNode(): $Node;
        get nodeCount(): number;
        getNodeCount(): number;
        get previousNode(): $Node;
        getPreviousNode(): $Node;
        get target(): $BlockPos;
        getTarget(): $BlockPos;
        get done(): boolean;
        isDone(): boolean;
        static createFromStream(arg0: $FriendlyByteBuf): $Path;
        advance(): void;
        canReach(): boolean;
        copy(): $Path;
        debugData(): $Path$DebugData;
        getEntityPosAtNode(arg0: $Entity, arg1: number): $Vec3;
        getNextEntityPos(arg0: $Entity): $Vec3;
        getNodePos(arg0: number): $BlockPos;
        getNode(arg0: number): $Node;
        notStarted(): boolean;
        replaceNode(arg0: number, arg1: $Node): void;
        sameAs(arg0: $Path): boolean;
        setNextNodeIndex(arg0: number): void;
        toString(): string;
        truncateNodes(arg0: number): void;
        writeToStream(arg0: $FriendlyByteBuf): void;
    }

    export class $Path$DebugData extends $Record {
        constructor(arg0: $Node[], arg1: $Node[], arg2: $Target[]);
        static read(arg0: $FriendlyByteBuf): $Path$DebugData;
        closedSet(): $Node[];
        equals(arg0: object): boolean;
        hashCode(): number;
        openSet(): $Node[];
        targetNodes(): $Set<$Target>;
        toString(): string;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $PathComputationType {
        static AIR: $PathComputationType;
        static LAND: $PathComputationType;
        static WATER: $PathComputationType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PathComputationType[];
        static valueOf(name: string): $PathComputationType;
    }
    export interface $PathComputationType extends $Enum<$PathComputationType> {}

    export class $PathType {
        static BLOCKED: $PathType;
        static BREACH: $PathType;
        static COCOA: $PathType;
        static DAMAGE_CAUTIOUS: $PathType;
        static DAMAGE_FIRE: $PathType;
        static DAMAGE_OTHER: $PathType;
        static DANGER_FIRE: $PathType;
        static DANGER_OTHER: $PathType;
        static DANGER_POWDER_SNOW: $PathType;
        static DANGER_TRAPDOOR: $PathType;
        static DOOR_IRON_CLOSED: $PathType;
        static DOOR_OPEN: $PathType;
        static DOOR_WOOD_CLOSED: $PathType;
        static FENCE: $PathType;
        static LAVA: $PathType;
        static LEAVES: $PathType;
        static OPEN: $PathType;
        static POWDER_SNOW: $PathType;
        static RAIL: $PathType;
        static STICKY_HONEY: $PathType;
        static TRAPDOOR: $PathType;
        static UNPASSABLE_RAIL: $PathType;
        static WALKABLE: $PathType;
        static WALKABLE_DOOR: $PathType;
        static WATER: $PathType;
        static WATER_BORDER: $PathType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PathType[];
        static valueOf(name: string): $PathType;
    }
    export interface $PathType extends $Enum<$PathType> {}

    export class $PathTypeCache {
        constructor();
        getOrCompute(arg0: $BlockGetter, arg1: $BlockPos_): $PathType;
        invalidate(arg0: $BlockPos_): void;
    }

    export class $PathfindingContext {
        constructor(arg0: $CollisionGetter, arg1: $Mob);
        getBlockState(arg0: $BlockPos_): $BlockState;
        getPathTypeFromState(arg0: number, arg1: number, arg2: number): $PathType;
        level(): $CollisionGetter;
        mobPosition(): $BlockPos;
    }

    export class $Target extends $Node {
        constructor(arg0: number, arg1: number, arg2: number);
        constructor(arg0: $Node);
        get bestNode(): $Node;
        getBestNode(): $Node;
        get reached(): boolean;
        isReached(): boolean;
        static createFromStream(arg0: $FriendlyByteBuf): $Node;
        static createFromStream(arg0: $FriendlyByteBuf): $Target;
        setReached(): void;
        updateBest(arg0: number, arg1: $Node): void;
    }

    export type $PathComputationType_ = $PathComputationType | "AIR" | "LAND" | "WATER";
    export type $PathType_ = $PathType | "BLOCKED" | "BREACH" | "COCOA" | "DAMAGE_CAUTIOUS" | "DAMAGE_FIRE" | "DAMAGE_OTHER" | "DANGER_FIRE" | "DANGER_OTHER" | "DANGER_POWDER_SNOW" | "DANGER_TRAPDOOR" | "DOOR_IRON_CLOSED" | "DOOR_OPEN" | "DOOR_WOOD_CLOSED" | "FENCE" | "LAVA" | "LEAVES" | "OPEN" | "POWDER_SNOW" | "RAIL" | "STICKY_HONEY" | "TRAPDOOR" | "UNPASSABLE_RAIL" | "WALKABLE" | "WALKABLE_DOOR" | "WATER" | "WATER_BORDER";
}
