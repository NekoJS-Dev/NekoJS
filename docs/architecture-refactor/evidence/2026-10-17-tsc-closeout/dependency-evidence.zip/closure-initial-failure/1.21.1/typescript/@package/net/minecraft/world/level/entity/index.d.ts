import { $Class, $Iterable } from "java:java/lang";
import { $UUID } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $FullChunkStatus, $FullChunkStatus_ } from "java:net/minecraft/server/level";
import { $AbortableIterationConsumer, $AbortableIterationConsumer$Continuation, $AbortableIterationConsumer$Continuation_, $AbortableIterationConsumer_ } from "java:net/minecraft/util";
import { $Entity$RemovalReason, $Entity$RemovalReason_ } from "java:net/minecraft/world/entity";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $AABB } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/level/entity" {
    export interface $ChunkStatusUpdateListener {
        onChunkStatusChange(arg0: $ChunkPos, arg1: $FullChunkStatus_): void;
    }

    export interface $EntityAccess {
        blockPosition(): $BlockPos;
        getBoundingBox(): $AABB;
        getId(): number;
        getPassengersAndSelf(): $Stream<$EntityAccess>;
        getSelfAndPassengers(): $Stream<$EntityAccess>;
        getUUID(): $UUID;
        isAlwaysTicking(): boolean;
        setLevelCallback(arg0: $EntityInLevelCallback): void;
        setRemoved(arg0: $Entity$RemovalReason_): void;
        shouldBeSaved(): boolean;
    }

    export interface $EntityInLevelCallback {
        onMove(): void;
        onRemove(arg0: $Entity$RemovalReason_): void;
    }
    export const $EntityInLevelCallback: {
        readonly NULL: $EntityInLevelCallback;
    };

    export interface $EntityTypeTest<B, T extends B> {
        getBaseClass(): $Class<B>;
        tryCast(arg0: B): T;
    }
    export const $EntityTypeTest: {
        forClass<B, T extends B>(arg0: $Class<T>): $EntityTypeTest<B, T>;
        forExactClass<B, T extends B>(arg0: $Class<T>): $EntityTypeTest<B, T>;
    };

    export interface $LevelEntityGetter<T extends $EntityAccess> {
        getAll(): $Iterable<T>;
        get(arg0: number): T;
        get(arg0: $UUID): T;
        get<U extends T>(arg0: $EntityTypeTest<T, U>, arg1: $AbortableIterationConsumer_<U, U, $AbortableIterationConsumer$Continuation_>): void;
        get<U extends T>(arg0: $EntityTypeTest<T, U>, arg1: $AABB, arg2: $AbortableIterationConsumer_<U, U, $AbortableIterationConsumer$Continuation_>): void;
        get(arg0: $AABB, arg1: $Consumer_<T, T>): void;
    }

    export type $ChunkStatusUpdateListener_<CallbackArg0 = $ChunkPos, CallbackArg1 = $FullChunkStatus> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($ChunkStatusUpdateListener & { readonly [Symbol.hasInstance]?: never });
}
