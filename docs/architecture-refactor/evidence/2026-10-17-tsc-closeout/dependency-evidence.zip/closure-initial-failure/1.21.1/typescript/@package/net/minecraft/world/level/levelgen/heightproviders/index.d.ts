import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $RandomSource } from "java:net/minecraft/util";
import { $SimpleWeightedRandomList } from "java:net/minecraft/util/random";
import { $VerticalAnchor, $VerticalAnchor_, $WorldGenerationContext } from "java:net/minecraft/world/level/levelgen";

declare module "java:net/minecraft/world/level/levelgen/heightproviders" {
    export class $HeightProvider {
        constructor();
        static CODEC: $Codec<$HeightProvider>;
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
    }

    export interface $HeightProviderType<P extends $HeightProvider> {
        codec(): $MapCodec<P>;
    }
    export const $HeightProviderType: {
        readonly BIASED_TO_BOTTOM: $HeightProviderType<$BiasedToBottomHeight>;
        readonly CONSTANT: $HeightProviderType<$ConstantHeight>;
        readonly TRAPEZOID: $HeightProviderType<$TrapezoidHeight>;
        readonly UNIFORM: $HeightProviderType<$UniformHeight>;
        readonly VERY_BIASED_TO_BOTTOM: $HeightProviderType<$VeryBiasedToBottomHeight>;
        readonly WEIGHTED_LIST: $HeightProviderType<$WeightedListHeight>;
    };

    export class $BiasedToBottomHeight extends $HeightProvider {
        static CODEC: $MapCodec<$BiasedToBottomHeight>;
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>, arg2: number): $BiasedToBottomHeight;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $ConstantHeight extends $HeightProvider {
        static CODEC: $MapCodec<$ConstantHeight>;
        static ZERO: $ConstantHeight;
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        get value(): $VerticalAnchor;
        getValue(): $VerticalAnchor;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>): $ConstantHeight;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $TrapezoidHeight extends $HeightProvider {
        static CODEC: $MapCodec<$TrapezoidHeight>;
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>, arg2: number): $TrapezoidHeight;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>): $TrapezoidHeight;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $UniformHeight extends $HeightProvider {
        static CODEC: $MapCodec<$UniformHeight>;
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>): $UniformHeight;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $VeryBiasedToBottomHeight extends $HeightProvider {
        static CODEC: $MapCodec<$VeryBiasedToBottomHeight>;
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        static of(arg0: $VerticalAnchor_<$WorldGenerationContext, number>, arg1: $VerticalAnchor_<$WorldGenerationContext, number>, arg2: number): $VeryBiasedToBottomHeight;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
        toString(): string;
    }

    export class $WeightedListHeight extends $HeightProvider {
        constructor(arg0: $SimpleWeightedRandomList<$HeightProvider>);
        static CODEC: $MapCodec<$WeightedListHeight>;
        get type(): $HeightProviderType<any>;
        getType(): $HeightProviderType<any>;
        sample(arg0: $RandomSource, arg1: $WorldGenerationContext): number;
    }

    export type $HeightProviderType_<Host0 extends $HeightProvider = any, CallbackResult = $MapCodec<Host0>> = (() => CallbackResult) | ($HeightProviderType<Host0> & { readonly [Symbol.hasInstance]?: never });
}
