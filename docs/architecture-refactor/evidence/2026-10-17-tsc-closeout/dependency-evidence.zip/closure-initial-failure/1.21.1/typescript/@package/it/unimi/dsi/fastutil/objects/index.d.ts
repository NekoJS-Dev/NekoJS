import { $BidirectionalIterator, $Function as $NekoImport$Function, $Function_ as $NekoImport$Function_, $Stack } from "java:it/unimi/dsi/fastutil";
import { $Byte2ByteFunction, $Byte2ByteFunction_, $Byte2CharFunction, $Byte2CharFunction_, $Byte2DoubleFunction, $Byte2DoubleFunction_, $Byte2FloatFunction, $Byte2FloatFunction_, $Byte2IntFunction, $Byte2IntFunction_, $Byte2LongFunction, $Byte2LongFunction_, $Byte2ObjectFunction, $Byte2ObjectFunction_, $Byte2ReferenceFunction, $Byte2ReferenceFunction_, $Byte2ShortFunction, $Byte2ShortFunction_ } from "java:it/unimi/dsi/fastutil/bytes";
import { $Char2ByteFunction, $Char2ByteFunction_, $Char2CharFunction, $Char2CharFunction_, $Char2DoubleFunction, $Char2DoubleFunction_, $Char2FloatFunction, $Char2FloatFunction_, $Char2IntFunction, $Char2IntFunction_, $Char2LongFunction, $Char2LongFunction_, $Char2ObjectFunction, $Char2ObjectFunction_, $Char2ReferenceFunction, $Char2ReferenceFunction_, $Char2ShortFunction, $Char2ShortFunction_ } from "java:it/unimi/dsi/fastutil/chars";
import { $Double2ByteFunction, $Double2ByteFunction_, $Double2CharFunction, $Double2CharFunction_, $Double2DoubleFunction, $Double2DoubleFunction_, $Double2FloatFunction, $Double2FloatFunction_, $Double2IntFunction, $Double2IntFunction_, $Double2LongFunction, $Double2LongFunction_, $Double2ObjectFunction, $Double2ObjectFunction_, $Double2ReferenceFunction, $Double2ReferenceFunction_, $Double2ShortFunction, $Double2ShortFunction_ } from "java:it/unimi/dsi/fastutil/doubles";
import { $Float2ByteFunction, $Float2ByteFunction_, $Float2CharFunction, $Float2CharFunction_, $Float2DoubleFunction, $Float2DoubleFunction_, $Float2FloatFunction, $Float2FloatFunction_, $Float2IntFunction, $Float2IntFunction_, $Float2LongFunction, $Float2LongFunction_, $Float2ObjectFunction, $Float2ObjectFunction_, $Float2ReferenceFunction, $Float2ReferenceFunction_, $Float2ShortFunction, $Float2ShortFunction_ } from "java:it/unimi/dsi/fastutil/floats";
import { $Int2ByteFunction, $Int2ByteFunction_, $Int2CharFunction, $Int2CharFunction_, $Int2DoubleFunction, $Int2DoubleFunction_, $Int2FloatFunction, $Int2FloatFunction_, $Int2IntFunction, $Int2IntFunction_, $Int2LongFunction, $Int2LongFunction_, $Int2ObjectFunction, $Int2ObjectFunction_, $Int2ReferenceFunction, $Int2ReferenceFunction_, $Int2ShortFunction, $Int2ShortFunction_, $IntBinaryOperator as $NekoImport$IntBinaryOperator, $IntBinaryOperator_ as $NekoImport$IntBinaryOperator_, $IntCollection } from "java:it/unimi/dsi/fastutil/ints";
import { $Long2ByteFunction, $Long2ByteFunction_, $Long2CharFunction, $Long2CharFunction_, $Long2DoubleFunction, $Long2DoubleFunction_, $Long2FloatFunction, $Long2FloatFunction_, $Long2IntFunction, $Long2IntFunction_, $Long2LongFunction, $Long2LongFunction_, $Long2ObjectFunction, $Long2ObjectFunction_, $Long2ReferenceFunction, $Long2ReferenceFunction_, $Long2ShortFunction, $Long2ShortFunction_ } from "java:it/unimi/dsi/fastutil/longs";
import { $Short2ByteFunction, $Short2ByteFunction_, $Short2CharFunction, $Short2CharFunction_, $Short2DoubleFunction, $Short2DoubleFunction_, $Short2FloatFunction, $Short2FloatFunction_, $Short2IntFunction, $Short2IntFunction_, $Short2LongFunction, $Short2LongFunction_, $Short2ObjectFunction, $Short2ObjectFunction_, $Short2ReferenceFunction, $Short2ReferenceFunction_, $Short2ShortFunction, $Short2ShortFunction_ } from "java:it/unimi/dsi/fastutil/shorts";
import { $Serializable } from "java:java/io";
import { $Character, $Cloneable, $Comparable, $Comparable_, $Iterable } from "java:java/lang";
import { $AbstractCollection, $Collection, $Comparator, $Comparator_, $Iterator, $List, $ListIterator, $Map, $Map$Entry, $RandomAccess, $Set, $Spliterator } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function as $NekoImport$Function1, $Function_ as $NekoImport$Function_1, $IntBinaryOperator as $NekoImport$IntBinaryOperator1, $IntBinaryOperator_ as $NekoImport$IntBinaryOperator_1, $IntFunction, $IntFunction_, $Predicate, $Predicate_, $ToDoubleFunction, $ToDoubleFunction_, $ToIntFunction, $ToIntFunction_, $ToLongFunction, $ToLongFunction_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Collector, $Stream } from "java:java/util/stream";

declare module "java:it/unimi/dsi/fastutil/objects" {
    export interface $Object2ObjectMap<K, V> extends $Object2ObjectFunction<K, V>, $Map<K, V> {
        clear(): void;
        computeIfAbsent(arg0: K, arg1: $Object2ObjectFunction_<K, V, object, V>): V;
        computeIfAbsent(arg0: K, arg1: $NekoImport$Function_1<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        computeObjectIfAbsentPartial(arg0: K, arg1: $Object2ObjectFunction_<K, V, object, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: object): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        entrySet(): $ObjectSet<$Map$Entry<K, V>>;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        keySet(): $ObjectSet<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        object2ObjectEntrySet(): $ObjectSet<$Object2ObjectMap$Entry<K, V>>;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        values(): $ObjectCollection<V>;
    }

    export interface $Object2ObjectFunction<K, V> extends $NekoImport$Function<K, V> {
        andThenByte(arg0: $Object2ByteFunction_<V, object, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Object2CharFunction_<V, object, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Object2DoubleFunction_<V, object, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Object2FloatFunction_<V, object, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Object2IntFunction_<V, object, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Object2LongFunction_<V, object, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, object, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, object, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Object2ShortFunction_<V, object, number>): $Object2ShortFunction<K>;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2ObjectFunction<V>;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object): V;
    }

    export interface $Object2ObjectMap$Entry<K, V> extends $Map$Entry<K, V> {
    }

    export interface $ObjectCollection<K> extends $Collection<K>, $ObjectIterable<K> {
        iterator(): $ObjectIterator<K>;
        spliterator(): $ObjectSpliterator<K>;
    }

    export interface $ObjectSet<K> extends $ObjectCollection<K>, $Set<K> {
        iterator(): $ObjectIterator<K>;
        spliterator(): $ObjectSpliterator<K>;
    }
    export const $ObjectSet: {
        of<K>(arg0?: K[]): $ObjectSet<K>;
        of<K>(arg0: K, arg1: K, arg2: K): $ObjectSet<K>;
        of<K>(arg0: K, arg1: K): $ObjectSet<K>;
        of<K>(arg0: K): $ObjectSet<K>;
        of<K>(): $ObjectSet<K>;
    };

    export interface $Object2ByteFunction<K> extends $NekoImport$Function<K, number>, $ToIntFunction<K> {
        andThenByte(arg0: $Byte2ByteFunction_<number, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Byte2CharFunction_<number, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Byte2DoubleFunction_<number, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Byte2FloatFunction_<number, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Byte2IntFunction_<number, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Byte2LongFunction_<number, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Byte2ObjectFunction_<T, number, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Byte2ReferenceFunction_<T, number, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Byte2ShortFunction_<number, number>): $Object2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsInt(arg0: K): number;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2ByteFunction;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2ByteFunction;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2ByteFunction;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2ByteFunction;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2ByteFunction;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2ByteFunction;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2ByteFunction<T>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2ByteFunction<T>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2ByteFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getByte(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeByte(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Object2CharFunction<K> extends $NekoImport$Function<K, $Character>, $ToIntFunction<K> {
        andThenByte(arg0: $Char2ByteFunction_<string, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Char2CharFunction_<string, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Char2DoubleFunction_<string, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Char2FloatFunction_<string, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Char2IntFunction_<string, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Char2LongFunction_<string, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Char2ObjectFunction_<T, string, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Char2ReferenceFunction_<T, string, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Char2ShortFunction_<string, number>): $Object2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<$Character, T, $Character, T>): $NekoImport$Function1<K, T>;
        applyAsInt(arg0: K): number;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2CharFunction;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2CharFunction;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2CharFunction;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2CharFunction;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2CharFunction;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2CharFunction;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2CharFunction<T>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2CharFunction<T>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2CharFunction;
        defaultReturnValue(arg0: string): void;
        defaultReturnValue(): string;
        getChar(arg0: object): string;
        getOrDefault(arg0: object, arg1: string): string;
        getOrDefault(arg0: object, arg1: string): $Character;
        get(arg0: object): $Character;
        put(arg0: K, arg1: string): string;
        put(arg0: K, arg1: string): $Character;
        removeChar(arg0: object): string;
        remove(arg0: object): $Character;
    }

    export interface $Object2DoubleFunction<K> extends $NekoImport$Function<K, number>, $ToDoubleFunction<K> {
        andThenByte(arg0: $Double2ByteFunction_<number, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Double2CharFunction_<number, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Double2DoubleFunction_<number, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Double2FloatFunction_<number, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Double2IntFunction_<number, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Double2LongFunction_<number, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Double2ObjectFunction_<T, number, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Double2ReferenceFunction_<T, number, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Double2ShortFunction_<number, number>): $Object2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsDouble(arg0: K): number;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2DoubleFunction;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2DoubleFunction;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2DoubleFunction;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2DoubleFunction;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2DoubleFunction;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2DoubleFunction;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2DoubleFunction<T>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2DoubleFunction<T>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2DoubleFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getDouble(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeDouble(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Object2FloatFunction<K> extends $NekoImport$Function<K, number>, $ToDoubleFunction<K> {
        andThenByte(arg0: $Float2ByteFunction_<number, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Float2CharFunction_<number, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Float2DoubleFunction_<number, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Float2FloatFunction_<number, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Float2IntFunction_<number, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Float2LongFunction_<number, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Float2ObjectFunction_<T, number, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Float2ReferenceFunction_<T, number, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Float2ShortFunction_<number, number>): $Object2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsDouble(arg0: K): number;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2FloatFunction;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2FloatFunction;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2FloatFunction;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2FloatFunction;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2FloatFunction;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2FloatFunction;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2FloatFunction<T>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2FloatFunction<T>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2FloatFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getFloat(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeFloat(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Object2IntFunction<K> extends $NekoImport$Function<K, number>, $ToIntFunction<K> {
        andThenByte(arg0: $Int2ByteFunction_<number, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Int2CharFunction_<number, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Int2DoubleFunction_<number, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Int2FloatFunction_<number, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Int2IntFunction_<number, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Int2LongFunction_<number, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Int2ObjectFunction_<T, number, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Int2ReferenceFunction_<T, number, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Int2ShortFunction_<number, number>): $Object2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsInt(arg0: K): number;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2IntFunction;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2IntFunction;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2IntFunction;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2IntFunction;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2IntFunction;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2IntFunction;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2IntFunction<T>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2IntFunction<T>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2IntFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getInt(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeInt(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Object2LongFunction<K> extends $NekoImport$Function<K, number>, $ToLongFunction<K> {
        andThenByte(arg0: $Long2ByteFunction_<number, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Long2CharFunction_<number, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Long2DoubleFunction_<number, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Long2FloatFunction_<number, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Long2IntFunction_<number, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Long2LongFunction_<number, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Long2ObjectFunction_<T, number, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Long2ReferenceFunction_<T, number, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Long2ShortFunction_<number, number>): $Object2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsLong(arg0: K): number;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2LongFunction;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2LongFunction;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2LongFunction;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2LongFunction;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2LongFunction;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2LongFunction;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2LongFunction<T>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2LongFunction<T>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2LongFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getLong(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeLong(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Object2ReferenceFunction<K, V> extends $NekoImport$Function<K, V> {
        andThenByte(arg0: $Reference2ByteFunction_<V, object, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Reference2CharFunction_<V, object, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Reference2DoubleFunction_<V, object, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Reference2FloatFunction_<V, object, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Reference2IntFunction_<V, object, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Reference2LongFunction_<V, object, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Reference2ObjectFunction_<V, T, object, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Reference2ReferenceFunction_<V, T, object, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Reference2ShortFunction_<V, object, number>): $Object2ShortFunction<K>;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2ReferenceFunction<V>;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2ReferenceFunction<V>;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2ReferenceFunction<V>;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2ReferenceFunction<V>;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2ReferenceFunction<V>;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2ReferenceFunction<V>;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2ReferenceFunction<T, V>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2ReferenceFunction<T, V>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2ReferenceFunction<V>;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object): V;
    }

    export interface $Object2ShortFunction<K> extends $NekoImport$Function<K, number>, $ToIntFunction<K> {
        andThenByte(arg0: $Short2ByteFunction_<number, number>): $Object2ByteFunction<K>;
        andThenChar(arg0: $Short2CharFunction_<number, string>): $Object2CharFunction<K>;
        andThenDouble(arg0: $Short2DoubleFunction_<number, number>): $Object2DoubleFunction<K>;
        andThenFloat(arg0: $Short2FloatFunction_<number, number>): $Object2FloatFunction<K>;
        andThenInt(arg0: $Short2IntFunction_<number, number>): $Object2IntFunction<K>;
        andThenLong(arg0: $Short2LongFunction_<number, number>): $Object2LongFunction<K>;
        andThenObject<T>(arg0: $Short2ObjectFunction_<T, number, T>): $Object2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Short2ReferenceFunction_<T, number, T>): $Object2ReferenceFunction<K, T>;
        andThenShort(arg0: $Short2ShortFunction_<number, number>): $Object2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsInt(arg0: K): number;
        composeByte(arg0: $Byte2ObjectFunction_<K, number, K>): $Byte2ShortFunction;
        composeChar(arg0: $Char2ObjectFunction_<K, string, K>): $Char2ShortFunction;
        composeDouble(arg0: $Double2ObjectFunction_<K, number, K>): $Double2ShortFunction;
        composeFloat(arg0: $Float2ObjectFunction_<K, number, K>): $Float2ShortFunction;
        composeInt(arg0: $Int2ObjectFunction_<K, number, K>): $Int2ShortFunction;
        composeLong(arg0: $Long2ObjectFunction_<K, number, K>): $Long2ShortFunction;
        composeObject<T>(arg0: $Object2ObjectFunction_<T, K, object, K>): $Object2ShortFunction<T>;
        composeReference<T>(arg0: $Reference2ObjectFunction_<T, K, object, K>): $Reference2ShortFunction<T>;
        composeShort(arg0: $Short2ObjectFunction_<K, number, K>): $Short2ShortFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        getShort(arg0: object): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeShort(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Reference2ObjectFunction<K, V> extends $NekoImport$Function<K, V> {
        andThenByte(arg0: $Object2ByteFunction_<V, object, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Object2CharFunction_<V, object, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Object2DoubleFunction_<V, object, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Object2FloatFunction_<V, object, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Object2IntFunction_<V, object, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Object2LongFunction_<V, object, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, object, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, object, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Object2ShortFunction_<V, object, number>): $Reference2ShortFunction<K>;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2ObjectFunction<V>;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object): V;
    }

    export interface $Reference2ByteFunction<K> extends $NekoImport$Function<K, number>, $ToIntFunction<K> {
        andThenByte(arg0: $Byte2ByteFunction_<number, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Byte2CharFunction_<number, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Byte2DoubleFunction_<number, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Byte2FloatFunction_<number, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Byte2IntFunction_<number, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Byte2LongFunction_<number, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Byte2ObjectFunction_<T, number, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Byte2ReferenceFunction_<T, number, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Byte2ShortFunction_<number, number>): $Reference2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsInt(arg0: K): number;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2ByteFunction;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2ByteFunction;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2ByteFunction;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2ByteFunction;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2ByteFunction;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2ByteFunction;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2ByteFunction<T>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2ByteFunction<T>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2ByteFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getByte(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeByte(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Reference2CharFunction<K> extends $NekoImport$Function<K, $Character>, $ToIntFunction<K> {
        andThenByte(arg0: $Char2ByteFunction_<string, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Char2CharFunction_<string, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Char2DoubleFunction_<string, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Char2FloatFunction_<string, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Char2IntFunction_<string, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Char2LongFunction_<string, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Char2ObjectFunction_<T, string, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Char2ReferenceFunction_<T, string, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Char2ShortFunction_<string, number>): $Reference2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<$Character, T, $Character, T>): $NekoImport$Function1<K, T>;
        applyAsInt(arg0: K): number;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2CharFunction;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2CharFunction;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2CharFunction;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2CharFunction;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2CharFunction;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2CharFunction;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2CharFunction<T>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2CharFunction<T>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2CharFunction;
        defaultReturnValue(arg0: string): void;
        defaultReturnValue(): string;
        getChar(arg0: object): string;
        getOrDefault(arg0: object, arg1: string): string;
        getOrDefault(arg0: object, arg1: string): $Character;
        get(arg0: object): $Character;
        put(arg0: K, arg1: string): string;
        put(arg0: K, arg1: string): $Character;
        removeChar(arg0: object): string;
        remove(arg0: object): $Character;
    }

    export interface $Reference2DoubleFunction<K> extends $NekoImport$Function<K, number>, $ToDoubleFunction<K> {
        andThenByte(arg0: $Double2ByteFunction_<number, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Double2CharFunction_<number, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Double2DoubleFunction_<number, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Double2FloatFunction_<number, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Double2IntFunction_<number, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Double2LongFunction_<number, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Double2ObjectFunction_<T, number, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Double2ReferenceFunction_<T, number, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Double2ShortFunction_<number, number>): $Reference2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsDouble(arg0: K): number;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2DoubleFunction;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2DoubleFunction;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2DoubleFunction;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2DoubleFunction;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2DoubleFunction;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2DoubleFunction;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2DoubleFunction<T>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2DoubleFunction<T>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2DoubleFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getDouble(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeDouble(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Reference2FloatFunction<K> extends $NekoImport$Function<K, number>, $ToDoubleFunction<K> {
        andThenByte(arg0: $Float2ByteFunction_<number, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Float2CharFunction_<number, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Float2DoubleFunction_<number, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Float2FloatFunction_<number, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Float2IntFunction_<number, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Float2LongFunction_<number, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Float2ObjectFunction_<T, number, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Float2ReferenceFunction_<T, number, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Float2ShortFunction_<number, number>): $Reference2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsDouble(arg0: K): number;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2FloatFunction;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2FloatFunction;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2FloatFunction;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2FloatFunction;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2FloatFunction;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2FloatFunction;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2FloatFunction<T>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2FloatFunction<T>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2FloatFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getFloat(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeFloat(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Reference2IntFunction<K> extends $NekoImport$Function<K, number>, $ToIntFunction<K> {
        andThenByte(arg0: $Int2ByteFunction_<number, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Int2CharFunction_<number, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Int2DoubleFunction_<number, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Int2FloatFunction_<number, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Int2IntFunction_<number, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Int2LongFunction_<number, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Int2ObjectFunction_<T, number, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Int2ReferenceFunction_<T, number, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Int2ShortFunction_<number, number>): $Reference2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsInt(arg0: K): number;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2IntFunction;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2IntFunction;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2IntFunction;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2IntFunction;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2IntFunction;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2IntFunction;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2IntFunction<T>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2IntFunction<T>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2IntFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getInt(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeInt(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Reference2LongFunction<K> extends $NekoImport$Function<K, number>, $ToLongFunction<K> {
        andThenByte(arg0: $Long2ByteFunction_<number, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Long2CharFunction_<number, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Long2DoubleFunction_<number, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Long2FloatFunction_<number, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Long2IntFunction_<number, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Long2LongFunction_<number, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Long2ObjectFunction_<T, number, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Long2ReferenceFunction_<T, number, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Long2ShortFunction_<number, number>): $Reference2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsLong(arg0: K): number;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2LongFunction;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2LongFunction;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2LongFunction;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2LongFunction;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2LongFunction;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2LongFunction;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2LongFunction<T>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2LongFunction<T>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2LongFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getLong(arg0: object): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeLong(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $Reference2ReferenceFunction<K, V> extends $NekoImport$Function<K, V> {
        andThenByte(arg0: $Reference2ByteFunction_<V, object, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Reference2CharFunction_<V, object, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Reference2DoubleFunction_<V, object, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Reference2FloatFunction_<V, object, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Reference2IntFunction_<V, object, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Reference2LongFunction_<V, object, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Reference2ObjectFunction_<V, T, object, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Reference2ReferenceFunction_<V, T, object, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Reference2ShortFunction_<V, object, number>): $Reference2ShortFunction<K>;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2ReferenceFunction<V>;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2ReferenceFunction<V>;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2ReferenceFunction<V>;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2ReferenceFunction<V>;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2ReferenceFunction<V>;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2ReferenceFunction<V>;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2ReferenceFunction<T, V>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2ReferenceFunction<T, V>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2ReferenceFunction<V>;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object): V;
    }

    export interface $Reference2ShortFunction<K> extends $NekoImport$Function<K, number>, $ToIntFunction<K> {
        andThenByte(arg0: $Short2ByteFunction_<number, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Short2CharFunction_<number, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Short2DoubleFunction_<number, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Short2FloatFunction_<number, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Short2IntFunction_<number, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Short2LongFunction_<number, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Short2ObjectFunction_<T, number, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Short2ReferenceFunction_<T, number, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Short2ShortFunction_<number, number>): $Reference2ShortFunction<K>;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<K, T>;
        applyAsInt(arg0: K): number;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2ShortFunction;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2ShortFunction;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2ShortFunction;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2ShortFunction;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2ShortFunction;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2ShortFunction;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2ShortFunction<T>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2ShortFunction<T>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2ShortFunction;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        getShort(arg0: object): number;
        get(arg0: object): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        removeShort(arg0: object): number;
        remove(arg0: object): number;
    }

    export interface $ObjectIterable<K> extends $Iterable<K> {
        iterator(): $ObjectIterator<K>;
        spliterator(): $ObjectSpliterator<K>;
    }

    export interface $ObjectIterator<K> extends $Iterator<K> {
        skip(arg0: number): number;
    }

    export interface $ObjectSpliterator<K> extends $Spliterator<K> {
        skip(arg0: number): number;
        trySplit(): $ObjectSpliterator<K>;
    }

    export interface $ObjectBidirectionalIterator<K> extends $ObjectIterator<K>, $BidirectionalIterator<K> {
        back(arg0: number): number;
        skip(arg0: number): number;
    }

    export interface $Object2IntMap<K> extends $Object2IntFunction<K>, $Map<K, number> {
        clear(): void;
        computeIfAbsent(arg0: K, arg1: $Object2IntFunction_<K, object, number>): number;
        computeIfAbsent(arg0: K, arg1: $NekoImport$Function_1<K, number, K, number>): number;
        computeIfAbsent(arg0: K, arg1: $ToIntFunction_<K, K, number>): number;
        computeIntIfAbsentPartial(arg0: K, arg1: $Object2IntFunction_<K, object, number>): number;
        computeIntIfAbsent(arg0: K, arg1: $ToIntFunction_<K, K, number>): number;
        computeIntIfPresent(arg0: K, arg1: $BiFunction_<K, number, number, K, number, number>): number;
        computeInt(arg0: K, arg1: $BiFunction_<K, number, number, K, number, number>): number;
        containsKey(arg0: object): boolean;
        containsValue(arg0: number): boolean;
        containsValue(arg0: object): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        entrySet(): $ObjectSet<$Map$Entry<K, number>>;
        forEach(arg0: $BiConsumer_<K, number, K, number>): void;
        getOrDefault(arg0: object, arg1: number): number;
        getOrDefault(arg0: object, arg1: number): number;
        get(arg0: object): number;
        keySet(): $ObjectSet<K>;
        mergeInt(arg0: K, arg1: number, arg2: $NekoImport$IntBinaryOperator_<number, number, number>): number;
        mergeInt(arg0: K, arg1: number, arg2: $BiFunction_<number, number, number, number, number, number>): number;
        mergeInt(arg0: K, arg1: number, arg2: $NekoImport$IntBinaryOperator_1<number, number, number>): number;
        merge(arg0: K, arg1: number, arg2: $BiFunction_<number, number, number, number, number, number>): number;
        merge(arg0: K, arg1: number, arg2: $BiFunction_<number, number, number, number, number, number>): number;
        object2IntEntrySet(): $ObjectSet<$Object2IntMap$Entry<K>>;
        putIfAbsent(arg0: K, arg1: number): number;
        putIfAbsent(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        put(arg0: K, arg1: number): number;
        remove(arg0: object, arg1: number): boolean;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): number;
        replace(arg0: K, arg1: number, arg2: number): boolean;
        replace(arg0: K, arg1: number): number;
        replace(arg0: K, arg1: number, arg2: number): boolean;
        replace(arg0: K, arg1: number): number;
        size(): number;
        values(): $IntCollection;
    }

    export interface $Object2IntMap$Entry<K> extends $Map$Entry<K, number> {
        getIntValue(): number;
        getValue(): number;
        setValue(arg0: number): number;
        setValue(arg0: number): number;
    }

    export class $Reference2ObjectArrayMap<K, V> extends $AbstractReference2ObjectMap<K, V> implements $Serializable, $Cloneable {
        constructor();
        constructor(arg0: number);
        constructor(arg0: $Reference2ObjectMap<K, V>);
        constructor(arg0: object[], arg1: object[]);
        constructor(arg0: object[], arg1: object[], arg2: number);
        constructor(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)));
        get empty(): boolean;
        isEmpty(): boolean;
        andThenByte(arg0: $Object2ByteFunction_<V, object, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Object2CharFunction_<V, object, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Object2DoubleFunction_<V, object, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Object2FloatFunction_<V, object, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Object2IntFunction_<V, object, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Object2LongFunction_<V, object, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, object, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, object, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Object2ShortFunction_<V, object, number>): $Reference2ShortFunction<K>;
        andThen<V1>(arg0: $NekoImport$Function_1<V, V1, V, V1>): $NekoImport$Function1<K, V1>;
        apply(arg0: K): V;
        clear(): void;
        clone(): $Reference2ObjectArrayMap<K, V>;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2ObjectFunction<V>;
        compose<V1>(arg0: $NekoImport$Function_1<V1, K, V1, K>): $NekoImport$Function1<V1, V>;
        computeIfAbsent(arg0: K, arg1: $Reference2ObjectFunction_<K, V, object, V>): V;
        computeIfAbsent(arg0: K, arg1: $NekoImport$Function_1<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        computeObjectIfAbsentPartial(arg0: K, arg1: $Reference2ObjectFunction_<K, V, object, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: object): boolean;
        containsValue(arg0: object): boolean;
        entrySet(): $ObjectSet<$Map$Entry<K, V>>;
        equals(arg0: object): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        hashCode(): number;
        keySet(): $ReferenceSet<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        reference2ObjectEntrySet(): $Reference2ObjectMap$FastEntrySet<K, V>;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        replaceAll(arg0: $BiFunction_<K, V, V, K, V, V>): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        values(): $ObjectCollection<V>;
    }

    export class $AbstractReference2ObjectMap<K, V> extends $AbstractReference2ObjectFunction<K, V> implements $Reference2ObjectMap<K, V>, $Serializable {
        get empty(): boolean;
        isEmpty(): boolean;
        andThenByte(arg0: $Object2ByteFunction_<V, object, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Object2CharFunction_<V, object, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Object2DoubleFunction_<V, object, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Object2FloatFunction_<V, object, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Object2IntFunction_<V, object, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Object2LongFunction_<V, object, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, object, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, object, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Object2ShortFunction_<V, object, number>): $Reference2ShortFunction<K>;
        andThen<V1>(arg0: $NekoImport$Function_1<V, V1, V, V1>): $NekoImport$Function1<K, V1>;
        apply(arg0: K): V;
        clear(): void;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2ObjectFunction<V>;
        compose<V1>(arg0: $NekoImport$Function_1<V1, K, V1, K>): $NekoImport$Function1<V1, V>;
        computeIfAbsent(arg0: K, arg1: $Reference2ObjectFunction_<K, V, object, V>): V;
        computeIfAbsent(arg0: K, arg1: $NekoImport$Function_1<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        computeObjectIfAbsentPartial(arg0: K, arg1: $Reference2ObjectFunction_<K, V, object, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: object): boolean;
        containsValue(arg0: object): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        entrySet(): $ObjectSet<$Map$Entry<K, V>>;
        equals(arg0: object): boolean;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        get(arg0: object): V;
        hashCode(): number;
        keySet(): $ReferenceSet<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putAll(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): void;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        reference2ObjectEntrySet(): $ObjectSet<$Reference2ObjectMap$Entry<K, V>>;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        replaceAll(arg0: $BiFunction_<K, V, V, K, V, V>): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        toString(): string;
        values(): $ObjectCollection<V>;
    }

    export interface $Reference2ObjectMap<K, V> extends $Reference2ObjectFunction<K, V>, $Map<K, V> {
        clear(): void;
        computeIfAbsent(arg0: K, arg1: $Reference2ObjectFunction_<K, V, object, V>): V;
        computeIfAbsent(arg0: K, arg1: $NekoImport$Function_1<K, V, K, V>): V;
        computeIfPresent(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        computeObjectIfAbsentPartial(arg0: K, arg1: $Reference2ObjectFunction_<K, V, object, V>): V;
        compute(arg0: K, arg1: $BiFunction_<K, V, V, K, V, V>): V;
        containsKey(arg0: object): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        entrySet(): $ObjectSet<$Map$Entry<K, V>>;
        forEach(arg0: $BiConsumer_<K, V, K, V>): void;
        getOrDefault(arg0: object, arg1: V): V;
        keySet(): $ReferenceSet<K>;
        merge(arg0: K, arg1: V, arg2: $BiFunction_<V, V, V, V, V, V>): V;
        putIfAbsent(arg0: K, arg1: V): V;
        put(arg0: K, arg1: V): V;
        reference2ObjectEntrySet(): $ObjectSet<$Reference2ObjectMap$Entry<K, V>>;
        remove(arg0: object, arg1: object): boolean;
        remove(arg0: object): V;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replace(arg0: K, arg1: V): V;
        size(): number;
        values(): $ObjectCollection<V>;
    }

    export interface $Reference2ObjectMap$FastEntrySet<K, V> extends $ObjectSet<$Reference2ObjectMap$Entry<K, V>> {
        fastForEach(arg0: $Consumer_<$Reference2ObjectMap$Entry<K, V>, $Reference2ObjectMap$Entry<K, V>>): void;
        fastIterator(): $ObjectIterator<$Reference2ObjectMap$Entry<K, V>>;
    }

    export interface $ReferenceSet<K> extends $ReferenceCollection<K>, $Set<K> {
        iterator(): $ObjectIterator<K>;
        spliterator(): $ObjectSpliterator<K>;
    }
    export const $ReferenceSet: {
        of<K>(arg0?: K[]): $ReferenceSet<K>;
        of<K>(arg0: K, arg1: K, arg2: K): $ReferenceSet<K>;
        of<K>(arg0: K, arg1: K): $ReferenceSet<K>;
        of<K>(arg0: K): $ReferenceSet<K>;
        of<K>(): $ReferenceSet<K>;
    };

    export class $AbstractReference2ObjectFunction<K, V> implements $Reference2ObjectFunction<K, V>, $Serializable {
        andThenByte(arg0: $Object2ByteFunction_<V, object, number>): $Reference2ByteFunction<K>;
        andThenChar(arg0: $Object2CharFunction_<V, object, string>): $Reference2CharFunction<K>;
        andThenDouble(arg0: $Object2DoubleFunction_<V, object, number>): $Reference2DoubleFunction<K>;
        andThenFloat(arg0: $Object2FloatFunction_<V, object, number>): $Reference2FloatFunction<K>;
        andThenInt(arg0: $Object2IntFunction_<V, object, number>): $Reference2IntFunction<K>;
        andThenLong(arg0: $Object2LongFunction_<V, object, number>): $Reference2LongFunction<K>;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, object, T>): $Reference2ObjectFunction<K, T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, object, T>): $Reference2ReferenceFunction<K, T>;
        andThenShort(arg0: $Object2ShortFunction_<V, object, number>): $Reference2ShortFunction<K>;
        andThen<V1>(arg0: $NekoImport$Function_1<V, V1, V, V1>): $NekoImport$Function1<K, V1>;
        apply(arg0: K): V;
        clear(): void;
        composeByte(arg0: $Byte2ReferenceFunction_<K, number, K>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2ReferenceFunction_<K, string, K>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2ReferenceFunction_<K, number, K>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2ReferenceFunction_<K, number, K>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2ReferenceFunction_<K, number, K>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2ReferenceFunction_<K, number, K>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2ReferenceFunction_<T, K, object, K>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2ReferenceFunction_<T, K, object, K>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2ReferenceFunction_<K, number, K>): $Short2ObjectFunction<V>;
        compose<V1>(arg0: $NekoImport$Function_1<V1, K, V1, K>): $NekoImport$Function1<V1, V>;
        containsKey(arg0: object): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: object, arg1: V): V;
        get(arg0: object): V;
        put(arg0: K, arg1: V): V;
        remove(arg0: object): V;
        size(): number;
    }

    export interface $Reference2ObjectMap$Entry<K, V> extends $Map$Entry<K, V> {
    }

    export interface $ReferenceCollection<K> extends $Collection<K>, $ObjectIterable<K> {
        iterator(): $ObjectIterator<K>;
        spliterator(): $ObjectSpliterator<K>;
    }

    export class $ObjectArrayList<K> extends $AbstractObjectList<K> implements $RandomAccess, $Cloneable, $Serializable {
        constructor();
        constructor(arg0: K[]);
        constructor(arg0: K[], arg1: number, arg2: number);
        constructor(arg0: number);
        constructor(arg0: $ObjectCollection<K>);
        constructor(arg0: $ObjectIterator<K>);
        constructor(arg0: $ObjectList<K>);
        constructor(arg0: K[]);
        constructor(arg0: K);
        static DEFAULT_INITIAL_CAPACITY: number;
        get first(): K;
        getFirst(): K;
        get last(): K;
        getLast(): K;
        get empty(): boolean;
        isEmpty(): boolean;
        static of<K>(arg0?: K[]): $ObjectArrayList<K>;
        static of<K>(): $ObjectArrayList<K>;
        static toListWithExpectedSize<K>(arg0: number): $Collector<K, any, $ObjectArrayList<K>>;
        static toList<K>(): $Collector<K, any, $ObjectArrayList<K>>;
        static wrap<K>(arg0: K[], arg1: number): $ObjectArrayList<K>;
        static wrap<K>(arg0: K[]): $ObjectArrayList<K>;
        addAll(arg0: number, arg1: $ObjectList<K>): boolean;
        addAll(arg0: number, arg1: K[]): boolean;
        addAll(arg0: $ObjectList<K>): boolean;
        addAll(arg0: K[]): boolean;
        addElements(arg0: number, arg1: K[], arg2: number, arg3: number): void;
        addElements(arg0: number, arg1: K[]): void;
        addFirst(arg0: K): void;
        addLast(arg0: K): void;
        add(arg0: K): boolean;
        add(arg0: number, arg1: K): void;
        clear(): void;
        clone(): $ObjectArrayList<K>;
        compareTo(arg0: $ObjectArrayList<K>): number;
        compareTo(arg0: K[]): number;
        elements(): K[];
        ensureCapacity(arg0: number): void;
        equals(arg0: $ObjectArrayList<K>): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<K, K>): void;
        getElements(arg0: number, arg1: object[], arg2: number, arg3: number): void;
        get(arg0: number): K;
        hashCode(): number;
        indexOf(arg0: object): number;
        lastIndexOf(arg0: object): number;
        listIterator(arg0: number): $ObjectListIterator<K>;
        listIterator(): $ObjectListIterator<K>;
        parallelStream(): $Stream<K>;
        removeAll(arg0: any[]): boolean;
        removeElements(arg0: number, arg1: number): void;
        removeFirst(): K;
        removeIf(arg0: $Predicate_<K, K, boolean>): boolean;
        removeLast(): K;
        remove(arg0: number): K;
        remove(arg0: object): boolean;
        replaceAll(arg0: $UnaryOperator_<K, K, K>): void;
        reversed(): $List<K>;
        setElements(arg0: K[]): void;
        setElements(arg0: number, arg1: K[], arg2: number, arg3: number): void;
        setElements(arg0: number, arg1: K[]): void;
        set(arg0: number, arg1: K): K;
        size(arg0: number): void;
        size(): number;
        sort(arg0: $Comparator_<K, K, K, number>): void;
        spliterator(): $ObjectSpliterator<K>;
        stream(): $Stream<K>;
        subList(arg0: number, arg1: number): $ObjectList<K>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
        trim(arg0: number): void;
        trim(): void;
        unstableSort(arg0: $Comparator_<K, K, K, number>): void;
    }

    export class $AbstractObjectList<K> extends $AbstractObjectCollection<K> implements $ObjectList<K>, $Stack<K> {
        get first(): K;
        getFirst(): K;
        get last(): K;
        getLast(): K;
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(arg0: number, arg1: $ObjectList<K>): boolean;
        addAll(arg0: number, arg1: K[]): boolean;
        addAll(arg0: $ObjectList<K>): boolean;
        addAll(arg0: K[]): boolean;
        addElements(arg0: number, arg1: K[], arg2: number, arg3: number): void;
        addElements(arg0: number, arg1: K[]): void;
        addFirst(arg0: K): void;
        addLast(arg0: K): void;
        add(arg0: K): boolean;
        add(arg0: number, arg1: K): void;
        clear(): void;
        compareTo(arg0: K[]): number;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<K, K>): void;
        getElements(arg0: number, arg1: object[], arg2: number, arg3: number): void;
        get(arg0: number): K;
        hashCode(): number;
        indexOf(arg0: object): number;
        iterator(): $ObjectListIterator<K>;
        lastIndexOf(arg0: object): number;
        listIterator(arg0: number): $ObjectListIterator<K>;
        listIterator(): $ObjectListIterator<K>;
        parallelStream(): $Stream<K>;
        peek(arg0: number): K;
        pop(): K;
        push(arg0: K): void;
        removeAll(arg0: any[]): boolean;
        removeElements(arg0: number, arg1: number): void;
        removeFirst(): K;
        removeIf(arg0: $Predicate_<K, K, boolean>): boolean;
        removeLast(): K;
        remove(arg0: number): K;
        remove(arg0: object): boolean;
        replaceAll(arg0: $UnaryOperator_<K, K, K>): void;
        retainAll(arg0: any[]): boolean;
        reversed(): $List<K>;
        setElements(arg0: K[]): void;
        setElements(arg0: number, arg1: K[], arg2: number, arg3: number): void;
        setElements(arg0: number, arg1: K[]): void;
        set(arg0: number, arg1: K): K;
        size(arg0: number): void;
        size(): number;
        sort(arg0: $Comparator_<K, K, K, number>): void;
        spliterator(): $ObjectSpliterator<K>;
        stream(): $Stream<K>;
        subList(arg0: number, arg1: number): $ObjectList<K>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
        toString(): string;
        top(): K;
        unstableSort(arg0: $Comparator_<K, K, K, number>): void;
    }

    export interface $ObjectList<K> extends $List<K>, $Comparable<$List<K>>, $ObjectCollection<K> {
        addAll(arg0: number, arg1: $ObjectList<K>): boolean;
        addAll(arg0: number, arg1: K[]): boolean;
        addAll(arg0: $ObjectList<K>): boolean;
        addAll(arg0: K[]): boolean;
        addElements(arg0: number, arg1: K[], arg2: number, arg3: number): void;
        addElements(arg0: number, arg1: K[]): void;
        getElements(arg0: number, arg1: object[], arg2: number, arg3: number): void;
        iterator(): $ObjectListIterator<K>;
        listIterator(arg0: number): $ObjectListIterator<K>;
        listIterator(): $ObjectListIterator<K>;
        removeElements(arg0: number, arg1: number): void;
        setElements(arg0: K[]): void;
        setElements(arg0: number, arg1: K[], arg2: number, arg3: number): void;
        setElements(arg0: number, arg1: K[]): void;
        size(arg0: number): void;
        size(): number;
        sort(arg0: $Comparator_<K, K, K, number>): void;
        spliterator(): $ObjectSpliterator<K>;
        subList(arg0: number, arg1: number): $ObjectList<K>;
        unstableSort(arg0: $Comparator_<K, K, K, number>): void;
    }
    export const $ObjectList: {
        of<K>(arg0?: K[]): $ObjectList<K>;
        of<K>(arg0: K, arg1: K, arg2: K): $ObjectList<K>;
        of<K>(arg0: K, arg1: K): $ObjectList<K>;
        of<K>(arg0: K): $ObjectList<K>;
        of<K>(): $ObjectList<K>;
    };

    export interface $ObjectListIterator<K> extends $ObjectBidirectionalIterator<K>, $ListIterator<K> {
        add(arg0: K): void;
        remove(): void;
        set(arg0: K): void;
    }

    export class $AbstractObjectCollection<K> extends $AbstractCollection<K> implements $ObjectCollection<K> {
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(arg0: K[]): boolean;
        add(arg0: K): boolean;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(arg0: object): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<K, K>): void;
        hashCode(): number;
        iterator(): $ObjectIterator<K>;
        parallelStream(): $Stream<K>;
        removeAll(arg0: any[]): boolean;
        removeIf(arg0: $Predicate_<K, K, boolean>): boolean;
        remove(arg0: object): boolean;
        retainAll(arg0: any[]): boolean;
        size(): number;
        spliterator(): $ObjectSpliterator<K>;
        stream(): $Stream<K>;
        toArray<T>(arg0: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
        toString(): string;
    }

    export type $Object2ObjectFunction_<Host0 = any, Host1 = any, CallbackArg0 = object, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2ObjectFunction<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
    export type $Object2ByteFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2ByteFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Object2CharFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2CharFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Object2DoubleFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2DoubleFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Object2FloatFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2FloatFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Object2IntFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2IntFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Object2LongFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2LongFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Object2ReferenceFunction_<Host0 = any, Host1 = any, CallbackArg0 = object, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2ReferenceFunction<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
    export type $Object2ShortFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Object2ShortFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2ObjectFunction_<Host0 = any, Host1 = any, CallbackArg0 = object, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2ObjectFunction<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2ByteFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2ByteFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2CharFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2CharFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2DoubleFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2DoubleFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2FloatFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2FloatFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2IntFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2IntFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2LongFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2LongFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2ReferenceFunction_<Host0 = any, Host1 = any, CallbackArg0 = object, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2ReferenceFunction<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
    export type $Reference2ShortFunction_<Host0 = any, CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Reference2ShortFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $ObjectIterable_<Host0 = any, CallbackResult = $ObjectIterator<Host0>> = (() => CallbackResult) | ($ObjectIterable<Host0> & { readonly [Symbol.hasInstance]?: never });
}
