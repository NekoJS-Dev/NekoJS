import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $BiConsumer, $BiConsumer_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $IntProvider } from "java:net/minecraft/util/valueproviders";
import { $LevelSimulatedReader } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $TreeConfiguration } from "java:net/minecraft/world/level/levelgen/feature/configurations";
import { $BlockStateProvider } from "java:net/minecraft/world/level/levelgen/feature/stateproviders";

declare module "java:net/minecraft/world/level/levelgen/feature/rootplacers" {
    export class $AboveRootPlacement extends $Record {
        constructor(arg0: $BlockStateProvider, arg1: number);
        static CODEC: $Codec<$AboveRootPlacement>;
        aboveRootPlacementChance(): number;
        aboveRootProvider(): $BlockStateProvider;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $RootPlacer {
        constructor(arg0: $IntProvider, arg1: $BlockStateProvider, arg2: $Optional<$AboveRootPlacement>);
        static CODEC: $Codec<$RootPlacer>;
        getTrunkOrigin(arg0: $BlockPos_, arg1: $RandomSource): $BlockPos;
        placeRoots(arg0: $LevelSimulatedReader, arg1: $BiConsumer_<$BlockPos, $BlockState, $BlockPos, $BlockState>, arg2: $RandomSource, arg3: $BlockPos_, arg4: $BlockPos_, arg5: $TreeConfiguration): boolean;
    }

}
