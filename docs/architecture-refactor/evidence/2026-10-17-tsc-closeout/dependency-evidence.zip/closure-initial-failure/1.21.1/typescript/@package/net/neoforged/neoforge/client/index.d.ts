export * as extensions from "java:net/neoforged/neoforge/client/extensions";
export * as model from "java:net/neoforged/neoforge/client/model";

