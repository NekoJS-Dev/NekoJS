import { $ItemEntity } from "java:net/minecraft/world/entity/item";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $ICancellableEvent } from "java:net/neoforged/bus/api";
import { $EntityEvent } from "java:net/neoforged/neoforge/event/entity";

declare module "java:net/neoforged/neoforge/event/entity/item" {
    export class $ItemEvent extends $EntityEvent {
        constructor(arg0: $ItemEntity);
        get entity(): $ItemEntity;
        getEntity(): $ItemEntity;
    }

    export class $ItemTossEvent extends $ItemEvent implements $ICancellableEvent {
        constructor(arg0: $ItemEntity, arg1: $Player);
        get player(): $Player;
        getPlayer(): $Player;
        get canceled(): boolean;
        isCanceled(): boolean;
        set canceled(value: boolean);
        setCanceled(arg0: boolean): void;
    }

}
