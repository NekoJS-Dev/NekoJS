export * as data from "java:net/neoforged/neoforge/client/model/data";

