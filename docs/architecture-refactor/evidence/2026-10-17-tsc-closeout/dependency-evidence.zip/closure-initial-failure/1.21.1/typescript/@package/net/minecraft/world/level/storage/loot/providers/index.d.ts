export * as number from "java:net/minecraft/world/level/storage/loot/providers/number";
export * as nbt from "java:net/minecraft/world/level/storage/loot/providers/nbt";
export * as score from "java:net/minecraft/world/level/storage/loot/providers/score";

