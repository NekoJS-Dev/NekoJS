import { $Set } from "java:java/util";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ProblemReporter } from "java:net/minecraft/util";
import { $LootContextUser, $ValidationContext } from "java:net/minecraft/world/level/storage/loot";

declare module "java:net/minecraft/world/level/storage/loot/parameters" {
    export class $LootContextParam<T> {
        constructor(arg0: $ResourceLocation_);
        get name(): $ResourceLocation;
        getName(): $ResourceLocation;
        toString(): string;
    }

    export class $LootContextParamSet {
        get allowed(): $Set<$LootContextParam<any>>;
        getAllowed(): $Set<$LootContextParam<any>>;
        get required(): $Set<$LootContextParam<any>>;
        getRequired(): $Set<$LootContextParam<any>>;
        static builder(): $LootContextParamSet$Builder;
        isAllowed(arg0: $LootContextParam<any>): boolean;
        toString(): string;
        validateUser(arg0: $ProblemReporter, arg1: $LootContextUser): void;
        validateUser(arg0: $ValidationContext, arg1: $LootContextUser): void;
    }

    export class $LootContextParamSet$Builder {
        constructor();
        build(): $LootContextParamSet;
        optional(arg0: $LootContextParam<any>): $LootContextParamSet$Builder;
        required(arg0: $LootContextParam<any>): $LootContextParamSet$Builder;
    }

}
