import { $Codec } from "java:com/mojang/serialization";
import { $Registry } from "java:net/minecraft/core";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";

declare module "java:net/neoforged/neoforge/registries/datamaps" {
    export class $DataMapType<R, T> {
        static builder<T, R>(arg0: $ResourceLocation_, arg1: $ResourceKey<$Registry<R>>, arg2: $Codec<T>): $DataMapType$Builder<T, R>;
        codec(): $Codec<T>;
        id(): $ResourceLocation;
        mandatorySync(): boolean;
        networkCodec(): $Codec<T>;
        registryKey(): $ResourceKey<$Registry<R>>;
    }

    export class $DataMapType$Builder<T, R> {
        build(): $DataMapType<R, T>;
        synced(arg0: $Codec<T>, arg1: boolean): $DataMapType$Builder<T, R>;
    }

    export interface $IWithData<R> {
        getData<T>(arg0: $DataMapType<R, T>): T;
    }

}
