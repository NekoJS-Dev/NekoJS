import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $Holder, $Holder_, $Registry } from "java:net/minecraft/core";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource, $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Attribute, $AttributeModifier, $AttributeModifier$Operation, $AttributeModifier$Operation_, $Attribute_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $EnchantedItemInUse, $LevelBasedValue } from "java:net/minecraft/world/item/enchantment";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/item/enchantment/effects" {
    export class $EnchantmentAttributeEffect extends $Record implements $EnchantmentLocationBasedEffect {
        constructor(arg0: $ResourceLocation_, arg1: $Holder_<$Attribute>, arg2: $LevelBasedValue, arg3: $AttributeModifier$Operation_);
        static CODEC: $MapCodec<$EnchantmentAttributeEffect>;
        amount(): $LevelBasedValue;
        attribute(): $Holder<$Attribute>;
        codec(): $MapCodec<$EnchantmentAttributeEffect>;
        equals(arg0: object): boolean;
        getModifier(arg0: number, arg1: $StringRepresentable_<string>): $AttributeModifier;
        hashCode(): number;
        id(): $ResourceLocation;
        onChangedBlock(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $Entity, arg4: $Vec3_, arg5: boolean): void;
        onDeactivated(arg0: $EnchantedItemInUse, arg1: $Entity, arg2: $Vec3_, arg3: number): void;
        operation(): $AttributeModifier$Operation;
        toString(): string;
    }

    export interface $EnchantmentEntityEffect extends $EnchantmentLocationBasedEffect {
        apply(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $Entity, arg4: $Vec3_): void;
        codec(): $MapCodec<$EnchantmentEntityEffect>;
        onChangedBlock(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $Entity, arg4: $Vec3_, arg5: boolean): void;
    }
    export const $EnchantmentEntityEffect: {
        bootstrap(arg0: $Registry<$MapCodec<$EnchantmentEntityEffect>>): $MapCodec<$EnchantmentEntityEffect>;
        readonly CODEC: $Codec<$EnchantmentEntityEffect>;
    };

    export interface $EnchantmentLocationBasedEffect {
        codec(): $MapCodec<$EnchantmentLocationBasedEffect>;
        onChangedBlock(arg0: $ServerLevel, arg1: number, arg2: $EnchantedItemInUse, arg3: $Entity, arg4: $Vec3_, arg5: boolean): void;
        onDeactivated(arg0: $EnchantedItemInUse, arg1: $Entity, arg2: $Vec3_, arg3: number): void;
    }
    export const $EnchantmentLocationBasedEffect: {
        bootstrap(arg0: $Registry<$MapCodec<$EnchantmentLocationBasedEffect>>): $MapCodec<$EnchantmentLocationBasedEffect>;
        readonly CODEC: $Codec<$EnchantmentLocationBasedEffect>;
    };

    export interface $EnchantmentValueEffect {
        codec(): $MapCodec<$EnchantmentValueEffect>;
        process(arg0: number, arg1: $RandomSource, arg2: number): number;
    }
    export const $EnchantmentValueEffect: {
        bootstrap(arg0: $Registry<$MapCodec<$EnchantmentValueEffect>>): $MapCodec<$EnchantmentValueEffect>;
        readonly CODEC: $Codec<$EnchantmentValueEffect>;
    };

}
