import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List } from "java:java/util";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $RandomSource } from "java:net/minecraft/util";
import { $WorldGenLevel } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $BlockPredicate } from "java:net/minecraft/world/level/levelgen/blockpredicates";

declare module "java:net/minecraft/world/level/levelgen/feature/stateproviders" {
    export class $BlockStateProvider {
        constructor();
        static CODEC: $Codec<$BlockStateProvider>;
        static simple(arg0: $Block_): $SimpleStateProvider;
        static simple(arg0: $BlockState_): $SimpleStateProvider;
        getState(arg0: $RandomSource, arg1: $BlockPos_): $BlockState;
    }

    export class $RuleBasedBlockStateProvider extends $Record {
        constructor(arg0: $BlockStateProvider, arg1: $RuleBasedBlockStateProvider$Rule[]);
        static CODEC: $Codec<$RuleBasedBlockStateProvider>;
        static simple(arg0: $Block_): $RuleBasedBlockStateProvider;
        static simple(arg0: $BlockStateProvider): $RuleBasedBlockStateProvider;
        equals(arg0: object): boolean;
        fallback(): $BlockStateProvider;
        getState(arg0: $WorldGenLevel, arg1: $RandomSource, arg2: $BlockPos_): $BlockState;
        hashCode(): number;
        rules(): $List<$RuleBasedBlockStateProvider$Rule>;
        toString(): string;
    }

    export class $SimpleStateProvider extends $BlockStateProvider {
        static CODEC: $MapCodec<$SimpleStateProvider>;
        getState(arg0: $RandomSource, arg1: $BlockPos_): $BlockState;
    }

    export class $RuleBasedBlockStateProvider$Rule extends $Record {
        constructor(arg0: $BlockPredicate, arg1: $BlockStateProvider);
        static CODEC: $Codec<$RuleBasedBlockStateProvider$Rule>;
        equals(arg0: object): boolean;
        hashCode(): number;
        ifTrue(): $BlockPredicate;
        then(): $BlockStateProvider;
        toString(): string;
    }

}
