import { $Codec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $Holder, $HolderSet, $Holder_ } from "java:net/minecraft/core";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $RandomSource } from "java:net/minecraft/util";
import { $FloatProvider, $IntProvider } from "java:net/minecraft/util/valueproviders";
import { $Block, $Block_, $MultifaceBlock } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $GeodeBlockSettings, $GeodeCrackSettings, $GeodeLayerSettings } from "java:net/minecraft/world/level/levelgen";
import { $BlockPredicate } from "java:net/minecraft/world/level/levelgen/blockpredicates";
import { $ConfiguredFeature, $SpikeFeature$EndSpike, $WeightedPlacedFeature } from "java:net/minecraft/world/level/levelgen/feature";
import { $FeatureSize } from "java:net/minecraft/world/level/levelgen/feature/featuresize";
import { $FoliagePlacer } from "java:net/minecraft/world/level/levelgen/feature/foliageplacers";
import { $RootPlacer } from "java:net/minecraft/world/level/levelgen/feature/rootplacers";
import { $BlockStateProvider, $RuleBasedBlockStateProvider } from "java:net/minecraft/world/level/levelgen/feature/stateproviders";
import { $TreeDecorator } from "java:net/minecraft/world/level/levelgen/feature/treedecorators";
import { $TrunkPlacer } from "java:net/minecraft/world/level/levelgen/feature/trunkplacers";
import { $CaveSurface, $CaveSurface_, $PlacedFeature } from "java:net/minecraft/world/level/levelgen/placement";
import { $RuleTest } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";
import { $FluidState } from "java:net/minecraft/world/level/material";

declare module "java:net/minecraft/world/level/levelgen/feature/configurations" {
    export class $BlockColumnConfiguration extends $Record implements $FeatureConfiguration {
        constructor(arg0: $BlockColumnConfiguration$Layer[], arg1: $Direction_, arg2: $BlockPredicate, arg3: boolean);
        static CODEC: $Codec<$BlockColumnConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        static layer(arg0: $IntProvider, arg1: $BlockStateProvider): $BlockColumnConfiguration$Layer;
        static simple(arg0: $IntProvider, arg1: $BlockStateProvider): $BlockColumnConfiguration;
        allowedPlacement(): $BlockPredicate;
        direction(): $Direction;
        equals(arg0: object): boolean;
        hashCode(): number;
        layers(): $List<$BlockColumnConfiguration$Layer>;
        prioritizeTip(): boolean;
        toString(): string;
    }

    export class $BlockColumnConfiguration$Layer extends $Record {
        constructor(arg0: $IntProvider, arg1: $BlockStateProvider);
        static CODEC: $Codec<$BlockColumnConfiguration$Layer>;
        equals(arg0: object): boolean;
        hashCode(): number;
        height(): $IntProvider;
        state(): $BlockStateProvider;
        toString(): string;
    }

    export class $BlockPileConfiguration implements $FeatureConfiguration {
        constructor(arg0: $BlockStateProvider);
        static CODEC: $Codec<$BlockPileConfiguration>;
        stateProvider: $BlockStateProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $BlockStateConfiguration implements $FeatureConfiguration {
        constructor(arg0: $BlockState_);
        static CODEC: $Codec<$BlockStateConfiguration>;
        state: $BlockState;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $ColumnFeatureConfiguration implements $FeatureConfiguration {
        constructor(arg0: $IntProvider, arg1: $IntProvider);
        static CODEC: $Codec<$ColumnFeatureConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        height(): $IntProvider;
        reach(): $IntProvider;
    }

    export class $CountConfiguration implements $FeatureConfiguration {
        constructor(arg0: number);
        constructor(arg0: $IntProvider);
        static CODEC: $Codec<$CountConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        count(): $IntProvider;
    }

    export class $DeltaFeatureConfiguration implements $FeatureConfiguration {
        constructor(arg0: $BlockState_, arg1: $BlockState_, arg2: $IntProvider, arg3: $IntProvider);
        static CODEC: $Codec<$DeltaFeatureConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        contents(): $BlockState;
        rimSize(): $IntProvider;
        rim(): $BlockState;
        size(): $IntProvider;
    }

    export class $DiskConfiguration extends $Record implements $FeatureConfiguration {
        constructor(arg0: $RuleBasedBlockStateProvider, arg1: $BlockPredicate, arg2: $IntProvider, arg3: number);
        static CODEC: $Codec<$DiskConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        equals(arg0: object): boolean;
        halfHeight(): number;
        hashCode(): number;
        radius(): $IntProvider;
        stateProvider(): $RuleBasedBlockStateProvider;
        target(): $BlockPredicate;
        toString(): string;
    }

    export class $DripstoneClusterConfiguration implements $FeatureConfiguration {
        constructor(arg0: number, arg1: $IntProvider, arg2: $IntProvider, arg3: number, arg4: number, arg5: $IntProvider, arg6: $FloatProvider, arg7: $FloatProvider, arg8: number, arg9: number, arg10: number);
        static CODEC: $Codec<$DripstoneClusterConfiguration>;
        chanceOfDripstoneColumnAtMaxDistanceFromCenter: number;
        density: $FloatProvider;
        dripstoneBlockLayerThickness: $IntProvider;
        floorToCeilingSearchRange: number;
        height: $IntProvider;
        heightDeviation: number;
        maxDistanceFromCenterAffectingHeightBias: number;
        maxDistanceFromEdgeAffectingChanceOfDripstoneColumn: number;
        maxStalagmiteStalactiteHeightDiff: number;
        radius: $IntProvider;
        wetness: $FloatProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $EndGatewayConfiguration implements $FeatureConfiguration {
        static CODEC: $Codec<$EndGatewayConfiguration>;
        get exit(): $Optional<$BlockPos>;
        getExit(): $Optional<$BlockPos>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        get exitExact(): boolean;
        isExitExact(): boolean;
        static delayedExitSearch(): $EndGatewayConfiguration;
        static knownExit(arg0: $BlockPos_, arg1: boolean): $EndGatewayConfiguration;
    }

    export interface $FeatureConfiguration {
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }
    export const $FeatureConfiguration: {
        readonly NONE: $NoneFeatureConfiguration;
    };

    export class $GeodeConfiguration implements $FeatureConfiguration {
        constructor(arg0: $GeodeBlockSettings, arg1: $GeodeLayerSettings, arg2: $GeodeCrackSettings, arg3: number, arg4: number, arg5: boolean, arg6: $IntProvider, arg7: $IntProvider, arg8: $IntProvider, arg9: number, arg10: number, arg11: number, arg12: number);
        static CHANCE_RANGE: $Codec<number>;
        static CODEC: $Codec<$GeodeConfiguration>;
        distributionPoints: $IntProvider;
        geodeBlockSettings: $GeodeBlockSettings;
        geodeCrackSettings: $GeodeCrackSettings;
        geodeLayerSettings: $GeodeLayerSettings;
        invalidBlocksThreshold: number;
        maxGenOffset: number;
        minGenOffset: number;
        noiseMultiplier: number;
        outerWallDistance: $IntProvider;
        placementsRequireLayer0Alternate: boolean;
        pointOffset: $IntProvider;
        useAlternateLayer0Chance: number;
        usePotentialPlacementsChance: number;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $HugeMushroomFeatureConfiguration implements $FeatureConfiguration {
        constructor(arg0: $BlockStateProvider, arg1: $BlockStateProvider, arg2: number);
        static CODEC: $Codec<$HugeMushroomFeatureConfiguration>;
        capProvider: $BlockStateProvider;
        foliageRadius: number;
        stemProvider: $BlockStateProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $LargeDripstoneConfiguration implements $FeatureConfiguration {
        constructor(arg0: number, arg1: $IntProvider, arg2: $FloatProvider, arg3: number, arg4: $FloatProvider, arg5: $FloatProvider, arg6: $FloatProvider, arg7: number, arg8: number);
        static CODEC: $Codec<$LargeDripstoneConfiguration>;
        columnRadius: $IntProvider;
        floorToCeilingSearchRange: number;
        heightScale: $FloatProvider;
        maxColumnRadiusToCaveHeightRatio: number;
        minBluntnessForWind: number;
        minRadiusForWind: number;
        stalactiteBluntness: $FloatProvider;
        stalagmiteBluntness: $FloatProvider;
        windSpeed: $FloatProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $LayerConfiguration implements $FeatureConfiguration {
        constructor(arg0: number, arg1: $BlockState_);
        static CODEC: $Codec<$LayerConfiguration>;
        height: number;
        state: $BlockState;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $MultifaceGrowthConfiguration implements $FeatureConfiguration {
        constructor(arg0: $MultifaceBlock, arg1: number, arg2: boolean, arg3: boolean, arg4: boolean, arg5: number, arg6: $HolderSet<$Block>);
        static CODEC: $Codec<$MultifaceGrowthConfiguration>;
        canBePlacedOn: $HolderSet<$Block>;
        canPlaceOnCeiling: boolean;
        canPlaceOnFloor: boolean;
        canPlaceOnWall: boolean;
        chanceOfSpreading: number;
        placeBlock: $MultifaceBlock;
        searchRange: number;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        getShuffledDirectionsExcept(arg0: $RandomSource, arg1: $Direction_): $List<$Direction>;
        getShuffledDirections(arg0: $RandomSource): $List<$Direction>;
    }

    export class $NetherForestVegetationConfig extends $BlockPileConfiguration {
        constructor(arg0: $BlockStateProvider, arg1: number, arg2: number);
        static CODEC: $Codec<$NetherForestVegetationConfig>;
        spreadHeight: number;
        spreadWidth: number;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $NoneFeatureConfiguration implements $FeatureConfiguration {
        constructor();
        static CODEC: $Codec<$NoneFeatureConfiguration>;
        static INSTANCE: $NoneFeatureConfiguration;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $OreConfiguration implements $FeatureConfiguration {
        constructor(arg0: $OreConfiguration$TargetBlockState[], arg1: number);
        constructor(arg0: $OreConfiguration$TargetBlockState[], arg1: number, arg2: number);
        constructor(arg0: $RuleTest, arg1: $BlockState_, arg2: number);
        constructor(arg0: $RuleTest, arg1: $BlockState_, arg2: number, arg3: number);
        static CODEC: $Codec<$OreConfiguration>;
        discardChanceOnAirExposure: number;
        size: number;
        targetStates: $List<$OreConfiguration$TargetBlockState>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        static target(arg0: $RuleTest, arg1: $BlockState_): $OreConfiguration$TargetBlockState;
    }

    export class $OreConfiguration$TargetBlockState {
        static CODEC: $Codec<$OreConfiguration$TargetBlockState>;
        state: $BlockState;
        target: $RuleTest;
    }

    export class $PointedDripstoneConfiguration implements $FeatureConfiguration {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        static CODEC: $Codec<$PointedDripstoneConfiguration>;
        chanceOfDirectionalSpread: number;
        chanceOfSpreadRadius2: number;
        chanceOfSpreadRadius3: number;
        chanceOfTallerDripstone: number;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $ProbabilityFeatureConfiguration implements $FeatureConfiguration {
        constructor(arg0: number);
        static CODEC: $Codec<$ProbabilityFeatureConfiguration>;
        probability: number;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $RandomBooleanFeatureConfiguration implements $FeatureConfiguration {
        constructor(arg0: $Holder_<$PlacedFeature>, arg1: $Holder_<$PlacedFeature>);
        static CODEC: $Codec<$RandomBooleanFeatureConfiguration>;
        featureFalse: $Holder<$PlacedFeature>;
        featureTrue: $Holder<$PlacedFeature>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $RandomFeatureConfiguration implements $FeatureConfiguration {
        constructor(arg0: $WeightedPlacedFeature[], arg1: $Holder_<$PlacedFeature>);
        static CODEC: $Codec<$RandomFeatureConfiguration>;
        defaultFeature: $Holder<$PlacedFeature>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $RandomPatchConfiguration extends $Record implements $FeatureConfiguration {
        constructor(arg0: number, arg1: number, arg2: number, arg3: $Holder_<$PlacedFeature>);
        static CODEC: $Codec<$RandomPatchConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        equals(arg0: object): boolean;
        feature(): $Holder<$PlacedFeature>;
        hashCode(): number;
        toString(): string;
        tries(): number;
        xzSpread(): number;
        ySpread(): number;
    }

    export class $ReplaceBlockConfiguration implements $FeatureConfiguration {
        constructor(arg0: $OreConfiguration$TargetBlockState[]);
        constructor(arg0: $BlockState_, arg1: $BlockState_);
        static CODEC: $Codec<$ReplaceBlockConfiguration>;
        targetStates: $List<$OreConfiguration$TargetBlockState>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $ReplaceSphereConfiguration implements $FeatureConfiguration {
        constructor(arg0: $BlockState_, arg1: $BlockState_, arg2: $IntProvider);
        static CODEC: $Codec<$ReplaceSphereConfiguration>;
        replaceState: $BlockState;
        targetState: $BlockState;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        radius(): $IntProvider;
    }

    export class $RootSystemConfiguration implements $FeatureConfiguration {
        constructor(arg0: $Holder_<$PlacedFeature>, arg1: number, arg2: number, arg3: $TagKey_<$Block>, arg4: $BlockStateProvider, arg5: number, arg6: number, arg7: number, arg8: number, arg9: $BlockStateProvider, arg10: number, arg11: number, arg12: $BlockPredicate);
        static CODEC: $Codec<$RootSystemConfiguration>;
        allowedTreePosition: $BlockPredicate;
        allowedVerticalWaterForTree: number;
        hangingRootPlacementAttempts: number;
        hangingRootRadius: number;
        hangingRootStateProvider: $BlockStateProvider;
        hangingRootsVerticalSpan: number;
        requiredVerticalSpaceForTree: number;
        rootColumnMaxHeight: number;
        rootPlacementAttempts: number;
        rootRadius: number;
        rootReplaceable: $TagKey<$Block>;
        rootStateProvider: $BlockStateProvider;
        treeFeature: $Holder<$PlacedFeature>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $SculkPatchConfiguration extends $Record implements $FeatureConfiguration {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: $IntProvider, arg6: number);
        static CODEC: $Codec<$SculkPatchConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        amountPerCharge(): number;
        catalystChance(): number;
        chargeCount(): number;
        equals(arg0: object): boolean;
        extraRareGrowths(): $IntProvider;
        growthRounds(): number;
        hashCode(): number;
        spreadAttempts(): number;
        spreadRounds(): number;
        toString(): string;
    }

    export class $SimpleBlockConfiguration extends $Record implements $FeatureConfiguration {
        constructor(arg0: $BlockStateProvider);
        static CODEC: $Codec<$SimpleBlockConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toPlace(): $BlockStateProvider;
        toString(): string;
    }

    export class $SimpleRandomFeatureConfiguration implements $FeatureConfiguration {
        constructor(arg0: $HolderSet<$PlacedFeature>);
        static CODEC: $Codec<$SimpleRandomFeatureConfiguration>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $SpikeConfiguration implements $FeatureConfiguration {
        constructor(arg0: boolean, arg1: $SpikeFeature$EndSpike[], arg2: $BlockPos_);
        static CODEC: $Codec<$SpikeConfiguration>;
        get crystalBeamTarget(): $BlockPos;
        getCrystalBeamTarget(): $BlockPos;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        get spikes(): $List<$SpikeFeature$EndSpike>;
        getSpikes(): $List<$SpikeFeature$EndSpike>;
        get crystalInvulnerable(): boolean;
        isCrystalInvulnerable(): boolean;
    }

    export class $SpringConfiguration implements $FeatureConfiguration {
        constructor(arg0: $FluidState, arg1: boolean, arg2: number, arg3: number, arg4: $HolderSet<$Block>);
        static CODEC: $Codec<$SpringConfiguration>;
        holeCount: number;
        requiresBlockBelow: boolean;
        rockCount: number;
        state: $FluidState;
        validBlocks: $HolderSet<$Block>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $TreeConfiguration implements $FeatureConfiguration {
        static CODEC: $Codec<$TreeConfiguration>;
        decorators: $List<$TreeDecorator>;
        dirtProvider: $BlockStateProvider;
        foliagePlacer: $FoliagePlacer;
        foliageProvider: $BlockStateProvider;
        forceDirt: boolean;
        ignoreVines: boolean;
        minimumSize: $FeatureSize;
        rootPlacer: $Optional<$RootPlacer>;
        trunkPlacer: $TrunkPlacer;
        trunkProvider: $BlockStateProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $TwistingVinesConfig extends $Record implements $FeatureConfiguration {
        constructor(arg0: number, arg1: number, arg2: number);
        static CODEC: $Codec<$TwistingVinesConfig>;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        maxHeight(): number;
        spreadHeight(): number;
        spreadWidth(): number;
        toString(): string;
    }

    export class $UnderwaterMagmaConfiguration implements $FeatureConfiguration {
        constructor(arg0: number, arg1: number, arg2: number);
        static CODEC: $Codec<$UnderwaterMagmaConfiguration>;
        floorSearchRange: number;
        placementProbabilityPerValidPosition: number;
        placementRadiusAroundFloor: number;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

    export class $VegetationPatchConfiguration implements $FeatureConfiguration {
        constructor(arg0: $TagKey_<$Block>, arg1: $BlockStateProvider, arg2: $Holder_<$PlacedFeature>, arg3: $CaveSurface_, arg4: $IntProvider, arg5: number, arg6: number, arg7: number, arg8: $IntProvider, arg9: number);
        static CODEC: $Codec<$VegetationPatchConfiguration>;
        depth: $IntProvider;
        extraBottomBlockChance: number;
        extraEdgeColumnChance: number;
        groundState: $BlockStateProvider;
        replaceable: $TagKey<$Block>;
        surface: $CaveSurface;
        vegetationChance: number;
        vegetationFeature: $Holder<$PlacedFeature>;
        verticalRange: number;
        xzRadius: $IntProvider;
        get features(): $Stream<$ConfiguredFeature<any, any>>;
        getFeatures(): $Stream<$ConfiguredFeature<any, any>>;
    }

}
