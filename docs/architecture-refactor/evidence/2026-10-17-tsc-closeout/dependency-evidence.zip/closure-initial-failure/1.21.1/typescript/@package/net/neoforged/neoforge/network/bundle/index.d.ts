import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ClientCommonPacketListener } from "java:net/minecraft/network/protocol/common";
import { $CustomPacketPayload, $CustomPacketPayload$Type, $CustomPacketPayload_ } from "java:net/minecraft/network/protocol/common/custom";

declare module "java:net/neoforged/neoforge/network/bundle" {
    export class $PacketAndPayloadAcceptor<L extends $ClientCommonPacketListener> {
        constructor(arg0: $Consumer_<$Packet<any>, $Packet<any>>);
        accept(arg0: $Packet<any>): $PacketAndPayloadAcceptor<L>;
        accept(arg0: $CustomPacketPayload_<$CustomPacketPayload$Type<$CustomPacketPayload>>): $PacketAndPayloadAcceptor<L>;
    }

}
