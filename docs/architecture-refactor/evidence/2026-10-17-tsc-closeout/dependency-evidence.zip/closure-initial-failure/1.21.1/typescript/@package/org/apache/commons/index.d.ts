export * as lang3 from "java:org/apache/commons/lang3";

