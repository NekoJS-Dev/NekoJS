import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $FluidStack, $FluidStack_, $IFluidTank } from "java:net/neoforged/neoforge/fluids";
import { $IFluidHandler, $IFluidHandler$FluidAction, $IFluidHandler$FluidAction_ } from "java:net/neoforged/neoforge/fluids/capability";

declare module "java:net/neoforged/neoforge/fluids/capability/templates" {
    export class $FluidTank implements $IFluidHandler, $IFluidTank {
        constructor(arg0: number);
        constructor(arg0: number, arg1: $Predicate_<$FluidStack, $FluidStack, boolean>);
        get capacity(): number;
        getCapacity(): number;
        set capacity(value: number);
        get fluidAmount(): number;
        getFluidAmount(): number;
        get fluid(): $FluidStack;
        getFluid(): $FluidStack;
        set fluid(value: $FluidStack_);
        get space(): number;
        getSpace(): number;
        get tanks(): number;
        getTanks(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        drain(arg0: number, arg1: $IFluidHandler$FluidAction_): $FluidStack;
        drain(arg0: $FluidStack_, arg1: $IFluidHandler$FluidAction_): $FluidStack;
        fill(arg0: $FluidStack_, arg1: $IFluidHandler$FluidAction_): number;
        getFluidInTank(arg0: number): $FluidStack;
        getTankCapacity(arg0: number): number;
        isFluidValid(arg0: number, arg1: $FluidStack_): boolean;
        isFluidValid(arg0: $FluidStack_): boolean;
        readFromNBT(arg0: $HolderLookup$Provider, arg1: $CompoundTag_): $FluidTank;
        setCapacity(arg0: number): $FluidTank;
        setFluid(arg0: $FluidStack_): void;
        setValidator(arg0: $Predicate_<$FluidStack, $FluidStack, boolean>): $FluidTank;
        writeToNBT(arg0: $HolderLookup$Provider, arg1: $CompoundTag_): $CompoundTag;
    }

}
