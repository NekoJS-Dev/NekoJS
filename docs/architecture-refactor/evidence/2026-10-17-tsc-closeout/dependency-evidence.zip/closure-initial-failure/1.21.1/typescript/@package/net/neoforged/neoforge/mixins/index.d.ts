import { $Set } from "java:java/util";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";

declare module "java:net/neoforged/neoforge/mixins" {
    export interface $BlockEntityTypeAccessor {
        neoforge$setValidBlocks(arg0: $Block_[]): void;
    }

    export type $BlockEntityTypeAccessor_<CallbackArg0 = $Set<$Block>> = ((arg0: CallbackArg0) => void) | ($BlockEntityTypeAccessor & { readonly [Symbol.hasInstance]?: never });
}
