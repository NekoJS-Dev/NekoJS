import type { RegistryTypes } from "@special/types";
import { $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Iterable, $Record } from "java:java/lang";
import { $Consumer, $Consumer_, $Function, $Function_ } from "java:java/util/function";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $LootContext, $ValidationContext } from "java:net/minecraft/world/level/storage/loot";
import { $ConditionUserBuilder, $LootItemCondition, $LootItemCondition$Builder, $LootItemCondition$Builder_ } from "java:net/minecraft/world/level/storage/loot/predicates";

declare module "java:net/minecraft/world/level/storage/loot/entries" {
    export class $AlternativesEntry$Builder extends $LootPoolEntryContainer$Builder<$AlternativesEntry$Builder> {
        constructor(arg0?: $LootPoolEntryContainer$Builder<any>[]);
        build(): $LootPoolEntryContainer;
        otherwise(arg0: $LootPoolEntryContainer$Builder<any>): $AlternativesEntry$Builder;
        when<E>(arg0: $Iterable<E>, arg1: $Function_<E, $LootItemCondition$Builder, E, $LootItemCondition$Builder_<$LootItemCondition>>): $AlternativesEntry$Builder;
        when(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $AlternativesEntry$Builder;
    }

    export class $EntryGroup$Builder extends $LootPoolEntryContainer$Builder<$EntryGroup$Builder> {
        constructor(arg0?: $LootPoolEntryContainer$Builder<any>[]);
        append(arg0: $LootPoolEntryContainer$Builder<any>): $EntryGroup$Builder;
        build(): $LootPoolEntryContainer;
        when<E>(arg0: $Iterable<E>, arg1: $Function_<E, $LootItemCondition$Builder, E, $LootItemCondition$Builder_<$LootItemCondition>>): $EntryGroup$Builder;
        when(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $EntryGroup$Builder;
    }

    export class $LootPoolEntryContainer implements $ComposableEntryContainer {
        get type(): $LootPoolEntryType;
        getType(): $LootPoolEntryType;
        and(arg0: $ComposableEntryContainer_<$LootContext, $Consumer<$LootPoolEntry>, boolean>): $ComposableEntryContainer;
        expand(arg0: $LootContext, arg1: $Consumer_<$LootPoolEntry, $LootPoolEntry>): boolean;
        or(arg0: $ComposableEntryContainer_<$LootContext, $Consumer<$LootPoolEntry>, boolean>): $ComposableEntryContainer;
        validate(arg0: $ValidationContext): void;
    }

    export class $LootPoolEntryContainer$Builder<T extends $LootPoolEntryContainer$Builder<T>> implements $ConditionUserBuilder<T> {
        constructor();
        append(arg0: $LootPoolEntryContainer$Builder<any>): $EntryGroup$Builder;
        build(): $LootPoolEntryContainer;
        otherwise(arg0: $LootPoolEntryContainer$Builder<any>): $AlternativesEntry$Builder;
        then(arg0: $LootPoolEntryContainer$Builder<any>): $SequentialEntry$Builder;
        unwrap(): T;
        when<E>(arg0: $Iterable<E>, arg1: $Function_<E, $LootItemCondition$Builder, E, $LootItemCondition$Builder_<$LootItemCondition>>): T;
        when(arg0: $LootItemCondition$Builder_<$LootItemCondition>): T;
    }

    export class $SequentialEntry$Builder extends $LootPoolEntryContainer$Builder<$SequentialEntry$Builder> {
        constructor(arg0?: $LootPoolEntryContainer$Builder<any>[]);
        build(): $LootPoolEntryContainer;
        then(arg0: $LootPoolEntryContainer$Builder<any>): $SequentialEntry$Builder;
        when<E>(arg0: $Iterable<E>, arg1: $Function_<E, $LootItemCondition$Builder, E, $LootItemCondition$Builder_<$LootItemCondition>>): $SequentialEntry$Builder;
        when(arg0: $LootItemCondition$Builder_<$LootItemCondition>): $SequentialEntry$Builder;
    }

    export class $LootPoolEntryType extends $Record {
        constructor(arg0: $MapCodec<$LootPoolEntryContainer>);
        codec(): $MapCodec<$LootPoolEntryContainer>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $ComposableEntryContainer {
        and(arg0: $ComposableEntryContainer_<$LootContext, $Consumer<$LootPoolEntry>, boolean>): $ComposableEntryContainer;
        expand(arg0: $LootContext, arg1: $Consumer_<$LootPoolEntry, $LootPoolEntry>): boolean;
        or(arg0: $ComposableEntryContainer_<$LootContext, $Consumer<$LootPoolEntry>, boolean>): $ComposableEntryContainer;
    }
    export const $ComposableEntryContainer: {
        readonly ALWAYS_FALSE: $ComposableEntryContainer;
        readonly ALWAYS_TRUE: $ComposableEntryContainer;
    };

    export interface $LootPoolEntry {
        createItemStack(arg0: $Consumer_<$ItemStack, $ItemStack>, arg1: $LootContext): void;
        getWeight(arg0: number): number;
    }

    export type $LootPoolEntryType_ = $LootPoolEntryType | RegistryTypes.LootPoolEntryType | $NekoId | string;
    export type $ComposableEntryContainer_<CallbackArg0 = $LootContext, CallbackArg1 = $Consumer<$LootPoolEntry>, CallbackResult = boolean> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($ComposableEntryContainer & { readonly [Symbol.hasInstance]?: never });
}
