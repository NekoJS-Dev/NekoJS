import { $Enum } from "java:java/lang";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $Difficulty, $Difficulty_ } from "java:net/minecraft/world";
import { $CombatEntry, $DamageSource } from "java:net/minecraft/world/damagesource";
import { $LivingEntity } from "java:net/minecraft/world/entity";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $LivingShieldBlockEvent } from "java:net/neoforged/neoforge/event/entity/living";

declare module "java:net/neoforged/neoforge/common/damagesource" {
    export class $DamageContainer {
        constructor(arg0: $DamageSource, arg1: number);
        get blockedDamage(): number;
        getBlockedDamage(): number;
        set blockedDamage(value: $LivingShieldBlockEvent);
        get newDamage(): number;
        getNewDamage(): number;
        set newDamage(value: number);
        get originalDamage(): number;
        getOriginalDamage(): number;
        get postAttackInvulnerabilityTicks(): number;
        getPostAttackInvulnerabilityTicks(): number;
        set postAttackInvulnerabilityTicks(value: number);
        get shieldDamage(): number;
        getShieldDamage(): number;
        get source(): $DamageSource;
        getSource(): $DamageSource;
        addModifier(arg0: $DamageContainer$Reduction_, arg1: $IReductionFunction_<$DamageContainer, number, number>): void;
        getReduction(arg0: $DamageContainer$Reduction_): number;
        setBlockedDamage(arg0: $LivingShieldBlockEvent): void;
        setNewDamage(arg0: number): void;
        setPostAttackInvulnerabilityTicks(arg0: number): void;
        setReduction(arg0: $DamageContainer$Reduction_, arg1: number): void;
    }

    export class $DamageContainer$Reduction {
        static ABSORPTION: $DamageContainer$Reduction;
        static ARMOR: $DamageContainer$Reduction;
        static ENCHANTMENTS: $DamageContainer$Reduction;
        static INNATE_RESISTANCE: $DamageContainer$Reduction;
        static INVULNERABILITY: $DamageContainer$Reduction;
        static MOB_EFFECTS: $DamageContainer$Reduction;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $DamageContainer$Reduction[];
        static valueOf(name: string): $DamageContainer$Reduction;
    }
    export interface $DamageContainer$Reduction extends $Enum<$DamageContainer$Reduction> {}

    export interface $IDeathMessageProvider {
        getDeathMessage(arg0: $LivingEntity, arg1: $CombatEntry, arg2: $CombatEntry): $Component;
    }
    export const $IDeathMessageProvider: {
        readonly DEFAULT: $IDeathMessageProvider;
    };

    export interface $IReductionFunction {
        modify(arg0: $DamageContainer, arg1: number): number;
    }

    export interface $IScalingFunction {
        scaleDamage(arg0: $DamageSource, arg1: $Player, arg2: number, arg3: $Difficulty_): number;
    }
    export const $IScalingFunction: {
        readonly DEFAULT: $IScalingFunction;
    };

    export type $DamageContainer$Reduction_ = $DamageContainer$Reduction | "ABSORPTION" | "ARMOR" | "ENCHANTMENTS" | "INNATE_RESISTANCE" | "INVULNERABILITY" | "MOB_EFFECTS";
    export type $IDeathMessageProvider_<CallbackArg0 = $LivingEntity, CallbackArg1 = $CombatEntry, CallbackArg2 = $CombatEntry, CallbackResult = $Component_> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($IDeathMessageProvider & { readonly [Symbol.hasInstance]?: never });
    export type $IReductionFunction_<CallbackArg0 = $DamageContainer, CallbackArg1 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($IReductionFunction & { readonly [Symbol.hasInstance]?: never });
    export type $IScalingFunction_<CallbackArg0 = $DamageSource, CallbackArg1 = $Player, CallbackArg2 = number, CallbackArg3 = $Difficulty, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => CallbackResult) | ($IScalingFunction & { readonly [Symbol.hasInstance]?: never });
}
