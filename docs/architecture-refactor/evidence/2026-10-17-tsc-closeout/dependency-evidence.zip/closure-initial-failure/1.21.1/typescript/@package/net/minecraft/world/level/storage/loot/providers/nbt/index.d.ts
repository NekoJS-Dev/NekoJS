import type { RegistryTypes } from "@special/types";
import { $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Record } from "java:java/lang";
import { $Set } from "java:java/util";
import { $Tag } from "java:net/minecraft/nbt";
import { $LootContext } from "java:net/minecraft/world/level/storage/loot";
import { $LootContextParam } from "java:net/minecraft/world/level/storage/loot/parameters";

declare module "java:net/minecraft/world/level/storage/loot/providers/nbt" {
    export class $LootNbtProviderType extends $Record {
        constructor(arg0: $MapCodec<$NbtProvider>);
        codec(): $MapCodec<$NbtProvider>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $NbtProvider {
        getReferencedContextParams(): $Set<$LootContextParam<any>>;
        getType(): $LootNbtProviderType;
        get(arg0: $LootContext): $Tag;
    }

    export type $LootNbtProviderType_ = $LootNbtProviderType | RegistryTypes.LootNbtProviderType | $NekoId | string;
}
