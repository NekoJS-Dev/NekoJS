import { $Codec, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $Enum, $Record, $StringBuilder } from "java:java/lang";
import { $List, $Optional, $OptionalLong, $Set } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Function, $Function_ } from "java:java/util/function";
import { $BlockPos, $BlockPos_, $Holder, $HolderGetter, $HolderGetter$Provider, $HolderGetter$Provider_, $Holder_, $Registry, $RegistryAccess$Frozen } from "java:net/minecraft/core";
import { $BootstrapContext } from "java:net/minecraft/data/worldgen";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $WorldGenRegion } from "java:net/minecraft/server/level";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $KeyDispatchDataCodec, $RandomSource } from "java:net/minecraft/util";
import { $ChunkPos, $LevelHeightAccessor, $NoiseColumn, $StructureManager } from "java:net/minecraft/world/level";
import { $Biome, $BiomeManager, $BiomeResolver, $BiomeResolver_, $BiomeSource, $Climate$ParameterPoint, $Climate$Sampler } from "java:net/minecraft/world/level/biome";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $ChunkAccess, $ChunkGenerator, $ProtoChunk } from "java:net/minecraft/world/level/chunk";
import { $ChunkStatus, $ChunkStatus_ } from "java:net/minecraft/world/level/chunk/status";
import { $LevelStem } from "java:net/minecraft/world/level/dimension";
import { $Blender } from "java:net/minecraft/world/level/levelgen/blending";
import { $CarvingContext } from "java:net/minecraft/world/level/levelgen/carver";
import { $BlockStateProvider } from "java:net/minecraft/world/level/levelgen/feature/stateproviders";
import { $NormalNoise, $NormalNoise$NoiseParameters } from "java:net/minecraft/world/level/levelgen/synth";
import { $PrimaryLevelData$SpecialWorldProperty, $PrimaryLevelData$SpecialWorldProperty_ } from "java:net/minecraft/world/level/storage";

export * as blending from "java:net/minecraft/world/level/levelgen/blending";
export * as blockpredicates from "java:net/minecraft/world/level/levelgen/blockpredicates";
export * as carver from "java:net/minecraft/world/level/levelgen/carver";
export * as feature from "java:net/minecraft/world/level/levelgen/feature";
export * as heightproviders from "java:net/minecraft/world/level/levelgen/heightproviders";
export * as placement from "java:net/minecraft/world/level/levelgen/placement";
export * as structure from "java:net/minecraft/world/level/levelgen/structure";
export * as synth from "java:net/minecraft/world/level/levelgen/synth";

declare module "java:net/minecraft/world/level/levelgen" {
    export interface $Aquifer {
        computeSubstance(arg0: $DensityFunction$FunctionContext, arg1: number): $BlockState;
        shouldScheduleFluidUpdate(): boolean;
    }
    export const $Aquifer: {
        createDisabled(arg0: $Aquifer$FluidPicker_<number, number, number, $Aquifer$FluidStatus>): $Aquifer;
        create(arg0: $NoiseChunk, arg1: $ChunkPos, arg2: $NoiseRouter, arg3: $PositionalRandomFactory, arg4: number, arg5: number, arg6: $Aquifer$FluidPicker_<number, number, number, $Aquifer$FluidStatus>): $Aquifer;
    };

    export interface $Aquifer$FluidPicker {
        computeFluid(arg0: number, arg1: number, arg2: number): $Aquifer$FluidStatus;
    }

    export class $Aquifer$FluidStatus {
        constructor(arg0: number, arg1: $BlockState_);
        at(arg0: number): $BlockState;
    }

    export class $BelowZeroRetrogen {
        static CODEC: $Codec<$BelowZeroRetrogen>;
        static UPGRADE_HEIGHT_ACCESSOR: $LevelHeightAccessor;
        static getBiomeResolver(arg0: $BiomeResolver_<number, number, number, $Climate$Sampler, $Holder_<$Biome>>, arg1: $ChunkAccess): $BiomeResolver;
        static read(arg0: $CompoundTag_): $BelowZeroRetrogen;
        static replaceOldBedrock(arg0: $ProtoChunk): void;
        applyBedrockMask(arg0: $ProtoChunk): void;
        hasBedrockHoles(): boolean;
        hasBedrockHole(arg0: number, arg1: number): boolean;
        targetStatus(): $ChunkStatus;
    }

    export interface $DensityFunction {
        abs(): $DensityFunction;
        clamp(arg0: number, arg1: number): $DensityFunction;
        codec(): $KeyDispatchDataCodec<$DensityFunction>;
        compute(arg0: $DensityFunction$FunctionContext): number;
        cube(): $DensityFunction;
        fillArray(arg0: number[], arg1: $DensityFunction$ContextProvider): void;
        halfNegative(): $DensityFunction;
        mapAll(arg0: $DensityFunction$Visitor_<$DensityFunction, $DensityFunction>): $DensityFunction;
        maxValue(): number;
        minValue(): number;
        quarterNegative(): $DensityFunction;
        square(): $DensityFunction;
        squeeze(): $DensityFunction;
    }
    export const $DensityFunction: {
        readonly CODEC: $Codec<$Holder<$DensityFunction>>;
        readonly DIRECT_CODEC: $Codec<$DensityFunction>;
        readonly HOLDER_HELPER_CODEC: $Codec<$DensityFunction>;
    };

    export interface $DensityFunction$ContextProvider {
        fillAllDirectly(arg0: number[], arg1: $DensityFunction): void;
        forIndex(arg0: number): $DensityFunction$FunctionContext;
    }

    export interface $DensityFunction$FunctionContext {
        blockX(): number;
        blockY(): number;
        blockZ(): number;
        getBlender(): $Blender;
    }

    export interface $DensityFunction$SimpleFunction extends $DensityFunction {
        fillArray(arg0: number[], arg1: $DensityFunction$ContextProvider): void;
        mapAll(arg0: $DensityFunction$Visitor_<$DensityFunction, $DensityFunction>): $DensityFunction;
    }

    export interface $DensityFunction$Visitor {
        apply(arg0: $DensityFunction): $DensityFunction;
        visitNoise(arg0: $DensityFunction$NoiseHolder): $DensityFunction$NoiseHolder;
    }

    export interface $DensityFunctions$BeardifierOrMarker extends $DensityFunction$SimpleFunction {
        codec(): $KeyDispatchDataCodec<$DensityFunction>;
    }
    export const $DensityFunctions$BeardifierOrMarker: {
        readonly CODEC: $KeyDispatchDataCodec<$DensityFunction>;
    };

    export class $GenerationStep$Carving {
        static AIR: $GenerationStep$Carving;
        static LIQUID: $GenerationStep$Carving;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GenerationStep$Carving[];
        static valueOf(name: string): $GenerationStep$Carving;
    }
    export interface $GenerationStep$Carving extends $Enum<$GenerationStep$Carving> {}

    export class $GenerationStep$Decoration {
        static FLUID_SPRINGS: $GenerationStep$Decoration;
        static LAKES: $GenerationStep$Decoration;
        static LOCAL_MODIFICATIONS: $GenerationStep$Decoration;
        static RAW_GENERATION: $GenerationStep$Decoration;
        static STRONGHOLDS: $GenerationStep$Decoration;
        static SURFACE_STRUCTURES: $GenerationStep$Decoration;
        static TOP_LAYER_MODIFICATION: $GenerationStep$Decoration;
        static UNDERGROUND_DECORATION: $GenerationStep$Decoration;
        static UNDERGROUND_ORES: $GenerationStep$Decoration;
        static UNDERGROUND_STRUCTURES: $GenerationStep$Decoration;
        static VEGETAL_DECORATION: $GenerationStep$Decoration;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $GenerationStep$Decoration[];
        static valueOf(name: string): $GenerationStep$Decoration;
    }
    export interface $GenerationStep$Decoration extends $Enum<$GenerationStep$Decoration> {}

    export class $GeodeBlockSettings {
        constructor(arg0: $BlockStateProvider, arg1: $BlockStateProvider, arg2: $BlockStateProvider, arg3: $BlockStateProvider, arg4: $BlockStateProvider, arg5: $BlockState_[], arg6: $TagKey_<$Block>, arg7: $TagKey_<$Block>);
        static CODEC: $Codec<$GeodeBlockSettings>;
        alternateInnerLayerProvider: $BlockStateProvider;
        cannotReplace: $TagKey<$Block>;
        fillingProvider: $BlockStateProvider;
        innerLayerProvider: $BlockStateProvider;
        innerPlacements: $List<$BlockState>;
        invalidBlocks: $TagKey<$Block>;
        middleLayerProvider: $BlockStateProvider;
        outerLayerProvider: $BlockStateProvider;
    }

    export class $GeodeCrackSettings {
        constructor(arg0: number, arg1: number, arg2: number);
        static CODEC: $Codec<$GeodeCrackSettings>;
        baseCrackSize: number;
        crackPointOffset: number;
        generateCrackChance: number;
    }

    export class $GeodeLayerSettings {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        static CODEC: $Codec<$GeodeLayerSettings>;
        filling: number;
        innerLayer: number;
        middleLayer: number;
        outerLayer: number;
    }

    export class $Heightmap {
        constructor(arg0: $ChunkAccess, arg1: $Heightmap$Types_);
        get rawData(): number[];
        getRawData(): number[];
        static primeHeightmaps(arg0: $ChunkAccess, arg1: $Heightmap$Types_[]): void;
        getFirstAvailable(arg0: number, arg1: number): number;
        getHighestTaken(arg0: number, arg1: number): number;
        setRawData(arg0: $ChunkAccess, arg1: $Heightmap$Types_, arg2: number[]): void;
        update(arg0: number, arg1: number, arg2: number, arg3: $BlockState_): boolean;
    }

    export class $Heightmap$Types {
        static MOTION_BLOCKING: $Heightmap$Types;
        static MOTION_BLOCKING_NO_LEAVES: $Heightmap$Types;
        static OCEAN_FLOOR: $Heightmap$Types;
        static OCEAN_FLOOR_WG: $Heightmap$Types;
        static WORLD_SURFACE: $Heightmap$Types;
        static WORLD_SURFACE_WG: $Heightmap$Types;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Heightmap$Types[];
        static valueOf(name: string): $Heightmap$Types;
    }
    export interface $Heightmap$Types extends $Enum<$Heightmap$Types> {}

    export class $LegacyRandomSource implements $BitRandomSource {
        constructor(arg0: number);
        consumeCount(arg0: number): void;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextGaussian(): number;
        nextIntBetweenInclusive(arg0: number, arg1: number): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(): number;
        next(arg0: number): number;
        setSeed(arg0: number): void;
        triangle(arg0: number, arg1: number): number;
    }

    export class $NoiseChunk implements $DensityFunction$ContextProvider, $DensityFunction$FunctionContext {
        constructor(arg0: number, arg1: $RandomState, arg2: number, arg3: number, arg4: $NoiseSettings, arg5: $DensityFunctions$BeardifierOrMarker, arg6: $NoiseGeneratorSettings, arg7: $Aquifer$FluidPicker_<number, number, number, $Aquifer$FluidStatus>, arg8: $Blender);
        get blender(): $Blender;
        getBlender(): $Blender;
        static forChunk(arg0: $ChunkAccess, arg1: $RandomState, arg2: $DensityFunctions$BeardifierOrMarker, arg3: $NoiseGeneratorSettings, arg4: $Aquifer$FluidPicker_<number, number, number, $Aquifer$FluidStatus>, arg5: $Blender): $NoiseChunk;
        advanceCellX(arg0: number): void;
        aquifer(): $Aquifer;
        blockX(): number;
        blockY(): number;
        blockZ(): number;
        fillAllDirectly(arg0: number[], arg1: $DensityFunction): void;
        forIndex(arg0: number): $NoiseChunk;
        initializeForFirstCellX(): void;
        preliminarySurfaceLevel(arg0: number, arg1: number): number;
        selectCellYZ(arg0: number, arg1: number): void;
        stopInterpolation(): void;
        swapSlices(): void;
        updateForX(arg0: number, arg1: number): void;
        updateForY(arg0: number, arg1: number): void;
        updateForZ(arg0: number, arg1: number): void;
    }

    export class $NoiseGeneratorSettings extends $Record {
        constructor(arg0: $NoiseSettings, arg1: $BlockState_, arg2: $BlockState_, arg3: $NoiseRouter, arg4: $SurfaceRules$RuleSource, arg5: $Climate$ParameterPoint[], arg6: number, arg7: boolean, arg8: boolean, arg9: boolean, arg10: boolean);
        static AMPLIFIED: $ResourceKey<$NoiseGeneratorSettings>;
        static CAVES: $ResourceKey<$NoiseGeneratorSettings>;
        static CODEC: $Codec<$Holder<$NoiseGeneratorSettings>>;
        static DIRECT_CODEC: $Codec<$NoiseGeneratorSettings>;
        static END: $ResourceKey<$NoiseGeneratorSettings>;
        static FLOATING_ISLANDS: $ResourceKey<$NoiseGeneratorSettings>;
        static LARGE_BIOMES: $ResourceKey<$NoiseGeneratorSettings>;
        static NETHER: $ResourceKey<$NoiseGeneratorSettings>;
        static OVERWORLD: $ResourceKey<$NoiseGeneratorSettings>;
        get randomSource(): $WorldgenRandom$Algorithm;
        getRandomSource(): $WorldgenRandom$Algorithm;
        isAquifersEnabled(): boolean;
        static bootstrap(arg0: $BootstrapContext<$NoiseGeneratorSettings>): void;
        static caves(arg0: $BootstrapContext<any>): $NoiseGeneratorSettings;
        static dummy(): $NoiseGeneratorSettings;
        static end(arg0: $BootstrapContext<any>): $NoiseGeneratorSettings;
        static floatingIslands(arg0: $BootstrapContext<any>): $NoiseGeneratorSettings;
        static nether(arg0: $BootstrapContext<any>): $NoiseGeneratorSettings;
        static overworld(arg0: $BootstrapContext<any>, arg1: boolean, arg2: boolean): $NoiseGeneratorSettings;
        aquifersEnabled(): boolean;
        defaultBlock(): $BlockState;
        defaultFluid(): $BlockState;
        disableMobGeneration(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        noiseRouter(): $NoiseRouter;
        noiseSettings(): $NoiseSettings;
        oreVeinsEnabled(): boolean;
        seaLevel(): number;
        spawnTarget(): $List<$Climate$ParameterPoint>;
        surfaceRule(): $SurfaceRules$RuleSource;
        toString(): string;
        useLegacyRandomSource(): boolean;
    }

    export class $NoiseRouter extends $Record {
        constructor(arg0: $DensityFunction, arg1: $DensityFunction, arg2: $DensityFunction, arg3: $DensityFunction, arg4: $DensityFunction, arg5: $DensityFunction, arg6: $DensityFunction, arg7: $DensityFunction, arg8: $DensityFunction, arg9: $DensityFunction, arg10: $DensityFunction, arg11: $DensityFunction, arg12: $DensityFunction, arg13: $DensityFunction, arg14: $DensityFunction);
        static CODEC: $Codec<$NoiseRouter>;
        barrierNoise(): $DensityFunction;
        continents(): $DensityFunction;
        depth(): $DensityFunction;
        equals(arg0: object): boolean;
        erosion(): $DensityFunction;
        finalDensity(): $DensityFunction;
        fluidLevelFloodednessNoise(): $DensityFunction;
        fluidLevelSpreadNoise(): $DensityFunction;
        hashCode(): number;
        initialDensityWithoutJaggedness(): $DensityFunction;
        lavaNoise(): $DensityFunction;
        mapAll(arg0: $DensityFunction$Visitor_<$DensityFunction, $DensityFunction>): $NoiseRouter;
        ridges(): $DensityFunction;
        temperature(): $DensityFunction;
        toString(): string;
        vegetation(): $DensityFunction;
        veinGap(): $DensityFunction;
        veinRidged(): $DensityFunction;
        veinToggle(): $DensityFunction;
    }

    export class $NoiseSettings extends $Record {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number);
        static CODEC: $Codec<$NoiseSettings>;
        get cellHeight(): number;
        getCellHeight(): number;
        get cellWidth(): number;
        getCellWidth(): number;
        static create(arg0: number, arg1: number, arg2: number, arg3: number): $NoiseSettings;
        clampToHeightAccessor(arg0: $LevelHeightAccessor): $NoiseSettings;
        equals(arg0: object): boolean;
        hashCode(): number;
        height(): number;
        minY(): number;
        noiseSizeHorizontal(): number;
        noiseSizeVertical(): number;
        toString(): string;
    }

    export interface $PositionalRandomFactory {
        at(arg0: number, arg1: number, arg2: number): $RandomSource;
        at(arg0: $BlockPos_): $RandomSource;
        fromHashOf(arg0: string): $RandomSource;
        fromHashOf(arg0: $ResourceLocation_): $RandomSource;
        fromSeed(arg0: number): $RandomSource;
        parityConfigString(arg0: $StringBuilder): void;
    }

    export class $RandomState {
        static create(arg0: $HolderGetter$Provider_<$ResourceKey<$Registry<any>>, $Optional<$HolderGetter<any>>>, arg1: $ResourceKey<$NoiseGeneratorSettings>, arg2: number): $RandomState;
        static create(arg0: $NoiseGeneratorSettings, arg1: $HolderGetter<$NormalNoise$NoiseParameters>, arg2: number): $RandomState;
        aquiferRandom(): $PositionalRandomFactory;
        getOrCreateNoise(arg0: $ResourceKey<$NormalNoise$NoiseParameters>): $NormalNoise;
        getOrCreateRandomFactory(arg0: $ResourceLocation_): $PositionalRandomFactory;
        oreRandom(): $PositionalRandomFactory;
        router(): $NoiseRouter;
        sampler(): $Climate$Sampler;
        surfaceSystem(): $SurfaceSystem;
    }

    export class $RandomSupport$Seed128bit extends $Record {
        constructor(arg0: number, arg1: number);
        equals(arg0: object): boolean;
        hashCode(): number;
        mixed(): $RandomSupport$Seed128bit;
        seedHi(): number;
        seedLo(): number;
        toString(): string;
        xor(arg0: number, arg1: number): $RandomSupport$Seed128bit;
        xor(arg0: $RandomSupport$Seed128bit): $RandomSupport$Seed128bit;
    }

    export interface $SurfaceRules$RuleSource extends $Function<$SurfaceRules$Context, $SurfaceRules$SurfaceRule> {
        codec(): $KeyDispatchDataCodec<$SurfaceRules$RuleSource>;
    }
    export const $SurfaceRules$RuleSource: {
        bootstrap(arg0: $Registry<$MapCodec<$SurfaceRules$RuleSource>>): $MapCodec<$SurfaceRules$RuleSource>;
        readonly CODEC: $Codec<$SurfaceRules$RuleSource>;
    };

    export class $SurfaceSystem {
        constructor(arg0: $RandomState, arg1: $BlockState_, arg2: number, arg3: $PositionalRandomFactory);
        buildSurface(arg0: $RandomState, arg1: $BiomeManager, arg2: $Registry<$Biome>, arg3: boolean, arg4: $WorldGenerationContext, arg5: $ChunkAccess, arg6: $NoiseChunk, arg7: $SurfaceRules$RuleSource): void;
        topMaterial(arg0: $SurfaceRules$RuleSource, arg1: $CarvingContext, arg2: $Function_<$BlockPos, $Holder<$Biome>, $BlockPos, $Holder_<$Biome>>, arg3: $ChunkAccess, arg4: $NoiseChunk, arg5: $BlockPos_, arg6: boolean): $Optional<$BlockState>;
    }

    export class $WorldDimensions$Complete extends $Record {
        constructor(dimensions: $Registry<$LevelStem>, specialWorldProperty: $PrimaryLevelData$SpecialWorldProperty_);
        dimensionsRegistryAccess(): $RegistryAccess$Frozen;
        dimensions(): $Registry<$LevelStem>;
        equals(arg0: object): boolean;
        hashCode(): number;
        lifecycle(): $Lifecycle;
        specialWorldProperty(): $PrimaryLevelData$SpecialWorldProperty;
        toString(): string;
    }

    export class $WorldGenerationContext {
        constructor(arg0: $ChunkGenerator, arg1: $LevelHeightAccessor);
        get genDepth(): number;
        getGenDepth(): number;
        get minGenY(): number;
        getMinGenY(): number;
    }

    export class $WorldOptions {
        constructor(arg0: number, arg1: boolean, arg2: boolean);
        static CODEC: $MapCodec<$WorldOptions>;
        static DEMO_OPTIONS: $WorldOptions;
        get oldCustomizedWorld(): boolean;
        isOldCustomizedWorld(): boolean;
        static defaultWithRandomSeed(): $WorldOptions;
        static parseSeed(arg0: string): $OptionalLong;
        static randomSeed(): number;
        generateBonusChest(): boolean;
        generateStructures(): boolean;
        seed(): number;
        withBonusChest(arg0: boolean): $WorldOptions;
        withSeed(arg0: $OptionalLong): $WorldOptions;
        withStructures(arg0: boolean): $WorldOptions;
    }

    export class $WorldgenRandom extends $LegacyRandomSource {
        constructor(arg0: $RandomSource);
        get count(): number;
        getCount(): number;
        static seedSlimeChunk(arg0: number, arg1: number, arg2: number, arg3: number): $RandomSource;
        consumeCount(arg0: number): void;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextIntBetweenInclusive(arg0: number, arg1: number): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(): number;
        next(arg0: number): number;
        setDecorationSeed(arg0: number, arg1: number, arg2: number): number;
        setFeatureSeed(arg0: number, arg1: number, arg2: number): void;
        setLargeFeatureSeed(arg0: number, arg1: number, arg2: number): void;
        setLargeFeatureWithSalt(arg0: number, arg1: number, arg2: number, arg3: number): void;
        setSeed(arg0: number): void;
        triangle(arg0: number, arg1: number): number;
    }

    export class $WorldgenRandom$Algorithm {
        static LEGACY: $WorldgenRandom$Algorithm;
        static XOROSHIRO: $WorldgenRandom$Algorithm;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $WorldgenRandom$Algorithm[];
        static valueOf(name: string): $WorldgenRandom$Algorithm;
    }
    export interface $WorldgenRandom$Algorithm extends $Enum<$WorldgenRandom$Algorithm> {}

    export class $XoroshiroRandomSource implements $RandomSource {
        constructor(arg0: number);
        constructor(arg0: number, arg1: number);
        constructor(arg0: $RandomSupport$Seed128bit);
        static CODEC: $Codec<$XoroshiroRandomSource>;
        consumeCount(arg0: number): void;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextGaussian(): number;
        nextIntBetweenInclusive(arg0: number, arg1: number): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(): number;
        setSeed(arg0: number): void;
        triangle(arg0: number, arg1: number): number;
    }

    export class $DensityFunction$NoiseHolder extends $Record {
        constructor(arg0: $Holder_<$NormalNoise$NoiseParameters>);
        constructor(arg0: $Holder_<$NormalNoise$NoiseParameters>, arg1: $NormalNoise);
        static CODEC: $Codec<$DensityFunction$NoiseHolder>;
        equals(arg0: object): boolean;
        getValue(arg0: number, arg1: number, arg2: number): number;
        hashCode(): number;
        maxValue(): number;
        noiseData(): $Holder<$NormalNoise$NoiseParameters>;
        noise(): $NormalNoise;
        toString(): string;
    }

    export interface $BitRandomSource extends $RandomSource {
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(): number;
        next(arg0: number): number;
    }
    export const $BitRandomSource: {
        readonly DOUBLE_MULTIPLIER: number;
        readonly FLOAT_MULTIPLIER: number;
    };

    export class $SurfaceRules$Context {
    }

    export interface $SurfaceRules$SurfaceRule {
        tryApply(arg0: number, arg1: number, arg2: number): $BlockState;
    }

    export interface $VerticalAnchor {
        resolveY(arg0: $WorldGenerationContext): number;
    }
    export const $VerticalAnchor: {
        aboveBottom(arg0: number): $VerticalAnchor;
        absolute(arg0: number): $VerticalAnchor;
        belowTop(arg0: number): $VerticalAnchor;
        bottom(): $VerticalAnchor;
        top(): $VerticalAnchor;
        readonly BOTTOM: $VerticalAnchor;
        readonly CODEC: $Codec<$VerticalAnchor>;
        readonly TOP: $VerticalAnchor;
    };

    export class $NoiseBasedChunkGenerator extends $ChunkGenerator {
        constructor(arg0: $BiomeSource, arg1: $Holder_<$NoiseGeneratorSettings>);
        static CODEC: $MapCodec<$NoiseBasedChunkGenerator>;
        get genDepth(): number;
        getGenDepth(): number;
        get minY(): number;
        getMinY(): number;
        get seaLevel(): number;
        getSeaLevel(): number;
        addDebugScreenInfo(arg0: string[], arg1: $RandomState, arg2: $BlockPos_): void;
        applyCarvers(arg0: $WorldGenRegion, arg1: number, arg2: $RandomState, arg3: $BiomeManager, arg4: $StructureManager, arg5: $ChunkAccess, arg6: $GenerationStep$Carving_): void;
        buildSurface(arg0: $WorldGenRegion, arg1: $StructureManager, arg2: $RandomState, arg3: $ChunkAccess): void;
        buildSurface(arg0: $ChunkAccess, arg1: $WorldGenerationContext, arg2: $RandomState, arg3: $StructureManager, arg4: $BiomeManager, arg5: $Registry<$Biome>, arg6: $Blender): void;
        createBiomes(arg0: $RandomState, arg1: $Blender, arg2: $StructureManager, arg3: $ChunkAccess): $CompletableFuture<$ChunkAccess>;
        fillFromNoise(arg0: $Blender, arg1: $RandomState, arg2: $StructureManager, arg3: $ChunkAccess): $CompletableFuture<$ChunkAccess>;
        generatorSettings(): $Holder<$NoiseGeneratorSettings>;
        getBaseColumn(arg0: number, arg1: number, arg2: $LevelHeightAccessor, arg3: $RandomState): $NoiseColumn;
        getBaseHeight(arg0: number, arg1: number, arg2: $Heightmap$Types_, arg3: $LevelHeightAccessor, arg4: $RandomState): number;
        spawnOriginalMobs(arg0: $WorldGenRegion): void;
        stable(arg0: $ResourceKey<$NoiseGeneratorSettings>): boolean;
    }

    export type $Aquifer$FluidPicker_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackResult = $Aquifer$FluidStatus> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($Aquifer$FluidPicker & { readonly [Symbol.hasInstance]?: never });
    export type $DensityFunction$Visitor_<CallbackArg0 = $DensityFunction, CallbackResult = $DensityFunction> = ((arg0: CallbackArg0) => CallbackResult) | ($DensityFunction$Visitor & { readonly [Symbol.hasInstance]?: never });
    export type $GenerationStep$Carving_ = $GenerationStep$Carving | "AIR" | "LIQUID";
    export type $GenerationStep$Decoration_ = $GenerationStep$Decoration | "FLUID_SPRINGS" | "LAKES" | "LOCAL_MODIFICATIONS" | "RAW_GENERATION" | "STRONGHOLDS" | "SURFACE_STRUCTURES" | "TOP_LAYER_MODIFICATION" | "UNDERGROUND_DECORATION" | "UNDERGROUND_ORES" | "UNDERGROUND_STRUCTURES" | "VEGETAL_DECORATION";
    export type $Heightmap$Types_ = $Heightmap$Types | "MOTION_BLOCKING" | "MOTION_BLOCKING_NO_LEAVES" | "OCEAN_FLOOR" | "OCEAN_FLOOR_WG" | "WORLD_SURFACE" | "WORLD_SURFACE_WG";
    export type $WorldgenRandom$Algorithm_ = $WorldgenRandom$Algorithm | "LEGACY" | "XOROSHIRO";
    export type $SurfaceRules$SurfaceRule_<CallbackArg0 = number, CallbackArg1 = number, CallbackArg2 = number, CallbackResult = $BlockState_> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($SurfaceRules$SurfaceRule & { readonly [Symbol.hasInstance]?: never });
    export type $VerticalAnchor_<CallbackArg0 = $WorldGenerationContext, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($VerticalAnchor & { readonly [Symbol.hasInstance]?: never });
}
