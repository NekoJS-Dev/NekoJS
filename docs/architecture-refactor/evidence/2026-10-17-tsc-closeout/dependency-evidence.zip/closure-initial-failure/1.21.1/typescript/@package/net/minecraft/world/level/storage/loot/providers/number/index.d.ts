import type { RegistryTypes } from "@special/types";
import { $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Record } from "java:java/lang";
import { $LootContext, $LootContextUser } from "java:net/minecraft/world/level/storage/loot";

declare module "java:net/minecraft/world/level/storage/loot/providers/number" {
    export class $LootNumberProviderType extends $Record {
        constructor(arg0: $MapCodec<$NumberProvider>);
        codec(): $MapCodec<$NumberProvider>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $NumberProvider extends $LootContextUser {
        getFloat(arg0: $LootContext): number;
        getInt(arg0: $LootContext): number;
        getType(): $LootNumberProviderType;
    }

    export type $LootNumberProviderType_ = $LootNumberProviderType | RegistryTypes.LootNumberProviderType | $NekoId | string;
}
