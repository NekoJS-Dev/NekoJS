export * as attachment from "java:net/neoforged/neoforge/attachment";
export * as capabilities from "java:net/neoforged/neoforge/capabilities";
export * as client from "java:net/neoforged/neoforge/client";
export * as common from "java:net/neoforged/neoforge/common";
export * as energy from "java:net/neoforged/neoforge/energy";
export * as entity from "java:net/neoforged/neoforge/entity";
export * as event from "java:net/neoforged/neoforge/event";
export * as fluids from "java:net/neoforged/neoforge/fluids";
export * as items from "java:net/neoforged/neoforge/items";
export * as mixins from "java:net/neoforged/neoforge/mixins";
export * as network from "java:net/neoforged/neoforge/network";
export * as registries from "java:net/neoforged/neoforge/registries";
export * as resource from "java:net/neoforged/neoforge/resource";

