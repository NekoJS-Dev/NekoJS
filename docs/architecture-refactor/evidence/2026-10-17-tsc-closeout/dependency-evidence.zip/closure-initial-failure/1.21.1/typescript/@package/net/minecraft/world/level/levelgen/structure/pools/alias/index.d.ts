import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List } from "java:java/util";
import { $BiConsumer, $BiConsumer_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $ResourceKey } from "java:net/minecraft/resources";
import { $RandomSource } from "java:net/minecraft/util";
import { $SimpleWeightedRandomList } from "java:net/minecraft/util/random";
import { $StructureTemplatePool } from "java:net/minecraft/world/level/levelgen/structure/pools";

declare module "java:net/minecraft/world/level/levelgen/structure/pools/alias" {
    export interface $PoolAliasBinding {
        allTargets(): $Stream<$ResourceKey<$StructureTemplatePool>>;
        codec(): $MapCodec<$PoolAliasBinding>;
        forEachResolved(arg0: $RandomSource, arg1: $BiConsumer_<$ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>>): void;
    }
    export const $PoolAliasBinding: {
        direct(arg0: string, arg1: string): $Direct;
        direct(arg0: $ResourceKey<$StructureTemplatePool>, arg1: $ResourceKey<$StructureTemplatePool>): $Direct;
        randomGroup(arg0: $SimpleWeightedRandomList<$List<$PoolAliasBinding>>): $RandomGroup;
        random(arg0: string, arg1: $SimpleWeightedRandomList<string>): $Random;
        random(arg0: $ResourceKey<$StructureTemplatePool>, arg1: $SimpleWeightedRandomList<$ResourceKey<$StructureTemplatePool>>): $Random;
        readonly CODEC: $Codec<$PoolAliasBinding>;
    };

    export class $Direct extends $Record implements $PoolAliasBinding {
        alias(): $ResourceKey<$StructureTemplatePool>;
        allTargets(): $Stream<$ResourceKey<$StructureTemplatePool>>;
        codec(): $MapCodec<$Direct>;
        equals(arg0: object): boolean;
        forEachResolved(arg0: $RandomSource, arg1: $BiConsumer_<$ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>>): void;
        hashCode(): number;
        target(): $ResourceKey<$StructureTemplatePool>;
        toString(): string;
    }

    export class $Random extends $Record implements $PoolAliasBinding {
        alias(): $ResourceKey<$StructureTemplatePool>;
        allTargets(): $Stream<$ResourceKey<$StructureTemplatePool>>;
        codec(): $MapCodec<$Random>;
        equals(arg0: object): boolean;
        forEachResolved(arg0: $RandomSource, arg1: $BiConsumer_<$ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>>): void;
        hashCode(): number;
        targets(): $SimpleWeightedRandomList<$ResourceKey<$StructureTemplatePool>>;
        toString(): string;
    }

    export class $RandomGroup extends $Record implements $PoolAliasBinding {
        allTargets(): $Stream<$ResourceKey<$StructureTemplatePool>>;
        codec(): $MapCodec<$RandomGroup>;
        equals(arg0: object): boolean;
        forEachResolved(arg0: $RandomSource, arg1: $BiConsumer_<$ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>, $ResourceKey<$StructureTemplatePool>>): void;
        groups(): $SimpleWeightedRandomList<$List<$PoolAliasBinding>>;
        hashCode(): number;
        toString(): string;
    }

}
