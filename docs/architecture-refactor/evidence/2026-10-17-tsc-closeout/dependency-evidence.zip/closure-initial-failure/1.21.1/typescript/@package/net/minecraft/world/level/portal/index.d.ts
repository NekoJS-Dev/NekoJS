import { $Record } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $BlockUtil$FoundRectangle } from "java:net/minecraft";
import { $BlockPos, $BlockPos_, $Direction$Axis, $Direction$Axis_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $Entity, $EntityDimensions } from "java:net/minecraft/world/entity";
import { $LevelAccessor } from "java:net/minecraft/world/level";
import { $WorldBorder } from "java:net/minecraft/world/level/border";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/world/level/portal" {
    export class $DimensionTransition extends $Record {
        constructor(arg0: $ServerLevel, arg1: $Entity, arg2: $DimensionTransition$PostDimensionTransition_<$Entity>);
        constructor(arg0: $ServerLevel, arg1: $Vec3_, arg2: $Vec3_, arg3: number, arg4: number, arg5: boolean, arg6: $DimensionTransition$PostDimensionTransition_<$Entity>);
        constructor(arg0: $ServerLevel, arg1: $Vec3_, arg2: $Vec3_, arg3: number, arg4: number, arg5: $DimensionTransition$PostDimensionTransition_<$Entity>);
        static DO_NOTHING: $DimensionTransition$PostDimensionTransition;
        static PLACE_PORTAL_TICKET: $DimensionTransition$PostDimensionTransition;
        static PLAY_PORTAL_SOUND: $DimensionTransition$PostDimensionTransition;
        static missingRespawnBlock(arg0: $ServerLevel, arg1: $Entity, arg2: $DimensionTransition$PostDimensionTransition_<$Entity>): $DimensionTransition;
        equals(arg0: object): boolean;
        hashCode(): number;
        missingRespawnBlock(): boolean;
        newLevel(): $ServerLevel;
        postDimensionTransition(): $DimensionTransition$PostDimensionTransition;
        pos(): $Vec3;
        speed(): $Vec3;
        toString(): string;
        xRot(): number;
        yRot(): number;
    }

    export interface $DimensionTransition$PostDimensionTransition {
        onTransition(arg0: $Entity): void;
        then(arg0: $DimensionTransition$PostDimensionTransition_<$Entity>): $DimensionTransition$PostDimensionTransition;
    }

    export class $PortalForcer {
        constructor(arg0: $ServerLevel);
        static TICKET_RADIUS: number;
        createPortal(arg0: $BlockPos_, arg1: $Direction$Axis_): $Optional<$BlockUtil$FoundRectangle>;
        findClosestPortalPosition(arg0: $BlockPos_, arg1: boolean, arg2: $WorldBorder): $Optional<$BlockPos>;
    }

    export class $PortalShape {
        constructor(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $Direction$Axis_);
        static MAX_HEIGHT: number;
        static MAX_WIDTH: number;
        get complete(): boolean;
        isComplete(): boolean;
        get valid(): boolean;
        isValid(): boolean;
        static findCollisionFreePosition(arg0: $Vec3_, arg1: $ServerLevel, arg2: $Entity, arg3: $EntityDimensions): $Vec3;
        static findEmptyPortalShape(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $Direction$Axis_): $Optional<$PortalShape>;
        static findPortalShape(arg0: $LevelAccessor, arg1: $BlockPos_, arg2: $Predicate_<$PortalShape, $PortalShape, boolean>, arg3: $Direction$Axis_): $Optional<$PortalShape>;
        static getRelativePosition(arg0: $BlockUtil$FoundRectangle, arg1: $Direction$Axis_, arg2: $Vec3_, arg3: $EntityDimensions): $Vec3;
        createPortalBlocks(): void;
    }

    export type $DimensionTransition$PostDimensionTransition_<CallbackArg0 = $Entity> = ((arg0: CallbackArg0) => void) | ($DimensionTransition$PostDimensionTransition & { readonly [Symbol.hasInstance]?: never });
}
