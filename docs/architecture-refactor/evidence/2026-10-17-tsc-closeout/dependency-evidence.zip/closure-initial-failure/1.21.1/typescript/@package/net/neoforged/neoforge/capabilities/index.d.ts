import { $Class } from "java:java/lang";
import { $List } from "java:java/util";
import { $BlockPos, $BlockPos_, $Direction, $Direction_ } from "java:net/minecraft/core";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $Entity, $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $ItemLike, $ItemLike_, $Level } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_ } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Event } from "java:net/neoforged/bus/api";
import { $IModBusEvent } from "java:net/neoforged/fml/event";

declare module "java:net/neoforged/neoforge/capabilities" {
    export class $BaseCapability<T, C> {
        contextClass(): $Class<C>;
        name(): $ResourceLocation;
        typeClass(): $Class<T>;
    }

    export class $BlockCapability<T, C> extends $BaseCapability<T, C> {
        get proxyable(): boolean;
        isProxyable(): boolean;
        static createSided<T>(arg0: $ResourceLocation_, arg1: $Class<T>): $BlockCapability<T, $Direction>;
        static createVoid<T>(arg0: $ResourceLocation_, arg1: $Class<T>): $BlockCapability<T, void>;
        static create<T, C>(arg0: $ResourceLocation_, arg1: $Class<T>, arg2: $Class<C>): $BlockCapability<T, C>;
        static getAllProxyable(): $List<$BlockCapability<any, any>>;
        static getAll(): $List<$BlockCapability<any, any>>;
        getCapability(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity, arg4: C): T;
    }

    export class $Capabilities {
    }

    export class $EntityCapability<T, C> extends $BaseCapability<T, C> {
        static createSided<T>(arg0: $ResourceLocation_, arg1: $Class<T>): $EntityCapability<T, $Direction>;
        static createVoid<T>(arg0: $ResourceLocation_, arg1: $Class<T>): $EntityCapability<T, void>;
        static create<T, C>(arg0: $ResourceLocation_, arg1: $Class<T>, arg2: $Class<C>): $EntityCapability<T, C>;
        static getAll(): $List<$EntityCapability<any, any>>;
        getCapability(arg0: $Entity, arg1: C): T;
    }

    export interface $IBlockCapabilityProvider<T, C> {
        getCapability(arg0: $Level, arg1: $BlockPos_, arg2: $BlockState_, arg3: $BlockEntity, arg4: C): T;
    }

    export interface $ICapabilityInvalidationListener {
        onInvalidate(): boolean;
    }

    export interface $ICapabilityProvider<O, C, T> {
        getCapability(arg0: O, arg1: C): T;
    }

    export class $ItemCapability<T, C> extends $BaseCapability<T, C> {
        static createVoid<T>(arg0: $ResourceLocation_, arg1: $Class<T>): $ItemCapability<T, void>;
        static create<T, C>(arg0: $ResourceLocation_, arg1: $Class<T>, arg2: $Class<C>): $ItemCapability<T, C>;
        static getAll(): $List<$ItemCapability<any, any>>;
        getCapability(arg0: $ItemStack_, arg1: C): T;
    }

    export class $RegisterCapabilitiesEvent extends $Event implements $IModBusEvent {
        isBlockRegistered(arg0: $BlockCapability<any, any>, arg1: $Block_): boolean;
        isEntityRegistered(arg0: $EntityCapability<any, any>, arg1: $EntityType_<any>): boolean;
        isItemRegistered(arg0: $ItemCapability<any, any>, arg1: $Item_): boolean;
        registerBlockEntity<T, C, BE extends $BlockEntity>(arg0: $BlockCapability<T, C>, arg1: $BlockEntityType_<BE>, arg2: $ICapabilityProvider_<BE, C, T, BE, C, T>): void;
        registerBlock<T, C>(arg0: $BlockCapability<T, C>, arg1: $IBlockCapabilityProvider_<T, C, $Level, $BlockPos, $BlockState, $BlockEntity, C, T>, arg2?: $Block_[]): void;
        registerEntity<T, C, E extends $Entity>(arg0: $EntityCapability<T, C>, arg1: $EntityType_<E>, arg2: $ICapabilityProvider_<E, C, T, E, C, T>): void;
        registerItem<T, C>(arg0: $ItemCapability<T, C>, arg1: $ICapabilityProvider_<$ItemStack, C, T, $ItemStack, C, T>, arg2?: $ItemLike_[]): void;
        setNonProxyable(arg0: $BlockCapability<any, any>): void;
        setProxyable(arg0: $BlockCapability<any, any>): void;
    }

    export type $IBlockCapabilityProvider_<Host0 = any, Host1 = any, CallbackArg0 = $Level, CallbackArg1 = $BlockPos, CallbackArg2 = $BlockState, CallbackArg3 = $BlockEntity, CallbackArg4 = Host1, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4) => CallbackResult) | ($IBlockCapabilityProvider<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
    export type $ICapabilityInvalidationListener_<CallbackResult = boolean> = (() => CallbackResult) | ($ICapabilityInvalidationListener & { readonly [Symbol.hasInstance]?: never });
    export type $ICapabilityProvider_<Host0 = any, Host1 = any, Host2 = any, CallbackArg0 = Host0, CallbackArg1 = Host1, CallbackResult = Host2> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($ICapabilityProvider<Host0, Host1, Host2> & { readonly [Symbol.hasInstance]?: never });
}
