import type { RegistryTypes } from "@special/types";
import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $Record } from "java:java/lang";
import { $List } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $Holder, $Holder_ } from "java:net/minecraft/core";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $TagKey, $TagKey_ } from "java:net/minecraft/tags";
import { $Fluid, $Fluid_ } from "java:net/minecraft/world/level/material";
import { $FluidStack, $FluidStack_ } from "java:net/neoforged/neoforge/fluids";

declare module "java:net/neoforged/neoforge/fluids/crafting" {
    export class $FluidIngredient implements $Predicate<$FluidStack> {
        constructor();
        static CODEC: $Codec<$FluidIngredient>;
        static CODEC_NON_EMPTY: $Codec<$FluidIngredient>;
        static LIST_CODEC: $Codec<$List<$FluidIngredient>>;
        static LIST_CODEC_NON_EMPTY: $Codec<$List<$FluidIngredient>>;
        static MAP_CODEC_NONEMPTY: $MapCodec<$FluidIngredient>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $FluidIngredient>;
        get stacks(): $FluidStack[];
        getStacks(): $FluidStack[];
        get type(): $FluidIngredientType<any>;
        getType(): $FluidIngredientType<any>;
        get empty(): boolean;
        isEmpty(): boolean;
        get simple(): boolean;
        isSimple(): boolean;
        static empty(): $FluidIngredient;
        static of(arg0?: $Fluid_[]): $FluidIngredient;
        static of(arg0?: $FluidStack_[]): $FluidIngredient;
        static of(): $FluidIngredient;
        static single(arg0: $Holder_<$Fluid>): $FluidIngredient;
        static single(arg0: $Fluid_): $FluidIngredient;
        static single(arg0: $FluidStack_): $FluidIngredient;
        static tag(arg0: $TagKey_<$Fluid>): $FluidIngredient;
        and(arg0: $Predicate_<$FluidStack, $FluidStack, boolean>): $Predicate<$FluidStack>;
        equals(arg0: object): boolean;
        hasNoFluids(): boolean;
        hashCode(): number;
        negate(): $Predicate<$FluidStack>;
        or(arg0: $Predicate_<$FluidStack, $FluidStack, boolean>): $Predicate<$FluidStack>;
        test(arg0: $FluidStack_): boolean;
    }

    export class $FluidIngredientType<T extends $FluidIngredient> extends $Record {
        constructor(arg0: $MapCodec<T>);
        constructor(codec: $MapCodec<T>, streamCodec: $StreamCodec<any, T>);
        codec(): $MapCodec<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        streamCodec(): $StreamCodec<any, T>;
        toString(): string;
    }

    export class $SizedFluidIngredient {
        constructor(arg0: $FluidIngredient_, arg1: number);
        static FLAT_CODEC: $Codec<$SizedFluidIngredient>;
        static NESTED_CODEC: $Codec<$SizedFluidIngredient>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $SizedFluidIngredient>;
        get fluids(): $FluidStack[];
        getFluids(): $FluidStack[];
        static of(arg0: $TagKey_<$Fluid>, arg1: number): $SizedFluidIngredient;
        static of(arg0: $Fluid_, arg1: number): $SizedFluidIngredient;
        static of(arg0: $FluidStack_): $SizedFluidIngredient;
        amount(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        ingredient(): $FluidIngredient;
        test(arg0: $FluidStack_): boolean;
        toString(): string;
    }

    /** fluid:id | #tag | @mod | * | /regex/ | { fluid?|tag?|mod?|regex?|wildcard?|filter?|any?|all?|not?|ingredient? } */
    export type $FluidIngredient_ = $FluidIngredient | RegistryTypes.Fluid | `#${RegistryTypes.FluidTag}` | `@${RegistryTypes.Namespace}` | "*" | `/${string}` | $FluidIngredient_[] | $FluidStack | $Fluid | $NekoId | { fluid?: RegistryTypes.Fluid, tag?: RegistryTypes.FluidTag, mod?: RegistryTypes.Namespace, regex?: string, wildcard?: boolean, filter?: ((fluid: $FluidStack) => boolean), any?: $FluidIngredient_[], all?: $FluidIngredient_[], not?: $FluidIngredient_, ingredient?: $FluidIngredient_ };
    /** fluid:id | #tag | @mod | * | /regex/ | { ingredient|fluid|tag|mod|regex|wildcard|filter|any|all|not, amount } */
    export type $SizedFluidIngredient_ = $SizedFluidIngredient | RegistryTypes.Fluid | `#${RegistryTypes.FluidTag}` | `@${RegistryTypes.Namespace}` | "*" | `/${string}` | $FluidStack | $Fluid | $NekoId | { ingredient?: $SizedFluidIngredient_, fluid?: RegistryTypes.Fluid, tag?: RegistryTypes.FluidTag, mod?: RegistryTypes.Namespace, regex?: string, wildcard?: boolean, filter?: ((fluid: $FluidStack) => boolean), any?: $SizedFluidIngredient_[], all?: $SizedFluidIngredient_[], not?: $SizedFluidIngredient_, amount: number };
}
