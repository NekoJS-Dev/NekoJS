import { $Record } from "java:java/lang";
import { $Path, $PathMatcher, $PathMatcher_ } from "java:java/nio/file";
import { $List } from "java:java/util";

declare module "java:net/minecraft/world/level/validation" {
    export class $DirectoryValidator {
        constructor(arg0: $PathMatcher_<$Path, boolean>);
        validateDirectory(arg0: $Path, arg1: boolean): $List<$ForbiddenSymlinkInfo>;
        validateKnownDirectory(arg0: $Path, arg1: $ForbiddenSymlinkInfo[]): void;
        validateSymlink(arg0: $Path, arg1: $ForbiddenSymlinkInfo[]): void;
        validateSymlink(arg0: $Path): $List<$ForbiddenSymlinkInfo>;
    }

    export class $ForbiddenSymlinkInfo extends $Record {
        constructor(arg0: $Path, arg1: $Path);
        equals(arg0: object): boolean;
        hashCode(): number;
        link(): $Path;
        target(): $Path;
        toString(): string;
    }

}
