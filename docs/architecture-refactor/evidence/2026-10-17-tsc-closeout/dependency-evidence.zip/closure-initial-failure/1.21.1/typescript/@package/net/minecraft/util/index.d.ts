import { $ServicesKeyInfo, $ServicesKeySet, $ServicesKeySet_, $ServicesKeyType, $ServicesKeyType_ } from "java:com/mojang/authlib/yggdrasil";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $Codec$ResultFunction, $DataResult, $Decoder, $Decoder$Boxed, $Decoder$Boxed_, $Decoder$Simple, $Decoder$Simple_, $Decoder$Terminal, $Decoder$Terminal_, $Decoder_, $Dynamic, $DynamicOps, $Encoder, $Encoder_, $Keyable, $Keyable_, $Lifecycle, $MapCodec } from "java:com/mojang/serialization";
import { $Int2IntFunction, $Int2IntFunction_ } from "java:it/unimi/dsi/fastutil/ints";
import { $Class, $Comparable, $Comparable_, $Enum, $Record, $Runnable, $Runnable_ } from "java:java/lang";
import { $PublicKey } from "java:java/security";
import { $Collection, $List, $Optional } from "java:java/util";
import { $CompletableFuture, $Executor, $Executor_ } from "java:java/util/concurrent";
import { $Consumer, $Consumer_, $Function, $Function_, $IntConsumer, $IntConsumer_, $Supplier, $Supplier_, $ToIntFunction, $ToIntFunction_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Component, $Component_, $Style } from "java:net/minecraft/network/chat";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $PositionalRandomFactory } from "java:net/minecraft/world/level/levelgen";
import { $Logger } from "java:org/slf4j";

export * as datafix from "java:net/minecraft/util/datafix";
export * as debugchart from "java:net/minecraft/util/debugchart";
export * as profiling from "java:net/minecraft/util/profiling";
export * as random from "java:net/minecraft/util/random";
export * as thread from "java:net/minecraft/util/thread";
export * as valueproviders from "java:net/minecraft/util/valueproviders";

declare module "java:net/minecraft/util" {
    export interface $AbortableIterationConsumer<T> {
        accept(arg0: T): $AbortableIterationConsumer$Continuation;
    }
    export const $AbortableIterationConsumer: {
        forConsumer<T>(arg0: $Consumer_<T, T>): $AbortableIterationConsumer<T>;
    };

    export class $AbortableIterationConsumer$Continuation {
        static ABORT: $AbortableIterationConsumer$Continuation;
        static CONTINUE: $AbortableIterationConsumer$Continuation;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AbortableIterationConsumer$Continuation[];
        static valueOf(name: string): $AbortableIterationConsumer$Continuation;
    }
    export interface $AbortableIterationConsumer$Continuation extends $Enum<$AbortableIterationConsumer$Continuation> {}

    export interface $BitStorage {
        copy(): $BitStorage;
        getAll(arg0: $IntConsumer_<number>): void;
        getAndSet(arg0: number, arg1: number): number;
        getBits(): number;
        getRaw(): number[];
        getSize(): number;
        get(arg0: number): number;
        set(arg0: number, arg1: number): void;
        unpack(arg0: number[]): void;
    }

    export class $ExtraCodecs$TagOrElementLocation extends $Record {
        constructor(arg0: $ResourceLocation_, arg1: boolean);
        decoratedId(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        tag(): boolean;
        toString(): string;
    }

    export interface $FormattedCharSequence {
        accept(arg0: $FormattedCharSink_<number, $Style, number, boolean>): boolean;
    }
    export const $FormattedCharSequence: {
        backward(arg0: string, arg1: $Style, arg2: $Int2IntFunction_<number, number>): $FormattedCharSequence;
        backward(arg0: string, arg1: $Style): $FormattedCharSequence;
        codepoint(arg0: number, arg1: $Style): $FormattedCharSequence;
        composite(arg0: $FormattedCharSequence_<$FormattedCharSink, boolean>[]): $FormattedCharSequence;
        composite(arg0?: $FormattedCharSequence_<$FormattedCharSink, boolean>[]): $FormattedCharSequence;
        composite(arg0: $FormattedCharSequence_<$FormattedCharSink, boolean>, arg1: $FormattedCharSequence_<$FormattedCharSink, boolean>): $FormattedCharSequence;
        composite(arg0: $FormattedCharSequence_<$FormattedCharSink, boolean>): $FormattedCharSequence;
        composite(): $FormattedCharSequence;
        decorateOutput(arg0: $FormattedCharSink_<number, $Style, number, boolean>, arg1: $Int2IntFunction_<number, number>): $FormattedCharSink;
        forward(arg0: string, arg1: $Style, arg2: $Int2IntFunction_<number, number>): $FormattedCharSequence;
        forward(arg0: string, arg1: $Style): $FormattedCharSequence;
        fromList(arg0: $FormattedCharSequence_<$FormattedCharSink, boolean>[]): $FormattedCharSequence;
        fromPair(arg0: $FormattedCharSequence_<$FormattedCharSink, boolean>, arg1: $FormattedCharSequence_<$FormattedCharSink, boolean>): $FormattedCharSequence;
        readonly EMPTY: $FormattedCharSequence;
    };

    export interface $FormattedCharSink {
        accept(arg0: number, arg1: $Style, arg2: number): boolean;
    }

    export class $InclusiveRange<T extends ($Comparable<T> | string | number | boolean)> extends $Record {
        constructor(arg0: T);
        constructor(arg0: T, arg1: T);
        static INT: $Codec<$InclusiveRange<number>>;
        static codec<T extends ($Comparable<T> | string | number | boolean)>(arg0: $Codec<T>, arg1: T, arg2: T): $Codec<$InclusiveRange<T>>;
        static codec<T extends ($Comparable<T> | string | number | boolean)>(arg0: $Codec<T>): $Codec<$InclusiveRange<T>>;
        static create<T extends ($Comparable<T> | string | number | boolean)>(arg0: T, arg1: T): $DataResult<$InclusiveRange<T>>;
        contains(arg0: $InclusiveRange<T>): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        isValueInRange(arg0: T): boolean;
        maxInclusive(): T;
        minInclusive(): T;
        toString(): string;
    }

    export class $KeyDispatchDataCodec<A> extends $Record {
        constructor(arg0: $MapCodec<A>);
        static of<A>(arg0: $MapCodec<A>): $KeyDispatchDataCodec<A>;
        codec(): $MapCodec<A>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $ModCheck extends $Record {
        constructor(arg0: $ModCheck$Confidence_, arg1: string);
        static identify(arg0: string, arg1: $Supplier_<string, string>, arg2: string, arg3: $Class<any>): $ModCheck;
        confidence(): $ModCheck$Confidence;
        description(): string;
        equals(arg0: object): boolean;
        fullDescription(): string;
        hashCode(): number;
        merge(arg0: $ModCheck): $ModCheck;
        shouldReportAsModified(): boolean;
        toString(): string;
    }

    export class $ModCheck$Confidence {
        static DEFINITELY: $ModCheck$Confidence;
        static PROBABLY_NOT: $ModCheck$Confidence;
        static VERY_LIKELY: $ModCheck$Confidence;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ModCheck$Confidence[];
        static valueOf(name: string): $ModCheck$Confidence;
    }
    export interface $ModCheck$Confidence extends $Enum<$ModCheck$Confidence> {}

    export interface $OptionEnum {
        getCaption(): $Component;
        getId(): number;
        getKey(): string;
    }

    export interface $ProblemReporter {
        forChild(arg0: string): $ProblemReporter;
        report(arg0: string): void;
    }

    export interface $ProgressListener {
        progressStagePercentage(arg0: number): void;
        progressStage(arg0: $Component_): void;
        progressStartNoAbort(arg0: $Component_): void;
        progressStart(arg0: $Component_): void;
        stop(): void;
    }

    export interface $RandomSource {
        consumeCount(arg0: number): void;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextGaussian(): number;
        nextIntBetweenInclusive(arg0: number, arg1: number): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(): number;
        setSeed(arg0: number): void;
        triangle(arg0: number, arg1: number): number;
    }
    export const $RandomSource: {
        createNewThreadLocalInstance(): $RandomSource;
        createThreadSafe(): $RandomSource;
        create(arg0: number): $RandomSource;
        create(): $RandomSource;
        readonly GAUSSIAN_SPREAD_FACTOR: number;
    };

    export interface $SignatureUpdater {
        update(arg0: $SignatureUpdater$Output_<number[]>): void;
    }

    export interface $SignatureUpdater$Output {
        update(arg0: number[]): void;
    }

    export interface $SignatureValidator {
        validate(arg0: number[], arg1: number[]): boolean;
        validate(arg0: $SignatureUpdater_<$SignatureUpdater$Output>, arg1: number[]): boolean;
    }
    export const $SignatureValidator: {
        from(arg0: $ServicesKeySet_<$ServicesKeyType, $ServicesKeyInfo[]>, arg1: $ServicesKeyType_): $SignatureValidator;
        from(arg0: $PublicKey, arg1: string): $SignatureValidator;
        readonly LOGGER: $Logger;
        readonly NO_VALIDATION: $SignatureValidator;
    };

    export class $StaticCache2D<T> {
        static create<T>(arg0: number, arg1: number, arg2: number, arg3: $StaticCache2D$Initializer_<T, number, number, T>): $StaticCache2D<T>;
        contains(arg0: number, arg1: number): boolean;
        forEach(arg0: $Consumer_<T, T>): void;
        get(arg0: number, arg1: number): T;
        toString(): string;
    }

    export interface $StaticCache2D$Initializer<T> {
        get(arg0: number, arg1: number): T;
    }

    export interface $StringRepresentable {
        getSerializedName(): string;
    }
    export const $StringRepresentable: {
        createNameLookup<T extends $StringRepresentable>(arg0: T[], arg1: $Function_<string, string, string, string>): $Function<string, T>;
        fromEnumWithMapping<E extends $Enum<E> & $StringRepresentable>(arg0: $Supplier_<E[], E[]>, arg1: $Function_<string, string, string, string>): $StringRepresentable$EnumCodec<E>;
        fromEnum<E extends $Enum<E> & $StringRepresentable>(arg0: $Supplier_<E[], E[]>): $StringRepresentable$EnumCodec<E>;
        fromValues<T extends $StringRepresentable>(arg0: $Supplier_<T[], T[]>): $Codec<T>;
        keys(arg0: $StringRepresentable_<string>[]): $Keyable;
        readonly PRE_BUILT_MAP_THRESHOLD: number;
    };

    export class $StringRepresentable$EnumCodec<E extends $Enum<E>> extends $StringRepresentable$StringRepresentableCodec<E> {
        constructor(arg0: E[], arg1: $Function_<string, E, string, E>);
        boxed(): $Decoder$Boxed<E>;
        byName(arg0: string, arg1: E): E;
        byName(arg0: string): E;
        comapFlatMap<S>(arg0: $Function_<E, $DataResult<S>, E, $DataResult<S>>, arg1: $Function_<S, E, S, E>): $Codec<S>;
        comap<B>(arg0: $Function_<B, E, B, E>): $Encoder<B>;
        decode<T>(arg0: $Dynamic<T>): $DataResult<$Pair<E, T>>;
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<E, T>>;
        deprecated(arg0: number): $Codec<E>;
        dispatchMap<E1>(arg0: string, arg1: $Function_<E1, E, E1, E>, arg2: $Function_<E, $MapCodec<E1>, E, $MapCodec<E1>>): $MapCodec<E1>;
        dispatchMap<E1>(arg0: $Function_<E1, E, E1, E>, arg1: $Function_<E, $MapCodec<E1>, E, $MapCodec<E1>>): $MapCodec<E1>;
        dispatchStable<E1>(arg0: $Function_<E1, E, E1, E>, arg1: $Function_<E, $MapCodec<E1>, E, $MapCodec<E1>>): $Codec<E1>;
        dispatch<E1>(arg0: string, arg1: $Function_<E1, E, E1, E>, arg2: $Function_<E, $MapCodec<E1>, E, $MapCodec<E1>>): $Codec<E1>;
        dispatch<E1>(arg0: $Function_<E1, E, E1, E>, arg1: $Function_<E, $MapCodec<E1>, E, $MapCodec<E1>>): $Codec<E1>;
        encodeStart<T>(arg0: $DynamicOps<T>, arg1: E): $DataResult<T>;
        fieldOf(arg0: string): $MapCodec<E>;
        flatComapMap<S>(arg0: $Function_<E, S, E, S>, arg1: $Function_<S, $DataResult<E>, S, $DataResult<E>>): $Codec<S>;
        flatComap<B>(arg0: $Function_<B, $DataResult<E>, B, $DataResult<E>>): $Encoder<B>;
        flatMap<B>(arg0: $Function_<E, $DataResult<B>, E, $DataResult<B>>): $Decoder<B>;
        flatXmap<S>(arg0: $Function_<E, $DataResult<S>, E, $DataResult<S>>, arg1: $Function_<S, $DataResult<E>, S, $DataResult<E>>): $Codec<S>;
        lenientOptionalFieldOf(arg0: string, arg1: E, arg2: $Lifecycle): $MapCodec<E>;
        lenientOptionalFieldOf(arg0: string, arg1: E): $MapCodec<E>;
        lenientOptionalFieldOf(arg0: string, arg1: $Lifecycle, arg2: E, arg3: $Lifecycle): $MapCodec<E>;
        lenientOptionalFieldOf(arg0: string): $MapCodec<$Optional<E>>;
        listOf(arg0: number, arg1: number): $Codec<$List<E>>;
        listOf(): $Codec<$List<E>>;
        mapResult(arg0: $Codec$ResultFunction<E>): $Codec<E>;
        map<B>(arg0: $Function_<E, B, E, B>): $Decoder<B>;
        optionalFieldOf(arg0: string, arg1: E, arg2: $Lifecycle): $MapCodec<E>;
        optionalFieldOf(arg0: string, arg1: E): $MapCodec<E>;
        optionalFieldOf(arg0: string, arg1: $Lifecycle, arg2: E, arg3: $Lifecycle): $MapCodec<E>;
        optionalFieldOf(arg0: string): $MapCodec<$Optional<E>>;
        orElseGet(arg0: $Consumer_<string, string>, arg1: $Supplier_<E, E>): $Codec<E>;
        orElseGet(arg0: $Supplier_<E, E>): $Codec<E>;
        orElseGet(arg0: $UnaryOperator_<string, string, string>, arg1: $Supplier_<E, E>): $Codec<E>;
        orElse(arg0: E): $Codec<E>;
        orElse(arg0: $Consumer_<string, string>, arg1: E): $Codec<E>;
        orElse(arg0: $UnaryOperator_<string, string, string>, arg1: E): $Codec<E>;
        parse<T>(arg0: $Dynamic<T>): $DataResult<E>;
        parse<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<E>;
        partialDispatch<E1>(arg0: string, arg1: $Function_<E1, $DataResult<E>, E1, $DataResult<E>>, arg2: $Function_<E, $DataResult<$MapCodec<E1>>, E, $DataResult<$MapCodec<E1>>>): $Codec<E1>;
        promotePartial(arg0: $Consumer_<string, string>): $Codec<E>;
        simple(): $Decoder$Simple<E>;
        sizeLimitedListOf(arg0: number): $Codec<$List<E>>;
        stable(): $Codec<E>;
        terminal(): $Decoder$Terminal<E>;
        validate(arg0: $Function_<E, $DataResult<E>, E, $DataResult<E>>): $Codec<E>;
        withLifecycle(arg0: $Lifecycle): $Codec<E>;
        xmap<S>(arg0: $Function_<E, S, E, S>, arg1: $Function_<S, E, S, E>): $Codec<S>;
    }

    export class $StringRepresentable$StringRepresentableCodec<S extends $StringRepresentable> implements $Codec<S> {
        constructor(arg0: S[], arg1: $Function_<string, S, string, S>, arg2: $ToIntFunction_<S, S, number>);
        boxed(): $Decoder$Boxed<S>;
        comapFlatMap<S1>(arg0: $Function_<S, $DataResult<S1>, S, $DataResult<S1>>, arg1: $Function_<S1, S, S1, S>): $Codec<S1>;
        comap<B>(arg0: $Function_<B, S, B, S>): $Encoder<B>;
        decode<T>(arg0: $Dynamic<T>): $DataResult<$Pair<S, T>>;
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<S, T>>;
        deprecated(arg0: number): $Codec<S>;
        dispatchMap<E>(arg0: string, arg1: $Function_<E, S, E, S>, arg2: $Function_<S, $MapCodec<E>, S, $MapCodec<E>>): $MapCodec<E>;
        dispatchMap<E>(arg0: $Function_<E, S, E, S>, arg1: $Function_<S, $MapCodec<E>, S, $MapCodec<E>>): $MapCodec<E>;
        dispatchStable<E>(arg0: $Function_<E, S, E, S>, arg1: $Function_<S, $MapCodec<E>, S, $MapCodec<E>>): $Codec<E>;
        dispatch<E>(arg0: string, arg1: $Function_<E, S, E, S>, arg2: $Function_<S, $MapCodec<E>, S, $MapCodec<E>>): $Codec<E>;
        dispatch<E>(arg0: $Function_<E, S, E, S>, arg1: $Function_<S, $MapCodec<E>, S, $MapCodec<E>>): $Codec<E>;
        encodeStart<T>(arg0: $DynamicOps<T>, arg1: S): $DataResult<T>;
        encode<T>(arg0: S, arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
        fieldOf(arg0: string): $MapCodec<S>;
        flatComapMap<S1>(arg0: $Function_<S, S1, S, S1>, arg1: $Function_<S1, $DataResult<S>, S1, $DataResult<S>>): $Codec<S1>;
        flatComap<B>(arg0: $Function_<B, $DataResult<S>, B, $DataResult<S>>): $Encoder<B>;
        flatMap<B>(arg0: $Function_<S, $DataResult<B>, S, $DataResult<B>>): $Decoder<B>;
        flatXmap<S1>(arg0: $Function_<S, $DataResult<S1>, S, $DataResult<S1>>, arg1: $Function_<S1, $DataResult<S>, S1, $DataResult<S>>): $Codec<S1>;
        lenientOptionalFieldOf(arg0: string, arg1: S, arg2: $Lifecycle): $MapCodec<S>;
        lenientOptionalFieldOf(arg0: string, arg1: S): $MapCodec<S>;
        lenientOptionalFieldOf(arg0: string, arg1: $Lifecycle, arg2: S, arg3: $Lifecycle): $MapCodec<S>;
        lenientOptionalFieldOf(arg0: string): $MapCodec<$Optional<S>>;
        listOf(arg0: number, arg1: number): $Codec<$List<S>>;
        listOf(): $Codec<$List<S>>;
        mapResult(arg0: $Codec$ResultFunction<S>): $Codec<S>;
        map<B>(arg0: $Function_<S, B, S, B>): $Decoder<B>;
        optionalFieldOf(arg0: string, arg1: S, arg2: $Lifecycle): $MapCodec<S>;
        optionalFieldOf(arg0: string, arg1: S): $MapCodec<S>;
        optionalFieldOf(arg0: string, arg1: $Lifecycle, arg2: S, arg3: $Lifecycle): $MapCodec<S>;
        optionalFieldOf(arg0: string): $MapCodec<$Optional<S>>;
        orElseGet(arg0: $Consumer_<string, string>, arg1: $Supplier_<S, S>): $Codec<S>;
        orElseGet(arg0: $Supplier_<S, S>): $Codec<S>;
        orElseGet(arg0: $UnaryOperator_<string, string, string>, arg1: $Supplier_<S, S>): $Codec<S>;
        orElse(arg0: S): $Codec<S>;
        orElse(arg0: $Consumer_<string, string>, arg1: S): $Codec<S>;
        orElse(arg0: $UnaryOperator_<string, string, string>, arg1: S): $Codec<S>;
        parse<T>(arg0: $Dynamic<T>): $DataResult<S>;
        parse<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<S>;
        partialDispatch<E>(arg0: string, arg1: $Function_<E, $DataResult<S>, E, $DataResult<S>>, arg2: $Function_<S, $DataResult<$MapCodec<E>>, S, $DataResult<$MapCodec<E>>>): $Codec<E>;
        promotePartial(arg0: $Consumer_<string, string>): $Codec<S>;
        simple(): $Decoder$Simple<S>;
        sizeLimitedListOf(arg0: number): $Codec<$List<S>>;
        stable(): $Codec<S>;
        terminal(): $Decoder$Terminal<S>;
        validate(arg0: $Function_<S, $DataResult<S>, S, $DataResult<S>>): $Codec<S>;
        withLifecycle(arg0: $Lifecycle): $Codec<S>;
        xmap<S1>(arg0: $Function_<S, S1, S, S1>, arg1: $Function_<S1, S, S1, S>): $Codec<S1>;
    }

    export interface $TaskChainer {
        append(arg0: $Runnable_): void;
        append<T>(arg0: $CompletableFuture<T>, arg1: $Consumer_<T, T>): void;
    }
    export const $TaskChainer: {
        immediate(arg0: $Executor_<$Runnable>): $TaskChainer;
        readonly LOGGER: $Logger;
    };

    export class $Unit {
        static INSTANCE: $Unit;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Unit[];
        static valueOf(name: string): $Unit;
    }
    export interface $Unit extends $Enum<$Unit> {}

    export type $AbortableIterationConsumer_<Host0 = any, CallbackArg0 = Host0, CallbackResult = $AbortableIterationConsumer$Continuation_> = ((arg0: CallbackArg0) => CallbackResult) | ($AbortableIterationConsumer<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $AbortableIterationConsumer$Continuation_ = $AbortableIterationConsumer$Continuation | "ABORT" | "CONTINUE";
    export type $FormattedCharSequence_<CallbackArg0 = $FormattedCharSink, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($FormattedCharSequence & { readonly [Symbol.hasInstance]?: never });
    export type $FormattedCharSink_<CallbackArg0 = number, CallbackArg1 = $Style, CallbackArg2 = number, CallbackResult = boolean> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => CallbackResult) | ($FormattedCharSink & { readonly [Symbol.hasInstance]?: never });
    export type $ModCheck$Confidence_ = $ModCheck$Confidence | "DEFINITELY" | "PROBABLY_NOT" | "VERY_LIKELY";
    export type $SignatureUpdater_<CallbackArg0 = $SignatureUpdater$Output> = ((arg0: CallbackArg0) => void) | ($SignatureUpdater & { readonly [Symbol.hasInstance]?: never });
    export type $SignatureUpdater$Output_<CallbackArg0 = number[]> = ((arg0: CallbackArg0) => void) | ($SignatureUpdater$Output & { readonly [Symbol.hasInstance]?: never });
    export type $SignatureValidator_<CallbackArg0 = $SignatureUpdater, CallbackArg1 = number[], CallbackResult = boolean> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($SignatureValidator & { readonly [Symbol.hasInstance]?: never });
    export type $StaticCache2D$Initializer_<Host0 = any, CallbackArg0 = number, CallbackArg1 = number, CallbackResult = Host0> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($StaticCache2D$Initializer<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $StringRepresentable_<CallbackResult = string> = (() => CallbackResult) | ($StringRepresentable & { readonly [Symbol.hasInstance]?: never });
    export type $TaskChainer_<CallbackArg0 = $CompletableFuture<any>, CallbackArg1 = $Consumer<any>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($TaskChainer & { readonly [Symbol.hasInstance]?: never });
    export type $Unit_ = $Unit | "INSTANCE";
}
