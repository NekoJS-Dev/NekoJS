import { $GameProfile } from "java:com/mojang/authlib";
import { $PropertyMap } from "java:com/mojang/authlib/properties";
import { $Codec, $DataResult, $DynamicOps, $MapDecoder, $MapEncoder } from "java:com/mojang/serialization";
import { $ByteBuf } from "java:io/netty/buffer";
import { $IntList } from "java:it/unimi/dsi/fastutil/ints";
import { $Enum, $Record } from "java:java/lang";
import { $DecimalFormat } from "java:java/text";
import { $List, $Optional, $UUID } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $BiConsumer, $BiConsumer_, $Consumer, $Consumer_, $Predicate, $Predicate_ } from "java:java/util/function";
import { $Holder, $HolderLookup$Provider, $Holder_ } from "java:net/minecraft/core";
import { $DataComponentType } from "java:net/minecraft/core/component";
import { $CompoundTag, $CompoundTag_, $Tag } from "java:net/minecraft/nbt";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $Entity, $EquipmentSlot, $EquipmentSlotGroup, $EquipmentSlotGroup_, $EquipmentSlot_ } from "java:net/minecraft/world/entity";
import { $Attribute, $AttributeModifier, $Attribute_ } from "java:net/minecraft/world/entity/ai/attributes";
import { $Item$TooltipContext, $ItemStack, $ItemStack_, $TooltipFlag } from "java:net/minecraft/world/item";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";

declare module "java:net/minecraft/world/item/component" {
    export class $CustomData {
        static CODEC: $Codec<$CustomData>;
        static CODEC_WITH_ID: $Codec<$CustomData>;
        static EMPTY: $CustomData;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $CustomData>;
        get unsafe(): $CompoundTag;
        getUnsafe(): $CompoundTag;
        get empty(): boolean;
        isEmpty(): boolean;
        static itemMatcher(arg0: $DataComponentType<$CustomData>, arg1: $CompoundTag_): $Predicate<$ItemStack>;
        static of(arg0: $CompoundTag_): $CustomData;
        static set(arg0: $DataComponentType<$CustomData>, arg1: $ItemStack_, arg2: $CompoundTag_): void;
        static update(arg0: $DataComponentType<$CustomData>, arg1: $ItemStack_, arg2: $Consumer_<$CompoundTag, $CompoundTag>): void;
        contains(arg0: string): boolean;
        copyTag(): $CompoundTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        loadInto(arg0: $Entity): void;
        loadInto(arg0: $BlockEntity, arg1: $HolderLookup$Provider): boolean;
        matchedBy(arg0: $CompoundTag_): boolean;
        read<T>(arg0: $DynamicOps<$Tag>, arg1: $MapDecoder<T>): $DataResult<T>;
        read<T>(arg0: $MapDecoder<T>): $DataResult<T>;
        size(): number;
        toString(): string;
        update<T>(arg0: $DynamicOps<$Tag>, arg1: $MapEncoder<T>, arg2: T): $DataResult<$CustomData>;
        update(arg0: $Consumer_<$CompoundTag, $CompoundTag>): $CustomData;
    }

    export class $FireworkExplosion extends $Record implements $TooltipProvider {
        constructor(shape: $FireworkExplosion$Shape_, colors: $IntList, fadeColors: $IntList, hasTrail: boolean, hasTwinkle: boolean);
        static CODEC: $Codec<$FireworkExplosion>;
        static COLOR_LIST_CODEC: $Codec<$IntList>;
        static DEFAULT: $FireworkExplosion;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $FireworkExplosion>;
        addAdditionalTooltip(arg0: $Consumer_<$Component, $Component>): void;
        addShapeNameTooltip(arg0: $Consumer_<$Component, $Component>): void;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer_<$Component, $Component>, arg2: $TooltipFlag): void;
        colors(): $IntList;
        equals(arg0: object): boolean;
        fadeColors(): $IntList;
        hasTrail(): boolean;
        hasTwinkle(): boolean;
        hashCode(): number;
        shape(): $FireworkExplosion$Shape;
        toString(): string;
        withFadeColors(arg0: $IntList): $FireworkExplosion;
    }

    export class $FireworkExplosion$Shape {
        static BURST: $FireworkExplosion$Shape;
        static CREEPER: $FireworkExplosion$Shape;
        static LARGE_BALL: $FireworkExplosion$Shape;
        static SMALL_BALL: $FireworkExplosion$Shape;
        static STAR: $FireworkExplosion$Shape;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $FireworkExplosion$Shape[];
        static valueOf(name: string): $FireworkExplosion$Shape;
    }
    export interface $FireworkExplosion$Shape extends $Enum<$FireworkExplosion$Shape> {}

    export class $ItemAttributeModifiers extends $Record {
        constructor(arg0: $ItemAttributeModifiers$Entry[], arg1: boolean);
        static ATTRIBUTE_MODIFIER_FORMAT: $DecimalFormat;
        static CODEC: $Codec<$ItemAttributeModifiers>;
        static EMPTY: $ItemAttributeModifiers;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemAttributeModifiers>;
        static builder(): $ItemAttributeModifiers$Builder;
        compute(arg0: number, arg1: $EquipmentSlot_): number;
        equals(arg0: object): boolean;
        forEach(arg0: $EquipmentSlotGroup_, arg1: $BiConsumer_<$Holder<$Attribute>, $AttributeModifier, $Holder<$Attribute>, $AttributeModifier>): void;
        forEach(arg0: $EquipmentSlot_, arg1: $BiConsumer_<$Holder<$Attribute>, $AttributeModifier, $Holder<$Attribute>, $AttributeModifier>): void;
        hashCode(): number;
        modifiers(): $List<$ItemAttributeModifiers$Entry>;
        showInTooltip(): boolean;
        toString(): string;
        withModifierAdded(arg0: $Holder_<$Attribute>, arg1: $AttributeModifier, arg2: $EquipmentSlotGroup_): $ItemAttributeModifiers;
        withTooltip(arg0: boolean): $ItemAttributeModifiers;
    }

    export class $ItemAttributeModifiers$Builder {
        add(arg0: $Holder_<$Attribute>, arg1: $AttributeModifier, arg2: $EquipmentSlotGroup_): $ItemAttributeModifiers$Builder;
        build(): $ItemAttributeModifiers;
    }

    export class $ItemAttributeModifiers$Entry extends $Record {
        constructor(arg0: $Holder_<$Attribute>, arg1: $AttributeModifier, arg2: $EquipmentSlotGroup_);
        static CODEC: $Codec<$ItemAttributeModifiers$Entry>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemAttributeModifiers$Entry>;
        attribute(): $Holder<$Attribute>;
        equals(arg0: object): boolean;
        hashCode(): number;
        matches(arg0: $Holder_<$Attribute>, arg1: $ResourceLocation_): boolean;
        modifier(): $AttributeModifier;
        slot(): $EquipmentSlotGroup;
        toString(): string;
    }

    export class $ItemLore extends $Record implements $TooltipProvider {
        constructor(arg0: $Component_[]);
        constructor(arg0: $Component_[], arg1: $Component_[]);
        static CODEC: $Codec<$ItemLore>;
        static EMPTY: $ItemLore;
        static MAX_LINES: number;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ItemLore>;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer_<$Component, $Component>, arg2: $TooltipFlag): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        lines(): $List<$Component>;
        styledLines(): $List<$Component>;
        toString(): string;
        withLineAdded(arg0: $Component_): $ItemLore;
    }

    export class $ResolvableProfile extends $Record {
        constructor(arg0: $GameProfile);
        constructor(arg0: $Optional<string>, arg1: $Optional<$UUID>, arg2: $PropertyMap);
        constructor(arg0: $Optional<string>, arg1: $Optional<$UUID>, arg2: $PropertyMap, arg3: $GameProfile);
        static CODEC: $Codec<$ResolvableProfile>;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ResolvableProfile>;
        get resolved(): boolean;
        isResolved(): boolean;
        equals(arg0: object): boolean;
        gameProfile(): $GameProfile;
        hashCode(): number;
        id(): $Optional<$UUID>;
        name(): $Optional<string>;
        properties(): $PropertyMap;
        resolve(): $CompletableFuture<$ResolvableProfile>;
        toString(): string;
    }

    export interface $TooltipProvider {
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer_<$Component, $Component>, arg2: $TooltipFlag): void;
    }

    export class $Fireworks extends $Record implements $TooltipProvider {
        constructor(arg0: number, arg1: $FireworkExplosion[]);
        static CODEC: $Codec<$Fireworks>;
        static MAX_EXPLOSIONS: number;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $Fireworks>;
        addToTooltip(arg0: $Item$TooltipContext, arg1: $Consumer_<$Component, $Component>, arg2: $TooltipFlag): void;
        equals(arg0: object): boolean;
        explosions(): $List<$FireworkExplosion>;
        flightDuration(): number;
        hashCode(): number;
        toString(): string;
    }

    export type $FireworkExplosion$Shape_ = $FireworkExplosion$Shape | "BURST" | "CREEPER" | "LARGE_BALL" | "SMALL_BALL" | "STAR";
    export type $TooltipProvider_<CallbackArg0 = $Item$TooltipContext, CallbackArg1 = $Consumer<$Component>, CallbackArg2 = $TooltipFlag> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void) | ($TooltipProvider & { readonly [Symbol.hasInstance]?: never });
    export type $Fireworks_ = $Fireworks | { [key: string]: any } | $Fireworks_[] | string;
}
