const Character = Java.type('java.lang.Character');
const CharMatcher = Java.type('com.google.common.base.CharMatcher');
const Int2CharOpenHashMap = Java.type('it.unimi.dsi.fastutil.ints.Int2CharOpenHashMap');
const Object2CharOpenHashMap = Java.type('it.unimi.dsi.fastutil.objects.Object2CharOpenHashMap');
function expect(value, expected, label) {
    if (value !== expected) throw new Error('Character value mismatch: ' + label);
}
expect(typeof Character.valueOf('a'), 'string', 'boxed return type');
expect(Character.valueOf('a'), 'a', 'boxed return');
const matcher = CharMatcher.is('a');
expect(matcher.matches('a'), true, 'primitive char input');
expect(matcher.test('a'), true, 'generic char predicate');
const ints = new Int2CharOpenHashMap();
ints.put(1, 'a');
expect(ints.get(1), 'a', 'primitive char map result');
expect(ints.apply(1), 'a', 'boxed generic map result');
const objects = new Object2CharOpenHashMap();
objects.put('key', 'a');
expect(objects.getChar('key'), 'a', 'object map char result');
expect(objects.apply('key'), 'a', 'object map generic result');
console.info('OWNED-CHARACTER-VALUES-PASS');
