export * as collect from "java:com/google/common/collect";
export * as reflect from "java:com/google/common/reflect";

