// NekoJS Probe Type Declarations

export * as com from "java:com";
export * as java from "java:java";
export * as net from "java:net";
export * as org from "java:org";
export * as it from "java:it";
export * as graal from "java:graal";
export * as javax from "java:javax";
export * as io from "java:io";
