import { $EventLoopTaskQueueFactory, $EventLoopTaskQueueFactory_, $MultithreadEventLoopGroup, $SelectStrategy, $SelectStrategyFactory, $SelectStrategyFactory_, $SelectStrategy_ } from "java:io/netty/channel";
import { $IntSupplier, $IntSupplier_ } from "java:io/netty/util";
import { $EventExecutor, $EventExecutorChooserFactory, $EventExecutorChooserFactory$EventExecutorChooser, $EventExecutorChooserFactory$EventExecutorChooser_, $EventExecutorChooserFactory_, $RejectedExecutionHandler, $RejectedExecutionHandler_, $SingleThreadEventExecutor } from "java:io/netty/util/concurrent";
import { $Runnable, $Runnable_, $Thread } from "java:java/lang";
import { $Queue, $Spliterator } from "java:java/util";
import { $Executor, $Executor_, $ThreadFactory, $ThreadFactory_ } from "java:java/util/concurrent";
import { $Consumer, $Consumer_ } from "java:java/util/function";

declare module "java:io/netty/channel/epoll" {
    export class $EpollEventLoopGroup extends $MultithreadEventLoopGroup {
        constructor();
        constructor(arg0: number);
        constructor(arg0: number, arg1: $SelectStrategyFactory_<$SelectStrategy_<$IntSupplier, boolean, number>>);
        constructor(arg0: number, arg1: $Executor_<$Runnable>);
        constructor(arg0: number, arg1: $Executor_<$Runnable>, arg2: $SelectStrategyFactory_<$SelectStrategy_<$IntSupplier, boolean, number>>);
        constructor(arg0: number, arg1: $Executor_<$Runnable>, arg2: $EventExecutorChooserFactory_<$EventExecutor[], $EventExecutorChooserFactory$EventExecutorChooser_<$EventExecutor>>, arg3: $SelectStrategyFactory_<$SelectStrategy_<$IntSupplier, boolean, number>>);
        constructor(arg0: number, arg1: $Executor_<$Runnable>, arg2: $EventExecutorChooserFactory_<$EventExecutor[], $EventExecutorChooserFactory$EventExecutorChooser_<$EventExecutor>>, arg3: $SelectStrategyFactory_<$SelectStrategy_<$IntSupplier, boolean, number>>, arg4: $RejectedExecutionHandler_<$Runnable, $SingleThreadEventExecutor>);
        constructor(arg0: number, arg1: $Executor_<$Runnable>, arg2: $EventExecutorChooserFactory_<$EventExecutor[], $EventExecutorChooserFactory$EventExecutorChooser_<$EventExecutor>>, arg3: $SelectStrategyFactory_<$SelectStrategy_<$IntSupplier, boolean, number>>, arg4: $RejectedExecutionHandler_<$Runnable, $SingleThreadEventExecutor>, arg5: $EventLoopTaskQueueFactory_<number, $Queue<$Runnable>>);
        constructor(arg0: number, arg1: $Executor_<$Runnable>, arg2: $EventExecutorChooserFactory_<$EventExecutor[], $EventExecutorChooserFactory$EventExecutorChooser_<$EventExecutor>>, arg3: $SelectStrategyFactory_<$SelectStrategy_<$IntSupplier, boolean, number>>, arg4: $RejectedExecutionHandler_<$Runnable, $SingleThreadEventExecutor>, arg5: $EventLoopTaskQueueFactory_<number, $Queue<$Runnable>>, arg6: $EventLoopTaskQueueFactory_<number, $Queue<$Runnable>>);
        constructor(arg0: number, arg1: $ThreadFactory_<$Runnable, $Thread>);
        constructor(arg0: number, arg1: $ThreadFactory_<$Runnable, $Thread>, arg2: number);
        constructor(arg0: number, arg1: $ThreadFactory_<$Runnable, $Thread>, arg2: number, arg3: $SelectStrategyFactory_<$SelectStrategy_<$IntSupplier, boolean, number>>);
        constructor(arg0: number, arg1: $ThreadFactory_<$Runnable, $Thread>, arg2: $SelectStrategyFactory_<$SelectStrategy_<$IntSupplier, boolean, number>>);
        constructor(arg0: $ThreadFactory_<$Runnable, $Thread>);
        close(): void;
        forEach(arg0: $Consumer_<$EventExecutor, $EventExecutor>): void;
        setIoRatio(arg0: number): void;
        spliterator(): $Spliterator<$EventExecutor>;
    }

}
