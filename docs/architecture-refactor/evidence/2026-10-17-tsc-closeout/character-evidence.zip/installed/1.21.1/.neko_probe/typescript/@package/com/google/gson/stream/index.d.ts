import { $Closeable, $Closeable_, $Flushable, $Flushable_, $Reader, $Writer } from "java:java/io";
import { $Enum } from "java:java/lang";

declare module "java:com/google/gson/stream" {
    export class $JsonReader implements $Closeable {
        constructor(arg0: $Reader);
        get path(): string;
        getPath(): string;
        get previousPath(): string;
        getPreviousPath(): string;
        get lenient(): boolean;
        isLenient(): boolean;
        set lenient(value: boolean);
        beginArray(): void;
        beginObject(): void;
        close(): void;
        endArray(): void;
        endObject(): void;
        hasNext(): boolean;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextInt(): number;
        nextLong(): number;
        nextName(): string;
        nextNull(): void;
        nextString(): string;
        peek(): $JsonToken;
        setLenient(arg0: boolean): void;
        skipValue(): void;
        toString(): string;
    }

    export class $JsonWriter implements $Closeable, $Flushable {
        constructor(arg0: $Writer);
        get serializeNulls(): boolean;
        getSerializeNulls(): boolean;
        set serializeNulls(value: boolean);
        get htmlSafe(): boolean;
        isHtmlSafe(): boolean;
        set htmlSafe(value: boolean);
        get lenient(): boolean;
        isLenient(): boolean;
        set lenient(value: boolean);
        beginArray(): $JsonWriter;
        beginObject(): $JsonWriter;
        close(): void;
        endArray(): $JsonWriter;
        endObject(): $JsonWriter;
        flush(): void;
        jsonValue(arg0: string): $JsonWriter;
        name(arg0: string): $JsonWriter;
        nullValue(): $JsonWriter;
        setHtmlSafe(arg0: boolean): void;
        setIndent(arg0: string): void;
        setLenient(arg0: boolean): void;
        setSerializeNulls(arg0: boolean): void;
        value(arg0: boolean): $JsonWriter;
        value(arg0: number): $JsonWriter;
        value(arg0: number): $JsonWriter;
        value(arg0: boolean): $JsonWriter;
        value(arg0: number): $JsonWriter;
        value(arg0: string): $JsonWriter;
        value(arg0: number): $JsonWriter;
    }

    export class $JsonToken {
        static BEGIN_ARRAY: $JsonToken;
        static BEGIN_OBJECT: $JsonToken;
        static BOOLEAN: $JsonToken;
        static END_ARRAY: $JsonToken;
        static END_DOCUMENT: $JsonToken;
        static END_OBJECT: $JsonToken;
        static NAME: $JsonToken;
        static NULL: $JsonToken;
        static NUMBER: $JsonToken;
        static STRING: $JsonToken;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $JsonToken[];
        static valueOf(name: string): $JsonToken;
    }
    export interface $JsonToken extends $Enum<$JsonToken> {}

    export type $JsonToken_ = $JsonToken | "BEGIN_ARRAY" | "BEGIN_OBJECT" | "BOOLEAN" | "END_ARRAY" | "END_DOCUMENT" | "END_OBJECT" | "NAME" | "NULL" | "NUMBER" | "STRING";
}
