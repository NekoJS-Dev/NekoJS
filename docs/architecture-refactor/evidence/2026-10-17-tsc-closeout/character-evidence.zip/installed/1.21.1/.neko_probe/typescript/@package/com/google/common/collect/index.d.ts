import { $Serializable } from "java:java/io";
import { $Comparable, $Comparable_, $Iterable } from "java:java/lang";
import { $AbstractCollection, $Collection, $Comparator, $Comparator_, $Iterator, $List, $ListIterator, $Map, $Map$Entry, $RandomAccess, $Set, $Spliterator } from "java:java/util";
import { $BiConsumer, $BiConsumer_, $Consumer, $Consumer_, $IntFunction, $IntFunction_, $ObjIntConsumer, $ObjIntConsumer_, $Predicate, $Predicate_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Collector, $Stream } from "java:java/util/stream";

declare module "java:com/google/common/collect" {
    export class $ForwardingMultimap<K, V> extends $ForwardingObject implements $Multimap<K, V> {
        get empty(): boolean;
        isEmpty(): boolean;
        asMap(): $Map<K, $Collection<V>>;
        clear(): void;
        containsEntry(key: object, value: object): boolean;
        containsKey(key: object): boolean;
        containsValue(value: object): boolean;
        entries(): $Collection<$Map$Entry<K, V>>;
        equals(object: object): boolean;
        forEach(action: $BiConsumer_<K, V, K, V>): void;
        get(key: K): $Collection<V>;
        hashCode(): number;
        keySet(): $Set<K>;
        keys(): $Multiset<K>;
        putAll(key: K, values: $Iterable<V>): boolean;
        putAll(multimap: $Multimap<K, V>): boolean;
        put(key: K, value: V): boolean;
        removeAll(key: object): $Collection<V>;
        remove(key: object, value: object): boolean;
        replaceValues(key: K, values: $Iterable<V>): $Collection<V>;
        size(): number;
        values(): $Collection<V>;
    }

    export class $ForwardingObject {
        toString(): string;
    }

    export interface $Multimap<K, V> {
        asMap(): $Map<K, $Collection<V>>;
        clear(): void;
        containsEntry(key: object, value: object): boolean;
        containsKey(key: object): boolean;
        containsValue(value: object): boolean;
        entries(): $Collection<$Map$Entry<K, V>>;
        equals(obj: object): boolean;
        forEach(action: $BiConsumer_<K, V, K, V>): void;
        get(key: K): $Collection<V>;
        hashCode(): number;
        isEmpty(): boolean;
        keySet(): $Set<K>;
        keys(): $Multiset<K>;
        putAll(key: K, values: $Iterable<V>): boolean;
        putAll(multimap: $Multimap<K, V>): boolean;
        put(key: K, value: V): boolean;
        removeAll(key: object): $Collection<V>;
        remove(key: object, value: object): boolean;
        replaceValues(key: K, values: $Iterable<V>): $Collection<V>;
        size(): number;
        values(): $Collection<V>;
    }

    export interface $Multiset<E> extends $Collection<E> {
        add(element: E, occurrences: number): number;
        add(element: E): boolean;
        containsAll(elements: any[]): boolean;
        contains(element: object): boolean;
        count(element: object): number;
        elementSet(): $Set<E>;
        entrySet(): $Set<$Multiset$Entry<E>>;
        equals(object: object): boolean;
        forEachEntry(action: $ObjIntConsumer_<E, E, number>): void;
        forEach(action: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $Iterator<E>;
        removeAll(c: any[]): boolean;
        remove(element: object, occurrences: number): number;
        remove(element: object): boolean;
        retainAll(c: any[]): boolean;
        setCount(element: E, oldCount: number, newCount: number): boolean;
        setCount(element: E, count: number): number;
        size(): number;
        spliterator(): $Spliterator<E>;
        toString(): string;
    }

    export interface $Multiset$Entry<E> {
        equals(o: object): boolean;
        getCount(): number;
        getElement(): E;
        hashCode(): number;
        toString(): string;
    }

    export class $ImmutableList<E> extends $ImmutableCollection<E> implements $List<E>, $RandomAccess {
        get first(): E;
        getFirst(): E;
        get last(): E;
        getLast(): E;
        get empty(): boolean;
        isEmpty(): boolean;
        static builderWithExpectedSize<E>(expectedSize: number): $ImmutableList$Builder<E>;
        static builder<E>(): $ImmutableList$Builder<E>;
        static copyOf<E>(elements: E[]): $ImmutableList<E>;
        static copyOf<E>(elements: $Iterable<E>): $ImmutableList<E>;
        static copyOf<E>(elements: E[]): $ImmutableList<E>;
        static copyOf<E>(elements: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E, e9: E, e10: E, e11: E, e12: E, others?: E[]): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E, e9: E, e10: E, e11: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E, e9: E, e10: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E, e9: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E, e8: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, e7: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E, e3: E): $ImmutableList<E>;
        static of<E>(e1: E, e2: E): $ImmutableList<E>;
        static of<E>(element: E): $ImmutableList<E>;
        static of<E>(): $ImmutableList<E>;
        static sortedCopyOf<E extends $Comparable<any>>(elements: $Iterable<E>): $ImmutableList<E>;
        static sortedCopyOf<E>(comparator: $Comparator_<E, E, E, number>, elements: $Iterable<E>): $ImmutableList<E>;
        static toImmutableList<E>(): $Collector<E, any, $ImmutableList<E>>;
        addAll(index: number, newElements: E[]): boolean;
        addAll(newElements: E[]): boolean;
        addFirst(arg0: E): void;
        addLast(arg0: E): void;
        add(e: E): boolean;
        add(index: number, element: E): void;
        asList(): $ImmutableList<E>;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(object: object): boolean;
        equals(obj: object): boolean;
        forEach(consumer: $Consumer_<E, E>): void;
        get(arg0: number): E;
        hashCode(): number;
        indexOf(object: object): number;
        iterator(): $UnmodifiableIterator<E>;
        lastIndexOf(object: object): number;
        listIterator(index: number): $UnmodifiableListIterator<E>;
        listIterator(): $UnmodifiableListIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(oldElements: any[]): boolean;
        removeFirst(): E;
        removeIf(filter: $Predicate_<E, E, boolean>): boolean;
        removeLast(): E;
        remove(index: number): E;
        remove(object: object): boolean;
        replaceAll(operator: $UnaryOperator_<E, E, E>): void;
        retainAll(elementsToKeep: any[]): boolean;
        reversed(): $List<E>;
        reverse(): $ImmutableList<E>;
        set(index: number, element: E): E;
        size(): number;
        sort(c: $Comparator_<E, E, E, number>): void;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        subList(fromIndex: number, toIndex: number): $ImmutableList<E>;
        toArray<T>(other: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export class $ImmutableCollection<E> extends $AbstractCollection<E> implements $Serializable {
        addAll(newElements: E[]): boolean;
        add(e: E): boolean;
        asList(): $ImmutableList<E>;
        clear(): void;
        contains(object: object): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $UnmodifiableIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(oldElements: any[]): boolean;
        removeIf(filter: $Predicate_<E, E, boolean>): boolean;
        remove(object: object): boolean;
        retainAll(elementsToKeep: any[]): boolean;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(other: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export class $ImmutableList$Builder<E> extends $ImmutableCollection$Builder<E> {
        constructor();
        addAll(elements: $Iterable<E>): $ImmutableList$Builder<E>;
        addAll(elements: E): $ImmutableList$Builder<E>;
        add(elements?: E[]): $ImmutableList$Builder<E>;
        add(element: E): $ImmutableList$Builder<E>;
        build(): $ImmutableList<E>;
    }

    export class $UnmodifiableIterator<E> implements $Iterator<E> {
        forEachRemaining(arg0: $Consumer_<E, E>): void;
        hasNext(): boolean;
        next(): E;
        remove(): void;
    }

    export class $UnmodifiableListIterator<E> extends $UnmodifiableIterator<E> implements $ListIterator<E> {
        add(e: E): void;
        forEachRemaining(arg0: $Consumer_<E, E>): void;
        hasNext(): boolean;
        hasPrevious(): boolean;
        nextIndex(): number;
        next(): E;
        previousIndex(): number;
        previous(): E;
        remove(): void;
        set(e: E): void;
    }

    export class $ImmutableCollection$Builder<E> {
        addAll(elements: $Iterable<E>): $ImmutableCollection$Builder<E>;
        addAll(elements: E): $ImmutableCollection$Builder<E>;
        add(elements?: E[]): $ImmutableCollection$Builder<E>;
        add(element: E): $ImmutableCollection$Builder<E>;
        build(): $ImmutableCollection<E>;
    }

    export class $ForwardingSet<E> extends $ForwardingCollection<E> implements $Set<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(collection: E[]): boolean;
        add(element: E): boolean;
        clear(): void;
        containsAll(collection: any[]): boolean;
        contains(object: object): boolean;
        equals(object: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(collection: any[]): boolean;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        remove(object: object): boolean;
        retainAll(collection: any[]): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(array: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export class $ForwardingCollection<E> extends $ForwardingObject implements $Collection<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        addAll(collection: E[]): boolean;
        add(element: E): boolean;
        clear(): void;
        containsAll(collection: any[]): boolean;
        contains(object: object): boolean;
        equals(arg0: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $Iterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(collection: any[]): boolean;
        removeIf(arg0: $Predicate_<E, E, boolean>): boolean;
        remove(object: object): boolean;
        retainAll(collection: any[]): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(array: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export class $ImmutableSet<E> extends $ImmutableCollection<E> implements $Set<E> {
        get empty(): boolean;
        isEmpty(): boolean;
        static builderWithExpectedSize<E>(expectedSize: number): $ImmutableSet$Builder<E>;
        static builder<E>(): $ImmutableSet$Builder<E>;
        static copyOf<E>(elements: E[]): $ImmutableSet<E>;
        static copyOf<E>(elements: $Iterable<E>): $ImmutableSet<E>;
        static copyOf<E>(elements: E[]): $ImmutableSet<E>;
        static copyOf<E>(elements: E): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E, e6: E, others?: E[]): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E, e5: E): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E, e3: E, e4: E): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E, e3: E): $ImmutableSet<E>;
        static of<E>(e1: E, e2: E): $ImmutableSet<E>;
        static of<E>(element: E): $ImmutableSet<E>;
        static of<E>(): $ImmutableSet<E>;
        static toImmutableSet<E>(): $Collector<E, any, $ImmutableSet<E>>;
        addAll(newElements: E[]): boolean;
        add(e: E): boolean;
        clear(): void;
        containsAll(arg0: any[]): boolean;
        contains(object: object): boolean;
        equals(object: object): boolean;
        forEach(arg0: $Consumer_<E, E>): void;
        hashCode(): number;
        iterator(): $UnmodifiableIterator<E>;
        parallelStream(): $Stream<E>;
        removeAll(oldElements: any[]): boolean;
        removeIf(filter: $Predicate_<E, E, boolean>): boolean;
        remove(object: object): boolean;
        retainAll(elementsToKeep: any[]): boolean;
        size(): number;
        spliterator(): $Spliterator<E>;
        stream(): $Stream<E>;
        toArray<T>(other: T[]): T[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): object[];
    }

    export class $ImmutableSet$Builder<E> extends $ImmutableCollection$Builder<E> {
        constructor();
        addAll(elements: $Iterable<E>): $ImmutableSet$Builder<E>;
        addAll(elements: E): $ImmutableSet$Builder<E>;
        add(elements?: E[]): $ImmutableSet$Builder<E>;
        add(element: E): $ImmutableSet$Builder<E>;
        build(): $ImmutableSet<E>;
    }

    export interface $Interner<E> {
        intern(sample: E): E;
    }

    export type $Interner_<Host0 = any, CallbackArg0 = Host0, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Interner<Host0> & { readonly [Symbol.hasInstance]?: never });
}
