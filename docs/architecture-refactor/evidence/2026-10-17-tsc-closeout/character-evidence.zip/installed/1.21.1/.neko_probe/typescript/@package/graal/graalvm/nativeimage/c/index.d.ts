export * as type from "java:graal/graalvm/nativeimage/c/type";

