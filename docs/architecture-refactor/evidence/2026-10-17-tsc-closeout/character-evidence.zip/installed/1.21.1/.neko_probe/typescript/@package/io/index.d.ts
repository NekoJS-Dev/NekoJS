export * as netty from "java:io/netty";

