export * as polyglot from "java:graal/graalvm/polyglot";
export * as nativeimage from "java:graal/graalvm/nativeimage";
export * as options from "java:graal/graalvm/options";
export * as word from "java:graal/graalvm/word";

