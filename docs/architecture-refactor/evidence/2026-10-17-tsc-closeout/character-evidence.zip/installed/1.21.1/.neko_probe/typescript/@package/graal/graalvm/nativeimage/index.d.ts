export * as c from "java:graal/graalvm/nativeimage/c";

