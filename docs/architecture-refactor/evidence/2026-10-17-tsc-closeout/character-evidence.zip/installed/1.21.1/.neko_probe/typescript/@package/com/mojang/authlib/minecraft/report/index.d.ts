import { $Record } from "java:java/lang";
import { $ByteBuffer } from "java:java/nio";
import { $Instant } from "java:java/time";
import { $List, $UUID } from "java:java/util";

declare module "java:com/mojang/authlib/minecraft/report" {
    export class $AbuseReportLimits extends $Record {
        constructor(maxOpinionCommentsLength: number, maxReportedMessageCount: number, maxEvidenceMessageCount: number, leadingContextMessageCount: number, trailingContextMessageCount: number);
        static DEFAULTS: $AbuseReportLimits;
        equals(arg0: object): boolean;
        hashCode(): number;
        leadingContextMessageCount(): number;
        maxEvidenceMessageCount(): number;
        maxOpinionCommentsLength(): number;
        maxReportedMessageCount(): number;
        toString(): string;
        trailingContextMessageCount(): number;
    }

    export class $AbuseReport extends $Record {
        constructor(opinionComments: string, reason: string, evidence: $ReportEvidence, skinUrl: string, reportedEntity: $ReportedEntity, createdTime: $Instant);
        static chat(arg0: string, arg1: string, arg2: $ReportEvidence, arg3: $ReportedEntity, arg4: $Instant): $AbuseReport;
        static name(arg0: string, arg1: $ReportedEntity, arg2: $Instant): $AbuseReport;
        static skin(arg0: string, arg1: string, arg2: string, arg3: $ReportedEntity, arg4: $Instant): $AbuseReport;
        createdTime(): $Instant;
        equals(arg0: object): boolean;
        evidence(): $ReportEvidence;
        hashCode(): number;
        opinionComments(): string;
        reason(): string;
        reportedEntity(): $ReportedEntity;
        skinUrl(): string;
        toString(): string;
    }

    export class $ReportEvidence extends $Record {
        constructor(messages: $ReportChatMessage[]);
        equals(arg0: object): boolean;
        hashCode(): number;
        messages(): $List<$ReportChatMessage>;
        toString(): string;
    }

    export class $ReportedEntity extends $Record {
        constructor(profileId: $UUID);
        equals(arg0: object): boolean;
        hashCode(): number;
        profileId(): $UUID;
        toString(): string;
    }

    export class $ReportChatMessage extends $Record {
        constructor(index: number, profileId: $UUID, sessionId: $UUID, timestamp: $Instant, salt: number, lastSeen: $ByteBuffer[], message: string, signature: $ByteBuffer, messageReported: boolean);
        equals(arg0: object): boolean;
        hashCode(): number;
        index(): number;
        lastSeen(): $List<$ByteBuffer>;
        messageReported(): boolean;
        message(): string;
        profileId(): $UUID;
        salt(): number;
        sessionId(): $UUID;
        signature(): $ByteBuffer;
        timestamp(): $Instant;
        toString(): string;
    }

}
