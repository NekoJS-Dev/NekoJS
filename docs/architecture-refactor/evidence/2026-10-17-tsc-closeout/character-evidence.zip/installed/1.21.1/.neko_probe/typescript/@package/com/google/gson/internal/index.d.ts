import { $ExclusionStrategy, $Gson, $TypeAdapter, $TypeAdapterFactory, $TypeAdapterFactory_ } from "java:com/google/gson";
import { $TypeToken } from "java:com/google/gson/reflect";
import { $Class, $Cloneable } from "java:java/lang";
import { $Field } from "java:java/lang/reflect";

declare module "java:com/google/gson/internal" {
    export class $Excluder implements $TypeAdapterFactory, $Cloneable {
        constructor();
        static DEFAULT: $Excluder;
        create<T>(arg0: $Gson, arg1: $TypeToken<T>): $TypeAdapter<T>;
        disableInnerClassSerialization(): $Excluder;
        excludeClass(arg0: $Class<any>, arg1: boolean): boolean;
        excludeFieldsWithoutExposeAnnotation(): $Excluder;
        excludeField(arg0: $Field, arg1: boolean): boolean;
        withExclusionStrategy(arg0: $ExclusionStrategy, arg1: boolean, arg2: boolean): $Excluder;
        withModifiers(arg0?: number[]): $Excluder;
        withVersion(arg0: number): $Excluder;
    }

}
