export * as gson from "java:com/google/gson";
export * as common from "java:com/google/common";

