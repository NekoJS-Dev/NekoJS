export * as api from "java:graal/mod/api";

