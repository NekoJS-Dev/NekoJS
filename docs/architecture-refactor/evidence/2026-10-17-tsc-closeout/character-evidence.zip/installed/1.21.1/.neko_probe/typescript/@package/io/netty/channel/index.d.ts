import { $ByteBuf, $ByteBufAllocator } from "java:io/netty/buffer";
import { $AbstractConstant, $Attribute, $AttributeKey, $AttributeMap, $IntSupplier, $IntSupplier_ } from "java:io/netty/util";
import { $EventExecutor, $EventExecutorGroup, $Future as $NekoImport$Future, $GenericFutureListener, $GenericFutureListener_, $MultithreadEventExecutorGroup, $OrderedEventExecutor, $ProgressiveFuture, $ProgressivePromise, $Promise, $ScheduledFuture } from "java:io/netty/util/concurrent";
import { $Serializable } from "java:java/io";
import { $Class, $Comparable, $Comparable_, $Iterable, $Runnable, $Runnable_, $Thread, $Throwable } from "java:java/lang";
import { $InetAddress, $NetworkInterface, $SocketAddress } from "java:java/net";
import { $ByteBuffer } from "java:java/nio";
import { $Collection, $Iterator, $List, $Map, $Map$Entry, $Queue, $Spliterator } from "java:java/util";
import { $Callable, $Callable_, $Executor, $Executor_, $Future as $NekoImport$Future1, $ThreadFactory, $ThreadFactory_, $TimeUnit, $TimeUnit_ } from "java:java/util/concurrent";
import { $Consumer, $Consumer_ } from "java:java/util/function";

export * as epoll from "java:io/netty/channel/epoll";
export * as nio from "java:io/netty/channel/nio";

declare module "java:io/netty/channel" {
    export interface $Channel extends $AttributeMap, $ChannelOutboundInvoker, $Comparable<$Channel> {
        alloc(): $ByteBufAllocator;
        bytesBeforeUnwritable(): number;
        bytesBeforeWritable(): number;
        closeFuture(): $ChannelFuture;
        config(): $ChannelConfig;
        eventLoop(): $EventLoop;
        flush(): $Channel;
        flush(): $ChannelOutboundInvoker;
        id(): $ChannelId;
        isActive(): boolean;
        isOpen(): boolean;
        isRegistered(): boolean;
        isWritable(): boolean;
        localAddress(): $SocketAddress;
        metadata(): $ChannelMetadata;
        parent(): $Channel;
        pipeline(): $ChannelPipeline;
        read(): $Channel;
        read(): $ChannelOutboundInvoker;
        remoteAddress(): $SocketAddress;
        unsafe(): $Channel$Unsafe;
    }

    export interface $ChannelFuture extends $NekoImport$Future<void> {
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelFuture;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $NekoImport$Future<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelFuture;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $NekoImport$Future<void>;
        awaitUninterruptibly(arg0: number, arg1: $TimeUnit_): boolean;
        awaitUninterruptibly(arg0: number): boolean;
        awaitUninterruptibly(): $ChannelFuture;
        awaitUninterruptibly(): $NekoImport$Future<void>;
        await(arg0: number, arg1: $TimeUnit_): boolean;
        await(arg0: number): boolean;
        await(): $ChannelFuture;
        await(): $NekoImport$Future<void>;
        channel(): $Channel;
        isVoid(): boolean;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelFuture;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $NekoImport$Future<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelFuture;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $NekoImport$Future<void>;
        syncUninterruptibly(): $ChannelFuture;
        syncUninterruptibly(): $NekoImport$Future<void>;
        sync(): $ChannelFuture;
        sync(): $NekoImport$Future<void>;
    }

    export interface $ChannelHandlerContext extends $AttributeMap, $ChannelInboundInvoker, $ChannelOutboundInvoker {
        alloc(): $ByteBufAllocator;
        attr<T>(arg0: $AttributeKey<T>): $Attribute<T>;
        channel(): $Channel;
        executor(): $EventExecutor;
        fireChannelActive(): $ChannelHandlerContext;
        fireChannelActive(): $ChannelInboundInvoker;
        fireChannelInactive(): $ChannelHandlerContext;
        fireChannelInactive(): $ChannelInboundInvoker;
        fireChannelReadComplete(): $ChannelHandlerContext;
        fireChannelReadComplete(): $ChannelInboundInvoker;
        fireChannelRead(arg0: object): $ChannelHandlerContext;
        fireChannelRead(arg0: object): $ChannelInboundInvoker;
        fireChannelRegistered(): $ChannelHandlerContext;
        fireChannelRegistered(): $ChannelInboundInvoker;
        fireChannelUnregistered(): $ChannelHandlerContext;
        fireChannelUnregistered(): $ChannelInboundInvoker;
        fireChannelWritabilityChanged(): $ChannelHandlerContext;
        fireChannelWritabilityChanged(): $ChannelInboundInvoker;
        fireExceptionCaught(arg0: $Throwable): $ChannelHandlerContext;
        fireExceptionCaught(arg0: $Throwable): $ChannelInboundInvoker;
        fireUserEventTriggered(arg0: object): $ChannelHandlerContext;
        fireUserEventTriggered(arg0: object): $ChannelInboundInvoker;
        flush(): $ChannelHandlerContext;
        flush(): $ChannelOutboundInvoker;
        handler(): $ChannelHandler;
        hasAttr<T>(arg0: $AttributeKey<T>): boolean;
        isRemoved(): boolean;
        name(): string;
        pipeline(): $ChannelPipeline;
        read(): $ChannelHandlerContext;
        read(): $ChannelOutboundInvoker;
    }

    export interface $ChannelPipeline extends $ChannelInboundInvoker, $ChannelOutboundInvoker, $Iterable<$Map$Entry<string, $ChannelHandler>> {
        addAfter(arg0: $EventExecutorGroup, arg1: string, arg2: string, arg3: $ChannelHandler): $ChannelPipeline;
        addAfter(arg0: string, arg1: string, arg2: $ChannelHandler): $ChannelPipeline;
        addBefore(arg0: $EventExecutorGroup, arg1: string, arg2: string, arg3: $ChannelHandler): $ChannelPipeline;
        addBefore(arg0: string, arg1: string, arg2: $ChannelHandler): $ChannelPipeline;
        addFirst(arg0?: $ChannelHandler[]): $ChannelPipeline;
        addFirst(arg0: $EventExecutorGroup, arg1?: $ChannelHandler[]): $ChannelPipeline;
        addFirst(arg0: $EventExecutorGroup, arg1: string, arg2: $ChannelHandler): $ChannelPipeline;
        addFirst(arg0: string, arg1: $ChannelHandler): $ChannelPipeline;
        addLast(arg0?: $ChannelHandler[]): $ChannelPipeline;
        addLast(arg0: $EventExecutorGroup, arg1?: $ChannelHandler[]): $ChannelPipeline;
        addLast(arg0: $EventExecutorGroup, arg1: string, arg2: $ChannelHandler): $ChannelPipeline;
        addLast(arg0: string, arg1: $ChannelHandler): $ChannelPipeline;
        channel(): $Channel;
        context(arg0: $ChannelHandler): $ChannelHandlerContext;
        context(arg0: $Class<$ChannelHandler>): $ChannelHandlerContext;
        context(arg0: string): $ChannelHandlerContext;
        fireChannelActive(): $ChannelInboundInvoker;
        fireChannelActive(): $ChannelPipeline;
        fireChannelInactive(): $ChannelInboundInvoker;
        fireChannelInactive(): $ChannelPipeline;
        fireChannelReadComplete(): $ChannelInboundInvoker;
        fireChannelReadComplete(): $ChannelPipeline;
        fireChannelRead(arg0: object): $ChannelInboundInvoker;
        fireChannelRead(arg0: object): $ChannelPipeline;
        fireChannelRegistered(): $ChannelInboundInvoker;
        fireChannelRegistered(): $ChannelPipeline;
        fireChannelUnregistered(): $ChannelInboundInvoker;
        fireChannelUnregistered(): $ChannelPipeline;
        fireChannelWritabilityChanged(): $ChannelInboundInvoker;
        fireChannelWritabilityChanged(): $ChannelPipeline;
        fireExceptionCaught(arg0: $Throwable): $ChannelInboundInvoker;
        fireExceptionCaught(arg0: $Throwable): $ChannelPipeline;
        fireUserEventTriggered(arg0: object): $ChannelInboundInvoker;
        fireUserEventTriggered(arg0: object): $ChannelPipeline;
        firstContext(): $ChannelHandlerContext;
        first(): $ChannelHandler;
        flush(): $ChannelOutboundInvoker;
        flush(): $ChannelPipeline;
        get<T extends $ChannelHandler>(arg0: $Class<T>): T;
        get(arg0: string): $ChannelHandler;
        lastContext(): $ChannelHandlerContext;
        last(): $ChannelHandler;
        names(): $List<string>;
        removeFirst(): $ChannelHandler;
        removeLast(): $ChannelHandler;
        remove(arg0: $ChannelHandler): $ChannelPipeline;
        remove<T extends $ChannelHandler>(arg0: $Class<T>): T;
        remove(arg0: string): $ChannelHandler;
        replace(arg0: $ChannelHandler, arg1: string, arg2: $ChannelHandler): $ChannelPipeline;
        replace<T extends $ChannelHandler>(arg0: $Class<T>, arg1: string, arg2: $ChannelHandler): T;
        replace(arg0: string, arg1: string, arg2: $ChannelHandler): $ChannelHandler;
        toMap(): $Map<string, $ChannelHandler>;
    }

    export class $DefaultEventLoopGroup extends $MultithreadEventLoopGroup {
        constructor();
        constructor(arg0: number);
        constructor(arg0: number, arg1: $Executor_<$Runnable>);
        constructor(arg0: number, arg1: $ThreadFactory_<$Runnable, $Thread>);
        constructor(arg0: $ThreadFactory_<$Runnable, $Thread>);
        close(): void;
        forEach(arg0: $Consumer_<$EventExecutor, $EventExecutor>): void;
        spliterator(): $Spliterator<$EventExecutor>;
    }

    export class $SimpleChannelInboundHandler<I> extends $ChannelInboundHandlerAdapter {
        acceptInboundMessage(arg0: object): boolean;
        channelRead(arg0: $ChannelHandlerContext, arg1: object): void;
    }

    export interface $Channel$Unsafe {
        beginRead(): void;
        bind(arg0: $SocketAddress, arg1: $ChannelPromise): void;
        closeForcibly(): void;
        close(arg0: $ChannelPromise): void;
        connect(arg0: $SocketAddress, arg1: $SocketAddress, arg2: $ChannelPromise): void;
        deregister(arg0: $ChannelPromise): void;
        disconnect(arg0: $ChannelPromise): void;
        flush(): void;
        localAddress(): $SocketAddress;
        outboundBuffer(): $ChannelOutboundBuffer;
        recvBufAllocHandle(): $RecvByteBufAllocator$Handle;
        register(arg0: $EventLoop, arg1: $ChannelPromise): void;
        remoteAddress(): $SocketAddress;
        voidPromise(): $ChannelPromise;
        write(arg0: object, arg1: $ChannelPromise): void;
    }

    export interface $ChannelConfig {
        getAllocator(): $ByteBufAllocator;
        getConnectTimeoutMillis(): number;
        getMaxMessagesPerRead(): number;
        getMessageSizeEstimator(): $MessageSizeEstimator;
        getOptions(): $Map<$ChannelOption<any>, object>;
        getOption<T>(arg0: $ChannelOption<T>): T;
        getRecvByteBufAllocator<T extends $RecvByteBufAllocator>(): T;
        getWriteBufferHighWaterMark(): number;
        getWriteBufferLowWaterMark(): number;
        getWriteBufferWaterMark(): $WriteBufferWaterMark;
        getWriteSpinCount(): number;
        isAutoClose(): boolean;
        isAutoRead(): boolean;
        setAllocator(arg0: $ByteBufAllocator): $ChannelConfig;
        setAutoClose(arg0: boolean): $ChannelConfig;
        setAutoRead(arg0: boolean): $ChannelConfig;
        setConnectTimeoutMillis(arg0: number): $ChannelConfig;
        setMaxMessagesPerRead(arg0: number): $ChannelConfig;
        setMessageSizeEstimator(arg0: $MessageSizeEstimator_<$MessageSizeEstimator$Handle_<object, number>>): $ChannelConfig;
        setOptions(arg0: ($Map<$ChannelOption<any>, any> | ([$ChannelOption<any>] extends [PropertyKey] ? Partial<Record<Extract<$ChannelOption<any>, PropertyKey>, any>> : never))): boolean;
        setOption<T>(arg0: $ChannelOption<T>, arg1: T): boolean;
        setRecvByteBufAllocator(arg0: $RecvByteBufAllocator_<$RecvByteBufAllocator$Handle>): $ChannelConfig;
        setWriteBufferHighWaterMark(arg0: number): $ChannelConfig;
        setWriteBufferLowWaterMark(arg0: number): $ChannelConfig;
        setWriteBufferWaterMark(arg0: $WriteBufferWaterMark): $ChannelConfig;
        setWriteSpinCount(arg0: number): $ChannelConfig;
    }

    export interface $ChannelId extends $Serializable, $Comparable<$ChannelId> {
        asLongText(): string;
        asShortText(): string;
    }

    export class $ChannelMetadata {
        constructor(arg0: boolean);
        constructor(arg0: boolean, arg1: number);
        defaultMaxMessagesPerRead(): number;
        hasDisconnect(): boolean;
    }

    export interface $ChannelOutboundInvoker {
        bind(arg0: $SocketAddress, arg1: $ChannelPromise): $ChannelFuture;
        bind(arg0: $SocketAddress): $ChannelFuture;
        close(arg0: $ChannelPromise): $ChannelFuture;
        close(): $ChannelFuture;
        connect(arg0: $SocketAddress, arg1: $ChannelPromise): $ChannelFuture;
        connect(arg0: $SocketAddress, arg1: $SocketAddress, arg2: $ChannelPromise): $ChannelFuture;
        connect(arg0: $SocketAddress, arg1: $SocketAddress): $ChannelFuture;
        connect(arg0: $SocketAddress): $ChannelFuture;
        deregister(arg0: $ChannelPromise): $ChannelFuture;
        deregister(): $ChannelFuture;
        disconnect(arg0: $ChannelPromise): $ChannelFuture;
        disconnect(): $ChannelFuture;
        flush(): $ChannelOutboundInvoker;
        newFailedFuture(arg0: $Throwable): $ChannelFuture;
        newProgressivePromise(): $ChannelProgressivePromise;
        newPromise(): $ChannelPromise;
        newSucceededFuture(): $ChannelFuture;
        read(): $ChannelOutboundInvoker;
        voidPromise(): $ChannelPromise;
        writeAndFlush(arg0: object, arg1: $ChannelPromise): $ChannelFuture;
        writeAndFlush(arg0: object): $ChannelFuture;
        write(arg0: object, arg1: $ChannelPromise): $ChannelFuture;
        write(arg0: object): $ChannelFuture;
    }

    export interface $EventLoop extends $OrderedEventExecutor, $EventLoopGroup {
        parent(): $EventLoopGroup;
        parent(): $EventExecutorGroup;
    }

    export class $ChannelOutboundBuffer {
        get empty(): boolean;
        isEmpty(): boolean;
        get writable(): boolean;
        isWritable(): boolean;
        addFlush(): void;
        addMessage(arg0: object, arg1: number, arg2: $ChannelPromise): void;
        bytesBeforeUnwritable(): number;
        bytesBeforeWritable(): number;
        currentProgress(): number;
        current(): object;
        forEachFlushedMessage(arg0: $ChannelOutboundBuffer$MessageProcessor_<object, boolean>): void;
        getUserDefinedWritability(arg0: number): boolean;
        nioBufferCount(): number;
        nioBufferSize(): number;
        nioBuffers(arg0: number, arg1: number): $ByteBuffer[];
        nioBuffers(): $ByteBuffer[];
        progress(arg0: number): void;
        recycle(): void;
        removeBytes(arg0: number): void;
        remove(arg0: $Throwable): boolean;
        remove(): boolean;
        setUserDefinedWritability(arg0: number, arg1: boolean): void;
        size(): number;
        totalPendingWriteBytes(): number;
    }

    export interface $ChannelPromise extends $ChannelFuture, $Promise<void> {
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelFuture;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelPromise;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $NekoImport$Future<void>;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $Promise<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelFuture;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelPromise;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $NekoImport$Future<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $Promise<void>;
        awaitUninterruptibly(arg0: number, arg1: $TimeUnit_): boolean;
        awaitUninterruptibly(arg0: number): boolean;
        awaitUninterruptibly(): $ChannelFuture;
        awaitUninterruptibly(): $ChannelPromise;
        awaitUninterruptibly(): $NekoImport$Future<void>;
        awaitUninterruptibly(): $Promise<void>;
        await(arg0: number, arg1: $TimeUnit_): boolean;
        await(arg0: number): boolean;
        await(): $ChannelFuture;
        await(): $ChannelPromise;
        await(): $NekoImport$Future<void>;
        await(): $Promise<void>;
        channel(): $Channel;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelFuture;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelPromise;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $NekoImport$Future<void>;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $Promise<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelFuture;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelPromise;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $NekoImport$Future<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $Promise<void>;
        setFailure(arg0: $Throwable): $ChannelPromise;
        setFailure(arg0: $Throwable): $Promise<void>;
        setSuccess(arg0: void): $ChannelPromise;
        setSuccess(arg0: void): $Promise<void>;
        setSuccess(): $ChannelPromise;
        syncUninterruptibly(): $ChannelFuture;
        syncUninterruptibly(): $ChannelPromise;
        syncUninterruptibly(): $NekoImport$Future<void>;
        syncUninterruptibly(): $Promise<void>;
        sync(): $ChannelFuture;
        sync(): $ChannelPromise;
        sync(): $NekoImport$Future<void>;
        sync(): $Promise<void>;
        trySuccess(arg0: void): boolean;
        trySuccess(): boolean;
        unvoid(): $ChannelPromise;
    }

    export interface $RecvByteBufAllocator$Handle {
        allocate(arg0: $ByteBufAllocator): $ByteBuf;
        attemptedBytesRead(arg0: number): void;
        attemptedBytesRead(): number;
        continueReading(): boolean;
        guess(): number;
        incMessagesRead(arg0: number): void;
        lastBytesRead(arg0: number): void;
        lastBytesRead(): number;
        readComplete(): void;
        reset(arg0: $ChannelConfig): void;
    }

    export class $ChannelOption<T> extends $AbstractConstant<$ChannelOption<T>> {
        static ALLOCATOR: $ChannelOption<$ByteBufAllocator>;
        static ALLOW_HALF_CLOSURE: $ChannelOption<boolean>;
        static AUTO_CLOSE: $ChannelOption<boolean>;
        static AUTO_READ: $ChannelOption<boolean>;
        static CONNECT_TIMEOUT_MILLIS: $ChannelOption<number>;
        static DATAGRAM_CHANNEL_ACTIVE_ON_REGISTRATION: $ChannelOption<boolean>;
        static IP_MULTICAST_ADDR: $ChannelOption<$InetAddress>;
        static IP_MULTICAST_IF: $ChannelOption<$NetworkInterface>;
        static IP_MULTICAST_LOOP_DISABLED: $ChannelOption<boolean>;
        static IP_MULTICAST_TTL: $ChannelOption<number>;
        static IP_TOS: $ChannelOption<number>;
        static MAX_MESSAGES_PER_READ: $ChannelOption<number>;
        static MAX_MESSAGES_PER_WRITE: $ChannelOption<number>;
        static MESSAGE_SIZE_ESTIMATOR: $ChannelOption<$MessageSizeEstimator>;
        static RCVBUF_ALLOCATOR: $ChannelOption<$RecvByteBufAllocator>;
        static SINGLE_EVENTEXECUTOR_PER_GROUP: $ChannelOption<boolean>;
        static SO_BACKLOG: $ChannelOption<number>;
        static SO_BROADCAST: $ChannelOption<boolean>;
        static SO_KEEPALIVE: $ChannelOption<boolean>;
        static SO_LINGER: $ChannelOption<number>;
        static SO_RCVBUF: $ChannelOption<number>;
        static SO_REUSEADDR: $ChannelOption<boolean>;
        static SO_SNDBUF: $ChannelOption<number>;
        static SO_TIMEOUT: $ChannelOption<number>;
        static TCP_FASTOPEN: $ChannelOption<number>;
        static TCP_FASTOPEN_CONNECT: $ChannelOption<boolean>;
        static TCP_NODELAY: $ChannelOption<boolean>;
        static WRITE_BUFFER_HIGH_WATER_MARK: $ChannelOption<number>;
        static WRITE_BUFFER_LOW_WATER_MARK: $ChannelOption<number>;
        static WRITE_BUFFER_WATER_MARK: $ChannelOption<$WriteBufferWaterMark>;
        static WRITE_SPIN_COUNT: $ChannelOption<number>;
        static exists(arg0: string): boolean;
        static newInstance<T>(arg0: string): $ChannelOption<T>;
        static valueOf<T>(arg0: $Class<any>, arg1: string): $ChannelOption<T>;
        static valueOf<T>(arg0: string): $ChannelOption<T>;
        validate(arg0: T): void;
    }

    export interface $MessageSizeEstimator {
        newHandle(): $MessageSizeEstimator$Handle;
    }

    export interface $RecvByteBufAllocator {
        newHandle(): $RecvByteBufAllocator$Handle;
    }

    export class $WriteBufferWaterMark {
        constructor(arg0: number, arg1: number);
        static DEFAULT: $WriteBufferWaterMark;
        high(): number;
        low(): number;
        toString(): string;
    }

    export interface $ChannelHandler {
        exceptionCaught(arg0: $ChannelHandlerContext, arg1: $Throwable): void;
        handlerAdded(arg0: $ChannelHandlerContext): void;
        handlerRemoved(arg0: $ChannelHandlerContext): void;
    }

    export interface $ChannelInboundInvoker {
        fireChannelActive(): $ChannelInboundInvoker;
        fireChannelInactive(): $ChannelInboundInvoker;
        fireChannelReadComplete(): $ChannelInboundInvoker;
        fireChannelRead(arg0: object): $ChannelInboundInvoker;
        fireChannelRegistered(): $ChannelInboundInvoker;
        fireChannelUnregistered(): $ChannelInboundInvoker;
        fireChannelWritabilityChanged(): $ChannelInboundInvoker;
        fireExceptionCaught(arg0: $Throwable): $ChannelInboundInvoker;
        fireUserEventTriggered(arg0: object): $ChannelInboundInvoker;
    }

    export interface $ChannelOutboundBuffer$MessageProcessor {
        processMessage(arg0: object): boolean;
    }

    export interface $ChannelProgressivePromise extends $ProgressivePromise<void>, $ChannelProgressiveFuture, $ChannelPromise {
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelFuture;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelProgressiveFuture;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelProgressivePromise;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelPromise;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $NekoImport$Future<void>;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ProgressiveFuture<void>;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ProgressivePromise<void>;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $Promise<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelFuture;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelProgressiveFuture;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelProgressivePromise;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelPromise;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $NekoImport$Future<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ProgressiveFuture<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ProgressivePromise<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $Promise<void>;
        awaitUninterruptibly(arg0: number, arg1: $TimeUnit_): boolean;
        awaitUninterruptibly(arg0: number): boolean;
        awaitUninterruptibly(): $ChannelFuture;
        awaitUninterruptibly(): $ChannelProgressiveFuture;
        awaitUninterruptibly(): $ChannelProgressivePromise;
        awaitUninterruptibly(): $ChannelPromise;
        awaitUninterruptibly(): $NekoImport$Future<void>;
        awaitUninterruptibly(): $ProgressiveFuture<void>;
        awaitUninterruptibly(): $ProgressivePromise<void>;
        awaitUninterruptibly(): $Promise<void>;
        await(arg0: number, arg1: $TimeUnit_): boolean;
        await(arg0: number): boolean;
        await(): $ChannelFuture;
        await(): $ChannelProgressiveFuture;
        await(): $ChannelProgressivePromise;
        await(): $ChannelPromise;
        await(): $NekoImport$Future<void>;
        await(): $ProgressiveFuture<void>;
        await(): $ProgressivePromise<void>;
        await(): $Promise<void>;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelFuture;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelProgressiveFuture;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelProgressivePromise;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelPromise;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $NekoImport$Future<void>;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ProgressiveFuture<void>;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ProgressivePromise<void>;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $Promise<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelFuture;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelProgressiveFuture;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelProgressivePromise;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelPromise;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $NekoImport$Future<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ProgressiveFuture<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ProgressivePromise<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $Promise<void>;
        setFailure(arg0: $Throwable): $ChannelProgressivePromise;
        setFailure(arg0: $Throwable): $ChannelPromise;
        setFailure(arg0: $Throwable): $ProgressivePromise<void>;
        setFailure(arg0: $Throwable): $Promise<void>;
        setProgress(arg0: number, arg1: number): $ChannelProgressivePromise;
        setProgress(arg0: number, arg1: number): $ProgressivePromise<void>;
        setSuccess(arg0: void): $ChannelProgressivePromise;
        setSuccess(arg0: void): $ChannelPromise;
        setSuccess(arg0: void): $ProgressivePromise<void>;
        setSuccess(arg0: void): $Promise<void>;
        setSuccess(): $ChannelProgressivePromise;
        setSuccess(): $ChannelPromise;
        syncUninterruptibly(): $ChannelFuture;
        syncUninterruptibly(): $ChannelProgressiveFuture;
        syncUninterruptibly(): $ChannelProgressivePromise;
        syncUninterruptibly(): $ChannelPromise;
        syncUninterruptibly(): $NekoImport$Future<void>;
        syncUninterruptibly(): $ProgressiveFuture<void>;
        syncUninterruptibly(): $ProgressivePromise<void>;
        syncUninterruptibly(): $Promise<void>;
        sync(): $ChannelFuture;
        sync(): $ChannelProgressiveFuture;
        sync(): $ChannelProgressivePromise;
        sync(): $ChannelPromise;
        sync(): $NekoImport$Future<void>;
        sync(): $ProgressiveFuture<void>;
        sync(): $ProgressivePromise<void>;
        sync(): $Promise<void>;
        unvoid(): $ChannelProgressivePromise;
        unvoid(): $ChannelPromise;
    }

    export interface $ChannelProgressiveFuture extends $ChannelFuture, $ProgressiveFuture<void> {
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelFuture;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelProgressiveFuture;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $NekoImport$Future<void>;
        addListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ProgressiveFuture<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelFuture;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelProgressiveFuture;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $NekoImport$Future<void>;
        addListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ProgressiveFuture<void>;
        awaitUninterruptibly(arg0: number, arg1: $TimeUnit_): boolean;
        awaitUninterruptibly(arg0: number): boolean;
        awaitUninterruptibly(): $ChannelFuture;
        awaitUninterruptibly(): $ChannelProgressiveFuture;
        awaitUninterruptibly(): $NekoImport$Future<void>;
        awaitUninterruptibly(): $ProgressiveFuture<void>;
        await(arg0: number, arg1: $TimeUnit_): boolean;
        await(arg0: number): boolean;
        await(): $ChannelFuture;
        await(): $ChannelProgressiveFuture;
        await(): $NekoImport$Future<void>;
        await(): $ProgressiveFuture<void>;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelFuture;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ChannelProgressiveFuture;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $NekoImport$Future<void>;
        removeListeners(arg0?: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>[]): $ProgressiveFuture<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelFuture;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ChannelProgressiveFuture;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $NekoImport$Future<void>;
        removeListener(arg0: $GenericFutureListener_<$NekoImport$Future<any>, $NekoImport$Future<any>>): $ProgressiveFuture<void>;
        syncUninterruptibly(): $ChannelFuture;
        syncUninterruptibly(): $ChannelProgressiveFuture;
        syncUninterruptibly(): $NekoImport$Future<void>;
        syncUninterruptibly(): $ProgressiveFuture<void>;
        sync(): $ChannelFuture;
        sync(): $ChannelProgressiveFuture;
        sync(): $NekoImport$Future<void>;
        sync(): $ProgressiveFuture<void>;
    }

    export class $MultithreadEventLoopGroup extends $MultithreadEventExecutorGroup implements $EventLoopGroup {
        isShutdown(): boolean;
        get shuttingDown(): boolean;
        isShuttingDown(): boolean;
        get terminated(): boolean;
        isTerminated(): boolean;
        awaitTermination(arg0: number, arg1: $TimeUnit_): boolean;
        close(): void;
        execute(arg0: $Runnable_): void;
        forEach(arg0: $Consumer_<$EventExecutor, $EventExecutor>): void;
        invokeAll<T>(arg0: $Callable_<T, T>[], arg1: number, arg2: $TimeUnit_): $List<$NekoImport$Future1<T>>;
        invokeAll<T>(arg0: $Callable_<T, T>[]): $List<$NekoImport$Future1<T>>;
        invokeAny<T>(arg0: $Callable_<T, T>[], arg1: number, arg2: $TimeUnit_): T;
        invokeAny<T>(arg0: $Callable_<T, T>[]): T;
        iterator(): $Iterator<$EventExecutor>;
        next(): $EventLoop;
        register(arg0: $ChannelPromise): $ChannelFuture;
        register(arg0: $Channel, arg1: $ChannelPromise): $ChannelFuture;
        register(arg0: $Channel): $ChannelFuture;
        scheduleAtFixedRate(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        scheduleWithFixedDelay(arg0: $Runnable_, arg1: number, arg2: number, arg3: $TimeUnit_): $ScheduledFuture<any>;
        schedule(arg0: $Runnable_, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<any>;
        schedule<V>(arg0: $Callable_<V, V>, arg1: number, arg2: $TimeUnit_): $ScheduledFuture<V>;
        shutdownGracefully(arg0: number, arg1: number, arg2: $TimeUnit_): $NekoImport$Future<any>;
        shutdownGracefully(): $NekoImport$Future<any>;
        shutdownNow(): $List<$Runnable>;
        shutdown(): void;
        spliterator(): $Spliterator<$EventExecutor>;
        submit<T>(arg0: $Runnable_, arg1: T): $NekoImport$Future<T>;
        submit(arg0: $Runnable_): $NekoImport$Future<any>;
        submit<T>(arg0: $Callable_<T, T>): $NekoImport$Future<T>;
        terminationFuture(): $NekoImport$Future<any>;
    }

    export interface $EventLoopGroup extends $EventExecutorGroup {
        next(): $EventLoop;
        next(): $EventExecutor;
        register(arg0: $ChannelPromise): $ChannelFuture;
        register(arg0: $Channel, arg1: $ChannelPromise): $ChannelFuture;
        register(arg0: $Channel): $ChannelFuture;
    }

    export interface $MessageSizeEstimator$Handle {
        size(arg0: object): number;
    }

    export class $ChannelInboundHandlerAdapter extends $ChannelHandlerAdapter implements $ChannelInboundHandler {
        constructor();
        channelActive(arg0: $ChannelHandlerContext): void;
        channelInactive(arg0: $ChannelHandlerContext): void;
        channelReadComplete(arg0: $ChannelHandlerContext): void;
        channelRead(arg0: $ChannelHandlerContext, arg1: object): void;
        channelRegistered(arg0: $ChannelHandlerContext): void;
        channelUnregistered(arg0: $ChannelHandlerContext): void;
        channelWritabilityChanged(arg0: $ChannelHandlerContext): void;
        exceptionCaught(arg0: $ChannelHandlerContext, arg1: $Throwable): void;
        handlerAdded(arg0: $ChannelHandlerContext): void;
        handlerRemoved(arg0: $ChannelHandlerContext): void;
        userEventTriggered(arg0: $ChannelHandlerContext, arg1: object): void;
    }

    export class $ChannelHandlerAdapter implements $ChannelHandler {
        constructor();
        get sharable(): boolean;
        isSharable(): boolean;
        exceptionCaught(arg0: $ChannelHandlerContext, arg1: $Throwable): void;
        handlerAdded(arg0: $ChannelHandlerContext): void;
        handlerRemoved(arg0: $ChannelHandlerContext): void;
    }

    export interface $ChannelInboundHandler extends $ChannelHandler {
        channelActive(arg0: $ChannelHandlerContext): void;
        channelInactive(arg0: $ChannelHandlerContext): void;
        channelReadComplete(arg0: $ChannelHandlerContext): void;
        channelRead(arg0: $ChannelHandlerContext, arg1: object): void;
        channelRegistered(arg0: $ChannelHandlerContext): void;
        channelUnregistered(arg0: $ChannelHandlerContext): void;
        channelWritabilityChanged(arg0: $ChannelHandlerContext): void;
        exceptionCaught(arg0: $ChannelHandlerContext, arg1: $Throwable): void;
        userEventTriggered(arg0: $ChannelHandlerContext, arg1: object): void;
    }

    export interface $EventLoopTaskQueueFactory {
        newTaskQueue(arg0: number): $Queue<$Runnable>;
    }

    export interface $SelectStrategyFactory {
        newSelectStrategy(): $SelectStrategy;
    }

    export interface $SelectStrategy {
        calculateStrategy(arg0: $IntSupplier_<number>, arg1: boolean): number;
    }
    export const $SelectStrategy: {
        readonly BUSY_WAIT: number;
        readonly CONTINUE: number;
        readonly SELECT: number;
    };

    export type $MessageSizeEstimator_<CallbackResult = $MessageSizeEstimator$Handle_<object, number>> = (() => CallbackResult) | ($MessageSizeEstimator & { readonly [Symbol.hasInstance]?: never });
    export type $RecvByteBufAllocator_<CallbackResult = $RecvByteBufAllocator$Handle> = (() => CallbackResult) | ($RecvByteBufAllocator & { readonly [Symbol.hasInstance]?: never });
    export type $ChannelOutboundBuffer$MessageProcessor_<CallbackArg0 = object, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($ChannelOutboundBuffer$MessageProcessor & { readonly [Symbol.hasInstance]?: never });
    export type $MessageSizeEstimator$Handle_<CallbackArg0 = object, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($MessageSizeEstimator$Handle & { readonly [Symbol.hasInstance]?: never });
    export type $EventLoopTaskQueueFactory_<CallbackArg0 = number, CallbackResult = $Queue<$Runnable>> = ((arg0: CallbackArg0) => CallbackResult) | ($EventLoopTaskQueueFactory & { readonly [Symbol.hasInstance]?: never });
    export type $SelectStrategyFactory_<CallbackResult = $SelectStrategy_<$IntSupplier, boolean, number>> = (() => CallbackResult) | ($SelectStrategyFactory & { readonly [Symbol.hasInstance]?: never });
    export type $SelectStrategy_<CallbackArg0 = $IntSupplier, CallbackArg1 = boolean, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($SelectStrategy & { readonly [Symbol.hasInstance]?: never });
}
