import { $PointerBase, $SignedWord, $WordBase, $WordBase_ } from "java:graal/graalvm/word";

declare module "java:graal/graalvm/nativeimage/c/type" {
    export interface $WordPointer extends $PointerBase {
        addressOf(index: $SignedWord): $WordPointer;
        addressOf(index: number): $WordPointer;
        read<T extends $WordBase>(index: $SignedWord): T;
        read<T extends $WordBase>(index: number): T;
        read<T extends $WordBase>(): T;
        write(index: $SignedWord, value: $WordBase_<number>): void;
        write(value: $WordBase_<number>): void;
        write(index: number, value: $WordBase_<number>): void;
    }

}
