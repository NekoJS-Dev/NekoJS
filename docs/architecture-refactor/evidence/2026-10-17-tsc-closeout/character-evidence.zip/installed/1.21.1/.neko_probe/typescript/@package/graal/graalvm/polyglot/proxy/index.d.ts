import { $Value } from "java:graal/graalvm/polyglot";
import { $Map } from "java:java/util";

declare module "java:graal/graalvm/polyglot/proxy" {
    export interface $ProxyExecutable extends $Proxy {
        execute(arguments_?: $Value[]): object;
    }

    export interface $ProxyObject extends $Proxy {
        getMemberKeys(): object;
        getMember(key: string): object;
        hasMember(key: string): boolean;
        putMember(key: string, value: $Value): void;
        removeMember(key: string): boolean;
    }
    export const $ProxyObject: {
        fromMap(values: ($Map<string, object> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, object>> : never))): $ProxyObject;
    };

    export interface $Proxy {
    }

    export type $ProxyExecutable_<CallbackArg0 = $Value[], CallbackResult = object> = ((arg0: CallbackArg0) => CallbackResult) | ($ProxyExecutable & { readonly [Symbol.hasInstance]?: never });
}
