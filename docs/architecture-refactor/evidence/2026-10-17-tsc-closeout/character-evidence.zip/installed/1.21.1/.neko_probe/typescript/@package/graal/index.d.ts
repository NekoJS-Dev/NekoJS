export * as graalvm from "java:graal/graalvm";
export * as mod from "java:graal/mod";

