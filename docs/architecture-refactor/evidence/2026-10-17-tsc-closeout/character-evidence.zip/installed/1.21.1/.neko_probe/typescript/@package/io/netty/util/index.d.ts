import { $Class, $Comparable, $Comparable_ } from "java:java/lang";

export * as concurrent from "java:io/netty/util/concurrent";

declare module "java:io/netty/util" {
    export interface $ByteProcessor {
        process(arg0: number): boolean;
    }
    export const $ByteProcessor: {
        readonly FIND_ASCII_SPACE: $ByteProcessor;
        readonly FIND_COMMA: $ByteProcessor;
        readonly FIND_CR: $ByteProcessor;
        readonly FIND_CRLF: $ByteProcessor;
        readonly FIND_LF: $ByteProcessor;
        readonly FIND_LINEAR_WHITESPACE: $ByteProcessor;
        readonly FIND_NON_CR: $ByteProcessor;
        readonly FIND_NON_CRLF: $ByteProcessor;
        readonly FIND_NON_LF: $ByteProcessor;
        readonly FIND_NON_LINEAR_WHITESPACE: $ByteProcessor;
        readonly FIND_NON_NUL: $ByteProcessor;
        readonly FIND_NUL: $ByteProcessor;
        readonly FIND_SEMI_COLON: $ByteProcessor;
    };

    export interface $ReferenceCounted {
        refCnt(): number;
        release(arg0: number): boolean;
        release(): boolean;
        retain(arg0: number): $ReferenceCounted;
        retain(): $ReferenceCounted;
        touch(arg0: object): $ReferenceCounted;
        touch(): $ReferenceCounted;
    }

    export interface $AttributeMap {
        attr<T>(arg0: $AttributeKey<T>): $Attribute<T>;
        hasAttr<T>(arg0: $AttributeKey<T>): boolean;
    }

    export interface $Attribute<T> {
        compareAndSet(arg0: T, arg1: T): boolean;
        getAndRemove(): T;
        getAndSet(arg0: T): T;
        get(): T;
        key(): $AttributeKey<T>;
        remove(): void;
        setIfAbsent(arg0: T): T;
        set(arg0: T): void;
    }

    export class $AttributeKey<T> extends $AbstractConstant<$AttributeKey<T>> {
        static exists(arg0: string): boolean;
        static newInstance<T>(arg0: string): $AttributeKey<T>;
        static valueOf<T>(arg0: $Class<any>, arg1: string): $AttributeKey<T>;
        static valueOf<T>(arg0: string): $AttributeKey<T>;
    }

    export class $AbstractConstant<T extends $AbstractConstant<T>> implements $Constant<T> {
        compareTo(arg0: T): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): number;
        name(): string;
        toString(): string;
    }

    export interface $IntSupplier {
        get(): number;
    }

    export interface $Constant<T extends $Constant<T>> extends $Comparable<T> {
        id(): number;
        name(): string;
    }

    export type $ByteProcessor_<CallbackArg0 = number, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($ByteProcessor & { readonly [Symbol.hasInstance]?: never });
    export type $IntSupplier_<CallbackResult = number> = (() => CallbackResult) | ($IntSupplier & { readonly [Symbol.hasInstance]?: never });
}
