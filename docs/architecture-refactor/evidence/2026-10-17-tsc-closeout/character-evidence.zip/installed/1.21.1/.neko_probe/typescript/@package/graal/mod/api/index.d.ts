import { $HostAccess$Builder, $HostAccess$TargetMappingPrecedence, $HostAccess$TargetMappingPrecedence_ } from "java:graal/graalvm/polyglot";
import { $Class } from "java:java/lang";
import { $List } from "java:java/util";
import { $Function, $Function_, $Predicate, $Predicate_ } from "java:java/util/function";

declare module "java:graal/mod/api" {
    export interface $TypeMappingProvider {
        provideMapping<T>(arg0: $Class<T>, arg1: $TypeMappingProvider$MappingRegistry_<T, $Class<any>, $Class<T>, $Predicate<any>, $Function<any, T>, $HostAccess$TargetMappingPrecedence>): void;
    }

    export interface $TypeMappingProviderRegistry {
        graal$addProvider(arg0: $TypeMappingProvider_<$Class<any>, $TypeMappingProvider$MappingRegistry<any>>): void;
        graal$viewProviders(): $List<$TypeMappingProvider>;
    }
    export const $TypeMappingProviderRegistry: {
        cast(object: $HostAccess$Builder): $TypeMappingProviderRegistry;
    };

    export interface $TypeMappingProvider$MappingRegistry<T> {
        register<S>(arg0: $Class<S>, arg1: $Class<T>, arg2: $Predicate_<S, S, boolean>, arg3: $Function_<S, T, S, T>, arg4: $HostAccess$TargetMappingPrecedence_): void;
        register<S>(sourceType: $Class<S>, targetType: $Class<T>, accepts: $Predicate_<S, S, boolean>, converter: $Function_<S, T, S, T>): void;
    }

    export type $TypeMappingProvider_<CallbackArg0 = $Class<any>, CallbackArg1 = $TypeMappingProvider$MappingRegistry<any>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($TypeMappingProvider & { readonly [Symbol.hasInstance]?: never });
    export type $TypeMappingProvider$MappingRegistry_<Host0 = any, CallbackArg0 = $Class<any>, CallbackArg1 = $Class<Host0>, CallbackArg2 = $Predicate<any>, CallbackArg3 = $Function<any, Host0>, CallbackArg4 = $HostAccess$TargetMappingPrecedence> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3, arg4: CallbackArg4) => void) | ($TypeMappingProvider$MappingRegistry<Host0> & { readonly [Symbol.hasInstance]?: never });
}
