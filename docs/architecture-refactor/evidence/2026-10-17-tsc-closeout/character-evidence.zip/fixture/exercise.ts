import { $TypeScriptCharacterProjectionTest$Api as Api } from 'java:com/tkisor/nekojs/probe/ir';
import type { $TypeScriptCharacterProjectionTest$Characters as Characters, $TypeScriptCharacterProjectionTest$Identity as Identity } from 'java:com/tkisor/nekojs/probe/ir';
declare const characters: Characters;
const inherited: Identity<string> = characters;
const copied: string = inherited.copy('a');
const letters: string[] = characters.letters();
const api = new Api('a');
const boxed: string = api.boxed();
const primitive: string = api.primitive();
const nested: string = api.holder.value;
const result: string = api.apply(value => value.toUpperCase());
api.letter = 'b';
api.letters = ['a', 'b'];
// @ts-expect-error Character input is not an arbitrary host object.
api.copy({});
// @ts-expect-error Character results retain the string value contract.
const wrongReturn: number = api.boxed();
// @ts-expect-error Nested host type arguments use the same value contract.
api.holder.value = 1;
// @ts-expect-error Callback results retain their actual character contract.
api.apply(value => 1);
