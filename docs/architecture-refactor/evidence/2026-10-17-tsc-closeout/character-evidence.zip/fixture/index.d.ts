declare module "java:com/tkisor/nekojs/probe/ir" {
    export interface $TypeScriptCharacterProjectionTest$Identity<T> {
        copy(value: T): T;
    }

    export interface $TypeScriptCharacterProjectionTest$Characters extends $TypeScriptCharacterProjectionTest$Identity<string> {
        copy(value: string): string;
        letters(): string[];
    }

    export interface $TypeScriptCharacterProjectionTest$Mapper<T, R> {
        apply(value: T): R;
    }

    export class $TypeScriptCharacterProjectionTest$Holder<T> {
        constructor();
        value: T;
    }

    export class $TypeScriptCharacterProjectionTest$Api {
        constructor(value: string);
        holder: $TypeScriptCharacterProjectionTest$Holder<string>;
        letter: string;
        letters: string[];
        apply(callback: $TypeScriptCharacterProjectionTest$Mapper_<string, string, string, string>): string;
        boxed(): string;
        copy(value: string): string;
        held(): string;
        identity(): $TypeScriptCharacterProjectionTest$Identity<string>;
        primitive(): string;
    }

    export type $TypeScriptCharacterProjectionTest$Identity_<Host0 = any, CallbackArg0 = Host0, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptCharacterProjectionTest$Identity<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $TypeScriptCharacterProjectionTest$Mapper_<Host0 = any, Host1 = any, CallbackArg0 = Host0, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptCharacterProjectionTest$Mapper<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
}
