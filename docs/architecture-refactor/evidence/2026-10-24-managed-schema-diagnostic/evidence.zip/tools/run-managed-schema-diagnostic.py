"""Measure managed-schema re-extraction on the actual performance fixture without altering production."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import time
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
root = tools / 'managed-schema-975496d3-v1'
assert not root.exists()
source = tools / 'dynamic-commit-975496d3-261-v1'
installed = repo / 'build/closeout-method-bounds-installed/26.1.2'
port = 31591
for number in [port, port + 1]:
    with socket.socket() as check:
        check.bind(('127.0.0.1', number))
root.mkdir()
server = root / 'server'
server.mkdir()
java = Path('C:/Program Files/Java/jdk-25.0.2/bin')
properties = (installed / 'server.properties').read_text()
properties = '\n'.join(f'server-port={port}' if line.startswith('server-port=') else
    f'rcon.port={port+1}' if line.startswith('rcon.port=') else
    'level-name=owned-schema-diagnostic' if line.startswith('level-name=') else
    'server-ip=127.0.0.1' if line.startswith('server-ip=') else line for line in properties.splitlines()) + '\n'
(server / 'server.properties').write_text(properties)
props = dict(line.split('=', 1) for line in properties.splitlines() if '=' in line and not line.startswith('#'))
shutil.copyfile(installed / 'eula.txt', server / 'eula.txt')
shutil.copytree(installed / 'nekojs/config', server / 'nekojs/config')
for folder in ['startup_scripts', 'server_scripts', 'client_scripts']:
    shutil.copytree(repo / 'bench/perf/fixtures/nekojs' / folder, server / 'nekojs' / folder)
(server / 'mods').mkdir()
for file in (installed / 'mods').glob('*.jar'):
    shutil.copyfile(file, server / 'mods' / file.name)
artifact = next(file for file in (server / 'mods').glob('nekojs-*.jar'))
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == '2206b92413bb4c9ac3f1d5f5cc2d7b3a9df95631e7defdd5c0d6ee368b9b2132'
(server / 'libraries').symlink_to((installed / 'libraries').resolve(), target_is_directory=True)
sources = root / 'src'
sources.mkdir()
text = (source / 'src/main/java/nekojs/acceptance/tcp/AcceptanceMod.java').read_text()
text = text.replace('nekojs.acceptance.tcp', 'nekojs.acceptance.schema').replace('neko_tcp_acceptance', 'neko_schema_acceptance')
text = text.replace('com.tkisor.nekojs.dynamic.DynamicRegistryFacade', 'com.tkisor.nekojs.api.event.ScriptBindingSchema')
text = text.replace('com.tkisor.nekojs.core.dynamic.txn.DynamicRegistryClientParticipant', 'com.tkisor.nekojs.script.ScriptEnvironmentFactory')
(sources / 'AcceptanceMod.java').write_text(text)
shutil.copyfile(tools / 'ManagedSchemaObservation.java', sources / 'ManagedSchemaObservation.java')
descriptor = json.loads((source / 'launch-descriptor.json').read_text())
classpath = [str(file) for file in (server / 'mods').glob('*.jar')] + descriptor['classpath']
classes = root / 'classes'
classes.mkdir()
with (root / 'compiler.log').open('xb') as log:
    compile_result = subprocess.run([str(java / 'javac.exe'), '-encoding', 'UTF-8', '-cp', os.pathsep.join(classpath),
        '-d', str(classes), *[str(file) for file in sources.glob('*.java')]], stdout=log, stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW)
assert compile_result.returncode == 0, 'Owned metadata helper compilation failed'
helper = server / 'mods/neko-schema-acceptance.jar'
with zipfile.ZipFile(helper, 'x', zipfile.ZIP_DEFLATED) as archive:
    for file in classes.rglob('*.class'):
        archive.write(file, file.relative_to(classes).as_posix())
    archive.writestr('META-INF/neoforge.mods.toml', 'modLoader="javafml"\nloaderVersion="[1,)"\nlicense="MIT"\n[[mods]]\nmodId="neko_schema_acceptance"\nversion="1"\ndisplayName="Owned schema metadata diagnostic"\n')
    archive.writestr('META-INF/MANIFEST.MF', 'Manifest-Version: 1.0\nFMLModType: MOD\n\n')
spec = importlib.util.spec_from_file_location('owned_rcon', repo / 'bench/perf/rcon.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
commands = []
def command(text):
    with socket.create_connection(('127.0.0.1', port + 1), timeout=10) as connection:
        connection.settimeout(90)
        rcon.send_packet(connection, 1, 3, props['rcon.password'])
        assert rcon.recv_packet(connection)[0] != -1
        rcon.send_packet(connection, 10, 2, text)
        response = rcon.recv_packet(connection)
        assert response is not None
        commands.append(dict(command=text, response=response[2]))
        return response[2]
def log():
    return (root / 'server-stdout.log').read_text(encoding='utf8', errors='replace')
def wait(predicate, seconds, label):
    end = time.monotonic() + seconds
    while not predicate():
        assert process.poll() is None, 'Owned server exited during ' + label
        assert time.monotonic() < end, 'Owned server timed out during ' + label
        time.sleep(0.2)
result = dict(productionRevision='975496d3bddf6fc76b206921a1d09207120ca24d',
    productionSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(), helperSha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
    fixtureScope='Existing performance scripts, fresh installed server; diagnostic, not original runServer formal sampler.',
    productionChanged=False, errors=[], forced=False)
(server / 'schema-measure-request.txt').write_text('00')
with (root / 'server-stdout.log').open('xb') as out, (root / 'server-stderr.log').open('xb') as err:
    process = subprocess.Popen([str(java / 'java.exe'), '-Xms512M', '-Xmx2G',
        '-Dnekojs.acceptance.jar=' + str(artifact), '@libraries/net/neoforged/neoforge/26.1.2.71/win_args.txt', 'nogui'],
        cwd=server, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
(root / 'owned-process.json').write_text(json.dumps(dict(pid=process.pid, directory=str(server))) + '\n')
try:
    wait(lambda: 'Done (' in log() and (server / 'schema-measure-00.json').exists(), 300, 'startup measurement')
    assert 'OWNED-TCP-INSTALLED-SOURCE-PASS' in log()
    for index in range(1, 6):
        time.sleep(3)
        response = command('nekojs reload')
        assert 'failed' not in response.lower() and 'rejected' not in response.lower(), response
        request = f'{index:02}'
        (server / 'schema-measure-request.txt').write_text(request)
        wait(lambda: (server / f'schema-measure-{request}.json').exists(), 30, 'schema measurement ' + request)
    result['measurements'] = []
    for index in range(6):
        row = json.loads((server / f'schema-measure-{index:02}.json').read_text())
        assert row['sameThread'] and len(row['measuredPassesMillis']) == 1000
        result['measurements'].append({key: row[key] for key in ['request', 'surfaceIdentity', 'symbolKinds',
            'firstPassMillis', 'meanMillis', 'medianMillis', 'p95Millis', 'maxMillis', 'memberChecksum']})
    result['verdict'] = 'DIAGNOSTIC COMPLETE'
except BaseException as failure:
    result['errors'].append(repr(failure))
    result['verdict'] = 'NOT GREEN'
    raise
finally:
    if process.poll() is None:
        try:
            command('stop')
            process.wait(timeout=90)
        except Exception as failure:
            result['errors'].append('Normal stop failed: ' + repr(failure))
            process.terminate()
            process.wait(timeout=30)
            result['forced'] = True
    result['exitCode'] = process.returncode
    (root / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    (root / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    assert process.returncode == 0 and not result['forced'] and not result['errors']
print(json.dumps(result), flush=True)
