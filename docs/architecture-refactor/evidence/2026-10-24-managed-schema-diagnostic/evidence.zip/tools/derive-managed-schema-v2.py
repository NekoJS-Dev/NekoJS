"""Retain the failed first fixture and publish the fresh diagnostic's requests atomically."""
from pathlib import Path

tools = Path.cwd() / 'build/priority-closeout'
text = (tools / 'run-managed-schema-diagnostic.py').read_text()
text = text.replace('managed-schema-975496d3-v1', 'managed-schema-975496d3-v2').replace('port = 31591', 'port = 31691')
marker = 'def log():\n'
assert text.count(marker) == 1
text = text.replace(marker, '''def publish_request(request):
    pending = server / 'schema-measure-request.pending'
    pending.write_text(request)
    end = time.monotonic() + 5
    while True:
        try:
            pending.replace(server / 'schema-measure-request.txt')
            return
        except PermissionError:
            assert time.monotonic() < end, 'Owned metadata request publication timed out'
            time.sleep(0.05)
def log():
''')
text = text.replace("(server / 'schema-measure-request.txt').write_text(request)", 'publish_request(request)')
text = text.replace("assert 'failed' not in response.lower() and 'rejected' not in response.lower(), response",
                    "assert 'reload committed:' in response and 'no errors.' in response, response")
target = tools / 'run-managed-schema-diagnostic-v2.py'
assert not target.exists()
target.write_text(text, newline='\n')
print('Prepared a fresh diagnostic; atomic request publication and complete no-error COMMIT checks.')
