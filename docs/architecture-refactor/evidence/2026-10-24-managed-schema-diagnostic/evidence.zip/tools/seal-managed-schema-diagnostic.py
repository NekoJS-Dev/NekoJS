"""Retain the failed fixture and complete actual-snapshot metadata measurements separately."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-24-managed-schema-diagnostic'
assert not out.exists()
first = tools / 'managed-schema-975496d3-v1'
second = tools / 'managed-schema-975496d3-v2'
failed = json.loads((first / 'result.json').read_text())
result = json.loads((second / 'result.json').read_text())
assert failed['verdict'] == 'NOT GREEN' and failed['errors']
assert result['verdict'] == 'DIAGNOSTIC COMPLETE' and result['exitCode'] == 0 and not result['forced'] and not result['errors']
assert len(result['measurements']) == 6
secrets = set()
for trial in [first, second]:
    properties = dict(line.split('=', 1) for line in (trial / 'server/server.properties').read_text().splitlines()
                      if '=' in line and not line.startswith('#'))
    secrets.add(properties['rcon.password'])
entries = {}
redactions = {}
def add(name, file):
    original = data = file.read_bytes()
    for secret in secrets:
        if secret:
            for encoding in ['utf8', 'utf-16-le', 'utf-16-be']:
                data = data.replace(secret.encode(encoding), '[REDACTED]'.encode(encoding))
    if data != original:
        redactions[name] = hashlib.sha256(original).hexdigest()
    assert name not in entries
    entries[name] = data
for index, trial in enumerate([first, second], 1):
    prefix = 'v' + str(index) + '/'
    for name in ['result.json', 'commands.json', 'owned-process.json', 'compiler.log', 'server-stdout.log', 'server-stderr.log']:
        add(prefix + name, trial / name)
    for file in (trial / 'src').glob('*.java'):
        add(prefix + 'src/' + file.name, file)
    for file in (trial / 'server').glob('schema-measure-*.json'):
        add(prefix + file.name, file)
    for file in (trial / 'server').glob('installed-source-*.json'):
        add(prefix + file.name, file)
    helper = trial / 'server/mods/neko-schema-acceptance.jar'
    add(prefix + 'helper.jar', helper)
    assert entries[prefix + 'helper.jar'] == helper.read_bytes()
    for folder in ['startup_scripts', 'server_scripts', 'client_scripts']:
        for file in (trial / 'server/nekojs' / folder).rglob('*.js'):
            add(prefix + 'fixtures/' + folder + '/' + file.relative_to(trial / 'server/nekojs' / folder).as_posix(), file)
for name in ['run-managed-schema-diagnostic.py', 'derive-managed-schema-v2.py', 'run-managed-schema-diagnostic-v2.py',
             'managed-schema-diagnostic-controller.log', 'managed-schema-diagnostic-v2-controller.log',
             'seal-managed-schema-diagnostic.py']:
    add('tools/' + name, tools / name)
add('tools/rcon.py', repo / 'bench/perf/rcon.py')
binding = repo / 'build/closeout-method-bounds-installed/preparation-manifest.json'
add('installed-candidate.json', binding)
manifest = json.loads(binding.read_text())
node = next(row for row in manifest['nodes'] if row['node'] == '26.1.2')
assert node['sha256'] == result['productionSha256']
production = second / 'server/mods' / node['artifact']
assert hashlib.sha256(production.read_bytes()).hexdigest() == node['sha256']
with zipfile.ZipFile(production) as archive:
    for name, digest in node['classBindings'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
reference = repo / 'docs/architecture-refactor/evidence/2026-10-24-method-bounds-performance/evidence.zip'
out.mkdir()
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(out / 'manifest.json').write_text(json.dumps(dict(sourceRevision=result['productionRevision'],
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    artifactReference=dict(path='../2026-10-24-method-bounds-performance/evidence.zip',
        archiveSha256=hashlib.sha256(reference.read_bytes()).hexdigest(), entry='artifact/' + node['artifact']),
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())},
    redactedOriginalHashes=redactions,
    exclusions=['world binaries', 'properties', 'compiler/launcher argument files', 'runtime libraries', 'crash report with full system details']), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size, rawSamples=6000,
    failedAttemptRetained=True, successfulNormalStops=1, productionChanged=False)))
