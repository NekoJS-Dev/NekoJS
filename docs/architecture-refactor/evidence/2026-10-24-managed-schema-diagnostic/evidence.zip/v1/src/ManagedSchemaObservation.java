package nekojs.acceptance.schema;

import com.google.gson.GsonBuilder;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.api.event.ScriptBindingSchema;
import com.tkisor.nekojs.api.surface.ApiSurfaceSnapshot;
import com.tkisor.nekojs.api.surface.ApiSymbolId;
import com.tkisor.nekojs.api.surface.EnvironmentKey;
import com.tkisor.nekojs.core.plugin.NekoPluginRuntime;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** Measures only pure managed-global schema extraction on an actual server snapshot. */
@EventBusSubscriber(modid = "neko_schema_acceptance")
public final class ManagedSchemaObservation {
    private static String previousRequest;
    private static volatile int sink;

    private static int extract(ApiSurfaceSnapshot surface, Set<String> occupied) {
        var globals = new HashMap<String, ApiSymbolId>();
        for (var symbol : surface.symbols()) {
            if (symbol.id().kind().equals("global")) globals.put(symbol.id().qualifiedName(), symbol.id());
        }
        int count = 0;
        for (var entry : globals.entrySet()) {
            if (!occupied.contains(entry.getKey())) {
                count += ScriptBindingSchema.fromSurface(surface, entry.getValue()).memberNames().size();
            }
        }
        return count;
    }

    @SubscribeEvent
    public static void tick(ServerTickEvent.Post event) throws Exception {
        Path requestFile = Path.of("schema-measure-request.txt");
        if (!Files.exists(requestFile)) return;
        String request = Files.readString(requestFile).strip();
        if (request.equals(previousRequest)) return;
        if (!request.matches("[0-9]{2}")) throw new IllegalStateException("Owned schema request is invalid");
        previousRequest = request;
        if (!event.getServer().isSameThread()) throw new IllegalStateException("Owned schema observation left the server thread");
        var runtime = NekoPluginRuntime.current();
        var view = runtime.apiRuntime(EnvironmentKey.current(ScriptType.SERVER));
        ApiSurfaceSnapshot surface = view.environmentSnapshot().surfaceSnapshot();
        Set<String> occupied = runtime.bindings(ScriptType.SERVER).keySet();
        long start = System.nanoTime();
        sink = extract(surface, occupied);
        double firstMillis = (System.nanoTime() - start) / 1_000_000.0;
        for (int index = 0; index < 100; index++) sink = extract(surface, occupied);
        double[] measured = new double[1000];
        for (int index = 0; index < measured.length; index++) {
            start = System.nanoTime();
            sink = extract(surface, occupied);
            measured[index] = (System.nanoTime() - start) / 1_000_000.0;
        }
        var members = new TreeMap<String, Set<String>>();
        var kinds = new TreeMap<String, Integer>();
        List<Map<String, String>> symbols = new ArrayList<>();
        for (var symbol : surface.symbols()) {
            kinds.merge(symbol.id().kind(), 1, Integer::sum);
            symbols.add(Map.of("kind", symbol.id().kind(), "qualifiedName", symbol.id().qualifiedName()));
            if (symbol.id().kind().equals("global") && !occupied.contains(symbol.id().qualifiedName())) {
                members.put(symbol.id().qualifiedName(), ScriptBindingSchema.fromSurface(surface, symbol.id()).memberNames());
            }
        }
        double[] ordered = measured.clone();
        Arrays.sort(ordered);
        var result = new LinkedHashMap<String, Object>();
        result.put("request", request);
        result.put("sameThread", true);
        result.put("surfaceIdentity", System.identityHashCode(surface));
        result.put("symbols", symbols);
        result.put("symbolKinds", kinds);
        result.put("occupiedBindingNames", occupied);
        result.put("selectedGlobalMembers", members);
        result.put("firstPassMillis", firstMillis);
        result.put("warmupPasses", 100);
        result.put("measuredPassesMillis", measured);
        result.put("meanMillis", Arrays.stream(measured).average().orElseThrow());
        result.put("medianMillis", ordered[500]);
        result.put("p95Millis", ordered[950]);
        result.put("maxMillis", ordered[999]);
        result.put("memberChecksum", sink);
        result.put("scope", "Re-extraction after startup/reload; does not time the BINDING phase or replace formal performance.");
        Files.writeString(Path.of("schema-measure-" + request + ".json"), new GsonBuilder().setPrettyPrinting().create().toJson(result) + "\n");
        System.out.println("OWNED-SCHEMA-METADATA-MEASURED request=" + request + " symbols=" + surface.symbols().size()
                + " selectedGlobals=" + members.size() + " firstMs=" + firstMillis);
    }
}
