import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
mode = sys.argv[1]
assert mode in {'focused-v1', 'focused-v2', 'check', 'check-v2', 'lang-control'}
output = project/'build/priority-closeout/pack-resources'/mode
output.mkdir(parents=True, exist_ok=False)
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME']+'/bin;'+environment['PATH']
environment['GRADLE_USER_HOME'] = 'D:/mcmodDemo/NekoJS/.gradle-<REDACTED-RCON-CREDENTIAL>'
arguments = ['cmd.exe', '/d', '/c', 'gradlew.bat', ':common:check' if mode.startswith('check') else ':common:test']
if not mode.startswith('check'):
    arguments.extend(['--tests', 'com.tkisor.nekojs.wrapper.LangGeneratorJSTest' if mode == 'lang-control'
                      else 'com.tkisor.nekojs.core.pack.PackResourceStabilityTest'])
arguments.extend(['--offline', '--console=plain', '--no-configuration-cache'])
sources = {str(path.relative_to(project)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [
    project/'common/src/test/java/com/tkisor/nekojs/core/pack/PackResourceStabilityTest.java',
    project/'common/src/test/java/com/tkisor/nekojs/core/pack/PackActivationTest.java']}
with (output/'stdout.log').open('wb') as stdout, (output/'stderr.log').open('wb') as stderr:
    result = subprocess.run(arguments, cwd=project, env=environment, stdout=stdout, stderr=stderr)
(output/'result.json').write_text(json.dumps(dict(exitCode=result.returncode, arguments=arguments[4:], sources=sources), indent=2)+'\n')
properties = dict(line.split('=', 1) for line in Path(
    'C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run/server.properties'
).read_text().splitlines() if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password']
for label in ['stdout.log', 'stderr.log']:
    text = (output/label).read_text(encoding='utf-8', errors='replace').replace(secret, '<REDACTED-RCON-CREDENTIAL>')
    print(label+':\n'+'\n'.join(text.splitlines()[-35:]))
print(json.dumps(dict(mode=mode, exitCode=result.returncode)))
sys.exit(result.returncode)
