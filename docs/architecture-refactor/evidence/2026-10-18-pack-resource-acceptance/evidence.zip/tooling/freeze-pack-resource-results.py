import hashlib
import json
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
mode = sys.argv[1]
assert mode in {'focused-v1', 'check', 'check-v2', 'lang-control'}
output = project/'build/priority-closeout/pack-resources'/mode
exit_code = json.loads((output/'result.json').read_text())['exitCode']
snapshot = output/'xml'
snapshot.mkdir(exist_ok=False)
totals = dict(tests=0, failures=0, errors=0, skipped=0)
files = {}
for file in sorted((project/'common/build/test-results/test').glob('TEST-*.xml')):
    shutil.copyfile(file, snapshot/file.name)
    data = file.read_bytes()
    files[file.name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    root = ET.fromstring(data)
    for key in totals:
        totals[key] += int(root.attrib.get(key, 0))
assert totals['tests'] > 0
assert (totals['failures'] == 0 and totals['errors'] == 0) == (exit_code == 0)
if mode == 'focused-v1':
    assert totals['tests'] == 5 and totals['skipped'] == 0
summary = dict(result='PASS' if exit_code == 0 else 'FAIL', totals=totals, files=files)
(output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(dict(mode=mode, **totals)))
