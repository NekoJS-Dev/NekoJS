import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project = Path('D:/mcmodDemo/NekoJS-mult')
tools = project/'build/priority-closeout'
target = project/'docs/architecture-refactor/evidence/2026-10-18-pack-resource-acceptance'
properties = dict(line.split('=', 1) for line in Path(
    'C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult/versions/26.1.2/run/server.properties'
).read_text().splitlines() if line and not line.startswith('#') and '=' in line)
secret = properties['rcon.password'].encode()
files, redactions = {}, {}


def add(path, name):
    data = path.read_bytes()
    assert name not in files
    if secret in data:
        redactions[name] = dict(originalSha256=hashlib.sha256(data).hexdigest(), occurrences=data.count(secret))
        data = data.replace(secret, b'<REDACTED-RCON-CREDENTIAL>')
    files[name] = data


for label in ['focused-v1', 'check', 'lang-control', 'check-v2']:
    output = tools/'pack-resources'/label
    assert (output/'summary.json').is_file()
    for path in sorted(output.rglob('*')):
        if path.is_file(): add(path, label+'/'+path.relative_to(output).as_posix())
for name in ['PackResourceStabilityTest.java', 'PackActivationTest.java']:
    add(project/'common/src/test/java/com/tkisor/nekojs/core/pack'/name, 'sources/'+name)
for relative in ['common/src/main/java/com/tkisor/nekojs/wrapper/LangGeneratorJS.java',
                 'common/src/test/java/com/tkisor/nekojs/wrapper/LangGeneratorJSTest.java']:
    assert subprocess.check_output(['git', 'show', '6e5bb8f0:'+relative], cwd=project) == (project/relative).read_bytes().replace(b'\r\n', b'\n')
    add(project/relative, 'sources/'+Path(relative).name)
for name in ['run-pack-resource-check.py', 'freeze-pack-resource-results.py', 'seal-pack-resource-evidence.py']:
    add(tools/name, 'tooling/'+name)
assert subprocess.run(['git', 'diff', '--quiet', '6e5bb8f0', '--', 'common/src/main', 'src/main', 'versions'], cwd=project).returncode == 0
files['redactions.json'] = (json.dumps(redactions, indent=2)+'\n').encode()
packed = target/'evidence.zip'
assert not packed.exists()
with zipfile.ZipFile(packed, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()): archive.writestr(name, data)
manifest = dict(productionTreesUnchanged=True, productionRevision='6e5bb8f00c3747b828056589853cb0471477b18a',
    sourceParentRevision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project, text=True).strip(),
    archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
    entries={name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(files.items())})
(target/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(entries=len(files), zipBytes=packed.stat().st_size, archiveSha256=manifest['archiveSha256'])))
