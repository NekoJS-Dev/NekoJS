import { types } from 'util';
import { types as nodeTypes } from 'node:util';
export function direct(value: unknown): object | null { if (types.isProxy(value)) { const narrowed: object = value; return narrowed; } return null; }
export function alias(value: unknown): object | null { if (nodeTypes.isProxy(value)) { const narrowed: object = value; return narrowed; } return null; }
