declare module 'util' {
    export function format(format: unknown, ...args: unknown[]): string;
    export function inspect(value: unknown): string;
    export function promisify(fn: Function): Function;
    export function callbackify(fn: Function): Function;
    export function deprecate<T extends Function>(fn: T, message: string, code?: string): T;
    export function inherits(ctor: Function, superCtor: Function): void;
    export function isDeepStrictEqual(left: unknown, right: unknown): boolean;
    export function debuglog(_section?: unknown): Function;
    export const types: { isPromise(value: unknown): value is Promise<unknown>; isProxy(_value: unknown): _value is object; isNativeError(value: unknown): value is Error; isDate(value: unknown): value is Date; isRegExp(value: unknown): value is RegExp; isMap(value: unknown): value is AnyMap; isSet(value: unknown): value is Set<unknown>; isWeakMap(value: unknown): value is AnyWeakMap; isWeakSet(value: unknown): value is WeakSet<object>; isArrayBuffer(value: unknown): value is ArrayBuffer; isSharedArrayBuffer(value: unknown): value is SharedArrayBuffer; isAnyArrayBuffer(value: unknown): value is ArrayBufferLike; isTypedArray(value: unknown): value is ArrayBufferView; isUint8Array(value: unknown): value is Uint8Array; isDataView(value: unknown): value is DataView; isArgumentsObject(value: unknown): value is ArrayLike<unknown>; isBoxedPrimitive(value: unknown): value is object; isBooleanObject(value: unknown): value is Boolean; isNumberObject(value: unknown): value is Number; isStringObject(value: unknown): value is String; isSymbolObject(value: unknown): value is Symbol; isBigIntObject(value: unknown): value is BigInt };
    interface NekoInspect {
        (value: unknown): string
        custom: symbol
      }
    type AnyMap = Map<unknown, unknown>
    type AnyWeakMap = WeakMap<object, unknown>
    type NekoCloneSeen = Map<unknown, unknown>
    interface NekoTypedArrayCtor { new (source: unknown): unknown }

}
declare module 'node:util' {
    export function format(format: unknown, ...args: unknown[]): string;
    export function inspect(value: unknown): string;
    export function promisify(fn: Function): Function;
    export function callbackify(fn: Function): Function;
    export function deprecate<T extends Function>(fn: T, message: string, code?: string): T;
    export function inherits(ctor: Function, superCtor: Function): void;
    export function isDeepStrictEqual(left: unknown, right: unknown): boolean;
    export function debuglog(_section?: unknown): Function;
    export const types: { isPromise(value: unknown): value is Promise<unknown>; isProxy(_value: unknown): _value is object; isNativeError(value: unknown): value is Error; isDate(value: unknown): value is Date; isRegExp(value: unknown): value is RegExp; isMap(value: unknown): value is AnyMap; isSet(value: unknown): value is Set<unknown>; isWeakMap(value: unknown): value is AnyWeakMap; isWeakSet(value: unknown): value is WeakSet<object>; isArrayBuffer(value: unknown): value is ArrayBuffer; isSharedArrayBuffer(value: unknown): value is SharedArrayBuffer; isAnyArrayBuffer(value: unknown): value is ArrayBufferLike; isTypedArray(value: unknown): value is ArrayBufferView; isUint8Array(value: unknown): value is Uint8Array; isDataView(value: unknown): value is DataView; isArgumentsObject(value: unknown): value is ArrayLike<unknown>; isBoxedPrimitive(value: unknown): value is object; isBooleanObject(value: unknown): value is Boolean; isNumberObject(value: unknown): value is Number; isStringObject(value: unknown): value is String; isSymbolObject(value: unknown): value is Symbol; isBigIntObject(value: unknown): value is BigInt };
    interface NekoInspect {
        (value: unknown): string
        custom: symbol
      }
    type AnyMap = Map<unknown, unknown>
    type AnyWeakMap = WeakMap<object, unknown>
    type NekoCloneSeen = Map<unknown, unknown>
    interface NekoTypedArrayCtor { new (source: unknown): unknown }

}
