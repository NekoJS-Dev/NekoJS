import { types } from 'node:util';
export function invalid(value: unknown): string | null { if (types.isProxy(value)) { const wrong: string = value; return wrong; } return null; }
