/** Demonstrates the distinct guarantees of a raw implementation and its generic interface view. */
public final class RawCycleViews {
    enum Alpha { VALUE }
    enum Beta { VALUE }
    interface Cycle {
        <E extends Enum<E>> E cycle(E value);
    }
    @SuppressWarnings({"rawtypes", "unchecked"})
    static final class RawHost implements Cycle {
        public Enum cycle(Enum value) {
            return Beta.VALUE;
        }
    }
    public static void main(String[] arguments) {
        RawHost host = new RawHost();
        Enum<?> direct = host.<Alpha>cycle(Alpha.VALUE);
        if (direct != Beta.VALUE) throw new AssertionError("Raw implementation result changed");
        System.out.println("RAW-EXPLICIT-TYPE-ARGUMENT-RETAINS-ENUM-RESULT");
        Cycle contract = host;
        try {
            Alpha result = contract.cycle(Alpha.VALUE);
            throw new AssertionError("Expected the interface view's inserted cast to fail: " + result);
        } catch (ClassCastException expected) {
            System.out.println("INTERFACE-VIEW-CAST-CAN-FAIL-FOR-UNCHECKED-RAW-IMPLEMENTATION");
        }
    }
}
