"""Keep the rejected raw-interface overload experiment and both compiler boundaries reproducible."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
out = repo / 'docs/architecture-refactor/evidence/2026-10-24-declaration-prototypes'
assert not out.exists()
result = json.loads((tools / 'raw-interface-overload-result.json').read_text())
assert result['rawFirstOrdinaryCallsExit'] == 0 and result['unchangedRawExplicitGuaranteeExit'] == 2
assert result['javaRejectsRawExplicitPrecisionExit'] == 1 and not result['productionAdopted']
names = ['RawCycleViews.java', 'RawCyclePrecision.java', 'raw-cycle-javac.log', 'raw-cycle-java.log',
    'raw-cycle-invalid-precision.log', 'raw-cycle-invalid-precision-v2.log',
    'raw-interface-overload-prototype.ts', 'raw-interface-overload-tsconfig.json', 'raw-interface-overload-base.log',
    'raw-interface-overload-no-new-precision.ts', 'raw-interface-overload-no-new-precision.json',
    'raw-interface-overload-no-new-precision.log', 'raw-interface-overload-result.json',
    'check-raw-interface-overload-prototype.py', 'seal-raw-interface-prototype.py']
entries = {name: (tools / name).read_bytes() for name in names}
for file in (tools / 'raw-cycle-classes').glob('*.class'):
    entries['classes/' + file.name] = file.read_bytes()
entries['java-version.txt'] = subprocess.check_output(['C:/Program Files/Java/jdk-25.0.2/bin/java.exe', '-version'], stderr=subprocess.STDOUT)
for name in ['common/src/main/java/com/tkisor/nekojs/probe/ir/TypeReflector.java',
             'common/src/main/java/com/tkisor/nekojs/probe/ir/MethodDecl.java']:
    entries['source/' + name] = subprocess.check_output(['git', 'show', '975496d3:' + name])
out.mkdir()
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(out / 'manifest.json').write_text(json.dumps(dict(sourceRevision='975496d3bddf6fc76b206921a1d09207120ca24d',
    typescriptVersion=json.loads((repo / 'node_modules/typescript/package.json').read_text())['version'],
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())}), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size, productionAdopted=False)))
