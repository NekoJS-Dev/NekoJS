"""Check raw-first overload selection and the additional explicit-generic guarantee separately."""
import json
from pathlib import Path
import subprocess

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
def run(name, command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    (tools / (name + '.log')).write_bytes(result.stdout)
    return result.returncode
base = run('raw-interface-overload-base', ['node', 'node_modules/typescript/bin/tsc', '-p', str(tools / 'raw-interface-overload-tsconfig.json')])
assert base == 0
source = (tools / 'raw-interface-overload-prototype.ts').read_text()
source = source.replace('const explicitGenericResult: Alpha = host.cycle<Alpha>(alpha);',
    '// @ts-expect-error A raw Java class method does not promise an Alpha result even with explicit type arguments.\n'
    'const explicitGenericResult: Alpha = host.cycle<Alpha>(alpha);')
(tools / 'raw-interface-overload-no-new-precision.ts').write_text(source, newline='\n')
config = json.loads((tools / 'raw-interface-overload-tsconfig.json').read_text())
config['files'] = ['raw-interface-overload-no-new-precision.ts']
(tools / 'raw-interface-overload-no-new-precision.json').write_text(json.dumps(config, indent=2) + '\n')
negative = run('raw-interface-overload-no-new-precision', ['node', 'node_modules/typescript/bin/tsc', '-p', str(tools / 'raw-interface-overload-no-new-precision.json')])
assert negative == 2
assert 'TS2578' in (tools / 'raw-interface-overload-no-new-precision.log').read_text()
java = 'C:/Program Files/Java/jdk-25.0.2/bin/'
(tools / 'RawCyclePrecision.java').write_text('''class RawCyclePrecision {
    void reject(RawCycleViews.RawHost host) {
        RawCycleViews.Alpha value = host.<RawCycleViews.Alpha>cycle(RawCycleViews.Alpha.VALUE);
    }
}
''', newline='\n')
javac = run('raw-cycle-invalid-precision-v2', [java + 'javac.exe', '-XDrawDiagnostics', '-cp', str(tools / 'raw-cycle-classes'),
    '-d', str(tools / 'raw-cycle-classes'), str(tools / 'RawCyclePrecision.java')])
assert javac != 0
assert 'compiler.err.prob.found.req' in (tools / 'raw-cycle-invalid-precision-v2.log').read_text()
result = dict(rawFirstOrdinaryCallsExit=base, unchangedRawExplicitGuaranteeExit=negative,
    javaRejectsRawExplicitPrecisionExit=javac, productionAdopted=False,
    conclusion='Raw-first ordering retains ordinary raw calls, but the extra generic signature still adds an explicit-generic return guarantee absent from the Java class method.')
(tools / 'raw-interface-overload-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
