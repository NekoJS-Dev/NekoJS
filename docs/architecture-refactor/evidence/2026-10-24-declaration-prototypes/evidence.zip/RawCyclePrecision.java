class RawCyclePrecision {
    void reject(RawCycleViews.RawHost host) {
        RawCycleViews.Alpha value = host.<RawCycleViews.Alpha>cycle(RawCycleViews.Alpha.VALUE);
    }
}
