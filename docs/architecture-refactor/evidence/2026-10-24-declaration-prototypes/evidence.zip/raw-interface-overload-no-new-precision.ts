// Throwaway representation experiment; this is not generated or production output.
declare class HostEnum<T> {
    name(): string;
    compareTo(other: T): number;
}
declare class Alpha extends HostEnum<Alpha> { readonly kind: 'alpha'; }
declare class Beta extends HostEnum<Beta> { readonly kind: 'beta'; }
interface Cycle {
    cycle<E extends HostEnum<E>>(value: E): E;
}
declare class RawHost implements Cycle {
    cycle(value: HostEnum<any>): HostEnum<any>;
    cycle<E extends HostEnum<E>>(value: E): E;
}
declare const host: RawHost;
declare const alpha: Alpha;
declare const beta: Beta;
const direct = host.cycle(alpha);
const rawResult: HostEnum<any> = direct;
// @ts-expect-error The direct class view must retain the raw return guarantee.
const falseDirectPrecision: Alpha = direct;
// @ts-expect-error A raw class result has no enum-specific field.
direct.kind;
const contract: Cycle = host;
const typedResult: Alpha = contract.cycle(alpha);
// @ts-expect-error The interface contract preserves the input enum type.
const falseInterfaceResult: Beta = contract.cycle(alpha);
const extracted = host.cycle;
// @ts-expect-error Extraction followed by direct invocation must still select the raw first overload.
const falseExtractedPrecision: Alpha = extracted(alpha);
const genericFunction: <E extends HostEnum<E>>(value: E) => E = host.cycle;
// @ts-expect-error A raw Java class method does not promise an Alpha result even with explicit type arguments.
const explicitGenericResult: Alpha = host.cycle<Alpha>(alpha);
// @ts-expect-error An explicit generic contract rejects another enum argument.
host.cycle<Alpha>(beta);
void [rawResult, typedResult, genericFunction, explicitGenericResult];
