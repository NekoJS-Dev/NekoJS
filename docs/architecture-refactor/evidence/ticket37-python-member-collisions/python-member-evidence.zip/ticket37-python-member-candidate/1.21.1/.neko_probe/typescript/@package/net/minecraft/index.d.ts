import { $Codec } from "java:com/mojang/serialization";
import { $Enum, $Integer, $Record, $RuntimeException, $StackTraceElement, $String, $StringBuilder, $Throwable } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Collection, $List } from "java:java/util";
import { $Callable } from "java:java/util/concurrent";
import { $Supplier } from "java:java/util/function";
import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $LevelHeightAccessor } from "java:net/minecraft/world/level";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";

export * as advancements from "java:net/minecraft/advancements";
export * as commands from "java:net/minecraft/commands";
export * as core from "java:net/minecraft/core";
export * as data from "java:net/minecraft/data";
export * as nbt from "java:net/minecraft/nbt";
export * as network from "java:net/minecraft/network";
export * as resources from "java:net/minecraft/resources";
export * as server from "java:net/minecraft/server";
export * as sounds from "java:net/minecraft/sounds";
export * as stats from "java:net/minecraft/stats";
export * as tags from "java:net/minecraft/tags";
export * as util from "java:net/minecraft/util";
export * as world from "java:net/minecraft/world";

declare module "java:net/minecraft" {
    export class $BlockUtil$FoundRectangle {
        constructor(arg0: $BlockPos_, arg1: number, arg2: number);
        axis1Size: number;
        axis2Size: number;
        minCorner: $BlockPos;
    }

    export class $ChatFormatting {
        static AQUA: $ChatFormatting;
        static BLACK: $ChatFormatting;
        static BLUE: $ChatFormatting;
        static BOLD: $ChatFormatting;
        static DARK_AQUA: $ChatFormatting;
        static DARK_BLUE: $ChatFormatting;
        static DARK_GRAY: $ChatFormatting;
        static DARK_GREEN: $ChatFormatting;
        static DARK_PURPLE: $ChatFormatting;
        static DARK_RED: $ChatFormatting;
        static GOLD: $ChatFormatting;
        static GRAY: $ChatFormatting;
        static GREEN: $ChatFormatting;
        static ITALIC: $ChatFormatting;
        static LIGHT_PURPLE: $ChatFormatting;
        static OBFUSCATED: $ChatFormatting;
        static RED: $ChatFormatting;
        static RESET: $ChatFormatting;
        static STRIKETHROUGH: $ChatFormatting;
        static UNDERLINE: $ChatFormatting;
        static WHITE: $ChatFormatting;
        static YELLOW: $ChatFormatting;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChatFormatting[];
        static valueOf(name: string): $ChatFormatting;
    }

    export class $CrashReport {
        constructor(arg0: string, arg1: $Throwable);
        get details(): string;
        getDetails(): string;
        get exceptionMessage(): string;
        getExceptionMessage(): string;
        get exception(): $Throwable;
        getException(): $Throwable;
        get saveFile(): $Path;
        getSaveFile(): $Path;
        get systemReport(): $SystemReport;
        getSystemReport(): $SystemReport;
        get title(): string;
        getTitle(): string;
        static forThrowable(arg0: $Throwable, arg1: string): $CrashReport;
        static preload(): void;
        addCategory(arg0: string, arg1: number): $CrashReportCategory;
        addCategory(arg0: string): $CrashReportCategory;
        getDetails(arg0: $StringBuilder): void;
        getFriendlyReport(arg0: $ReportType, arg1: string[]): string;
        getFriendlyReport(arg0: $ReportType): string;
        saveToFile(arg0: string, arg1: $ReportType, arg2: string[]): boolean;
        saveToFile(arg0: string, arg1: $ReportType): boolean;
    }

    export class $CrashReportCategory {
        constructor(arg0: string);
        get stacktrace(): $StackTraceElement[];
        getStacktrace(): $StackTraceElement[];
        static formatLocation(arg0: $LevelHeightAccessor, arg1: number, arg2: number, arg3: number): string;
        static formatLocation(arg0: $LevelHeightAccessor, arg1: number, arg2: number, arg3: number): string;
        static formatLocation(arg0: $LevelHeightAccessor, arg1: $BlockPos_): string;
        static populateBlockDetails(arg0: $CrashReportCategory, arg1: $LevelHeightAccessor, arg2: $BlockPos_, arg3: $BlockState_): void;
        applyStackTrace(arg0: $Throwable): void;
        fillInStackTrace(arg0: number): number;
        getDetails(arg0: $StringBuilder): void;
        setDetailError(arg0: string, arg1: $Throwable): void;
        setDetail(arg0: string, arg1: object): $CrashReportCategory;
        setDetail(arg0: string, arg1: $CrashReportDetail<string>): $CrashReportCategory;
        trimStacktrace(arg0: number): void;
        validateStackTrace(arg0: $StackTraceElement, arg1: $StackTraceElement): boolean;
    }

    export interface $CrashReportDetail<V> extends $Callable {
    }

    export class $ReportType extends $Record {
        constructor(header: string, nuggets: string[]);
        static CHUNK_IO_ERROR: $ReportType;
        static CRASH: $ReportType;
        static NETWORK_PROTOCOL_ERROR: $ReportType;
        static PROFILE: $ReportType;
        static TEST: $ReportType;
        get errorComment(): string;
        getErrorComment(): string;
        appendHeader(arg0: $StringBuilder, arg1: string[]): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        header(): string;
        nuggets(): $List<string>;
        toString(): string;
    }

    export class $ReportedException extends $RuntimeException {
        constructor(arg0: $CrashReport);
        get cause(): $Throwable;
        getCause(): $Throwable;
        get message(): string;
        getMessage(): string;
        get report(): $CrashReport;
        getReport(): $CrashReport;
    }

    export class $SystemReport {
        constructor();
        static BYTES_PER_MEBIBYTE: number;
        static sizeInMiB(arg0: number): number;
        appendToCrashReportString(arg0: $StringBuilder): void;
        setDetail(arg0: string, arg1: string): void;
        setDetail(arg0: string, arg1: $Supplier<string>): void;
        toLineSeparatedString(): string;
    }

    export type $ChatFormatting_ = $ChatFormatting | "AQUA" | "BLACK" | "BLUE" | "BOLD" | "DARK_AQUA" | "DARK_BLUE" | "DARK_GRAY" | "DARK_GREEN" | "DARK_PURPLE" | "DARK_RED" | "GOLD" | "GRAY" | "GREEN" | "ITALIC" | "LIGHT_PURPLE" | "OBFUSCATED" | "RED" | "RESET" | "STRIKETHROUGH" | "UNDERLINE" | "WHITE" | "YELLOW";
}
