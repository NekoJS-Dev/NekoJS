import { $TypeToken } from "java:com/google/common/reflect";
import { $PointFree, $PointFreeRule } from "java:com/mojang/datafixers/functions";
import { $App, $App2 } from "java:com/mojang/datafixers/kinds";
import { $Optic } from "java:com/mojang/datafixers/optics";
import { $Schema } from "java:com/mojang/datafixers/schemas";
import { $Type, $Type$FieldNotFoundException } from "java:com/mojang/datafixers/types";
import { $TaggedChoice$TaggedChoiceType, $TypeTemplate } from "java:com/mojang/datafixers/types/templates";
import { $Either, $Pair } from "java:com/mojang/datafixers/util";
import { $DataResult, $Dynamic, $DynamicOps } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $BitSet, $Collection, $List, $Optional, $Set } from "java:java/util";
import { $Consumer, $Function, $Supplier } from "java:java/util/function";

export * as functions from "java:com/mojang/datafixers/functions";
export * as kinds from "java:com/mojang/datafixers/kinds";
export * as optics from "java:com/mojang/datafixers/optics";
export * as schemas from "java:com/mojang/datafixers/schemas";
export * as types from "java:com/mojang/datafixers/types";
export * as util from "java:com/mojang/datafixers/util";

declare module "java:com/mojang/datafixers" {
    export interface $DSL$TypeReference {
        in(arg0: $Schema): $TypeTemplate;
        typeName(): string;
    }

    export interface $DataFixer {
        getSchema(arg0: number): $Schema;
        update<T>(arg0: $DSL$TypeReference, arg1: $Dynamic<T>, arg2: number, arg3: number): $Dynamic<T>;
    }

    export interface $FamilyOptic<A, B> {
        apply(arg0: number): $TypedOptic<any, any, A, B>;
    }

    export interface $OpticFinder<FT> {
        findType<A>(arg0: $Type<A>, arg1: boolean): $Either<$TypedOptic<A, any, FT, FT>, $Type$FieldNotFoundException>;
        findType<A, FR>(arg0: $Type<A>, arg1: $Type<FR>, arg2: boolean): $Either<$TypedOptic<A, any, FT, FR>, $Type$FieldNotFoundException>;
        inField<GT>(arg0: string, arg1: $Type<GT>): $OpticFinder<FT>;
        type(): $Type<FT>;
    }

    export class $RewriteResult<A, B> extends $Record {
        constructor(view: $View<A, B>, recData: $BitSet);
        static create<A, B>(arg0: $View<A, B>, arg1: $BitSet): $RewriteResult<A, B>;
        static nop<A>(arg0: $Type<A>): $RewriteResult<A, A>;
        compose<C>(arg0: $RewriteResult<C, A>): $RewriteResult<C, B>;
        equals(arg0: object): boolean;
        hashCode(): number;
        recData(): $BitSet;
        toString(): string;
        view(): $View<A, B>;
    }

    export interface $TypeRewriteRule {
        all(arg0: $TypeRewriteRule, arg1: boolean, arg2: boolean): $TypeRewriteRule;
        checkOnce(arg0: $TypeRewriteRule, arg1: $Consumer<$Type<any>>): $TypeRewriteRule;
        everywhere(arg0: $TypeRewriteRule, arg1: $PointFreeRule, arg2: boolean, arg3: boolean): $TypeRewriteRule;
        ifSame<B>(arg0: $Type<B>, arg1: $RewriteResult<B, any>): $TypeRewriteRule;
        nop(): $TypeRewriteRule;
        once(arg0: $TypeRewriteRule): $TypeRewriteRule;
        one(arg0: $TypeRewriteRule): $TypeRewriteRule;
        orElse(arg0: $TypeRewriteRule, arg1: $TypeRewriteRule): $TypeRewriteRule;
        orElse(arg0: $TypeRewriteRule, arg1: $Supplier<$TypeRewriteRule>): $TypeRewriteRule;
        rewrite<A>(arg0: $Type<A>): $Optional<$RewriteResult<A, any>>;
        seq(arg0: $TypeRewriteRule, arg1?: $TypeRewriteRule[]): $TypeRewriteRule;
        seq(arg0: $TypeRewriteRule, arg1: $TypeRewriteRule): $TypeRewriteRule;
        seq(arg0: $TypeRewriteRule[]): $TypeRewriteRule;
    }

    export class $Typed<A> {
        constructor(arg0: $Type<A>, arg1: $DynamicOps<any>, arg2: A);
        get ops(): $DynamicOps<any>;
        getOps(): $DynamicOps<any>;
        get type(): $Type<A>;
        getType(): $Type<A>;
        get value(): A;
        getValue(): A;
        static pair<A, B>(arg0: $Typed<A>, arg1: $Typed<B>): $Typed<$Pair<A, B>>;
        getAllTyped<FT>(arg0: $OpticFinder<FT>): $List<$Typed<FT>>;
        getAll<FT>(arg0: $TypedOptic<A, any, FT, any>): $List<FT>;
        getOptionalTyped<FT>(arg0: $OpticFinder<FT>): $Optional<$Typed<FT>>;
        getOptional<FT>(arg0: $OpticFinder<FT>): $Optional<FT>;
        getOrCreateTyped<FT>(arg0: $OpticFinder<FT>): $Typed<FT>;
        getOrCreate<FT>(arg0: $OpticFinder<FT>): FT;
        getOrDefault<FT>(arg0: $OpticFinder<FT>, arg1: FT): FT;
        getTyped<FT>(arg0: $OpticFinder<FT>): $Typed<FT>;
        get<FT>(arg0: $OpticFinder<FT>): FT;
        inj1<B>(arg0: $Type<B>): $Typed<$Either<A, B>>;
        inj2<B>(arg0: $Type<B>): $Typed<$Either<B, A>>;
        out(): $Typed<A>;
        set<FT>(arg0: $OpticFinder<FT>, arg1: FT): $Typed<any>;
        set<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Typed<FR>): $Typed<any>;
        set<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: FR): $Typed<any>;
        toString(): string;
        updateRecursiveTyped<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: $Function<$Typed<any>, $Typed<any>>): $Typed<any>;
        updateRecursiveTyped<FT>(arg0: $OpticFinder<FT>, arg1: $Function<$Typed<any>, $Typed<any>>): $Typed<any>;
        updateRecursive<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: $Function<FT, FR>): $Typed<any>;
        updateRecursive<FT>(arg0: $OpticFinder<FT>, arg1: $Function<FT, FT>): $Typed<any>;
        updateTyped<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: $Function<$Typed<any>, $Typed<any>>): $Typed<any>;
        updateTyped<FT>(arg0: $OpticFinder<FT>, arg1: $Function<$Typed<any>, $Typed<any>>): $Typed<any>;
        update<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>, arg2: $Function<FT, FR>): $Typed<any>;
        update<FT>(arg0: $OpticFinder<FT>, arg1: $Function<FT, FT>): $Typed<any>;
        write(): $DataResult<$Dynamic<any>>;
    }

    export class $TypedOptic<S, T, A, B> extends $Record {
        constructor(arg0: $TypeToken<$K1>, arg1: $Type<S>, arg2: $Type<T>, arg3: $Type<A>, arg4: $Type<B>, arg5: $Optic<any, S, T, A, B>);
        constructor(arg0: $TypeToken<$K1>[], arg1: $Type<S>, arg2: $Type<T>, arg3: $Type<A>, arg4: $Type<B>, arg5: $Optic<any, S, T, A, B>);
        constructor(bounds: $TypeToken<$K1>[], elements: $TypedOptic$Element<any, any, any, any>[]);
        static adapter<S, T>(arg0: $Type<S>, arg1: $Type<T>): $TypedOptic<S, T, S, T>;
        static compoundListElements<K, V, V2>(arg0: $Type<K>, arg1: $Type<V>, arg2: $Type<V2>): $TypedOptic<$List<$Pair<K, V>>, $List<$Pair<K, V2>>, V, V2>;
        static compoundListKeys<K, V, K2>(arg0: $Type<K>, arg1: $Type<K2>, arg2: $Type<V>): $TypedOptic<$List<$Pair<K, V>>, $List<$Pair<K2, V>>, K, K2>;
        static inj1<F, G, F2>(arg0: $Type<F>, arg1: $Type<G>, arg2: $Type<F2>): $TypedOptic<$Either<F, G>, $Either<F2, G>, F, F2>;
        static inj2<F, G, G2>(arg0: $Type<F>, arg1: $Type<G>, arg2: $Type<G2>): $TypedOptic<$Either<F, G>, $Either<F, G2>, G, G2>;
        static instanceOf<Proof2>(arg0: $TypeToken<$K1>[], arg1: $TypeToken<Proof2>): boolean;
        static list<A, B>(arg0: $Type<A>, arg1: $Type<B>): $TypedOptic<$List<A>, $List<B>, A, B>;
        static proj1<F, G, F2>(arg0: $Type<F>, arg1: $Type<G>, arg2: $Type<F2>): $TypedOptic<$Pair<F, G>, $Pair<F2, G>, F, F2>;
        static proj2<F, G, G2>(arg0: $Type<F>, arg1: $Type<G>, arg2: $Type<G2>): $TypedOptic<$Pair<F, G>, $Pair<F, G2>, G, G2>;
        static tagged<K, A, B>(arg0: $TaggedChoice$TaggedChoiceType<K>, arg1: K, arg2: $Type<A>, arg3: $Type<B>): $TypedOptic<$Pair<K, any>, $Pair<K, any>, A, B>;
        aType(): $Type<A>;
        apply<P, Proof2>(arg0: $TypeToken<Proof2>, arg1: $App<Proof2, P>, arg2: $App2<P, A, B>): $App2<P, S, T>;
        bType(): $Type<B>;
        bounds(): $Set<$TypeToken<$K1>>;
        castOuterUnchecked<S2, T2>(arg0: $Type<S2>, arg1: $Type<T2>): $TypedOptic<S2, T2, A, B>;
        castOuter(arg0: $Type<S>, arg1: $Type<T>): $TypedOptic<S, T, A, B>;
        compose<A1, B1>(arg0: $TypedOptic<A, B, A1, B1>): $TypedOptic<S, T, A1, B1>;
        elements(): $List<$TypedOptic$Element<any, any, any, any>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        innermost(): $Optic<any, any, any, A, B>;
        outermost(): $Optic<any, S, T, any, any>;
        sType(): $Type<S>;
        tType(): $Type<T>;
        toString(): string;
        upCast<Proof2>(arg0: $TypeToken<Proof2>): $Optional<$Optic<any, S, T, A, B>>;
    }

    export class $View<A, B> extends $Record implements $App2 {
        constructor(function_: $PointFree<$Function<A, B>>);
        get nop(): boolean;
        isNop(): boolean;
        static create<A, B>(arg0: $PointFree<$Function<A, B>>): $View<A, B>;
        static create<A, B>(arg0: string, arg1: $Type<A>, arg2: $Type<B>, arg3: $Function<$DynamicOps<any>, $Function<A, B>>): $View<A, B>;
        static nopView<A>(arg0: $Type<A>): $View<A, A>;
        compose<C>(arg0: $View<C, A>): $View<C, B>;
        equals(arg0: object): boolean;
        flatMap<C>(arg0: $Function<$Type<B>, $View<B, C>>): $View<A, C>;
        funcType(): $Type<$Function<A, B>>;
        function(): $PointFree<$Function<A, B>>;
        hashCode(): number;
        newType(): $Type<B>;
        rewriteOrNop(arg0: $PointFreeRule): $View<A, B>;
        rewrite(arg0: $PointFreeRule): $Optional<$View<A, B>>;
        toString(): string;
        type(): $Type<A>;
    }

}
