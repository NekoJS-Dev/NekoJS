import { $Gson, $JsonElement } from "java:com/google/gson";
import { $BufferedReader, $InputStream } from "java:java/io";
import { $AutoCloseable, $String, $Void } from "java:java/lang";
import { $Path } from "java:java/nio/file";
import { $Collection, $List, $Map, $Optional, $Set } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $ZipEntry, $ZipFile } from "java:java/util/zip";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $PackResources } from "java:net/minecraft/server/packs";
import { $MetadataSectionSerializer } from "java:net/minecraft/server/packs/metadata";
import { $KnownPack } from "java:net/minecraft/server/packs/repository";
import { $ProfilerFiller } from "java:net/minecraft/util/profiling";
import { $ContextAwareReloadListener } from "java:net/neoforged/neoforge/resource";

declare module "java:net/minecraft/server/packs/resources" {
    export interface $CloseableResourceManager extends $ResourceManager, $AutoCloseable {
        close(): void;
    }

    export interface $IoSupplier<T> {
        create(arg0: string): $IoSupplier<$InputStream>;
        create(arg0: $ZipFile, arg1: $ZipEntry): $IoSupplier<$InputStream>;
        get(): T;
    }

    export interface $PreparableReloadListener {
        getName(): string;
        reload(arg0: $PreparableReloadListener$PreparationBarrier, arg1: $ResourceManager, arg2: $ProfilerFiller, arg3: $ProfilerFiller, arg4: $Executor, arg5: $Executor): $CompletableFuture<void>;
    }

    export interface $PreparableReloadListener$PreparationBarrier {
        wait<T>(arg0: T): $CompletableFuture<T>;
    }

    export class $Resource {
        constructor(arg0: $PackResources, arg1: $IoSupplier<$InputStream>);
        constructor(arg0: $PackResources, arg1: $IoSupplier<$InputStream>, arg2: $IoSupplier<$ResourceMetadata>);
        knownPackInfo(): $Optional<$KnownPack>;
        metadata(): $ResourceMetadata;
        openAsReader(): $BufferedReader;
        open(): $InputStream;
        sourcePackId(): string;
        source(): $PackResources;
    }

    export interface $ResourceManager extends $ResourceProvider {
        getNamespaces(): $Set<string>;
        getResourceStack(arg0: $ResourceLocation_): $List<$Resource>;
        listPacks(): $Stream<$PackResources>;
        listResourceStacks(arg0: string, arg1: $Predicate<$ResourceLocation_>): $Map<$ResourceLocation, $List<$Resource>>;
        listResources(arg0: string, arg1: $Predicate<$ResourceLocation_>): $Map<$ResourceLocation, $Resource>;
    }

    export interface $ResourceMetadata {
        copySections(arg0: $MetadataSectionSerializer<any>[]): $ResourceMetadata;
        fromJsonStream(arg0: $InputStream): $ResourceMetadata;
        getSection<T>(arg0: $MetadataSectionSerializer<T>): $Optional<T>;
        static EMPTY: $ResourceMetadata;
        static EMPTY_SUPPLIER: $IoSupplier<$ResourceMetadata>;
    }

    export interface $ResourceProvider {
        fromMap(arg0: { [key: $ResourceLocation_]: $Resource }): $ResourceProvider;
        getResourceOrThrow(arg0: $ResourceLocation_): $Resource;
        getResource(arg0: $ResourceLocation_): $Optional<$Resource>;
        openAsReader(arg0: $ResourceLocation_): $BufferedReader;
        open(arg0: $ResourceLocation_): $InputStream;
        static EMPTY: $ResourceProvider;
    }

    export class $SimpleJsonResourceReloadListener extends $SimplePreparableReloadListener {
        constructor(arg0: $Gson, arg1: string);
        static scanDirectory(arg0: $ResourceManager, arg1: string, arg2: $Gson, arg3: { [key: $ResourceLocation_]: $JsonElement }): void;
    }

    export class $SimplePreparableReloadListener<T> extends $ContextAwareReloadListener implements $PreparableReloadListener {
        constructor();
        reload(arg0: $PreparableReloadListener$PreparationBarrier, arg1: $ResourceManager, arg2: $ProfilerFiller, arg3: $ProfilerFiller, arg4: $Executor, arg5: $Executor): $CompletableFuture<void>;
    }

}
