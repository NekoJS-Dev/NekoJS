import { $InputStream } from "java:java/io";
import { $AutoCloseable, $Enum, $Record, $String } from "java:java/lang";
import { $Optional, $Set } from "java:java/util";
import { $BiConsumer } from "java:java/util/function";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $MetadataSectionSerializer } from "java:net/minecraft/server/packs/metadata";
import { $KnownPack, $Pack$Position, $Pack$Position_, $PackSource } from "java:net/minecraft/server/packs/repository";
import { $IoSupplier } from "java:net/minecraft/server/packs/resources";
import { $StringRepresentable } from "java:net/minecraft/util";
import { $IPackResourcesExtension } from "java:net/neoforged/neoforge/common/extensions";

export * as metadata from "java:net/minecraft/server/packs/metadata";
export * as repository from "java:net/minecraft/server/packs/repository";
export * as resources from "java:net/minecraft/server/packs/resources";

declare module "java:net/minecraft/server/packs" {
    export class $PackLocationInfo extends $Record {
        constructor(arg0: string, arg1: $Component_, arg2: $PackSource, arg3: $Optional<$KnownPack>);
        createChatLink(arg0: boolean, arg1: $Component_): $Component;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): string;
        knownPackInfo(): $Optional<$KnownPack>;
        source(): $PackSource;
        title(): $Component;
        toString(): string;
    }

    export interface $PackResources extends $AutoCloseable, $IPackResourcesExtension {
        close(): void;
        getMetadataSection<T>(arg0: $MetadataSectionSerializer<T>): T;
        getNamespaces(arg0: $PackType_): $Set<string>;
        getResource(arg0: $PackType_, arg1: $ResourceLocation_): $IoSupplier<$InputStream>;
        getRootResource(arg0?: string[]): $IoSupplier<$InputStream>;
        knownPackInfo(): $Optional<$KnownPack>;
        listResources(arg0: $PackType_, arg1: string, arg2: string, arg3: $PackResources$ResourceOutput): void;
        location(): $PackLocationInfo;
        packId(): string;
        static METADATA_EXTENSION: string;
        static PACK_META: string;
    }

    export interface $PackResources$ResourceOutput extends $BiConsumer {
    }

    export class $PackSelectionConfig extends $Record {
        constructor(arg0: boolean, arg1: $Pack$Position_, arg2: boolean);
        defaultPosition(): $Pack$Position;
        equals(arg0: object): boolean;
        fixedPosition(): boolean;
        hashCode(): number;
        required(): boolean;
        toString(): string;
    }

    export class $PackType {
        static CLIENT_RESOURCES: $PackType;
        static SERVER_DATA: $PackType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PackType[];
        static valueOf(name: string): $PackType;
    }

    export type $PackType_ = $PackType | "CLIENT_RESOURCES" | "SERVER_DATA";
}
