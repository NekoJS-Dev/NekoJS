import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $NekoWrapper } from "java:com/tkisor/nekojs/wrapper";
import { $PersistentDataJS } from "java:com/tkisor/nekojs/wrapper/pdata";
import { $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Item, $ItemStack, $ItemStack_, $Item_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_ } from "java:net/minecraft/world/item/crafting";
import { $SizedIngredient, $SizedIngredient_ } from "java:net/neoforged/neoforge/common/crafting";

declare module "java:com/tkisor/nekojs/wrapper/item" {
    export class $IngredientJS implements $NekoWrapper {
        constructor();
        constructor(ids?: string[]);
        constructor(ingredient: $Ingredient_);
        get items(): $ItemStack[];
        getItems(): $ItemStack[];
        get empty(): boolean;
        isEmpty(): boolean;
        and(ingredient: $Ingredient_): $IngredientJS;
        asIngredient(): $IngredientJS;
        asStack(): $SizedIngredientJS;
        displayStacks(): $List<$ItemStack>;
        except(ingredient: $Ingredient_): $IngredientJS;
        first(): $ItemStack;
        intersect(ingredient: $Ingredient_): $IngredientJS;
        matches(stack: $ItemStack_): boolean;
        matches(ingredient: $Ingredient_): boolean;
        or(id: $NekoId): $IngredientJS;
        or(other: $IngredientJS): $IngredientJS;
        or(id: string): $IngredientJS;
        or(stack: $ItemStack_): $IngredientJS;
        or(item: $Item_): $IngredientJS;
        or(ingredient: $Ingredient_): $IngredientJS;
        stacks(): $List<$ItemStack>;
        subtract(ingredient: $Ingredient_): $IngredientJS;
        test(stack: $ItemStack_): boolean;
        unwrap(): $Ingredient;
        withCount(count: number): $SizedIngredientJS;
    }

    export class $PersistentDataJS extends $PersistentDataJS {
        constructor(rawStack: $ItemStack_);
    }

    /** An item ingredient paired with a count, for recipe inputs like '4 sticks'. */
    export class $SizedIngredientJS implements $NekoWrapper {
        /**
         * Creates a sized ingredient from an ingredient and a count.
         * @param ingredient the ingredient to match
         * @param count required item count; must be positive
         */
        constructor(ingredient: $Ingredient_, count: number);
        /**
         * Gets the required item count.
         * @returns the count; always positive
         */
        count(): number;
        /**
         * Gets the underlying ingredient.
         * @returns the wrapped Ingredient
         */
        ingredient(): $Ingredient;
        /**
         * Unwraps to the NeoForge SizedIngredient.
         * @returns a new SizedIngredient instance built from this wrapper's ingredient and count
         */
        unwrap(): $SizedIngredient;
    }

}
