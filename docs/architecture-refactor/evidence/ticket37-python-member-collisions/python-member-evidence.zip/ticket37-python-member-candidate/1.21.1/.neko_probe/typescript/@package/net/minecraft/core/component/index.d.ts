import { $Codec, $DataResult, $DynamicOps } from "java:com/mojang/serialization";
import { $Iterable, $Record, $String } from "java:java/lang";
import { $Iterator, $Map, $Map$Entry, $Optional, $Set } from "java:java/util";
import { $Predicate } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $IDataComponentHolderExtension, $IDataComponentMapBuilderExtensions } from "java:net/neoforged/neoforge/common/extensions";

declare module "java:net/minecraft/core/component" {
    export interface $DataComponentHolder extends $IDataComponentHolderExtension {
        getComponents(): $DataComponentMap;
        getOrDefault<T>(arg0: $DataComponentType<T>, arg1: T): T;
        get<T>(arg0: $DataComponentType<T>): T;
        has(arg0: $DataComponentType<any>): boolean;
    }

    export interface $DataComponentMap extends $Iterable {
        builder(): $DataComponentMap$Builder;
        composite(arg0: $DataComponentMap, arg1: $DataComponentMap): $DataComponentMap;
        filter(arg0: $Predicate<$DataComponentType<any>>): $DataComponentMap;
        getOrDefault<T>(arg0: $DataComponentType<T>, arg1: T): T;
        getTyped<T>(arg0: $DataComponentType<T>): $TypedDataComponent<T>;
        get<T>(arg0: $DataComponentType<T>): T;
        has(arg0: $DataComponentType<any>): boolean;
        isEmpty(): boolean;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        makeCodecFromMap(arg0: $Codec<{ [key: $DataComponentType<any>]: object }>): $Codec<$DataComponentMap>;
        makeCodec(arg0: $Codec<$DataComponentType<any>>): $Codec<$DataComponentMap>;
        size(): number;
        stream(): $Stream<$TypedDataComponent<any>>;
        static CODEC: $Codec<$DataComponentMap>;
        static EMPTY: $DataComponentMap;
    }

    export class $DataComponentMap$Builder implements $IDataComponentMapBuilderExtensions {
        addAll(arg0: $DataComponentMap): $DataComponentMap$Builder;
        build(): $DataComponentMap;
        set<T>(arg0: $DataComponentType<T>, arg1: T): $DataComponentMap$Builder;
    }

    export class $DataComponentPatch {
        static CODEC: $Codec<$DataComponentPatch>;
        static EMPTY: $DataComponentPatch;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentPatch>;
        get empty(): boolean;
        isEmpty(): boolean;
        static builder(): $DataComponentPatch$Builder;
        entrySet(): $Set<$Map$Entry<$DataComponentType<any>, $Optional<any>>>;
        equals(arg0: object): boolean;
        forget(arg0: $Predicate<$DataComponentType<any>>): $DataComponentPatch;
        get<T>(arg0: $DataComponentType<T>): $Optional<T>;
        hashCode(): number;
        size(): number;
        split(): $DataComponentPatch$SplitResult;
        toString(): string;
    }

    export class $DataComponentPatch$Builder {
        build(): $DataComponentPatch;
        remove<T>(arg0: $DataComponentType<T>): $DataComponentPatch$Builder;
        set<T>(arg0: $DataComponentType<T>, arg1: T): $DataComponentPatch$Builder;
        set<T>(arg0: $TypedDataComponent<T>): $DataComponentPatch$Builder;
    }

    export class $DataComponentPatch$SplitResult extends $Record {
        constructor(added: $DataComponentMap, removed: $DataComponentType<any>[]);
        static EMPTY: $DataComponentPatch$SplitResult;
        added(): $DataComponentMap;
        equals(arg0: object): boolean;
        hashCode(): number;
        removed(): $Set<$DataComponentType<any>>;
        toString(): string;
    }

    export class $DataComponentPredicate implements $Predicate {
        static CODEC: $Codec<$DataComponentPredicate>;
        static EMPTY: $DataComponentPredicate;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentPredicate>;
        static allOf(arg0: $DataComponentMap): $DataComponentPredicate;
        static builder(): $DataComponentPredicate$Builder;
        alwaysMatches(): boolean;
        asPatch(): $DataComponentPatch;
        equals(arg0: object): boolean;
        hashCode(): number;
        test(arg0: $DataComponentHolder): boolean;
        test(arg0: $DataComponentMap): boolean;
        toString(): string;
    }

    export class $DataComponentPredicate$Builder {
        build(): $DataComponentPredicate;
        expect<T>(arg0: $DataComponentType<any>, arg1: T): $DataComponentPredicate$Builder;
    }

    export interface $DataComponentType<T> {
        builder<T>(): $DataComponentType$Builder<T>;
        codecOrThrow(): $Codec<T>;
        codec(): $Codec<T>;
        isTransient(): boolean;
        streamCodec(): $StreamCodec<any, T>;
        static CODEC: $Codec<$DataComponentType<any>>;
        static PERSISTENT_CODEC: $Codec<$DataComponentType<any>>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $DataComponentType<any>>;
        static VALUE_MAP_CODEC: $Codec<$Map<$DataComponentType<any>, object>>;
    }

    export class $DataComponentType$Builder<T> {
        constructor();
        build(): $DataComponentType<T>;
        cacheEncoding(): $DataComponentType$Builder<T>;
        networkSynchronized(arg0: $StreamCodec<any, T>): $DataComponentType$Builder<T>;
        persistent(arg0: $Codec<T>): $DataComponentType$Builder<T>;
    }

    export class $PatchedDataComponentMap implements $DataComponentMap {
        constructor(arg0: $DataComponentMap);
        get patchEmpty(): boolean;
        isPatchEmpty(): boolean;
        static fromPatch(arg0: $DataComponentMap, arg1: $DataComponentPatch): $PatchedDataComponentMap;
        applyPatch(arg0: $DataComponentPatch): void;
        asPatch(): $DataComponentPatch;
        copy(): $PatchedDataComponentMap;
        equals(arg0: object): boolean;
        get<T>(arg0: $DataComponentType<T>): T;
        hashCode(): number;
        iterator(): $Iterator<$TypedDataComponent<any>>;
        keySet(): $Set<$DataComponentType<any>>;
        remove<T>(arg0: $DataComponentType<T>): T;
        restorePatch(arg0: $DataComponentPatch): void;
        set<T>(arg0: $DataComponentType<any>, arg1: T): T;
        size(): number;
        toString(): string;
    }

    export class $TypedDataComponent<T> extends $Record {
        constructor(arg0: $DataComponentType<T>, arg1: T);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $TypedDataComponent<any>>;
        static createUnchecked<T>(arg0: $DataComponentType<T>, arg1: object): $TypedDataComponent<T>;
        applyTo(arg0: $PatchedDataComponentMap): void;
        encodeValue<D>(arg0: $DynamicOps<D>): $DataResult<D>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        type(): $DataComponentType<T>;
        value(): T;
    }

}
