import { $StringReader } from "java:com/mojang/brigadier";
import { $DynamicCommandExceptionType, $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Codec } from "java:com/mojang/serialization";
import { $Double, $Record, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Function, $Supplier } from "java:java/util/function";

declare module "java:net/minecraft/advancements/critereon" {
    export interface $MinMaxBounds<T extends number> {
        createCodec<T, R>(arg0: $Codec<T>, arg1: $MinMaxBounds$BoundsFactory<T, R>): $Codec<R>;
        fromReader<T, R>(arg0: $StringReader, arg1: $MinMaxBounds$BoundsFromReaderFactory<T, R>, arg2: $Function<string, T>, arg3: $Supplier<$DynamicCommandExceptionType>, arg4: $Function<T, T>): R;
        isAny(): boolean;
        max(): $Optional<T>;
        min(): $Optional<T>;
        unwrapPoint(): $Optional<T>;
        static ERROR_EMPTY: $SimpleCommandExceptionType;
        static ERROR_SWAPPED: $SimpleCommandExceptionType;
    }

    export interface $MinMaxBounds$BoundsFactory<T extends number, R extends $MinMaxBounds<T>> {
        create(arg0: $Optional<T>, arg1: $Optional<T>): R;
    }

    export interface $MinMaxBounds$BoundsFromReaderFactory<T extends number, R extends $MinMaxBounds<T>> {
        create(arg0: $StringReader, arg1: $Optional<T>, arg2: $Optional<T>): R;
    }

    export class $MinMaxBounds$Doubles extends $Record implements $MinMaxBounds {
        constructor(arg0: $Optional<number>, arg1: $Optional<number>, arg2: $Optional<number>, arg3: $Optional<number>);
        static ANY: $MinMaxBounds$Doubles;
        static CODEC: $Codec<$MinMaxBounds$Doubles>;
        static atLeast(arg0: number): $MinMaxBounds$Doubles;
        static atMost(arg0: number): $MinMaxBounds$Doubles;
        static between(arg0: number, arg1: number): $MinMaxBounds$Doubles;
        static exactly(arg0: number): $MinMaxBounds$Doubles;
        static fromReader(arg0: $StringReader, arg1: $Function<number, number>): $MinMaxBounds$Doubles;
        static fromReader(arg0: $StringReader): $MinMaxBounds$Doubles;
        equals(arg0: object): boolean;
        hashCode(): number;
        matchesSqr(arg0: number): boolean;
        matches(arg0: number): boolean;
        maxSq(): $Optional<number>;
        max(): $Optional<number>;
        minSq(): $Optional<number>;
        min(): $Optional<number>;
        toString(): string;
    }

}
