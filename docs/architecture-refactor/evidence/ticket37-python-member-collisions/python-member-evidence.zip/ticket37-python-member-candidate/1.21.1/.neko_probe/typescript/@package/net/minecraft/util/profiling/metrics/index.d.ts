import { $Enum, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $Consumer, $DoubleSupplier, $ToDoubleFunction } from "java:java/util/function";

declare module "java:net/minecraft/util/profiling/metrics" {
    export class $MetricCategory {
        static CHUNK_RENDERING: $MetricCategory;
        static CHUNK_RENDERING_DISPATCHING: $MetricCategory;
        static CPU: $MetricCategory;
        static EVENT_LOOPS: $MetricCategory;
        static GPU: $MetricCategory;
        static JVM: $MetricCategory;
        static MAIL_BOXES: $MetricCategory;
        static PATH_FINDING: $MetricCategory;
        static TICK_LOOP: $MetricCategory;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $MetricCategory[];
        static valueOf(name: string): $MetricCategory;
    }

    export class $MetricSampler {
        get category(): $MetricCategory;
        getCategory(): $MetricCategory;
        get name(): string;
        getName(): string;
        static builder<T>(arg0: string, arg1: $MetricCategory_, arg2: $ToDoubleFunction<T>, arg3: T): $MetricSampler$MetricSamplerBuilder<T>;
        static create<T>(arg0: string, arg1: $MetricCategory_, arg2: T, arg3: $ToDoubleFunction<T>): $MetricSampler;
        static create(arg0: string, arg1: $MetricCategory_, arg2: $DoubleSupplier): $MetricSampler;
        equals(arg0: object): boolean;
        hashCode(): number;
        onEndTick(arg0: number): void;
        onFinished(): void;
        onStartTick(): void;
        result(): $MetricSampler$SamplerResult;
        triggersThreshold(): boolean;
    }

    export class $MetricSampler$MetricSamplerBuilder<T> {
        constructor(arg0: string, arg1: $MetricCategory_, arg2: $ToDoubleFunction<T>, arg3: T);
        build(): $MetricSampler;
        withBeforeTick(arg0: $Consumer<T>): $MetricSampler$MetricSamplerBuilder<T>;
        withThresholdAlert(arg0: $MetricSampler$ThresholdTest): $MetricSampler$MetricSamplerBuilder<T>;
    }

    export class $MetricSampler$SamplerResult {
        constructor(arg0: number, arg1: number, arg2: $Int2DoubleMap);
        get firstTick(): number;
        getFirstTick(): number;
        get lastTick(): number;
        getLastTick(): number;
        valueAtTick(arg0: number): number;
    }

    export interface $ProfilerMeasured {
        profiledMetrics(): $List<$MetricSampler>;
    }

    export type $MetricCategory_ = $MetricCategory | "CHUNK_RENDERING" | "CHUNK_RENDERING_DISPATCHING" | "CPU" | "EVENT_LOOPS" | "GPU" | "JVM" | "MAIL_BOXES" | "PATH_FINDING" | "TICK_LOOP";
}
