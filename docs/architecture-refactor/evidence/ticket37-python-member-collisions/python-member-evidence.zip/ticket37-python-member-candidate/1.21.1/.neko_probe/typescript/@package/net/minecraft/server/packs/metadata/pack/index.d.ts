import { $Codec } from "java:com/mojang/serialization";
import { $Integer, $Record, $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $MetadataSectionType } from "java:net/minecraft/server/packs/metadata";
import { $InclusiveRange } from "java:net/minecraft/util";

declare module "java:net/minecraft/server/packs/metadata/pack" {
    export class $PackMetadataSection extends $Record {
        constructor(arg0: $Component_, arg1: number);
        constructor(description: $Component_, packFormat: number, supportedFormats: $Optional<$InclusiveRange<number>>);
        static CODEC: $Codec<$PackMetadataSection>;
        static TYPE: $MetadataSectionType<$PackMetadataSection>;
        description(): $Component;
        equals(arg0: object): boolean;
        hashCode(): number;
        packFormat(): number;
        supportedFormats(): $Optional<$InclusiveRange<number>>;
        toString(): string;
    }

}
