import { $Type } from "java:com/mojang/datafixers/types";
import { $DynamicOps } from "java:com/mojang/serialization";
import { $String } from "java:java/lang";
import { $Optional } from "java:java/util";
import { $Function } from "java:java/util/function";

declare module "java:com/mojang/datafixers/functions" {
    export class $PointFree<T> {
        constructor();
        static indent(arg0: number): string;
        evalCached(): $Function<$DynamicOps<any>, T>;
        eval(): $Function<$DynamicOps<any>, T>;
        toString(arg0: number): string;
        toString(): string;
        type(): $Type<T>;
    }

    export interface $PointFreeRule {
        all(arg0: $PointFreeRule): $PointFreeRule;
        choice(arg0?: $PointFreeRule[]): $PointFreeRule;
        everywhere(arg0: $PointFreeRule, arg1: $PointFreeRule): $PointFreeRule;
        many(arg0: $PointFreeRule): $PointFreeRule;
        nop(): $PointFreeRule;
        once(arg0: $PointFreeRule): $PointFreeRule;
        one(arg0: $PointFreeRule): $PointFreeRule;
        rewriteOrNop<A>(arg0: $PointFree<A>): $PointFree<A>;
        rewrite<A>(arg0: $PointFree<A>): $Optional<$PointFree<A>>;
        seq(arg0?: $PointFreeRule[]): $PointFreeRule;
    }

}
