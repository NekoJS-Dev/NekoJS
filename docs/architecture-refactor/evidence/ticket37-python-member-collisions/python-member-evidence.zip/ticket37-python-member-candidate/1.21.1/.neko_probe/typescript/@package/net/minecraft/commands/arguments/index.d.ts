import { $Enum, $Record, $String } from "java:java/lang";
import { $List } from "java:java/util";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $FriendlyByteBuf } from "java:net/minecraft/network";
import { $MessageSignature, $SignableCommand } from "java:net/minecraft/network/chat";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

export * as selector from "java:net/minecraft/commands/arguments/selector";

declare module "java:net/minecraft/commands/arguments" {
    export class $ArgumentSignatures extends $Record {
        constructor(arg0: $ArgumentSignatures$Entry[]);
        constructor(arg0: $FriendlyByteBuf);
        static EMPTY: $ArgumentSignatures;
        static signCommand(arg0: $SignableCommand<any>, arg1: $ArgumentSignatures$Signer): $ArgumentSignatures;
        entries(): $List<$ArgumentSignatures$Entry>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $ArgumentSignatures$Entry extends $Record {
        constructor(arg0: string, arg1: $MessageSignature);
        constructor(arg0: $FriendlyByteBuf);
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): string;
        signature(): $MessageSignature;
        toString(): string;
        write(arg0: $FriendlyByteBuf): void;
    }

    export interface $ArgumentSignatures$Signer {
        sign(arg0: string): $MessageSignature;
    }

    export class $EntityAnchorArgument$Anchor {
        static EYES: $EntityAnchorArgument$Anchor;
        static FEET: $EntityAnchorArgument$Anchor;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $EntityAnchorArgument$Anchor[];
        static valueOf(name: string): $EntityAnchorArgument$Anchor;
    }

    export type $EntityAnchorArgument$Anchor_ = $EntityAnchorArgument$Anchor | "EYES" | "FEET";
}
