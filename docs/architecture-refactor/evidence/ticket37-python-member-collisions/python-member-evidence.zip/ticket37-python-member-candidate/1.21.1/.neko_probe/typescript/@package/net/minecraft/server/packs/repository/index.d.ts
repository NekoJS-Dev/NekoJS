import { $ByteBuf } from "java:io/netty/buffer";
import { $Enum, $Integer, $Record, $String } from "java:java/lang";
import { $Collection, $List } from "java:java/util";
import { $Consumer, $Function, $UnaryOperator } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $PackLocationInfo, $PackResources, $PackSelectionConfig, $PackType, $PackType_ } from "java:net/minecraft/server/packs";
import { $PackMetadataSection } from "java:net/minecraft/server/packs/metadata/pack";
import { $InclusiveRange } from "java:net/minecraft/util";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";

declare module "java:net/minecraft/server/packs/repository" {
    export class $KnownPack extends $Record {
        constructor(arg0: string, arg1: string, arg2: string);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $KnownPack>;
        static VANILLA_NAMESPACE: string;
        get vanilla(): boolean;
        isVanilla(): boolean;
        static vanilla(arg0: string): $KnownPack;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): string;
        namespace(): string;
        toString(): string;
        version(): string;
    }

    export class $Pack {
        constructor(arg0: $PackLocationInfo, arg1: $Pack$ResourcesSupplier, arg2: $Pack$Metadata, arg3: $PackSelectionConfig);
        get children(): $List<$Pack>;
        getChildren(): $List<$Pack>;
        get compatibility(): $PackCompatibility;
        getCompatibility(): $PackCompatibility;
        get defaultPosition(): $Pack$Position;
        getDefaultPosition(): $Pack$Position;
        get description(): $Component;
        getDescription(): $Component;
        get id(): string;
        getId(): string;
        get packSource(): $PackSource;
        getPackSource(): $PackSource;
        get requestedFeatures(): $FeatureFlagSet;
        getRequestedFeatures(): $FeatureFlagSet;
        get title(): $Component;
        getTitle(): $Component;
        get fixedPosition(): boolean;
        isFixedPosition(): boolean;
        get hidden(): boolean;
        isHidden(): boolean;
        get required(): boolean;
        isRequired(): boolean;
        static getDeclaredPackVersions(arg0: string, arg1: $PackMetadataSection): $InclusiveRange<number>;
        static readMetaAndCreate(arg0: $PackLocationInfo, arg1: $Pack$ResourcesSupplier, arg2: $PackType_, arg3: $PackSelectionConfig): $Pack;
        static readPackMetadata(arg0: $PackLocationInfo, arg1: $Pack$ResourcesSupplier, arg2: number): $Pack$Metadata;
        equals(arg0: object): boolean;
        getChatLink(arg0: boolean): $Component;
        hashCode(): number;
        hidden(): $Pack;
        location(): $PackLocationInfo;
        open(): $PackResources;
        selectionConfig(): $PackSelectionConfig;
        streamSelfAndChildren(): $Stream<$Pack>;
        withChildren(arg0: $Pack[]): $Pack;
    }

    export class $Pack$Metadata extends $Record {
        constructor(arg0: $Component_, arg1: $PackCompatibility_, arg2: $FeatureFlagSet, arg3: string[]);
        constructor(description: $Component_, compatibility: $PackCompatibility_, requestedFeatures: $FeatureFlagSet, overlays: string[], isHidden: boolean);
        get hidden(): boolean;
        isHidden(): boolean;
        compatibility(): $PackCompatibility;
        description(): $Component;
        equals(arg0: object): boolean;
        hashCode(): number;
        overlays(): $List<string>;
        requestedFeatures(): $FeatureFlagSet;
        toString(): string;
    }

    export class $Pack$Position {
        static BOTTOM: $Pack$Position;
        static TOP: $Pack$Position;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Pack$Position[];
        static valueOf(name: string): $Pack$Position;
    }

    export interface $Pack$ResourcesSupplier {
        openFull(arg0: $PackLocationInfo, arg1: $Pack$Metadata): $PackResources;
        openPrimary(arg0: $PackLocationInfo): $PackResources;
    }

    export class $PackCompatibility {
        static COMPATIBLE: $PackCompatibility;
        static TOO_NEW: $PackCompatibility;
        static TOO_OLD: $PackCompatibility;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $PackCompatibility[];
        static valueOf(name: string): $PackCompatibility;
    }

    export class $PackRepository {
        constructor(arg0?: $RepositorySource[]);
        get availableIds(): $Collection<string>;
        getAvailableIds(): $Collection<string>;
        get availablePacks(): $Collection<$Pack>;
        getAvailablePacks(): $Collection<$Pack>;
        get requestedFeatureFlags(): $FeatureFlagSet;
        getRequestedFeatureFlags(): $FeatureFlagSet;
        get selectedIds(): $Collection<string>;
        getSelectedIds(): $Collection<string>;
        get selectedPacks(): $Collection<$Pack>;
        getSelectedPacks(): $Collection<$Pack>;
        static displayPackList(arg0: $Pack[]): string;
        addPackFinder(arg0: $RepositorySource): void;
        addPack(arg0: string): boolean;
        getPack(arg0: string): $Pack;
        isAvailable(arg0: string): boolean;
        openAllSelected(): $List<$PackResources>;
        rebuildSelected(arg0: string[]): $List<$Pack>;
        reload(): void;
        removePack(arg0: string): boolean;
    }

    export interface $PackSource {
        create(arg0: $UnaryOperator<$Component_>, arg1: boolean): $PackSource;
        decorate(arg0: $Component_): $Component;
        shouldAddAutomatically(): boolean;
        static BUILT_IN: $PackSource;
        static DEFAULT: $PackSource;
        static FEATURE: $PackSource;
        static NO_DECORATION: $UnaryOperator<$Component>;
        static SERVER: $PackSource;
        static WORLD: $PackSource;
    }

    export interface $RepositorySource {
        loadPacks(arg0: $Consumer<$Pack>): void;
    }

    export type $Pack$Position_ = $Pack$Position | "BOTTOM" | "TOP";
    export type $PackCompatibility_ = $PackCompatibility | "COMPATIBLE" | "TOO_NEW" | "TOO_OLD";
}
