import { $List } from "java:java/util";
import { $BiConsumer, $Predicate } from "java:java/util/function";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $Entity } from "java:net/minecraft/world/entity";
import { $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";

declare module "java:net/minecraft/commands/arguments/selector" {
    export class $EntitySelector {
        constructor(arg0: number, arg1: boolean, arg2: boolean, arg3: $Predicate<$Entity>[], arg4: $MinMaxBounds$Doubles, arg5: $Function<$Vec3_, $Vec3_>, arg6: $AABB, arg7: $BiConsumer<$Vec3_, $Entity[]>, arg8: boolean, arg9: string, arg10: string, arg11: $EntityType<any>, arg12: boolean);
        static INFINITE: number;
        static ORDER_ARBITRARY: $BiConsumer<$Vec3, $List<$Entity>>;
        contextFreePredicates: $List<$Predicate<$Entity>>;
        get maxResults(): number;
        getMaxResults(): number;
        get selfSelector(): boolean;
        isSelfSelector(): boolean;
        get worldLimited(): boolean;
        isWorldLimited(): boolean;
        static joinNames(arg0: $Entity[]): $Component;
        findEntities(arg0: $CommandSourceStack): $List<$Entity>;
        findPlayers(arg0: $CommandSourceStack): $List<$ServerPlayer>;
        findSingleEntity(arg0: $CommandSourceStack): $Entity;
        findSinglePlayer(arg0: $CommandSourceStack): $ServerPlayer;
        includesEntities(): boolean;
        usesSelector(): boolean;
    }

}
