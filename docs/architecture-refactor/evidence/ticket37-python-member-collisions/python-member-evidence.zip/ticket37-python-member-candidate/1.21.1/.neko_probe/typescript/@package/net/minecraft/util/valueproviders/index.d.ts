import { $Codec, $MapCodec } from "java:com/mojang/serialization";
import { $String } from "java:java/lang";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/util/valueproviders" {
    export class $BiasedToBottomInt extends $IntProvider {
        static CODEC: $MapCodec<$BiasedToBottomInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static of(arg0: number, arg1: number): $BiasedToBottomInt;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $ClampedInt extends $IntProvider {
        constructor(arg0: $IntProvider, arg1: number, arg2: number);
        static CODEC: $MapCodec<$ClampedInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static of(arg0: $IntProvider, arg1: number, arg2: number): $ClampedInt;
        sample(arg0: $RandomSource): number;
    }

    export class $ClampedNormalInt extends $IntProvider {
        static CODEC: $MapCodec<$ClampedNormalInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static of(arg0: number, arg1: number, arg2: number, arg3: number): $ClampedNormalInt;
        static sample(arg0: $RandomSource, arg1: number, arg2: number, arg3: number, arg4: number): number;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $ConstantInt extends $IntProvider {
        static CODEC: $MapCodec<$ConstantInt>;
        static ZERO: $ConstantInt;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        get value(): number;
        getValue(): number;
        static of(arg0: number): $ConstantInt;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $IntProvider {
        constructor();
        static CODEC: $Codec<$IntProvider>;
        static NON_NEGATIVE_CODEC: $Codec<$IntProvider>;
        static POSITIVE_CODEC: $Codec<$IntProvider>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static codec(arg0: number, arg1: number): $Codec<$IntProvider>;
        static validateCodec<T>(arg0: number, arg1: number, arg2: $Codec<T>): $Codec<T>;
        sample(arg0: $RandomSource): number;
    }

    export interface $IntProviderType<P extends $IntProvider> {
        codec(): $MapCodec<P>;
        register<P>(arg0: string, arg1: $MapCodec<P>): $IntProviderType<P>;
        static BIASED_TO_BOTTOM: $IntProviderType<$BiasedToBottomInt>;
        static CLAMPED: $IntProviderType<$ClampedInt>;
        static CLAMPED_NORMAL: $IntProviderType<$ClampedNormalInt>;
        static CONSTANT: $IntProviderType<$ConstantInt>;
        static UNIFORM: $IntProviderType<$UniformInt>;
        static WEIGHTED_LIST: $IntProviderType<$WeightedListInt>;
    }

    export class $UniformInt extends $IntProvider {
        static CODEC: $MapCodec<$UniformInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        static of(arg0: number, arg1: number): $UniformInt;
        sample(arg0: $RandomSource): number;
        toString(): string;
    }

    export class $WeightedListInt extends $IntProvider {
        constructor(arg0: $SimpleWeightedRandomList<$IntProvider>);
        static CODEC: $MapCodec<$WeightedListInt>;
        get maxValue(): number;
        getMaxValue(): number;
        get minValue(): number;
        getMinValue(): number;
        get type(): $IntProviderType<any>;
        getType(): $IntProviderType<any>;
        sample(arg0: $RandomSource): number;
    }

}
