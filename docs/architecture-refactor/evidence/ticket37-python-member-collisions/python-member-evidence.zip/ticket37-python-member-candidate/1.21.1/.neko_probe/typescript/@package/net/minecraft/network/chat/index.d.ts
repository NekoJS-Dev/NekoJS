import { $GameProfile } from "java:com/mojang/authlib";
import { $Message, $ParseResults } from "java:com/mojang/brigadier";
import { $Codec, $DataResult, $MapCodec } from "java:com/mojang/serialization";
import { $MutableComponentExtension } from "java:com/tkisor/nekojs/api/inject";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Boolean, $Enum, $Record, $String } from "java:java/lang";
import { $URI } from "java:java/net";
import { $ByteBuffer } from "java:java/nio";
import { $Duration, $Instant } from "java:java/time";
import { $BitSet, $Date, $List, $Optional, $UUID } from "java:java/util";
import { $BooleanSupplier, $UnaryOperator } from "java:java/util/function";
import { $ChatFormatting, $ChatFormatting_ } from "java:net/minecraft";
import { $CommandSourceStack } from "java:net/minecraft/commands";
import { $Holder, $Holder_, $RegistryAccess } from "java:net/minecraft/core";
import { $BootstrapContext } from "java:net/minecraft/data/worldgen";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $DataSource } from "java:net/minecraft/network/chat/contents";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $RegistryOps, $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ServerPlayer } from "java:net/minecraft/server/level";
import { $FormattedCharSequence, $SignatureUpdater, $SignatureUpdater$Output, $SignatureValidator, $StringRepresentable, $Unit, $Unit_ } from "java:net/minecraft/util";
import { $Entity, $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $ProfilePublicKey, $ProfilePublicKey$Data } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $ChunkPos } from "java:net/minecraft/world/level";
import { $Logger } from "java:org/slf4j";

export * as contents from "java:net/minecraft/network/chat/contents";
export * as numbers from "java:net/minecraft/network/chat/numbers";

declare module "java:net/minecraft/network/chat" {
    export interface $ChatDecorator {
        decorate(arg0: $ServerPlayer, arg1: $Component_): $Component;
        static PLAIN: $ChatDecorator;
    }

    export class $ChatType extends $Record {
        constructor(arg0: $ChatTypeDecoration, arg1: $ChatTypeDecoration);
        static CHAT: $ResourceKey<$ChatType>;
        static DEFAULT_CHAT_DECORATION: $ChatTypeDecoration;
        static DIRECT_CODEC: $Codec<$ChatType>;
        static DIRECT_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ChatType>;
        static EMOTE_COMMAND: $ResourceKey<$ChatType>;
        static MSG_COMMAND_INCOMING: $ResourceKey<$ChatType>;
        static MSG_COMMAND_OUTGOING: $ResourceKey<$ChatType>;
        static SAY_COMMAND: $ResourceKey<$ChatType>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $Holder<$ChatType>>;
        static TEAM_MSG_COMMAND_INCOMING: $ResourceKey<$ChatType>;
        static TEAM_MSG_COMMAND_OUTGOING: $ResourceKey<$ChatType>;
        static bind(arg0: $ResourceKey<$ChatType>, arg1: $CommandSourceStack): $ChatType$Bound;
        static bind(arg0: $ResourceKey<$ChatType>, arg1: $RegistryAccess, arg2: $Component_): $ChatType$Bound;
        static bind(arg0: $ResourceKey<$ChatType>, arg1: $Entity): $ChatType$Bound;
        static bootstrap(arg0: $BootstrapContext<$ChatType>): void;
        chat(): $ChatTypeDecoration;
        equals(arg0: object): boolean;
        hashCode(): number;
        narration(): $ChatTypeDecoration;
        toString(): string;
    }

    export class $ChatType$Bound extends $Record {
        constructor(arg0: $Holder<$ChatType>, arg1: $Component_, arg2: $Optional<$Component_>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ChatType$Bound>;
        chatType(): $Holder<$ChatType>;
        decorateNarration(arg0: $Component_): $Component;
        decorate(arg0: $Component_): $Component;
        equals(arg0: object): boolean;
        hashCode(): number;
        name(): $Component;
        targetName(): $Optional<$Component>;
        toString(): string;
        withTargetName(arg0: $Component_): $ChatType$Bound;
    }

    export class $ChatTypeDecoration extends $Record {
        constructor(arg0: string, arg1: $ChatTypeDecoration$Parameter_[], arg2: $Style);
        static CODEC: $Codec<$ChatTypeDecoration>;
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ChatTypeDecoration>;
        static incomingDirectMessage(arg0: string): $ChatTypeDecoration;
        static outgoingDirectMessage(arg0: string): $ChatTypeDecoration;
        static teamMessage(arg0: string): $ChatTypeDecoration;
        static withSender(arg0: string): $ChatTypeDecoration;
        decorate(arg0: $Component_, arg1: $ChatType$Bound): $Component;
        equals(arg0: object): boolean;
        hashCode(): number;
        parameters(): $List<$ChatTypeDecoration$Parameter>;
        style(): $Style;
        toString(): string;
        translationKey(): string;
    }

    export class $ChatTypeDecoration$Parameter {
        static CONTENT: $ChatTypeDecoration$Parameter;
        static SENDER: $ChatTypeDecoration$Parameter;
        static TARGET: $ChatTypeDecoration$Parameter;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ChatTypeDecoration$Parameter[];
        static valueOf(name: string): $ChatTypeDecoration$Parameter;
    }

    export class $ClickEvent {
        constructor(arg0: $ClickEvent$Action_, arg1: string);
        static CODEC: $Codec<$ClickEvent>;
        get action(): $ClickEvent$Action;
        getAction(): $ClickEvent$Action;
        get value(): string;
        getValue(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $ClickEvent$Action {
        static CHANGE_PAGE: $ClickEvent$Action;
        static COPY_TO_CLIPBOARD: $ClickEvent$Action;
        static OPEN_FILE: $ClickEvent$Action;
        static OPEN_URL: $ClickEvent$Action;
        static RUN_COMMAND: $ClickEvent$Action;
        static SUGGEST_COMMAND: $ClickEvent$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ClickEvent$Action[];
        static valueOf(name: string): $ClickEvent$Action;
    }

    export interface $Component extends $Message, $FormattedText {
        contains(arg0: $Component_): boolean;
        copy(): $MutableComponent;
        empty(): $MutableComponent;
        getContents(): $ComponentContents;
        getSiblings(): $List<$Component>;
        getString(arg0: number): string;
        getString(): string;
        getStyle(): $Style;
        getVisualOrderText(): $FormattedCharSequence;
        keybind(arg0: string): $MutableComponent;
        literal(arg0: string): $MutableComponent;
        nbt(arg0: string, arg1: boolean, arg2: $Optional<$Component_>, arg3: $DataSource): $MutableComponent;
        nullToEmpty(arg0: string): $Component;
        plainCopy(): $MutableComponent;
        score(arg0: string, arg1: string): $MutableComponent;
        selector(arg0: string, arg1: $Optional<$Component_>): $MutableComponent;
        toFlatList(arg0: $Style): $List<$Component>;
        toFlatList(): $List<$Component>;
        translatableEscape(arg0: string, arg1?: object[]): $MutableComponent;
        translatableWithFallback(arg0: string, arg1: string, arg2?: object[]): $MutableComponent;
        translatableWithFallback(arg0: string, arg1: string): $MutableComponent;
        translatable(arg0: string, arg1?: object[]): $MutableComponent;
        translatable(arg0: string): $MutableComponent;
        translationArg(arg0: $Message): $Component;
        translationArg(arg0: $URI): $Component;
        translationArg(arg0: $Date): $Component;
        translationArg(arg0: string): $Component;
        translationArg(arg0: $ResourceLocation_): $Component;
        translationArg(arg0: $ChunkPos): $Component;
        tryCollapseToString(): string;
        visit<T>(arg0: $FormattedText$ContentConsumer<T>): $Optional<T>;
        visit<T>(arg0: $FormattedText$StyledContentConsumer<T>, arg1: $Style): $Optional<T>;
    }

    export interface $ComponentContents {
        resolve(arg0: $CommandSourceStack, arg1: $Entity, arg2: number): $MutableComponent;
        type(): $ComponentContents$Type<any>;
        visit<T>(arg0: $FormattedText$ContentConsumer<T>): $Optional<T>;
        visit<T>(arg0: $FormattedText$StyledContentConsumer<T>, arg1: $Style): $Optional<T>;
    }

    export class $ComponentContents$Type<T extends $ComponentContents> extends $Record implements $StringRepresentable {
        constructor(arg0: $MapCodec<T>, arg1: string);
        get serializedName(): string;
        getSerializedName(): string;
        codec(): $MapCodec<T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): string;
        toString(): string;
    }

    export class $FilterMask {
        constructor(arg0: number);
        static CODEC: $Codec<$FilterMask>;
        static FILTERED_STYLE: $Style;
        static FULLY_FILTERED: $FilterMask;
        static PASS_THROUGH: $FilterMask;
        get empty(): boolean;
        isEmpty(): boolean;
        get fullyFiltered(): boolean;
        isFullyFiltered(): boolean;
        static read(arg0: $FriendlyByteBuf): $FilterMask;
        static write(arg0: $FriendlyByteBuf, arg1: $FilterMask): void;
        applyWithFormatting(arg0: string): $Component;
        apply(arg0: string): string;
        equals(arg0: object): boolean;
        hashCode(): number;
    }

    export interface $FormattedText {
        composite(arg0: $FormattedText[]): $FormattedText;
        composite(arg0?: $FormattedText[]): $FormattedText;
        getString(): string;
        of(arg0: string, arg1: $Style): $FormattedText;
        of(arg0: string): $FormattedText;
        visit<T>(arg0: $FormattedText$ContentConsumer<T>): $Optional<T>;
        visit<T>(arg0: $FormattedText$StyledContentConsumer<T>, arg1: $Style): $Optional<T>;
        static EMPTY: $FormattedText;
        static STOP_ITERATION: $Optional<$Unit>;
    }

    export interface $FormattedText$ContentConsumer<T> {
        accept(arg0: string): $Optional<T>;
    }

    export interface $FormattedText$StyledContentConsumer<T> {
        accept(arg0: $Style, arg1: string): $Optional<T>;
    }

    export class $HoverEvent {
        constructor(arg0: $HoverEvent$Action<T>, arg1: T);
        static CODEC: $Codec<$HoverEvent>;
        get action(): $HoverEvent$Action<any>;
        getAction(): $HoverEvent$Action<any>;
        equals(arg0: object): boolean;
        getValue<T>(arg0: $HoverEvent$Action<T>): T;
        hashCode(): number;
        toString(): string;
    }

    export class $HoverEvent$Action<T> implements $StringRepresentable {
        constructor(arg0: string, arg1: boolean, arg2: $Codec<T>, arg3: $HoverEvent$LegacyConverter<T>);
        static CODEC: $Codec<$HoverEvent$Action<any>>;
        static SHOW_ENTITY: $HoverEvent$Action<$HoverEvent$EntityTooltipInfo>;
        static SHOW_ITEM: $HoverEvent$Action<$HoverEvent$ItemStackInfo>;
        static SHOW_TEXT: $HoverEvent$Action<$Component>;
        static UNSAFE_CODEC: $Codec<$HoverEvent$Action<any>>;
        get serializedName(): string;
        getSerializedName(): string;
        get allowedFromServer(): boolean;
        isAllowedFromServer(): boolean;
        toString(): string;
    }

    export class $HoverEvent$EntityTooltipInfo {
        constructor(arg0: $EntityType<any>, arg1: string, arg2: $Optional<$Component_>);
        constructor(arg0: $EntityType<any>, arg1: string, arg2: $Component_);
        static CODEC: $Codec<$HoverEvent$EntityTooltipInfo>;
        id: $UUID;
        name: $Optional<$Component>;
        type: $EntityType<any>;
        get tooltipLines(): $List<$Component>;
        getTooltipLines(): $List<$Component>;
        static legacyCreate(arg0: $Component_, arg1: $RegistryOps<any>): $DataResult<$HoverEvent$EntityTooltipInfo>;
        equals(arg0: object): boolean;
        hashCode(): number;
    }

    export class $HoverEvent$ItemStackInfo {
        constructor(arg0: $ItemStack_);
        static CODEC: $Codec<$HoverEvent$ItemStackInfo>;
        static FULL_CODEC: $Codec<$HoverEvent$ItemStackInfo>;
        get itemStack(): $ItemStack;
        getItemStack(): $ItemStack;
        equals(arg0: object): boolean;
        hashCode(): number;
    }

    export interface $HoverEvent$LegacyConverter<T> {
        parse(arg0: $Component_, arg1: $RegistryOps<any>): $DataResult<T>;
    }

    export class $LastSeenMessages extends $Record {
        constructor(arg0: $MessageSignature[]);
        static CODEC: $Codec<$LastSeenMessages>;
        static EMPTY: $LastSeenMessages;
        static LAST_SEEN_MESSAGES_MAX_LENGTH: number;
        entries(): $List<$MessageSignature>;
        equals(arg0: object): boolean;
        hashCode(): number;
        pack(arg0: $MessageSignatureCache): $LastSeenMessages$Packed;
        toString(): string;
        updateSignature(arg0: $SignatureUpdater$Output): void;
    }

    export class $LastSeenMessages$Packed extends $Record {
        constructor(arg0: $MessageSignature$Packed[]);
        constructor(arg0: $FriendlyByteBuf);
        static EMPTY: $LastSeenMessages$Packed;
        entries(): $List<$MessageSignature$Packed>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        unpack(arg0: $MessageSignatureCache): $Optional<$LastSeenMessages>;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $LastSeenMessages$Update extends $Record {
        constructor(arg0: number, arg1: $BitSet);
        constructor(arg0: $FriendlyByteBuf);
        acknowledged(): $BitSet;
        equals(arg0: object): boolean;
        hashCode(): number;
        offset(): number;
        toString(): string;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $MessageSignature extends $Record {
        constructor(arg0: number[]);
        static BYTES: number;
        static CODEC: $Codec<$MessageSignature>;
        static read(arg0: $FriendlyByteBuf): $MessageSignature;
        static write(arg0: $FriendlyByteBuf, arg1: $MessageSignature): void;
        asByteBuffer(): $ByteBuffer;
        bytes(): number[];
        equals(arg0: object): boolean;
        hashCode(): number;
        pack(arg0: $MessageSignatureCache): $MessageSignature$Packed;
        toString(): string;
        verify(arg0: $SignatureValidator, arg1: $SignatureUpdater): boolean;
    }

    export class $MessageSignature$Packed extends $Record {
        constructor(arg0: number);
        constructor(arg0: number, arg1: $MessageSignature);
        constructor(arg0: $MessageSignature);
        static FULL_SIGNATURE: number;
        static read(arg0: $FriendlyByteBuf): $MessageSignature$Packed;
        static write(arg0: $FriendlyByteBuf, arg1: $MessageSignature$Packed): void;
        equals(arg0: object): boolean;
        fullSignature(): $MessageSignature;
        hashCode(): number;
        id(): number;
        toString(): string;
        unpack(arg0: $MessageSignatureCache): $Optional<$MessageSignature>;
    }

    export class $MessageSignatureCache {
        constructor(arg0: number);
        static NOT_FOUND: number;
        static createDefault(): $MessageSignatureCache;
        pack(arg0: $MessageSignature): number;
        push(arg0: $SignedMessageBody, arg1: $MessageSignature): void;
        unpack(arg0: number): $MessageSignature;
    }

    export class $MutableComponent implements $Component, $MutableComponentExtension {
        get contents(): $ComponentContents;
        getContents(): $ComponentContents;
        get siblings(): $List<$Component>;
        getSiblings(): $List<$Component>;
        get style(): $Style;
        getStyle(): $Style;
        set style(value: $Style);
        get visualOrderText(): $FormattedCharSequence;
        getVisualOrderText(): $FormattedCharSequence;
        static create(arg0: $ComponentContents): $MutableComponent;
        append(arg0: string): $MutableComponent;
        append(arg0: $Component_): $MutableComponent;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        withColor(arg0: number): $MutableComponent;
        withStyle(arg0: $UnaryOperator<$Style>): $MutableComponent;
        withStyle(arg0?: $ChatFormatting_[]): $MutableComponent;
        withStyle(arg0: $ChatFormatting_): $MutableComponent;
        withStyle(arg0: $Style): $MutableComponent;
    }

    export interface $OutgoingChatMessage {
        content(): $Component;
        create(arg0: $PlayerChatMessage): $OutgoingChatMessage;
        sendToPlayer(arg0: $ServerPlayer, arg1: boolean, arg2: $ChatType$Bound): void;
    }

    export class $PlayerChatMessage extends $Record {
        constructor(arg0: $SignedMessageLink, arg1: $MessageSignature, arg2: $SignedMessageBody, arg3: $Component_, arg4: $FilterMask);
        static MAP_CODEC: $MapCodec<$PlayerChatMessage>;
        static MESSAGE_EXPIRES_AFTER_CLIENT: $Duration;
        static MESSAGE_EXPIRES_AFTER_SERVER: $Duration;
        get fullyFiltered(): boolean;
        isFullyFiltered(): boolean;
        get system(): boolean;
        isSystem(): boolean;
        static system(arg0: string): $PlayerChatMessage;
        static unsigned(arg0: string, arg1: string): $PlayerChatMessage;
        static updateSignature(arg0: $SignatureUpdater$Output, arg1: $SignedMessageLink, arg2: $SignedMessageBody): void;
        decoratedContent(): $Component;
        equals(arg0: object): boolean;
        filterMask(): $FilterMask;
        filter(arg0: boolean): $PlayerChatMessage;
        filter(arg0: $FilterMask): $PlayerChatMessage;
        hasExpiredClient(arg0: $Instant): boolean;
        hasExpiredServer(arg0: $Instant): boolean;
        hasSignatureFrom(arg0: string): boolean;
        hasSignature(): boolean;
        hashCode(): number;
        link(): $SignedMessageLink;
        removeSignature(): $PlayerChatMessage;
        removeUnsignedContent(): $PlayerChatMessage;
        salt(): number;
        sender(): $UUID;
        signature(): $MessageSignature;
        signedBody(): $SignedMessageBody;
        signedContent(): string;
        timeStamp(): $Instant;
        toString(): string;
        unsignedContent(): $Component;
        verify(arg0: $SignatureValidator): boolean;
        withUnsignedContent(arg0: $Component_): $PlayerChatMessage;
    }

    export class $RemoteChatSession extends $Record {
        constructor(arg0: string, arg1: $ProfilePublicKey);
        asData(): $RemoteChatSession$Data;
        createMessageDecoder(arg0: string): $SignedMessageChain$Decoder;
        createMessageValidator(arg0: $Duration): $SignedMessageValidator;
        equals(arg0: object): boolean;
        hasExpired(): boolean;
        hashCode(): number;
        profilePublicKey(): $ProfilePublicKey;
        sessionId(): $UUID;
        toString(): string;
    }

    export class $RemoteChatSession$Data extends $Record {
        constructor(arg0: string, arg1: $ProfilePublicKey$Data);
        static read(arg0: $FriendlyByteBuf): $RemoteChatSession$Data;
        static write(arg0: $FriendlyByteBuf, arg1: $RemoteChatSession$Data): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        profilePublicKey(): $ProfilePublicKey$Data;
        sessionId(): $UUID;
        toString(): string;
        validate(arg0: $GameProfile, arg1: $SignatureValidator): $RemoteChatSession;
    }

    export class $SignableCommand<S> extends $Record {
        constructor(arguments_: $SignableCommand$Argument<S>[]);
        static hasSignableArguments<S>(arg0: $ParseResults<S>): boolean;
        static of<S>(arg0: $ParseResults<S>): $SignableCommand<S>;
        arguments(): $List<$SignableCommand$Argument<S>>;
        equals(arg0: object): boolean;
        getArgument(arg0: string): $SignableCommand$Argument<S>;
        hashCode(): number;
        toString(): string;
    }

    export class $SignedMessageBody extends $Record {
        constructor(arg0: string, arg1: $Instant, arg2: number, arg3: $LastSeenMessages);
        static MAP_CODEC: $MapCodec<$SignedMessageBody>;
        static unsigned(arg0: string): $SignedMessageBody;
        content(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        lastSeen(): $LastSeenMessages;
        pack(arg0: $MessageSignatureCache): $SignedMessageBody$Packed;
        salt(): number;
        timeStamp(): $Instant;
        toString(): string;
        updateSignature(arg0: $SignatureUpdater$Output): void;
    }

    export class $SignedMessageBody$Packed extends $Record {
        constructor(arg0: string, arg1: $Instant, arg2: number, arg3: $LastSeenMessages$Packed);
        constructor(arg0: $FriendlyByteBuf);
        content(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        lastSeen(): $LastSeenMessages$Packed;
        salt(): number;
        timeStamp(): $Instant;
        toString(): string;
        unpack(arg0: $MessageSignatureCache): $Optional<$SignedMessageBody>;
        write(arg0: $FriendlyByteBuf): void;
    }

    export interface $SignedMessageChain$Decoder {
        setChainBroken(): void;
        unpack(arg0: $MessageSignature, arg1: $SignedMessageBody): $PlayerChatMessage;
        unsigned(arg0: string, arg1: $BooleanSupplier): $SignedMessageChain$Decoder;
    }

    export class $SignedMessageLink extends $Record {
        constructor(arg0: number, arg1: string, arg2: string);
        static CODEC: $Codec<$SignedMessageLink>;
        static root(arg0: string, arg1: string): $SignedMessageLink;
        static unsigned(arg0: string): $SignedMessageLink;
        advance(): $SignedMessageLink;
        equals(arg0: object): boolean;
        hashCode(): number;
        index(): number;
        isDescendantOf(arg0: $SignedMessageLink): boolean;
        sender(): $UUID;
        sessionId(): $UUID;
        toString(): string;
        updateSignature(arg0: $SignatureUpdater$Output): void;
    }

    export interface $SignedMessageValidator {
        updateAndValidate(arg0: $PlayerChatMessage): $PlayerChatMessage;
        static ACCEPT_UNSIGNED: $SignedMessageValidator;
        static LOGGER: $Logger;
        static REJECT_ALL: $SignedMessageValidator;
    }

    export class $Style {
        static DEFAULT_FONT: $ResourceLocation;
        static EMPTY: $Style;
        get clickEvent(): $ClickEvent;
        getClickEvent(): $ClickEvent;
        get color(): $TextColor;
        getColor(): $TextColor;
        get font(): $ResourceLocation;
        getFont(): $ResourceLocation;
        get hoverEvent(): $HoverEvent;
        getHoverEvent(): $HoverEvent;
        get insertion(): string;
        getInsertion(): string;
        get bold(): boolean;
        isBold(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        get italic(): boolean;
        isItalic(): boolean;
        get obfuscated(): boolean;
        isObfuscated(): boolean;
        get strikethrough(): boolean;
        isStrikethrough(): boolean;
        get underlined(): boolean;
        isUnderlined(): boolean;
        applyFormats(arg0?: $ChatFormatting_[]): $Style;
        applyFormat(arg0: $ChatFormatting_): $Style;
        applyLegacyFormat(arg0: $ChatFormatting_): $Style;
        applyTo(arg0: $Style): $Style;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        withBold(arg0: boolean): $Style;
        withClickEvent(arg0: $ClickEvent): $Style;
        withColor(arg0: number): $Style;
        withColor(arg0: $ChatFormatting_): $Style;
        withColor(arg0: $TextColor): $Style;
        withFont(arg0: $ResourceLocation_): $Style;
        withHoverEvent(arg0: $HoverEvent): $Style;
        withInsertion(arg0: string): $Style;
        withItalic(arg0: boolean): $Style;
        withObfuscated(arg0: boolean): $Style;
        withStrikethrough(arg0: boolean): $Style;
        withUnderlined(arg0: boolean): $Style;
    }

    export class $TextColor {
        static CODEC: $Codec<$TextColor>;
        get value(): number;
        getValue(): number;
        static fromLegacyFormat(arg0: $ChatFormatting_): $TextColor;
        static fromRgb(arg0: number): $TextColor;
        static parseColor(arg0: string): $DataResult<$TextColor>;
        equals(arg0: object): boolean;
        hashCode(): number;
        serialize(): string;
        toString(): string;
    }

    export type $ChatTypeDecoration$Parameter_ = $ChatTypeDecoration$Parameter | "CONTENT" | "SENDER" | "TARGET";
    export type $ClickEvent$Action_ = $ClickEvent$Action | "CHANGE_PAGE" | "COPY_TO_CLIPBOARD" | "OPEN_FILE" | "OPEN_URL" | "RUN_COMMAND" | "SUGGEST_COMMAND";
    export type $Component_ = $Component | string | $TextValue;
}
