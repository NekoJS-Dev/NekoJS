import { $Codec } from "java:com/mojang/serialization";
import { $DataInput, $DataOutput } from "java:java/io";
import { $Byte, $Enum, $Integer, $Long, $Number, $String } from "java:java/lang";
import { $AbstractList, $List, $Map, $Set, $UUID } from "java:java/util";

declare module "java:net/minecraft/nbt" {
    export class $ByteArrayTag extends $CollectionTag {
        constructor(arg0: number[]);
        constructor(arg0: number[]);
        static TYPE: $TagType<$ByteArrayTag>;
        get asByteArray(): number[];
        getAsByteArray(): number[];
        get elementType(): number;
        getElementType(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ByteArrayTag>;
        getType(): $TagType<$ByteArrayTag>;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        addTag(arg0: number, arg1: $Tag): boolean;
        add(arg0: number, arg1: $ByteTag): void;
        clear(): void;
        copy(): $Tag;
        equals(arg0: object): boolean;
        get(arg0: number): $ByteTag;
        hashCode(): number;
        remove(arg0: number): $ByteTag;
        setTag(arg0: number, arg1: $Tag): boolean;
        set(arg0: number, arg1: $ByteTag): $ByteTag;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $ByteTag extends $NumericTag {
        static ONE: $ByteTag;
        static TYPE: $TagType<$ByteTag>;
        static ZERO: $ByteTag;
        get asByte(): number;
        getAsByte(): number;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ByteTag>;
        getType(): $TagType<$ByteTag>;
        static valueOf(arg0: boolean): $ByteTag;
        static valueOf(arg0: number): $ByteTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $ByteTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        write(arg0: $DataOutput): void;
    }

    export class $CollectionTag<T extends $Tag> extends $AbstractList implements $Tag {
        constructor();
        get elementType(): number;
        getElementType(): number;
        addTag(arg0: number, arg1: $Tag): boolean;
        add(arg0: number, arg1: T): void;
        remove(arg0: number): T;
        setTag(arg0: number, arg1: $Tag): boolean;
        set(arg0: number, arg1: T): T;
    }

    export class $CompoundTag implements $Tag {
        constructor();
        constructor(arg0: number);
        static CODEC: $Codec<$CompoundTag>;
        static TYPE: $TagType<$CompoundTag>;
        tags: $Map<string, $Tag>;
        get allKeys(): $Set<string>;
        getAllKeys(): $Set<string>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$CompoundTag>;
        getType(): $TagType<$CompoundTag>;
        get empty(): boolean;
        isEmpty(): boolean;
        static readNamedTagData(arg0: $TagType<any>, arg1: string, arg2: $DataInput, arg3: $NbtAccounter): $Tag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        contains(arg0: string, arg1: number): boolean;
        contains(arg0: string): boolean;
        copy(): $CompoundTag;
        equals(arg0: object): boolean;
        getBoolean(arg0: string): boolean;
        getByteArray(arg0: string): number[];
        getByte(arg0: string): number;
        getCompound(arg0: string): $CompoundTag;
        getDouble(arg0: string): number;
        getFloat(arg0: string): number;
        getIntArray(arg0: string): number[];
        getInt(arg0: string): number;
        getList(arg0: string, arg1: number): $ListTag;
        getLongArray(arg0: string): number[];
        getLong(arg0: string): number;
        getShort(arg0: string): number;
        getString(arg0: string): string;
        getTagType(arg0: string): number;
        getUUID(arg0: string): $UUID;
        get(arg0: string): $Tag;
        hasUUID(arg0: string): boolean;
        hashCode(): number;
        merge(arg0: $CompoundTag_): $CompoundTag;
        putBoolean(arg0: string, arg1: boolean): void;
        putByteArray(arg0: string, arg1: number[]): void;
        putByteArray(arg0: string, arg1: number[]): void;
        putByte(arg0: string, arg1: number): void;
        putDouble(arg0: string, arg1: number): void;
        putFloat(arg0: string, arg1: number): void;
        putIntArray(arg0: string, arg1: number[]): void;
        putIntArray(arg0: string, arg1: number[]): void;
        putInt(arg0: string, arg1: number): void;
        putLongArray(arg0: string, arg1: number[]): void;
        putLongArray(arg0: string, arg1: number[]): void;
        putLong(arg0: string, arg1: number): void;
        putShort(arg0: string, arg1: number): void;
        putString(arg0: string, arg1: string): void;
        putUUID(arg0: string, arg1: string): void;
        put(arg0: string, arg1: $Tag): $Tag;
        remove(arg0: string): void;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $DoubleTag extends $NumericTag {
        static TYPE: $TagType<$DoubleTag>;
        static ZERO: $DoubleTag;
        get asByte(): number;
        getAsByte(): number;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$DoubleTag>;
        getType(): $TagType<$DoubleTag>;
        static valueOf(arg0: number): $DoubleTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $DoubleTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        write(arg0: $DataOutput): void;
    }

    export class $EndTag implements $Tag {
        static INSTANCE: $EndTag;
        static TYPE: $TagType<$EndTag>;
        get id(): number;
        getId(): number;
        get type(): $TagType<$EndTag>;
        getType(): $TagType<$EndTag>;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $EndTag;
        sizeInBytes(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $FloatTag extends $NumericTag {
        static TYPE: $TagType<$FloatTag>;
        static ZERO: $FloatTag;
        get asByte(): number;
        getAsByte(): number;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$FloatTag>;
        getType(): $TagType<$FloatTag>;
        static valueOf(arg0: number): $FloatTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $FloatTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        write(arg0: $DataOutput): void;
    }

    export class $IntArrayTag extends $CollectionTag {
        constructor(arg0: number[]);
        constructor(arg0: number[]);
        static TYPE: $TagType<$IntArrayTag>;
        get asIntArray(): number[];
        getAsIntArray(): number[];
        get elementType(): number;
        getElementType(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$IntArrayTag>;
        getType(): $TagType<$IntArrayTag>;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        addTag(arg0: number, arg1: $Tag): boolean;
        add(arg0: number, arg1: $IntTag): void;
        clear(): void;
        copy(): $IntArrayTag;
        equals(arg0: object): boolean;
        get(arg0: number): $IntTag;
        hashCode(): number;
        remove(arg0: number): $IntTag;
        setTag(arg0: number, arg1: $Tag): boolean;
        set(arg0: number, arg1: $IntTag): $IntTag;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $IntTag extends $NumericTag {
        static TYPE: $TagType<$IntTag>;
        get asByte(): number;
        getAsByte(): number;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$IntTag>;
        getType(): $TagType<$IntTag>;
        static valueOf(arg0: number): $IntTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $IntTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        write(arg0: $DataOutput): void;
    }

    export class $ListTag extends $CollectionTag {
        constructor();
        constructor(arg0: number);
        constructor(arg0: $Tag[], arg1: number);
        static TYPE: $TagType<$ListTag>;
        get elementType(): number;
        getElementType(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ListTag>;
        getType(): $TagType<$ListTag>;
        get empty(): boolean;
        isEmpty(): boolean;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        addTag(arg0: number, arg1: $Tag): boolean;
        add(arg0: number, arg1: $Tag): void;
        clear(): void;
        copy(): $ListTag;
        equals(arg0: object): boolean;
        getCompound(arg0: number): $CompoundTag;
        getDouble(arg0: number): number;
        getFloat(arg0: number): number;
        getIntArray(arg0: number): number[];
        getInt(arg0: number): number;
        getList(arg0: number): $ListTag;
        getLongArray(arg0: number): number[];
        getShort(arg0: number): number;
        getString(arg0: number): string;
        get(arg0: number): $Tag;
        hashCode(): number;
        remove(arg0: number): $Tag;
        setTag(arg0: number, arg1: $Tag): boolean;
        set(arg0: number, arg1: $Tag): $Tag;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $LongArrayTag extends $CollectionTag {
        constructor(arg0: $LongSet);
        constructor(arg0: number[]);
        constructor(arg0: number[]);
        static TYPE: $TagType<$LongArrayTag>;
        get asLongArray(): number[];
        getAsLongArray(): number[];
        get elementType(): number;
        getElementType(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$LongArrayTag>;
        getType(): $TagType<$LongArrayTag>;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        addTag(arg0: number, arg1: $Tag): boolean;
        add(arg0: number, arg1: $LongTag): void;
        clear(): void;
        copy(): $LongArrayTag;
        equals(arg0: object): boolean;
        get(arg0: number): $LongTag;
        hashCode(): number;
        remove(arg0: number): $LongTag;
        setTag(arg0: number, arg1: $Tag): boolean;
        set(arg0: number, arg1: $LongTag): $LongTag;
        sizeInBytes(): number;
        size(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export class $LongTag extends $NumericTag {
        static TYPE: $TagType<$LongTag>;
        get asByte(): number;
        getAsByte(): number;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$LongTag>;
        getType(): $TagType<$LongTag>;
        static valueOf(arg0: number): $LongTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $LongTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        write(arg0: $DataOutput): void;
    }

    export class $NbtAccounter {
        constructor(arg0: number, arg1: number);
        get depth(): number;
        getDepth(): number;
        get usage(): number;
        getUsage(): number;
        static create(arg0: number): $NbtAccounter;
        static unlimitedHeap(): $NbtAccounter;
        accountBytes(arg0: number, arg1: number): void;
        accountBytes(arg0: number): void;
        popDepth(): void;
        pushDepth(): void;
        readUTF(arg0: string): string;
    }

    export class $NumericTag implements $Tag {
        get asByte(): number;
        getAsByte(): number;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        toString(): string;
    }

    export class $ShortTag extends $NumericTag {
        static TYPE: $TagType<$ShortTag>;
        get asByte(): number;
        getAsByte(): number;
        get asDouble(): number;
        getAsDouble(): number;
        get asFloat(): number;
        getAsFloat(): number;
        get asInt(): number;
        getAsInt(): number;
        get asLong(): number;
        getAsLong(): number;
        get asNumber(): number;
        getAsNumber(): number;
        get asShort(): number;
        getAsShort(): number;
        get id(): number;
        getId(): number;
        get type(): $TagType<$ShortTag>;
        getType(): $TagType<$ShortTag>;
        static valueOf(arg0: number): $ShortTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $ShortTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        write(arg0: $DataOutput): void;
    }

    export interface $StreamTagVisitor {
        visitContainerEnd(): $StreamTagVisitor$ValueResult;
        visitElement(arg0: $TagType<any>, arg1: number): $StreamTagVisitor$EntryResult;
        visitEnd(): $StreamTagVisitor$ValueResult;
        visitEntry(arg0: $TagType<any>, arg1: string): $StreamTagVisitor$EntryResult;
        visitEntry(arg0: $TagType<any>): $StreamTagVisitor$EntryResult;
        visitList(arg0: $TagType<any>, arg1: number): $StreamTagVisitor$ValueResult;
        visitRootEntry(arg0: $TagType<any>): $StreamTagVisitor$ValueResult;
        visit(arg0: number[]): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: number[]): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: string): $StreamTagVisitor$ValueResult;
        visit(arg0: number[]): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
        visit(arg0: number): $StreamTagVisitor$ValueResult;
    }

    export class $StreamTagVisitor$EntryResult {
        static BREAK: $StreamTagVisitor$EntryResult;
        static ENTER: $StreamTagVisitor$EntryResult;
        static HALT: $StreamTagVisitor$EntryResult;
        static SKIP: $StreamTagVisitor$EntryResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StreamTagVisitor$EntryResult[];
        static valueOf(name: string): $StreamTagVisitor$EntryResult;
    }

    export class $StreamTagVisitor$ValueResult {
        static BREAK: $StreamTagVisitor$ValueResult;
        static CONTINUE: $StreamTagVisitor$ValueResult;
        static HALT: $StreamTagVisitor$ValueResult;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $StreamTagVisitor$ValueResult[];
        static valueOf(name: string): $StreamTagVisitor$ValueResult;
    }

    export class $StringTag implements $Tag {
        static TYPE: $TagType<$StringTag>;
        get asString(): string;
        getAsString(): string;
        get id(): number;
        getId(): number;
        get type(): $TagType<$StringTag>;
        getType(): $TagType<$StringTag>;
        static quoteAndEscape(arg0: string): string;
        static skipString(arg0: $DataInput): void;
        static valueOf(arg0: string): $StringTag;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $StringTag;
        equals(arg0: object): boolean;
        hashCode(): number;
        sizeInBytes(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
    }

    export interface $Tag {
        acceptAsRoot(arg0: $StreamTagVisitor): void;
        accept(arg0: $StreamTagVisitor): $StreamTagVisitor$ValueResult;
        accept(arg0: $TagVisitor): void;
        copy(): $Tag;
        getAsString(): string;
        getId(): number;
        getType(): $TagType<any>;
        sizeInBytes(): number;
        toString(): string;
        write(arg0: $DataOutput): void;
        static ARRAY_HEADER: number;
        static MAX_DEPTH: number;
        static OBJECT_HEADER: number;
        static OBJECT_REFERENCE: number;
        static STRING_SIZE: number;
        static TAG_ANY_NUMERIC: number;
        static TAG_BYTE: number;
        static TAG_BYTE_ARRAY: number;
        static TAG_COMPOUND: number;
        static TAG_DOUBLE: number;
        static TAG_END: number;
        static TAG_FLOAT: number;
        static TAG_INT: number;
        static TAG_INT_ARRAY: number;
        static TAG_LIST: number;
        static TAG_LONG: number;
        static TAG_LONG_ARRAY: number;
        static TAG_SHORT: number;
        static TAG_STRING: number;
    }

    export interface $TagType<T extends $Tag> {
        createInvalid(arg0: number): $TagType<$EndTag>;
        getName(): string;
        getPrettyName(): string;
        isValue(): boolean;
        load(arg0: $DataInput, arg1: $NbtAccounter): T;
        parseRoot(arg0: $DataInput, arg1: $StreamTagVisitor, arg2: $NbtAccounter): void;
        parse(arg0: $DataInput, arg1: $StreamTagVisitor, arg2: $NbtAccounter): $StreamTagVisitor$ValueResult;
        skip(arg0: $DataInput, arg1: number, arg2: $NbtAccounter): void;
        skip(arg0: $DataInput, arg1: $NbtAccounter): void;
    }

    export interface $TagVisitor {
        visitByteArray(arg0: $ByteArrayTag): void;
        visitByte(arg0: $ByteTag): void;
        visitCompound(arg0: $CompoundTag_): void;
        visitDouble(arg0: $DoubleTag): void;
        visitEnd(arg0: $EndTag): void;
        visitFloat(arg0: $FloatTag): void;
        visitIntArray(arg0: $IntArrayTag): void;
        visitInt(arg0: $IntTag): void;
        visitList(arg0: $ListTag): void;
        visitLongArray(arg0: $LongArrayTag): void;
        visitLong(arg0: $LongTag): void;
        visitShort(arg0: $ShortTag): void;
        visitString(arg0: $StringTag): void;
    }

    export type $CompoundTag_ = $CompoundTag | { [key: string]: any };
    export type $StreamTagVisitor$EntryResult_ = $StreamTagVisitor$EntryResult | "BREAK" | "ENTER" | "HALT" | "SKIP";
    export type $StreamTagVisitor$ValueResult_ = $StreamTagVisitor$ValueResult | "BREAK" | "CONTINUE" | "HALT";
}
