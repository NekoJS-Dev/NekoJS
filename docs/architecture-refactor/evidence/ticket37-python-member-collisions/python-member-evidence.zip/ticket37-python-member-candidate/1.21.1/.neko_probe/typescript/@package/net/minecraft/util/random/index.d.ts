import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $List, $Optional } from "java:java/util";
import { $RandomSource } from "java:net/minecraft/util";

declare module "java:net/minecraft/util/random" {
    export class $SimpleWeightedRandomList<E> extends $WeightedRandomList {
        static builder<E>(): $SimpleWeightedRandomList$Builder<E>;
        static empty<E>(): $SimpleWeightedRandomList<E>;
        static single<E>(arg0: E): $SimpleWeightedRandomList<E>;
        static wrappedCodecAllowingEmpty<E>(arg0: $Codec<E>): $Codec<$SimpleWeightedRandomList<E>>;
        static wrappedCodec<E>(arg0: $Codec<E>): $Codec<$SimpleWeightedRandomList<E>>;
        getRandomValue(arg0: $RandomSource): $Optional<E>;
    }

    export class $SimpleWeightedRandomList$Builder<E> {
        constructor();
        add(arg0: E, arg1: number): $SimpleWeightedRandomList$Builder<E>;
        add(arg0: E): $SimpleWeightedRandomList$Builder<E>;
        build(): $SimpleWeightedRandomList<E>;
    }

    export class $Weight {
        static CODEC: $Codec<$Weight>;
        static of(arg0: number): $Weight;
        asInt(): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export interface $WeightedEntry {
        getWeight(): $Weight;
        wrap<T>(arg0: T, arg1: number): $WeightedEntry$Wrapper<T>;
    }

    export class $WeightedEntry$IntrusiveBase implements $WeightedEntry {
        constructor(arg0: number);
        constructor(arg0: $Weight);
        get weight(): $Weight;
        getWeight(): $Weight;
    }

    export class $WeightedEntry$Wrapper<T> extends $Record implements $WeightedEntry {
        constructor(arg0: T, arg1: $Weight);
        get weight(): $Weight;
        getWeight(): $Weight;
        static codec<E>(arg0: $Codec<E>): $Codec<$WeightedEntry$Wrapper<E>>;
        data(): T;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
        weight(): $Weight;
    }

    export class $WeightedRandomList<E extends $WeightedEntry> {
        get empty(): boolean;
        isEmpty(): boolean;
        static codec<E>(arg0: $Codec<E>): $Codec<$WeightedRandomList<E>>;
        static create<E>(arg0?: E[]): $WeightedRandomList<E>;
        static create<E>(arg0: E[]): $WeightedRandomList<E>;
        static create<E>(): $WeightedRandomList<E>;
        equals(arg0: object): boolean;
        getRandom(arg0: $RandomSource): $Optional<E>;
        hashCode(): number;
        unwrap(): $List<E>;
    }

}
