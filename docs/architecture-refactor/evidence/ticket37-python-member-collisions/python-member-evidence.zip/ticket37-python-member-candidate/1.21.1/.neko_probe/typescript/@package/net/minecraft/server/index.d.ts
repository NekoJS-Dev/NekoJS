import { $GameProfile, $GameProfileRepository } from "java:com/mojang/authlib";
import { $MinecraftSessionService } from "java:com/mojang/authlib/minecraft";
import { $ServicesKeySet, $YggdrasilAuthenticationService } from "java:com/mojang/authlib/yggdrasil";
import { $CommandDispatcher } from "java:com/mojang/brigadier";
import { $DataFixer } from "java:com/mojang/datafixers";
import { $Either, $Pair } from "java:com/mojang/datafixers/util";
import { $AttachedData } from "java:com/tkisor/nekojs/api/data";
import { $ServerExtension } from "java:com/tkisor/nekojs/api/inject";
import { $ByteBuf } from "java:io/netty/buffer";
import { $File } from "java:java/io";
import { $AutoCloseable, $Enum, $Iterable, $Record, $Runnable, $RuntimeException, $String, $Thread, $Throwable, $Void } from "java:java/lang";
import { $Proxy, $URI } from "java:java/net";
import { $Path } from "java:java/nio/file";
import { $KeyPair } from "java:java/security";
import { $Collection, $List, $Map, $Optional, $Set, $UUID } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $BooleanSupplier, $Consumer, $Function } from "java:java/util/function";
import { $CrashReport, $SystemReport } from "java:net/minecraft";
import { $AdvancementHolder, $AdvancementProgress, $AdvancementTree } from "java:net/minecraft/advancements";
import { $CommandSource, $CommandSourceStack, $Commands, $Commands$CommandSelection, $Commands$CommandSelection_ } from "java:net/minecraft/commands";
import { $CommandFunction } from "java:net/minecraft/commands/functions";
import { $BlockPos, $BlockPos_, $HolderGetter$Provider, $HolderLookup$Provider, $LayeredRegistryAccess, $Registry, $RegistryAccess$Frozen } from "java:net/minecraft/core";
import { $ChatDecorator, $ChatType$Bound, $Component, $Component_ } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet } from "java:net/minecraft/network/protocol";
import { $ServerStatus } from "java:net/minecraft/network/protocol/status";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $CustomBossEvents } from "java:net/minecraft/server/bossevents";
import { $ServerLevel, $ServerPlayer, $ServerPlayerGameMode } from "java:net/minecraft/server/level";
import { $ServerConnectionListener, $TextFilter } from "java:net/minecraft/server/network";
import { $PackRepository } from "java:net/minecraft/server/packs/repository";
import { $CloseableResourceManager, $PreparableReloadListener, $PreparableReloadListener$PreparationBarrier, $ResourceManager, $SimpleJsonResourceReloadListener } from "java:net/minecraft/server/packs/resources";
import { $GameProfileCache, $PlayerList } from "java:net/minecraft/server/players";
import { $ModCheck, $SignatureValidator } from "java:net/minecraft/util";
import { $RemoteDebugSampleType, $RemoteDebugSampleType_ } from "java:net/minecraft/util/debugchart";
import { $ProfileResults, $ProfilerFiller } from "java:net/minecraft/util/profiling";
import { $ReentrantBlockableEventLoop } from "java:net/minecraft/util/thread";
import { $Difficulty, $Difficulty_, $TickRateManager } from "java:net/minecraft/world";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $FeatureFlagSet } from "java:net/minecraft/world/flag";
import { $PotionBrewing } from "java:net/minecraft/world/item/alchemy";
import { $RecipeManager } from "java:net/minecraft/world/item/crafting";
import { $ChunkPos, $GameRules, $GameType, $GameType_, $Level, $LevelSettings, $WorldDataConfiguration } from "java:net/minecraft/world/level";
import { $ChunkIOErrorReporter, $RegionStorageInfo } from "java:net/minecraft/world/level/chunk/storage";
import { $StructureTemplateManager } from "java:net/minecraft/world/level/levelgen/structure/templatesystem";
import { $SavedData$Factory } from "java:net/minecraft/world/level/saveddata";
import { $CommandStorage, $LevelResource, $WorldData } from "java:net/minecraft/world/level/storage";
import { $LootTable } from "java:net/minecraft/world/level/storage/loot";
import { $DisplaySlot, $DisplaySlot_, $Objective, $PlayerTeam, $ScoreHolder, $Scoreboard, $ScoreboardSaveData } from "java:net/minecraft/world/scores";
import { $ICondition$IContext } from "java:net/neoforged/neoforge/common/conditions";

export * as bossevents from "java:net/minecraft/server/bossevents";
export * as level from "java:net/minecraft/server/level";
export * as network from "java:net/minecraft/server/network";
export * as packs from "java:net/minecraft/server/packs";
export * as players from "java:net/minecraft/server/players";

declare module "java:net/minecraft/server" {
    export class $MinecraftServer extends $ReentrantBlockableEventLoop implements $ServerInfo, $ChunkIOErrorReporter, $CommandSource, $AutoCloseable, $ServerExtension {
        constructor(arg0: $Thread, arg1: $LevelStorageSource$LevelStorageAccess, arg2: $PackRepository, arg3: $WorldStem, arg4: $Proxy, arg5: $DataFixer, arg6: $Services, arg7: $ChunkProgressListenerFactory);
        static ABSOLUTE_MAX_WORLD_SIZE: number;
        static ANONYMOUS_PLAYER_PROFILE: $GameProfile;
        static DEMO_SETTINGS: $LevelSettings;
        static VANILLA_BRAND: string;
        get absoluteMaxWorldSize(): number;
        getAbsoluteMaxWorldSize(): number;
        get advancements(): $ServerAdvancementManager;
        getAdvancements(): $ServerAdvancementManager;
        get allLevels(): $Iterable<$ServerLevel>;
        getAllLevels(): $Iterable<$ServerLevel>;
        get averageTickTimeNanos(): number;
        getAverageTickTimeNanos(): number;
        get chatDecorator(): $ChatDecorator;
        getChatDecorator(): $ChatDecorator;
        get commandStorage(): $CommandStorage;
        getCommandStorage(): $CommandStorage;
        get commands(): $Commands;
        getCommands(): $Commands;
        get compressionThreshold(): number;
        getCompressionThreshold(): number;
        get connection(): $ServerConnectionListener;
        getConnection(): $ServerConnectionListener;
        get currentSmoothedTickTime(): number;
        getCurrentSmoothedTickTime(): number;
        get customBossEvents(): $CustomBossEvents;
        getCustomBossEvents(): $CustomBossEvents;
        get defaultGameType(): $GameType;
        getDefaultGameType(): $GameType;
        set defaultGameType(value: $GameType_);
        get fixerUpper(): $DataFixer;
        getFixerUpper(): $DataFixer;
        get forcedGameType(): $GameType;
        getForcedGameType(): $GameType;
        get functionCompilationLevel(): number;
        getFunctionCompilationLevel(): number;
        get functions(): $ServerFunctionManager;
        getFunctions(): $ServerFunctionManager;
        get gameRules(): $GameRules;
        getGameRules(): $GameRules;
        get keyPair(): $KeyPair;
        getKeyPair(): $KeyPair;
        get localIp(): string;
        getLocalIp(): string;
        set localIp(value: string);
        get maxChainedNeighborUpdates(): number;
        getMaxChainedNeighborUpdates(): number;
        get maxPlayers(): number;
        getMaxPlayers(): number;
        get moddedStatus(): $ModCheck;
        getModdedStatus(): $ModCheck;
        get motd(): string;
        getMotd(): string;
        set motd(value: string);
        get nextTickTime(): number;
        getNextTickTime(): number;
        get operatorUserPermissionLevel(): number;
        getOperatorUserPermissionLevel(): number;
        get packRepository(): $PackRepository;
        getPackRepository(): $PackRepository;
        get playerCount(): number;
        getPlayerCount(): number;
        get playerIdleTimeout(): number;
        getPlayerIdleTimeout(): number;
        set playerIdleTimeout(value: number);
        get playerList(): $PlayerList;
        getPlayerList(): $PlayerList;
        set playerList(value: $PlayerList);
        get playerNames(): string[];
        getPlayerNames(): string[];
        get port(): number;
        getPort(): number;
        set port(value: number);
        get preventProxyConnections(): boolean;
        getPreventProxyConnections(): boolean;
        set preventProxyConnections(value: boolean);
        get profileCache(): $GameProfileCache;
        getProfileCache(): $GameProfileCache;
        get profileKeySignatureValidator(): $SignatureValidator;
        getProfileKeySignatureValidator(): $SignatureValidator;
        get profileRepository(): $GameProfileRepository;
        getProfileRepository(): $GameProfileRepository;
        get profiler(): $ProfilerFiller;
        getProfiler(): $ProfilerFiller;
        get proxy(): $Proxy;
        getProxy(): $Proxy;
        get rateLimitPacketsPerSecond(): number;
        getRateLimitPacketsPerSecond(): number;
        get recipeManager(): $RecipeManager;
        getRecipeManager(): $RecipeManager;
        get resourceManager(): $ResourceManager;
        getResourceManager(): $ResourceManager;
        get runningThread(): $Thread;
        getRunningThread(): $Thread;
        get scoreboard(): $ServerScoreboard;
        getScoreboard(): $ServerScoreboard;
        get serverDirectory(): $Path;
        getServerDirectory(): $Path;
        get serverModName(): string;
        getServerModName(): string;
        get serverResourcePack(): $Optional<$MinecraftServer$ServerResourcePackInfo>;
        getServerResourcePack(): $Optional<$MinecraftServer$ServerResourcePackInfo>;
        get serverResources(): $MinecraftServer$ReloadableResources;
        getServerResources(): $MinecraftServer$ReloadableResources;
        get serverVersion(): string;
        getServerVersion(): string;
        get sessionService(): $MinecraftSessionService;
        getSessionService(): $MinecraftSessionService;
        get singleplayerProfile(): $GameProfile;
        getSingleplayerProfile(): $GameProfile;
        set singleplayerProfile(value: $GameProfile);
        get spawnProtectionRadius(): number;
        getSpawnProtectionRadius(): number;
        get statusJson(): string;
        getStatusJson(): string;
        get status(): $ServerStatus;
        getStatus(): $ServerStatus;
        get structureManager(): $StructureTemplateManager;
        getStructureManager(): $StructureTemplateManager;
        get tickCount(): number;
        getTickCount(): number;
        get tickTimesNanos(): number[];
        getTickTimesNanos(): number[];
        get worldData(): $WorldData;
        getWorldData(): $WorldData;
        get worldScreenshotFile(): $Optional<$Path>;
        getWorldScreenshotFile(): $Optional<$Path>;
        get commandBlockEnabled(): boolean;
        isCommandBlockEnabled(): boolean;
        get currentlySaving(): boolean;
        isCurrentlySaving(): boolean;
        get dedicatedServer(): boolean;
        isDedicatedServer(): boolean;
        get demo(): boolean;
        isDemo(): boolean;
        set demo(value: boolean);
        get enforceWhitelist(): boolean;
        isEnforceWhitelist(): boolean;
        set enforceWhitelist(value: boolean);
        get epollEnabled(): boolean;
        isEpollEnabled(): boolean;
        get flightAllowed(): boolean;
        isFlightAllowed(): boolean;
        set flightAllowed(value: boolean);
        get hardcore(): boolean;
        isHardcore(): boolean;
        get paused(): boolean;
        isPaused(): boolean;
        get published(): boolean;
        isPublished(): boolean;
        get pvpAllowed(): boolean;
        isPvpAllowed(): boolean;
        set pvpAllowed(value: boolean);
        get ready(): boolean;
        isReady(): boolean;
        get recordingMetrics(): boolean;
        isRecordingMetrics(): boolean;
        get resourcePackRequired(): boolean;
        isResourcePackRequired(): boolean;
        get running(): boolean;
        isRunning(): boolean;
        get shutdown(): boolean;
        isShutdown(): boolean;
        get singleplayer(): boolean;
        isSingleplayer(): boolean;
        get spawningAnimals(): boolean;
        isSpawningAnimals(): boolean;
        get spawningMonsters(): boolean;
        isSpawningMonsters(): boolean;
        get stopped(): boolean;
        isStopped(): boolean;
        get tickTimeLoggingEnabled(): boolean;
        isTickTimeLoggingEnabled(): boolean;
        get timeProfilerRunning(): boolean;
        isTimeProfilerRunning(): boolean;
        static configurePackRepository(arg0: $PackRepository, arg1: $WorldDataConfiguration, arg2: boolean, arg3: boolean): $WorldDataConfiguration;
        static setFatalException(arg0: $RuntimeException): void;
        static spin<S>(arg0: $Function<$Thread, S>): S;
        static throwIfFatalException(): boolean;
        acceptsFailure(): boolean;
        acceptsSuccess(): boolean;
        acceptsTransfers(): boolean;
        addTickable(arg0: $Runnable): void;
        areNpcsEnabled(): boolean;
        cancelRecordingMetrics(): void;
        close(): void;
        createCommandSourceStack(): $CommandSourceStack;
        createGameModeForPlayer(arg0: $ServerPlayer): $ServerPlayerGameMode;
        createTextFilterForPlayer(arg0: $ServerPlayer): $TextFilter;
        doRunTask(arg0: $TickTask): void;
        dumpServerProperties(arg0: string): void;
        endMetricsRecordingTick(): void;
        enforceSecureProfile(): boolean;
        executeIfPossible(arg0: $Runnable): void;
        fillServerSystemReport(arg0: $SystemReport): $SystemReport;
        fillSystemReport(arg0: $SystemReport): $SystemReport;
        finishRecordingMetrics(): void;
        forceSynchronousWrites(): boolean;
        forceTimeSynchronization(): void;
        forgeGetWorldMap(): $Map<$ResourceKey<$Level>, $ServerLevel>;
        getFile(arg0: string): $Path;
        getLevel(arg0: $ResourceKey<$Level>): $ServerLevel;
        getProfilePermissions(arg0: $GameProfile): number;
        getScaledTrackingDistance(arg0: number): number;
        getSpawnRadius(arg0: $ServerLevel): number;
        getTickTime(arg0: $ResourceKey<$Level>): number[];
        getWorldPath(arg0: $LevelResource): $Path;
        halt(arg0: boolean): void;
        hasGui(): boolean;
        hidesOnlinePlayers(): boolean;
        invalidateStatus(): void;
        isLevelEnabled(arg0: $Level): boolean;
        isSingleplayerOwner(arg0: $GameProfile): boolean;
        isUnderSpawnProtection(arg0: $ServerLevel, arg1: $BlockPos_, arg2: $Player): boolean;
        kickUnlistedPlayers(arg0: $CommandSourceStack): void;
        levelKeys(): $Set<$ResourceKey<$Level>>;
        logChatMessage(arg0: $Component_, arg1: $ChatType$Bound, arg2: string): void;
        logIPs(): boolean;
        managedBlock(arg0: $BooleanSupplier): void;
        markWorldsDirty(): void;
        data(): $AttachedData;
        onServerCrash(arg0: $CrashReport): void;
        onServerExit(): void;
        onTickRateChanged(): void;
        overworld(): $ServerLevel;
        pollTask(): boolean;
        potionBrewing(): $PotionBrewing;
        publishServer(arg0: $GameType_, arg1: boolean, arg2: number): boolean;
        registries(): $LayeredRegistryAccess<$RegistryLayer>;
        registryAccess(): $RegistryAccess$Frozen;
        reloadResources(arg0: string[]): $CompletableFuture<void>;
        reloadableRegistries(): $ReloadableServerRegistries$Holder;
        repliesToStatus(): boolean;
        reportChunkLoadFailure(arg0: $Throwable, arg1: $RegionStorageInfo, arg2: $ChunkPos): void;
        reportChunkSaveFailure(arg0: $Throwable, arg1: $RegionStorageInfo, arg2: $ChunkPos): void;
        saveAllChunks(arg0: boolean, arg1: boolean, arg2: boolean): boolean;
        saveEverything(arg0: boolean, arg1: boolean, arg2: boolean): boolean;
        scheduleExecutables(): boolean;
        sendSystemMessage(arg0: $Component_): void;
        serverLinks(): $ServerLinks;
        setDifficulty(arg0: $Difficulty_, arg1: boolean): void;
        shouldInformAdmins(): boolean;
        shouldRconBroadcast(): boolean;
        startRecordingMetrics(arg0: $Consumer<$ProfileResults>, arg1: $Consumer<string>): void;
        startTimeProfiler(): void;
        stopRecordingMetrics(): void;
        stopServer(): void;
        stopTimeProfiler(): $ProfileResults;
        subscribeToDebugSample(arg0: $ServerPlayer, arg1: $RemoteDebugSampleType_): void;
        tickChildren(arg0: $BooleanSupplier): void;
        tickRateManager(): $ServerTickRateManager;
        tickServer(arg0: $BooleanSupplier): void;
        usesAuthentication(): boolean;
        waitForTasks(): void;
    }

    export class $MinecraftServer$ReloadableResources extends $Record implements $AutoCloseable {
        constructor(resourceManager: $CloseableResourceManager, managers: $ReloadableServerResources);
        close(): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        managers(): $ReloadableServerResources;
        resourceManager(): $CloseableResourceManager;
        toString(): string;
    }

    export class $MinecraftServer$ServerResourcePackInfo extends $Record {
        constructor(id: string, url: string, hash: string, isRequired: boolean, prompt: $Component_);
        get required(): boolean;
        isRequired(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        hash(): string;
        id(): $UUID;
        prompt(): $Component;
        toString(): string;
        url(): string;
    }

    export class $PlayerAdvancements {
        constructor(arg0: $DataFixer, arg1: $PlayerList, arg2: $ServerAdvancementManager, arg3: string, arg4: $ServerPlayer);
        award(arg0: $AdvancementHolder, arg1: string): boolean;
        flushDirty(arg0: $ServerPlayer): void;
        getOrStartProgress(arg0: $AdvancementHolder): $AdvancementProgress;
        reload(arg0: $ServerAdvancementManager): void;
        revoke(arg0: $AdvancementHolder, arg1: string): boolean;
        save(): void;
        stopListening(): void;
    }

    export class $RegistryLayer {
        static DIMENSIONS: $RegistryLayer;
        static RELOADABLE: $RegistryLayer;
        static STATIC: $RegistryLayer;
        static WORLDGEN: $RegistryLayer;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RegistryLayer[];
        static valueOf(name: string): $RegistryLayer;
    }

    export class $ReloadableServerRegistries$Holder {
        constructor(arg0: $RegistryAccess$Frozen);
        getKeys(arg0: $ResourceKey<$Registry<any>>): $Collection<$ResourceLocation>;
        getLootTable(arg0: $ResourceKey<$LootTable>): $LootTable;
        get(): $RegistryAccess$Frozen;
        lookup(): $HolderGetter$Provider;
    }

    export class $ReloadableServerResources {
        get advancements(): $ServerAdvancementManager;
        getAdvancements(): $ServerAdvancementManager;
        get commands(): $Commands;
        getCommands(): $Commands;
        get conditionContext(): $ICondition$IContext;
        getConditionContext(): $ICondition$IContext;
        get functionLibrary(): $ServerFunctionLibrary;
        getFunctionLibrary(): $ServerFunctionLibrary;
        get recipeManager(): $RecipeManager;
        getRecipeManager(): $RecipeManager;
        get registryLookup(): $HolderLookup$Provider;
        getRegistryLookup(): $HolderLookup$Provider;
        static loadResources(arg0: $ResourceManager, arg1: $LayeredRegistryAccess<$RegistryLayer_>, arg2: $FeatureFlagSet, arg3: $Commands$CommandSelection_, arg4: number, arg5: $Executor, arg6: $Executor): $CompletableFuture<$ReloadableServerResources>;
        fullRegistries(): $ReloadableServerRegistries$Holder;
        listeners(): $List<$PreparableReloadListener>;
        updateRegistryTags(): void;
    }

    export class $ServerAdvancementManager extends $SimpleJsonResourceReloadListener {
        constructor(arg0: $HolderLookup$Provider);
        get allAdvancements(): $Collection<$AdvancementHolder>;
        getAllAdvancements(): $Collection<$AdvancementHolder>;
        get(arg0: $ResourceLocation_): $AdvancementHolder;
        tree(): $AdvancementTree;
    }

    export class $ServerFunctionLibrary implements $PreparableReloadListener {
        constructor(arg0: number, arg1: $CommandDispatcher<$CommandSourceStack>);
        static TYPE_KEY: $ResourceKey<$Registry<$CommandFunction<$CommandSourceStack>>>;
        get availableTags(): $Iterable<$ResourceLocation>;
        getAvailableTags(): $Iterable<$ResourceLocation>;
        get functions(): $Map<$ResourceLocation, $CommandFunction<$CommandSourceStack>>;
        getFunctions(): $Map<$ResourceLocation, $CommandFunction<$CommandSourceStack>>;
        getFunction(arg0: $ResourceLocation_): $Optional<$CommandFunction<$CommandSourceStack>>;
        getTag(arg0: $ResourceLocation_): $Collection<$CommandFunction<$CommandSourceStack>>;
        reload(arg0: $PreparableReloadListener$PreparationBarrier, arg1: $ResourceManager, arg2: $ProfilerFiller, arg3: $ProfilerFiller, arg4: $Executor, arg5: $Executor): $CompletableFuture<void>;
    }

    export class $ServerFunctionManager {
        constructor(arg0: $MinecraftServer, arg1: $ServerFunctionLibrary);
        get dispatcher(): $CommandDispatcher<$CommandSourceStack>;
        getDispatcher(): $CommandDispatcher<$CommandSourceStack>;
        get functionNames(): $Iterable<$ResourceLocation>;
        getFunctionNames(): $Iterable<$ResourceLocation>;
        get gameLoopSender(): $CommandSourceStack;
        getGameLoopSender(): $CommandSourceStack;
        get tagNames(): $Iterable<$ResourceLocation>;
        getTagNames(): $Iterable<$ResourceLocation>;
        execute(arg0: $CommandFunction<$CommandSourceStack>, arg1: $CommandSourceStack): void;
        getTag(arg0: $ResourceLocation_): $Collection<$CommandFunction<$CommandSourceStack>>;
        get(arg0: $ResourceLocation_): $Optional<$CommandFunction<$CommandSourceStack>>;
        replaceLibrary(arg0: $ServerFunctionLibrary): void;
        tick(): void;
    }

    export interface $ServerInfo {
        getMaxPlayers(): number;
        getMotd(): string;
        getPlayerCount(): number;
        getServerVersion(): string;
    }

    export class $ServerLinks extends $Record {
        constructor(arg0: $ServerLinks$Entry[]);
        static EMPTY: $ServerLinks;
        static TYPE_STREAM_CODEC: $StreamCodec<$ByteBuf, $Either<$ServerLinks$KnownLinkType, $Component>>;
        static UNTRUSTED_LINKS_STREAM_CODEC: $StreamCodec<$ByteBuf, $List<$ServerLinks$UntrustedEntry>>;
        get empty(): boolean;
        isEmpty(): boolean;
        entries(): $List<$ServerLinks$Entry>;
        equals(arg0: object): boolean;
        findKnownType(arg0: $ServerLinks$KnownLinkType_): $Optional<$ServerLinks$Entry>;
        hashCode(): number;
        toString(): string;
        untrust(): $List<$ServerLinks$UntrustedEntry>;
    }

    export class $ServerLinks$Entry extends $Record {
        constructor(arg0: $Either<$ServerLinks$KnownLinkType_, $Component_>, arg1: $URI);
        static custom(arg0: $Component_, arg1: $URI): $ServerLinks$Entry;
        static knownType(arg0: $ServerLinks$KnownLinkType_, arg1: $URI): $ServerLinks$Entry;
        displayName(): $Component;
        equals(arg0: object): boolean;
        hashCode(): number;
        link(): $URI;
        toString(): string;
        type(): $Either<$ServerLinks$KnownLinkType, $Component>;
    }

    export class $ServerLinks$KnownLinkType {
        static ANNOUNCEMENTS: $ServerLinks$KnownLinkType;
        static BUG_REPORT: $ServerLinks$KnownLinkType;
        static COMMUNITY: $ServerLinks$KnownLinkType;
        static COMMUNITY_GUIDELINES: $ServerLinks$KnownLinkType;
        static FEEDBACK: $ServerLinks$KnownLinkType;
        static FORUMS: $ServerLinks$KnownLinkType;
        static NEWS: $ServerLinks$KnownLinkType;
        static STATUS: $ServerLinks$KnownLinkType;
        static SUPPORT: $ServerLinks$KnownLinkType;
        static WEBSITE: $ServerLinks$KnownLinkType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerLinks$KnownLinkType[];
        static valueOf(name: string): $ServerLinks$KnownLinkType;
    }

    export class $ServerLinks$UntrustedEntry extends $Record {
        constructor(arg0: $Either<$ServerLinks$KnownLinkType_, $Component_>, arg1: string);
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerLinks$UntrustedEntry>;
        equals(arg0: object): boolean;
        hashCode(): number;
        link(): string;
        toString(): string;
        type(): $Either<$ServerLinks$KnownLinkType, $Component>;
    }

    export class $ServerScoreboard extends $Scoreboard {
        constructor(arg0: $MinecraftServer);
        addDirtyListener(arg0: $Runnable): void;
        addPlayerToTeam(arg0: string, arg1: $PlayerTeam): boolean;
        dataFactory(): $SavedData$Factory<$ScoreboardSaveData>;
        getObjectiveDisplaySlotCount(arg0: $Objective): number;
        getStartTrackingPackets(arg0: $Objective): $List<$Packet<any>>;
        getStopTrackingPackets(arg0: $Objective): $List<$Packet<any>>;
        onObjectiveAdded(arg0: $Objective): void;
        onObjectiveChanged(arg0: $Objective): void;
        onObjectiveRemoved(arg0: $Objective): void;
        onPlayerRemoved(arg0: $ScoreHolder): void;
        onPlayerScoreRemoved(arg0: $ScoreHolder, arg1: $Objective): void;
        onTeamAdded(arg0: $PlayerTeam): void;
        onTeamChanged(arg0: $PlayerTeam): void;
        onTeamRemoved(arg0: $PlayerTeam): void;
        removePlayerFromTeam(arg0: string, arg1: $PlayerTeam): void;
        setDisplayObjective(arg0: $DisplaySlot_, arg1: $Objective): void;
        startTrackingObjective(arg0: $Objective): void;
        stopTrackingObjective(arg0: $Objective): void;
    }

    export class $ServerTickRateManager extends $TickRateManager {
        constructor(arg0: $MinecraftServer);
        get sprinting(): boolean;
        isSprinting(): boolean;
        checkShouldSprintThisTick(): boolean;
        endTickWork(): void;
        requestGameToSprint(arg0: number): boolean;
        stepGameIfPaused(arg0: number): boolean;
        stopSprinting(): boolean;
        stopStepping(): boolean;
        updateJoiningPlayer(arg0: $ServerPlayer): void;
    }

    export class $Services extends $Record {
        constructor(arg0: $MinecraftSessionService, arg1: $ServicesKeySet, arg2: $GameProfileRepository, arg3: $GameProfileCache);
        static create(arg0: $YggdrasilAuthenticationService, arg1: string): $Services;
        canValidateProfileKeys(): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        profileCache(): $GameProfileCache;
        profileKeySignatureValidator(): $SignatureValidator;
        profileRepository(): $GameProfileRepository;
        servicesKeySet(): $ServicesKeySet;
        sessionService(): $MinecraftSessionService;
        toString(): string;
    }

    export class $TickTask implements $Runnable {
        constructor(arg0: number, arg1: $Runnable);
        get tick(): number;
        getTick(): number;
        run(): void;
    }

    export class $WorldLoader$PackConfig extends $Record {
        constructor(packRepository: $PackRepository, initialDataConfig: $WorldDataConfiguration, safeMode: boolean, initMode: boolean);
        createResourceManager(): $Pair<$WorldDataConfiguration, $CloseableResourceManager>;
        equals(arg0: object): boolean;
        hashCode(): number;
        initMode(): boolean;
        initialDataConfig(): $WorldDataConfiguration;
        packRepository(): $PackRepository;
        safeMode(): boolean;
        toString(): string;
    }

    export class $WorldStem extends $Record implements $AutoCloseable {
        constructor(arg0: $CloseableResourceManager, arg1: $ReloadableServerResources, arg2: $LayeredRegistryAccess<$RegistryLayer_>, arg3: $WorldData);
        close(): void;
        dataPackResources(): $ReloadableServerResources;
        equals(arg0: object): boolean;
        hashCode(): number;
        registries(): $LayeredRegistryAccess<$RegistryLayer>;
        resourceManager(): $CloseableResourceManager;
        toString(): string;
        worldData(): $WorldData;
    }

    export type $RegistryLayer_ = $RegistryLayer | "DIMENSIONS" | "RELOADABLE" | "STATIC" | "WORLDGEN";
    export type $ServerLinks$KnownLinkType_ = $ServerLinks$KnownLinkType | "ANNOUNCEMENTS" | "BUG_REPORT" | "COMMUNITY" | "COMMUNITY_GUIDELINES" | "FEEDBACK" | "FORUMS" | "NEWS" | "STATUS" | "SUPPORT" | "WEBSITE";
}
