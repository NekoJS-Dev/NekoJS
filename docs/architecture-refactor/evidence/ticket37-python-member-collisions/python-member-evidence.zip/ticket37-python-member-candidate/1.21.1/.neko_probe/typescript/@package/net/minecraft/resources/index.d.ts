import { $StringReader } from "java:com/mojang/brigadier";
import { $SimpleCommandExceptionType } from "java:com/mojang/brigadier/exceptions";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult, $Dynamic, $DynamicOps, $Lifecycle, $ListBuilder, $MapCodec, $MapLike, $RecordBuilder } from "java:com/mojang/serialization";
import { $RecordCodecBuilder } from "java:com/mojang/serialization/codecs";
import { $NekoId } from "java:com/tkisor/nekojs/api/data";
import { $ByteBuf } from "java:io/netty/buffer";
import { $Boolean, $Comparable, $Number, $Record, $String } from "java:java/lang";
import { $ByteBuffer } from "java:java/nio";
import { $List, $Map, $Optional } from "java:java/util";
import { $BiConsumer, $Consumer, $UnaryOperator } from "java:java/util/function";
import { $IntStream, $LongStream, $Stream } from "java:java/util/stream";
import { $Holder$Reference, $HolderGetter, $HolderLookup$Provider, $HolderLookup$RegistryLookup, $HolderOwner, $Registry } from "java:net/minecraft/core";
import { $StreamCodec } from "java:net/minecraft/network/codec";

declare module "java:net/minecraft/resources" {
    export class $DelegatingOps<T> implements $DynamicOps {
        compressMaps(): boolean;
        convertTo<U>(arg0: $DynamicOps<U>, arg1: T): U;
        createBoolean(arg0: boolean): T;
        createByteList(arg0: $ByteBuffer): T;
        createByte(arg0: number): T;
        createDouble(arg0: number): T;
        createFloat(arg0: number): T;
        createIntList(arg0: $IntStream): T;
        createInt(arg0: number): T;
        createList(arg0: $Stream<T>): T;
        createLongList(arg0: $LongStream): T;
        createLong(arg0: number): T;
        createMap(arg0: { [key: T]: T }): T;
        createMap(arg0: $Stream<$Pair<T, T>>): T;
        createNumeric(arg0: number): T;
        createShort(arg0: number): T;
        createString(arg0: string): T;
        emptyList(): T;
        emptyMap(): T;
        empty(): T;
        getBooleanValue(arg0: T): $DataResult<boolean>;
        getByteBuffer(arg0: T): $DataResult<$ByteBuffer>;
        getIntStream(arg0: T): $DataResult<$IntStream>;
        getList(arg0: T): $DataResult<$Consumer<$Consumer<T>>>;
        getLongStream(arg0: T): $DataResult<$LongStream>;
        getMapEntries(arg0: T): $DataResult<$Consumer<$BiConsumer<T, T>>>;
        getMapValues(arg0: T): $DataResult<$Stream<$Pair<T, T>>>;
        getMap(arg0: T): $DataResult<$MapLike<T>>;
        getNumberValue(arg0: T): $DataResult<number>;
        getStream(arg0: T): $DataResult<$Stream<T>>;
        getStringValue(arg0: T): $DataResult<string>;
        listBuilder(): $ListBuilder<T>;
        mapBuilder(): $RecordBuilder<T>;
        mergeToList(arg0: T, arg1: T): $DataResult<T>;
        mergeToList(arg0: T, arg1: T[]): $DataResult<T>;
        mergeToMap(arg0: T, arg1: T, arg2: T): $DataResult<T>;
        mergeToMap(arg0: T, arg1: $MapLike<T>): $DataResult<T>;
        mergeToMap(arg0: T, arg1: { [key: T]: T }): $DataResult<T>;
        mergeToPrimitive(arg0: T, arg1: T): $DataResult<T>;
        remove(arg0: T, arg1: string): T;
    }

    export class $RegistryOps<T> extends $DelegatingOps {
        lookupProvider: $RegistryOps$RegistryInfoLookup;
        static create<T>(arg0: $DynamicOps<T>, arg1: $HolderLookup$Provider): $RegistryOps<T>;
        static create<T>(arg0: $DynamicOps<T>, arg1: $RegistryOps$RegistryInfoLookup): $RegistryOps<T>;
        static injectRegistryContext<T>(arg0: $Dynamic<T>, arg1: $HolderLookup$Provider): $Dynamic<T>;
        static retrieveElement<E, O>(arg0: $ResourceKey<E>): $RecordCodecBuilder<O, $Holder$Reference<E>>;
        static retrieveGetter<E, O>(arg0: $ResourceKey<$Registry<E>>): $RecordCodecBuilder<O, $HolderGetter<E>>;
        static retrieveRegistryLookup<E>(arg0: $ResourceKey<$Registry<E>>): $MapCodec<$HolderLookup$RegistryLookup<E>>;
        equals(arg0: object): boolean;
        getter<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$HolderGetter<E>>;
        hashCode(): number;
        owner<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$HolderOwner<E>>;
        withParent<U>(arg0: $DynamicOps<U>): $RegistryOps<U>;
    }

    export class $RegistryOps$RegistryInfo<T> extends $Record {
        constructor(owner: $HolderOwner<T>, getter: $HolderGetter<T>, elementsLifecycle: $Lifecycle);
        get ter(): $HolderGetter<T>;
        getter(): $HolderGetter<T>;
        static fromRegistryLookup<T>(arg0: $HolderLookup$RegistryLookup<T>): $RegistryOps$RegistryInfo<T>;
        elementsLifecycle(): $Lifecycle;
        equals(arg0: object): boolean;
        hashCode(): number;
        owner(): $HolderOwner<T>;
        toString(): string;
    }

    export interface $RegistryOps$RegistryInfoLookup {
        lookup<T>(arg0: $ResourceKey<$Registry<T>>): $Optional<$RegistryOps$RegistryInfo<T>>;
    }

    export class $ResourceKey<T> implements $Comparable {
        static codec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$ResourceKey<T>>;
        static createRegistryKey<T>(arg0: $ResourceLocation_): $ResourceKey<$Registry<T>>;
        static create<T>(arg0: $ResourceKey<$Registry<T>>, arg1: $ResourceLocation_): $ResourceKey<T>;
        static streamCodec<T>(arg0: $ResourceKey<$Registry<T>>): $StreamCodec<$ByteBuf, $ResourceKey<T>>;
        cast<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$ResourceKey<E>>;
        compareTo(arg0: $ResourceKey<any>): number;
        isFor(arg0: $ResourceKey<$Registry<any>>): boolean;
        location(): $ResourceLocation;
        registryKey(): $ResourceKey<$Registry<T>>;
        registry(): $ResourceLocation;
        toString(): string;
    }

    export class $ResourceLocation implements $Comparable {
        static CODEC: $Codec<$ResourceLocation>;
        static DEFAULT_NAMESPACE: string;
        static ERROR_INVALID: $SimpleCommandExceptionType;
        static NAMESPACE_SEPARATOR: string;
        static REALMS_NAMESPACE: string;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ResourceLocation>;
        get namespace(): string;
        getNamespace(): string;
        get path(): string;
        getPath(): string;
        static bySeparator(arg0: string, arg1: string): $ResourceLocation;
        static fromNamespaceAndPath(arg0: string, arg1: string): $ResourceLocation;
        static isAllowedInResourceLocation(arg0: string): boolean;
        static isValidNamespace(arg0: string): boolean;
        static isValidPath(arg0: string): boolean;
        static parse(arg0: string): $ResourceLocation;
        static readNonEmpty(arg0: $StringReader): $ResourceLocation;
        static read(arg0: $StringReader): $ResourceLocation;
        static read(arg0: string): $DataResult<$ResourceLocation>;
        static tryBuild(arg0: string, arg1: string): $ResourceLocation;
        static tryBySeparator(arg0: string, arg1: string): $ResourceLocation;
        static tryParse(arg0: string): $ResourceLocation;
        static validNamespaceChar(arg0: string): boolean;
        static validPathChar(arg0: string): boolean;
        static withDefaultNamespace(arg0: string): $ResourceLocation;
        compareNamespaced(arg0: $ResourceLocation_): number;
        compareTo(arg0: $ResourceLocation_): number;
        equals(arg0: object): boolean;
        hashCode(): number;
        toDebugFileName(): string;
        toLanguageKey(arg0: string, arg1: string): string;
        toLanguageKey(arg0: string): string;
        toLanguageKey(): string;
        toShortLanguageKey(): string;
        toString(): string;
        withPath(arg0: string): $ResourceLocation;
        withPath(arg0: $UnaryOperator<string>): $ResourceLocation;
        withPrefix(arg0: string): $ResourceLocation;
        withSuffix(arg0: string): $ResourceLocation;
    }

    export type $ResourceLocation_ = $ResourceLocation | string | $NekoId;
}
