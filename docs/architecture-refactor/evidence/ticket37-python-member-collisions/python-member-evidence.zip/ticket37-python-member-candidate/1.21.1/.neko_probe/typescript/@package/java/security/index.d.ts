import { $Serializable } from "java:java/io";
import { $ClassLoader, $String } from "java:java/lang";
import { $URL } from "java:java/net";
import { $ByteBuffer } from "java:java/nio";
import { $Certificate } from "java:java/security/cert";
import { $AlgorithmParameterSpec } from "java:java/security/spec";
import { $Enumeration } from "java:java/util";
import { $Stream } from "java:java/util/stream";
import { $Destroyable, $Subject } from "java:javax/security/auth";

declare module "java:java/security" {
    export class $CodeSource implements $Serializable {
        constructor(arg0: $URL, arg1: $CodeSigner[]);
        constructor(arg0: $URL, arg1: $Certificate[]);
        get certificates(): $Certificate[];
        getCertificates(): $Certificate[];
        get codeSigners(): $CodeSigner[];
        getCodeSigners(): $CodeSigner[];
        get location(): $URL;
        getLocation(): $URL;
        equals(arg0: object): boolean;
        hashCode(): number;
        implies(arg0: $CodeSource): boolean;
        toString(): string;
    }

    export interface $Guard {
        checkGuard(arg0: object): void;
    }

    export interface $Key extends $Serializable {
        getAlgorithm(): string;
        getEncoded(): number[];
        getFormat(): string;
        static serialVersionUID: number;
    }

    export class $KeyPair implements $Serializable {
        constructor(arg0: $PublicKey, arg1: $PrivateKey);
        get private(): $PrivateKey;
        getPrivate(): $PrivateKey;
        get public(): $PublicKey;
        getPublic(): $PublicKey;
    }

    export class $Permission implements $Guard, $Serializable {
        constructor(arg0: string);
        get actions(): string;
        getActions(): string;
        get name(): string;
        getName(): string;
        checkGuard(arg0: object): void;
        equals(arg0: object): boolean;
        hashCode(): number;
        implies(arg0: $Permission): boolean;
        newPermissionCollection(): $PermissionCollection;
        toString(): string;
    }

    export class $PermissionCollection implements $Serializable {
        constructor();
        get readOnly(): boolean;
        isReadOnly(): boolean;
        add(arg0: $Permission): void;
        elementsAsStream(): $Stream<$Permission>;
        elements(): $Enumeration<$Permission>;
        implies(arg0: $Permission): boolean;
        setReadOnly(): void;
        toString(): string;
    }

    export interface $Principal {
        equals(arg0: object): boolean;
        getName(): string;
        hashCode(): number;
        implies(arg0: $Subject): boolean;
        toString(): string;
    }

    export interface $PrivateKey extends $Key, $Destroyable {
        static serialVersionUID: number;
    }

    export class $ProtectionDomain {
        constructor(arg0: $CodeSource, arg1: $PermissionCollection);
        constructor(arg0: $CodeSource, arg1: $PermissionCollection, arg2: $ClassLoader, arg3: $Principal[]);
        get classLoader(): $ClassLoader;
        getClassLoader(): $ClassLoader;
        get codeSource(): $CodeSource;
        getCodeSource(): $CodeSource;
        get permissions(): $PermissionCollection;
        getPermissions(): $PermissionCollection;
        get principals(): $Principal[];
        getPrincipals(): $Principal[];
        implies(arg0: $Permission): boolean;
        staticPermissionsOnly(): boolean;
        toString(): string;
    }

    export interface $PublicKey extends $Key {
        static serialVersionUID: number;
    }

    export class $Signature extends $SignatureSpi {
        get algorithm(): string;
        getAlgorithm(): string;
        get parameters(): $AlgorithmParameters;
        getParameters(): $AlgorithmParameters;
        get provider(): $Provider;
        getProvider(): $Provider;
        static getInstance(arg0: string, arg1: string): $Signature;
        static getInstance(arg0: string, arg1: $Provider): $Signature;
        static getInstance(arg0: string): $Signature;
        clone(): object;
        getParameter(arg0: string): object;
        initSign(arg0: $PrivateKey, arg1: $SecureRandom): void;
        initSign(arg0: $PrivateKey): void;
        initVerify(arg0: $PublicKey): void;
        initVerify(arg0: $Certificate): void;
        setParameter(arg0: string, arg1: object): void;
        sign(arg0: number[], arg1: number, arg2: number): number;
        sign(): number[];
        toString(): string;
        update(arg0: number[], arg1: number, arg2: number): void;
        update(arg0: number[]): void;
        update(arg0: number): void;
        update(arg0: $ByteBuffer): void;
        verify(arg0: number[], arg1: number, arg2: number): boolean;
        verify(arg0: number[]): boolean;
    }

}
