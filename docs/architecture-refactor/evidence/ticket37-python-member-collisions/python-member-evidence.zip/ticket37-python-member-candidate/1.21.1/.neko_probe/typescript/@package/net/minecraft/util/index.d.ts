import { $ServicesKeySet, $ServicesKeyType, $ServicesKeyType_ } from "java:com/mojang/authlib/yggdrasil";
import { $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult, $DynamicOps, $Keyable, $MapCodec } from "java:com/mojang/serialization";
import { $Int2IntFunction } from "java:it/unimi/dsi/fastutil/ints";
import { $Class, $Enum, $Integer, $Record, $Runnable, $String } from "java:java/lang";
import { $PublicKey } from "java:java/security";
import { $List } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $Consumer, $Function, $IntConsumer, $Supplier } from "java:java/util/function";
import { $Component, $Component_, $Style } from "java:net/minecraft/network/chat";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $PositionalRandomFactory } from "java:net/minecraft/world/level/levelgen";
import { $Logger } from "java:org/slf4j";

export * as datafix from "java:net/minecraft/util/datafix";
export * as debugchart from "java:net/minecraft/util/debugchart";
export * as profiling from "java:net/minecraft/util/profiling";
export * as random from "java:net/minecraft/util/random";
export * as thread from "java:net/minecraft/util/thread";
export * as valueproviders from "java:net/minecraft/util/valueproviders";

declare module "java:net/minecraft/util" {
    export interface $AbortableIterationConsumer<T> {
        accept(arg0: T): $AbortableIterationConsumer$Continuation;
        forConsumer<T>(arg0: $Consumer<T>): $AbortableIterationConsumer<T>;
    }

    export class $AbortableIterationConsumer$Continuation {
        static ABORT: $AbortableIterationConsumer$Continuation;
        static CONTINUE: $AbortableIterationConsumer$Continuation;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AbortableIterationConsumer$Continuation[];
        static valueOf(name: string): $AbortableIterationConsumer$Continuation;
    }

    export interface $BitStorage {
        copy(): $BitStorage;
        getAll(arg0: $IntConsumer): void;
        getAndSet(arg0: number, arg1: number): number;
        getBits(): number;
        getRaw(): number[];
        getSize(): number;
        get(arg0: number): number;
        set(arg0: number, arg1: number): void;
        unpack(arg0: number[]): void;
    }

    export class $ExtraCodecs$TagOrElementLocation extends $Record {
        constructor(arg0: $ResourceLocation_, arg1: boolean);
        decoratedId(): string;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        tag(): boolean;
        toString(): string;
    }

    export interface $FormattedCharSequence {
        accept(arg0: $FormattedCharSink): boolean;
        backward(arg0: string, arg1: $Style, arg2: $Int2IntFunction): $FormattedCharSequence;
        backward(arg0: string, arg1: $Style): $FormattedCharSequence;
        codepoint(arg0: number, arg1: $Style): $FormattedCharSequence;
        composite(arg0: $FormattedCharSequence[]): $FormattedCharSequence;
        composite(arg0?: $FormattedCharSequence[]): $FormattedCharSequence;
        composite(arg0: $FormattedCharSequence, arg1: $FormattedCharSequence): $FormattedCharSequence;
        composite(arg0: $FormattedCharSequence): $FormattedCharSequence;
        composite(): $FormattedCharSequence;
        decorateOutput(arg0: $FormattedCharSink, arg1: $Int2IntFunction): $FormattedCharSink;
        forward(arg0: string, arg1: $Style, arg2: $Int2IntFunction): $FormattedCharSequence;
        forward(arg0: string, arg1: $Style): $FormattedCharSequence;
        fromList(arg0: $FormattedCharSequence[]): $FormattedCharSequence;
        fromPair(arg0: $FormattedCharSequence, arg1: $FormattedCharSequence): $FormattedCharSequence;
        static EMPTY: $FormattedCharSequence;
    }

    export interface $FormattedCharSink {
        accept(arg0: number, arg1: $Style, arg2: number): boolean;
    }

    export class $InclusiveRange<T extends $Comparable<T>> extends $Record {
        constructor(arg0: T);
        constructor(arg0: T, arg1: T);
        static INT: $Codec<$InclusiveRange<number>>;
        static codec<T>(arg0: $Codec<T>, arg1: T, arg2: T): $Codec<$InclusiveRange<T>>;
        static codec<T>(arg0: $Codec<T>): $Codec<$InclusiveRange<T>>;
        static create<T>(arg0: T, arg1: T): $DataResult<$InclusiveRange<T>>;
        contains(arg0: $InclusiveRange<T>): boolean;
        equals(arg0: object): boolean;
        hashCode(): number;
        isValueInRange(arg0: T): boolean;
        maxInclusive(): T;
        minInclusive(): T;
        toString(): string;
    }

    export class $KeyDispatchDataCodec<A> extends $Record {
        constructor(arg0: $MapCodec<A>);
        static of<A>(arg0: $MapCodec<A>): $KeyDispatchDataCodec<A>;
        codec(): $MapCodec<A>;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $ModCheck extends $Record {
        constructor(arg0: $ModCheck$Confidence_, arg1: string);
        static identify(arg0: string, arg1: $Supplier<string>, arg2: string, arg3: $Class<any>): $ModCheck;
        confidence(): $ModCheck$Confidence;
        description(): string;
        equals(arg0: object): boolean;
        fullDescription(): string;
        hashCode(): number;
        merge(arg0: $ModCheck): $ModCheck;
        shouldReportAsModified(): boolean;
        toString(): string;
    }

    export class $ModCheck$Confidence {
        static DEFINITELY: $ModCheck$Confidence;
        static PROBABLY_NOT: $ModCheck$Confidence;
        static VERY_LIKELY: $ModCheck$Confidence;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ModCheck$Confidence[];
        static valueOf(name: string): $ModCheck$Confidence;
    }

    export interface $OptionEnum {
        getCaption(): $Component;
        getId(): number;
        getKey(): string;
    }

    export interface $ProblemReporter {
        forChild(arg0: string): $ProblemReporter;
        report(arg0: string): void;
    }

    export interface $ProgressListener {
        progressStagePercentage(arg0: number): void;
        progressStage(arg0: $Component_): void;
        progressStartNoAbort(arg0: $Component_): void;
        progressStart(arg0: $Component_): void;
        stop(): void;
    }

    export interface $RandomSource {
        consumeCount(arg0: number): void;
        createNewThreadLocalInstance(): $RandomSource;
        createThreadSafe(): $RandomSource;
        create(arg0: number): $RandomSource;
        create(): $RandomSource;
        forkPositional(): $PositionalRandomFactory;
        fork(): $RandomSource;
        nextBoolean(): boolean;
        nextDouble(): number;
        nextFloat(): number;
        nextGaussian(): number;
        nextIntBetweenInclusive(arg0: number, arg1: number): number;
        nextInt(arg0: number, arg1: number): number;
        nextInt(arg0: number): number;
        nextInt(): number;
        nextLong(): number;
        setSeed(arg0: number): void;
        triangle(arg0: number, arg1: number): number;
        static GAUSSIAN_SPREAD_FACTOR: number;
    }

    export interface $SignatureUpdater {
        update(arg0: $SignatureUpdater$Output): void;
    }

    export interface $SignatureUpdater$Output {
        update(arg0: number[]): void;
    }

    export interface $SignatureValidator {
        from(arg0: $ServicesKeySet, arg1: $ServicesKeyType_): $SignatureValidator;
        from(arg0: $PublicKey, arg1: string): $SignatureValidator;
        validate(arg0: number[], arg1: number[]): boolean;
        validate(arg0: $SignatureUpdater, arg1: number[]): boolean;
        static LOGGER: $Logger;
        static NO_VALIDATION: $SignatureValidator;
    }

    export class $StaticCache2D<T> {
        static create<T>(arg0: number, arg1: number, arg2: number, arg3: $StaticCache2D$Initializer<T>): $StaticCache2D<T>;
        contains(arg0: number, arg1: number): boolean;
        forEach(arg0: $Consumer<T>): void;
        get(arg0: number, arg1: number): T;
        toString(): string;
    }

    export interface $StaticCache2D$Initializer<T> {
        get(arg0: number, arg1: number): T;
    }

    export interface $StringRepresentable {
        createNameLookup<T>(arg0: T[], arg1: $Function<string, string>): $Function<string, T>;
        fromEnumWithMapping<E>(arg0: $Supplier<E[]>, arg1: $Function<string, string>): $StringRepresentable$EnumCodec<E>;
        fromEnum<E>(arg0: $Supplier<E[]>): $StringRepresentable$EnumCodec<E>;
        fromValues<T>(arg0: $Supplier<T[]>): $Codec<T>;
        getSerializedName(): string;
        keys(arg0: $StringRepresentable[]): $Keyable;
        static PRE_BUILT_MAP_THRESHOLD: number;
    }

    export class $StringRepresentable$EnumCodec<E extends $Enum<E>> extends $StringRepresentable$StringRepresentableCodec {
        constructor(arg0: E[], arg1: $Function<string, E>);
        byName(arg0: string, arg1: E): E;
        byName(arg0: string): E;
    }

    export class $StringRepresentable$StringRepresentableCodec<S extends $StringRepresentable> implements $Codec {
        constructor(arg0: S[], arg1: $Function<string, S>, arg2: $ToIntFunction<S>);
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<S, T>>;
        encode<T>(arg0: S, arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
    }

    export interface $TaskChainer {
        append(arg0: $Runnable): void;
        append<T>(arg0: $CompletableFuture<T>, arg1: $Consumer<T>): void;
        immediate(arg0: $Executor): $TaskChainer;
        static LOGGER: $Logger;
    }

    export class $Unit {
        static INSTANCE: $Unit;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Unit[];
        static valueOf(name: string): $Unit;
    }

    export type $AbortableIterationConsumer$Continuation_ = $AbortableIterationConsumer$Continuation | "ABORT" | "CONTINUE";
    export type $ModCheck$Confidence_ = $ModCheck$Confidence | "DEFINITELY" | "PROBABLY_NOT" | "VERY_LIKELY";
    export type $Unit_ = $Unit | "INSTANCE";
}
