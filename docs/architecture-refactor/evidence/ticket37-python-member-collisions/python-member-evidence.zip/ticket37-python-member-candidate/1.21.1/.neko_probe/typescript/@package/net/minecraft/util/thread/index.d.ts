import { $AutoCloseable, $Runnable, $String, $Void } from "java:java/lang";
import { $List } from "java:java/util";
import { $CompletableFuture, $Executor } from "java:java/util/concurrent";
import { $BooleanSupplier, $Consumer, $Function, $Supplier } from "java:java/util/function";
import { $MetricSampler, $ProfilerMeasured } from "java:net/minecraft/util/profiling/metrics";

declare module "java:net/minecraft/util/thread" {
    export class $BlockableEventLoop<R extends $Runnable> implements $ProfilerMeasured, $ProcessorHandle, $Executor {
        get pendingTasksCount(): number;
        getPendingTasksCount(): number;
        get sameThread(): boolean;
        isSameThread(): boolean;
        executeBlocking(arg0: $Runnable): void;
        executeIfPossible(arg0: $Runnable): void;
        execute(arg0: $Runnable): void;
        managedBlock(arg0: $BooleanSupplier): void;
        name(): string;
        pollTask(): boolean;
        profiledMetrics(): $List<$MetricSampler>;
        submitAsync(arg0: $Runnable): $CompletableFuture<void>;
        submit(arg0: $Runnable): $CompletableFuture<void>;
        submit<V>(arg0: $Supplier<V>): $CompletableFuture<V>;
        tell(arg0: R): void;
        waitForTasks(): void;
    }

    export interface $ProcessorHandle<Msg> extends $AutoCloseable {
        askEither<Source>(arg0: $Function<any, Msg>): $CompletableFuture<Source>;
        ask<Source>(arg0: $Function<any, Msg>): $CompletableFuture<Source>;
        close(): void;
        name(): string;
        of<Msg>(arg0: string, arg1: $Consumer<Msg>): $ProcessorHandle<Msg>;
        tell(arg0: Msg): void;
    }

    export class $ProcessorMailbox<T> implements $ProfilerMeasured, $ProcessorHandle, $AutoCloseable, $Runnable {
        constructor(arg0: $StrictQueue<any, $Runnable>, arg1: $Executor, arg2: string);
        static create(arg0: $Executor, arg1: string): $ProcessorMailbox<$Runnable>;
        close(): void;
        hasWork(): boolean;
        name(): string;
        profiledMetrics(): $List<$MetricSampler>;
        runAll(): void;
        run(): void;
        size(): number;
        tell(arg0: T): void;
        toString(): string;
    }

    export class $ReentrantBlockableEventLoop<R extends $Runnable> extends $BlockableEventLoop {
        constructor(arg0: string);
        doRunTask(arg0: R): void;
        scheduleExecutables(): boolean;
    }

    export interface $StrictQueue<T, F> {
        isEmpty(): boolean;
        pop(): F;
        push(arg0: T): boolean;
        size(): number;
    }

}
