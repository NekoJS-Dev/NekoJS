import { $TypeToken } from "java:com/google/common/reflect";
import { $App, $App2 } from "java:com/mojang/datafixers/kinds";
import { $Optional, $Set } from "java:java/util";
import { $Function } from "java:java/util/function";

declare module "java:com/mojang/datafixers/optics" {
    export interface $Optic<Proof extends $K1, S, T, A, B> {
        eval<P>(arg0: $App<Proof, P>): $Function<$App2<P, A, B>, $App2<P, S, T>>;
        upCast<Proof2>(arg0: $TypeToken<$K1>[], arg1: $TypeToken<Proof2>): $Optional<$Optic<any, S, T, A, B>>;
    }

}
