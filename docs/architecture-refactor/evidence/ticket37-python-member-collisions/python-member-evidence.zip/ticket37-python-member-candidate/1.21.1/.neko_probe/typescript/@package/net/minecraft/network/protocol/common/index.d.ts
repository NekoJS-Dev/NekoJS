import { $Enum, $Record, $String } from "java:java/lang";
import { $UUID } from "java:java/util";
import { $FriendlyByteBuf, $RegistryFriendlyByteBuf } from "java:net/minecraft/network";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $CustomPacketPayload } from "java:net/minecraft/network/protocol/common/custom";
import { $ServerCookiePacketListener } from "java:net/minecraft/network/protocol/cookie";
import { $ServerPacketListener } from "java:net/minecraft/network/protocol/game";
import { $ClientInformation } from "java:net/minecraft/server/level";
import { $IServerCommonPacketListenerExtension } from "java:net/neoforged/neoforge/common/extensions";

export * as custom from "java:net/minecraft/network/protocol/common/custom";

declare module "java:net/minecraft/network/protocol/common" {
    export class $ClientboundCustomPayloadPacket extends $Record implements $Packet {
        constructor(payload: $CustomPacketPayload);
        static CONFIG_STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ClientboundCustomPayloadPacket>;
        static GAMEPLAY_STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundCustomPayloadPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ClientCommonPacketListener): void;
        hashCode(): number;
        payload(): $CustomPacketPayload;
        toString(): string;
        type(): $PacketType<$ClientboundCustomPayloadPacket>;
    }

    export interface $ServerCommonPacketListener extends $ServerCookiePacketListener, $ServerPacketListener, $IServerCommonPacketListenerExtension {
        handleClientInformation(arg0: $ServerboundClientInformationPacket): void;
        handleCustomPayload(arg0: $ServerboundCustomPayloadPacket): void;
        handleKeepAlive(arg0: $ServerboundKeepAlivePacket): void;
        handlePong(arg0: $ServerboundPongPacket): void;
        handleResourcePackResponse(arg0: $ServerboundResourcePackPacket): void;
    }

    export class $ServerboundClientInformationPacket extends $Record implements $Packet {
        constructor(arg0: $ClientInformation);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundClientInformationPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCommonPacketListener): void;
        hashCode(): number;
        information(): $ClientInformation;
        toString(): string;
        type(): $PacketType<$ServerboundClientInformationPacket>;
    }

    export class $ServerboundCustomPayloadPacket extends $Record implements $Packet {
        constructor(payload: $CustomPacketPayload);
        static CONFIG_STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCustomPayloadPacket>;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCustomPayloadPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCommonPacketListener): void;
        hashCode(): number;
        payload(): $CustomPacketPayload;
        toString(): string;
        type(): $PacketType<$ServerboundCustomPayloadPacket>;
    }

    export class $ServerboundKeepAlivePacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundKeepAlivePacket>;
        get id(): number;
        getId(): number;
        handle(arg0: $ServerCommonPacketListener): void;
        type(): $PacketType<$ServerboundKeepAlivePacket>;
    }

    export class $ServerboundPongPacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPongPacket>;
        get id(): number;
        getId(): number;
        handle(arg0: $ServerCommonPacketListener): void;
        type(): $PacketType<$ServerboundPongPacket>;
    }

    export class $ServerboundResourcePackPacket extends $Record implements $Packet {
        constructor(arg0: string, arg1: $ServerboundResourcePackPacket$Action_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundResourcePackPacket>;
        action(): $ServerboundResourcePackPacket$Action;
        equals(arg0: object): boolean;
        handle(arg0: $ServerCommonPacketListener): void;
        hashCode(): number;
        id(): $UUID;
        toString(): string;
        type(): $PacketType<$ServerboundResourcePackPacket>;
    }

    export class $ServerboundResourcePackPacket$Action {
        static ACCEPTED: $ServerboundResourcePackPacket$Action;
        static DECLINED: $ServerboundResourcePackPacket$Action;
        static DISCARDED: $ServerboundResourcePackPacket$Action;
        static DOWNLOADED: $ServerboundResourcePackPacket$Action;
        static FAILED_DOWNLOAD: $ServerboundResourcePackPacket$Action;
        static FAILED_RELOAD: $ServerboundResourcePackPacket$Action;
        static INVALID_URL: $ServerboundResourcePackPacket$Action;
        static SUCCESSFULLY_LOADED: $ServerboundResourcePackPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundResourcePackPacket$Action[];
        static valueOf(name: string): $ServerboundResourcePackPacket$Action;
    }

    export type $ServerboundResourcePackPacket$Action_ = $ServerboundResourcePackPacket$Action | "ACCEPTED" | "DECLINED" | "DISCARDED" | "DOWNLOADED" | "FAILED_DOWNLOAD" | "FAILED_RELOAD" | "INVALID_URL" | "SUCCESSFULLY_LOADED";
}
