import { $ByteBuf } from "java:io/netty/buffer";
import { $Int2ObjectMap } from "java:it/unimi/dsi/fastutil/ints";
import { $Enum, $Exception, $Record, $String } from "java:java/lang";
import { $Instant } from "java:java/time";
import { $BitSet, $List, $Optional, $UUID } from "java:java/util";
import { $BiFunction, $Consumer } from "java:java/util/function";
import { $AdvancementHolder } from "java:net/minecraft/advancements";
import { $ArgumentSignatures } from "java:net/minecraft/commands/arguments";
import { $BlockPos, $BlockPos_, $Direction, $Direction_, $GlobalPos, $Holder, $Holder_, $RegistryAccess, $Vec3i } from "java:net/minecraft/core";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ConnectionProtocol, $ConnectionProtocol_, $FriendlyByteBuf, $RegistryFriendlyByteBuf, $ServerboundPacketListener } from "java:net/minecraft/network";
import { $LastSeenMessages$Update, $MessageSignature, $RemoteChatSession$Data } from "java:net/minecraft/network/chat";
import { $StreamCodec } from "java:net/minecraft/network/codec";
import { $Packet, $PacketType } from "java:net/minecraft/network/protocol";
import { $ServerCommonPacketListener } from "java:net/minecraft/network/protocol/common";
import { $ServerPingPacketListener } from "java:net/minecraft/network/protocol/ping";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RemoteDebugSampleType, $RemoteDebugSampleType_ } from "java:net/minecraft/util/debugchart";
import { $Difficulty, $Difficulty_, $InteractionHand, $InteractionHand_ } from "java:net/minecraft/world";
import { $MobEffect, $MobEffect_ } from "java:net/minecraft/world/effect";
import { $Entity, $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";
import { $ClickType, $ClickType_, $RecipeBookType, $RecipeBookType_ } from "java:net/minecraft/world/inventory";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $BaseCommandBlock, $GameType, $GameType_, $Level } from "java:net/minecraft/world/level";
import { $Mirror, $Mirror_, $Rotation, $Rotation_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_, $CommandBlockEntity$Mode, $CommandBlockEntity$Mode_, $JigsawBlockEntity$JointType, $JigsawBlockEntity$JointType_, $StructureBlockEntity$UpdateType, $StructureBlockEntity$UpdateType_ } from "java:net/minecraft/world/level/block/entity";
import { $StructureMode, $StructureMode_ } from "java:net/minecraft/world/level/block/state/properties";
import { $LevelChunk } from "java:net/minecraft/world/level/chunk";
import { $DimensionType } from "java:net/minecraft/world/level/dimension";
import { $BlockHitResult, $Vec3, $Vec3_ } from "java:net/minecraft/world/phys";
import { $IServerGamePacketListenerExtension } from "java:net/neoforged/neoforge/common/extensions";
import { $Logger } from "java:org/slf4j";

declare module "java:net/minecraft/network/protocol/game" {
    export class $ClientboundAddEntityPacket implements $Packet {
        constructor(arg0: number, arg1: string, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: $EntityType<any>, arg8: number, arg9: $Vec3_, arg10: number);
        constructor(arg0: $Entity, arg1: number, arg2: $BlockPos_);
        constructor(arg0: $Entity, arg1: $ServerEntity);
        constructor(arg0: $Entity, arg1: $ServerEntity, arg2: number);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundAddEntityPacket>;
        get data(): number;
        getData(): number;
        get id(): number;
        getId(): number;
        get type(): $EntityType<any>;
        getType(): $EntityType<any>;
        get uUID(): $UUID;
        getUUID(): $UUID;
        get xRot(): number;
        getXRot(): number;
        get xa(): number;
        getXa(): number;
        get x(): number;
        getX(): number;
        get yHeadRot(): number;
        getYHeadRot(): number;
        get yRot(): number;
        getYRot(): number;
        get ya(): number;
        getYa(): number;
        get y(): number;
        getY(): number;
        get za(): number;
        getZa(): number;
        get z(): number;
        getZ(): number;
        handle(arg0: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundAddEntityPacket>;
    }

    export class $ClientboundBlockEntityDataPacket implements $Packet {
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundBlockEntityDataPacket>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get tag(): $CompoundTag;
        getTag(): $CompoundTag;
        get type(): $BlockEntityType<any>;
        getType(): $BlockEntityType<any>;
        static create(arg0: $BlockEntity, arg1: $BiFunction<$BlockEntity, $RegistryAccess, $CompoundTag_>): $ClientboundBlockEntityDataPacket;
        static create(arg0: $BlockEntity): $ClientboundBlockEntityDataPacket;
        handle(arg0: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundBlockEntityDataPacket>;
    }

    export class $ClientboundLevelChunkPacketData {
        constructor(arg0: $RegistryFriendlyByteBuf, arg1: number, arg2: number);
        constructor(arg0: $LevelChunk);
        get heightmaps(): $CompoundTag;
        getHeightmaps(): $CompoundTag;
        get readBuffer(): $FriendlyByteBuf;
        getReadBuffer(): $FriendlyByteBuf;
        static extractChunkData(arg0: $FriendlyByteBuf, arg1: $LevelChunk): void;
        getBlockEntitiesTagsConsumer(arg0: number, arg1: number): $Consumer<$ClientboundLevelChunkPacketData$BlockEntityTagOutput>;
        write(arg0: $RegistryFriendlyByteBuf): void;
    }

    export interface $ClientboundLevelChunkPacketData$BlockEntityTagOutput {
        accept(arg0: $BlockPos_, arg1: $BlockEntityType<any>, arg2: $CompoundTag_): void;
    }

    export class $ClientboundLevelChunkWithLightPacket implements $Packet {
        constructor(arg0: $LevelChunk, arg1: $LevelLightEngine, arg2: $BitSet, arg3: $BitSet);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ClientboundLevelChunkWithLightPacket>;
        get chunkData(): $ClientboundLevelChunkPacketData;
        getChunkData(): $ClientboundLevelChunkPacketData;
        get lightData(): $ClientboundLightUpdatePacketData;
        getLightData(): $ClientboundLightUpdatePacketData;
        get x(): number;
        getX(): number;
        get z(): number;
        getZ(): number;
        handle(arg0: $ClientGamePacketListener): void;
        type(): $PacketType<$ClientboundLevelChunkWithLightPacket>;
    }

    export class $ClientboundLightUpdatePacketData {
        constructor(arg0: $FriendlyByteBuf, arg1: number, arg2: number);
        constructor(arg0: $ChunkPos, arg1: $LevelLightEngine, arg2: $BitSet, arg3: $BitSet);
        get blockUpdates(): $List<number[]>;
        getBlockUpdates(): $List<number[]>;
        get blockYMask(): $BitSet;
        getBlockYMask(): $BitSet;
        get emptyBlockYMask(): $BitSet;
        getEmptyBlockYMask(): $BitSet;
        get emptySkyYMask(): $BitSet;
        getEmptySkyYMask(): $BitSet;
        get skyUpdates(): $List<number[]>;
        getSkyUpdates(): $List<number[]>;
        get skyYMask(): $BitSet;
        getSkyYMask(): $BitSet;
        write(arg0: $FriendlyByteBuf): void;
    }

    export class $CommonPlayerSpawnInfo extends $Record {
        constructor(arg0: $Holder<$DimensionType>, arg1: $ResourceKey<$Level>, arg2: number, arg3: $GameType_, arg4: $GameType_, arg5: boolean, arg6: boolean, arg7: $Optional<$GlobalPos>, arg8: number);
        constructor(arg0: $RegistryFriendlyByteBuf);
        get debug(): boolean;
        isDebug(): boolean;
        get flat(): boolean;
        isFlat(): boolean;
        dimensionType(): $Holder<$DimensionType>;
        dimension(): $ResourceKey<$Level>;
        equals(arg0: object): boolean;
        gameType(): $GameType;
        hashCode(): number;
        lastDeathLocation(): $Optional<$GlobalPos>;
        portalCooldown(): number;
        previousGameType(): $GameType;
        seed(): number;
        toString(): string;
        write(arg0: $RegistryFriendlyByteBuf): void;
    }

    export interface $ServerGamePacketListener extends $ServerPingPacketListener, $ServerCommonPacketListener, $IServerGamePacketListenerExtension {
        handleAcceptTeleportPacket(arg0: $ServerboundAcceptTeleportationPacket): void;
        handleAnimate(arg0: $ServerboundSwingPacket): void;
        handleBlockEntityTagQuery(arg0: $ServerboundBlockEntityTagQueryPacket): void;
        handleChangeDifficulty(arg0: $ServerboundChangeDifficultyPacket): void;
        handleChatAck(arg0: $ServerboundChatAckPacket): void;
        handleChatCommand(arg0: $ServerboundChatCommandPacket): void;
        handleChatSessionUpdate(arg0: $ServerboundChatSessionUpdatePacket): void;
        handleChat(arg0: $ServerboundChatPacket): void;
        handleChunkBatchReceived(arg0: $ServerboundChunkBatchReceivedPacket): void;
        handleClientCommand(arg0: $ServerboundClientCommandPacket): void;
        handleConfigurationAcknowledged(arg0: $ServerboundConfigurationAcknowledgedPacket): void;
        handleContainerButtonClick(arg0: $ServerboundContainerButtonClickPacket): void;
        handleContainerClick(arg0: $ServerboundContainerClickPacket): void;
        handleContainerClose(arg0: $ServerboundContainerClosePacket): void;
        handleContainerSlotStateChanged(arg0: $ServerboundContainerSlotStateChangedPacket): void;
        handleCustomCommandSuggestions(arg0: $ServerboundCommandSuggestionPacket): void;
        handleDebugSampleSubscription(arg0: $ServerboundDebugSampleSubscriptionPacket): void;
        handleEditBook(arg0: $ServerboundEditBookPacket): void;
        handleEntityTagQuery(arg0: $ServerboundEntityTagQueryPacket): void;
        handleInteract(arg0: $ServerboundInteractPacket): void;
        handleJigsawGenerate(arg0: $ServerboundJigsawGeneratePacket): void;
        handleLockDifficulty(arg0: $ServerboundLockDifficultyPacket): void;
        handleMovePlayer(arg0: $ServerboundMovePlayerPacket): void;
        handleMoveVehicle(arg0: $ServerboundMoveVehiclePacket): void;
        handlePaddleBoat(arg0: $ServerboundPaddleBoatPacket): void;
        handlePickItem(arg0: $ServerboundPickItemPacket): void;
        handlePlaceRecipe(arg0: $ServerboundPlaceRecipePacket): void;
        handlePlayerAbilities(arg0: $ServerboundPlayerAbilitiesPacket): void;
        handlePlayerAction(arg0: $ServerboundPlayerActionPacket): void;
        handlePlayerCommand(arg0: $ServerboundPlayerCommandPacket): void;
        handlePlayerInput(arg0: $ServerboundPlayerInputPacket): void;
        handleRecipeBookChangeSettingsPacket(arg0: $ServerboundRecipeBookChangeSettingsPacket): void;
        handleRecipeBookSeenRecipePacket(arg0: $ServerboundRecipeBookSeenRecipePacket): void;
        handleRenameItem(arg0: $ServerboundRenameItemPacket): void;
        handleSeenAdvancements(arg0: $ServerboundSeenAdvancementsPacket): void;
        handleSelectTrade(arg0: $ServerboundSelectTradePacket): void;
        handleSetBeaconPacket(arg0: $ServerboundSetBeaconPacket): void;
        handleSetCarriedItem(arg0: $ServerboundSetCarriedItemPacket): void;
        handleSetCommandBlock(arg0: $ServerboundSetCommandBlockPacket): void;
        handleSetCommandMinecart(arg0: $ServerboundSetCommandMinecartPacket): void;
        handleSetCreativeModeSlot(arg0: $ServerboundSetCreativeModeSlotPacket): void;
        handleSetJigsawBlock(arg0: $ServerboundSetJigsawBlockPacket): void;
        handleSetStructureBlock(arg0: $ServerboundSetStructureBlockPacket): void;
        handleSignUpdate(arg0: $ServerboundSignUpdatePacket): void;
        handleSignedChatCommand(arg0: $ServerboundChatCommandSignedPacket): void;
        handleTeleportToEntityPacket(arg0: $ServerboundTeleportToEntityPacket): void;
        handleUseItemOn(arg0: $ServerboundUseItemOnPacket): void;
        handleUseItem(arg0: $ServerboundUseItemPacket): void;
        protocol(): $ConnectionProtocol;
    }

    export interface $ServerPacketListener extends $ServerboundPacketListener {
        onPacketError(arg0: $Packet, arg1: $Exception): void;
        static LOGGER: $Logger;
    }

    export class $ServerboundAcceptTeleportationPacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundAcceptTeleportationPacket>;
        get id(): number;
        getId(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundAcceptTeleportationPacket>;
    }

    export class $ServerboundBlockEntityTagQueryPacket implements $Packet {
        constructor(arg0: number, arg1: $BlockPos_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundBlockEntityTagQueryPacket>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get transactionId(): number;
        getTransactionId(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundBlockEntityTagQueryPacket>;
    }

    export class $ServerboundChangeDifficultyPacket implements $Packet {
        constructor(arg0: $Difficulty_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChangeDifficultyPacket>;
        get difficulty(): $Difficulty;
        getDifficulty(): $Difficulty;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundChangeDifficultyPacket>;
    }

    export class $ServerboundChatAckPacket extends $Record implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatAckPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        offset(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChatAckPacket>;
    }

    export class $ServerboundChatCommandPacket extends $Record implements $Packet {
        constructor(arg0: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatCommandPacket>;
        command(): string;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChatCommandPacket>;
    }

    export class $ServerboundChatCommandSignedPacket extends $Record implements $Packet {
        constructor(arg0: string, arg1: $Instant, arg2: number, arg3: $ArgumentSignatures, arg4: $LastSeenMessages$Update);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatCommandSignedPacket>;
        argumentSignatures(): $ArgumentSignatures;
        command(): string;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        lastSeenMessages(): $LastSeenMessages$Update;
        salt(): number;
        timeStamp(): $Instant;
        toString(): string;
        type(): $PacketType<$ServerboundChatCommandSignedPacket>;
    }

    export class $ServerboundChatPacket extends $Record implements $Packet {
        constructor(arg0: string, arg1: $Instant, arg2: number, arg3: $MessageSignature, arg4: $LastSeenMessages$Update);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        lastSeenMessages(): $LastSeenMessages$Update;
        message(): string;
        salt(): number;
        signature(): $MessageSignature;
        timeStamp(): $Instant;
        toString(): string;
        type(): $PacketType<$ServerboundChatPacket>;
    }

    export class $ServerboundChatSessionUpdatePacket extends $Record implements $Packet {
        constructor(arg0: $RemoteChatSession$Data);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChatSessionUpdatePacket>;
        chatSession(): $RemoteChatSession$Data;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChatSessionUpdatePacket>;
    }

    export class $ServerboundChunkBatchReceivedPacket extends $Record implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundChunkBatchReceivedPacket>;
        desiredChunksPerTick(): number;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundChunkBatchReceivedPacket>;
    }

    export class $ServerboundClientCommandPacket implements $Packet {
        constructor(arg0: $ServerboundClientCommandPacket$Action_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundClientCommandPacket>;
        get action(): $ServerboundClientCommandPacket$Action;
        getAction(): $ServerboundClientCommandPacket$Action;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundClientCommandPacket>;
    }

    export class $ServerboundClientCommandPacket$Action {
        static PERFORM_RESPAWN: $ServerboundClientCommandPacket$Action;
        static REQUEST_STATS: $ServerboundClientCommandPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundClientCommandPacket$Action[];
        static valueOf(name: string): $ServerboundClientCommandPacket$Action;
    }

    export class $ServerboundCommandSuggestionPacket implements $Packet {
        constructor(arg0: number, arg1: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundCommandSuggestionPacket>;
        get command(): string;
        getCommand(): string;
        get id(): number;
        getId(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundCommandSuggestionPacket>;
    }

    export class $ServerboundConfigurationAcknowledgedPacket implements $Packet {
        static INSTANCE: $ServerboundConfigurationAcknowledgedPacket;
        static STREAM_CODEC: $StreamCodec<$ByteBuf, $ServerboundConfigurationAcknowledgedPacket>;
        get terminal(): boolean;
        isTerminal(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundConfigurationAcknowledgedPacket>;
    }

    export class $ServerboundContainerButtonClickPacket extends $Record implements $Packet {
        constructor(arg0: number, arg1: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundContainerButtonClickPacket>;
        buttonId(): number;
        containerId(): number;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        toString(): string;
        type(): $PacketType<$ServerboundContainerButtonClickPacket>;
    }

    export class $ServerboundContainerClickPacket implements $Packet {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: $ClickType_, arg5: $ItemStack_, arg6: $Int2ObjectMap<$ItemStack_>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ServerboundContainerClickPacket>;
        get buttonNum(): number;
        getButtonNum(): number;
        get carriedItem(): $ItemStack;
        getCarriedItem(): $ItemStack;
        get changedSlots(): $Int2ObjectMap<$ItemStack>;
        getChangedSlots(): $Int2ObjectMap<$ItemStack>;
        get clickType(): $ClickType;
        getClickType(): $ClickType;
        get containerId(): number;
        getContainerId(): number;
        get slotNum(): number;
        getSlotNum(): number;
        get stateId(): number;
        getStateId(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundContainerClickPacket>;
    }

    export class $ServerboundContainerClosePacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundContainerClosePacket>;
        get containerId(): number;
        getContainerId(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundContainerClosePacket>;
    }

    export class $ServerboundContainerSlotStateChangedPacket extends $Record implements $Packet {
        constructor(arg0: number, arg1: number, arg2: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundContainerSlotStateChangedPacket>;
        containerId(): number;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        newState(): boolean;
        slotId(): number;
        toString(): string;
        type(): $PacketType<$ServerboundContainerSlotStateChangedPacket>;
    }

    export class $ServerboundDebugSampleSubscriptionPacket extends $Record implements $Packet {
        constructor(arg0: $RemoteDebugSampleType_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundDebugSampleSubscriptionPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        sampleType(): $RemoteDebugSampleType;
        toString(): string;
        type(): $PacketType<$ServerboundDebugSampleSubscriptionPacket>;
    }

    export class $ServerboundEditBookPacket extends $Record implements $Packet {
        constructor(arg0: number, arg1: string[], arg2: $Optional<string>);
        static MAX_BYTES_PER_CHAR: number;
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundEditBookPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        pages(): $List<string>;
        slot(): number;
        title(): $Optional<string>;
        toString(): string;
        type(): $PacketType<$ServerboundEditBookPacket>;
    }

    export class $ServerboundEntityTagQueryPacket implements $Packet {
        constructor(arg0: number, arg1: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundEntityTagQueryPacket>;
        get entityId(): number;
        getEntityId(): number;
        get transactionId(): number;
        getTransactionId(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundEntityTagQueryPacket>;
    }

    export class $ServerboundInteractPacket implements $Packet {
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundInteractPacket>;
        get usingSecondaryAction(): boolean;
        isUsingSecondaryAction(): boolean;
        static createAttackPacket(arg0: $Entity, arg1: boolean): $ServerboundInteractPacket;
        static createInteractionPacket(arg0: $Entity, arg1: boolean, arg2: $InteractionHand_, arg3: $Vec3_): $ServerboundInteractPacket;
        static createInteractionPacket(arg0: $Entity, arg1: boolean, arg2: $InteractionHand_): $ServerboundInteractPacket;
        dispatch(arg0: $ServerboundInteractPacket$Handler): void;
        getTarget(arg0: $ServerLevel): $Entity;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundInteractPacket>;
    }

    export interface $ServerboundInteractPacket$Handler {
        onAttack(): void;
        onInteraction(arg0: $InteractionHand_, arg1: $Vec3_): void;
        onInteraction(arg0: $InteractionHand_): void;
    }

    export class $ServerboundJigsawGeneratePacket implements $Packet {
        constructor(arg0: $BlockPos_, arg1: number, arg2: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundJigsawGeneratePacket>;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        handle(arg0: $ServerGamePacketListener): void;
        keepJigsaws(): boolean;
        levels(): number;
        type(): $PacketType<$ServerboundJigsawGeneratePacket>;
    }

    export class $ServerboundLockDifficultyPacket implements $Packet {
        constructor(arg0: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundLockDifficultyPacket>;
        get locked(): boolean;
        isLocked(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundLockDifficultyPacket>;
    }

    export class $ServerboundMovePlayerPacket implements $Packet {
        get onGround(): boolean;
        isOnGround(): boolean;
        getXRot(arg0: number): number;
        getX(arg0: number): number;
        getYRot(arg0: number): number;
        getY(arg0: number): number;
        getZ(arg0: number): number;
        handle(arg0: $ServerGamePacketListener): void;
        hasPosition(): boolean;
        hasRotation(): boolean;
        type(): $PacketType<$ServerboundMovePlayerPacket>;
    }

    export class $ServerboundMoveVehiclePacket implements $Packet {
        constructor(arg0: $Entity);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundMoveVehiclePacket>;
        get xRot(): number;
        getXRot(): number;
        get x(): number;
        getX(): number;
        get yRot(): number;
        getYRot(): number;
        get y(): number;
        getY(): number;
        get z(): number;
        getZ(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundMoveVehiclePacket>;
    }

    export class $ServerboundPaddleBoatPacket implements $Packet {
        constructor(arg0: boolean, arg1: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPaddleBoatPacket>;
        get left(): boolean;
        getLeft(): boolean;
        get right(): boolean;
        getRight(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPaddleBoatPacket>;
    }

    export class $ServerboundPickItemPacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPickItemPacket>;
        get slot(): number;
        getSlot(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPickItemPacket>;
    }

    export class $ServerboundPlaceRecipePacket implements $Packet {
        constructor(arg0: number, arg1: $RecipeHolder<any>, arg2: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlaceRecipePacket>;
        get containerId(): number;
        getContainerId(): number;
        get recipe(): $ResourceLocation;
        getRecipe(): $ResourceLocation;
        get shiftDown(): boolean;
        isShiftDown(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPlaceRecipePacket>;
    }

    export class $ServerboundPlayerAbilitiesPacket implements $Packet {
        constructor(arg0: $Abilities);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlayerAbilitiesPacket>;
        get flying(): boolean;
        isFlying(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPlayerAbilitiesPacket>;
    }

    export class $ServerboundPlayerActionPacket implements $Packet {
        constructor(arg0: $ServerboundPlayerActionPacket$Action_, arg1: $BlockPos_, arg2: $Direction_);
        constructor(arg0: $ServerboundPlayerActionPacket$Action_, arg1: $BlockPos_, arg2: $Direction_, arg3: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlayerActionPacket>;
        get action(): $ServerboundPlayerActionPacket$Action;
        getAction(): $ServerboundPlayerActionPacket$Action;
        get direction(): $Direction;
        getDirection(): $Direction;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get sequence(): number;
        getSequence(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPlayerActionPacket>;
    }

    export class $ServerboundPlayerActionPacket$Action {
        static ABORT_DESTROY_BLOCK: $ServerboundPlayerActionPacket$Action;
        static DROP_ALL_ITEMS: $ServerboundPlayerActionPacket$Action;
        static DROP_ITEM: $ServerboundPlayerActionPacket$Action;
        static RELEASE_USE_ITEM: $ServerboundPlayerActionPacket$Action;
        static START_DESTROY_BLOCK: $ServerboundPlayerActionPacket$Action;
        static STOP_DESTROY_BLOCK: $ServerboundPlayerActionPacket$Action;
        static SWAP_ITEM_WITH_OFFHAND: $ServerboundPlayerActionPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundPlayerActionPacket$Action[];
        static valueOf(name: string): $ServerboundPlayerActionPacket$Action;
    }

    export class $ServerboundPlayerCommandPacket implements $Packet {
        constructor(arg0: $Entity, arg1: $ServerboundPlayerCommandPacket$Action_);
        constructor(arg0: $Entity, arg1: $ServerboundPlayerCommandPacket$Action_, arg2: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlayerCommandPacket>;
        get action(): $ServerboundPlayerCommandPacket$Action;
        getAction(): $ServerboundPlayerCommandPacket$Action;
        get data(): number;
        getData(): number;
        get id(): number;
        getId(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPlayerCommandPacket>;
    }

    export class $ServerboundPlayerCommandPacket$Action {
        static OPEN_INVENTORY: $ServerboundPlayerCommandPacket$Action;
        static PRESS_SHIFT_KEY: $ServerboundPlayerCommandPacket$Action;
        static RELEASE_SHIFT_KEY: $ServerboundPlayerCommandPacket$Action;
        static START_FALL_FLYING: $ServerboundPlayerCommandPacket$Action;
        static START_RIDING_JUMP: $ServerboundPlayerCommandPacket$Action;
        static START_SPRINTING: $ServerboundPlayerCommandPacket$Action;
        static STOP_RIDING_JUMP: $ServerboundPlayerCommandPacket$Action;
        static STOP_SLEEPING: $ServerboundPlayerCommandPacket$Action;
        static STOP_SPRINTING: $ServerboundPlayerCommandPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundPlayerCommandPacket$Action[];
        static valueOf(name: string): $ServerboundPlayerCommandPacket$Action;
    }

    export class $ServerboundPlayerInputPacket implements $Packet {
        constructor(arg0: number, arg1: number, arg2: boolean, arg3: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundPlayerInputPacket>;
        get xxa(): number;
        getXxa(): number;
        get zza(): number;
        getZza(): number;
        get jumping(): boolean;
        isJumping(): boolean;
        get shiftKeyDown(): boolean;
        isShiftKeyDown(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundPlayerInputPacket>;
    }

    export class $ServerboundRecipeBookChangeSettingsPacket implements $Packet {
        constructor(arg0: $RecipeBookType_, arg1: boolean, arg2: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundRecipeBookChangeSettingsPacket>;
        get bookType(): $RecipeBookType;
        getBookType(): $RecipeBookType;
        get filtering(): boolean;
        isFiltering(): boolean;
        get open(): boolean;
        isOpen(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundRecipeBookChangeSettingsPacket>;
    }

    export class $ServerboundRecipeBookSeenRecipePacket implements $Packet {
        constructor(arg0: $RecipeHolder<any>);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundRecipeBookSeenRecipePacket>;
        get recipe(): $ResourceLocation;
        getRecipe(): $ResourceLocation;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundRecipeBookSeenRecipePacket>;
    }

    export class $ServerboundRenameItemPacket implements $Packet {
        constructor(arg0: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundRenameItemPacket>;
        get name(): string;
        getName(): string;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundRenameItemPacket>;
    }

    export class $ServerboundSeenAdvancementsPacket implements $Packet {
        constructor(arg0: $ServerboundSeenAdvancementsPacket$Action_, arg1: $ResourceLocation_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSeenAdvancementsPacket>;
        get action(): $ServerboundSeenAdvancementsPacket$Action;
        getAction(): $ServerboundSeenAdvancementsPacket$Action;
        get tab(): $ResourceLocation;
        getTab(): $ResourceLocation;
        static closedScreen(): $ServerboundSeenAdvancementsPacket;
        static openedTab(arg0: $AdvancementHolder): $ServerboundSeenAdvancementsPacket;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSeenAdvancementsPacket>;
    }

    export class $ServerboundSeenAdvancementsPacket$Action {
        static CLOSED_SCREEN: $ServerboundSeenAdvancementsPacket$Action;
        static OPENED_TAB: $ServerboundSeenAdvancementsPacket$Action;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ServerboundSeenAdvancementsPacket$Action[];
        static valueOf(name: string): $ServerboundSeenAdvancementsPacket$Action;
    }

    export class $ServerboundSelectTradePacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSelectTradePacket>;
        get item(): number;
        getItem(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSelectTradePacket>;
    }

    export class $ServerboundSetBeaconPacket extends $Record implements $Packet {
        constructor(arg0: $Optional<$Holder<$MobEffect_>>, arg1: $Optional<$Holder<$MobEffect_>>);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ServerboundSetBeaconPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        primary(): $Optional<$Holder<$MobEffect>>;
        secondary(): $Optional<$Holder<$MobEffect>>;
        toString(): string;
        type(): $PacketType<$ServerboundSetBeaconPacket>;
    }

    export class $ServerboundSetCarriedItemPacket implements $Packet {
        constructor(arg0: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetCarriedItemPacket>;
        get slot(): number;
        getSlot(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetCarriedItemPacket>;
    }

    export class $ServerboundSetCommandBlockPacket implements $Packet {
        constructor(arg0: $BlockPos_, arg1: string, arg2: $CommandBlockEntity$Mode_, arg3: boolean, arg4: boolean, arg5: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetCommandBlockPacket>;
        get command(): string;
        getCommand(): string;
        get mode(): $CommandBlockEntity$Mode;
        getMode(): $CommandBlockEntity$Mode;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get automatic(): boolean;
        isAutomatic(): boolean;
        get conditional(): boolean;
        isConditional(): boolean;
        get trackOutput(): boolean;
        isTrackOutput(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetCommandBlockPacket>;
    }

    export class $ServerboundSetCommandMinecartPacket implements $Packet {
        constructor(arg0: number, arg1: string, arg2: boolean);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetCommandMinecartPacket>;
        get command(): string;
        getCommand(): string;
        get trackOutput(): boolean;
        isTrackOutput(): boolean;
        getCommandBlock(arg0: $Level): $BaseCommandBlock;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetCommandMinecartPacket>;
    }

    export class $ServerboundSetCreativeModeSlotPacket extends $Record implements $Packet {
        constructor(arg0: number, arg1: $ItemStack_);
        constructor(arg0: number, arg1: $ItemStack_);
        static STREAM_CODEC: $StreamCodec<$RegistryFriendlyByteBuf, $ServerboundSetCreativeModeSlotPacket>;
        equals(arg0: object): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        hashCode(): number;
        itemStack(): $ItemStack;
        slotNum(): number;
        toString(): string;
        type(): $PacketType<$ServerboundSetCreativeModeSlotPacket>;
    }

    export class $ServerboundSetJigsawBlockPacket implements $Packet {
        constructor(arg0: $BlockPos_, arg1: $ResourceLocation_, arg2: $ResourceLocation_, arg3: $ResourceLocation_, arg4: string, arg5: $JigsawBlockEntity$JointType_, arg6: number, arg7: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetJigsawBlockPacket>;
        get finalState(): string;
        getFinalState(): string;
        get joint(): $JigsawBlockEntity$JointType;
        getJoint(): $JigsawBlockEntity$JointType;
        get name(): $ResourceLocation;
        getName(): $ResourceLocation;
        get placementPriority(): number;
        getPlacementPriority(): number;
        get pool(): $ResourceLocation;
        getPool(): $ResourceLocation;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get selectionPriority(): number;
        getSelectionPriority(): number;
        get target(): $ResourceLocation;
        getTarget(): $ResourceLocation;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetJigsawBlockPacket>;
    }

    export class $ServerboundSetStructureBlockPacket implements $Packet {
        constructor(arg0: $BlockPos_, arg1: $StructureBlockEntity$UpdateType_, arg2: $StructureMode_, arg3: string, arg4: $BlockPos_, arg5: $Vec3i, arg6: $Mirror_, arg7: $Rotation_, arg8: string, arg9: boolean, arg10: boolean, arg11: boolean, arg12: number, arg13: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSetStructureBlockPacket>;
        get data(): string;
        getData(): string;
        get integrity(): number;
        getIntegrity(): number;
        get mirror(): $Mirror;
        getMirror(): $Mirror;
        get mode(): $StructureMode;
        getMode(): $StructureMode;
        get name(): string;
        getName(): string;
        get offset(): $BlockPos;
        getOffset(): $BlockPos;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get rotation(): $Rotation;
        getRotation(): $Rotation;
        get seed(): number;
        getSeed(): number;
        get size(): $Vec3i;
        getSize(): $Vec3i;
        get updateType(): $StructureBlockEntity$UpdateType;
        getUpdateType(): $StructureBlockEntity$UpdateType;
        get ignoreEntities(): boolean;
        isIgnoreEntities(): boolean;
        get showAir(): boolean;
        isShowAir(): boolean;
        get showBoundingBox(): boolean;
        isShowBoundingBox(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSetStructureBlockPacket>;
    }

    export class $ServerboundSignUpdatePacket implements $Packet {
        constructor(arg0: $BlockPos_, arg1: boolean, arg2: string, arg3: string, arg4: string, arg5: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSignUpdatePacket>;
        get lines(): string[];
        getLines(): string[];
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get frontText(): boolean;
        isFrontText(): boolean;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSignUpdatePacket>;
    }

    export class $ServerboundSwingPacket implements $Packet {
        constructor(arg0: $InteractionHand_);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundSwingPacket>;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundSwingPacket>;
    }

    export class $ServerboundTeleportToEntityPacket implements $Packet {
        constructor(arg0: string);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundTeleportToEntityPacket>;
        getEntity(arg0: $ServerLevel): $Entity;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundTeleportToEntityPacket>;
    }

    export class $ServerboundUseItemOnPacket implements $Packet {
        constructor(arg0: $InteractionHand_, arg1: $BlockHitResult, arg2: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundUseItemOnPacket>;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get hitResult(): $BlockHitResult;
        getHitResult(): $BlockHitResult;
        get sequence(): number;
        getSequence(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundUseItemOnPacket>;
    }

    export class $ServerboundUseItemPacket implements $Packet {
        constructor(arg0: $InteractionHand_, arg1: number, arg2: number, arg3: number);
        static STREAM_CODEC: $StreamCodec<$FriendlyByteBuf, $ServerboundUseItemPacket>;
        get hand(): $InteractionHand;
        getHand(): $InteractionHand;
        get sequence(): number;
        getSequence(): number;
        get xRot(): number;
        getXRot(): number;
        get yRot(): number;
        getYRot(): number;
        handle(arg0: $ServerGamePacketListener): void;
        type(): $PacketType<$ServerboundUseItemPacket>;
    }

    export class $VecDeltaCodec {
        constructor();
        get base(): $Vec3;
        getBase(): $Vec3;
        set base(value: $Vec3_);
        decode(arg0: number, arg1: number, arg2: number): $Vec3;
        delta(arg0: $Vec3_): $Vec3;
        encodeX(arg0: $Vec3_): number;
        encodeY(arg0: $Vec3_): number;
        encodeZ(arg0: $Vec3_): number;
    }

    export type $ServerboundClientCommandPacket$Action_ = $ServerboundClientCommandPacket$Action | "PERFORM_RESPAWN" | "REQUEST_STATS";
    export type $ServerboundPlayerActionPacket$Action_ = $ServerboundPlayerActionPacket$Action | "ABORT_DESTROY_BLOCK" | "DROP_ALL_ITEMS" | "DROP_ITEM" | "RELEASE_USE_ITEM" | "START_DESTROY_BLOCK" | "STOP_DESTROY_BLOCK" | "SWAP_ITEM_WITH_OFFHAND";
    export type $ServerboundPlayerCommandPacket$Action_ = $ServerboundPlayerCommandPacket$Action | "OPEN_INVENTORY" | "PRESS_SHIFT_KEY" | "RELEASE_SHIFT_KEY" | "START_FALL_FLYING" | "START_RIDING_JUMP" | "START_SPRINTING" | "STOP_RIDING_JUMP" | "STOP_SLEEPING" | "STOP_SPRINTING";
    export type $ServerboundSeenAdvancementsPacket$Action_ = $ServerboundSeenAdvancementsPacket$Action | "CLOSED_SCREEN" | "OPENED_TAB";
}
