import { $JsonObject } from "java:com/google/gson";
import { $Codec } from "java:com/mojang/serialization";
import { $String } from "java:java/lang";

export * as pack from "java:net/minecraft/server/packs/metadata/pack";

declare module "java:net/minecraft/server/packs/metadata" {
    export interface $MetadataSectionSerializer<T> {
        fromJson(arg0: $JsonObject): T;
        getMetadataSectionName(): string;
    }

    export interface $MetadataSectionType<T> extends $MetadataSectionSerializer {
        fromCodec<T>(arg0: string, arg1: $Codec<T>): $MetadataSectionType<T>;
        toJson(arg0: T): $JsonObject;
    }

}
