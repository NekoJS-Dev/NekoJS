import { $Codec } from "java:com/mojang/serialization";
import { $Record, $String } from "java:java/lang";
import { $Collection, $Optional } from "java:java/util";
import { $Consumer, $Predicate } from "java:java/util/function";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ExtraCodecs$TagOrElementLocation } from "java:net/minecraft/util";

declare module "java:net/minecraft/tags" {
    export class $TagEntry {
        static CODEC: $Codec<$TagEntry>;
        id: $ResourceLocation;
        required: boolean;
        tag: boolean;
        get id(): $ResourceLocation;
        getId(): $ResourceLocation;
        get required(): boolean;
        isRequired(): boolean;
        get tag(): boolean;
        isTag(): boolean;
        static element(arg0: $ResourceLocation_): $TagEntry;
        static optionalElement(arg0: $ResourceLocation_): $TagEntry;
        static optionalTag(arg0: $ResourceLocation_): $TagEntry;
        static tag(arg0: $ResourceLocation_): $TagEntry;
        build<T>(arg0: $TagEntry$Lookup<T>, arg1: $Consumer<T>): boolean;
        elementOrTag(): $ExtraCodecs$TagOrElementLocation;
        toString(): string;
        verifyIfPresent(arg0: $Predicate<$ResourceLocation_>, arg1: $Predicate<$ResourceLocation_>): boolean;
        visitOptionalDependencies(arg0: $Consumer<$ResourceLocation_>): void;
        visitRequiredDependencies(arg0: $Consumer<$ResourceLocation_>): void;
    }

    export interface $TagEntry$Lookup<T> {
        element(arg0: $ResourceLocation_): T;
        tag(arg0: $ResourceLocation_): $Collection<T>;
    }

    export class $TagKey<T> extends $Record {
        constructor(arg0: $ResourceKey<$Registry<T>>, arg1: $ResourceLocation_);
        static codec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        static create<T>(arg0: $ResourceKey<$Registry<T>>, arg1: $ResourceLocation_): $TagKey<T>;
        static hashedCodec<T>(arg0: $ResourceKey<$Registry<T>>): $Codec<$TagKey<T>>;
        cast<E>(arg0: $ResourceKey<$Registry<E>>): $Optional<$TagKey<E>>;
        equals(arg0: object): boolean;
        hashCode(): number;
        isFor(arg0: $ResourceKey<$Registry<any>>): boolean;
        location(): $ResourceLocation;
        registry(): $ResourceKey<$Registry<T>>;
        toString(): string;
    }

    export class $TagLoader$EntryWithSource extends $Record {
        constructor(arg0: $TagEntry, arg1: string);
        constructor(entry: $TagEntry, source: string, remove: boolean);
        entry(): $TagEntry;
        equals(arg0: object): boolean;
        hashCode(): number;
        remove(): boolean;
        source(): string;
        toString(): string;
    }

    export type $TagKey_ = string | { type?: string, tag: string };
}
