import ast
import collections
import json
from pathlib import Path

root = Path.cwd()
source = root / 'build/ticket37-config-sync-repair/legacy-probe-actual-explicit-pyright.json'
document = json.loads(source.read_text(encoding='utf-8'))
records = []
for diagnostic in document['generalDiagnostics']:
    if diagnostic.get('rule') != 'reportRedeclaration':
        continue
    path = Path(diagnostic['file'])
    tree = ast.parse(path.read_text(encoding='utf-8'))
    line = diagnostic['range']['start']['line'] + 1
    node = next((n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AnnAssign)) and n.lineno == line), None)
    if node is None:
        raise AssertionError((path, line))
    owner = next(c for c in tree.body if isinstance(c, ast.ClassDef) and any(n is node for n in c.body))
    member_name = lambda n: n.name if isinstance(n, ast.FunctionDef) else ast.unparse(n.target) if isinstance(n, ast.AnnAssign) else ''
    name = member_name(node)
    declarations = [dict(line=n.lineno, kind=type(n).__name__, decorators=[ast.unparse(d) for d in getattr(n, 'decorator_list', [])]) for n in owner.body if member_name(n) == name]
    category = 'property/member collision' if any('property' in n['decorators'] for n in declarations) else 'other duplicate'
    records.append(dict(file=path.relative_to(root / 'build').as_posix(), owner=owner.name, member=name, category=category, declarations=declarations))
result = dict(input=str(source.relative_to(root)), diagnosticRules=dict(collections.Counter(d.get('rule', 'none') for d in document['generalDiagnostics'])), redeclarationCategories=dict(collections.Counter(r['category'] for r in records)), redeclarations=records)
destination = source.with_name('python-ide-triage.json')
destination.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k != 'redeclarations'}))
for record in records:
    print(record['owner'], record['member'], record['category'])
