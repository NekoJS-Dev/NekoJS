import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
out = root / 'build/ticket37-config-sync-repair'
sha = lambda data: hashlib.sha256(data).hexdigest()
patch = subprocess.check_output(['git', 'diff', '9b2c5d29', '--', 'common/src/main/java/com/tkisor/nekojs/probe/backend/python/PythonClassRenderer.java'])
(out / 'python-member-production.patch').write_bytes(patch)
counts = []
entries = []
archive_path = out / 'python-member-final-ordinary-xml.zip'
with ZipFile(archive_path, 'x', ZIP_DEFLATED) as archive:
    for project in ['common', 'common-api-processor'] + ['versions/' + n for n in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']]:
        row = dict(project=project, xml=0, tests=0, skipped=0, failures=0, errors=0)
        for path in sorted((root / project / 'build/test-results/test').glob('TEST-*.xml')):
            suite = ET.parse(path).getroot()
            row['xml'] += 1
            for key in ['tests', 'skipped', 'failures', 'errors']:
                row[key] += int(suite.get(key, 0))
            data = path.read_bytes()
            name = path.relative_to(root).as_posix()
            archive.writestr(name, data)
            entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
        counts.append(row)
total = {key: sum(row[key] for row in counts) for key in ['xml', 'tests', 'skipped', 'failures', 'errors']}
assert total == dict(xml=791, tests=4595, skipped=271, failures=1, errors=0), total
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in entries:
        assert sha(archive.read(record['path'])) == record['sha256']
artifacts = []
for node in ['1.21.1', '26.1.2', '26.2.0', '26.1.2-fabric', '26.2.0-fabric']:
    for path in sorted((root / 'versions' / node / 'build/libs').glob('*.jar')):
        if path.name.endswith(('-sources.jar', '-dev.jar')):
            continue
        artifacts.append(dict(node=node, file=path.name, bytes=path.stat().st_size, sha256=sha(path.read_bytes())))
document = dict(sourceBase='9b2c5d29', sourceWip=True, productionPatchSha256=sha(patch), projects=counts, total=total, artifacts=artifacts, matrixVerdict='FAIL: ServerPackCacheTest directory move AccessDeniedException', xmlArchive=dict(file=archive_path.name, sha256=sha(archive_path.read_bytes()), entries=entries), note='Failed ordinary report snapshot includes up-to-date reports. No golden regeneration. Independent reviewer jobs failed due to account usage limit; manual owner review is separate.')
(out / 'python-member-final-test-summary.json').write_text(json.dumps(document, indent=2) + '\n')
print(json.dumps(dict(total=total, productionPatchSha256=sha(patch), artifacts=artifacts)))
