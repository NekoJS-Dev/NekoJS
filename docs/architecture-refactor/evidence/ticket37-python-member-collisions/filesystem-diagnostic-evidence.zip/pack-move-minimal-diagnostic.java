package com.tkisor.nekojs.core.pack.sync;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.assertEquals;
/** Minimal directory rename diagnostic with no NekoJS runtime or pack code. */
class ServerPackCacheMoveDiagnosticTest {
    @TempDir Path bucketRoot;
    @RepeatedTest(100)
    void renameNewAndPreviousDirectories() throws Exception {
        Path target = Files.createDirectories(bucketRoot.resolve("pack"));
        Files.writeString(target.resolve("old.json"), "old");
        Path staging = Files.createTempDirectory(bucketRoot, ".stage-");
        Path staged = Files.createDirectories(staging.resolve("pack"));
        Files.writeString(staged.resolve("new.json"), "new");
        Path backup = Files.createDirectories(staging.resolve(".rollback")).resolve("pack");
        Files.move(target, backup);
        Files.move(staged, target);
        assertEquals("new", Files.readString(target.resolve("new.json")));
        assertEquals("old", Files.readString(backup.resolve("old.json")));
    }
}
