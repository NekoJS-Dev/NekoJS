package com.tkisor.nekojs.core.pack.sync;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Diagnostic repetitions of the existing physical rollback fixture. */
class ServerPackCacheMoveDiagnosticTest {
    @TempDir Path bucketRoot;
    @RepeatedTest(100)
    void physicalRestorePropagatesDeleteFailureAndRetainsStaging() throws Exception {
        String syncId = "packs:restore-failure";
        String manifest = "{\"id\": \"demo\", \"version\": \"1.0.0\"}";
        var files = List.of(new PackContentFile("client_scripts/hud.js", "hud()".getBytes()),
                new PackContentFile("assets/nekojs/lang/en_us.json", "{}".getBytes()));
        ServerPackCache.persistPack(bucketRoot, syncId, manifest, files);
        Path staging = ServerPackCache.createStagingRoot(bucketRoot);
        ServerPackCache.stagePack(staging, syncId, manifest, files);
        Path target = bucketRoot.resolve(SyncedPack.encodeSyncId(syncId));
        var replacement = new ServerPackCache.PhysicalReplacement(staging, bucketRoot, path -> {
            if (path.equals(target)) throw new IOException("injected physical delete failure");
            ServerPackCache.deleteRecursivelyStrict(path);
        });
        replacement.replace(syncId);
        assertThrows(IOException.class, replacement::restore);
        assertTrue(Files.exists(staging));
    }
}
