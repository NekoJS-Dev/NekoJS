package com.tkisor.nekojs.core.pack.sync;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.assertEquals;
/** Minimal directory rename diagnostic with no NekoJS runtime or pack code. */
class ServerPackCacheMoveDiagnosticTest {
    @TempDir Path bucketRoot;
    private static void writePack(Path root) throws Exception {
        Files.writeString(root.resolve("nekojs.pack.json"), "{\"id\": \"demo\", \"version\": \"1.0.0\"}");
        Files.createDirectories(root.resolve("client_scripts"));
        Files.writeString(root.resolve("client_scripts/hud.js"), "hud()");
        Files.createDirectories(root.resolve("assets/nekojs/lang"));
        Files.writeString(root.resolve("assets/nekojs/lang/en_us.json"), "{}");
    }
    @RepeatedTest(1000)
    void renameNewAndPreviousDirectories() throws Exception {
        Path target = Files.createDirectories(bucketRoot.resolve("pack"));
        writePack(target);
        Path staging = Files.createTempDirectory(bucketRoot, ".stage-");
        Path staged = Files.createDirectories(staging.resolve("pack"));
        writePack(staged);
        Path backup = Files.createDirectories(staging.resolve(".rollback")).resolve("pack");
        Files.move(target, backup);
        Files.move(staged, target);
        assertEquals("hud()", Files.readString(target.resolve("client_scripts/hud.js")));
        assertEquals("hud()", Files.readString(backup.resolve("client_scripts/hud.js")));
    }
}


