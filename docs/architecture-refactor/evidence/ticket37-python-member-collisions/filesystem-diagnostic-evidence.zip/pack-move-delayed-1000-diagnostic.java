package com.tkisor.nekojs.core.pack.sync;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.assertEquals;
/** Read-only failure-state probes and diagnostic delayed moves, never production retry policy. */
class ServerPackCacheMoveDiagnosticTest {
    @TempDir Path bucketRoot;
    private IOException initialFailure;
    private static void writePack(Path root) throws Exception {
        Files.writeString(root.resolve("manifest.json"), "{\"id\": \"demo\", \"version\": \"1.0.0\"}");
        Files.createDirectories(root.resolve("client_scripts"));
        Files.writeString(root.resolve("client_scripts/hud.js"), "hud()");
        Files.createDirectories(root.resolve("assets/nekojs/lang"));
        Files.writeString(root.resolve("assets/nekojs/lang/en_us.json"), "{}");
    }
    private void move(Path source, Path target, String operation) throws Exception {
        try { Files.move(source, target); }
        catch (AccessDeniedException original) {
            initialFailure = original;
            System.out.println("[DEBUG-packmove] initialFailure operation=" + operation
                    + " sourceExists=" + Files.isDirectory(source) + " targetExists=" + Files.exists(target)
                    + " sourceReadonly=" + Files.getAttribute(source, "dos:readonly"));
            int elapsed = 0;
            for (int delay : new int[]{1, 10, 100}) {
                Thread.sleep(delay);
                elapsed += delay;
                try {
                    Files.move(source, target);
                    System.out.println("[DEBUG-packmove] recovered operation=" + operation + " delayMs=" + elapsed);
                    return;
                } catch (AccessDeniedException stillDenied) {
                    System.out.println("[DEBUG-packmove] stillDenied operation=" + operation + " delayMs=" + elapsed);
                }
            }
            throw original;
        }
    }
    @RepeatedTest(1000)
    void renameNewAndPreviousDirectories() throws Exception {
        Path target = Files.createDirectories(bucketRoot.resolve("pack"));
        writePack(target);
        Path staging = Files.createTempDirectory(bucketRoot, ".stage-");
        Path staged = Files.createDirectories(staging.resolve("pack"));
        writePack(staged);
        Path backup = Files.createDirectories(staging.resolve(".rollback")).resolve("pack");
        move(target, backup, "backup");
        move(staged, target, "install");
        assertEquals("hud()", Files.readString(target.resolve("client_scripts/hud.js")));
        assertEquals("hud()", Files.readString(backup.resolve("client_scripts/hud.js")));
        if (initialFailure != null) throw initialFailure;
    }
}

