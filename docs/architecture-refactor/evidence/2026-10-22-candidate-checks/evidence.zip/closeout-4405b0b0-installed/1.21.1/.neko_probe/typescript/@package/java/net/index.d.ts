import { $Closeable, $Closeable_, $InputStream, $OutputStream, $Serializable } from "java:java/io";
import { $Class, $Comparable, $Comparable_, $Enum } from "java:java/lang";
import { $DatagramChannel, $ServerSocketChannel, $SocketChannel } from "java:java/nio/channels";
import { $Permission } from "java:java/security";
import { $Enumeration, $List, $Map, $Set } from "java:java/util";
import { $Stream } from "java:java/util/stream";

declare module "java:java/net" {
    export class $ContentHandler {
        constructor();
        getContent(arg0: $URLConnection, arg1: $Class<any>[]): unknown;
        getContent(arg0: $URLConnection): unknown;
    }

    export interface $ContentHandlerFactory {
        createContentHandler(arg0: string): $ContentHandler;
    }

    export interface $FileNameMap {
        getContentTypeFor(arg0: string): string;
    }

    export class $InetAddress implements $Serializable {
        get address(): number[];
        getAddress(): number[];
        get canonicalHostName(): string;
        getCanonicalHostName(): string;
        get hostAddress(): string;
        getHostAddress(): string;
        get hostName(): string;
        getHostName(): string;
        get anyLocalAddress(): boolean;
        isAnyLocalAddress(): boolean;
        get linkLocalAddress(): boolean;
        isLinkLocalAddress(): boolean;
        get loopbackAddress(): boolean;
        isLoopbackAddress(): boolean;
        get mCGlobal(): boolean;
        isMCGlobal(): boolean;
        get mCLinkLocal(): boolean;
        isMCLinkLocal(): boolean;
        get mCNodeLocal(): boolean;
        isMCNodeLocal(): boolean;
        get mCOrgLocal(): boolean;
        isMCOrgLocal(): boolean;
        get mCSiteLocal(): boolean;
        isMCSiteLocal(): boolean;
        get multicastAddress(): boolean;
        isMulticastAddress(): boolean;
        get siteLocalAddress(): boolean;
        isSiteLocalAddress(): boolean;
        static getAllByName(arg0: string): $InetAddress[];
        static getByAddress(arg0: number[]): $InetAddress;
        static getByAddress(arg0: string, arg1: number[]): $InetAddress;
        static getByName(arg0: string): $InetAddress;
        static getLocalHost(): $InetAddress;
        static getLoopbackAddress(): $InetAddress;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        isReachable(arg0: number): boolean;
        isReachable(arg0: $NetworkInterface, arg1: number, arg2: number): boolean;
        toString(): string;
    }

    export class $InetSocketAddress extends $SocketAddress {
        constructor(arg0: number);
        constructor(arg0: string, arg1: number);
        constructor(arg0: $InetAddress, arg1: number);
        get address(): $InetAddress;
        getAddress(): $InetAddress;
        get hostName(): string;
        getHostName(): string;
        get hostString(): string;
        getHostString(): string;
        get port(): number;
        getPort(): number;
        get unresolved(): boolean;
        isUnresolved(): boolean;
        static createUnresolved(arg0: string, arg1: number): $InetSocketAddress;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $InterfaceAddress {
        get address(): $InetAddress;
        getAddress(): $InetAddress;
        get broadcast(): $InetAddress;
        getBroadcast(): $InetAddress;
        get networkPrefixLength(): number;
        getNetworkPrefixLength(): number;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $NetworkInterface {
        get displayName(): string;
        getDisplayName(): string;
        get hardwareAddress(): number[];
        getHardwareAddress(): number[];
        get index(): number;
        getIndex(): number;
        getInetAddresses(): $Enumeration<$InetAddress>;
        get interfaceAddresses(): $List<$InterfaceAddress>;
        getInterfaceAddresses(): $List<$InterfaceAddress>;
        get mTU(): number;
        getMTU(): number;
        get name(): string;
        getName(): string;
        get parent(): $NetworkInterface;
        getParent(): $NetworkInterface;
        getSubInterfaces(): $Enumeration<$NetworkInterface>;
        get loopback(): boolean;
        isLoopback(): boolean;
        get pointToPoint(): boolean;
        isPointToPoint(): boolean;
        get up(): boolean;
        isUp(): boolean;
        get virtual(): boolean;
        isVirtual(): boolean;
        static getByIndex(arg0: number): $NetworkInterface;
        static getByInetAddress(arg0: $InetAddress): $NetworkInterface;
        static getByName(arg0: string): $NetworkInterface;
        static getNetworkInterfaces(): $Enumeration<$NetworkInterface>;
        static networkInterfaces(): $Stream<$NetworkInterface>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        inetAddresses(): $Stream<$InetAddress>;
        subInterfaces(): $Stream<$NetworkInterface>;
        supportsMulticast(): boolean;
        toString(): string;
    }

    export class $Proxy {
        constructor(arg0: $Proxy$Type_, arg1: $SocketAddress);
        static NO_PROXY: $Proxy;
        address(): $SocketAddress;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
        type(): $Proxy$Type;
    }

    export class $Proxy$Type {
        static DIRECT: $Proxy$Type;
        static HTTP: $Proxy$Type;
        static SOCKS: $Proxy$Type;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Proxy$Type[];
        static valueOf(name: string): $Proxy$Type;
    }
    export interface $Proxy$Type extends $Enum<$Proxy$Type> {}

    export class $SocketAddress implements $Serializable {
        constructor();
    }

    export class $URI implements $Comparable<$URI>, $Serializable {
        constructor(arg0: string);
        constructor(arg0: string, arg1: string, arg2: string);
        constructor(arg0: string, arg1: string, arg2: string, arg3: number, arg4: string, arg5: string, arg6: string);
        constructor(arg0: string, arg1: string, arg2: string, arg3: string);
        constructor(arg0: string, arg1: string, arg2: string, arg3: string, arg4: string);
        get authority(): string;
        getAuthority(): string;
        get fragment(): string;
        getFragment(): string;
        get host(): string;
        getHost(): string;
        get path(): string;
        getPath(): string;
        get port(): number;
        getPort(): number;
        get query(): string;
        getQuery(): string;
        get rawAuthority(): string;
        getRawAuthority(): string;
        get rawFragment(): string;
        getRawFragment(): string;
        get rawPath(): string;
        getRawPath(): string;
        get rawQuery(): string;
        getRawQuery(): string;
        get rawSchemeSpecificPart(): string;
        getRawSchemeSpecificPart(): string;
        get rawUserInfo(): string;
        getRawUserInfo(): string;
        get schemeSpecificPart(): string;
        getSchemeSpecificPart(): string;
        get scheme(): string;
        getScheme(): string;
        get userInfo(): string;
        getUserInfo(): string;
        get absolute(): boolean;
        isAbsolute(): boolean;
        get opaque(): boolean;
        isOpaque(): boolean;
        static create(arg0: string): $URI;
        compareTo(arg0: $URI): number;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        normalize(): $URI;
        parseServerAuthority(): $URI;
        relativize(arg0: $URI): $URI;
        resolve(arg0: string): $URI;
        resolve(arg0: $URI): $URI;
        toASCIIString(): string;
        toString(): string;
        toURL(): $URL;
    }

    export class $URL implements $Serializable {
        constructor(arg0: string);
        constructor(arg0: string, arg1: string, arg2: number, arg3: string);
        constructor(arg0: string, arg1: string, arg2: number, arg3: string, arg4: $URLStreamHandler);
        constructor(arg0: string, arg1: string, arg2: string);
        constructor(arg0: $URL, arg1: string);
        constructor(arg0: $URL, arg1: string, arg2: $URLStreamHandler);
        get authority(): string;
        getAuthority(): string;
        get content(): unknown;
        getContent(): unknown;
        get defaultPort(): number;
        getDefaultPort(): number;
        get file(): string;
        getFile(): string;
        get host(): string;
        getHost(): string;
        get path(): string;
        getPath(): string;
        get port(): number;
        getPort(): number;
        get protocol(): string;
        getProtocol(): string;
        get query(): string;
        getQuery(): string;
        get ref(): string;
        getRef(): string;
        get userInfo(): string;
        getUserInfo(): string;
        static of(arg0: $URI, arg1: $URLStreamHandler): $URL;
        static setURLStreamHandlerFactory(arg0: $URLStreamHandlerFactory_<string, $URLStreamHandler>): void;
        equals(arg0: unknown): boolean;
        getContent(arg0: $Class<any>[]): unknown;
        hashCode(): number;
        openConnection(arg0: $Proxy): $URLConnection;
        openConnection(): $URLConnection;
        openStream(): $InputStream;
        sameFile(arg0: $URL): boolean;
        toExternalForm(): string;
        toString(): string;
        toURI(): $URI;
    }

    export class $URLConnection {
        get allowUserInteraction(): boolean;
        getAllowUserInteraction(): boolean;
        set allowUserInteraction(value: boolean);
        get connectTimeout(): number;
        getConnectTimeout(): number;
        set connectTimeout(value: number);
        get contentEncoding(): string;
        getContentEncoding(): string;
        get contentLengthLong(): number;
        getContentLengthLong(): number;
        get contentLength(): number;
        getContentLength(): number;
        get contentType(): string;
        getContentType(): string;
        get content(): unknown;
        getContent(): unknown;
        get date(): number;
        getDate(): number;
        get defaultUseCaches(): boolean;
        getDefaultUseCaches(): boolean;
        set defaultUseCaches(value: boolean);
        get doInput(): boolean;
        getDoInput(): boolean;
        set doInput(value: boolean);
        get doOutput(): boolean;
        getDoOutput(): boolean;
        set doOutput(value: boolean);
        get expiration(): number;
        getExpiration(): number;
        get headerFields(): $Map<string, $List<string>>;
        getHeaderFields(): $Map<string, $List<string>>;
        get ifModifiedSince(): number;
        getIfModifiedSince(): number;
        set ifModifiedSince(value: number);
        get inputStream(): $InputStream;
        getInputStream(): $InputStream;
        get lastModified(): number;
        getLastModified(): number;
        get outputStream(): $OutputStream;
        getOutputStream(): $OutputStream;
        get permission(): $Permission;
        getPermission(): $Permission;
        get readTimeout(): number;
        getReadTimeout(): number;
        set readTimeout(value: number);
        get requestProperties(): $Map<string, $List<string>>;
        getRequestProperties(): $Map<string, $List<string>>;
        get uRL(): $URL;
        getURL(): $URL;
        get useCaches(): boolean;
        getUseCaches(): boolean;
        set useCaches(value: boolean);
        static getDefaultAllowUserInteraction(): boolean;
        static getDefaultRequestProperty(arg0: string): string;
        static getDefaultUseCaches(arg0: string): boolean;
        static getFileNameMap(): $FileNameMap;
        static guessContentTypeFromName(arg0: string): string;
        static guessContentTypeFromStream(arg0: $InputStream): string;
        static setContentHandlerFactory(arg0: $ContentHandlerFactory_<string, $ContentHandler>): void;
        static setDefaultAllowUserInteraction(arg0: boolean): void;
        static setDefaultRequestProperty(arg0: string, arg1: string): void;
        static setDefaultUseCaches(arg0: string, arg1: boolean): void;
        static setFileNameMap(arg0: $FileNameMap_<string, string>): void;
        addRequestProperty(arg0: string, arg1: string): void;
        connect(): void;
        getContent(arg0: $Class<any>[]): unknown;
        getHeaderFieldDate(arg0: string, arg1: number): number;
        getHeaderFieldInt(arg0: string, arg1: number): number;
        getHeaderFieldKey(arg0: number): string;
        getHeaderFieldLong(arg0: string, arg1: number): number;
        getHeaderField(arg0: number): string;
        getHeaderField(arg0: string): string;
        getRequestProperty(arg0: string): string;
        setAllowUserInteraction(arg0: boolean): void;
        setConnectTimeout(arg0: number): void;
        setDefaultUseCaches(arg0: boolean): void;
        setDoInput(arg0: boolean): void;
        setDoOutput(arg0: boolean): void;
        setIfModifiedSince(arg0: number): void;
        setReadTimeout(arg0: number): void;
        setRequestProperty(arg0: string, arg1: string): void;
        setUseCaches(arg0: boolean): void;
        toString(): string;
    }

    export class $URLStreamHandler {
        constructor();
    }

    export interface $URLStreamHandlerFactory {
        createURLStreamHandler(arg0: string): $URLStreamHandler;
    }

    export interface $ProtocolFamily {
        name(): string;
    }

    export class $DatagramSocket implements $Closeable {
        constructor();
        constructor(arg0: number);
        constructor(arg0: number, arg1: $InetAddress);
        constructor(arg0: $SocketAddress);
        get broadcast(): boolean;
        getBroadcast(): boolean;
        set broadcast(value: boolean);
        get channel(): $DatagramChannel;
        getChannel(): $DatagramChannel;
        get inetAddress(): $InetAddress;
        getInetAddress(): $InetAddress;
        get localAddress(): $InetAddress;
        getLocalAddress(): $InetAddress;
        get localPort(): number;
        getLocalPort(): number;
        get localSocketAddress(): $SocketAddress;
        getLocalSocketAddress(): $SocketAddress;
        get port(): number;
        getPort(): number;
        get receiveBufferSize(): number;
        getReceiveBufferSize(): number;
        set receiveBufferSize(value: number);
        get remoteSocketAddress(): $SocketAddress;
        getRemoteSocketAddress(): $SocketAddress;
        get reuseAddress(): boolean;
        getReuseAddress(): boolean;
        set reuseAddress(value: boolean);
        get sendBufferSize(): number;
        getSendBufferSize(): number;
        set sendBufferSize(value: number);
        get soTimeout(): number;
        getSoTimeout(): number;
        set soTimeout(value: number);
        get trafficClass(): number;
        getTrafficClass(): number;
        set trafficClass(value: number);
        get bound(): boolean;
        isBound(): boolean;
        get closed(): boolean;
        isClosed(): boolean;
        get connected(): boolean;
        isConnected(): boolean;
        static setDatagramSocketImplFactory(arg0: $DatagramSocketImplFactory_<$DatagramSocketImpl>): void;
        bind(arg0: $SocketAddress): void;
        close(): void;
        connect(arg0: $InetAddress, arg1: number): void;
        connect(arg0: $SocketAddress): void;
        disconnect(): void;
        getOption<T>(arg0: $SocketOption<T>): T;
        joinGroup(arg0: $SocketAddress, arg1: $NetworkInterface): void;
        leaveGroup(arg0: $SocketAddress, arg1: $NetworkInterface): void;
        receive(arg0: $DatagramPacket): void;
        send(arg0: $DatagramPacket): void;
        setBroadcast(arg0: boolean): void;
        setOption<T>(arg0: $SocketOption<T>, arg1: T): $DatagramSocket;
        setReceiveBufferSize(arg0: number): void;
        setReuseAddress(arg0: boolean): void;
        setSendBufferSize(arg0: number): void;
        setSoTimeout(arg0: number): void;
        setTrafficClass(arg0: number): void;
        supportedOptions(): $Set<$SocketOption<any>>;
    }

    export interface $SocketOption<T> {
        name(): string;
        type(): $Class<T>;
    }

    export class $DatagramPacket {
        constructor(arg0: number[], arg1: number);
        constructor(arg0: number[], arg1: number, arg2: number);
        constructor(arg0: number[], arg1: number, arg2: number, arg3: $InetAddress, arg4: number);
        constructor(arg0: number[], arg1: number, arg2: number, arg3: $SocketAddress);
        constructor(arg0: number[], arg1: number, arg2: $InetAddress, arg3: number);
        constructor(arg0: number[], arg1: number, arg2: $SocketAddress);
        get address(): $InetAddress;
        getAddress(): $InetAddress;
        set address(value: $InetAddress);
        get data(): number[];
        getData(): number[];
        set data(value: number[]);
        get length(): number;
        getLength(): number;
        set length(value: number);
        get offset(): number;
        getOffset(): number;
        get port(): number;
        getPort(): number;
        set port(value: number);
        get socketAddress(): $SocketAddress;
        getSocketAddress(): $SocketAddress;
        set socketAddress(value: $SocketAddress);
        setAddress(arg0: $InetAddress): void;
        setData(arg0: number[], arg1: number, arg2: number): void;
        setData(arg0: number[]): void;
        setLength(arg0: number): void;
        setPort(arg0: number): void;
        setSocketAddress(arg0: $SocketAddress): void;
    }

    export interface $DatagramSocketImplFactory {
        createDatagramSocketImpl(): $DatagramSocketImpl;
    }

    export class $DatagramSocketImpl implements $SocketOptions {
        constructor();
        getOption(arg0: number): unknown;
        setOption(arg0: number, arg1: unknown): void;
    }

    export interface $SocketOptions {
        getOption(arg0: number): unknown;
        setOption(arg0: number, arg1: unknown): void;
    }
    export const $SocketOptions: {
        readonly IP_MULTICAST_IF: number;
        readonly IP_MULTICAST_IF2: number;
        readonly IP_MULTICAST_LOOP: number;
        readonly IP_TOS: number;
        readonly SO_BINDADDR: number;
        readonly SO_BROADCAST: number;
        readonly SO_KEEPALIVE: number;
        readonly SO_LINGER: number;
        readonly SO_OOBINLINE: number;
        readonly SO_RCVBUF: number;
        readonly SO_REUSEADDR: number;
        readonly SO_REUSEPORT: number;
        readonly SO_SNDBUF: number;
        readonly SO_TIMEOUT: number;
        readonly TCP_NODELAY: number;
    };

    export class $ServerSocket implements $Closeable {
        constructor();
        constructor(arg0: number);
        constructor(arg0: number, arg1: number);
        constructor(arg0: number, arg1: number, arg2: $InetAddress);
        get channel(): $ServerSocketChannel;
        getChannel(): $ServerSocketChannel;
        get inetAddress(): $InetAddress;
        getInetAddress(): $InetAddress;
        get localPort(): number;
        getLocalPort(): number;
        get localSocketAddress(): $SocketAddress;
        getLocalSocketAddress(): $SocketAddress;
        get receiveBufferSize(): number;
        getReceiveBufferSize(): number;
        set receiveBufferSize(value: number);
        get reuseAddress(): boolean;
        getReuseAddress(): boolean;
        set reuseAddress(value: boolean);
        get soTimeout(): number;
        getSoTimeout(): number;
        set soTimeout(value: number);
        get bound(): boolean;
        isBound(): boolean;
        get closed(): boolean;
        isClosed(): boolean;
        static setSocketFactory(arg0: $SocketImplFactory_<$SocketImpl>): void;
        accept(): $Socket;
        bind(arg0: $SocketAddress, arg1: number): void;
        bind(arg0: $SocketAddress): void;
        close(): void;
        getOption<T>(arg0: $SocketOption<T>): T;
        setOption<T>(arg0: $SocketOption<T>, arg1: T): $ServerSocket;
        setPerformancePreferences(arg0: number, arg1: number, arg2: number): void;
        setReceiveBufferSize(arg0: number): void;
        setReuseAddress(arg0: boolean): void;
        setSoTimeout(arg0: number): void;
        supportedOptions(): $Set<$SocketOption<any>>;
        toString(): string;
    }

    export class $Socket implements $Closeable {
        constructor();
        constructor(arg0: string, arg1: number);
        constructor(arg0: string, arg1: number, arg2: boolean);
        constructor(arg0: string, arg1: number, arg2: $InetAddress, arg3: number);
        constructor(arg0: $InetAddress, arg1: number);
        constructor(arg0: $InetAddress, arg1: number, arg2: boolean);
        constructor(arg0: $InetAddress, arg1: number, arg2: $InetAddress, arg3: number);
        constructor(arg0: $Proxy);
        get channel(): $SocketChannel;
        getChannel(): $SocketChannel;
        get inetAddress(): $InetAddress;
        getInetAddress(): $InetAddress;
        get inputStream(): $InputStream;
        getInputStream(): $InputStream;
        get keepAlive(): boolean;
        getKeepAlive(): boolean;
        set keepAlive(value: boolean);
        get localAddress(): $InetAddress;
        getLocalAddress(): $InetAddress;
        get localPort(): number;
        getLocalPort(): number;
        get localSocketAddress(): $SocketAddress;
        getLocalSocketAddress(): $SocketAddress;
        get oOBInline(): boolean;
        getOOBInline(): boolean;
        set oOBInline(value: boolean);
        get outputStream(): $OutputStream;
        getOutputStream(): $OutputStream;
        get port(): number;
        getPort(): number;
        get receiveBufferSize(): number;
        getReceiveBufferSize(): number;
        set receiveBufferSize(value: number);
        get remoteSocketAddress(): $SocketAddress;
        getRemoteSocketAddress(): $SocketAddress;
        get reuseAddress(): boolean;
        getReuseAddress(): boolean;
        set reuseAddress(value: boolean);
        get sendBufferSize(): number;
        getSendBufferSize(): number;
        set sendBufferSize(value: number);
        get soLinger(): number;
        getSoLinger(): number;
        get soTimeout(): number;
        getSoTimeout(): number;
        set soTimeout(value: number);
        get tcpNoDelay(): boolean;
        getTcpNoDelay(): boolean;
        set tcpNoDelay(value: boolean);
        get trafficClass(): number;
        getTrafficClass(): number;
        set trafficClass(value: number);
        get bound(): boolean;
        isBound(): boolean;
        get closed(): boolean;
        isClosed(): boolean;
        get connected(): boolean;
        isConnected(): boolean;
        get inputShutdown(): boolean;
        isInputShutdown(): boolean;
        get outputShutdown(): boolean;
        isOutputShutdown(): boolean;
        static setSocketImplFactory(arg0: $SocketImplFactory_<$SocketImpl>): void;
        bind(arg0: $SocketAddress): void;
        close(): void;
        connect(arg0: $SocketAddress, arg1: number): void;
        connect(arg0: $SocketAddress): void;
        getOption<T>(arg0: $SocketOption<T>): T;
        sendUrgentData(arg0: number): void;
        setKeepAlive(arg0: boolean): void;
        setOOBInline(arg0: boolean): void;
        setOption<T>(arg0: $SocketOption<T>, arg1: T): $Socket;
        setPerformancePreferences(arg0: number, arg1: number, arg2: number): void;
        setReceiveBufferSize(arg0: number): void;
        setReuseAddress(arg0: boolean): void;
        setSendBufferSize(arg0: number): void;
        setSoLinger(arg0: boolean, arg1: number): void;
        setSoTimeout(arg0: number): void;
        setTcpNoDelay(arg0: boolean): void;
        setTrafficClass(arg0: number): void;
        shutdownInput(): void;
        shutdownOutput(): void;
        supportedOptions(): $Set<$SocketOption<any>>;
        toString(): string;
    }

    export interface $SocketImplFactory {
        createSocketImpl(): $SocketImpl;
    }

    export class $SocketImpl implements $SocketOptions {
        constructor();
        getOption(arg0: number): unknown;
        setOption(arg0: number, arg1: unknown): void;
        toString(): string;
    }

    export type $ContentHandlerFactory_<CallbackArg0 = string, CallbackResult = $ContentHandler> = ((arg0: CallbackArg0) => CallbackResult) | ($ContentHandlerFactory & { readonly [Symbol.hasInstance]?: never });
    export type $FileNameMap_<CallbackArg0 = string, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($FileNameMap & { readonly [Symbol.hasInstance]?: never });
    export type $Proxy$Type_ = $Proxy$Type | "DIRECT" | "HTTP" | "SOCKS";
    export type $URLStreamHandlerFactory_<CallbackArg0 = string, CallbackResult = $URLStreamHandler> = ((arg0: CallbackArg0) => CallbackResult) | ($URLStreamHandlerFactory & { readonly [Symbol.hasInstance]?: never });
    export type $ProtocolFamily_<CallbackResult = string> = (() => CallbackResult) | ($ProtocolFamily & { readonly [Symbol.hasInstance]?: never });
    export type $DatagramSocketImplFactory_<CallbackResult = $DatagramSocketImpl> = (() => CallbackResult) | ($DatagramSocketImplFactory & { readonly [Symbol.hasInstance]?: never });
    export type $SocketImplFactory_<CallbackResult = $SocketImpl> = (() => CallbackResult) | ($SocketImplFactory & { readonly [Symbol.hasInstance]?: never });
}
