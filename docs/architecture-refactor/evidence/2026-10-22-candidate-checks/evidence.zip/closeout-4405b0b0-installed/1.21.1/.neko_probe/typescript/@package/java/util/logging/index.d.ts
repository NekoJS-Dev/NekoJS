import { $Serializable } from "java:java/io";
import { $Exception, $Throwable } from "java:java/lang";
import { $Instant } from "java:java/time";
import { $ResourceBundle } from "java:java/util";

declare module "java:java/util/logging" {
    export class $Handler {
        get encoding(): string;
        getEncoding(): string;
        set encoding(value: string);
        get errorManager(): $ErrorManager;
        getErrorManager(): $ErrorManager;
        set errorManager(value: $ErrorManager);
        get filter(): $Filter;
        getFilter(): $Filter;
        set filter(value: $Filter_<$LogRecord, boolean>);
        get formatter(): $Formatter;
        getFormatter(): $Formatter;
        set formatter(value: $Formatter);
        get level(): $Level;
        getLevel(): $Level;
        set level(value: $Level);
        close(): void;
        flush(): void;
        isLoggable(arg0: $LogRecord): boolean;
        publish(arg0: $LogRecord): void;
        setEncoding(arg0: string): void;
        setErrorManager(arg0: $ErrorManager): void;
        setFilter(arg0: $Filter_<$LogRecord, boolean>): void;
        setFormatter(arg0: $Formatter): void;
        setLevel(arg0: $Level): void;
    }

    export class $ErrorManager {
        constructor();
        static CLOSE_FAILURE: number;
        static FLUSH_FAILURE: number;
        static FORMAT_FAILURE: number;
        static GENERIC_FAILURE: number;
        static OPEN_FAILURE: number;
        static WRITE_FAILURE: number;
        error(arg0: string, arg1: $Exception, arg2: number): void;
    }

    export interface $Filter {
        isLoggable(arg0: $LogRecord): boolean;
    }

    export class $Formatter {
        formatMessage(arg0: $LogRecord): string;
        format(arg0: $LogRecord): string;
        getHead(arg0: $Handler): string;
        getTail(arg0: $Handler): string;
    }

    export class $Level implements $Serializable {
        static ALL: $Level;
        static CONFIG: $Level;
        static FINE: $Level;
        static FINER: $Level;
        static FINEST: $Level;
        static INFO: $Level;
        static OFF: $Level;
        static SEVERE: $Level;
        static WARNING: $Level;
        get localizedName(): string;
        getLocalizedName(): string;
        get name(): string;
        getName(): string;
        get resourceBundleName(): string;
        getResourceBundleName(): string;
        static parse(arg0: string): $Level;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        intValue(): number;
        toString(): string;
    }

    export class $LogRecord implements $Serializable {
        constructor(arg0: $Level, arg1: string);
        get instant(): $Instant;
        getInstant(): $Instant;
        set instant(value: $Instant);
        get level(): $Level;
        getLevel(): $Level;
        set level(value: $Level);
        get loggerName(): string;
        getLoggerName(): string;
        set loggerName(value: string);
        get longThreadID(): number;
        getLongThreadID(): number;
        set longThreadID(value: number);
        get message(): string;
        getMessage(): string;
        set message(value: string);
        get millis(): number;
        getMillis(): number;
        set millis(value: number);
        get parameters(): unknown[];
        getParameters(): unknown[];
        set parameters(value: unknown[]);
        get resourceBundleName(): string;
        getResourceBundleName(): string;
        set resourceBundleName(value: string);
        get resourceBundle(): $ResourceBundle;
        getResourceBundle(): $ResourceBundle;
        set resourceBundle(value: $ResourceBundle);
        get sequenceNumber(): number;
        getSequenceNumber(): number;
        set sequenceNumber(value: number);
        get sourceClassName(): string;
        getSourceClassName(): string;
        set sourceClassName(value: string);
        get sourceMethodName(): string;
        getSourceMethodName(): string;
        set sourceMethodName(value: string);
        get threadID(): number;
        getThreadID(): number;
        set threadID(value: number);
        get thrown(): $Throwable;
        getThrown(): $Throwable;
        set thrown(value: $Throwable);
        setInstant(arg0: $Instant): void;
        setLevel(arg0: $Level): void;
        setLoggerName(arg0: string): void;
        setLongThreadID(arg0: number): $LogRecord;
        setMessage(arg0: string): void;
        setMillis(arg0: number): void;
        setParameters(arg0: unknown[]): void;
        setResourceBundleName(arg0: string): void;
        setResourceBundle(arg0: $ResourceBundle): void;
        setSequenceNumber(arg0: number): void;
        setSourceClassName(arg0: string): void;
        setSourceMethodName(arg0: string): void;
        setThreadID(arg0: number): void;
        setThrown(arg0: $Throwable): void;
    }

    export type $Filter_<CallbackArg0 = $LogRecord, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($Filter & { readonly [Symbol.hasInstance]?: never });
}
