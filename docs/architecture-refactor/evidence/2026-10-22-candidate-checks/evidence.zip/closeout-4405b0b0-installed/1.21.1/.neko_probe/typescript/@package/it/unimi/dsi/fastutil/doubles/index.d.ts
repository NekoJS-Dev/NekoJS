import { $Function as $NekoImport$Function, $Function_ as $NekoImport$Function_, $Pair } from "java:it/unimi/dsi/fastutil";
import { $Byte2ByteFunction, $Byte2ByteFunction_, $Byte2CharFunction, $Byte2CharFunction_, $Byte2DoubleFunction, $Byte2DoubleFunction_, $Byte2FloatFunction, $Byte2FloatFunction_, $Byte2IntFunction, $Byte2IntFunction_, $Byte2LongFunction, $Byte2LongFunction_, $Byte2ObjectFunction, $Byte2ObjectFunction_, $Byte2ReferenceFunction, $Byte2ReferenceFunction_, $Byte2ShortFunction, $Byte2ShortFunction_ } from "java:it/unimi/dsi/fastutil/bytes";
import { $Char2ByteFunction, $Char2ByteFunction_, $Char2CharFunction, $Char2CharFunction_, $Char2DoubleFunction, $Char2DoubleFunction_, $Char2FloatFunction, $Char2FloatFunction_, $Char2IntFunction, $Char2IntFunction_, $Char2LongFunction, $Char2LongFunction_, $Char2ObjectFunction, $Char2ObjectFunction_, $Char2ReferenceFunction, $Char2ReferenceFunction_, $Char2ShortFunction, $Char2ShortFunction_ } from "java:it/unimi/dsi/fastutil/chars";
import { $Float2ByteFunction, $Float2ByteFunction_, $Float2CharFunction, $Float2CharFunction_, $Float2DoubleFunction, $Float2DoubleFunction_, $Float2FloatFunction, $Float2FloatFunction_, $Float2IntFunction, $Float2IntFunction_, $Float2LongFunction, $Float2LongFunction_, $Float2ObjectFunction, $Float2ObjectFunction_, $Float2ReferenceFunction, $Float2ReferenceFunction_, $Float2ShortFunction, $Float2ShortFunction_ } from "java:it/unimi/dsi/fastutil/floats";
import { $Int2ByteFunction, $Int2ByteFunction_, $Int2CharFunction, $Int2CharFunction_, $Int2DoubleFunction, $Int2DoubleFunction_, $Int2FloatFunction, $Int2FloatFunction_, $Int2IntFunction, $Int2IntFunction_, $Int2LongFunction, $Int2LongFunction_, $Int2ObjectFunction, $Int2ObjectFunction_, $Int2ReferenceFunction, $Int2ReferenceFunction_, $Int2ShortFunction, $Int2ShortFunction_ } from "java:it/unimi/dsi/fastutil/ints";
import { $Long2ByteFunction, $Long2ByteFunction_, $Long2CharFunction, $Long2CharFunction_, $Long2DoubleFunction, $Long2DoubleFunction_, $Long2FloatFunction, $Long2FloatFunction_, $Long2IntFunction, $Long2IntFunction_, $Long2LongFunction, $Long2LongFunction_, $Long2ObjectFunction, $Long2ObjectFunction_, $Long2ReferenceFunction, $Long2ReferenceFunction_, $Long2ShortFunction, $Long2ShortFunction_ } from "java:it/unimi/dsi/fastutil/longs";
import { $Object2ByteFunction, $Object2ByteFunction_, $Object2CharFunction, $Object2CharFunction_, $Object2DoubleFunction, $Object2DoubleFunction_, $Object2FloatFunction, $Object2FloatFunction_, $Object2IntFunction, $Object2IntFunction_, $Object2LongFunction, $Object2LongFunction_, $Object2ObjectFunction, $Object2ObjectFunction_, $Object2ReferenceFunction, $Object2ReferenceFunction_, $Object2ShortFunction, $Object2ShortFunction_, $ObjectBidirectionalIterator, $Reference2ByteFunction, $Reference2ByteFunction_, $Reference2CharFunction, $Reference2CharFunction_, $Reference2DoubleFunction, $Reference2DoubleFunction_, $Reference2FloatFunction, $Reference2FloatFunction_, $Reference2IntFunction, $Reference2IntFunction_, $Reference2LongFunction, $Reference2LongFunction_, $Reference2ObjectFunction, $Reference2ObjectFunction_, $Reference2ReferenceFunction, $Reference2ReferenceFunction_, $Reference2ShortFunction, $Reference2ShortFunction_ } from "java:it/unimi/dsi/fastutil/objects";
import { $Short2ByteFunction, $Short2ByteFunction_, $Short2CharFunction, $Short2CharFunction_, $Short2DoubleFunction, $Short2DoubleFunction_, $Short2FloatFunction, $Short2FloatFunction_, $Short2IntFunction, $Short2IntFunction_, $Short2LongFunction, $Short2LongFunction_, $Short2ObjectFunction, $Short2ObjectFunction_, $Short2ReferenceFunction, $Short2ReferenceFunction_, $Short2ShortFunction, $Short2ShortFunction_ } from "java:it/unimi/dsi/fastutil/shorts";
import { $Serializable } from "java:java/io";
import { $Comparable, $Comparable_, $Iterable } from "java:java/lang";
import { $Collection, $Comparator, $Comparator_, $List, $ListIterator, $PrimitiveIterator$OfDouble, $Spliterator$OfDouble } from "java:java/util";
import { $BinaryOperator, $BinaryOperator_, $Consumer, $Consumer_, $DoubleBinaryOperator as $NekoImport$DoubleBinaryOperator, $DoubleBinaryOperator_ as $NekoImport$DoubleBinaryOperator_, $DoubleConsumer as $NekoImport$DoubleConsumer, $DoubleConsumer_ as $NekoImport$DoubleConsumer_, $DoubleFunction, $DoubleFunction_, $DoublePredicate as $NekoImport$DoublePredicate, $DoublePredicate_ as $NekoImport$DoublePredicate_, $DoubleToIntFunction, $DoubleToIntFunction_, $DoubleToLongFunction, $DoubleToLongFunction_, $DoubleUnaryOperator as $NekoImport$DoubleUnaryOperator, $DoubleUnaryOperator_ as $NekoImport$DoubleUnaryOperator_, $Function as $NekoImport$Function1, $Function_ as $NekoImport$Function_1, $IntFunction, $IntFunction_, $Predicate, $Predicate_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $DoubleStream, $Stream } from "java:java/util/stream";

declare module "java:it/unimi/dsi/fastutil/doubles" {
    export interface $Double2ObjectFunction<out V> extends $NekoImport$Function<number, V>, $DoubleFunction<V> {
        andThenByte(arg0: $Object2ByteFunction_<V, unknown, number>): $Double2ByteFunction;
        andThenChar(arg0: $Object2CharFunction_<V, unknown, string>): $Double2CharFunction;
        andThenDouble(arg0: $Object2DoubleFunction_<V, unknown, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Object2FloatFunction_<V, unknown, number>): $Double2FloatFunction;
        andThenInt(arg0: $Object2IntFunction_<V, unknown, number>): $Double2IntFunction;
        andThenLong(arg0: $Object2LongFunction_<V, unknown, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Object2ObjectFunction_<V, T, unknown, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Object2ReferenceFunction_<V, T, unknown, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Object2ShortFunction_<V, unknown, number>): $Double2ShortFunction;
        apply(arg0: number): V;
        apply(arg0: number): V;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2ObjectFunction<V>;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2ObjectFunction<V>;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2ObjectFunction<V>;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2ObjectFunction<V>;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2ObjectFunction<V>;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2ObjectFunction<V>;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2ObjectFunction<T, V>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2ObjectFunction<T, V>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2ObjectFunction<V>;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, V>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: number, arg1: V): V;
        getOrDefault(arg0: unknown, arg1: V): V;
        get(arg0: number): V;
        get(arg0: unknown): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: number): V;
        remove(arg0: unknown): V;
    }

    export interface $Double2ByteFunction extends $NekoImport$Function<number, number>, $DoubleToIntFunction {
        andThenByte(arg0: $Byte2ByteFunction_<number, number>): $Double2ByteFunction;
        andThenChar(arg0: $Byte2CharFunction_<number, string>): $Double2CharFunction;
        andThenDouble(arg0: $Byte2DoubleFunction_<number, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Byte2FloatFunction_<number, number>): $Double2FloatFunction;
        andThenInt(arg0: $Byte2IntFunction_<number, number>): $Double2IntFunction;
        andThenLong(arg0: $Byte2LongFunction_<number, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Byte2ObjectFunction_<T, number, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Byte2ReferenceFunction_<T, number, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Byte2ShortFunction_<number, number>): $Double2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2ByteFunction;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2ByteFunction;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2ByteFunction;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2ByteFunction;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2ByteFunction;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2ByteFunction;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2ByteFunction<T>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2ByteFunction<T>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2ByteFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $Double2CharFunction extends $NekoImport$Function<number, string>, $DoubleToIntFunction {
        andThenByte(arg0: $Char2ByteFunction_<string, number>): $Double2ByteFunction;
        andThenChar(arg0: $Char2CharFunction_<string, string>): $Double2CharFunction;
        andThenDouble(arg0: $Char2DoubleFunction_<string, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Char2FloatFunction_<string, number>): $Double2FloatFunction;
        andThenInt(arg0: $Char2IntFunction_<string, number>): $Double2IntFunction;
        andThenLong(arg0: $Char2LongFunction_<string, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Char2ObjectFunction_<T, string, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Char2ReferenceFunction_<T, string, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Char2ShortFunction_<string, number>): $Double2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<string, T, string, T>): $NekoImport$Function1<number, T>;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2CharFunction;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2CharFunction;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2CharFunction;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2CharFunction;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2CharFunction;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2CharFunction;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2CharFunction<T>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2CharFunction<T>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2CharFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, string>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: string): void;
        defaultReturnValue(): string;
        getOrDefault(arg0: number, arg1: string): string;
        getOrDefault(arg0: unknown, arg1: string): string;
        get(arg0: number): string;
        get(arg0: unknown): string;
        put(arg0: number, arg1: string): string;
        put(arg0: number, arg1: string): string;
        remove(arg0: number): string;
        remove(arg0: unknown): string;
    }

    export interface $Double2DoubleFunction extends $NekoImport$Function<number, number>, $NekoImport$DoubleUnaryOperator {
        andThenByte(arg0: $Double2ByteFunction_<number, number>): $Double2ByteFunction;
        andThenChar(arg0: $Double2CharFunction_<number, string>): $Double2CharFunction;
        andThenDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Double2FloatFunction_<number, number>): $Double2FloatFunction;
        andThenInt(arg0: $Double2IntFunction_<number, number>): $Double2IntFunction;
        andThenLong(arg0: $Double2LongFunction_<number, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Double2ObjectFunction_<T, number, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Double2ReferenceFunction_<T, number, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Double2ShortFunction_<number, number>): $Double2ShortFunction;
        andThen(arg0: $NekoImport$DoubleUnaryOperator_<number, number>): $NekoImport$DoubleUnaryOperator;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsDouble(arg0: number): number;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2DoubleFunction;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2DoubleFunction;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2DoubleFunction;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2DoubleFunction;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2DoubleFunction;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2DoubleFunction;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2DoubleFunction<T>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2DoubleFunction<T>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2DoubleFunction;
        compose(arg0: $NekoImport$DoubleUnaryOperator_<number, number>): $NekoImport$DoubleUnaryOperator;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }
    export const $Double2DoubleFunction: {
        identity(): $Double2DoubleFunction;
    };

    export interface $Double2FloatFunction extends $NekoImport$Function<number, number>, $NekoImport$DoubleUnaryOperator {
        andThenByte(arg0: $Float2ByteFunction_<number, number>): $Double2ByteFunction;
        andThenChar(arg0: $Float2CharFunction_<number, string>): $Double2CharFunction;
        andThenDouble(arg0: $Float2DoubleFunction_<number, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Float2FloatFunction_<number, number>): $Double2FloatFunction;
        andThenInt(arg0: $Float2IntFunction_<number, number>): $Double2IntFunction;
        andThenLong(arg0: $Float2LongFunction_<number, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Float2ObjectFunction_<T, number, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Float2ReferenceFunction_<T, number, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Float2ShortFunction_<number, number>): $Double2ShortFunction;
        andThen(arg0: $NekoImport$DoubleUnaryOperator_<number, number>): $NekoImport$DoubleUnaryOperator;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsDouble(arg0: number): number;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2FloatFunction;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2FloatFunction;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2FloatFunction;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2FloatFunction;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2FloatFunction;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2FloatFunction;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2FloatFunction<T>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2FloatFunction<T>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2FloatFunction;
        compose(arg0: $NekoImport$DoubleUnaryOperator_<number, number>): $NekoImport$DoubleUnaryOperator;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $Double2IntFunction extends $NekoImport$Function<number, number>, $DoubleToIntFunction {
        andThenByte(arg0: $Int2ByteFunction_<number, number>): $Double2ByteFunction;
        andThenChar(arg0: $Int2CharFunction_<number, string>): $Double2CharFunction;
        andThenDouble(arg0: $Int2DoubleFunction_<number, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Int2FloatFunction_<number, number>): $Double2FloatFunction;
        andThenInt(arg0: $Int2IntFunction_<number, number>): $Double2IntFunction;
        andThenLong(arg0: $Int2LongFunction_<number, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Int2ObjectFunction_<T, number, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Int2ReferenceFunction_<T, number, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Int2ShortFunction_<number, number>): $Double2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2IntFunction;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2IntFunction;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2IntFunction;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2IntFunction;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2IntFunction;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2IntFunction;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2IntFunction<T>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2IntFunction<T>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2IntFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $Double2LongFunction extends $NekoImport$Function<number, number>, $DoubleToLongFunction {
        andThenByte(arg0: $Long2ByteFunction_<number, number>): $Double2ByteFunction;
        andThenChar(arg0: $Long2CharFunction_<number, string>): $Double2CharFunction;
        andThenDouble(arg0: $Long2DoubleFunction_<number, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Long2FloatFunction_<number, number>): $Double2FloatFunction;
        andThenInt(arg0: $Long2IntFunction_<number, number>): $Double2IntFunction;
        andThenLong(arg0: $Long2LongFunction_<number, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Long2ObjectFunction_<T, number, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Long2ReferenceFunction_<T, number, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Long2ShortFunction_<number, number>): $Double2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsLong(arg0: number): number;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2LongFunction;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2LongFunction;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2LongFunction;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2LongFunction;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2LongFunction;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2LongFunction;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2LongFunction<T>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2LongFunction<T>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2LongFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $Double2ReferenceFunction<out V> extends $NekoImport$Function<number, V>, $DoubleFunction<V> {
        andThenByte(arg0: $Reference2ByteFunction_<V, unknown, number>): $Double2ByteFunction;
        andThenChar(arg0: $Reference2CharFunction_<V, unknown, string>): $Double2CharFunction;
        andThenDouble(arg0: $Reference2DoubleFunction_<V, unknown, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Reference2FloatFunction_<V, unknown, number>): $Double2FloatFunction;
        andThenInt(arg0: $Reference2IntFunction_<V, unknown, number>): $Double2IntFunction;
        andThenLong(arg0: $Reference2LongFunction_<V, unknown, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Reference2ObjectFunction_<V, T, unknown, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Reference2ReferenceFunction_<V, T, unknown, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Reference2ShortFunction_<V, unknown, number>): $Double2ShortFunction;
        apply(arg0: number): V;
        apply(arg0: number): V;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2ReferenceFunction<V>;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2ReferenceFunction<V>;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2ReferenceFunction<V>;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2ReferenceFunction<V>;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2ReferenceFunction<V>;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2ReferenceFunction<V>;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2ReferenceFunction<T, V>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2ReferenceFunction<T, V>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2ReferenceFunction<V>;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, V>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: V): void;
        defaultReturnValue(): V;
        getOrDefault(arg0: number, arg1: V): V;
        getOrDefault(arg0: unknown, arg1: V): V;
        get(arg0: number): V;
        get(arg0: unknown): V;
        put(arg0: number, arg1: V): V;
        put(arg0: number, arg1: V): V;
        remove(arg0: number): V;
        remove(arg0: unknown): V;
    }

    export interface $Double2ShortFunction extends $NekoImport$Function<number, number>, $DoubleToIntFunction {
        andThenByte(arg0: $Short2ByteFunction_<number, number>): $Double2ByteFunction;
        andThenChar(arg0: $Short2CharFunction_<number, string>): $Double2CharFunction;
        andThenDouble(arg0: $Short2DoubleFunction_<number, number>): $Double2DoubleFunction;
        andThenFloat(arg0: $Short2FloatFunction_<number, number>): $Double2FloatFunction;
        andThenInt(arg0: $Short2IntFunction_<number, number>): $Double2IntFunction;
        andThenLong(arg0: $Short2LongFunction_<number, number>): $Double2LongFunction;
        andThenObject<T>(arg0: $Short2ObjectFunction_<T, number, T>): $Double2ObjectFunction<T>;
        andThenReference<T>(arg0: $Short2ReferenceFunction_<T, number, T>): $Double2ReferenceFunction<T>;
        andThenShort(arg0: $Short2ShortFunction_<number, number>): $Double2ShortFunction;
        andThen<T>(arg0: $NekoImport$Function_1<number, T, number, T>): $NekoImport$Function1<number, T>;
        applyAsInt(arg0: number): number;
        composeByte(arg0: $Byte2DoubleFunction_<number, number>): $Byte2ShortFunction;
        composeChar(arg0: $Char2DoubleFunction_<string, number>): $Char2ShortFunction;
        composeDouble(arg0: $Double2DoubleFunction_<number, number>): $Double2ShortFunction;
        composeFloat(arg0: $Float2DoubleFunction_<number, number>): $Float2ShortFunction;
        composeInt(arg0: $Int2DoubleFunction_<number, number>): $Int2ShortFunction;
        composeLong(arg0: $Long2DoubleFunction_<number, number>): $Long2ShortFunction;
        composeObject<T>(arg0: $Object2DoubleFunction_<T, unknown, number>): $Object2ShortFunction<T>;
        composeReference<T>(arg0: $Reference2DoubleFunction_<T, unknown, number>): $Reference2ShortFunction<T>;
        composeShort(arg0: $Short2DoubleFunction_<number, number>): $Short2ShortFunction;
        compose<T>(arg0: $NekoImport$Function_1<T, number, T, number>): $NekoImport$Function1<T, number>;
        containsKey(arg0: number): boolean;
        containsKey(arg0: unknown): boolean;
        defaultReturnValue(arg0: number): void;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        getOrDefault(arg0: unknown, arg1: number): number;
        get(arg0: number): number;
        get(arg0: unknown): number;
        put(arg0: number, arg1: number): number;
        put(arg0: number, arg1: number): number;
        remove(arg0: number): number;
        remove(arg0: unknown): number;
    }

    export interface $DoubleBinaryOperator extends $BinaryOperator<number>, $NekoImport$DoubleBinaryOperator {
        applyAsDouble(arg0: number, arg1: number): number;
        apply(arg0: number, arg1: number): number;
        apply(arg0: number, arg1: number): number;
    }

    export interface $DoubleCollection extends $Collection<number>, $DoubleIterable {
        addAll(arg0: $DoubleCollection): boolean;
        addAll(arg0: ($Collection<number> | (number)[])): boolean;
        add(arg0: number): boolean;
        add(arg0: number): boolean;
        containsAll(arg0: $DoubleCollection): boolean;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: number): boolean;
        contains(arg0: unknown): boolean;
        doubleIterator(): $DoubleIterator;
        doubleParallelStream(): $DoubleStream;
        doubleSpliterator(): $DoubleSpliterator;
        doubleStream(): $DoubleStream;
        forEach(arg0: $DoubleConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$DoubleConsumer_<number>): void;
        iterator(): $DoubleIterator;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $DoubleCollection): boolean;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeIf(arg0: $DoublePredicate_<number, boolean>): boolean;
        removeIf(arg0: $NekoImport$DoublePredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        remove(arg0: unknown): boolean;
        rem(arg0: number): boolean;
        retainAll(arg0: $DoubleCollection): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        spliterator(): $DoubleSpliterator;
        stream(): $Stream<number>;
        toArray<T>(arg0: T[]): T[];
        toArray(arg0: number[]): number[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
        toDoubleArray(arg0: number[]): number[];
        toDoubleArray(): number[];
    }

    export interface $DoubleConsumer extends $Consumer<number>, $NekoImport$DoubleConsumer {
        accept(arg0: number): void;
        accept(arg0: number): void;
        andThen(arg0: $DoubleConsumer_<number>): $DoubleConsumer;
        andThen(arg0: $Consumer_<number, number>): $Consumer<number>;
        andThen(arg0: $NekoImport$DoubleConsumer_<number>): $DoubleConsumer;
    }

    export interface $DoubleIterable extends $Iterable<number> {
        doubleIterator(): $DoubleIterator;
        doubleSpliterator(): $DoubleSpliterator;
        forEach(arg0: $DoubleConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$DoubleConsumer_<number>): void;
        iterator(): $DoubleIterator;
        spliterator(): $DoubleSpliterator;
    }

    export interface $DoubleIterator extends $PrimitiveIterator$OfDouble {
        forEachRemaining(arg0: $DoubleConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$DoubleConsumer_<number>): void;
        nextDouble(): number;
        next(): number;
        skip(arg0: number): number;
    }

    export interface $DoublePredicate extends $Predicate<number>, $NekoImport$DoublePredicate {
        and(arg0: $DoublePredicate_<number, boolean>): $DoublePredicate;
        and(arg0: $NekoImport$DoublePredicate_<number, boolean>): $DoublePredicate;
        and(arg0: $Predicate_<number, number, boolean>): $Predicate<number>;
        negate(): $DoublePredicate;
        or(arg0: $DoublePredicate_<number, boolean>): $DoublePredicate;
        or(arg0: $NekoImport$DoublePredicate_<number, boolean>): $DoublePredicate;
        or(arg0: $Predicate_<number, number, boolean>): $Predicate<number>;
        test(arg0: number): boolean;
        test(arg0: number): boolean;
    }

    export interface $DoubleSpliterator extends $Spliterator$OfDouble {
        forEachRemaining(arg0: $DoubleConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$DoubleConsumer_<number>): void;
        getComparator(): $DoubleComparator;
        skip(arg0: number): number;
        tryAdvance(arg0: $DoubleConsumer_<number>): boolean;
        tryAdvance(arg0: $Consumer_<number, number>): boolean;
        tryAdvance(arg0: $NekoImport$DoubleConsumer_<number>): boolean;
        trySplit(): $DoubleSpliterator;
    }

    export interface $DoubleComparator extends $Comparator<number> {
        compare(arg0: number, arg1: number): number;
        compare(arg0: number, arg1: number): number;
        reversed(): $DoubleComparator;
        thenComparing(arg0: $DoubleComparator_<number, number, number>): $DoubleComparator;
        thenComparing(arg0: $Comparator_<number, number, number, number>): $Comparator<number>;
        thenComparing<U>(arg0: $NekoImport$Function_1<number, U, number, U>, arg1: $Comparator_<U, U, U, number>): $Comparator<number>;
        thenComparing<U extends $Comparable<any>>(arg0: $NekoImport$Function_1<number, U, number, U>): $Comparator<number>;
    }

    export class $DoubleDoubleImmutablePair implements $DoubleDoublePair, $Serializable {
        constructor(arg0: number, arg1: number);
        static of(arg0: number, arg1: number): $DoubleDoubleImmutablePair;
        equals(arg0: unknown): boolean;
        firstDouble(): number;
        first(arg0: number): $DoubleDoublePair;
        first(arg0: number): $DoubleDoublePair;
        first(): number;
        hashCode(): number;
        keyDouble(): number;
        key(arg0: number): $DoubleDoublePair;
        key(arg0: number): $DoubleDoublePair;
        key(): number;
        leftDouble(): number;
        left(arg0: number): $DoubleDoublePair;
        left(arg0: number): $DoubleDoublePair;
        left(): number;
        rightDouble(): number;
        right(arg0: number): $DoubleDoublePair;
        right(arg0: number): $DoubleDoublePair;
        right(): number;
        secondDouble(): number;
        second(arg0: number): $DoubleDoublePair;
        second(arg0: number): $DoubleDoublePair;
        second(): number;
        toString(): string;
        valueDouble(): number;
        value(arg0: number): $DoubleDoublePair;
        value(arg0: number): $DoubleDoublePair;
        value(): number;
    }

    export interface $DoubleDoublePair extends $Pair<number, number> {
        firstDouble(): number;
        first(arg0: number): $DoubleDoublePair;
        first(arg0: number): $DoubleDoublePair;
        first(): number;
        keyDouble(): number;
        key(arg0: number): $DoubleDoublePair;
        key(arg0: number): $DoubleDoublePair;
        key(): number;
        leftDouble(): number;
        left(arg0: number): $DoubleDoublePair;
        left(arg0: number): $DoubleDoublePair;
        left(): number;
        rightDouble(): number;
        right(arg0: number): $DoubleDoublePair;
        right(arg0: number): $DoubleDoublePair;
        right(): number;
        secondDouble(): number;
        second(arg0: number): $DoubleDoublePair;
        second(arg0: number): $DoubleDoublePair;
        second(): number;
        valueDouble(): number;
        value(arg0: number): $DoubleDoublePair;
        value(arg0: number): $DoubleDoublePair;
        value(): number;
    }
    export const $DoubleDoublePair: {
        lexComparator(): $Comparator<$DoubleDoublePair>;
        of(arg0: number, arg1: number): $DoubleDoublePair;
    };

    export interface $DoubleList extends $List<number>, $Comparable<$List<number>>, $DoubleCollection {
        addAll(arg0: number, arg1: $DoubleCollection): boolean;
        addAll(arg0: number, arg1: $DoubleList): boolean;
        addAll(arg0: number, arg1: ($Collection<number> | (number)[])): boolean;
        addAll(arg0: $DoubleCollection): boolean;
        addAll(arg0: $DoubleList): boolean;
        addAll(arg0: ($Collection<number> | (number)[])): boolean;
        addElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        addElements(arg0: number, arg1: number[]): void;
        add(arg0: number): boolean;
        add(arg0: number, arg1: number): void;
        add(arg0: number, arg1: number): void;
        add(arg0: number): boolean;
        clear(): void;
        containsAll(arg0: $DoubleCollection): boolean;
        containsAll(arg0: ($Collection<any> | (any)[])): boolean;
        contains(arg0: number): boolean;
        contains(arg0: unknown): boolean;
        equals(arg0: unknown): boolean;
        forEach(arg0: $DoubleConsumer_<number>): void;
        forEach(arg0: $Consumer_<number, number>): void;
        forEach(arg0: $NekoImport$DoubleConsumer_<number>): void;
        getDouble(arg0: number): number;
        getElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        get(arg0: number): number;
        hashCode(): number;
        indexOf(arg0: number): number;
        indexOf(arg0: unknown): number;
        isEmpty(): boolean;
        iterator(): $DoubleListIterator;
        lastIndexOf(arg0: number): number;
        lastIndexOf(arg0: unknown): number;
        listIterator(arg0: number): $DoubleListIterator;
        listIterator(): $DoubleListIterator;
        parallelStream(): $Stream<number>;
        removeAll(arg0: $DoubleCollection): boolean;
        removeAll(arg0: ($Collection<any> | (any)[])): boolean;
        removeDouble(arg0: number): number;
        removeElements(arg0: number, arg1: number): void;
        removeIf(arg0: $DoublePredicate_<number, boolean>): boolean;
        removeIf(arg0: $NekoImport$DoublePredicate_<number, boolean>): boolean;
        removeIf(arg0: $Predicate_<number, number, boolean>): boolean;
        remove(arg0: number): number;
        remove(arg0: unknown): boolean;
        replaceAll(arg0: $DoubleUnaryOperator_<number, number>): void;
        replaceAll(arg0: $NekoImport$DoubleUnaryOperator_<number, number>): void;
        replaceAll(arg0: $UnaryOperator_<number, number, number>): void;
        retainAll(arg0: $DoubleCollection): boolean;
        retainAll(arg0: ($Collection<any> | (any)[])): boolean;
        setElements(arg0: number[]): void;
        setElements(arg0: number, arg1: number[], arg2: number, arg3: number): void;
        setElements(arg0: number, arg1: number[]): void;
        set(arg0: number, arg1: number): number;
        set(arg0: number, arg1: number): number;
        size(arg0: number): void;
        size(): number;
        sort(arg0: $DoubleComparator_<number, number, number>): void;
        sort(arg0: $Comparator_<number, number, number, number>): void;
        spliterator(): $DoubleSpliterator;
        stream(): $Stream<number>;
        subList(arg0: number, arg1: number): $DoubleList;
        toArray<T>(arg0: T[]): T[];
        toArray(arg0: number[]): number[];
        toArray<T>(arg0: $IntFunction_<T[], number, T[]>): T[];
        toArray(): unknown[];
        unstableSort(arg0: $DoubleComparator_<number, number, number>): void;
        unstableSort(arg0: $Comparator_<number, number, number, number>): void;
    }
    export const $DoubleList: {
        of(arg0?: number[]): $DoubleList;
        of(arg0: number, arg1: number, arg2: number): $DoubleList;
        of(arg0: number, arg1: number): $DoubleList;
        of(arg0: number): $DoubleList;
        of(): $DoubleList;
    };

    export interface $DoubleListIterator extends $DoubleBidirectionalIterator, $ListIterator<number> {
        add(arg0: number): void;
        add(arg0: number): void;
        forEachRemaining(arg0: $DoubleConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$DoubleConsumer_<number>): void;
        hasNext(): boolean;
        hasPrevious(): boolean;
        next(): number;
        previous(): number;
        remove(): void;
        set(arg0: number): void;
        set(arg0: number): void;
    }

    export interface $DoubleUnaryOperator extends $UnaryOperator<number>, $NekoImport$DoubleUnaryOperator {
        andThen(arg0: $NekoImport$DoubleUnaryOperator_<number, number>): $NekoImport$DoubleUnaryOperator;
        andThen<V>(arg0: $NekoImport$Function_1<number, V, number, V>): $NekoImport$Function1<number, V>;
        applyAsDouble(arg0: number): number;
        apply(arg0: number): number;
        apply(arg0: number): number;
        compose(arg0: $NekoImport$DoubleUnaryOperator_<number, number>): $NekoImport$DoubleUnaryOperator;
        compose<V>(arg0: $NekoImport$Function_1<V, number, V, number>): $NekoImport$Function1<V, number>;
    }
    export const $DoubleUnaryOperator: {
        identity(): $DoubleUnaryOperator;
        negation(): $DoubleUnaryOperator;
    };

    export interface $DoubleBidirectionalIterator extends $DoubleIterator, $ObjectBidirectionalIterator<number> {
        back(arg0: number): number;
        forEachRemaining(arg0: $DoubleConsumer_<number>): void;
        forEachRemaining(arg0: $Consumer_<number, number>): void;
        forEachRemaining(arg0: $NekoImport$DoubleConsumer_<number>): void;
        hasNext(): boolean;
        next(): number;
        previousDouble(): number;
        previous(): number;
        remove(): void;
        skip(arg0: number): number;
    }

    export type $Double2ObjectFunction_<Host0 = any, CallbackArg0 = number, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2ObjectFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Double2ByteFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2ByteFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Double2CharFunction_<CallbackArg0 = number, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2CharFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Double2DoubleFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2DoubleFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Double2FloatFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2FloatFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Double2IntFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2IntFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Double2LongFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2LongFunction & { readonly [Symbol.hasInstance]?: never });
    export type $Double2ReferenceFunction_<Host0 = any, CallbackArg0 = number, CallbackResult = Host0> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2ReferenceFunction<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $Double2ShortFunction_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Double2ShortFunction & { readonly [Symbol.hasInstance]?: never });
    export type $DoubleBinaryOperator_<CallbackArg0 = number, CallbackArg1 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($DoubleBinaryOperator & { readonly [Symbol.hasInstance]?: never });
    export type $DoubleConsumer_<CallbackArg0 = number> = ((arg0: CallbackArg0) => void) | ($DoubleConsumer & { readonly [Symbol.hasInstance]?: never });
    export type $DoubleIterable_<CallbackResult = $DoubleIterator> = (() => CallbackResult) | ($DoubleIterable & { readonly [Symbol.hasInstance]?: never });
    export type $DoublePredicate_<CallbackArg0 = number, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | ($DoublePredicate & { readonly [Symbol.hasInstance]?: never });
    export type $DoubleComparator_<CallbackArg0 = number, CallbackArg1 = number, CallbackResult = number> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | ($DoubleComparator & { readonly [Symbol.hasInstance]?: never });
    export type $DoubleUnaryOperator_<CallbackArg0 = number, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($DoubleUnaryOperator & { readonly [Symbol.hasInstance]?: never });
}
