const Reflector = Java.type('com.tkisor.nekojs.probe.ir.TypeReflector');
for (const host of ['net.minecraft.server.MinecraftServer', 'net.minecraft.world.entity.player.Player', 'net.minecraft.world.level.Level']) {
    const cls = Java.type(host).class;
    const reflection = [];
    for (const method of cls.getMethods()) {
        if (String(method.getName()) !== 'neko$data') continue;
        reflection.push({ declaringClass: String(method.getDeclaringClass().getName()),
            genericReturnType: String(method.getGenericReturnType().getTypeName()),
            returnType: String(method.getReturnType().getName()), bridge: method.isBridge(), synthetic: method.isSynthetic() });
    }
    const ir = [];
    for (const method of new Reflector().reflect(cls).methods) {
        const name = String(method.name);
        if (name !== 'data' && name !== 'neko$data') continue;
        const slot = method.returnType;
        ir.push({ name, getter: method.isGetter, property: String(method.property),
            sourceType: slot.sourceType === null ? null : String(slot.sourceType.getTypeName()),
            ref: String(slot.ref), overridden: slot.overridden });
    }
    console.info('OWNED-DATA-SIGNATURES=' + JSON.stringify({ host, reflection, ir }));
}
