import assert, { deepEqual, fail } from 'node:assert';
assert(true);
assert.default(true);
if (!deepEqual({ value: 1 }, { value: 1 }) || deepEqual({ value: 1 }, { value: 2 })) {
  throw new Error('Owned assertion boolean helper mismatch');
}
for (const attempt of [() => fail(), () => fail(1), () => fail(1, 2),
    () => fail(1, 2, 'message'), () => fail(1, 2, 'message', 'operator')]) {
  let thrown = false;
  try { attempt(); } catch (error) { thrown = error instanceof assert.AssertionError; }
  if (!thrown) throw new Error('Owned assertion failure inputs mismatch');
}
const id = UUID.fromString('00000000-0000-0000-0000-000000000001');
if (id.compareTo(id) !== 0) throw new Error('Owned UUID host identity mismatch');
console.info('IDE-BATCH-NATIVE-ESM-ASSERT-UUID-PASS');
