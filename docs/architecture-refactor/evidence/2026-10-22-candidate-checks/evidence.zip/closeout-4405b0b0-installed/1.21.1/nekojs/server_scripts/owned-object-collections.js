
const FunctionClass = Java.type('java.util.function.Function');
const ArrayListClass = Java.type('java.util.ArrayList');
const HashSetClass = Java.type('java.util.HashSet');
const CollectionsClass = Java.type('java.util.Collections');
const identity = FunctionClass.identity();
for (const value of [12, 'value', true, null]) {
  if (identity.apply(value) !== value) throw new Error('Owned Object value roundtrip mismatch');
}
const hostList = new ArrayListClass();
hostList.add('one');
hostList.addAll(['two', 'three']);
const hostCopy = new ArrayListClass(hostList);
if (hostCopy.size() !== 3 || CollectionsClass.frequency(hostCopy, 'one') !== 1) {
  throw new Error('Owned host Collection input mismatch');
}
if (CollectionsClass.unmodifiableCollection(['one', 'two']).size() !== 2) {
  throw new Error('Owned array Collection conversion mismatch');
}
const hostSet = new HashSetClass(hostList);
if (CollectionsClass.unmodifiableSet(hostSet).size() !== 3) throw new Error('Owned host Set input mismatch');
let arraySetRejected = false;
try { CollectionsClass.unmodifiableSet(['one']).size(); } catch (error) {
  arraySetRejected = true;
}
if (!arraySetRejected) throw new Error('Owned unsupported Set array conversion was accepted');
console.info('OWNED-OBJECT-COLLECTION-INPUTS-PASS');
