import { $ProbeConstableValueProjectionTest$Calls as Calls } from 'java:com/tkisor/nekojs/probe';
import type { $ConstantDesc } from 'java:java/lang/constant';
const explicit: boolean = Calls.directDescription();
Calls.acceptDescription(true);
const rawHost: $ConstantDesc = Calls.classDescription();
rawHost.resolveConstantDesc;
const rawArray: $ConstantDesc[] = Calls.descriptions();
rawArray[0].resolveConstantDesc;
const explicitArray: (string | number)[] = Calls.explicitArray();
Calls.explicitVarargs(['value', 1.5]);
// @ts-expect-error Explicit array element unions do not include boolean.
explicitArray.push(true);
Calls.acceptAll([rawHost]);
Calls.acceptFactory(() => () => rawHost);
// @ts-expect-error An explicitly retained host array does not gain primitive inputs.
Calls.acceptAll([1.5]);
// @ts-expect-error Explicit nested SAM slots retain their raw result references.
Calls.acceptFactory(() => () => 1.5);
// @ts-expect-error A raw override of another slot must not leak into ordinary outputs.
const leakedHost: $ConstantDesc = Calls.doubleDescription().get();
// @ts-expect-error Explicit slot edits retain authority over the source's scalar projection.
Calls.acceptDescription(1.5);
// @ts-expect-error The edited result is not the original constant description domain.
const original: number = Calls.directDescription();
