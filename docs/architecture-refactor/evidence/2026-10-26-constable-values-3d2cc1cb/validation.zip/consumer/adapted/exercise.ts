import { $ProbeConstableValueProjectionTest$Calls as Calls } from 'java:com/tkisor/nekojs/probe';
import type { $ConstantDesc } from 'java:java/lang/constant';
Calls.acceptDescription(true);
Calls.acceptDescriptions([true]);
Calls.acceptSupplier(() => true);
Calls.acceptFactory(() => () => true);
// @ts-expect-error Explicit adapter inputs have priority over intrinsic value alternatives.
Calls.acceptDescription(1.5);
// @ts-expect-error The wildcard input element keeps the explicit adapter domain.
Calls.acceptDescriptions([1.5]);
// @ts-expect-error Callback results are Java inputs and use the explicit adapter domain.
Calls.acceptSupplier(() => 1.5);
// @ts-expect-error Nested callback results retain the same conversion priority.
Calls.acceptFactory(() => () => 1.5);
Calls.consume(value => {
    const received: number | string | $ConstantDesc = value;
    // @ts-expect-error Java callback operands are outputs, not the adapter's input shape.
    const inputOnly: boolean = value;
});
