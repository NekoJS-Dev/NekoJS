import { $InputStream, $PrintStream, $PrintWriter, $Serializable } from "java:java/io";
import { $Annotation, $Annotation_ } from "java:java/lang/annotation";
import { $ClassDesc, $Constable, $Constable_, $ConstantDesc, $ConstantDesc_, $DirectMethodHandleDesc, $DynamicConstantDesc } from "java:java/lang/constant";
import { $MethodHandles$Lookup, $TypeDescriptor$OfField } from "java:java/lang/invoke";
import { $Configuration, $ModuleDescriptor } from "java:java/lang/module";
import { $AccessFlag, $AccessFlag_, $AnnotatedElement, $AnnotatedType, $Constructor, $Field, $GenericDeclaration, $Method, $RecordComponent, $Type, $TypeVariable } from "java:java/lang/reflect";
import { $URL } from "java:java/net";
import { $CharBuffer } from "java:java/nio";
import { $Charset } from "java:java/nio/charset";
import { $ProtectionDomain } from "java:java/security";
import { $Duration } from "java:java/time";
import { $Comparator, $Comparator_, $Enumeration, $Iterator, $List, $Locale, $Map, $Optional, $Set, $Spliterator } from "java:java/util";
import { $ThreadFactory, $ThreadFactory_ } from "java:java/util/concurrent";
import { $Consumer, $Consumer_, $Function, $Function_ } from "java:java/util/function";
import { $IntStream, $Stream } from "java:java/util/stream";

export * as constant from "java:java/lang/constant";
export * as invoke from "java:java/lang/invoke";
export * as annotation from "java:java/lang/annotation";
export * as reflect from "java:java/lang/reflect";
export * as module from "java:java/lang/module";
export * as foreign from "java:java/lang/foreign";

declare module "java:java/lang" {
    export class $Double implements $Comparable<number>, $Constable, $ConstantDesc {
        constructor(arg0: number);
        constructor(arg0: string);
        static BYTES: number;
        static MAX_EXPONENT: number;
        static MAX_VALUE: number;
        static MIN_EXPONENT: number;
        static MIN_NORMAL: number;
        static MIN_VALUE: number;
        static NEGATIVE_INFINITY: number;
        static NaN: number;
        static POSITIVE_INFINITY: number;
        static PRECISION: number;
        static SIZE: number;
        static TYPE: $Class<number>;
        get infinite(): boolean;
        isInfinite(): boolean;
        get naN(): boolean;
        isNaN(): boolean;
        static compare(arg0: number, arg1: number): number;
        static doubleToLongBits(arg0: number): number;
        static doubleToRawLongBits(arg0: number): number;
        static hashCode(arg0: number): number;
        static isFinite(arg0: number): boolean;
        static isInfinite(arg0: number): boolean;
        static isNaN(arg0: number): boolean;
        static longBitsToDouble(arg0: number): number;
        static max(arg0: number, arg1: number): number;
        static min(arg0: number, arg1: number): number;
        static parseDouble(arg0: string): number;
        static sum(arg0: number, arg1: number): number;
        static toHexString(arg0: number): string;
        static toString(arg0: number): string;
        static valueOf(arg0: number): number;
        static valueOf(arg0: string): number;
        byteValue(): number;
        compareTo(arg0: number): number;
        describeConstable(): $Optional<number>;
        doubleValue(): number;
        equals(arg0: unknown): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        resolveConstantDesc(arg0: $MethodHandles$Lookup): number;
        shortValue(): number;
        toString(): string;
    }

    export class $Float implements $Comparable<number>, $Constable, $ConstantDesc {
        constructor(arg0: number);
        constructor(arg0: number);
        constructor(arg0: string);
        static BYTES: number;
        static MAX_EXPONENT: number;
        static MAX_VALUE: number;
        static MIN_EXPONENT: number;
        static MIN_NORMAL: number;
        static MIN_VALUE: number;
        static NEGATIVE_INFINITY: number;
        static NaN: number;
        static POSITIVE_INFINITY: number;
        static PRECISION: number;
        static SIZE: number;
        static TYPE: $Class<number>;
        get infinite(): boolean;
        isInfinite(): boolean;
        get naN(): boolean;
        isNaN(): boolean;
        static compare(arg0: number, arg1: number): number;
        static float16ToFloat(arg0: number): number;
        static floatToFloat16(arg0: number): number;
        static floatToIntBits(arg0: number): number;
        static floatToRawIntBits(arg0: number): number;
        static hashCode(arg0: number): number;
        static intBitsToFloat(arg0: number): number;
        static isFinite(arg0: number): boolean;
        static isInfinite(arg0: number): boolean;
        static isNaN(arg0: number): boolean;
        static max(arg0: number, arg1: number): number;
        static min(arg0: number, arg1: number): number;
        static parseFloat(arg0: string): number;
        static sum(arg0: number, arg1: number): number;
        static toHexString(arg0: number): string;
        static toString(arg0: number): string;
        static valueOf(arg0: number): number;
        static valueOf(arg0: string): number;
        byteValue(): number;
        compareTo(arg0: number): number;
        describeConstable(): $Optional<number>;
        doubleValue(): number;
        equals(arg0: unknown): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        resolveConstantDesc(arg0: $MethodHandles$Lookup): number;
        shortValue(): number;
        toString(): string;
    }

    export class $Integer implements $Comparable<number>, $Constable, $ConstantDesc {
        constructor(arg0: number);
        constructor(arg0: string);
        static BYTES: number;
        static MAX_VALUE: number;
        static MIN_VALUE: number;
        static SIZE: number;
        static TYPE: $Class<number>;
        static bitCount(arg0: number): number;
        static compareUnsigned(arg0: number, arg1: number): number;
        static compare(arg0: number, arg1: number): number;
        static compress(arg0: number, arg1: number): number;
        static decode(arg0: string): number;
        static divideUnsigned(arg0: number, arg1: number): number;
        static expand(arg0: number, arg1: number): number;
        static getInteger(arg0: string, arg1: number): number;
        static getInteger(arg0: string, arg1: number): number;
        static getInteger(arg0: string): number;
        static hashCode(arg0: number): number;
        static highestOneBit(arg0: number): number;
        static lowestOneBit(arg0: number): number;
        static max(arg0: number, arg1: number): number;
        static min(arg0: number, arg1: number): number;
        static numberOfLeadingZeros(arg0: number): number;
        static numberOfTrailingZeros(arg0: number): number;
        static parseInt(arg0: $CharSequence, arg1: number, arg2: number, arg3: number): number;
        static parseInt(arg0: string, arg1: number): number;
        static parseInt(arg0: string): number;
        static parseUnsignedInt(arg0: $CharSequence, arg1: number, arg2: number, arg3: number): number;
        static parseUnsignedInt(arg0: string, arg1: number): number;
        static parseUnsignedInt(arg0: string): number;
        static remainderUnsigned(arg0: number, arg1: number): number;
        static reverseBytes(arg0: number): number;
        static reverse(arg0: number): number;
        static rotateLeft(arg0: number, arg1: number): number;
        static rotateRight(arg0: number, arg1: number): number;
        static signum(arg0: number): number;
        static sum(arg0: number, arg1: number): number;
        static toBinaryString(arg0: number): string;
        static toHexString(arg0: number): string;
        static toOctalString(arg0: number): string;
        static toString(arg0: number, arg1: number): string;
        static toString(arg0: number): string;
        static toUnsignedLong(arg0: number): number;
        static toUnsignedString(arg0: number, arg1: number): string;
        static toUnsignedString(arg0: number): string;
        static valueOf(arg0: number): number;
        static valueOf(arg0: string, arg1: number): number;
        static valueOf(arg0: string): number;
        byteValue(): number;
        compareTo(arg0: number): number;
        describeConstable(): $Optional<number>;
        doubleValue(): number;
        equals(arg0: unknown): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        resolveConstantDesc(arg0: $MethodHandles$Lookup): number;
        shortValue(): number;
        toString(): string;
    }

    export class $Long implements $Comparable<number>, $Constable, $ConstantDesc {
        constructor(arg0: string);
        constructor(arg0: number);
        static BYTES: number;
        static MAX_VALUE: number;
        static MIN_VALUE: number;
        static SIZE: number;
        static TYPE: $Class<number>;
        static bitCount(arg0: number): number;
        static compareUnsigned(arg0: number, arg1: number): number;
        static compare(arg0: number, arg1: number): number;
        static compress(arg0: number, arg1: number): number;
        static decode(arg0: string): number;
        static divideUnsigned(arg0: number, arg1: number): number;
        static expand(arg0: number, arg1: number): number;
        static getLong(arg0: string, arg1: number): number;
        static getLong(arg0: string, arg1: number): number;
        static getLong(arg0: string): number;
        static hashCode(arg0: number): number;
        static highestOneBit(arg0: number): number;
        static lowestOneBit(arg0: number): number;
        static max(arg0: number, arg1: number): number;
        static min(arg0: number, arg1: number): number;
        static numberOfLeadingZeros(arg0: number): number;
        static numberOfTrailingZeros(arg0: number): number;
        static parseLong(arg0: $CharSequence, arg1: number, arg2: number, arg3: number): number;
        static parseLong(arg0: string, arg1: number): number;
        static parseLong(arg0: string): number;
        static parseUnsignedLong(arg0: $CharSequence, arg1: number, arg2: number, arg3: number): number;
        static parseUnsignedLong(arg0: string, arg1: number): number;
        static parseUnsignedLong(arg0: string): number;
        static remainderUnsigned(arg0: number, arg1: number): number;
        static reverseBytes(arg0: number): number;
        static reverse(arg0: number): number;
        static rotateLeft(arg0: number, arg1: number): number;
        static rotateRight(arg0: number, arg1: number): number;
        static signum(arg0: number): number;
        static sum(arg0: number, arg1: number): number;
        static toBinaryString(arg0: number): string;
        static toHexString(arg0: number): string;
        static toOctalString(arg0: number): string;
        static toString(arg0: number, arg1: number): string;
        static toString(arg0: number): string;
        static toUnsignedString(arg0: number, arg1: number): string;
        static toUnsignedString(arg0: number): string;
        static valueOf(arg0: string, arg1: number): number;
        static valueOf(arg0: string): number;
        static valueOf(arg0: number): number;
        byteValue(): number;
        compareTo(arg0: number): number;
        describeConstable(): $Optional<number>;
        doubleValue(): number;
        equals(arg0: unknown): boolean;
        floatValue(): number;
        hashCode(): number;
        intValue(): number;
        longValue(): number;
        resolveConstantDesc(arg0: $MethodHandles$Lookup): number;
        shortValue(): number;
        toString(): string;
    }

    export class $String implements $Serializable, $Comparable<string>, $CharSequence, $Constable, $ConstantDesc {
        constructor();
        constructor(arg0: number[]);
        constructor(arg0: number[], arg1: number);
        constructor(arg0: number[], arg1: number, arg2: number);
        constructor(arg0: number[], arg1: number, arg2: number, arg3: number);
        constructor(arg0: number[], arg1: number, arg2: number, arg3: string);
        constructor(arg0: number[], arg1: number, arg2: number, arg3: $Charset);
        constructor(arg0: number[], arg1: string);
        constructor(arg0: number[], arg1: $Charset);
        constructor(arg0: string[]);
        constructor(arg0: string[], arg1: number, arg2: number);
        constructor(arg0: number[], arg1: number, arg2: number);
        constructor(arg0: string);
        constructor(arg0: $StringBuffer);
        constructor(arg0: $StringBuilder);
        static CASE_INSENSITIVE_ORDER: $Comparator<string>;
        get bytes(): number[];
        getBytes(): number[];
        get blank(): boolean;
        isBlank(): boolean;
        get empty(): boolean;
        isEmpty(): boolean;
        static copyValueOf(arg0: string[], arg1: number, arg2: number): string;
        static copyValueOf(arg0: string[]): string;
        static format(arg0: string, arg1?: unknown[]): string;
        static format(arg0: $Locale, arg1: string, arg2?: unknown[]): string;
        static join(arg0: $CharSequence, arg1?: $CharSequence[]): string;
        static join(arg0: $CharSequence, arg1: ($Iterable<$CharSequence> | ($CharSequence)[])): string;
        static valueOf(arg0: boolean): string;
        static valueOf(arg0: string[], arg1: number, arg2: number): string;
        static valueOf(arg0: string[]): string;
        static valueOf(arg0: string): string;
        static valueOf(arg0: number): string;
        static valueOf(arg0: number): string;
        static valueOf(arg0: number): string;
        static valueOf(arg0: unknown): string;
        static valueOf(arg0: number): string;
        charAt(arg0: number): string;
        chars(): $IntStream;
        codePointAt(arg0: number): number;
        codePointBefore(arg0: number): number;
        codePointCount(arg0: number, arg1: number): number;
        codePoints(): $IntStream;
        compareToIgnoreCase(arg0: string): number;
        compareTo(arg0: string): number;
        concat(arg0: string): string;
        contains(arg0: $CharSequence): boolean;
        contentEquals(arg0: $CharSequence): boolean;
        contentEquals(arg0: $StringBuffer): boolean;
        describeConstable(): $Optional<string>;
        endsWith(arg0: string): boolean;
        equalsIgnoreCase(arg0: string): boolean;
        equals(arg0: unknown): boolean;
        formatted(arg0?: unknown[]): string;
        getBytes(arg0: number, arg1: number, arg2: number[], arg3: number): void;
        getBytes(arg0: string): number[];
        getBytes(arg0: $Charset): number[];
        getChars(arg0: number, arg1: number, arg2: string[], arg3: number): void;
        hashCode(): number;
        indent(arg0: number): string;
        indexOf(arg0: number, arg1: number, arg2: number): number;
        indexOf(arg0: number, arg1: number): number;
        indexOf(arg0: number): number;
        indexOf(arg0: string, arg1: number, arg2: number): number;
        indexOf(arg0: string, arg1: number): number;
        indexOf(arg0: string): number;
        intern(): string;
        lastIndexOf(arg0: number, arg1: number): number;
        lastIndexOf(arg0: number): number;
        lastIndexOf(arg0: string, arg1: number): number;
        lastIndexOf(arg0: string): number;
        length(): number;
        lines(): $Stream<string>;
        matches(arg0: string): boolean;
        offsetByCodePoints(arg0: number, arg1: number): number;
        regionMatches(arg0: boolean, arg1: number, arg2: string, arg3: number, arg4: number): boolean;
        regionMatches(arg0: number, arg1: string, arg2: number, arg3: number): boolean;
        repeat(arg0: number): string;
        replaceAll(arg0: string, arg1: string): string;
        replaceFirst(arg0: string, arg1: string): string;
        replace(arg0: string, arg1: string): string;
        replace(arg0: $CharSequence, arg1: $CharSequence): string;
        resolveConstantDesc(arg0: $MethodHandles$Lookup): string;
        splitWithDelimiters(arg0: string, arg1: number): string[];
        split(arg0: string, arg1: number): string[];
        split(arg0: string): string[];
        startsWith(arg0: string, arg1: number): boolean;
        startsWith(arg0: string): boolean;
        stripIndent(): string;
        stripLeading(): string;
        stripTrailing(): string;
        strip(): string;
        subSequence(arg0: number, arg1: number): $CharSequence;
        substring(arg0: number, arg1: number): string;
        substring(arg0: number): string;
        toCharArray(): string[];
        toLowerCase(arg0: $Locale): string;
        toLowerCase(): string;
        toString(): string;
        toUpperCase(arg0: $Locale): string;
        toUpperCase(): string;
        transform<R>(arg0: $Function_<string, R, string, R>): R;
        translateEscapes(): string;
        trim(): string;
    }

    export class $Class<T> implements $Serializable, $GenericDeclaration, $Type, $AnnotatedElement, $TypeDescriptor$OfField<$Class<any>>, $Constable {
        get annotatedInterfaces(): $AnnotatedType[];
        getAnnotatedInterfaces(): $AnnotatedType[];
        get annotatedSuperclass(): $AnnotatedType;
        getAnnotatedSuperclass(): $AnnotatedType;
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get canonicalName(): string;
        getCanonicalName(): string;
        get classLoader(): $ClassLoader;
        getClassLoader(): $ClassLoader;
        get classes(): $Class<any>[];
        getClasses(): $Class<any>[];
        getComponentType(): $Class<any>;
        get constructors(): $Constructor<any>[];
        getConstructors(): $Constructor<any>[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaredClasses(): $Class<any>[];
        getDeclaredClasses(): $Class<any>[];
        get declaredConstructors(): $Constructor<any>[];
        getDeclaredConstructors(): $Constructor<any>[];
        get declaredFields(): $Field[];
        getDeclaredFields(): $Field[];
        get declaredMethods(): $Method[];
        getDeclaredMethods(): $Method[];
        get declaringClass(): $Class<any>;
        getDeclaringClass(): $Class<any>;
        get enclosingClass(): $Class<any>;
        getEnclosingClass(): $Class<any>;
        get enclosingConstructor(): $Constructor<any>;
        getEnclosingConstructor(): $Constructor<any>;
        get enclosingMethod(): $Method;
        getEnclosingMethod(): $Method;
        get enumConstants(): T[];
        getEnumConstants(): T[];
        get fields(): $Field[];
        getFields(): $Field[];
        get genericInterfaces(): $Type[];
        getGenericInterfaces(): $Type[];
        get genericSuperclass(): $Type;
        getGenericSuperclass(): $Type;
        get interfaces(): $Class<any>[];
        getInterfaces(): $Class<any>[];
        get methods(): $Method[];
        getMethods(): $Method[];
        get modifiers(): number;
        getModifiers(): number;
        get module(): $Module;
        getModule(): $Module;
        get name(): string;
        getName(): string;
        get nestHost(): $Class<any>;
        getNestHost(): $Class<any>;
        get nestMembers(): $Class<any>[];
        getNestMembers(): $Class<any>[];
        get packageName(): string;
        getPackageName(): string;
        get package(): $Package;
        getPackage(): $Package;
        get permittedSubclasses(): $Class<any>[];
        getPermittedSubclasses(): $Class<any>[];
        get protectionDomain(): $ProtectionDomain;
        getProtectionDomain(): $ProtectionDomain;
        get recordComponents(): $RecordComponent[];
        getRecordComponents(): $RecordComponent[];
        get signers(): unknown[];
        getSigners(): unknown[];
        get simpleName(): string;
        getSimpleName(): string;
        get superclass(): $Class<any>;
        getSuperclass(): $Class<any>;
        get typeName(): string;
        getTypeName(): string;
        get typeParameters(): $TypeVariable<$Class<T>>[];
        getTypeParameters(): $TypeVariable<$Class<T>>[];
        get annotation(): boolean;
        isAnnotation(): boolean;
        get anonymousClass(): boolean;
        isAnonymousClass(): boolean;
        get array(): boolean;
        isArray(): boolean;
        get enum(): boolean;
        isEnum(): boolean;
        get hidden(): boolean;
        isHidden(): boolean;
        get interface(): boolean;
        isInterface(): boolean;
        get localClass(): boolean;
        isLocalClass(): boolean;
        get memberClass(): boolean;
        isMemberClass(): boolean;
        get primitive(): boolean;
        isPrimitive(): boolean;
        get record(): boolean;
        isRecord(): boolean;
        get sealed(): boolean;
        isSealed(): boolean;
        get synthetic(): boolean;
        isSynthetic(): boolean;
        get unnamedClass(): boolean;
        isUnnamedClass(): boolean;
        static forName(arg0: $Module, arg1: string): $Class<any>;
        static forName(arg0: string, arg1: boolean, arg2: $ClassLoader): $Class<any>;
        static forName(arg0: string): $Class<any>;
        accessFlags(): $Set<$AccessFlag>;
        arrayType(): $Class<any>;
        asSubclass<U>(arg0: $Class<U>): $Class<U>;
        cast(arg0: unknown): T;
        componentType(): $Class<any>;
        describeConstable(): $Optional<$ClassDesc>;
        descriptorString(): string;
        desiredAssertionStatus(): boolean;
        getAnnotationsByType<A extends $Annotation>(arg0: $Class<A>): A[];
        getAnnotation<A extends $Annotation>(arg0: $Class<A>): A;
        getConstructor(arg0?: $Class<any>[]): $Constructor<T>;
        getDeclaredAnnotationsByType<A extends $Annotation>(arg0: $Class<A>): A[];
        getDeclaredAnnotation<A extends $Annotation>(arg0: $Class<A>): A;
        getDeclaredConstructor(arg0?: $Class<any>[]): $Constructor<T>;
        getDeclaredField(arg0: string): $Field;
        getDeclaredMethod(arg0: string, arg1?: $Class<any>[]): $Method;
        getField(arg0: string): $Field;
        getMethod(arg0: string, arg1?: $Class<any>[]): $Method;
        getResourceAsStream(arg0: string): $InputStream;
        getResource(arg0: string): $URL;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        isAssignableFrom(arg0: $Class<any>): boolean;
        isInstance(arg0: unknown): boolean;
        isNestmateOf(arg0: $Class<any>): boolean;
        newInstance(): T;
        toGenericString(): string;
        toString(): string;
    }

    export interface $Comparable<T> {
        compareTo(arg0: T): number;
    }

    export class $ClassLoader {
        get definedPackages(): $Package[];
        getDefinedPackages(): $Package[];
        get name(): string;
        getName(): string;
        get parent(): $ClassLoader;
        getParent(): $ClassLoader;
        get unnamedModule(): $Module;
        getUnnamedModule(): $Module;
        get registeredAsParallelCapable(): boolean;
        isRegisteredAsParallelCapable(): boolean;
        static getPlatformClassLoader(): $ClassLoader;
        static getSystemClassLoader(): $ClassLoader;
        static getSystemResourceAsStream(arg0: string): $InputStream;
        static getSystemResources(arg0: string): $Enumeration<$URL>;
        static getSystemResource(arg0: string): $URL;
        clearAssertionStatus(): void;
        getDefinedPackage(arg0: string): $Package;
        getResourceAsStream(arg0: string): $InputStream;
        getResources(arg0: string): $Enumeration<$URL>;
        getResource(arg0: string): $URL;
        loadClass(arg0: string): $Class<any>;
        resources(arg0: string): $Stream<$URL>;
        setClassAssertionStatus(arg0: string, arg1: boolean): void;
        setDefaultAssertionStatus(arg0: boolean): void;
        setPackageAssertionStatus(arg0: string, arg1: boolean): void;
    }

    export class $Module implements $AnnotatedElement {
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get classLoader(): $ClassLoader;
        getClassLoader(): $ClassLoader;
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get descriptor(): $ModuleDescriptor;
        getDescriptor(): $ModuleDescriptor;
        get layer(): $ModuleLayer;
        getLayer(): $ModuleLayer;
        get name(): string;
        getName(): string;
        get packages(): $Set<string>;
        getPackages(): $Set<string>;
        get named(): boolean;
        isNamed(): boolean;
        get nativeAccessEnabled(): boolean;
        isNativeAccessEnabled(): boolean;
        addExports(arg0: string, arg1: $Module): $Module;
        addOpens(arg0: string, arg1: $Module): $Module;
        addReads(arg0: $Module): $Module;
        addUses(arg0: $Class<any>): $Module;
        canRead(arg0: $Module): boolean;
        canUse(arg0: $Class<any>): boolean;
        getAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getDeclaredAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getDeclaredAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getResourceAsStream(arg0: string): $InputStream;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        isExported(arg0: string, arg1: $Module): boolean;
        isExported(arg0: string): boolean;
        isOpen(arg0: string, arg1: $Module): boolean;
        isOpen(arg0: string): boolean;
        toString(): string;
    }

    export class $Package extends $NamedPackage implements $AnnotatedElement {
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get implementationTitle(): string;
        getImplementationTitle(): string;
        get implementationVendor(): string;
        getImplementationVendor(): string;
        get implementationVersion(): string;
        getImplementationVersion(): string;
        get name(): string;
        getName(): string;
        get specificationTitle(): string;
        getSpecificationTitle(): string;
        get specificationVendor(): string;
        getSpecificationVendor(): string;
        get specificationVersion(): string;
        getSpecificationVersion(): string;
        get sealed(): boolean;
        isSealed(): boolean;
        static getPackages(): $Package[];
        static getPackage(arg0: string): $Package;
        getAnnotationsByType<A extends $Annotation>(arg0: $Class<A>): A[];
        getAnnotation<A extends $Annotation>(arg0: $Class<A>): A;
        getDeclaredAnnotationsByType<A extends $Annotation>(arg0: $Class<A>): A[];
        getDeclaredAnnotation<A extends $Annotation>(arg0: $Class<A>): A;
        hashCode(): number;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        isCompatibleWith(arg0: string): boolean;
        isSealed(arg0: $URL): boolean;
        toString(): string;
    }

    export interface $AutoCloseable {
        close(): void;
    }

    export interface $CharSequence {
        charAt(arg0: number): string;
        chars(): $IntStream;
        codePoints(): $IntStream;
        isEmpty(): boolean;
        length(): number;
        subSequence(arg0: number, arg1: number): $CharSequence;
        toString(): string;
    }
    export const $CharSequence: {
        compare(arg0: $CharSequence, arg1: $CharSequence): number;
    };

    export class $ModuleLayer {
        static boot(): $ModuleLayer;
        static defineModulesWithManyLoaders(arg0: $Configuration, arg1: ($List<$ModuleLayer> | ($ModuleLayer)[]), arg2: $ClassLoader): $ModuleLayer$Controller;
        static defineModulesWithOneLoader(arg0: $Configuration, arg1: ($List<$ModuleLayer> | ($ModuleLayer)[]), arg2: $ClassLoader): $ModuleLayer$Controller;
        static defineModules(arg0: $Configuration, arg1: ($List<$ModuleLayer> | ($ModuleLayer)[]), arg2: $Function_<string, $ClassLoader, string, $ClassLoader>): $ModuleLayer$Controller;
        static empty(): $ModuleLayer;
        configuration(): $Configuration;
        defineModulesWithManyLoaders(arg0: $Configuration, arg1: $ClassLoader): $ModuleLayer;
        defineModulesWithOneLoader(arg0: $Configuration, arg1: $ClassLoader): $ModuleLayer;
        defineModules(arg0: $Configuration, arg1: $Function_<string, $ClassLoader, string, $ClassLoader>): $ModuleLayer;
        findLoader(arg0: string): $ClassLoader;
        findModule(arg0: string): $Optional<$Module>;
        modules(): $Set<$Module>;
        parents(): $List<$ModuleLayer>;
        toString(): string;
    }

    export class $ModuleLayer$Controller {
        addExports(arg0: $Module, arg1: string, arg2: $Module): $ModuleLayer$Controller;
        addOpens(arg0: $Module, arg1: string, arg2: $Module): $ModuleLayer$Controller;
        addReads(arg0: $Module, arg1: $Module): $ModuleLayer$Controller;
        enableNativeAccess(arg0: $Module): $ModuleLayer$Controller;
        layer(): $ModuleLayer;
    }

    export class $NamedPackage {
    }

    export interface $Iterable<T> {
        forEach(arg0: $Consumer_<T, T>): void;
        iterator(): $Iterator<T>;
        spliterator(): $Spliterator<T>;
    }

    export class $StringBuffer extends $AbstractStringBuilder implements $Appendable, $Serializable, $Comparable<$StringBuffer>, $CharSequence {
        constructor();
        constructor(arg0: number);
        constructor(arg0: $CharSequence);
        constructor(arg0: string);
        get empty(): boolean;
        isEmpty(): boolean;
        appendCodePoint(arg0: number): $StringBuffer;
        append(arg0: boolean): $StringBuffer;
        append(arg0: string[], arg1: number, arg2: number): $StringBuffer;
        append(arg0: string[]): $StringBuffer;
        append(arg0: string): $StringBuffer;
        append(arg0: number): $StringBuffer;
        append(arg0: number): $StringBuffer;
        append(arg0: number): $StringBuffer;
        append(arg0: $CharSequence, arg1: number, arg2: number): $StringBuffer;
        append(arg0: $CharSequence): $StringBuffer;
        append(arg0: unknown): $StringBuffer;
        append(arg0: $StringBuffer): $StringBuffer;
        append(arg0: string): $StringBuffer;
        append(arg0: number): $StringBuffer;
        capacity(): number;
        charAt(arg0: number): string;
        codePointAt(arg0: number): number;
        codePointBefore(arg0: number): number;
        codePointCount(arg0: number, arg1: number): number;
        compareTo(arg0: $StringBuffer): number;
        deleteCharAt(arg0: number): $StringBuffer;
        delete(arg0: number, arg1: number): $StringBuffer;
        ensureCapacity(arg0: number): void;
        getChars(arg0: number, arg1: number, arg2: string[], arg3: number): void;
        indexOf(arg0: string, arg1: number): number;
        indexOf(arg0: string): number;
        insert(arg0: number, arg1: boolean): $StringBuffer;
        insert(arg0: number, arg1: string[], arg2: number, arg3: number): $StringBuffer;
        insert(arg0: number, arg1: string[]): $StringBuffer;
        insert(arg0: number, arg1: string): $StringBuffer;
        insert(arg0: number, arg1: number): $StringBuffer;
        insert(arg0: number, arg1: number): $StringBuffer;
        insert(arg0: number, arg1: number): $StringBuffer;
        insert(arg0: number, arg1: $CharSequence, arg2: number, arg3: number): $StringBuffer;
        insert(arg0: number, arg1: $CharSequence): $StringBuffer;
        insert(arg0: number, arg1: unknown): $StringBuffer;
        insert(arg0: number, arg1: string): $StringBuffer;
        insert(arg0: number, arg1: number): $StringBuffer;
        lastIndexOf(arg0: string, arg1: number): number;
        lastIndexOf(arg0: string): number;
        length(): number;
        offsetByCodePoints(arg0: number, arg1: number): number;
        repeat(arg0: number, arg1: number): $StringBuffer;
        repeat(arg0: $CharSequence, arg1: number): $StringBuffer;
        replace(arg0: number, arg1: number, arg2: string): $StringBuffer;
        reverse(): $StringBuffer;
        setCharAt(arg0: number, arg1: string): void;
        setLength(arg0: number): void;
        subSequence(arg0: number, arg1: number): $CharSequence;
        substring(arg0: number, arg1: number): string;
        substring(arg0: number): string;
        toString(): string;
        trimToSize(): void;
    }

    export class $StringBuilder extends $AbstractStringBuilder implements $Appendable, $Serializable, $Comparable<$StringBuilder>, $CharSequence {
        constructor();
        constructor(arg0: number);
        constructor(arg0: $CharSequence);
        constructor(arg0: string);
        get empty(): boolean;
        isEmpty(): boolean;
        appendCodePoint(arg0: number): $StringBuilder;
        append(arg0: boolean): $StringBuilder;
        append(arg0: string[], arg1: number, arg2: number): $StringBuilder;
        append(arg0: string[]): $StringBuilder;
        append(arg0: string): $StringBuilder;
        append(arg0: number): $StringBuilder;
        append(arg0: number): $StringBuilder;
        append(arg0: number): $StringBuilder;
        append(arg0: $CharSequence, arg1: number, arg2: number): $StringBuilder;
        append(arg0: $CharSequence): $StringBuilder;
        append(arg0: unknown): $StringBuilder;
        append(arg0: $StringBuffer): $StringBuilder;
        append(arg0: string): $StringBuilder;
        append(arg0: number): $StringBuilder;
        compareTo(arg0: $StringBuilder): number;
        deleteCharAt(arg0: number): $StringBuilder;
        delete(arg0: number, arg1: number): $StringBuilder;
        indexOf(arg0: string, arg1: number): number;
        indexOf(arg0: string): number;
        insert(arg0: number, arg1: boolean): $StringBuilder;
        insert(arg0: number, arg1: string[], arg2: number, arg3: number): $StringBuilder;
        insert(arg0: number, arg1: string[]): $StringBuilder;
        insert(arg0: number, arg1: string): $StringBuilder;
        insert(arg0: number, arg1: number): $StringBuilder;
        insert(arg0: number, arg1: number): $StringBuilder;
        insert(arg0: number, arg1: number): $StringBuilder;
        insert(arg0: number, arg1: $CharSequence, arg2: number, arg3: number): $StringBuilder;
        insert(arg0: number, arg1: $CharSequence): $StringBuilder;
        insert(arg0: number, arg1: unknown): $StringBuilder;
        insert(arg0: number, arg1: string): $StringBuilder;
        insert(arg0: number, arg1: number): $StringBuilder;
        lastIndexOf(arg0: string, arg1: number): number;
        lastIndexOf(arg0: string): number;
        repeat(arg0: number, arg1: number): $StringBuilder;
        repeat(arg0: $CharSequence, arg1: number): $StringBuilder;
        replace(arg0: number, arg1: number, arg2: string): $StringBuilder;
        reverse(): $StringBuilder;
        toString(): string;
    }

    export class $AbstractStringBuilder implements $Appendable, $CharSequence {
        get empty(): boolean;
        isEmpty(): boolean;
        appendCodePoint(arg0: number): $AbstractStringBuilder;
        append(arg0: boolean): $AbstractStringBuilder;
        append(arg0: string[], arg1: number, arg2: number): $AbstractStringBuilder;
        append(arg0: string[]): $AbstractStringBuilder;
        append(arg0: string): $AbstractStringBuilder;
        append(arg0: number): $AbstractStringBuilder;
        append(arg0: number): $AbstractStringBuilder;
        append(arg0: number): $AbstractStringBuilder;
        append(arg0: $CharSequence, arg1: number, arg2: number): $AbstractStringBuilder;
        append(arg0: $CharSequence): $AbstractStringBuilder;
        append(arg0: unknown): $AbstractStringBuilder;
        append(arg0: $StringBuffer): $AbstractStringBuilder;
        append(arg0: string): $AbstractStringBuilder;
        append(arg0: number): $AbstractStringBuilder;
        capacity(): number;
        charAt(arg0: number): string;
        chars(): $IntStream;
        codePointAt(arg0: number): number;
        codePointBefore(arg0: number): number;
        codePointCount(arg0: number, arg1: number): number;
        codePoints(): $IntStream;
        deleteCharAt(arg0: number): $AbstractStringBuilder;
        delete(arg0: number, arg1: number): $AbstractStringBuilder;
        ensureCapacity(arg0: number): void;
        getChars(arg0: number, arg1: number, arg2: string[], arg3: number): void;
        indexOf(arg0: string, arg1: number): number;
        indexOf(arg0: string): number;
        insert(arg0: number, arg1: boolean): $AbstractStringBuilder;
        insert(arg0: number, arg1: string[], arg2: number, arg3: number): $AbstractStringBuilder;
        insert(arg0: number, arg1: string[]): $AbstractStringBuilder;
        insert(arg0: number, arg1: string): $AbstractStringBuilder;
        insert(arg0: number, arg1: number): $AbstractStringBuilder;
        insert(arg0: number, arg1: number): $AbstractStringBuilder;
        insert(arg0: number, arg1: number): $AbstractStringBuilder;
        insert(arg0: number, arg1: $CharSequence, arg2: number, arg3: number): $AbstractStringBuilder;
        insert(arg0: number, arg1: $CharSequence): $AbstractStringBuilder;
        insert(arg0: number, arg1: unknown): $AbstractStringBuilder;
        insert(arg0: number, arg1: string): $AbstractStringBuilder;
        insert(arg0: number, arg1: number): $AbstractStringBuilder;
        lastIndexOf(arg0: string, arg1: number): number;
        lastIndexOf(arg0: string): number;
        length(): number;
        offsetByCodePoints(arg0: number, arg1: number): number;
        repeat(arg0: number, arg1: number): $AbstractStringBuilder;
        repeat(arg0: $CharSequence, arg1: number): $AbstractStringBuilder;
        replace(arg0: number, arg1: number, arg2: string): $AbstractStringBuilder;
        reverse(): $AbstractStringBuilder;
        setCharAt(arg0: number, arg1: string): void;
        setLength(arg0: number): void;
        subSequence(arg0: number, arg1: number): $CharSequence;
        substring(arg0: number, arg1: number): string;
        substring(arg0: number): string;
        toString(): string;
        trimToSize(): void;
    }

    export interface $Appendable {
        append(arg0: string): $Appendable;
        append(arg0: $CharSequence, arg1: number, arg2: number): $Appendable;
        append(arg0: $CharSequence): $Appendable;
    }

    export class $Enum<E extends $Enum<E>> implements $Constable, $Comparable<E>, $Serializable {
        get declaringClass(): $Class<E>;
        getDeclaringClass(): $Class<E>;
        static valueOf<T extends $Enum<T>>(arg0: $Class<T>, arg1: string): T;
        compareTo(arg0: E): number;
        describeConstable(): $Optional<$Enum$EnumDesc<E>>;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        name(): string;
        ordinal(): number;
        toString(): string;
    }

    export class $Enum$EnumDesc<E extends $Enum<E>> extends $DynamicConstantDesc<E> {
        static of<E extends $Enum<E>>(arg0: $ClassDesc, arg1: string): $Enum$EnumDesc<E>;
        static of<T>(arg0: $DirectMethodHandleDesc, arg1?: $ConstantDesc_[]): $DynamicConstantDesc<T>;
        static of<T>(arg0: $DirectMethodHandleDesc): $DynamicConstantDesc<T>;
        resolveConstantDesc(arg0: $MethodHandles$Lookup): E;
        toString(): string;
    }

    export interface $Readable {
        read(arg0: $CharBuffer): number;
    }

    export class $Throwable implements $Serializable {
        constructor();
        constructor(arg0: string);
        constructor(arg0: string, arg1: $Throwable);
        constructor(arg0: $Throwable);
        get cause(): $Throwable;
        getCause(): $Throwable;
        get localizedMessage(): string;
        getLocalizedMessage(): string;
        get message(): string;
        getMessage(): string;
        get stackTrace(): $StackTraceElement[];
        getStackTrace(): $StackTraceElement[];
        set stackTrace(value: $StackTraceElement[]);
        get suppressed(): $Throwable[];
        getSuppressed(): $Throwable[];
        addSuppressed(arg0: $Throwable): void;
        fillInStackTrace(): $Throwable;
        initCause(arg0: $Throwable): $Throwable;
        printStackTrace(arg0: $PrintStream): void;
        printStackTrace(arg0: $PrintWriter): void;
        printStackTrace(): void;
        setStackTrace(arg0: $StackTraceElement[]): void;
        toString(): string;
    }

    export class $StackTraceElement implements $Serializable {
        constructor(arg0: string, arg1: string, arg2: string, arg3: number);
        constructor(arg0: string, arg1: string, arg2: string, arg3: string, arg4: string, arg5: string, arg6: number);
        get classLoaderName(): string;
        getClassLoaderName(): string;
        get className(): string;
        getClassName(): string;
        get fileName(): string;
        getFileName(): string;
        get lineNumber(): number;
        getLineNumber(): number;
        get methodName(): string;
        getMethodName(): string;
        get moduleName(): string;
        getModuleName(): string;
        get moduleVersion(): string;
        getModuleVersion(): string;
        get nativeMethod(): boolean;
        isNativeMethod(): boolean;
        equals(arg0: unknown): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $Thread implements $Runnable {
        constructor();
        constructor(arg0: $Runnable_);
        constructor(arg0: $Runnable_, arg1: string);
        constructor(arg0: string);
        constructor(arg0: $ThreadGroup, arg1: $Runnable_);
        constructor(arg0: $ThreadGroup, arg1: $Runnable_, arg2: string);
        constructor(arg0: $ThreadGroup, arg1: $Runnable_, arg2: string, arg3: number);
        constructor(arg0: $ThreadGroup, arg1: $Runnable_, arg2: string, arg3: number, arg4: boolean);
        constructor(arg0: $ThreadGroup, arg1: string);
        static MAX_PRIORITY: number;
        static MIN_PRIORITY: number;
        static NORM_PRIORITY: number;
        get contextClassLoader(): $ClassLoader;
        getContextClassLoader(): $ClassLoader;
        set contextClassLoader(value: $ClassLoader);
        get id(): number;
        getId(): number;
        get name(): string;
        getName(): string;
        set name(value: string);
        get priority(): number;
        getPriority(): number;
        set priority(value: number);
        get stackTrace(): $StackTraceElement[];
        getStackTrace(): $StackTraceElement[];
        get state(): $Thread$State;
        getState(): $Thread$State;
        get threadGroup(): $ThreadGroup;
        getThreadGroup(): $ThreadGroup;
        get uncaughtExceptionHandler(): $Thread$UncaughtExceptionHandler;
        getUncaughtExceptionHandler(): $Thread$UncaughtExceptionHandler;
        set uncaughtExceptionHandler(value: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>);
        get alive(): boolean;
        isAlive(): boolean;
        get daemon(): boolean;
        isDaemon(): boolean;
        set daemon(value: boolean);
        get interrupted(): boolean;
        isInterrupted(): boolean;
        get virtual(): boolean;
        isVirtual(): boolean;
        static activeCount(): number;
        static currentThread(): $Thread;
        static dumpStack(): void;
        static enumerate(arg0: $Thread[]): number;
        static getAllStackTraces(): $Map<$Thread, $StackTraceElement[]>;
        static getDefaultUncaughtExceptionHandler(): $Thread$UncaughtExceptionHandler;
        static holdsLock(arg0: unknown): boolean;
        static interrupted(): boolean;
        static ofPlatform(): $Thread$Builder$OfPlatform;
        static ofVirtual(): $Thread$Builder$OfVirtual;
        static onSpinWait(): void;
        static setDefaultUncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): void;
        static sleep(arg0: $Duration): void;
        static sleep(arg0: number, arg1: number): void;
        static sleep(arg0: number): void;
        static startVirtualThread(arg0: $Runnable_): $Thread;
        static yield(): void;
        checkAccess(): void;
        countStackFrames(): number;
        interrupt(): void;
        join(arg0: $Duration): boolean;
        join(arg0: number, arg1: number): void;
        join(arg0: number): void;
        join(): void;
        resume(): void;
        run(): void;
        setContextClassLoader(arg0: $ClassLoader): void;
        setDaemon(arg0: boolean): void;
        setName(arg0: string): void;
        setPriority(arg0: number): void;
        setUncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): void;
        start(): void;
        stop(): void;
        suspend(): void;
        threadId(): number;
        toString(): string;
    }

    export interface $Runnable {
        run(): void;
    }

    export interface $Thread$Builder$OfPlatform extends $Thread$Builder {
        daemon(arg0: boolean): $Thread$Builder$OfPlatform;
        daemon(): $Thread$Builder$OfPlatform;
        group(arg0: $ThreadGroup): $Thread$Builder$OfPlatform;
        inheritInheritableThreadLocals(arg0: boolean): $Thread$Builder$OfPlatform;
        name(arg0: string, arg1: number): $Thread$Builder$OfPlatform;
        name(arg0: string): $Thread$Builder$OfPlatform;
        priority(arg0: number): $Thread$Builder$OfPlatform;
        stackSize(arg0: number): $Thread$Builder$OfPlatform;
        uncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): $Thread$Builder$OfPlatform;
    }

    export interface $Thread$Builder$OfVirtual extends $Thread$Builder {
        inheritInheritableThreadLocals(arg0: boolean): $Thread$Builder$OfVirtual;
        name(arg0: string, arg1: number): $Thread$Builder$OfVirtual;
        name(arg0: string): $Thread$Builder$OfVirtual;
        uncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): $Thread$Builder$OfVirtual;
    }

    export class $Thread$State {
        static BLOCKED: $Thread$State;
        static NEW: $Thread$State;
        static RUNNABLE: $Thread$State;
        static TERMINATED: $Thread$State;
        static TIMED_WAITING: $Thread$State;
        static WAITING: $Thread$State;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Thread$State[];
        static valueOf(name: string): $Thread$State;
    }
    export interface $Thread$State extends $Enum<$Thread$State> {}

    export interface $Thread$UncaughtExceptionHandler {
        uncaughtException(arg0: $Thread, arg1: $Throwable): void;
    }

    export class $ThreadGroup implements $Thread$UncaughtExceptionHandler {
        constructor(arg0: string);
        constructor(arg0: $ThreadGroup, arg1: string);
        get maxPriority(): number;
        getMaxPriority(): number;
        set maxPriority(value: number);
        get name(): string;
        getName(): string;
        get parent(): $ThreadGroup;
        getParent(): $ThreadGroup;
        get daemon(): boolean;
        isDaemon(): boolean;
        set daemon(value: boolean);
        get destroyed(): boolean;
        isDestroyed(): boolean;
        activeCount(): number;
        activeGroupCount(): number;
        checkAccess(): void;
        destroy(): void;
        enumerate(arg0: $ThreadGroup[], arg1: boolean): number;
        enumerate(arg0: $ThreadGroup[]): number;
        enumerate(arg0: $Thread[], arg1: boolean): number;
        enumerate(arg0: $Thread[]): number;
        interrupt(): void;
        list(): void;
        parentOf(arg0: $ThreadGroup): boolean;
        resume(): void;
        setDaemon(arg0: boolean): void;
        setMaxPriority(arg0: number): void;
        stop(): void;
        suspend(): void;
        toString(): string;
        uncaughtException(arg0: $Thread, arg1: $Throwable): void;
    }

    export interface $Thread$Builder {
        factory(): $ThreadFactory;
        inheritInheritableThreadLocals(arg0: boolean): $Thread$Builder;
        name(arg0: string, arg1: number): $Thread$Builder;
        name(arg0: string): $Thread$Builder;
        start(arg0: $Runnable_): $Thread;
        uncaughtExceptionHandler(arg0: $Thread$UncaughtExceptionHandler_<$Thread, $Throwable>): $Thread$Builder;
        unstarted(arg0: $Runnable_): $Thread;
    }

    export interface $Cloneable {
    }

    export type $Comparable_<Host0 = any, CallbackArg0 = Host0, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Comparable<Host0> & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "compareTo": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $AutoCloseable_ = (() => void) | ($AutoCloseable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "close": () => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Iterable_<T> = ($Iterable<T> | (T)[]);
    export type $Readable_<CallbackArg0 = $CharBuffer, CallbackResult = number> = ((arg0: CallbackArg0) => CallbackResult) | ($Readable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "read": (arg0: CallbackArg0) => CallbackResult } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Runnable_ = (() => void) | ($Runnable & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "run": () => void } & { readonly [Symbol.hasInstance]?: never }>);
    export type $Thread$State_ = $Thread$State | "BLOCKED" | "NEW" | "RUNNABLE" | "TERMINATED" | "TIMED_WAITING" | "WAITING";
    export type $Thread$UncaughtExceptionHandler_<CallbackArg0 = $Thread, CallbackArg1 = $Throwable> = ((arg0: CallbackArg0, arg1: CallbackArg1) => void) | ($Thread$UncaughtExceptionHandler & { readonly [Symbol.hasInstance]?: never }) | (globalThis.NoInfer<{ readonly "uncaughtException": (arg0: CallbackArg0, arg1: CallbackArg1) => void } & { readonly [Symbol.hasInstance]?: never }>);
}
