import { $ConstantDesc, $ConstantDesc_ } from "java:java/lang/constant";
import { $List, $Optional, $OptionalView } from "java:java/util";
import { $Consumer, $Consumer_, $Supplier, $Supplier_ } from "java:java/util/function";

declare module "java:com/tkisor/nekojs/probe" {
    export class $ProbeConstableValueProjectionTest$Calls {
        constructor();
        static acceptAll(values: $ConstantDesc_[]): number;
        static acceptDescriptions(values: ($List<(number | string | $ConstantDesc)> | ($ConstantDesc_)[])): number;
        static acceptDescription(value: $ConstantDesc_): string;
        static acceptFactory(value: $Supplier_<$Supplier<(number | string | $ConstantDesc)>, $Supplier_<(number | string | $ConstantDesc), $ConstantDesc_>>): (number | string | $ConstantDesc);
        static acceptSupplier(value: $Supplier_<(number | string | $ConstantDesc), $ConstantDesc_>): (number | string | $ConstantDesc);
        static acceptVarargs(values?: $ConstantDesc_[]): number;
        static classDescription(): (number | string | $ConstantDesc);
        static consume(consumer: $Consumer_<(number | string | $ConstantDesc), (number | string | $ConstantDesc)>): void;
        static descriptions(): (number | string | $ConstantDesc)[];
        static directDescription(): (number | string | $ConstantDesc);
        static doubleDescription(): $OptionalView<(number | string | $ConstantDesc)>;
        static explicitArray(): (number | string | $ConstantDesc)[];
        static explicitVarargs(values?: $ConstantDesc_[]): number;
        static integerDescription(): $OptionalView<(number | string | $ConstantDesc)>;
        static stringDescription(): $OptionalView<(number | string | $ConstantDesc)>;
    }

    export class $ProbeConstableValueProjectionTest$VarargsConstructor {
        constructor(values?: $ConstantDesc_[]);
        count: number;
    }

}
