import { $Class, $Enum } from "java:java/lang";
import { $Annotation, $Annotation_ } from "java:java/lang/annotation";
import { $Set } from "java:java/util";

declare module "java:java/lang/reflect" {
    export class $AccessFlag {
        static ABSTRACT: $AccessFlag;
        static ANNOTATION: $AccessFlag;
        static BRIDGE: $AccessFlag;
        static ENUM: $AccessFlag;
        static FINAL: $AccessFlag;
        static INTERFACE: $AccessFlag;
        static MANDATED: $AccessFlag;
        static MODULE: $AccessFlag;
        static NATIVE: $AccessFlag;
        static OPEN: $AccessFlag;
        static PRIVATE: $AccessFlag;
        static PROTECTED: $AccessFlag;
        static PUBLIC: $AccessFlag;
        static STATIC: $AccessFlag;
        static STATIC_PHASE: $AccessFlag;
        static STRICT: $AccessFlag;
        static SUPER: $AccessFlag;
        static SYNCHRONIZED: $AccessFlag;
        static SYNTHETIC: $AccessFlag;
        static TRANSIENT: $AccessFlag;
        static TRANSITIVE: $AccessFlag;
        static VARARGS: $AccessFlag;
        static VOLATILE: $AccessFlag;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AccessFlag[];
        static valueOf(name: string): $AccessFlag;
    }
    export interface $AccessFlag extends $Enum<$AccessFlag> {}

    export interface $AnnotatedElement {
        getAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getAnnotations(): $Annotation[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getDeclaredAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getDeclaredAnnotations(): $Annotation[];
        getDeclaredAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
    }

    export interface $AnnotatedType extends $AnnotatedElement {
        getAnnotatedOwnerType(): $AnnotatedType;
        getAnnotations(): $Annotation[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getDeclaredAnnotations(): $Annotation[];
        getType(): $Type;
    }

    export class $Constructor<T> extends $Executable {
        get annotatedReceiverType(): $AnnotatedType;
        getAnnotatedReceiverType(): $AnnotatedType;
        get annotatedReturnType(): $AnnotatedType;
        getAnnotatedReturnType(): $AnnotatedType;
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaringClass(): $Class<T>;
        getDeclaringClass(): $Class<T>;
        get exceptionTypes(): $Class<any>[];
        getExceptionTypes(): $Class<any>[];
        get genericExceptionTypes(): $Type[];
        getGenericExceptionTypes(): $Type[];
        get genericParameterTypes(): $Type[];
        getGenericParameterTypes(): $Type[];
        get modifiers(): number;
        getModifiers(): number;
        get name(): string;
        getName(): string;
        get parameterAnnotations(): $Annotation[][];
        getParameterAnnotations(): $Annotation[][];
        get parameterCount(): number;
        getParameterCount(): number;
        get parameterTypes(): $Class<any>[];
        getParameterTypes(): $Class<any>[];
        get typeParameters(): $TypeVariable<$Constructor<T>>[];
        getTypeParameters(): $TypeVariable<$Constructor<T>>[];
        get synthetic(): boolean;
        isSynthetic(): boolean;
        get varArgs(): boolean;
        isVarArgs(): boolean;
        equals(arg0: unknown): boolean;
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        hashCode(): number;
        newInstance(arg0?: unknown[]): T;
        setAccessible(arg0: boolean): void;
        toGenericString(): string;
        toString(): string;
    }

    export class $Field extends $AccessibleObject implements $Member {
        get annotatedType(): $AnnotatedType;
        getAnnotatedType(): $AnnotatedType;
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaringClass(): $Class<any>;
        getDeclaringClass(): $Class<any>;
        get genericType(): $Type;
        getGenericType(): $Type;
        get modifiers(): number;
        getModifiers(): number;
        get name(): string;
        getName(): string;
        get type(): $Class<any>;
        getType(): $Class<any>;
        get enumConstant(): boolean;
        isEnumConstant(): boolean;
        get synthetic(): boolean;
        isSynthetic(): boolean;
        accessFlags(): $Set<$AccessFlag>;
        equals(arg0: unknown): boolean;
        getAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getBoolean(arg0: unknown): boolean;
        getByte(arg0: unknown): number;
        getChar(arg0: unknown): string;
        getDouble(arg0: unknown): number;
        getFloat(arg0: unknown): number;
        getInt(arg0: unknown): number;
        getLong(arg0: unknown): number;
        getShort(arg0: unknown): number;
        get(arg0: unknown): unknown;
        hashCode(): number;
        setAccessible(arg0: boolean): void;
        setBoolean(arg0: unknown, arg1: boolean): void;
        setByte(arg0: unknown, arg1: number): void;
        setChar(arg0: unknown, arg1: string): void;
        setDouble(arg0: unknown, arg1: number): void;
        setFloat(arg0: unknown, arg1: number): void;
        setInt(arg0: unknown, arg1: number): void;
        setLong(arg0: unknown, arg1: number): void;
        setShort(arg0: unknown, arg1: number): void;
        set(arg0: unknown, arg1: unknown): void;
        toGenericString(): string;
        toString(): string;
    }

    export interface $GenericDeclaration extends $AnnotatedElement {
        getTypeParameters(): $TypeVariable<any>[];
    }

    export class $Method extends $Executable {
        get annotatedReturnType(): $AnnotatedType;
        getAnnotatedReturnType(): $AnnotatedType;
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaringClass(): $Class<any>;
        getDeclaringClass(): $Class<any>;
        get defaultValue(): unknown;
        getDefaultValue(): unknown;
        get exceptionTypes(): $Class<any>[];
        getExceptionTypes(): $Class<any>[];
        get genericExceptionTypes(): $Type[];
        getGenericExceptionTypes(): $Type[];
        get genericParameterTypes(): $Type[];
        getGenericParameterTypes(): $Type[];
        get genericReturnType(): $Type;
        getGenericReturnType(): $Type;
        get modifiers(): number;
        getModifiers(): number;
        get name(): string;
        getName(): string;
        get parameterAnnotations(): $Annotation[][];
        getParameterAnnotations(): $Annotation[][];
        get parameterCount(): number;
        getParameterCount(): number;
        get parameterTypes(): $Class<any>[];
        getParameterTypes(): $Class<any>[];
        get returnType(): $Class<any>;
        getReturnType(): $Class<any>;
        get typeParameters(): $TypeVariable<$Method>[];
        getTypeParameters(): $TypeVariable<$Method>[];
        get bridge(): boolean;
        isBridge(): boolean;
        get default(): boolean;
        isDefault(): boolean;
        get synthetic(): boolean;
        isSynthetic(): boolean;
        get varArgs(): boolean;
        isVarArgs(): boolean;
        equals(arg0: unknown): boolean;
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        hashCode(): number;
        invoke(arg0: unknown, arg1?: unknown[]): unknown;
        setAccessible(arg0: boolean): void;
        toGenericString(): string;
        toString(): string;
    }

    export class $RecordComponent implements $AnnotatedElement {
        get accessor(): $Method;
        getAccessor(): $Method;
        get annotatedType(): $AnnotatedType;
        getAnnotatedType(): $AnnotatedType;
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaringRecord(): $Class<any>;
        getDeclaringRecord(): $Class<any>;
        get genericSignature(): string;
        getGenericSignature(): string;
        get genericType(): $Type;
        getGenericType(): $Type;
        get name(): string;
        getName(): string;
        get type(): $Class<any>;
        getType(): $Class<any>;
        getAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getDeclaredAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getDeclaredAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        toString(): string;
    }

    export interface $Type {
        getTypeName(): string;
    }

    export interface $TypeVariable<D extends $GenericDeclaration> extends $Type, $AnnotatedElement {
        getAnnotatedBounds(): $AnnotatedType[];
        getBounds(): $Type[];
        getGenericDeclaration(): D;
        getName(): string;
    }

    export interface $Member {
        accessFlags(): $Set<$AccessFlag>;
        getDeclaringClass(): $Class<any>;
        getModifiers(): number;
        getName(): string;
        isSynthetic(): boolean;
    }
    export const $Member: {
        readonly DECLARED: number;
        readonly PUBLIC: number;
    };

    export class $Executable extends $AccessibleObject implements $Member, $GenericDeclaration {
        get annotatedExceptionTypes(): $AnnotatedType[];
        getAnnotatedExceptionTypes(): $AnnotatedType[];
        get annotatedParameterTypes(): $AnnotatedType[];
        getAnnotatedParameterTypes(): $AnnotatedType[];
        get annotatedReceiverType(): $AnnotatedType;
        getAnnotatedReceiverType(): $AnnotatedType;
        get annotatedReturnType(): $AnnotatedType;
        getAnnotatedReturnType(): $AnnotatedType;
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaringClass(): $Class<any>;
        getDeclaringClass(): $Class<any>;
        get exceptionTypes(): $Class<any>[];
        getExceptionTypes(): $Class<any>[];
        get genericExceptionTypes(): $Type[];
        getGenericExceptionTypes(): $Type[];
        get genericParameterTypes(): $Type[];
        getGenericParameterTypes(): $Type[];
        get modifiers(): number;
        getModifiers(): number;
        get name(): string;
        getName(): string;
        get parameterAnnotations(): $Annotation[][];
        getParameterAnnotations(): $Annotation[][];
        get parameterCount(): number;
        getParameterCount(): number;
        get parameterTypes(): $Class<any>[];
        getParameterTypes(): $Class<any>[];
        get parameters(): $Parameter[];
        getParameters(): $Parameter[];
        get typeParameters(): $TypeVariable<any>[];
        getTypeParameters(): $TypeVariable<any>[];
        get synthetic(): boolean;
        isSynthetic(): boolean;
        get varArgs(): boolean;
        isVarArgs(): boolean;
        accessFlags(): $Set<$AccessFlag>;
        getAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getDeclaredAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getDeclaredAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        toGenericString(): string;
    }

    export class $AccessibleObject implements $AnnotatedElement {
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get accessible(): boolean;
        isAccessible(): boolean;
        set accessible(value: boolean);
        static setAccessible(arg0: $AccessibleObject[], arg1: boolean): void;
        canAccess(arg0: unknown): boolean;
        getAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getDeclaredAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getDeclaredAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        setAccessible(arg0: boolean): void;
        trySetAccessible(): boolean;
    }

    export class $Parameter implements $AnnotatedElement {
        get annotatedType(): $AnnotatedType;
        getAnnotatedType(): $AnnotatedType;
        get annotations(): $Annotation[];
        getAnnotations(): $Annotation[];
        get declaredAnnotations(): $Annotation[];
        getDeclaredAnnotations(): $Annotation[];
        get declaringExecutable(): $Executable;
        getDeclaringExecutable(): $Executable;
        get modifiers(): number;
        getModifiers(): number;
        get name(): string;
        getName(): string;
        get parameterizedType(): $Type;
        getParameterizedType(): $Type;
        get type(): $Class<any>;
        getType(): $Class<any>;
        get implicit(): boolean;
        isImplicit(): boolean;
        get namePresent(): boolean;
        isNamePresent(): boolean;
        get synthetic(): boolean;
        isSynthetic(): boolean;
        get varArgs(): boolean;
        isVarArgs(): boolean;
        accessFlags(): $Set<$AccessFlag>;
        equals(arg0: unknown): boolean;
        getAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        getDeclaredAnnotationsByType<T extends $Annotation>(arg0: $Class<T>): T[];
        getDeclaredAnnotation<T extends $Annotation>(arg0: $Class<T>): T;
        hashCode(): number;
        isAnnotationPresent(arg0: $Class<$Annotation>): boolean;
        toString(): string;
    }

    export type $AccessFlag_ = $AccessFlag | "ABSTRACT" | "ANNOTATION" | "BRIDGE" | "ENUM" | "FINAL" | "INTERFACE" | "MANDATED" | "MODULE" | "NATIVE" | "OPEN" | "PRIVATE" | "PROTECTED" | "PUBLIC" | "STATIC" | "STATIC_PHASE" | "STRICT" | "SUPER" | "SYNCHRONIZED" | "SYNTHETIC" | "TRANSIENT" | "TRANSITIVE" | "VARARGS" | "VOLATILE";
}
