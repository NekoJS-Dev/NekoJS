import { $ConstantDesc, $ConstantDesc_ } from "java:java/lang/constant";
import { $MethodHandles$Lookup } from "java:java/lang/invoke";
import { $List, $Optional, $OptionalView } from "java:java/util";
import { $Consumer, $Consumer_, $Supplier, $Supplier_ } from "java:java/util/function";

declare module "java:com/tkisor/nekojs/probe" {
    export class $ProbeConstableValueProjectionTest$Calls {
        constructor();
        static acceptAll(values: (number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)[]): number;
        static acceptDescriptions(values: ($List<(number | string | $ConstantDesc)> | ((number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>))[])): number;
        static acceptDescription(value: (number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)): string;
        static acceptFactory(value: $Supplier_<$Supplier<(number | string | $ConstantDesc)>, $Supplier_<(number | string | $ConstantDesc), (number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)>>): (number | string | $ConstantDesc);
        static acceptSupplier(value: $Supplier_<(number | string | $ConstantDesc), (number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)>): (number | string | $ConstantDesc);
        static acceptVarargs(values?: (number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)[]): number;
        static classDescription(): (number | string | $ConstantDesc);
        static consume(consumer: $Consumer_<(number | string | $ConstantDesc), (number | string | $ConstantDesc)>): void;
        static descriptions(): (number | string | $ConstantDesc)[];
        static directDescription(): (number | string | $ConstantDesc);
        static doubleDescription(): $OptionalView<(number | string | $ConstantDesc)>;
        static explicitArray(): (number | string | $ConstantDesc)[];
        static explicitVarargs(values?: (number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)[]): number;
        static integerDescription(): $OptionalView<(number | string | $ConstantDesc)>;
        static stringDescription(): $OptionalView<(number | string | $ConstantDesc)>;
    }

    export class $ProbeConstableValueProjectionTest$VarargsConstructor {
        constructor(values?: (number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)[]);
        count: number;
    }

}
