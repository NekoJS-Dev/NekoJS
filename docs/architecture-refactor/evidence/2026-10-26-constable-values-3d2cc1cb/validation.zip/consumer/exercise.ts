import { $ProbeConstableValueProjectionTest$Calls as Calls } from 'java:com/tkisor/nekojs/probe';
import { $ProbeConstableValueProjectionTest$VarargsConstructor as Constructor } from 'java:com/tkisor/nekojs/probe';
import type { $ConstantDesc } from 'java:java/lang/constant';
const direct: number | string | $ConstantDesc = Calls.directDescription();
const captured: number | string | $ConstantDesc = Calls.doubleDescription().get();
Calls.acceptDescription(1.5);
Calls.acceptDescription('value');
declare const host: $ConstantDesc;
Calls.acceptDescription(host);
const array: (number | string | $ConstantDesc)[] = Calls.descriptions();
Calls.acceptAll([1.5, 'value', host]);
Calls.acceptVarargs();
Calls.acceptVarargs([1.5, 'value', host]);
new Constructor([1.5, 'value', host]);
// @ts-expect-error Constructor-local bounds keep the same scalar/host input domain.
new Constructor([true]);
// @ts-expect-error The varargs array keeps the actual element domain.
Calls.acceptVarargs([true]);
// @ts-expect-error Array elements keep the same actual value domain.
Calls.acceptAll([true]);
// @ts-expect-error Booleans are not constant descriptions.
Calls.acceptDescription(true);
// @ts-expect-error A projected scalar does not expose Java ConstantDesc methods.
Calls.doubleDescription().get().resolveConstantDesc;
// @ts-expect-error The result can also be a genuine non-scalar description.
const scalarOnly: number = Calls.directDescription();
