from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile

root = Path('common/src/test/resources/nekojs/probe/legacy-tree')
changes = []
with ZipFile('build/constable-value-goldens-before.zip') as before:
    assert set(before.namelist()) == {p.as_posix() for p in root.rglob('*') if p.is_file()}
    for name in before.namelist():
        old, new = before.read(name), Path(name).read_bytes()
        if old == new:
            continue
        old_lines, new_lines = old.decode().splitlines(), new.decode().splitlines()
        assert len(old_lines) == len(new_lines), name
        lines = []
        for number, (a, b) in enumerate(zip(old_lines, new_lines), 1):
            if a == b:
                continue
            expected = a.replace('$ConstantDesc_<$MethodHandles$Lookup, unknown>',
                                 '(number | string | $ConstantDesc_<$MethodHandles$Lookup, unknown>)')
            expected = re.sub(r'\$ConstantDesc(?![\w$])', '(number | string | $ConstantDesc)', expected)
            assert b == expected, (name, number, a, b, expected)
            lines.append({'line': number, 'before': a, 'after': b})
        changes.append({'file': name, 'beforeSha256': sha256(old).hexdigest(),
                        'afterSha256': sha256(new).hexdigest(), 'lines': lines})
assert len(changes) == 2 and sum(len(c['lines']) for c in changes) == 8
report = {'changedFiles': 2, 'changedValueLines': 8, 'allOtherLinesAndMembersRetained': True, 'changes': changes}
Path('build/constable-value-golden-delta.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print('PASS: 2 files / 8 value lines; all other lines, members, aliases and heritage retained')
