# Current d109 installed IDE acceptance

Five exact current official artifacts, original owned STARTUP/SERVER fixtures,
fresh dedicated worlds and cached loader installations. Runtime registration,
place/reload/effect probes, actual Probe generation, all Python AST, whole
default editor includes TypeScript with only skipLibCheck=false and noEmit,
Pyright all real stubs. Retain diagnostics without editing generated outputs.
Every server stops by owned RCON with direct exits. No formal performance or
client/all-domain/human/release conclusion inferred from these checks.
