
import { $Optional } from 'java:java/util';
import type {
    $ProbeWildcardOptionalCaptureTest$ConstableLike as Parent,
    $ProbeWildcardOptionalCaptureTest$ConstDesc as Bound,
    $ProbeWildcardOptionalCaptureTest$DynamicDesc as Narrow,
    $ProbeWildcardOptionalCaptureTest$BooleanLike as Implementation
} from 'java:com/tkisor/nekojs/probe';
declare const implementation: Implementation;
const parent: Parent = implementation;
const result = parent.describeConstable();
const upper: Bound = result.get();
const narrow: Narrow = implementation.describeConstable().get();
// @ts-expect-error The upper bound does not expose narrow members.
upper.code;
// @ts-expect-error The value kind remains checked.
const wrong: string = result.get();

const fallback: Bound = result.or(() => $Optional.empty()).get();
declare const genericHost: { get: <C extends Bound>() => $Optional<C> };
const fromHost: Bound = result.or(genericHost).get();
// @ts-expect-error An unrelated supplier payload remains rejected.
result.or(() => $Optional.of('wrong'));

const reduced: Bound = result.stream().reduce((left, right) => left).get();
// @ts-expect-error An unrelated reducer result remains rejected.
result.stream().reduce((left, right) => 'wrong');

const list = result.stream().toList();
const item: Bound = list.get(0);
const nested: Bound = list.reversed().subList(0, 1).get(0);
const iterated: Bound = list.listIterator().next();
list.replaceAll(value => value);
list.add(upper);
list.addAll([]);
// @ts-expect-error An unrelated element kind remains rejected.
list.add('wrong');
// @ts-expect-error A callback cannot produce an unrelated element kind.
list.replaceAll(value => 'wrong');
// @ts-expect-error Upper-bound reads do not gain narrow members.
list.get(0).code;

import { $UnaryOperator, $BinaryOperator } from 'java:java/util/function';
list.replaceAll($UnaryOperator.identity());
const hostReduced: Bound = result.stream().reduce($BinaryOperator.maxBy((left: Bound, right: Bound) => 0)).get();

const identity = $UnaryOperator.identity<Bound>();
// @ts-expect-error A generic identity does not fabricate a narrow result from a broad value.
const invented: Narrow = identity.apply(upper);
// @ts-expect-error An explicit generic argument must still admit the actual operand.
identity.apply<Narrow>(upper);
// @ts-expect-error A different element kind cannot provide the captured operator.
list.replaceAll($UnaryOperator.identity<string>());
declare const wrongDomain: <C extends string>(value: C) => C;
// @ts-expect-error A callback's quantified domain must admit the capture bound.
list.replaceAll(wrongDomain);
