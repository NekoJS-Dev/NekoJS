
import { $Optional } from 'java:java/util';
import type {
    $ProbeWildcardOptionalCaptureTest$ConstableLike as Parent,
    $ProbeWildcardOptionalCaptureTest$ConstDesc as Bound,
    $ProbeWildcardOptionalCaptureTest$DynamicDesc as Narrow,
    $ProbeWildcardOptionalCaptureTest$BooleanLike as Implementation
} from 'java:com/tkisor/nekojs/probe';
declare const implementation: Implementation;
const parent: Parent = implementation;
const result = parent.describeConstable();
const upper: Bound = result.get();
const narrow: Narrow = implementation.describeConstable().get();
// @ts-expect-error The upper bound does not expose narrow members.
upper.code;
// @ts-expect-error The value kind remains checked.
const wrong: string = result.get();
