import hashlib
import json
import re
import socket
import subprocess
import zipfile
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/ticket37-native-pair-d109'
destination = project / 'docs/architecture-refactor/evidence/ticket37-native-focus-d109'
assert not destination.exists()
destination.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {}
def add(path, name):
    assert name not in entries
    entries[name] = path.read_bytes()

for name in ('preparation.json', 'PAIR-PLAN.md', 'PLAN.md', 'LIFECYCLE-PLAN.md', 'rcon.jsonl', 'glfw-crash-disassembly.txt'):
    add(root / name, 'runtime/' + name)
for node in ('server', 'clientA', 'clientB'):
    for name in ('stdout.log', 'stderr.log', 'exit.json', 'owned-process.json'):
        add(root / node / name, 'runtime/' + node + '/' + name)
    if node != 'server':
        add(root / node / 'nekojs/client_scripts/visual-proof.js', 'runtime/' + node + '/visual-proof.js')
add(root / 'clientB/close-probe.json', 'runtime/clientB/close-probe.json')
minimal = ('minimal-glfw', 'minimal-no-api', 'minimal-pointer-pair', 'minimal-pointer-single')
crashes = []
for name in minimal:
    add(root / name / 'inputs.json', 'runtime/' + name + '/inputs.json')
    for directory in sorted((root / name).glob('[AB]')):
        for filename in ('stdout.log', 'stderr.log', 'exit.json', 'owned-process.json'):
            add(directory / filename, 'runtime/' + name + '/' + directory.name + '/' + filename)
for path in sorted(root.rglob('hs_err_pid*.log')):
    text = path.read_text(encoding='utf-8')
    a = text.index('Current thread')
    b = text.index('Registers:')
    end = text.index('XMM[0]', b)
    extracted = text[a:end]
    relative = str(path.relative_to(root)).replace('\\', '/')
    entries['runtime/' + relative + '.signal.txt'] = extracted.encode('utf-8')
    crashes.append(dict(file=relative, bytes=path.stat().st_size, sha256=sha(path.read_bytes()),
                        problematicFrame=re.search(r'C  \[glfw.dll\+0x[0-9a-f]+\]', text).group(0)))
add(root / 'minimal-pointer-pair/pointer-proof.json', 'runtime/pointer-proof.json')
helpers = project / 'build/ticket37-config-sync-repair'
names = ('prepare-native-pair-d109.py', 'prepare-pair-profiles-d109.py', 'run-native-pair-d109.py',
         'rcon-native-pair-d109.py', 'signal-native-pair-d109.py', 'close-native-pair-d109.py',
         'prepare-pair-close-d109.py', 'setup-pair-scene-d109.py', 'NativeFocusProbe.java',
         'NativeFocusNoApiProbe.java', 'NativePointerProbe.java', 'run-native-focus-probe.py',
         'run-native-noapi-probe.py', 'run-native-pointer-probe.py', 'run-native-single-probe.py',
         'prepare-native-pointer-control.py', 'archive-native-focus-d109.py')
for name in names:
    add(helpers / name, 'helpers/' + name)
properties = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines() if '=' in line)
secret = properties['rcon.password'].encode()
for name, data in entries.items():
    assert secret not in data, name
for port in (25983, 25984):
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
artifact_sha = 'fde6c16ba1b6fbca43dfc87aff4bf9709c1925bcb2d72c307f2e73346922f092'
copies = {}
for node in ('server', 'clientA', 'clientB'):
    jar = root / node / 'mods/nekojs-neoforge-26.2.0-1.1.0-preview3.jar'
    copies[node] = sha(jar.read_bytes())
    assert copies[node] == artifact_sha
proof = json.loads((root / 'minimal-pointer-pair/pointer-proof.json').read_text())
assert proof['foreignPointerEqualsRbx'] and proof['readOffset'] == '0x1f0'
assert len(crashes) == 4 and all(row['problematicFrame'] == 'C  [glfw.dll+0x10fa1]' for row in crashes)
for name in ('minimal-glfw', 'minimal-no-api', 'minimal-pointer-pair'):
    assert json.loads((root / name / 'A/exit.json').read_text())['exitCode'] == 1
    assert json.loads((root / name / 'B/exit.json').read_text())['exitCode'] == 0
assert json.loads((root / 'minimal-pointer-single/A/exit.json').read_text())['exitCode'] == 0
summary = dict(checkoutRevision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    productionRevision='d10912ebbf24d9d5df75a908dc7a5529da09979a', artifactCopies=copies,
    concurrentMinecraft='FAIL: A crashed during Sky activation before bounded cycles, screenshots or reload',
    configurationCatchUp='PASS: two real clients synchronized generation2 and joined',
    minimalOpenGl='RED: exact DLL +0x10fa1 without Minecraft/Graal/NekoJS/bridge',
    minimalNoApiNoCallbacks='RED: exact DLL +0x10fa1 without OpenGL or callbacks',
    pointerControl=proof, singleProcess='PASS: three observed Sky activations and direct exit0',
    retainedRawCrashHashes=crashes, glfwVersion='3.5.0 Win32 WGL Null EGL OSMesa VisualC DLL',
    nativeRepair='NOT_APPLIED: third-party DLL and Sky helper unchanged',
    currentMultiplayerReload='NOT_RUN', firstPixel='NOT_VERIFIED', allNodeVisual='NOT_RUN',
    ownedProcesses='ALL_ENDED', portsFree=[25983,25984], humanAcceptance='NOT_RECORDED', overall='NOT_COMPLETE')
(destination / 'runtime-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
archive = destination / 'native-focus-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(entries.items()):
        output.writestr(name, data)
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
    entries=[dict(name=name, bytes=len(data), sha256=sha(data)) for name,data in sorted(entries.items())],
    exclusions=['raw hs_err', 'credentials/server.properties', 'worlds', 'launcher argfiles',
                'binary artifacts/libraries/native DLLs', 'unrelated user files/screenshots'])
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as original:
    assert original.testzip() is None
    for row in manifest['entries']:
        assert sha(original.read(row['name'])) == row['sha256']
print(json.dumps(dict(entries=len(entries), bytes=manifest['bytes'], sha256=manifest['sha256'], result='PASS')))
