import hashlib
import json
import subprocess
import sys
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/ticket37-native-pair-d109/minimal-no-api'
java_dir = Path('C:/Program Files/Java/jdk-25.0.2/bin')
libraries = project / 'build/ticket37-config-sync-installed-attempt1/launcherA/.minecraft/libraries/org/lwjgl'
native = project / 'build/ticket37-native-pair-d109/clientA/owned-natives/lwjgl'
jars = [libraries / name / '3.4.1' / (name + '-3.4.1.jar') for name in ('lwjgl', 'lwjgl-glfw', 'lwjgl-opengl')]
assert all(path.is_file() for path in jars)
mode = sys.argv[1]
if mode == 'prepare':
    assert not root.exists()
    root.mkdir()
    source = project / 'build/ticket37-config-sync-repair/NativeFocusNoApiProbe.java'
    subprocess.run([str(java_dir / 'javac.exe'), '-cp', ';'.join(map(str, jars)), '-d', str(root), str(source)], check=True)
    hashes = {str(path.relative_to(project)): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in jars + [native / 'glfw.dll', native / 'lwjgl.dll', native / 'lwjgl_opengl.dll']}
    (root / 'inputs.json').write_text(json.dumps(hashes, indent=2))
    print('MINIMAL_GLFW_PREPARED')
else:
    assert mode in ('A', 'B')
    directory = root / mode
    assert not directory.exists()
    directory.mkdir()
    args = [str(java_dir / 'java.exe'), '--enable-native-access=ALL-UNNAMED',
            '-Dorg.lwjgl.librarypath=' + str(native), '-cp', ';'.join(map(str, [root] + jars)),
            'NativeFocusNoApiProbe', mode, str(directory / 'close.signal')]
    with (directory / 'stdout.log').open('xb') as out, (directory / 'stderr.log').open('xb') as err:
        process = subprocess.Popen(args, cwd=directory, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
    (directory / 'owned-process.json').write_text(json.dumps(dict(pid=process.pid, executable=args[0], mode=mode)))
    print('MINIMAL_GLFW_STARTED', mode, process.pid, flush=True)
    code = process.wait()
    (directory / 'exit.json').write_text(json.dumps(dict(mode=mode, exitCode=code)))
    print('MINIMAL_GLFW_EXIT', mode, code, flush=True)
