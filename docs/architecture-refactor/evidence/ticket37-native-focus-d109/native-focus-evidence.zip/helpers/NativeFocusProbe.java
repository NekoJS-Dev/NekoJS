import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import java.nio.file.Files;
import java.nio.file.Path;

public final class NativeFocusProbe {
    public static void main(String[] args) throws Exception {
        Path close = Path.of(args[1]);
        GLFWErrorCallback error = GLFWErrorCallback.createPrint(System.err);
        error.set();
        if (!GLFW.glfwInit()) throw new IllegalStateException("GLFW initialization failed");
        long window = GLFW.glfwCreateWindow(640, 400, "Neko Owned GLFW Probe " + args[0], 0, 0);
        if (window == 0) throw new IllegalStateException("GLFW window creation failed");
        GLFW.glfwSetWindowFocusCallback(window, (handle, focused) ->
            System.out.println("FOCUS " + args[0] + " " + focused));
        GLFW.glfwMakeContextCurrent(window);
        GL.createCapabilities();
        GLFW.glfwSwapInterval(1);
        System.out.println("READY " + args[0] + " pid=" + ProcessHandle.current().pid()
            + " glfw=" + GLFW.glfwGetVersionString());
        long deadline = System.nanoTime() + 300_000_000_000L;
        while (!GLFW.glfwWindowShouldClose(window) && !Files.exists(close)
                && System.nanoTime() < deadline) {
            GL11.glClearColor(args[0].equals("A") ? 0.2f : 0.6f, 0.3f, 0.5f, 1.0f);
            GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
            GLFW.glfwSwapBuffers(window);
            GLFW.glfwPollEvents();
        }
        org.lwjgl.glfw.Callbacks.glfwFreeCallbacks(window);
        GLFW.glfwDestroyWindow(window);
        GLFW.glfwTerminate();
        error.free();
        System.out.println("NORMAL_STOP " + args[0]);
    }
}
