import org.lwjgl.glfw.GLFW;
import java.nio.file.Files;
import java.nio.file.Path;

public final class NativeFocusNoApiProbe {
    public static void main(String[] args) throws Exception {
        if (!GLFW.glfwInit()) throw new IllegalStateException("GLFW initialization failed");
        GLFW.glfwWindowHint(GLFW.GLFW_CLIENT_API, GLFW.GLFW_NO_API);
        long window = GLFW.glfwCreateWindow(640, 400, "Neko Owned GLFW NoApi " + args[0], 0, 0);
        if (window == 0) throw new IllegalStateException("Window creation failed");
        System.out.println("READY " + args[0] + " pid=" + ProcessHandle.current().pid()
            + " glfw=" + GLFW.glfwGetVersionString());
        long deadline = System.nanoTime() + 300_000_000_000L;
        while (!GLFW.glfwWindowShouldClose(window) && !Files.exists(Path.of(args[1]))
                && System.nanoTime() < deadline) {
            GLFW.glfwPollEvents();
            Thread.sleep(10);
        }
        GLFW.glfwDestroyWindow(window);
        GLFW.glfwTerminate();
        System.out.println("NORMAL_STOP " + args[0]);
    }
}
