from pathlib import Path
import subprocess
import sys

helpers = Path('build/ticket37-config-sync-repair')
source = (helpers / 'NativeFocusNoApiProbe.java').read_text()
source = source.replace('NativeFocusNoApiProbe', 'NativePointerProbe')
source = source.replace('Neko Owned GLFW NoApi', 'Neko Owned GLFW Pointer')
source = source.replace('+ " glfw=" + GLFW.glfwGetVersionString()', '+ " windowPointer=0x" + Long.toHexString(window) + " glfw=" + GLFW.glfwGetVersionString()')
destination = helpers / 'NativePointerProbe.java'
assert not destination.exists()
destination.write_text(source)
runner = (helpers / 'run-native-noapi-probe.py').read_text()
runner = runner.replace('minimal-no-api', 'minimal-pointer-pair').replace('NativeFocusNoApiProbe', 'NativePointerProbe')
destination = helpers / 'run-native-pointer-probe.py'
assert not destination.exists()
destination.write_text(runner)
subprocess.run([sys.executable, str(destination), 'prepare'], check=True)
single = helpers / 'run-native-single-probe.py'
assert not single.exists()
single.write_text(runner.replace('minimal-pointer-pair', 'minimal-pointer-single'))
subprocess.run([sys.executable, str(single), 'prepare'], check=True)
print('POINTER_PAIR_AND_SINGLE_CONTROLS_PREPARED')
