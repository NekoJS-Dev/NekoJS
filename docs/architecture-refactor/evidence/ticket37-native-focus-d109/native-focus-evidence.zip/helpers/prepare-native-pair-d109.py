from pathlib import Path
import subprocess
import sys

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
root = project / 'build/ticket37-native-pair-d109'
assert not root.exists()
sources = {
    'prepare-client93-visual-resumed-d109.py': 'prepare-pair-profiles-d109.py',
    'run-client93-resumed-d109.py': 'run-native-pair-d109.py',
    'rcon-client93-resumed-d109.py': 'rcon-native-pair-d109.py',
    'signal-lifecycle-d109.py': 'signal-native-pair-d109.py',
    'probe-client-close-d109.py': 'close-native-pair-d109.py',
    'prepare-lifecycle-close-probe.py': 'prepare-pair-close-d109.py',
}
for original, target in sources.items():
    destination = helpers / target
    assert not destination.exists()
    text = (helpers / original).read_text(encoding='utf-8')
    text = text.replace('ticket37-client-lifecycle-d109', 'ticket37-native-pair-d109')
    text = text.replace('25981', '25983').replace('25982', '25984')
    if original.startswith('prepare-client93'):
        text = text.replace("((artifact, graal, bridge) if letter == 'A' else (artifact, graal))", '(artifact, graal)')
    destination.write_text(text, encoding='utf-8')
subprocess.run([sys.executable, str(helpers / sources['prepare-client93-visual-resumed-d109.py'])], check=True)
subprocess.run([sys.executable, str(helpers / sources['prepare-lifecycle-close-probe.py'])], check=True)
(root / 'PAIR-PLAN.md').write_text('''# Concurrent native client control

Exact d109 official NeoForge26.2 JAR, NeoForge26.2.0.75, JDK25.0.2.
Fresh dedicated server/world, two synthetic offline clients, neither with
the HTTP bridge. Ports25983/25984. Preserve unchanged permission configs.
Observe each returned owned window before using Sky. Alternate activation
three complete A/B cycles, capture native F2 frames, resource-reload each
with actual F3+T, and request a server reload with both real clients online.
Retain all crashes, missing observations, direct exits and raw logs.
Close each on its tick owner, then RCON-stop only this dedicated server.
This bounded control cannot establish that the historical GLFW defect is
fixed or certify first-pixel, pack-download, all-node or maintainer gates.
Inherited PLAN/LIFECYCLE-PLAN are templates; this plan defines the run.
''', encoding='utf-8')
assert all(not list((root / ('client' + letter) / 'mods').glob('*mcp*')) for letter in ('A', 'B'))
print('CONCURRENT_NO_BRIDGE_CONTROL_PREPARED')
