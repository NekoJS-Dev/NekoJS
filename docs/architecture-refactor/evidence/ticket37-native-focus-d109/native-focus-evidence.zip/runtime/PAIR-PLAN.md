# Concurrent native client control

Exact d109 official NeoForge26.2 JAR, NeoForge26.2.0.75, JDK25.0.2.
Fresh dedicated server/world, two synthetic offline clients, neither with
the HTTP bridge. Ports25983/25984. Preserve unchanged permission configs.
Observe each returned owned window before using Sky. Alternate activation
three complete A/B cycles, capture native F2 frames, resource-reload each
with actual F3+T, and request a server reload with both real clients online.
Retain all crashes, missing observations, direct exits and raw logs.
Close each on its tick owner, then RCON-stop only this dedicated server.
This bounded control cannot establish that the historical GLFW defect is
fixed or certify first-pixel, pack-download, all-node or maintainer gates.
Inherited PLAN/LIFECYCLE-PLAN are templates; this plan defines the run.
