# Current client visual and two-player installed acceptance

Use exact current official NeoForge26.2 JAR from the completed five-node
source-bound build, fresh owned world/profiles, cached NeoForge26.2.0.75,
JDK25.0.2 and synthetic offline identities. Server port25983/RCON25984.
Launch A first, bind Minecraft bridge by actual client PID/game directory,
verify initial join/catch-up, declaration generation and first HUD state.
Capture clear/vanilla override/custom inline blur, candidate rejection
retaining the previous generation, and next successful recovery.
Then launch B to observe two real sessions/ACK/activation after ordinary
server reload. Preserve original failures, native crashes and raw logs.
No sandbox/HostAccess/ClassFilter/production source changes. Screenshot
after a HUD callback does not certify the first rendered pixel frame.
Do not operate user game profiles or unrelated processes. Normal server
RCON stop and client close; record direct exits. Raw launcher arguments,
credentials, worlds and hs_err stay local. User explicitly authorized
visible client testing in this turn. No release or human PASS inferred.
