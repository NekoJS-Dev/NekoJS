const visualFs = require('node:fs');
const visualSignal = 'D:/mcmodDemo/NekoJS-mult/build/ticket37-native-pair-d109/clientA/nekojs/data/visual-step.txt';
let lastVisualStep = '';
let hudRecorded = false;
ClientEvents.postEffects(event => {
    event.register('minecraft:invert', { blurRadius: 16, blurRounds: 1 });
    event.register('ticket37_client93:inline_blur', { blurRadius: 16, blurRounds: 1 });
});
ClientEvents.loggedIn(() => {
    const accepted = PostEffects.set('ticket37_client93:inline_blur');
    console.info('CLIENT93-LOGIN-SET ' + JSON.stringify({ accepted, generation: PostEffects.activeGeneration(), current: PostEffects.current(), active: PostEffects.isActive() }));
});
ClientEvents.tickPost(() => {
    if (!visualFs.existsSync(visualSignal)) return;
    const step = String(visualFs.readFileSync(visualSignal, 'utf8')).trim();
    if (step === lastVisualStep) return;
    lastVisualStep = step;
    if (step === 'close') {
        console.info('LIFECYCLE-OWNED-STOP requested=true');
        Java.type('net.minecraft.client.Minecraft').getInstance().stop();
        return;
    }
    const accepted = step === 'inline' ? PostEffects.set('ticket37_client93:inline_blur') : step === 'vanilla' ? PostEffects.set('minecraft:invert') : PostEffects.clear();
    console.info('CLIENT93-VISUAL-STEP ' + JSON.stringify({ step, accepted, generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('ticket37_client93:inline_blur'), current: PostEffects.current(), active: PostEffects.isActive() }));
});
ClientEvents.hud(() => {
    if (hudRecorded) return;
    hudRecorded = true;
    console.info('CLIENT93-FIRST-HUD ' + JSON.stringify({ generation: PostEffects.activeGeneration(), declared: PostEffects.hasDefinition('ticket37_client93:inline_blur'), current: PostEffects.current(), active: PostEffects.isActive() }));
});
