﻿// <REDACTED-RCON-CREDENTIAL> fixture entry (module scaffold placeholder).
