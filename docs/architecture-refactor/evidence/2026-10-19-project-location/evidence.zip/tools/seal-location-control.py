"""Freeze the unchanged-artifact location cohort without duplicating its JAR."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

project=Path('D:/mcmodDemo/NekoJS-mult')
tools=project/'build/priority-closeout'
tree=Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
cohort=tools/'location-d-606d1fff-formal'
prep=json.loads((cohort/'preparation.json').read_text())
cprep=json.loads((tools/'source-map-606d1fff-formal/preparation.json').read_text())
assert prep['artifactSha256']==cprep['artifactSha256'] and prep['classBindings']==cprep['classBindings']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()==prep['revision']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True).strip()
classes={}
for relative in ['common/build/classes/java/main','versions/26.1.2/build/classes/java/main']:
    base=tree/relative
    for file in base.rglob('*.class'):
        key=file.relative_to(base).as_posix()
        assert key not in classes
        classes[key]=hashlib.sha256(file.read_bytes()).hexdigest()
assert classes==prep['classBindings']
assert hashlib.sha256(Path(prep['artifact']).read_bytes()).hexdigest()==prep['artifactSha256']
for file in (tree/'versions/26.1.2/build').rglob('*.txt'):
    assert 'nekoStartup' not in file.read_text(errors='replace')
fixtureHashes={name:hashlib.sha256((tree/name).read_bytes()).hexdigest() for name in prep['fixtureHashes']}
assert fixtureHashes==prep['fixtureHashes']
target=project/'docs/architecture-refactor/evidence/2026-10-19-project-location'
target.mkdir(parents=True,exist_ok=True)
reference=project/'docs/architecture-refactor/evidence/2026-10-19-source-map-decoder/evidence.zip'
secrets=[]
for file in [tree/'versions/26.1.2/run/server.properties',tools/'client-world-acceptance/server/server.properties']:
    secrets.extend(line.split('=',1)[1] for line in file.read_text().splitlines() if line.startswith('rcon.password='))
entries,redactions={},{}
def add_bytes(data,name):
    encoding='utf-16' if data.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig'
    try:text=data.decode(encoding)
    except UnicodeDecodeError:
        encoding='gb18030';text=data.decode(encoding)
    if any(secret in text for secret in secrets):
        redactions[name]=dict(originalSha256=hashlib.sha256(data).hexdigest())
        for secret in secrets:text=text.replace(secret,'<REDACTED-RCON-CREDENTIAL>')
        data=text.encode(encoding)
    assert all(secret.encode(codec) not in data for secret in secrets for codec in ['utf-8','utf-16-le','utf-16-be'])
    assert name not in entries
    entries[name]=data
def add(file,name):add_bytes(file.read_bytes(),name)
for file in cohort.iterdir():
    if file.is_file():add(file,'formal/metadata/'+file.name)
for group in json.loads((cohort/'groups.json').read_text()):
    folder=Path(group['outputDirectories'][0])
    for file in folder.rglob('*'):
        if file.is_file() and file.suffix in {'.json','.jsonl','.log','.txt','.csv'}:
            add(file,'formal/'+group['group']+'/'+file.relative_to(folder).as_posix())
for name in ['formal-performance.py','formal-location-performance.py','judge-performance.py','prepare-location-control.py',
             'location-control-preparation.json','location-control-build.log','seal-location-control.py']:
    add(tools/name,'tools/'+name)
for name in ['preparation.json','groups.json','judgment.json']:
    add(tools/'source-map-606d1fff-formal'/name,'c-reference/'+name)
for name in ['bench/perf/sample.ps1','bench/perf/rcon.py',*prep['fixtureHashes']]:add(tree/name,'harness/'+name)
post=dict(classBindings=classes,fixtureHashes=fixtureHashes,trackedSourcesClean=True,normalRunConfiguration=True)
add_bytes((json.dumps(post,indent=2)+'\n').encode(),'post-run-bindings.json')
entries['redactions.json']=(json.dumps(redactions,indent=2)+'\n').encode()
packed=target/'evidence.zip'
with zipfile.ZipFile(packed,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,data in sorted(entries.items()):archive.writestr(name,data)
manifest=dict(sourceRevision=prep['revision'],samplerChanged=False,externalQosController=False,
              artifactIdenticalToCReference=True,referenceArchive='../2026-10-19-source-map-decoder/evidence.zip',
              referenceArchiveSha256=hashlib.sha256(reference.read_bytes()).hexdigest(),
              archiveBytes=packed.stat().st_size,archiveSha256=hashlib.sha256(packed.read_bytes()).hexdigest(),
              entries={name:hashlib.sha256(data).hexdigest() for name,data in sorted(entries.items())})
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='entries'}))
print('entries='+str(len(entries)))
