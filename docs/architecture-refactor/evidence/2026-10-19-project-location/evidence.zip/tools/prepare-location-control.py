"""Bind an independent D-drive checkout to the same classes and copied test world."""
import hashlib
import json
import shutil
import socket
import subprocess
from pathlib import Path

tools = Path(__file__).resolve().parent
source = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
target = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
expected = json.loads((tools / 'source-map-606d1fff-formal/preparation.json').read_text())
result = tools / 'location-control-preparation.json'
assert not result.exists()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def safe_tree(path, owner):
    assert path.resolve().is_relative_to(owner.resolve())
    for item in [path, *path.parents, *path.rglob('*')]:
        assert not item.is_symlink() and not item.is_junction(), item

for tree in [source, target]:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == expected['revision']
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
    bindings = {}
    for relative in ['common/build/classes/java/main', 'versions/26.1.2/build/classes/java/main']:
        base = tree / relative
        for file in base.rglob('*.class'):
            name = file.relative_to(base).as_posix()
            assert name not in bindings
            bindings[name] = digest(file)
    assert bindings == expected['classBindings'], 'Compiled classes differ at ' + str(tree)
    assert digest(tree / 'bench/perf/sample.ps1') == expected['samplerSha256']
    assert {name: digest(tree / name) for name in expected['fixtureHashes']} == expected['fixtureHashes']
    safe_tree(tree / 'versions/26.1.2/run', tree / 'versions/26.1.2/run')
for port in [25871, 25872]:
    with socket.socket() as listener: listener.bind(('127.0.0.1', port))

old_run = source / 'versions/26.1.2/run'
new_run = target / 'versions/26.1.2/run'
copied = {}
for name in ['world', 'config', 'mods', 'server.properties', 'eula.txt']:
    before, after = old_run / name, new_run / name
    assert not after.exists(), 'Preserve existing target ' + str(after)
    if not before.exists(): continue
    if before.is_dir():
        shutil.copytree(before, after)
        for file in before.rglob('*'):
            if file.is_file():
                key = file.relative_to(old_run).as_posix()
                assert digest(file) == digest(new_run / key)
                copied[key] = digest(file)
    else:
        shutil.copy2(before, after)
        assert digest(before) == digest(after)
        copied[name] = digest(before)
summary = dict(revision=expected['revision'], source=str(source), target=str(target),
               compiledClassesIdentical=True, classCount=len(expected['classBindings']),
               fixtureHashes=expected['fixtureHashes'], samplerSha256=expected['samplerSha256'],
               copiedRunFileHashes=copied,
               limits='Location includes drive and path depth, not path length alone. Sequential cohorts are not a randomized causal comparison.')
result.write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(classes=len(expected['classBindings']), copiedFiles=len(copied), preservedExistingTargets=True)))
