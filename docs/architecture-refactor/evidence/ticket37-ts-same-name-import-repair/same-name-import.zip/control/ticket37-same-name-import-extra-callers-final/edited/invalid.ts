import { $Usage as Usage } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $PersistentData as Other } from "java:com/tkisor/nekojs/probe/testfixture/sameother";
import { $PersistentData as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
new Usage().acceptBase(new Base<string>("bad"));
const wrong: string = new Usage().acceptBase(new Other()).otherValue(); export {wrong};
