import { $Usage as Usage } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $PersistentData as Other } from "java:com/tkisor/nekojs/probe/testfixture/sameother";
import { $PersistentData as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
const result: Other = new Usage().acceptBase(new Other());
const value: number = result.otherValue(); export {value};
