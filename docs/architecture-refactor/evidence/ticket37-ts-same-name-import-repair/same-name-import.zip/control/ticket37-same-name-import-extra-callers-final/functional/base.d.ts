declare module "java:com/tkisor/nekojs/probe/testfixture/samebase" {
    export interface $Callback {
        apply(value: $Token): $Token;
    }

    export class $Token {
        constructor(value: string);
        baseValue(): string;
    }

    export type $Callback_<CallbackArg0 = $Token, CallbackResult = $Token> = ((arg0: CallbackArg0) => CallbackResult) | ($Callback & { readonly [Symbol.hasInstance]?: never });
}
