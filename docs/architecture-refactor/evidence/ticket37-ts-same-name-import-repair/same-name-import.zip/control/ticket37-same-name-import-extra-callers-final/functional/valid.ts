import { $CallbackUser as User, $Callback as Local } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $Token as Token, $Callback as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
const token = new Token("base"); const user = new User();
const returned: Token = user.invokeBase(value => value, token);
const local: Token = user.invokeLocal(value => value, token);
declare const host: Local; const base: Base = host;
export {returned,local,base};
