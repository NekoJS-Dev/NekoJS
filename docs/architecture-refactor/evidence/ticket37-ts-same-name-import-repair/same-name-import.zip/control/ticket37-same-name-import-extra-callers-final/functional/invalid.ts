import { $CallbackUser as User, $Callback as Local } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $Token as Token, $Callback as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
new User().invokeBase(value => "bad", new Token("ok"));
new User().invokeLocal((value: string) => new Token(value), new Token("ok"));
new User().invokeBase(value => value, 1);
