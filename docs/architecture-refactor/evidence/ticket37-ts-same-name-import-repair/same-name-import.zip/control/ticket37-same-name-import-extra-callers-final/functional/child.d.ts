import { $Callback as $NekoImport$Callback, $Callback_ as $NekoImport$Callback_, $Token as $NekoImport$Token } from "java:com/tkisor/nekojs/probe/testfixture/samebase";

declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export interface $Callback extends $NekoImport$Callback {
    }

    export class $Token extends $NekoImport$Token {
        constructor(value: string);
        acceptBase(value: $NekoImport$Token): string;
    }

    export class $CallbackUser {
        constructor();
        invokeBase(callback: $NekoImport$Callback_<$NekoImport$Token, $NekoImport$Token>, value: $NekoImport$Token): $NekoImport$Token;
        invokeLocal(callback: $Callback_<$NekoImport$Token, $NekoImport$Token>, value: $NekoImport$Token): $NekoImport$Token;
    }

    export type $Callback_<CallbackArg0 = $NekoImport$Token, CallbackResult = $NekoImport$Token> = ((arg0: CallbackArg0) => CallbackResult) | ($Callback & { readonly [Symbol.hasInstance]?: never });
}
