import { $PersistentData } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData } from "java:com/tkisor/nekojs/probe/testfixture/sameother";

declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export class $PersistentData extends $PersistentData<string> {
        constructor(value: string);
        acceptBase(value: $PersistentData<string>): string;
    }

    export class $Usage {
        constructor();
        base: $PersistentData<string>;
        other: $PersistentData;
        self: $PersistentData;
        acceptBase(value: $PersistentData<string>): $PersistentData<string>;
        acceptOther(value: $PersistentData): $PersistentData;
    }

}
