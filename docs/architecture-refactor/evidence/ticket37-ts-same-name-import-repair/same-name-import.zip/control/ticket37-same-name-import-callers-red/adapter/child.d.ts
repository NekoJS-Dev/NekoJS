import { $Token, $Token_ } from "java:com/tkisor/nekojs/probe/testfixture/samebase";

declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export class $Token extends $Token {
        constructor(value: string);
        acceptBase(value: $Token_): string;
    }

    export type $Token_ = $Token;
}
