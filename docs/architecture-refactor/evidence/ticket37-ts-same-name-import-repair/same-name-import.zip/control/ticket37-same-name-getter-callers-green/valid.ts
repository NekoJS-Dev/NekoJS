import { $GetterUsage as Usage, $PersistentData as Child } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $PersistentData as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData as Other } from "java:com/tkisor/nekojs/probe/testfixture/sameother";
const child = new Child("child"); const base: Base<string> = child;
const usage = new Usage();
const named: Other = usage.named; const escaped: Other = usage.escaped; const namespace: Other = usage.namespace;
const values: number[] = [named.otherValue(), escaped.otherValue(), namespace.otherValue()]; export {base,values};
