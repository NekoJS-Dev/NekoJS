import { $PersistentData as $NekoImport$PersistentData3 } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData as $NekoImport$PersistentData4 } from "java:com/tkisor/nekojs/probe/testfixture/sameother";

import { $PersistentData as $NekoImport$PersistentData } from "java:com/tkisor/nekojs/probe/testfixture/sameother";
import { $PersistentData as \u0024NekoImport$PersistentData1 } from "java:com/tkisor/nekojs/probe/testfixture/sameother";
import * as $NekoImport$PersistentData2 from "java:com/tkisor/nekojs/probe/testfixture/sameother";

declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export class $PersistentData extends $NekoImport$PersistentData3<string> {
        constructor(value: string);
        acceptBase(value: $NekoImport$PersistentData3<string>): string;
    }

    export class $GetterUsage {
        constructor();
        get escaped(): $NekoImport$PersistentData1;
        get named(): $NekoImport$PersistentData;
        get namespace(): $NekoImport$PersistentData2.$PersistentData;
    }

}
