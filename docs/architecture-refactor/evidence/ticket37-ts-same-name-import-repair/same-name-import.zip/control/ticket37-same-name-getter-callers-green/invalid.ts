import { $GetterUsage as Usage, $PersistentData as Child } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $PersistentData as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData as Other } from "java:com/tkisor/nekojs/probe/testfixture/sameother";
const wrong: Base<string> = new Usage().named;
const wrongNumber: string = new Usage().escaped.otherValue();
new Child("child").acceptBase(new Usage().namespace); export {wrong,wrongNumber};
