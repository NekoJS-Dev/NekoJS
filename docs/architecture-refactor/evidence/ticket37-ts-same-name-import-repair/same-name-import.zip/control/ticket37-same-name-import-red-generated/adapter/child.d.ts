import { $PersistentData, $PersistentData_ } from "java:com/tkisor/nekojs/probe/testfixture/samebase";

declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export class $PersistentData extends $PersistentData<string> {
        constructor(value: string);
        acceptBase(value: $PersistentData_): string;
    }

    export type $PersistentData_ = $PersistentData;
}
