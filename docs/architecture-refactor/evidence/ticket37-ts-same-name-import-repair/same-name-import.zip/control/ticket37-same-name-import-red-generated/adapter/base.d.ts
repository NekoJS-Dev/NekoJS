declare module "java:com/tkisor/nekojs/probe/testfixture/samebase" {
    export class $PersistentData<T> {
        constructor(value: T);
        baseValue(): T;
    }

    export type $PersistentData_ = $PersistentData;
}
