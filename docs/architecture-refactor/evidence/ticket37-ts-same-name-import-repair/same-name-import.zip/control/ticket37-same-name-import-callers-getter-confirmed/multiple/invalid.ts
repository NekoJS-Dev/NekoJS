import { $PersistentData as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData as Child } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $Usage as Usage } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $PersistentData as Other } from "java:com/tkisor/nekojs/probe/testfixture/sameother";
new Child(1);
new Child("ok").acceptBase(new Base<number>(1));
new Usage().acceptOther(new Base<string>("bad"));
const wrong: number = new Child("ok").baseValue();
export {wrong};
