import { $PersistentData as $NekoImport$PersistentData } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData as $NekoImport$PersistentData1 } from "java:com/tkisor/nekojs/probe/testfixture/sameother";

declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export class $PersistentData extends $NekoImport$PersistentData<string> {
        constructor(value: string);
        acceptBase(value: $NekoImport$PersistentData<string>): string;
    }

    export class $Usage {
        constructor();
        base: $NekoImport$PersistentData<string>;
        other: $NekoImport$PersistentData1;
        self: $PersistentData;
        acceptBase(value: $NekoImport$PersistentData<string>): $NekoImport$PersistentData<string>;
        acceptOther(value: $NekoImport$PersistentData1): $NekoImport$PersistentData1;
    }

}
