import { $Token as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $Token as Child } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $Token_ as ChildInput } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
new Child(1);
new Child("ok").acceptBase(1);
const wrong: ChildInput = "bad";
export {wrong};
