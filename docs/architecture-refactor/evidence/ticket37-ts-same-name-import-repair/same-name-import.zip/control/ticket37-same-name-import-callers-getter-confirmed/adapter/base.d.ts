declare module "java:com/tkisor/nekojs/probe/testfixture/samebase" {
    export class $Token {
        constructor(value: string);
        baseValue(): string;
    }

    export type $Token_ = $Token;
}
