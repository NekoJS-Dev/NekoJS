import { $Token as Base } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $Token as Child } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
import { $Token_ as ChildInput } from "java:com/tkisor/nekojs/probe/testfixture/samechild";
const child = new Child("child"); const base = new Base("base");
const asInput: ChildInput = base; const accepted: string = child.acceptBase(base);
export {asInput,accepted};
