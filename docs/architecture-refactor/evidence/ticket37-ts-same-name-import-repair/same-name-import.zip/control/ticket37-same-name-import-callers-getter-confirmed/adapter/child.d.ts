import { $Token as $NekoImport$Token, $Token_ as $NekoImport$Token_ } from "java:com/tkisor/nekojs/probe/testfixture/samebase";

declare module "java:com/tkisor/nekojs/probe/testfixture/samechild" {
    export class $Token extends $NekoImport$Token {
        constructor(value: string);
        acceptBase(value: $NekoImport$Token_): string;
    }

    export type $Token_ = $Token | $NekoImport$Token;
}
