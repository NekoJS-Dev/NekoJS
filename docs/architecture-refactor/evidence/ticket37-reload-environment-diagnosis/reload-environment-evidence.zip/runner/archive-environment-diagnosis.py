import collections
import hashlib
import json
import re
import socket
import subprocess
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd().resolve()
owned = root / 'build/ticket37-perf-owned-ac810fa7'
repair = root / 'build/ticket37-config-sync-repair'
out = root / 'docs/architecture-refactor/evidence/ticket37-reload-environment-diagnosis'
out.mkdir()
revision = '93f4b259ffafb6466918582fcfa950c2c2480d77'
baseline = '7b724a50f51367ad43f5903b1e7240e8e69bad10'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git', '-C', str(owned), 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', '-C', str(owned), 'status', '--porcelain'], text=True).strip()
for port in (25871, 25872):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', port))
sampler_sha = sha((owned / 'bench/perf/sample.ps1').read_bytes())
assert sampler_sha == '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
secrets = [line.partition('=')[2].encode() for line in (owned / 'versions/26.1.2/run/server.properties').read_text().splitlines() if line.startswith('rcon.password=')]


def scan(data):
    checked = data.replace(b'.gradle-perf02', b'[owned-gradle-cache]')
    assert not any(secret and secret in checked for secret in secrets), 'Actual credential found'
    assert not re.search(rb'(?m)^rcon\.password=', data), 'Credential property found'


files = {}
groups = []
for label, directory, expected, instrumented in [
    ('old-environment-control', 'ticket37-perf-7b-environment-control', baseline, False),
    ('adjacent-current-control', 'ticket37-perf-93-adjacent-control', revision, False),
    ('owned-current-profile', 'ticket37-perf-93-owned-profile', revision, True),
]:
    work = root / 'build' / directory
    inventory = json.loads((work / 'output-inventory-after.json').read_text())
    assert len(inventory['new']) == 1
    folder = owned / 'bench/perf/out' / inventory['new'][0]
    rows = [json.loads(line) for line in (folder / 'samples.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    assert len(rows) == 5 and [row['index'] for row in rows] == [1, 2, 3, 4, 5]
    assert all(row['rev'] == expected[:8] and row['mode'] == 'reload' and row['node'] == '26.1.2' and row['kind'] == 'formal' and row['stop_channel'] == 'rcon' and not row['killed'] and not row['forced_kill'] and 'phase=COMMIT - no errors.' in row['rcon_response'] for row in rows)
    exit_path = work / ('sampler-exit.json' if instrumented else 'reload-control.txt.exit.json')
    assert json.loads(exit_path.read_text())['exitCode'] == 0
    for guard in ['before-guard', 'after-guard']:
        exit_name = guard + ('-exit.json' if instrumented else '.txt.exit.json')
        assert json.loads((work / exit_name).read_text())['exitCode'] == 0
    log = (folder / 'reload-session-stdout.log').read_text(encoding='utf-8', errors='replace')
    assert 'BUILD SUCCESSFUL' in log and 'Stopping server' in log
    marker = [row['marker_ms'] for row in rows]
    rtt = [row['rcon_rtt_ms'] for row in rows]
    groups.append(dict(group=label, sourceRevision=expected, folder=folder.name, markerMs=marker,
                       markerMeanMs=sum(marker) / 5, rconRttMs=rtt, rconRttMeanMs=sum(rtt) / 5,
                       markerTailMs=[m-r for m, r in zip(marker, rtt)],
                       markerTailMeanMs=sum(m-r for m, r in zip(marker, rtt)) / 5,
                       thresholdMs=285.3, diagnosticGate='INSTRUMENTED: not acceptance' if instrumented else ('PASS' if sum(marker) / 5 <= 285.3 else 'FAIL'),
                       samplerExit=0, samples=rows, instrumented=instrumented))
    for path in folder.iterdir():
        if path.is_file() and path.suffix in ('.log', '.jsonl', '.txt', '.json', '.csv'):
            files['samples/' + folder.name + '/' + path.name] = path
    for path in work.iterdir():
        if path.is_file() and path.suffix in ('.txt', '.json') and 'local-only' not in path.name:
            files['wrapper/' + label + '/' + path.name] = path

profile_work = root / 'build/ticket37-perf-93-owned-profile'
aggregate = json.loads((profile_work / 'profile-aggregate.json').read_text())
transactions = aggregate['transactionSamples']
phases = {
    'pathSafety': 'NekoModuleResolver.verifyInsideGameDir',
    'memberValidation': 'GlobalBindingMemberValidator.validate',
    'candidateContext': 'ScriptManager.createCandidateEnvironment',
    'bindingInstall': 'ScriptEnvironmentFactory.installEnvironmentBindings',
    'scriptExecution': 'ScriptManager.loadCandidateScripts',
    'commit': 'ScriptManager.commitGeneration',
}
counts = {phase: sum(any(pattern in method for method in row['methods']) for row in transactions) for phase, pattern in phases.items()}
events = json.loads((profile_work / 'events-local-only.json').read_text())['recording']['events']
probe_observations = []
for event in events:
    values = event['values']
    if event['type'] not in ('jdk.ExecutionSample', 'jdk.NativeMethodSample'):
        continue
    thread = values.get('sampledThread') or values.get('eventThread') or {}
    methods = []
    for frame in (values.get('stackTrace') or {}).get('frames') or []:
        method = frame['method']
        owner = method['type']['name'].replace('/', '.')
        if owner.startswith('com.tkisor.nekojs.probe.'):
            methods.append(owner + '.' + method['name'])
    if methods:
        probe_observations.append(dict(time=values['startTime'], thread=thread.get('javaName') or thread.get('osName'), methods=methods))
phase_summary = dict(transactionSamples=len(transactions), overlappingPhaseSampleCounts=counts,
                     probeObservations=probe_observations,
                     limits='Overlapping sampled presence, not percentages or precise phase durations; absent frames do not prove non-execution')
(profile_work / 'profile-phase-counts.json').write_text(json.dumps(phase_summary, indent=2) + '\n', encoding='utf-8')
files['wrapper/owned-current-profile/profile-phase-counts.json'] = profile_work / 'profile-phase-counts.json'

compiled = []
binding = json.loads((root / 'build/ticket37-same-name-import-installed/artifact-source-binding.json').read_text())
for name, expected in binding['nodes'][0]['classHashes'].items():
    relative = 'common/build/classes/java/main/' + name
    resource = (owned / relative).read_bytes()
    assert sha(resource) == expected and resource == (root / relative).read_bytes()
    compiled.append(dict(path=relative, sha256=sha(resource)))
assert len(compiled) == 14
production_diff = subprocess.check_output(['git', 'diff', '--name-only', baseline, revision, '--', 'common/src/main/java', 'src/main/java', 'versions'], text=True).splitlines()
assert len(production_diff) == 6 and all('/probe/' in path for path in production_diff)
for name in ['ticket37-perf-environment-control-runners', 'ticket37-perf-adjacent-current-runners', 'ticket37-perf-owned-profile-runners']:
    for path in (root / 'build' / name).iterdir():
        if path.is_file():
            files['runner/' + name + '/' + path.name] = path
for name in ['run-old-environment-control.py', 'prepare-adjacent-current-control.py', 'run-adjacent-current-control.py', 'run-owned-reload-profile.py', 'read-owned-reload-profile.py', 'archive-environment-diagnosis.py']:
    files['runner/' + name] = repair / name
historical = json.loads((root / 'docs/architecture-refactor/evidence/ticket37-same-name-performance/summary.json').read_text())
assert historical['overall'] == 'FAIL'
retained = [dict(group=row['group'], values=row['formalValuesMs'], mean=row['meanMs'], verdict=row['acceptanceVerdict']) for row in historical['groups']]
summary = dict(groups=groups, samplerSha256=sampler_sha, originalFormalGroups=retained,
               currentFormalPerformance='FAIL retained', normalRconSessions=3,
               toolObservedOuterExits=[dict(sessionId=71025, exitCode=0), dict(sessionId=12267, exitCode=0), dict(sessionId=75839, exitCode=0)],
               currentCompiledClasses=compiled, productionDiffPaths=production_diff, profile=phase_summary,
               desktop='Hidden console/background servers only; no GUI client/input/window activation/desktop switch. No independent desktop or CPU/memory isolation established.',
               cause='NOT ESTABLISHED. Adjacent marker difference contains a larger observation tail while current RTT is lower. RTT is not reload body duration.',
               errata='Adjacent runner inherited the phrase old-source control in one summary string. Its actual source guard/raw samples are exact93; retained original text is not an old-source run.',
               limitations=['Temporal controls do not hold external workload constant', 'Old-control compiled class bytes were not separately frozen before switching back; source/guards/build logs retained', 'JFR is sampled, instrumented and includes startup', 'Full IDE/other tickets/maintainer acceptance remain incomplete', 'Automation PAUSED; tool permission-field UNRESOLVED'])
archive_path = out / 'reload-environment-evidence.zip'
entries = []
with ZipFile(archive_path, 'x', ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        assert not name.endswith('.jfr') and 'local-only' not in name and 'server.properties' not in name
        data = path.read_bytes()
        scan(data)
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for entry in entries:
        assert sha(archive.read(entry['path'])) == entry['sha256']
summary['archive'] = dict(file=archive_path.name, entries=len(entries), bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes()))
summary['entries'] = entries
summary_bytes = (json.dumps(summary, indent=2) + '\n').encode()
scan(summary_bytes)
(out / 'summary.json').write_bytes(summary_bytes)
print(json.dumps(dict(groups=[{k:v for k,v in row.items() if k != 'samples'} for row in groups], profile=phase_summary, archive=summary['archive'])))
