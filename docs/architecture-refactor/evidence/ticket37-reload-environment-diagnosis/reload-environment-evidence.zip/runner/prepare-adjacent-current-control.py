from pathlib import Path

root = Path.cwd().resolve()
repair = root / 'build/ticket37-config-sync-repair'
source = (repair / 'run-old-environment-control.py').read_text(encoding='utf-8')
source = source.replace('ticket37-perf-environment-control-runners', 'ticket37-perf-adjacent-current-runners')
source = source.replace('ticket37-perf-7b-environment-control', 'ticket37-perf-93-adjacent-control')
source = source.replace('7b724a50f51367ad43f5903b1e7240e8e69bad10', '93f4b259ffafb6466918582fcfa950c2c2480d77')
start = source.index("plan = '''")
end = source.index("'''\n", start) + 4
source = source[:start] + "plan = '''# One predeclared adjacent current-source diagnostic control\n\nRun exactly one unchanged 93f4b259 reload group with all five samples after\nthe completed old 7b temporal control (407,224,342,207,219; mean279.8ms).\nUse the same original sampler/fixtures/JDK/cache/owned checkout/world/ports\nand path/reparse/process/source/sampler guards. Keep every sample and raw\nlog, including the first. This is a diagnostic comparison, not replacement\nacceptance: both original exact93 failing groups remain FAIL. No retries\nor additional groups selected by their scores. Time drift and unknown\nexternal workload still limit causal inference. Do not stop user processes.\n\nThe sampler and console descendants use their own hidden console. No GUI\nclient launch, desktop switching or window activation. This does not isolate\nCPU/memory or provide another Windows desktop. No source/sampler/fixture/\nthreshold/user configuration edits. Inventory before/after binds exactly one\nnew output directory. The original formal failures remain retained even if\nthis diagnostic group passes.\n'''\n" + source[end:]
source = source.replace('OLD_SOURCE_CONTROL_START', 'ADJACENT_CURRENT_CONTROL_START')
target = repair / 'run-adjacent-current-control.py'
with target.open('x', encoding='utf-8') as output:
    output.write(source)
print('ADJACENT_RUNNER_PREPARED')
