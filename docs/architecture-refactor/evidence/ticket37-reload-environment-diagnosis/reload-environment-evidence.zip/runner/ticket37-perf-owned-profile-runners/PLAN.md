# One predeclared owned-only reload profile

After both temporal controls settle, run exactly one original five-reload
sampler group at exact93 with a JDK profile recording attached to the newly
launched owned server JVM. Preserve sampler/fixtures/JDK/cache/ports/source
and path/reparse/process guards. Bind the server using its owned checkout
command line, excluding Gradle launcher/daemon/worker processes, and actual
owned game-directory startup log. Never attach to unrelated Java processes.
The original formal groups remain FAIL. Instrumented values are diagnostic,
not a substitute acceptance group. Record every sample including the first.

Test whether Probe import allocation/rendering is visible on the reload path,
and identify observed server-thread work. Sampling absence cannot establish
that a function never executed; correlate with the source call path.
Do not infer full reload-body duration from RCON RTT or second-resolution
log times. Attach timing and profiler overhead limit quantitative comparison.

Run console processes in their own hidden console. No GUI client, window
activation or desktop switching. This is not CPU/memory isolation. Raw JFR
and raw event JSON stay local and uncommitted; publish only derived class/
thread/event-count/timing aggregates with no file/network payloads.
