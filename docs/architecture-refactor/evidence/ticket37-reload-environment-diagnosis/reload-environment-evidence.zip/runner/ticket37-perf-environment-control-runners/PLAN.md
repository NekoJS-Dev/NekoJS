# One predeclared old-source environment control

Run exactly one reload group with all five samples at unchanged source
7b724a50f51367ad43f5903b1e7240e8e69bad10. Use the unchanged sampler, fixtures,
JDK 25, Gradle cache, owned checkout/world and ports from the completed exact
93f4b259 formal groups. This is a diagnostic temporal control, not acceptance
of current source and not a replacement of either current failing group.
Keep the first sample, every raw log, RCON RTT and marker metric. Unknown/user
processes remain untouched; system idleness and matched external workload
are not established. The time gap limits causal inference.

Preserve all existing path/reparse/process/port/source/sampler guards.
Inventory existing output directories before launching and bind only the
single newly created reload directory to this run. Run the sampler in its
own hidden console so its ordinary console descendants inherit a hidden
console; do not start GUI clients or activate windows. This is background
execution on the same desktop, not another desktop or resource isolation.
No source, fixture, sampler, threshold or user configuration edits.
