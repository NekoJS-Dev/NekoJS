import hashlib
import json
import os
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
helpers = root / 'build/ticket37-perf-adjacent-current-runners'
helpers.mkdir()
owned = root / 'build/ticket37-perf-owned-ac810fa7'
destination = root / 'build/ticket37-perf-93-adjacent-control'
revision = '93f4b259ffafb6466918582fcfa950c2c2480d77'
previous = '93f4b259ffafb6466918582fcfa950c2c2480d77'
repair = root / 'build/ticket37-config-sync-repair'
plan = '''# One predeclared adjacent current-source diagnostic control

Run exactly one unchanged 93f4b259 reload group with all five samples after
the completed old 7b temporal control (407,224,342,207,219; mean279.8ms).
Use the same original sampler/fixtures/JDK/cache/owned checkout/world/ports
and path/reparse/process/source/sampler guards. Keep every sample and raw
log, including the first. This is a diagnostic comparison, not replacement
acceptance: both original exact93 failing groups remain FAIL. No retries
or additional groups selected by their scores. Time drift and unknown
external workload still limit causal inference. Do not stop user processes.

The sampler and console descendants use their own hidden console. No GUI
client launch, desktop switching or window activation. This does not isolate
CPU/memory or provide another Windows desktop. No source/sampler/fixture/
threshold/user configuration edits. Inventory before/after binds exactly one
new output directory. The original formal failures remain retained even if
this diagnostic group passes.
'''
(helpers / 'PLAN.md').write_text(plan, encoding='utf-8')
for name in ('prepare-same-name-performance.ps1', 'guard-same-name-performance.ps1'):
    source = (repair / name).read_text(encoding='utf-8-sig')
    assert previous in source and 'ticket37-perf-93f4b259' in source
    source = source.replace(previous, revision).replace('ticket37-perf-93f4b259', 'ticket37-perf-93-adjacent-control')
    (helpers / name).write_text(source, encoding='utf-8')
child_env = dict(os.environ)
child_env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
child_env['JAVA_HOME'] = r'C:\Program Files\Java\jdk-25.0.2'
child_env['PATH'] = child_env['JAVA_HOME'] + r'\bin;' + child_env['PATH']
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = subprocess.SW_HIDE


def run(command, directory, output_name):
    with (directory / output_name).open('xb') as output:
        result = subprocess.run(command, cwd=owned, env=child_env, stdout=output,
                                stderr=subprocess.STDOUT, startupinfo=startup,
                                creationflags=subprocess.CREATE_NEW_CONSOLE)
    record = dict(exitCode=result.returncode, sourceRevision=revision,
                  capture='Direct subprocess wait; own hidden console; redirected files')
    (directory / (output_name + '.exit.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(output_name + ' EXIT=' + str(result.returncode), flush=True)
    assert result.returncode == 0, record


def powershell(path):
    return ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(path)]


run(powershell(helpers / 'prepare-same-name-performance.ps1'), helpers, 'preparation.txt')
before = sorted(p.name for p in (owned / 'bench/perf/out').iterdir() if p.is_dir())
(destination / 'output-inventory-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf-8')
run(powershell(helpers / 'guard-same-name-performance.ps1'), destination, 'before-guard.txt')
print('ADJACENT_CURRENT_CONTROL_START', flush=True)
run(powershell(owned / 'bench/perf/sample.ps1') + ['-Mode', 'reload', '-Node', '26.1.2', '-Warmup', '2', '-Samples', '5', '-Reloads', '5', '-GradleUserHome', 'D:/mcmodDemo/NekoJS/.gradle-perf02', '-ServerPort', '25871', '-RconPort', '25872'], destination, 'reload-control.txt')
after = sorted(p.name for p in (owned / 'bench/perf/out').iterdir() if p.is_dir())
new = sorted(set(after) - set(before))
(destination / 'output-inventory-after.json').write_text(json.dumps(dict(all=after, new=new), indent=2) + '\n', encoding='utf-8')
assert len(new) == 1 and new[0].endswith('-reload-26.1.2'), new
sample_dir = owned / 'bench/perf/out' / new[0]
rows = [json.loads(line) for line in (sample_dir / 'samples.jsonl').read_text(encoding='utf-8-sig').splitlines()]
assert len(rows) == 5 and [row['index'] for row in rows] == [1, 2, 3, 4, 5]
assert all(row['rev'] == revision[:8] and row['node'] == '26.1.2' and row['mode'] == 'reload' and row['kind'] == 'formal' and row['stop_channel'] == 'rcon' and row['killed'] is False and row['forced_kill'] is False for row in rows)
marker = [row['marker_ms'] for row in rows]
rtt = [row['rcon_rtt_ms'] for row in rows]
assert all(isinstance(value, int) and value > 0 for value in marker + rtt)
summary = dict(sourceRevision=revision, sampleDirectory=new[0], markerMs=marker,
               markerMeanMs=sum(marker) / 5, gateMs=285.3,
               controlGate='PASS' if sum(marker) / 5 <= 285.3 else 'FAIL',
               rconRttMs=rtt, markerTailMs=[m-r for m, r in zip(marker, rtt)],
               samplerSha256=hashlib.sha256((owned / 'bench/perf/sample.ps1').read_bytes()).hexdigest(),
               currentSourcePerformance='FAIL retained; this old-source control cannot certify current source')
(destination / 'control-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
run(powershell(helpers / 'guard-same-name-performance.ps1'), destination, 'after-guard.txt')
print(json.dumps(summary), flush=True)
