# One predeclared adjacent current-source diagnostic control

Run exactly one unchanged 93f4b259 reload group with all five samples after
the completed old 7b temporal control (407,224,342,207,219; mean279.8ms).
Use the same original sampler/fixtures/JDK/cache/owned checkout/world/ports
and path/reparse/process/source/sampler guards. Keep every sample and raw
log, including the first. This is a diagnostic comparison, not replacement
acceptance: both original exact93 failing groups remain FAIL. No retries
or additional groups selected by their scores. Time drift and unknown
external workload still limit causal inference. Do not stop user processes.

The sampler and console descendants use their own hidden console. No GUI
client launch, desktop switching or window activation. This does not isolate
CPU/memory or provide another Windows desktop. No source/sampler/fixture/
threshold/user configuration edits. Inventory before/after binds exactly one
new output directory. The original formal failures remain retained even if
this diagnostic group passes.
