import json
import os
import subprocess
import time
from pathlib import Path

root = Path.cwd().resolve()
owned = root / 'build/ticket37-perf-owned-ac810fa7'
helpers = root / 'build/ticket37-perf-owned-profile-runners'
helpers.mkdir()
destination = root / 'build/ticket37-perf-93-owned-profile'
destination.mkdir()
revision = '93f4b259ffafb6466918582fcfa950c2c2480d77'
(helpers / 'PLAN.md').write_text('''# One predeclared owned-only reload profile

After both temporal controls settle, run exactly one original five-reload
sampler group at exact93 with a JDK profile recording attached to the newly
launched owned server JVM. Preserve sampler/fixtures/JDK/cache/ports/source
and path/reparse/process guards. Bind the server using its owned checkout
command line, excluding Gradle launcher/daemon/worker processes, and actual
owned game-directory startup log. Never attach to unrelated Java processes.
The original formal groups remain FAIL. Instrumented values are diagnostic,
not a substitute acceptance group. Record every sample including the first.

Test whether Probe import allocation/rendering is visible on the reload path,
and identify observed server-thread work. Sampling absence cannot establish
that a function never executed; correlate with the source call path.
Do not infer full reload-body duration from RCON RTT or second-resolution
log times. Attach timing and profiler overhead limit quantitative comparison.

Run console processes in their own hidden console. No GUI client, window
activation or desktop switching. This is not CPU/memory isolation. Raw JFR
and raw event JSON stay local and uncommitted; publish only derived class/
thread/event-count/timing aggregates with no file/network payloads.
''', encoding='utf-8')
guard_source = (root / 'build/ticket37-config-sync-repair/guard-same-name-performance.ps1').read_text(encoding='utf-8-sig')
assert revision in guard_source
(helpers / 'guard.ps1').write_text(guard_source, encoding='utf-8')
env = dict(os.environ)
env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
env['JAVA_HOME'] = r'C:\Program Files\Java\jdk-25.0.2'
env['PATH'] = env['JAVA_HOME'] + r'\bin;' + env['PATH']
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = subprocess.SW_HIDE
kwargs = dict(cwd=owned, env=env, startupinfo=startup, creationflags=subprocess.CREATE_NEW_CONSOLE)
ps = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass']


def guard(name):
    with (destination / (name + '.txt')).open('xb') as output:
        result = subprocess.run(ps + ['-File', str(helpers / 'guard.ps1')], stdout=output, stderr=subprocess.STDOUT, **kwargs)
    (destination / (name + '-exit.json')).write_text(json.dumps(dict(exitCode=result.returncode)) + '\n', encoding='utf-8')
    assert result.returncode == 0


guard('before-guard')
before = sorted(p.name for p in (owned / 'bench/perf/out').iterdir() if p.is_dir())
(destination / 'output-inventory-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf-8')
with (destination / 'sampler.txt').open('xb') as output:
    process = subprocess.Popen(ps + ['-File', str(owned / 'bench/perf/sample.ps1'), '-Mode', 'reload', '-Node', '26.1.2', '-Warmup', '2', '-Samples', '5', '-Reloads', '5', '-GradleUserHome', 'D:/mcmodDemo/NekoJS/.gradle-perf02', '-ServerPort', '25871', '-RconPort', '25872'], stdout=output, stderr=subprocess.STDOUT, **kwargs)
    print('OWNED_PROFILE_SAMPLER_START', flush=True)
    profile = None
    while process.poll() is None:
        current = [p for p in (owned / 'bench/perf/out').iterdir() if p.is_dir() and p.name not in before]
        if profile is None and len(current) == 1:
            log = current[0] / 'reload-session-stdout.log'
            if log.exists() and ('Game directory: ' + str(owned / 'versions/26.1.2/run')) in log.read_text(encoding='utf-8', errors='replace'):
                query = "Get-CimInstance Win32_Process -Filter \"Name='java.exe'\" | Where-Object { $_.CommandLine -and $_.CommandLine.Contains('" + str(owned) + "') -and $_.CommandLine -notmatch 'GradleWrapperMain|GradleDaemon|GradleWorkerMain' } | Select-Object ProcessId,CreationDate | ConvertTo-Json -Compress"
                identity = subprocess.run(ps + ['-Command', query], stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs)
                assert identity.returncode == 0
                found = json.loads(identity.stdout.decode('utf-8-sig'))
                assert isinstance(found, dict) and isinstance(found['ProcessId'], int), found
                profile = dict(serverJvmPid=found['ProcessId'], creationDate=found['CreationDate'],
                               ownership='Owned command-line path, non-Gradle JVM, observed exact owned game-directory log',
                               sampledDirectory=current[0].name)
                (destination / 'profile-owner.json').write_text(json.dumps(profile, indent=2) + '\n', encoding='utf-8')
                command = [str(Path(env['JAVA_HOME']) / 'bin/jcmd.exe'), str(profile['serverJvmPid']), 'JFR.start', 'name=NekoOwnedReload', 'settings=profile', 'duration=120s', 'dumponexit=true', 'filename=' + str(destination / 'owned-local-only.jfr')]
                with (destination / 'jfr-start.txt').open('xb') as attach_output:
                    attached = subprocess.run(command, stdout=attach_output, stderr=subprocess.STDOUT, **kwargs)
                (destination / 'jfr-start-exit.json').write_text(json.dumps(dict(exitCode=attached.returncode)) + '\n', encoding='utf-8')
                assert attached.returncode == 0
                print('OWNED_PROFILE_ATTACHED PID=' + str(profile['serverJvmPid']), flush=True)
        time.sleep(0.75)
    code = process.wait()
(destination / 'sampler-exit.json').write_text(json.dumps(dict(exitCode=code, sourceRevision=revision, capture='Direct subprocess wait; instrumented diagnostic only')) + '\n', encoding='utf-8')
assert code == 0 and profile is not None
after = sorted(p.name for p in (owned / 'bench/perf/out').iterdir() if p.is_dir())
new = sorted(set(after) - set(before))
(destination / 'output-inventory-after.json').write_text(json.dumps(dict(all=after, new=new), indent=2) + '\n', encoding='utf-8')
assert new == [profile['sampledDirectory']]
assert (destination / 'owned-local-only.jfr').stat().st_size > 0
guard('after-guard')
print('OWNED_PROFILE_COMPLETE EXIT=0', flush=True)
