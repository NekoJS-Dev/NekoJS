import collections
import json
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
work = root / 'build/ticket37-perf-93-owned-profile'
raw = work / 'events-local-only.json'
with raw.open('xb') as output:
    result = subprocess.run([r'C:\Program Files\Java\jdk-25.0.2\bin\jfr.exe', 'print', '--json', '--events', 'jdk.ExecutionSample,jdk.NativeMethodSample,jdk.GarbageCollection,jdk.ThreadCPULoad', '--stack-depth', '64', str(work / 'owned-local-only.jfr')], stdout=output, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
assert result.returncode == 0, result.stderr.decode(errors='replace')
(work / 'events-print-exit.json').write_text(json.dumps(dict(exitCode=result.returncode)) + '\n', encoding='utf-8')
events = json.loads(raw.read_text(encoding='utf-8'))['recording']['events']
types = collections.Counter(event['type'] for event in events)
threads = collections.Counter()
server_frames = collections.Counter()
transaction_frames = collections.Counter()
all_probe_frames = collections.Counter()
transaction_samples = []
for event in events:
    values = event['values']
    if event['type'] not in ('jdk.ExecutionSample', 'jdk.NativeMethodSample'):
        continue
    thread = values.get('sampledThread') or values.get('eventThread') or {}
    name = thread.get('javaName') or thread.get('osName') or '<unnamed>'
    threads[name] += 1
    frames = (values.get('stackTrace') or {}).get('frames') or []
    methods = []
    for frame in frames:
        method = frame['method']
        owner = method['type']['name'].replace('/', '.')
        methods.append(owner + '.' + method['name'])
        if owner.startswith('com.tkisor.nekojs.probe.'):
            all_probe_frames[owner + '.' + method['name']] += 1
    if name == 'Server thread':
        server_frames.update(set(methods))
        if any(method.startswith('com.tkisor.nekojs.script.ScriptManager.reloadScriptsTransactional') for method in methods):
            transaction_frames.update(set(methods))
            transaction_samples.append(dict(startTime=values['startTime'], methods=methods))
summary = dict(eventCounts=dict(types), sampledThreads=dict(threads),
               serverThreadSampleCount=threads['Server thread'],
               transactionSampleCount=len(transaction_samples),
               topServerFrames=server_frames.most_common(25),
               topTransactionFrames=transaction_frames.most_common(35),
               probeFramesObserved=dict(all_probe_frames),
               transactionSamples=transaction_samples,
               limitations=['Sampled presence only; absent samples do not prove non-execution',
                            'Profiler attach/collection adds overhead; not formal performance acceptance',
                            'Aggregate contains class/method/thread/time/count only; raw JFR/JSON local-only'])
(work / 'profile-aggregate.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: summary[key] for key in ('eventCounts', 'serverThreadSampleCount', 'transactionSampleCount', 'topTransactionFrames', 'probeFramesObserved')}))
