import json
from pathlib import Path

project = Path.cwd().resolve()
helpers = project / 'build/ticket37-config-sync-repair'
work = project / 'build/ticket37-reload-execution-7d'
source = (helpers / 'read-reload-phase-7d.py').read_text(encoding='utf-8')
source = source.replace('ticket37-reload-phase-7d', 'ticket37-reload-execution-7d')
source = source.replace('DEBUG-7d-phase', 'DEBUG-7d-(?:phase|exec)')
source = source.replace('(?: message=(.*))?', '(?: (?:message|script)=(.*))?')
exec(compile(source, str(helpers / 'read-reload-phase-7d.py'), 'exec'))
summary = json.loads((work / 'phase-summary.json').read_text())
for row in summary['reloads']:
    events = row['events']
    def span(begin, end, script=None):
        starts = [e for e in events if e['phase'] == begin and (script is None or e['message'] == script)]
        ends = [e for e in events if e['phase'] == end and (script is None or e['message'] == script)]
        assert len(starts) == len(ends) == 1, (begin, end, script, starts, ends)
        assert starts[0]['nano'] < ends[0]['nano']
        return (ends[0]['nano'] - starts[0]['nano']) / 1e6
    scripts = [e['message'] for e in events if e['phase'] == 'entry-begin']
    assert len(scripts) == len(set(scripts)) == 6, scripts
    row['executionBreakdown'] = dict(beforeHookMs=span('before-hook-begin', 'before-hook-end'),
        afterHookMs=span('after-hook-begin', 'after-hook-end'), preloadMs=span('preload-begin', 'preload-end'),
        scripts=[dict(script=script, entryMs=span('entry-begin', 'entry-end', script),
                      validationMs=span('validation-begin', 'validation-end', script),
                      moduleMs=span('module-begin', 'module-end', script)) for script in scripts])
    for key in ('entryMs', 'validationMs', 'moduleMs'):
        row['executionBreakdown'][key] = sum(s[key] for s in row['executionBreakdown']['scripts'])
keys = ('beforeHookMs', 'afterHookMs', 'preloadMs', 'entryMs', 'validationMs', 'moduleMs')
summary['executionMeans'] = {key: sum(row['executionBreakdown'][key] for row in summary['reloads']) / 5 for key in keys}
summary['breakdownLimits'] = 'Module spans combine resolution, trust/read, compilation, guest evaluation and promise wait; not a pure eval measurement. All synchronous observer costs unquantified.'
(work / 'execution-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(dict(result='PASS', means=summary['means'], executionMeans=summary['executionMeans'],
    reloads=[dict(index=row['index'], execution=row['executionBreakdown']) for row in summary['reloads']]), indent=2))
