# One predeclared execution boundary diagnostic

Ranked predictions: preload/module preparation dominates; entry validation dominates;
or before/after plugin hooks dominate. Measure successful candidate execution at
those boundaries without disabling or changing any work, fixture, security rule,
original sampler or formal metric. One group, five original indexed reloads,
all initial readiness events and first samples retained. Synchronous output cost
is not quantified; dirty four-file source is diagnostic only. Restore exact
originals after source/patch/owned-process guards. Main production source untouched.
