from pathlib import Path

helpers = Path.cwd() / 'build/ticket37-config-sync-repair'
source = (helpers / 'archive-reload-phase-7d.py').read_text(encoding='utf-8')
source = source.replace('ticket37-reload-phase-7d', 'ticket37-reload-execution-7d')
source = source.replace('phase-summary.json', 'execution-summary.json').replace('reload-phase-evidence.zip', 'reload-execution-evidence.zip')
source = source.replace("'com/tkisor/nekojs/core/lifecycle/ReloadProgressTracker'", "'com/tkisor/nekojs/core/lifecycle/ReloadProgressTracker',\n                                'com/tkisor/nekojs/script/ScriptManager', 'com/tkisor/nekojs/script/ScriptExecutor'")
source = source.replace("'archive-reload-phase-7d.py'):", "'archive-reload-phase-7d.py', 'prepare-reload-execution-7d.py', 'run-reload-execution-7d.py',\n             'read-reload-execution-7d.py', 'restore-reload-execution-7d.py', 'archive-reload-execution-7d.py'):")
exec(compile(source, str(helpers / 'archive-reload-phase-7d.py'), 'exec'))
