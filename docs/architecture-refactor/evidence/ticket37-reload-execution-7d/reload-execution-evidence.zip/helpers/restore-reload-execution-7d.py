import hashlib
import json
import os
import subprocess
from pathlib import Path

project = Path.cwd().resolve()
owned = project / 'build/ticket37-perf-owned-ac810fa7'
work = project / 'build/ticket37-reload-execution-7d'
manifest = json.loads((work / 'manifest.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
assert json.loads((work / 'runner-exit.json').read_text())['exitCode'] == 0
assert json.loads((work / 'after-guard-exit.json').read_text())['exitCode'] == 0
assert sha(subprocess.check_output(['git', '-C', str(owned), 'diff'])) == manifest['instrumentationPatchSha256']
env = dict(os.environ)
env['PSModulePath'] = r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
with (work / 'restore-before-guard.txt').open('xb') as output:
    result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(work / 'guard.ps1')],
                            env=env, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
assert result.returncode == 0
for name, record in manifest['files'].items():
    path = owned / name
    original = (work / 'original' / name).read_bytes()
    assert path.resolve().is_relative_to(owned.resolve()) and not path.is_symlink()
    assert sha(path.read_bytes()) == record['instrumentedSha256'] and sha(original) == record['originalSha256']
    path.write_bytes(original)
assert not subprocess.check_output(['git', '-C', str(owned), 'status', '--porcelain'], text=True).strip()
(work / 'restored-source.json').write_text(json.dumps(dict(result='PASS', sourceRevision=manifest['sourceRevision'],
    sourceRestoredByteEqual=True, compiledDiagnosticCache='Retained locally; no official class binding inheritance until rebuilding')))
print('OWNED_DIAGNOSTIC_SOURCE_RESTORED=PASS')
