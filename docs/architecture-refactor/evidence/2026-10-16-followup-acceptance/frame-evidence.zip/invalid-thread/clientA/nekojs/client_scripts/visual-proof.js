const frameFs = require('node:fs');
const FrameMinecraft = Java.type('net.minecraft.client.Minecraft');
const FrameClientCompat = Java.type('com.tkisor.nekojs.platform.compat.McClientCompat');
const FrameThread = Java.type('java.lang.Thread');
const frameSignal = 'nekojs/data/visual-step.txt';
let lastFrameStep = '';
let reloadFrameFuture = null;
ClientEvents.postEffects(event => {
    event.register('ticket37_frame:inline_blur', { blurRadius: 16, blurRounds: 1 });
});
ClientEvents.tickPost(() => {
    const minecraft = FrameMinecraft.getInstance();
    if (minecraft.player === null || !frameFs.existsSync(frameSignal)) return;
    if (reloadFrameFuture !== null && reloadFrameFuture.isDone()) {
        console.info('FIRST-POST-FRAME-RESOURCE-RELOAD-COMPLETE');
        reloadFrameFuture = null;
    }
    const step = String(frameFs.readFileSync(frameSignal, 'utf8')).trim();
    if (step === lastFrameStep) return;
    lastFrameStep = step;
    if (step === 'close') {
        console.info('FIRST-POST-FRAME-OWNED-STOP');
        minecraft.stop();
        return;
    }
    if (step === 'reload') {
        console.info('FIRST-POST-FRAME-RESOURCE-RELOAD-REQUEST');
        reloadFrameFuture = minecraft.reloadResourcePacks();
        return;
    }
    if (!step.startsWith('clear-') && !step.startsWith('blur-')) return;
    minecraft.options.pauseOnLostFocus = false;
    FrameClientCompat.get().showScreen(null);
    const accepted = step.startsWith('blur-') ? PostEffects.set('ticket37_frame:inline_blur') : PostEffects.clear();
    const armed = { step, accepted, generation: PostEffects.activeGeneration(), current: PostEffects.current(),
        active: PostEffects.isActive(), setThread: String(FrameThread.currentThread().getName()),
        sameThread: minecraft.isSameThread() };
    console.info('FIRST-POST-FRAME-SET-RETURN ' + JSON.stringify(armed));
    frameFs.writeFileSync('nekojs/data/first-frame-arm.json', JSON.stringify(armed));
});
