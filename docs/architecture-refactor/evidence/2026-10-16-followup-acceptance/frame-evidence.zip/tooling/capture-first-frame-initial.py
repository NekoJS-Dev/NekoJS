import hashlib
import json
import re
import sys
import time
from pathlib import Path

root = Path('build/domain-first-post-frame-0965-2')
client = root / 'clientA'
step = sys.argv[1]
assert step == 'reload' or step.startswith(('clear-', 'blur-', 'retained-'))
before = set((client / 'screenshots').glob('*.png'))
initial_log = (client / 'stdout.log').read_text(encoding='utf-8', errors='replace')
initial_generations = [int(value) for value in re.findall(r'Installed client post-effect generation (\d+)', initial_log)]
initial_generation = max(initial_generations, default=-1)
if step.startswith('retained-'):
    assert 'Owned first-frame candidate rejection' in initial_log and 'phase=RELOAD_CANCEL' in initial_log
    signal = client / 'nekojs/data/first-frame-arm.json'
    pending = signal.with_suffix('.pending')
    pending.write_text(json.dumps(dict(step=step, noSetRequested=True,
        observedInstalledGeneration=initial_generation)), encoding='utf-8')
    pending.replace(signal)
else:
    signal = client / 'nekojs/data/visual-step.txt'
    pending = signal.with_suffix('.pending')
    pending.write_text(step + '\n', encoding='ascii')
    pending.replace(signal)
started = time.monotonic()
result = dict(step=step, verdict='NOTGREEN')
try:
    while time.monotonic() - started < 60:
        startup = (client / 'logs/nekojs/startup.log').read_text(encoding='utf-8', errors='replace')
        log = (client / 'logs/nekojs/client.log').read_text(encoding='utf-8', errors='replace')
        if step == 'reload':
            runtime_log = (client / 'stdout.log').read_text(encoding='utf-8', errors='replace')
            generations = [int(value) for value in re.findall(r'Installed client post-effect generation (\d+)', runtime_log)]
            if generations and max(generations) > initial_generation:
                result.update(verdict='PASS', resourceReloadScriptGenerationChanged=True,
                    beforeGeneration=initial_generation, afterGeneration=max(generations))
                break
        else:
            requests = [json.loads(match.group(1)) for match in re.finditer(
                r'FIRST-POST-FRAME-REQUEST (\{[^\r\n]+\})', startup)]
            ready = [json.loads(match.group(1)) for match in re.finditer(
                r'FIRST-POST-FRAME-IMAGE-READY (\{[^\r\n]+\})', startup)]
            request = next((row for row in requests if row['step'] == step), None)
            image_ready = next((row for row in ready if row['request']['step'] == step), None)
            files = set((client / 'screenshots').glob('*.png')) - before
            if request and image_ready and len(files) == 1:
                path = files.pop()
                if path.stat().st_size < 100:
                    time.sleep(0.1)
                    continue
                assert request['sameThread'], request
                if step.startswith('retained-'):
                    assert request['noSetRequested'] and request['observedInstalledGeneration'] == initial_generation
                else:
                    assert request['accepted'] and request['active'] is step.startswith('blur-'), request
                result.update(verdict='PASS', request=request, imageReady=image_ready,
                    screenshot=dict(file=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                                    bytes=path.stat().st_size), displayPresentVerified=False)
                break
        assert not (client / 'exit.json').exists(), 'Owned client exited before capture'
        time.sleep(0.1)
    assert result['verdict'] == 'PASS', 'No completed first-Post capture for ' + step
finally:
    result['seconds'] = round(time.monotonic() - started, 3)
    with (root / 'captures.jsonl').open('a', encoding='utf-8') as output:
        output.write(json.dumps(result) + '\n')
    print(json.dumps(result), flush=True)
