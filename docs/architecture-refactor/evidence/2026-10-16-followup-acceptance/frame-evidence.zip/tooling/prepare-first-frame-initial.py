import hashlib
import json
import shutil
import socket
import subprocess
import uuid
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/domain-first-post-frame-0965-2'
source = project / 'build/domain-closeout-reviewed-installed/26.2.0'
old = project / 'build/ticket37-current-client-7d/clientA'
assert not root.exists()
for port in [26801, 26802, 26803]:
    with socket.socket() as guard:
        guard.bind(('127.0.0.1', port))
preparation = json.loads((source.parent / 'preparation-manifest.json').read_text())
node = next(row for row in preparation['nodes'] if row['node'] == '26.2.0')
for name in ['server', 'clientA']:
    directory = root / name
    shutil.copytree(source / 'mods', directory / 'mods')
    for folder in ['config', 'startup_scripts']:
        shutil.copytree(source / 'nekojs' / folder, directory / 'nekojs' / folder)
    artifact = directory / 'mods' / node['artifact']
    assert hashlib.sha256(artifact.read_bytes()).hexdigest() == node['sha256']
server = root / 'server'
(server / 'libraries').symlink_to((source / 'libraries').resolve(), target_is_directory=True)
(server / 'nekojs/server_scripts').mkdir()
(server / 'eula.txt').write_text('eula=true\n')
(server / 'server.properties').write_text('\n'.join([
    'server-ip=127.0.0.1', 'server-port=26801', 'enable-rcon=true', 'rcon.port=26802',
    'rcon.password=' + uuid.uuid4().hex, 'online-mode=false', 'level-name=owned-first-frame-world',
    'gamemode=creative', 'difficulty=peaceful', 'view-distance=3', 'simulation-distance=3',
    'max-players=1', 'spawn-protection=0', 'generate-structures=false', 'level-type=minecraft:flat']) + '\n')
client = root / 'clientA'
shutil.copytree(old / 'owned-natives', client / 'owned-natives')
(client / 'nekojs/client_scripts').mkdir()
(client / 'nekojs/data').mkdir()
(client / 'options.txt').write_text(
    'enableVsync:false\nmaxFps:30\nrenderDistance:3\nsimulationDistance:3\n'
    'entityDistanceScaling:0.5\nfullscreen:false\nskipMultiplayerWarning:true\npauseOnLostFocus:false\n')
startup = r'''const frameFs = require('node:fs');
const FrameMinecraft = Java.type('net.minecraft.client.Minecraft');
const FrameScreenshot = Java.type('net.minecraft.client.Screenshot');
const armPath = 'nekojs/data/first-frame-arm.json';
let postFrame = 0;
let captureRequest = null;
NativeEvents.onEvent('net.neoforged.neoforge.client.event.RenderFrameEvent$Post', () => {
    postFrame++;
    const minecraft = FrameMinecraft.getInstance();
    if (minecraft.level === null || !frameFs.existsSync(armPath)) return;
    const armed = JSON.parse(String(frameFs.readFileSync(armPath, 'utf8')));
    if (armed.consumed) return;
    frameFs.writeFileSync(armPath, JSON.stringify({ consumed: true, step: armed.step }));
    captureRequest = { ...armed, postFrame, sameThread: minecraft.isSameThread() };
    console.info('FIRST-POST-FRAME-REQUEST ' + JSON.stringify(captureRequest));
    FrameScreenshot.grab(minecraft, false);
});
NativeEvents.onEvent('net.neoforged.neoforge.client.event.ScreenshotEvent', () => {
    console.info('FIRST-POST-FRAME-IMAGE-READY ' + JSON.stringify({ request: captureRequest,
        observedPostFrame: postFrame, sameThread: FrameMinecraft.getInstance().isSameThread() }));
});
console.info('FIRST-POST-FRAME-LISTENERS-READY');
'''
(client / 'nekojs/startup_scripts/first-post-frame.js').write_text(startup, encoding='utf-8')
fixture = r'''const frameFs = require('node:fs');
const FrameMinecraft = Java.type('net.minecraft.client.Minecraft');
const FrameClientCompat = Java.type('com.tkisor.nekojs.platform.compat.McClientCompat');
const frameSignal = 'nekojs/data/visual-step.txt';
let lastFrameStep = '';
let reloadFrameFuture = null;
ClientEvents.postEffects(event => {
    event.register('ticket37_frame:inline_blur', { blurRadius: 16, blurRounds: 1 });
});
ClientEvents.tickPost(() => {
    const minecraft = FrameMinecraft.getInstance();
    if (minecraft.player === null || !frameFs.existsSync(frameSignal)) return;
    if (reloadFrameFuture !== null && reloadFrameFuture.isDone()) {
        console.info('FIRST-POST-FRAME-RESOURCE-RELOAD-COMPLETE');
        reloadFrameFuture = null;
    }
    const step = String(frameFs.readFileSync(frameSignal, 'utf8')).trim();
    if (step === lastFrameStep) return;
    lastFrameStep = step;
    if (step === 'close') {
        console.info('FIRST-POST-FRAME-OWNED-STOP');
        minecraft.stop();
        return;
    }
    if (step === 'reload') {
        console.info('FIRST-POST-FRAME-RESOURCE-RELOAD-REQUEST');
        reloadFrameFuture = minecraft.reloadResourcePacks();
        return;
    }
    if (!step.startsWith('clear-') && !step.startsWith('blur-')) return;
    minecraft.options.pauseOnLostFocus = false;
    FrameClientCompat.get().showScreen(null);
    const accepted = step.startsWith('blur-') ? PostEffects.set('ticket37_frame:inline_blur') : PostEffects.clear();
    const armed = { step, accepted, generation: PostEffects.activeGeneration(), current: PostEffects.current(),
        active: PostEffects.isActive(), sameThread: minecraft.isSameThread() };
    console.info('FIRST-POST-FRAME-SET-RETURN ' + JSON.stringify(armed));
    frameFs.writeFileSync('nekojs/data/first-frame-arm.json', JSON.stringify(armed));
});
'''
(client / 'nekojs/client_scripts/visual-proof.js').write_text(fixture, encoding='utf-8')
helpers = project / 'build/ticket37-config-sync-repair'
for source_name, output_name in [('run-current-client-7d.py', 'run-first-frame.py'),
                                 ('rcon-current-client-7d.py', 'rcon-first-frame.py'),
                                 ('setup-current-scene-7d.py', 'setup-first-frame.py')]:
    text = (helpers / source_name).read_text(encoding='utf-8')
    text = text.replace('ticket37-current-client-7d', root.name).replace('25991', '26801')
    text = text.replace('NekoClient7d', 'NekoFirstFrame').replace('rcon-current-client-7d.py', 'rcon-first-frame.py')
    if source_name.startswith('setup-'):
        text = text.replace(", 'tp NekoFirstFrameB 5.5 72 -12.5 0 0'", '')
    text = text.replace("{'A': 9876, 'B': 9875}", "{'A': 26803, 'B': 26804}")
    (helpers / output_name).write_text(text, encoding='utf-8')
(root / 'preparation.json').write_text(json.dumps(dict(
    checkoutRevision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    productionBase=preparation['sourceRevision'], productionPatchSha256=preparation['productionPatchSha256'],
    node=node, serverPort=26801, rconPort=26802, freshWorld=True, privateProfiles=True,
    sharedReadOnlyLauncherCache='ticket37-config-sync-installed-attempt1/launcherA/.minecraft',
    boundary='first synchronous RenderFrameEvent.Post after set return; not display present',
    fixtureHashes={str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest()
                   for directory in [server, client] for path in (directory / 'nekojs').rglob('*.js')}
), indent=2) + '\n', encoding='utf-8')
print('PREPARED', root, node['sha256'])
