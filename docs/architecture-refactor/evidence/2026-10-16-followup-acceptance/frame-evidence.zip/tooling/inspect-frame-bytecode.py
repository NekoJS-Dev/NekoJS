import hashlib
import json
import subprocess
from pathlib import Path

root = Path('build/domain-first-post-frame-0965-3/bytecode')
root.mkdir()
libraries = Path('build/ticket37-config-sync-installed-attempt1/launcherA/.minecraft/libraries')
inputs = {
    'minecraft': ('net/neoforged/minecraft-client-patched/26.2.0.75/minecraft-client-patched-26.2.0.75.jar',
        'f355f0045aafb6b618d46e7546efdd409b959f8477fe4c0f3e8840223b92ccea',
        ['net.minecraft.client.Minecraft', 'net.minecraft.client.gui.Gui',
         'net.minecraft.client.renderer.GameRenderer', 'net.minecraft.client.Screenshot']),
    'neoforge': ('net/neoforged/neoforge/26.2.0.75/neoforge-26.2.0.75-universal.jar',
        '94457e8680861206aac46f0136aecd421b50ded0bdb96fc84400af7c0dbde0d8',
        ['net.neoforged.neoforge.client.ClientHooks',
         'net.neoforged.neoforge.client.event.RenderFrameEvent$Post']),
    'bus': ('net/neoforged/bus/8.0.5/bus-8.0.5.jar',
        '705e24f37752809499a5cd0c7dd31eaabf3d933c5d3b2060168e94e9ef62593a',
        ['net.neoforged.bus.EventBus', 'net.neoforged.bus.ConsumerEventHandler'])
}
manifest = []
for name, (relative, expected, classes) in inputs.items():
    jar = libraries / relative
    digest = hashlib.sha256(jar.read_bytes()).hexdigest()
    assert digest == expected, (name, digest)
    for klass in classes:
        command = ['C:/Program Files/Java/jdk-25.0.2/bin/javap.exe', '-p', '-c', '-classpath', str(jar), klass]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert result.returncode == 0 and not result.stderr, klass
        (root / (klass + '.txt')).write_bytes(result.stdout)
    manifest.append(dict(name=name, library=relative, sha256=digest, classes=classes, flags=['-p', '-c']))
(root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print('PASS: exact fixture-cache jar hashes and eight disassembled classes')
