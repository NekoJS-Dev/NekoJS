import hashlib
import json
import shutil
import zipfile
from pathlib import Path

evidence = Path('docs/architecture-refactor/evidence/2026-10-16-followup-acceptance')
root = Path('build/domain-first-post-frame-0965-3')
archive = evidence / 'frame-evidence.zip'
assert not archive.exists()
entries = {}


def add(path, name):
    data = path.read_bytes()
    inspected = data
    if path.suffix == '.py':
        inspected = inspected.replace(b"'rcon." + b"password=' + uuid.uuid4().hex", b'generated-credential')
    assert b'rcon.' + b'password=' not in inspected, path
    entries[name] = data


captures = [json.loads(line) for line in (root / 'captures.jsonl').read_text().splitlines()]
assert len(captures) == 9 and all(row['verdict'] == 'PASS' for row in captures)
for row in captures:
    if 'request' in row:
        assert row['request']['sameThread'] and row['request']['overlayPresent'] is False
        assert row['displayPresentVerified'] is False
        path = root / 'clientA/screenshots' / row['screenshot']['file']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['screenshot']['sha256']
for phase in ['server', 'clientA']:
    assert json.loads((root / phase / 'exit.json').read_text())['exitCode'] == 0
for label, directory in [('accepted', root),
                         ('invalid-thread', Path('build/domain-first-post-frame-0965')),
                         ('intermediate', Path('build/domain-first-post-frame-0965-2'))]:
    for name in ['preparation.json', 'captures.jsonl', 'failed-verdict.json', 'rcon.jsonl']:
        if (directory / name).exists():
            add(directory / name, label + '/' + name)
    for phase in ['server', 'clientA']:
        for name in ['stdout.log', 'stderr.log', 'exit.json']:
            add(directory / phase / name, label + '/' + phase + '/' + name)
        for path in (directory / phase / 'logs/nekojs').rglob('*.log'):
            add(path, label + '/' + phase + '/logs/nekojs/' + path.relative_to(directory / phase / 'logs/nekojs').as_posix())
        for folder in ['startup_scripts', 'client_scripts']:
            for path in (directory / phase / 'nekojs' / folder).rglob('*'):
                if path.is_file() and (path.suffix == '.js' or path.name.endswith('.rejected')):
                    add(path, label + '/' + phase + '/nekojs/' + folder + '/' + path.relative_to(directory / phase / 'nekojs' / folder).as_posix())
        for path in (directory / phase / 'screenshots').glob('*.png'):
            add(path, label + '/' + phase + '/screenshots/' + path.name)
for path in (root / 'bytecode').iterdir():
    add(path, 'bytecode/' + path.name)
for name in ['NativeEventsJS.java', 'NekoJSCorePlugin.java']:
    path = next(Path('src/main/java').rglob(name))
    add(path, 'production-sources/' + name)
for name in ['prepare-first-frame.py', 'prepare-first-frame-initial.py', 'capture-first-frame.py',
             'capture-first-frame-initial.py', 'inspect-frame-bytecode.py', 'archive-frame.py']:
    add(Path('build/domain-closeout-tooling') / name, 'tooling/' + name)
for name in ['run-first-frame.py', 'rcon-first-frame.py', 'setup-first-frame.py']:
    add(Path('build/ticket37-config-sync-repair') / name, 'tooling/' + name)
for path in Path('build/domain-closeout-tooling').glob('first-frame*.log'):
    add(path, 'tooling/' + path.name)
summary = dict(verdict='PASS', scope='NeoForge 26.2.0.75, exact 0965 production classes, visible-world render target',
               production=json.loads((root / 'preparation.json').read_text()), captures=captures,
               clientExit=0, serverExit=0, displayPresentVerified=False,
               excluded=['invalid-thread trial', 'unsupported custom-id activation',
                         'intermediate clear-after and clear-recovery overlay images'],
               otherClientNodes='not run in this trial')
(evidence / 'frame-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
add(evidence / 'frame-summary.json', 'frame-summary.json')
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(entries.items()):
        output.writestr(name, data)
manifest = dict(archive=archive.name, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                entries={name:hashlib.sha256(data).hexdigest() for name,data in sorted(entries.items())})
(evidence / 'frame-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for step, filename in [('clear-before', 'frame-clear.png'), ('blur-before', 'frame-blur.png')]:
    row = next(row for row in captures if row['step'] == step)
    destination = evidence / filename
    assert not destination.exists()
    shutil.copyfile(root / 'clientA/screenshots' / row['screenshot']['file'], destination)
print('PASS:', len(entries), 'entries;', archive.stat().st_size, 'bytes')
