const frameFs = require('node:fs');
const FrameMinecraft = Java.type('net.minecraft.client.Minecraft');
const FrameClientCompat = Java.type('com.tkisor.nekojs.platform.compat.McClientCompat');
const frameSignal = 'nekojs/data/visual-step.txt';
let lastFrameStep = '';
ClientEvents.postEffects(event => {
    event.register('minecraft:invert', { blurRadius: 16, blurRounds: 1 });
});
ClientEvents.tickPost(() => {
    const minecraft = FrameMinecraft.getInstance();
    if (minecraft.player === null || !frameFs.existsSync(frameSignal)) return;
    const step = String(frameFs.readFileSync(frameSignal, 'utf8')).trim();
    if (step === lastFrameStep) return;
    lastFrameStep = step;
    if (step === 'close') {
        console.info('FIRST-POST-FRAME-OWNED-STOP');
        minecraft.stop();
        return;
    }
    if (step === 'reload') {
        frameFs.writeFileSync(frameSignal, 'idle\n');
        console.info('FIRST-POST-FRAME-RESOURCE-RELOAD-REQUEST');
        minecraft.reloadResourcePacks();
        return;
    }
    if (!step.startsWith('clear-') && !step.startsWith('blur-')) return;
    minecraft.options.pauseOnLostFocus = false;
    FrameClientCompat.get().showScreen(null);
    const accepted = step.startsWith('blur-') ? PostEffects.set('minecraft:invert') : PostEffects.clear();
    const armed = { step, accepted, generation: PostEffects.activeGeneration(), current: PostEffects.current(),
        active: PostEffects.isActive(), sameThread: minecraft.isSameThread() };
    console.info('FIRST-POST-FRAME-SET-RETURN ' + JSON.stringify(armed));
    frameFs.writeFileSync('nekojs/data/first-frame-arm.json', JSON.stringify(armed));
});
