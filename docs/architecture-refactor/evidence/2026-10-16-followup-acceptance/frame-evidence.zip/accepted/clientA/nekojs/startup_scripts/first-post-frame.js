const frameFs = require('node:fs');
const FrameMinecraft = Java.type('net.minecraft.client.Minecraft');
const FrameScreenshot = Java.type('net.minecraft.client.Screenshot');
const armPath = 'nekojs/data/first-frame-arm.json';
let postFrame = 0;
let captureRequest = null;
NativeEvents.onEvent('net.neoforged.neoforge.client.event.RenderFrameEvent$Post', () => {
    postFrame++;
    const minecraft = FrameMinecraft.getInstance();
    if (minecraft.level === null || !frameFs.existsSync(armPath)) return;
    const armed = JSON.parse(String(frameFs.readFileSync(armPath, 'utf8')));
    if (armed.consumed) return;
    frameFs.writeFileSync(armPath, JSON.stringify({ consumed: true, step: armed.step }));
    captureRequest = { ...armed, postFrame, sameThread: minecraft.isSameThread(),
        overlayPresent: minecraft.gui.overlay() !== null };
    console.info('FIRST-POST-FRAME-REQUEST ' + JSON.stringify(captureRequest));
    FrameScreenshot.grab(minecraft, false);
});
NativeEvents.onEvent('net.neoforged.neoforge.client.event.ScreenshotEvent', () => {
    console.info('FIRST-POST-FRAME-IMAGE-READY ' + JSON.stringify({ request: captureRequest,
        observedPostFrame: postFrame, sameThread: FrameMinecraft.getInstance().isSameThread() }));
});
console.info('FIRST-POST-FRAME-LISTENERS-READY');
