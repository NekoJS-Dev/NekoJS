import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.api.event.ScriptBindingSchema;
import com.tkisor.nekojs.core.compiler.EventCallbackSourceValidator;
import com.tkisor.nekojs.core.compiler.GlobalBindingMemberValidator;
import com.tkisor.nekojs.core.compiler.ScriptSourcePreflight;
import com.tkisor.nekojs.script.ScriptTypeEnv;
import com.tkisor.nekojs.testfixture.TestPlatformInit;
import com.google.gson.Gson;
import java.nio.file.*;
import java.util.*;

public final class PreflightBenchmark {
    record Source(Path path, String text) {}
    static List<Source> sources;
    static ScriptBindingSchema.View schema;
    static long run(boolean shared, int rounds) {
        long started = System.nanoTime();
        for (int i = 0; i < rounds; i++) for (Source source : sources) {
            if (shared) ScriptSourcePreflight.validate(source.path(), source.text(), schema);
            else {
                GlobalBindingMemberValidator.validate(source.path(), source.text(), schema);
                EventCallbackSourceValidator.validate(source.path(), source.text(), schema);
            }
        }
        return System.nanoTime() - started;
    }
    public static void main(String[] args) throws Exception {
        TestPlatformInit.ensureInitialized(Path.of(args[1], "platform"));
        Path directory = Path.of(args[0]);
        sources = new ArrayList<>();
        try (var files = Files.walk(directory)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".js")).sorted().toList())
                sources.add(new Source(ScriptTypeEnv.scriptsDir(ScriptType.SERVER).resolve(directory.relativize(file)), Files.readString(file)));
        }
        Map<String, ScriptBindingSchema.BindingMembers> bindings = new LinkedHashMap<>();
        for (String name : List.of("ServerEvents", "Item", "Block", "Utils", "Platform", "Java", "global", "shared"))
            bindings.put(name, new ScriptBindingSchema.BindingMembers(Set.of(), Set.of(), true));
        schema = new ScriptBindingSchema.View(bindings, Set.of("console", "require", "process", "Math", "JSON", "Date", "String", "Number", "Object", "Array", "BigInt", "parseInt", "setTimeout", "globalThis", "eval"), diagnostic -> {});
        run(false, 1000);
        run(true, 1000);
        Gson gson = new Gson();
        for (int pair = 0; pair < 10; pair++) {
            long separate, shared;
            if (pair % 2 == 0) { separate = run(false, 200); shared = run(true, 200); }
            else { shared = run(true, 200); separate = run(false, 200); }
            System.out.println(gson.toJson(Map.of("pair", pair, "separateMs", separate/1e6, "sharedMs", shared/1e6, "rounds", 200, "files", sources.size(), "first", pair % 2 == 0 ? "separate" : "shared")));
        }
    }
}
