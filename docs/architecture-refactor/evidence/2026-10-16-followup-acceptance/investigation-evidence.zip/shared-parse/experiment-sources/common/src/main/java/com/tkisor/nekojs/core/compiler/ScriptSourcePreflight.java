package com.tkisor.nekojs.core.compiler;

import com.tkisor.nekojs.api.event.ScriptBindingSchema;

import java.nio.file.Path;
import java.util.Map;

/** Runs binding and callback checks against one source parse and the current generation's schema. */
public final class ScriptSourcePreflight {
    private ScriptSourcePreflight() {}

    public static void validate(Path file, String source, ScriptBindingSchema.View view) {
        if (file == null || source == null || source.isEmpty()) return;
        Map<String, ScriptBindingSchema.BindingMembers> schema = ScriptBindingSchema.schemaForPath(file, view);
        if (schema.isEmpty()) return;

        ValNode.Block ast;
        try {
            ast = ValParser.parse(source);
        } catch (Throwable failure) {
            GlobalBindingMemberValidator.reportParseFailure(file, failure);
            EventCallbackSourceValidator.reportParseFailure(file, failure);
            return;
        }
        GlobalBindingMemberValidator.validateParsed(file, source, view, schema, ast);
        EventCallbackSourceValidator.validateParsed(file, source, view, schema, ast);
    }
}
