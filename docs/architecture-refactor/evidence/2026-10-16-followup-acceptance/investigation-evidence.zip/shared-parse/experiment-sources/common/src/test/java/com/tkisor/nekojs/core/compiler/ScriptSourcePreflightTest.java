package com.tkisor.nekojs.core.compiler;

import com.tkisor.nekojs.api.JavaMemberIndex;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.api.event.ScriptBindingSchema;
import com.tkisor.nekojs.api.event.ScriptErrorReporter;
import com.tkisor.nekojs.script.ScriptTypeEnv;
import com.tkisor.nekojs.testfixture.TestPlatformInit;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScriptSourcePreflightTest {
    private final List<String> reported = new ArrayList<>();

    @BeforeEach
    void initialize() {
        TestPlatformInit.ensureInitialized();
        ScriptErrorReporter.set((type, kind, failure) -> reported.add(failure.getMessage()));
    }

    @AfterEach
    void releaseReporter() {
        ScriptErrorReporter.set(ScriptErrorReporter.Reporter.NOOP);
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "Utils.serverTel('x'); Registry.item('x', build => { build.maxStackSiz(8); });",
            "function outer() { Registry.item('x', build => { build.maxStackSiz(8); }); Utils.serverTel('x'); }",
            "Registry.item('x', build => { build.maxStackSize(8); }); Utils.serverTell('x');"
    })
    void sharedParsePreservesBothChecksAndDiagnosticOrder(String source) {
        Class<?> helper = GlobalBindingMemberValidatorTest.UtilsJS.class;
        Class<?> registry = EventCallbackSourceValidatorTest.RegistryLikeBinding.class;
        var view = new ScriptBindingSchema.View(Map.of(
                "Utils", new ScriptBindingSchema.BindingMembers(JavaMemberIndex.allMembersOf(helper), Set.of(helper)),
                "Registry", new ScriptBindingSchema.BindingMembers(JavaMemberIndex.allMembersOf(registry), Set.of(registry))),
                Set.of("console", "Math", "globalThis"));
        Path file = ScriptTypeEnv.scriptsDir(ScriptType.SERVER).resolve("shared-preflight.js");

        GlobalBindingMemberValidator.validate(file, source, view);
        EventCallbackSourceValidator.validate(file, source, view);
        List<String> separate = List.copyOf(reported);
        reported.clear();
        ScriptSourcePreflight.validate(file, source, view);
        assertEquals(separate, reported);
        if (source.contains("serverTel('")) {
            assertTrue(reported.stream().anyMatch(message -> message.contains("serverTel")), reported.toString());
            assertTrue(reported.stream().anyMatch(message -> message.contains("maxStackSiz")), reported.toString());
        } else {
            assertTrue(reported.isEmpty(), reported.toString());
        }
    }

    @Test
    void unchangedSourceUsesEachGenerationsBindingSchema() {
        Path file = ScriptTypeEnv.scriptsDir(ScriptType.SERVER).resolve("generation-preflight.js");
        String source = "Helper.newMember();";
        var previous = new ScriptBindingSchema.View(Map.of(
                "Helper", new ScriptBindingSchema.BindingMembers(Set.of("oldMember"))), Set.of("console"));
        var candidate = new ScriptBindingSchema.View(Map.of(
                "Helper", new ScriptBindingSchema.BindingMembers(Set.of("newMember"))), Set.of("console"));

        ScriptSourcePreflight.validate(file, source, previous);
        assertFalse(reported.isEmpty());
        reported.clear();
        ScriptSourcePreflight.validate(file, source, candidate);
        assertTrue(reported.isEmpty(), reported.toString());
        ScriptSourcePreflight.validate(file, source, previous);
        assertFalse(reported.isEmpty());
    }
}
