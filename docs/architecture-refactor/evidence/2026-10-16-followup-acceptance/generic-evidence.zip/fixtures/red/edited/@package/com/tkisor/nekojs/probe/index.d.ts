declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptGenericAdapterTest$Box<T> {
        constructor(value: T);
        get(): T;
    }

    export class $TypeScriptGenericAdapterTest$Payload {
        constructor();
        name(): string;
    }

    export class $TypeScriptGenericAdapterTest$Alternate extends $TypeScriptGenericAdapterTest$Payload {
        constructor();
        alternate(): number;
    }

    export class $TypeScriptGenericAdapterTest$Bounded<T extends $TypeScriptGenericAdapterTest$Alternate> {
        constructor(value: T);
        get(): T;
    }

    export class $TypeScriptGenericAdapterTest$Recursive<T extends $TypeScriptGenericAdapterTest$Recursive<T>> {
        constructor();
        get(): T;
    }

    export class $TypeScriptGenericAdapterTest$Node extends $TypeScriptGenericAdapterTest$Recursive<$TypeScriptGenericAdapterTest$Node> {
        constructor();
        label(): string;
    }

    export class $TypeScriptGenericAdapterTest$Calls {
        constructor();
        bounded(value: $TypeScriptGenericAdapterTest$Bounded_): void;
        box(value: $TypeScriptGenericAdapterTest$Box_): void;
        recursive(value: $TypeScriptGenericAdapterTest$Recursive_): void;
    }

    export type $TypeScriptGenericAdapterTest$Box_ = $TypeScriptGenericAdapterTest$Box | string | $TypeScriptGenericAdapterTest$Box_[] | { next: $TypeScriptGenericAdapterTest$Box_ };
    export type $TypeScriptGenericAdapterTest$Bounded_ = $TypeScriptGenericAdapterTest$Bounded | string | $TypeScriptGenericAdapterTest$Bounded_[] | { next: $TypeScriptGenericAdapterTest$Bounded_ };
    export type $TypeScriptGenericAdapterTest$Recursive_ = $TypeScriptGenericAdapterTest$Recursive | string | $TypeScriptGenericAdapterTest$Recursive_[] | { next: $TypeScriptGenericAdapterTest$Recursive_ };
}
