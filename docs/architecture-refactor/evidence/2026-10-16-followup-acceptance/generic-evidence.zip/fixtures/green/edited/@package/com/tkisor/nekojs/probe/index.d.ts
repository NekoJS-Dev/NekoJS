declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptGenericAdapterTest$Box<T> {
        constructor(value: T);
        get(): T;
    }

    export class $TypeScriptGenericAdapterTest$Payload {
        constructor();
        name(): string;
    }

    export class $TypeScriptGenericAdapterTest$Alternate extends $TypeScriptGenericAdapterTest$Payload {
        constructor();
        alternate(): number;
    }

    export class $TypeScriptGenericAdapterTest$Bounded<T extends $TypeScriptGenericAdapterTest$Alternate> {
        constructor(value: T);
        get(): T;
    }

    export class $TypeScriptGenericAdapterTest$Recursive<T extends $TypeScriptGenericAdapterTest$Recursive<T>> {
        constructor();
        get(): T;
    }

    export class $TypeScriptGenericAdapterTest$Node extends $TypeScriptGenericAdapterTest$Recursive<$TypeScriptGenericAdapterTest$Node> {
        constructor();
        label(): string;
    }

    export class $TypeScriptGenericAdapterTest$Calls {
        constructor();
        bounded(value: $TypeScriptGenericAdapterTest$Bounded_<$TypeScriptGenericAdapterTest$Alternate>): void;
        box(value: $TypeScriptGenericAdapterTest$Box_<string>): void;
        recursive(value: $TypeScriptGenericAdapterTest$Recursive_<$TypeScriptGenericAdapterTest$Node>): void;
    }

    export type $TypeScriptGenericAdapterTest$Box_<T = any> = $TypeScriptGenericAdapterTest$Box<T> | string | $TypeScriptGenericAdapterTest$Box_<T>[] | { next: $TypeScriptGenericAdapterTest$Box_<T> };
    export type $TypeScriptGenericAdapterTest$Bounded_<T extends $TypeScriptGenericAdapterTest$Alternate = any> = $TypeScriptGenericAdapterTest$Bounded<T> | string | $TypeScriptGenericAdapterTest$Bounded_<T>[] | { next: $TypeScriptGenericAdapterTest$Bounded_<T> };
    export type $TypeScriptGenericAdapterTest$Recursive_<T extends $TypeScriptGenericAdapterTest$Recursive<T> = any> = $TypeScriptGenericAdapterTest$Recursive<T> | string | $TypeScriptGenericAdapterTest$Recursive_<T>[] | { next: $TypeScriptGenericAdapterTest$Recursive_<T> };
}
