import { $TypeScriptGenericAdapterTest$Box as Box,
    $TypeScriptGenericAdapterTest$Box_ as BoxInput,
    $TypeScriptGenericAdapterTest$Bounded as Bounded,
    $TypeScriptGenericAdapterTest$Bounded_ as BoundedInput,
    $TypeScriptGenericAdapterTest$Recursive_ as RecursiveInput,
    $TypeScriptGenericAdapterTest$Payload as Payload,
    $TypeScriptGenericAdapterTest$Alternate as Alternate,
    $TypeScriptGenericAdapterTest$Node as Node,
    $TypeScriptGenericAdapterTest$Calls as Calls } from 'java:com/tkisor/nekojs/probe';
declare const calls: Calls;
calls.box(new Box('value'));
calls.box('encoded');
calls.box([new Box('value')]);
calls.box({ next: new Box('value') });
const raw: BoxInput = new Box(42);
const exact: BoxInput<string> = new Box('value');
// @ts-expect-error Explicit arguments preserve the host value type.
calls.box(new Box(42));
// @ts-expect-error Nested Self forwards the same host argument.
calls.box([new Box(42)]);
// @ts-expect-error Object Self forwards the same host argument.
calls.box({ next: new Box(42) });
// @ts-expect-error Direct alias uses retain their explicit argument.
const wrong: BoxInput<string> = new Box(42);
calls.bounded(new Bounded(new Alternate()));
// @ts-expect-error The target's upper bound is retained.
declare const invalidBound: BoundedInput<string>;
declare const recursive: RecursiveInput<Node>;
calls.recursive(recursive);
// @ts-expect-error Recursive bounds are retained.
declare const invalidRecursive: RecursiveInput<Payload>;
// @ts-expect-error The edited bound replaces the reflected one.
declare const baseBound: BoundedInput<Payload>;
