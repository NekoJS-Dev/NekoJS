declare module 'raw-input-fixture' {
    export interface $TypeScriptRawInputTest$Listener {
        listen(): void;
    }
    export class $TypeScriptRawInputTest$Payload implements $TypeScriptRawInputTest$Listener {
        constructor();
        listen(): void;
    }
    export class $TypeScriptRawInputTest$Raw<T extends $TypeScriptRawInputTest$Listener> {
        constructor();
        value: T;
    }
    export class $TypeScriptRawInputTest$Api {
        constructor();
        array(values: $TypeScriptRawInputTest$Raw[][]): void;
        edited(value: $TypeScriptRawInputTest$Raw<$TypeScriptRawInputTest$Payload>): void;
        raw(value: $TypeScriptRawInputTest$Raw): void;
        typed(value: $TypeScriptRawInputTest$Raw<$TypeScriptRawInputTest$Payload>): void;
    }
}
