import type { $TypeScriptRawInputTest$Api as Api, $TypeScriptRawInputTest$Raw as Raw, $TypeScriptRawInputTest$Payload as Payload } from 'raw-input-fixture';
declare const api: Api;
api.raw({value: 1});
api.array([[{value: 1}]]);
const valid: Raw<Payload> = {value: {listen() {}}};
api.typed(valid);
api.edited(valid);
// @ts-expect-error Explicit host arguments retain their member types.
api.typed({value: 1});
// @ts-expect-error An edited slot must not regain reflection's raw erasure.
api.edited({value: 1});
// @ts-expect-error Raw use sites do not remove the declared bound.
type Invalid = Raw<number>;
