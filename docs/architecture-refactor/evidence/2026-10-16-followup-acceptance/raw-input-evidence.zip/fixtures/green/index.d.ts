declare module 'raw-input-fixture' {
    export interface $TypeScriptRawInputTest$Listener {
        listen(): void;
    }
    export class $TypeScriptRawInputTest$Payload implements $TypeScriptRawInputTest$Listener {
        constructor();
        listen(): void;
    }
    export class $TypeScriptRawInputTest$Raw<T extends $TypeScriptRawInputTest$Listener> {
        constructor();
        value: T;
    }
    export class $TypeScriptRawInputTest$Pair<L, R> {
        constructor();
        first: L;
        second: R;
    }
    export interface $TypeScriptRawInputTest$Mapper<T, R> {
        apply(value: T): R;
    }
    export class $TypeScriptRawInputTest$Api {
        constructor();
        array(values: $TypeScriptRawInputTest$Raw<any>[][]): void;
        callback(value: $TypeScriptRawInputTest$Mapper_<$TypeScriptRawInputTest$Raw<any>, $TypeScriptRawInputTest$Payload, $TypeScriptRawInputTest$Raw<any>, $TypeScriptRawInputTest$Payload>): void;
        edited(value: $TypeScriptRawInputTest$Raw<$TypeScriptRawInputTest$Payload>): void;
        nested(value: $TypeScriptRawInputTest$Pair<$TypeScriptRawInputTest$Raw<any>, $TypeScriptRawInputTest$Payload>): void;
        raw(value: $TypeScriptRawInputTest$Raw<any>): void;
        typedCallback(value: $TypeScriptRawInputTest$Mapper_<$TypeScriptRawInputTest$Raw<$TypeScriptRawInputTest$Payload>, $TypeScriptRawInputTest$Payload, $TypeScriptRawInputTest$Raw<$TypeScriptRawInputTest$Payload>, $TypeScriptRawInputTest$Payload>): void;
        typed(value: $TypeScriptRawInputTest$Raw<$TypeScriptRawInputTest$Payload>): void;
        wildcard(value: $TypeScriptRawInputTest$Pair<$TypeScriptRawInputTest$Raw<any>[], $TypeScriptRawInputTest$Payload>): void;
    }
    export type $TypeScriptRawInputTest$Mapper_<Host0 = any, Host1 = any, CallbackArg0 = Host0, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($TypeScriptRawInputTest$Mapper<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
}
