import type { $TypeScriptRawInputTest$Api as Api, $TypeScriptRawInputTest$Raw as Raw, $TypeScriptRawInputTest$Payload as Payload } from 'raw-input-fixture';
declare const api: Api;
api.raw({value: 1});
api.array([[{value: 1}]]);
const valid: Raw<Payload> = {value: {listen() {}}};
api.typed(valid);
api.edited(valid);
api.nested({first: {value: 1}, second: {listen() {}}});
api.wildcard({first: [{value: 1}], second: {listen() {}}});
api.callback(value => ({listen() {}}));
api.callback({apply(value) {return {listen() {}};}});
// @ts-expect-error Explicit host arguments retain their member types.
api.typed({value: 1});
// @ts-expect-error An edited slot must not regain reflection's raw erasure.
api.edited({value: 1});
// @ts-expect-error Raw use sites do not remove the declared bound.
type Invalid = Raw<number>;
// @ts-expect-error Erasing one raw argument must preserve its typed sibling.
api.nested({first: {value: 1}, second: 1});
// @ts-expect-error Raw callback arguments retain the typed callback result.
api.callback(value => 1);
// @ts-expect-error Explicit callback host arguments remain precise.
api.typedCallback(value => {value.value = 1; return {listen() {}};});
