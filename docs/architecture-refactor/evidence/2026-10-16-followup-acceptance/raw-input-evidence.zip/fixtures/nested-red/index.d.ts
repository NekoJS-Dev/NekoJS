declare module 'raw-input-fixture' {
    export interface $TypeScriptRawInputTest$Listener {
        listen(): void;
    }
    export class $TypeScriptRawInputTest$Payload implements $TypeScriptRawInputTest$Listener {
        constructor();
        listen(): void;
    }
    export class $TypeScriptRawInputTest$Raw<T extends $TypeScriptRawInputTest$Listener> {
        constructor();
        value: T;
    }
    export class $TypeScriptRawInputTest$Pair<L, R> {
        constructor();
        first: L;
        second: R;
    }
    export class $TypeScriptRawInputTest$Api {
        constructor();
        array(values: $TypeScriptRawInputTest$Raw<any>[][]): void;
        edited(value: $TypeScriptRawInputTest$Raw<$TypeScriptRawInputTest$Payload>): void;
        nested(value: $TypeScriptRawInputTest$Pair<$TypeScriptRawInputTest$Raw, $TypeScriptRawInputTest$Payload>): void;
        raw(value: $TypeScriptRawInputTest$Raw<any>): void;
        typed(value: $TypeScriptRawInputTest$Raw<$TypeScriptRawInputTest$Payload>): void;
    }
}
