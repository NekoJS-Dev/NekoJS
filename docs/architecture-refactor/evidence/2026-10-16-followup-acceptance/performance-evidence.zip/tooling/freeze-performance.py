import hashlib
import json
import subprocess
from pathlib import Path

root = Path('build/domain-performance-0965')
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == '0965e29b90fecb80f62a97e7f0dd110a82b8653a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
preparation = json.loads(Path('build/domain-closeout-reviewed-installed/preparation-manifest.json').read_text())
node = next(row for row in preparation['nodes'] if row['node'] == '26.1.2')
classes = {}
for directory in [worktree / 'common/build/classes/java/main', worktree / 'versions/26.1.2/build/classes/java/main']:
    for path in directory.rglob('*.class'):
        classes[path.relative_to(directory).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
assert classes == node['classBindings'], [key for key in classes if classes[key] != node['classBindings'].get(key)]
result = dict(revision='0965e29b90fecb80f62a97e7f0dd110a82b8653a', classBindings=classes,
              reviewedArtifactSha256=node['sha256'], classesMatchReviewedArtifact=True,
              cleanBeforeControlCheckout=True)
(root / 'frozen-classes.json').write_text(json.dumps(result, indent=2) + '\n')
print('PASS:', len(classes), 'development runtime classes equal reviewed official artifact classes')
