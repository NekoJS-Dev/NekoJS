import hashlib
import json
import os
import socket
import subprocess
import time
from pathlib import Path

project = Path.cwd().resolve()
worktree = Path('C:/Users/11515/.codex/worktrees/domain-perf-0965/NekoJS-mult').resolve()
destination = project / 'build/domain-performance-0965'
assert not destination.exists()
destination.mkdir()
revision = '0965e29b90fecb80f62a97e7f0dd110a82b8653a'
sampler = worktree / 'bench/perf/sample.ps1'
sampler_sha = '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
environment = dict(os.environ)
environment['JAVA_HOME'] = 'C:/Program Files/Java/jdk-25.0.2'
environment['PATH'] = environment['JAVA_HOME'] + '/bin;' + environment['PATH']
for path in [worktree, worktree / 'versions', worktree / 'versions/26.1.2', worktree / 'versions/26.1.2/run']:
    assert not path.is_symlink() and not (hasattr(path, 'is_junction') and path.is_junction()), path
assert (worktree / 'versions/26.1.2/run/nekojs').resolve().is_relative_to(worktree)
fixture_hashes = {p.relative_to(worktree).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in (worktree / 'bench/perf/fixtures/nekojs').rglob('*') if p.is_file()}
(destination / 'preparation.json').write_text(json.dumps(dict(revision=revision, worktree=str(worktree),
    samplerSha256=sampler_sha, fixtureHashes=fixture_hashes,
    scope='Existing source runServer startup/reload policy; not installed-JAR startup timing',
    plannedGroups=['reload-1', 'reload-2', 'startup'], warmup=2, samples=5, reloads=5), indent=2) + '\n')
groups = []
for group in ['reload-1', 'reload-2', 'startup']:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == revision
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True).strip()
    assert hashlib.sha256(sampler.read_bytes()).hexdigest() == sampler_sha
    for port in [25871, 25872]:
        with socket.socket() as guard:
            guard.bind(('127.0.0.1', port))
    outputs = worktree / 'bench/perf/out'
    before = set(outputs.iterdir()) if outputs.exists() else set()
    arguments = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(sampler),
        '-Mode', 'startup' if group == 'startup' else 'reload', '-Node', '26.1.2', '-Warmup', '2',
        '-Samples', '5', '-Reloads', '5', '-GradleUserHome', 'D:/mcmodDemo/NekoJS/.gradle-perf02',
        '-ServerPort', '25871', '-RconPort', '25872']
    started = time.monotonic()
    print('FORMAL_GROUP_START', group, flush=True)
    with (destination / (group + '.txt')).open('xb') as out, (destination / (group + '-stderr.txt')).open('xb') as err:
        process = subprocess.Popen(arguments, cwd=worktree, env=environment, stdout=out, stderr=err,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
    (destination / (group + '-owner.json')).write_text(json.dumps(dict(pid=process.pid,
        executable=arguments[0], worktree=str(worktree), arguments=arguments), indent=2) + '\n')
    code = process.wait()
    created = sorted(set(outputs.iterdir()) - before)
    row = dict(group=group, exitCode=code, seconds=round(time.monotonic()-started, 3),
               outputDirectories=[str(path) for path in created])
    groups.append(row)
    (destination / 'groups.json').write_text(json.dumps(groups, indent=2) + '\n')
    print('FORMAL_GROUP_EXIT', json.dumps(row), flush=True)
    assert code == 0 and len(created) == 1, row
print('FORMAL_GROUPS_COMPLETE', flush=True)
