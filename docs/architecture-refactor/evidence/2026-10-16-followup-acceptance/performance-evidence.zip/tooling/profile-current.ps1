$ErrorActionPreference = 'Stop'
$env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
$ProjectDir = 'C:\Users\11515\.codex\worktrees\domain-perf-0965\NekoJS-mult'
$diagnosticRoot = 'D:\mcmodDemo\NekoJS-mult\build\domain-performance-profile-0965'
$javaRoot = 'C:\Program Files\Java\jdk-25.0.2'
$env:JAVA_HOME = $javaRoot
$env:PATH = "$javaRoot\bin;$env:PATH"
$Node = '26.1.2'
$GradleUserHome = 'D:\mcmodDemo\NekoJS\.gradle-perf02'
$ServerPort = 25871
$RconPort = 25872
$RconPass = $env:NEKO_PERF_RCON_PASS
$RunDir = Join-Path $ProjectDir 'versions\26.1.2\run'
$FixtureDir = Join-Path $ProjectDir 'bench\perf\fixtures\nekojs'
$OutDir = $diagnosticRoot
$perfOut = Join-Path $RunDir 'nekojs\perf-out'
$script:StdinOk = $null
$script:TestStdin = $false
if (Test-Path -LiteralPath $diagnosticRoot) { throw 'Diagnostic evidence already exists' }
if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 25871,25872).Count -ne 0) { throw 'Diagnostic ports occupied' }
if ((& git -C $ProjectDir rev-parse HEAD).Trim() -ne '0965e29b90fecb80f62a97e7f0dd110a82b8653a') { throw 'Diagnostic source mismatch' }
if (@(& git -C $ProjectDir status --porcelain).Count -ne 0) { throw 'Diagnostic checkout not clean' }
$checkedPath = Get-Item -LiteralPath $RunDir
while ($null -ne $checkedPath) {
    if (($checkedPath.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Diagnostic run path has reparse point' }
    $checkedPath = $checkedPath.Parent
}
New-Item -ItemType Directory -Path $diagnosticRoot | Out-Null
$sampleDirectory = Join-Path $ProjectDir 'bench\perf'
$samplePath = Join-Path $sampleDirectory 'sample.ps1'
$parseTokens = $null
$parseErrors = $null
$sampleAst = [Management.Automation.Language.Parser]::ParseFile($samplePath, [ref]$parseTokens, [ref]$parseErrors)
if ($parseErrors.Count -ne 0) { throw 'Sampler parse failed' }
$functionNodes = $sampleAst.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst]}, $false)
foreach ($functionNode in $functionNodes) {
    $functionText = $functionNode.Extent.Text.Replace('$PSScriptRoot', "'$sampleDirectory'")
    . ([ScriptBlock]::Create($functionText))
}
Write-EnvSnapshot
Deploy-Fixtures -Bench:$false
$recordingPath = Join-Path $diagnosticRoot 'reload.jfr'
$settingsPath = Join-Path $diagnosticRoot 'reload.jfc'
& "$javaRoot\bin\jfr.exe" configure --input "$javaRoot\lib\jfr\profile.jfc" --output $settingsPath 'jdk.ExecutionSample#period=1ms' 'jdk.NativeMethodSample#period=1ms' 'jdk.ThreadPark#threshold=1ms' 'jdk.JavaMonitorWait#threshold=1ms' 'jdk.JavaMonitorEnter#threshold=1ms' 'jdk.InitialEnvironmentVariable#enabled=false' 'jdk.InitialSystemProperty#enabled=false' 'jdk.InitialSecurityProperty#enabled=false' 'jdk.SystemProcess#enabled=false' 'jdk.JVMInformation#enabled=false'
if ($LASTEXITCODE -ne 0) { throw 'JFR configuration failed' }
$session = Invoke-ServerSession -Tag 'profile' -OnDone {
    param($proc, $outLog, $sw)
    $listeners = @(Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 25871)
    if ($listeners.Count -ne 1) { throw 'Expected one owned game listener' }
    $gameId = $listeners[0].OwningProcess
    $gameProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$gameId"
    if ($gameProcess.Name -ne 'java.exe' -or $gameProcess.ExecutablePath -ne "$javaRoot\bin\java.exe" -or -not $gameProcess.CommandLine.Contains($ProjectDir)) { throw 'Unexpected game process; refuse to attach' }
    @{ pid = $gameId; launcher = $proc.Id; started = $gameProcess.CreationDate; revision = '0965e29b90fecb80f62a97e7f0dd110a82b8653a' } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $diagnosticRoot 'jvm.json')
    & "$javaRoot\bin\jcmd.exe" $gameId JFR.configure stackdepth=128 *> (Join-Path $diagnosticRoot 'jfr-configure.log')
    if ($LASTEXITCODE -ne 0) { throw 'JFR configure failed' }
    & "$javaRoot\bin\jcmd.exe" $gameId JFR.start name=Reload15 "settings=$settingsPath" *> (Join-Path $diagnosticRoot 'jfr-start.log')
    if ($LASTEXITCODE -ne 0) { throw 'JFR start failed' }
    $observations = @()
    for ($reloadIndex = 1; $reloadIndex -le 5; $reloadIndex++) {
        Start-Sleep -Milliseconds 3000
        $startedUtc = [datetime]::UtcNow.ToString('o')
        $timer = [Diagnostics.Stopwatch]::StartNew()
        $response = Invoke-Rcon -Command 'nekojs reload'
        $elapsedMs = $timer.Elapsed.TotalMilliseconds
        if ($response -notmatch 'phase=COMMIT - no errors\.') { throw 'Diagnostic reload did not commit cleanly' }
        $observations += @{ index = $reloadIndex; rconMs = $elapsedMs; response = $response; startedUtc = $startedUtc; endedUtc = [datetime]::UtcNow.ToString('o') }
    }
    & "$javaRoot\bin\jcmd.exe" $gameId JFR.stop name=Reload15 "filename=$recordingPath" *> (Join-Path $diagnosticRoot 'jfr-stop.log')
    if ($LASTEXITCODE -ne 0) { throw 'JFR stop failed' }
    $observations | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $diagnosticRoot 'reloads.json')
    $stop = Stop-Server $proc
    @{ stopSent = $true; stopChannel = $stop.channel; killed = $stop.killed }
}
$session | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $diagnosticRoot 'session.json')
if ($session.forcedKill -or $session.extra.killed -or $session.extra.stopChannel -ne 'rcon') { throw 'Diagnostic stop was not normal' }
$safeRecording = Join-Path $diagnosticRoot 'safe-profile.jfr'
& "$javaRoot\bin\jfr.exe" scrub --include-events 'jdk.ExecutionSample,jdk.NativeMethodSample,jdk.ThreadPark,jdk.JavaMonitorWait,jdk.JavaMonitorEnter,jdk.GCPhasePause' $recordingPath $safeRecording
if ($LASTEXITCODE -ne 0) { throw 'Safe event whitelist extraction failed' }
Write-Output 'DIAGNOSTIC_JFR_COMPLETE' 
