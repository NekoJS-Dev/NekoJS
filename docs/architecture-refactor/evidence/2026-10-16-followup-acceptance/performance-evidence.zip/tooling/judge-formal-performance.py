import json
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else 'build/domain-performance-0965')
groups = json.loads((root / 'groups.json').read_text())
results = []
for group in groups:
    assert group['exitCode'] == 0 and len(group['outputDirectories']) == 1
    output = Path(group['outputDirectories'][0])
    rows = [json.loads(line) for line in (output / 'samples.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    formal = [row for row in rows if row['kind'] == 'formal']
    assert len(formal) == 5
    assert all(not row.get('timeout') and not row['killed'] and not row['forced_kill'] for row in rows)
    startup = group['group'] == 'startup'
    key = 'wall_done_ms' if startup else 'marker_ms'
    limit = 41173 if startup else 285.3
    if startup:
        assert len([row for row in rows if row['kind'] == 'warmup']) == 2
    else:
        assert all('phase=COMMIT - no errors' in row['rcon_response'] for row in formal)
    values = [row[key] for row in formal]
    mean = statistics.mean(values)
    result = dict(group=group['group'], revision=formal[0]['rev'], measure=key, values=values,
        mean=mean, stdev=statistics.stdev(values), limit=limit, verdict='PASS' if mean <= limit else 'FAIL',
        samples=len(formal), sampleFile=str(output / 'samples.jsonl'), environmentFile=str(output / 'env-snapshot.txt'))
    if not startup:
        result['rconMean'] = statistics.mean(row['rcon_rtt_ms'] for row in formal)
        result['markerMinusRconMean'] = statistics.mean(row['marker_ms'] - row['rcon_rtt_ms'] for row in formal)
    results.append(result)
preparation = json.loads((root / 'preparation.json').read_text())
summary = dict(complete=[row['group'] for row in groups] == preparation['plannedGroups'], verdict='PASS' if all(row['verdict'] == 'PASS' for row in results) else 'FAIL',
    scope=preparation['scope'], groups=results)
(root / 'judgment.json').write_text(json.dumps(summary, indent=2) + '\n')
for row in results:
    print(row['group'], row['verdict'], 'mean=', row['mean'], 'limit=', row['limit'], 'values=', row['values'])
sys.exit(0 if summary['complete'] and summary['verdict'] == 'PASS' else 2)
