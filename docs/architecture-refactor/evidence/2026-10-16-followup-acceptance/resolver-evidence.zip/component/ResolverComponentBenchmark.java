import com.tkisor.nekojs.core.module.NekoModuleResolver;
import com.tkisor.nekojs.core.module.NekoResolvedModule;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Diagnostic component experiment; JSON inputs isolate resolver checks from compiler setup. */
public class ResolverComponentBenchmark {
    private static volatile int consumed;
    private static final Method baseline;
    private static final Method fileModule;
    static {
        try {
            baseline = NekoModuleResolver.class.getMethod("resolveEntry", String.class);
            fileModule = NekoModuleResolver.class.getDeclaredMethod("resolveFileModule", Path.class);
            fileModule.setAccessible(true);
        } catch (ReflectiveOperationException error) { throw new ExceptionInInitializerError(error); }
    }

    private static Path parse(Path root, String path) throws IOException {
        if (path == null || path.isBlank()) throw new IOException("Module path must not be blank");
        String normalized = path.replace('\\', '/');
        if (normalized.startsWith("file:")) return Path.of(URI.create(normalized)).normalize();
        if (normalized.startsWith("./")) normalized = normalized.substring(2);
        Path parsed = Path.of(normalized);
        return (parsed.isAbsolute() ? parsed : root.resolve(parsed)).normalize();
    }

    private static Object resolve(NekoModuleResolver resolver, Path root, String path, boolean candidate) throws Exception {
        try {
            return candidate ? fileModule.invoke(resolver, parse(root, path)) : baseline.invoke(resolver, path);
        } catch (InvocationTargetException error) {
            if (error.getCause() instanceof Exception cause) throw cause;
            throw error;
        }
    }

    private static String failure(NekoModuleResolver resolver, Path root, String path, boolean candidate) throws Exception {
        try {
            resolve(resolver, root, path, candidate);
            throw new AssertionError("Expected the path to be rejected");
        } catch (IOException | IllegalArgumentException error) {
            return error.getClass().getName() + ": " + error.getMessage();
        }
    }

    private static long time(NekoModuleResolver resolver, Path root, List<String> paths, boolean candidate, int repeats) throws Exception {
        long start = System.nanoTime();
        for (int iteration = 0; iteration < repeats; iteration++) {
            for (String path : paths) consumed ^= resolve(resolver, root, path, candidate).hashCode();
        }
        return System.nanoTime() - start;
    }

    public static void main(String[] args) throws Exception {
        Path directory = Path.of(args[0]).toAbsolutePath().normalize();
        if (Files.exists(directory)) throw new AssertionError("Fresh experiment directory required");
        Path game = directory.resolve("game");
        Path root = game.resolve("nekojs");
        List<String> paths = new ArrayList<>();
        for (int index = 0; index < 6; index++) {
            Path path = root.resolve("server_scripts/sub/" + index + ".json");
            Files.createDirectories(path.getParent());
            Files.writeString(path, "{}");
            paths.add(switch (index % 3) {
                case 0 -> "./" + root.relativize(path).toString().replace('\\', '/');
                case 1 -> path.toString();
                default -> path.toUri().toString();
            });
        }
        // JSON resolution never accesses the compiler policy; no runtime registry is initialized.
        NekoModuleResolver resolver = new NekoModuleResolver(game, root, root.resolve("node_modules"), null);
        for (String path : paths) {
            if (!resolve(resolver, root, path, false).equals(resolve(resolver, root, path, true))) {
                throw new AssertionError("Resolved module identity changed");
            }
        }
        List<String> rejected = new ArrayList<>();
        rejected.add(null);
        rejected.add(" ");
        rejected.add("../../outside.json");
        rejected.add(directory.resolve("outside.json").toString());
        Files.writeString(directory.resolve("outside.json"), "{}");
        boolean symlinkChecked = false;
        Path link = root.resolve("server_scripts/link.json");
        try {
            Files.createSymbolicLink(link, directory.resolve("outside.json"));
            rejected.add(link.toString());
            symlinkChecked = true;
        } catch (IOException | UnsupportedOperationException unavailable) {
            // Preserve an explicit availability result instead of counting an unrun symlink check as passed.
        }
        for (String path : rejected) {
            if (!failure(resolver, root, path, false).equals(failure(resolver, root, path, true))) {
                throw new AssertionError("Path rejection changed");
            }
        }
        time(resolver, root, paths, false, 100);
        time(resolver, root, paths, true, 100);
        System.out.println("{\"diagnosticOnly\":true,\"pathsPerSet\":6,\"repeatsPerArm\":30,\"identityCases\":6,\"rejectionCases\":"
                + rejected.size() + ",\"symlinkChecked\":" + symlinkChecked + ",\"pairs\":[");
        for (int pair = 0; pair < 10; pair++) {
            long oldTime, newTime;
            if (pair % 2 == 0) {
                oldTime = time(resolver, root, paths, false, 30);
                newTime = time(resolver, root, paths, true, 30);
            } else {
                newTime = time(resolver, root, paths, true, 30);
                oldTime = time(resolver, root, paths, false, 30);
            }
            System.out.println((pair == 0 ? "" : ",") + "{\"pair\":" + pair + ",\"baselineNs\":" + oldTime
                    + ",\"candidateNs\":" + newTime + ",\"baselineFirst\":" + (pair % 2 == 0) + "}");
        }
        System.out.println("]}");
    }
}
