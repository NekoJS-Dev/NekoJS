from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'ResolverComponentBenchmark.java').read_text(encoding='utf-8')
replacements = [
    ('ResolverComponentBenchmark', 'ResolverProductionBenchmark'),
    ('private static final Method fileModule;',
     'private static final Method currentEntry;\n    private static Object baselineResolver;'),
    ('baseline = NekoModuleResolver.class.getMethod', 'baseline = DiagnosticBaselineResolver.class.getMethod'),
    ('fileModule = NekoModuleResolver.class.getDeclaredMethod("resolveFileModule", Path.class);',
     'currentEntry = NekoModuleResolver.class.getMethod("resolveEntry", String.class);'),
    ('            fileModule.setAccessible(true);\n', ''),
    ('fileModule.invoke(resolver, parse(root, path)) : baseline.invoke(resolver, path)',
     'currentEntry.invoke(resolver, path) : baseline.invoke(baselineResolver, path)'),
    ('        for (String path : paths) {\n            if (!resolve',
     '        baselineResolver = new DiagnosticBaselineResolver(game, root, root.resolve("node_modules"), null);\n'
     '        for (String path : paths) {\n            if (!resolve')]
for before, after in replacements:
    assert before in source, before
    source = source.replace(before, after)
start = source.index('    private static Path parse(')
end = source.index('    private static Object resolve(', start)
source = source[:start] + source[end:]
target = root / 'ResolverProductionBenchmark.java'
assert not target.exists()
target.write_text(source, encoding='utf-8')
