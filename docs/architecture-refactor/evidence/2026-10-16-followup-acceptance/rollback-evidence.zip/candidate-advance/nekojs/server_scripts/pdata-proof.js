const seen = new Set();
ServerEvents.tickPost(event => {
    for (const entity of event.server.overworld().getAllEntities()) {
        if (!entity.hasTag('nekojs_pdata_written') || seen.has(entity.getId())) continue;
        const data = entity.pdata();
        data.putString('nekojs:rollback-proof', 'proof-2').putInt('nekojs:rollback-revision', 2);
        console.info('ROLLBACK-PDATA ' + JSON.stringify({phase: 'candidate-advance', value: data.getString('nekojs:rollback-proof'), revision: data.getInt('nekojs:rollback-revision')}));
        seen.add(entity.getId());
    }
});
