"""Rehearse artifact and whole-world data rollback in fresh owned server directories."""

import hashlib
import importlib.util
import json
import shutil
import socket
import subprocess
import time
from pathlib import Path

project = Path.cwd().resolve()
root = project / 'build/domain-closeout-rollback-installed-2'
assert not root.exists()
root.mkdir()
source = project / 'build/domain-closeout-final-installed/26.1.2'
current = next((source / 'mods').glob('nekojs-*.jar'))
previous = project / 'build/domain-closeout-preserved/previous-26.1.2.jar'
assert hashlib.sha256(previous.read_bytes()).hexdigest() == 'ade011a0bb7252d93f6374c234ec9353dbf6105f1793c448a0f64d5d6771c52b'
spec = importlib.util.spec_from_file_location('owned_rcon', project / 'bench/perf/rcon.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
java = 'C:/Program Files/Java/jdk-25.0.2/bin/java.exe'
world_name = 'owned-rollback-proof'
records = []


def hashes(directory):
    return {path.relative_to(directory).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(directory.rglob('*')) if path.is_file()}


def prepare(name, artifact, index, world=None, write=None):
    directory = root / name
    directory.mkdir()
    shutil.copyfile(source / 'eula.txt', directory / 'eula.txt')
    port = 26631 + index * 10
    for number in [port, port + 1]:
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', number))
    properties = (source / 'server.properties').read_text(encoding='utf-8')
    properties = '\n'.join(f'server-port={port}' if line.startswith('server-port=') else
        f'rcon.port={port+1}' if line.startswith('rcon.port=') else
        f'level-name={world_name}' if line.startswith('level-name=') else
        'server-ip=127.0.0.1' if line.startswith('server-ip=') else line for line in properties.splitlines()) + '\n'
    (directory / 'server.properties').write_text(properties, encoding='utf-8')
    shutil.copytree(source / 'nekojs/config', directory / 'nekojs/config')
    (directory / 'nekojs/server_scripts').mkdir()
    script = '''const seen = new Set();
ServerEvents.tickPost(event => {
    for (const entity of event.server.overworld().getAllEntities()) {
        if (!entity.hasTag('nekojs_pdata_written') || seen.has(entity.getId())) continue;
        const data = entity.pdata();
        WRITE
        console.info('ROLLBACK-PDATA ' + JSON.stringify({phase: 'PHASE', value: data.getString('nekojs:rollback-proof'), revision: data.getInt('nekojs:rollback-revision')}));
        seen.add(entity.getId());
    }
});
'''.replace('PHASE', name).replace('WRITE', '' if write is None else
        f"data.putString('nekojs:rollback-proof', 'proof-{write}').putInt('nekojs:rollback-revision', {write});")
    (directory / 'nekojs/server_scripts/pdata-proof.js').write_text(script, encoding='utf-8')
    (directory / 'mods').mkdir()
    for dependency in (source / 'mods').glob('*.jar'):
        if not dependency.name.startswith('nekojs-'):
            shutil.copyfile(dependency, directory / 'mods' / dependency.name)
    shutil.copyfile(artifact, directory / 'mods' / current.name)
    (directory / 'libraries').symlink_to((source / 'libraries').resolve(), target_is_directory=True)
    if world is not None:
        before = hashes(world)
        shutil.copytree(world, directory / world_name)
        assert hashes(directory / world_name) == before
    record = dict(phase=name, artifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),
                  sourceRevision='20809213' if artifact == current else None,
                  oldRevisionKnown=artifact == current, copiedWorldHashes=hashes(directory / world_name) if world else None)
    (directory / 'preparation.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
    return directory, port + 1, dict(line.split('=', 1) for line in properties.splitlines() if '=' in line)['rcon.password'], record


def execute(prepared, expected, initial=False):
    directory, port, password, record = prepared
    arguments = [java, '-Xms512M', '-Xmx2G', '@libraries/net/neoforged/neoforge/26.1.2.71/win_args.txt', 'nogui']
    commands = []
    def command(text):
        with socket.create_connection(('127.0.0.1', port), timeout=15) as connection:
            connection.settimeout(60)
            rcon.send_packet(connection, 1, 3, password)
            assert rcon.recv_packet(connection)[0] != -1
            rcon.send_packet(connection, 10, 2, text)
            response = rcon.recv_packet(connection)
            assert response is not None
            commands.append(dict(command=text, response=response[2]))
            return response[2]
    def log():
        return (directory / 'server-stdout.log').read_text(encoding='utf-8', errors='replace')
    with (directory / 'server-stdout.log').open('xb') as out, (directory / 'server-stderr.log').open('xb') as err:
        process = subprocess.Popen(arguments, cwd=directory, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
    (directory / 'owned-process.json').write_text(json.dumps(dict(pid=process.pid, arguments=arguments, directory=str(directory))), encoding='utf-8')
    try:
        deadline = time.monotonic() + 300
        while 'Done (' not in log() and 'Done(' not in log():
            assert process.poll() is None, 'Owned server exited before ready'
            assert time.monotonic() < deadline, 'Owned server readiness timed out'
            time.sleep(1)
        command('forceload add 0 0')
        if initial:
            command('setblock 2 80 0 minecraft:stone')
            response = command('summon minecraft:armor_stand 0 81 0 {Tags:["nekojs_pdata_written"],NoGravity:1b,Invulnerable:1b}')
            assert 'summon' in response.lower(), response
        elif expected == 2 and record['phase'] == 'candidate-advance':
            command('setblock 2 80 0 minecraft:gold_block')
        deadline = time.monotonic() + 45
        marker = f'"phase":"{record["phase"]}","value":"proof-{expected}","revision":{expected}'
        while marker not in log():
            assert time.monotonic() < deadline, 'Production pdata reader/writer marker missing: ' + marker
            time.sleep(0.5)
        physical = command('data get entity @e[type=minecraft:armor_stand,tag=nekojs_pdata_written,limit=1] NeoForgeData')
        assert 'NekoJSPersistentData' in physical and f'proof-{expected}' in physical, physical
        block = 'minecraft:gold_block' if expected == 2 else 'minecraft:stone'
        response = command('execute if block 2 80 0 ' + block + ' run say ROLLBACK-BLOCK-PASS')
        # RCON say broadcasts to the server log without a direct response body.
        deadline = time.monotonic() + 10
        while '[Rcon] ROLLBACK-BLOCK-PASS' not in log():
            assert time.monotonic() < deadline, 'Conditional world-block broadcast missing'
            time.sleep(0.2)
        command('save-all flush')
        record.update(verdict='PASS', readValue=f'proof-{expected}', block=block)
    except BaseException as failure:
        record.update(verdict='NOTGREEN', failure=str(failure))
        raise
    finally:
        if process.poll() is None:
            command('stop')
        try:
            exit_code = process.wait(timeout=90)
        finally:
            (directory / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n', encoding='utf-8')
        record['exitCode'] = exit_code
        record['worldAfterStop'] = hashes(directory / world_name)
        records.append(record)
        (directory / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        (root / 'summary.json').write_text(json.dumps(dict(records=records), indent=2) + '\n', encoding='utf-8')
        assert exit_code == 0
    print(record['phase'], record['verdict'], record['readValue'], flush=True)
    return directory / world_name


first = execute(prepare('candidate-initial', current, 0, write=1), 1, initial=True)
backup = root / 'stopped-world-backup'
backup_hashes = hashes(first)
shutil.copytree(first, backup)
assert hashes(backup) == backup_hashes
(root / 'backup-manifest.json').write_text(json.dumps(backup_hashes, indent=2) + '\n', encoding='utf-8')
advanced = execute(prepare('candidate-advance', current, 1, world=first, write=2), 2)
advanced_before_rollback = hashes(advanced)
execute(prepare('artifact-rollback', previous, 2, world=advanced), 2)
assert hashes(advanced) == advanced_before_rollback
restore = prepare('data-restore', current, 3, world=backup)
assert hashes(restore[0] / world_name) == backup_hashes
second_copy = root / 'idempotence-copy'
shutil.copytree(backup, second_copy)
assert hashes(second_copy) == backup_hashes
execute(restore, 1)
assert hashes(backup) == backup_hashes and hashes(advanced) == advanced_before_rollback
(root / 'final-verdict.json').write_text(json.dumps(dict(verdict='PASS', separateArtifactAndDataRollback=True,
    backupRetained=True, advancedWorldRetained=True, exactRestoreBeforeBoot=True,
    repeatedCopyHashesEqual=True, oldSourceRevision=None, scope='26.1.2 NeoForge, owned whole-world fixture only'), indent=2) + '\n', encoding='utf-8')
