import type { $BeanAliasExclusionTest$Parent as Parent, $BeanAliasExclusionTest$Child as Child,
  $BeanAliasExclusionTest$Independent as Independent, $BeanAliasExclusionTest$OwnGetter as OwnGetter,
  $BeanAliasExclusionTest$Bounded as Bounded } from 'java:com/tkisor/nekojs/probe';
declare const parent: Parent;
declare const child: Child;
declare const independent: Independent;
declare const own: OwnGetter;
const bounded: Bounded<Child> = {entity: child};
const base: Parent = child;
const result: boolean = parent.isAttackable();
const childResult: boolean = child.attackable();
const independentResult: boolean = independent.attackable;
const ownResult: boolean = own.attackable;
const unrelated: boolean = parent.other;
// @ts-expect-error The declared bound remains precise.
type Invalid = Bounded<number>;
