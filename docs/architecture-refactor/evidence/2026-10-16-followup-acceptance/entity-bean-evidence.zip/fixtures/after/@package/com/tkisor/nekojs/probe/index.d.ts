declare module "java:com/tkisor/nekojs/probe" {
    export class $BeanAliasExclusionTest$Parent {
        constructor();
        isAttackable(): boolean;
        get other(): boolean;
        isOther(): boolean;
    }

    export class $BeanAliasExclusionTest$Child extends $BeanAliasExclusionTest$Parent {
        constructor();
        attackable(): boolean;
    }

    export class $BeanAliasExclusionTest$Independent {
        constructor();
        get attackable(): boolean;
        isAttackable(): boolean;
    }

    export class $BeanAliasExclusionTest$OwnGetter extends $BeanAliasExclusionTest$Parent {
        constructor();
        get attackable(): boolean;
        isAttackable(): boolean;
    }

    export class $BeanAliasExclusionTest$Bounded<T extends $BeanAliasExclusionTest$Parent> {
        constructor();
        entity: T;
    }

}
