export * as probe from "java:com/tkisor/nekojs/probe";

