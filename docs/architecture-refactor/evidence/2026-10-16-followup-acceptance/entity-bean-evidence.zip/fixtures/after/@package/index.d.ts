// NekoJS Probe Type Declarations

export * as com from "java:com";
