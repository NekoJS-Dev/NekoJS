import { $Enum } from "java:java/lang";

declare module "java:com/tkisor/nekojs/probe" {
    export class $TypeScriptEnumHeritageTest$Color {
        static BLUE: $TypeScriptEnumHeritageTest$Color;
        static RED: $TypeScriptEnumHeritageTest$Color;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TypeScriptEnumHeritageTest$Color[];
        static valueOf(name: string): $TypeScriptEnumHeritageTest$Color;
    }
    export interface $TypeScriptEnumHeritageTest$Color extends $Enum<$TypeScriptEnumHeritageTest$Color> {}

    export type $TypeScriptEnumHeritageTest$Color_ = $TypeScriptEnumHeritageTest$Color | "BLUE" | "RED";
}
