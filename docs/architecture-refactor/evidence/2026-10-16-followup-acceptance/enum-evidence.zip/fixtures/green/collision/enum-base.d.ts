declare module "java:java/lang" {
    export class $Enum<E extends $Enum<E>> {
        compareTo(other: E): number;
        static valueOf<T extends $Enum<T>>(kind: object, name: string): T;
    }
}
