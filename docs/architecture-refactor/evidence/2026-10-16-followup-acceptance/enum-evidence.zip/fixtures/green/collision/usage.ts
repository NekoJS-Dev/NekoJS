import { $TypeScriptEnumHeritageTest$Color as Color } from "java:com/tkisor/nekojs/probe";
import { $Enum } from "java:java/lang";
function acceptEnum<E extends $Enum<E>>(value: E): E { return value; }
const exact: Color = acceptEnum(Color.RED);
const parsed: Color = Color.valueOf("BLUE");
const comparison: number = exact.compareTo(parsed);
// @ts-expect-error The enum factory retains its one-argument signature.
Color.valueOf({}, "RED");
// @ts-expect-error A string is not a Java enum instance.
acceptEnum("RED");
