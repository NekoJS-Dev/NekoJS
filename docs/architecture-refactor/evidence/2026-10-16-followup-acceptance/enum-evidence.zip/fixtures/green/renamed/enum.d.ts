import { $Enum } from "java:java/lang";

declare module "java:com/tkisor/nekojs/probe" {
    export class $RenamedColor {
        static BLUE: $RenamedColor;
        static RED: $RenamedColor;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $RenamedColor[];
        static valueOf(name: string): $RenamedColor;
    }
    export interface $RenamedColor extends $Enum<$RenamedColor> {}
    export type $TypeScriptEnumHeritageTest$Color = $RenamedColor;
    export const $TypeScriptEnumHeritageTest$Color: typeof $RenamedColor;

    export type $RenamedColor_ = $RenamedColor | "BLUE" | "RED";
    export type $TypeScriptEnumHeritageTest$Color_ = $RenamedColor_;
}
