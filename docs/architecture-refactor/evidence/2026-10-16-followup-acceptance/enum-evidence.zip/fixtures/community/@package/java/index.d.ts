export * as lang from "java:java/lang";

