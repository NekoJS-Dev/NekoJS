declare module "java:com/tkisor/nekojs/probe/testfixture/samebase" {
    export class $AuthoredBase<T> {
        constructor(value: T);
        baseValue(): T;
    }
    export type $PersistentData<T> = $AuthoredBase<T>;
    export const $PersistentData: typeof $AuthoredBase;

}
