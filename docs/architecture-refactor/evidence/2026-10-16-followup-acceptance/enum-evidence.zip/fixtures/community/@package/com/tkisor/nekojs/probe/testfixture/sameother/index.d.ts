declare module "java:com/tkisor/nekojs/probe/testfixture/sameother" {
    export class $PersistentData {
        constructor();
        otherValue(): number;
    }

}
