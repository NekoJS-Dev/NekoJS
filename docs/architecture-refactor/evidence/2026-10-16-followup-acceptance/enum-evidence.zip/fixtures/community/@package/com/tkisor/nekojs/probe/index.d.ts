export * as testfixture from "java:com/tkisor/nekojs/probe/testfixture";

