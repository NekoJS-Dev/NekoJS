import { $CallbackValue } from "java:com/tkisor/nekojs/probe/testfixture/callback";
import { $PersistentData as $NekoImport$PersistentData } from "java:com/tkisor/nekojs/probe/testfixture/samebase";
import { $PersistentData as $NekoImport$PersistentData1 } from "java:com/tkisor/nekojs/probe/testfixture/sameother";
import { $Enum } from "java:java/lang";

export * as samebase from "java:com/tkisor/nekojs/probe/testfixture/samebase";
export * as sameother from "java:com/tkisor/nekojs/probe/testfixture/sameother";
export * as callback from "java:com/tkisor/nekojs/probe/testfixture/callback";

declare module "java:com/tkisor/nekojs/probe/testfixture" {
    export class $CommunityProbeTypes$Api {
        constructor();
        consume(callback: $CommunityProbeTypes$Mapper_<$CommunityProbeTypes$Payload, string, $CommunityProbeTypes$Payload, string>): void;
        containerWildcard(callback: $CommunityProbeTypes$Mapper_<$CommunityProbeTypes$Container<any>, string, $CommunityProbeTypes$Container<any>, string>): string;
        infer<T>(callback: $CommunityProbeTypes$Supplier_<T, T>): T;
        inherited(callback: $CommunityProbeTypes$StringMapper_<string, string>): void;
        mode(mode: $CommunityProbeTypes$Mode_): void;
        nested(callback: $CommunityProbeTypes$Supplier_<$CommunityProbeTypes$Supplier<$CommunityProbeTypes$Payload>, $CommunityProbeTypes$Supplier_<$CommunityProbeTypes$Payload, $CommunityProbeTypes$Payload_>>): void;
        produce(callback: $CommunityProbeTypes$Supplier_<$CommunityProbeTypes$Payload, $CommunityProbeTypes$Payload_>): void;
        raw(callback: $CommunityProbeTypes$Mapper_<any, any, any, any>): void;
        wildcard(callback: $CommunityProbeTypes$Mapper_<$CallbackValue, string, $CallbackValue, string>): void;
    }

    export class $CommunityProbeTypes$Payload {
        constructor();
        get name(): string;
        getName(): string;
    }

    export interface $CommunityProbeTypes$Mapper<T, R> {
        apply(value: T): R;
        equals(other: object): boolean;
    }

    export interface $CommunityProbeTypes$StringMapper extends $CommunityProbeTypes$Mapper<string, string> {
    }

    export interface $CommunityProbeTypes$Supplier<T> {
        get(): T;
    }

    export class $CommunityProbeTypes$RpcBuilder<
        T extends Record<string, 'string' | 'int'> = {},
        R extends 'string' | 'int' | undefined = undefined> {
        schema<const S extends Record<string, 'string' | 'int'>>(value: S): $CommunityProbeTypes$RpcBuilder<S, R>;
        returns<V extends 'string' | 'int'>(value: V): $CommunityProbeTypes$RpcBuilder<T, V>;
        fn(callback: (args: { [K in keyof T]: T[K] extends 'string' ? string : number }) =>
            (R extends 'string' ? string : R extends 'int' ? number : void)): void;
        base(): import("java:com/tkisor/nekojs/probe/testfixture/samebase").$PersistentData<string>;
        other(): import("java:com/tkisor/nekojs/probe/testfixture/sameother").$PersistentData;
    }

    export class $CommunityProbeTypes$Container<T> {
        constructor(value: T);
        get(): T;
    }

    export class $AuthoredMode {
        static A: $AuthoredMode;
        static B: $AuthoredMode;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $AuthoredMode[];
        static valueOf(name: string): $AuthoredMode;
    }
    export interface $AuthoredMode extends $Enum<$AuthoredMode> {}
    export type $CommunityProbeTypes$Mode = $AuthoredMode;
    export const $CommunityProbeTypes$Mode: typeof $AuthoredMode;

    export type $CommunityProbeTypes$Payload_ = $CommunityProbeTypes$Payload | string;
    export type $CommunityProbeTypes$Mapper_<Host0 = any, Host1 = any, CallbackArg0 = Host0, CallbackResult = Host1> = ((arg0: CallbackArg0) => CallbackResult) | ($CommunityProbeTypes$Mapper<Host0, Host1> & { readonly [Symbol.hasInstance]?: never });
    export type $CommunityProbeTypes$StringMapper_<CallbackArg0 = string, CallbackResult = string> = ((arg0: CallbackArg0) => CallbackResult) | ($CommunityProbeTypes$StringMapper & { readonly [Symbol.hasInstance]?: never });
    export type $CommunityProbeTypes$Supplier_<Host0 = any, CallbackResult = Host0> = (() => CallbackResult) | ($CommunityProbeTypes$Supplier<Host0> & { readonly [Symbol.hasInstance]?: never });
    export type $AuthoredMode_ = $AuthoredMode | "A" | "B";
    export type $CommunityProbeTypes$Mode_ = $AuthoredMode_;
}
