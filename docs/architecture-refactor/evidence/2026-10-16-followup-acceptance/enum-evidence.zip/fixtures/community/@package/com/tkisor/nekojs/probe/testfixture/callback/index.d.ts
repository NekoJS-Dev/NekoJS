declare module "java:com/tkisor/nekojs/probe/testfixture/callback" {
    export class $CallbackValue {
        constructor();
        get label(): string;
        getLabel(): string;
    }

}
