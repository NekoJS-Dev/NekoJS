declare module "java:com/tkisor/nekojs/probe" {
    export class $Enum {
        static BLUE: $Enum;
        static RED: $Enum;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $Enum[];
        static valueOf(name: string): $Enum;
    }
    export type $TypeScriptEnumHeritageTest$Color = $Enum;
    export const $TypeScriptEnumHeritageTest$Color: typeof $Enum;

    export type $Enum_ = $Enum | "BLUE" | "RED";
    export type $TypeScriptEnumHeritageTest$Color_ = $Enum_;
}
