import { $ApiTypeRef } from "java:com/tkisor/nekojs/api/surface";
import { $Class } from "java:java/lang";
import { $Type } from "java:java/lang/reflect";
import { $List, $Map } from "java:java/util";

declare module "java:com/tkisor/nekojs/probe/ir" {
    export class $FieldDecl {
        constructor(name: string, type: $TypeSlot);
        docs: $List<string>;
        hidden: boolean;
        isEnumConstant: boolean;
        isFinal: boolean;
        isStatic: boolean;
        name: string;
        renameTo: string;
        type: $TypeSlot;
        effectiveName(): string;
    }

    export class $MethodDecl {
        constructor(name: string);
        docs: $List<string>;
        hidden: boolean;
        isConstructor: boolean;
        isGetter: boolean;
        isSetter: boolean;
        isStatic: boolean;
        name: string;
        overloads: $List<$MethodDecl$Overload>;
        params: $List<$MethodDecl$MethodParam>;
        property: string;
        renameTo: string;
        returnType: $TypeSlot;
        setterParamType: $TypeSlot;
        typeParameterBounds: $Map<string, $List<$TypeSlot>>;
        typeParams: $List<string>;
        effectiveName(): string;
    }

    export class $MethodDecl$MethodParam {
        constructor(name: string, type: $TypeSlot, varargs: boolean);
        name: string;
        optional: boolean;
        type: $TypeSlot;
        varargs: boolean;
    }

    export class $MethodDecl$Overload {
        constructor(params: string[], returns: string, docs: string[]);
        docs: $List<string>;
        params: $List<string>;
        returns: string;
    }

    export class $TypeDecl {
        constructor(kind: $TypeDecl$Kind_, sourceClass: $Class<any>, fqn: string);
        constructors: $List<$MethodDecl>;
        docs: $List<string>;
        fields: $List<$FieldDecl>;
        fqn: string;
        hidden: boolean;
        interfaces: $List<$TypeSlot>;
        kind: $TypeDecl$Kind;
        methods: $List<$MethodDecl>;
        mutated: boolean;
        renameTo: string;
        sourceClass: $Class<any>;
        superType: $TypeSlot;
        typeParams: $List<$TypeDecl$TypeParam>;
        beanFieldWriteType(field: $FieldDecl, getter: $MethodDecl): $TypeSlot;
        beanGetterForField(field: $FieldDecl): $MethodDecl;
        effectiveTypeName(): string;
    }

    export class $TypeDecl$Kind {
        static CLASS: $TypeDecl$Kind;
        static ENUM: $TypeDecl$Kind;
        static INTERFACE: $TypeDecl$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $TypeDecl$Kind[];
        static valueOf(name: string): $TypeDecl$Kind;
    }

    export class $TypeDecl$TypeParam {
        constructor(name: string, bound: $TypeSlot);
        bound: $TypeSlot;
        name: string;
    }

    export class $TypeSlot {
        constructor(sourceType: $Type, ref: $ApiTypeRef);
        overridden: boolean;
        ref: $ApiTypeRef;
        sourceType: $Type;
        static of(sourceType: $Type, ref: $ApiTypeRef): $TypeSlot;
    }

    export type $TypeDecl$Kind_ = $TypeDecl$Kind | "CLASS" | "ENUM" | "INTERFACE";
}
