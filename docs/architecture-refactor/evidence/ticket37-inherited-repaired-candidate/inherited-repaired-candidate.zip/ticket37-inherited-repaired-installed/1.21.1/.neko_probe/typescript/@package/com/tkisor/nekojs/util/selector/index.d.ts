import { $List } from "java:java/util";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $EntitySelector } from "java:net/minecraft/commands/arguments/selector";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $Entity } from "java:net/minecraft/world/entity";

declare module "java:com/tkisor/nekojs/util/selector" {
    export class $EntitySelectorBuilderJS {
        constructor();
        get alive(): $EntitySelectorBuilderJS;
        isAlive(): $EntitySelectorBuilderJS;
        static allEntities(): $EntitySelectorBuilderJS;
        static allPlayers(): $EntitySelectorBuilderJS;
        static nearestEntity(): $EntitySelectorBuilderJS;
        static nearestPlayer(): $EntitySelectorBuilderJS;
        static randomEntity(): $EntitySelectorBuilderJS;
        static randomPlayer(): $EntitySelectorBuilderJS;
        create(): $EntitySelector;
        distanceAbove(minDistance: number): $EntitySelectorBuilderJS;
        distanceBelow(maxDistance: number): $EntitySelectorBuilderJS;
        distance(minDistance: number, maxDistance: number): $EntitySelectorBuilderJS;
        dx(deltaX: number): $EntitySelectorBuilderJS;
        dy(deltaY: number): $EntitySelectorBuilderJS;
        dz(deltaZ: number): $EntitySelectorBuilderJS;
        gamemode(gamemodeName: string, inverse: boolean): $EntitySelectorBuilderJS;
        gamemode(gamemodeName: string): $EntitySelectorBuilderJS;
        level(minLevel: number, maxLevel: number): $EntitySelectorBuilderJS;
        limit(limit: number): $EntitySelectorBuilderJS;
        name(name: string, inverse: boolean): $EntitySelectorBuilderJS;
        name(name: string): $EntitySelectorBuilderJS;
        orderArbitrary(): $EntitySelectorBuilderJS;
        orderFurthest(): $EntitySelectorBuilderJS;
        orderNearest(): $EntitySelectorBuilderJS;
        orderRandom(): $EntitySelectorBuilderJS;
        tag(tag: string, inverse: boolean): $EntitySelectorBuilderJS;
        tag(tag: string): $EntitySelectorBuilderJS;
        team(team: string, inverse: boolean): $EntitySelectorBuilderJS;
        team(team: string): $EntitySelectorBuilderJS;
        typeTag(tagId: string, inverse: boolean): $EntitySelectorBuilderJS;
        typeTag(tagId: string): $EntitySelectorBuilderJS;
        type(entityTypeId: string, inverse: boolean): $EntitySelectorBuilderJS;
        type(entityTypeId: string): $EntitySelectorBuilderJS;
        x(x: number): $EntitySelectorBuilderJS;
        y(y: number): $EntitySelectorBuilderJS;
        z(z: number): $EntitySelectorBuilderJS;
    }

    export class $EntitySelectorsJS {
        constructor();
        allEntities(): $EntitySelectorBuilderJS;
        allPlayers(): $EntitySelectorBuilderJS;
        builder(): $EntitySelectorBuilderJS;
        create(config: $Consumer_<$EntitySelectorBuilderJS, $EntitySelectorBuilderJS>): $EntitySelector;
        find(level: $ServerLevel, selector: $EntitySelector, x: number, y: number, z: number): $List<$Entity>;
        find(level: $ServerLevel, selector: $EntitySelector): $List<$Entity>;
        nearestEntity(): $EntitySelectorBuilderJS;
        nearestPlayer(): $EntitySelectorBuilderJS;
        randomEntity(): $EntitySelectorBuilderJS;
        randomPlayer(): $EntitySelectorBuilderJS;
    }

}
