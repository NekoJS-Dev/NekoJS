import { $Consumer, $Consumer_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";

declare module "java:com/tkisor/nekojs/wrapper/pdata" {
    export class $PersistentDataJS {
        constructor(getter: $Supplier_<$CompoundTag, $CompoundTag_>, saver: $Consumer_<$CompoundTag, $CompoundTag>);
        constructor(getter: $Supplier_<$CompoundTag, $CompoundTag_>, saver: $Consumer_<$CompoundTag, $CompoundTag>, dirtyMarker: $Runnable_, syncer: $Runnable_);
        static readOnly(getter: $Supplier_<$CompoundTag, $CompoundTag_>): $PersistentDataJS;
        clear(): $PersistentDataJS;
        contains(key: string): boolean;
        copyTag(): $CompoundTag;
        edit(editor: $Consumer_<$CompoundTag, $CompoundTag>): $PersistentDataJS;
        getBoolean(key: string): boolean;
        getByteArray(key: string): number[];
        getByte(key: string): number;
        getCompound(key: string): $CompoundTag;
        getDouble(key: string): number;
        getFloat(key: string): number;
        getIntArray(key: string): number[];
        getInt(key: string): number;
        getLongArray(key: string): number[];
        getLong(key: string): number;
        getShort(key: string): number;
        getString(key: string): string;
        get(key: string): object;
        markDirty(): $PersistentDataJS;
        merge(other: $CompoundTag_): $PersistentDataJS;
        putBoolean(key: string, value: boolean): $PersistentDataJS;
        putByteArray(key: string, value: number[]): $PersistentDataJS;
        putByte(key: string, value: number): $PersistentDataJS;
        putCompound(key: string, value: $CompoundTag_): $PersistentDataJS;
        putDouble(key: string, value: number): $PersistentDataJS;
        putFloat(key: string, value: number): $PersistentDataJS;
        putIntArray(key: string, value: number[]): $PersistentDataJS;
        putInt(key: string, value: number): $PersistentDataJS;
        putLongArray(key: string, value: number[]): $PersistentDataJS;
        putLong(key: string, value: number): $PersistentDataJS;
        putShort(key: string, value: number): $PersistentDataJS;
        putString(key: string, value: string): $PersistentDataJS;
        remove(key: string): $PersistentDataJS;
        replaceTag(tag: $CompoundTag_): $PersistentDataJS;
        sync(): $PersistentDataJS;
    }

}
