import { $BiFunction, $BiFunction_, $Supplier, $Supplier_ } from "java:java/util/function";
import { $Direction, $Direction_ } from "java:net/minecraft/core";
import { $Entity } from "java:net/minecraft/world/entity";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $BlockEntity } from "java:net/minecraft/world/level/block/entity";
import { $BlockCapability, $EntityCapability, $IBlockCapabilityProvider, $IBlockCapabilityProvider_, $ItemCapability, $RegisterCapabilitiesEvent } from "java:net/neoforged/neoforge/capabilities";

declare module "java:com/tkisor/nekojs/wrapper/event/registry" {
    export class $CapabilityRegistryEventJS {
        constructor();
        apply(event: $RegisterCapabilitiesEvent): void;
        registerBlockEntityContext(typeId: string, capability: string, provider: $BiFunction_<$BlockEntity, $Direction, any, $BlockEntity, $Direction, any>): void;
        registerBlockEntityNative<T, C>(typeId: string, capability: $BlockCapability<T, C>, provider: $BiFunction_<$BlockEntity, C, T, $BlockEntity, C, T>): void;
        registerBlockEntity(typeId: string, capability: string, provider: $Supplier_<any, any>): void;
        registerBlockNative<T, C>(blockId: string, capability: $BlockCapability<T, C>, provider: $IBlockCapabilityProvider_<T, C, $Level, $BlockPos, $BlockState, $BlockEntity, C, T>): void;
        registerBlock(blockId: string, capability: string, provider: $IBlockCapabilityProvider_<any, object, $Level, $BlockPos, $BlockState, $BlockEntity, object, any>): void;
        registerEntityNative<T, C>(typeId: string, capability: $EntityCapability<T, C>, provider: $BiFunction_<$Entity, C, T, $Entity, C, T>): void;
        registerEntity(typeId: string, capability: string, provider: $BiFunction_<$Entity, object, any, $Entity, object, any>): void;
        registerItemNative<T, C>(itemId: string, capability: $ItemCapability<T, C>, provider: $BiFunction_<$ItemStack, C, T, $ItemStack, C, T>): void;
        registerItem(itemId: string, capability: string, provider: $BiFunction_<$ItemStack, object, any, $ItemStack, object, any>): void;
    }

}
