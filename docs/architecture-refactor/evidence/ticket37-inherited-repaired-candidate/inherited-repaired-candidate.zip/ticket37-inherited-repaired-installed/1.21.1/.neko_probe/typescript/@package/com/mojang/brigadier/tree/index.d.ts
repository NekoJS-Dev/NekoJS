import { $AmbiguityConsumer, $AmbiguityConsumer_, $Command, $Command_, $RedirectModifier, $RedirectModifier_, $StringReader } from "java:com/mojang/brigadier";
import { $ArgumentType, $ArgumentType_ } from "java:com/mojang/brigadier/arguments";
import { $ArgumentBuilder, $LiteralArgumentBuilder, $RequiredArgumentBuilder } from "java:com/mojang/brigadier/builder";
import { $CommandContext, $CommandContextBuilder } from "java:com/mojang/brigadier/context";
import { $SuggestionProvider, $SuggestionProvider_, $Suggestions, $SuggestionsBuilder } from "java:com/mojang/brigadier/suggestion";
import { $Comparable, $Comparable_ } from "java:java/lang";
import { $Collection } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";
import { $Predicate, $Predicate_ } from "java:java/util/function";

declare module "java:com/mojang/brigadier/tree" {
    export class $ArgumentCommandNode<S, T> extends $CommandNode<S> {
        constructor(arg0: string, arg1: $ArgumentType_<T, $StringReader, T>, arg2: $Command_<S, $CommandContext<S>, number>, arg3: $Predicate_<S, S, boolean>, arg4: $CommandNode<S>, arg5: $RedirectModifier_<S, $CommandContext<S>, S[]>, arg6: boolean, arg7: $SuggestionProvider_<S, $CommandContext<S>, $SuggestionsBuilder, $CompletableFuture<$Suggestions>>);
        get customSuggestions(): $SuggestionProvider<S>;
        getCustomSuggestions(): $SuggestionProvider<S>;
        get examples(): $Collection<string>;
        getExamples(): $Collection<string>;
        get name(): string;
        getName(): string;
        get type(): $ArgumentType<T>;
        getType(): $ArgumentType<T>;
        get usageText(): string;
        getUsageText(): string;
        createBuilder(): $RequiredArgumentBuilder<S, T>;
        equals(arg0: object): boolean;
        hashCode(): number;
        isValidInput(arg0: string): boolean;
        listSuggestions(arg0: $CommandContext<S>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        parse(arg0: $StringReader, arg1: $CommandContextBuilder<S>): void;
        toString(): string;
    }

    export class $CommandNode<S> implements $Comparable<$CommandNode<S>> {
        get children(): $Collection<$CommandNode<S>>;
        getChildren(): $Collection<$CommandNode<S>>;
        get command(): $Command<S>;
        getCommand(): $Command<S>;
        get examples(): $Collection<string>;
        getExamples(): $Collection<string>;
        get name(): string;
        getName(): string;
        get redirectModifier(): $RedirectModifier<S>;
        getRedirectModifier(): $RedirectModifier<S>;
        get redirect(): $CommandNode<S>;
        getRedirect(): $CommandNode<S>;
        get requirement(): $Predicate<S>;
        getRequirement(): $Predicate<S>;
        get usageText(): string;
        getUsageText(): string;
        get fork(): boolean;
        isFork(): boolean;
        addChild(arg0: $CommandNode<S>): void;
        canUse(arg0: S): boolean;
        compareTo(arg0: $CommandNode<S>): number;
        createBuilder(): $ArgumentBuilder<S, any>;
        equals(arg0: object): boolean;
        findAmbiguities(arg0: $AmbiguityConsumer_<S, $CommandNode<S>, $CommandNode<S>, $CommandNode<S>, $Collection<string>>): void;
        getChild(arg0: string): $CommandNode<S>;
        getRelevantNodes(arg0: $StringReader): $Collection<$CommandNode<S>>;
        hashCode(): number;
        listSuggestions(arg0: $CommandContext<S>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        parse(arg0: $StringReader, arg1: $CommandContextBuilder<S>): void;
    }

    export class $LiteralCommandNode<S> extends $CommandNode<S> {
        constructor(arg0: string, arg1: $Command_<S, $CommandContext<S>, number>, arg2: $Predicate_<S, S, boolean>, arg3: $CommandNode<S>, arg4: $RedirectModifier_<S, $CommandContext<S>, S[]>, arg5: boolean);
        get examples(): $Collection<string>;
        getExamples(): $Collection<string>;
        get literal(): string;
        getLiteral(): string;
        get name(): string;
        getName(): string;
        get usageText(): string;
        getUsageText(): string;
        createBuilder(): $LiteralArgumentBuilder<S>;
        equals(arg0: object): boolean;
        hashCode(): number;
        isValidInput(arg0: string): boolean;
        listSuggestions(arg0: $CommandContext<S>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        parse(arg0: $StringReader, arg1: $CommandContextBuilder<S>): void;
        toString(): string;
    }

    export class $RootCommandNode<S> extends $CommandNode<S> {
        constructor();
        get examples(): $Collection<string>;
        getExamples(): $Collection<string>;
        get name(): string;
        getName(): string;
        get usageText(): string;
        getUsageText(): string;
        createBuilder(): $ArgumentBuilder<S, any>;
        equals(arg0: object): boolean;
        isValidInput(arg0: string): boolean;
        listSuggestions(arg0: $CommandContext<S>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
        parse(arg0: $StringReader, arg1: $CommandContextBuilder<S>): void;
        toString(): string;
    }

}
