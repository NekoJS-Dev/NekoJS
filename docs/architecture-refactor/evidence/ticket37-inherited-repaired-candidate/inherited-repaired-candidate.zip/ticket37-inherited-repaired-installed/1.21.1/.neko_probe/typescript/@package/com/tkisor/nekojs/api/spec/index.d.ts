export * as inject from "java:com/tkisor/nekojs/api/spec/inject";

