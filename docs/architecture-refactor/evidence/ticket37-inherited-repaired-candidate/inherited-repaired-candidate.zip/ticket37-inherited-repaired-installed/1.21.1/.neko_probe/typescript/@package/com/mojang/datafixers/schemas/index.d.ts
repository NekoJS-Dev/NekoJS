import { $DSL$TypeReference, $DSL$TypeReference_ } from "java:com/mojang/datafixers";
import { $Type } from "java:com/mojang/datafixers/types";
import { $TaggedChoice$TaggedChoiceType, $TypeTemplate } from "java:com/mojang/datafixers/types/templates";
import { $Map, $Set } from "java:java/util";
import { $Function, $Function_, $Supplier, $Supplier_ } from "java:java/util/function";

declare module "java:com/mojang/datafixers/schemas" {
    export class $Schema {
        constructor(arg0: number, arg1: $Schema);
        get parent(): $Schema;
        getParent(): $Schema;
        get versionKey(): number;
        getVersionKey(): number;
        findChoiceType(arg0: $DSL$TypeReference_<string>): $TaggedChoice$TaggedChoiceType<any>;
        getChoiceType(arg0: $DSL$TypeReference_<string>, arg1: string): $Type<any>;
        getTypeRaw(arg0: $DSL$TypeReference_<string>): $Type<any>;
        getType(arg0: $DSL$TypeReference_<string>): $Type<any>;
        id(arg0: string): $TypeTemplate;
        registerBlockEntities(arg0: $Schema): $Map<string, $Supplier<$TypeTemplate>>;
        registerEntities(arg0: $Schema): $Map<string, $Supplier<$TypeTemplate>>;
        registerSimple(arg0: ($Map<string, $Supplier_<$TypeTemplate, $TypeTemplate>> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, $Supplier_<$TypeTemplate, $TypeTemplate>>> : never)), arg1: string): void;
        registerTypes(arg0: $Schema, arg1: ($Map<string, $Supplier_<$TypeTemplate, $TypeTemplate>> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, $Supplier_<$TypeTemplate, $TypeTemplate>>> : never)), arg2: ($Map<string, $Supplier_<$TypeTemplate, $TypeTemplate>> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, $Supplier_<$TypeTemplate, $TypeTemplate>>> : never))): void;
        registerType(arg0: boolean, arg1: $DSL$TypeReference_<string>, arg2: $Supplier_<$TypeTemplate, $TypeTemplate>): void;
        register(arg0: ($Map<string, $Supplier_<$TypeTemplate, $TypeTemplate>> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, $Supplier_<$TypeTemplate, $TypeTemplate>>> : never)), arg1: string, arg2: $Function_<string, $TypeTemplate, string, $TypeTemplate>): void;
        register(arg0: ($Map<string, $Supplier_<$TypeTemplate, $TypeTemplate>> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, $Supplier_<$TypeTemplate, $TypeTemplate>>> : never)), arg1: string, arg2: $Supplier_<$TypeTemplate, $TypeTemplate>): void;
        resolveTemplate(arg0: string): $TypeTemplate;
        types(): $Set<string>;
    }

}
