import { $GameProfile, $SignatureState, $SignatureState_ } from "java:com/mojang/authlib";
import { $AbuseReportLimits } from "java:com/mojang/authlib/minecraft/report";
import { $Property } from "java:com/mojang/authlib/properties";
import { $ProfileResult } from "java:com/mojang/authlib/yggdrasil";
import { $AbuseReportRequest } from "java:com/mojang/authlib/yggdrasil/request";
import { $KeyPairResponse } from "java:com/mojang/authlib/yggdrasil/response";
import { $Record } from "java:java/lang";
import { $InetAddress } from "java:java/net";
import { $Map, $Set, $UUID } from "java:java/util";
import { $Executor, $Executor_ } from "java:java/util/concurrent";

export * as report from "java:com/mojang/authlib/minecraft/report";

declare module "java:com/mojang/authlib/minecraft" {
    export class $MinecraftProfileTexture {
        constructor(arg0: string, arg1: ($Map<string, string> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, string>> : never)));
        static PROFILE_TEXTURE_COUNT: number;
        get hash(): string;
        getHash(): string;
        get url(): string;
        getUrl(): string;
        getMetadata(arg0: string): string;
        toString(): string;
    }

    export class $MinecraftProfileTextures extends $Record {
        constructor(skin: $MinecraftProfileTexture, cape: $MinecraftProfileTexture, elytra: $MinecraftProfileTexture, signatureState: $SignatureState_);
        static EMPTY: $MinecraftProfileTextures;
        cape(): $MinecraftProfileTexture;
        elytra(): $MinecraftProfileTexture;
        equals(arg0: object): boolean;
        hashCode(): number;
        signatureState(): $SignatureState;
        skin(): $MinecraftProfileTexture;
        toString(): string;
    }

    export interface $MinecraftSessionService {
        fetchProfile(arg0: string, arg1: boolean): $ProfileResult;
        getPackedTextures(arg0: $GameProfile): $Property;
        getSecurePropertyValue(arg0: $Property): string;
        getTextures(arg0: $GameProfile): $MinecraftProfileTextures;
        hasJoinedServer(arg0: string, arg1: string, arg2: $InetAddress): $ProfileResult;
        joinServer(arg0: string, arg1: string, arg2: string): void;
        unpackTextures(arg0: $Property): $MinecraftProfileTextures;
    }

    export interface $TelemetrySession {
        createNewEvent(arg0: string): $TelemetryEvent;
        isEnabled(): boolean;
    }
    export const $TelemetrySession: {
        readonly DISABLED: $TelemetrySession;
    };

    export interface $UserApiService {
        canSendReports(): boolean;
        fetchProperties(): $UserApiService$UserProperties;
        getAbuseReportLimits(): $AbuseReportLimits;
        getKeyPair(): $KeyPairResponse;
        isBlockedPlayer(arg0: string): boolean;
        newTelemetrySession(arg0: $Executor_<$Runnable>): $TelemetrySession;
        refreshBlockList(): void;
        reportAbuse(arg0: $AbuseReportRequest): void;
    }
    export const $UserApiService: {
        readonly OFFLINE: $UserApiService;
        readonly OFFLINE_PROPERTIES: $UserApiService$UserProperties;
    };

    export class $UserApiService$UserProperties extends $Record {
        constructor(flags: $UserApiService$UserFlag_[], bannedScopes: ($Map<string, $BanDetails> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, $BanDetails>> : never)));
        bannedScopes(): $Map<string, $BanDetails>;
        equals(arg0: object): boolean;
        flags(): $Set<$UserApiService$UserFlag>;
        flag(arg0: $UserApiService$UserFlag_): boolean;
        hashCode(): number;
        toString(): string;
    }

}
