export * as events from "java:com/tkisor/nekojs/probe/events";
export * as ir from "java:com/tkisor/nekojs/probe/ir";

