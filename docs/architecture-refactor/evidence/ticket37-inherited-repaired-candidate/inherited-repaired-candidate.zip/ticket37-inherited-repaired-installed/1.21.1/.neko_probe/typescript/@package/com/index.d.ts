export * as mojang from "java:com/mojang";
export * as tkisor from "java:com/tkisor";

