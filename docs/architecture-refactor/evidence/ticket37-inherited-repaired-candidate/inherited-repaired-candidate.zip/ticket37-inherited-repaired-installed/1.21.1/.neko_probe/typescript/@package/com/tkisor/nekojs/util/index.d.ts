export * as selector from "java:com/tkisor/nekojs/util/selector";

