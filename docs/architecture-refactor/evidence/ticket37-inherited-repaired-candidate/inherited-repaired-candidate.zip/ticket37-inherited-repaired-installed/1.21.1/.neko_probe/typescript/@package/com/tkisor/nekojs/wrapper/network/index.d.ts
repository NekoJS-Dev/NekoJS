import { $CompoundTag, $CompoundTag_ } from "java:net/minecraft/nbt";
import { $ServerPlayer } from "java:net/minecraft/server/level";

declare module "java:com/tkisor/nekojs/wrapper/network" {
    export class $NetworkDataEventJS {
        constructor(channel: string, data: $CompoundTag_, sender: $ServerPlayer);
        get channel(): string;
        getChannel(): string;
        get data(): $CompoundTag;
        getData(): $CompoundTag;
        get player(): $ServerPlayer;
        getPlayer(): $ServerPlayer;
    }

    export class $NetworkJS {
        constructor();
        static sendToAll(channel: string, data: $CompoundTag_): void;
        static sendToPlayer(player: $ServerPlayer, channel: string, data: $CompoundTag_): void;
        static sendToServer(channel: string, data: $CompoundTag_): void;
    }

}
