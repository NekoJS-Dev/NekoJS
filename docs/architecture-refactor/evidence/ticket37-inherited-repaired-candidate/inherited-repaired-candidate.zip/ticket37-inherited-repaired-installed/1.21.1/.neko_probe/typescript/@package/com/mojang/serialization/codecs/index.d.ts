import { $Products$P1, $Products$P10, $Products$P11, $Products$P12, $Products$P13, $Products$P14, $Products$P15, $Products$P16, $Products$P2, $Products$P3, $Products$P4, $Products$P5, $Products$P6, $Products$P7, $Products$P8, $Products$P9 } from "java:com/mojang/datafixers";
import { $App, $Applicative, $Applicative$Mu, $K1 } from "java:com/mojang/datafixers/kinds";
import { $Function10, $Function10_, $Function11, $Function11_, $Function12, $Function12_, $Function13, $Function13_, $Function14, $Function14_, $Function15, $Function15_, $Function16, $Function16_, $Function3, $Function3_, $Function4, $Function4_, $Function5, $Function5_, $Function6, $Function6_, $Function7, $Function7_, $Function8, $Function8_, $Function9, $Function9_, $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $Codec$ResultFunction, $DataResult, $Decoder, $Decoder$Boxed, $Decoder$Boxed_, $Decoder$Simple, $Decoder$Simple_, $Decoder$Terminal, $Decoder$Terminal_, $Decoder_, $Dynamic, $DynamicOps, $Encoder, $Encoder_, $Lifecycle, $MapCodec, $MapDecoder, $MapEncoder, $MapLike, $RecordBuilder } from "java:com/mojang/serialization";
import { $Record } from "java:java/lang";
import { $List, $Map, $Optional } from "java:java/util";
import { $BiFunction, $BiFunction_, $Consumer, $Consumer_, $Function, $Function_, $Supplier, $Supplier_, $UnaryOperator, $UnaryOperator_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";

declare module "java:com/mojang/serialization/codecs" {
    export interface $BaseMapCodec<K, V> {
        decode<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>): $DataResult<$Map<K, V>>;
        elementCodec(): $Codec<V>;
        encode<T>(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg1: $DynamicOps<T>, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
        keyCodec(): $Codec<K>;
    }

    export interface $PrimitiveCodec<A> extends $Codec<A> {
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<A, T>>;
        encode<T>(arg0: A, arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
        read<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<A>;
        write<T>(arg0: $DynamicOps<T>, arg1: A): T;
    }

    export class $RecordCodecBuilder<O, F> implements $App<$RecordCodecBuilder$Mu<O>, F> {
        static build<O>(arg0: $App<$RecordCodecBuilder$Mu<O>, O>): $MapCodec<O>;
        static create<O>(arg0: $Function_<$RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>, $RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>>): $Codec<O>;
        static deprecated<O, F>(arg0: F, arg1: number): $RecordCodecBuilder<O, F>;
        static instance<O>(): $RecordCodecBuilder$Instance<O>;
        static mapCodec<O>(arg0: $Function_<$RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>, $RecordCodecBuilder$Instance<O>, $App<$RecordCodecBuilder$Mu<O>, O>>): $MapCodec<O>;
        static of<O, F>(arg0: $Function_<O, F, O, F>, arg1: $MapCodec<F>): $RecordCodecBuilder<O, F>;
        static of<O, F>(arg0: $Function_<O, F, O, F>, arg1: string, arg2: $Codec<F>): $RecordCodecBuilder<O, F>;
        static point<O, F>(arg0: F, arg1: $Lifecycle): $RecordCodecBuilder<O, F>;
        static point<O, F>(arg0: F): $RecordCodecBuilder<O, F>;
        static stable<O, F>(arg0: F): $RecordCodecBuilder<O, F>;
        static unbox<O, F>(arg0: $App<$RecordCodecBuilder$Mu<O>, F>): $RecordCodecBuilder<O, F>;
        dependent<E>(arg0: $Function_<O, E, O, E>, arg1: $MapEncoder<E>, arg2: $Function_<F, $MapDecoder<E>, F, $MapDecoder<E>>): $RecordCodecBuilder<O, E>;
    }

    export class $RecordCodecBuilder$Instance<O> implements $Applicative<$RecordCodecBuilder$Mu<O>, $RecordCodecBuilder$Instance$Mu<O>> {
        constructor();
        ap10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>, arg10: $App<$RecordCodecBuilder$Mu<O>, T10>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>, arg10: $App<$RecordCodecBuilder$Mu<O>, T10>, arg11: $App<$RecordCodecBuilder$Mu<O>, T11>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>, arg10: $App<$RecordCodecBuilder$Mu<O>, T10>, arg11: $App<$RecordCodecBuilder$Mu<O>, T11>, arg12: $App<$RecordCodecBuilder$Mu<O>, T12>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>, arg10: $App<$RecordCodecBuilder$Mu<O>, T10>, arg11: $App<$RecordCodecBuilder$Mu<O>, T11>, arg12: $App<$RecordCodecBuilder$Mu<O>, T12>, arg13: $App<$RecordCodecBuilder$Mu<O>, T13>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>, arg10: $App<$RecordCodecBuilder$Mu<O>, T10>, arg11: $App<$RecordCodecBuilder$Mu<O>, T11>, arg12: $App<$RecordCodecBuilder$Mu<O>, T12>, arg13: $App<$RecordCodecBuilder$Mu<O>, T13>, arg14: $App<$RecordCodecBuilder$Mu<O>, T14>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>, arg10: $App<$RecordCodecBuilder$Mu<O>, T10>, arg11: $App<$RecordCodecBuilder$Mu<O>, T11>, arg12: $App<$RecordCodecBuilder$Mu<O>, T12>, arg13: $App<$RecordCodecBuilder$Mu<O>, T13>, arg14: $App<$RecordCodecBuilder$Mu<O>, T14>, arg15: $App<$RecordCodecBuilder$Mu<O>, T15>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>, arg10: $App<$RecordCodecBuilder$Mu<O>, T10>, arg11: $App<$RecordCodecBuilder$Mu<O>, T11>, arg12: $App<$RecordCodecBuilder$Mu<O>, T12>, arg13: $App<$RecordCodecBuilder$Mu<O>, T13>, arg14: $App<$RecordCodecBuilder$Mu<O>, T14>, arg15: $App<$RecordCodecBuilder$Mu<O>, T15>, arg16: $App<$RecordCodecBuilder$Mu<O>, T16>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap2<A, B, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $BiFunction<A, B, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, A>, arg2: $App<$RecordCodecBuilder$Mu<O>, B>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap3<T1, T2, T3, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function3<T1, T2, T3, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap4<T1, T2, T3, T4, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function4<T1, T2, T3, T4, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap5<T1, T2, T3, T4, T5, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function5<T1, T2, T3, T4, T5, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap6<T1, T2, T3, T4, T5, T6, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function6<T1, T2, T3, T4, T5, T6, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap7<T1, T2, T3, T4, T5, T6, T7, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function7<T1, T2, T3, T4, T5, T6, T7, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap8<T1, T2, T3, T4, T5, T6, T7, T8, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function8<T1, T2, T3, T4, T5, T6, T7, T8, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap9<T1, T2, T3, T4, T5, T6, T7, T8, T9, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function9<T1, T2, T3, T4, T5, T6, T7, T8, T9, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>): $App<$RecordCodecBuilder$Mu<O>, R>;
        apply2<A, B, R>(arg0: $BiFunction_<A, B, R, A, B, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, A>, arg2: $App<$RecordCodecBuilder$Mu<O>, B>): $App<$RecordCodecBuilder$Mu<O>, R>;
        apply3<T1, T2, T3, R>(arg0: $Function3_<T1, T2, T3, R, T1, T2, T3, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>): $App<$RecordCodecBuilder$Mu<O>, R>;
        apply4<T1, T2, T3, T4, R>(arg0: $Function4_<T1, T2, T3, T4, R, T1, T2, T3, T4, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>): $App<$RecordCodecBuilder$Mu<O>, R>;
        apply5<T1, T2, T3, T4, T5, R>(arg0: $Function5_<T1, T2, T3, T4, T5, R, T1, T2, T3, T4, T5, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>): $App<$RecordCodecBuilder$Mu<O>, R>;
        apply6<T1, T2, T3, T4, T5, T6, R>(arg0: $Function6_<T1, T2, T3, T4, T5, T6, R, T1, T2, T3, T4, T5, T6, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>): $App<$RecordCodecBuilder$Mu<O>, R>;
        apply7<T1, T2, T3, T4, T5, T6, T7, R>(arg0: $Function7_<T1, T2, T3, T4, T5, T6, T7, R, T1, T2, T3, T4, T5, T6, T7, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>): $App<$RecordCodecBuilder$Mu<O>, R>;
        apply8<T1, T2, T3, T4, T5, T6, T7, T8, R>(arg0: $Function8_<T1, T2, T3, T4, T5, T6, T7, T8, R, T1, T2, T3, T4, T5, T6, T7, T8, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>): $App<$RecordCodecBuilder$Mu<O>, R>;
        apply9<T1, T2, T3, T4, T5, T6, T7, T8, T9, R>(arg0: $Function9_<T1, T2, T3, T4, T5, T6, T7, T8, T9, R, T1, T2, T3, T4, T5, T6, T7, T8, T9, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T1>, arg2: $App<$RecordCodecBuilder$Mu<O>, T2>, arg3: $App<$RecordCodecBuilder$Mu<O>, T3>, arg4: $App<$RecordCodecBuilder$Mu<O>, T4>, arg5: $App<$RecordCodecBuilder$Mu<O>, T5>, arg6: $App<$RecordCodecBuilder$Mu<O>, T6>, arg7: $App<$RecordCodecBuilder$Mu<O>, T7>, arg8: $App<$RecordCodecBuilder$Mu<O>, T8>, arg9: $App<$RecordCodecBuilder$Mu<O>, T9>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap<A, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function<A, R>>, arg1: $App<$RecordCodecBuilder$Mu<O>, A>): $App<$RecordCodecBuilder$Mu<O>, R>;
        ap<A, R>(arg0: $Function_<A, R, A, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, A>): $App<$RecordCodecBuilder$Mu<O>, R>;
        deprecated<A>(arg0: A, arg1: number): $App<$RecordCodecBuilder$Mu<O>, A>;
        group<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>, arg8: $App<$RecordCodecBuilder$Mu<O>, T9>, arg9: $App<$RecordCodecBuilder$Mu<O>, T10>, arg10: $App<$RecordCodecBuilder$Mu<O>, T11>, arg11: $App<$RecordCodecBuilder$Mu<O>, T12>, arg12: $App<$RecordCodecBuilder$Mu<O>, T13>, arg13: $App<$RecordCodecBuilder$Mu<O>, T14>, arg14: $App<$RecordCodecBuilder$Mu<O>, T15>, arg15: $App<$RecordCodecBuilder$Mu<O>, T16>): $Products$P16<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>;
        group<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>, arg8: $App<$RecordCodecBuilder$Mu<O>, T9>, arg9: $App<$RecordCodecBuilder$Mu<O>, T10>, arg10: $App<$RecordCodecBuilder$Mu<O>, T11>, arg11: $App<$RecordCodecBuilder$Mu<O>, T12>, arg12: $App<$RecordCodecBuilder$Mu<O>, T13>, arg13: $App<$RecordCodecBuilder$Mu<O>, T14>, arg14: $App<$RecordCodecBuilder$Mu<O>, T15>): $Products$P15<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>;
        group<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>, arg8: $App<$RecordCodecBuilder$Mu<O>, T9>, arg9: $App<$RecordCodecBuilder$Mu<O>, T10>, arg10: $App<$RecordCodecBuilder$Mu<O>, T11>, arg11: $App<$RecordCodecBuilder$Mu<O>, T12>, arg12: $App<$RecordCodecBuilder$Mu<O>, T13>, arg13: $App<$RecordCodecBuilder$Mu<O>, T14>): $Products$P14<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>;
        group<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>, arg8: $App<$RecordCodecBuilder$Mu<O>, T9>, arg9: $App<$RecordCodecBuilder$Mu<O>, T10>, arg10: $App<$RecordCodecBuilder$Mu<O>, T11>, arg11: $App<$RecordCodecBuilder$Mu<O>, T12>, arg12: $App<$RecordCodecBuilder$Mu<O>, T13>): $Products$P13<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>;
        group<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>, arg8: $App<$RecordCodecBuilder$Mu<O>, T9>, arg9: $App<$RecordCodecBuilder$Mu<O>, T10>, arg10: $App<$RecordCodecBuilder$Mu<O>, T11>, arg11: $App<$RecordCodecBuilder$Mu<O>, T12>): $Products$P12<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>;
        group<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>, arg8: $App<$RecordCodecBuilder$Mu<O>, T9>, arg9: $App<$RecordCodecBuilder$Mu<O>, T10>, arg10: $App<$RecordCodecBuilder$Mu<O>, T11>): $Products$P11<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>;
        group<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>, arg8: $App<$RecordCodecBuilder$Mu<O>, T9>, arg9: $App<$RecordCodecBuilder$Mu<O>, T10>): $Products$P10<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>;
        group<T1, T2, T3, T4, T5, T6, T7, T8, T9>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>, arg8: $App<$RecordCodecBuilder$Mu<O>, T9>): $Products$P9<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8, T9>;
        group<T1, T2, T3, T4, T5, T6, T7, T8>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>, arg7: $App<$RecordCodecBuilder$Mu<O>, T8>): $Products$P8<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7, T8>;
        group<T1, T2, T3, T4, T5, T6, T7>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>, arg6: $App<$RecordCodecBuilder$Mu<O>, T7>): $Products$P7<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6, T7>;
        group<T1, T2, T3, T4, T5, T6>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>, arg5: $App<$RecordCodecBuilder$Mu<O>, T6>): $Products$P6<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5, T6>;
        group<T1, T2, T3, T4, T5>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>, arg4: $App<$RecordCodecBuilder$Mu<O>, T5>): $Products$P5<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4, T5>;
        group<T1, T2, T3, T4>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>, arg3: $App<$RecordCodecBuilder$Mu<O>, T4>): $Products$P4<$RecordCodecBuilder$Mu<O>, T1, T2, T3, T4>;
        group<T1, T2, T3>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>, arg2: $App<$RecordCodecBuilder$Mu<O>, T3>): $Products$P3<$RecordCodecBuilder$Mu<O>, T1, T2, T3>;
        group<T1, T2>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>, arg1: $App<$RecordCodecBuilder$Mu<O>, T2>): $Products$P2<$RecordCodecBuilder$Mu<O>, T1, T2>;
        group<T1>(arg0: $App<$RecordCodecBuilder$Mu<O>, T1>): $Products$P1<$RecordCodecBuilder$Mu<O>, T1>;
        lift1<A, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function<A, R>>): $Function<$App<$RecordCodecBuilder$Mu<O>, A>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        lift2<A, B, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $BiFunction<A, B, R>>): $BiFunction<$App<$RecordCodecBuilder$Mu<O>, A>, $App<$RecordCodecBuilder$Mu<O>, B>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        lift3<T1, T2, T3, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function3<T1, T2, T3, R>>): $Function3<$App<$RecordCodecBuilder$Mu<O>, T1>, $App<$RecordCodecBuilder$Mu<O>, T2>, $App<$RecordCodecBuilder$Mu<O>, T3>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        lift4<T1, T2, T3, T4, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function4<T1, T2, T3, T4, R>>): $Function4<$App<$RecordCodecBuilder$Mu<O>, T1>, $App<$RecordCodecBuilder$Mu<O>, T2>, $App<$RecordCodecBuilder$Mu<O>, T3>, $App<$RecordCodecBuilder$Mu<O>, T4>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        lift5<T1, T2, T3, T4, T5, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function5<T1, T2, T3, T4, T5, R>>): $Function5<$App<$RecordCodecBuilder$Mu<O>, T1>, $App<$RecordCodecBuilder$Mu<O>, T2>, $App<$RecordCodecBuilder$Mu<O>, T3>, $App<$RecordCodecBuilder$Mu<O>, T4>, $App<$RecordCodecBuilder$Mu<O>, T5>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        lift6<T1, T2, T3, T4, T5, T6, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function6<T1, T2, T3, T4, T5, T6, R>>): $Function6<$App<$RecordCodecBuilder$Mu<O>, T1>, $App<$RecordCodecBuilder$Mu<O>, T2>, $App<$RecordCodecBuilder$Mu<O>, T3>, $App<$RecordCodecBuilder$Mu<O>, T4>, $App<$RecordCodecBuilder$Mu<O>, T5>, $App<$RecordCodecBuilder$Mu<O>, T6>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        lift7<T1, T2, T3, T4, T5, T6, T7, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function7<T1, T2, T3, T4, T5, T6, T7, R>>): $Function7<$App<$RecordCodecBuilder$Mu<O>, T1>, $App<$RecordCodecBuilder$Mu<O>, T2>, $App<$RecordCodecBuilder$Mu<O>, T3>, $App<$RecordCodecBuilder$Mu<O>, T4>, $App<$RecordCodecBuilder$Mu<O>, T5>, $App<$RecordCodecBuilder$Mu<O>, T6>, $App<$RecordCodecBuilder$Mu<O>, T7>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        lift8<T1, T2, T3, T4, T5, T6, T7, T8, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function8<T1, T2, T3, T4, T5, T6, T7, T8, R>>): $Function8<$App<$RecordCodecBuilder$Mu<O>, T1>, $App<$RecordCodecBuilder$Mu<O>, T2>, $App<$RecordCodecBuilder$Mu<O>, T3>, $App<$RecordCodecBuilder$Mu<O>, T4>, $App<$RecordCodecBuilder$Mu<O>, T5>, $App<$RecordCodecBuilder$Mu<O>, T6>, $App<$RecordCodecBuilder$Mu<O>, T7>, $App<$RecordCodecBuilder$Mu<O>, T8>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        lift9<T1, T2, T3, T4, T5, T6, T7, T8, T9, R>(arg0: $App<$RecordCodecBuilder$Mu<O>, $Function9<T1, T2, T3, T4, T5, T6, T7, T8, T9, R>>): $Function9<$App<$RecordCodecBuilder$Mu<O>, T1>, $App<$RecordCodecBuilder$Mu<O>, T2>, $App<$RecordCodecBuilder$Mu<O>, T3>, $App<$RecordCodecBuilder$Mu<O>, T4>, $App<$RecordCodecBuilder$Mu<O>, T5>, $App<$RecordCodecBuilder$Mu<O>, T6>, $App<$RecordCodecBuilder$Mu<O>, T7>, $App<$RecordCodecBuilder$Mu<O>, T8>, $App<$RecordCodecBuilder$Mu<O>, T9>, $App<$RecordCodecBuilder$Mu<O>, R>>;
        map<T, R>(arg0: $Function_<T, R, T, R>, arg1: $App<$RecordCodecBuilder$Mu<O>, T>): $App<$RecordCodecBuilder$Mu<O>, R>;
        point<A>(arg0: A, arg1: $Lifecycle): $App<$RecordCodecBuilder$Mu<O>, A>;
        point<A>(arg0: A): $App<$RecordCodecBuilder$Mu<O>, A>;
        stable<A>(arg0: A): $App<$RecordCodecBuilder$Mu<O>, A>;
    }

    export class $RecordCodecBuilder$Instance$Mu<O> implements $Applicative$Mu {
    }

    export class $RecordCodecBuilder$Mu<O> implements $K1 {
        constructor();
    }

    export class $SimpleMapCodec<K, V> extends $MapCodec<$Map<K, V>> implements $BaseMapCodec<K, V> {
        constructor(arg0: $Codec<K>, arg1: $Codec<V>, arg2: $Keyable_<$DynamicOps<any>, $Stream<any>>);
        ap<E>(arg0: $MapDecoder<$Function<any, E>>): $MapDecoder<E>;
        comap<B>(arg0: $Function_<B, $Map<K, V>, B, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>): $MapEncoder<B>;
        compressedBuilder<T>(arg0: $DynamicOps<T>): $RecordBuilder<T>;
        compressedDecode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Map<K, V>>;
        decoder(): $Decoder<$Map<K, V>>;
        decode<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>): $DataResult<$Map<K, V>>;
        elementCodec(): $Codec<V>;
        encoder(): $Encoder<$Map<K, V>>;
        encode<T>(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg1: $DynamicOps<T>, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
        equals(arg0: object): boolean;
        flatComap<B>(arg0: $Function_<B, $DataResult<$Map<K, V>>, B, $DataResult<$Map<K, V>>>): $MapEncoder<B>;
        flatMap<B>(arg0: $Function_<$Map<K, V>, $DataResult<B>, $Map<K, V>, $DataResult<B>>): $MapDecoder<B>;
        hashCode(): number;
        keyCodec(): $Codec<K>;
        keys<T>(arg0: $DynamicOps<T>): $Stream<T>;
        map<B>(arg0: $Function_<$Map<K, V>, B, $Map<K, V>, B>): $MapDecoder<B>;
        toString(): string;
    }

    export class $UnboundedMapCodec<K, V> extends $Record implements $BaseMapCodec<K, V>, $Codec<$Map<K, V>> {
        constructor(keyCodec: $Codec<K>, elementCodec: $Codec<V>);
        boxed(): $Decoder$Boxed<$Map<K, V>>;
        comapFlatMap<S>(arg0: $Function_<$Map<K, V>, $DataResult<S>, $Map<K, V>, $DataResult<S>>, arg1: $Function_<S, $Map<K, V>, S, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>): $Codec<S>;
        comap<B>(arg0: $Function_<B, $Map<K, V>, B, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>): $Encoder<B>;
        decode<T>(arg0: $Dynamic<T>): $DataResult<$Pair<$Map<K, V>, T>>;
        decode<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<$Map<K, V>, T>>;
        decode<T>(arg0: $DynamicOps<T>, arg1: $MapLike<T>): $DataResult<$Map<K, V>>;
        deprecated(arg0: number): $Codec<$Map<K, V>>;
        dispatchMap<E>(arg0: string, arg1: $Function_<E, $Map<K, V>, E, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>, arg2: $Function_<$Map<K, V>, $MapCodec<E>, $Map<K, V>, $MapCodec<E>>): $MapCodec<E>;
        dispatchMap<E>(arg0: $Function_<E, $Map<K, V>, E, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>, arg1: $Function_<$Map<K, V>, $MapCodec<E>, $Map<K, V>, $MapCodec<E>>): $MapCodec<E>;
        dispatchStable<E>(arg0: $Function_<E, $Map<K, V>, E, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>, arg1: $Function_<$Map<K, V>, $MapCodec<E>, $Map<K, V>, $MapCodec<E>>): $Codec<E>;
        dispatch<E>(arg0: string, arg1: $Function_<E, $Map<K, V>, E, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>, arg2: $Function_<$Map<K, V>, $MapCodec<E>, $Map<K, V>, $MapCodec<E>>): $Codec<E>;
        dispatch<E>(arg0: $Function_<E, $Map<K, V>, E, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>, arg1: $Function_<$Map<K, V>, $MapCodec<E>, $Map<K, V>, $MapCodec<E>>): $Codec<E>;
        elementCodec(): $Codec<V>;
        encodeStart<T>(arg0: $DynamicOps<T>, arg1: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): $DataResult<T>;
        encode<T>(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg1: $DynamicOps<T>, arg2: T): $DataResult<T>;
        encode<T>(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg1: $DynamicOps<T>, arg2: $RecordBuilder<T>): $RecordBuilder<T>;
        equals(arg0: object): boolean;
        fieldOf(arg0: string): $MapCodec<$Map<K, V>>;
        flatComapMap<S>(arg0: $Function_<$Map<K, V>, S, $Map<K, V>, S>, arg1: $Function_<S, $DataResult<$Map<K, V>>, S, $DataResult<$Map<K, V>>>): $Codec<S>;
        flatComap<B>(arg0: $Function_<B, $DataResult<$Map<K, V>>, B, $DataResult<$Map<K, V>>>): $Encoder<B>;
        flatMap<B>(arg0: $Function_<$Map<K, V>, $DataResult<B>, $Map<K, V>, $DataResult<B>>): $Decoder<B>;
        flatXmap<S>(arg0: $Function_<$Map<K, V>, $DataResult<S>, $Map<K, V>, $DataResult<S>>, arg1: $Function_<S, $DataResult<$Map<K, V>>, S, $DataResult<$Map<K, V>>>): $Codec<S>;
        hashCode(): number;
        keyCodec(): $Codec<K>;
        lenientOptionalFieldOf(arg0: string, arg1: $Lifecycle, arg2: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg3: $Lifecycle): $MapCodec<$Map<K, V>>;
        lenientOptionalFieldOf(arg0: string, arg1: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg2: $Lifecycle): $MapCodec<$Map<K, V>>;
        lenientOptionalFieldOf(arg0: string, arg1: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): $MapCodec<$Map<K, V>>;
        lenientOptionalFieldOf(arg0: string): $MapCodec<$Optional<$Map<K, V>>>;
        listOf(arg0: number, arg1: number): $Codec<$List<$Map<K, V>>>;
        listOf(): $Codec<$List<$Map<K, V>>>;
        mapResult(arg0: $Codec$ResultFunction<$Map<K, V>>): $Codec<$Map<K, V>>;
        map<B>(arg0: $Function_<$Map<K, V>, B, $Map<K, V>, B>): $Decoder<B>;
        optionalFieldOf(arg0: string, arg1: $Lifecycle, arg2: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg3: $Lifecycle): $MapCodec<$Map<K, V>>;
        optionalFieldOf(arg0: string, arg1: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never)), arg2: $Lifecycle): $MapCodec<$Map<K, V>>;
        optionalFieldOf(arg0: string, arg1: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): $MapCodec<$Map<K, V>>;
        optionalFieldOf(arg0: string): $MapCodec<$Optional<$Map<K, V>>>;
        orElseGet(arg0: $Consumer_<string, string>, arg1: $Supplier_<$Map<K, V>, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>): $Codec<$Map<K, V>>;
        orElseGet(arg0: $Supplier_<$Map<K, V>, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>): $Codec<$Map<K, V>>;
        orElseGet(arg0: $UnaryOperator_<string, string, string>, arg1: $Supplier_<$Map<K, V>, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>): $Codec<$Map<K, V>>;
        orElse(arg0: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): $Codec<$Map<K, V>>;
        orElse(arg0: $Consumer_<string, string>, arg1: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): $Codec<$Map<K, V>>;
        orElse(arg0: $UnaryOperator_<string, string, string>, arg1: ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))): $Codec<$Map<K, V>>;
        parse<T>(arg0: $Dynamic<T>): $DataResult<$Map<K, V>>;
        parse<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Map<K, V>>;
        partialDispatch<E>(arg0: string, arg1: $Function_<E, $DataResult<$Map<K, V>>, E, $DataResult<$Map<K, V>>>, arg2: $Function_<$Map<K, V>, $DataResult<$MapCodec<E>>, $Map<K, V>, $DataResult<$MapCodec<E>>>): $Codec<E>;
        promotePartial(arg0: $Consumer_<string, string>): $Codec<$Map<K, V>>;
        simple(): $Decoder$Simple<$Map<K, V>>;
        sizeLimitedListOf(arg0: number): $Codec<$List<$Map<K, V>>>;
        stable(): $Codec<$Map<K, V>>;
        terminal(): $Decoder$Terminal<$Map<K, V>>;
        toString(): string;
        validate(arg0: $Function_<$Map<K, V>, $DataResult<$Map<K, V>>, $Map<K, V>, $DataResult<$Map<K, V>>>): $Codec<$Map<K, V>>;
        withLifecycle(arg0: $Lifecycle): $Codec<$Map<K, V>>;
        xmap<S>(arg0: $Function_<$Map<K, V>, S, $Map<K, V>, S>, arg1: $Function_<S, $Map<K, V>, S, ($Map<K, V> | ([K] extends [PropertyKey] ? Partial<Record<Extract<K, PropertyKey>, V>> : never))>): $Codec<S>;
    }

}
