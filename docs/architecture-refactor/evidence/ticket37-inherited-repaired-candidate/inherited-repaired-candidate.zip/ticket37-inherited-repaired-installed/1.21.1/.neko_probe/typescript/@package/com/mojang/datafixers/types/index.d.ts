import { $OpticFinder, $RewriteResult, $TypeRewriteRule, $TypeRewriteRule_, $Typed, $TypedOptic } from "java:com/mojang/datafixers";
import { $PointFreeRule, $PointFreeRule_ } from "java:com/mojang/datafixers/functions";
import { $App, $K1 } from "java:com/mojang/datafixers/kinds";
import { $RecursiveTypeFamily } from "java:com/mojang/datafixers/types/families";
import { $TaggedChoice$TaggedChoiceType, $TypeTemplate } from "java:com/mojang/datafixers/types/templates";
import { $Either, $Pair } from "java:com/mojang/datafixers/util";
import { $Codec, $DataResult, $Dynamic, $DynamicOps } from "java:com/mojang/serialization";
import { $Optional } from "java:java/util";

export * as families from "java:com/mojang/datafixers/types/families";
export * as templates from "java:com/mojang/datafixers/types/templates";

declare module "java:com/mojang/datafixers/types" {
    export class $Type<A> implements $App<$Type$Mu, A> {
        constructor();
        static opticView<S, T, A, B>(arg0: $Type<S>, arg1: $RewriteResult<A, B>, arg2: $TypedOptic<S, T, A, B>): $RewriteResult<S, T>;
        static unbox<A>(arg0: $App<$Type$Mu, A>): $Type<A>;
        all(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: boolean, arg2: boolean): $RewriteResult<A, any>;
        buildTemplate(): $TypeTemplate;
        codec(): $Codec<A>;
        equals(arg0: object, arg1: boolean, arg2: boolean): boolean;
        equals(arg0: object): boolean;
        everywhere(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>, arg2: boolean, arg3: boolean): $Optional<$RewriteResult<A, any>>;
        findCheckedType(arg0: number): $Optional<$Type<any>>;
        findChoiceType(arg0: string, arg1: number): $Optional<$TaggedChoice$TaggedChoiceType<any>>;
        findFieldTypeOpt(arg0: string): $Optional<$Type<any>>;
        findFieldType(arg0: string): $Type<any>;
        findField(arg0: string): $OpticFinder<any>;
        findTypeCached<FT, FR>(arg0: $Type<FT>, arg1: $Type<FR>, arg2: $Type$TypeMatcher_<FT, FR, $Type<any>, $Either<$TypedOptic<any, any, FT, FR>, $Type$FieldNotFoundException>>, arg3: boolean): $Either<$TypedOptic<A, any, FT, FR>, $Type$FieldNotFoundException>;
        findTypeInChildren<FT, FR>(arg0: $Type<FT>, arg1: $Type<FR>, arg2: $Type$TypeMatcher_<FT, FR, $Type<any>, $Either<$TypedOptic<any, any, FT, FR>, $Type$FieldNotFoundException>>, arg3: boolean): $Either<$TypedOptic<A, any, FT, FR>, $Type$FieldNotFoundException>;
        findType<FT, FR>(arg0: $Type<FT>, arg1: $Type<FR>, arg2: $Type$TypeMatcher_<FT, FR, $Type<any>, $Either<$TypedOptic<any, any, FT, FR>, $Type$FieldNotFoundException>>, arg3: boolean): $Either<$TypedOptic<A, any, FT, FR>, $Type$FieldNotFoundException>;
        finder(): $OpticFinder<A>;
        getSetType<FT, FR>(arg0: $OpticFinder<FT>, arg1: $Type<FR>): $Type<any>;
        ifSame<B>(arg0: $Typed<B>): $Optional<A>;
        ifSame<B>(arg0: $Type<B>, arg1: B): $Optional<A>;
        ifSame<B>(arg0: $Type<B>, arg1: $RewriteResult<B, any>): $Optional<$RewriteResult<A, any>>;
        one(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>): $Optional<$RewriteResult<A, any>>;
        pointTyped(arg0: $DynamicOps<any>): $Optional<$Typed<A>>;
        point(arg0: $DynamicOps<any>): $Optional<A>;
        readAndWrite<T>(arg0: $DynamicOps<T>, arg1: $Type<any>, arg2: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg3: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>, arg4: T): $DataResult<T>;
        readTyped<T>(arg0: $Dynamic<T>): $DataResult<$Pair<$Typed<A>, T>>;
        readTyped<T>(arg0: $DynamicOps<T>, arg1: T): $DataResult<$Pair<$Typed<A>, T>>;
        read<T>(arg0: $Dynamic<T>): $DataResult<$Pair<A, $Dynamic<T>>>;
        read<T>(arg0: $DynamicOps<T>, arg1: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg2: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>, arg3: T): $DataResult<$Pair<$Optional<any>, T>>;
        rewriteOrNop(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>): $RewriteResult<A, any>;
        rewrite(arg0: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg1: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $Optional<$RewriteResult<A, any>>;
        template(): $TypeTemplate;
        updateMu(arg0: $RecursiveTypeFamily): $Type<any>;
        writeDynamic<T>(arg0: $DynamicOps<T>, arg1: A): $DataResult<$Dynamic<T>>;
        write<T>(arg0: $DynamicOps<T>, arg1: A): $DataResult<T>;
    }

    export class $Type$FieldNotFoundException extends $Type$TypeError {
        constructor(arg0: string);
    }

    export class $Type$Mu implements $K1 {
        constructor();
    }

    export class $Type$TypeError {
        constructor(arg0: string);
        toString(): string;
    }

    export interface $Type$TypeMatcher<FT, FR> {
        match<S>(arg0: $Type<S>): $Either<$TypedOptic<S, any, FT, FR>, $Type$FieldNotFoundException>;
    }

    export type $Type$TypeMatcher_<Host0 = any, Host1 = any, CallbackArg0 = $Type<any>, CallbackResult = $Either<$TypedOptic<any, any, Host0, Host1>, $Type$FieldNotFoundException>> = ((arg0: CallbackArg0) => CallbackResult) | $Type$TypeMatcher<Host0, Host1>;
}
