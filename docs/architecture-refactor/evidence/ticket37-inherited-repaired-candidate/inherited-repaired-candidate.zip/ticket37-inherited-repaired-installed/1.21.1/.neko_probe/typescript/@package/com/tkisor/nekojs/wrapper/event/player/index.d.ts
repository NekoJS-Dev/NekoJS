import { $Player } from "java:net/minecraft/world/entity/player";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";

declare module "java:com/tkisor/nekojs/wrapper/event/player" {
    /**
     * Event fired when a slot in a player's inventory changes (PlayerEvents.inventoryChanged).
     * Listeners are dispatched by item id, e.g. PlayerEvents.inventoryChanged('minecraft:stone', event => ...).
     */
    export class $InventoryChangedEventJS {
        constructor(player: $Player, item: $ItemStack_, slot: number);
        get item(): $ItemStack;
        getItem(): $ItemStack;
        get player(): $Player;
        getPlayer(): $Player;
        get slot(): number;
        getSlot(): number;
    }

}
