import { $GoalRegistry$GoalBuilderJS } from "java:com/tkisor/nekojs/wrapper/entity";
import { $Consumer, $Consumer_ } from "java:java/util/function";
import { $EntityType, $EntityType_ } from "java:net/minecraft/world/entity";

declare module "java:com/tkisor/nekojs/wrapper/event/entity" {
    /** Event given to GoalEvents.register callbacks (startup scripts) for registering built-in AI goals on entity types. */
    export class $GoalRegisterEventJS {
        constructor();
        /**
         * Registers goals on the entity type with the given id via a builder callback; register() runs automatically afterwards.
         * @param id entity type id like 'minecraft:zombie'
         * @param consumer callback receiving the GoalBuilderJS to configure
         */
        forType(id: string, consumer: $Consumer_<$GoalRegistry$GoalBuilderJS, $GoalRegistry$GoalBuilderJS>): void;
        /**
         * Starts a goal builder for the entity type with the given id; call builder.register() to apply.
         * @param id entity type id like 'minecraft:zombie'
         * @returns a GoalBuilderJS bound to the entity type; not registered until register() is called
         */
        forType(id: string): $GoalRegistry$GoalBuilderJS;
        /**
         * Registers goals on the given entity type via a builder callback; register() runs automatically afterwards.
         * @param type the entity type to register goals for
         * @param consumer callback receiving the GoalBuilderJS to configure
         */
        forType(type: $EntityType_, consumer: $Consumer_<$GoalRegistry$GoalBuilderJS, $GoalRegistry$GoalBuilderJS>): void;
        /**
         * Starts a goal builder for the given entity type; call builder.register() to apply.
         * @param type the entity type to register goals for
         * @returns a GoalBuilderJS bound to the entity type; not registered until register() is called
         */
        forType(type: $EntityType_): $GoalRegistry$GoalBuilderJS;
    }

}
