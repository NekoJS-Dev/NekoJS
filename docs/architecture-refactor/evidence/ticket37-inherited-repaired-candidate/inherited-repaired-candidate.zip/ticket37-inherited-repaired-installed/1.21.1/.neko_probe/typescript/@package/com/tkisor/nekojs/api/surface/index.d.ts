import { $Record } from "java:java/lang";
import { $List } from "java:java/util";

declare module "java:com/tkisor/nekojs/api/surface" {
    export class $ApiParameter extends $Record {
        constructor(name: string, type: $ApiTypeRef, optional: boolean, varargs: boolean);
        equals(o: object): boolean;
        hashCode(): number;
        name(): string;
        optional(): boolean;
        toString(): string;
        type(): $ApiTypeRef;
        varargs(): boolean;
    }

    export class $ApiSignature extends $Record {
        constructor(parameters: $ApiParameter[], returnType: $ApiTypeRef, isConstructor: boolean);
        get constructor(): boolean;
        isConstructor(): boolean;
        static constructor(parameters: $ApiParameter[], returnType: $ApiTypeRef): $ApiSignature;
        static function(parameters: $ApiParameter[], returnType: $ApiTypeRef): $ApiSignature;
        callKey(): string;
        compatibilityKey(): string;
        equals(o: object): boolean;
        hashCode(): number;
        parameters(): $List<$ApiParameter>;
        returnType(): $ApiTypeRef;
        toString(): string;
    }

    export class $ApiSymbolId extends $Record {
        constructor(kind: string, qualifiedName: string);
        static parse(raw: string): $ApiSymbolId;
        equals(o: object): boolean;
        hashCode(): number;
        kind(): string;
        qualifiedName(): string;
        toString(): string;
        value(): string;
    }

    export class $ApiTypeRef extends $Record {
        constructor(kind: $ApiTypeRef$Kind_, name: string, arguments_: $ApiTypeRef[], callbackSignature: $ApiSignature);
        static array(element: $ApiTypeRef): $ApiTypeRef;
        static callback(signature: $ApiSignature): $ApiTypeRef;
        static primitive(name: string): $ApiTypeRef;
        static symbol(id: $ApiSymbolId, arguments_: $ApiTypeRef[]): $ApiTypeRef;
        static symbol(id: $ApiSymbolId): $ApiTypeRef;
        static typeVariable(name: string): $ApiTypeRef;
        static union(members: $ApiTypeRef[]): $ApiTypeRef;
        static voidType(): $ApiTypeRef;
        arguments(): $List<$ApiTypeRef>;
        callbackSignature(): $ApiSignature;
        compatibilityKey(): string;
        equals(o: object): boolean;
        hashCode(): number;
        kind(): $ApiTypeRef$Kind;
        name(): string;
        toString(): string;
    }

    export class $ApiTypeRef$Kind {
        static ARRAY: $ApiTypeRef$Kind;
        static CALLBACK: $ApiTypeRef$Kind;
        static PRIMITIVE: $ApiTypeRef$Kind;
        static SYMBOL: $ApiTypeRef$Kind;
        static TYPE_VARIABLE: $ApiTypeRef$Kind;
        static UNION: $ApiTypeRef$Kind;
        static VOID: $ApiTypeRef$Kind;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ApiTypeRef$Kind[];
        static valueOf(name: string): $ApiTypeRef$Kind;
    }

    export type $ApiTypeRef$Kind_ = $ApiTypeRef$Kind | "ARRAY" | "CALLBACK" | "PRIMITIVE" | "SYMBOL" | "TYPE_VARIABLE" | "UNION" | "VOID";
}
