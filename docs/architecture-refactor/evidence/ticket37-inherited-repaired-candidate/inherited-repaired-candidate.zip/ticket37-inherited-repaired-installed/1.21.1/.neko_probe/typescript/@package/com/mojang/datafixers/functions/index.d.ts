import { $Type } from "java:com/mojang/datafixers/types";
import { $DynamicOps } from "java:com/mojang/serialization";
import { $Optional } from "java:java/util";
import { $Function, $Function_ } from "java:java/util/function";

declare module "java:com/mojang/datafixers/functions" {
    export class $PointFree<T> {
        constructor();
        static indent(arg0: number): string;
        evalCached(): $Function<$DynamicOps<any>, T>;
        eval(): $Function<$DynamicOps<any>, T>;
        toString(arg0: number): string;
        toString(): string;
        type(): $Type<T>;
    }

    export interface $PointFreeRule {
        rewriteOrNop<A>(arg0: $PointFree<A>): $PointFree<A>;
        rewrite<A>(arg0: $PointFree<A>): $Optional<$PointFree<A>>;
    }
    export const $PointFreeRule: {
        all(arg0: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $PointFreeRule;
        choice(arg0?: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>[]): $PointFreeRule;
        everywhere(arg0: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>, arg1: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $PointFreeRule;
        many(arg0: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $PointFreeRule;
        nop(): $PointFreeRule;
        once(arg0: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $PointFreeRule;
        one(arg0: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $PointFreeRule;
        seq(arg0?: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>[]): $PointFreeRule;
    };

    export type $PointFreeRule_<CallbackArg0 = $PointFree<any>, CallbackResult = $Optional<$PointFree<any>>> = ((arg0: CallbackArg0) => CallbackResult) | $PointFreeRule;
}
