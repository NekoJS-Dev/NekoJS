import { $AbuseReport } from "java:com/mojang/authlib/minecraft/report";
import { $Record } from "java:java/lang";
import { $UUID } from "java:java/util";

declare module "java:com/mojang/authlib/yggdrasil/request" {
    export class $AbuseReportRequest extends $Record {
        constructor(version: number, id: string, report: $AbuseReport, clientInfo: $AbuseReportRequest$ClientInfo, thirdPartyServerInfo: $AbuseReportRequest$ThirdPartyServerInfo, realmInfo: $AbuseReportRequest$RealmInfo, reportType: string);
        clientInfo(): $AbuseReportRequest$ClientInfo;
        equals(arg0: object): boolean;
        hashCode(): number;
        id(): $UUID;
        realmInfo(): $AbuseReportRequest$RealmInfo;
        reportType(): string;
        report(): $AbuseReport;
        thirdPartyServerInfo(): $AbuseReportRequest$ThirdPartyServerInfo;
        toString(): string;
        version(): number;
    }

}
