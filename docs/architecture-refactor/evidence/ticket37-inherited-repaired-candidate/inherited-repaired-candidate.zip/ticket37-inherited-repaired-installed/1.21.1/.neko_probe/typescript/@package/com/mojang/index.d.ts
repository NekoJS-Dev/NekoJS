export * as authlib from "java:com/mojang/authlib";
export * as brigadier from "java:com/mojang/brigadier";
export * as datafixers from "java:com/mojang/datafixers";
export * as math from "java:com/mojang/math";
export * as serialization from "java:com/mojang/serialization";

