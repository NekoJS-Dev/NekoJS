// Auto-generated managed API declarations for test.
// Do not edit; regenerate with /nekojs probe.

export {};

declare global {
    type JsonInput = null | boolean | number | string | $JsonValue | readonly JsonInput[] | { readonly [key: string]: JsonInput };

    type NbtInput = string | number | $NbtValue | readonly NbtInput[] | { readonly [key: string]: NbtInput };

    interface $ID {
        asString(id: $NekoId): null | string;
        namespace(id: $NekoId): null | string;
        of(value: string): null | $NekoId;
        of(namespace: string, path: string): null | $NekoId;
        path(id: $NekoId): null | string;
    }
    interface $JsonIO {
        parse(source: string): null | $JsonValue;
        read(path: string): null | $JsonValue;
        toPrettyString(value: JsonInput): null | string;
        toString(value: JsonInput): null | string;
        write(path: string, value: JsonInput): void;
    }
    interface $JsonValue {
        toPrettyString(): null | string;
        toString(): null | string;
    }
    interface $ModInfo {
        id(): null | string;
        name(): null | string;
        version(): null | string;
    }
    interface $NBT {
        byte(value: number): null | $NbtValue;
        byteArray(values: unknown[]): null | $NbtValue;
        compound(): null | unknown;
        double(value: number): null | $NbtValue;
        entries(value: NbtInput): $NbtEntry[] | null;
        float(value: number): null | $NbtValue;
        fromObject(value: unknown): null | $NbtValue;
        int(value: number): null | $NbtValue;
        intArray(values: unknown[]): null | $NbtValue;
        kind(value: NbtInput): null | string;
        long(value: string): null | $NbtValue;
        of(value: NbtInput): null | $NbtValue;
        parse(snbt: string): null | $NbtValue;
        read(path: string): null | $NbtValue;
        scalar(value: NbtInput): null | unknown;
        short(value: number): null | $NbtValue;
        toObject(value: NbtInput): null | unknown;
        toSnbt(value: NbtInput): null | string;
        values(value: NbtInput): NbtInput[] | null;
        write(path: string, value: NbtInput): void;
    }
    interface $NbtEntry {
        key(): null | string;
        value(): null | $NbtValue;
    }
    interface $NbtValue {
        entries(): $NbtEntry[] | null;
        kind(): null | string;
        of(): null | $NbtValue;
        scalar(): null | unknown;
        toObject(): null | unknown;
        toSnbt(): null | string;
        values(): NbtInput[] | null;
    }
    interface $NekoId {
        asString(): null | string;
        namespace(): null | string;
        path(): null | string;
    }
    interface $PerfTimer {
        elapsedMillis(): null | number;
        end(): null | $PerfTimer;
        ended(): boolean | null;
        label(): null | string;
        mark(markLabel: string): null | $PerfTimer;
        marks(): unknown[] | null;
        report(): null | unknown;
    }
    interface $Performance {
        bench(fn: unknown, runs: number): null | unknown;
        now(): null | number;
        start(label: string): null | $PerfTimer;
        time(fn: unknown): null | number;
    }
    interface $Platform {
        capabilities(): string[] | null;
        getInfo(modId: string): null | $ModInfo;
        getList(): string[] | null;
        getLoaderId(): null | string;
        getLoaderVersion(): null | string;
        getMcVersion(): null | string;
        isClient(): boolean | null;
        isDevelopment(): boolean | null;
        isLoaded(modId: string): boolean | null;
    }
    interface $Registry {
        get(registryId: string): null | $RegistryView;
    }
    interface $RegistryView {
        all(): string[] | null;
        dataMapIds(): string[] | null;
        dataMapValue(dataMapTypeId: string, id: string): null | string;
        exists(): boolean | null;
        has(id: string): boolean | null;
        iterator(): null | unknown;
        tag(tagId: string): string[] | null;
    }
    interface $ScriptEventRegistrationEvent {
        register(groupName: string, eventName: string): void;
        register(config: unknown): void;
        targetType(): null | unknown;
    }
    interface $Text {
        append(receiver: $TextValue, ...values: (boolean | number | string | $TextValue)[]): null | $TextValue;
        aqua(receiver: $TextValue): null | $TextValue;
        black(receiver: $TextValue): null | $TextValue;
        blue(receiver: $TextValue): null | $TextValue;
        bold(receiver: $TextValue, value: boolean): null | $TextValue;
        click(receiver: $TextValue, action: string, value: string): null | $TextValue;
        color(receiver: $TextValue, color: string): null | $TextValue;
        darkAqua(receiver: $TextValue): null | $TextValue;
        darkBlue(receiver: $TextValue): null | $TextValue;
        darkGray(receiver: $TextValue): null | $TextValue;
        darkGreen(receiver: $TextValue): null | $TextValue;
        darkPurple(receiver: $TextValue): null | $TextValue;
        darkRed(receiver: $TextValue): null | $TextValue;
        empty(): null | $TextValue;
        font(receiver: $TextValue, font: string): null | $TextValue;
        gold(receiver: $TextValue): null | $TextValue;
        gray(receiver: $TextValue): null | $TextValue;
        green(receiver: $TextValue): null | $TextValue;
        hover(receiver: $TextValue, text: $TextValue): null | $TextValue;
        insertion(receiver: $TextValue, insertion: string): null | $TextValue;
        italic(receiver: $TextValue, value: boolean): null | $TextValue;
        join(separator: $TextValue, ...values: (boolean | number | string | $TextValue)[]): null | $TextValue;
        keybind(keybind: string): null | $TextValue;
        lightPurple(receiver: $TextValue): null | $TextValue;
        obfuscated(receiver: $TextValue, value: boolean): null | $TextValue;
        of(text: string): null | $TextValue;
        ofValues(...values: (boolean | number | string | $TextValue)[]): null | $TextValue;
        red(receiver: $TextValue): null | $TextValue;
        score(name: string, objective: string): null | $TextValue;
        selector(pattern: string): null | $TextValue;
        strikethrough(receiver: $TextValue, value: boolean): null | $TextValue;
        translatable(key: string, ...arguments: (boolean | number | string | $TextValue)[]): null | $TextValue;
        translateWithFallback(key: string, fallback: string, ...arguments: (boolean | number | string | $TextValue)[]): null | $TextValue;
        underlined(receiver: $TextValue, value: boolean): null | $TextValue;
        white(receiver: $TextValue): null | $TextValue;
        yellow(receiver: $TextValue): null | $TextValue;
    }
    interface $TextValue {
        append(...values: (boolean | number | string | $TextValue)[]): null | $TextValue;
        aqua(): null | $TextValue;
        black(): null | $TextValue;
        blue(): null | $TextValue;
        bold(value: boolean): null | $TextValue;
        click(action: string, value: string): null | $TextValue;
        color(color: string): null | $TextValue;
        darkAqua(): null | $TextValue;
        darkBlue(): null | $TextValue;
        darkGray(): null | $TextValue;
        darkGreen(): null | $TextValue;
        darkPurple(): null | $TextValue;
        darkRed(): null | $TextValue;
        font(font: string): null | $TextValue;
        gold(): null | $TextValue;
        gray(): null | $TextValue;
        green(): null | $TextValue;
        hover(text: $TextValue): null | $TextValue;
        insertion(insertion: string): null | $TextValue;
        isEmpty(): boolean | null;
        italic(value: boolean): null | $TextValue;
        join(...values: (boolean | number | string | $TextValue)[]): null | $TextValue;
        lightPurple(): null | $TextValue;
        obfuscated(value: boolean): null | $TextValue;
        red(): null | $TextValue;
        strikethrough(value: boolean): null | $TextValue;
        underlined(value: boolean): null | $TextValue;
        white(): null | $TextValue;
        yellow(): null | $TextValue;
    }

    const ID: $ID;
    const JsonIO: $JsonIO;
    const NBT: $NBT;
    const Performance: $Performance;
    const Platform: $Platform;
    const Registry: $Registry;
    const Text: $Text;
}
