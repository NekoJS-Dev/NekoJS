import { $TypeToken } from "java:com/google/common/reflect";
import { $App, $App2, $K1, $K2 } from "java:com/mojang/datafixers/kinds";
import { $Optional, $Set } from "java:java/util";
import { $Function, $Function_ } from "java:java/util/function";

declare module "java:com/mojang/datafixers/optics" {
    export interface $Optic<Proof extends $K1, S, T, A, B> {
        eval<P extends $K2>(arg0: $App<Proof, P>): $Function<$App2<P, A, B>, $App2<P, S, T>>;
        upCast<Proof2 extends $K1>(arg0: $TypeToken<$K1>[], arg1: $TypeToken<Proof2>): $Optional<$Optic<any, S, T, A, B>>;
    }

    export type $Optic_<Host0 = any, Host1 = any, Host2 = any, Host3 = any, Host4 = any, CallbackArg0 = $App<Host0, any>, CallbackResult = $Function_<$App2<any, Host3, Host4>, $App2<any, Host1, Host2>, $App2<any, Host3, Host4>, $App2<any, Host1, Host2>>> = ((arg0: CallbackArg0) => CallbackResult) | $Optic<Host0, Host1, Host2, Host3, Host4>;
}
