import { $Command, $CommandDispatcher, $Command_, $ImmutableStringReader, $RedirectModifier, $RedirectModifier_, $ResultConsumer, $ResultConsumer_ } from "java:com/mojang/brigadier";
import { $CommandNode } from "java:com/mojang/brigadier/tree";
import { $Class } from "java:java/lang";
import { $Collection, $List, $Map, $Optional } from "java:java/util";

declare module "java:com/mojang/brigadier/context" {
    export class $CommandContext<S> {
        constructor(arg0: S, arg1: string, arg2: ($Map<string, $ParsedArgument<S, any>> | ([string] extends [PropertyKey] ? Partial<Record<Extract<string, PropertyKey>, $ParsedArgument<S, any>>> : never)), arg3: $Command_<S, $CommandContext<S>, number>, arg4: $CommandNode<S>, arg5: $ParsedCommandNode<S>[], arg6: $StringRange, arg7: $CommandContext<S>, arg8: $RedirectModifier_<S, $CommandContext<S>, S[]>, arg9: boolean);
        get child(): $CommandContext<S>;
        getChild(): $CommandContext<S>;
        get command(): $Command<S>;
        getCommand(): $Command<S>;
        get input(): string;
        getInput(): string;
        get lastChild(): $CommandContext<S>;
        getLastChild(): $CommandContext<S>;
        get nodes(): $List<$ParsedCommandNode<S>>;
        getNodes(): $List<$ParsedCommandNode<S>>;
        get range(): $StringRange;
        getRange(): $StringRange;
        get redirectModifier(): $RedirectModifier<S>;
        getRedirectModifier(): $RedirectModifier<S>;
        get rootNode(): $CommandNode<S>;
        getRootNode(): $CommandNode<S>;
        get source(): S;
        getSource(): S;
        get forked(): boolean;
        isForked(): boolean;
        copyFor(arg0: S): $CommandContext<S>;
        equals(arg0: object): boolean;
        getArgument<V>(arg0: string, arg1: $Class<V>): V;
        hasNodes(): boolean;
        hashCode(): number;
    }

    export class $CommandContextBuilder<S> {
        constructor(arg0: $CommandDispatcher<S>, arg1: S, arg2: $CommandNode<S>, arg3: number);
        get arguments(): $Map<string, $ParsedArgument<S, any>>;
        getArguments(): $Map<string, $ParsedArgument<S, any>>;
        get child(): $CommandContextBuilder<S>;
        getChild(): $CommandContextBuilder<S>;
        get command(): $Command<S>;
        getCommand(): $Command<S>;
        get dispatcher(): $CommandDispatcher<S>;
        getDispatcher(): $CommandDispatcher<S>;
        get lastChild(): $CommandContextBuilder<S>;
        getLastChild(): $CommandContextBuilder<S>;
        get nodes(): $List<$ParsedCommandNode<S>>;
        getNodes(): $List<$ParsedCommandNode<S>>;
        get range(): $StringRange;
        getRange(): $StringRange;
        get rootNode(): $CommandNode<S>;
        getRootNode(): $CommandNode<S>;
        get source(): S;
        getSource(): S;
        build(arg0: string): $CommandContext<S>;
        copy(): $CommandContextBuilder<S>;
        findSuggestionContext(arg0: number): $SuggestionContext<S>;
        withArgument(arg0: string, arg1: $ParsedArgument<S, any>): $CommandContextBuilder<S>;
        withChild(arg0: $CommandContextBuilder<S>): $CommandContextBuilder<S>;
        withCommand(arg0: $Command_<S, $CommandContext<S>, number>): $CommandContextBuilder<S>;
        withNode(arg0: $CommandNode<S>, arg1: $StringRange): $CommandContextBuilder<S>;
        withSource(arg0: S): $CommandContextBuilder<S>;
    }

    export class $ContextChain<S> {
        constructor(arg0: $CommandContext<S>[], arg1: $CommandContext<S>);
        get stage(): $ContextChain$Stage;
        getStage(): $ContextChain$Stage;
        get topContext(): $CommandContext<S>;
        getTopContext(): $CommandContext<S>;
        static runExecutable<S>(arg0: $CommandContext<S>, arg1: S, arg2: $ResultConsumer_<S, $CommandContext<S>, boolean, number>, arg3: boolean): number;
        static runModifier<S>(arg0: $CommandContext<S>, arg1: S, arg2: $ResultConsumer_<S, $CommandContext<S>, boolean, number>, arg3: boolean): $Collection<S>;
        static tryFlatten<S>(arg0: $CommandContext<S>): $Optional<$ContextChain<S>>;
        executeAll(arg0: S, arg1: $ResultConsumer_<S, $CommandContext<S>, boolean, number>): number;
        nextStage(): $ContextChain<S>;
    }

    export class $ContextChain$Stage {
        static EXECUTE: $ContextChain$Stage;
        static MODIFY: $ContextChain$Stage;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ContextChain$Stage[];
        static valueOf(name: string): $ContextChain$Stage;
    }

    export class $ParsedArgument<S, T> {
        constructor(arg0: number, arg1: number, arg2: T);
        get range(): $StringRange;
        getRange(): $StringRange;
        get result(): T;
        getResult(): T;
        equals(arg0: object): boolean;
        hashCode(): number;
    }

    export class $ParsedCommandNode<S> {
        constructor(arg0: $CommandNode<S>, arg1: $StringRange);
        get node(): $CommandNode<S>;
        getNode(): $CommandNode<S>;
        get range(): $StringRange;
        getRange(): $StringRange;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $StringRange {
        constructor(arg0: number, arg1: number);
        get end(): number;
        getEnd(): number;
        get length(): number;
        getLength(): number;
        get start(): number;
        getStart(): number;
        get empty(): boolean;
        isEmpty(): boolean;
        static at(arg0: number): $StringRange;
        static between(arg0: number, arg1: number): $StringRange;
        static encompassing(arg0: $StringRange, arg1: $StringRange): $StringRange;
        equals(arg0: object): boolean;
        get(arg0: $ImmutableStringReader): string;
        get(arg0: string): string;
        hashCode(): number;
        toString(): string;
    }

    export class $SuggestionContext<S> {
        constructor(arg0: $CommandNode<S>, arg1: number);
        parent: $CommandNode<S>;
        startPos: number;
    }

    export type $ContextChain$Stage_ = $ContextChain$Stage | "EXECUTE" | "MODIFY";
}
