import type { RegistryTypes } from "@special/types";
import { $JsonElement, $JsonObject } from "java:com/google/gson";
import { $Record } from "java:java/lang";
import { $Set } from "java:java/util";
import { $HolderLookup$Provider } from "java:net/minecraft/core";
import { $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";
import { $ItemStack, $ItemStack_ } from "java:net/minecraft/world/item";
import { $Ingredient, $Ingredient_, $RecipeHolder } from "java:net/minecraft/world/item/crafting";
import { $FluidStack, $FluidStack_ } from "java:net/neoforged/neoforge/fluids";
import { $FluidIngredient, $FluidIngredient_, $SizedFluidIngredient, $SizedFluidIngredient_ } from "java:net/neoforged/neoforge/fluids/crafting";

export * as definition from "java:com/tkisor/nekojs/api/recipe/definition";

declare module "java:com/tkisor/nekojs/api/recipe" {
    export interface $IRecipeManagerExtension {
        nekojs$applyScripts(): void;
    }

    export interface $RecipeBuilder {
        setPath(path: string, value: $RecipeJsonValue_): $RecipeBuilder;
    }

    export class $RecipeCreationContext extends $Record {
        constructor(api: string, type: string, prefix: string, scriptId: string);
        static of(api: string, type: string, prefix: string, scriptId: string): $RecipeCreationContext;
        static of(api: string, type: string, prefix: string): $RecipeCreationContext;
        api(): string;
        describe(id: string): string;
        equals(o: object): boolean;
        hashCode(): number;
        prefix(): string;
        scriptId(): string;
        toString(): string;
        type(): string;
        withScriptId(scriptId: string): $RecipeCreationContext;
    }

    export class $RecipeEntryJS {
        constructor(event: $RecipeEventJS, id: $ResourceLocation_, json: $JsonObject);
        builder(): $RecipeJsonBuilder;
        copy(newId: string): $RecipeJsonBuilder;
        group(group: string): $RecipeEntryJS;
        group(): string;
        id(newId: string): $RecipeEntryJS;
        id(): string;
        json(): $JsonObject;
        merge(value: $JsonObject): $RecipeEntryJS;
        merge(value: $RecipeJsonValue_): $RecipeEntryJS;
        removePaths(paths: $RecipeJsonValue_): $RecipeEntryJS;
        removePath(path: string): $RecipeEntryJS;
        removeProperty(key: string): $RecipeEntryJS;
        remove(): void;
        setPaths(values: $RecipeJsonValue_): $RecipeEntryJS;
        setPath(path: string, value: $RecipeJsonValue_): $RecipeEntryJS;
        type(): string;
        validate(): $RecipeEntryJS;
    }

    export interface $RecipeFilter {
        test(holder: $RecipeHolder<any>, registries: $HolderLookup$Provider): boolean;
    }

    export class $RecipeJsonBuilder implements $RecipeBuilder {
        constructor(event: $RecipeEventJS, prebuiltJson: $JsonObject, prefix: string);
        constructor(event: $RecipeEventJS, prebuiltJson: $JsonObject, prefix: string, context: $RecipeCreationContext);
        constructor(event: $RecipeEventJS, prebuiltJson: $JsonObject, currentId: $ResourceLocation_);
        constructor(event: $RecipeEventJS, prebuiltJson: $JsonObject, currentId: $ResourceLocation_, context: $RecipeCreationContext);
        constructor(event: $RecipeEventJS, type: string, prefix: string);
        constructor(event: $RecipeEventJS, type: string, prefix: string, context: $RecipeCreationContext);
        static parseId(id: string): $ResourceLocation;
        context(): $RecipeCreationContext;
        fluidIngredient(key: string, ingredient: $FluidIngredient_): $RecipeJsonBuilder;
        fluid(key: string, stack: $FluidStack_): $RecipeJsonBuilder;
        group(group: string): $RecipeJsonBuilder;
        id(newId: string): $RecipeJsonBuilder;
        input(key: string, ingredient: $Ingredient_): $RecipeJsonBuilder;
        jsonProperty(key: string, value: $JsonElement): $RecipeJsonBuilder;
        jsonProperty(key: string, value: boolean): $RecipeJsonBuilder;
        jsonProperty(key: string, value: number): $RecipeJsonBuilder;
        jsonProperty(key: string, value: string): $RecipeJsonBuilder;
        json(): $JsonObject;
        merge(value: $JsonObject): $RecipeJsonBuilder;
        merge(value: $RecipeJsonValue_): $RecipeJsonBuilder;
        output(key: string, result: $ItemStack_): $RecipeJsonBuilder;
        property(key: string, value: $RecipeJsonValue_): $RecipeJsonBuilder;
        removePaths(paths: $RecipeJsonValue_): $RecipeJsonBuilder;
        removePath(path: string): $RecipeJsonBuilder;
        removeProperty(key: string): $RecipeJsonBuilder;
        setPaths(values: $RecipeJsonValue_): $RecipeJsonBuilder;
        setPath(path: string, value: $RecipeJsonValue_): $RecipeJsonBuilder;
        sizedFluidIngredient(key: string, ingredient: $SizedFluidIngredient_): $RecipeJsonBuilder;
        validate(): $RecipeJsonBuilder;
    }

    export class $RecipeJsonValue extends $Record {
        constructor(value: object);
        equals(o: object): boolean;
        hashCode(): number;
        toString(): string;
        value(): object;
    }

    export interface $RecipeLifecycleContext {
        count(): number;
        dump(): string;
        exists(id: string): boolean;
        getJson(id: string): string;
        ids(): $Set<string>;
        print(): void;
        removeById(id: string): void;
        setJson(id: string, json: string): void;
    }

    export type $IRecipeManagerExtension_ = (() => void) | $IRecipeManagerExtension;
    export type $RecipeBuilder_<CallbackArg0 = string, CallbackArg1 = $RecipeJsonValue, CallbackResult = $RecipeBuilder> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | $RecipeBuilder;
    export type $RecipeFilter_ = string | $RecipeFilter_[] | { not?: $RecipeFilter_, and?: $RecipeFilter_, or?: $RecipeFilter_, output?: (RegistryTypes.Item | `#${RegistryTypes.ItemTag}`), input?: (RegistryTypes.Item | `#${RegistryTypes.ItemTag}`), mod?: string, group?: string, id?: string, idStartsWith?: string, idEndsWith?: string, idContains?: string, type?: string };
    export type $RecipeJsonValue_ = $RecipeJsonValue | string | number | boolean | $RecipeJsonValue_[] | { [key: string]: any };
}
