export * as block from "java:com/tkisor/nekojs/wrapper/event/block";
export * as entity from "java:com/tkisor/nekojs/wrapper/event/entity";
export * as player from "java:com/tkisor/nekojs/wrapper/event/player";
export * as registry from "java:com/tkisor/nekojs/wrapper/event/registry";
export * as server from "java:com/tkisor/nekojs/wrapper/event/server";

