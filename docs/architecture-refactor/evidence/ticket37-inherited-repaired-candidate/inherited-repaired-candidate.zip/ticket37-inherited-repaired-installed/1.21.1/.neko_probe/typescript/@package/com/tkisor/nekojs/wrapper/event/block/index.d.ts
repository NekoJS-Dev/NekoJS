import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $Player } from "java:net/minecraft/world/entity/player";
import { $LevelAccessor } from "java:net/minecraft/world/level";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";

declare module "java:com/tkisor/nekojs/wrapper/event/block" {
    /**
     * Fired when a block is broken (BlockEvents.broken). Listeners are dispatched by block id.
     * Return true to cancel the break.
     */
    export class $BlockBrokenEventJS {
        constructor(level: $LevelAccessor, pos: $BlockPos_, state: $BlockState_, player: $Player);
        /** The block that was broken. */
        get block(): $Block;
        getBlock(): $Block;
        get level(): $LevelAccessor;
        getLevel(): $LevelAccessor;
        get player(): $Player;
        getPlayer(): $Player;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get state(): $BlockState;
        getState(): $BlockState;
    }

}
