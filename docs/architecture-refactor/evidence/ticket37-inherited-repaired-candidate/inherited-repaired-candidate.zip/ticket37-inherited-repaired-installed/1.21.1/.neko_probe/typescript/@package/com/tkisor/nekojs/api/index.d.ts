import { $List } from "java:java/util";
import { $Predicate, $Predicate_ } from "java:java/util/function";
import { $Stream } from "java:java/util/stream";

export * as data from "java:com/tkisor/nekojs/api/data";
export * as event from "java:com/tkisor/nekojs/api/event";
export * as inject from "java:com/tkisor/nekojs/api/inject";
export * as recipe from "java:com/tkisor/nekojs/api/recipe";
export * as spec from "java:com/tkisor/nekojs/api/spec";
export * as surface from "java:com/tkisor/nekojs/api/surface";

declare module "java:com/tkisor/nekojs/api" {
    export class $ScriptType {
        static CLIENT: $ScriptType;
        static SERVER: $ScriptType;
        static STARTUP: $ScriptType;
        static TEST: $ScriptType;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $ScriptType[];
        static valueOf(name: string): $ScriptType;
    }

    export interface $ScriptTypePredicate extends $Predicate<$ScriptType> {
        canApplyOn(type: $ScriptType_): boolean;
        negate(): $ScriptTypePredicate;
        streamMatched(): $Stream<$ScriptType>;
    }
    export const $ScriptTypePredicate: {
        any(): $ScriptTypePredicate;
        exact(type: $ScriptType_): $ScriptTypePredicate;
    };

    export type $ScriptType_ = $ScriptType | "CLIENT" | "SERVER" | "STARTUP" | "TEST";
    export type $ScriptTypePredicate_<CallbackArg0 = $ScriptType, CallbackResult = boolean> = ((arg0: CallbackArg0) => CallbackResult) | $ScriptTypePredicate;
}
