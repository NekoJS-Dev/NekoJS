import { $Message, $Message_ } from "java:com/mojang/brigadier";
import { $CommandContext, $StringRange } from "java:com/mojang/brigadier/context";
import { $Comparable, $Comparable_ } from "java:java/lang";
import { $Collection, $List } from "java:java/util";
import { $CompletableFuture } from "java:java/util/concurrent";

declare module "java:com/mojang/brigadier/suggestion" {
    export class $Suggestion implements $Comparable<$Suggestion> {
        constructor(arg0: $StringRange, arg1: string);
        constructor(arg0: $StringRange, arg1: string, arg2: $Message_<string>);
        get range(): $StringRange;
        getRange(): $StringRange;
        get text(): string;
        getText(): string;
        get tooltip(): $Message;
        getTooltip(): $Message;
        apply(arg0: string): string;
        compareToIgnoreCase(arg0: $Suggestion): number;
        compareTo(arg0: $Suggestion): number;
        equals(arg0: object): boolean;
        expand(arg0: string, arg1: $StringRange): $Suggestion;
        hashCode(): number;
        toString(): string;
    }

    export interface $SuggestionProvider<S> {
        getSuggestions(arg0: $CommandContext<S>, arg1: $SuggestionsBuilder): $CompletableFuture<$Suggestions>;
    }

    export class $Suggestions {
        constructor(arg0: $StringRange, arg1: $Suggestion[]);
        get list(): $List<$Suggestion>;
        getList(): $List<$Suggestion>;
        get range(): $StringRange;
        getRange(): $StringRange;
        get empty(): boolean;
        isEmpty(): boolean;
        static create(arg0: string, arg1: $Suggestion[]): $Suggestions;
        static empty(): $CompletableFuture<$Suggestions>;
        static merge(arg0: string, arg1: $Suggestions[]): $Suggestions;
        equals(arg0: object): boolean;
        hashCode(): number;
        toString(): string;
    }

    export class $SuggestionsBuilder {
        constructor(arg0: string, arg1: number);
        constructor(arg0: string, arg1: string, arg2: number);
        get input(): string;
        getInput(): string;
        get remainingLowerCase(): string;
        getRemainingLowerCase(): string;
        get remaining(): string;
        getRemaining(): string;
        get start(): number;
        getStart(): number;
        add(arg0: $SuggestionsBuilder): $SuggestionsBuilder;
        buildFuture(): $CompletableFuture<$Suggestions>;
        build(): $Suggestions;
        createOffset(arg0: number): $SuggestionsBuilder;
        restart(): $SuggestionsBuilder;
        suggest(arg0: number, arg1: $Message_<string>): $SuggestionsBuilder;
        suggest(arg0: number): $SuggestionsBuilder;
        suggest(arg0: string, arg1: $Message_<string>): $SuggestionsBuilder;
        suggest(arg0: string): $SuggestionsBuilder;
    }

    export type $SuggestionProvider_<Host0 = any, CallbackArg0 = $CommandContext<Host0>, CallbackArg1 = $SuggestionsBuilder, CallbackResult = $CompletableFuture<$Suggestions>> = ((arg0: CallbackArg0, arg1: CallbackArg1) => CallbackResult) | $SuggestionProvider<Host0>;
}
