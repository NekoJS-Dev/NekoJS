import { $Value } from "java:graal/graalvm/polyglot";
import { $ProxyObject } from "java:graal/graalvm/polyglot/proxy";
import { $Record } from "java:java/lang";
import { $List, $Map } from "java:java/util";
import { $Supplier, $Supplier_ } from "java:java/util/function";
import { $Registry } from "java:net/minecraft/core";
import { $ResourceKey, $ResourceLocation, $ResourceLocation_ } from "java:net/minecraft/resources";

declare module "java:com/tkisor/nekojs/wrapper/registry/gen" {
    export class $RegistryEventJS implements $ProxyObject {
        get memberKeys(): object;
        getMemberKeys(): object;
        static create(repository: $RegistryRepository, node: string): $RegistryEventJS;
        getMember(name: string): object;
        hasMember(name: string): boolean;
        putMember(name: string, value: $Value): void;
        removeMember(name: string): boolean;
    }

    export class $RegistryObjectBuilder<T> implements $Supplier<T> {
        id: $ResourceLocation;
        build(): T;
        get(): T;
        handleAdditionalObjects(registry: $RegistryObjectBuilder$AdditionalObjectRegistry_<$ResourceKey<$Registry<any>>, $ResourceLocation, $Supplier<any>>): void;
    }

    export interface $RegistryObjectBuilder$AdditionalObjectRegistry {
        additional(registry: $ResourceKey<$Registry<any>>, id: $ResourceLocation_, supplier: $Supplier_<any, any>): void;
    }

    export class $RegistryRepository {
        constructor();
        get empty(): boolean;
        isEmpty(): boolean;
        addAdditional(registry: $ResourceKey<$Registry<any>>, id: $ResourceLocation_, supplier: $Supplier_<any, any>, source: $ResourceLocation_): void;
        add(registry: $ResourceKey<$Registry<any>>, builder: $RegistryObjectBuilder<any>, typeName: string, origin: string): void;
        add(registry: $ResourceKey<$Registry<any>>, builder: $RegistryObjectBuilder<any>): void;
        drainAdditional(registry: $ResourceKey<$Registry<any>>): $List<$RegistryRepository$Additional>;
        drain(registry: $ResourceKey<$Registry<any>>): $List<$RegistryRepository$Entry>;
        undeliveredAdditional(): $Map<$ResourceKey<$Registry<any>>, $List<$RegistryRepository$Additional>>;
        undrained(): $Map<$ResourceKey<$Registry<any>>, $List<$RegistryRepository$Entry>>;
    }

    export class $RegistryRepository$Additional extends $Record {
        constructor(registry: $ResourceKey<$Registry<any>>, id: $ResourceLocation_, supplier: $Supplier_<any, any>, source: $ResourceLocation_);
        equals(o: object): boolean;
        hashCode(): number;
        id(): $ResourceLocation;
        registry(): $ResourceKey<$Registry<any>>;
        source(): $ResourceLocation;
        supplier(): $Supplier<any>;
        toString(): string;
    }

    export class $RegistryRepository$Entry extends $Record {
        constructor(builder: $RegistryObjectBuilder<any>, typeName: string, origin: string);
        builder(): $RegistryObjectBuilder<any>;
        equals(o: object): boolean;
        hashCode(): number;
        origin(): string;
        toString(): string;
        typeName(): string;
    }

    export type $RegistryObjectBuilder$AdditionalObjectRegistry_<CallbackArg0 = $ResourceKey<$Registry<any>>, CallbackArg1 = $ResourceLocation, CallbackArg2 = $Supplier<any>> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2) => void) | $RegistryObjectBuilder$AdditionalObjectRegistry;
}
