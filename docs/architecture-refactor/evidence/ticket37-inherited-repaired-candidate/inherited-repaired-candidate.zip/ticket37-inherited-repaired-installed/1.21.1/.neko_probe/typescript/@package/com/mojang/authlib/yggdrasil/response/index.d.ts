import { $Record } from "java:java/lang";
import { $ByteBuffer } from "java:java/nio";

declare module "java:com/mojang/authlib/yggdrasil/response" {
    export class $KeyPairResponse extends $Record {
        constructor(keyPair: $KeyPairResponse$KeyPair, publicKeySignature: $ByteBuffer, expiresAt: string, refreshedAfter: string);
        equals(arg0: object): boolean;
        expiresAt(): string;
        hashCode(): number;
        keyPair(): $KeyPairResponse$KeyPair;
        publicKeySignature(): $ByteBuffer;
        refreshedAfter(): string;
        toString(): string;
    }

}
