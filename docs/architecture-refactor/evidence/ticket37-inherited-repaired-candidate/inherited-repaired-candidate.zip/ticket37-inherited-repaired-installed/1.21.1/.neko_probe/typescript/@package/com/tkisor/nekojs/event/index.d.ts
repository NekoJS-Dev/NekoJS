export * as level from "java:com/tkisor/nekojs/event/level";

