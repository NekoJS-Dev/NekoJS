declare module "java:com/tkisor/nekojs/api/spec/inject" {
    export interface $BlockSpec {
        getId(): string;
    }

    export interface $BlockStateSpec {
        getId(): string;
        hasTag(tagLocation: string): boolean;
        is(idOrTag: string): boolean;
    }

    export interface $EntitySpec {
        getLevel(): object;
        kill(): boolean;
        remove(): void;
        teleport(x: number, y: number, z: number): void;
    }

    export interface $ItemSpec {
        getId(): string;
    }

    export interface $ItemStackSpec {
        getId(): string;
        hasEnchantment(enchId: string, level: number): boolean;
        isUnbreakable(): boolean;
        matches(other: object): boolean;
        pdata(): object;
        setUnbreakable(value: boolean): void;
        withCount(count: number): object;
    }

    export interface $LevelSpec {
        data(): object;
        getBlockState(x: number, y: number, z: number): object;
        getId(): string;
        getPlayers(): object;
        getTime(): number;
        isDay(): boolean;
        isRaining(): boolean;
        setBlock(x: number, y: number, z: number, block: object): boolean;
        setRaining(raining: boolean): void;
        setTime(time: number): void;
    }

    export interface $LivingEntitySpec {
        addEffect(effectId: string, duration: number, amplifier: number): boolean;
        damage(amount: number): void;
        getChestItem(): object;
        getFeetItem(): object;
        getHeadItem(): object;
        getLegsItem(): object;
        getOffHandItem(): object;
        removeEffect(effectId: string): boolean;
    }

    export interface $MutableComponentSpec {
        aqua(): object;
        black(): object;
        blue(): object;
        bold(value: boolean): object;
        bold(): object;
        darkAqua(): object;
        darkBlue(): object;
        darkGray(): object;
        darkGreen(): object;
        darkPurple(): object;
        darkRed(): object;
        font(font: string): object;
        gold(): object;
        gray(): object;
        green(): object;
        hasStyle(): boolean;
        insertion(insertion: string): object;
        italic(value: boolean): object;
        italic(): object;
        lightPurple(): object;
        noColor(): object;
        obfuscated(value: boolean): object;
        obfuscated(): object;
        red(): object;
        strikethrough(value: boolean): object;
        strikethrough(): object;
        underlined(value: boolean): object;
        underlined(): object;
        white(): object;
        yellow(): object;
    }

    export interface $PlayerSpec {
        addXpLevels(levels: number): void;
        addXpPoints(points: number): void;
        getGamemode(): string;
        getXpLevel(): number;
        give(stack: object): void;
        isOp(): boolean;
        kick(reason: object): void;
        setGamemode(gamemode: string): void;
        setXpLevel(level: number): void;
    }

    export interface $ServerSpec {
        data(): object;
    }

}
