import { $BlockPos, $BlockPos_ } from "java:net/minecraft/core";
import { $ServerLevel } from "java:net/minecraft/server/level";
import { $RandomSource } from "java:net/minecraft/util";
import { $Block, $Block_ } from "java:net/minecraft/world/level/block";
import { $BlockEntity, $BlockEntityType, $BlockEntityType_ } from "java:net/minecraft/world/level/block/entity";
import { $BlockState, $BlockState_ } from "java:net/minecraft/world/level/block/state";
import { $Event } from "java:net/neoforged/bus/api";

declare module "java:com/tkisor/nekojs/event/level" {
    export class $BlockEntityTickEvent extends $Event {
        constructor(blockEntity: $BlockEntity);
        get blockEntity(): $BlockEntity;
        getBlockEntity(): $BlockEntity;
        get type(): $BlockEntityType<any>;
        getType(): $BlockEntityType<any>;
    }

    export class $RandomTickEvent extends $Event {
        constructor(level: $ServerLevel, pos: $BlockPos_, state: $BlockState_, random: $RandomSource);
        get block(): $Block;
        getBlock(): $Block;
        get level(): $ServerLevel;
        getLevel(): $ServerLevel;
        get pos(): $BlockPos;
        getPos(): $BlockPos;
        get random(): $RandomSource;
        getRandom(): $RandomSource;
        get state(): $BlockState;
        getState(): $BlockState;
    }

}
