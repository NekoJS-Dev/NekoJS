import { $ScriptType, $ScriptType_ } from "java:com/tkisor/nekojs/api";

declare module "java:com/tkisor/nekojs/api/event" {
    export interface $ScriptEventRegistrar {
        register(targetType: $ScriptType_, groupName: string, eventName: string, sourceScriptId: string): void;
    }

    export class $ScriptEventRegistrationEvent {
        constructor(targetType: $ScriptType_, registrar: $ScriptEventRegistrar_<$ScriptType, string, string, string>);
        register(config: object): void;
        register(groupName: string, eventName: string): void;
        targetType(): $ScriptType;
    }

    export type $ScriptEventRegistrar_<CallbackArg0 = $ScriptType, CallbackArg1 = string, CallbackArg2 = string, CallbackArg3 = string> = ((arg0: CallbackArg0, arg1: CallbackArg1, arg2: CallbackArg2, arg3: CallbackArg3) => void) | $ScriptEventRegistrar;
}
