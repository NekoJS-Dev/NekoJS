import { $Codec } from "java:com/mojang/serialization";
import { $Direction, $Direction$Axis, $Direction$Axis_, $Direction_, $FrontAndTop, $FrontAndTop_ } from "java:net/minecraft/core";
import { $StringRepresentable, $StringRepresentable_ } from "java:net/minecraft/util";
import { $ITransformationExtension } from "java:net/neoforged/neoforge/common/extensions";
import { $Matrix3f, $Matrix4f, $Quaternionf, $Vector3f, $Vector4f } from "java:org/joml";

declare module "java:com/mojang/math" {
    export class $OctahedralGroup {
        static IDENTITY: $OctahedralGroup;
        static INVERSION: $OctahedralGroup;
        static INVERT_X: $OctahedralGroup;
        static INVERT_Y: $OctahedralGroup;
        static INVERT_Z: $OctahedralGroup;
        static ROT_120_NNN: $OctahedralGroup;
        static ROT_120_NNP: $OctahedralGroup;
        static ROT_120_NPN: $OctahedralGroup;
        static ROT_120_NPP: $OctahedralGroup;
        static ROT_120_PNN: $OctahedralGroup;
        static ROT_120_PNP: $OctahedralGroup;
        static ROT_120_PPN: $OctahedralGroup;
        static ROT_120_PPP: $OctahedralGroup;
        static ROT_180_EDGE_XY_NEG: $OctahedralGroup;
        static ROT_180_EDGE_XY_POS: $OctahedralGroup;
        static ROT_180_EDGE_XZ_NEG: $OctahedralGroup;
        static ROT_180_EDGE_XZ_POS: $OctahedralGroup;
        static ROT_180_EDGE_YZ_NEG: $OctahedralGroup;
        static ROT_180_EDGE_YZ_POS: $OctahedralGroup;
        static ROT_180_FACE_XY: $OctahedralGroup;
        static ROT_180_FACE_XZ: $OctahedralGroup;
        static ROT_180_FACE_YZ: $OctahedralGroup;
        static ROT_60_REF_NNN: $OctahedralGroup;
        static ROT_60_REF_NNP: $OctahedralGroup;
        static ROT_60_REF_NPN: $OctahedralGroup;
        static ROT_60_REF_NPP: $OctahedralGroup;
        static ROT_60_REF_PNN: $OctahedralGroup;
        static ROT_60_REF_PNP: $OctahedralGroup;
        static ROT_60_REF_PPN: $OctahedralGroup;
        static ROT_60_REF_PPP: $OctahedralGroup;
        static ROT_90_REF_X_NEG: $OctahedralGroup;
        static ROT_90_REF_X_POS: $OctahedralGroup;
        static ROT_90_REF_Y_NEG: $OctahedralGroup;
        static ROT_90_REF_Y_POS: $OctahedralGroup;
        static ROT_90_REF_Z_NEG: $OctahedralGroup;
        static ROT_90_REF_Z_POS: $OctahedralGroup;
        static ROT_90_X_NEG: $OctahedralGroup;
        static ROT_90_X_POS: $OctahedralGroup;
        static ROT_90_Y_NEG: $OctahedralGroup;
        static ROT_90_Y_POS: $OctahedralGroup;
        static ROT_90_Z_NEG: $OctahedralGroup;
        static ROT_90_Z_POS: $OctahedralGroup;
        static SWAP_NEG_XY: $OctahedralGroup;
        static SWAP_NEG_XZ: $OctahedralGroup;
        static SWAP_NEG_YZ: $OctahedralGroup;
        static SWAP_XY: $OctahedralGroup;
        static SWAP_XZ: $OctahedralGroup;
        static SWAP_YZ: $OctahedralGroup;
        name(): string;
        ordinal(): number;
        toString(): string;
        static values(): $OctahedralGroup[];
        static valueOf(name: string): $OctahedralGroup;
    }

    export class $Transformation implements $ITransformationExtension {
        constructor(arg0: $Matrix4f);
        constructor(arg0: $Vector3f, arg1: $Quaternionf, arg2: $Vector3f, arg3: $Quaternionf);
        static CODEC: $Codec<$Transformation>;
        static EXTENDED_CODEC: $Codec<$Transformation>;
        get leftRotation(): $Quaternionf;
        getLeftRotation(): $Quaternionf;
        get matrix(): $Matrix4f;
        getMatrix(): $Matrix4f;
        get normalMatrix(): $Matrix3f;
        getNormalMatrix(): $Matrix3f;
        get rightRotation(): $Quaternionf;
        getRightRotation(): $Quaternionf;
        get scale(): $Vector3f;
        getScale(): $Vector3f;
        get translation(): $Vector3f;
        getTranslation(): $Vector3f;
        get identity(): boolean;
        isIdentity(): boolean;
        static identity(): $Transformation;
        applyOrigin(arg0: $Vector3f): $Transformation;
        blockCenterToCorner(): $Transformation;
        blockCornerToCenter(): $Transformation;
        compose(arg0: $Transformation): $Transformation;
        equals(arg0: object): boolean;
        hashCode(): number;
        inverse(): $Transformation;
        rotateTransform(arg0: $Direction_): $Direction;
        slerp(arg0: $Transformation, arg1: number): $Transformation;
        transformNormal(arg0: $Vector3f): void;
        transformPosition(arg0: $Vector4f): void;
    }

    export type $OctahedralGroup_ = $OctahedralGroup | "IDENTITY" | "INVERSION" | "INVERT_X" | "INVERT_Y" | "INVERT_Z" | "ROT_120_NNN" | "ROT_120_NNP" | "ROT_120_NPN" | "ROT_120_NPP" | "ROT_120_PNN" | "ROT_120_PNP" | "ROT_120_PPN" | "ROT_120_PPP" | "ROT_180_EDGE_XY_NEG" | "ROT_180_EDGE_XY_POS" | "ROT_180_EDGE_XZ_NEG" | "ROT_180_EDGE_XZ_POS" | "ROT_180_EDGE_YZ_NEG" | "ROT_180_EDGE_YZ_POS" | "ROT_180_FACE_XY" | "ROT_180_FACE_XZ" | "ROT_180_FACE_YZ" | "ROT_60_REF_NNN" | "ROT_60_REF_NNP" | "ROT_60_REF_NPN" | "ROT_60_REF_NPP" | "ROT_60_REF_PNN" | "ROT_60_REF_PNP" | "ROT_60_REF_PPN" | "ROT_60_REF_PPP" | "ROT_90_REF_X_NEG" | "ROT_90_REF_X_POS" | "ROT_90_REF_Y_NEG" | "ROT_90_REF_Y_POS" | "ROT_90_REF_Z_NEG" | "ROT_90_REF_Z_POS" | "ROT_90_X_NEG" | "ROT_90_X_POS" | "ROT_90_Y_NEG" | "ROT_90_Y_POS" | "ROT_90_Z_NEG" | "ROT_90_Z_POS" | "SWAP_NEG_XY" | "SWAP_NEG_XZ" | "SWAP_NEG_YZ" | "SWAP_XY" | "SWAP_XZ" | "SWAP_YZ";
}
