import { $FamilyOptic, $FamilyOptic_, $RewriteResult, $TypeRewriteRule, $TypeRewriteRule_, $TypedOptic } from "java:com/mojang/datafixers";
import { $PointFreeRule, $PointFreeRule_ } from "java:com/mojang/datafixers/functions";
import { $Type, $Type$FieldNotFoundException, $Type$TypeMatcher, $Type$TypeMatcher_ } from "java:com/mojang/datafixers/types";
import { $RecursivePoint$RecursivePointType, $TypeTemplate } from "java:com/mojang/datafixers/types/templates";
import { $Either } from "java:com/mojang/datafixers/util";
import { $Optional } from "java:java/util";
import { $IntFunction, $IntFunction_ } from "java:java/util/function";

declare module "java:com/mojang/datafixers/types/families" {
    export interface $Algebra {
        apply(arg0: number): $RewriteResult<any, any>;
        toString(arg0: number): string;
    }

    export class $RecursiveTypeFamily implements $TypeFamily {
        constructor(arg0: string, arg1: $TypeTemplate);
        apply(arg0: number): $RecursivePoint$RecursivePointType<any>;
        buildMuType<A>(arg0: $Type<A>, arg1: $RecursiveTypeFamily): $RecursivePoint$RecursivePointType<A>;
        equals(arg0: object): boolean;
        everywhere(arg0: number, arg1: $TypeRewriteRule_<$Type<any>, $Optional<$RewriteResult<any, any>>>, arg2: $PointFreeRule_<$PointFree<any>, $Optional<$PointFree<any>>>): $Optional<$RewriteResult<any, any>>;
        findType<A, B>(arg0: number, arg1: $Type<A>, arg2: $Type<B>, arg3: $Type$TypeMatcher_<A, B, $Type<any>, $Either<$TypedOptic<any, any, A, B>, $Type$FieldNotFoundException>>, arg4: boolean): $Either<$TypedOptic<any, any, A, B>, $Type$FieldNotFoundException>;
        fold(arg0: $Algebra, arg1: $RecursiveTypeFamily): $IntFunction<$RewriteResult<any, any>>;
        hashCode(): number;
        name(): string;
        size(): number;
        template(): $TypeTemplate;
        toString(): string;
    }

    export interface $TypeFamily {
        apply(arg0: number): $Type<any>;
    }
    export const $TypeFamily: {
        familyOptic<A, B>(arg0: $IntFunction_<$TypedOptic<any, any, A, B>, number, $TypedOptic<any, any, A, B>>): $FamilyOptic<A, B>;
    };

    export type $TypeFamily_<CallbackArg0 = number, CallbackResult = $Type<any>> = ((arg0: CallbackArg0) => CallbackResult) | $TypeFamily;
}
