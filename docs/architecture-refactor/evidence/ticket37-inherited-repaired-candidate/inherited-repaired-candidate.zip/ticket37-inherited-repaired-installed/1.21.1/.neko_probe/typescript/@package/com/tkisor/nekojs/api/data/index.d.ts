import { $ScriptType, $ScriptType_ } from "java:com/tkisor/nekojs/api";
import { $Class, $Record } from "java:java/lang";
import { $HashMap } from "java:java/util";

declare module "java:com/tkisor/nekojs/api/data" {
    export class $AttachedData<T> extends $HashMap<string, object> {
        constructor(parent: T);
        get parent(): T;
        getParent(): T;
        add(key: string, data: object): void;
    }

    export interface $Binding {
        close(scriptType: $ScriptType_): void;
        name(): string;
        valueType(): $Class<any>;
        value(): object;
    }
    export const $Binding: {
        of(name: string, value: object, valueType: $Class<any>): $Binding;
        of(name: string, value: object): $Binding;
    };

    export class $NekoId extends $Record {
        constructor(namespace: string, path: string);
        static DEFAULT_NAMESPACE: string;
        getNamespace(): string;
        getPath(): string;
        static of(namespace: string, path: string): $NekoId;
        static of(value: string): $NekoId;
        asString(): string;
        equals(o: object): boolean;
        hashCode(): number;
        namespace(): string;
        path(): string;
        toString(): string;
    }

}
