    export interface $TypeScriptInheritedInterfaceTest$Values<T> {
        array(input: T[]): T[];
        echo(input: T): T;
        identity<R>(input: R): R;
        value(): T;
    }
    export const $TypeScriptInheritedInterfaceTest$Values: {
        factory(): string;
    };
    export interface $TypeScriptInheritedInterfaceTest$ChildValues<T> extends $TypeScriptInheritedInterfaceTest$Values<T> {
    }
    export interface $TypeScriptInheritedInterfaceTest$Sized {
        size(): number;
    }
    export class $TypeScriptInheritedInterfaceTest$Value<T> implements $TypeScriptInheritedInterfaceTest$ChildValues<T>, $TypeScriptInheritedInterfaceTest$Sized {
        constructor(input: T);
        array(input: T[]): T[];
        echo(input: T): T;
        echo(): number;
        identity<R>(input: R): R;
        size(): number;
        value(): T;
    }
    export class $TypeScriptInheritedInterfaceTest$TextValue extends $TypeScriptInheritedInterfaceTest$Value<string> {
        constructor(input: string);
        array(input: string[]): string[];
        echo(input: string): string;
        echo(): number;
        identity<R>(input: R): R;
        size(): number;
    }
    export class $TypeScriptInheritedInterfaceTest$RemappedParent {
        constructor();
        call(input: string): string;
    }
    export class $TypeScriptInheritedInterfaceTest$RemappedChild extends $TypeScriptInheritedInterfaceTest$RemappedParent {
        constructor();
        call(input: string): string;
        call(input: number): number;
    }
    export interface $TypeScriptInheritedInterfaceTest$ReadOnlyValue {
        getValue(): string;
    }
    export class $TypeScriptInheritedInterfaceTest$StaticSetter implements $TypeScriptInheritedInterfaceTest$ReadOnlyValue {
        constructor();
        get value(): string;
        getValue(): string;
        static setValue(input: string): void;
    }
    export class $TypeScriptInheritedInterfaceTest$RootValue {
        constructor();
        marker: string;
    }
    export class $TypeScriptInheritedInterfaceTest$Constrained<T extends $TypeScriptInheritedInterfaceTest$RootValue> {
        constructor(input: T);
        input: T;
    }
    export interface $TypeScriptInheritedInterfaceTest$GenericSource<A> {
        bounded<T extends $TypeScriptInheritedInterfaceTest$RootValue>(input: T): $TypeScriptInheritedInterfaceTest$Constrained<T>;
        transform<T>(input: A, result: T): T;
    }
    export class $TypeScriptInheritedInterfaceTest$GenericValue<T> implements $TypeScriptInheritedInterfaceTest$GenericSource<T> {
        constructor();
        bounded<T1 extends $TypeScriptInheritedInterfaceTest$RootValue>(input: T1): $TypeScriptInheritedInterfaceTest$Constrained<T1>;
        transform<T1>(input: T, result: T1): T1;
    }
