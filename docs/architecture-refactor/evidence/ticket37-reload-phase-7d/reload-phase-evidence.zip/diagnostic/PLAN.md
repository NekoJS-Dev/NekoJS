# One predeclared instrumented phase group

The three exact 7d formal groups have ended and remain FAIL/PASS as recorded.
Run exactly one five-reload original sampler session on the owned checkout,
with only the frozen two-file timing patch. Original fixtures/sampler/JDK/cache/
ports and path/reparse/process guards remain unchanged. Dirty source is allowed
only for the exact recorded instrumentation; this is not formal certification.

Direct stderr nano/epoch timestamps mark root entry/after-manager and existing
begin/step/finish transitions. Synchronous prints perturb the measured work;
differences to RTT cannot distinguish queue/auth/network individually. Root
return after-manager is a proxy just before success result construction; no
failure/exception path timing guarantee. No guest permissions or host binding
changes, profiler attachment, GUI control or unrelated process operations.

Preserve every first/remaining value and direct exits. Compare observed root/
phase spans with RTT and marker only as diagnosis. Restore the two originals
only after exact patch/source/owned-process checks; never reset or clean.
