$ErrorActionPreference='Stop'
$project='D:\mcmodDemo\NekoJS-mult'
$root=Join-Path $project 'build\ticket37-4431-multiplayer'
$installed=Join-Path $project 'build\ticket15-startup-reviewed-installed-26.2'
$shared='C:\Users\11515\AppData\Roaming\.minecraft'
if(Test-Path -LiteralPath $root){throw 'Preserve existing multiplayer profile'}
New-Item -ItemType Directory -Path $root | Out-Null
$server=Join-Path $root 'server'
New-Item -ItemType Directory -Path $server | Out-Null
New-Item -ItemType Junction -Path (Join-Path $server 'libraries') -Target (Join-Path $installed 'libraries') | Out-Null
Copy-Item -LiteralPath (Join-Path $installed 'win_args.txt') -Destination $server
foreach($rel in @('mods','nekojs\config','nekojs\startup_scripts','nekojs\server_scripts')) {New-Item -ItemType Directory -Path (Join-Path $server $rel) | Out-Null}
foreach($name in @('graal-1504336-8762962.jar','nekojs-neoforge-26.2.0-1.1.0-preview3.jar')) {Copy-Item -LiteralPath (Join-Path $installed "mods\$name") -Destination (Join-Path $server 'mods')}
Copy-Item -LiteralPath (Join-Path $installed 'nekojs\config\engine.toml') -Destination (Join-Path $server 'nekojs\config')
Copy-Item -LiteralPath (Join-Path $installed 'nekojs\startup_scripts\proof-startup.js') -Destination (Join-Path $server 'nekojs\startup_scripts')
Copy-Item -LiteralPath (Join-Path $installed 'nekojs\server_scripts\proof-dynamic.js') -Destination (Join-Path $server 'nekojs\server_scripts')
$credential=[guid]::NewGuid().ToString('N')
'eula=true' | Set-Content -LiteralPath (Join-Path $server 'eula.txt') -Encoding utf8
@('server-ip=127.0.0.1','server-port=25901','enable-rcon=true','rcon.port=25902',"rcon.password=$credential",'level-name=owned-multiplayer-proof-world','online-mode=false','view-distance=3','simulation-distance=3','max-players=4','spawn-protection=0','motd=Owned multiplayer proof') | Set-Content -LiteralPath (Join-Path $server 'server.properties') -Encoding utf8
foreach($letter in @('A','B')) {
    $client=Join-Path $root "client$letter"
    $mc=Join-Path $root "launcher$letter\.minecraft"
    foreach($rel in @('mods','nekojs\config','nekojs\startup_scripts')) {New-Item -ItemType Directory -Path (Join-Path $client $rel) | Out-Null}
    foreach($name in @('graal-1504336-8762962.jar','nekojs-neoforge-26.2.0-1.1.0-preview3.jar')) {Copy-Item -LiteralPath (Join-Path $server "mods\$name") -Destination (Join-Path $client 'mods')}
    Copy-Item -LiteralPath (Join-Path $installed 'nekojs\config\engine.toml') -Destination (Join-Path $client 'nekojs\config')
    Copy-Item -LiteralPath (Join-Path $server 'nekojs\startup_scripts\proof-startup.js') -Destination (Join-Path $client 'nekojs\startup_scripts')
    New-Item -ItemType Directory -Path (Join-Path $mc 'versions') | Out-Null
    foreach($version in @('26.2','neoforge-26.2.0.75')) {
        New-Item -ItemType Directory -Path (Join-Path $mc "versions\$version") | Out-Null
        Copy-Item -LiteralPath (Join-Path $shared "versions\$version\$version.json") -Destination (Join-Path $mc "versions\$version")
    }
    Copy-Item -LiteralPath (Join-Path $shared 'versions\26.2\26.2.jar') -Destination (Join-Path $mc 'versions\26.2')
    foreach($dependency in @('libraries','assets')) {New-Item -ItemType Junction -Path (Join-Path $mc $dependency) -Target (Join-Path $shared $dependency) | Out-Null}
    New-Item -ItemType Directory -Path (Join-Path $mc 'mcp_launcher') | Out-Null
    $identity=[guid]::NewGuid().ToString('D')
    @{accounts=@(@{type='offline';uuid=$identity;username="NekoProof$letter"});selected_account=$identity;max_memory_mb=2048;min_memory_mb=512;width=854;height=480} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $mc 'mcp_launcher\config.json') -Encoding utf8
}
Write-Output 'OWNED_MULTIPLAYER_PROFILES_PREPARED=true'
Write-Output ('ARTIFACT_SHA256='+(Get-FileHash -LiteralPath (Join-Path $server 'mods\nekojs-neoforge-26.2.0-1.1.0-preview3.jar')).Hash)
