from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
repo=Path.cwd(); tools=repo/'build/priority-closeout'
out=repo/'docs/architecture-refactor/evidence/2026-10-23-posteffects-closeout'
assert not out.exists()
audit=json.loads((tools/'ticket28-component-audit.json').read_text())
assert audit['currentSource'].startswith('88e18d84')
entries={'source-audit.json':(tools/'ticket28-component-audit.json').read_bytes()}
for row in audit['componentSources']:
 data=(repo/row['path']).read_bytes().replace(b'\r\n',b'\n')
 assert hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
 entries['source/'+row['path']]=data
counts=dict(tests=0,skipped=0,failures=0,errors=0)
for module in ['common',*[f'versions/{n}' for n in ['1.21.1','26.1.2','26.2.0','26.1.2-fabric','26.2.0-fabric']]]:
 for file in (tools/'registry-catalog-matrix'/module/'test').glob('TEST-*.xml'):
  if 'PostEffect' not in file.name and not (module=='common' and 'ScriptReloadGenerationTest' in file.name):continue
  r=ET.parse(file).getroot()
  assert int(r.get('errors','0'))==int(r.get('failures','0'))==0,file
  for k in counts:counts[k]+=int(r.get(k,'0'))
  entries['tests/'+module+'/'+file.name]=file.read_bytes()
assert counts['tests']>50,counts
for folder in ['2026-10-22-unified-client-native','2026-10-22-posteffects-legacy-installed']:
 root=repo/'docs/architecture-refactor/evidence'/folder
 result=subprocess.run(['python',str(root/'verify.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 assert result.returncode==0
 entries['prior-evidence/'+folder+'-verify.log']=result.stdout
 entries['prior-evidence/'+folder+'-manifest.json']=(root/'manifest.json').read_bytes()
entries['tools/audit-ticket28-component.py']=(tools/'audit-ticket28-component.py').read_bytes()
entries['tools/seal-ticket28-closeout.py']=Path(__file__).read_bytes()
entries['acceptance/PUBLIC-MIGRATIONS.md']=(repo/'docs/architecture-refactor/evidence/ticket37-autonomous-closeout/PUBLIC-MIGRATIONS.md').read_bytes()
summary=dict(currentSource=audit['currentSource'],installedClientSource='4405b0b0',componentUnchanged=True,componentFiles=14,oldExecutableConsumers=0,tests=counts,exactDeletionApproval='existing A28 approval only',wholeCurrentCandidateClientRetest=False,wholeReleaseAcceptance=False,physicalKeyboardAndPresentAcceptance=False,otherMigrationDeletionAuthorized=False)
entries['summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
out.mkdir()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,d in sorted(entries.items()): z.writestr(n,d)
(out/'manifest.json').write_text(json.dumps(dict(archiveSha256=hashlib.sha256((out/'evidence.zip').read_bytes()).hexdigest(),entries={n:dict(size=len(d),sha256=hashlib.sha256(d).hexdigest()) for n,d in sorted(entries.items())}),indent=2)+'\n')
print(json.dumps(dict(entries=len(entries),bytes=(out/'evidence.zip').stat().st_size,tests=counts)))
