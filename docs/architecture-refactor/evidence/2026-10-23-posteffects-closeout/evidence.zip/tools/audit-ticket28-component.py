import hashlib,json,re,subprocess
from pathlib import Path
p=Path.cwd(); out=p/'build/priority-closeout/ticket28-component-audit.json'
paths=[n for n in subprocess.check_output(['git','ls-files','common/src/main','src/main','versions'],text=True).splitlines() if '/posteffect/' in n or n.endswith('/PostEffectResourceReloadMixin.java')]
assert len(paths)==14,len(paths)
rows=[]; mentions=[]
pattern=re.compile(r'PostEffects(?:JS)?\.(?:register|unregister|has)\b|PostEffectManager\.(?:register|unregister|clearRegistered)\b')
for n in paths:
 before=subprocess.check_output(['git','show','4405b0b0:'+n]); after=subprocess.check_output(['git','show','HEAD:'+n])
 assert before==after,n
 rows.append(dict(path=n,sha256=hashlib.sha256(after).hexdigest(),unchangedFromInstalledSource=True))
files=subprocess.check_output(['git','ls-files','common/src/main','src','versions'],text=True).splitlines()
for n in files:
 if Path(n).suffix not in ['.java','.js','.ts']: continue
 file=p/n
 if not file.is_file(): continue
 for lineno,line in enumerate(file.read_text(encoding='utf-8').splitlines(),1):
  if pattern.search(line):
   assert line.lstrip().startswith(('*','//')), (n,lineno,line)
   mentions.append(dict(path=n,line=lineno,text=line.strip(),kind='comment'))
out.write_text(json.dumps(dict(installedSource='4405b0b0',currentSource=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),componentSources=rows,oldStaticSymbolMentions=mentions,sourceIdentityOnly=True,wholeCurrentCandidateClientRetest=False),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(componentSources=len(rows),executableOldSymbolConsumers=0,commentMentions=len(mentions))))
