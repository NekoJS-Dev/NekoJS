"""Run complete-game resource observations; this is not a reload performance cohort."""
import hashlib
import json
import os
import re
import socket
import subprocess
import time
import uuid
import zipfile
from pathlib import Path

repo=Path('D:/mcmodDemo/NekoJS-mult')
out=repo/'build/priority-closeout/pack-game-6bce9c23-v1'
binding=json.loads((out/'source-binding.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==binding['revision']
assert not (out/'classpath.log').exists(), 'Preserve all attempts'
for port in [25891,25892]:
    with socket.socket() as probe:probe.bind(('127.0.0.1',port))
environment=dict(os.environ)
environment['JAVA_HOME']='C:/Program Files/Java/jdk-25.0.2'
environment['PATH']=environment['JAVA_HOME']+'/bin;'+environment['PATH']
java=Path(environment['JAVA_HOME'])/'bin'
gradle=[str(repo/'gradlew.bat'),'-g','D:/mcmodDemo/NekoJS/.gradle-perf02',
    '-Dorg.gradle.java.home='+environment['JAVA_HOME'],'--offline','--no-parallel','--console=plain',
    '-I',str(out/'observation.gradle')]
execution=[]
def execute(label,args):
    start=time.monotonic()
    with (out/(label+'.log')).open('xb') as log:
        code=subprocess.run(args,cwd=repo,env=environment,stdout=log,stderr=subprocess.STDOUT,
                            creationflags=subprocess.CREATE_NO_WINDOW).returncode
    execution.append(dict(stage=label,exitCode=code,seconds=time.monotonic()-start))
    (out/'execution.json').write_text(json.dumps(execution,indent=2)+'\n')
    assert code==0,label
    print('PREPARATION_EXIT',label,code,flush=True)
execute('classpath',gradle+[':26.2.0-fabric:packGameClasspath'])
classes=out/'classes'
classes.mkdir()
classpath=';'.join([str(repo/'common/build/classes/java/main'),str(repo/'versions/26.2.0-fabric/build/classes/java/main'),
                    (out/'compile-classpath.txt').read_text()])
execute('compile',[str(java/'javac.exe'),'-encoding','UTF-8','-cp',classpath,'-d',str(classes),str(out/'PackGameObservation.java')])
metadata=dict(schemaVersion=1,id='neko_pack_observation',version='1.0.0',environment='server',
    entrypoints={'main':['neko.acceptance.PackGameObservation']},depends={'fabricloader':'>=0.19.0','nekojs':'*','java':'>=25'})
observer=out/'game/mods/neko-pack-observation.jar'
with zipfile.ZipFile(observer,'x',zipfile.ZIP_DEFLATED) as jar:
    jar.writestr('fabric.mod.json',json.dumps(metadata,indent=2)+'\n')
    for path in sorted(classes.rglob('*.class')):jar.write(path,path.relative_to(classes).as_posix())
(out/'observer-binding.json').write_text(json.dumps(dict(sha256=hashlib.sha256(observer.read_bytes()).hexdigest(),
    sourceSha256=hashlib.sha256((out/'PackGameObservation.java').read_bytes()).hexdigest()),indent=2)+'\n')
password=uuid.uuid4().hex
game=out/'game'
(game/'eula.txt').write_text('eula=true\n')
(game/'server.properties').write_text('\n'.join(['server-port=25891','server-ip=127.0.0.1','enable-rcon=true',
    'rcon.port=25892','rcon.password='+password,'online-mode=false','level-name=world','level-seed=20261020',
    'generate-structures=false','view-distance=2','simulation-distance=2','max-players=1','spawn-protection=0'])+'\n')
commands=[]
snapshots=[]
def rcon(command,timeout=120):
    start=time.monotonic()
    result=subprocess.run(['python','-X','utf8',str(repo/'bench/perf/rcon.py'),'25892',password,str(timeout),command],
        cwd=repo,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    text=result.stdout.decode('utf-8',errors='replace')
    commands.append(dict(command=command,response=text,exitCode=result.returncode,seconds=time.monotonic()-start))
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    assert result.returncode==0,'RCON transport failed: '+command
    return text
def checkpoint(operation,label,packs):
    assert 'PACK-GAME-OBSERVATION '+label+' PASS' in rcon(f'packprobe {operation} {label} {packs}'),label
def sample(label,packs,pid):
    time.sleep(1)
    checkpoint('sample',label,packs)
    resources=[json.loads(line) for line in (out/'resources.jsonl').read_text().splitlines()]
    assert resources[-1]['label']==label and resources[-1]['stage']=='sample'
    script=(f'$p=Get-Process -Id {pid}; $c=Get-CimInstance Win32_Process -Filter "ProcessId = {pid}"; '
        '[pscustomobject]@{pid=$p.Id;privateCommitBytes=$p.PrivateMemorySize64;workingSetBytes=$p.WorkingSet64;'
        f'owned=$c.CommandLine.Contains("-Dneko.pack.observation={out.as_posix()}")'+'}|ConvertTo-Json -Compress')
    measured=subprocess.run(['powershell.exe','-NoProfile','-Command',script],stdout=subprocess.PIPE,stderr=subprocess.PIPE,
        env=environment,creationflags=subprocess.CREATE_NO_WINDOW,check=True)
    process_memory=json.loads(measured.stdout.decode('utf-8-sig'))
    assert process_memory['owned'] and process_memory['pid']==pid
    (out/(label+'-process.json')).write_text(json.dumps(process_memory,indent=2)+'\n')
    execute(label+'-nmt',[str(java/'jcmd.exe'),str(pid),'VM.native_memory','summary','scale=KB'])
    text=(out/(label+'-nmt.log')).read_text()
    total=re.search(r'Total: reserved=(\d+)KB, committed=(\d+)KB',text)
    heap=re.search(r'Java Heap \(reserved=(\d+)KB, committed=(\d+)KB\)',text)
    assert total and heap,'Native memory tracking was not active'
    snapshots.append(dict(label=label,packs=packs,pid=pid,resourceRow=resources[-1],process=process_memory,
        nmtTotalCommittedKiB=int(total.group(2)),nmtHeapCommittedKiB=int(heap.group(2)),
        nmtNonHeapCommittedKiB=int(total.group(2))-int(heap.group(2))))
    (out/'memory.json').write_text(json.dumps(snapshots,indent=2)+'\n')
def enable(packs):
    for index in range(8):
        (game/f'nekojs/packs/pack{index}/.neko_pack.state.json').write_text(json.dumps(dict(enabled=index<packs))+'\n')
def reload(label,packs):
    assert 'phase=COMMIT - no errors.' in rcon('nekojs reload'),label
    checkpoint('commit',label,packs)
    print('PACK_GAME_COMMIT',label,packs,flush=True)

ready=False
normal_stop=False
accepted=False
process=None
start=time.monotonic()
try:
    with (out/'launcher.log').open('xb') as log:
        process=subprocess.Popen(gradle+[':26.2.0-fabric:runServer'],cwd=repo,env=environment,
            stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        (out/'launcher.json').write_text(json.dumps(dict(pid=process.pid,revision=binding['revision']),indent=2)+'\n')
        deadline=time.monotonic()+420
        latest=game/'logs/latest.log'
        while time.monotonic()<deadline:
            if process.poll() is not None:raise AssertionError('Game launcher exited before readiness')
            if (out/'started.json').exists() and latest.exists() and 'Done (' in latest.read_text(encoding='utf-8'):
                ready=True
                break
            time.sleep(1)
        assert ready,'Game startup deadline exceeded'
        started=json.loads((out/'started.json').read_text())
        pid=started['pid']
        assert started['enableJVMCI']=='true','Complete-game GraalMC compiler was not enabled'
        assert 'graalmc ' in latest.read_text(encoding='utf-8'),'GraalMC mod was not loaded'
        sample('legacy',0,pid)
        for packs in [1,4,8,4]:
            label='scale'+str(packs) if packs!=4 or len(snapshots)<4 else 'steady4'
            enable(packs)
            reload(label,packs)
            sample(label,packs,pid)
        for index in range(1,51):
            reload('reload'+str(index),4)
            if index%10==0:sample('window'+str(index),4,pid)
        enable(0)
        reload('disabled',0)
        sample('disabled',0,pid)
        assert rcon('stop').strip()=='Stopping the server'
        process.wait(timeout=90)
        normal_stop=process.returncode==0
        assert normal_stop,'Game launcher did not exit normally'
        accepted=True
finally:
    if process is not None and process.poll() is None:
        try:
            rcon('stop',timeout=10)
            process.wait(timeout=60)
            normal_stop=process.returncode==0
        except (AssertionError,subprocess.TimeoutExpired):
            subprocess.run(['taskkill.exe','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    (out/'result.json').write_text(json.dumps(dict(accepted=accepted,ready=ready,normalStop=normal_stop,
        launcherExitCode=None if process is None else process.poll(),seconds=time.monotonic()-start,
        diagnosticOnly=True,formalPerformanceMeasured=False),indent=2)+'\n')
current={}
for relative in ['common/build/classes/java/main','versions/26.2.0-fabric/build/classes/java/main']:
    directory=repo/relative
    for path in directory.rglob('*.class'):current[path.relative_to(directory).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
assert current==binding['classes'],'Production classes changed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==binding['revision']
print('PACK_GAME_OBSERVATION_COMPLETE',flush=True)
