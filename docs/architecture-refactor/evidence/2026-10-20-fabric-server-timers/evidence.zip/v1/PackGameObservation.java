package neko.acceptance;

import com.google.gson.Gson;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.tkisor.nekojs.api.ScriptType;
import com.tkisor.nekojs.core.lifecycle.CandidateDomainCollector;
import com.tkisor.nekojs.core.lifecycle.NekoRuntimeRoot;
import com.tkisor.nekojs.core.node.NekoNodeRuntime;
import com.tkisor.nekojs.core.node.NekoNodeTimers;
import com.tkisor.nekojs.script.ScriptContextRegistry;
import com.tkisor.nekojs.script.ScriptManager;
import graal.graalvm.polyglot.Context;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

import java.lang.management.ManagementFactory;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ScheduledExecutorService;

/** Isolated acceptance mod: records resources without changing NekoJS production classes. */
public final class PackGameObservation implements ModInitializer {
    private static final Gson JSON = new Gson();
    private static final Path OUTPUT = Path.of(System.getProperty("neko.pack.observation"));
    private static final Map<String, Integer> TICK = new HashMap<>();
    private static final Map<String, Integer> IMMEDIATES = new HashMap<>();
    private static final Map<String, Integer> INTERVALS = new HashMap<>();
    private static final List<String> CALLBACK_FAILURES = new ArrayList<>();
    private static final List<WeakReference<Context>> RETIRED = new ArrayList<>();
    private static List<Resource> active = List.of();
    private static List<Resource> pending = List.of();
    private static Set<String> activeTokens = Set.of();
    private static int nonServerContexts;
    private static int peak;
    private static int expectedPeak;
    private static int graceTicks;
    private static long checkedTicks;

    public static void tick(String owner, String token) { TICK.merge(owner+":"+token, 1, Integer::sum); }
    public static void immediate(String owner, String token) { IMMEDIATES.merge(owner+":"+token, 1, Integer::sum); }
    public static void interval(String owner, String token) { INTERVALS.merge(owner+":"+token, 1, Integer::sum); }

    @Override public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) -> {
            var root = Commands.literal("packprobe");
            for (String operation : List.of("commit", "sample")) {
                root.then(Commands.literal(operation)
                        .then(Commands.argument("label", StringArgumentType.word())
                        .then(Commands.argument("packs", IntegerArgumentType.integer(0, 8))
                        .executes(command -> {
                            String label = StringArgumentType.getString(command, "label");
                            checkpoint(operation.equals("commit"), label, IntegerArgumentType.getInteger(command, "packs"));
                            command.getSource().sendSuccess(() -> Component.literal("PACK-GAME-OBSERVATION "+label+" PASS"), false);
                            return 1;
                        }))));
            }
            dispatcher.register(root);
        });
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            try {
                NekoRuntimeRoot root = (NekoRuntimeRoot) field(
                        Class.forName("com.tkisor.nekojs.fabric.NekoJSFabricMod"), "runtimeRoot").get(null);
                require(root != null, "Runtime root was absent after server startup");
                active = serverResources();
                nonServerContexts = registered().size()-active.size();
                root.registerDomainCollector(new CandidateDomainCollector() {
                    public String domain() { return "pack-game-observation"; }
                    public ScriptType scriptType() { return ScriptType.SERVER; }
                    public void collect(Handle handle) {
                        require(pending.isEmpty(), "Unconsumed candidate observation");
                        pending = handle.candidateContexts().stream().map(Resource::capture).toList();
                        peak = registered().size();
                        expectedPeak = nonServerContexts+active.size()+pending.size();
                        require(peak == expectedPeak, "Unexpected replacement peak: "+peak+" / "+expectedPeak);
                    }
                    @Override public void reconcileAfterRemoval(Handle handle) { }
                });
                var context = active.getFirst().context();
                var row = new LinkedHashMap<String, Object>();
                row.put("pid", ProcessHandle.current().pid());
                row.put("javaVersion", System.getProperty("java.version"));
                row.put("engineVersion", context.getEngine().getVersion());
                row.put("engineImplementation", context.getEngine().getImplementationName());
                row.put("enableJVMCI", ManagementFactory.getPlatformMXBean(
                        com.sun.management.HotSpotDiagnosticMXBean.class).getVMOption("EnableJVMCI").getValue());
                row.put("baselineServerContexts", active.size());
                row.put("nonServerContexts", nonServerContexts);
                Files.writeString(OUTPUT.resolve("started.json"), JSON.toJson(row)+"\n");
            } catch (Exception failure) { throw new AssertionError("Pack observation initialization failed", failure); }
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!pending.isEmpty()) { TICK.clear(); return; }
            if (graceTicks > 0) graceTicks--;
            else if (!active.isEmpty()) {
                if (!TICK.keySet().equals(activeTokens) || TICK.values().stream().anyMatch(count -> count != 1)) {
                    CALLBACK_FAILURES.add("Unexpected callback ownership at checked tick "+checkedTicks+": "+TICK);
                }
                checkedTicks++;
            }
            TICK.clear();
        });
    }

    private static void checkpoint(boolean committed, String label, int packs) {
        try {
            if (committed) {
                require(!pending.isEmpty(), "No observed candidate batch for "+label);
                for (Resource old : active) {
                    old.assertReleased();
                    RETIRED.add(new WeakReference<>(old.context()));
                }
                active = pending;
                pending = List.of();
                var tokens = new LinkedHashSet<String>();
                for (Resource resource : active) {
                    var bindings = resource.context().getBindings("js");
                    if (bindings.hasMember("privateOwner")) {
                        String owner = bindings.getMember("privateOwner").asString();
                        String token = bindings.getMember("privateToken").asString();
                        require(tokens.add(owner+":"+token), "Duplicate active owner");
                        require(bindings.getMember("privatePayload").getArraySize() == 4096, "Private payload size changed");
                    }
                }
                activeTokens = Set.copyOf(tokens);
                graceTicks = 2;
            } else {
                require(CALLBACK_FAILURES.isEmpty(), "Callback ownership failed: "+CALLBACK_FAILURES);
                for (String token : activeTokens) require(IMMEDIATES.getOrDefault(token, 0) == 1, "Immediate did not run once: "+token);
                require(INTERVALS.isEmpty(), "Long interval fired during the observation window");
                for (int attempt=0; attempt<3; attempt++) { System.gc(); Thread.sleep(50); }
            }
            require(active.size() == packs+1 && activeTokens.size() == packs, "Independent Context count changed");
            require(registered().size() == nonServerContexts+packs+1, "Retired Context remains registered");
            for (Resource resource : active) resource.assertLive();
            long collected = RETIRED.stream().filter(reference -> reference.get() == null).count();
            var row = new LinkedHashMap<String, Object>();
            row.put("label", label);
            row.put("stage", committed ? "commit" : "sample");
            row.put("time", Instant.now().toString());
            row.put("pid", ProcessHandle.current().pid());
            row.put("packs", packs);
            row.put("serverContexts", active.size());
            row.put("registeredContexts", registered().size());
            row.put("lastPeak", peak);
            row.put("expectedPeak", expectedPeak);
            row.put("retiredContexts", RETIRED.size());
            row.put("observedCollected", collected);
            row.put("checkedTicks", checkedTicks);
            row.put("callbackFailures", List.copyOf(CALLBACK_FAILURES));
            row.put("javaHeapUsedBytes", ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed());
            row.put("liveJavaThreads", ManagementFactory.getThreadMXBean().getThreadCount());
            Files.writeString(OUTPUT.resolve("resources.jsonl"), JSON.toJson(row)+"\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception failure) { throw new AssertionError("Pack observation checkpoint failed", failure); }
    }

    @SuppressWarnings("unchecked") private static Map<Context, ScriptManager> registered() {
        try { return (Map<Context, ScriptManager>) field(ScriptManager.class, "CONTEXT_TO_MANAGER").get(null); }
        catch (ReflectiveOperationException failure) { throw new AssertionError(failure); }
    }
    private static List<Resource> serverResources() {
        return registered().keySet().stream().filter(context -> ScriptContextRegistry.scriptTypeOf(context) == ScriptType.SERVER)
                .map(Resource::capture).toList();
    }
    private static Field field(Class<?> owner, String name) {
        try { Field result=owner.getDeclaredField(name); result.setAccessible(true); return result; }
        catch (ReflectiveOperationException failure) { throw new AssertionError(failure); }
    }
    private static void require(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    private record Resource(Context context, NekoNodeTimers timers, ScheduledExecutorService scheduler) {
        static Resource capture(Context context) {
            try {
                NekoNodeRuntime node = context.getBindings("js").getMember("__nekoNodeRuntime").asHostObject();
                return new Resource(context, node.timers(), (ScheduledExecutorService) field(NekoNodeTimers.class, "scheduler").get(node.timers()));
            } catch (IllegalAccessException failure) { throw new AssertionError(failure); }
        }
        void assertLive() {
            require(ScriptContextRegistry.scriptTypeOf(context) == ScriptType.SERVER, "Active Context lost its type");
            require(ScriptManager.from(context) != null && !scheduler.isShutdown(), "Active resources are closed");
            require(context.eval("js", "21*2").asInt() == 42, "Active Context evaluation failed");
        }
        void assertReleased() throws Exception {
            boolean rejected=false;
            try { context.eval("js", "21*2"); } catch (IllegalStateException closed) { rejected=true; }
            require(rejected, "Retired Context accepted evaluation");
            require(!registered().containsKey(context), "Retired manager remains registered");
            for (String name : List.of("contextToScriptType", "contextToScriptId", "contextToBindings", "lastWrittenScriptId")) {
                require(!((Map<?, ?>) field(ScriptContextRegistry.class, name).get(null)).containsKey(context), "Retired metadata remains: "+name);
            }
            require(scheduler.isTerminated() && !timers.hasPendingCallbacks(), "Retired scheduler remains active");
            require(((Map<?, ?>) field(NekoNodeTimers.class, "tasks").get(timers)).isEmpty(), "Retired timer task remains");
            require(((Queue<?>) field(NekoNodeTimers.class, "ready").get(timers)).isEmpty(), "Retired callback remains ready");
        }
    }
}
