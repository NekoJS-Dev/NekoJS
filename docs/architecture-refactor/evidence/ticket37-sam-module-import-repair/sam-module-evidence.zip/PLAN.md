# Contextual callback host imports installed acceptance

Exact one-file common canonical patch on recorded source base. Five current
official JARs after the final full matrix; fresh dedicated worlds, existing
cached loaders and unchanged proof fixtures. Run actual generation/runtime
checks, normal RCON/direct exits, unchanged default editor includes with strict
TSC and all Python stubs. Compare diagnostic headers to prior manual item
revision; retain every new or remaining error. No edited generated output,
gate weakening, historical performance or client certification inheritance.
