DynamicRegistryEvents.dynamicRegistry(event => {
  event.item('nekojs_acceptance:tcp_seed', build => { build.maxStackSize = 16; build.rarity = 'rare'; });
});
