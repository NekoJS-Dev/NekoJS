import hashlib
import json
import shutil
from pathlib import Path

p = Path.cwd()
source = p / 'build/priority-closeout/dynamic-tcp-d91ca974-v1'
root = p / 'build/priority-closeout/dynamic-tcp-d91ca974-v2'
assert not root.exists()
root.mkdir()
for side in ['server', 'clientA', 'clientB']:
    directory = root / side
    (directory / 'nekojs/config').mkdir(parents=True)
    for scripts in ['server_scripts', 'client_scripts', 'startup_scripts']:
        (directory / 'nekojs' / scripts).mkdir()
    (directory / 'nekojs/config/engine.toml').write_text('[dynamicRegistry]\nenabled = true\n')
    (directory / 'action.txt').write_text('idle')
    shutil.copytree(source / side / 'mods', directory / 'mods', ignore=shutil.ignore_patterns('*acceptance.jar'))
    if side != 'server':
        shutil.copyfile(source / side / 'options.txt', directory / 'options.txt')
shutil.copyfile(source / 'server/eula.txt', root / 'server/eula.txt')
(root / 'server/server.properties').write_text((source / 'server/server.properties').read_text()
    .replace('28791', '28891').replace('28792', '28892'))
(root / 'server/libraries').symlink_to((source / 'server/libraries').resolve(), target_is_directory=True)
shutil.copyfile(source / 'artifact-manifest.json', root / 'artifact-manifest.json')
(root / 'build/libs').mkdir(parents=True)
helper = next((source / 'build/libs').glob('*.jar'))
shutil.copyfile(helper, root / 'build/libs' / helper.name)
descriptor = json.loads((source / 'launch-descriptor.json').read_text())
(root / 'build/moddev').mkdir()
for file in (source / 'build/moddev').iterdir():
    if file.is_file() and file.suffix in {'.txt', '.xml'}:
        content = file.read_text(encoding='utf8')
        content = content.replace(str(source).replace('\\', '\\\\'), str(root).replace('\\', '\\\\'))
        content = content.replace(source.as_posix(), root.as_posix()).replace(source.name, root.name)
        content = content.replace('127.0.0.1:28791', '127.0.0.1:28891')
        (root / 'build/moddev' / file.name).write_text(content, encoding='utf8')
for key in ['jvmArgs', 'args']:
    descriptor[key] = [value.replace(str(source), str(root)) if value.startswith('@') else value for value in descriptor[key]]
descriptor['workingDirectory'] = str(root / 'clientA')
(root / 'launch-descriptor.json').write_text(json.dumps(descriptor, indent=2) + '\n')
runner = (p / 'build/priority-closeout/run-dynamic-tcp-v1.py').read_text()
runner = runner.replace(source.name, root.name).replace('28791', '28891')
runner = runner.replace("command('nekojs reload SERVER')", "command('nekojs reload server')")
runner = runner.replace("['abortReason'] == 'ack-timeout'", "['abortReason'].startswith('ack-timeout:')")
runner = runner.replace("['abortReason'] == 'participant-disconnected'", "['abortReason'].startswith('participant-disconnected:')")
(p / 'build/priority-closeout/run-dynamic-tcp-v2.py').write_text(runner, encoding='utf8')
(root / 'preparation.json').write_text(json.dumps(dict(sourceRevision='d91ca974ba88fe3507281b47a3bdb574322c5c9d',
    freshWorld=True, previousAttempt=source.name,
    correction='Use the actual lowercase command literal; compare abort reason prefixes with participant details.',
    helperArtifactSha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
    sharedHelperOutputs=str(source / 'build'),
    launchNote='Reuses the compiled, unchanged owned helper output and cached runtime classpath; NekoJS is separately installed in each new game directory.'), indent=2) + '\n')
print(root)
