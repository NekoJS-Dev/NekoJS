import hashlib
import importlib.util
import json
import os
import re
import shutil
import socket
import subprocess
import time
from pathlib import Path

p = Path.cwd()
root = p / 'build/priority-closeout/dynamic-tcp-262-d91ca974-v1'
assert not (root / 'run-result.json').exists()
spec = importlib.util.spec_from_file_location('owned_rcon', p / 'bench/perf/rcon.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
props = dict(line.split('=', 1) for line in (root / 'server/server.properties').read_text().splitlines()
             if '=' in line and not line.startswith('#'))
descriptor = json.loads((root / 'launch-descriptor.json').read_text())
helper = next((root / 'build/libs').glob('*.jar'))
shutil.copyfile(helper, root / 'server/mods' / helper.name)
(root / 'clientB/nekojs/config/engine.toml').write_text('[dynamicRegistry]\nenabled = false\n')
processes = []
result = dict(sourceRevision='d91ca974ba88fe3507281b47a3bdb574322c5c9d', stages=[], errors=[], forced=[], exits={},
              helperSha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
              environmentKeys=list(descriptor['environment']), launchModFoldersPresent=any(
                  value.startswith('-Dfml.modFolders=') for value in descriptor['jvmArgs']))
server_ready = False


def log(name):
    file = root / (name + '-stdout.log')
    return file.read_text(encoding='utf8', errors='replace') if file.exists() else ''


def snapshot(side):
    try:
        value = json.loads((root / side / ('server-observation.json' if side == 'server' else 'client-observation.json')).read_text())
        assert value['sameThread']
        return value
    except (FileNotFoundError, json.JSONDecodeError, PermissionError):
        return None


def wait(predicate, seconds, label):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        value = predicate()
        if value:
            return value
        for name, process, side in processes:
            if name not in result['exits'] and process.poll() is not None:
                raise RuntimeError(f'{name} exited during {label}: {process.returncode}')
        time.sleep(0.2)
    raise TimeoutError(label)


def command(text):
    with socket.create_connection(('127.0.0.1', int(props['rcon.port'])), timeout=15) as connection:
        connection.settimeout(60)
        rcon.send_packet(connection, 1, 3, props['rcon.password'])
        auth = rcon.recv_packet(connection)
        assert auth is not None and auth[0] != -1
        rcon.send_packet(connection, 10, 2, text)
        response = rcon.recv_packet(connection)
        assert response is not None
    with (root / 'commands.jsonl').open('a', encoding='utf8') as output:
        output.write(json.dumps(dict(command=text, response=response[2])) + '\n')
    return response[2]


def start(name, args, side, environment=None):
    with (root / (name + '-stdout.log')).open('xb') as out, (root / (name + '-stderr.log')).open('xb') as err:
        process = subprocess.Popen(args, cwd=root / side, stdout=out, stderr=err, env=environment,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
    processes.append((name, process, side))
    (root / (name + '-owned-process.json')).write_text(json.dumps(dict(pid=process.pid, owner=root.name, side=side,
        executable=args[0]), indent=2) + '\n')
    return process


def start_client(side, name):
    folder = root / side
    (folder / 'action.txt').write_text('idle')
    program = root / 'build/moddev/clientRunProgramArgs.txt'
    copied = root / (name + '-program-arguments.txt')
    copied.write_text(program.read_text().replace('OwnedTcpA', 'OwnedTcpA' if side == 'clientA' else 'OwnedTcpB'))
    args = [value.replace(str(root / 'clientA'), str(folder)).replace('dynamic-tcp-262-d91ca974-v1-clientA', root.name + '-' + side)
            for value in descriptor['jvmArgs']]
    # The VM argfile also contains the installed-JAR property; use a side-specific copy.
    prepared = []
    for arg in args:
        if arg.startswith('@'):
            original = Path(arg[1:])
            target = root / (name + '-vm-arguments.txt')
            target.write_text(original.read_text().replace('clientA', side))
            prepared.append('@' + str(target))
        else:
            prepared.append(arg)
    arguments = [('@' + str(copied)) if value.startswith('@') and Path(value[1:]).samefile(program) else value
                 for value in descriptor['args']]
    environment = dict(os.environ, **descriptor['environment'])
    return start(name, [descriptor['java'], *prepared, '-cp', os.pathsep.join(descriptor['classpath']),
                       descriptor['mainClass'], *arguments], side, environment)


def signal(side, action):
    (root / side / 'action.txt').write_text(action)


def note(name):
    data = dict(stage=name, server=snapshot('server'), clientA=snapshot('clientA'), clientB=snapshot('clientB'))
    (root / (name + '.json')).write_text(json.dumps(data, indent=2) + '\n')
    result['stages'].append(name)
    print('TCP_STAGE_PASS', name, flush=True)
    return data


def item_present(side, path):
    value = snapshot(side)
    return value is not None and value['items'][path]['present']


def reload_items(names):
    previous = snapshot('server')['ledgerGeneration']
    script = "DynamicRegistryEvents.dynamicRegistry(event => {\n" + ''.join(
        "  event.item('nekojs_acceptance:" + name + "', build => { build.maxStackSize = 16; build.rarity = 'rare'; });\n"
        for name in names) + "});\n"
    (root / 'server/nekojs/server_scripts/owned-dynamic-items.js').write_text(script)
    command('nekojs reload server')
    wait(lambda: snapshot('server') and snapshot('server')['ledgerGeneration'] > previous, 90, 'ledger publication')
    generation = snapshot('server')['ledgerGeneration']
    return generation


def terminal(generation, committed):
    def completed():
        value = snapshot('server')
        summary = value.get('lastSummary') if value else None
        return value if summary and summary['generation'] == generation and summary['committed'] == committed else None
    return wait(completed, 60, 'transaction terminal ' + str(generation))


def outcomes(generation, outcome):
    return [value for value in snapshot('server').get('syncOutcomes', [])
            if value['generation'] == generation and value['outcome'] == outcome]


def stop_client(name, process, side):
    signal(side, 'close')
    code = process.wait(timeout=90)
    result['exits'][name] = code
    assert code == 0, (name, code)


try:
    java = 'C:/Program Files/Java/jdk-25.0.2/bin/java.exe'
    server = start('server', [java, '-Xms512M', '-Xmx2G',
        '-Dnekojs.acceptance.owner=' + root.name + '-server',
        '-Dnekojs.acceptance.jar=' + str(root / 'server/mods/nekojs-neoforge-26.2.0-1.1.0-preview3.jar'),
        '@libraries/net/neoforged/neoforge/26.2.0.75/win_args.txt', 'nogui'], 'server')
    wait(lambda: 'Done (' in log('server') and snapshot('server'), 300, 'server startup')
    server_ready = True
    assert 'OWNED-TCP-INSTALLED-SOURCE-PASS' in log('server')
    assert snapshot('server')['ledgerEmpty'] and snapshot('server')['ackTimeoutMillis'] == 10000
    assert not any(value['present'] for value in snapshot('server')['items'].values())
    a = start_client('clientA', 'clientA')
    wait(lambda: snapshot('clientA') and snapshot('clientA')['connected'], 300, 'client A join')
    b = start_client('clientB', 'clientB-disabled')
    wait(lambda: snapshot('clientB') and snapshot('clientB')['connected'], 300, 'gate-disabled B initial join')
    assert snapshot('clientA')['gateEnabled'] and not snapshot('clientB')['gateEnabled']
    note('01-empty-ledger-two-players')
    generation = reload_items(['tcp_seed'])
    rejected = terminal(generation, False)
    assert outcomes(generation, 'ack-rejected')
    assert not any(item_present(side, 'tcp_seed') for side in ['server', 'clientA', 'clientB'])
    note('02-real-prepare-nack')
    stop_client('clientB-disabled', b, 'clientB')
    wait(lambda: len(snapshot('server')['players']) == 1, 30, 'disabled B departure')
    generation = reload_items(['tcp_seed'])
    terminal(generation, True)
    wait(lambda: item_present('server', 'tcp_seed') and item_present('clientA', 'tcp_seed'), 30, 'A physical activation')
    wait(lambda: outcomes(generation, 'activation-report'), 30, 'A activation report')
    note('03-play-prepare-ack-commit')
    (root / 'clientB/nekojs/config/engine.toml').write_text('[dynamicRegistry]\nenabled = true\n')
    b = start_client('clientB', 'clientB-enabled')
    wait(lambda: snapshot('clientB') and snapshot('clientB')['connected'] and snapshot('clientB')['gateEnabled'], 300, 'late B join')
    wait(lambda: item_present('clientB', 'tcp_seed') and outcomes(generation, 'state-sync-completed'), 30, 'B configuration catch-up')
    note('04-configuration-state-sync')
    generation = reload_items(['tcp_seed', 'tcp_dual'])
    terminal(generation, True)
    wait(lambda: all(item_present(side, 'tcp_dual') for side in ['server', 'clientA', 'clientB']), 30, 'two client activation')
    assert len({value['participantId'] for value in outcomes(generation, 'ack')}) == 2
    note('05-two-distinct-prepare-acks')
    offset = len(log('clientA'))
    signal('clientA', 'block:12500')
    wait(lambda: 'OWNED-TCP-OWNER-BLOCK-BEGIN' in log('clientA')[offset:], 30, 'A owner delay')
    generation = reload_items(['tcp_seed', 'tcp_dual', 'tcp_timeout'])
    timeout = terminal(generation, False)
    assert timeout['lastSummary']['abortReason'].startswith('ack-timeout:'), timeout['lastSummary']
    wait(lambda: outcomes(generation, 'late-ack-outside-transaction'), 30, 'real late ACK')
    assert not any(item_present(side, 'tcp_timeout') for side in ['server', 'clientA', 'clientB'])
    note('06-ack-timeout-and-late-ack')
    offset = len(log('clientA'))
    signal('clientA', 'block:6000')
    wait(lambda: 'OWNED-TCP-OWNER-BLOCK-BEGIN' in log('clientA')[offset:], 30, 'A disconnect delay')
    generation = reload_items(['tcp_seed', 'tcp_dual', 'tcp_disconnect'])
    wait(lambda: snapshot('server')['status'] == 'AWAITING_ACK', 10, 'pending ACK before kick')
    command('kick OwnedTcpA Owned prepare-disconnect acceptance')
    disconnected = terminal(generation, False)
    assert disconnected['lastSummary']['abortReason'].startswith('participant-disconnected:'), disconnected['lastSummary']
    assert not item_present('server', 'tcp_disconnect') and not item_present('clientB', 'tcp_disconnect')
    note('07-prepare-disconnect-abort')
    wait(lambda: snapshot('clientA') and not snapshot('clientA')['connected'], 30, 'A disconnected menu')
    signal('clientA', 'connect:127.0.0.1:29091')
    wait(lambda: snapshot('clientA')['connected'] and len(snapshot('server')['players']) == 2, 90, 'A reconnect')
    assert all(item_present('clientA', name) for name in ['tcp_seed', 'tcp_dual'])
    assert not any(item_present(side, name) for side in ['server', 'clientA', 'clientB']
                   for name in ['tcp_timeout', 'tcp_disconnect'])
    note('08-reconnect-activated-state-only')
except Exception as error:
    result['errors'].append(repr(error))
    print('TCP_FAILURE', repr(error), flush=True)
finally:
    for name, process, side in reversed(processes):
        if side != 'server' and name not in result['exits']:
            try:
                if process.poll() is None:
                    stop_client(name, process, side)
                else:
                    result['exits'][name] = process.returncode
                    result['errors'].append(name + ' exited before normal stop')
            except Exception as error:
                result['errors'].append(name + ' shutdown: ' + repr(error))
                process.terminate()
                process.wait(timeout=30)
                result['forced'].append(name)
                result['exits'][name] = process.returncode
    if server_ready:
        try:
            command('stop')
        except Exception as error:
            result['errors'].append('server stop: ' + repr(error))
    for name, process, side in processes:
        if side == 'server':
            try:
                process.wait(timeout=90)
            except subprocess.TimeoutExpired:
                process.terminate()
                process.wait(timeout=30)
                result['forced'].append(name)
            result['exits'][name] = process.returncode
    result['verdict'] = 'PASS' if len(result['stages']) == 8 and not result['errors'] and not result['forced'] and all(
        code == 0 for code in result['exits'].values()) else 'NOT GREEN'
    (root / 'run-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
