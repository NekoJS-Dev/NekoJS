"""Prepare an isolated, opt-in TCP acceptance fixture; never alter production configuration."""
import hashlib
import json
import shutil
from pathlib import Path

p = Path.cwd()
source = p / 'build/priority-closeout/posteffects-261-installed-d91ca974-v2'
root = p / 'build/priority-closeout/dynamic-tcp-d91ca974-v1'
assert not root.exists()
root.mkdir()
shutil.copyfile(source / 'settings.gradle', root / 'settings.gradle')
(root / 'build.gradle').write_text('''plugins {
    id 'java'
    id 'net.neoforged.moddev' version '2.0.140'
}
java.toolchain.languageVersion = JavaLanguageVersion.of(25)
dependencies { compileOnly fileTree('clientA/mods') { include '*.jar' } }
neoForge {
    version = '26.1.2.71'
    mods { neko_tcp_acceptance { sourceSet(sourceSets.main) } }
    runs {
        client {
            client()
            gameDirectory = file('clientA')
            programArguments.addAll('--username', 'OwnedTcpA', '--width', '640', '--height', '400',
                    '--quickPlayMultiplayer', '127.0.0.1:28791')
            jvmArguments.addAll('-Xmx2G', '-Dnekojs.acceptance.owner=dynamic-tcp-d91ca974-v1-clientA',
                    '-Dnekojs.acceptance.jar=' + file('clientA/mods/nekojs-neoforge-26.1.2-1.1.0-preview3.jar').absolutePath)
        }
    }
}
tasks.withType(JavaCompile).configureEach { options.encoding = 'UTF-8' }
tasks.register('writeOwnedLaunch') {
    dependsOn 'prepareClientRun', 'classes'
    doLast {
        def run = tasks.named('runClient').get()
        def descriptor = [java: run.javaLauncher.get().executablePath.asFile.absolutePath,
            jvmArgs: run.allJvmArgs, classpath: run.classpathProvider.files.collect { it.absolutePath },
            mainClass: run.mainClass.get(), args: run.args,
            workingDirectory: run.gameDirectory.get().asFile.absolutePath,
            environment: run.environmentProperty.get().findAll { key, value -> key == 'MOD_CLASSES' }]
        file('launch-descriptor.json').text = groovy.json.JsonOutput.prettyPrint(groovy.json.JsonOutput.toJson(descriptor))
    }
}
''', encoding='utf8')
for side in ['server', 'clientA', 'clientB']:
    directory = root / side
    (directory / 'nekojs/config').mkdir(parents=True)
    (directory / 'nekojs/server_scripts').mkdir()
    (directory / 'nekojs/client_scripts').mkdir()
    (directory / 'nekojs/startup_scripts').mkdir()
    (directory / 'nekojs/data').mkdir()
    (directory / 'nekojs/config/engine.toml').write_text('''[dynamicRegistry]
enabled = true
''', encoding='utf8')
    (directory / 'action.txt').write_text('idle', encoding='utf8')
    shutil.copytree(source / 'client/mods', directory / 'mods')
    if side != 'server':
        shutil.copyfile(source / 'client/options.txt', directory / 'options.txt')
shutil.copyfile(source / 'server/eula.txt', root / 'server/eula.txt')
(root / 'server/server.properties').write_text((source / 'server/server.properties').read_text()
    .replace('28691', '28791').replace('28692', '28792'))
(root / 'server/libraries').symlink_to((source / 'server/libraries').resolve(), target_is_directory=True)
shutil.copyfile(source / 'artifact-manifest.json', root / 'artifact-manifest.json')
resources = root / 'src/main/resources/META-INF'
resources.mkdir(parents=True)
(resources / 'neoforge.mods.toml').write_text('''modLoader="javafml"
loaderVersion="[1,)"
license="MIT"
[[mods]]
modId="neko_tcp_acceptance"
version="1"
displayName="Owned Dynamic Registry TCP acceptance"
''', encoding='utf8')
(root / 'src/main/java/nekojs/acceptance/tcp').mkdir(parents=True)
(root / 'preparation.json').write_text(json.dumps(dict(sourceRevision='d91ca974ba88fe3507281b47a3bdb574322c5c9d',
    freshWorld=True, activationGate='Explicitly enabled only in the owned fixture directories.',
    pinnedLaunchImplementation='ModDev 2.0.140 task properties; not a stable production API.',
    status='PREPARATION ONLY; no TCP assertion executed.'), indent=2) + '\n', encoding='utf8')
print(root)
