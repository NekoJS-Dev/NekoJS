import hashlib
import json
import zipfile
from pathlib import Path

p = Path.cwd()
root = p / 'build/priority-closeout/dynamic-tcp-d91ca974-v3'
run = json.loads((root / 'run-result.json').read_text())
assert run['verdict'] == 'PASS' and not run['errors'] and not run['forced']
assert len(run['stages']) == 8 and len(run['exits']) == 4 and all(value == 0 for value in run['exits'].values())
states = [json.loads((root / (name + '.json')).read_text()) for name in run['stages']]

def outcome(state, generation, name, participant=None):
    return any(value['generation'] == generation and value['outcome'] == name
               and (participant is None or participant == value['participantId'])
               for value in state['server']['syncOutcomes'])

def properties(state, side, name):
    return state[side]['items'][name] == dict(present=True, maxStackSize=16, rarity='RARE')

assert states[0]['server']['ledgerEmpty'] and states[0]['server']['activatedGeneration'] == -1
assert states[0]['server']['ackTimeoutMillis'] == 10000 and len(states[0]['server']['players']) == 2
players = {value['name']: value['id'] for value in states[0]['server']['players']}
a, b = players['OwnedTcpA'], players['OwnedTcpB']
nack, single, catchup, dual, timeout, disconnect, reconnect = states[1:]
nack_gen = nack['server']['lastSummary']['generation']
assert not nack['server']['lastSummary']['committed'] and outcome(nack, nack_gen, 'ack-rejected', b)
assert all(not nack[side]['items']['tcp_seed']['present'] for side in ['server', 'clientA', 'clientB'])
single_gen = single['server']['activatedGeneration']
assert single['server']['lastSummary']['committed'] and outcome(single, single_gen, 'ack', a)
assert outcome(single, single_gen, 'activation-report', a)
assert all(properties(single, side, 'tcp_seed') for side in ['server', 'clientA'])
assert outcome(catchup, single_gen, 'state-sync-sent', b) and outcome(catchup, single_gen, 'state-sync-completed', b)
assert properties(catchup, 'clientB', 'tcp_seed') and catchup['clientB']['gateEnabled']
dual_gen = dual['server']['activatedGeneration']
assert dual_gen > single_gen and dual['server']['lastSummary']['committed']
assert {value['participantId'] for value in dual['server']['syncOutcomes']
        if value['generation'] == dual_gen and value['outcome'] == 'ack'} == {a, b}
assert all(properties(dual, side, name) for side in ['server', 'clientA', 'clientB'] for name in ['tcp_seed', 'tcp_dual'])
timeout_gen = timeout['server']['lastSummary']['generation']
assert timeout['server']['lastSummary']['abortReason'].startswith('ack-timeout:')
assert outcome(timeout, timeout_gen, 'late-ack-outside-transaction', a)
assert any(value['generation'] == timeout_gen and value.get('errorSource') == 'ack-timeout'
           and not value['passed'] for value in timeout['server']['phaseLog'])
disconnect_gen = disconnect['server']['lastSummary']['generation']
assert disconnect['server']['lastSummary']['abortReason'] == 'participant-disconnected:' + a
assert len(reconnect['server']['players']) == 2
assert reconnect['server']['ledgerGeneration'] == disconnect_gen > timeout_gen > dual_gen
assert reconnect['server']['activatedGeneration'] == dual_gen
assert outcome(reconnect, dual_gen, 'state-sync-sent', a) and outcome(reconnect, dual_gen, 'state-sync-completed', a)
assert all(properties(reconnect, side, name) for side in ['server', 'clientA', 'clientB'] for name in ['tcp_seed', 'tcp_dual'])
assert all(not reconnect[side]['items'][name]['present'] for side in ['server', 'clientA', 'clientB']
           for name in ['tcp_timeout', 'tcp_disconnect'])
assert all(state[side]['sameThread'] for state in states for side in ['server', 'clientA', 'clientB'] if state[side])
manifest = json.loads((root / 'artifact-manifest.json').read_text())
expected = next(value['sha256'] for value in manifest['artifacts'] if value['name'].startswith('nekojs-'))
proofs = []
for side, count in [('server', 1), ('clientA', 1), ('clientB', 2)]:
    files = list((root / side).glob('installed-source-*.json'))
    assert len(files) == count, (side, files)
    for file in files:
        proof = json.loads(file.read_text())
        jar = Path(proof['modFile'])
        assert jar.samefile(Path(proof['expectedJar'])) and hashlib.sha256(jar.read_bytes()).hexdigest() == expected
        assert proof['artifactSha256'] == expected
        with zipfile.ZipFile(jar) as archive:
            for name, binding in proof['classes'].items():
                assert jar.name in binding['codeSource'] and jar.name in binding['resource']
                assert hashlib.sha256(archive.read(name.replace('.', '/') + '.class')).hexdigest() == binding['sha256']
        proofs.append(dict(side=side, pid=proof['pid'], proof=file.name))
review = dict(verdict='PASS', sourceRevision=run['sourceRevision'], artifactSha256=expected,
    generations=dict(emptyLedger=states[0]['server']['ledgerGeneration'], nack=nack_gen, firstCommit=single_gen,
        dualCommit=dual_gen, timeout=timeout_gen, disconnect=disconnect_gen, reconnectActivated=dual_gen),
    participants=players, installedProofs=proofs, stages=run['stages'], exits=run['exits'],
    boundary='Real TCP sockets and production handlers; owner-thread delay and kick are owned fixture actions, not injected ACKs.',
    remaining=['26.2.0 runtime', 'final unified candidate', 'post-commit activation-failure degradation', 'maintainer release acceptance'])
destination = root / 'acceptance-review.json'
assert not destination.exists()
destination.write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps(review))
