"""Seal successful TCP trials and the failed setup attempts without game data or credentials."""
import hashlib
import json
import zipfile
from pathlib import Path

p = Path.cwd()
raw = p / 'build/priority-closeout'
out = p / 'docs/architecture-refactor/evidence/2026-10-22-dynamic-tcp'
assert not out.exists()
names = ['dynamic-tcp-d91ca974-v1', 'dynamic-tcp-d91ca974-v2', 'dynamic-tcp-d91ca974-v3',
         'dynamic-tcp-262-d91ca974-v1']
for name in names[2:]:
    assert json.loads((raw / name / 'acceptance-review.json').read_text())['verdict'] == 'PASS'
out.mkdir()
entries = {}
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    def add(f, name):
        assert name not in entries
        assert not any(value in name for value in ['server.properties', 'vm-arguments', 'program-arguments', 'launch-descriptor'])
        data = f.read_bytes()
        entries[name] = dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
        z.writestr(name, data)
    for name in names:
        root = raw / name
        for f in sorted(root.iterdir()):
            if f.is_file() and f.suffix in {'.json', '.jsonl', '.log', '.gradle'} and f.name != 'launch-descriptor.json':
                add(f, name + '/' + f.name)
        for f in sorted((root / 'src').rglob('*')):
            if f.is_file():
                add(f, name + '/src/' + f.relative_to(root / 'src').as_posix())
        for side in ['server', 'clientA', 'clientB']:
            directory = root / side
            for pattern in ['installed-source-*.json', '*observation*.json', '*observation*.jsonl', 'stdout.log', 'stderr.log']:
                for f in sorted(directory.glob(pattern)):
                    key = name + '/' + side + '/' + f.name
                    if key not in entries:
                        add(f, key)
            for f in sorted((directory / 'nekojs').rglob('*')):
                if f.is_file() and f.suffix in {'.js', '.toml'} and 'data' not in f.relative_to(directory / 'nekojs').parts:
                    add(f, name + '/' + side + '/nekojs/' + f.relative_to(directory / 'nekojs').as_posix())
    for f in sorted(raw.iterdir()):
        if f.is_file() and ('dynamic-tcp' in f.name) and f.suffix in {'.py', '.log'}:
            add(f, 'tooling/' + f.name)
manifest = dict(sourceRevision='d91ca974ba88fe3507281b47a3bdb574322c5c9d',
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(), entries=entries,
    successful=names[2:], failed=names[:2],
    exclusions=['worlds', 'JARs and dependencies', 'launch descriptors and argument files', 'server.properties', 'human sign-off'])
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size)))
