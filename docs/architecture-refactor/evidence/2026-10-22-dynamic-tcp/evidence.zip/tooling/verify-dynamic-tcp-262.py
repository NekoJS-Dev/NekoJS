from pathlib import Path

source = Path('build/priority-closeout/verify-dynamic-tcp-v3.py').read_text()
source = source.replace('dynamic-tcp-d91ca974-v3', 'dynamic-tcp-262-d91ca974-v1')
source = source.replace("'26.2.0 runtime', ", '')
exec(compile(source, __file__, 'exec'))
