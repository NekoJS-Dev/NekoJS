import json
import shutil
from pathlib import Path

p = Path.cwd()
source = p / 'build/priority-closeout/dynamic-tcp-d91ca974-v1'
root = p / 'build/priority-closeout/dynamic-tcp-262-d91ca974-v1'
installed = p / 'build/closeout-d91ca974-installed/26.2.0'
assert not root.exists()
root.mkdir()
shutil.copyfile(source / 'settings.gradle', root / 'settings.gradle')
build = (source / 'build.gradle').read_text().replace(source.name, root.name)
build = build.replace('26.1.2.71', '26.2.0.57').replace('neoforge-26.1.2-', 'neoforge-26.2.0-').replace('28791', '29091')
build = build.replace("jvmArguments.addAll('-Xmx2G',", "jvmArguments.add('-Dneoforge.warnings.logofile.hide=true')\n            jvmArguments.addAll('-Xmx2G',")
(root / 'build.gradle').write_text(build)
shutil.copytree(source / 'src', root / 'src')
client_source = root / 'src/main/java/nekojs/acceptance/tcp/ClientObservation.java'
client_source.write_text(client_source.read_text().replace('import com.tkisor.nekojs.core.fs.ClassFilter;',
    'import com.tkisor.nekojs.core.fs.ClassFilter;\nimport com.tkisor.nekojs.platform.compat.McClientCompat;')
    .replace('client.screen', 'McClientCompat.get().currentScreen()'))
for side in ['server', 'clientA', 'clientB']:
    directory = root / side
    (directory / 'nekojs/config').mkdir(parents=True)
    for folder in ['server_scripts', 'client_scripts', 'startup_scripts']:
        (directory / 'nekojs' / folder).mkdir()
    (directory / 'nekojs/config/engine.toml').write_text('[dynamicRegistry]\nenabled = true\n')
    (directory / 'action.txt').write_text('idle')
    shutil.copytree(installed / 'mods', directory / 'mods')
    if side != 'server':
        shutil.copyfile(source / side / 'options.txt', directory / 'options.txt')
shutil.copyfile(source / 'server/eula.txt', root / 'server/eula.txt')
(root / 'server/server.properties').write_text((source / 'server/server.properties').read_text()
    .replace('28791', '29091').replace('28792', '29092'))
(root / 'server/libraries').symlink_to((installed / 'libraries').resolve(), target_is_directory=True)
manifest = json.loads((p / 'build/closeout-d91ca974-installed/preparation-manifest.json').read_text())
node = next(value for value in manifest['nodes'] if value['node'] == '26.2.0')
(root / 'artifact-manifest.json').write_text(json.dumps(dict(sourceRevision=manifest['sourceRevision'],
    artifacts=[dict(name=f.name, sha256=__import__('hashlib').sha256(f.read_bytes()).hexdigest())
               for f in (installed / 'mods').glob('*.jar')], nodeClassBindings=node['classBindings']), indent=2) + '\n')
(root / 'preparation.json').write_text(json.dumps(dict(sourceRevision=manifest['sourceRevision'], freshWorld=True,
    clientLoader='26.2.0.57', serverLoader='26.2.0.75',
    clientScreenAccess='Existing McClientCompat facade.',
    developmentWarningPolicy='neoforge.warnings.logofile.hide=true suppresses the vendor developer icon warning only.',
    status='PREPARATION ONLY; runtime not executed.'), indent=2) + '\n')
runner = (p / 'build/priority-closeout/run-dynamic-tcp-v3.py').read_text()
runner = runner.replace('dynamic-tcp-d91ca974-v3', root.name).replace('28991', '29091')
runner = runner.replace('neoforge-26.1.2-', 'neoforge-26.2.0-').replace('26.1.2.71/win_args', '26.2.0.75/win_args')
(p / 'build/priority-closeout/run-dynamic-tcp-262.py').write_text(runner)
print(root)
