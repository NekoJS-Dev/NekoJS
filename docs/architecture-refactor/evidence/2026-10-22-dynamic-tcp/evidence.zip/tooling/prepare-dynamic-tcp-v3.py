from pathlib import Path

p = Path.cwd()
source = (p / 'build/priority-closeout/prepare-dynamic-tcp-v2.py').read_text()
source = source.replace("dynamic-tcp-d91ca974-v2'", "dynamic-tcp-d91ca974-v3'")
source = source.replace(".replace('28791', '28891').replace('28792', '28892')", ".replace('28791', '28991').replace('28792', '28992')")
source = source.replace("'127.0.0.1:28891'", "'127.0.0.1:28991'")
source = source.replace(".replace('28791', '28891')", ".replace('28791', '28991')")
source = source.replace("value.replace(str(source), str(root)) if value.startswith('@')", "value.replace(source.name, root.name) if value.startswith('@')")
source = source.replace("run-dynamic-tcp-v2.py", "run-dynamic-tcp-v3.py")
source = source.replace("Use the actual lowercase command literal; compare abort reason prefixes with participant details.",
    "Keep lowercase command and detailed abort reasons; relocate escaped @argfile references by the exact owned directory name.")
exec(compile(source, 'prepare-dynamic-tcp-v3-derived', 'exec'))
