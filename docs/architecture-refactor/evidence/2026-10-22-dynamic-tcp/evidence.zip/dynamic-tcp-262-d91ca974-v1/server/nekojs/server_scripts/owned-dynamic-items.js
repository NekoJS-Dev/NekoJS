DynamicRegistryEvents.dynamicRegistry(event => {
  event.item('nekojs_acceptance:tcp_seed', build => { build.maxStackSize = 16; build.rarity = 'rare'; });
  event.item('nekojs_acceptance:tcp_dual', build => { build.maxStackSize = 16; build.rarity = 'rare'; });
  event.item('nekojs_acceptance:tcp_disconnect', build => { build.maxStackSize = 16; build.rarity = 'rare'; });
});
