package nekojs.acceptance.tcp;

import com.google.gson.Gson;
import com.tkisor.nekojs.dynamic.DynamicRegistryFacade;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.LinkedHashMap;
import java.util.Map;

/** Samples existing coordinator diagnostics on the server owner thread without injecting protocol decisions. */
@EventBusSubscriber(modid = "neko_tcp_acceptance")
public final class ServerObservation {
    private static String previous = "";

    @SubscribeEvent
    public static void tick(ServerTickEvent.Post event) throws Exception {
        var runtime = DynamicRegistryFacade.runtime();
        var engine = runtime.activationEngine();
        Map<String, Object> state = new LinkedHashMap<>();
        state.put("sameThread", event.getServer().isSameThread());
        state.put("players", event.getServer().getPlayerList().getPlayers().stream()
                .map(player -> Map.of("name", player.getName().getString(), "id", player.getStringUUID())).toList());
        state.put("ledgerEmpty", runtime.store().isEmpty());
        state.put("ledgerGeneration", runtime.store().committedGeneration());
        state.put("items", RegistryObservation.items());
        if (engine != null) {
            state.put("status", engine.status().name());
            state.put("activatedGeneration", engine.activatedGeneration());
            state.put("lastSummary", engine.lastSummary());
            state.put("phaseLog", engine.phaseLog());
            state.put("syncOutcomes", engine.syncOutcomes());
            state.put("ackTimeoutMillis", engine.ackTimeoutMillis());
        }
        String json = new Gson().toJson(state);
        if (!previous.equals(json)) {
            RegistryObservation.write("server-observation", json);
            previous = json;
        }
    }
}
