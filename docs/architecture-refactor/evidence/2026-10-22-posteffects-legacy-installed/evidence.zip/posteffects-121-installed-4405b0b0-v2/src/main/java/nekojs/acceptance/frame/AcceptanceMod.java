package nekojs.acceptance.frame;

import com.google.gson.GsonBuilder;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipFile;

/** Verifies that this isolated launcher loads NekoJS from the installed production artifact. */
@Mod("neko_frame_acceptance")
public final class AcceptanceMod {
    public AcceptanceMod() throws Exception {
        Path expected = Path.of(System.getProperty("nekojs.acceptance.jar")).toAbsolutePath().normalize();
        Path actual = ModList.get().getModFileById("nekojs").getFile().getFilePath().toAbsolutePath().normalize();
        if (!Files.isSameFile(expected, actual)) throw new IllegalStateException("Installed NekoJS mod source mismatch: " + actual);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("expectedJar", expected.toString());
        result.put("modFile", actual.toString());
        result.put("artifactSha256", sha256(Files.readAllBytes(actual)));
        Map<String, Object> classes = new LinkedHashMap<>();
        try (ZipFile archive = new ZipFile(expected.toFile())) {
            for (String name : new String[]{"com.tkisor.nekojs.NekoJS", "com.tkisor.nekojs.client.posteffect.PostEffectManager"}) {
                Class<?> type = Class.forName(name, false, getClass().getClassLoader());
                String entry = name.replace('.', '/') + ".class";
                byte[] packaged;
                try (var input = archive.getInputStream(archive.getEntry(entry))) { packaged = input.readAllBytes(); }
                byte[] loaded;
                try (var input = type.getResourceAsStream("/" + entry)) { loaded = input.readAllBytes(); }
                if (!java.util.Arrays.equals(packaged, loaded)) throw new IllegalStateException("Installed class byte mismatch: " + name);
                String codeSource = type.getProtectionDomain().getCodeSource().getLocation().toExternalForm();
                if (!codeSource.contains(expected.getFileName().toString())) throw new IllegalStateException("Installed class code source mismatch: " + codeSource);
                classes.put(name, Map.of("sha256", sha256(loaded), "codeSource", codeSource,
                        "resource", type.getResource("/" + entry).toExternalForm()));
            }
        }
        result.put("classes", classes);
        result.put("configuredSourceModIds", java.util.List.of("neko_frame_acceptance"));
        result.put("modClassesEnvironment", System.getenv("MOD_CLASSES"));
        Files.writeString(Path.of("installed-source.json"), new GsonBuilder().setPrettyPrinting().create().toJson(result) + "\n",
                StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
        System.out.println("INSTALLED-NEKOJS-SOURCE-PASS");
    }
    private static String sha256(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
}
