package nekojs.acceptance.frame.mixin;
import nekojs.acceptance.frame.InputDriver;
import com.mojang.blaze3d.platform.InputConstants;

import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** Overrides only the held F3 query during this fixture's synchronous native key dispatch. */
@Mixin(value = InputConstants.class, remap = false)
public abstract class InputStateMixin {
    @Inject(method = "isKeyDown", at = @At("HEAD"), cancellable = true)
    private static void heldF3(long window, int key, CallbackInfoReturnable<Boolean> result) {
        if (InputDriver.f3Held() && key == GLFW.GLFW_KEY_F3) result.setReturnValue(true);
    }
}
