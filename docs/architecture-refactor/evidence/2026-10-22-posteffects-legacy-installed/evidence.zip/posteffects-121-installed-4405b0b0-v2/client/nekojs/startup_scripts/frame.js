const fs = require('node:fs');
const Minecraft = Java.type('net.minecraft.client.Minecraft');
const Screenshot = Java.type('net.minecraft.client.Screenshot');
let frame = 0;
let request = null;
NativeEvents.onEvent('net.neoforged.neoforge.client.event.RenderFrameEvent$Post', () => {
    frame++;
    const mc = Minecraft.getInstance();
    if (mc.level === null || mc.getOverlay() !== null || !fs.existsSync('nekojs/data/arm.json')) return;
    const arm = JSON.parse(String(fs.readFileSync('nekojs/data/arm.json', 'utf8')));
    if (arm.consumed) return;
    fs.writeFileSync('nekojs/data/arm.json', JSON.stringify({consumed:true,step:arm.step}));
    request = {...arm, frame, sameThread:mc.isSameThread(), overlayPresent:mc.getOverlay() !== null};
    console.info('POST-FRAME-REQUEST ' + JSON.stringify(request));
    Screenshot.grab(mc.gameDirectory, mc.getMainRenderTarget(), message => {
        console.info('POST-FRAME-SAVED ' + JSON.stringify({request,message:message.getString()}));
    });
});
console.info('POST-FRAME-LISTENERS-READY');
