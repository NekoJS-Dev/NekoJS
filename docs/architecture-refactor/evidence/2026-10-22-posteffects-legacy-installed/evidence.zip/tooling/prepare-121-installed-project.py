import hashlib
import json
import shutil
import zipfile
from pathlib import Path

p = Path.cwd()
old = p / 'build/priority-closeout/posteffects-121-f3t-final'
modern = p / 'build/priority-closeout/posteffects-261-installed-d91ca974-v2'
root = p / 'build/priority-closeout/posteffects-121-installed-d91ca974-v1'
installed = p / 'build/closeout-d91ca974-installed/1.21.1'
assert not root.exists()
root.mkdir()
shutil.copyfile(modern / 'settings.gradle', root / 'settings.gradle')
build = (modern / 'build.gradle').read_text().replace(modern.name, root.name)
build = build.replace('JavaLanguageVersion.of(25)', 'JavaLanguageVersion.of(21)').replace('26.1.2.71', '21.1.227')
build = build.replace('neoforge-26.1.2-', 'neoforge-1.21.1-').replace('1.1.0-preview3.jar', '1.1.0-preview3-server.jar')
build = build.replace('28691', '29291')
build += "\ndependencies { compileOnly fileTree(dir: 'client/mods', include: '*.jar') }\n"
(root / 'build.gradle').write_text(build)
shutil.copytree(old / 'testmod/java', root / 'src/main/java')
shutil.copytree(old / 'testmod/resources', root / 'src/main/resources')
shutil.copyfile(modern / 'src/main/java/nekojs/acceptance/frame/AcceptanceMod.java',
    root / 'src/main/java/nekojs/acceptance/frame/AcceptanceMod.java')
for side in ['client', 'server']:
    directory = root / side
    shutil.copytree(old / side / 'config', directory / 'config')
    shutil.copytree(installed / 'mods', directory / 'mods')
shutil.copytree(old / 'client/nekojs/startup_scripts', root / 'client/nekojs/startup_scripts')
shutil.copytree(old / 'client/nekojs/client_scripts', root / 'client/nekojs/client_scripts')
(root / 'client/nekojs/data').mkdir()
(root / 'client/nekojs/data/step.txt').write_text('idle')
shutil.copyfile(old / 'client/options.txt', root / 'client/options.txt')
shutil.copyfile(old / 'server/eula.txt', root / 'server/eula.txt')
(root / 'server/server.properties').write_text((old / 'server/server.properties').read_text()
    .replace('28341', '29291').replace('28342', '29292'))
(root / 'server/libraries').symlink_to((old / 'server/libraries').resolve(), target_is_directory=True)
manifest = json.loads((p / 'build/closeout-d91ca974-installed/preparation-manifest.json').read_text())
node = next(value for value in manifest['nodes'] if value['node'] == '1.21.1')
jar = next((root / 'client/mods').glob('nekojs-*.jar'))
assert hashlib.sha256(jar.read_bytes()).hexdigest() == node['sha256']
with zipfile.ZipFile(jar) as z:
    for name, expected in node['classBindings'].items():
        assert hashlib.sha256(z.read(name)).hexdigest() == expected
    assert 'com/tkisor/nekojs/client/posteffect/PostEffectManager.class' in z.namelist()
(root / 'artifact-manifest.json').write_text(json.dumps(dict(sourceRevision=manifest['sourceRevision'],
    artifacts=[dict(name=f.name, sha256=hashlib.sha256(f.read_bytes()).hexdigest())
        for f in (installed / 'mods').glob('*.jar')], nodeClassBindings=node['classBindings']), indent=2) + '\n')
runner = (p / 'build/priority-closeout/run-posteffects-121-f3t-final.py').read_text().replace(old.name, root.name)
runner = runner.replace("'--init-script', str(root / 'client.init.gradle'), ':1.21.1:runClient', '--console=plain'",
    "'--project-dir', str(root), 'runClient', '--console=plain'")
needle = "wait_for(lambda: 'PackAcceptance joined the game' in log(server), 600, 'client join')"
assert needle in runner
runner = runner.replace(needle, needle + "\n    assert 'INSTALLED-NEKOJS-SOURCE-PASS' in log(client)\n    assert (client / 'installed-source.json').is_file()")
runner = runner.replace("rejected.with_suffix('.js.rejected')", "rejected.with_suffix('.js.rejected-installed-121')")
(p / 'build/priority-closeout/run-posteffects-121-installed.py').write_text(runner)
(root / 'preparation.json').write_text(json.dumps(dict(sourceRevision=manifest['sourceRevision'], freshWorld=True,
    clientLoader='21.1.227', serverLoader='21.1.227', clientJava=21,
    artifact=jar.name, packagedClassCount=len(node['classBindings']),
    method='Independent ModDev source helper with installed production JAR, legacy 16-stage native fixture.'), indent=2) + '\n')
print(root)
