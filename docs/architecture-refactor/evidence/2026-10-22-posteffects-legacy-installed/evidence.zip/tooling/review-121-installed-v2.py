import hashlib
import json
import zipfile
from pathlib import Path

p = Path.cwd()
r = p / 'build/priority-closeout/posteffects-121-installed-4405b0b0-v2'
run = json.loads((r / 'run-result.json').read_text())
assert run['mechanicalVerdict'] == 'PASS' and len(run['stages']) == 16
assert run['clientExit'] == run['serverExit'] == 0 and not run['errors'] and not run['forced']
manifest = json.loads((r / 'artifact-manifest.json').read_text())
source = json.loads((r / 'client/installed-source.json').read_text())
assert source['artifactSha256'] == manifest['artifacts']['client']['sha256']
jar = Path(source['modFile'])
assert jar.samefile(Path(source['expectedJar']))
for side, artifact in manifest['artifacts'].items():
    file = r / side / 'mods' / artifact['name']
    assert hashlib.sha256(file.read_bytes()).hexdigest() == artifact['sha256']
    with zipfile.ZipFile(file) as z:
        for name, expected in manifest['nodeClassBindings'].items():
            assert hashlib.sha256(z.read(name)).hexdigest() == expected
for name, binding in source['classes'].items():
    assert jar.name in binding['codeSource'] and jar.name in binding['resource']
    assert binding['sha256'] == manifest['nodeClassBindings'][name.replace('.', '/') + '.class']
for stage in run['stages']:
    assert hashlib.sha256((r / stage['image']).read_bytes()).hexdigest() == stage['sha256']
assert not (r / 'pixel-review.json').exists()
original = (p / 'build/priority-closeout/review-121-f3t-final.py').read_text()
original = original.replace('posteffects-121-f3t-final', r.name)
exec(compile(original, __file__, 'exec'))
review = json.loads((r / 'pixel-review.json').read_text())
review.update(verdict='PASS', sourceRevision=manifest['sourceRevision'], sourceBindingVerified=True,
    artifactSha256=source['artifactSha256'], packagedClassCount=len(manifest['nodeClassBindings']))
(r / 'pixel-review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps(dict(verdict='PASS', frames=16, sourceRevision=manifest['sourceRevision'],
    packagedClassCount=review['packagedClassCount'], normalExits=2)))
