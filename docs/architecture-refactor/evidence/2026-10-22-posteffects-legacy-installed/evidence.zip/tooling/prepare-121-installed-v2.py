import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

p = Path.cwd()
raw = p / 'build/priority-closeout'
source = raw / 'posteffects-121-installed-d91ca974-v1'
root = raw / 'posteffects-121-installed-4405b0b0-v2'
libs = p / 'versions/1.21.1/build/libs'
assert not root.exists()
assert json.loads((source / 'run-result.json').read_text())['mechanicalVerdict'] == 'NOT GREEN'
root.mkdir()
shutil.copyfile(source / 'settings.gradle', root / 'settings.gradle')
(root / 'build.gradle').write_text((source / 'build.gradle').read_text().replace(source.name, root.name)
    .replace('1.1.0-preview3-server.jar', '1.1.0-preview3.jar').replace('29291', '29491'))
shutil.copytree(source / 'src', root / 'src')
bindings = {}
for directory in [p / 'common/build/classes/java/main', p / 'versions/1.21.1/build/classes/java/main']:
    for f in directory.rglob('*.class'):
        key = f.relative_to(directory).as_posix()
        assert key not in bindings
        bindings[key] = hashlib.sha256(f.read_bytes()).hexdigest()
artifacts = {}
for side in ['client', 'server']:
    directory = root / side
    shutil.copytree(source / side / 'config', directory / 'config')
    (directory / 'mods').mkdir()
    for f in (source / side / 'mods').glob('*.jar'):
        if not f.name.startswith('nekojs-'):
            shutil.copyfile(f, directory / 'mods' / f.name)
    artifact = libs / ('nekojs-neoforge-1.21.1-1.1.0-preview3' + ('-server' if side == 'server' else '') + '.jar')
    with zipfile.ZipFile(artifact) as z:
        for name, expected in bindings.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == expected
        assert ('META-INF/jarjar/icu4j-73.2.jar' in z.namelist()) == (side == 'server')
    shutil.copyfile(artifact, directory / 'mods' / artifact.name)
    artifacts[side] = dict(name=artifact.name, sha256=hashlib.sha256(artifact.read_bytes()).hexdigest())
for folder in ['startup_scripts', 'client_scripts']:
    shutil.copytree(source / 'client/nekojs' / folder, root / 'client/nekojs' / folder)
(root / 'client/nekojs/data').mkdir()
(root / 'client/nekojs/data/step.txt').write_text('idle')
shutil.copyfile(source / 'client/options.txt', root / 'client/options.txt')
shutil.copyfile(source / 'server/eula.txt', root / 'server/eula.txt')
(root / 'server/server.properties').write_text((source / 'server/server.properties').read_text()
    .replace('29291', '29491').replace('29292', '29492'))
(root / 'server/libraries').symlink_to((source / 'server/libraries').resolve(), target_is_directory=True)
revision = subprocess.check_output(['git', 'rev-parse', '4405b0b0'], text=True).strip()
(root / 'artifact-manifest.json').write_text(json.dumps(dict(sourceRevision=revision, artifacts=artifacts,
    nodeClassBindings=bindings, variantPolicy='Thin client JAR; server JAR embeds required ICU. Same production classes.'), indent=2) + '\n')
runner = (raw / 'run-posteffects-121-installed.py').read_text().replace(source.name, root.name)
(raw / 'run-posteffects-121-installed-v2.py').write_text(runner)
(root / 'preparation.json').write_text(json.dumps(dict(sourceRevision=revision, freshWorld=True,
    previousAttempt=source.name, correction='Use the configured thin client artifact to avoid duplicate ICU modules.',
    clientLoader='21.1.227', serverLoader='21.1.227', packagedClassCount=len(bindings)), indent=2) + '\n')
print(json.dumps(dict(root=str(root), artifacts=artifacts, packagedClassCount=len(bindings))))
