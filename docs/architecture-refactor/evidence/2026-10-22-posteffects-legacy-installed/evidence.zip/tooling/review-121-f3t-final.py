from pathlib import Path
import json,numpy as np
from PIL import Image
r=Path('build/priority-closeout/posteffects-121-f3t-final');v=json.loads((r/'run-result.json').read_text());roi=(230,200,380,260)
a={x['step']:np.asarray(Image.open(r/x['image']).crop(roi)).astype(float) for x in v['stages']};clear=a['clear-after'];effect=a['effect-after'];rows=[]
for x in v['stages']:
 n=x['step'];dc=float(np.mean(np.abs(a[n]-clear)));de=float(np.mean(np.abs(a[n]-effect)))
 if n in ['retained-native','retained-native-retired']:
  expected='native-creeper';green=float(np.mean(a[n][:,:,1]-a[n][:,:,0]));ok=green>30;row=dict(step=n,expected=expected,greenMinusRed=green,passed=ok)
 else:
  expected='clear' if n.startswith('clear-') or n in ['retained-cleared','retained-retired','effect-inactive','retained-inactive'] else 'invert';ok=dc<de if expected=='clear' else de<dc;row=dict(step=n,expected=expected,meanAbsoluteDistanceToClear=dc,meanAbsoluteDistanceToEffect=de,passed=ok)
 rows.append(row);assert ok,n
native_distance=float(np.mean(np.abs(a['retained-native']-a['retained-native-retired'])));assert native_distance<1
log=(r/'client/stdout.log').read_text(errors='replace');assert log.count('OWNED-F3T-NATIVE-PRESS-BEGIN')==7 and log.count('OWNED-F3T-NATIVE-PRESS-END held=false')==7
out=dict(roi=roi,roiSelection='Same wall region selected after original pre-fix image inspection; excludes HUD/crosshair',referenceScope='Visual classification; invert reference not a pre-registered shader-color formula',rows=rows,nativeRetirementImageDifference=native_distance,nativeKeyboardDispatches=7,screenshotsReviewed=True,reviewer='Primary agent; all sixteen original PNGs inspected. Not physical keyboard/display present/maintainer sign-off.')
(r/'pixel-review.json').write_text(json.dumps(out,indent=2));print(dict(stages=len(rows),allPassed=True,nativeRetirementImageDifference=native_distance))
