import hashlib
import json
import zipfile
from pathlib import Path

p = Path.cwd()
raw = p / 'build/priority-closeout'
out = p / 'docs/architecture-refactor/evidence/2026-10-22-posteffects-legacy-installed'
assert not (out / 'evidence.zip').exists()
names = ['posteffects-121-installed-d91ca974-v1', 'posteffects-121-installed-4405b0b0-v2']
assert json.loads((raw / names[1] / 'pixel-review.json').read_text())['verdict'] == 'PASS'
out.mkdir(exist_ok=True)
entries = {}
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    def add(f, name):
        assert name not in entries
        data = f.read_bytes()
        entries[name] = dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
        z.writestr(name, data)
    for name in names:
        trial = raw / name
        for f in sorted(trial.iterdir()):
            if f.is_file() and f.suffix in {'.json', '.jsonl', '.log', '.png', '.gradle'}:
                add(f, name + '/' + f.name)
        for f in sorted((trial / 'src').rglob('*')):
            if f.is_file():
                add(f, name + '/src/' + f.relative_to(trial / 'src').as_posix())
        for side in ['client', 'server']:
            for file in ['stdout.log', 'stderr.log', 'installed-source.json', 'owned-process.json']:
                f = trial / side / file
                if f.exists():
                    add(f, name + '/' + side + '/' + file)
            for folder in ['startup_scripts', 'client_scripts', 'server_scripts', 'config']:
                for f in sorted((trial / side / 'nekojs' / folder).rglob('*')):
                    if f.is_file() and f.suffix in {'.js', '.toml'}:
                        add(f, name + '/' + side + '/nekojs/' + folder + '/' + f.relative_to(trial / side / 'nekojs' / folder).as_posix())
    for name in ['prepare-121-installed-project.py', 'prepare-121-installed-v2.py',
                 'run-posteffects-121-installed.py', 'run-posteffects-121-installed-v2.py',
                 'review-121-installed-v2.py', 'review-121-f3t-final.py',
                 '121-installed-native-run.log', '121-installed-native-v2-run.log', 'seal-121-installed-native.py']:
        add(raw / name, 'tooling/' + name)
(out / 'manifest.json').write_text(json.dumps(dict(entries=entries,
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    sourceRevision='4405b0b0ba8e4d1665c6e1d92d1b172cc4f18349', failed=names[0], successful=names[1]), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size)))
