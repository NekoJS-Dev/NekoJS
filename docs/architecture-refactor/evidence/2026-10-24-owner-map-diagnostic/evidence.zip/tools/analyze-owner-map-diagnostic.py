"""Associate every map event with its observed reload without changing any gate."""
from collections import defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent / '6e43b827-map-diagnostic'
events = json.loads((root / 'events.json').read_text(encoding='utf-8-sig'))['recording']['events']
observations = json.loads((root / 'session/observations.json').read_text(encoding='utf-8-sig'))
session = json.loads((root / 'session/session.json').read_text(encoding='utf-8-sig'))
assert not session['forcedKill'] and not session['extra']['killed'] and session['extra']['stopChannel'] == 'rcon'
assert len(observations) == 20
reloads = [row for row in observations if row['command'] == 'nekojs reload']
assert len(reloads) == 10
groups = defaultdict(list)
rows = []
used = set()
for row in reloads:
    assert 'phase=COMMIT - no errors.' in row['response'] and row['markerMs'] is not None
    start, end = datetime.fromisoformat(row['startedUtc']), datetime.fromisoformat(row['returnedUtc'])
    current = []
    for index, event in enumerate(events):
        values = event['values']
        if start <= datetime.fromisoformat(values['startTime']) <= end:
            assert index not in used and event['type'] == 'neko.SourceMapPreparation6e'
            used.add(index)
            current.append(values)
            assert values['eventThread']['javaName'] == 'Server thread'
            key = (values['generatedPath'], values['rawSha256'], values['cacheRevision'], values['prependedLines'])
            groups[key].append(dict(pair=row['pair'], **values))
    assert len(current) == 6, (row['pair'], len(current))
    assert len({value['registryIdentity'] for value in current}) == 1
    rows.append(dict(pair=row['pair'], events=len(current), markerMs=row['markerMs'],
        parseMs=sum(value['parseNanos'] for value in current) / 1e6,
        normalizeMs=sum(value['normalizeNanos'] for value in current) / 1e6,
        parseCpuNs=sum(value['parseCpuNanos'] for value in current),
        registryIdentity=current[0]['registryIdentity']))
assert len(used) == len(events) == 60
assert len(groups) == 6 and all(len(values) == 10 for values in groups.values())
paths = []
for key, values in sorted(groups.items()):
    paths.append(dict(generatedPath=key[0], rawSha256=key[1], cacheRevision=key[2], prependedLines=key[3],
        rawChars=values[0]['rawChars'], calls=len(values), parseMs=[value['parseNanos'] / 1e6 for value in values]))
result = dict(sourceRevision=json.loads((root / 'binding.json').read_text())['revision'], diagnosticOnly=True,
    successfulReloads=10, controlQueries=10, normalStops=1, mapEvents=len(events), distinctMapKeys=len(groups),
    rows=rows, paths=paths, parseMeanMs=statistics.mean(row['parseMs'] for row in rows),
    parseMaxMs=max(row['parseMs'] for row in rows),
    normalizeMeanMs=statistics.mean(row['normalizeMs'] for row in rows),
    rawEventsSha256=hashlib.sha256((root / 'events.json').read_bytes()).hexdigest(),
    limits=['Instrumented diagnostic, different cadence and JFR overhead; not a policy sample.',
        'CPU counter resolution may be coarse; zero does not establish zero CPU cost.',
        'Repeated identity hash values alone do not prove Java object identity.',
        'Map key repetition does not authorize caching or prove end-to-end savings.'])
(root / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['rows', 'paths', 'limits']}))
