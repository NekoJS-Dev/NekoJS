"""Instrument one owned source file for a bounded, non-gating map diagnostic."""
import hashlib
import json
from pathlib import Path
import subprocess

tools = Path(__file__).resolve().parent
tree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
out = tools / '6e43b827-map-diagnostic'
revision = '6e43b82789a7dbf7b9659dc1c21fefecac662649'
relative = 'common/src/main/java/com/tkisor/nekojs/core/error/SourceMapRegistry.java'
assert not out.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
out.mkdir()
target = tree / relative
original = target.read_bytes()
(out / 'SourceMapRegistry.java.original').write_bytes(original)
source = original.decode('utf-8').replace('\r\n', '\n')
before = '''        String generatedPath = normalizeLookupPath(scriptPath);
        NormalizedSourceMap sourceMap = parse(generatedPath, sourceMapJson, prependedLineCount);'''
after = '''        MapPreparationDiagnostic profile = new MapPreparationDiagnostic();
        profile.begin();
        long normalizeStarted = System.nanoTime();
        String generatedPath = normalizeLookupPath(scriptPath);
        profile.normalizeNanos = System.nanoTime() - normalizeStarted;
        long cpuStarted = MapPreparationDiagnostic.cpuTime();
        long parseStarted = System.nanoTime();
        NormalizedSourceMap sourceMap = parse(generatedPath, sourceMapJson, prependedLineCount);
        profile.parseNanos = System.nanoTime() - parseStarted;
        long cpuEnded = MapPreparationDiagnostic.cpuTime();
        profile.parseCpuNanos = cpuStarted < 0 || cpuEnded < 0 ? -1 : cpuEnded - cpuStarted;
        profile.end();'''
assert source.count(before) == 1
source = source.replace(before, after)
before = '''        if (sourceMap.file != null && !sourceMap.file.isBlank()) {
            mappings.put(sourceMap.file, sourceMap);
            if (cacheKey != null && !cacheKey.isBlank()) {
                revisions.put(sourceMap.file, cacheKey);
            } else {
                revisions.remove(sourceMap.file);
            }
        }
    }'''
after = before[:-5] + '''        profile.generatedPath = generatedPath;
        profile.rawChars = sourceMapJson == null ? -1 : sourceMapJson.length();
        profile.rawSha256 = MapPreparationDiagnostic.digest(sourceMapJson);
        profile.cacheRevision = cacheKey;
        profile.prependedLines = prependedLineCount;
        profile.registryIdentity = System.identityHashCode(this);
        profile.commit();
    }'''
assert source.count(before) == 1
source = source.replace(before, after)
event = '''
    @jdk.jfr.Name("neko.SourceMapPreparation6e")
    @jdk.jfr.Label("Source map preparation diagnostic")
    @jdk.jfr.StackTrace(false)
    static final class MapPreparationDiagnostic extends jdk.jfr.Event {
        private static final java.lang.management.ThreadMXBean CPU =
                java.lang.management.ManagementFactory.getThreadMXBean();
        public String generatedPath;
        public String rawSha256;
        public String cacheRevision;
        public int rawChars;
        public int prependedLines;
        public int registryIdentity;
        public long normalizeNanos;
        public long parseNanos;
        public long parseCpuNanos;

        static long cpuTime() {
            return CPU.isCurrentThreadCpuTimeSupported() && CPU.isThreadCpuTimeEnabled()
                    ? CPU.getCurrentThreadCpuTime() : -1;
        }

        static String digest(String value) {
            if (value == null) return null;
            try {
                return java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256")
                        .digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            } catch (java.security.NoSuchAlgorithmException ex) {
                throw new AssertionError(ex);
            }
        }
    }
'''
source = source[:source.rfind('}')] + event + source[source.rfind('}'):]
target.write_text(source, encoding='utf-8', newline='\n')
(out / 'binding.json').write_text(json.dumps(dict(revision=revision, diagnosticOnly=True,
    bindings=[dict(path=relative, originalSha256=hashlib.sha256(original).hexdigest(),
                   instrumentedSha256=hashlib.sha256(target.read_bytes()).hexdigest())]), indent=2) + '\n')
(out / 'instrumentation.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', relative], cwd=tree))
controller = (tools / '975496d3-stage-diagnostic/diagnostic.ps1').read_text()
controller = controller.replace('975496d3-stage-diagnostic/session', '6e43b827-map-diagnostic/session')
controller = controller.replace('975496d3bddf6fc76b206921a1d09207120ca24d', revision).replace("'975496d3'", "'6e43b827'")
controller = controller.replace(').Count -ne 4)', ').Count -ne 1)')
controller = controller.replace('$pair -le 30', '$pair -le 10')
(out / 'diagnostic.ps1').write_text(controller, encoding='utf-8', newline='\n')
(out / 'run.py').write_bytes((tools / '975496d3-stage-diagnostic/run.py').read_bytes())
print(json.dumps(dict(prepared=True, revision=revision, temporarySourceFiles=1, diagnosticOnly=True)))
