import json
import os
import subprocess
import time
from pathlib import Path

tools = Path(__file__).resolve().parent
worktree = Path('D:/mcmodDemo/NekoJS-perf-606d1fff')
environment = dict(os.environ)
properties = dict(line.split('=', 1) for line in
    (worktree / 'versions/26.1.2/run/server.properties').read_text().splitlines()
    if line and not line.startswith('#') and '=' in line)
environment['NEKO_PERF_RCON_PASS'] = properties['rcon.password']
arguments = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(tools / 'diagnostic.ps1')]
started = time.monotonic()
with (tools / 'controller.log').open('xb') as out, (tools / 'controller-stderr.log').open('xb') as err:
    process = subprocess.Popen(arguments, cwd=worktree, env=environment, stdout=out, stderr=err,
                               creationflags=subprocess.CREATE_NO_WINDOW)
code = process.wait()
result = dict(exitCode=code, seconds=time.monotonic()-started)
(tools / 'exit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
raise SystemExit(code)
