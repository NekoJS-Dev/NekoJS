# Exact 93f4b259 performance diagnosis plan

The predeclared formal groups retain every sample. Reload groups [536,269,358,363,393] and [324,270,360,369,329] fail the unchanged 285.3ms gate at means 383.8 and 330.4. Startup remains in progress when this plan is written. No cause is established; the prior exact 7b PASS is a historical result, not a controlled contemporaneous comparison. All owned installed/compiler/control jobs directly settled before formal sampling. Previously existing Java daemons/workers remain untouched; their ownership and contribution are unknown.

Ranked falsifiable hypotheses for the next diagnosis window, after all current formal jobs settle:

1. Environment or unrelated persistent workload contributes. One predeclared unchanged 7b group with the original sampler/fixtures/guards under current conditions would also exceed its historical results. Do not stop unknown/user processes or replace current failing groups.
2. Marker observation includes delay beyond the actual reload body. Correlating retained RCON RTT, script marker and existing phase timings would show increased marker tail without comparable body growth. Keep marker_ms as the acceptance metric; RTT cannot replace the gate.
3. A changed Probe path executes during startup/reload and adds real work. An owned-only profile and call trace would show the allocator/rendering changes on the relevant path; if absent, that causal explanation is rejected. Source-only naming changes and old scores alone cannot prove causality.

Use read-only existing logs first, then one variable per owned profiling/control session. Preserve failures and original raw JFR locally; publish only redacted derived aggregates. No threshold, fixture, sample selection, revision mixing or path-guard changes. Overall remains NOT COMPLETE.
