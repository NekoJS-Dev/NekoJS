import gzip
import hashlib
import io
import json
import re
import socket
import subprocess
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd().resolve()
owned = root/'build/ticket37-perf-owned-ac810fa7'
repair = root/'build/ticket37-config-sync-repair'
work = root/'build/ticket37-perf-93f4b259'
out = root/'docs/architecture-refactor/evidence/ticket37-same-name-performance'
revision = '93f4b259ffafb6466918582fcfa950c2c2480d77'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git', '-C', str(owned), 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', '-C', str(owned), 'status', '--porcelain'], text=True).strip()
assert sha((owned/'bench/perf/sample.ps1').read_bytes()) == '1f9c5d14a1a586da4b3f1ca8e71b2407ce089ee8bee185418963e1b5745df0b4'
assert json.loads((repair/'same-name-performance-runner-exit.json').read_text())['exitCode'] == 0
for port in [25871, 25872]:
    with socket.socket() as guard: guard.bind(('127.0.0.1', port))
secrets = [line.partition('=')[2].encode() for line in (owned/'versions/26.1.2/run/server.properties').read_text().splitlines() if line.startswith('rcon.password=')]
def scan(data, suffix):
    if suffix == '.gz': return scan(gzip.decompress(data), '')
    if suffix == '.zip':
        with ZipFile(io.BytesIO(data)) as nested:
            for name in nested.namelist(): scan(nested.read(name), Path(name).suffix)
        return
    # The fixed cache directory shares the benchmark password's text, not its credential role.
    checked = data.replace(b'.gradle-perf02', b'[owned-gradle-cache]')
    assert not any(secret and secret in checked for secret in secrets), 'Credential value in evidence'
    assert not re.search(rb'(?m)^rcon\.password=', data), 'Credential line in evidence'
folders = []
for folder in sorted((owned/'bench/perf/out').iterdir()):
    path = folder/'samples.jsonl'
    if not path.is_file(): continue
    samples = [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    if samples and samples[0]['rev'] == revision[:8]: folders.append((folder, samples))
assert len(folders) == 3
assert [samples[0]['mode'] for _, samples in folders] == ['reload', 'reload', 'startup']
files, groups = {}, []
for index, (folder, samples) in enumerate(folders):
    mode = samples[0]['mode']
    formal = [sample for sample in samples if sample['kind'] == 'formal']
    warmup = [sample for sample in samples if sample['kind'] == 'warmup']
    assert len(formal) == 5 and len(samples) == (7 if mode == 'startup' else 5)
    assert [sample['index'] for sample in formal] == ([3, 4, 5, 6, 7] if mode == 'startup' else [1, 2, 3, 4, 5])
    assert all(sample['rev'] == revision[:8] and sample['node'] == '26.1.2' for sample in samples)
    assert all(sample['stop_channel'] == 'rcon' and not sample['forced_kill'] and not sample['killed'] and not sample.get('timeout') for sample in samples)
    if mode == 'reload': assert all('phase=COMMIT - no errors.' in sample['rcon_response'] for sample in formal)
    key = 'wall_done_ms' if mode == 'startup' else 'marker_ms'
    values = [sample[key] for sample in formal]
    assert all(isinstance(value, (int, float)) for value in values)
    mean = sum(values)/5
    threshold = 41173 if mode == 'startup' else 285.3
    label = ['reload-confirmed-1', 'reload-confirmed-2', 'startup-confirmed'][index]
    exit_status = json.loads((work/(label+'-exit.json')).read_text())['samplerExit']
    assert exit_status == 0
    groups.append(dict(group=label, folder=folder.name, mode=mode, formalValuesMs=values,
        meanMs=mean, thresholdMs=threshold, acceptanceVerdict='PASS' if mean <= threshold else 'FAIL',
        samplerExit=exit_status, warmupValuesMs=[sample[key] for sample in warmup], samples=samples))
    for path in folder.iterdir():
        if path.is_file() and path.suffix in ['.log', '.jsonl', '.txt', '.json', '.csv']:
            files['samples/'+folder.name+'/'+path.name] = path
for path in work.iterdir():
    if path.is_file() and path.suffix in ['.txt', '.json']: files['wrapper/'+path.name] = path
for path in repair.iterdir():
    if path.is_file() and 'same-name-performance' in path.name and path.name != 'same-name-performance-archive.txt':
        files['runner/'+path.name] = path
compiled = []
installed = root/'build/ticket37-same-name-import-installed'
binding = json.loads((installed/'artifact-source-binding.json').read_text())
preparation = json.loads((installed/'preparation-manifest.json').read_text())
for name, expected in binding['nodes'][0]['classHashes'].items():
    relative = 'common/build/classes/java/main/'+name
    resource = (owned/relative).read_bytes()
    assert sha(resource) == expected and resource == (root/relative).read_bytes()
    for row in preparation['nodes']:
        artifacts = list((installed/row['node']/'mods').glob('nekojs-*.jar'))
        assert len(artifacts) == 1 and sha(artifacts[0].read_bytes()) == row['sha256']
        with ZipFile(artifacts[0]) as jar: assert jar.read(name) == resource
    compiled.append(dict(path=relative, sha256=sha(resource), actualFiveInstalledClassesByteEqual=True))
assert len(compiled) == 14
fixture_hashes = json.loads((work/'fixture-hashes.json').read_text(encoding='utf-8-sig'))
assert fixture_hashes == json.loads((root/'build/ticket37-perf-cb5f7fe6/fixture-hashes.json').read_text(encoding='utf-8-sig'))
for row in fixture_hashes:
    assert sha((owned/row['path']).read_bytes()).upper() == row['sha256']
assert subprocess.run(['git', 'diff', '--quiet', 'cb5f7fe6a81d1415acff69c5e91ac430457385d5', revision, '--', 'bench/perf/fixtures']).returncode == 0
archive_path = out/'same-name-performance-evidence.zip'
assert not archive_path.exists()
entries = []
with ZipFile(archive_path, 'x', ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        scan(data, path.suffix)
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=sha(data)))
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(entries) == len(archive.namelist())
    for entry in entries: assert sha(archive.read(entry['path'])) == entry['sha256']
launch_pids = sorted({sample['pid'] for _, samples in folders for sample in samples})
assert len(launch_pids) == 9
summary = dict(sourceRevision=revision, samplerSha256=sha((owned/'bench/perf/sample.ps1').read_bytes()),
    fixtureHashes=fixture_hashes, fixturesEqualHistoricalCb5=True, compiledClasses=compiled,
    groups=groups, overall='PASS' if all(group['acceptanceVerdict'] == 'PASS' for group in groups) else 'FAIL',
    normalRconSessions=9, sessionLauncherPids=launch_pids, sessionLauncherMeaning='Sampler records cmd.exe Gradle launcher PID, not actual server JVM PID',
    directSamplerExits=[0, 0, 0], directOuterRunnerExit=0, formalPortsFree=[25871, 25872],
    archive=dict(file=archive_path.name, entries=len(entries), bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes())),
    entries=entries, exclusions=['server.properties/RCON credentials', 'worlds', 'binary artifacts', 'raw JFR', 'unrelated processes/data'],
    limitations=['Primary dedicated-server startup/reload only', 'No causal claim about the import identity correction', 'Full IDE and broader tickets remain incomplete', 'Maintainer acceptance NOT RECORDED', 'Automation PAUSED', 'Tool permission-field issue UNRESOLVED'])
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(groups=[{key:value for key,value in group.items() if key != 'samples'} for group in groups], overall=summary['overall'], archive=summary['archive'], normalRconSessions=9)))
