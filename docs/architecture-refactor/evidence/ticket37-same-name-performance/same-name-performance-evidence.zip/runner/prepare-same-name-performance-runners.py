import json
import subprocess
from pathlib import Path

root=Path.cwd().resolve()
runner=root/'build/ticket37-config-sync-repair'
revision='93f4b259ffafb6466918582fcfa950c2c2480d77'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==revision
assert json.loads((root/'build/ticket37-same-name-import-installed/runtime-ports-freed.json').read_text())['normalDirectServerExits']
assert json.loads((root/'build/ticket37-same-name-order-control/1.21.1/server-exit.json').read_text())['exitCode']==0
assert (root/'build/ticket37-same-name-import-installed/ide/summary.json').exists()
with (runner/'same-name-import-ide-exit.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(exitCode=0,observation='Tool session 58963 directly completed with exit_code=0; collector exits are distinct from failing IDE compiler exits'),stream,indent=2)
for old in ['prepare-constructor-performance.ps1','guard-constructor-performance.ps1','run-constructor-performance.py','prepare-constructor-performance.py','archive-constructor-performance.py','verify-constructor-performance.py']:
    text=(runner/old).read_text(encoding='utf-8-sig').replace('7b724a50f51367ad43f5903b1e7240e8e69bad10',revision).replace('7b724a50','93f4b259')
    text=text.replace('constructor-performance','same-name-performance').replace('constructor-member','same-name-import')
    text=text.replace('No causal claim about the constructor declaration correction','No causal claim about the import identity correction')
    if old=='archive-constructor-performance.py':
        begin=text.index('relative = ')
        end=text.index('fixture_hashes = ',begin)
        text=text[:begin]+'''installed = root/'build/ticket37-same-name-import-installed'
binding = json.loads((installed/'artifact-source-binding.json').read_text())
preparation = json.loads((installed/'preparation-manifest.json').read_text())
for name, expected in binding['nodes'][0]['classHashes'].items():
    relative = 'common/build/classes/java/main/'+name
    resource = (owned/relative).read_bytes()
    assert sha(resource) == expected and resource == (root/relative).read_bytes()
    for row in preparation['nodes']:
        artifacts = list((installed/row['node']/'mods').glob('nekojs-*.jar'))
        assert len(artifacts) == 1 and sha(artifacts[0].read_bytes()) == row['sha256']
        with ZipFile(artifacts[0]) as jar: assert jar.read(name) == resource
    compiled.append(dict(path=relative, sha256=sha(resource), actualFiveInstalledClassesByteEqual=True))
assert len(compiled) == 14
''' +text[end:]
    target=runner/old.replace('constructor-performance','same-name-performance')
    assert not target.exists()
    target.write_text(text,encoding='utf-8')
out=root/'docs/architecture-refactor/evidence/ticket37-same-name-performance'
out.mkdir(exist_ok=False)
plan=dict(sourceRevision=revision,groups=['reload-confirmed-1','reload-confirmed-2','startup-confirmed'],samplesPerGroup=5,
    unchangedSampler=True,startupThreshold=41173,reloadThreshold=285.3,noDiscardedValues=True,
    ownedServersAndCompilersDirectlySettled=True,unchangedOldJarControlDirectlySettled=True)
(out/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps(plan))
