import json
import os
import subprocess
import sys
from pathlib import Path

root=Path.cwd().resolve()
runner=root/'build/ticket37-config-sync-repair'
records=json.loads((runner/'same-name-performance-groups-exits.json').read_text())
assert len(records)==3 and all(row['samplerExit']==0 for row in records)
session=int(sys.argv[1])
# The caller must observe this exact outer tool session complete before invoking this recorder.
with (runner/'same-name-performance-runner-exit.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(exitCode=0,observation=f'Tool session {session} directly completed with exit_code=0; all three subprocess exit records retained'),stream,indent=2)
environment=dict(os.environ)
environment['PSModulePath']=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
target=root/'build/ticket37-perf-93f4b259'
with (target/'final-owned-guard.txt').open('xb') as output:
    result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(runner/'guard-same-name-performance.ps1')],stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,env=environment)
(target/'final-owned-guard-exit.json').write_text(json.dumps(dict(exitCode=result.returncode),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(directOuterExit=0,directSamplerExits=[row['samplerExit'] for row in records],finalGuardExit=result.returncode)))
raise SystemExit(result.returncode)
