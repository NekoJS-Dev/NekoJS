"""Archive the current four-stage rollback proof without credentials or world binaries."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
trial = repo / 'build/closeout-method-bounds-rollback'
out = repo / 'docs/architecture-refactor/evidence/2026-10-24-candidate-rollback'
assert not out.exists()
final = json.loads((trial / 'final-verdict.json').read_text())
assert final['verdict'] == 'PASS'
binding = json.loads((tools / 'method-bounds-rollback-binding.json').read_text())
phases = ['baseline-initial', 'candidate-advance', 'artifact-rollback', 'data-restore']
secrets = set()
for phase in phases:
    props = dict(line.split('=', 1) for line in (trial / phase / 'server.properties').read_text().splitlines()
                 if '=' in line and not line.startswith('#'))
    secrets.add(props['rcon.password'])
entries = {}
redactions = {}
def add(name, file):
    original = data = file.read_bytes()
    for secret in secrets:
        if secret:
            for encoding in ['utf8', 'utf-16-le', 'utf-16-be']:
                data = data.replace(secret.encode(encoding), '[REDACTED]'.encode(encoding))
    if original != data:
        redactions[name] = hashlib.sha256(original).hexdigest()
    assert name not in entries
    entries[name] = data
for name in ['summary.json', 'backup-manifest.json', 'final-verdict.json']:
    add(name, trial / name)
for phase in phases:
    result = json.loads((trial / phase / 'result.json').read_text())
    assert result['exitCode'] == 0 and result['verdict'] == 'PASS'
    for name in ['preparation.json', 'result.json', 'commands.json', 'owned-process.json', 'server-stdout.log', 'server-stderr.log']:
        add(phase + '/' + name, trial / phase / name)
    add(phase + '/pdata-proof.js', trial / phase / 'nekojs/server_scripts/pdata-proof.js')
for name in ['prepare-method-bounds-rollback.py', 'rollback-method-bounds.py', 'rollback-4405b0b0.py',
             'method-bounds-rollback-run.log', 'method-bounds-rollback-binding.json', 'seal-method-bounds-rollback.py']:
    add('tools/' + name, tools / name)
add('tools/rcon.py', repo / 'bench/perf/rcon.py')
candidate = binding['candidate']
jar = trial / 'candidate-advance/mods' / candidate['artifact']
assert hashlib.sha256(jar.read_bytes()).hexdigest() == candidate['sha256']
add('artifact/' + candidate['artifact'], jar)
assert entries['artifact/' + candidate['artifact']] == jar.read_bytes(), 'Artifact must remain byte-identical'
with zipfile.ZipFile(jar) as archive:
    for name, digest in candidate['classBindings'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
out.mkdir()
with zipfile.ZipFile(out / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(out / 'manifest.json').write_text(json.dumps(dict(
    archiveSha256=hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest(),
    oldRevision='d91ca974', candidateRevision=binding['sourceRevision'],
    entries={name: dict(size=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(entries.items())},
    redactedOriginalHashes=redactions,
    exclusions=['world binaries', 'runtime libraries', 'server.properties', 'human release acceptance']), indent=2) + '\n')
print(json.dumps(dict(entries=len(entries), bytes=(out / 'evidence.zip').stat().st_size, normalExits=4)))
