"""Bind the existing four-stage rollback rehearsal to the installed method-bound candidate."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd()
tools = repo / 'build/priority-closeout'
installed = repo / 'build/closeout-method-bounds-installed'
prep = json.loads((installed / 'preparation-manifest.json').read_text())
revision = '975496d3bddf6fc76b206921a1d09207120ca24d'
assert prep['sourceRevision'] == revision
node = next(row for row in prep['nodes'] if row['node'] == '26.1.2')
artifact = installed / node['node'] / 'mods' / node['artifact']
assert hashlib.sha256(artifact.read_bytes()).hexdigest() == node['sha256'] == '2206b92413bb4c9ac3f1d5f5cc2d7b3a9df95631e7defdd5c0d6ee368b9b2132'
with zipfile.ZipFile(artifact) as jar:
    for name, digest in node['classBindings'].items():
        assert hashlib.sha256(jar.read(name)).hexdigest() == digest
original = (tools / 'rollback-4405b0b0.py').read_text()
text = original.replace('build/closeout-4405b0b0-rollback', 'build/closeout-method-bounds-rollback')
text = text.replace('build/closeout-4405b0b0-installed/26.1.2', 'build/closeout-method-bounds-installed/26.1.2')
text = text.replace("'4405b0b0'", repr(revision)).replace('29331 + index * 10', '29631 + index * 10')
assert original != text and '4405b0b0' not in text
output = tools / 'rollback-method-bounds.py'
assert not output.exists()
output.write_text(text, encoding='utf-8', newline='\n')
(tools / 'method-bounds-rollback-binding.json').write_text(json.dumps(dict(
    sourceRevision=revision, candidate=node, originalToolSha256=hashlib.sha256(original.encode()).hexdigest(),
    preparedToolSha256=hashlib.sha256(output.read_bytes()).hexdigest(),
    scope='Same four-stage public pdata and physical world proof; fresh owned directories and ports.'), indent=2) + '\n')
print(json.dumps(dict(prepared=True, classBindings=len(node['classBindings']), candidateSha256=node['sha256'])))
